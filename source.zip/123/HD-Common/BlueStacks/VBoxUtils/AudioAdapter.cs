﻿using System;
using System.Xml.Serialization;

namespace BlueStacks.VBoxUtils
{
	// Token: 0x02000044 RID: 68
	[XmlRoot(ElementName = "AudioAdapter", Namespace = "http://www.virtualbox.org/")]
	public class AudioAdapter
	{
		// Token: 0x17000055 RID: 85
		// (get) Token: 0x06000142 RID: 322 RVA: 0x0000297D File Offset: 0x00000B7D
		// (set) Token: 0x06000143 RID: 323 RVA: 0x00002985 File Offset: 0x00000B85
		[XmlAttribute(AttributeName = "driver")]
		public string Driver { get; set; }

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x06000144 RID: 324 RVA: 0x0000298E File Offset: 0x00000B8E
		// (set) Token: 0x06000145 RID: 325 RVA: 0x00002996 File Offset: 0x00000B96
		[XmlAttribute(AttributeName = "enabled")]
		public string Enabled { get; set; }
	}
}
