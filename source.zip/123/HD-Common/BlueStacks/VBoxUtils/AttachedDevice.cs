﻿using System;
using System.Xml.Serialization;

namespace BlueStacks.VBoxUtils
{
	// Token: 0x0200004A RID: 74
	[XmlRoot(ElementName = "AttachedDevice", Namespace = "http://www.virtualbox.org/")]
	public class AttachedDevice
	{
		// Token: 0x1700006C RID: 108
		// (get) Token: 0x06000176 RID: 374 RVA: 0x00002B04 File Offset: 0x00000D04
		// (set) Token: 0x06000177 RID: 375 RVA: 0x00002B0C File Offset: 0x00000D0C
		[XmlElement(ElementName = "Image", Namespace = "http://www.virtualbox.org/")]
		public Image Image { get; set; }

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x06000178 RID: 376 RVA: 0x00002B15 File Offset: 0x00000D15
		// (set) Token: 0x06000179 RID: 377 RVA: 0x00002B1D File Offset: 0x00000D1D
		[XmlAttribute(AttributeName = "type")]
		public string Type { get; set; }

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x0600017A RID: 378 RVA: 0x00002B26 File Offset: 0x00000D26
		// (set) Token: 0x0600017B RID: 379 RVA: 0x00002B2E File Offset: 0x00000D2E
		[XmlAttribute(AttributeName = "port")]
		public string Port { get; set; }

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x0600017C RID: 380 RVA: 0x00002B37 File Offset: 0x00000D37
		// (set) Token: 0x0600017D RID: 381 RVA: 0x00002B3F File Offset: 0x00000D3F
		[XmlAttribute(AttributeName = "device")]
		public string Device { get; set; }
	}
}
