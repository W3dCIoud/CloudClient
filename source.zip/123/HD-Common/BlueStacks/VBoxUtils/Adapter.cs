﻿using System;
using System.Xml.Serialization;

namespace BlueStacks.VBoxUtils
{
	// Token: 0x02000040 RID: 64
	[XmlRoot(ElementName = "Adapter", Namespace = "http://www.virtualbox.org/")]
	public class Adapter
	{
		// Token: 0x17000048 RID: 72
		// (get) Token: 0x06000124 RID: 292 RVA: 0x000028A0 File Offset: 0x00000AA0
		// (set) Token: 0x06000125 RID: 293 RVA: 0x000028A8 File Offset: 0x00000AA8
		[XmlElement(ElementName = "DisabledModes", Namespace = "http://www.virtualbox.org/")]
		public DisabledModes DisabledModes { get; set; }

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x06000126 RID: 294 RVA: 0x000028B1 File Offset: 0x00000AB1
		// (set) Token: 0x06000127 RID: 295 RVA: 0x000028B9 File Offset: 0x00000AB9
		[XmlElement(ElementName = "NAT", Namespace = "http://www.virtualbox.org/")]
		public string NAT { get; set; }

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x06000128 RID: 296 RVA: 0x000028C2 File Offset: 0x00000AC2
		// (set) Token: 0x06000129 RID: 297 RVA: 0x000028CA File Offset: 0x00000ACA
		[XmlAttribute(AttributeName = "slot")]
		public string Slot { get; set; }

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x0600012A RID: 298 RVA: 0x000028D3 File Offset: 0x00000AD3
		// (set) Token: 0x0600012B RID: 299 RVA: 0x000028DB File Offset: 0x00000ADB
		[XmlAttribute(AttributeName = "enabled")]
		public string Enabled { get; set; }

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x0600012C RID: 300 RVA: 0x000028E4 File Offset: 0x00000AE4
		// (set) Token: 0x0600012D RID: 301 RVA: 0x000028EC File Offset: 0x00000AEC
		[XmlAttribute(AttributeName = "MACAddress")]
		public string MACAddress { get; set; }

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x0600012E RID: 302 RVA: 0x000028F5 File Offset: 0x00000AF5
		// (set) Token: 0x0600012F RID: 303 RVA: 0x000028FD File Offset: 0x00000AFD
		[XmlAttribute(AttributeName = "cable")]
		public string Cable { get; set; }

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x06000130 RID: 304 RVA: 0x00002906 File Offset: 0x00000B06
		// (set) Token: 0x06000131 RID: 305 RVA: 0x0000290E File Offset: 0x00000B0E
		[XmlAttribute(AttributeName = "type")]
		public string Type { get; set; }
	}
}
