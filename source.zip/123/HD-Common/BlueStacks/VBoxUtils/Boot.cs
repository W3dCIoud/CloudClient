﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace BlueStacks.VBoxUtils
{
	// Token: 0x02000033 RID: 51
	[XmlRoot(ElementName = "Boot", Namespace = "http://www.virtualbox.org/")]
	public class Boot
	{
		// Token: 0x17000035 RID: 53
		// (get) Token: 0x060000F1 RID: 241 RVA: 0x0000275D File Offset: 0x0000095D
		// (set) Token: 0x060000F2 RID: 242 RVA: 0x00002765 File Offset: 0x00000965
		[XmlElement(ElementName = "Order", Namespace = "http://www.virtualbox.org/")]
		public List<Order> Order { get; set; }
	}
}
