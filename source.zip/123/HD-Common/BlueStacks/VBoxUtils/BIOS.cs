﻿using System;
using System.Xml.Serialization;

namespace BlueStacks.VBoxUtils
{
	// Token: 0x02000039 RID: 57
	[XmlRoot(ElementName = "BIOS", Namespace = "http://www.virtualbox.org/")]
	public class BIOS
	{
		// Token: 0x1700003D RID: 61
		// (get) Token: 0x06000107 RID: 263 RVA: 0x000027E5 File Offset: 0x000009E5
		// (set) Token: 0x06000108 RID: 264 RVA: 0x000027ED File Offset: 0x000009ED
		[XmlElement(ElementName = "IOAPIC", Namespace = "http://www.virtualbox.org/")]
		public IOAPIC IOAPIC { get; set; }

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x06000109 RID: 265 RVA: 0x000027F6 File Offset: 0x000009F6
		// (set) Token: 0x0600010A RID: 266 RVA: 0x000027FE File Offset: 0x000009FE
		[XmlElement(ElementName = "Logo", Namespace = "http://www.virtualbox.org/")]
		public Logo Logo { get; set; }

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x0600010B RID: 267 RVA: 0x00002807 File Offset: 0x00000A07
		// (set) Token: 0x0600010C RID: 268 RVA: 0x0000280F File Offset: 0x00000A0F
		[XmlElement(ElementName = "BootMenu", Namespace = "http://www.virtualbox.org/")]
		public BootMenu BootMenu { get; set; }
	}
}
