﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000193 RID: 403
	public enum InstallerWrapperCodes
	{
		// Token: 0x04000A9C RID: 2716
		NO_INSTALLER_FOUND = -1
	}
}
