﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x02000097 RID: 151
	public class CornerRadiusToDoubleConvertor : MarkupExtension, IValueConverter
	{
		// Token: 0x06000373 RID: 883 RVA: 0x00003F5C File Offset: 0x0000215C
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return CornerRadiusToDoubleConvertor.Convert(value, targetType);
		}

		// Token: 0x06000374 RID: 884 RVA: 0x00003F5C File Offset: 0x0000215C
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return CornerRadiusToDoubleConvertor.Convert(value, targetType);
		}

		// Token: 0x06000375 RID: 885 RVA: 0x00016A88 File Offset: 0x00014C88
		public static object Convert(object value, Type targetType)
		{
			if (typeof(double).Equals(targetType))
			{
				return ((CornerRadius)value).TopLeft;
			}
			return value;
		}

		// Token: 0x06000376 RID: 886 RVA: 0x00003F48 File Offset: 0x00002148
		public override object ProvideValue(IServiceProvider serviceProvider)
		{
			return this;
		}
	}
}
