﻿using System;
using System.IO;

namespace BlueStacks.Common
{
	// Token: 0x02000059 RID: 89
	public class ForceDedicatedGPU
	{
		// Token: 0x060001EB RID: 491 RVA: 0x0000F434 File Offset: 0x0000D634
		public static bool ToggleDedicatedGPU(bool enable, string binPath = null)
		{
			try
			{
				if (binPath == null)
				{
					binPath = Path.Combine(RegistryStrings.InstallDir, "HD-ForceGPU.exe");
				}
				string args = enable ? "1" : "0";
				return RunCommand.RunCmd(binPath, args, true, true, false, 0).ExitCode == 0;
			}
			catch (Exception ex)
			{
				Logger.Error("An error occured while running {0}, Ex: {1}", new object[]
				{
					binPath,
					ex
				});
			}
			return false;
		}

		// Token: 0x040000F3 RID: 243
		private const string ENABLE_ARG = "1";

		// Token: 0x040000F4 RID: 244
		private const string DISABLE_ARG = "0";
	}
}
