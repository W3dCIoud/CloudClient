﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000189 RID: 393
	public class InstallerStatsEvent
	{
		// Token: 0x040009B9 RID: 2489
		public const string InstallStarted = "install_launched";

		// Token: 0x040009BA RID: 2490
		public const string InstallAborted = "install_aborted_by_user";

		// Token: 0x040009BB RID: 2491
		public const string InstallLicenseAgreed = "install_license_agreed";

		// Token: 0x040009BC RID: 2492
		public const string InstallChecksPassed = "install_checks_passed";

		// Token: 0x040009BD RID: 2493
		public const string InstallCompleted = "install_completed";

		// Token: 0x040009BE RID: 2494
		public const string InstallFailed = "install_failed";

		// Token: 0x040009BF RID: 2495
		public const string UpgradeLaunched = "upgrade_launched";

		// Token: 0x040009C0 RID: 2496
		public const string BackupCancel = "backup_cancel";

		// Token: 0x040009C1 RID: 2497
		public const string BackupContinue = "backup_continue";

		// Token: 0x040009C2 RID: 2498
		public const string BackupCross = "backup_cross";

		// Token: 0x040009C3 RID: 2499
		public const string UpgradeStart = "upgrade_start";

		// Token: 0x040009C4 RID: 2500
		public const string UpgradeAborted = "upgrade_aborted_by_user";

		// Token: 0x040009C5 RID: 2501
		public const string UpgradeCleaned = "upgrade_cleaned";

		// Token: 0x040009C6 RID: 2502
		public const string UpgradeChecksPassed = "upgrade_checks_passed";

		// Token: 0x040009C7 RID: 2503
		public const string UpgradeCompleted = "upgrade_completed";

		// Token: 0x040009C8 RID: 2504
		public const string UpgradeFailed = "upgrade_failed";

		// Token: 0x040009C9 RID: 2505
		public const string MiLaunched = "mi_launched";

		// Token: 0x040009CA RID: 2506
		public const string MiUacPrompted = "mi_uac_prompted";

		// Token: 0x040009CB RID: 2507
		public const string MiUacPromptRetried = "mi_uac_prompt_retried";

		// Token: 0x040009CC RID: 2508
		public const string MiAdminLaunched = "mi_admin_launched";

		// Token: 0x040009CD RID: 2509
		public const string MiBackupContinue = "mi_backup_continue";

		// Token: 0x040009CE RID: 2510
		public const string MiBackupCancel = "mi_backup_cancel";

		// Token: 0x040009CF RID: 2511
		public const string MiBackupCross = "mi_backup_cross";

		// Token: 0x040009D0 RID: 2512
		public const string MiInstallLicenseAgreed = "mi_license_agreed";

		// Token: 0x040009D1 RID: 2513
		public const string MiLowDiskSpaceRetried = "mi_low_disk_space_retried";

		// Token: 0x040009D2 RID: 2514
		public const string MiChecksPassed = "mi_checks_passed";

		// Token: 0x040009D3 RID: 2515
		public const string MiDownloadStarted = "mi_download_started";

		// Token: 0x040009D4 RID: 2516
		public const string MiDownloadFailed = "mi_download_failed";

		// Token: 0x040009D5 RID: 2517
		public const string MiDownloadRetried = "mi_download_retried";

		// Token: 0x040009D6 RID: 2518
		public const string MiDownloadCompleted = "mi_download_completed";

		// Token: 0x040009D7 RID: 2519
		public const string MiMinimizePopupInit = "mi_minimizepopup_init";

		// Token: 0x040009D8 RID: 2520
		public const string MiMinimizePopupYes = "mi_minimizepopup_yes";

		// Token: 0x040009D9 RID: 2521
		public const string MiMinimizePopupNo = "mi_minimizepopup_no";

		// Token: 0x040009DA RID: 2522
		public const string MiClosed = "mi_closed";

		// Token: 0x040009DB RID: 2523
		public const string MiFailed = "mi_failed";

		// Token: 0x040009DC RID: 2524
		public const string MiFullInstallerLaunched = "mi_full_installer_launched";

		// Token: 0x040009DD RID: 2525
		public const string MiAdminProcCompleted = "mi_admin_proc_completed";

		// Token: 0x040009DE RID: 2526
		public const string MiRegistryNotFound = "mi_registry_not_found";

		// Token: 0x040009DF RID: 2527
		public const string MiClientLaunchFailed = "mi_client_launch_failed";

		// Token: 0x040009E0 RID: 2528
		public const string MiClientLaunched = "mi_client_launched";

		// Token: 0x040009E1 RID: 2529
		public const string DeviceProvisioned = "device_provisioned";

		// Token: 0x040009E2 RID: 2530
		public const string GoogleLoginCompleted = "google_login_completed";

		// Token: 0x040009E3 RID: 2531
		public const string BlueStacksLoginCompleted = "bluestacks_login_completed";
	}
}
