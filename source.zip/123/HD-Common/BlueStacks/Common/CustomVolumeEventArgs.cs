﻿using System;
using System.Collections.Generic;

namespace BlueStacks.Common
{
	// Token: 0x020000AB RID: 171
	public class CustomVolumeEventArgs : EventArgs
	{
		// Token: 0x17000101 RID: 257
		// (get) Token: 0x0600042A RID: 1066 RVA: 0x000044C6 File Offset: 0x000026C6
		// (set) Token: 0x0600042B RID: 1067 RVA: 0x000044CE File Offset: 0x000026CE
		public int Volume { get; set; }

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x0600042C RID: 1068 RVA: 0x000044D7 File Offset: 0x000026D7
		// (set) Token: 0x0600042D RID: 1069 RVA: 0x000044DF File Offset: 0x000026DF
		public Dictionary<string, string> dictData { get; set; }

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x0600042E RID: 1070 RVA: 0x000044E8 File Offset: 0x000026E8
		// (set) Token: 0x0600042F RID: 1071 RVA: 0x000044F0 File Offset: 0x000026F0
		public string mSelected { get; set; }

		// Token: 0x06000430 RID: 1072 RVA: 0x000044F9 File Offset: 0x000026F9
		public CustomVolumeEventArgs(int volume)
		{
			this.Volume = volume;
		}

		// Token: 0x06000431 RID: 1073 RVA: 0x00004508 File Offset: 0x00002708
		public CustomVolumeEventArgs(Dictionary<string, string> dict, string selected)
		{
			this.dictData = dict;
			this.mSelected = selected;
		}
	}
}
