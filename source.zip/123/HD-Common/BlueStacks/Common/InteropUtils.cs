﻿using System;
using System.Runtime.InteropServices;

namespace BlueStacks.Common
{
	// Token: 0x02000162 RID: 354
	public class InteropUtils
	{
		// Token: 0x06000B8A RID: 2954
		[DllImport("kernel32.dll")]
		public static extern long GetTickCount64();
	}
}
