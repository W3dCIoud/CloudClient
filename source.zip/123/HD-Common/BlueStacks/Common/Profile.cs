﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Management;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

namespace BlueStacks.Common
{
	// Token: 0x02000146 RID: 326
	public class Profile
	{
		// Token: 0x06000B08 RID: 2824
		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool IsWow64Process(IntPtr proc, ref bool isWow);

		// Token: 0x170002C9 RID: 713
		// (get) Token: 0x06000B09 RID: 2825 RVA: 0x0000A81F File Offset: 0x00008A1F
		// (set) Token: 0x06000B0A RID: 2826 RVA: 0x0000A826 File Offset: 0x00008A26
		public static string GlVendor
		{
			get
			{
				return Profile.s_glVendor;
			}
			set
			{
				Profile.s_glVendor = value;
			}
		}

		// Token: 0x170002CA RID: 714
		// (get) Token: 0x06000B0B RID: 2827 RVA: 0x0000A82E File Offset: 0x00008A2E
		// (set) Token: 0x06000B0C RID: 2828 RVA: 0x0000A835 File Offset: 0x00008A35
		public static string GlRenderer
		{
			get
			{
				return Profile.s_glRenderer;
			}
			set
			{
				Profile.s_glRenderer = value;
			}
		}

		// Token: 0x170002CB RID: 715
		// (get) Token: 0x06000B0D RID: 2829 RVA: 0x0000A83D File Offset: 0x00008A3D
		// (set) Token: 0x06000B0E RID: 2830 RVA: 0x0000A844 File Offset: 0x00008A44
		public static string GlVersion
		{
			get
			{
				return Profile.s_glVersion;
			}
			set
			{
				Profile.s_glVersion = value;
			}
		}

		// Token: 0x06000B0F RID: 2831 RVA: 0x0000A84C File Offset: 0x00008A4C
		private static bool IsOs64Bit()
		{
			return IntPtr.Size == 8 || (IntPtr.Size == 4 && Profile.Is32BitProcessOn64BitProcessor());
		}

		// Token: 0x06000B10 RID: 2832 RVA: 0x00030464 File Offset: 0x0002E664
		private static bool Is32BitProcessOn64BitProcessor()
		{
			bool result = false;
			Profile.IsWow64Process(Process.GetCurrentProcess().Handle, ref result);
			return result;
		}

		// Token: 0x06000B11 RID: 2833 RVA: 0x00030488 File Offset: 0x0002E688
		public static Dictionary<string, string> Info()
		{
			if (Profile.s_Info != null)
			{
				return Profile.s_Info;
			}
			string key = "Android";
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary.Add("ProcessorId", Profile.GetSysInfo("Select processorID from Win32_Processor"));
			dictionary.Add("Processor", Profile.CPU);
			string sysInfo = Profile.GetSysInfo("Select NumberOfLogicalProcessors from Win32_Processor");
			Logger.Info("the length of numOfProcessor string is {0}", new object[]
			{
				sysInfo.Length.ToString()
			});
			dictionary.Add("NumberOfProcessors", sysInfo);
			dictionary.Add("GPU", Profile.GPU);
			dictionary.Add("GPUDriver", Profile.GetSysInfo("Select DriverVersion from Win32_VideoController"));
			dictionary.Add("OS", Profile.OS);
			string value = string.Format("{0}.{1}", Environment.OSVersion.Version.Major, Environment.OSVersion.Version.Minor);
			dictionary.Add("OSVersion", value);
			dictionary.Add("RAM", Profile.RAM);
			try
			{
				string version = RegistryManager.Instance.Version;
				dictionary.Add("BlueStacksVersion", version);
			}
			catch
			{
			}
			int num;
			try
			{
				num = RegistryManager.Instance.Guest[key].GlMode;
			}
			catch
			{
				num = -1;
			}
			dictionary.Add("GlMode", num.ToString());
			int num2;
			try
			{
				num2 = RegistryManager.Instance.Guest[key].GlRenderMode;
			}
			catch
			{
				num2 = -1;
			}
			dictionary.Add("GlRenderMode", num2.ToString());
			string value2 = "";
			try
			{
				RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\OEMInformation");
				string arg = (string)registryKey.GetValue("Manufacturer", "");
				string arg2 = (string)registryKey.GetValue("Model", "");
				value2 = string.Format("{0} {1}", arg, arg2);
			}
			catch
			{
			}
			dictionary.Add("OEMInfo", value2);
			int num3 = Screen.PrimaryScreen.Bounds.Width;
			int num4 = Screen.PrimaryScreen.Bounds.Height;
			dictionary.Add("ScreenResolution", num3.ToString() + "x" + num4.ToString());
			try
			{
				num3 = RegistryManager.Instance.Guest[key].WindowWidth;
				num4 = RegistryManager.Instance.Guest[key].WindowHeight;
				dictionary.Add("BlueStacksResolution", num3.ToString() + "x" + num4.ToString());
			}
			catch
			{
			}
			string value3 = "";
			try
			{
				RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\NET Framework Setup\\NDP");
				foreach (string text in registryKey2.GetSubKeyNames())
				{
					if (text.StartsWith("v"))
					{
						RegistryKey registryKey3 = registryKey2.OpenSubKey(text);
						if (registryKey3.GetValue("Install") != null && (int)registryKey3.GetValue("Install") == 1)
						{
							value3 = (string)registryKey3.GetValue("Version");
						}
						if (text == "v4")
						{
							RegistryKey registryKey4 = registryKey3.OpenSubKey("Client");
							if (registryKey4 != null && (int)registryKey4.GetValue("Install") == 1)
							{
								value3 = (string)registryKey4.GetValue("Version") + " Client";
							}
							registryKey4 = registryKey3.OpenSubKey("Full");
							if (registryKey4 != null && (int)registryKey4.GetValue("Install") == 1)
							{
								value3 = (string)registryKey4.GetValue("Version") + " Full";
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Got exception when checking dot net version,err: {0}", new object[]
				{
					ex.ToString()
				});
			}
			dictionary.Add("DotNetVersion", value3);
			if (Profile.IsOs64Bit())
			{
				dictionary.Add("OSVERSIONTYPE", "64 bit");
			}
			else
			{
				dictionary.Add("OSVERSIONTYPE", "32 bit");
			}
			Profile.s_Info = dictionary;
			return Profile.s_Info;
		}

		// Token: 0x06000B12 RID: 2834 RVA: 0x00030944 File Offset: 0x0002EB44
		public static Dictionary<string, string> InfoForGraphicsDriverCheck()
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary.Add("os_version", Profile.GetSysInfo("Select Caption from Win32_OperatingSystem"));
			dictionary.Add("os_arch", Profile.GetSysInfo("Select OSArchitecture from Win32_OperatingSystem"));
			dictionary.Add("processor_vendor", Profile.GetSysInfo("Select Manufacturer from Win32_Processor"));
			dictionary.Add("processor", Profile.GetSysInfo("Select Name from Win32_Processor"));
			string text = Profile.GetSysInfo("Select Caption from Win32_VideoController");
			string text2 = "";
			string[] array = text.Split(new string[]
			{
				Environment.NewLine,
				"\r\n",
				"\n"
			}, StringSplitOptions.RemoveEmptyEntries);
			if (!string.IsNullOrEmpty(text))
			{
				foreach (string text3 in array)
				{
					text2 = text2 + text3.Substring(0, text3.IndexOf(" ")) + "\r\n";
				}
				text2 = text2.Trim();
			}
			string text4 = Profile.GetSysInfo("Select DriverVersion from Win32_VideoController");
			string text5 = Profile.GetSysInfo("Select DriverDate from Win32_VideoController");
			string[] array3 = text2.Split(new string[]
			{
				Environment.NewLine,
				"\r\n",
				"\n"
			}, StringSplitOptions.RemoveEmptyEntries);
			string[] array4 = text4.Split(new string[]
			{
				Environment.NewLine,
				"\r\n",
				"\n"
			}, StringSplitOptions.RemoveEmptyEntries);
			string[] array5 = text5.Split(new string[]
			{
				Environment.NewLine,
				"\r\n",
				"\n"
			}, StringSplitOptions.RemoveEmptyEntries);
			for (int j = 0; j < array.Length; j++)
			{
				if (array[j] == Profile.GlRenderer || Profile.GlVendor.Contains(array3[j]))
				{
					text = array[j];
					text2 = array3[j];
					text4 = array4[j];
					text5 = array5[j];
					break;
				}
			}
			dictionary.Add("gpu", text);
			dictionary.Add("gpu_vendor", text2);
			dictionary.Add("driver_version", text4);
			dictionary.Add("driver_date", text5);
			string value = "";
			RegistryKey registryKey2;
			RegistryKey registryKey = registryKey2 = Registry.LocalMachine.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\OEMInformation");
			try
			{
				if (registryKey != null)
				{
					value = (string)registryKey.GetValue("Manufacturer", "");
				}
			}
			finally
			{
				if (registryKey2 != null)
				{
					((IDisposable)registryKey2).Dispose();
				}
			}
			dictionary.Add("oem_manufacturer", value);
			string value2 = "";
			registryKey = (registryKey2 = Registry.LocalMachine.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\OEMInformation"));
			try
			{
				if (registryKey != null)
				{
					value2 = (string)registryKey.GetValue("Model", "");
				}
			}
			finally
			{
				if (registryKey2 != null)
				{
					((IDisposable)registryKey2).Dispose();
				}
			}
			dictionary.Add("oem_model", value2);
			dictionary.Add("bst_oem", RegistryManager.Instance.Oem);
			return dictionary;
		}

		// Token: 0x06000B13 RID: 2835 RVA: 0x0000A868 File Offset: 0x00008A68
		private static string ToUpper(string id)
		{
			return id.ToUpperInvariant();
		}

		// Token: 0x170002CC RID: 716
		// (get) Token: 0x06000B14 RID: 2836 RVA: 0x00030C14 File Offset: 0x0002EE14
		public static string RAM
		{
			get
			{
				int num = 0;
				try
				{
					num = (int)(Convert.ToUInt64(Profile.GetSysInfo("Select TotalPhysicalMemory from Win32_ComputerSystem")) / 1048576UL);
				}
				catch (Exception ex)
				{
					Logger.Error("Exception when finding ram");
					Logger.Error(ex.ToString());
				}
				return num.ToString();
			}
		}

		// Token: 0x170002CD RID: 717
		// (get) Token: 0x06000B15 RID: 2837 RVA: 0x0000A870 File Offset: 0x00008A70
		public static string CPU
		{
			get
			{
				return Profile.GetSysInfo("Select Name from Win32_Processor");
			}
		}

		// Token: 0x170002CE RID: 718
		// (get) Token: 0x06000B16 RID: 2838 RVA: 0x0000A87C File Offset: 0x00008A7C
		public static string GPU
		{
			get
			{
				return Profile.GetSysInfo("Select Caption from Win32_VideoController");
			}
		}

		// Token: 0x170002CF RID: 719
		// (get) Token: 0x06000B17 RID: 2839 RVA: 0x0000A888 File Offset: 0x00008A88
		public static string OS
		{
			get
			{
				if (string.IsNullOrEmpty(Profile.sOS))
				{
					Profile.sOS = Profile.GetSysInfo("Select Caption from Win32_OperatingSystem");
				}
				return Profile.sOS;
			}
		}

		// Token: 0x06000B18 RID: 2840 RVA: 0x00030C6C File Offset: 0x0002EE6C
		public static string GetSysInfo(string query)
		{
			int num = 0;
			string text = "";
			try
			{
				foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher(query).Get())
				{
					ManagementBaseObject managementBaseObject2 = (ManagementObject)managementBaseObject;
					num++;
					foreach (PropertyData propertyData in managementBaseObject2.Properties)
					{
						text = text + propertyData.Value.ToString() + "\n";
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in getting sysinfo err:" + ex.ToString());
			}
			return text.Trim();
		}

		// Token: 0x040007C3 RID: 1987
		private static Dictionary<string, string> s_Info;

		// Token: 0x040007C4 RID: 1988
		private static string s_glVendor = "";

		// Token: 0x040007C5 RID: 1989
		private static string s_glRenderer = "";

		// Token: 0x040007C6 RID: 1990
		private static string s_glVersion = "";

		// Token: 0x040007C7 RID: 1991
		private static string sOS = "";
	}
}
