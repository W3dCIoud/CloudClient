﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000DC RID: 220
	public enum SidebarGroup
	{
		// Token: 0x04000570 RID: 1392
		Independent,
		// Token: 0x04000571 RID: 1393
		VolumeControls,
		// Token: 0x04000572 RID: 1394
		Keymapping,
		// Token: 0x04000573 RID: 1395
		CapturingTools,
		// Token: 0x04000574 RID: 1396
		Automation,
		// Token: 0x04000575 RID: 1397
		QuickSettings,
		// Token: 0x04000576 RID: 1398
		MIManager,
		// Token: 0x04000577 RID: 1399
		StaticElements
	}
}
