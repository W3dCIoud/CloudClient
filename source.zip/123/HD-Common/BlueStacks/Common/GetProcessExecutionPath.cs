﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace BlueStacks.Common
{
	// Token: 0x02000149 RID: 329
	public class GetProcessExecutionPath
	{
		// Token: 0x06000B1E RID: 2846
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern bool QueryFullProcessImageName(IntPtr hwnd, int flags, [Out] StringBuilder buffer, out int size);

		// Token: 0x06000B1F RID: 2847
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern IntPtr OpenProcess(int flags, bool handle, UIntPtr procId);

		// Token: 0x06000B20 RID: 2848
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern bool CloseHandle(IntPtr handle);

		// Token: 0x06000B21 RID: 2849 RVA: 0x00030E38 File Offset: 0x0002F038
		public static List<string> GetApplicationPath(Process[] procList)
		{
			List<string> list = new List<string>();
			foreach (Process process in procList)
			{
				try
				{
					if (SystemUtils.IsOSWinXP())
					{
						if (SystemUtils.IsAdministrator())
						{
							list.Add(process.MainModule.FileName.ToString());
						}
					}
					else
					{
						UIntPtr dwProcessId = new UIntPtr((uint)process.Id);
						list.Add(GetProcessExecutionPath.GetExecutablePathAboveVista(dwProcessId));
					}
				}
				catch (Exception)
				{
				}
			}
			return list;
		}

		// Token: 0x06000B22 RID: 2850 RVA: 0x00030EB8 File Offset: 0x0002F0B8
		public static string GetExecutablePathAboveVista(UIntPtr dwProcessId)
		{
			StringBuilder stringBuilder = new StringBuilder(1024);
			IntPtr intPtr = GetProcessExecutionPath.OpenProcess(4096, false, dwProcessId);
			if (intPtr != IntPtr.Zero)
			{
				try
				{
					int capacity = stringBuilder.Capacity;
					if (GetProcessExecutionPath.QueryFullProcessImageName(intPtr, 0, stringBuilder, out capacity))
					{
						return stringBuilder.ToString();
					}
				}
				finally
				{
					GetProcessExecutionPath.CloseHandle(intPtr);
				}
			}
			return string.Empty;
		}
	}
}
