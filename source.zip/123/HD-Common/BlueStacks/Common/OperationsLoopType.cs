﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000D7 RID: 215
	public enum OperationsLoopType
	{
		// Token: 0x0400053E RID: 1342
		TillLoopNumber,
		// Token: 0x0400053F RID: 1343
		TillTime,
		// Token: 0x04000540 RID: 1344
		UntilStopped
	}
}
