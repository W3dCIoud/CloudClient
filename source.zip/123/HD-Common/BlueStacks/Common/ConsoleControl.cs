﻿using System;
using System.Runtime.InteropServices;

namespace BlueStacks.Common
{
	// Token: 0x020000A2 RID: 162
	public class ConsoleControl
	{
		// Token: 0x060003ED RID: 1005
		[DllImport("Kernel32")]
		private static extern bool SetConsoleCtrlHandler(ConsoleControl.Handler handler, bool Add);

		// Token: 0x060003EE RID: 1006 RVA: 0x0000423F File Offset: 0x0000243F
		public static void SetHandler(ConsoleControl.Handler handler)
		{
			ConsoleControl.SetConsoleCtrlHandler(handler, true);
		}

		// Token: 0x020000A3 RID: 163
		// (Invoke) Token: 0x060003F1 RID: 1009
		public delegate bool Handler(ConsoleControl.CtrlType ctrlType);

		// Token: 0x020000A4 RID: 164
		public enum CtrlType
		{
			// Token: 0x040003BC RID: 956
			CTRL_C_EVENT,
			// Token: 0x040003BD RID: 957
			CTRL_BREAK_EVENT,
			// Token: 0x040003BE RID: 958
			CTRL_CLOSE_EVENT,
			// Token: 0x040003BF RID: 959
			CTRL_LOGOFF_EVENT = 5,
			// Token: 0x040003C0 RID: 960
			CTRL_SHUTDOWN_EVENT
		}
	}
}
