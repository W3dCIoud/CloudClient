﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000D9 RID: 217
	public enum RichPopupStyles
	{
		// Token: 0x04000548 RID: 1352
		Centered,
		// Token: 0x04000549 RID: 1353
		Simple
	}
}
