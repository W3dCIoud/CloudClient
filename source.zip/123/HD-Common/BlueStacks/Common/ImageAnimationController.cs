﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace BlueStacks.Common
{
	// Token: 0x0200013B RID: 315
	public class ImageAnimationController : IDisposable
	{
		// Token: 0x06000AB3 RID: 2739 RVA: 0x0002F324 File Offset: 0x0002D524
		internal ImageAnimationController(Image image, ObjectAnimationUsingKeyFrames animation, bool autoStart)
		{
			this._image = image;
			this._animation = animation;
			this._animation.Completed += this.AnimationCompleted;
			this._clock = this._animation.CreateClock();
			this._clockController = this._clock.Controller;
			ImageAnimationController._sourceDescriptor.AddValueChanged(image, new EventHandler(this.ImageSourceChanged));
			this._clockController.Pause();
			this._image.ApplyAnimationClock(Image.SourceProperty, this._clock);
			if (autoStart)
			{
				this._clockController.Resume();
			}
		}

		// Token: 0x06000AB4 RID: 2740 RVA: 0x0000A4DB File Offset: 0x000086DB
		private void AnimationCompleted(object sender, EventArgs e)
		{
			this._image.RaiseEvent(new RoutedEventArgs(ImageBehavior.AnimationCompletedEvent, this._image));
		}

		// Token: 0x06000AB5 RID: 2741 RVA: 0x0000A4F8 File Offset: 0x000086F8
		private void ImageSourceChanged(object sender, EventArgs e)
		{
			this.OnCurrentFrameChanged();
		}

		// Token: 0x170002BD RID: 701
		// (get) Token: 0x06000AB6 RID: 2742 RVA: 0x0000A500 File Offset: 0x00008700
		public int FrameCount
		{
			get
			{
				return this._animation.KeyFrames.Count;
			}
		}

		// Token: 0x170002BE RID: 702
		// (get) Token: 0x06000AB7 RID: 2743 RVA: 0x0000A512 File Offset: 0x00008712
		public bool IsPaused
		{
			get
			{
				return this._clock.IsPaused;
			}
		}

		// Token: 0x170002BF RID: 703
		// (get) Token: 0x06000AB8 RID: 2744 RVA: 0x0000A51F File Offset: 0x0000871F
		public bool IsComplete
		{
			get
			{
				return this._clock.CurrentState == ClockState.Filling;
			}
		}

		// Token: 0x06000AB9 RID: 2745 RVA: 0x0002F3C4 File Offset: 0x0002D5C4
		public void GotoFrame(int index)
		{
			ObjectKeyFrame objectKeyFrame = this._animation.KeyFrames[index];
			this._clockController.Seek(objectKeyFrame.KeyTime.TimeSpan, TimeSeekOrigin.BeginTime);
		}

		// Token: 0x170002C0 RID: 704
		// (get) Token: 0x06000ABA RID: 2746 RVA: 0x0002F400 File Offset: 0x0002D600
		public int CurrentFrame
		{
			get
			{
				TimeSpan? time = this._clock.CurrentTime;
				var <>f__AnonymousType = this._animation.KeyFrames.Cast<ObjectKeyFrame>().Select((ObjectKeyFrame f, int i) => new
				{
					Time = f.KeyTime.TimeSpan,
					Index = i
				}).FirstOrDefault(fi => fi.Time >= time);
				if (<>f__AnonymousType != null)
				{
					return <>f__AnonymousType.Index;
				}
				return -1;
			}
		}

		// Token: 0x06000ABB RID: 2747 RVA: 0x0000A52F File Offset: 0x0000872F
		public void Pause()
		{
			this._clockController.Pause();
		}

		// Token: 0x06000ABC RID: 2748 RVA: 0x0000A53C File Offset: 0x0000873C
		public void Play()
		{
			this._clockController.Resume();
		}

		// Token: 0x14000007 RID: 7
		// (add) Token: 0x06000ABD RID: 2749 RVA: 0x0002F478 File Offset: 0x0002D678
		// (remove) Token: 0x06000ABE RID: 2750 RVA: 0x0002F4B0 File Offset: 0x0002D6B0
		public event EventHandler CurrentFrameChanged;

		// Token: 0x06000ABF RID: 2751 RVA: 0x0002F4E8 File Offset: 0x0002D6E8
		private void OnCurrentFrameChanged()
		{
			EventHandler currentFrameChanged = this.CurrentFrameChanged;
			if (currentFrameChanged != null)
			{
				currentFrameChanged(this, EventArgs.Empty);
			}
		}

		// Token: 0x06000AC0 RID: 2752 RVA: 0x0002F50C File Offset: 0x0002D70C
		~ImageAnimationController()
		{
			this.Dispose(false);
		}

		// Token: 0x06000AC1 RID: 2753 RVA: 0x0000A549 File Offset: 0x00008749
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x06000AC2 RID: 2754 RVA: 0x0002F53C File Offset: 0x0002D73C
		protected virtual void Dispose(bool disposing)
		{
			if (disposing)
			{
				this._image.BeginAnimation(Image.SourceProperty, null);
				this._animation.Completed -= this.AnimationCompleted;
				ImageAnimationController._sourceDescriptor.RemoveValueChanged(this._image, new EventHandler(this.ImageSourceChanged));
				this._image.Source = null;
			}
		}

		// Token: 0x0400079A RID: 1946
		private static readonly DependencyPropertyDescriptor _sourceDescriptor = DependencyPropertyDescriptor.FromProperty(Image.SourceProperty, typeof(Image));

		// Token: 0x0400079B RID: 1947
		private readonly Image _image;

		// Token: 0x0400079C RID: 1948
		private readonly ObjectAnimationUsingKeyFrames _animation;

		// Token: 0x0400079D RID: 1949
		private readonly AnimationClock _clock;

		// Token: 0x0400079E RID: 1950
		private readonly ClockController _clockController;
	}
}
