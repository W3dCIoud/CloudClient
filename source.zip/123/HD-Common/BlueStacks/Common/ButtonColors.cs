﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000CF RID: 207
	public enum ButtonColors
	{
		// Token: 0x04000511 RID: 1297
		Red,
		// Token: 0x04000512 RID: 1298
		DarkRed,
		// Token: 0x04000513 RID: 1299
		White,
		// Token: 0x04000514 RID: 1300
		WhiteWithGreyFG,
		// Token: 0x04000515 RID: 1301
		Blue,
		// Token: 0x04000516 RID: 1302
		Orange,
		// Token: 0x04000517 RID: 1303
		Background,
		// Token: 0x04000518 RID: 1304
		BackgroundBlueBorder,
		// Token: 0x04000519 RID: 1305
		Green,
		// Token: 0x0400051A RID: 1306
		Border,
		// Token: 0x0400051B RID: 1307
		Transparent
	}
}
