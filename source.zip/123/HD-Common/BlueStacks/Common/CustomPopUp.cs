﻿using System;
using System.Windows.Controls.Primitives;

namespace BlueStacks.Common
{
	// Token: 0x020000AE RID: 174
	public class CustomPopUp : Popup
	{
		// Token: 0x06000464 RID: 1124 RVA: 0x000047F0 File Offset: 0x000029F0
		public CustomPopUp()
		{
			base.Opened += this.CustomPopUp_Initialized;
		}

		// Token: 0x06000465 RID: 1125 RVA: 0x0000480A File Offset: 0x00002A0A
		private void CustomPopUp_Initialized(object sender, EventArgs e)
		{
			RenderHelper.ChangeRenderModeToSoftware(sender);
		}
	}
}
