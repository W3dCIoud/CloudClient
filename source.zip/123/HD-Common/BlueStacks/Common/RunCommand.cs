﻿using System;
using System.Diagnostics;

namespace BlueStacks.Common
{
	// Token: 0x020000EA RID: 234
	public static class RunCommand
	{
		// Token: 0x06000875 RID: 2165 RVA: 0x00023748 File Offset: 0x00021948
		public static RunCommand.CmdRes RunCmd(string cmd, string args, bool addOutputToLogs = false, bool addCommandToLogs = true, bool requireAdministrator = false, int timeout = 0)
		{
			RunCommand.<>c__DisplayClass1_0 CS$<>8__locals1 = new RunCommand.<>c__DisplayClass1_0();
			CS$<>8__locals1.addOutputToLogs = addOutputToLogs;
			if (addCommandToLogs)
			{
				Logger.Info("RunCmd: starting cmd: " + cmd);
				Logger.Info("  args: " + args);
			}
			CS$<>8__locals1.res = new RunCommand.CmdRes();
			using (Process proc = new Process())
			{
				proc.StartInfo.FileName = cmd;
				proc.StartInfo.Arguments = args;
				proc.StartInfo.UseShellExecute = false;
				proc.StartInfo.CreateNoWindow = true;
				if (requireAdministrator)
				{
					proc.StartInfo.Verb = "runas";
				}
				proc.StartInfo.RedirectStandardInput = true;
				proc.StartInfo.RedirectStandardOutput = true;
				proc.StartInfo.RedirectStandardError = true;
				proc.OutputDataReceived += delegate(object sender, DataReceivedEventArgs line)
				{
					string text = line.Data;
					if (text != null && (text = text.Trim()) != string.Empty)
					{
						if (CS$<>8__locals1.addOutputToLogs)
						{
							Logger.Info(proc.Id + " OUT: " + text);
						}
						RunCommand.CmdRes res = CS$<>8__locals1.res;
						res.StdOut = res.StdOut + text + "\n";
					}
				};
				proc.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs line)
				{
					if (CS$<>8__locals1.addOutputToLogs)
					{
						Logger.Info(proc.Id + " ERR: " + line.Data);
					}
					RunCommand.CmdRes res = CS$<>8__locals1.res;
					res.StdErr = res.StdErr + line.Data + "\n";
				};
				proc.Start();
				proc.BeginOutputReadLine();
				proc.BeginErrorReadLine();
				bool flag = true;
				if (timeout == 0)
				{
					proc.WaitForExit();
				}
				else
				{
					flag = proc.WaitForExit(timeout);
				}
				proc.CancelOutputRead();
				proc.CancelErrorRead();
				if (CS$<>8__locals1.addOutputToLogs && flag)
				{
					Logger.Info(string.Concat(new object[]
					{
						"RunCmd for proc.ID = ",
						proc.Id,
						" exited with exitCode: ",
						proc.ExitCode
					}));
					CS$<>8__locals1.res.ExitCode = proc.ExitCode;
				}
				if (!flag)
				{
					Logger.Fatal("RunCmd for proc.ID = {0} terminated after timeout of {1}", new object[]
					{
						proc.Id,
						timeout
					});
					CS$<>8__locals1.res.ExitCode = -1;
				}
			}
			return CS$<>8__locals1.res;
		}

		// Token: 0x020000EB RID: 235
		public class CmdRes
		{
			// Token: 0x04000653 RID: 1619
			public string StdOut = "";

			// Token: 0x04000654 RID: 1620
			public string StdErr = "";

			// Token: 0x04000655 RID: 1621
			public int ExitCode;
		}
	}
}
