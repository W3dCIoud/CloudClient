﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.AccessControl;
using System.Security.Principal;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Xml;
using Microsoft.Win32;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x020000A0 RID: 160
	public class CommonInstallUtils
	{
		// Token: 0x060003A3 RID: 931
		[DllImport("shell32.dll", CharSet = CharSet.Auto)]
		private static extern int SHGetFolderPath(IntPtr hwndOwner, int nFolder, IntPtr hToken, uint dwFlags, [Out] StringBuilder pszPath);

		// Token: 0x060003A4 RID: 932
		[DllImport("HD-LibraryHandler.dll", CharSet = CharSet.Auto)]
		private static extern int DeleteLibrary(string libraryName);

		// Token: 0x060003A5 RID: 933
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		public static extern bool CreateHardLink(string lpFileName, string lpExistingFileName, IntPtr lpSecurityAttributes);

		// Token: 0x060003A6 RID: 934
		[DllImport("kernel32.dll", SetLastError = true)]
		[return: MarshalAs(UnmanagedType.Bool)]
		private static extern bool IsWow64Process([In] IntPtr hProcess, out bool wow64Process);

		// Token: 0x060003A7 RID: 935
		[DllImport("advapi32", CharSet = CharSet.Auto, SetLastError = true)]
		public static extern int RegRenameKey(UIntPtr hKey, [MarshalAs(UnmanagedType.LPWStr)] string oldname, [MarshalAs(UnmanagedType.LPWStr)] string newname);

		// Token: 0x060003A8 RID: 936
		[DllImport("HD-OpenGl-Native.dll")]
		public static extern int IsVulkanSupported();

		// Token: 0x060003A9 RID: 937
		[DllImport("HD-OpenGl-Native.dll")]
		public static extern void PgaLoggerInit(Logger.HdLoggerCallback cb);

		// Token: 0x060003AA RID: 938 RVA: 0x00016F34 File Offset: 0x00015134
		private static bool InternalCheckIsWow64()
		{
			if ((Environment.OSVersion.Version.Major == 5 && Environment.OSVersion.Version.Minor >= 1) || Environment.OSVersion.Version.Major >= 6)
			{
				using (Process currentProcess = Process.GetCurrentProcess())
				{
					bool result;
					if (!CommonInstallUtils.IsWow64Process(currentProcess.Handle, out result))
					{
						return false;
					}
					return result;
				}
				return false;
			}
			return false;
		}

		// Token: 0x060003AB RID: 939 RVA: 0x00016FB4 File Offset: 0x000151B4
		public static void KillBlueStacksProcesses()
		{
			Logger.Info("Killing all BlueStacks processes");
			ProcessUtils.KillProcessesByName(new string[]
			{
				"BlueStacks",
				"Keymapui",
				"BstkSVC",
				"HD-OBS",
				"HD-Player",
				"HD-Agent",
				"HD-Adb",
				"HD-RunApp",
				"HD-LogCollector",
				"HD-DataManager",
				"HD-QuitMultiInstall",
				"HD-MultiInstanceManager"
			});
		}

		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x060003AC RID: 940 RVA: 0x00004154 File Offset: 0x00002354
		public static string EngineInstallDir
		{
			get
			{
				return (string)Utils.GetRegistryHKLMValue(string.Format("Software\\BlueStacks{0}", Strings.GetOemTag()), "InstallDir", string.Empty);
			}
		}

		// Token: 0x060003AD RID: 941 RVA: 0x0001703C File Offset: 0x0001523C
		public static void RunHdQuit()
		{
			try
			{
				string fileName = Path.Combine(CommonInstallUtils.EngineInstallDir, "HD-Quit.exe");
				Process process = new Process();
				process.StartInfo.FileName = fileName;
				process.Start();
				process.WaitForExit();
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in running hd-quit err: {0}", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x060003AE RID: 942 RVA: 0x000170A4 File Offset: 0x000152A4
		public static void ModifyDirectoryPermissionsForEveryone(string dir)
		{
			if (!Directory.Exists(dir))
			{
				Directory.CreateDirectory(dir);
			}
			try
			{
				string identity = new SecurityIdentifier("S-1-1-0").Translate(typeof(NTAccount)).ToString();
				DirectoryInfo directoryInfo = new DirectoryInfo(dir);
				DirectorySecurity accessControl = directoryInfo.GetAccessControl();
				accessControl.AddAccessRule(new FileSystemAccessRule(identity, FileSystemRights.FullControl, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
				directoryInfo.SetAccessControl(accessControl);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to set permissions. err: " + ex.ToString());
			}
			try
			{
				if (!SystemUtils.IsOSWinXP())
				{
					foreach (string fileName in Directory.GetFiles(dir))
					{
						string identity2 = new SecurityIdentifier("S-1-1-0").Translate(typeof(NTAccount)).ToString();
						FileInfo fileInfo = new FileInfo(fileName);
						FileSecurity accessControl2 = fileInfo.GetAccessControl();
						accessControl2.AddAccessRule(new FileSystemAccessRule(identity2, FileSystemRights.FullControl, AccessControlType.Allow));
						fileInfo.SetAccessControl(accessControl2);
					}
				}
				string[] array = Directory.GetDirectories(dir);
				for (int i = 0; i < array.Length; i++)
				{
					CommonInstallUtils.ModifyDirectoryPermissionsForEveryone(array[i]);
				}
			}
			catch (Exception ex2)
			{
				Logger.Error("Failed to set permissions. err: " + ex2.ToString());
			}
		}

		// Token: 0x060003AF RID: 943 RVA: 0x000171E8 File Offset: 0x000153E8
		public static bool MoveDirectory(string srcDir, string dstDir)
		{
			Logger.Info("Moving directory {0} to {1}", new object[]
			{
				srcDir,
				dstDir
			});
			try
			{
				if (Directory.Exists(dstDir))
				{
					Directory.Delete(dstDir, true);
				}
				Directory.Move(srcDir, dstDir);
			}
			catch (Exception ex)
			{
				Logger.Info("------------ FOR DEV TRACKING--------------- Moving failed");
				Logger.Info("Caught exception when moving directory {0} to {1} err :{2}", new object[]
				{
					srcDir,
					dstDir,
					ex.ToString()
				});
				if (!Directory.Exists(dstDir))
				{
					Directory.CreateDirectory(dstDir);
				}
				foreach (string text in Directory.GetFiles(srcDir))
				{
					FileInfo fileInfo = new FileInfo(text);
					string text2 = Path.Combine(dstDir, fileInfo.Name);
					try
					{
						if (File.Exists(text2))
						{
							File.SetAttributes(text, FileAttributes.Normal);
							File.Delete(text2);
						}
						File.Move(text, text2);
					}
					catch (Exception ex2)
					{
						Logger.Info("Exception in file move {0} to {1}. Copying instead.. ex:{2}", new object[]
						{
							text,
							text2,
							ex2.ToString()
						});
						try
						{
							File.Copy(text, text2, true);
						}
						catch (Exception ex3)
						{
							Logger.Error("Exception in file copy: THIS WILL RESULT IN DEPLOYMENT FAILURE" + ex3.ToString());
							return false;
						}
					}
				}
				string[] array = Directory.GetDirectories(srcDir);
				for (int i = 0; i < array.Length; i++)
				{
					DirectoryInfo directoryInfo = new DirectoryInfo(array[i]);
					string text3 = Path.Combine(dstDir, directoryInfo.Name);
					string text4 = Path.Combine(srcDir, directoryInfo.Name);
					if (!CommonInstallUtils.MoveDirectory(text4, text3))
					{
						Logger.Warning("Returing false in directory move for {0} to {1}", new object[]
						{
							text4,
							text3
						});
						return false;
					}
				}
				try
				{
					Directory.Delete(srcDir);
				}
				catch (Exception ex4)
				{
					Logger.Info("Ignoring exception when trying to delete srcDir at the end err:{0}", new object[]
					{
						ex4.ToString()
					});
				}
			}
			return true;
		}

		// Token: 0x060003B0 RID: 944 RVA: 0x00017408 File Offset: 0x00015608
		public static string GetFolderPath(int CSIDL)
		{
			StringBuilder stringBuilder = new StringBuilder(260);
			CommonInstallUtils.SHGetFolderPath(IntPtr.Zero, CSIDL, IntPtr.Zero, 0U, stringBuilder);
			return stringBuilder.ToString();
		}

		// Token: 0x060003B1 RID: 945 RVA: 0x0001743C File Offset: 0x0001563C
		public static void DeleteLegacyShortcuts()
		{
			Logger.Info("Deleting legacy shortcuts");
			ShortcutHelper.DeleteDesktopShortcut("Start BlueStacks.lnk");
			ShortcutHelper.DeleteStartMenuShortcut("Start BlueStacks.lnk");
			ShortcutHelper.DeleteStartMenuShortcut("Programs\\BlueStacks\\Start BlueStacks.lnk");
			if (!string.IsNullOrEmpty(Oem.Instance.DesktopShortcutFileName))
			{
				ShortcutHelper.DeleteDesktopShortcut(Oem.Instance.DesktopShortcutFileName);
				ShortcutHelper.DeleteStartMenuShortcut(Oem.Instance.DesktopShortcutFileName);
			}
			if (Oem.Instance.CreateMultiInstanceManagerIcon)
			{
				ShortcutHelper.DeleteDesktopShortcut("BlueStacks Multi-Instance Manager.lnk");
				ShortcutHelper.DeleteStartMenuShortcut("BlueStacks Multi-Instance Manager.lnk");
			}
			try
			{
				string path = Path.Combine(CommonInstallUtils.GetFolderPath(25), Oem.Instance.DesktopShortcutFileName);
				if (File.Exists(path))
				{
					File.Delete(path);
				}
			}
			catch
			{
			}
		}

		// Token: 0x060003B2 RID: 946 RVA: 0x00004179 File Offset: 0x00002379
		public static bool CheckIfSDCardPresent()
		{
			return File.Exists(Path.Combine(Path.Combine(RegistryStrings.DataDir, "Android"), "SDCard.vdi"));
		}

		// Token: 0x060003B3 RID: 947 RVA: 0x000174FC File Offset: 0x000156FC
		public static void DeleteOldShortcuts()
		{
			try
			{
				CommonInstallUtils.DeleteLegacyShortcuts();
			}
			catch (Exception ex)
			{
				Logger.Warning("Failed to delete old shortcuts. Err: " + ex.ToString());
			}
		}

		// Token: 0x060003B4 RID: 948 RVA: 0x00017538 File Offset: 0x00015738
		public static void CreateDesktopAndStartMenuShortcuts(string shortcutName, string iconPath, string targetBinPath, string args = "", string description = "")
		{
			try
			{
				if (Oem.Instance.IsCreateDesktopAndStartMenuShortcut)
				{
					if (!string.IsNullOrEmpty(shortcutName))
					{
						if (string.IsNullOrEmpty(description))
						{
							description = shortcutName;
						}
						ShortcutHelper.CreateCommonDesktopShortcut(shortcutName, iconPath, targetBinPath, args, description);
						ShortcutHelper.CreateCommonStartMenuShortcut(shortcutName, iconPath, targetBinPath, args, shortcutName);
						Utils.SHChangeNotify(134217728, 4096, IntPtr.Zero, IntPtr.Zero);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Failed to create BlueStacks shortcuts. ex: " + ex.ToString());
			}
		}

		// Token: 0x060003B5 RID: 949 RVA: 0x000175C4 File Offset: 0x000157C4
		public static void UpdateOldAppDesktopShortcutTarget(string oldInstallDir, string newInstallDir)
		{
			try
			{
				foreach (string text in Directory.GetFiles(ShortcutHelper.sDesktopPath, "*.lnk", SearchOption.AllDirectories))
				{
					try
					{
						if (File.Exists(text) && ShortcutHelper.GetShortcutArguments(text).TrimEnd(new char[]
						{
							'\\'
						}).ToLower().Equals(Path.Combine(oldInstallDir, "HD-RunApp.exe").ToLower()))
						{
							string text2 = ShortcutHelper.GetShortcutIconLocation(text);
							if (text2.ToLower().Contains("library\\icons"))
							{
								text2 = text2.Replace("Library\\Icons", "Gadget");
								ShortcutHelper.UpdateTargetPathAndIcon(text, Path.Combine(newInstallDir, "HD-RunApp.exe"), text2);
							}
						}
					}
					catch
					{
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to fix app shortcut target");
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x060003B6 RID: 950 RVA: 0x000176AC File Offset: 0x000158AC
		public static void CreatePartnerRegistryEntry(string clientInstallDir)
		{
			string name = string.Format("Software\\BlueStacks{0}\\Config", Strings.GetOemTag());
			Logger.Info("CreatePartnerRegistryEntry start");
			using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(name, true))
			{
				if (registryKey != null)
				{
					registryKey.SetValue("PartnerExePath", Path.Combine(clientInstallDir, "BlueStacks.exe"));
				}
				else
				{
					Logger.Info("Not writing partner exe path , registry not exists");
				}
			}
		}

		// Token: 0x060003B7 RID: 951 RVA: 0x00017724 File Offset: 0x00015924
		public static bool RecreateAddRemoveRegistry(string pfDir, string iconPath, string displayName, string publisher)
		{
			try
			{
				string subkey = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\BlueStacks" + Strings.GetOemTag();
				using (RegistryKey registryKey = Registry.LocalMachine.CreateSubKey(subkey))
				{
					registryKey.SetValue("DisplayName", displayName);
					registryKey.SetValue("DisplayVersion", "4.140.12.1002");
					registryKey.SetValue("DisplayIcon", iconPath);
					registryKey.SetValue("EstimatedSize", 2096128, RegistryValueKind.DWord);
					registryKey.SetValue("InstallDate", string.Format("{0:yyyyMMdd}", DateTime.Now));
					registryKey.SetValue("NoModify", "1", RegistryValueKind.DWord);
					registryKey.SetValue("NoRepair", "1", RegistryValueKind.DWord);
					registryKey.SetValue("Publisher", publisher);
					registryKey.SetValue("UninstallString", Path.Combine(pfDir, "BlueStacksUninstaller.exe -tmp"));
				}
				return true;
			}
			catch (Exception ex)
			{
				Logger.Info("Error in creating ControlPanel registry: {0}", new object[]
				{
					ex.ToString()
				});
			}
			return false;
		}

		// Token: 0x060003B8 RID: 952 RVA: 0x0001783C File Offset: 0x00015A3C
		public static List<string> GetUninstallCurrentVersionSubKey(string keyToSearch)
		{
			List<string> list = new List<string>();
			using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall", true))
			{
				foreach (string text in registryKey.GetSubKeyNames())
				{
					using (RegistryKey registryKey2 = registryKey.OpenSubKey(text, true))
					{
						string text2 = (string)registryKey2.GetValue("DisplayName");
						if (text2 != null && text2.Equals(keyToSearch, StringComparison.OrdinalIgnoreCase))
						{
							list.Add(text);
						}
					}
				}
			}
			return list;
		}

		// Token: 0x060003B9 RID: 953 RVA: 0x000178E8 File Offset: 0x00015AE8
		public static RunCommand.CmdRes ExtractZip(string zipFilePath, string extractDirectory)
		{
			string cmd = Path.Combine(Directory.GetCurrentDirectory(), "7zr.exe");
			if (!Directory.Exists(extractDirectory))
			{
				Directory.CreateDirectory(extractDirectory);
			}
			string args = string.Format("x \"{0}\" -o\"{1}\" -aoa", zipFilePath, extractDirectory);
			return RunCommand.RunCmd(cmd, args, false, true, false, 0);
		}

		// Token: 0x060003BA RID: 954 RVA: 0x0001792C File Offset: 0x00015B2C
		public static void CopyLogFileToLogDir(string logFilePath, string destFileName)
		{
			try
			{
				string destFileName2 = Path.Combine(RegistryManager.Instance.LogDir, destFileName);
				File.Copy(logFilePath, destFileName2, true);
			}
			catch (Exception ex)
			{
				Logger.Error("Got exception when copying isntaller logs in log dir ex :{0}", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x060003BB RID: 955 RVA: 0x00017980 File Offset: 0x00015B80
		public static void DeleteDirectory(List<string> directories, bool throwError = false)
		{
			foreach (string text in directories)
			{
				try
				{
					CommonInstallUtils.DeleteDirectory(text);
				}
				catch (Exception ex)
				{
					Logger.Warning("Failed to delete directory {0}, ignoring", new object[]
					{
						text
					});
					Logger.Warning(ex.Message);
					if (throwError)
					{
						throw;
					}
				}
			}
		}

		// Token: 0x060003BC RID: 956 RVA: 0x00017A04 File Offset: 0x00015C04
		public static void DeleteDirectory(string targetDir)
		{
			if (string.IsNullOrEmpty(targetDir) || CommonInstallUtils.sDisallowedDeletionStrings.Any((string str) => str.Equals(targetDir, StringComparison.CurrentCultureIgnoreCase)))
			{
				Logger.Warning("A hazardous DirectoryDelete for '{0}' was invoked. Ignoring the call", new object[]
				{
					targetDir
				});
				return;
			}
			try
			{
				Logger.Info("Deleting directory : " + targetDir);
				Directory.Delete(targetDir, true);
			}
			catch (DirectoryNotFoundException)
			{
				Logger.Warning("Could not delete {0} as it does not exist", new object[]
				{
					targetDir
				});
			}
			catch (Exception ex)
			{
				Logger.Warning("Got exception when deleting {0}, err:{1}", new object[]
				{
					targetDir,
					ex.ToString()
				});
				Logger.Info("------------- FOR DEV TRACKING --------------");
				foreach (string path in Directory.GetFiles(targetDir))
				{
					File.SetAttributes(path, FileAttributes.Normal);
					File.Delete(path);
				}
				string[] array = Directory.GetDirectories(targetDir);
				for (int i = 0; i < array.Length; i++)
				{
					CommonInstallUtils.DeleteDirectory(array[i]);
				}
				try
				{
					Directory.Delete(targetDir, true);
				}
				catch (IOException)
				{
					Thread.Sleep(100);
					try
					{
						Directory.Delete(targetDir, true);
					}
					catch
					{
					}
				}
				catch (UnauthorizedAccessException)
				{
					Thread.Sleep(100);
					try
					{
						Directory.Delete(targetDir, true);
					}
					catch
					{
					}
				}
			}
		}

		// Token: 0x060003BD RID: 957 RVA: 0x00017BB4 File Offset: 0x00015DB4
		public static void GetScreenResolution(out int windowWidth, out int windowHeight, out int guestWidth, out int guestHeight)
		{
			double aspectRatio = 1.7777777777777777;
			double num;
			double num2;
			double num3;
			WpfUtils.GetDefaultSize(out num, out num2, out num3, aspectRatio, true);
			windowWidth = (int)(num - 17.0) / 16 * 16;
			windowHeight = windowWidth / 16 * 9;
			Utils.GetGuestWidthAndHeight(windowWidth, windowHeight, out guestWidth, out guestHeight);
			if (Oem.Instance.IsPixelParityToBeIgnored)
			{
				Utils.GetWindowWidthAndHeight(out guestWidth, out guestHeight);
			}
			Logger.Info("Resolution values: guestWidth: {0} guestHeight: {1} widowWidth: {2} windowHeight: {3}", new object[]
			{
				guestWidth,
				guestHeight,
				windowWidth,
				windowHeight
			});
		}

		// Token: 0x060003BE RID: 958 RVA: 0x00017C4C File Offset: 0x00015E4C
		public static void CreateWebUrlScheme(string clientInstallDir)
		{
			try
			{
				string bgpkeyName = Strings.BGPKeyName;
				using (RegistryKey registryKey = Registry.ClassesRoot.CreateSubKey(bgpkeyName))
				{
					registryKey.SetValue("", "BlueStacks Web Url Scheme");
					registryKey.SetValue("URL Protocol", "");
				}
				using (RegistryKey registryKey2 = Registry.ClassesRoot.CreateSubKey(bgpkeyName + "\\DefaultIcon"))
				{
					registryKey2.SetValue("", Path.Combine(clientInstallDir, "ProductLogo.ico"));
				}
				using (RegistryKey registryKey3 = Registry.ClassesRoot.CreateSubKey(bgpkeyName + "\\Shell"))
				{
					registryKey3.SetValue("", "open");
				}
				using (RegistryKey registryKey4 = Registry.ClassesRoot.CreateSubKey(bgpkeyName + "\\Shell\\open"))
				{
					registryKey4.SetValue("", "Open BlueStacks Game Platform");
				}
				using (RegistryKey registryKey5 = Registry.ClassesRoot.CreateSubKey(bgpkeyName + "\\Shell\\open\\command"))
				{
					string arg = Path.Combine(clientInstallDir, "Bluestacks.exe");
					string value = string.Format("\"{0}\" %1", arg);
					registryKey5.SetValue("", value);
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Failed to create web url scheme. Err: " + ex.ToString());
			}
		}

		// Token: 0x060003BF RID: 959 RVA: 0x00017E38 File Offset: 0x00016038
		public static void CreateInstallApkScheme(string installDir, string baseKeyName, string targetBinary)
		{
			Logger.Info("CreateInstallApkScheme start");
			try
			{
				using (RegistryKey registryKey = Registry.ClassesRoot.CreateSubKey(baseKeyName))
				{
					registryKey.SetValue("", string.Format("{0} Android Package File", Strings.ProductDisplayName));
				}
				using (RegistryKey registryKey2 = Registry.ClassesRoot.CreateSubKey(baseKeyName + "\\DefaultIcon"))
				{
					registryKey2.SetValue("", RegistryStrings.ProductIconCompletePath);
				}
				using (RegistryKey registryKey3 = Registry.ClassesRoot.CreateSubKey(baseKeyName + "\\Shell"))
				{
					registryKey3.SetValue("", "open");
				}
				using (RegistryKey registryKey4 = Registry.ClassesRoot.CreateSubKey(baseKeyName + "\\Shell\\open"))
				{
					registryKey4.SetValue("", string.Format("Open with {0} APK Installer", Strings.ProductDisplayName));
				}
				using (RegistryKey registryKey5 = Registry.ClassesRoot.CreateSubKey(baseKeyName + "\\Shell\\open\\command"))
				{
					string arg = Path.Combine(installDir, targetBinary);
					string value = string.Format("{0} \"%1\"", arg);
					registryKey5.SetValue("", value);
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Some error while setting APKHandler extention association, ex: " + ex.Message);
			}
			try
			{
				if (baseKeyName.Equals("BlueStacks.Apk"))
				{
					using (RegistryKey registryKey6 = Registry.ClassesRoot.CreateSubKey(".apk"))
					{
						registryKey6.SetValue("", baseKeyName, RegistryValueKind.String);
						goto IL_1AA;
					}
				}
				using (RegistryKey registryKey7 = Registry.ClassesRoot.CreateSubKey(".xapk"))
				{
					registryKey7.SetValue("", baseKeyName, RegistryValueKind.String);
				}
				IL_1AA:;
			}
			catch (Exception ex2)
			{
				Logger.Warning("Some error while setting main .apk extention association, ex: " + ex2.Message);
			}
			Logger.Info("CreateInstallApkScheme end");
		}

		// Token: 0x060003C0 RID: 960 RVA: 0x000180F4 File Offset: 0x000162F4
		public static void DeleteInstallApkScheme(string installDir, string baseKeyName)
		{
			Logger.Info("DeleteInstallApkScheme start");
			try
			{
				string text = "junkPath";
				using (RegistryKey registryKey = Registry.ClassesRoot.OpenSubKey(baseKeyName + "\\Shell\\open\\command"))
				{
					text = (string)registryKey.GetValue("");
				}
				text.TrimEnd(new char[]
				{
					'"'
				});
				if (text.StartsWith(installDir))
				{
					Registry.ClassesRoot.DeleteSubKeyTree(baseKeyName);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to delete apk handler registry. Ex : " + ex.ToString());
			}
			Logger.Info("DeleteInstallApkScheme end");
		}

		// Token: 0x060003C1 RID: 961 RVA: 0x000181AC File Offset: 0x000163AC
		public static void LogAllServiceNames()
		{
			try
			{
				Logger.Info("Installed kernel level services:-");
				foreach (ServiceController serviceController in ServiceController.GetDevices())
				{
					Logger.Info("ServiceName: {0},\tDisplayName: {1}", new object[]
					{
						serviceController.ServiceName,
						serviceController.DisplayName
					});
				}
				Logger.Info("Installed services:-");
				foreach (ServiceController serviceController2 in ServiceController.GetServices())
				{
					Logger.Info("ServiceName: {0},\tDisplayName: {1}", new object[]
					{
						serviceController2.ServiceName,
						serviceController2.DisplayName
					});
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Some error occured while logging services, ex: " + ex.Message);
			}
		}

		// Token: 0x060003C2 RID: 962 RVA: 0x00018270 File Offset: 0x00016470
		public static void CheckForActiveHandles(string installerExtractedPath)
		{
			Logger.Info("Checking for active Handles");
			try
			{
				RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Sysinternals\\Handle", true);
				if (registryKey == null)
				{
					Registry.CurrentUser.CreateSubKey("Software\\Sysinternals\\Handle");
				}
				else
				{
					registryKey.Close();
				}
				using (RegistryKey registryKey2 = Registry.CurrentUser.OpenSubKey("Software\\Sysinternals\\Handle", true))
				{
					registryKey2.SetValue("EulaAccepted", 1, RegistryValueKind.DWord);
					Logger.Info("Accepted");
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Couldn't access registry, ex: {0}", new object[]
				{
					ex.Message
				});
			}
			try
			{
				string cmd = Path.Combine(installerExtractedPath, "HD-Handle.exe");
				string args = "bluestacks";
				RunCommand.RunCmd(cmd, args, true, true, false, 0);
			}
			catch (Exception ex2)
			{
				Logger.Warning("Couldn't check for active handles, ex: {0}", new object[]
				{
					ex2.Message
				});
			}
		}

		// Token: 0x060003C3 RID: 963 RVA: 0x00004199 File Offset: 0x00002399
		public static void RemoveAndAddFirewallRule(string ruleName, string binPath)
		{
			CommonInstallUtils.RemoveFirewallRule(ruleName);
			CommonInstallUtils.AddFirewallRule(ruleName, binPath);
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x00018370 File Offset: 0x00016570
		public static void AddFirewallRule(string ruleName, string binPath)
		{
			try
			{
				string cmd = "netsh.exe";
				string args = string.Format("advfirewall firewall add rule name=\"{0}\" dir=in action=allow program=\"{1}\" enable=yes", ruleName, binPath);
				RunCommand.RunCmd(cmd, args, false, true, false, 0);
			}
			catch (Exception ex)
			{
				Logger.Error("Error in adding firewall rule", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x060003C5 RID: 965 RVA: 0x000183C8 File Offset: 0x000165C8
		public static void RemoveFirewallRule(string ruleName)
		{
			try
			{
				string cmd = "netsh.exe";
				string args = string.Format("advfirewall firewall delete rule name=\"{0}\"", ruleName);
				RunCommand.RunCmd(cmd, args, false, true, false, 0);
			}
			catch (Exception ex)
			{
				Logger.Error("{0} Firewall rule dont exist {1}", new object[]
				{
					ruleName,
					ex.ToString()
				});
			}
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x00018424 File Offset: 0x00016624
		public static bool CreateHardLinkForFile(string existingFilePath, string newFilePath)
		{
			try
			{
				Logger.Info("Creating link from " + existingFilePath + " to " + newFilePath);
				if (!CommonInstallUtils.CreateHardLink(newFilePath, existingFilePath, IntPtr.Zero))
				{
					Logger.Error("Failed to create hard link: " + Marshal.GetLastWin32Error());
					if (File.Exists(existingFilePath))
					{
						Logger.Error("Copying the file instead");
						File.Copy(existingFilePath, newFilePath, true);
					}
				}
				return true;
			}
			catch (Exception ex)
			{
				Logger.Error("Failed in creating hard link, Ex: " + ex.ToString());
			}
			return false;
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x000184B8 File Offset: 0x000166B8
		public static bool CreateHardLinkForDirectory(string existingDirPath, string newDirPath)
		{
			try
			{
				Logger.Info("Creating link from " + existingDirPath + " to " + newDirPath);
				if (!Directory.Exists(newDirPath))
				{
					Directory.CreateDirectory(newDirPath);
				}
				foreach (FileInfo fileInfo in new DirectoryInfo(existingDirPath).GetFiles())
				{
					string fullName = fileInfo.FullName;
					string newFilePath = Path.Combine(newDirPath, fileInfo.Name);
					if (!CommonInstallUtils.CreateHardLinkForFile(fullName, newFilePath))
					{
						Logger.Error("Failed to create hard link for file : " + fileInfo.FullName);
						return false;
					}
				}
				foreach (DirectoryInfo directoryInfo in new DirectoryInfo(existingDirPath).GetDirectories())
				{
					if (!CommonInstallUtils.CreateHardLinkForDirectory(Path.Combine(existingDirPath, directoryInfo.Name), Path.Combine(newDirPath, directoryInfo.Name)))
					{
						return false;
					}
				}
				return true;
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to create hard link for directory, Err: " + ex.ToString());
			}
			return false;
		}

		// Token: 0x060003C8 RID: 968 RVA: 0x000185B8 File Offset: 0x000167B8
		public static bool IsDiskFull(Exception ex)
		{
			int num = Marshal.GetHRForException(ex) & 65535;
			Logger.Info("Win32 error code: " + num);
			Logger.Info("Disk full error codes are: {0} and {1}", new object[]
			{
				112,
				39
			});
			return num == 39 || num == 112;
		}

		// Token: 0x060003C9 RID: 969 RVA: 0x00018618 File Offset: 0x00016818
		public static bool StopAndUninstallService(string svcName, int timeoutSeconds = 15, bool isKernelDriver = false)
		{
			Logger.Info("Uninstalling service {0}", new object[]
			{
				svcName
			});
			bool result;
			try
			{
				CommonInstallUtils.StopService(svcName, timeoutSeconds);
				CommonInstallUtils.UninstallService(svcName, isKernelDriver);
				result = true;
			}
			catch (Exception ex)
			{
				Logger.Warning("Ignoring exception when uninstalling service {0} ex : {1}", new object[]
				{
					svcName,
					ex.ToString()
				});
				result = false;
			}
			return result;
		}

		// Token: 0x060003CA RID: 970 RVA: 0x00018680 File Offset: 0x00016880
		private static void StopService(string serviceName, int timeoutSeconds = 15)
		{
			Logger.Info("Stopping service {0} with timeout {1}s", new object[]
			{
				serviceName,
				timeoutSeconds
			});
			ServiceController serviceController = new ServiceController(serviceName);
			TimeSpan timeout = TimeSpan.FromSeconds((double)timeoutSeconds);
			if (serviceController.Status == ServiceControllerStatus.Stopped || serviceController.Status == ServiceControllerStatus.StopPending)
			{
				serviceController.WaitForStatus(ServiceControllerStatus.Stopped, timeout);
				Logger.Info("Service {0} stopped", new object[]
				{
					serviceName
				});
				return;
			}
			try
			{
				Logger.Info("Service is running , stopping the service {0}", new object[]
				{
					serviceName
				});
				serviceController.Stop();
				serviceController.WaitForStatus(ServiceControllerStatus.Stopped, timeout);
				Logger.Info("Service stopped successfully");
			}
			catch (System.ServiceProcess.TimeoutException)
			{
				Logger.Error("Timed out while waiting for service to stop");
				throw;
			}
			catch (Exception ex)
			{
				Logger.Error("Got exception stopping service {0}, Err: {1}", new object[]
				{
					serviceName,
					ex.ToString()
				});
				throw;
			}
		}

		// Token: 0x060003CB RID: 971 RVA: 0x000041A8 File Offset: 0x000023A8
		private static void UninstallService(string name, bool isKernelDriverService = false)
		{
			ServiceManager.UninstallService(name, isKernelDriverService);
		}

		// Token: 0x060003CC RID: 972 RVA: 0x00018760 File Offset: 0x00016960
		public static bool DoesRegistryHKLMHiveExist(string hivePath)
		{
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(hivePath);
			bool flag = registryKey != null;
			if (flag)
			{
				registryKey.Close();
			}
			return flag;
		}

		// Token: 0x060003CD RID: 973 RVA: 0x000041B2 File Offset: 0x000023B2
		public static string ConvertIntToEnumString(int enumCode)
		{
			return Enum.GetName(typeof(InstallerCodes), (InstallerCodes)enumCode);
		}

		// Token: 0x060003CE RID: 974 RVA: 0x00018788 File Offset: 0x00016988
		public static string GetCurrentLocale()
		{
			string result;
			try
			{
				result = Thread.CurrentThread.CurrentCulture.Name;
			}
			catch
			{
				result = "en-US";
			}
			return result;
		}

		// Token: 0x060003CF RID: 975 RVA: 0x000041C9 File Offset: 0x000023C9
		public static void StopBlueStacksIfUpgrade(bool isUpgrade, string svcName, out bool isServiceStopped)
		{
			isServiceStopped = true;
			if (isUpgrade)
			{
				CommonInstallUtils.KillBlueStacksProcesses();
				CommonInstallUtils.RunHdQuit();
				ServiceManager.StopService(svcName, false);
				isServiceStopped = CommonInstallUtils.CheckIfServiceStopped(svcName);
			}
		}

		// Token: 0x060003D0 RID: 976 RVA: 0x000187C4 File Offset: 0x000169C4
		private static bool CheckIfServiceStopped(string svcName)
		{
			try
			{
				Logger.Info("Checking if {0} is stopped", new object[]
				{
					svcName
				});
				ServiceController[] devices = ServiceController.GetDevices();
				int i = 0;
				while (i < devices.Length)
				{
					ServiceController serviceController = devices[i];
					if (serviceController.ServiceName == svcName)
					{
						ServiceControllerStatus status = serviceController.Status;
						Logger.Info("Service status of {0} is {1}", new object[]
						{
							svcName,
							status
						});
						if (status != ServiceControllerStatus.Stopped)
						{
							Logger.Warning("Service is not stopped, returning false");
							return false;
						}
						break;
					}
					else
					{
						i++;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("An error occured while checking if svc is stopped, ex: " + ex.ToString());
			}
			return true;
		}

		// Token: 0x060003D1 RID: 977 RVA: 0x00018874 File Offset: 0x00016A74
		public static bool IsUpgradePossible(string clientKeyPath)
		{
			Logger.Info("Checking if upgrade possible");
			bool flag = false;
			Version v = new Version("3.52.66.1905");
			Version v2 = new Version("2.52.66.8704");
			using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(clientKeyPath))
			{
				string text = string.Empty;
				string text2 = string.Empty;
				if (registryKey != null)
				{
					text = (string)registryKey.GetValue("ClientVersion", "");
					if (string.IsNullOrEmpty(text))
					{
						text2 = (string)registryKey.GetValue("Version", "");
					}
				}
				if (!string.IsNullOrEmpty(text))
				{
					Version v3 = new Version(text);
					Logger.Info("Previous client version is {0}", new object[]
					{
						text
					});
					if (v3 >= v)
					{
						flag = true;
					}
				}
				else if (!string.IsNullOrEmpty(text2))
				{
					Version v4 = new Version(text2);
					Logger.Info("Previous engine version is {0}", new object[]
					{
						text2
					});
					if (v4 >= v2)
					{
						flag = true;
					}
				}
				else
				{
					Logger.Info("ClientVersion as well as Version registry not found so setting isUpgradePossible to false");
					flag = false;
				}
			}
			Logger.Info("IsUpgradePossible: {0}", new object[]
			{
				flag
			});
			return flag;
		}

		// Token: 0x060003D2 RID: 978 RVA: 0x000189AC File Offset: 0x00016BAC
		public static string GenerateUniqueInstallId()
		{
			Logger.Info("Generating install ID");
			try
			{
				string text = Guid.NewGuid().ToString();
				Logger.Info("GeneratedID: " + text);
				return text;
			}
			catch (Exception ex)
			{
				Logger.Warning("Failed to generate unique install id");
				Logger.Warning(ex.ToString());
			}
			return string.Empty;
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x00018A18 File Offset: 0x00016C18
		public static void LogAllDirs(List<string> listOfDirs)
		{
			Logger.Info("-----------------------------------------------------");
			Logger.Info("Logging all dirs");
			foreach (string dir in listOfDirs.Distinct<string>().ToList<string>())
			{
				CommonInstallUtils.LogDir(dir, false);
			}
			Logger.Info("-----------------------------------------------------");
		}

		// Token: 0x060003D4 RID: 980 RVA: 0x00018A8C File Offset: 0x00016C8C
		public static void LogDir(string dir, bool onlyDirs = false)
		{
			try
			{
				CommonInstallUtils.DumpDirListing(dir, onlyDirs);
			}
			catch (Exception ex)
			{
				Logger.Warning("Couldn't log dir {0}, ignoring exception: {1}", new object[]
				{
					dir,
					ex.Message
				});
			}
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x00018AD4 File Offset: 0x00016CD4
		private static void DumpDirListing(string dir, bool onlyDirs = false)
		{
			string args = string.Format("/c dir \"{0}\" /s", dir);
			if (onlyDirs)
			{
				args = string.Format("/c dir \"{0}\" /ad /s", dir);
			}
			RunCommand.RunCmd("cmd", args, true, true, false, 0);
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x00018B0C File Offset: 0x00016D0C
		public static bool CheckForOldConfigFiles(string dataDir)
		{
			try
			{
				string path = Path.Combine(dataDir, "UserData\\InputMapper\\UserFiles");
				if (Directory.Exists(path))
				{
					foreach (FileInfo fileInfo in new DirectoryInfo(path).GetFiles("*.cfg"))
					{
						if (fileInfo.Length != 0L)
						{
							return true;
						}
						Logger.Warning("Zero length config file found, ignoring: {0}", new object[]
						{
							fileInfo.Name
						});
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Some error in checking for old Config Files: " + ex.Message);
			}
			return false;
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x00018BA8 File Offset: 0x00016DA8
		public static bool CheckIfValidJsonFile(string jsonFileName)
		{
			try
			{
				Logger.Info("Checking if {0} is a valid json file", new object[]
				{
					jsonFileName
				});
				JArray.Parse(File.ReadAllText(jsonFileName));
				return true;
			}
			catch (Exception ex)
			{
				Logger.Error("{0} may be corrupt. Ex: {1}", new object[]
				{
					jsonFileName,
					ex.Message
				});
			}
			return false;
		}

		// Token: 0x060003D8 RID: 984 RVA: 0x00018C0C File Offset: 0x00016E0C
		public static string ZipLogsAndRegistry(string logsDir, string currentInstallerLogPath)
		{
			Logger.Info("In ZipLogsAndRegistry");
			string result;
			try
			{
				string text = CommonInstallUtils.CreateStagingDir();
				string text2 = Path.Combine(text, "Logs");
				if (Directory.Exists(logsDir))
				{
					Directory.CreateDirectory(text2);
					CommonInstallUtils.CopyFiles(logsDir, text2);
					CommonInstallUtils.ExportBluestacksRegistry(text, "RegHKLM.txt");
					string destFileName = Path.Combine(text, Path.GetFileName(currentInstallerLogPath));
					File.Copy(currentInstallerLogPath, destFileName);
					string text3 = Path.Combine(Path.GetTempPath(), "Installer.zip");
					CommonInstallUtils.CreateZipFile(text, text3);
					Directory.Delete(text2, true);
					result = text3;
				}
				else
				{
					result = null;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in creating zip file " + ex.ToString());
				result = null;
			}
			return result;
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x00018CC4 File Offset: 0x00016EC4
		private static void CreateZipFile(string zipFolderTempPath, string zipFilePath)
		{
			try
			{
				string prog = Path.Combine(Directory.GetCurrentDirectory(), "7zr.exe");
				string args = string.Format("a {0} -m0=LZMA:a=2 {1}\\*", zipFilePath, zipFolderTempPath);
				if (File.Exists(zipFilePath))
				{
					File.Delete(zipFilePath);
				}
				Utils.RunCmd(prog, args, null);
			}
			catch (Exception ex)
			{
				Logger.Error("Error in creating Zip " + ex.ToString());
			}
		}

		// Token: 0x060003DA RID: 986 RVA: 0x00018D30 File Offset: 0x00016F30
		private static void ExportBluestacksRegistry(string destination, string fileName)
		{
			try
			{
				string args = string.Format("EXPORT HKLM\\{0} \"{1}\"", Strings.RegistryBaseKeyPath, Path.Combine(destination, fileName));
				Utils.RunCmd("reg.exe", args, null);
			}
			catch
			{
			}
		}

		// Token: 0x060003DB RID: 987 RVA: 0x00018D78 File Offset: 0x00016F78
		private static void CopyFiles(string src, string dest)
		{
			foreach (string text in Directory.GetFiles(src))
			{
				string fileName = Path.GetFileName(text);
				string destFileName = Path.Combine(dest, fileName);
				File.Copy(text, destFileName);
			}
		}

		// Token: 0x060003DC RID: 988 RVA: 0x00018DB4 File Offset: 0x00016FB4
		private static string CreateStagingDir()
		{
			string randomFileName = Path.GetRandomFileName();
			string text = Path.Combine(Path.GetTempPath(), randomFileName);
			if (Directory.Exists(text))
			{
				Directory.Delete(text);
			}
			Directory.CreateDirectory(text);
			return text;
		}

		// Token: 0x060003DD RID: 989 RVA: 0x00018DEC File Offset: 0x00016FEC
		public static Dictionary<string, string> GetSupportedGLModes(string glCheckDir)
		{
			Logger.Info("Checking for supported GL Modes");
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			List<string> list = new List<string>();
			try
			{
				foreach (string text in new List<string>
				{
					"1 1",
					"4 1",
					"1 2",
					"4 2"
				})
				{
					if (CommonInstallUtils.RunGLCheck(glCheckDir, text) == 0)
					{
						list.Add(text);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("An error occured while checking for supported GLModes");
				Logger.Error(ex.ToString());
			}
			dictionary["supported_glmodes"] = string.Join(",", list.ToArray());
			Logger.Info("Supported GL Modes: " + string.Join(",", list.ToArray()));
			return dictionary;
		}

		// Token: 0x060003DE RID: 990 RVA: 0x00018EE8 File Offset: 0x000170E8
		private static int RunGLCheck(string glCheckDir, string args)
		{
			try
			{
				return RunCommand.RunCmd(Path.Combine(glCheckDir, "HD-GLCheck.exe"), args, true, true, false, 10000).ExitCode;
			}
			catch (Exception ex)
			{
				Logger.Warning("An error occured while running glcheck, ignorning.");
				Logger.Warning(ex.Message);
			}
			return -1;
		}

		// Token: 0x060003DF RID: 991 RVA: 0x00003337 File Offset: 0x00001537
		public static void CheckIfVulkanSupported()
		{
		}

		// Token: 0x060003E0 RID: 992 RVA: 0x00018F40 File Offset: 0x00017140
		public static void WriteClientVersionInFile(string version)
		{
			int i = 5;
			while (i > 0)
			{
				try
				{
					string text = Path.Combine(RegistryManager.Instance.UserDefinedDir, "bst_params.txt");
					CommonInstallUtils.WriteToFile(text, string.Format("version={0}", version), "version");
					Logger.Info("version written to file successfully");
					string identity = new SecurityIdentifier("S-1-1-0").Translate(typeof(NTAccount)).ToString();
					FileInfo fileInfo = new FileInfo(text);
					FileSecurity accessControl = fileInfo.GetAccessControl();
					accessControl.AddAccessRule(new FileSystemAccessRule(identity, FileSystemRights.FullControl, AccessControlType.Allow));
					fileInfo.SetAccessControl(accessControl);
					break;
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to write agent port to bst_params.txt. Ex: " + ex.ToString());
				}
				Logger.Info("retrying..." + i);
				i--;
				Thread.Sleep(500);
			}
		}

		// Token: 0x060003E1 RID: 993 RVA: 0x00019020 File Offset: 0x00017220
		private static void WriteToFile(string path, string text, string searchText = "")
		{
			bool flag = true;
			List<string> list = new List<string>();
			if (File.Exists(path))
			{
				foreach (string text2 in File.ReadAllLines(path))
				{
					if (text2.Contains("="))
					{
						if (text2.Contains(searchText))
						{
							list.Add(text);
							flag = false;
						}
						else
						{
							list.Add(text2);
						}
					}
				}
			}
			if (flag)
			{
				using (TextWriter textWriter = new StreamWriter(path, true))
				{
					textWriter.WriteLine(text);
					textWriter.Flush();
					return;
				}
			}
			using (TextWriter textWriter2 = new StreamWriter(path, false))
			{
				foreach (string value in list)
				{
					textWriter2.WriteLine(value);
				}
				textWriter2.Flush();
			}
		}

		// Token: 0x060003E2 RID: 994 RVA: 0x000041EA File Offset: 0x000023EA
		public static int SetupVmConfig(string installDir, string dataDir)
		{
			Logger.Info("In SetupVmConfig");
			if (!CommonInstallUtils.InstallVmConfig(installDir, dataDir))
			{
				Logger.Info("Throwing error cannot create android.bstk from in file");
				return -42;
			}
			return 0;
		}

		// Token: 0x060003E3 RID: 995 RVA: 0x0000420D File Offset: 0x0000240D
		public static int SetupBstkGlobalConfig(string installDir, string dataDir)
		{
			Logger.Info("In SetupBstkGlobalConfig");
			if (!CommonInstallUtils.InstallVirtualBoxConfig(dataDir, false))
			{
				Logger.Info("Throwing error cannot create bstkglobal from in file");
				return -41;
			}
			return 0;
		}

		// Token: 0x060003E4 RID: 996 RVA: 0x00019128 File Offset: 0x00017328
		public static bool InstallVirtualBoxConfig(string dataDir, bool isUpgrade = false)
		{
			Logger.Info("InstallVirtualBoxConfig()");
			string path = Path.Combine(dataDir, "Manager");
			string text = Path.Combine(Path.Combine(dataDir, "Manager"), "BstkGlobal.xml");
			string text2 = Path.Combine(path, "BstkGlobal.xml.in");
			string text3 = null;
			try
			{
				using (StreamReader streamReader = new StreamReader(text2))
				{
					text3 = streamReader.ReadToEnd();
				}
			}
			catch (Exception ex)
			{
				Logger.Error(string.Concat(new object[]
				{
					"Cannot read '",
					text2,
					"': ",
					ex
				}));
				return false;
			}
			string str = dataDir;
			if (isUpgrade)
			{
				str = RegistryStrings.DataDir.TrimEnd(new char[]
				{
					'\\'
				});
			}
			string text4 = text3;
			text4 = text4.Replace("@@USER_DEFINED_DIR@@", str + "\\");
			try
			{
				using (StreamWriter streamWriter = new StreamWriter(text))
				{
					streamWriter.Write(text4);
				}
			}
			catch (Exception ex2)
			{
				Logger.Error(string.Concat(new object[]
				{
					"Cannot write '",
					text,
					"': ",
					ex2
				}));
				return false;
			}
			return true;
		}

		// Token: 0x060003E5 RID: 997 RVA: 0x00019280 File Offset: 0x00017480
		private static bool InstallVmConfig(string installDir, string dataDir)
		{
			Logger.Info("InstallVmConfig()");
			string path = Path.Combine(dataDir, "Android");
			string text = Path.Combine(path, "Android.bstk");
			string text2 = Path.Combine(path, "Android.bstk.in");
			string text3 = null;
			if (File.Exists(text))
			{
				Logger.Info("android.bstk already present returning");
				return true;
			}
			try
			{
				using (StreamReader streamReader = new StreamReader(text2))
				{
					text3 = streamReader.ReadToEnd();
				}
			}
			catch (Exception ex)
			{
				Logger.Info(string.Concat(new object[]
				{
					"Cannot read '",
					text2,
					"': ",
					ex
				}));
				return false;
			}
			string text4 = text3;
			text4 = text4.Replace("@@HD_PLUS_DEVICES_DLL_PATH@@", SecurityElement.Escape(Path.Combine(installDir, "HD-Plus-Devices.dll")));
			string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
			if (!string.IsNullOrEmpty(folderPath))
			{
				string newValue = string.Format("<SharedFolder name=\"Documents\" hostPath=\"{0}\" writable=\"true\" autoMount=\"false\"/>", SecurityElement.Escape(folderPath));
				text4 = text4.Replace("@@USER_DOCUMENTS_FOLDER@@", newValue);
			}
			else
			{
				text4 = text4.Replace("@@USER_DOCUMENTS_FOLDER@@", "");
			}
			string folderPath2 = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
			if (!string.IsNullOrEmpty(folderPath2))
			{
				string newValue2 = string.Format("<SharedFolder name=\"Pictures\" hostPath=\"{0}\" writable=\"true\" autoMount=\"false\"/>", SecurityElement.Escape(folderPath2));
				text4 = text4.Replace("@@USER_PICTURES_FOLDER@@", newValue2);
			}
			else
			{
				text4 = text4.Replace("@@USER_PICTURES_FOLDER@@", "");
			}
			text4 = text4.Replace("@@INPUT_MAPPER_FOLDER@@", SecurityElement.Escape(Path.Combine(dataDir, "UserData\\InputMapper")));
			text4 = text4.Replace("@@BST_SHARED_FOLDER@@", SecurityElement.Escape(Path.Combine(dataDir, "UserData\\SharedFolder")));
			text4 = text4.Replace("@@BST_VM_MEMORY_SIZE@@", SecurityElement.Escape(Utils.GetAndroidVMMemory(true).ToString()));
			try
			{
				XmlDocument xmlDocument = new XmlDocument();
				xmlDocument.LoadXml(text4);
				xmlDocument.Save(text);
			}
			catch (Exception ex2)
			{
				Logger.Info(string.Concat(new object[]
				{
					"Cannot write '",
					text,
					"': ",
					ex2
				}));
				return false;
			}
			return true;
		}

		// Token: 0x060003E6 RID: 998 RVA: 0x00019494 File Offset: 0x00017694
		public static bool CheckSupportedGlRenderMode(out int glRenderMode, out string glVendor, out string glRenderer, out string glVersion, out GLMode glMode)
		{
			glRenderMode = 4;
			glVersion = "";
			glRenderer = "";
			glVendor = "";
			glMode = GLMode.PGA;
			if (Oem.Instance.CheckForAGAInInstaller && CommonInstallUtils.CheckSupportedGlRenderMode(GLMode.AGA, out glRenderMode, out glVendor, out glRenderer, out glVersion))
			{
				Logger.Info("AGA supported!");
				glMode = GLMode.AGA;
				return true;
			}
			return CommonInstallUtils.CheckSupportedGlRenderMode(GLMode.PGA, out glRenderMode, out glVendor, out glRenderer, out glVersion);
		}

		// Token: 0x060003E7 RID: 999 RVA: 0x000194F0 File Offset: 0x000176F0
		public static bool CheckSupportedGlRenderMode(GLMode mode, out int glRenderMode, out string glVendor, out string glRenderer, out string glVersion)
		{
			glRenderMode = 4;
			glVersion = "";
			glRenderer = "";
			glVendor = "";
			try
			{
				int num;
				if (BlueStacksGL.GLCheckInstallation(GLRenderer.OpenGL, mode, out glVendor, out glRenderer, out glVersion) == 0)
				{
					num = 0;
					glRenderMode = 1;
				}
				else if (SystemUtils.IsOs64Bit())
				{
					if (CommonInstallUtils.GpuWithDx9SupportOnly())
					{
						Logger.Info("Machine has gpu which runs on DX9 only");
						glRenderMode = 2;
						num = BlueStacksGL.GLCheckInstallation(GLRenderer.DX9, mode, out glVendor, out glRenderer, out glVersion);
					}
					else
					{
						glRenderMode = 4;
						num = BlueStacksGL.GLCheckInstallation(GLRenderer.DX11FallbackDX9, mode, out glVendor, out glRenderer, out glVersion);
						if (num != 0)
						{
							glRenderMode = 2;
							num = BlueStacksGL.GLCheckInstallation(GLRenderer.DX9, mode, out glVendor, out glRenderer, out glVersion);
						}
					}
				}
				else
				{
					glRenderMode = 2;
					num = BlueStacksGL.GLCheckInstallation(GLRenderer.DX9, mode, out glVendor, out glRenderer, out glVersion);
				}
				if (num != 0)
				{
					Logger.Info("DirectX not supported.");
					glRenderMode = -1;
					return false;
				}
				return true;
			}
			catch (Exception ex)
			{
				Logger.Error("Some error occured while checking for GL. Ex: {0}", new object[]
				{
					ex
				});
			}
			return false;
		}

		// Token: 0x060003E8 RID: 1000 RVA: 0x000195C8 File Offset: 0x000177C8
		public static bool GpuWithDx9SupportOnly()
		{
			string[] array = new string[]
			{
				"Mobile Intel(R) 4 Series Express Chipset Family",
				"Mobile Intel(R) 45 Express Chipset Family",
				"Mobile Intel(R) 965 Express Chipset Family",
				"Intel(R) G41 Express Chipset",
				"Intel(R) G45/G43 Express Chipset",
				"Intel(R) Q45/Q43 Express Chipset"
			};
			string text = "";
			try
			{
				foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher("SELECT * FROM Win32_DisplayConfiguration").Get())
				{
					foreach (PropertyData propertyData in ((ManagementObject)managementBaseObject).Properties)
					{
						if (propertyData.Name == "Description")
						{
							text = propertyData.Value.ToString();
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while runninq query. Error: ", new object[]
				{
					ex.ToString()
				});
			}
			Logger.Info("Graphics card: {0}", new object[]
			{
				text
			});
			string text2 = text.ToLower();
			if (text2.Contains("intel") && text2.Contains("express chipset"))
			{
				Logger.Info("graphicsCard : {0} part of the list of graphics card to be forced to dx9", new object[]
				{
					text
				});
				return true;
			}
			return false;
		}

		// Token: 0x040003B4 RID: 948
		private const string OpenGL_Native_DLL = "HD-OpenGl-Native.dll";

		// Token: 0x040003B5 RID: 949
		private const int CSIDL_COMMON_DESKTOPDIRECTORY = 25;

		// Token: 0x040003B6 RID: 950
		private const int CSIDL_COMMON_STARTMENU = 22;

		// Token: 0x040003B7 RID: 951
		internal static List<string> sDisallowedDeletionStrings = new List<string>
		{
			"*",
			"\\",
			Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
			Environment.GetFolderPath(Environment.SpecialFolder.CommonProgramFiles),
			Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData)
		};

		// Token: 0x040003B8 RID: 952
		private static bool is64BitProcess = IntPtr.Size == 8;

		// Token: 0x040003B9 RID: 953
		internal static bool is64BitOperatingSystem = CommonInstallUtils.is64BitProcess || CommonInstallUtils.InternalCheckIsWow64();
	}
}
