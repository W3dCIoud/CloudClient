﻿using System;
using System.Runtime.InteropServices;

namespace BlueStacks.Common
{
	// Token: 0x02000064 RID: 100
	public class MemoryMappedFile
	{
		// Token: 0x06000224 RID: 548
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern IntPtr OpenFileMapping(uint dwDesiredAccess, bool bInheritHandle, string lpName);

		// Token: 0x06000225 RID: 549
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern IntPtr MapViewOfFile(IntPtr hFileMappingObject, uint dwDesiredAccess, uint dwFileOffsetHigh, uint dwFileOffsetLow, UIntPtr dwNumberOfBytesToMap);

		// Token: 0x06000226 RID: 550
		[DllImport("kernel32.dll", SetLastError = true)]
		[return: MarshalAs(UnmanagedType.Bool)]
		private static extern bool CloseHandle(IntPtr hObject);

		// Token: 0x06000227 RID: 551 RVA: 0x00010260 File Offset: 0x0000E460
		public static int GetNCSoftAgentPort(string SharedMemoryName, uint NumBytes)
		{
			IntPtr intPtr = MemoryMappedFile.OpenFileMapping(983071U, false, SharedMemoryName);
			if (IntPtr.Zero == intPtr)
			{
				Logger.Error("Shared Memory Handle not found. Last Error : " + Marshal.GetLastWin32Error());
				return -1;
			}
			IntPtr intPtr2 = MemoryMappedFile.MapViewOfFile(intPtr, 983071U, 0U, 0U, new UIntPtr(NumBytes));
			if (intPtr2 == IntPtr.Zero)
			{
				Logger.Error("Cannot map view of file. Last Error : " + Marshal.GetLastWin32Error());
				return -1;
			}
			int result = -1;
			try
			{
				result = Marshal.ReadInt32(intPtr2);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to read memory as int32");
				Logger.Error(ex.ToString());
			}
			if (IntPtr.Zero != intPtr)
			{
				MemoryMappedFile.CloseHandle(intPtr);
				intPtr = IntPtr.Zero;
			}
			intPtr2 = IntPtr.Zero;
			return result;
		}

		// Token: 0x04000111 RID: 273
		private const uint STANDARD_RIGHTS_REQUIRED = 983040U;

		// Token: 0x04000112 RID: 274
		private const uint SECTION_QUERY = 1U;

		// Token: 0x04000113 RID: 275
		private const uint SECTION_MAP_WRITE = 2U;

		// Token: 0x04000114 RID: 276
		private const uint SECTION_MAP_READ = 4U;

		// Token: 0x04000115 RID: 277
		private const uint SECTION_MAP_EXECUTE = 8U;

		// Token: 0x04000116 RID: 278
		private const uint SECTION_EXTEND_SIZE = 16U;

		// Token: 0x04000117 RID: 279
		private const uint SECTION_ALL_ACCESS = 983071U;

		// Token: 0x04000118 RID: 280
		private const uint FILE_MAP_ALL_ACCESS = 983071U;
	}
}
