﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x0200005F RID: 95
	internal class JSonTemplates
	{
		// Token: 0x1700008C RID: 140
		// (get) Token: 0x06000205 RID: 517 RVA: 0x0000FBA8 File Offset: 0x0000DDA8
		public static string SuccessArrayJSonTemplate
		{
			get
			{
				if (string.IsNullOrEmpty(JSonTemplates.mSuccessArrayJsonString))
				{
					JSonTemplates.mSuccessArrayJsonString = new JArray
					{
						new JObject
						{
							{
								"success",
								true
							},
							{
								"reason",
								""
							}
						}
					}.ToString(Formatting.None, new JsonConverter[0]);
				}
				return JSonTemplates.mSuccessArrayJsonString;
			}
		}

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x06000206 RID: 518 RVA: 0x0000FC10 File Offset: 0x0000DE10
		public static string FailedArrayJSonTemplate
		{
			get
			{
				if (string.IsNullOrEmpty(JSonTemplates.mFailedArrayJsonString))
				{
					JSonTemplates.mFailedArrayJsonString = new JArray
					{
						new JObject
						{
							{
								"success",
								false
							},
							{
								"reason",
								""
							}
						}
					}.ToString(Formatting.None, new JsonConverter[0]);
				}
				return JSonTemplates.mFailedArrayJsonString;
			}
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x06000207 RID: 519 RVA: 0x0000FC78 File Offset: 0x0000DE78
		public static string SuccessJSonTemplate
		{
			get
			{
				if (string.IsNullOrEmpty(JSonTemplates.mSuccessJsonString))
				{
					JSonTemplates.mSuccessJsonString = new JObject
					{
						{
							"success",
							true
						},
						{
							"reason",
							""
						}
					}.ToString(Formatting.None, new JsonConverter[0]);
				}
				return JSonTemplates.mSuccessJsonString;
			}
		}

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x06000208 RID: 520 RVA: 0x0000FCD4 File Offset: 0x0000DED4
		public static string FailedJSonTemplate
		{
			get
			{
				if (string.IsNullOrEmpty(JSonTemplates.mFailedJsonString))
				{
					JSonTemplates.mFailedJsonString = new JObject
					{
						{
							"success",
							false
						},
						{
							"reason",
							""
						}
					}.ToString(Formatting.None, new JsonConverter[0]);
				}
				return JSonTemplates.mFailedJsonString;
			}
		}

		// Token: 0x040000FF RID: 255
		private static string mSuccessArrayJsonString = string.Empty;

		// Token: 0x04000100 RID: 256
		private static string mFailedArrayJsonString = string.Empty;

		// Token: 0x04000101 RID: 257
		private static string mSuccessJsonString = string.Empty;

		// Token: 0x04000102 RID: 258
		private static string mFailedJsonString = string.Empty;
	}
}
