﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000C8 RID: 200
	public enum NotificationPayloadType
	{
		// Token: 0x040004F1 RID: 1265
		Generic,
		// Token: 0x040004F2 RID: 1266
		Pika
	}
}
