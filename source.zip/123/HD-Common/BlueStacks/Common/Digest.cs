﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000187 RID: 391
	public class Digest
	{
		// Token: 0x06000C6D RID: 3181 RVA: 0x0000B31A File Offset: 0x0000951A
		public Digest()
		{
			this.A = 1732584193U;
			this.B = 4023233417U;
			this.C = 2562383102U;
			this.D = 271733878U;
		}

		// Token: 0x06000C6E RID: 3182 RVA: 0x00034B54 File Offset: 0x00032D54
		public string GetString()
		{
			return this.ReverseByte(this.A).ToString("X8") + this.ReverseByte(this.B).ToString("X8") + this.ReverseByte(this.C).ToString("X8") + this.ReverseByte(this.D).ToString("X8");
		}

		// Token: 0x06000C6F RID: 3183 RVA: 0x0000B34E File Offset: 0x0000954E
		private uint ReverseByte(uint uiNumber)
		{
			return (uiNumber & 255U) << 24 | uiNumber >> 24 | (uiNumber & 16711680U) >> 8 | (uiNumber & 65280U) << 8;
		}

		// Token: 0x040009B1 RID: 2481
		public uint A;

		// Token: 0x040009B2 RID: 2482
		public uint B;

		// Token: 0x040009B3 RID: 2483
		public uint C;

		// Token: 0x040009B4 RID: 2484
		public uint D;
	}
}
