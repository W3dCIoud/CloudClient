﻿using System;
using System.IO;
using Microsoft.Win32;

namespace BlueStacks.Common
{
	// Token: 0x020000E3 RID: 227
	public class MonitorLocator
	{
		// Token: 0x0600067E RID: 1662 RVA: 0x00006961 File Offset: 0x00004B61
		static MonitorLocator()
		{
			MonitorLocator.REG_PATH = Path.Combine(RegistryManager.Instance.BaseKeyPath, "Monitors");
		}

		// Token: 0x0600067F RID: 1663 RVA: 0x0001F890 File Offset: 0x0001DA90
		public static void Publish(string vmName, uint vmId)
		{
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(MonitorLocator.REG_PATH, true);
			foreach (string name in registryKey.GetValueNames())
			{
				if (registryKey.GetValueKind(name) != RegistryValueKind.DWord)
				{
					registryKey.DeleteValue(name);
				}
				else
				{
					uint num = (uint)((int)registryKey.GetValue(name, 0));
					if (vmId == num)
					{
						registryKey.DeleteValue(name);
					}
				}
			}
			registryKey.SetValue(vmName, vmId, RegistryValueKind.DWord);
		}

		// Token: 0x06000680 RID: 1664 RVA: 0x00006986 File Offset: 0x00004B86
		public static string[] Fetch()
		{
			return Registry.LocalMachine.OpenSubKey(MonitorLocator.REG_PATH, true).GetValueNames();
		}

		// Token: 0x06000681 RID: 1665 RVA: 0x0000699D File Offset: 0x00004B9D
		public static uint Lookup(string vmName)
		{
			return (uint)((int)Registry.LocalMachine.OpenSubKey(MonitorLocator.REG_PATH).GetValue(vmName, 0));
		}

		// Token: 0x04000590 RID: 1424
		private static string REG_PATH = string.Empty;
	}
}
