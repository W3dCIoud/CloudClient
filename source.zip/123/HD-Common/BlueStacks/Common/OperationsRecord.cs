﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000072 RID: 114
	public class OperationsRecord
	{
		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x0600027F RID: 639 RVA: 0x000034C9 File Offset: 0x000016C9
		// (set) Token: 0x06000280 RID: 640 RVA: 0x000034D1 File Offset: 0x000016D1
		public string TimeCreated
		{
			get
			{
				return this.mTimeCreated;
			}
			set
			{
				this.mTimeCreated = value;
			}
		}

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x06000281 RID: 641 RVA: 0x000034DA File Offset: 0x000016DA
		// (set) Token: 0x06000282 RID: 642 RVA: 0x000034E2 File Offset: 0x000016E2
		public string Name
		{
			get
			{
				return this.mName;
			}
			set
			{
				this.mName = value;
			}
		}

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x06000283 RID: 643 RVA: 0x000034EB File Offset: 0x000016EB
		// (set) Token: 0x06000284 RID: 644 RVA: 0x000034F3 File Offset: 0x000016F3
		public string FileName
		{
			get
			{
				return this.mFileName;
			}
			set
			{
				this.mFileName = value;
			}
		}

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x06000285 RID: 645 RVA: 0x000034FC File Offset: 0x000016FC
		// (set) Token: 0x06000286 RID: 646 RVA: 0x00003504 File Offset: 0x00001704
		public object Events
		{
			get
			{
				return this.mEvents;
			}
			set
			{
				this.mEvents = value;
			}
		}

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x06000287 RID: 647 RVA: 0x0000350D File Offset: 0x0000170D
		// (set) Token: 0x06000288 RID: 648 RVA: 0x00003515 File Offset: 0x00001715
		public OperationsLoopType LoopType
		{
			get
			{
				return this.mLoopType;
			}
			set
			{
				this.mLoopType = value;
			}
		}

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x06000289 RID: 649 RVA: 0x0000351E File Offset: 0x0000171E
		// (set) Token: 0x0600028A RID: 650 RVA: 0x00003526 File Offset: 0x00001726
		public int LoopNumber
		{
			get
			{
				return this.mLoopNumber;
			}
			set
			{
				this.mLoopNumber = value;
			}
		}

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x0600028B RID: 651 RVA: 0x0000352F File Offset: 0x0000172F
		// (set) Token: 0x0600028C RID: 652 RVA: 0x00003537 File Offset: 0x00001737
		public int LoopTime
		{
			get
			{
				return this.mLoopTime;
			}
			set
			{
				this.mLoopTime = value;
			}
		}

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x0600028D RID: 653 RVA: 0x00003540 File Offset: 0x00001740
		// (set) Token: 0x0600028E RID: 654 RVA: 0x00003548 File Offset: 0x00001748
		public int LoopInterval
		{
			get
			{
				return this.mLoopInterval;
			}
			set
			{
				this.mLoopInterval = value;
			}
		}

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x0600028F RID: 655 RVA: 0x00003551 File Offset: 0x00001751
		// (set) Token: 0x06000290 RID: 656 RVA: 0x00003559 File Offset: 0x00001759
		public double Acceleration
		{
			get
			{
				return this.mAcceleration;
			}
			set
			{
				this.mAcceleration = value;
			}
		}

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x06000291 RID: 657 RVA: 0x00003562 File Offset: 0x00001762
		// (set) Token: 0x06000292 RID: 658 RVA: 0x0000356A File Offset: 0x0000176A
		public bool PlayOnStart
		{
			get
			{
				return this.mPlayOnStart;
			}
			set
			{
				this.mPlayOnStart = value;
			}
		}

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x06000293 RID: 659 RVA: 0x00003573 File Offset: 0x00001773
		// (set) Token: 0x06000294 RID: 660 RVA: 0x0000357B File Offset: 0x0000177B
		public bool RestartPlayer
		{
			get
			{
				return this.mRestartPlayer;
			}
			set
			{
				this.mRestartPlayer = value;
			}
		}

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x06000295 RID: 661 RVA: 0x00003584 File Offset: 0x00001784
		// (set) Token: 0x06000296 RID: 662 RVA: 0x0000358C File Offset: 0x0000178C
		public int RestartPlayerAfterMinutes
		{
			get
			{
				return this.mRestartPlayerAfterMinutes;
			}
			set
			{
				this.mRestartPlayerAfterMinutes = value;
			}
		}

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x06000297 RID: 663 RVA: 0x00003595 File Offset: 0x00001795
		// (set) Token: 0x06000298 RID: 664 RVA: 0x0000359D File Offset: 0x0000179D
		public string ShortCut
		{
			get
			{
				return this.mShortcut;
			}
			set
			{
				this.mShortcut = value;
			}
		}

		// Token: 0x04000175 RID: 373
		private string mTimeCreated;

		// Token: 0x04000176 RID: 374
		private string mName = string.Empty;

		// Token: 0x04000177 RID: 375
		private string mFileName = string.Empty;

		// Token: 0x04000178 RID: 376
		private object mEvents;

		// Token: 0x04000179 RID: 377
		private OperationsLoopType mLoopType;

		// Token: 0x0400017A RID: 378
		private int mLoopNumber = 1;

		// Token: 0x0400017B RID: 379
		private int mLoopTime;

		// Token: 0x0400017C RID: 380
		private int mLoopInterval;

		// Token: 0x0400017D RID: 381
		private double mAcceleration = 1.0;

		// Token: 0x0400017E RID: 382
		private bool mPlayOnStart;

		// Token: 0x0400017F RID: 383
		private bool mRestartPlayer;

		// Token: 0x04000180 RID: 384
		private int mRestartPlayerAfterMinutes = 60;

		// Token: 0x04000181 RID: 385
		private string mShortcut = string.Empty;
	}
}
