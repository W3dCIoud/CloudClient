﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace BlueStacks.Common
{
	// Token: 0x020000E6 RID: 230
	public static class RegistrySymlinkUtils
	{
		// Token: 0x06000825 RID: 2085
		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool IsWow64Process(IntPtr proc, ref bool isWow);

		// Token: 0x06000826 RID: 2086
		[DllImport("advapi32.dll", SetLastError = true)]
		private static extern int RegOpenKeyEx(IntPtr hKey, string lpSubKey, uint ulOptions, uint samDesired, ref IntPtr phkResult);

		// Token: 0x06000827 RID: 2087
		[DllImport("advapi32.dll", SetLastError = true)]
		private static extern int RegCreateKeyEx(IntPtr hKey, string lpSubKey, uint Reserved, string lpClass, uint dwOptions, uint samDesired, IntPtr lpSecurityAttributes, ref IntPtr phkResult, ref uint lpdwDisposition);

		// Token: 0x06000828 RID: 2088
		[DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
		private static extern int RegSetValueEx(IntPtr hKey, string lpValueName, uint Reserved, uint dwType, string lpData, int cbData);

		// Token: 0x06000829 RID: 2089
		[DllImport("ntdll.dll", SetLastError = true)]
		private static extern int ZwDeleteKey(IntPtr hKey);

		// Token: 0x0600082A RID: 2090
		[DllImport("advapi32.dll", SetLastError = true)]
		private static extern int RegDeleteValue(IntPtr hKey, string lpValueName);

		// Token: 0x0600082B RID: 2091
		[DllImport("advapi32.dll", SetLastError = true)]
		private static extern int RegCloseKey(IntPtr hKey);

		// Token: 0x0600082C RID: 2092 RVA: 0x00020550 File Offset: 0x0001E750
		public static bool SymlinkCreator()
		{
			if (RegistrySymlinkUtils.IsOs64Bit())
			{
				try
				{
					RegistrySymlinkUtils.RemoveRegistrySymlink();
				}
				catch (Exception)
				{
				}
				RegistrySymlinkUtils.CreateRegistrySymlink();
			}
			return true;
		}

		// Token: 0x0600082D RID: 2093 RVA: 0x000092AA File Offset: 0x000074AA
		public static bool IsOs64Bit()
		{
			return IntPtr.Size == 8 || (IntPtr.Size == 4 && RegistrySymlinkUtils.Is32BitProcessOn64BitProcessor());
		}

		// Token: 0x0600082E RID: 2094 RVA: 0x00020584 File Offset: 0x0001E784
		private static bool Is32BitProcessOn64BitProcessor()
		{
			bool result = false;
			RegistrySymlinkUtils.IsWow64Process(Process.GetCurrentProcess().Handle, ref result);
			return result;
		}

		// Token: 0x0600082F RID: 2095 RVA: 0x000205A8 File Offset: 0x0001E7A8
		public static void CreateRegistrySymlink()
		{
			IntPtr hKey = (IntPtr)(-2147483646);
			IntPtr zero = IntPtr.Zero;
			IntPtr zero2 = IntPtr.Zero;
			uint num = 0U;
			int num2 = RegistrySymlinkUtils.RegOpenKeyEx(hKey, "Software", 0U, 983359U, ref zero);
			if (num2 != 0)
			{
				throw new ApplicationException("Cannot open 64-bit HKLM\\Software", new Win32Exception(num2));
			}
			try
			{
				num2 = RegistrySymlinkUtils.RegCreateKeyEx(zero, "BlueStacks" + Strings.GetOemTag(), 0U, null, 2U, 983359U, IntPtr.Zero, ref zero2, ref num);
				if (num2 != 0)
				{
					throw new ApplicationException("Cannot create 64-bit registry", new Win32Exception(num2));
				}
				string text = "\\Registry\\Machine\\Software\\Wow6432Node\\BlueStacks" + Strings.GetOemTag();
				num2 = RegistrySymlinkUtils.RegSetValueEx(zero2, "SymbolicLinkValue", 0U, 6U, text, text.Length * 2);
				if (num2 != 0)
				{
					throw new ApplicationException("Cannot set registry symlink value for target" + text, new Win32Exception(num2));
				}
			}
			finally
			{
				RegistrySymlinkUtils.RegCloseKey(zero);
				if (zero2 != IntPtr.Zero)
				{
					RegistrySymlinkUtils.RegCloseKey(zero2);
				}
			}
		}

		// Token: 0x06000830 RID: 2096 RVA: 0x000206A4 File Offset: 0x0001E8A4
		public static void RemoveRegistrySymlink()
		{
			IntPtr hKey = (IntPtr)(-2147483646);
			IntPtr zero = IntPtr.Zero;
			IntPtr zero2 = IntPtr.Zero;
			int num = RegistrySymlinkUtils.RegOpenKeyEx(hKey, "Software", 0U, 983359U, ref zero);
			if (num != 0)
			{
				throw new ApplicationException("Cannot open 64-bit HKLM\\Software", new Win32Exception(num));
			}
			try
			{
				num = RegistrySymlinkUtils.RegOpenKeyEx(zero, "BlueStacks" + Strings.GetOemTag(), 8U, 983359U, ref zero2);
				if (num != 0)
				{
					throw new ApplicationException("Cannot open 64-bit registry", new Win32Exception(num));
				}
				num = RegistrySymlinkUtils.RegDeleteValue(zero2, "SymbolicLinkValue");
				num = RegistrySymlinkUtils.ZwDeleteKey(zero2);
			}
			finally
			{
				RegistrySymlinkUtils.RegCloseKey(zero);
				if (zero2 != IntPtr.Zero)
				{
					RegistrySymlinkUtils.RegCloseKey(zero2);
				}
			}
		}

		// Token: 0x06000831 RID: 2097 RVA: 0x00020764 File Offset: 0x0001E964
		public static bool IsSymlinkPresent()
		{
			if (RegistrySymlinkUtils.IsOs64Bit())
			{
				try
				{
					IntPtr hKey = (IntPtr)(-2147483646);
					IntPtr zero = IntPtr.Zero;
					int num = RegistrySymlinkUtils.RegOpenKeyEx(hKey, "Software", 0U, 257U, ref zero);
					if (num != 0)
					{
						throw new ApplicationException("Cannot open 64-bit HKLM\\Software: 0x" + num.ToString("x"));
					}
					num = RegistrySymlinkUtils.RegOpenKeyEx(zero, "BlueStacks" + Strings.GetOemTag(), 8U, 257U, ref zero);
					if (num != 0)
					{
						throw new ApplicationException("Cannot open 64-bit registry: 0x" + num.ToString("x"));
					}
					return true;
				}
				catch (Exception ex)
				{
					Logger.Warning("Some error while detecting symlink. Ex: {0}", new object[]
					{
						ex.Message
					});
					return false;
				}
				return false;
			}
			return false;
		}

		// Token: 0x040005E1 RID: 1505
		private const uint REG_LINK = 6U;

		// Token: 0x040005E2 RID: 1506
		private const uint HKEY_LOCAL_MACHINE = 2147483650U;

		// Token: 0x040005E3 RID: 1507
		private const uint REG_OPTION_CREATE_LINK = 2U;

		// Token: 0x040005E4 RID: 1508
		private const uint REG_OPTION_OPEN_LINK = 8U;

		// Token: 0x040005E5 RID: 1509
		private const uint KEY_ALL_ACCESS = 983103U;

		// Token: 0x040005E6 RID: 1510
		private const uint KEY_WOW64_64KEY = 256U;

		// Token: 0x040005E7 RID: 1511
		private const uint KEY_QUERY_VALUE = 1U;
	}
}
