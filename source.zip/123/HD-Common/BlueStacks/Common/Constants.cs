﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200009A RID: 154
	public class Constants
	{
		// Token: 0x04000374 RID: 884
		public const string MacroPostFix = "_macro";

		// Token: 0x04000375 RID: 885
		public const string dateFormat = "yyyy-MM-dd HH:mm";

		// Token: 0x04000376 RID: 886
		public static Version win8version = new Version(6, 2, 9200, 0);

		// Token: 0x04000377 RID: 887
		public const int IDENTITY_OFFSET = 16;

		// Token: 0x04000378 RID: 888
		public const int GUEST_ABS_MAX_X = 32768;

		// Token: 0x04000379 RID: 889
		public const int GUEST_ABS_MAX_Y = 32768;

		// Token: 0x0400037A RID: 890
		public const int MaxAllowedCPUCores = 8;

		// Token: 0x0400037B RID: 891
		public const int TOUCH_POINTS_MAX = 16;

		// Token: 0x0400037C RID: 892
		public const int SWIPE_TOUCH_POINTS_MAX = 1;

		// Token: 0x0400037D RID: 893
		public const long LWIN_TIMEOUT_TICKS = 1000000L;

		// Token: 0x0400037E RID: 894
		public const int CURSOR_HIDE_CLIP_LEN = 15;

		// Token: 0x0400037F RID: 895
		public static string ImapLocaleStringsConstant = "IMAP_STRING_";

		// Token: 0x04000380 RID: 896
		public const string ImapDependent = "Dependent";

		// Token: 0x04000381 RID: 897
		public const string ImapIndependent = "Independent";

		// Token: 0x04000382 RID: 898
		public const string ImapSubElement = "SubElement";

		// Token: 0x04000383 RID: 899
		public const string ImapParentElement = "ParentElement";

		// Token: 0x04000384 RID: 900
		public const string ImapNotCommon = "NotCommon";

		// Token: 0x04000385 RID: 901
		public const string ImapLinked = "Linked";

		// Token: 0x04000386 RID: 902
		public const string ImapCanvasElementY = "IMAP_CanvasElementX";

		// Token: 0x04000387 RID: 903
		public const string ImapCanvasElementX = "IMAP_CanvasElementY";

		// Token: 0x04000388 RID: 904
		public const string ImapCanvasElementRadius = "IMAP_CanvasElementRadius";

		// Token: 0x04000389 RID: 905
		public const string IMAPPopupUIElement = "IMAP_PopupUIElement";

		// Token: 0x0400038A RID: 906
		public const string IMAPKeypropertyPrefix = "Key";

		// Token: 0x0400038B RID: 907
		public const string IMAPUserDefined = "User-Defined";

		// Token: 0x0400038C RID: 908
		public const string ImapVideoHeaderConstant = "AAVideo";

		// Token: 0x0400038D RID: 909
		public const string ImapMiscHeaderConstant = "MISC";

		// Token: 0x0400038E RID: 910
		public const string ImapGlobalValid = "GlobalValidTag";

		// Token: 0x0400038F RID: 911
		public const string ImapDeveloperModeUIElemnt = "IMAP_DeveloperModeUIElemnt";

		// Token: 0x04000390 RID: 912
		public static string[] ImapGamepadEvents = new string[]
		{
			"GamepadDpadUp",
			"GamepadDpadDown",
			"GamepadDpadLeft",
			"GamepadDpadRight",
			"GamepadStart",
			"GamepadStop",
			"GamepadLeftThumb",
			"GamepadRightThumb",
			"GamepadLeftShoulder",
			"GamepadRightShoulder",
			"GamepadA",
			"GamepadB",
			"GamepadX",
			"GamepadY",
			"GamepadLStickUp",
			"GamepadLStickDown",
			"GamepadLStickLeft",
			"GamepadLStickRight",
			"GamepadRtickUp",
			"GamepadRStickDown",
			"GamepadRStickLeft",
			"GamepadRStickRight",
			"GamepadLTrigger",
			"GamepadRTrigger"
		};

		// Token: 0x04000391 RID: 913
		public static string[] ImapShootingModeAppsList = new string[]
		{
			"com.dts.freefireth",
			"com.netease.mrzhna",
			"com.tencent.ig",
			"com.titan.cd.gb",
			"com.critical.strike2",
			"com.gameloft.android.ANMP.GloftM5HM",
			"com.axlebolt.standoff2",
			"com.netease.chiji",
			"com.netease.ko",
			"com.tencent.tmgp.kr.codm",
			"com.garena.game.codm",
			"com.activision.callofduty.shooter"
		};
	}
}
