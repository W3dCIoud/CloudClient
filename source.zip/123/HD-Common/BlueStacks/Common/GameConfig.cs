﻿using System;
using System.IO;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x02000063 RID: 99
	public class GameConfig
	{
		// Token: 0x17000090 RID: 144
		// (get) Token: 0x06000216 RID: 534 RVA: 0x00010020 File Offset: 0x0000E220
		public static GameConfig Instance
		{
			get
			{
				if (GameConfig.sInstance == null)
				{
					object obj = GameConfig.syncRoot;
					lock (obj)
					{
						GameConfig.sInstance = new GameConfig();
						GameConfig.Init();
					}
				}
				return GameConfig.sInstance;
			}
		}

		// Token: 0x06000217 RID: 535 RVA: 0x00010074 File Offset: 0x0000E274
		private static void Init()
		{
			GameConfig.sFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "game_config.json");
			if (File.Exists(GameConfig.sFilePath))
			{
				Logger.Info("Loading cfg from : " + GameConfig.sFilePath);
				GameConfig.LoadFile(GameConfig.sFilePath);
			}
		}

		// Token: 0x06000218 RID: 536 RVA: 0x000100C4 File Offset: 0x0000E2C4
		private static void LoadFile(string sFilePath)
		{
			try
			{
				JObject obj = JObject.Parse(File.ReadAllText(sFilePath));
				GameConfig.Instance.mAppName = GameConfig.GetJsonStringValue(obj, "app_name");
				GameConfig.Instance.mPkgName = GameConfig.GetJsonStringValue(obj, "pkg_name");
				GameConfig.Instance.mActivityName = GameConfig.GetJsonStringValue(obj, "activity_name");
				GameConfig.Instance.mControlPanelEntryName = GameConfig.GetJsonStringValue(obj, "control_panel_name");
				GameConfig.Instance.mControlPanelPublisher = GameConfig.GetJsonStringValue(obj, "control_panel_publisher");
				GameConfig.Instance.mInstallerCopyrightText = GameConfig.GetJsonStringValue(obj, "installer_copyright");
				GameConfig.Instance.mAppGenericAction = (GenericAction)Enum.Parse(typeof(GenericAction), GameConfig.GetJsonStringValue(obj, "app_generic_action"));
				GameConfig.Instance.mAppCDNURL = GameConfig.GetJsonStringValue(obj, "app_cdn_url");
			}
			catch (Exception ex)
			{
				Logger.Error("Some error while parsing config, maybe an invalid file. Ex: {0}", new object[]
				{
					ex.Message
				});
			}
		}

		// Token: 0x06000219 RID: 537 RVA: 0x000101C8 File Offset: 0x0000E3C8
		private static string GetJsonStringValue(JObject obj, string keyName)
		{
			string empty = string.Empty;
			if (obj.ContainsKey(keyName))
			{
				return obj[keyName].ToString().Trim();
			}
			return empty;
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x0600021A RID: 538 RVA: 0x000030D9 File Offset: 0x000012D9
		public string ControlPanelEntryName
		{
			get
			{
				return this.mControlPanelEntryName;
			}
		}

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x0600021B RID: 539 RVA: 0x000030E1 File Offset: 0x000012E1
		public string ControlPanelPublisher
		{
			get
			{
				return this.mControlPanelPublisher;
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x0600021C RID: 540 RVA: 0x000030E9 File Offset: 0x000012E9
		public string InstallerCopyrightText
		{
			get
			{
				return this.mInstallerCopyrightText;
			}
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x0600021D RID: 541 RVA: 0x000030F1 File Offset: 0x000012F1
		public string AppName
		{
			get
			{
				return this.mAppName;
			}
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x0600021E RID: 542 RVA: 0x000030F9 File Offset: 0x000012F9
		public string PkgName
		{
			get
			{
				return this.mPkgName;
			}
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x0600021F RID: 543 RVA: 0x00003101 File Offset: 0x00001301
		public string ActivityName
		{
			get
			{
				return this.mActivityName;
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x06000220 RID: 544 RVA: 0x00003109 File Offset: 0x00001309
		public GenericAction AppGenericAction
		{
			get
			{
				return this.mAppGenericAction;
			}
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x06000221 RID: 545 RVA: 0x00003111 File Offset: 0x00001311
		public string AppCDNURL
		{
			get
			{
				return this.mAppCDNURL;
			}
		}

		// Token: 0x04000105 RID: 261
		public const string sConfigFilename = "game_config.json";

		// Token: 0x04000106 RID: 262
		private static string sFilePath = string.Empty;

		// Token: 0x04000107 RID: 263
		private static volatile GameConfig sInstance;

		// Token: 0x04000108 RID: 264
		private static object syncRoot = new object();

		// Token: 0x04000109 RID: 265
		private string mControlPanelEntryName = string.Empty;

		// Token: 0x0400010A RID: 266
		private string mControlPanelPublisher = string.Empty;

		// Token: 0x0400010B RID: 267
		private string mInstallerCopyrightText = string.Empty;

		// Token: 0x0400010C RID: 268
		private string mAppName = string.Empty;

		// Token: 0x0400010D RID: 269
		private string mPkgName = string.Empty;

		// Token: 0x0400010E RID: 270
		private string mActivityName = string.Empty;

		// Token: 0x0400010F RID: 271
		private GenericAction mAppGenericAction = GenericAction.InstallPlay;

		// Token: 0x04000110 RID: 272
		private string mAppCDNURL = string.Empty;
	}
}
