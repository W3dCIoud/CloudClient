﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200016C RID: 364
	public enum RegSAM
	{
		// Token: 0x0400082B RID: 2091
		QueryValue = 1,
		// Token: 0x0400082C RID: 2092
		SetValue,
		// Token: 0x0400082D RID: 2093
		CreateSubKey = 4,
		// Token: 0x0400082E RID: 2094
		EnumerateSubKeys = 8,
		// Token: 0x0400082F RID: 2095
		Notify = 16,
		// Token: 0x04000830 RID: 2096
		CreateLink = 32,
		// Token: 0x04000831 RID: 2097
		WOW64_32Key = 512,
		// Token: 0x04000832 RID: 2098
		WOW64_64Key = 256,
		// Token: 0x04000833 RID: 2099
		WOW64_Res = 768,
		// Token: 0x04000834 RID: 2100
		Read = 131097,
		// Token: 0x04000835 RID: 2101
		Write = 131078,
		// Token: 0x04000836 RID: 2102
		Execute = 131097,
		// Token: 0x04000837 RID: 2103
		AllAccess = 983103
	}
}
