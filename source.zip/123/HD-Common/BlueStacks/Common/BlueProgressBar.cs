﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x02000090 RID: 144
	public class BlueProgressBar : ProgressBar, IComponentConnector
	{
		// Token: 0x060002E8 RID: 744 RVA: 0x00003965 File Offset: 0x00001B65
		public BlueProgressBar()
		{
			this.InitializeComponent();
		}

		// Token: 0x060002E9 RID: 745 RVA: 0x0001257C File Offset: 0x0001077C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/blueprogressbar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060002EA RID: 746 RVA: 0x00003973 File Offset: 0x00001B73
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			this._contentLoaded = true;
		}

		// Token: 0x04000359 RID: 857
		private bool _contentLoaded;
	}
}
