﻿using System;
using System.Net;

namespace BlueStacks.Common
{
	// Token: 0x02000057 RID: 87
	public class ExtendedWebClient : WebClient
	{
		// Token: 0x060001E0 RID: 480 RVA: 0x00002F21 File Offset: 0x00001121
		public ExtendedWebClient(int timeout)
		{
			this.mTimeout = timeout;
		}

		// Token: 0x060001E1 RID: 481 RVA: 0x00002F30 File Offset: 0x00001130
		protected override WebRequest GetWebRequest(Uri address)
		{
			WebRequest webRequest = base.GetWebRequest(address);
			webRequest.Timeout = this.mTimeout;
			return webRequest;
		}

		// Token: 0x040000F2 RID: 242
		private int mTimeout;
	}
}
