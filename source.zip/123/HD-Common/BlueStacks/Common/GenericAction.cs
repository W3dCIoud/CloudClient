﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000C7 RID: 199
	public enum GenericAction
	{
		// Token: 0x040004E5 RID: 1253
		InstallPlay = 1,
		// Token: 0x040004E6 RID: 1254
		InstallCDN,
		// Token: 0x040004E7 RID: 1255
		ApplicationBrowser = 4,
		// Token: 0x040004E8 RID: 1256
		UserBrowser = 8,
		// Token: 0x040004E9 RID: 1257
		AppCenter = 16,
		// Token: 0x040004EA RID: 1258
		HomeAppTab = 32,
		// Token: 0x040004EB RID: 1259
		SettingsMenu = 64,
		// Token: 0x040004EC RID: 1260
		KeyBasedPopup = 128,
		// Token: 0x040004ED RID: 1261
		OpenSystemApp = 256,
		// Token: 0x040004EE RID: 1262
		PopupBrowser = 512,
		// Token: 0x040004EF RID: 1263
		None = 65536
	}
}
