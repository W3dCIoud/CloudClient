﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace BlueStacks.Common
{
	// Token: 0x0200010E RID: 270
	public class TextWrapCustomCheckBox : UserControl, IComponentConnector
	{
		// Token: 0x170002B0 RID: 688
		// (get) Token: 0x06000936 RID: 2358 RVA: 0x00009A1B File Offset: 0x00007C1B
		// (set) Token: 0x06000937 RID: 2359 RVA: 0x00009A2D File Offset: 0x00007C2D
		public SolidColorBrush CheckBoxTextBlockForeground
		{
			get
			{
				return (SolidColorBrush)base.GetValue(TextWrapCustomCheckBox.TextBlockForegroundProperty);
			}
			set
			{
				base.SetValue(TextWrapCustomCheckBox.TextBlockForegroundProperty, value);
			}
		}

		// Token: 0x06000938 RID: 2360 RVA: 0x0002666C File Offset: 0x0002486C
		private static void OnForegroundPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			TextWrapCustomCheckBox textWrapCustomCheckBox = d as TextWrapCustomCheckBox;
			if (textWrapCustomCheckBox == null)
			{
				Logger.Debug("custom check box is null");
				return;
			}
			textWrapCustomCheckBox.mCheckBoxContent.Foreground = (e.NewValue as SolidColorBrush);
		}

		// Token: 0x170002B1 RID: 689
		// (get) Token: 0x06000939 RID: 2361 RVA: 0x00009A3B File Offset: 0x00007C3B
		// (set) Token: 0x0600093A RID: 2362 RVA: 0x00009A4D File Offset: 0x00007C4D
		public string CheckBoxTextBlockText
		{
			get
			{
				return (string)base.GetValue(TextWrapCustomCheckBox.TextBlockTextProperty);
			}
			set
			{
				base.SetValue(TextWrapCustomCheckBox.TextBlockTextProperty, value);
			}
		}

		// Token: 0x0600093B RID: 2363 RVA: 0x000266A8 File Offset: 0x000248A8
		private static void OnTextPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			TextWrapCustomCheckBox textWrapCustomCheckBox = d as TextWrapCustomCheckBox;
			if (textWrapCustomCheckBox == null)
			{
				Logger.Debug("custom check box is null");
				return;
			}
			textWrapCustomCheckBox.mCheckBoxContent.Text = (e.NewValue as string);
		}

		// Token: 0x0600093C RID: 2364 RVA: 0x00009A5B File Offset: 0x00007C5B
		public TextWrapCustomCheckBox()
		{
			this.InitializeComponent();
		}

		// Token: 0x170002B2 RID: 690
		// (get) Token: 0x0600093D RID: 2365 RVA: 0x00009A69 File Offset: 0x00007C69
		// (set) Token: 0x0600093E RID: 2366 RVA: 0x00009A71 File Offset: 0x00007C71
		public bool IsChecked
		{
			get
			{
				return this.mIsChecked;
			}
			set
			{
				this.mIsChecked = value;
				this.UpdateImage();
			}
		}

		// Token: 0x170002B3 RID: 691
		// (get) Token: 0x0600093F RID: 2367 RVA: 0x00009A80 File Offset: 0x00007C80
		// (set) Token: 0x06000940 RID: 2368 RVA: 0x00009A88 File Offset: 0x00007C88
		internal CheckBoxType CheckBoxType
		{
			get
			{
				return this.mCheckBoxType;
			}
			set
			{
				this.mCheckBoxType = value;
				this.UpdateImage();
			}
		}

		// Token: 0x06000941 RID: 2369 RVA: 0x000266E4 File Offset: 0x000248E4
		private void UpdateImage()
		{
			string imageName;
			if (this.CheckBoxType == CheckBoxType.White)
			{
				if (this.IsChecked)
				{
					imageName = "checked_white";
				}
				else
				{
					imageName = "unchecked_white";
				}
			}
			else if (this.IsChecked)
			{
				imageName = "checked_gray";
			}
			else
			{
				imageName = "unchecked_gray";
			}
			this.mCheckBoxImage.ImageName = imageName;
		}

		// Token: 0x06000942 RID: 2370 RVA: 0x00009A97 File Offset: 0x00007C97
		private void CustomCheckBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.IsChecked)
			{
				this.IsChecked = false;
				return;
			}
			this.IsChecked = true;
		}

		// Token: 0x06000943 RID: 2371 RVA: 0x0002673C File Offset: 0x0002493C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/textwrapcustomcheckbox.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000944 RID: 2372 RVA: 0x00003339 File Offset: 0x00001539
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000945 RID: 2373 RVA: 0x0002676C File Offset: 0x0002496C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((Grid)target).MouseDown += this.CustomCheckBox_MouseDown;
				return;
			case 2:
				this.mCheckBoxImage = (CustomPictureBox)target;
				return;
			case 3:
				this.mCheckBoxContent = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040006E6 RID: 1766
		private bool mIsChecked;

		// Token: 0x040006E7 RID: 1767
		private CheckBoxType mCheckBoxType;

		// Token: 0x040006E8 RID: 1768
		public static readonly DependencyProperty TextBlockForegroundProperty = DependencyProperty.RegisterAttached("CheckBoxTextBlockForeground", typeof(SolidColorBrush), typeof(TextWrapCustomCheckBox), new PropertyMetadata(Brushes.White, new PropertyChangedCallback(TextWrapCustomCheckBox.OnForegroundPropertyChanged)));

		// Token: 0x040006E9 RID: 1769
		public static readonly DependencyProperty TextBlockTextProperty = DependencyProperty.Register("CheckBoxTextBlockText", typeof(string), typeof(TextWrapCustomCheckBox), new PropertyMetadata("Agree", new PropertyChangedCallback(TextWrapCustomCheckBox.OnTextPropertyChanged)));

		// Token: 0x040006EA RID: 1770
		internal CustomPictureBox mCheckBoxImage;

		// Token: 0x040006EB RID: 1771
		internal TextBlock mCheckBoxContent;

		// Token: 0x040006EC RID: 1772
		private bool _contentLoaded;
	}
}
