﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace BlueStacks.Common
{
	// Token: 0x020000F8 RID: 248
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("000214F9-0000-0000-C000-000000000046")]
	[ComImport]
	public interface IShellLink
	{
		// Token: 0x060008A7 RID: 2215
		void GetPath([MarshalAs(UnmanagedType.LPWStr)] [Out] StringBuilder pszFile, int cchMaxPath, out WIN32_FIND_DATAW pfd, int fFlags);

		// Token: 0x060008A8 RID: 2216
		void GetIDList(out IntPtr ppidl);

		// Token: 0x060008A9 RID: 2217
		void SetIDList(IntPtr pidl);

		// Token: 0x060008AA RID: 2218
		void GetDescription([MarshalAs(UnmanagedType.LPWStr)] [Out] StringBuilder pszName, int cchMaxName);

		// Token: 0x060008AB RID: 2219
		void SetDescription([MarshalAs(UnmanagedType.LPWStr)] string pszName);

		// Token: 0x060008AC RID: 2220
		void GetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] [Out] StringBuilder pszDir, int cchMaxPath);

		// Token: 0x060008AD RID: 2221
		void SetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] string pszDir);

		// Token: 0x060008AE RID: 2222
		void GetArguments([MarshalAs(UnmanagedType.LPWStr)] [Out] StringBuilder pszArgs, int cchMaxPath);

		// Token: 0x060008AF RID: 2223
		void SetArguments([MarshalAs(UnmanagedType.LPWStr)] string pszArgs);

		// Token: 0x060008B0 RID: 2224
		void GetHotkey(out short pwHotkey);

		// Token: 0x060008B1 RID: 2225
		void SetHotkey(short wHotkey);

		// Token: 0x060008B2 RID: 2226
		void GetShowCmd(out int piShowCmd);

		// Token: 0x060008B3 RID: 2227
		void SetShowCmd(int iShowCmd);

		// Token: 0x060008B4 RID: 2228
		void GetIconLocation([MarshalAs(UnmanagedType.LPWStr)] [Out] StringBuilder pszIconPath, int cchIconPath, out int piIcon);

		// Token: 0x060008B5 RID: 2229
		void SetIconLocation([MarshalAs(UnmanagedType.LPWStr)] string pszIconPath, int iIcon);

		// Token: 0x060008B6 RID: 2230
		void SetRelativePath([MarshalAs(UnmanagedType.LPWStr)] string pszPathRel, int dwReserved);

		// Token: 0x060008B7 RID: 2231
		void Resolve(IntPtr hwnd, int fFlags);

		// Token: 0x060008B8 RID: 2232
		void SetPath([MarshalAs(UnmanagedType.LPWStr)] string pszFile);
	}
}
