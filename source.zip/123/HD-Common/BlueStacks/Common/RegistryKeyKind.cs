﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200016D RID: 365
	public enum RegistryKeyKind
	{
		// Token: 0x04000839 RID: 2105
		HKEY_LOCAL_MACHINE,
		// Token: 0x0400083A RID: 2106
		HKEY_CURRENT_USER
	}
}
