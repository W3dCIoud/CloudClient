﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x020000E7 RID: 231
	public class DisplaySettingsBase : System.Windows.Controls.UserControl, IComponentConnector
	{
		// Token: 0x1700029B RID: 667
		// (get) Token: 0x06000832 RID: 2098 RVA: 0x000092C6 File Offset: 0x000074C6
		public CustomButton RestartNowBtn
		{
			get
			{
				return this.mRestartNowBtn;
			}
		}

		// Token: 0x06000833 RID: 2099 RVA: 0x00003337 File Offset: 0x00001537
		protected virtual void RestartNowBtn_Click(object sender, RoutedEventArgs e)
		{
		}

		// Token: 0x06000834 RID: 2100 RVA: 0x00020830 File Offset: 0x0001EA30
		public DisplaySettingsBase()
		{
			this.LoadViewFromUri("/HD-Common;component/UIElements/DisplaySettingsBase.xaml");
			base.Visibility = Visibility.Hidden;
			this.RestartNowBtn.Visibility = Visibility.Hidden;
		}

		// Token: 0x06000835 RID: 2101 RVA: 0x00020928 File Offset: 0x0001EB28
		public void Init()
		{
			this.mOrientation.Items.Clear();
			ComboBoxItem comboBoxItem = new ComboBoxItem();
			comboBoxItem.Content = LocaleStrings.GetLocalizedString("STRING_ORIENTATION_LANDSCAPE", false);
			this.mOrientation.Items.Add(comboBoxItem);
			ComboBoxItem comboBoxItem2 = new ComboBoxItem();
			comboBoxItem2.Content = LocaleStrings.GetLocalizedString("STRING_ORIENTATION_PORTRAIT", false);
			this.mOrientation.Items.Add(comboBoxItem2);
			ComboBoxItem comboBoxItem3 = new ComboBoxItem();
			comboBoxItem3.Content = LocaleStrings.GetLocalizedString("STRING_CUSTOM1", false);
			this.mOrientation.Items.Add(comboBoxItem3);
			this.mResWidth = RegistryManager.Instance.Guest[this.mVmName].GuestWidth;
			this.mResHeight = RegistryManager.Instance.Guest[this.mVmName].GuestHeight;
			this.CustomResX.Text = this.mResWidth.ToString();
			this.CustomResY.Text = this.mResHeight.ToString();
			string text = this.mResWidth.ToString() + " x " + this.mResHeight.ToString();
			int num;
			int num2;
			this.GetWindowWidthAndHeight(out num, out num2);
			if (this.mLandscapeResolutions.Contains(text))
			{
				this.mOrientation.SelectedIndex = 0;
				this.mRadioButtons.Visibility = Visibility.Visible;
				this.mCustomRes.Visibility = Visibility.Collapsed;
				this.Res1.Content = "1280 x 720";
				this.Res2.Content = "1366 x 768";
				this.Res3.Content = "1600 x 768";
				this.Res4.Content = "1920 x 1080";
				string text2 = num + " x " + num2;
				this.DefaultResRadioBtn.Content = LocaleStrings.GetLocalizedString("STRING_SYSTEM_DEFAULT", false) + " (" + text2 + ")";
				if (text == text2)
				{
					this.DefaultResRadioBtn.IsChecked = new bool?(true);
					this.previousResolution = this.DefaultResRadioBtn;
				}
				else if (!(text == "1280 x 720"))
				{
					if (!(text == "1366 x 768"))
					{
						if (!(text == "1600 x 768"))
						{
							if (text == "1920 x 1080")
							{
								this.Res4.IsChecked = new bool?(true);
								this.previousResolution = this.Res4;
							}
						}
						else
						{
							this.Res3.IsChecked = new bool?(true);
							this.previousResolution = this.Res3;
						}
					}
					else
					{
						this.Res2.IsChecked = new bool?(true);
						this.previousResolution = this.Res2;
					}
				}
				else
				{
					this.Res1.IsChecked = new bool?(true);
					this.previousResolution = this.Res1;
				}
			}
			else if (this.mPortraitResolutions.Contains(text))
			{
				this.mOrientation.SelectedIndex = 1;
				this.mRadioButtons.Visibility = Visibility.Visible;
				this.mCustomRes.Visibility = Visibility.Collapsed;
				this.Res1.Content = "1024 x 768";
				this.Res2.Content = "1080 x 1080";
				this.Res3.Content = "1440 x 1080";
				this.Res4.Content = "1920 x 1440";
				string text3 = num2 + " x " + num;
				this.DefaultResRadioBtn.Content = LocaleStrings.GetLocalizedString("STRING_SYSTEM_DEFAULT", false) + " (" + text3 + ")";
				if (text == text3)
				{
					this.DefaultResRadioBtn.IsChecked = new bool?(true);
					this.previousResolution = this.DefaultResRadioBtn;
				}
				else if (!(text == "1024 x 768"))
				{
					if (!(text == "1080 x 1080"))
					{
						if (!(text == "1440 x 1080"))
						{
							if (text == "1920 x 1440")
							{
								this.Res4.IsChecked = new bool?(true);
								this.previousResolution = this.Res4;
							}
						}
						else
						{
							this.Res3.IsChecked = new bool?(true);
							this.previousResolution = this.Res3;
						}
					}
					else
					{
						this.Res2.IsChecked = new bool?(true);
						this.previousResolution = this.Res2;
					}
				}
				else
				{
					this.Res1.IsChecked = new bool?(true);
					this.previousResolution = this.Res1;
				}
			}
			else
			{
				this.mOrientation.SelectedIndex = 2;
				this.mRadioButtons.Visibility = Visibility.Collapsed;
				this.mCustomRes.Visibility = Visibility.Visible;
			}
			if (this.mShouldRestart)
			{
				this.mRestartNowBtn.Visibility = Visibility.Visible;
			}
			this.mCurrentDpi = Utils.GetDpiFromBootParameters(RegistryManager.Instance.Guest[this.mVmName].BootParameters);
			if (!string.IsNullOrEmpty(this.mCurrentDpi))
			{
				if (this.mCurrentDpi == "160")
				{
					this.Dpi160.IsChecked = new bool?(true);
				}
				else if (this.mCurrentDpi == "240")
				{
					this.Dpi240.IsChecked = new bool?(true);
				}
				else
				{
					this.Dpi320.IsChecked = new bool?(true);
				}
			}
			else
			{
				this.Dpi240.IsChecked = new bool?(true);
			}
			this.Dpi160.Content = "400 " + LocaleStrings.GetLocalizedString("STRING_DPI", false);
			this.Dpi240.Content = "440 " + LocaleStrings.GetLocalizedString("STRING_DPI", false);
			this.Dpi320.Content = "480" + LocaleStrings.GetLocalizedString("STRING_DPI", false);
		}

		// Token: 0x06000836 RID: 2102 RVA: 0x00020ED0 File Offset: 0x0001F0D0
		private void Resolution_Checked(object sender, RoutedEventArgs e)
		{
			if (this.DefaultResRadioBtn.IsChecked.Value)
			{
				this.GetWindowWidthAndHeight(out this.mResSelectedWidth, out this.mResSelectedHeight);
				this.CustomResX.IsEnabled = false;
				this.CustomResY.IsEnabled = false;
				this.CustomResX.Text = this.mResSelectedWidth.ToString();
				this.CustomResY.Text = this.mResSelectedHeight.ToString();
				if (this.mOrientation.SelectedIndex == 1)
				{
					int num = this.mResSelectedWidth;
					this.mResSelectedWidth = this.mResSelectedHeight;
					this.mResSelectedHeight = num;
				}
			}
			else
			{
				if (this.CustomResolution.IsChecked.Value)
				{
					this.CustomResX.IsEnabled = true;
					this.CustomResY.IsEnabled = true;
					return;
				}
				this.CustomResX.IsEnabled = false;
				this.CustomResY.IsEnabled = false;
				string[] array = (sender as CustomRadioButton).Content.ToString().Split(new char[]
				{
					'x'
				});
				this.mResSelectedWidth = Convert.ToInt32(array[0]);
				this.mResSelectedHeight = Convert.ToInt32(array[1]);
			}
			if (this.mResSelectedWidth != this.mResWidth && this.mResSelectedHeight != this.mResHeight)
			{
				this.UpdateRestartBtnVisibility(Visibility.Visible);
			}
			else if (this.mCurrentDpi == this.mSelectedDpi)
			{
				this.UpdateRestartBtnVisibility(Visibility.Hidden);
			}
			RegistryManager.Instance.Guest[this.mVmName].GuestWidth = this.mResSelectedWidth;
			RegistryManager.Instance.Guest[this.mVmName].GuestHeight = this.mResSelectedHeight;
		}

		// Token: 0x06000837 RID: 2103 RVA: 0x000092CE File Offset: 0x000074CE
		private void CheckNumeric_PreviewTextInput(object sender, TextCompositionEventArgs e)
		{
			e.Handled = !this.IsTextAllowed(e.Text);
		}

		// Token: 0x06000838 RID: 2104 RVA: 0x000092E5 File Offset: 0x000074E5
		private bool IsTextAllowed(string text)
		{
			return !new Regex("[^0-9.-]+").IsMatch(text);
		}

		// Token: 0x06000839 RID: 2105 RVA: 0x00021080 File Offset: 0x0001F280
		private void CheckNumeric_Pasting(object sender, DataObjectPastingEventArgs e)
		{
			if (e.DataObject.GetDataPresent(typeof(string)))
			{
				string text = (string)e.DataObject.GetData(typeof(string));
				if (!this.IsTextAllowed(text))
				{
					e.CancelCommand();
					return;
				}
			}
			else
			{
				e.CancelCommand();
			}
		}

		// Token: 0x0600083A RID: 2106 RVA: 0x000210D8 File Offset: 0x0001F2D8
		private void Dpi_Checked(object sender, RoutedEventArgs e)
		{
			if (this.Dpi160.IsChecked.Value)
			{
				this.mSelectedDpi = "400";
			}
			else if (this.Dpi240.IsChecked.Value)
			{
				this.mSelectedDpi = "440";
			}
			else if (this.Dpi320.IsChecked.Value)
			{
				this.mSelectedDpi = "480";
			}
			Utils.SetDPIInBootParameters(RegistryManager.Instance.Guest[this.mVmName].BootParameters, this.mSelectedDpi, this.mVmName);
			if (this.mCurrentDpi != this.mSelectedDpi)
			{
				this.UpdateRestartBtnVisibility(Visibility.Visible);
				return;
			}
			if (this.mResSelectedWidth != this.mResWidth && this.mResSelectedHeight != this.mResHeight)
			{
				this.UpdateRestartBtnVisibility(Visibility.Hidden);
			}
		}

		// Token: 0x0600083B RID: 2107 RVA: 0x000211B4 File Offset: 0x0001F3B4
		private void CustomResX_LostFocus(object sender, RoutedEventArgs e)
		{
			try
			{
				this.mResSelectedWidth = Convert.ToInt32(this.CustomResX.Text);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception when correcting custom resolution " + ex.ToString());
				return;
			}
			this.CustomResX.Text = this.mResSelectedWidth.ToString();
			RegistryManager.Instance.Guest[this.mVmName].GuestWidth = this.mResSelectedWidth;
		}

		// Token: 0x0600083C RID: 2108 RVA: 0x00021238 File Offset: 0x0001F438
		private void CustomResY_LostFocus(object sender, RoutedEventArgs e)
		{
			try
			{
				this.mResSelectedHeight = Convert.ToInt32(this.CustomResY.Text);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception when correcting custom resolution " + ex.ToString());
				return;
			}
			this.CustomResY.Text = this.mResSelectedHeight.ToString();
			RegistryManager.Instance.Guest[this.mVmName].GuestHeight = this.mResSelectedHeight;
		}

		// Token: 0x0600083D RID: 2109 RVA: 0x000092FA File Offset: 0x000074FA
		private void UpdateRestartBtnVisibility(Visibility vis)
		{
			if (!base.GetType().Namespace.Equals("BlueStacks.MultiInstanceManager", StringComparison.InvariantCultureIgnoreCase))
			{
				this.mRestartNowBtn.Visibility = vis;
				if (vis == Visibility.Visible)
				{
					this.mShouldRestart = true;
					return;
				}
				this.mShouldRestart = false;
			}
		}

		// Token: 0x0600083E RID: 2110 RVA: 0x000212BC File Offset: 0x0001F4BC
		private void GetWindowWidthAndHeight(out int width, out int height)
		{
			int width2 = Screen.PrimaryScreen.Bounds.Width;
			int height2 = Screen.PrimaryScreen.Bounds.Height;
			if (width2 > 2560 && height2 > 1440)
			{
				width = 2560;
				height = 1440;
				return;
			}
			if (width2 > 1920 && height2 > 1080)
			{
				width = 1920;
				height = 1080;
				return;
			}
			if (width2 > 1600 && height2 > 900)
			{
				width = 1600;
				height = 900;
				return;
			}
			if (width2 > 1280 && height2 > 720)
			{
				width = 1280;
				height = 720;
				return;
			}
			width = 960;
			height = 540;
		}

		// Token: 0x0600083F RID: 2111 RVA: 0x0002137C File Offset: 0x0001F57C
		private void Orientation_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			int num;
			int num2;
			this.GetWindowWidthAndHeight(out num, out num2);
			string text = this.mResWidth.ToString() + " x " + this.mResHeight.ToString();
			if (this.mOrientation.SelectedIndex == 0)
			{
				this.mRadioButtons.Visibility = Visibility.Visible;
				this.mCustomRes.Visibility = Visibility.Collapsed;
				this.Res1.Content = "1280 x 720";
				this.Res2.Content = "1366 x 768";
				this.Res3.Content = "1600 x 768";
				this.Res4.Content = "1920 x 1080";
				string str = num + " x " + num2;
				this.DefaultResRadioBtn.Content = LocaleStrings.GetLocalizedString("STRING_SYSTEM_DEFAULT", false) + " (" + str + ")";
				if (!this.mLandscapeResolutions.Contains(text))
				{
					this.DefaultResRadioBtn.IsChecked = new bool?(false);
					this.DefaultResRadioBtn.IsChecked = new bool?(true);
					this.previousResolution = this.DefaultResRadioBtn;
					this.UpdateRestartBtnVisibility(Visibility.Visible);
					return;
				}
				if (text == "1280 x 720")
				{
					this.Res1.IsChecked = new bool?(true);
					this.previousResolution = this.Res1;
					return;
				}
				if (text == "1366 x 768")
				{
					this.Res2.IsChecked = new bool?(true);
					this.previousResolution = this.Res2;
					return;
				}
				if (text == "1600 x 900")
				{
					this.Res3.IsChecked = new bool?(true);
					this.previousResolution = this.Res3;
					return;
				}
				if (!(text == "1920 x 1080"))
				{
					return;
				}
				this.Res4.IsChecked = new bool?(true);
				this.previousResolution = this.Res4;
				return;
			}
			else
			{
				if (this.mOrientation.SelectedIndex != 1)
				{
					this.mRadioButtons.Visibility = Visibility.Collapsed;
					this.mCustomRes.Visibility = Visibility.Visible;
					this.CustomResX.IsEnabled = true;
					this.CustomResY.IsEnabled = true;
					if (this.mLandscapeResolutions.Contains(text) || this.mLandscapeResolutions.Contains(text))
					{
						this.UpdateRestartBtnVisibility(Visibility.Visible);
					}
					return;
				}
				this.mRadioButtons.Visibility = Visibility.Visible;
				this.mCustomRes.Visibility = Visibility.Collapsed;
				this.Res1.Content = "1024 x 768";
				this.Res2.Content = "1080 x 1080";
				this.Res3.Content = "1440 x 1080";
				this.Res4.Content = "1920 x 1440";
				string str2 = num2 + " x " + num;
				this.DefaultResRadioBtn.Content = LocaleStrings.GetLocalizedString("STRING_SYSTEM_DEFAULT", false) + " (" + str2 + ")";
				if (!this.mPortraitResolutions.Contains(text))
				{
					this.DefaultResRadioBtn.IsChecked = new bool?(false);
					this.DefaultResRadioBtn.IsChecked = new bool?(true);
					this.previousResolution = this.DefaultResRadioBtn;
					this.UpdateRestartBtnVisibility(Visibility.Visible);
					return;
				}
				if (text == "1024 x 768")
				{
					this.Res1.IsChecked = new bool?(true);
					this.previousResolution = this.Res1;
					return;
				}
				if (text == "1080 x 1080")
				{
					this.Res2.IsChecked = new bool?(true);
					this.previousResolution = this.Res2;
					return;
				}
				if (text == "1440 x 1080")
				{
					this.Res3.IsChecked = new bool?(true);
					this.previousResolution = this.Res3;
					return;
				}
				if (!(text == "1920 x 1440"))
				{
					return;
				}
				this.Res4.IsChecked = new bool?(true);
				this.previousResolution = this.Res4;
				return;
			}
		}

		// Token: 0x06000840 RID: 2112 RVA: 0x00021734 File Offset: 0x0001F934
		private void CustomRes_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			try
			{
				this.mResSelectedWidth = Convert.ToInt32(this.CustomResX.Text);
				this.mResSelectedHeight = Convert.ToInt32(this.CustomResY.Text);
				RegistryManager.Instance.Guest[this.mVmName].GuestWidth = this.mResSelectedWidth;
				RegistryManager.Instance.Guest[this.mVmName].GuestHeight = this.mResSelectedHeight;
				if (this.mResSelectedWidth != this.mResWidth || this.mResSelectedHeight != this.mResHeight)
				{
					this.UpdateRestartBtnVisibility(Visibility.Visible);
				}
				else if (this.mCurrentDpi == this.mSelectedDpi)
				{
					this.UpdateRestartBtnVisibility(Visibility.Hidden);
				}
			}
			catch (Exception arg)
			{
				Logger.Error("Error in parsing textbox content" + arg);
			}
		}

		// Token: 0x06000841 RID: 2113 RVA: 0x00021814 File Offset: 0x0001FA14
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/displaysettingsbase.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000842 RID: 2114 RVA: 0x00003339 File Offset: 0x00001539
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000843 RID: 2115 RVA: 0x00021844 File Offset: 0x0001FA44
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mOrientation = (CustomComboBox)target;
				return;
			case 2:
				this.mRadioButtons = (Grid)target;
				return;
			case 3:
				this.Res1 = (CustomRadioButton)target;
				return;
			case 4:
				this.Res2 = (CustomRadioButton)target;
				return;
			case 5:
				this.Res3 = (CustomRadioButton)target;
				return;
			case 6:
				this.Res4 = (CustomRadioButton)target;
				return;
			case 7:
				this.DefaultResRadioBtn = (CustomRadioButton)target;
				return;
			case 8:
				this.mCustomRes = (Grid)target;
				return;
			case 9:
				this.CustomResolution = (CustomRadioButton)target;
				return;
			case 10:
				this.CustomResX = (CustomTextBox)target;
				this.CustomResX.AddHandler(System.Windows.DataObject.PastingEvent, new DataObjectPastingEventHandler(this.CheckNumeric_Pasting));
				return;
			case 11:
				this.CustomResY = (CustomTextBox)target;
				this.CustomResY.AddHandler(System.Windows.DataObject.PastingEvent, new DataObjectPastingEventHandler(this.CheckNumeric_Pasting));
				return;
			case 12:
				this.Dpi160 = (CustomRadioButton)target;
				return;
			case 13:
				this.Dpi240 = (CustomRadioButton)target;
				return;
			case 14:
				this.Dpi320 = (CustomRadioButton)target;
				return;
			case 15:
				this.mInfoIcon = (CustomPictureBox)target;
				return;
			case 16:
				this.mRestartNowBtn = (CustomButton)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040005E8 RID: 1512
		private string mSelectedDpi = "160";

		// Token: 0x040005E9 RID: 1513
		private string mCurrentDpi = "240";

		// Token: 0x040005EA RID: 1514
		private int mResSelectedWidth = 1920;

		// Token: 0x040005EB RID: 1515
		private int mResSelectedHeight = 1080;

		// Token: 0x040005EC RID: 1516
		private int mResWidth = 1920;

		// Token: 0x040005ED RID: 1517
		private int mResHeight = 1080;

		// Token: 0x040005EE RID: 1518
		private bool mShouldRestart;

		// Token: 0x040005EF RID: 1519
		private CustomRadioButton previousResolution = new CustomRadioButton();

		// Token: 0x040005F0 RID: 1520
		private const string Res1280x720 = "1280 x 720";

		// Token: 0x040005F1 RID: 1521
		private const string Res1600x900 = "1600 x 900";

		// Token: 0x040005F2 RID: 1522
		private const string Res1920x1080 = "1920 x 1080";

		// Token: 0x040005F3 RID: 1523
		private const string Res2560x1440 = "2560 x 1440";

		// Token: 0x040005F4 RID: 1524
		private List<string> mLandscapeResolutions = new List<string>
		{
			"1280 x 720",
			"1600 x 900",
			"1920 x 1080",
			"2560 x 1440"
		};

		// Token: 0x040005F5 RID: 1525
		private const string Res720x1280 = "720 x 1280";

		// Token: 0x040005F6 RID: 1526
		private const string Res900x1600 = "900 x 1600";

		// Token: 0x040005F7 RID: 1527
		private const string Res1080x1920 = "1080 x 1920";

		// Token: 0x040005F8 RID: 1528
		private const string Res1440x2560 = "1440 x 2560";

		// Token: 0x040005F9 RID: 1529
		private List<string> mPortraitResolutions = new List<string>
		{
			"720 x 1280",
			"900 x 1600",
			"1080 x 1920",
			"1440 x 2560"
		};

		// Token: 0x040005FA RID: 1530
		public string mVmName = "Android";

		// Token: 0x040005FB RID: 1531
		internal CustomComboBox mOrientation;

		// Token: 0x040005FC RID: 1532
		internal Grid mRadioButtons;

		// Token: 0x040005FD RID: 1533
		internal CustomRadioButton Res1;

		// Token: 0x040005FE RID: 1534
		internal CustomRadioButton Res2;

		// Token: 0x040005FF RID: 1535
		internal CustomRadioButton Res3;

		// Token: 0x04000600 RID: 1536
		internal CustomRadioButton Res4;

		// Token: 0x04000601 RID: 1537
		internal CustomRadioButton DefaultResRadioBtn;

		// Token: 0x04000602 RID: 1538
		internal Grid mCustomRes;

		// Token: 0x04000603 RID: 1539
		internal CustomRadioButton CustomResolution;

		// Token: 0x04000604 RID: 1540
		internal CustomTextBox CustomResX;

		// Token: 0x04000605 RID: 1541
		internal CustomTextBox CustomResY;

		// Token: 0x04000606 RID: 1542
		internal CustomRadioButton Dpi160;

		// Token: 0x04000607 RID: 1543
		internal CustomRadioButton Dpi240;

		// Token: 0x04000608 RID: 1544
		internal CustomRadioButton Dpi320;

		// Token: 0x04000609 RID: 1545
		internal CustomPictureBox mInfoIcon;

		// Token: 0x0400060A RID: 1546
		internal CustomButton mRestartNowBtn;

		// Token: 0x0400060B RID: 1547
		private bool _contentLoaded;
	}
}
