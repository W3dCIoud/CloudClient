﻿using System;
using System.IO;
using System.Windows.Media.Imaging;

namespace BlueStacks.Common
{
	// Token: 0x02000160 RID: 352
	public class ImageUtils
	{
		// Token: 0x06000B7D RID: 2941 RVA: 0x0002605C File Offset: 0x0002425C
		public static BitmapImage BitmapFromPath(string path)
		{
			BitmapImage bitmapImage = null;
			if (File.Exists(path))
			{
				bitmapImage = new BitmapImage();
				FileStream fileStream = File.OpenRead(path);
				bitmapImage.BeginInit();
				bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
				bitmapImage.StreamSource = fileStream;
				bitmapImage.EndInit();
				fileStream.Close();
				fileStream.Dispose();
			}
			return bitmapImage;
		}

		// Token: 0x06000B7E RID: 2942 RVA: 0x00031A9C File Offset: 0x0002FC9C
		public static BitmapImage BitmapFromUri(string uri)
		{
			BitmapImage bitmapImage = null;
			try
			{
				bitmapImage = new BitmapImage();
				bitmapImage.BeginInit();
				bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
				bitmapImage.UriSource = new Uri(uri);
				bitmapImage.EndInit();
			}
			catch
			{
			}
			return bitmapImage;
		}
	}
}
