﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000C5 RID: 197
	public enum EngineState
	{
		// Token: 0x040004DC RID: 1244
		plus,
		// Token: 0x040004DD RID: 1245
		raw,
		// Token: 0x040004DE RID: 1246
		legacy
	}
}
