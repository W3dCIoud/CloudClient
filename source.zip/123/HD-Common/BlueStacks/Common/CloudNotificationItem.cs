﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200009E RID: 158
	public class CloudNotificationItem
	{
		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x06000384 RID: 900 RVA: 0x00003F82 File Offset: 0x00002182
		// (set) Token: 0x06000385 RID: 901 RVA: 0x00003F8A File Offset: 0x0000218A
		public string Title
		{
			get
			{
				return this.mTitle;
			}
			set
			{
				this.mTitle = value;
			}
		}

		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x06000386 RID: 902 RVA: 0x00003F93 File Offset: 0x00002193
		// (set) Token: 0x06000387 RID: 903 RVA: 0x00003F9B File Offset: 0x0000219B
		public string Url
		{
			get
			{
				return this.mUrl;
			}
			set
			{
				this.mUrl = value;
			}
		}

		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x06000388 RID: 904 RVA: 0x00003FA4 File Offset: 0x000021A4
		// (set) Token: 0x06000389 RID: 905 RVA: 0x00003FAC File Offset: 0x000021AC
		public string Message
		{
			get
			{
				return this.mMessage;
			}
			set
			{
				this.mMessage = value;
			}
		}

		// Token: 0x170000EA RID: 234
		// (get) Token: 0x0600038A RID: 906 RVA: 0x00003FB5 File Offset: 0x000021B5
		// (set) Token: 0x0600038B RID: 907 RVA: 0x00003FBD File Offset: 0x000021BD
		public string ImagePath
		{
			get
			{
				return this.mImagePath;
			}
			set
			{
				this.mImagePath = value;
			}
		}

		// Token: 0x170000EB RID: 235
		// (get) Token: 0x0600038C RID: 908 RVA: 0x00003FC6 File Offset: 0x000021C6
		// (set) Token: 0x0600038D RID: 909 RVA: 0x00003FCE File Offset: 0x000021CE
		public bool IsRead
		{
			get
			{
				return this.mIsRead;
			}
			set
			{
				this.mIsRead = value;
			}
		}

		// Token: 0x0600038E RID: 910 RVA: 0x00003FD7 File Offset: 0x000021D7
		public CloudNotificationItem()
		{
		}

		// Token: 0x0600038F RID: 911 RVA: 0x00016CA0 File Offset: 0x00014EA0
		public CloudNotificationItem(string title, string content, string imagePath, string url)
		{
			this.mTitle = title;
			this.mMessage = content;
			this.mImagePath = imagePath;
			this.mUrl = url;
		}

		// Token: 0x040003AB RID: 939
		private string mTitle = string.Empty;

		// Token: 0x040003AC RID: 940
		private string mUrl = string.Empty;

		// Token: 0x040003AD RID: 941
		private string mMessage = string.Empty;

		// Token: 0x040003AE RID: 942
		private string mImagePath = string.Empty;

		// Token: 0x040003AF RID: 943
		private bool mIsRead;
	}
}
