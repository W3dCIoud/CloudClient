﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000070 RID: 112
	[Serializable]
	public class NotificationItem
	{
		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x06000266 RID: 614 RVA: 0x000033CE File Offset: 0x000015CE
		// (set) Token: 0x06000267 RID: 615 RVA: 0x000033D6 File Offset: 0x000015D6
		public string ID
		{
			get
			{
				return this.mID;
			}
			set
			{
				this.mID = value;
			}
		}

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x06000268 RID: 616 RVA: 0x000033DF File Offset: 0x000015DF
		// (set) Token: 0x06000269 RID: 617 RVA: 0x000033E7 File Offset: 0x000015E7
		public MuteState MuteState
		{
			get
			{
				return this.mMuteState;
			}
			set
			{
				this.mMuteState = value;
			}
		}

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x0600026A RID: 618 RVA: 0x000033F0 File Offset: 0x000015F0
		// (set) Token: 0x0600026B RID: 619 RVA: 0x000033F8 File Offset: 0x000015F8
		public DateTime MuteTime
		{
			get
			{
				return this.mMuteTime;
			}
			set
			{
				this.mMuteTime = value;
			}
		}

		// Token: 0x0600026C RID: 620 RVA: 0x00003401 File Offset: 0x00001601
		public NotificationItem(string key, MuteState state, DateTime now)
		{
			this.ID = key;
			this.MuteState = state;
			this.MuteTime = now;
		}

		// Token: 0x0600026D RID: 621 RVA: 0x0000343B File Offset: 0x0000163B
		public NotificationItem()
		{
		}

		// Token: 0x0400016C RID: 364
		private string mID = string.Empty;

		// Token: 0x0400016D RID: 365
		private MuteState mMuteState = MuteState.AutoHide;

		// Token: 0x0400016E RID: 366
		private DateTime mMuteTime = DateTime.MinValue;
	}
}
