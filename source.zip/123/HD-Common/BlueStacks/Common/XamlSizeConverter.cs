﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x020001A8 RID: 424
	public class XamlSizeConverter : MarkupExtension, IValueConverter
	{
		// Token: 0x06000D01 RID: 3329 RVA: 0x0000B79F File Offset: 0x0000999F
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return System.Convert.ToDouble(value, culture) * System.Convert.ToDouble(parameter, culture);
		}

		// Token: 0x06000D02 RID: 3330 RVA: 0x0000B7B7 File Offset: 0x000099B7
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			throw new NotImplementedException();
		}

		// Token: 0x06000D03 RID: 3331 RVA: 0x00003F48 File Offset: 0x00002148
		public override object ProvideValue(IServiceProvider serviceProvider)
		{
			return this;
		}
	}
}
