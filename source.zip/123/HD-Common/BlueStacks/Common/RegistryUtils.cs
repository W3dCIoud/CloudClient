﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using Microsoft.Win32;

namespace BlueStacks.Common
{
	// Token: 0x0200016E RID: 366
	public static class RegistryUtils
	{
		// Token: 0x06000BD4 RID: 3028
		[DllImport("advapi32", CharSet = CharSet.Auto, SetLastError = true)]
		public static extern int RegRenameKey(UIntPtr hKey, [MarshalAs(UnmanagedType.LPWStr)] string oldname, [MarshalAs(UnmanagedType.LPWStr)] string newname);

		// Token: 0x06000BD5 RID: 3029
		[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		public static extern int RegOpenKeyEx(UIntPtr hKey, string subKey, int ulOptions, RegSAM samDesired, out UIntPtr hkResult);

		// Token: 0x06000BD6 RID: 3030 RVA: 0x00032FCC File Offset: 0x000311CC
		public static RegistryKey InitKey(string keyName)
		{
			RegistryKey result;
			try
			{
				result = Registry.LocalMachine.CreateSubKey(keyName);
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000BD7 RID: 3031 RVA: 0x00033000 File Offset: 0x00031200
		public static void DeleteKey(string hklmPath, bool throwOnError = true)
		{
			try
			{
				Registry.LocalMachine.DeleteSubKeyTree(hklmPath);
			}
			catch
			{
				if (throwOnError)
				{
					throw;
				}
			}
		}

		// Token: 0x06000BD8 RID: 3032 RVA: 0x00033034 File Offset: 0x00031234
		public static object GetRegistryValue(string registryPath, string key, object defaultValue, RegistryKeyKind registryKind = RegistryKeyKind.HKEY_LOCAL_MACHINE)
		{
			RegistryKey registryKey = null;
			object result = defaultValue;
			if (registryKind != RegistryKeyKind.HKEY_LOCAL_MACHINE)
			{
				if (registryKind == RegistryKeyKind.HKEY_CURRENT_USER)
				{
					registryKey = Registry.CurrentUser.OpenSubKey(registryPath);
				}
			}
			else
			{
				registryKey = Registry.LocalMachine.OpenSubKey(registryPath);
			}
			if (registryKey != null)
			{
				result = registryKey.GetValue(key, defaultValue);
				registryKey.Close();
			}
			return result;
		}

		// Token: 0x06000BD9 RID: 3033 RVA: 0x0003307C File Offset: 0x0003127C
		public static bool SetRegistryValue(string registryPath, string key, object value, RegistryValueKind type, RegistryKeyKind registryKind = RegistryKeyKind.HKEY_LOCAL_MACHINE)
		{
			RegistryKey registryKey = null;
			bool result = true;
			try
			{
				if (registryKind != RegistryKeyKind.HKEY_LOCAL_MACHINE)
				{
					if (registryKind == RegistryKeyKind.HKEY_CURRENT_USER)
					{
						registryKey = Registry.CurrentUser.CreateSubKey(registryPath);
					}
				}
				else
				{
					registryKey = Registry.LocalMachine.CreateSubKey(registryPath);
				}
				if (registryKey != null)
				{
					registryKey.SetValue(key, value, type);
				}
			}
			catch
			{
				Logger.Warning("Failed to set registry value at {0} for {1}:{2}", new object[]
				{
					registryPath,
					key,
					value
				});
				result = false;
			}
			finally
			{
				if (registryKey != null)
				{
					registryKey.Close();
				}
			}
			return result;
		}

		// Token: 0x06000BDA RID: 3034 RVA: 0x00033108 File Offset: 0x00031308
		public static int RenameKey(string basePath, string oldName, string newName, bool deleteNewIfExist)
		{
			if (deleteNewIfExist)
			{
				try
				{
					Registry.LocalMachine.DeleteSubKeyTree(Path.Combine(basePath, newName));
				}
				catch (Exception ex)
				{
					Logger.Warning("Couldn't delete new subkeytree: {0}\\{1}, ex: {2}", new object[]
					{
						basePath,
						newName,
						ex.Message
					});
				}
			}
			UIntPtr hKey;
			int num = RegistryUtils.RegOpenKeyEx(RegistryUtils.HKEY_LOCAL_MACHINE, basePath, 0, RegSAM.Write, out hKey);
			if (num == 0)
			{
				num = RegistryUtils.RegRenameKey(hKey, oldName, newName);
			}
			return num;
		}

		// Token: 0x06000BDB RID: 3035 RVA: 0x00033180 File Offset: 0x00031380
		public static void GrantAllAccessPermission(RegistryKey rk)
		{
			object obj = new SecurityIdentifier(WellKnownSidType.WorldSid, null).Translate(typeof(NTAccount)) as NTAccount;
			RegistrySecurity registrySecurity = new RegistrySecurity();
			RegistryAccessRule rule = new RegistryAccessRule(obj.ToString(), RegistryRights.FullControl, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow);
			registrySecurity.AddAccessRule(rule);
			rk.SetAccessControl(registrySecurity);
		}

		// Token: 0x06000BDC RID: 3036 RVA: 0x000331D0 File Offset: 0x000313D0
		public static void MoveUnifiedInstallerRegistryFromWow64()
		{
			try
			{
				RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(Strings.RegistryBaseKeyPath);
				if (registryKey == null || string.IsNullOrEmpty((string)registryKey.GetValue("Version", null)))
				{
					RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("Software", true);
					RegistryKey registryKey3 = Registry.LocalMachine.OpenSubKey("Software\\WOW6432Node\\BlueStacks" + Strings.GetOemTag());
					if (registryKey3 != null)
					{
						RegistryKey registryKey4 = registryKey2.CreateSubKey("BlueStacks" + Strings.GetOemTag());
						RegistryUtils.RecurseCopyKey(registryKey3, registryKey4);
						registryKey2.DeleteSubKeyTree("WOW6432Node\\BlueStacks" + Strings.GetOemTag());
						RegistryUtils.GrantAllAccessPermission(registryKey4);
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000BDD RID: 3037 RVA: 0x00033288 File Offset: 0x00031488
		private static void RecurseCopyKey(RegistryKey sourceKey, RegistryKey destinationKey)
		{
			foreach (string name in sourceKey.GetValueNames())
			{
				object value = sourceKey.GetValue(name);
				RegistryValueKind valueKind = sourceKey.GetValueKind(name);
				destinationKey.SetValue(name, value, valueKind);
			}
			foreach (string text in sourceKey.GetSubKeyNames())
			{
				RegistryKey sourceKey2 = sourceKey.OpenSubKey(text);
				RegistryKey destinationKey2 = destinationKey.CreateSubKey(text);
				RegistryUtils.RecurseCopyKey(sourceKey2, destinationKey2);
			}
		}

		// Token: 0x0400083B RID: 2107
		public static UIntPtr HKEY_LOCAL_MACHINE = new UIntPtr(2147483650U);

		// Token: 0x0400083C RID: 2108
		public static UIntPtr HKEY_CURRENT_USER = new UIntPtr(2147483649U);
	}
}
