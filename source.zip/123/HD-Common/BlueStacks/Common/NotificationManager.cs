﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace BlueStacks.Common
{
	// Token: 0x02000071 RID: 113
	public sealed class NotificationManager
	{
		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x0600026E RID: 622 RVA: 0x00011454 File Offset: 0x0000F654
		public static NotificationManager Instance
		{
			get
			{
				if (NotificationManager.mInstance == null)
				{
					object obj = NotificationManager.syncRoot;
					lock (obj)
					{
						if (NotificationManager.mInstance == null)
						{
							NotificationManager.mInstance = new NotificationManager();
						}
					}
				}
				return NotificationManager.mInstance;
			}
		}

		// Token: 0x0600026F RID: 623 RVA: 0x000114AC File Offset: 0x0000F6AC
		private NotificationManager()
		{
			this.ReloadNotificationDetails();
			this.mNotificationFilePath = Path.Combine(RegistryStrings.BstUserDataDir, "Notifications.txt");
		}

		// Token: 0x06000270 RID: 624 RVA: 0x0001150C File Offset: 0x0000F70C
		public void ReloadNotificationDetails()
		{
			if (string.IsNullOrEmpty(RegistryManager.Instance.NotificationData))
			{
				this.mDictNotificationItems = new SerializableDictionary<string, NotificationItem>();
				return;
			}
			StringReader textReader = new StringReader(RegistryManager.Instance.NotificationData);
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(SerializableDictionary<string, NotificationItem>));
			this.mDictNotificationItems = (SerializableDictionary<string, NotificationItem>)xmlSerializer.Deserialize(textReader);
		}

		// Token: 0x06000271 RID: 625 RVA: 0x00011568 File Offset: 0x0000F768
		private void UpdateNotificationsSettings()
		{
			try
			{
				StringWriter stringWriter = new StringWriter();
				new XmlSerializer(typeof(SerializableDictionary<string, NotificationItem>)).Serialize(stringWriter, this.mDictNotificationItems);
				RegistryManager.Instance.NotificationData = stringWriter.ToString();
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to update notification... Err : " + ex.ToString());
			}
		}

		// Token: 0x06000272 RID: 626 RVA: 0x00003460 File Offset: 0x00001660
		public MuteState IsShowNotificationForKey(string title)
		{
			this.ReloadNotificationDetails();
			return this.IsNotificationMutedForKey(title);
		}

		// Token: 0x06000273 RID: 627 RVA: 0x000115D0 File Offset: 0x0000F7D0
		public MuteState IsNotificationMutedForKey(string title)
		{
			MuteState muteState = MuteState.AutoHide;
			if (this.mDictNotificationItems.ContainsKey(title))
			{
				if (this.mDictNotificationItems[title].MuteState != MuteState.AutoHide)
				{
					if (this.mDictNotificationItems[title].MuteState == MuteState.MutedForever)
					{
						muteState = MuteState.MutedForever;
					}
					else if (this.mDictNotificationItems[title].MuteState == MuteState.NotMuted)
					{
						muteState = MuteState.NotMuted;
					}
					else if (this.mDictNotificationItems[title].MuteState == MuteState.MutedFor1Hour)
					{
						if ((DateTime.Now - this.mDictNotificationItems[title].MuteTime).Hours < 1)
						{
							muteState = MuteState.MutedForever;
						}
						else
						{
							this.mDictNotificationItems.Remove(title);
							this.UpdateNotificationsSettings();
							muteState = MuteState.AutoHide;
						}
					}
					else if (this.mDictNotificationItems[title].MuteState == MuteState.MutedFor1Day)
					{
						if ((DateTime.Now - this.mDictNotificationItems[title].MuteTime).Days < 1)
						{
							muteState = MuteState.MutedForever;
						}
						else
						{
							this.mDictNotificationItems.Remove(title);
							this.UpdateNotificationsSettings();
							muteState = MuteState.AutoHide;
						}
					}
					else if (this.mDictNotificationItems[title].MuteState == MuteState.MutedFor1Week)
					{
						if ((DateTime.Now - this.mDictNotificationItems[title].MuteTime).Days < 7)
						{
							muteState = MuteState.MutedForever;
						}
						else
						{
							this.mDictNotificationItems.Remove(title);
							this.UpdateNotificationsSettings();
							muteState = MuteState.AutoHide;
						}
					}
				}
			}
			else
			{
				muteState = this.GetDefaultState();
				this.mDictNotificationItems.Add(title, new NotificationItem(title, muteState, DateTime.Now));
			}
			return muteState;
		}

		// Token: 0x06000274 RID: 628 RVA: 0x00011764 File Offset: 0x0000F964
		public void UpdateMuteState(MuteState state, string key)
		{
			if (this.mDictNotificationItems.ContainsKey(key))
			{
				this.mDictNotificationItems[key].MuteState = state;
				this.mDictNotificationItems[key].MuteTime = DateTime.Now;
			}
			else
			{
				this.mDictNotificationItems.Add(key, new NotificationItem(key, state, DateTime.Now));
			}
			this.UpdateNotificationsSettings();
		}

		// Token: 0x06000275 RID: 629 RVA: 0x0000346F File Offset: 0x0000166F
		internal void DeleteMuteState(string key)
		{
			if (this.mDictNotificationItems.ContainsKey(key))
			{
				this.mDictNotificationItems.Remove(key);
			}
			this.UpdateNotificationsSettings();
		}

		// Token: 0x06000276 RID: 630 RVA: 0x000117C8 File Offset: 0x0000F9C8
		public void AddNewNotification(string imagePath, int id, string title, string msg, string url)
		{
			int i = 3;
			while (i > 0)
			{
				i--;
				try
				{
					CloudNotificationItem value = new CloudNotificationItem(title, msg, imagePath, url);
					SerializableDictionary<string, CloudNotificationItem> savedNotifications = this.GetSavedNotifications();
					savedNotifications[id.ToString()] = value;
					this.SaveNotifications(savedNotifications);
					break;
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to add notification titled : {0} and msg : {1}... Err : {2}", new object[]
					{
						title,
						msg,
						ex.ToString()
					});
				}
			}
		}

		// Token: 0x06000277 RID: 631 RVA: 0x00011840 File Offset: 0x0000FA40
		private void SaveNotifications(SerializableDictionary<string, CloudNotificationItem> lstItem)
		{
			using (XmlTextWriter xmlTextWriter = new XmlTextWriter(this.mNotificationFilePath, Encoding.UTF8))
			{
				xmlTextWriter.Formatting = Formatting.Indented;
				new XmlSerializer(typeof(SerializableDictionary<string, CloudNotificationItem>)).Serialize(xmlTextWriter, lstItem);
				xmlTextWriter.Flush();
			}
		}

		// Token: 0x06000278 RID: 632 RVA: 0x000118A0 File Offset: 0x0000FAA0
		private SerializableDictionary<string, CloudNotificationItem> GetSavedNotifications()
		{
			SerializableDictionary<string, CloudNotificationItem> result = new SerializableDictionary<string, CloudNotificationItem>();
			if (File.Exists(this.mNotificationFilePath))
			{
				using (FileStream fileStream = File.OpenRead(this.mNotificationFilePath))
				{
					result = (SerializableDictionary<string, CloudNotificationItem>)new XmlSerializer(typeof(SerializableDictionary<string, CloudNotificationItem>)).Deserialize(fileStream);
					fileStream.Flush();
				}
			}
			return result;
		}

		// Token: 0x06000279 RID: 633 RVA: 0x0001190C File Offset: 0x0000FB0C
		public void RemoveNotification(string key)
		{
			int i = 3;
			while (i > 0)
			{
				i--;
				try
				{
					SerializableDictionary<string, CloudNotificationItem> savedNotifications = this.GetSavedNotifications();
					if (savedNotifications.ContainsKey(key))
					{
						savedNotifications.Remove(key);
						this.SaveNotifications(savedNotifications);
					}
					break;
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to remove notification... Err : " + ex.ToString());
				}
			}
		}

		// Token: 0x0600027A RID: 634 RVA: 0x00011970 File Offset: 0x0000FB70
		public void MarkReadNotification(string key)
		{
			int i = 3;
			while (i > 0)
			{
				i--;
				try
				{
					SerializableDictionary<string, CloudNotificationItem> savedNotifications = this.GetSavedNotifications();
					if (key != null && savedNotifications.ContainsKey(key))
					{
						savedNotifications[key].IsRead = true;
						this.SaveNotifications(savedNotifications);
					}
					break;
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to mark read notification... Err : " + ex.ToString());
				}
			}
		}

		// Token: 0x0600027B RID: 635 RVA: 0x000119DC File Offset: 0x0000FBDC
		public void UpdateDictionary()
		{
			int i = 3;
			while (i > 0)
			{
				i--;
				try
				{
					this.mDictNotifications = NotificationManager.Instance.GetSavedNotifications();
					break;
				}
				catch (Exception ex)
				{
					Logger.Info("Failed to update notification dictionary... Err : " + ex.ToString());
				}
			}
		}

		// Token: 0x0600027C RID: 636 RVA: 0x00011A30 File Offset: 0x0000FC30
		private MuteState GetDefaultState()
		{
			if (this.mDictNotificationItems != null)
			{
				foreach (KeyValuePair<string, NotificationItem> keyValuePair in this.mDictNotificationItems)
				{
					if (string.Compare(keyValuePair.Key, this.mShowNotificationText, StringComparison.InvariantCultureIgnoreCase) == 0)
					{
						return keyValuePair.Value.MuteState;
					}
				}
				return MuteState.AutoHide;
			}
			return MuteState.AutoHide;
		}

		// Token: 0x0600027D RID: 637 RVA: 0x00003492 File Offset: 0x00001692
		public void RemoveNotificationItem(string title)
		{
			if (this.mDictNotificationItems != null && this.mDictNotificationItems.ContainsKey(title))
			{
				this.mDictNotificationItems.Remove(title);
				this.UpdateNotificationsSettings();
			}
		}

		// Token: 0x0400016F RID: 367
		public SerializableDictionary<string, NotificationItem> mDictNotificationItems = new SerializableDictionary<string, NotificationItem>();

		// Token: 0x04000170 RID: 368
		public SerializableDictionary<string, CloudNotificationItem> mDictNotifications = new SerializableDictionary<string, CloudNotificationItem>();

		// Token: 0x04000171 RID: 369
		private static volatile NotificationManager mInstance;

		// Token: 0x04000172 RID: 370
		private static object syncRoot = new object();

		// Token: 0x04000173 RID: 371
		internal string mNotificationFilePath = string.Empty;

		// Token: 0x04000174 RID: 372
		private string mShowNotificationText = LocaleStrings.GetLocalizedString("ShowNotificationsText", false);
	}
}
