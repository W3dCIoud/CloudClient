﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000192 RID: 402
	public enum MultiInstanceManagerCodes
	{
		// Token: 0x04000A99 RID: 2713
		MULTI_INSTANCE_MANAGER_ALREADY_RUNNING,
		// Token: 0x04000A9A RID: 2714
		INSTANCE_RUNNING
	}
}
