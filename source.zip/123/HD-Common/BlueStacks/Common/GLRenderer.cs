﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200015C RID: 348
	public enum GLRenderer
	{
		// Token: 0x040007F7 RID: 2039
		OpenGL = 1,
		// Token: 0x040007F8 RID: 2040
		DX9,
		// Token: 0x040007F9 RID: 2041
		DX11,
		// Token: 0x040007FA RID: 2042
		DX11FallbackDX9
	}
}
