﻿using System;
using System.IO;
using System.Text.RegularExpressions;

namespace BlueStacks.Common
{
	// Token: 0x02000058 RID: 88
	public static class StringExtensions
	{
		// Token: 0x060001E2 RID: 482 RVA: 0x0000F240 File Offset: 0x0000D440
		public static bool IsNullOrWhiteSpace(this string value)
		{
			if (value == null)
			{
				return true;
			}
			for (int i = 0; i < value.Length; i++)
			{
				if (!char.IsWhiteSpace(value[i]))
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x060001E3 RID: 483 RVA: 0x0000F274 File Offset: 0x0000D474
		public static bool IsSubPathOf(this string baseDirPath, string path)
		{
			string fullPath = Path.GetFullPath(path.Replace('/', '\\').WithEnding("\\"));
			string fullPath2 = Path.GetFullPath(baseDirPath.Replace('/', '\\').WithEnding("\\"));
			return fullPath.StartsWith(fullPath2, StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x060001E4 RID: 484 RVA: 0x0000F2BC File Offset: 0x0000D4BC
		public static string WithEnding(this string str, string ending)
		{
			if (str == null)
			{
				return ending;
			}
			for (int i = 0; i <= ending.Length; i++)
			{
				string text = str + ending.Right(i);
				if (text.EndsWith(ending))
				{
					return text;
				}
			}
			return str;
		}

		// Token: 0x060001E5 RID: 485 RVA: 0x0000F2FC File Offset: 0x0000D4FC
		public static string Right(this string value, int length)
		{
			if (value == null)
			{
				throw new ArgumentNullException("value");
			}
			if (length < 0)
			{
				throw new ArgumentOutOfRangeException("length", length, "Length is less than zero");
			}
			if (length >= value.Length)
			{
				return value;
			}
			return value.Substring(value.Length - length);
		}

		// Token: 0x060001E6 RID: 486 RVA: 0x00002F45 File Offset: 0x00001145
		public static bool IsValidFileName(this string value)
		{
			if (value == null)
			{
				return false;
			}
			value = value.Trim();
			return !string.IsNullOrEmpty(value) && value.IndexOfAny(Path.GetInvalidFileNameChars()) < 0;
		}

		// Token: 0x060001E7 RID: 487 RVA: 0x0000F34C File Offset: 0x0000D54C
		public static bool GetValidFileName(this string value, out string fileName)
		{
			fileName = string.Empty;
			if (value == null)
			{
				return false;
			}
			value = value.Trim();
			if (string.IsNullOrEmpty(value))
			{
				return false;
			}
			for (int i = value.IndexOfAny(Path.GetInvalidFileNameChars()); i >= 0; i = value.IndexOfAny(Path.GetInvalidFileNameChars()))
			{
				fileName = value.Remove(i, 1);
			}
			return string.IsNullOrEmpty(fileName);
		}

		// Token: 0x060001E8 RID: 488 RVA: 0x00002F6F File Offset: 0x0000116F
		public static string CombinePathWith(this string path1, string path2)
		{
			return Path.Combine(path1, path2);
		}

		// Token: 0x060001E9 RID: 489 RVA: 0x0000F3A8 File Offset: 0x0000D5A8
		public static bool IsValidPath(string path)
		{
			if (!new Regex("^[a-zA-Z]:\\\\$").IsMatch(path.Substring(0, 3)))
			{
				return false;
			}
			string text = new string(Path.GetInvalidPathChars());
			text += ":/?*\"";
			if (new Regex("[" + Regex.Escape(text) + "]").IsMatch(path.Substring(3, path.Length - 3)))
			{
				return false;
			}
			DirectoryInfo directoryInfo = new DirectoryInfo(Path.GetFullPath(path));
			if (!directoryInfo.Exists)
			{
				directoryInfo.Create();
			}
			return true;
		}

		// Token: 0x060001EA RID: 490 RVA: 0x00002F78 File Offset: 0x00001178
		public static T ToEnum<T>(this string value)
		{
			return (T)((object)Enum.Parse(typeof(T), value, true));
		}
	}
}
