﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using BlueStacks.Common.Grm;
using Newtonsoft.Json;

namespace BlueStacks.Common
{
	// Token: 0x02000093 RID: 147
	public class AppRequirementsParser
	{
		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x06000352 RID: 850 RVA: 0x00016070 File Offset: 0x00014270
		public static AppRequirementsParser Instance
		{
			get
			{
				if (AppRequirementsParser.sInstance == null)
				{
					object obj = AppRequirementsParser.syncRoot;
					lock (obj)
					{
						if (AppRequirementsParser.sInstance == null)
						{
							AppRequirementsParser.sInstance = new AppRequirementsParser();
						}
					}
				}
				return AppRequirementsParser.sInstance;
			}
		}

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x06000353 RID: 851 RVA: 0x00003E80 File Offset: 0x00002080
		// (set) Token: 0x06000354 RID: 852 RVA: 0x00003E88 File Offset: 0x00002088
		public List<AppRequirement> Requirements
		{
			get
			{
				return this.mRequirements;
			}
			set
			{
				this.mRequirements = value;
				Action requirementConfigUpdated = this.RequirementConfigUpdated;
				if (requirementConfigUpdated == null)
				{
					return;
				}
				requirementConfigUpdated();
			}
		}

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x06000355 RID: 853 RVA: 0x000160C8 File Offset: 0x000142C8
		// (remove) Token: 0x06000356 RID: 854 RVA: 0x00016100 File Offset: 0x00014300
		public event Action RequirementConfigUpdated;

		// Token: 0x06000357 RID: 855 RVA: 0x00003EA1 File Offset: 0x000020A1
		private AppRequirementsParser()
		{
			this.mRequirementsJsonFile = Path.Combine(RegistryStrings.GadgetDir, "requirements.json");
			this.mRequirementsTranslationsFile = Path.Combine(RegistryStrings.GadgetDir, "req_trans.json");
		}

		// Token: 0x06000358 RID: 856 RVA: 0x00016138 File Offset: 0x00014338
		public void PopulateRequirementsFromFile()
		{
			string value = "[]";
			string value2 = "[]";
			using (Mutex mutex = new Mutex(false, "BlueStacks_AppRequirementUpdate"))
			{
				if (mutex.WaitOne())
				{
					try
					{
						if (!File.Exists(this.mRequirementsJsonFile))
						{
							using (StreamWriter streamWriter = new StreamWriter(this.mRequirementsJsonFile, true))
							{
								streamWriter.Write("[");
								streamWriter.WriteLine();
								streamWriter.Write("]");
							}
						}
						using (StreamReader streamReader = new StreamReader(new FileStream(this.mRequirementsJsonFile, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))
						{
							value = streamReader.ReadToEnd();
						}
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to get app requirements");
						Logger.Error(ex.ToString());
					}
					try
					{
						if (!File.Exists(this.mRequirementsTranslationsFile))
						{
							using (StreamWriter streamWriter2 = new StreamWriter(this.mRequirementsTranslationsFile, true))
							{
								streamWriter2.Write("{}");
							}
						}
						using (StreamReader streamReader2 = new StreamReader(new FileStream(this.mRequirementsTranslationsFile, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))
						{
							value2 = streamReader2.ReadToEnd();
						}
					}
					catch (Exception ex2)
					{
						Logger.Error("Failed to get app requirements translations from file");
						Logger.Error(ex2.ToString());
					}
					finally
					{
						mutex.ReleaseMutex();
					}
				}
			}
			List<AppRequirement> requirements = new List<AppRequirement>();
			try
			{
				requirements = JsonConvert.DeserializeObject<List<AppRequirement>>(value, Utils.GetSerializerSettings());
			}
			catch (Exception arg)
			{
				Logger.Error("Exception in parsing apprequirement json " + arg);
			}
			Dictionary<string, Dictionary<string, string>> dictionary = new Dictionary<string, Dictionary<string, string>>();
			try
			{
				dictionary = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, string>>>(value2, Utils.GetSerializerSettings());
			}
			catch (Exception arg2)
			{
				Logger.Error("Exception in parsing req translations json " + arg2);
			}
			this.Requirements = requirements;
			if (dictionary != null && dictionary.Count > 0)
			{
				this.mTranslations = dictionary;
			}
		}

		// Token: 0x06000359 RID: 857 RVA: 0x000163E4 File Offset: 0x000145E4
		public void UpdateOverwriteRequirements(string fullJson, string translationJson)
		{
			List<AppRequirement> list = JsonConvert.DeserializeObject<List<AppRequirement>>(fullJson, Utils.GetSerializerSettings());
			Dictionary<string, Dictionary<string, string>> dictionary = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, string>>>(translationJson, Utils.GetSerializerSettings());
			this.SaveRequirements(list, dictionary);
			if (dictionary.Count > 0)
			{
				this.mTranslations = dictionary;
			}
			this.Requirements = list;
		}

		// Token: 0x0600035A RID: 858 RVA: 0x00016428 File Offset: 0x00014628
		public string GetLocalizedString(string key)
		{
			string text = RegistryManager.Instance.UserSelectedLocale;
			text = LocaleStrings.FindClosestMatchingLocale(text);
			if (this.mTranslations.ContainsKey(text) && this.mTranslations[text].ContainsKey(key))
			{
				return this.mTranslations[text][key];
			}
			return key;
		}

		// Token: 0x0600035B RID: 859 RVA: 0x00016480 File Offset: 0x00014680
		private void SaveRequirements(List<AppRequirement> appRequirements, Dictionary<string, Dictionary<string, string>> translations)
		{
			using (Mutex mutex = new Mutex(false, "BlueStacks_AppRequirementUpdate"))
			{
				if (mutex.WaitOne())
				{
					try
					{
						FileInfo fileInfo = new FileInfo(this.mRequirementsJsonFile + ".tmp");
						JsonSerializer jsonSerializer = JsonSerializer.Create(Utils.GetSerializerSettings());
						using (TextWriter textWriter = new StreamWriter(fileInfo.Open(FileMode.Create)))
						{
							using (JsonWriter jsonWriter = new JsonTextWriter(textWriter))
							{
								jsonSerializer.Serialize(jsonWriter, appRequirements);
							}
						}
						File.Copy(this.mRequirementsJsonFile, this.mRequirementsJsonFile + ".bak", true);
						File.Delete(this.mRequirementsJsonFile);
						int num = 10;
						while (File.Exists(this.mRequirementsJsonFile) && num > 0)
						{
							num--;
							Thread.Sleep(100);
						}
						File.Move(this.mRequirementsJsonFile + ".tmp", this.mRequirementsJsonFile);
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to write/move requirements to apps json file");
						Logger.Error(ex.ToString());
					}
					try
					{
						FileInfo fileInfo2 = new FileInfo(this.mRequirementsTranslationsFile + ".tmp");
						JsonSerializer jsonSerializer2 = JsonSerializer.Create(Utils.GetSerializerSettings());
						using (TextWriter textWriter2 = new StreamWriter(fileInfo2.Open(FileMode.Create)))
						{
							using (JsonWriter jsonWriter2 = new JsonTextWriter(textWriter2))
							{
								jsonSerializer2.Serialize(jsonWriter2, translations);
							}
						}
						File.Copy(this.mRequirementsTranslationsFile, this.mRequirementsTranslationsFile + ".bak", true);
						File.Delete(this.mRequirementsTranslationsFile);
						int num2 = 10;
						while (File.Exists(this.mRequirementsTranslationsFile) && num2 > 0)
						{
							num2--;
							Thread.Sleep(100);
						}
						File.Move(this.mRequirementsTranslationsFile + ".tmp", this.mRequirementsTranslationsFile);
					}
					catch (Exception ex2)
					{
						Logger.Error("Failed to write/move requirements translations to req translations json file");
						Logger.Error(ex2.ToString());
					}
					finally
					{
						mutex.ReleaseMutex();
					}
				}
			}
		}

		// Token: 0x04000367 RID: 871
		private static object syncRoot = new object();

		// Token: 0x04000368 RID: 872
		private static volatile AppRequirementsParser sInstance;

		// Token: 0x04000369 RID: 873
		private List<AppRequirement> mRequirements;

		// Token: 0x0400036A RID: 874
		private Dictionary<string, Dictionary<string, string>> mTranslations = new Dictionary<string, Dictionary<string, string>>();

		// Token: 0x0400036C RID: 876
		private readonly string mRequirementsJsonFile;

		// Token: 0x0400036D RID: 877
		private readonly string mRequirementsTranslationsFile;
	}
}
