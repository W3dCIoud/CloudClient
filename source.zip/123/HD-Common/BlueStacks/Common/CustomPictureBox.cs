﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;

namespace BlueStacks.Common
{
	// Token: 0x02000109 RID: 265
	public class CustomPictureBox : Image
	{
		// Token: 0x170002A3 RID: 675
		// (get) Token: 0x060008FA RID: 2298 RVA: 0x00009768 File Offset: 0x00007968
		// (set) Token: 0x060008FB RID: 2299 RVA: 0x00009770 File Offset: 0x00007970
		public bool IsFullImagePath
		{
			get
			{
				return this.mIsFullImagePath;
			}
			set
			{
				this.mIsFullImagePath = value;
			}
		}

		// Token: 0x170002A4 RID: 676
		// (get) Token: 0x060008FC RID: 2300 RVA: 0x00009779 File Offset: 0x00007979
		// (set) Token: 0x060008FD RID: 2301 RVA: 0x0000978B File Offset: 0x0000798B
		public string ImageName
		{
			get
			{
				return (string)base.GetValue(CustomPictureBox.ImageNameProperty);
			}
			set
			{
				base.SetValue(CustomPictureBox.ImageNameProperty, value);
			}
		}

		// Token: 0x170002A5 RID: 677
		// (get) Token: 0x060008FE RID: 2302 RVA: 0x00009799 File Offset: 0x00007999
		// (set) Token: 0x060008FF RID: 2303 RVA: 0x000097AB File Offset: 0x000079AB
		public bool IsAlwaysHalfSize
		{
			get
			{
				return (bool)base.GetValue(CustomPictureBox.IsAlwaysHalfSizeProperty);
			}
			set
			{
				base.SetValue(CustomPictureBox.IsAlwaysHalfSizeProperty, value);
			}
		}

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x06000900 RID: 2304 RVA: 0x00025B28 File Offset: 0x00023D28
		// (remove) Token: 0x06000901 RID: 2305 RVA: 0x00025B5C File Offset: 0x00023D5C
		public static event EventHandler SourceUpdatedEvent;

		// Token: 0x170002A6 RID: 678
		// (get) Token: 0x06000902 RID: 2306 RVA: 0x000097BE File Offset: 0x000079BE
		// (set) Token: 0x06000903 RID: 2307 RVA: 0x00025B90 File Offset: 0x00023D90
		public bool IsImageToBeRotated
		{
			get
			{
				return this.mIsImageToBeRotated;
			}
			set
			{
				this.mIsImageToBeRotated = value;
				if (value)
				{
					base.SizeChanged -= this.CustomPictureBox_SizeChanged;
					base.IsVisibleChanged -= this.CustomPictureBox_IsVisibleChanged;
					base.SizeChanged += this.CustomPictureBox_SizeChanged;
					base.IsVisibleChanged += this.CustomPictureBox_IsVisibleChanged;
					return;
				}
				if (this.mStoryBoard != null)
				{
					this.mStoryBoard.Stop();
				}
				base.SizeChanged -= this.CustomPictureBox_SizeChanged;
				base.IsVisibleChanged -= this.CustomPictureBox_IsVisibleChanged;
			}
		}

		// Token: 0x06000904 RID: 2308 RVA: 0x000097C6 File Offset: 0x000079C6
		public void SetDisabledState()
		{
			this.mButtonState = CustomPictureBox.State.disabled;
			base.Opacity = 0.4;
			this.SetDefaultImage();
		}

		// Token: 0x06000905 RID: 2309 RVA: 0x000097E4 File Offset: 0x000079E4
		public void SetNormalState()
		{
			this.mButtonState = CustomPictureBox.State.normal;
			base.Opacity = 1.0;
		}

		// Token: 0x06000906 RID: 2310 RVA: 0x00025C28 File Offset: 0x00023E28
		private string AppendStringToImageName(string appendText)
		{
			if (this.ImageName.EndsWith(".png", StringComparison.InvariantCultureIgnoreCase) || this.ImageName.EndsWith(".jpg", StringComparison.InvariantCultureIgnoreCase) || this.ImageName.EndsWith(".jpeg", StringComparison.InvariantCultureIgnoreCase) || this.ImageName.EndsWith(".ico", StringComparison.InvariantCultureIgnoreCase))
			{
				string extension = Path.GetExtension(this.ImageName);
				string directoryName = Path.GetDirectoryName(this.ImageName);
				return string.Concat(new string[]
				{
					directoryName,
					Path.DirectorySeparatorChar.ToString(),
					Path.GetFileNameWithoutExtension(this.ImageName),
					appendText,
					extension
				});
			}
			return this.ImageName + appendText;
		}

		// Token: 0x170002A7 RID: 679
		// (get) Token: 0x06000907 RID: 2311 RVA: 0x000097FC File Offset: 0x000079FC
		private string HoverImage
		{
			get
			{
				return this.AppendStringToImageName("_hover");
			}
		}

		// Token: 0x170002A8 RID: 680
		// (get) Token: 0x06000908 RID: 2312 RVA: 0x00009809 File Offset: 0x00007A09
		private string ClickImage
		{
			get
			{
				return this.AppendStringToImageName("_click");
			}
		}

		// Token: 0x170002A9 RID: 681
		// (get) Token: 0x06000909 RID: 2313 RVA: 0x00009816 File Offset: 0x00007A16
		private string DisabledImage
		{
			get
			{
				return this.AppendStringToImageName("_dis");
			}
		}

		// Token: 0x170002AA RID: 682
		// (get) Token: 0x0600090A RID: 2314 RVA: 0x00009823 File Offset: 0x00007A23
		public string SelectedImage
		{
			get
			{
				return this.AppendStringToImageName("_selected");
			}
		}

		// Token: 0x170002AB RID: 683
		// (get) Token: 0x0600090B RID: 2315 RVA: 0x00009830 File Offset: 0x00007A30
		public static string AssetsDir
		{
			get
			{
				return Path.Combine(RegistryManager.Instance.ClientInstallDir, RegistryManager.Instance.ClientThemeName);
			}
		}

		// Token: 0x0600090C RID: 2316 RVA: 0x00025CDC File Offset: 0x00023EDC
		public CustomPictureBox()
		{
			base.MouseEnter += this.PictureBox_MouseEnter;
			base.MouseLeave += this.PictureBox_MouseLeave;
			base.MouseDown += this.PictureBox_MouseDown;
			base.MouseUp += this.PictureBox_MouseUp;
			RenderOptions.SetBitmapScalingMode(this, BitmapScalingMode.HighQuality);
		}

		// Token: 0x0600090D RID: 2317 RVA: 0x00025D40 File Offset: 0x00023F40
		public static void UpdateImagesFromNewDirectory(string path = "")
		{
			foreach (Tuple<string, bool> tuple in (from _ in CustomPictureBox.sImageAssetsDict
			select new Tuple<string, bool>(_.Key, _.Value.Item2)).ToList<Tuple<string, bool>>())
			{
				if (tuple.Item1.IndexOfAny(new char[]
				{
					Path.AltDirectorySeparatorChar,
					Path.DirectorySeparatorChar
				}) == -1)
				{
					CustomPictureBox.sImageAssetsDict.Remove(tuple.Item1);
					CustomPictureBox.GetBitmapImage(tuple.Item1, path, tuple.Item2);
				}
			}
			CustomPictureBox.NotifyUIElements();
		}

		// Token: 0x0600090E RID: 2318 RVA: 0x0000984B File Offset: 0x00007A4B
		internal static void NotifyUIElements()
		{
			if (CustomPictureBox.SourceUpdatedEvent != null)
			{
				CustomPictureBox.SourceUpdatedEvent(null, null);
			}
		}

		// Token: 0x0600090F RID: 2319 RVA: 0x00025E04 File Offset: 0x00024004
		private static void ImageNameChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
		{
			CustomPictureBox customPictureBox = source as CustomPictureBox;
			if (!DesignerProperties.GetIsInDesignMode(customPictureBox))
			{
				customPictureBox.SetDefaultImage();
			}
		}

		// Token: 0x06000910 RID: 2320 RVA: 0x00025E04 File Offset: 0x00024004
		private static void IsAlwaysHalfSizeChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
		{
			CustomPictureBox customPictureBox = source as CustomPictureBox;
			if (!DesignerProperties.GetIsInDesignMode(customPictureBox))
			{
				customPictureBox.SetDefaultImage();
			}
		}

		// Token: 0x06000911 RID: 2321 RVA: 0x00009860 File Offset: 0x00007A60
		private void PictureBox_MouseEnter(object sender, MouseEventArgs e)
		{
			if (this.mButtonState == CustomPictureBox.State.normal && !this.IsFullImagePath)
			{
				this.SetHoverImage();
			}
		}

		// Token: 0x06000912 RID: 2322 RVA: 0x00009878 File Offset: 0x00007A78
		private void PictureBox_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.IsFullImagePath)
			{
				this.SetDefaultImage();
			}
		}

		// Token: 0x06000913 RID: 2323 RVA: 0x00009888 File Offset: 0x00007A88
		private void PictureBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.mButtonState == CustomPictureBox.State.normal && !this.IsFullImagePath)
			{
				this.SetClickedImage();
			}
		}

		// Token: 0x06000914 RID: 2324 RVA: 0x000098A0 File Offset: 0x00007AA0
		private void PictureBox_MouseUp(object sender, MouseButtonEventArgs e)
		{
			if (!this.IsFullImagePath)
			{
				if (base.IsMouseOver && this.mButtonState == CustomPictureBox.State.normal)
				{
					this.SetHoverImage();
					return;
				}
				this.SetDefaultImage();
			}
		}

		// Token: 0x06000915 RID: 2325 RVA: 0x00025E28 File Offset: 0x00024028
		public void SetHoverImage()
		{
			try
			{
				if (!this.IsFullImagePath)
				{
					CustomPictureBox.SetBitmapImage(this, this.HoverImage, false);
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000916 RID: 2326 RVA: 0x00025E60 File Offset: 0x00024060
		public void SetClickedImage()
		{
			try
			{
				if (!this.IsFullImagePath)
				{
					CustomPictureBox.SetBitmapImage(this, this.ClickImage, false);
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000917 RID: 2327 RVA: 0x00025E98 File Offset: 0x00024098
		public void SetSelectedImage()
		{
			try
			{
				if (!this.IsFullImagePath)
				{
					CustomPictureBox.SetBitmapImage(this, this.SelectedImage, false);
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000918 RID: 2328 RVA: 0x00025ED0 File Offset: 0x000240D0
		public void SetDisabledImage()
		{
			try
			{
				if (!this.IsFullImagePath)
				{
					CustomPictureBox.SetBitmapImage(this, this.DisabledImage, false);
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000919 RID: 2329 RVA: 0x00025F08 File Offset: 0x00024108
		public void SetDefaultImage()
		{
			try
			{
				CustomPictureBox.SetBitmapImage(this, this.ImageName, this.IsFullImagePath);
			}
			catch
			{
			}
		}

		// Token: 0x0600091A RID: 2330 RVA: 0x00025F3C File Offset: 0x0002413C
		public static BitmapImage GetBitmapImage(string fileName, string assetDirectory = "", bool isFullImagePath = false)
		{
			if (string.IsNullOrEmpty(fileName))
			{
				return null;
			}
			if (CustomPictureBox.sImageAssetsDict.ContainsKey(fileName))
			{
				return CustomPictureBox.sImageAssetsDict[fileName].Item1;
			}
			BitmapImage bitmapImage = null;
			if (fileName.IndexOfAny(new char[]
			{
				Path.AltDirectorySeparatorChar,
				Path.DirectorySeparatorChar
			}) != -1)
			{
				if (!isFullImagePath)
				{
					Logger.Warning("Full image path not marked false for image: " + fileName);
				}
				bitmapImage = CustomPictureBox.BitmapFromPath(fileName);
			}
			else if (isFullImagePath)
			{
				Logger.Warning("Full image path marked true for image: " + fileName);
			}
			if (bitmapImage == null)
			{
				if (string.IsNullOrEmpty(assetDirectory))
				{
					assetDirectory = CustomPictureBox.AssetsDir;
				}
				bitmapImage = CustomPictureBox.BitmapFromPath(Path.Combine(assetDirectory, Path.GetFileNameWithoutExtension(fileName) + ".png"));
				if (bitmapImage == null)
				{
					bitmapImage = CustomPictureBox.BitmapFromPath(Path.Combine(assetDirectory, fileName));
					if (bitmapImage == null)
					{
						bitmapImage = CustomPictureBox.BitmapFromPath(Path.Combine(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets"), Path.GetFileNameWithoutExtension(fileName) + ".png"));
					}
				}
			}
			CustomPictureBox.sImageAssetsDict.Add(fileName, new Tuple<BitmapImage, bool>(bitmapImage, isFullImagePath));
			if (bitmapImage == null)
			{
				Logger.Warning("Returning a null image for {0}", new object[]
				{
					fileName
				});
			}
			return bitmapImage;
		}

		// Token: 0x0600091B RID: 2331 RVA: 0x0002605C File Offset: 0x0002425C
		private static BitmapImage BitmapFromPath(string path)
		{
			BitmapImage bitmapImage = null;
			if (File.Exists(path))
			{
				bitmapImage = new BitmapImage();
				FileStream fileStream = File.OpenRead(path);
				bitmapImage.BeginInit();
				bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
				bitmapImage.StreamSource = fileStream;
				bitmapImage.EndInit();
				fileStream.Close();
				fileStream.Dispose();
			}
			return bitmapImage;
		}

		// Token: 0x0600091C RID: 2332 RVA: 0x000260A8 File Offset: 0x000242A8
		public static void SetBitmapImage(Image image, string fileName, bool isFullImagePath = false)
		{
			BitmapImage bitmapImage = CustomPictureBox.GetBitmapImage(fileName, "", isFullImagePath);
			if (bitmapImage != null)
			{
				bitmapImage.Freeze();
				BlueStacksUIBinding.Bind(image, Image.SourceProperty, fileName);
				if (image is CustomPictureBox)
				{
					CustomPictureBox customPictureBox = image as CustomPictureBox;
					customPictureBox.BitmapImage = bitmapImage;
					if (customPictureBox.IsAlwaysHalfSize)
					{
						customPictureBox.maxSize = new Point(customPictureBox.MaxWidth, customPictureBox.MaxHeight);
						customPictureBox.MaxWidth = bitmapImage.Width / 2.0;
						customPictureBox.MaxHeight = bitmapImage.Height / 2.0;
					}
					else if (customPictureBox.maxSize != default(Point))
					{
						customPictureBox.MaxWidth = customPictureBox.maxSize.X;
						customPictureBox.MaxHeight = customPictureBox.maxSize.Y;
					}
				}
			}
		}

		// Token: 0x0600091D RID: 2333 RVA: 0x0002617C File Offset: 0x0002437C
		private void CustomPictureBox_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (base.RenderTransform != null)
			{
				RotateTransform rotateTransform = base.RenderTransform as RotateTransform;
				if (rotateTransform != null)
				{
					rotateTransform.CenterX = base.ActualWidth / 2.0;
					rotateTransform.CenterY = base.ActualHeight / 2.0;
				}
			}
		}

		// Token: 0x0600091E RID: 2334 RVA: 0x000261CC File Offset: 0x000243CC
		private void CustomPictureBox_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (base.IsVisible && this.mIsImageToBeRotated)
			{
				if (this.mStoryBoard == null)
				{
					this.mStoryBoard = new Storyboard();
					this.animation = new DoubleAnimation();
					this.animation.From = new double?(0.0);
					this.animation.To = new double?((double)360);
					this.animation.RepeatBehavior = RepeatBehavior.Forever;
					this.animation.Duration = new Duration(new TimeSpan(0, 0, 1));
					base.RenderTransform = new RotateTransform
					{
						CenterX = base.ActualWidth / 2.0,
						CenterY = base.ActualHeight / 2.0
					};
					Storyboard.SetTarget(this.animation, this);
					Storyboard.SetTargetProperty(this.animation, new PropertyPath("(UIElement.RenderTransform).(RotateTransform.Angle)", new object[0]));
					this.mStoryBoard.Children.Add(this.animation);
				}
				this.mStoryBoard.Begin();
				return;
			}
			Storyboard storyboard = this.mStoryBoard;
			if (storyboard == null)
			{
				return;
			}
			storyboard.Pause();
		}

		// Token: 0x170002AC RID: 684
		// (set) Token: 0x0600091F RID: 2335 RVA: 0x000262FC File Offset: 0x000244FC
		public bool IsDisabled
		{
			set
			{
				if (value)
				{
					base.MouseEnter -= this.PictureBox_MouseEnter;
					base.MouseLeave -= this.PictureBox_MouseLeave;
					base.MouseDown -= this.PictureBox_MouseDown;
					base.MouseUp -= this.PictureBox_MouseUp;
					base.Opacity = 0.5;
				}
			}
		}

		// Token: 0x06000920 RID: 2336 RVA: 0x00026364 File Offset: 0x00024564
		public void ReloadImages()
		{
			CustomPictureBox.sImageAssetsDict.Remove(this.ClickImage);
			CustomPictureBox.sImageAssetsDict.Remove(this.ImageName);
			CustomPictureBox.sImageAssetsDict.Remove(this.HoverImage);
			CustomPictureBox.sImageAssetsDict.Remove(this.SelectedImage);
			CustomPictureBox.sImageAssetsDict.Remove(this.DisabledImage);
			this.SetDefaultImage();
			CustomPictureBox.GCCollectAsync();
		}

		// Token: 0x06000921 RID: 2337 RVA: 0x000098C7 File Offset: 0x00007AC7
		private static void GCCollectAsync()
		{
			new Thread(delegate()
			{
				GC.Collect();
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x040006C2 RID: 1730
		private Point maxSize;

		// Token: 0x040006C3 RID: 1731
		internal BitmapImage BitmapImage;

		// Token: 0x040006C4 RID: 1732
		internal DoubleAnimation animation;

		// Token: 0x040006C5 RID: 1733
		public CustomPictureBox.State mButtonState;

		// Token: 0x040006C6 RID: 1734
		private bool mIsFullImagePath;

		// Token: 0x040006C7 RID: 1735
		public static readonly DependencyProperty ImageNameProperty = DependencyProperty.Register("ImageName", typeof(string), typeof(CustomPictureBox), new FrameworkPropertyMetadata("", new PropertyChangedCallback(CustomPictureBox.ImageNameChanged)));

		// Token: 0x040006C8 RID: 1736
		public static readonly DependencyProperty IsAlwaysHalfSizeProperty = DependencyProperty.Register("IsAlwaysHalfSize", typeof(bool), typeof(CustomPictureBox), new FrameworkPropertyMetadata(false, new PropertyChangedCallback(CustomPictureBox.IsAlwaysHalfSizeChanged)));

		// Token: 0x040006CA RID: 1738
		public static Dictionary<string, Tuple<BitmapImage, bool>> sImageAssetsDict = new Dictionary<string, Tuple<BitmapImage, bool>>();

		// Token: 0x040006CB RID: 1739
		private Storyboard mStoryBoard;

		// Token: 0x040006CC RID: 1740
		private bool mIsImageToBeRotated;

		// Token: 0x0200010A RID: 266
		public enum State
		{
			// Token: 0x040006CE RID: 1742
			normal,
			// Token: 0x040006CF RID: 1743
			disabled
		}
	}
}
