﻿using System;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;

namespace BlueStacks.Common
{
	// Token: 0x02000183 RID: 387
	public class RenderHelper
	{
		// Token: 0x170002F1 RID: 753
		// (get) Token: 0x06000C59 RID: 3161 RVA: 0x0000B1F8 File Offset: 0x000093F8
		private static bool SoftwareOnly
		{
			get
			{
				if (RenderHelper.mSoftwareOnly == null)
				{
					RenderHelper.mSoftwareOnly = new bool?(false);
				}
				return RenderHelper.mSoftwareOnly.Value;
			}
		}

		// Token: 0x06000C5A RID: 3162 RVA: 0x0003495C File Offset: 0x00032B5C
		public static void ChangeRenderModeToSoftware(object sender)
		{
			if (RenderHelper.SoftwareOnly)
			{
				Visual visual = (Visual)sender;
				if (visual != null)
				{
					HwndSource hwndSource = PresentationSource.FromVisual(visual) as HwndSource;
					if (hwndSource != null)
					{
						Logger.Info("hwnd Source :" + sender.ToString());
						hwndSource.CompositionTarget.RenderMode = RenderMode.SoftwareOnly;
						return;
					}
					Logger.Info("sender = " + sender.ToString());
				}
			}
		}

		// Token: 0x040008A7 RID: 2215
		private static bool? mSoftwareOnly;
	}
}
