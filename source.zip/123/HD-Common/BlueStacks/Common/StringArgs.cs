﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000AA RID: 170
	public class StringArgs : EventArgs
	{
		// Token: 0x06000429 RID: 1065 RVA: 0x000044AC File Offset: 0x000026AC
		public StringArgs(string str)
		{
			this.mStr = str;
		}

		// Token: 0x040003D3 RID: 979
		public string mStr = string.Empty;
	}
}
