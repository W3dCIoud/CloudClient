﻿using System;
using System.Runtime.InteropServices;

namespace BlueStacks.Common
{
	// Token: 0x020000F6 RID: 246
	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
	public struct WIN32_FIND_DATAW
	{
		// Token: 0x04000667 RID: 1639
		public uint dwFileAttributes;

		// Token: 0x04000668 RID: 1640
		public long ftCreationTime;

		// Token: 0x04000669 RID: 1641
		public long ftLastAccessTime;

		// Token: 0x0400066A RID: 1642
		public long ftLastWriteTime;

		// Token: 0x0400066B RID: 1643
		public uint nFileSizeHigh;

		// Token: 0x0400066C RID: 1644
		public uint nFileSizeLow;

		// Token: 0x0400066D RID: 1645
		public uint dwReserved0;

		// Token: 0x0400066E RID: 1646
		public uint dwReserved1;

		// Token: 0x0400066F RID: 1647
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
		public string cFileName;

		// Token: 0x04000670 RID: 1648
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 14)]
		public string cAlternateFileName;
	}
}
