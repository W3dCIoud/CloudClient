﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;

namespace BlueStacks.Common
{
	// Token: 0x0200007E RID: 126
	public class LocaleStrings
	{
		// Token: 0x14000001 RID: 1
		// (add) Token: 0x060002AC RID: 684 RVA: 0x00011BC8 File Offset: 0x0000FDC8
		// (remove) Token: 0x060002AD RID: 685 RVA: 0x00011BFC File Offset: 0x0000FDFC
		public static event EventHandler SourceUpdatedEvent;

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x060002AE RID: 686 RVA: 0x00003604 File Offset: 0x00001804
		// (set) Token: 0x060002AF RID: 687 RVA: 0x00003619 File Offset: 0x00001819
		public static Dictionary<string, string> DictLocalizedString
		{
			get
			{
				if (LocaleStrings.sDictLocalizedString == null)
				{
					LocaleStrings.InitLocalization(null);
				}
				return LocaleStrings.sDictLocalizedString;
			}
			set
			{
				LocaleStrings.sDictLocalizedString = value;
			}
		}

		// Token: 0x060002B0 RID: 688 RVA: 0x00011C30 File Offset: 0x0000FE30
		public static bool AppendLocaleIfDoesntExist(string key, string value)
		{
			bool result = false;
			try
			{
				if (!LocaleStrings.DictLocalizedString.ContainsKey(key))
				{
					LocaleStrings.DictLocalizedString.Add(key, value);
					result = true;
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Error appending locale entry: {0}" + ex.Message);
			}
			return result;
		}

		// Token: 0x060002B1 RID: 689 RVA: 0x00003621 File Offset: 0x00001821
		public static Dictionary<string, string> InitLocalization(string localeDir)
		{
			return LocaleStrings.InitLocalization(localeDir, "Android", false, true);
		}

		// Token: 0x060002B2 RID: 690 RVA: 0x00011C88 File Offset: 0x0000FE88
		public static Dictionary<string, string> InitLocalization(string localeDir, string vmName, bool skipLocalePickFromRegistry = false, bool replaceGameNameWithBSTIfPossible = true)
		{
			if (localeDir == null)
			{
				LocaleStrings.sResourceLocation = Path.Combine(RegistryManager.Instance.UserDefinedDir, "Locales");
			}
			else
			{
				LocaleStrings.sResourceLocation = localeDir;
			}
			LocaleStrings.sDictLocalizedString = new Dictionary<string, string>(StringComparer.InvariantCultureIgnoreCase);
			LocaleStrings.sLocale = LocaleStrings.GetLocaleName(vmName, skipLocalePickFromRegistry);
			if (LocaleStrings.PopulateLocaleStrings("en-US", replaceGameNameWithBSTIfPossible))
			{
				Logger.Info("Successfully populated English strings");
			}
			if (string.Compare(LocaleStrings.sLocale, "en-US") != 0 && LocaleStrings.PopulateLocaleStrings(LocaleStrings.sLocale, replaceGameNameWithBSTIfPossible))
			{
				Logger.Info("Successfully populated localized strings for locale: " + LocaleStrings.sLocale);
			}
			EventHandler sourceUpdatedEvent = LocaleStrings.SourceUpdatedEvent;
			if (sourceUpdatedEvent != null)
			{
				sourceUpdatedEvent("Locale_Updated", null);
			}
			return LocaleStrings.sDictLocalizedString;
		}

		// Token: 0x060002B3 RID: 691 RVA: 0x00011D38 File Offset: 0x0000FF38
		public static string GetLocaleName(string vmName, bool skipLocalePickFromRegistry = false)
		{
			string text = skipLocalePickFromRegistry ? null : RegistryManager.Instance.Guest[vmName].Locale;
			if (string.IsNullOrEmpty(text))
			{
				if (FeatureManager.Instance.IsCustomUIForDMM)
				{
					return "ja-JP";
				}
				text = LocaleStrings.FindClosestMatchingLocale(Thread.CurrentThread.CurrentCulture.Name);
			}
			return text;
		}

		// Token: 0x060002B4 RID: 692 RVA: 0x00011D94 File Offset: 0x0000FF94
		public static string GetLocalizedString(string id, bool isDefaultValueEmpty = false)
		{
			string text = id.Trim();
			string text2 = LocaleStrings.RemoveConstants(id);
			try
			{
				if (LocaleStrings.sDictLocalizedString == null)
				{
					LocaleStrings.InitLocalization(null);
				}
				if (LocaleStrings.sDictLocalizedString.ContainsKey(id.ToUpper()))
				{
					text = LocaleStrings.sDictLocalizedString[id.ToUpper()];
				}
				else if (!text.Equals(text2))
				{
					text = text2;
				}
				if (isDefaultValueEmpty)
				{
					text = string.Empty;
				}
			}
			catch (Exception)
			{
				Logger.Warning("Localized string not available for: " + id);
			}
			return text;
		}

		// Token: 0x060002B5 RID: 693 RVA: 0x00011E1C File Offset: 0x0001001C
		private static bool PopulateLocaleStrings(string locale, bool replaceBSTWithGameNameIfPossible = true)
		{
			bool result;
			try
			{
				string localeFilePath = LocaleStrings.GetLocaleFilePath(locale);
				if (!File.Exists(localeFilePath))
				{
					Logger.Info(string.Format("Localization File does not exist: {0}", localeFilePath));
					result = false;
				}
				else
				{
					LocaleStrings.FillDictionary(localeFilePath, LocaleStrings.sDictLocalizedString, replaceBSTWithGameNameIfPossible);
					result = true;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Could not populate localizes strings. Error: " + ex.ToString());
				result = false;
			}
			return result;
		}

		// Token: 0x060002B6 RID: 694 RVA: 0x00003630 File Offset: 0x00001830
		internal static string RemoveConstants(string path)
		{
			if (path.Contains(Constants.ImapLocaleStringsConstant))
			{
				path = path.Replace(Constants.ImapLocaleStringsConstant, "");
				path = path.Replace("_", " ");
			}
			return path;
		}

		// Token: 0x060002B7 RID: 695 RVA: 0x00011E88 File Offset: 0x00010088
		private static string GetLocaleFilePath(string locale)
		{
			string path = string.Format("i18n.{0}.txt", locale);
			return Path.Combine(LocaleStrings.sResourceLocation, path);
		}

		// Token: 0x060002B8 RID: 696 RVA: 0x00011EAC File Offset: 0x000100AC
		private static void FillDictionary(string filePath, Dictionary<string, string> dict, bool replaceGameNameWithBSTIfPossible = true)
		{
			try
			{
				foreach (string text in File.ReadAllLines(filePath))
				{
					if (text.IndexOf("=") != -1)
					{
						string[] array2 = text.Split(new char[]
						{
							'='
						});
						string text2 = array2[1].Trim();
						if (text2.Contains("@@STRING_PRODUCT_NAME@@"))
						{
							text2 = text2.Replace("@@STRING_PRODUCT_NAME@@", Strings.ProductDisplayName);
							if ("BlueStacks" == Strings.ProductDisplayName && replaceGameNameWithBSTIfPossible && !string.IsNullOrEmpty(GameConfig.Instance.AppName))
							{
								text2 = text2.Replace("BlueStacks", GameConfig.Instance.AppName);
							}
						}
						text2 = text2.Replace("App Player App Player", "App Player");
						dict[array2[0].Trim().ToUpper()] = text2;
					}
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		// Token: 0x060002B9 RID: 697 RVA: 0x00011FA0 File Offset: 0x000101A0
		public static string FindClosestMatchingLocale(string requestedLocale)
		{
			string result = "en-US";
			Logger.Info("Finding closest locale match to {0}", new object[]
			{
				requestedLocale
			});
			try
			{
				List<string> list = LocaleStrings.sSupportedLocales.Keys.ToList<string>();
				bool flag = false;
				string twoLetterISOLanguageNameFromLocale = Utils.GetTwoLetterISOLanguageNameFromLocale(requestedLocale);
				string regionFromLocale = Utils.GetRegionFromLocale(requestedLocale);
				foreach (string text in list)
				{
					if (string.Equals(regionFromLocale, Utils.GetRegionFromLocale(text), StringComparison.InvariantCultureIgnoreCase))
					{
						Logger.Info("Match found by region: {0}", new object[]
						{
							text
						});
						result = text;
						flag = true;
						break;
					}
					if (string.Equals(twoLetterISOLanguageNameFromLocale, Utils.GetTwoLetterISOLanguageNameFromLocale(text), StringComparison.InvariantCultureIgnoreCase))
					{
						Logger.Info("Match found by ISO language name: {0}", new object[]
						{
							text
						});
						result = text;
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					Logger.Warning("No locale match could be found, defaulting to: {0}", new object[]
					{
						"en-US"
					});
					result = "en-US";
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Some error occured. Ex: {0}", new object[]
				{
					ex.ToString()
				});
				Logger.Warning("Defaulting to: {0}", new object[]
				{
					"en-US"
				});
				result = "en-US";
			}
			return result;
		}

		// Token: 0x040002DF RID: 735
		public const string DEFAULT_LOCALE = "en-US";

		// Token: 0x040002E0 RID: 736
		public static string sLocale;

		// Token: 0x040002E1 RID: 737
		public static string sResourceLocation;

		// Token: 0x040002E3 RID: 739
		public static Dictionary<string, string> sSupportedLocales = new Dictionary<string, string>
		{
			{
				"en-US",
				new CultureInfo("en-US").NativeName
			},
			{
				"ar-EG",
				new CultureInfo("ar-EG").NativeName
			},
			{
				"de-DE",
				new CultureInfo("de-DE").NativeName
			},
			{
				"es-ES",
				new CultureInfo("es-ES").NativeName
			},
			{
				"fr-FR",
				new CultureInfo("fr-FR").NativeName
			},
			{
				"it-IT",
				new CultureInfo("it-IT").NativeName
			},
			{
				"ja-JP",
				new CultureInfo("ja-JP").NativeName
			},
			{
				"ko-KR",
				new CultureInfo("ko-KR").NativeName
			},
			{
				"pl-PL",
				new CultureInfo("pl-PL").NativeName
			},
			{
				"pt-BR",
				new CultureInfo("pt-BR").NativeName
			},
			{
				"ru-RU",
				new CultureInfo("ru-RU").NativeName
			},
			{
				"th-TH",
				new CultureInfo("th-TH").NativeName
			},
			{
				"tr-TR",
				new CultureInfo("tr-TR").NativeName
			},
			{
				"vi-VN",
				new CultureInfo("vi-VN").NativeName
			},
			{
				"zh-TW",
				new CultureInfo("zh-TW").NativeName
			}
		};

		// Token: 0x040002E4 RID: 740
		public static Dictionary<string, string> sDictLocalizedString = null;
	}
}
