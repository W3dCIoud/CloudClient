﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200018F RID: 399
	public enum MultiInstanceErrorCodesEnum
	{
		// Token: 0x04000A64 RID: 2660
		ReachedMaxLimit = -1,
		// Token: 0x04000A65 RID: 2661
		CloneVmFailure = -2,
		// Token: 0x04000A66 RID: 2662
		RegistryCopyFailure = -3,
		// Token: 0x04000A67 RID: 2663
		CreateServiceFailure = -4,
		// Token: 0x04000A68 RID: 2664
		UnknownException = -5,
		// Token: 0x04000A69 RID: 2665
		CommandNotFound = -6,
		// Token: 0x04000A6A RID: 2666
		VmNameNotValid = -7,
		// Token: 0x04000A6B RID: 2667
		VmNotExist = -8,
		// Token: 0x04000A6C RID: 2668
		VmNotRunning = -9,
		// Token: 0x04000A6D RID: 2669
		CannotDeleteDefaultVm = -10,
		// Token: 0x04000A6E RID: 2670
		NotSupportedInLegacyAndRawMode = -11,
		// Token: 0x04000A6F RID: 2671
		VirtualBoxInitFailed = -12,
		// Token: 0x04000A70 RID: 2672
		NotSupportedInLegacyMode = -13,
		// Token: 0x04000A71 RID: 2673
		WrongValue = -14,
		// Token: 0x04000A72 RID: 2674
		DeviceCapsNotPresent = -15,
		// Token: 0x04000A73 RID: 2675
		FactoryResetUnHandledException = -16,
		// Token: 0x04000A74 RID: 2676
		ProcessAlreadyRunning = -17,
		// Token: 0x04000A75 RID: 2677
		InvalidVmType = -18,
		// Token: 0x04000A76 RID: 2678
		CannotCloneRunningVm = -19
	}
}
