﻿using System;
using System.IO;
using System.Text;

namespace BlueStacks.Common
{
	// Token: 0x02000188 RID: 392
	public class _MD5
	{
		// Token: 0x170002F8 RID: 760
		// (set) Token: 0x06000C70 RID: 3184 RVA: 0x0000B373 File Offset: 0x00009573
		public string Value
		{
			set
			{
				this.ValueAsByte = Encoding.ASCII.GetBytes(value);
			}
		}

		// Token: 0x170002F9 RID: 761
		// (set) Token: 0x06000C71 RID: 3185 RVA: 0x00034BCC File Offset: 0x00032DCC
		public byte[] ValueAsByte
		{
			set
			{
				this.m_byteInput = new byte[value.Length];
				for (int i = 0; i < value.Length; i++)
				{
					this.m_byteInput[i] = value[i];
				}
				this.CalculateMD5Value();
			}
		}

		// Token: 0x170002FA RID: 762
		// (get) Token: 0x06000C72 RID: 3186 RVA: 0x0000B386 File Offset: 0x00009586
		public string FingerPrint
		{
			get
			{
				return this.dg.GetString();
			}
		}

		// Token: 0x06000C73 RID: 3187 RVA: 0x0000B393 File Offset: 0x00009593
		public _MD5()
		{
			this.dg = new Digest();
		}

		// Token: 0x170002FB RID: 763
		// (set) Token: 0x06000C74 RID: 3188 RVA: 0x00034C08 File Offset: 0x00032E08
		public string ValueAsFile
		{
			set
			{
				int num = 65536;
				byte[] array = new byte[num];
				uint num2 = 0U;
				new byte[0];
				using (Stream stream = File.OpenRead(value))
				{
					int num3;
					while ((num3 = stream.Read(array, 0, num)) == num)
					{
						num2 += 1U;
						this.TransformBlock(array);
					}
					byte[] array2 = new byte[0];
					if (num3 != 0)
					{
						array2 = new byte[num3];
						for (int i = 0; i < num3; i++)
						{
							array2[i] = array[i];
						}
					}
					ulong totalSize = (ulong)num2 * (ulong)((long)num) + (ulong)((long)num3);
					this.TransformBlock(this.GetLastPaddedBuffer(totalSize, array2));
				}
			}
		}

		// Token: 0x06000C75 RID: 3189 RVA: 0x00034CB8 File Offset: 0x00032EB8
		public void TransformBlock(byte[] block)
		{
			uint num = (uint)(block.Length * 8 / 32);
			for (uint num2 = 0U; num2 < num / 16U; num2 += 1U)
			{
				this.CopyBlock(block, num2);
				this.PerformTransformation(ref this.dg.A, ref this.dg.B, ref this.dg.C, ref this.dg.D);
			}
		}

		// Token: 0x06000C76 RID: 3190 RVA: 0x00034D18 File Offset: 0x00032F18
		protected byte[] GetLastPaddedBuffer(ulong totalSize, byte[] buffer)
		{
			uint num = (uint)((448 - buffer.Length * 8 % 512 + 512) % 512);
			if (num == 0U)
			{
				num = 512U;
			}
			uint num2 = (uint)((long)buffer.Length + (long)((ulong)(num / 8U)) + 8L);
			ulong num3 = totalSize * 8UL;
			byte[] array = new byte[num2];
			for (int i = 0; i < buffer.Length; i++)
			{
				array[i] = buffer[i];
			}
			byte[] array2 = array;
			int num4 = buffer.Length;
			array2[num4] |= 128;
			for (int j = 8; j > 0; j--)
			{
				array[(int)(checked((IntPtr)(unchecked((ulong)num2 - (ulong)((long)j)))))] = (byte)(num3 >> (8 - j) * 8 & 255UL);
			}
			return array;
		}

		// Token: 0x06000C77 RID: 3191 RVA: 0x00034DC0 File Offset: 0x00032FC0
		protected void CalculateMD5Value()
		{
			byte[] array = this.CreatePaddedBuffer();
			uint num = (uint)(array.Length * 8 / 32);
			for (uint num2 = 0U; num2 < num / 16U; num2 += 1U)
			{
				this.CopyBlock(array, num2);
				this.PerformTransformation(ref this.dg.A, ref this.dg.B, ref this.dg.C, ref this.dg.D);
			}
		}

		// Token: 0x06000C78 RID: 3192 RVA: 0x0000B3B3 File Offset: 0x000095B3
		protected void TransF(ref uint a, uint b, uint c, uint d, uint k, ushort s, uint i)
		{
			a = b + _MD5.RotateLeft(a + ((b & c) | (~b & d)) + this.X[(int)k] + _MD5.T[(int)(i - 1U)], s);
		}

		// Token: 0x06000C79 RID: 3193 RVA: 0x0000B3E1 File Offset: 0x000095E1
		protected void TransG(ref uint a, uint b, uint c, uint d, uint k, ushort s, uint i)
		{
			a = b + _MD5.RotateLeft(a + ((b & d) | (c & ~d)) + this.X[(int)k] + _MD5.T[(int)(i - 1U)], s);
		}

		// Token: 0x06000C7A RID: 3194 RVA: 0x0000B410 File Offset: 0x00009610
		protected void TransH(ref uint a, uint b, uint c, uint d, uint k, ushort s, uint i)
		{
			a = b + _MD5.RotateLeft(a + (b ^ c ^ d) + this.X[(int)k] + _MD5.T[(int)(i - 1U)], s);
		}

		// Token: 0x06000C7B RID: 3195 RVA: 0x0000B43B File Offset: 0x0000963B
		protected void TransI(ref uint a, uint b, uint c, uint d, uint k, ushort s, uint i)
		{
			a = b + _MD5.RotateLeft(a + (c ^ (b | ~d)) + this.X[(int)k] + _MD5.T[(int)(i - 1U)], s);
		}

		// Token: 0x06000C7C RID: 3196 RVA: 0x00034E28 File Offset: 0x00033028
		protected void PerformTransformation(ref uint A, ref uint B, ref uint C, ref uint D)
		{
			uint num = A;
			uint num2 = B;
			uint num3 = C;
			uint num4 = D;
			this.TransF(ref A, B, C, D, 0U, 7, 1U);
			this.TransF(ref D, A, B, C, 1U, 12, 2U);
			this.TransF(ref C, D, A, B, 2U, 17, 3U);
			this.TransF(ref B, C, D, A, 3U, 22, 4U);
			this.TransF(ref A, B, C, D, 4U, 7, 5U);
			this.TransF(ref D, A, B, C, 5U, 12, 6U);
			this.TransF(ref C, D, A, B, 6U, 17, 7U);
			this.TransF(ref B, C, D, A, 7U, 22, 8U);
			this.TransF(ref A, B, C, D, 8U, 7, 9U);
			this.TransF(ref D, A, B, C, 9U, 12, 10U);
			this.TransF(ref C, D, A, B, 10U, 17, 11U);
			this.TransF(ref B, C, D, A, 11U, 22, 12U);
			this.TransF(ref A, B, C, D, 12U, 7, 13U);
			this.TransF(ref D, A, B, C, 13U, 12, 14U);
			this.TransF(ref C, D, A, B, 14U, 17, 15U);
			this.TransF(ref B, C, D, A, 15U, 22, 16U);
			this.TransG(ref A, B, C, D, 1U, 5, 17U);
			this.TransG(ref D, A, B, C, 6U, 9, 18U);
			this.TransG(ref C, D, A, B, 11U, 14, 19U);
			this.TransG(ref B, C, D, A, 0U, 20, 20U);
			this.TransG(ref A, B, C, D, 5U, 5, 21U);
			this.TransG(ref D, A, B, C, 10U, 9, 22U);
			this.TransG(ref C, D, A, B, 15U, 14, 23U);
			this.TransG(ref B, C, D, A, 4U, 20, 24U);
			this.TransG(ref A, B, C, D, 9U, 5, 25U);
			this.TransG(ref D, A, B, C, 14U, 9, 26U);
			this.TransG(ref C, D, A, B, 3U, 14, 27U);
			this.TransG(ref B, C, D, A, 8U, 20, 28U);
			this.TransG(ref A, B, C, D, 13U, 5, 29U);
			this.TransG(ref D, A, B, C, 2U, 9, 30U);
			this.TransG(ref C, D, A, B, 7U, 14, 31U);
			this.TransG(ref B, C, D, A, 12U, 20, 32U);
			this.TransH(ref A, B, C, D, 5U, 4, 33U);
			this.TransH(ref D, A, B, C, 8U, 11, 34U);
			this.TransH(ref C, D, A, B, 11U, 16, 35U);
			this.TransH(ref B, C, D, A, 14U, 23, 36U);
			this.TransH(ref A, B, C, D, 1U, 4, 37U);
			this.TransH(ref D, A, B, C, 4U, 11, 38U);
			this.TransH(ref C, D, A, B, 7U, 16, 39U);
			this.TransH(ref B, C, D, A, 10U, 23, 40U);
			this.TransH(ref A, B, C, D, 13U, 4, 41U);
			this.TransH(ref D, A, B, C, 0U, 11, 42U);
			this.TransH(ref C, D, A, B, 3U, 16, 43U);
			this.TransH(ref B, C, D, A, 6U, 23, 44U);
			this.TransH(ref A, B, C, D, 9U, 4, 45U);
			this.TransH(ref D, A, B, C, 12U, 11, 46U);
			this.TransH(ref C, D, A, B, 15U, 16, 47U);
			this.TransH(ref B, C, D, A, 2U, 23, 48U);
			this.TransI(ref A, B, C, D, 0U, 6, 49U);
			this.TransI(ref D, A, B, C, 7U, 10, 50U);
			this.TransI(ref C, D, A, B, 14U, 15, 51U);
			this.TransI(ref B, C, D, A, 5U, 21, 52U);
			this.TransI(ref A, B, C, D, 12U, 6, 53U);
			this.TransI(ref D, A, B, C, 3U, 10, 54U);
			this.TransI(ref C, D, A, B, 10U, 15, 55U);
			this.TransI(ref B, C, D, A, 1U, 21, 56U);
			this.TransI(ref A, B, C, D, 8U, 6, 57U);
			this.TransI(ref D, A, B, C, 15U, 10, 58U);
			this.TransI(ref C, D, A, B, 6U, 15, 59U);
			this.TransI(ref B, C, D, A, 13U, 21, 60U);
			this.TransI(ref A, B, C, D, 4U, 6, 61U);
			this.TransI(ref D, A, B, C, 11U, 10, 62U);
			this.TransI(ref C, D, A, B, 2U, 15, 63U);
			this.TransI(ref B, C, D, A, 9U, 21, 64U);
			A += num;
			B += num2;
			C += num3;
			D += num4;
		}

		// Token: 0x06000C7D RID: 3197 RVA: 0x00035320 File Offset: 0x00033520
		protected byte[] CreatePaddedBuffer()
		{
			uint num = (uint)((448 - this.m_byteInput.Length * 8 % 512 + 512) % 512);
			if (num == 0U)
			{
				num = 512U;
			}
			uint num2 = (uint)((long)this.m_byteInput.Length + (long)((ulong)(num / 8U)) + 8L);
			ulong num3 = (ulong)((long)this.m_byteInput.Length * 8L);
			byte[] array = new byte[num2];
			for (int i = 0; i < this.m_byteInput.Length; i++)
			{
				array[i] = this.m_byteInput[i];
			}
			byte[] array2 = array;
			int num4 = this.m_byteInput.Length;
			array2[num4] |= 128;
			for (int j = 8; j > 0; j--)
			{
				array[(int)(checked((IntPtr)(unchecked((ulong)num2 - (ulong)((long)j)))))] = (byte)(num3 >> (8 - j) * 8 & 255UL);
			}
			return array;
		}

		// Token: 0x06000C7E RID: 3198 RVA: 0x000353EC File Offset: 0x000335EC
		protected void CopyBlock(byte[] bMsg, uint block)
		{
			block <<= 6;
			for (uint num = 0U; num < 61U; num += 4U)
			{
				this.X[(int)(num >> 2)] = (uint)((int)bMsg[(int)(block + (num + 3U))] << 24 | (int)bMsg[(int)(block + (num + 2U))] << 16 | (int)bMsg[(int)(block + (num + 1U))] << 8 | (int)bMsg[(int)(block + num)]);
			}
		}

		// Token: 0x06000C7F RID: 3199 RVA: 0x0000B467 File Offset: 0x00009667
		public static uint RotateLeft(uint uiNumber, ushort shift)
		{
			return uiNumber >> (int)(32 - shift) | uiNumber << (int)shift;
		}

		// Token: 0x040009B5 RID: 2485
		private static readonly uint[] T = new uint[]
		{
			3614090360U,
			3905402710U,
			606105819U,
			3250441966U,
			4118548399U,
			1200080426U,
			2821735955U,
			4249261313U,
			1770035416U,
			2336552879U,
			4294925233U,
			2304563134U,
			1804603682U,
			4254626195U,
			2792965006U,
			1236535329U,
			4129170786U,
			3225465664U,
			643717713U,
			3921069994U,
			3593408605U,
			38016083U,
			3634488961U,
			3889429448U,
			568446438U,
			3275163606U,
			4107603335U,
			1163531501U,
			2850285829U,
			4243563512U,
			1735328473U,
			2368359562U,
			4294588738U,
			2272392833U,
			1839030562U,
			4259657740U,
			2763975236U,
			1272893353U,
			4139469664U,
			3200236656U,
			681279174U,
			3936430074U,
			3572445317U,
			76029189U,
			3654602809U,
			3873151461U,
			530742520U,
			3299628645U,
			4096336452U,
			1126891415U,
			2878612391U,
			4237533241U,
			1700485571U,
			2399980690U,
			4293915773U,
			2240044497U,
			1873313359U,
			4264355552U,
			2734768916U,
			1309151649U,
			4149444226U,
			3174756917U,
			718787259U,
			3951481745U
		};

		// Token: 0x040009B6 RID: 2486
		protected uint[] X = new uint[16];

		// Token: 0x040009B7 RID: 2487
		protected byte[] m_byteInput;

		// Token: 0x040009B8 RID: 2488
		private Digest dg;
	}
}
