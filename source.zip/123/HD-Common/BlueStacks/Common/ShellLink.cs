﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace BlueStacks.Common
{
	// Token: 0x020000F7 RID: 247
	[Guid("00021401-0000-0000-C000-000000000046")]
	[ComImport]
	public class ShellLink
	{
		// Token: 0x060008A6 RID: 2214
		[MethodImpl(MethodImplOptions.InternalCall)]
		public extern ShellLink();
	}
}
