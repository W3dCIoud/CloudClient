﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace BlueStacks.Common
{
	// Token: 0x020000C3 RID: 195
	public static class IconHelper
	{
		// Token: 0x0600064E RID: 1614 RVA: 0x0001E6E8 File Offset: 0x0001C8E8
		public static bool ConvertToIcon(Stream input, Stream output, int size = 16, bool preserveAspectRatio = false)
		{
			Bitmap bitmap = (Bitmap)Image.FromStream(input);
			if (bitmap == null)
			{
				return false;
			}
			float num = (float)size;
			float num2 = (float)size;
			if (preserveAspectRatio)
			{
				if (bitmap.Width > bitmap.Height)
				{
					num2 = (float)bitmap.Height / (float)bitmap.Width * (float)size;
				}
				else
				{
					num = (float)bitmap.Width / (float)bitmap.Height * (float)size;
				}
			}
			Bitmap bitmap2 = new Bitmap(bitmap, new Size((int)num, (int)num2));
			if (bitmap2 == null)
			{
				return false;
			}
			using (MemoryStream memoryStream = new MemoryStream())
			{
				bitmap2.Save(memoryStream, ImageFormat.Png);
				BinaryWriter binaryWriter = new BinaryWriter(output);
				if (output == null || binaryWriter == null)
				{
					return false;
				}
				binaryWriter.Write(0);
				binaryWriter.Write(0);
				binaryWriter.Write(1);
				binaryWriter.Write(1);
				binaryWriter.Write((byte)num);
				binaryWriter.Write((byte)num2);
				binaryWriter.Write(0);
				binaryWriter.Write(0);
				binaryWriter.Write(0);
				binaryWriter.Write(32);
				binaryWriter.Write((int)memoryStream.Length);
				binaryWriter.Write(22);
				binaryWriter.Write(memoryStream.ToArray());
				binaryWriter.Flush();
				binaryWriter.Close();
			}
			return true;
		}

		// Token: 0x0600064F RID: 1615 RVA: 0x0001E834 File Offset: 0x0001CA34
		public static bool ConvertToIcon(string inputPath, string outputPath, int size = 16, bool preserveAspectRatio = false)
		{
			bool result;
			using (FileStream fileStream = new FileStream(inputPath, FileMode.Open, FileAccess.Read))
			{
				using (FileStream fileStream2 = new FileStream(outputPath, FileMode.OpenOrCreate))
				{
					result = IconHelper.ConvertToIcon(fileStream, fileStream2, size, preserveAspectRatio);
				}
			}
			return result;
		}

		// Token: 0x06000650 RID: 1616 RVA: 0x0001E890 File Offset: 0x0001CA90
		public static byte[] ConvertToIcon(Image image, bool preserveAspectRatio = false)
		{
			MemoryStream memoryStream = new MemoryStream();
			image.Save(memoryStream, ImageFormat.Png);
			memoryStream.Seek(0L, SeekOrigin.Begin);
			MemoryStream memoryStream2 = new MemoryStream();
			int width = image.Size.Width;
			if (!IconHelper.ConvertToIcon(memoryStream, memoryStream2, width, preserveAspectRatio))
			{
				return null;
			}
			return memoryStream2.ToArray();
		}
	}
}
