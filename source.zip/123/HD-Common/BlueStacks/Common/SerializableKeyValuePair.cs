﻿using System;
using System.Text;

namespace BlueStacks.Common
{
	// Token: 0x020000EF RID: 239
	[Serializable]
	public struct SerializableKeyValuePair<TKey, TValue>
	{
		// Token: 0x06000883 RID: 2179 RVA: 0x000094E1 File Offset: 0x000076E1
		public SerializableKeyValuePair(TKey key, TValue value)
		{
			this.key = key;
			this.value = value;
		}

		// Token: 0x1700029E RID: 670
		// (get) Token: 0x06000884 RID: 2180 RVA: 0x000094F1 File Offset: 0x000076F1
		// (set) Token: 0x06000885 RID: 2181 RVA: 0x000094F9 File Offset: 0x000076F9
		public TKey Key
		{
			get
			{
				return this.key;
			}
			set
			{
				this.key = value;
			}
		}

		// Token: 0x1700029F RID: 671
		// (get) Token: 0x06000886 RID: 2182 RVA: 0x00009502 File Offset: 0x00007702
		// (set) Token: 0x06000887 RID: 2183 RVA: 0x0000950A File Offset: 0x0000770A
		public TValue Value
		{
			get
			{
				return this.value;
			}
			set
			{
				this.value = value;
			}
		}

		// Token: 0x06000888 RID: 2184 RVA: 0x00023C54 File Offset: 0x00021E54
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append('[');
			if (this.Key != null)
			{
				StringBuilder stringBuilder2 = stringBuilder;
				TKey tkey = this.Key;
				stringBuilder2.Append(tkey.ToString());
			}
			stringBuilder.Append(", ");
			if (this.Value != null)
			{
				StringBuilder stringBuilder3 = stringBuilder;
				TValue tvalue = this.Value;
				stringBuilder3.Append(tvalue.ToString());
			}
			stringBuilder.Append(']');
			return stringBuilder.ToString();
		}

		// Token: 0x0400065A RID: 1626
		private TKey key;

		// Token: 0x0400065B RID: 1627
		private TValue value;
	}
}
