﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200006F RID: 111
	public enum MuteState
	{
		// Token: 0x04000166 RID: 358
		NotMuted,
		// Token: 0x04000167 RID: 359
		AutoHide,
		// Token: 0x04000168 RID: 360
		MutedFor1Hour,
		// Token: 0x04000169 RID: 361
		MutedFor1Day,
		// Token: 0x0400016A RID: 362
		MutedFor1Week,
		// Token: 0x0400016B RID: 363
		MutedForever
	}
}
