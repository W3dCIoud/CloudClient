﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x02000068 RID: 104
	public static class MultiInstanceUtils
	{
		// Token: 0x0600022F RID: 559 RVA: 0x000103A8 File Offset: 0x0000E5A8
		public static bool VerifyVmId(string vmId)
		{
			string[] vmList = RegistryManager.Instance.VmList;
			for (int i = 0; i < vmList.Length; i++)
			{
				if (vmList[i].Equals(vmId, StringComparison.OrdinalIgnoreCase))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x06000230 RID: 560 RVA: 0x00003182 File Offset: 0x00001382
		public static void SetDeviceCapsRegistry(string legacyReason, string engine)
		{
			MultiInstanceUtils.SetDeviceCapsRegistry(legacyReason, engine, CpuHvmState.Unknown, BiosHvmState.Unknown);
		}

		// Token: 0x06000231 RID: 561 RVA: 0x000103E0 File Offset: 0x0000E5E0
		public static void SetDeviceCapsRegistry(string legacyReason, string engine, CpuHvmState cpuHvm, BiosHvmState biosHvm)
		{
			string deviceCaps = RegistryManager.Instance.DeviceCaps;
			JObject jobject = new JObject();
			jobject.Add("engine_enabled", engine);
			jobject.Add("legacy_reason", legacyReason);
			jobject.Add("cpu_hvm", cpuHvm.ToString());
			jobject.Add("bios_hvm", biosHvm.ToString());
			JObject jobject2 = JObject.Parse(deviceCaps);
			if (!deviceCaps.Equals(""))
			{
				string text = jobject2["engine_enabled"].ToString();
				Logger.Info("Old engine was {0}", new object[]
				{
					text
				});
				if (!text.Equals(engine))
				{
					RegistryManager.Instance.SystemInfoStats2 = 1;
				}
			}
			RegistryManager.Instance.CurrentEngine = engine;
			RegistryManager.Instance.DeviceCaps = jobject.ToString(Formatting.None, new JsonConverter[0]);
		}
	}
}
