﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace BlueStacks.Common
{
	// Token: 0x020000EE RID: 238
	[XmlRoot("dictionary")]
	[Serializable]
	public class SerializableDictionary<TKey, TValue> : Dictionary<TKey, TValue>, IXmlSerializable
	{
		// Token: 0x0600087B RID: 2171 RVA: 0x000094B9 File Offset: 0x000076B9
		public SerializableDictionary()
		{
		}

		// Token: 0x0600087C RID: 2172 RVA: 0x000094C1 File Offset: 0x000076C1
		public SerializableDictionary(IEqualityComparer<TKey> comparer) : base(comparer)
		{
		}

		// Token: 0x0600087D RID: 2173 RVA: 0x000094CA File Offset: 0x000076CA
		public SerializableDictionary(IDictionary<TKey, TValue> dictionary, IEqualityComparer<TKey> comparer) : base(dictionary, comparer)
		{
		}

		// Token: 0x0600087E RID: 2174 RVA: 0x000094D4 File Offset: 0x000076D4
		protected SerializableDictionary(SerializationInfo info, StreamingContext context) : base(info, context)
		{
		}

		// Token: 0x0600087F RID: 2175 RVA: 0x000094DE File Offset: 0x000076DE
		public XmlSchema GetSchema()
		{
			return null;
		}

		// Token: 0x06000880 RID: 2176 RVA: 0x00023A8C File Offset: 0x00021C8C
		public void ReadXml(XmlReader reader)
		{
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(TKey));
			XmlSerializer xmlSerializer2 = new XmlSerializer(typeof(TValue));
			bool isEmptyElement = reader.IsEmptyElement;
			reader.Read();
			if (isEmptyElement)
			{
				return;
			}
			while (reader.NodeType != XmlNodeType.EndElement)
			{
				reader.ReadStartElement("item");
				reader.ReadStartElement("key");
				TKey key = (TKey)((object)xmlSerializer.Deserialize(reader));
				reader.ReadEndElement();
				reader.ReadStartElement("value");
				TValue value = (TValue)((object)xmlSerializer2.Deserialize(reader));
				reader.ReadEndElement();
				base.Add(key, value);
				reader.ReadEndElement();
				reader.MoveToContent();
			}
			reader.ReadEndElement();
		}

		// Token: 0x06000881 RID: 2177 RVA: 0x00023B38 File Offset: 0x00021D38
		public void WriteXml(XmlWriter writer)
		{
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(TKey));
			XmlSerializer xmlSerializer2 = new XmlSerializer(typeof(TValue));
			foreach (TKey tkey in base.Keys)
			{
				writer.WriteStartElement("item");
				writer.WriteStartElement("key");
				xmlSerializer.Serialize(writer, tkey);
				writer.WriteEndElement();
				writer.WriteStartElement("value");
				TValue tvalue = base[tkey];
				xmlSerializer2.Serialize(writer, tvalue);
				writer.WriteEndElement();
				writer.WriteEndElement();
			}
		}

		// Token: 0x06000882 RID: 2178 RVA: 0x00023BFC File Offset: 0x00021DFC
		public virtual object Clone()
		{
			base.GetType();
			IFormatter formatter = new BinaryFormatter();
			object result;
			using (Stream stream = new MemoryStream())
			{
				formatter.Serialize(stream, this);
				stream.Seek(0L, SeekOrigin.Begin);
				result = formatter.Deserialize(stream);
			}
			return result;
		}
	}
}
