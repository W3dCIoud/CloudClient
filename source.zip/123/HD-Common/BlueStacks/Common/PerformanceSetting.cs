﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000DB RID: 219
	public enum PerformanceSetting
	{
		// Token: 0x0400056B RID: 1387
		High,
		// Token: 0x0400056C RID: 1388
		Medium,
		// Token: 0x0400056D RID: 1389
		Low,
		// Token: 0x0400056E RID: 1390
		Custom
	}
}
