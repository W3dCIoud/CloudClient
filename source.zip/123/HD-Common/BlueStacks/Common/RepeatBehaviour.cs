﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000C4 RID: 196
	public enum RepeatBehaviour
	{
		// Token: 0x040004D6 RID: 1238
		Once,
		// Token: 0x040004D7 RID: 1239
		For5Minutes,
		// Token: 0x040004D8 RID: 1240
		For1hour,
		// Token: 0x040004D9 RID: 1241
		For8Hour,
		// Token: 0x040004DA RID: 1242
		Forever
	}
}
