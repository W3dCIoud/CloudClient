﻿using System;
using System.Linq;

namespace BlueStacks.Common
{
	// Token: 0x02000172 RID: 370
	public static class StringUtils
	{
		// Token: 0x06000BF6 RID: 3062 RVA: 0x0000AEB3 File Offset: 0x000090B3
		public static string GetControlCharFreeString(string s)
		{
			return new string((from c in s
			where !char.IsControl(c)
			select c).ToArray<char>());
		}
	}
}
