﻿using System;
using System.Threading;

namespace BlueStacks.Common
{
	// Token: 0x0200018A RID: 394
	public class Countdown
	{
		// Token: 0x06000C82 RID: 3202 RVA: 0x0000B492 File Offset: 0x00009692
		public Countdown()
		{
		}

		// Token: 0x06000C83 RID: 3203 RVA: 0x0000B4A5 File Offset: 0x000096A5
		public Countdown(int initialCount)
		{
			this._value = initialCount;
		}

		// Token: 0x06000C84 RID: 3204 RVA: 0x0000B4BF File Offset: 0x000096BF
		public void Signal()
		{
			this.AddCount(-1);
		}

		// Token: 0x06000C85 RID: 3205 RVA: 0x0003543C File Offset: 0x0003363C
		public void AddCount(int amount)
		{
			object locker = this._locker;
			lock (locker)
			{
				this._value += amount;
				if (this._value <= 0)
				{
					Monitor.PulseAll(this._locker);
				}
			}
		}

		// Token: 0x06000C86 RID: 3206 RVA: 0x00035494 File Offset: 0x00033694
		public void Wait()
		{
			object locker = this._locker;
			lock (locker)
			{
				while (this._value > 0)
				{
					Monitor.Wait(this._locker);
				}
			}
		}

		// Token: 0x040009E4 RID: 2532
		private object _locker = new object();

		// Token: 0x040009E5 RID: 2533
		private int _value;
	}
}
