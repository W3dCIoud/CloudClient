﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000E9 RID: 233
	internal enum PerformanceProperty
	{
		// Token: 0x04000651 RID: 1617
		RAM,
		// Token: 0x04000652 RID: 1618
		CPUCores
	}
}
