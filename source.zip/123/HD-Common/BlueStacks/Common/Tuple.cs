﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200019F RID: 415
	public class Tuple<T1>
	{
		// Token: 0x06000CCC RID: 3276 RVA: 0x0000B641 File Offset: 0x00009841
		public Tuple(T1 item1)
		{
			this.Item1 = item1;
		}

		// Token: 0x170002FE RID: 766
		// (get) Token: 0x06000CCD RID: 3277 RVA: 0x0000B650 File Offset: 0x00009850
		// (set) Token: 0x06000CCE RID: 3278 RVA: 0x0000B658 File Offset: 0x00009858
		public T1 Item1 { get; set; }
	}
}
