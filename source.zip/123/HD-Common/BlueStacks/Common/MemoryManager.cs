﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;

namespace BlueStacks.Common
{
	// Token: 0x02000061 RID: 97
	public class MemoryManager
	{
		// Token: 0x0600020E RID: 526
		[DllImport("KERNEL32.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "SetProcessWorkingSetSize", SetLastError = true)]
		private static extern bool SetProcessWorkingSetSize32(IntPtr pProcess, int dwMinimumWorkingSetSize, int dwMaximumWorkingSetSize);

		// Token: 0x0600020F RID: 527
		[DllImport("KERNEL32.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "SetProcessWorkingSetSize", SetLastError = true)]
		private static extern bool SetProcessWorkingSetSize64(IntPtr pProcess, long dwMinimumWorkingSetSize, long dwMaximumWorkingSetSize);

		// Token: 0x06000210 RID: 528
		[DllImport("psapi.dll")]
		private static extern int EmptyWorkingSet(IntPtr hwProc);

		// Token: 0x06000211 RID: 529 RVA: 0x0000309B File Offset: 0x0000129B
		public void TrimMemory()
		{
			new Thread(delegate()
			{
				int num = RegistryManager.Instance.TrimMemoryDuration * 1000;
				Logger.Info("Setting trim memory duration to: " + num);
				for (;;)
				{
					Thread.Sleep(num);
					try
					{
						GC.Collect(2, GCCollectionMode.Forced);
						GC.WaitForPendingFinalizers();
						if (Environment.OSVersion.Platform == PlatformID.Win32NT)
						{
							if (IntPtr.Size == 8)
							{
								MemoryManager.SetProcessWorkingSetSize64(Process.GetCurrentProcess().Handle, -1L, -1L);
							}
							else
							{
								MemoryManager.SetProcessWorkingSetSize32(Process.GetCurrentProcess().Handle, -1, -1);
							}
						}
						using (Process currentProcess = Process.GetCurrentProcess())
						{
							Logger.Debug("Trimming memory");
							MemoryManager.EmptyWorkingSet(currentProcess.Handle);
						}
					}
					catch (Exception ex)
					{
						Logger.Error("Exception while trimming memory ex: " + ex.ToString());
					}
				}
			})
			{
				IsBackground = true
			}.Start();
		}
	}
}
