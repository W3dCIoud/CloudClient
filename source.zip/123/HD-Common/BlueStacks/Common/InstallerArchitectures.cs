﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200016F RID: 367
	public class InstallerArchitectures
	{
		// Token: 0x170002E9 RID: 745
		// (get) Token: 0x06000BDF RID: 3039 RVA: 0x0000AD81 File Offset: 0x00008F81
		public static string AMD64
		{
			get
			{
				return "amd64";
			}
		}

		// Token: 0x170002EA RID: 746
		// (get) Token: 0x06000BE0 RID: 3040 RVA: 0x0000AD88 File Offset: 0x00008F88
		public static string X86
		{
			get
			{
				return "x86";
			}
		}
	}
}
