﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x020001B9 RID: 441
	internal class GifPlainTextExtension : GifExtension
	{
		// Token: 0x17000336 RID: 822
		// (get) Token: 0x06000D93 RID: 3475 RVA: 0x0000BC64 File Offset: 0x00009E64
		// (set) Token: 0x06000D94 RID: 3476 RVA: 0x0000BC6C File Offset: 0x00009E6C
		public int BlockSize { get; private set; }

		// Token: 0x17000337 RID: 823
		// (get) Token: 0x06000D95 RID: 3477 RVA: 0x0000BC75 File Offset: 0x00009E75
		// (set) Token: 0x06000D96 RID: 3478 RVA: 0x0000BC7D File Offset: 0x00009E7D
		public int Left { get; private set; }

		// Token: 0x17000338 RID: 824
		// (get) Token: 0x06000D97 RID: 3479 RVA: 0x0000BC86 File Offset: 0x00009E86
		// (set) Token: 0x06000D98 RID: 3480 RVA: 0x0000BC8E File Offset: 0x00009E8E
		public int Top { get; private set; }

		// Token: 0x17000339 RID: 825
		// (get) Token: 0x06000D99 RID: 3481 RVA: 0x0000BC97 File Offset: 0x00009E97
		// (set) Token: 0x06000D9A RID: 3482 RVA: 0x0000BC9F File Offset: 0x00009E9F
		public int Width { get; private set; }

		// Token: 0x1700033A RID: 826
		// (get) Token: 0x06000D9B RID: 3483 RVA: 0x0000BCA8 File Offset: 0x00009EA8
		// (set) Token: 0x06000D9C RID: 3484 RVA: 0x0000BCB0 File Offset: 0x00009EB0
		public int Height { get; private set; }

		// Token: 0x1700033B RID: 827
		// (get) Token: 0x06000D9D RID: 3485 RVA: 0x0000BCB9 File Offset: 0x00009EB9
		// (set) Token: 0x06000D9E RID: 3486 RVA: 0x0000BCC1 File Offset: 0x00009EC1
		public int CellWidth { get; private set; }

		// Token: 0x1700033C RID: 828
		// (get) Token: 0x06000D9F RID: 3487 RVA: 0x0000BCCA File Offset: 0x00009ECA
		// (set) Token: 0x06000DA0 RID: 3488 RVA: 0x0000BCD2 File Offset: 0x00009ED2
		public int CellHeight { get; private set; }

		// Token: 0x1700033D RID: 829
		// (get) Token: 0x06000DA1 RID: 3489 RVA: 0x0000BCDB File Offset: 0x00009EDB
		// (set) Token: 0x06000DA2 RID: 3490 RVA: 0x0000BCE3 File Offset: 0x00009EE3
		public int ForegroundColorIndex { get; private set; }

		// Token: 0x1700033E RID: 830
		// (get) Token: 0x06000DA3 RID: 3491 RVA: 0x0000BCEC File Offset: 0x00009EEC
		// (set) Token: 0x06000DA4 RID: 3492 RVA: 0x0000BCF4 File Offset: 0x00009EF4
		public int BackgroundColorIndex { get; private set; }

		// Token: 0x1700033F RID: 831
		// (get) Token: 0x06000DA5 RID: 3493 RVA: 0x0000BCFD File Offset: 0x00009EFD
		// (set) Token: 0x06000DA6 RID: 3494 RVA: 0x0000BD05 File Offset: 0x00009F05
		public string Text { get; private set; }

		// Token: 0x17000340 RID: 832
		// (get) Token: 0x06000DA7 RID: 3495 RVA: 0x0000BD0E File Offset: 0x00009F0E
		// (set) Token: 0x06000DA8 RID: 3496 RVA: 0x0000BD16 File Offset: 0x00009F16
		public IList<GifExtension> Extensions { get; private set; }

		// Token: 0x06000DA9 RID: 3497 RVA: 0x0000B802 File Offset: 0x00009A02
		private GifPlainTextExtension()
		{
		}

		// Token: 0x17000341 RID: 833
		// (get) Token: 0x06000DAA RID: 3498 RVA: 0x0000AC7B File Offset: 0x00008E7B
		internal override GifBlockKind Kind
		{
			get
			{
				return GifBlockKind.GraphicRendering;
			}
		}

		// Token: 0x06000DAB RID: 3499 RVA: 0x0000BD1F File Offset: 0x00009F1F
		internal static GifPlainTextExtension ReadPlainText(Stream stream, IEnumerable<GifExtension> controlExtensions, bool metadataOnly)
		{
			GifPlainTextExtension gifPlainTextExtension = new GifPlainTextExtension();
			gifPlainTextExtension.Read(stream, controlExtensions, metadataOnly);
			return gifPlainTextExtension;
		}

		// Token: 0x06000DAC RID: 3500 RVA: 0x00037CB4 File Offset: 0x00035EB4
		private void Read(Stream stream, IEnumerable<GifExtension> controlExtensions, bool metadataOnly)
		{
			byte[] array = new byte[13];
			stream.ReadAll(array, 0, array.Length);
			this.BlockSize = (int)array[0];
			if (this.BlockSize != 12)
			{
				throw GifHelpers.InvalidBlockSizeException("Plain Text Extension", 12, this.BlockSize);
			}
			this.Left = (int)BitConverter.ToUInt16(array, 1);
			this.Top = (int)BitConverter.ToUInt16(array, 3);
			this.Width = (int)BitConverter.ToUInt16(array, 5);
			this.Height = (int)BitConverter.ToUInt16(array, 7);
			this.CellWidth = (int)array[9];
			this.CellHeight = (int)array[10];
			this.ForegroundColorIndex = (int)array[11];
			this.BackgroundColorIndex = (int)array[12];
			byte[] bytes = GifHelpers.ReadDataBlocks(stream, metadataOnly);
			this.Text = Encoding.ASCII.GetString(bytes);
			this.Extensions = controlExtensions.ToList<GifExtension>().AsReadOnly();
		}

		// Token: 0x04000B95 RID: 2965
		internal const int ExtensionLabel = 1;
	}
}
