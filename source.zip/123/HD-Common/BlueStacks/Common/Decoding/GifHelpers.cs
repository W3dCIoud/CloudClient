﻿using System;
using System.IO;
using System.Text;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x020001B5 RID: 437
	internal static class GifHelpers
	{
		// Token: 0x06000D5A RID: 3418 RVA: 0x00037A54 File Offset: 0x00035C54
		public static string ReadString(Stream stream, int length)
		{
			byte[] array = new byte[length];
			stream.ReadAll(array, 0, length);
			return Encoding.ASCII.GetString(array);
		}

		// Token: 0x06000D5B RID: 3419 RVA: 0x00037A7C File Offset: 0x00035C7C
		public static byte[] ReadDataBlocks(Stream stream, bool discard)
		{
			MemoryStream memoryStream = discard ? null : new MemoryStream();
			byte[] result;
			using (memoryStream)
			{
				int num;
				while ((num = stream.ReadByte()) > 0)
				{
					byte[] buffer = new byte[num];
					stream.ReadAll(buffer, 0, num);
					if (memoryStream != null)
					{
						memoryStream.Write(buffer, 0, num);
					}
				}
				if (memoryStream != null)
				{
					result = memoryStream.ToArray();
				}
				else
				{
					result = null;
				}
			}
			return result;
		}

		// Token: 0x06000D5C RID: 3420 RVA: 0x00037AF0 File Offset: 0x00035CF0
		public static GifColor[] ReadColorTable(Stream stream, int size)
		{
			int num = 3 * size;
			byte[] array = new byte[num];
			stream.ReadAll(array, 0, num);
			GifColor[] array2 = new GifColor[size];
			for (int i = 0; i < size; i++)
			{
				byte r = array[3 * i];
				byte g = array[3 * i + 1];
				byte b = array[3 * i + 2];
				array2[i] = new GifColor(r, g, b);
			}
			return array2;
		}

		// Token: 0x06000D5D RID: 3421 RVA: 0x0000BA18 File Offset: 0x00009C18
		public static bool IsNetscapeExtension(GifApplicationExtension ext)
		{
			return ext.ApplicationIdentifier == "NETSCAPE" && Encoding.ASCII.GetString(ext.AuthenticationCode) == "2.0";
		}

		// Token: 0x06000D5E RID: 3422 RVA: 0x0000BA48 File Offset: 0x00009C48
		public static ushort GetRepeatCount(GifApplicationExtension ext)
		{
			if (ext.Data.Length >= 3)
			{
				return BitConverter.ToUInt16(ext.Data, 1);
			}
			return 1;
		}

		// Token: 0x06000D5F RID: 3423 RVA: 0x0000BA63 File Offset: 0x00009C63
		public static Exception UnexpectedEndOfStreamException()
		{
			return new GifDecoderException("Unexpected end of stream before trailer was encountered");
		}

		// Token: 0x06000D60 RID: 3424 RVA: 0x0000BA6F File Offset: 0x00009C6F
		public static Exception UnknownBlockTypeException(int blockId)
		{
			return new GifDecoderException("Unknown block type: 0x" + blockId.ToString("x2"));
		}

		// Token: 0x06000D61 RID: 3425 RVA: 0x0000BA8C File Offset: 0x00009C8C
		public static Exception UnknownExtensionTypeException(int extensionLabel)
		{
			return new GifDecoderException("Unknown extension type: 0x" + extensionLabel.ToString("x2"));
		}

		// Token: 0x06000D62 RID: 3426 RVA: 0x0000BAA9 File Offset: 0x00009CA9
		public static Exception InvalidBlockSizeException(string blockName, int expectedBlockSize, int actualBlockSize)
		{
			return new GifDecoderException(string.Format("Invalid block size for {0}. Expected {1}, but was {2}", blockName, expectedBlockSize, actualBlockSize));
		}

		// Token: 0x06000D63 RID: 3427 RVA: 0x0000BAC7 File Offset: 0x00009CC7
		public static Exception InvalidSignatureException(string signature)
		{
			return new GifDecoderException("Invalid file signature: " + signature);
		}

		// Token: 0x06000D64 RID: 3428 RVA: 0x0000BAD9 File Offset: 0x00009CD9
		public static Exception UnsupportedVersionException(string version)
		{
			return new GifDecoderException("Unsupported version: " + version);
		}

		// Token: 0x06000D65 RID: 3429 RVA: 0x00037B50 File Offset: 0x00035D50
		public static void ReadAll(this Stream stream, byte[] buffer, int offset, int count)
		{
			for (int i = 0; i < count; i += stream.Read(buffer, offset + i, count - i))
			{
			}
		}
	}
}
