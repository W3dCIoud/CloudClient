﻿using System;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x020001AD RID: 429
	internal struct GifColor
	{
		// Token: 0x06000D15 RID: 3349 RVA: 0x0000B81B File Offset: 0x00009A1B
		internal GifColor(byte r, byte g, byte b)
		{
			this._r = r;
			this._g = g;
			this._b = b;
		}

		// Token: 0x1700030A RID: 778
		// (get) Token: 0x06000D16 RID: 3350 RVA: 0x0000B832 File Offset: 0x00009A32
		public byte R
		{
			get
			{
				return this._r;
			}
		}

		// Token: 0x1700030B RID: 779
		// (get) Token: 0x06000D17 RID: 3351 RVA: 0x0000B83A File Offset: 0x00009A3A
		public byte G
		{
			get
			{
				return this._g;
			}
		}

		// Token: 0x1700030C RID: 780
		// (get) Token: 0x06000D18 RID: 3352 RVA: 0x0000B842 File Offset: 0x00009A42
		public byte B
		{
			get
			{
				return this._b;
			}
		}

		// Token: 0x06000D19 RID: 3353 RVA: 0x0000B84A File Offset: 0x00009A4A
		public override string ToString()
		{
			return string.Format("#{0:x2}{1:x2}{2:x2}", this._r, this._g, this._b);
		}

		// Token: 0x04000B69 RID: 2921
		private readonly byte _r;

		// Token: 0x04000B6A RID: 2922
		private readonly byte _g;

		// Token: 0x04000B6B RID: 2923
		private readonly byte _b;
	}
}
