﻿using System;
using System.IO;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x020001B4 RID: 436
	internal class GifHeader : GifBlock
	{
		// Token: 0x17000320 RID: 800
		// (get) Token: 0x06000D50 RID: 3408 RVA: 0x0000B9D4 File Offset: 0x00009BD4
		// (set) Token: 0x06000D51 RID: 3409 RVA: 0x0000B9DC File Offset: 0x00009BDC
		public string Signature { get; private set; }

		// Token: 0x17000321 RID: 801
		// (get) Token: 0x06000D52 RID: 3410 RVA: 0x0000B9E5 File Offset: 0x00009BE5
		// (set) Token: 0x06000D53 RID: 3411 RVA: 0x0000B9ED File Offset: 0x00009BED
		public string Version { get; private set; }

		// Token: 0x17000322 RID: 802
		// (get) Token: 0x06000D54 RID: 3412 RVA: 0x0000B9F6 File Offset: 0x00009BF6
		// (set) Token: 0x06000D55 RID: 3413 RVA: 0x0000B9FE File Offset: 0x00009BFE
		public GifLogicalScreenDescriptor LogicalScreenDescriptor { get; private set; }

		// Token: 0x06000D56 RID: 3414 RVA: 0x0000B8A0 File Offset: 0x00009AA0
		private GifHeader()
		{
		}

		// Token: 0x17000323 RID: 803
		// (get) Token: 0x06000D57 RID: 3415 RVA: 0x0000BA07 File Offset: 0x00009C07
		internal override GifBlockKind Kind
		{
			get
			{
				return GifBlockKind.Other;
			}
		}

		// Token: 0x06000D58 RID: 3416 RVA: 0x0000BA0A File Offset: 0x00009C0A
		internal static GifHeader ReadHeader(Stream stream)
		{
			GifHeader gifHeader = new GifHeader();
			gifHeader.Read(stream);
			return gifHeader;
		}

		// Token: 0x06000D59 RID: 3417 RVA: 0x000379D0 File Offset: 0x00035BD0
		private void Read(Stream stream)
		{
			this.Signature = GifHelpers.ReadString(stream, 3);
			if (this.Signature != "GIF")
			{
				throw GifHelpers.InvalidSignatureException(this.Signature);
			}
			this.Version = GifHelpers.ReadString(stream, 3);
			if (this.Version != "87a" && this.Version != "89a")
			{
				throw GifHelpers.UnsupportedVersionException(this.Version);
			}
			this.LogicalScreenDescriptor = GifLogicalScreenDescriptor.ReadLogicalScreenDescriptor(stream);
		}
	}
}
