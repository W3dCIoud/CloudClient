﻿using System;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x020001BA RID: 442
	internal class GifTrailer : GifBlock
	{
		// Token: 0x06000DAD RID: 3501 RVA: 0x0000B8A0 File Offset: 0x00009AA0
		private GifTrailer()
		{
		}

		// Token: 0x17000342 RID: 834
		// (get) Token: 0x06000DAE RID: 3502 RVA: 0x0000BA07 File Offset: 0x00009C07
		internal override GifBlockKind Kind
		{
			get
			{
				return GifBlockKind.Other;
			}
		}

		// Token: 0x06000DAF RID: 3503 RVA: 0x0000BD2F File Offset: 0x00009F2F
		internal static GifTrailer ReadTrailer()
		{
			return new GifTrailer();
		}

		// Token: 0x04000BA1 RID: 2977
		internal const int TrailerByte = 59;
	}
}
