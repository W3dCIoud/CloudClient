﻿using System;
using System.IO;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x020001B7 RID: 439
	internal class GifImageDescriptor
	{
		// Token: 0x17000326 RID: 806
		// (get) Token: 0x06000D6D RID: 3437 RVA: 0x0000BB38 File Offset: 0x00009D38
		// (set) Token: 0x06000D6E RID: 3438 RVA: 0x0000BB40 File Offset: 0x00009D40
		public int Left { get; private set; }

		// Token: 0x17000327 RID: 807
		// (get) Token: 0x06000D6F RID: 3439 RVA: 0x0000BB49 File Offset: 0x00009D49
		// (set) Token: 0x06000D70 RID: 3440 RVA: 0x0000BB51 File Offset: 0x00009D51
		public int Top { get; private set; }

		// Token: 0x17000328 RID: 808
		// (get) Token: 0x06000D71 RID: 3441 RVA: 0x0000BB5A File Offset: 0x00009D5A
		// (set) Token: 0x06000D72 RID: 3442 RVA: 0x0000BB62 File Offset: 0x00009D62
		public int Width { get; private set; }

		// Token: 0x17000329 RID: 809
		// (get) Token: 0x06000D73 RID: 3443 RVA: 0x0000BB6B File Offset: 0x00009D6B
		// (set) Token: 0x06000D74 RID: 3444 RVA: 0x0000BB73 File Offset: 0x00009D73
		public int Height { get; private set; }

		// Token: 0x1700032A RID: 810
		// (get) Token: 0x06000D75 RID: 3445 RVA: 0x0000BB7C File Offset: 0x00009D7C
		// (set) Token: 0x06000D76 RID: 3446 RVA: 0x0000BB84 File Offset: 0x00009D84
		public bool HasLocalColorTable { get; private set; }

		// Token: 0x1700032B RID: 811
		// (get) Token: 0x06000D77 RID: 3447 RVA: 0x0000BB8D File Offset: 0x00009D8D
		// (set) Token: 0x06000D78 RID: 3448 RVA: 0x0000BB95 File Offset: 0x00009D95
		public bool Interlace { get; private set; }

		// Token: 0x1700032C RID: 812
		// (get) Token: 0x06000D79 RID: 3449 RVA: 0x0000BB9E File Offset: 0x00009D9E
		// (set) Token: 0x06000D7A RID: 3450 RVA: 0x0000BBA6 File Offset: 0x00009DA6
		public bool IsLocalColorTableSorted { get; private set; }

		// Token: 0x1700032D RID: 813
		// (get) Token: 0x06000D7B RID: 3451 RVA: 0x0000BBAF File Offset: 0x00009DAF
		// (set) Token: 0x06000D7C RID: 3452 RVA: 0x0000BBB7 File Offset: 0x00009DB7
		public int LocalColorTableSize { get; private set; }

		// Token: 0x06000D7D RID: 3453 RVA: 0x000021BB File Offset: 0x000003BB
		private GifImageDescriptor()
		{
		}

		// Token: 0x06000D7E RID: 3454 RVA: 0x0000BBC0 File Offset: 0x00009DC0
		internal static GifImageDescriptor ReadImageDescriptor(Stream stream)
		{
			GifImageDescriptor gifImageDescriptor = new GifImageDescriptor();
			gifImageDescriptor.Read(stream);
			return gifImageDescriptor;
		}

		// Token: 0x06000D7F RID: 3455 RVA: 0x00037B78 File Offset: 0x00035D78
		private void Read(Stream stream)
		{
			byte[] array = new byte[9];
			stream.ReadAll(array, 0, array.Length);
			this.Left = (int)BitConverter.ToUInt16(array, 0);
			this.Top = (int)BitConverter.ToUInt16(array, 2);
			this.Width = (int)BitConverter.ToUInt16(array, 4);
			this.Height = (int)BitConverter.ToUInt16(array, 6);
			byte b = array[8];
			this.HasLocalColorTable = ((b & 128) > 0);
			this.Interlace = ((b & 64) > 0);
			this.IsLocalColorTableSorted = ((b & 32) > 0);
			this.LocalColorTableSize = 1 << (int)((b & 7) + 1);
		}
	}
}
