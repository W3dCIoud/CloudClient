﻿using System;
using System.Collections.Generic;
using System.IO;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x020001AB RID: 427
	internal abstract class GifBlock
	{
		// Token: 0x06000D12 RID: 3346 RVA: 0x000376DC File Offset: 0x000358DC
		internal static GifBlock ReadBlock(Stream stream, IEnumerable<GifExtension> controlExtensions, bool metadataOnly)
		{
			int num = stream.ReadByte();
			if (num < 0)
			{
				throw GifHelpers.UnexpectedEndOfStreamException();
			}
			if (num == 33)
			{
				return GifExtension.ReadExtension(stream, controlExtensions, metadataOnly);
			}
			if (num == 44)
			{
				return GifFrame.ReadFrame(stream, controlExtensions, metadataOnly);
			}
			if (num != 59)
			{
				throw GifHelpers.UnknownBlockTypeException(num);
			}
			return GifTrailer.ReadTrailer();
		}

		// Token: 0x17000309 RID: 777
		// (get) Token: 0x06000D13 RID: 3347
		internal abstract GifBlockKind Kind { get; }
	}
}
