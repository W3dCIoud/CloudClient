﻿using System;
using System.Runtime.Serialization;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x020001AF RID: 431
	[Serializable]
	internal class GifDecoderException : Exception
	{
		// Token: 0x06000D20 RID: 3360 RVA: 0x0000233F File Offset: 0x0000053F
		internal GifDecoderException()
		{
		}

		// Token: 0x06000D21 RID: 3361 RVA: 0x00002FD6 File Offset: 0x000011D6
		internal GifDecoderException(string message) : base(message)
		{
		}

		// Token: 0x06000D22 RID: 3362 RVA: 0x000024B1 File Offset: 0x000006B1
		internal GifDecoderException(string message, Exception inner) : base(message, inner)
		{
		}

		// Token: 0x06000D23 RID: 3363 RVA: 0x0000B896 File Offset: 0x00009A96
		protected GifDecoderException(SerializationInfo info, StreamingContext context) : base(info, context)
		{
		}
	}
}
