﻿using System;
using System.IO;
using System.Text;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x020001AA RID: 426
	internal class GifApplicationExtension : GifExtension
	{
		// Token: 0x17000304 RID: 772
		// (get) Token: 0x06000D06 RID: 3334 RVA: 0x0000B7BE File Offset: 0x000099BE
		// (set) Token: 0x06000D07 RID: 3335 RVA: 0x0000B7C6 File Offset: 0x000099C6
		public int BlockSize { get; private set; }

		// Token: 0x17000305 RID: 773
		// (get) Token: 0x06000D08 RID: 3336 RVA: 0x0000B7CF File Offset: 0x000099CF
		// (set) Token: 0x06000D09 RID: 3337 RVA: 0x0000B7D7 File Offset: 0x000099D7
		public string ApplicationIdentifier { get; private set; }

		// Token: 0x17000306 RID: 774
		// (get) Token: 0x06000D0A RID: 3338 RVA: 0x0000B7E0 File Offset: 0x000099E0
		// (set) Token: 0x06000D0B RID: 3339 RVA: 0x0000B7E8 File Offset: 0x000099E8
		public byte[] AuthenticationCode { get; private set; }

		// Token: 0x17000307 RID: 775
		// (get) Token: 0x06000D0C RID: 3340 RVA: 0x0000B7F1 File Offset: 0x000099F1
		// (set) Token: 0x06000D0D RID: 3341 RVA: 0x0000B7F9 File Offset: 0x000099F9
		public byte[] Data { get; private set; }

		// Token: 0x06000D0E RID: 3342 RVA: 0x0000B802 File Offset: 0x00009A02
		private GifApplicationExtension()
		{
		}

		// Token: 0x17000308 RID: 776
		// (get) Token: 0x06000D0F RID: 3343 RVA: 0x0000B80A File Offset: 0x00009A0A
		internal override GifBlockKind Kind
		{
			get
			{
				return GifBlockKind.SpecialPurpose;
			}
		}

		// Token: 0x06000D10 RID: 3344 RVA: 0x0000B80D File Offset: 0x00009A0D
		internal static GifApplicationExtension ReadApplication(Stream stream)
		{
			GifApplicationExtension gifApplicationExtension = new GifApplicationExtension();
			gifApplicationExtension.Read(stream);
			return gifApplicationExtension;
		}

		// Token: 0x06000D11 RID: 3345 RVA: 0x0003765C File Offset: 0x0003585C
		private void Read(Stream stream)
		{
			byte[] array = new byte[12];
			stream.ReadAll(array, 0, array.Length);
			this.BlockSize = (int)array[0];
			if (this.BlockSize != 11)
			{
				throw GifHelpers.InvalidBlockSizeException("Application Extension", 11, this.BlockSize);
			}
			this.ApplicationIdentifier = Encoding.ASCII.GetString(array, 1, 8);
			byte[] array2 = new byte[3];
			Array.Copy(array, 9, array2, 0, 3);
			this.AuthenticationCode = array2;
			this.Data = GifHelpers.ReadDataBlocks(stream, false);
		}

		// Token: 0x04000B5F RID: 2911
		internal const int ExtensionLabel = 255;
	}
}
