﻿using System;
using System.IO;
using System.Text;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x020001AE RID: 430
	internal class GifCommentExtension : GifExtension
	{
		// Token: 0x1700030D RID: 781
		// (get) Token: 0x06000D1A RID: 3354 RVA: 0x0000B877 File Offset: 0x00009A77
		// (set) Token: 0x06000D1B RID: 3355 RVA: 0x0000B87F File Offset: 0x00009A7F
		public string Text { get; private set; }

		// Token: 0x06000D1C RID: 3356 RVA: 0x0000B802 File Offset: 0x00009A02
		private GifCommentExtension()
		{
		}

		// Token: 0x1700030E RID: 782
		// (get) Token: 0x06000D1D RID: 3357 RVA: 0x0000B80A File Offset: 0x00009A0A
		internal override GifBlockKind Kind
		{
			get
			{
				return GifBlockKind.SpecialPurpose;
			}
		}

		// Token: 0x06000D1E RID: 3358 RVA: 0x0000B888 File Offset: 0x00009A88
		internal static GifCommentExtension ReadComment(Stream stream)
		{
			GifCommentExtension gifCommentExtension = new GifCommentExtension();
			gifCommentExtension.Read(stream);
			return gifCommentExtension;
		}

		// Token: 0x06000D1F RID: 3359 RVA: 0x0003772C File Offset: 0x0003592C
		private void Read(Stream stream)
		{
			byte[] array = GifHelpers.ReadDataBlocks(stream, false);
			if (array != null)
			{
				this.Text = Encoding.ASCII.GetString(array);
			}
		}

		// Token: 0x04000B6C RID: 2924
		internal const int ExtensionLabel = 254;
	}
}
