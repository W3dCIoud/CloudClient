﻿using System;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x020001AC RID: 428
	internal enum GifBlockKind
	{
		// Token: 0x04000B65 RID: 2917
		Control,
		// Token: 0x04000B66 RID: 2918
		GraphicRendering,
		// Token: 0x04000B67 RID: 2919
		SpecialPurpose,
		// Token: 0x04000B68 RID: 2920
		Other
	}
}
