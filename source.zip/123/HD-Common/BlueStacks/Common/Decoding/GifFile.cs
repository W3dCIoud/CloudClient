﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x020001B1 RID: 433
	internal class GifFile
	{
		// Token: 0x1700030F RID: 783
		// (get) Token: 0x06000D26 RID: 3366 RVA: 0x0000B8A8 File Offset: 0x00009AA8
		// (set) Token: 0x06000D27 RID: 3367 RVA: 0x0000B8B0 File Offset: 0x00009AB0
		public GifHeader Header { get; private set; }

		// Token: 0x17000310 RID: 784
		// (get) Token: 0x06000D28 RID: 3368 RVA: 0x0000B8B9 File Offset: 0x00009AB9
		// (set) Token: 0x06000D29 RID: 3369 RVA: 0x0000B8C1 File Offset: 0x00009AC1
		public GifColor[] GlobalColorTable { get; set; }

		// Token: 0x17000311 RID: 785
		// (get) Token: 0x06000D2A RID: 3370 RVA: 0x0000B8CA File Offset: 0x00009ACA
		// (set) Token: 0x06000D2B RID: 3371 RVA: 0x0000B8D2 File Offset: 0x00009AD2
		public IList<GifFrame> Frames { get; set; }

		// Token: 0x17000312 RID: 786
		// (get) Token: 0x06000D2C RID: 3372 RVA: 0x0000B8DB File Offset: 0x00009ADB
		// (set) Token: 0x06000D2D RID: 3373 RVA: 0x0000B8E3 File Offset: 0x00009AE3
		public IList<GifExtension> Extensions { get; set; }

		// Token: 0x17000313 RID: 787
		// (get) Token: 0x06000D2E RID: 3374 RVA: 0x0000B8EC File Offset: 0x00009AEC
		// (set) Token: 0x06000D2F RID: 3375 RVA: 0x0000B8F4 File Offset: 0x00009AF4
		public ushort RepeatCount { get; set; }

		// Token: 0x06000D30 RID: 3376 RVA: 0x000021BB File Offset: 0x000003BB
		private GifFile()
		{
		}

		// Token: 0x06000D31 RID: 3377 RVA: 0x0000B8FD File Offset: 0x00009AFD
		internal static GifFile ReadGifFile(Stream stream, bool metadataOnly)
		{
			GifFile gifFile = new GifFile();
			gifFile.Read(stream, metadataOnly);
			return gifFile;
		}

		// Token: 0x06000D32 RID: 3378 RVA: 0x000377C4 File Offset: 0x000359C4
		private void Read(Stream stream, bool metadataOnly)
		{
			this.Header = GifHeader.ReadHeader(stream);
			if (this.Header.LogicalScreenDescriptor.HasGlobalColorTable)
			{
				this.GlobalColorTable = GifHelpers.ReadColorTable(stream, this.Header.LogicalScreenDescriptor.GlobalColorTableSize);
			}
			this.ReadFrames(stream, metadataOnly);
			GifApplicationExtension gifApplicationExtension = this.Extensions.OfType<GifApplicationExtension>().FirstOrDefault(new Func<GifApplicationExtension, bool>(GifHelpers.IsNetscapeExtension));
			if (gifApplicationExtension != null)
			{
				this.RepeatCount = GifHelpers.GetRepeatCount(gifApplicationExtension);
				return;
			}
			this.RepeatCount = 1;
		}

		// Token: 0x06000D33 RID: 3379 RVA: 0x00037848 File Offset: 0x00035A48
		private void ReadFrames(Stream stream, bool metadataOnly)
		{
			List<GifFrame> list = new List<GifFrame>();
			List<GifExtension> list2 = new List<GifExtension>();
			List<GifExtension> list3 = new List<GifExtension>();
			for (;;)
			{
				GifBlock gifBlock = GifBlock.ReadBlock(stream, list2, metadataOnly);
				if (gifBlock.Kind == GifBlockKind.GraphicRendering)
				{
					list2 = new List<GifExtension>();
				}
				if (gifBlock is GifFrame)
				{
					list.Add((GifFrame)gifBlock);
				}
				else if (gifBlock is GifExtension)
				{
					GifExtension gifExtension = (GifExtension)gifBlock;
					GifBlockKind kind = gifExtension.Kind;
					if (kind != GifBlockKind.Control)
					{
						if (kind == GifBlockKind.SpecialPurpose)
						{
							list3.Add(gifExtension);
						}
					}
					else
					{
						list2.Add(gifExtension);
					}
				}
				else if (gifBlock is GifTrailer)
				{
					break;
				}
			}
			this.Frames = list.AsReadOnly();
			this.Extensions = list3.AsReadOnly();
		}
	}
}
