﻿using System;
using System.IO;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x020001B3 RID: 435
	internal class GifGraphicControlExtension : GifExtension
	{
		// Token: 0x17000319 RID: 793
		// (get) Token: 0x06000D40 RID: 3392 RVA: 0x0000B960 File Offset: 0x00009B60
		// (set) Token: 0x06000D41 RID: 3393 RVA: 0x0000B968 File Offset: 0x00009B68
		public int BlockSize { get; private set; }

		// Token: 0x1700031A RID: 794
		// (get) Token: 0x06000D42 RID: 3394 RVA: 0x0000B971 File Offset: 0x00009B71
		// (set) Token: 0x06000D43 RID: 3395 RVA: 0x0000B979 File Offset: 0x00009B79
		public int DisposalMethod { get; private set; }

		// Token: 0x1700031B RID: 795
		// (get) Token: 0x06000D44 RID: 3396 RVA: 0x0000B982 File Offset: 0x00009B82
		// (set) Token: 0x06000D45 RID: 3397 RVA: 0x0000B98A File Offset: 0x00009B8A
		public bool UserInput { get; private set; }

		// Token: 0x1700031C RID: 796
		// (get) Token: 0x06000D46 RID: 3398 RVA: 0x0000B993 File Offset: 0x00009B93
		// (set) Token: 0x06000D47 RID: 3399 RVA: 0x0000B99B File Offset: 0x00009B9B
		public bool HasTransparency { get; private set; }

		// Token: 0x1700031D RID: 797
		// (get) Token: 0x06000D48 RID: 3400 RVA: 0x0000B9A4 File Offset: 0x00009BA4
		// (set) Token: 0x06000D49 RID: 3401 RVA: 0x0000B9AC File Offset: 0x00009BAC
		public int Delay { get; private set; }

		// Token: 0x1700031E RID: 798
		// (get) Token: 0x06000D4A RID: 3402 RVA: 0x0000B9B5 File Offset: 0x00009BB5
		// (set) Token: 0x06000D4B RID: 3403 RVA: 0x0000B9BD File Offset: 0x00009BBD
		public int TransparencyIndex { get; private set; }

		// Token: 0x06000D4C RID: 3404 RVA: 0x0000B802 File Offset: 0x00009A02
		private GifGraphicControlExtension()
		{
		}

		// Token: 0x1700031F RID: 799
		// (get) Token: 0x06000D4D RID: 3405 RVA: 0x00004E1D File Offset: 0x0000301D
		internal override GifBlockKind Kind
		{
			get
			{
				return GifBlockKind.Control;
			}
		}

		// Token: 0x06000D4E RID: 3406 RVA: 0x0000B9C6 File Offset: 0x00009BC6
		internal static GifGraphicControlExtension ReadGraphicsControl(Stream stream)
		{
			GifGraphicControlExtension gifGraphicControlExtension = new GifGraphicControlExtension();
			gifGraphicControlExtension.Read(stream);
			return gifGraphicControlExtension;
		}

		// Token: 0x06000D4F RID: 3407 RVA: 0x0003794C File Offset: 0x00035B4C
		private void Read(Stream stream)
		{
			byte[] array = new byte[6];
			stream.ReadAll(array, 0, array.Length);
			this.BlockSize = (int)array[0];
			if (this.BlockSize != 4)
			{
				throw GifHelpers.InvalidBlockSizeException("Graphic Control Extension", 4, this.BlockSize);
			}
			byte b = array[1];
			this.DisposalMethod = (b & 28) >> 2;
			this.UserInput = ((b & 2) > 0);
			this.HasTransparency = ((b & 1) > 0);
			this.Delay = (int)(BitConverter.ToUInt16(array, 2) * 10);
			this.TransparencyIndex = (int)array[4];
		}

		// Token: 0x04000B79 RID: 2937
		internal const int ExtensionLabel = 249;
	}
}
