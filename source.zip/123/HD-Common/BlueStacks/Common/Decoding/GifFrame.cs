﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x020001B2 RID: 434
	internal class GifFrame : GifBlock
	{
		// Token: 0x17000314 RID: 788
		// (get) Token: 0x06000D34 RID: 3380 RVA: 0x0000B90C File Offset: 0x00009B0C
		// (set) Token: 0x06000D35 RID: 3381 RVA: 0x0000B914 File Offset: 0x00009B14
		public GifImageDescriptor Descriptor { get; private set; }

		// Token: 0x17000315 RID: 789
		// (get) Token: 0x06000D36 RID: 3382 RVA: 0x0000B91D File Offset: 0x00009B1D
		// (set) Token: 0x06000D37 RID: 3383 RVA: 0x0000B925 File Offset: 0x00009B25
		public GifColor[] LocalColorTable { get; private set; }

		// Token: 0x17000316 RID: 790
		// (get) Token: 0x06000D38 RID: 3384 RVA: 0x0000B92E File Offset: 0x00009B2E
		// (set) Token: 0x06000D39 RID: 3385 RVA: 0x0000B936 File Offset: 0x00009B36
		public IList<GifExtension> Extensions { get; private set; }

		// Token: 0x17000317 RID: 791
		// (get) Token: 0x06000D3A RID: 3386 RVA: 0x0000B93F File Offset: 0x00009B3F
		// (set) Token: 0x06000D3B RID: 3387 RVA: 0x0000B947 File Offset: 0x00009B47
		public GifImageData ImageData { get; private set; }

		// Token: 0x06000D3C RID: 3388 RVA: 0x0000B8A0 File Offset: 0x00009AA0
		private GifFrame()
		{
		}

		// Token: 0x17000318 RID: 792
		// (get) Token: 0x06000D3D RID: 3389 RVA: 0x0000AC7B File Offset: 0x00008E7B
		internal override GifBlockKind Kind
		{
			get
			{
				return GifBlockKind.GraphicRendering;
			}
		}

		// Token: 0x06000D3E RID: 3390 RVA: 0x0000B950 File Offset: 0x00009B50
		internal static GifFrame ReadFrame(Stream stream, IEnumerable<GifExtension> controlExtensions, bool metadataOnly)
		{
			GifFrame gifFrame = new GifFrame();
			gifFrame.Read(stream, controlExtensions, metadataOnly);
			return gifFrame;
		}

		// Token: 0x06000D3F RID: 3391 RVA: 0x000378F0 File Offset: 0x00035AF0
		private void Read(Stream stream, IEnumerable<GifExtension> controlExtensions, bool metadataOnly)
		{
			this.Descriptor = GifImageDescriptor.ReadImageDescriptor(stream);
			if (this.Descriptor.HasLocalColorTable)
			{
				this.LocalColorTable = GifHelpers.ReadColorTable(stream, this.Descriptor.LocalColorTableSize);
			}
			this.ImageData = GifImageData.ReadImageData(stream, metadataOnly);
			this.Extensions = controlExtensions.ToList<GifExtension>().AsReadOnly();
		}

		// Token: 0x04000B74 RID: 2932
		internal const int ImageSeparator = 44;
	}
}
