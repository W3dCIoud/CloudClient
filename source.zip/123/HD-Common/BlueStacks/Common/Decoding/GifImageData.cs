﻿using System;
using System.IO;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x020001B6 RID: 438
	internal class GifImageData
	{
		// Token: 0x17000324 RID: 804
		// (get) Token: 0x06000D66 RID: 3430 RVA: 0x0000BAEB File Offset: 0x00009CEB
		// (set) Token: 0x06000D67 RID: 3431 RVA: 0x0000BAF3 File Offset: 0x00009CF3
		public byte LzwMinimumCodeSize { get; set; }

		// Token: 0x17000325 RID: 805
		// (get) Token: 0x06000D68 RID: 3432 RVA: 0x0000BAFC File Offset: 0x00009CFC
		// (set) Token: 0x06000D69 RID: 3433 RVA: 0x0000BB04 File Offset: 0x00009D04
		public byte[] CompressedData { get; set; }

		// Token: 0x06000D6A RID: 3434 RVA: 0x000021BB File Offset: 0x000003BB
		private GifImageData()
		{
		}

		// Token: 0x06000D6B RID: 3435 RVA: 0x0000BB0D File Offset: 0x00009D0D
		internal static GifImageData ReadImageData(Stream stream, bool metadataOnly)
		{
			GifImageData gifImageData = new GifImageData();
			gifImageData.Read(stream, metadataOnly);
			return gifImageData;
		}

		// Token: 0x06000D6C RID: 3436 RVA: 0x0000BB1C File Offset: 0x00009D1C
		private void Read(Stream stream, bool metadataOnly)
		{
			this.LzwMinimumCodeSize = (byte)stream.ReadByte();
			this.CompressedData = GifHelpers.ReadDataBlocks(stream, metadataOnly);
		}
	}
}
