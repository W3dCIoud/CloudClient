﻿using System;
using System.IO;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x020001B8 RID: 440
	internal class GifLogicalScreenDescriptor
	{
		// Token: 0x1700032E RID: 814
		// (get) Token: 0x06000D80 RID: 3456 RVA: 0x0000BBCE File Offset: 0x00009DCE
		// (set) Token: 0x06000D81 RID: 3457 RVA: 0x0000BBD6 File Offset: 0x00009DD6
		public int Width { get; private set; }

		// Token: 0x1700032F RID: 815
		// (get) Token: 0x06000D82 RID: 3458 RVA: 0x0000BBDF File Offset: 0x00009DDF
		// (set) Token: 0x06000D83 RID: 3459 RVA: 0x0000BBE7 File Offset: 0x00009DE7
		public int Height { get; private set; }

		// Token: 0x17000330 RID: 816
		// (get) Token: 0x06000D84 RID: 3460 RVA: 0x0000BBF0 File Offset: 0x00009DF0
		// (set) Token: 0x06000D85 RID: 3461 RVA: 0x0000BBF8 File Offset: 0x00009DF8
		public bool HasGlobalColorTable { get; private set; }

		// Token: 0x17000331 RID: 817
		// (get) Token: 0x06000D86 RID: 3462 RVA: 0x0000BC01 File Offset: 0x00009E01
		// (set) Token: 0x06000D87 RID: 3463 RVA: 0x0000BC09 File Offset: 0x00009E09
		public int ColorResolution { get; private set; }

		// Token: 0x17000332 RID: 818
		// (get) Token: 0x06000D88 RID: 3464 RVA: 0x0000BC12 File Offset: 0x00009E12
		// (set) Token: 0x06000D89 RID: 3465 RVA: 0x0000BC1A File Offset: 0x00009E1A
		public bool IsGlobalColorTableSorted { get; private set; }

		// Token: 0x17000333 RID: 819
		// (get) Token: 0x06000D8A RID: 3466 RVA: 0x0000BC23 File Offset: 0x00009E23
		// (set) Token: 0x06000D8B RID: 3467 RVA: 0x0000BC2B File Offset: 0x00009E2B
		public int GlobalColorTableSize { get; private set; }

		// Token: 0x17000334 RID: 820
		// (get) Token: 0x06000D8C RID: 3468 RVA: 0x0000BC34 File Offset: 0x00009E34
		// (set) Token: 0x06000D8D RID: 3469 RVA: 0x0000BC3C File Offset: 0x00009E3C
		public int BackgroundColorIndex { get; private set; }

		// Token: 0x17000335 RID: 821
		// (get) Token: 0x06000D8E RID: 3470 RVA: 0x0000BC45 File Offset: 0x00009E45
		// (set) Token: 0x06000D8F RID: 3471 RVA: 0x0000BC4D File Offset: 0x00009E4D
		public double PixelAspectRatio { get; private set; }

		// Token: 0x06000D90 RID: 3472 RVA: 0x0000BC56 File Offset: 0x00009E56
		internal static GifLogicalScreenDescriptor ReadLogicalScreenDescriptor(Stream stream)
		{
			GifLogicalScreenDescriptor gifLogicalScreenDescriptor = new GifLogicalScreenDescriptor();
			gifLogicalScreenDescriptor.Read(stream);
			return gifLogicalScreenDescriptor;
		}

		// Token: 0x06000D91 RID: 3473 RVA: 0x00037C0C File Offset: 0x00035E0C
		private void Read(Stream stream)
		{
			byte[] array = new byte[7];
			stream.ReadAll(array, 0, array.Length);
			this.Width = (int)BitConverter.ToUInt16(array, 0);
			this.Height = (int)BitConverter.ToUInt16(array, 2);
			byte b = array[4];
			this.HasGlobalColorTable = ((b & 128) > 0);
			this.ColorResolution = ((b & 112) >> 4) + 1;
			this.IsGlobalColorTableSorted = ((b & 8) > 0);
			this.GlobalColorTableSize = 1 << (int)((b & 7) + 1);
			this.BackgroundColorIndex = (int)array[5];
			this.PixelAspectRatio = ((array[5] == 0) ? 0.0 : ((double)(15 + array[5]) / 64.0));
		}
	}
}
