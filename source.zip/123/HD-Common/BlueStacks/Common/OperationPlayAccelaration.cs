﻿using System;
using System.ComponentModel;

namespace BlueStacks.Common
{
	// Token: 0x020000D8 RID: 216
	public enum OperationPlayAccelaration
	{
		// Token: 0x04000542 RID: 1346
		[Description("1x")]
		OneX,
		// Token: 0x04000543 RID: 1347
		[Description("2x")]
		TwoX,
		// Token: 0x04000544 RID: 1348
		[Description("3x")]
		ThreeX,
		// Token: 0x04000545 RID: 1349
		[Description("4x")]
		FourX,
		// Token: 0x04000546 RID: 1350
		[Description("5x")]
		FiveX
	}
}
