﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000145 RID: 325
	public enum HD_VIRT_TYPE
	{
		// Token: 0x040007C0 RID: 1984
		HD_VIRT_TYPE_LEGACY,
		// Token: 0x040007C1 RID: 1985
		HD_VIRT_TYPE_VMX,
		// Token: 0x040007C2 RID: 1986
		HD_VIRT_TYPE_SVM
	}
}
