﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Newtonsoft.Json;

namespace BlueStacks.Common
{
	// Token: 0x02000060 RID: 96
	public static class JSONUtils
	{
		// Token: 0x0600020B RID: 523 RVA: 0x0000FD30 File Offset: 0x0000DF30
		public static string GetJSONArrayString(Dictionary<string, string> dict)
		{
			StringBuilder stringBuilder = new StringBuilder();
			using (JsonWriter jsonWriter = new JsonTextWriter(new StringWriter(stringBuilder)))
			{
				jsonWriter.WriteStartArray();
				jsonWriter.WriteStartObject();
				foreach (KeyValuePair<string, string> keyValuePair in dict)
				{
					jsonWriter.WritePropertyName(keyValuePair.Key);
					jsonWriter.WriteValue(keyValuePair.Value.ToString());
				}
				jsonWriter.WriteEndObject();
				jsonWriter.WriteEndArray();
			}
			return stringBuilder.ToString();
		}

		// Token: 0x0600020C RID: 524 RVA: 0x0000FDE0 File Offset: 0x0000DFE0
		public static string GetJSONObjectString<T>(Dictionary<string, T> dict)
		{
			StringBuilder stringBuilder = new StringBuilder();
			using (JsonWriter jsonWriter = new JsonTextWriter(new StringWriter(stringBuilder)))
			{
				jsonWriter.WriteStartObject();
				foreach (KeyValuePair<string, T> keyValuePair in dict)
				{
					jsonWriter.WritePropertyName(keyValuePair.Key.ToString());
					JsonWriter jsonWriter2 = jsonWriter;
					T value = keyValuePair.Value;
					jsonWriter2.WriteValue(value.ToString());
				}
				jsonWriter.WriteEndObject();
			}
			return stringBuilder.ToString();
		}

		// Token: 0x0600020D RID: 525 RVA: 0x0000FE94 File Offset: 0x0000E094
		public static string GetJSONObjectString(Dictionary<string, Dictionary<string, long>> dict)
		{
			StringBuilder stringBuilder = new StringBuilder();
			using (JsonWriter jsonWriter = new JsonTextWriter(new StringWriter(stringBuilder)))
			{
				jsonWriter.WriteStartObject();
				foreach (KeyValuePair<string, Dictionary<string, long>> keyValuePair in dict)
				{
					jsonWriter.WritePropertyName(keyValuePair.Key.ToString());
					jsonWriter.WriteValue(JSONUtils.GetJSONObjectString<long>(keyValuePair.Value));
				}
				jsonWriter.WriteEndObject();
			}
			return stringBuilder.ToString();
		}
	}
}
