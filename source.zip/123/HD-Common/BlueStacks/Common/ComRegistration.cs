﻿using System;
using System.Diagnostics;
using System.IO;

namespace BlueStacks.Common
{
	// Token: 0x0200005E RID: 94
	public class ComRegistration
	{
		// Token: 0x06000200 RID: 512 RVA: 0x0000302F File Offset: 0x0000122F
		public static int Register()
		{
			Logger.Info("Registering COM components");
			return ComRegistration.RunBinary("-reg");
		}

		// Token: 0x06000201 RID: 513 RVA: 0x00003045 File Offset: 0x00001245
		public static int Unregister()
		{
			Logger.Info("Unregistering COM components");
			return ComRegistration.RunBinary("-unreg");
		}

		// Token: 0x06000202 RID: 514 RVA: 0x0000FB40 File Offset: 0x0000DD40
		private static int RunBinary(string args)
		{
			Process process = new Process();
			process.StartInfo.FileName = ComRegistration.BIN_PATH;
			process.StartInfo.Arguments = args;
			process.StartInfo.UseShellExecute = true;
			process.StartInfo.CreateNoWindow = true;
			process.StartInfo.Verb = "runas";
			process.Start();
			process.WaitForExit();
			return process.ExitCode;
		}

		// Token: 0x040000FE RID: 254
		public static string BIN_PATH = Path.Combine(RegistryStrings.InstallDir, "HD-ComRegistrar.exe");
	}
}
