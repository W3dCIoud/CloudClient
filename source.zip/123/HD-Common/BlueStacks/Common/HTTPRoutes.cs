﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000075 RID: 117
	public class HTTPRoutes
	{
		// Token: 0x02000076 RID: 118
		public class Agent
		{
			// Token: 0x04000185 RID: 389
			public const string Ping = "ping";

			// Token: 0x04000186 RID: 390
			public const string BootFailedPopup = "bootFailedPopup";

			// Token: 0x04000187 RID: 391
			public const string LaunchDefaultWebApp = "launchDefaultWebApp";

			// Token: 0x04000188 RID: 392
			public const string Installed = "installed";

			// Token: 0x04000189 RID: 393
			public const string Uninstalled = "uninstalled";

			// Token: 0x0400018A RID: 394
			public const string GetAppList = "getAppList";

			// Token: 0x0400018B RID: 395
			public const string Install = "install";

			// Token: 0x0400018C RID: 396
			public const string Uninstall = "uninstall";

			// Token: 0x0400018D RID: 397
			public const string RunApp = "runApp";

			// Token: 0x0400018E RID: 398
			public const string SetLocale = "setLocale";

			// Token: 0x0400018F RID: 399
			public const string InstallAppByUrl = "installAppByUrl";

			// Token: 0x04000190 RID: 400
			public const string AppCrashedInfo = "appCrashedInfo";

			// Token: 0x04000191 RID: 401
			public const string GetUserData = "getUserData";

			// Token: 0x04000192 RID: 402
			public const string ShowNotification = "showNotification";

			// Token: 0x04000193 RID: 403
			public const string AppDownloadStatus = "appDownloadStatus";

			// Token: 0x04000194 RID: 404
			public const string ShowFeNotification = "showFeNotification";

			// Token: 0x04000195 RID: 405
			public const string BindMount = "bindmount";

			// Token: 0x04000196 RID: 406
			public const string UnbindMount = "unbindmount";

			// Token: 0x04000197 RID: 407
			public const string QuitFrontend = "quitFrontend";

			// Token: 0x04000198 RID: 408
			public const string GetAppImage = "getAppImage";

			// Token: 0x04000199 RID: 409
			public const string ShowTrayNotification = "showTrayNotification";

			// Token: 0x0400019A RID: 410
			public const string Restart = "restart";

			// Token: 0x0400019B RID: 411
			public const string Notification = "notification";

			// Token: 0x0400019C RID: 412
			public const string Clipboard = "clipboard";

			// Token: 0x0400019D RID: 413
			public const string IsAppInstalled = "isAppInstalled";

			// Token: 0x0400019E RID: 414
			public const string TopActivityInfo = "topActivityInfo";

			// Token: 0x0400019F RID: 415
			public const string SysTrayVisibility = "sysTrayVisibility";

			// Token: 0x040001A0 RID: 416
			public const string RestartAgent = "restartAgent";

			// Token: 0x040001A1 RID: 417
			public const string ShowTileInterface = "showTileInterface";

			// Token: 0x040001A2 RID: 418
			public const string SetNewLocation = "setNewLocation";

			// Token: 0x040001A3 RID: 419
			public const string AdEvents = "adEvents";

			// Token: 0x040001A4 RID: 420
			public const string ExitAgent = "exitAgent";

			// Token: 0x040001A5 RID: 421
			public const string StopApp = "stopApp";

			// Token: 0x040001A6 RID: 422
			public const string ReleaseApkInstallThread = "releaseApkInstallThread";

			// Token: 0x040001A7 RID: 423
			public const string ClearAppData = "clearAppData";

			// Token: 0x040001A8 RID: 424
			public const string RestartGameManager = "restartGameManager";

			// Token: 0x040001A9 RID: 425
			public const string PostHttpUrl = "postHttpUrl";

			// Token: 0x040001AA RID: 426
			public const string InstanceExist = "instanceExist";

			// Token: 0x040001AB RID: 427
			public const string QueryInstances = "queryInstances";

			// Token: 0x040001AC RID: 428
			public const string CreateInstance = "createInstance";

			// Token: 0x040001AD RID: 429
			public const string DeleteInstance = "deleteInstance";

			// Token: 0x040001AE RID: 430
			public const string StartInstance = "startInstance";

			// Token: 0x040001AF RID: 431
			public const string GetRunningInstances = "getRunningInstances";

			// Token: 0x040001B0 RID: 432
			public const string StopInstance = "stopInstance";

			// Token: 0x040001B1 RID: 433
			public const string SetVmConfig = "setVmConfig";

			// Token: 0x040001B2 RID: 434
			public const string IsMultiInstanceSupported = "isMultiInstanceSupported";

			// Token: 0x040001B3 RID: 435
			public const string SetCpu = "setCpu";

			// Token: 0x040001B4 RID: 436
			public const string SetDpi = "setDpi";

			// Token: 0x040001B5 RID: 437
			public const string SetRam = "setRam";

			// Token: 0x040001B6 RID: 438
			public const string SetResolution = "setResolution";

			// Token: 0x040001B7 RID: 439
			public const string GetGuid = "getGuid";

			// Token: 0x040001B8 RID: 440
			public const string Backup = "backup";

			// Token: 0x040001B9 RID: 441
			public const string Restore = "restore";

			// Token: 0x040001BA RID: 442
			public const string AppJsonUpdatedForVideo = "appJsonUpdatedForVideo";

			// Token: 0x040001BB RID: 443
			public const string DeviceProfileUpdated = "deviceProfileUpdated";

			// Token: 0x040001BC RID: 444
			public const string InstanceStopped = "instanceStopped";

			// Token: 0x040001BD RID: 445
			public const string GetInstanceStatus = "getInstanceStatus";

			// Token: 0x040001BE RID: 446
			public const string IsEngineReady = "isEngineReady";

			// Token: 0x040001BF RID: 447
			public const string FrontendStatusUpdate = "FrontendStatusUpdate";

			// Token: 0x040001C0 RID: 448
			public const string CopyToAndroid = "copyToAndroid";

			// Token: 0x040001C1 RID: 449
			public const string CopyToWindows = "copyToWindows";

			// Token: 0x040001C2 RID: 450
			public const string SetCurrentVolume = "setCurrentVolume";

			// Token: 0x040001C3 RID: 451
			public const string DownloadInstalledAppsCfg = "downloadInstalledAppsCfg";

			// Token: 0x040001C4 RID: 452
			public const string SetVMDisplayName = "setVMDisplayName";

			// Token: 0x040001C5 RID: 453
			public const string SortWindows = "sortWindows";

			// Token: 0x040001C6 RID: 454
			public const string MaintenanceWarning = "maintenanceWarning";

			// Token: 0x040001C7 RID: 455
			public const string EnableDebugLogs = "enableDebugLogs";

			// Token: 0x040001C8 RID: 456
			public const string LogAppClick = "logAppClick";

			// Token: 0x040001C9 RID: 457
			public const string SetNCPlayerCharacterName = "setNCPlayerCharacterName";

			// Token: 0x040001CA RID: 458
			public const string LaunchPlay = "launchPlay";

			// Token: 0x040001CB RID: 459
			public const string RemoveAccount = "removeAccount";

			// Token: 0x040001CC RID: 460
			public const string SetDeviceProfile = "setDeviceProfile";

			// Token: 0x040001CD RID: 461
			public const string ScreenLock = "screenLock";

			// Token: 0x040001CE RID: 462
			public const string MakeDir = "makeDir";

			// Token: 0x040001CF RID: 463
			public const string GetHeightWidth = "getHeightWidth";

			// Token: 0x040001D0 RID: 464
			public const string SetStreamingStatus = "setStreamingStatus";

			// Token: 0x040001D1 RID: 465
			public const string GetShortcut = "getShortcut";

			// Token: 0x040001D2 RID: 466
			public const string SetShortcut = "setShortcut";
		}

		// Token: 0x02000077 RID: 119
		public class Client
		{
			// Token: 0x040001D3 RID: 467
			public const string Ping = "ping";

			// Token: 0x040001D4 RID: 468
			public const string AppDisplayed = "appDisplayed";

			// Token: 0x040001D5 RID: 469
			public const string CloseCrashedAppTab = "closeCrashedAppTab";

			// Token: 0x040001D6 RID: 470
			public const string AppLaunched = "appLaunched";

			// Token: 0x040001D7 RID: 471
			public const string ShowApp = "showApp";

			// Token: 0x040001D8 RID: 472
			public const string ShowWindow = "showWindow";

			// Token: 0x040001D9 RID: 473
			public const string IsGMVisible = "isVisible";

			// Token: 0x040001DA RID: 474
			public const string AppUninstalled = "appUninstalled";

			// Token: 0x040001DB RID: 475
			public const string AppInstalled = "appInstalled";

			// Token: 0x040001DC RID: 476
			public const string EnableWndProcLogging = "enableWndProcLogging";

			// Token: 0x040001DD RID: 477
			public const string Quit = "quit";

			// Token: 0x040001DE RID: 478
			public const string Google = "google";

			// Token: 0x040001DF RID: 479
			public const string ShowWebPage = "showWebPage";

			// Token: 0x040001E0 RID: 480
			public const string ShowHomeTab = "showHomeTab";

			// Token: 0x040001E1 RID: 481
			public const string CloseTab = "closeTab";

			// Token: 0x040001E2 RID: 482
			public const string GooglePlayAppInstall = "googlePlayAppInstall";

			// Token: 0x040001E3 RID: 483
			public const string AppInstallStarted = "appInstallStarted";

			// Token: 0x040001E4 RID: 484
			public const string AppInstallFailed = "appInstallFailed";

			// Token: 0x040001E5 RID: 485
			public const string OTSCompleted = "oneTimeSetupCompleted";

			// Token: 0x040001E6 RID: 486
			public const string UpdateUserInfo = "updateUserInfo";

			// Token: 0x040001E7 RID: 487
			public const string BootFailedPopup = "bootFailedPopup";

			// Token: 0x040001E8 RID: 488
			public const string OpenPackage = "openPackage";

			// Token: 0x040001E9 RID: 489
			public const string DragDropInstall = "dragDropInstall";

			// Token: 0x040001EA RID: 490
			public const string StopInstance = "stopInstance";

			// Token: 0x040001EB RID: 491
			public const string StartInstance = "startInstance";

			// Token: 0x040001EC RID: 492
			public const string HideBluestacks = "hideBluestacks";

			// Token: 0x040001ED RID: 493
			public const string TileWindow = "tileWindow";

			// Token: 0x040001EE RID: 494
			public const string CascadeWindow = "cascadeWindow";

			// Token: 0x040001EF RID: 495
			public const string ToggleFarmMode = "toggleFarmMode";

			// Token: 0x040001F0 RID: 496
			public const string LaunchWebTab = "launchWebTab";

			// Token: 0x040001F1 RID: 497
			public const string OpenNotificationSettings = "openNotificationSettings";

			// Token: 0x040001F2 RID: 498
			public const string IsAnyAppRunning = "isAnyAppRunning";

			// Token: 0x040001F3 RID: 499
			public const string ChangeTextOTS = "changeTextOTS";

			// Token: 0x040001F4 RID: 500
			public const string ShowIMESwitchPrompt = "showIMESwitchPrompt";

			// Token: 0x040001F5 RID: 501
			public const string LaunchDefaultWebApp = "launchDefaultWebApp";

			// Token: 0x040001F6 RID: 502
			public const string MacroCompleted = "macroCompleted";

			// Token: 0x040001F7 RID: 503
			public const string AppInfoUpdated = "appInfoUpdated";

			// Token: 0x040001F8 RID: 504
			public const string SendAppDisplayed = "sendAppDisplayed";

			// Token: 0x040001F9 RID: 505
			public const string IsGmVisible = "static";

			// Token: 0x040001FA RID: 506
			public const string RestartFrontend = "restartFrontend";

			// Token: 0x040001FB RID: 507
			public const string GcCollect = "gcCollect";

			// Token: 0x040001FC RID: 508
			public const string ShowWindowAndApp = "showWindowAndApp";

			// Token: 0x040001FD RID: 509
			public const string UnsupportedCpuError = "unsupportedCpuError";

			// Token: 0x040001FE RID: 510
			public const string ChangeOrientaion = "changeOrientaion";

			// Token: 0x040001FF RID: 511
			public const string ShootingModeChanged = "shootingModeChanged";

			// Token: 0x04000200 RID: 512
			public const string GuestBootCompleted = "guestBootCompleted";

			// Token: 0x04000201 RID: 513
			public const string GetRunningInstances = "getRunningInstances";

			// Token: 0x04000202 RID: 514
			public const string AppJsonChanged = "appJsonChanged";

			// Token: 0x04000203 RID: 515
			public const string GetCurrentAppDetails = "getCurrentAppDetails";

			// Token: 0x04000204 RID: 516
			public const string MaintenanceWarning = "maintenanceWarning";

			// Token: 0x04000205 RID: 517
			public const string RequirementConfigUpdated = "requirementConfigUpdated";

			// Token: 0x04000206 RID: 518
			public const string DeviceProfileUpdated = "deviceProfileUpdated";

			// Token: 0x04000207 RID: 519
			public const string UpdateSizeOfOverlay = "updateSizeOfOverlay";

			// Token: 0x04000208 RID: 520
			public const string AndroidLocaleChanged = "androidLocaleChanged";

			// Token: 0x04000209 RID: 521
			public const string SaveComboEvents = "saveComboEvents";

			// Token: 0x0400020A RID: 522
			public const string HandleClientOperation = "handleClientOperation";

			// Token: 0x0400020B RID: 523
			public const string MacroPlaybackComplete = "macroPlaybackComplete";

			// Token: 0x0400020C RID: 524
			public const string ObsStatus = "obsStatus";

			// Token: 0x0400020D RID: 525
			public const string ReportObsError = "reportObsError";

			// Token: 0x0400020E RID: 526
			public const string CapturingError = "capturingError";

			// Token: 0x0400020F RID: 527
			public const string OpenGLCapturingError = "openGLCapturingError";

			// Token: 0x04000210 RID: 528
			public const string ToggleStreamingMode = "toggleStreamingMode";

			// Token: 0x04000211 RID: 529
			public const string HandleClientGamepadButton = "handleClientGamepadButton";

			// Token: 0x04000212 RID: 530
			public const string HandleGamepadConnection = "handleGamepadConnection";

			// Token: 0x04000213 RID: 531
			public const string HandleGamepadGuidanceButton = "handleGamepadGuidanceButton";

			// Token: 0x04000214 RID: 532
			public const string DeviceProvisioned = "deviceProvisioned";

			// Token: 0x04000215 RID: 533
			public const string GoogleSignin = "googleSignin";

			// Token: 0x04000216 RID: 534
			public const string ShowFullscreenSidebar = "showFullscreenSidebar";

			// Token: 0x04000217 RID: 535
			public const string UpdateLocale = "updateLocale";

			// Token: 0x04000218 RID: 536
			public const string ScreenshotCaptured = "screenshotCaptured";

			// Token: 0x04000219 RID: 537
			public const string SetCurrentVolumeFromAndroid = "setCurrentVolumeFromAndroid";

			// Token: 0x0400021A RID: 538
			public const string HotKeyEvents = "hotKeyEvents";

			// Token: 0x0400021B RID: 539
			public const string SetLocale = "setLocale";

			// Token: 0x0400021C RID: 540
			public const string EnableDebugLogs = "enableDebugLogs";

			// Token: 0x0400021D RID: 541
			public const string SetDMMKeymapping = "setDMMKeymapping";

			// Token: 0x0400021E RID: 542
			public const string NCSetGameInfoOnTopBar = "ncSetGameInfoOnTopBar";

			// Token: 0x0400021F RID: 543
			public const string LaunchPlay = "launchPlay";

			// Token: 0x04000220 RID: 544
			public const string EnableKeyboardHookLogging = "enableKeyboardHookLogging";

			// Token: 0x04000221 RID: 545
			public const string MuteAllInstances = "muteAllInstances";

			// Token: 0x04000222 RID: 546
			public const string ScreenLock = "screenLock";

			// Token: 0x04000223 RID: 547
			public const string GetHeightWidth = "getHeightWidth";

			// Token: 0x04000224 RID: 548
			public const string AccountSetupCompleted = "accountSetupCompleted";

			// Token: 0x04000225 RID: 549
			public const string OpenThemeEditor = "openThemeEditor";

			// Token: 0x04000226 RID: 550
			public const string SetStreamingStatus = "setStreamingStatus";

			// Token: 0x04000227 RID: 551
			public const string PlayerScriptModifierClick = "playerScriptModifierClick";

			// Token: 0x04000228 RID: 552
			public const string ReloadShortcuts = "reloadShortcuts";

			// Token: 0x04000229 RID: 553
			public const string ReloadPromotions = "reloadPromotions";
		}

		// Token: 0x02000078 RID: 120
		public class Cloud
		{
			// Token: 0x0400022A RID: 554
			public const string GetAnnouncement = "/getAnnouncement";

			// Token: 0x0400022B RID: 555
			public const string AppUsage = "/bs3/stats/v4/usage";

			// Token: 0x0400022C RID: 556
			public const string FrontendClickStats = "/bs3/stats/frontend_click_stats";

			// Token: 0x0400022D RID: 557
			public const string ScheduledPing = "/api/scheduledping";

			// Token: 0x0400022E RID: 558
			public const string ScheduledPingStats = "/stats/scheduledpingstats";

			// Token: 0x0400022F RID: 559
			public const string SecurityMetrics = "/bs4/security_metrics";

			// Token: 0x04000230 RID: 560
			public const string UnifiedInstallStats = "/bs3/stats/unified_install_stats";

			// Token: 0x04000231 RID: 561
			public const string UpdateLocale = "updateLocale";

			// Token: 0x04000232 RID: 562
			public const string ProblemCategories = "/app_settings/problem_categories";

			// Token: 0x04000233 RID: 563
			public const string Promotions = "promotions";

			// Token: 0x04000234 RID: 564
			public const string GrmFetchUrl = "grm/files";

			// Token: 0x04000235 RID: 565
			public const string BtvFetchUrl = "bs4/btv/GetBTVFile";

			// Token: 0x04000236 RID: 566
			public const string HelpArticles = "help_articles";
		}

		// Token: 0x02000079 RID: 121
		public class HelpArticlesKeys
		{
			// Token: 0x04000237 RID: 567
			public const string KMScriptFAQ = "keymapping_script_faq";

			// Token: 0x04000238 RID: 568
			public const string BS4MinRequirements = "bs3_nougat_min_requirements";

			// Token: 0x04000239 RID: 569
			public const string BGPCompatKKVersion = "bgp_kk_compat_version";

			// Token: 0x0400023A RID: 570
			public const string EnableVirtualization = "enable_virtualization";

			// Token: 0x0400023B RID: 571
			public const string VtxUnavailable = "vtx_unavailable";

			// Token: 0x0400023C RID: 572
			public const string UpgradeSupportInfo = "upgrade_support_info";

			// Token: 0x0400023D RID: 573
			public const string BS3MinRequirements = "bs3_min_requirements";

			// Token: 0x0400023E RID: 574
			public const string DisableAntivirus = "disable_antivirus";

			// Token: 0x0400023F RID: 575
			public const string ChangePowerPlan = "change_powerplan";

			// Token: 0x04000240 RID: 576
			public const string FailedSslConnection = "failed_ssl_connection";

			// Token: 0x04000241 RID: 577
			public const string AudioServiceIssue = "audio_service_issue";

			// Token: 0x04000242 RID: 578
			public const string TermsOfUse = "terms_of_use";

			// Token: 0x04000243 RID: 579
			public const string DisableHypervisors = "disable_hypervisor";

			// Token: 0x04000244 RID: 580
			public const string ChangeGraphicsMode = "change_graphics_mode";

			// Token: 0x04000245 RID: 581
			public const string AdvancedGameControl = "advanced_game_control";

			// Token: 0x04000246 RID: 582
			public const string SmartControl = "smart_control";

			// Token: 0x04000247 RID: 583
			public const string GameSettingsKnowMore = "game_settings_know_more";

			// Token: 0x04000248 RID: 584
			public const string ProfileSettingsWarningInPubg = "profile_settings_warning_pubg";
		}

		// Token: 0x0200007A RID: 122
		public class BTv
		{
			// Token: 0x04000249 RID: 585
			public const string Ping = "ping";

			// Token: 0x0400024A RID: 586
			public const string ReceiveAppInstallStatus = "receiveAppInstallStatus";
		}

		// Token: 0x0200007B RID: 123
		public class Engine
		{
			// Token: 0x0400024B RID: 587
			public const string Ping = "ping";

			// Token: 0x0400024C RID: 588
			public const string RefreshKeymapUri = "refreshKeymap";

			// Token: 0x0400024D RID: 589
			public const string Shutdown = "shutdown";

			// Token: 0x0400024E RID: 590
			public const string SwitchOrientation = "switchOrientation";

			// Token: 0x0400024F RID: 591
			public const string ShowWindow = "showWindow";

			// Token: 0x04000250 RID: 592
			public const string RefreshWindow = "refreshWindow";

			// Token: 0x04000251 RID: 593
			public const string SetParent = "setParent";

			// Token: 0x04000252 RID: 594
			public const string ShareScreenshot = "shareScreenshot";

			// Token: 0x04000253 RID: 595
			public const string GoBack = "goBack";

			// Token: 0x04000254 RID: 596
			public const string CloseScreen = "closeScreen";

			// Token: 0x04000255 RID: 597
			public const string SoftControlBarEvent = "softControlBarEvent";

			// Token: 0x04000256 RID: 598
			public const string InputMapperFilesDownloaded = "inputMapperFilesDownloaded";

			// Token: 0x04000257 RID: 599
			public const string EnableWndProcLogging = "enableWndProcLogging";

			// Token: 0x04000258 RID: 600
			public const string PingVm = "pingVm";

			// Token: 0x04000259 RID: 601
			public const string CopyFiles = "copyFiles";

			// Token: 0x0400025A RID: 602
			public const string GetWindowsFiles = "getWindowsFiles";

			// Token: 0x0400025B RID: 603
			public const string GpsCoordinates = "gpsCoordinates";

			// Token: 0x0400025C RID: 604
			public const string InitGamepad = "initGamepad";

			// Token: 0x0400025D RID: 605
			public const string GetVolume = "getVolume";

			// Token: 0x0400025E RID: 606
			public const string SetVolume = "setVolume";

			// Token: 0x0400025F RID: 607
			public const string TopDisplayedActivityInfo = "topDisplayedActivityInfo";

			// Token: 0x04000260 RID: 608
			public const string AppDisplayed = "appDisplayed";

			// Token: 0x04000261 RID: 609
			public const string GoHome = "goHome";

			// Token: 0x04000262 RID: 610
			public const string IsKeyboardEnabled = "isKeyboardEnabled";

			// Token: 0x04000263 RID: 611
			public const string SetKeymappingState = "setKeymappingState";

			// Token: 0x04000264 RID: 612
			public const string Keymap = "keymap";

			// Token: 0x04000265 RID: 613
			public const string SetFrontendVisibility = "setFrontendVisibility";

			// Token: 0x04000266 RID: 614
			public const string GetFeSize = "getFeSize";

			// Token: 0x04000267 RID: 615
			public const string Mute = "mute";

			// Token: 0x04000268 RID: 616
			public const string Unmute = "unmute";

			// Token: 0x04000269 RID: 617
			public const string GetCurrentKeymappingStatus = "getCurrentKeymappingStatus";

			// Token: 0x0400026A RID: 618
			public const string Shake = "shake";

			// Token: 0x0400026B RID: 619
			public const string IsKeyNameFocussed = "isKeyNameFocussed";

			// Token: 0x0400026C RID: 620
			public const string AndroidImeSelected = "androidImeSelected";

			// Token: 0x0400026D RID: 621
			public const string IsGpsSupported = "isGpsSupported";

			// Token: 0x0400026E RID: 622
			public const string InstallApk = "installApk";

			// Token: 0x0400026F RID: 623
			public const string InjectCopy = "injectCopy";

			// Token: 0x04000270 RID: 624
			public const string InjectPaste = "injectPaste";

			// Token: 0x04000271 RID: 625
			public const string StopZygote = "stopZygote";

			// Token: 0x04000272 RID: 626
			public const string StartZygote = "startZygote";

			// Token: 0x04000273 RID: 627
			public const string GetKeyMappingParserVersion = "getKeyMappingParserVersion";

			// Token: 0x04000274 RID: 628
			public const string VibrateHostWindow = "vibrateHostWindow";

			// Token: 0x04000275 RID: 629
			public const string LocaleChanged = "localeChanged";

			// Token: 0x04000276 RID: 630
			public const string GetScreenshot = "getScreenshot";

			// Token: 0x04000277 RID: 631
			public const string SetPcImeWorkflow = "setPcImeWorkflow";

			// Token: 0x04000278 RID: 632
			public const string SetUserInfo = "setUserInfo";

			// Token: 0x04000279 RID: 633
			public const string GetUserInfo = "getUserInfo";

			// Token: 0x0400027A RID: 634
			public const string GetPremium = "getPremium";

			// Token: 0x0400027B RID: 635
			public const string SetCursorStyle = "setCursorStyle";

			// Token: 0x0400027C RID: 636
			public const string OpenMacroWindow = "openMacroWindow";

			// Token: 0x0400027D RID: 637
			public const string StartReroll = "startReroll";

			// Token: 0x0400027E RID: 638
			public const string AbortReroll = "abortReroll";

			// Token: 0x0400027F RID: 639
			public const string SetPackagesForInteraction = "setPackagesForInteraction";

			// Token: 0x04000280 RID: 640
			public const string GetInteractionForPackage = "getInteractionForPackage";

			// Token: 0x04000281 RID: 641
			public const string ToggleScreen = "toggleScreen";

			// Token: 0x04000282 RID: 642
			public const string SendGlWindowSize = "sendGlWindowSize";

			// Token: 0x04000283 RID: 643
			public const string DeactivateFrontend = "deactivateFrontend";

			// Token: 0x04000284 RID: 644
			public const string StartRecordingCombo = "startRecordingCombo";

			// Token: 0x04000285 RID: 645
			public const string StopRecordingCombo = "stopRecordingCombo";

			// Token: 0x04000286 RID: 646
			public const string HandleClientOperation = "handleClientOperation";

			// Token: 0x04000287 RID: 647
			public const string StartMacroPlayback = "startMacroPlayback";

			// Token: 0x04000288 RID: 648
			public const string StopMacroPlayback = "stopMacroPlayback";

			// Token: 0x04000289 RID: 649
			public const string FarmModeHandler = "farmModeHandler";

			// Token: 0x0400028A RID: 650
			public const string StartOperationsSync = "startOperationsSync";

			// Token: 0x0400028B RID: 651
			public const string StopOperationsSync = "stopOperationsSync";

			// Token: 0x0400028C RID: 652
			public const string StartSyncConsumer = "startSyncConsumer";

			// Token: 0x0400028D RID: 653
			public const string StopSyncConsumer = "stopSyncConsumer";

			// Token: 0x0400028E RID: 654
			public const string ShowFPS = "showFPS";

			// Token: 0x0400028F RID: 655
			public const string CloseCrashedAppTab = "closeCrashedAppTab";

			// Token: 0x04000290 RID: 656
			public const string OTSCompleted = "oneTimeSetupCompleted";

			// Token: 0x04000291 RID: 657
			public const string VisibleChangedUri = "frontendVisibleChanged";

			// Token: 0x04000292 RID: 658
			public const string AppDataFEUrl = "appDataFeUrl";

			// Token: 0x04000293 RID: 659
			public const string RunAppInfo = "runAppInfo";

			// Token: 0x04000294 RID: 660
			public const string StopAppInfo = "stopAppInfo";

			// Token: 0x04000295 RID: 661
			public const string QuitFrontend = "quitFrontend";

			// Token: 0x04000296 RID: 662
			public const string ShowFeNotification = "showFeNotification";

			// Token: 0x04000297 RID: 663
			public const string ToggleGamepadButton = "toggleGamepadButton";

			// Token: 0x04000298 RID: 664
			public const string DeviceProvisioned = "deviceProvisioned";

			// Token: 0x04000299 RID: 665
			public const string GoogleSignin = "googleSignin";

			// Token: 0x0400029A RID: 666
			public const string ShowFENotification = "showFENotification";

			// Token: 0x0400029B RID: 667
			public const string IsAppPlayerRooted = "isAppPlayerRooted";

			// Token: 0x0400029C RID: 668
			public const string SetIsFullscreen = "setIsFullscreen";

			// Token: 0x0400029D RID: 669
			public const string GetInteractionStats = "getInteractionStats";

			// Token: 0x0400029E RID: 670
			public const string EnableGamepad = "enableGamepad";

			// Token: 0x0400029F RID: 671
			public const string ExportCfgFile = "exportCfgFile";

			// Token: 0x040002A0 RID: 672
			public const string ImportCfgFile = "importCfgFile";

			// Token: 0x040002A1 RID: 673
			public const string EnableDebugLogs = "enableDebugLogs";

			// Token: 0x040002A2 RID: 674
			public const string RunMacroUnit = "runMacroUnit";

			// Token: 0x040002A3 RID: 675
			public const string PauseRecordingCombo = "pauseRecordingCombo";

			// Token: 0x040002A4 RID: 676
			public const string ReloadShortcutsConfig = "reloadShortcutsConfig";

			// Token: 0x040002A5 RID: 677
			public const string AccountSetupCompleted = "accountSetupCompleted";

			// Token: 0x040002A6 RID: 678
			public const string ScriptEditingModeEntered = "scriptEditingModeEntered";

			// Token: 0x040002A7 RID: 679
			public const string PlayPauseSync = "playPauseSync";

			// Token: 0x040002A8 RID: 680
			public const string ReinitGuestRegistry = "reinitGuestRegistry";

			// Token: 0x040002A9 RID: 681
			public const string UpdateMacroShortcutsDict = "updateMacroShortcutsDict";
		}

		// Token: 0x0200007C RID: 124
		public class Guest
		{
			// Token: 0x040002AA RID: 682
			public const string Ping = "ping";

			// Token: 0x040002AB RID: 683
			public const string Install = "install";

			// Token: 0x040002AC RID: 684
			public const string Xinstall = "xinstall";

			// Token: 0x040002AD RID: 685
			public const string BrowserInstall = "browserInstall";

			// Token: 0x040002AE RID: 686
			public const string Uninstall = "uninstall";

			// Token: 0x040002AF RID: 687
			public const string InstalledPackages = "installedPackages";

			// Token: 0x040002B0 RID: 688
			public const string Clipboard = "clipboard";

			// Token: 0x040002B1 RID: 689
			public const string CustomStartActivity = "customStartActivity";

			// Token: 0x040002B2 RID: 690
			public const string AmzInstall = "amzInstall";

			// Token: 0x040002B3 RID: 691
			public const string ConnectHostTemp = "connectHost";

			// Token: 0x040002B4 RID: 692
			public const string DisconnectHostTemp = "disconnectHost";

			// Token: 0x040002B5 RID: 693
			public const string ConnectHostPermanently = "connectHost?d=permanent";

			// Token: 0x040002B6 RID: 694
			public const string DisconnectHostPermanently = "disconnectHost?d=permanent";

			// Token: 0x040002B7 RID: 695
			public const string CheckAdbStatus = "checkADBStatus";

			// Token: 0x040002B8 RID: 696
			public const string CustomStartService = "customStartService";

			// Token: 0x040002B9 RID: 697
			public const string SetNewLocation = "setNewLocation";

			// Token: 0x040002BA RID: 698
			public const string BindMount = "bindmount";

			// Token: 0x040002BB RID: 699
			public const string UnbindMount = "unbindmount";

			// Token: 0x040002BC RID: 700
			public const string CheckIfGuestReady = "checkIfGuestReady";

			// Token: 0x040002BD RID: 701
			public const string IsOTSCompleted = "isOTSCompleted";

			// Token: 0x040002BE RID: 702
			public const string GetDefaultLauncher = "getDefaultLauncher";

			// Token: 0x040002BF RID: 703
			public const string SetDefaultLauncher = "setDefaultLauncher";

			// Token: 0x040002C0 RID: 704
			public const string Home = "home";

			// Token: 0x040002C1 RID: 705
			public const string RemoveAccountsInfo = "removeAccountsInfo";

			// Token: 0x040002C2 RID: 706
			public const string GetGoogleAdID = "getGoogleAdID";

			// Token: 0x040002C3 RID: 707
			public const string CheckSSLConnection = "checkSSLConnection";

			// Token: 0x040002C4 RID: 708
			public const string GetConfigList = "getConfigList";

			// Token: 0x040002C5 RID: 709
			public const string GetVolume = "getVolume";

			// Token: 0x040002C6 RID: 710
			public const string SetVolume = "setVolume";

			// Token: 0x040002C7 RID: 711
			public const string ChangePCode = "changePCode";

			// Token: 0x040002C8 RID: 712
			public const string FileDrop = "fileDrop";

			// Token: 0x040002C9 RID: 713
			public const string GetCurrentIMEID = "getCurrentIMEID";

			// Token: 0x040002CA RID: 714
			public const string IsPackageInstalled = "isPackageInstalled";

			// Token: 0x040002CB RID: 715
			public const string GetPackageDetails = "getPackageDetails";

			// Token: 0x040002CC RID: 716
			public const string GetLaunchActivityName = "getLaunchActivityName";

			// Token: 0x040002CD RID: 717
			public const string GetAppName = "getAppName";

			// Token: 0x040002CE RID: 718
			public const string AppJSonChanged = "appJSonChanged";

			// Token: 0x040002CF RID: 719
			public const string SetWindowsAgentAddr = "setWindowsAgentAddr";

			// Token: 0x040002D0 RID: 720
			public const string SetWindowsFrontendAddr = "setWindowsFrontendAddr";

			// Token: 0x040002D1 RID: 721
			public const string SetGameManagerAddr = "setGameManagerAddr";

			// Token: 0x040002D2 RID: 722
			public const string SetBlueStacksConfig = "setBlueStacksConfig";

			// Token: 0x040002D3 RID: 723
			public const string ShowTrayNotification = "showTrayNotification";

			// Token: 0x040002D4 RID: 724
			public const string MuteAppPlayer = "muteAppPlayer";

			// Token: 0x040002D5 RID: 725
			public const string UnmuteAppPlayer = "unmuteAppPlayer";

			// Token: 0x040002D6 RID: 726
			public const string HostOrientation = "hostOrientation";

			// Token: 0x040002D7 RID: 727
			public const string GetProp = "getprop";

			// Token: 0x040002D8 RID: 728
			public const string GetAndroidID = "getAndroidID";

			// Token: 0x040002D9 RID: 729
			public const string GuestOrientation = "guestorientation";

			// Token: 0x040002DA RID: 730
			public const string IsSharedFolderMounted = "isSharedFolderMounted";

			// Token: 0x040002DB RID: 731
			public const string GameSettingsEnabled = "gameSettingsEnabled";
		}

		// Token: 0x0200007D RID: 125
		public class NCSoftAgent
		{
			// Token: 0x040002DC RID: 732
			public const string AccountGoogleLogin = "account/google/login";

			// Token: 0x040002DD RID: 733
			public const string ErrorCrash = "error/crash";

			// Token: 0x040002DE RID: 734
			public const string ActionButtonStreaming = "action/button/streaming";
		}
	}
}
