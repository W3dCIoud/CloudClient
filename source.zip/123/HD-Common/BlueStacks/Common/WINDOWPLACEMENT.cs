﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000135 RID: 309
	[Serializable]
	public struct WINDOWPLACEMENT
	{
		// Token: 0x0400077A RID: 1914
		public int length;

		// Token: 0x0400077B RID: 1915
		public int flags;

		// Token: 0x0400077C RID: 1916
		public int showCmd;

		// Token: 0x0400077D RID: 1917
		public POINT minPosition;

		// Token: 0x0400077E RID: 1918
		public POINT maxPosition;

		// Token: 0x0400077F RID: 1919
		public RECT normalPosition;
	}
}
