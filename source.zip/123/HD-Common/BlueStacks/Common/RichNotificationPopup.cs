﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x02000138 RID: 312
	public class RichNotificationPopup : CustomWindow, IComponentConnector
	{
		// Token: 0x170002B5 RID: 693
		// (set) Token: 0x06000A95 RID: 2709 RVA: 0x0000A393 File Offset: 0x00008593
		public string BackgroundImage
		{
			set
			{
				this.mBackgroundImage.ImageName = value;
			}
		}

		// Token: 0x170002B6 RID: 694
		// (set) Token: 0x06000A96 RID: 2710 RVA: 0x0000A3A1 File Offset: 0x000085A1
		public string GameIcon
		{
			set
			{
				this.mGameIcon.ImageName = value;
			}
		}

		// Token: 0x170002B7 RID: 695
		// (set) Token: 0x06000A97 RID: 2711 RVA: 0x0000A3AF File Offset: 0x000085AF
		public string GameTitleText
		{
			set
			{
				this.mGameTitle.Text = value;
			}
		}

		// Token: 0x170002B8 RID: 696
		// (set) Token: 0x06000A98 RID: 2712 RVA: 0x0000A3BD File Offset: 0x000085BD
		public string GameDeveloperText
		{
			set
			{
				this.mGameDeveloper.Text = value;
			}
		}

		// Token: 0x170002B9 RID: 697
		// (get) Token: 0x06000A99 RID: 2713 RVA: 0x0000A3CB File Offset: 0x000085CB
		// (set) Token: 0x06000A9A RID: 2714 RVA: 0x0000A3D3 File Offset: 0x000085D3
		public CustomButton Button
		{
			get
			{
				return this.mButton;
			}
			set
			{
				this.mButton = value;
			}
		}

		// Token: 0x170002BA RID: 698
		// (set) Token: 0x06000A9B RID: 2715 RVA: 0x0000A3DC File Offset: 0x000085DC
		public MouseButtonEventHandler CloseButtonHandler
		{
			set
			{
				this.mCloseButton.PreviewMouseLeftButtonUp += value;
			}
		}

		// Token: 0x170002BB RID: 699
		// (set) Token: 0x06000A9C RID: 2716 RVA: 0x0000A3EA File Offset: 0x000085EA
		public MouseButtonEventHandler MuteButtonHandler
		{
			set
			{
				this.mMuteButton.PreviewMouseLeftButtonUp += value;
			}
		}

		// Token: 0x170002BC RID: 700
		// (set) Token: 0x06000A9D RID: 2717 RVA: 0x0000A3F8 File Offset: 0x000085F8
		public bool IsCentered
		{
			set
			{
				if (value)
				{
					this.SetWindowStyle(RichPopupStyles.Centered);
					return;
				}
				this.SetWindowStyle(RichPopupStyles.Simple);
			}
		}

		// Token: 0x06000A9E RID: 2718 RVA: 0x0002EDDC File Offset: 0x0002CFDC
		private void SetWindowStyle(RichPopupStyles style)
		{
			if (style == RichPopupStyles.Centered)
			{
				base.Width = 600.0;
				base.Height = 380.0;
				base.WindowStartupLocation = WindowStartupLocation.CenterScreen;
				return;
			}
			if (style != RichPopupStyles.Simple)
			{
				return;
			}
			base.Width = 320.0;
			base.Height = 210.0;
			base.Left = SystemParameters.FullPrimaryScreenWidth - base.Width - 16.0;
			base.Top = SystemParameters.FullPrimaryScreenHeight - base.Height;
			this.mMuteButton.Height = (this.mMuteButton.Width = 16.0);
			this.mMuteButton.Margin = new Thickness(0.0, 0.0, 5.0, 0.0);
			this.mCloseButton.Height = (this.mCloseButton.Width = 16.0);
			this.mBottomGrid.Margin = new Thickness(10.0);
			this.mBottomGrid.Height = 26.0;
			this.mGameTitle.FontSize = 11.0;
			Grid.SetRowSpan(this.mGameTitle, 2);
			this.mGameTitle.VerticalAlignment = VerticalAlignment.Center;
			this.mGameDeveloper.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000A9F RID: 2719 RVA: 0x0000A40C File Offset: 0x0000860C
		public RichNotificationPopup()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000AA0 RID: 2720 RVA: 0x00003337 File Offset: 0x00001537
		private void mCloseButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
		}

		// Token: 0x06000AA1 RID: 2721 RVA: 0x0002EF40 File Offset: 0x0002D140
		public void ShowWindow()
		{
			string path = Path.Combine(RegistryManager.Instance.UserDefinedDir, "Client\\Helper");
			this.mMuteButton.ImageName = Path.Combine(path, "mute2.png");
			this.mCloseButton.ImageName = Path.Combine(path, "close.png");
			this.mMuteButton.ToolTip = LocaleStrings.GetLocalizedString("STRING_MUTE_NOTIFICATION_TOOLTIP", false);
			this.mCloseButton.ToolTip = LocaleStrings.GetLocalizedString("STRING_CLOSE", false);
			base.ShowDialog();
		}

		// Token: 0x06000AA2 RID: 2722 RVA: 0x0002EFC4 File Offset: 0x0002D1C4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/wpf/richnotificationpopup.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000AA3 RID: 2723 RVA: 0x00003339 File Offset: 0x00001539
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000AA4 RID: 2724 RVA: 0x0002EFF4 File Offset: 0x0002D1F4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mBackgroundImage = (CustomPictureBox)target;
				return;
			case 2:
				this.mCloseButtonGrid = (Grid)target;
				return;
			case 3:
				this.mCloseButtonStackPanel = (StackPanel)target;
				return;
			case 4:
				this.mMuteButton = (CustomPictureBox)target;
				return;
			case 5:
				this.mCloseButton = (CustomPictureBox)target;
				return;
			case 6:
				this.mBottomGrid = (Grid)target;
				return;
			case 7:
				this.mGameIcon = (CustomPictureBox)target;
				return;
			case 8:
				this.mGameDescriptionGrid = (Grid)target;
				return;
			case 9:
				this.mGameTitle = (TextBlock)target;
				return;
			case 10:
				this.mGameDeveloper = (TextBlock)target;
				return;
			case 11:
				this.mButton = (CustomButton)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000789 RID: 1929
		public string AssetFolderPath = Path.Combine(RegistryManager.Instance.ClientInstallDir, RegistryManager.Instance.ClientThemeName);

		// Token: 0x0400078A RID: 1930
		internal CustomPictureBox mBackgroundImage;

		// Token: 0x0400078B RID: 1931
		internal Grid mCloseButtonGrid;

		// Token: 0x0400078C RID: 1932
		internal StackPanel mCloseButtonStackPanel;

		// Token: 0x0400078D RID: 1933
		internal CustomPictureBox mMuteButton;

		// Token: 0x0400078E RID: 1934
		internal CustomPictureBox mCloseButton;

		// Token: 0x0400078F RID: 1935
		internal Grid mBottomGrid;

		// Token: 0x04000790 RID: 1936
		internal CustomPictureBox mGameIcon;

		// Token: 0x04000791 RID: 1937
		internal Grid mGameDescriptionGrid;

		// Token: 0x04000792 RID: 1938
		internal TextBlock mGameTitle;

		// Token: 0x04000793 RID: 1939
		internal TextBlock mGameDeveloper;

		// Token: 0x04000794 RID: 1940
		internal CustomButton mButton;

		// Token: 0x04000795 RID: 1941
		private bool _contentLoaded;
	}
}
