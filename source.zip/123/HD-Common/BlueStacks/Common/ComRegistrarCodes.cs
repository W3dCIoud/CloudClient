﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000196 RID: 406
	public enum ComRegistrarCodes
	{
		// Token: 0x04000AB5 RID: 2741
		SUCCESS,
		// Token: 0x04000AB6 RID: 2742
		ALREADY_RUNNING,
		// Token: 0x04000AB7 RID: 2743
		INVALID_ARGS,
		// Token: 0x04000AB8 RID: 2744
		UNHANDLED_EXCEPTION,
		// Token: 0x04000AB9 RID: 2745
		NON_ADMIN_CONTEXT,
		// Token: 0x04000ABA RID: 2746
		REGISTRATION_FAILED = 10
	}
}
