﻿using System;
using System.Collections.Generic;
using System.IO;

namespace BlueStacks.Common
{
	// Token: 0x020000E4 RID: 228
	public sealed class Oem
	{
		// Token: 0x170001C7 RID: 455
		// (get) Token: 0x06000683 RID: 1667 RVA: 0x0001F908 File Offset: 0x0001DB08
		public static Oem Instance
		{
			get
			{
				if (Oem.sInstance == null)
				{
					object obj = Oem.syncRoot;
					lock (obj)
					{
						if (Oem.sInstance == null)
						{
							Oem oem = new Oem();
							oem.LoadOem();
							Oem.sInstance = oem;
						}
					}
				}
				return Oem.sInstance;
			}
		}

		// Token: 0x06000684 RID: 1668 RVA: 0x0001F968 File Offset: 0x0001DB68
		private void LoadOem()
		{
			try
			{
				string text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Oem.sFileName);
				Logger.Info("Attempting to load {0} from path: {1}", new object[]
				{
					Oem.sFileName,
					text
				});
				if (!File.Exists(text))
				{
					text = Oem.sCurrentFilePath;
					if (!File.Exists(text))
					{
						throw new Exception(string.Format("{0} file not found", Oem.sFileName));
					}
				}
				Oem.sCurrentFilePath = text;
				foreach (string text2 in File.ReadAllLines(text))
				{
					if (text2.IndexOf("=") != -1)
					{
						string[] array2 = text2.Split(new char[]
						{
							'='
						});
						this.mPropertiesDictionary[array2[0].Trim()] = array2[1].Trim();
					}
				}
				this.LoadProperties();
			}
			catch (Exception ex)
			{
				Logger.Error("An exception occured while loading Oem config file, loading default values: " + ex.Message);
				Oem.sInstance = new Oem();
			}
		}

		// Token: 0x06000685 RID: 1669 RVA: 0x000069BF File Offset: 0x00004BBF
		private T GetObjectValueForKey<T>(string propertyName, T defaultValue)
		{
			if (this.mPropertiesDictionary.ContainsKey(propertyName))
			{
				return this.mPropertiesDictionary[propertyName].GetObjectOfType(defaultValue);
			}
			return defaultValue;
		}

		// Token: 0x06000686 RID: 1670 RVA: 0x000069E3 File Offset: 0x00004BE3
		private string GetStringValueOrDefault(string propertyName, string defaultValue)
		{
			if (this.mPropertiesDictionary.ContainsKey(propertyName))
			{
				return this.mPropertiesDictionary[propertyName];
			}
			return defaultValue;
		}

		// Token: 0x06000687 RID: 1671 RVA: 0x0001FA6C File Offset: 0x0001DC6C
		private void LoadProperties()
		{
			this.mWindowsOEMFeatures = this.GetObjectValueForKey<ulong>("WindowsOEMFeatures", 0UL);
			this.mAppsOEMFeaturesBits = this.GetObjectValueForKey<ulong>("AppsOEMFeaturesBits", 0UL);
			this.mPartnerControlBarHeight = this.GetObjectValueForKey<int>("PartnerControlBarHeight", 0);
			this.mAndroidFeatureBits = this.GetObjectValueForKey<uint>("AndroidFeatureBits", 0U);
			this.mSendAppClickStatsFromClient = this.GetObjectValueForKey<bool>("SendAppClickStatsFromClient", false);
			this.mIsPixelParityToBeIgnored = this.GetObjectValueForKey<bool>("IsPixelParityToBeIgnored", false);
			this.mIsShowVersionOnSysTrayToolTip = this.GetObjectValueForKey<bool>("IsShowVersionOnSysTrayToolTip", true);
			this.mIsVTPopupEnabled = this.GetObjectValueForKey<bool>("IsVTPopupEnabled", false);
			this.mIsUseFrontendBanner = this.GetObjectValueForKey<bool>("IsUseFrontendBanner", false);
			this.mIsFrontendFormLocation6 = this.GetObjectValueForKey<bool>("IsFrontendFormLocation6", false);
			this.mIsMessageBoxToBeDisplayed = this.GetObjectValueForKey<bool>("IsMessageBoxToBeDisplayed", true);
			this.mIsResizeFrontendWindow = this.GetObjectValueForKey<bool>("IsResizeFrontendWindow", true);
			this.mIsFrontendBorderHidden = this.GetObjectValueForKey<bool>("IsFrontendBorderHidden", false);
			this.mIsOnlyStopButtonToBeAddedInContextMenuOFSysTray = this.GetObjectValueForKey<bool>("IsOnlyStopButtonToBeAddedInContextMenuOFSysTray", false);
			this.mIsCountryChina = this.GetObjectValueForKey<bool>("IsCountryChina", false);
			this.mIsLoadCACodeFromCloud = this.GetObjectValueForKey<bool>("IsLoadCACodeFromCloud", true);
			this.mIsSendGameManagerRequest = this.GetObjectValueForKey<bool>("IsSendGameManagerRequest", false);
			this.mIsHideMessageBoxIconInTaskBar = this.GetObjectValueForKey<bool>("IsHideMessageBoxIconInTaskBar", false);
			this.mIsLefClickOnTrayIconLaunchPartner = this.GetObjectValueForKey<bool>("IsLefClickOnTrayIconLaunchPartner", false);
			this.mIsGameManagerToBeStartedOnRunApp = this.GetObjectValueForKey<bool>("IsGameManagerToBeStartedOnRunApp", false);
			this.mIsCreateDesktopIconForApp = this.GetObjectValueForKey<bool>("IsCreateDesktopIconForApp", false);
			this.mIsDownloadIconFromWeb = this.GetObjectValueForKey<bool>("IsDownloadIconFromWeb", false);
			this.mIsSysTrayIconTextToBeBlueStacks3 = this.GetObjectValueForKey<bool>("IsSysTrayIconTextToBeBlueStacks3", false);
			this.mIsOEMWithBGPClient = this.GetObjectValueForKey<bool>("IsOEMWithBGPClient", false);
			this.mIsLaunchUIOnRunApp = this.GetObjectValueForKey<bool>("IsLaunchUIOnRunApp", false);
			this.mIsRemoveAccountOnExit = this.GetObjectValueForKey<bool>("IsRemoveAccountOnExit", false);
			this.mIsFormBorderStyleFixedSingle = this.GetObjectValueForKey<bool>("IsFormBorderStyleFixedSingle", false);
			this.mCreateDesktopIcons = this.GetObjectValueForKey<bool>("CreateDesktopIcons", true);
			this.mCreateMultiInstanceManagerIcon = this.GetObjectValueForKey<bool>("CreateMultiInstanceManagerIcon", false);
			this.mIsBackupWarningVisible = this.GetObjectValueForKey<bool>("IsBackupWarningVisible", true);
			this.mIsWriteRegistryInfoInFile = this.GetObjectValueForKey<bool>("IsWriteRegistryInfoInFile", false);
			this.mIsCreateInstallApkRegistry = this.GetObjectValueForKey<bool>("IsCreateInstallApkRegistry", true);
			this.mIsCreateDesktopAndStartMenuShortcut = this.GetObjectValueForKey<bool>("IsCreateDesktopAndStartMenuShortcut", true);
			this.mIsDragDropEnabled = this.GetObjectValueForKey<bool>("IsDragDropEnabled", true);
			this.mIsProductBeta = this.GetObjectValueForKey<bool>("IsProductBeta", false);
			this.mIsSwitchToAndroidHome = this.GetObjectValueForKey<bool>("IsSwitchToAndroidHome", false);
			this.mIsResetSigninRegistryForFreshVM = this.GetObjectValueForKey<bool>("IsResetSigninRegistryForFreshVM", true);
			this.mCreateUninstallEntry = this.GetObjectValueForKey<bool>("CreateUninstallEntry", true);
			this.mCheckForAGAInInstaller = this.GetObjectValueForKey<bool>("CheckForAGAInInstaller", false);
			this.mMsgWindowClassName = this.GetStringValueOrDefault("MsgWindowClassName", null);
			this.mMsgWindowTitle = this.GetStringValueOrDefault("MsgWindowTitle", null);
			this.mOem = this.GetStringValueOrDefault("OEM", "gamemanager");
			this.mDnsValue = this.GetStringValueOrDefault("DNSValue", "8.8.8.8");
			this.mDefaultTitle = this.GetStringValueOrDefault("DefaultTitle", "DefaultTitle");
			this.mDesktopShortcutFileName = this.GetStringValueOrDefault("DesktopShortcutFileName", "");
			this.mBlueStacksApkHandlerTitle = this.GetStringValueOrDefault("BlueStacksApkHandlerTitle", "BlueStacksApkHandlerTitle");
			this.mCommonAppTitleText = this.GetStringValueOrDefault("CommonAppTitleText", "BlueStacks Android Plugin");
			this.mSnapShotShareString = this.GetStringValueOrDefault("SnapShotShareString", "SnapShotShareString");
			this.mDmmApiPrefix = this.GetStringValueOrDefault("DMMApiPrefix", string.Empty);
			this.mControlPanelDisplayName = this.GetStringValueOrDefault("ControlPanelDisplayName", "BlueStacks App Player");
			this.mStartMenuShortcutName = this.GetStringValueOrDefault("StartMenuShortcutName", "");
		}

		// Token: 0x06000688 RID: 1672 RVA: 0x0001FE3C File Offset: 0x0001E03C
		public void ReInit()
		{
			object obj = Oem.syncRoot;
			lock (obj)
			{
				Oem.sInstance = null;
			}
		}

		// Token: 0x06000689 RID: 1673 RVA: 0x00006A01 File Offset: 0x00004C01
		public string GetTitle(string title)
		{
			if (this.DefaultTitle.Equals("DefaultTitle"))
			{
				return title;
			}
			return this.DefaultTitle;
		}

		// Token: 0x170001C8 RID: 456
		// (get) Token: 0x0600068A RID: 1674 RVA: 0x00006A1D File Offset: 0x00004C1D
		// (set) Token: 0x0600068B RID: 1675 RVA: 0x00006A25 File Offset: 0x00004C25
		public ulong WindowsOEMFeatures
		{
			get
			{
				return this.mWindowsOEMFeatures;
			}
			set
			{
				this.mWindowsOEMFeatures = value;
			}
		}

		// Token: 0x170001C9 RID: 457
		// (get) Token: 0x0600068C RID: 1676 RVA: 0x00006A2E File Offset: 0x00004C2E
		// (set) Token: 0x0600068D RID: 1677 RVA: 0x00006A36 File Offset: 0x00004C36
		public ulong AppsOEMFeaturesBits
		{
			get
			{
				return this.mAppsOEMFeaturesBits;
			}
			set
			{
				this.mAppsOEMFeaturesBits = value;
			}
		}

		// Token: 0x170001CA RID: 458
		// (get) Token: 0x0600068E RID: 1678 RVA: 0x00006A3F File Offset: 0x00004C3F
		// (set) Token: 0x0600068F RID: 1679 RVA: 0x00006A47 File Offset: 0x00004C47
		public string MsgWindowClassName
		{
			get
			{
				return this.mMsgWindowClassName;
			}
			set
			{
				this.mMsgWindowClassName = value;
			}
		}

		// Token: 0x170001CB RID: 459
		// (get) Token: 0x06000690 RID: 1680 RVA: 0x00006A50 File Offset: 0x00004C50
		// (set) Token: 0x06000691 RID: 1681 RVA: 0x00006A58 File Offset: 0x00004C58
		public string MsgWindowTitle
		{
			get
			{
				return this.mMsgWindowTitle;
			}
			set
			{
				this.mMsgWindowTitle = value;
			}
		}

		// Token: 0x170001CC RID: 460
		// (get) Token: 0x06000692 RID: 1682 RVA: 0x00006A61 File Offset: 0x00004C61
		// (set) Token: 0x06000693 RID: 1683 RVA: 0x00006A69 File Offset: 0x00004C69
		public uint AndroidFeatureBits
		{
			get
			{
				return this.mAndroidFeatureBits;
			}
			set
			{
				this.mAndroidFeatureBits = value;
			}
		}

		// Token: 0x170001CD RID: 461
		// (get) Token: 0x06000694 RID: 1684 RVA: 0x00006A72 File Offset: 0x00004C72
		// (set) Token: 0x06000695 RID: 1685 RVA: 0x00006A7A File Offset: 0x00004C7A
		public bool SendAppClickStatsFromClient
		{
			get
			{
				return this.mSendAppClickStatsFromClient;
			}
			set
			{
				this.mSendAppClickStatsFromClient = value;
			}
		}

		// Token: 0x170001CE RID: 462
		// (get) Token: 0x06000696 RID: 1686 RVA: 0x00006A83 File Offset: 0x00004C83
		// (set) Token: 0x06000697 RID: 1687 RVA: 0x00006A8B File Offset: 0x00004C8B
		public bool IsPixelParityToBeIgnored
		{
			get
			{
				return this.mIsPixelParityToBeIgnored;
			}
			set
			{
				this.mIsPixelParityToBeIgnored = value;
			}
		}

		// Token: 0x170001CF RID: 463
		// (get) Token: 0x06000698 RID: 1688 RVA: 0x00006A94 File Offset: 0x00004C94
		// (set) Token: 0x06000699 RID: 1689 RVA: 0x00006A9C File Offset: 0x00004C9C
		public bool IsShowVersionOnSysTrayToolTip
		{
			get
			{
				return this.mIsShowVersionOnSysTrayToolTip;
			}
			set
			{
				this.mIsShowVersionOnSysTrayToolTip = value;
			}
		}

		// Token: 0x170001D0 RID: 464
		// (get) Token: 0x0600069A RID: 1690 RVA: 0x00006AA5 File Offset: 0x00004CA5
		// (set) Token: 0x0600069B RID: 1691 RVA: 0x00006AAD File Offset: 0x00004CAD
		public bool IsVTPopupEnabled
		{
			get
			{
				return this.mIsVTPopupEnabled;
			}
			set
			{
				this.mIsVTPopupEnabled = value;
			}
		}

		// Token: 0x170001D1 RID: 465
		// (get) Token: 0x0600069C RID: 1692 RVA: 0x00006AB6 File Offset: 0x00004CB6
		// (set) Token: 0x0600069D RID: 1693 RVA: 0x00006ABE File Offset: 0x00004CBE
		public bool IsUseFrontendBanner
		{
			get
			{
				return this.mIsUseFrontendBanner;
			}
			set
			{
				this.mIsUseFrontendBanner = value;
			}
		}

		// Token: 0x170001D2 RID: 466
		// (get) Token: 0x0600069E RID: 1694 RVA: 0x00006AC7 File Offset: 0x00004CC7
		// (set) Token: 0x0600069F RID: 1695 RVA: 0x00006ACF File Offset: 0x00004CCF
		public bool IsFrontendFormLocation6
		{
			get
			{
				return this.mIsFrontendFormLocation6;
			}
			set
			{
				this.mIsFrontendFormLocation6 = value;
			}
		}

		// Token: 0x170001D3 RID: 467
		// (get) Token: 0x060006A0 RID: 1696 RVA: 0x00006AD8 File Offset: 0x00004CD8
		// (set) Token: 0x060006A1 RID: 1697 RVA: 0x00006AE0 File Offset: 0x00004CE0
		public bool IsMessageBoxToBeDisplayed
		{
			get
			{
				return this.mIsMessageBoxToBeDisplayed;
			}
			set
			{
				this.mIsMessageBoxToBeDisplayed = value;
			}
		}

		// Token: 0x170001D4 RID: 468
		// (get) Token: 0x060006A2 RID: 1698 RVA: 0x00006AE9 File Offset: 0x00004CE9
		// (set) Token: 0x060006A3 RID: 1699 RVA: 0x00006AF1 File Offset: 0x00004CF1
		public int PartnerControlBarHeight
		{
			get
			{
				return this.mPartnerControlBarHeight;
			}
			set
			{
				this.mPartnerControlBarHeight = value;
			}
		}

		// Token: 0x170001D5 RID: 469
		// (get) Token: 0x060006A4 RID: 1700 RVA: 0x00006AFA File Offset: 0x00004CFA
		// (set) Token: 0x060006A5 RID: 1701 RVA: 0x00006B02 File Offset: 0x00004D02
		public bool IsResizeFrontendWindow
		{
			get
			{
				return this.mIsResizeFrontendWindow;
			}
			set
			{
				this.mIsResizeFrontendWindow = value;
			}
		}

		// Token: 0x170001D6 RID: 470
		// (get) Token: 0x060006A6 RID: 1702 RVA: 0x00006B0B File Offset: 0x00004D0B
		// (set) Token: 0x060006A7 RID: 1703 RVA: 0x00006B13 File Offset: 0x00004D13
		public bool IsFrontendBorderHidden
		{
			get
			{
				return this.mIsFrontendBorderHidden;
			}
			set
			{
				this.mIsFrontendBorderHidden = value;
			}
		}

		// Token: 0x170001D7 RID: 471
		// (get) Token: 0x060006A8 RID: 1704 RVA: 0x00006B1C File Offset: 0x00004D1C
		// (set) Token: 0x060006A9 RID: 1705 RVA: 0x00006B24 File Offset: 0x00004D24
		public bool IsOnlyStopButtonToBeAddedInContextMenuOFSysTray
		{
			get
			{
				return this.mIsOnlyStopButtonToBeAddedInContextMenuOFSysTray;
			}
			set
			{
				this.mIsOnlyStopButtonToBeAddedInContextMenuOFSysTray = value;
			}
		}

		// Token: 0x170001D8 RID: 472
		// (get) Token: 0x060006AA RID: 1706 RVA: 0x00006B2D File Offset: 0x00004D2D
		// (set) Token: 0x060006AB RID: 1707 RVA: 0x00006B35 File Offset: 0x00004D35
		public bool IsCountryChina
		{
			get
			{
				return this.mIsCountryChina;
			}
			set
			{
				this.mIsCountryChina = value;
			}
		}

		// Token: 0x170001D9 RID: 473
		// (get) Token: 0x060006AC RID: 1708 RVA: 0x00006B3E File Offset: 0x00004D3E
		// (set) Token: 0x060006AD RID: 1709 RVA: 0x00006B46 File Offset: 0x00004D46
		public bool IsLoadCACodeFromCloud
		{
			get
			{
				return this.mIsLoadCACodeFromCloud;
			}
			set
			{
				this.mIsLoadCACodeFromCloud = value;
			}
		}

		// Token: 0x170001DA RID: 474
		// (get) Token: 0x060006AE RID: 1710 RVA: 0x00006B4F File Offset: 0x00004D4F
		// (set) Token: 0x060006AF RID: 1711 RVA: 0x00006B57 File Offset: 0x00004D57
		public bool IsSendGameManagerRequest
		{
			get
			{
				return this.mIsSendGameManagerRequest;
			}
			set
			{
				this.mIsSendGameManagerRequest = value;
			}
		}

		// Token: 0x170001DB RID: 475
		// (get) Token: 0x060006B0 RID: 1712 RVA: 0x00006B60 File Offset: 0x00004D60
		// (set) Token: 0x060006B1 RID: 1713 RVA: 0x00006B68 File Offset: 0x00004D68
		public bool IsHideMessageBoxIconInTaskBar
		{
			get
			{
				return this.mIsHideMessageBoxIconInTaskBar;
			}
			set
			{
				this.mIsHideMessageBoxIconInTaskBar = value;
			}
		}

		// Token: 0x170001DC RID: 476
		// (get) Token: 0x060006B2 RID: 1714 RVA: 0x00006B71 File Offset: 0x00004D71
		// (set) Token: 0x060006B3 RID: 1715 RVA: 0x00006B79 File Offset: 0x00004D79
		public bool IsLefClickOnTrayIconLaunchPartner
		{
			get
			{
				return this.mIsLefClickOnTrayIconLaunchPartner;
			}
			set
			{
				this.mIsLefClickOnTrayIconLaunchPartner = value;
			}
		}

		// Token: 0x170001DD RID: 477
		// (get) Token: 0x060006B4 RID: 1716 RVA: 0x00006B82 File Offset: 0x00004D82
		// (set) Token: 0x060006B5 RID: 1717 RVA: 0x00006B8A File Offset: 0x00004D8A
		public bool IsGameManagerToBeStartedOnRunApp
		{
			get
			{
				return this.mIsGameManagerToBeStartedOnRunApp;
			}
			set
			{
				this.mIsGameManagerToBeStartedOnRunApp = value;
			}
		}

		// Token: 0x170001DE RID: 478
		// (get) Token: 0x060006B6 RID: 1718 RVA: 0x00006B93 File Offset: 0x00004D93
		// (set) Token: 0x060006B7 RID: 1719 RVA: 0x00006B9B File Offset: 0x00004D9B
		public bool IsCreateDesktopIconForApp
		{
			get
			{
				return this.mIsCreateDesktopIconForApp;
			}
			set
			{
				this.mIsCreateDesktopIconForApp = value;
			}
		}

		// Token: 0x170001DF RID: 479
		// (get) Token: 0x060006B8 RID: 1720 RVA: 0x00006BA4 File Offset: 0x00004DA4
		// (set) Token: 0x060006B9 RID: 1721 RVA: 0x00006BAC File Offset: 0x00004DAC
		public bool IsDownloadIconFromWeb
		{
			get
			{
				return this.mIsDownloadIconFromWeb;
			}
			set
			{
				this.mIsDownloadIconFromWeb = value;
			}
		}

		// Token: 0x170001E0 RID: 480
		// (get) Token: 0x060006BA RID: 1722 RVA: 0x00006BB5 File Offset: 0x00004DB5
		// (set) Token: 0x060006BB RID: 1723 RVA: 0x00006BBD File Offset: 0x00004DBD
		public bool IsSysTrayIconTextToBeBlueStacks3
		{
			get
			{
				return this.mIsSysTrayIconTextToBeBlueStacks3;
			}
			set
			{
				this.mIsSysTrayIconTextToBeBlueStacks3 = value;
			}
		}

		// Token: 0x170001E1 RID: 481
		// (get) Token: 0x060006BC RID: 1724 RVA: 0x00006BC6 File Offset: 0x00004DC6
		// (set) Token: 0x060006BD RID: 1725 RVA: 0x00006BCE File Offset: 0x00004DCE
		public bool IsOEMWithBGPClient
		{
			get
			{
				return this.mIsOEMWithBGPClient;
			}
			set
			{
				this.mIsOEMWithBGPClient = value;
			}
		}

		// Token: 0x170001E2 RID: 482
		// (get) Token: 0x060006BE RID: 1726 RVA: 0x00006BD7 File Offset: 0x00004DD7
		// (set) Token: 0x060006BF RID: 1727 RVA: 0x00006BDF File Offset: 0x00004DDF
		public bool IsLaunchUIOnRunApp
		{
			get
			{
				return this.mIsLaunchUIOnRunApp;
			}
			set
			{
				this.mIsLaunchUIOnRunApp = value;
			}
		}

		// Token: 0x170001E3 RID: 483
		// (get) Token: 0x060006C0 RID: 1728 RVA: 0x00006BE8 File Offset: 0x00004DE8
		// (set) Token: 0x060006C1 RID: 1729 RVA: 0x00006BF0 File Offset: 0x00004DF0
		public bool IsRemoveAccountOnExit
		{
			get
			{
				return this.mIsRemoveAccountOnExit;
			}
			set
			{
				this.mIsRemoveAccountOnExit = value;
			}
		}

		// Token: 0x170001E4 RID: 484
		// (get) Token: 0x060006C2 RID: 1730 RVA: 0x00006BF9 File Offset: 0x00004DF9
		// (set) Token: 0x060006C3 RID: 1731 RVA: 0x00006C01 File Offset: 0x00004E01
		public bool IsFormBorderStyleFixedSingle
		{
			get
			{
				return this.mIsFormBorderStyleFixedSingle;
			}
			set
			{
				this.mIsFormBorderStyleFixedSingle = value;
			}
		}

		// Token: 0x170001E5 RID: 485
		// (get) Token: 0x060006C4 RID: 1732 RVA: 0x00006C0A File Offset: 0x00004E0A
		// (set) Token: 0x060006C5 RID: 1733 RVA: 0x00006C12 File Offset: 0x00004E12
		public bool IsBackupWarningVisible
		{
			get
			{
				return this.mIsBackupWarningVisible;
			}
			set
			{
				this.mIsBackupWarningVisible = value;
			}
		}

		// Token: 0x170001E6 RID: 486
		// (get) Token: 0x060006C6 RID: 1734 RVA: 0x00006C1B File Offset: 0x00004E1B
		// (set) Token: 0x060006C7 RID: 1735 RVA: 0x00006C23 File Offset: 0x00004E23
		public bool IsWriteRegistryInfoInFile
		{
			get
			{
				return this.mIsWriteRegistryInfoInFile;
			}
			set
			{
				this.mIsWriteRegistryInfoInFile = value;
			}
		}

		// Token: 0x170001E7 RID: 487
		// (get) Token: 0x060006C8 RID: 1736 RVA: 0x00006C2C File Offset: 0x00004E2C
		// (set) Token: 0x060006C9 RID: 1737 RVA: 0x00006C34 File Offset: 0x00004E34
		public bool IsCreateInstallApkRegistry
		{
			get
			{
				return this.mIsCreateInstallApkRegistry;
			}
			set
			{
				this.mIsCreateInstallApkRegistry = value;
			}
		}

		// Token: 0x170001E8 RID: 488
		// (get) Token: 0x060006CA RID: 1738 RVA: 0x00006C3D File Offset: 0x00004E3D
		// (set) Token: 0x060006CB RID: 1739 RVA: 0x00006C45 File Offset: 0x00004E45
		public bool IsCreateDesktopAndStartMenuShortcut
		{
			get
			{
				return this.mIsCreateDesktopAndStartMenuShortcut;
			}
			set
			{
				this.mIsCreateDesktopAndStartMenuShortcut = value;
			}
		}

		// Token: 0x170001E9 RID: 489
		// (get) Token: 0x060006CC RID: 1740 RVA: 0x00006C4E File Offset: 0x00004E4E
		// (set) Token: 0x060006CD RID: 1741 RVA: 0x00006C56 File Offset: 0x00004E56
		public bool IsDragDropEnabled
		{
			get
			{
				return this.mIsDragDropEnabled;
			}
			set
			{
				this.mIsDragDropEnabled = value;
			}
		}

		// Token: 0x170001EA RID: 490
		// (get) Token: 0x060006CE RID: 1742 RVA: 0x00006C5F File Offset: 0x00004E5F
		// (set) Token: 0x060006CF RID: 1743 RVA: 0x00006C67 File Offset: 0x00004E67
		public bool IsProductBeta
		{
			get
			{
				return this.mIsProductBeta;
			}
			set
			{
				this.mIsProductBeta = value;
			}
		}

		// Token: 0x170001EB RID: 491
		// (get) Token: 0x060006D0 RID: 1744 RVA: 0x00006C70 File Offset: 0x00004E70
		// (set) Token: 0x060006D1 RID: 1745 RVA: 0x00006C78 File Offset: 0x00004E78
		public bool IsResetSigninRegistryForFreshVM
		{
			get
			{
				return this.mIsResetSigninRegistryForFreshVM;
			}
			set
			{
				this.mIsResetSigninRegistryForFreshVM = value;
			}
		}

		// Token: 0x170001EC RID: 492
		// (get) Token: 0x060006D2 RID: 1746 RVA: 0x00006C81 File Offset: 0x00004E81
		public bool CreateUninstallEntry
		{
			get
			{
				return this.mCreateUninstallEntry;
			}
		}

		// Token: 0x170001ED RID: 493
		// (get) Token: 0x060006D3 RID: 1747 RVA: 0x00006C89 File Offset: 0x00004E89
		public bool CheckForAGAInInstaller
		{
			get
			{
				return this.mCheckForAGAInInstaller;
			}
		}

		// Token: 0x170001EE RID: 494
		// (get) Token: 0x060006D4 RID: 1748 RVA: 0x00006C91 File Offset: 0x00004E91
		// (set) Token: 0x060006D5 RID: 1749 RVA: 0x00006C99 File Offset: 0x00004E99
		public string OEM
		{
			get
			{
				return this.mOem;
			}
			set
			{
				this.mOem = value;
			}
		}

		// Token: 0x170001EF RID: 495
		// (get) Token: 0x060006D6 RID: 1750 RVA: 0x00006CA2 File Offset: 0x00004EA2
		// (set) Token: 0x060006D7 RID: 1751 RVA: 0x00006CAA File Offset: 0x00004EAA
		public string DNSValue
		{
			get
			{
				return this.mDnsValue;
			}
			set
			{
				this.mDnsValue = value;
			}
		}

		// Token: 0x170001F0 RID: 496
		// (get) Token: 0x060006D8 RID: 1752 RVA: 0x00006CB3 File Offset: 0x00004EB3
		// (set) Token: 0x060006D9 RID: 1753 RVA: 0x00006CEB File Offset: 0x00004EEB
		public string DefaultTitle
		{
			get
			{
				if (string.IsNullOrEmpty(this.mDefaultTitle) || this.mDefaultTitle.Equals("DefaultTitle"))
				{
					this.mDefaultTitle = LocaleStrings.GetLocalizedString("DefaultTitle", false);
				}
				return this.mDefaultTitle;
			}
			set
			{
				this.mDefaultTitle = value;
			}
		}

		// Token: 0x170001F1 RID: 497
		// (get) Token: 0x060006DA RID: 1754 RVA: 0x00006CF4 File Offset: 0x00004EF4
		// (set) Token: 0x060006DB RID: 1755 RVA: 0x00006CFC File Offset: 0x00004EFC
		public string DesktopShortcutFileName
		{
			get
			{
				return this.mDesktopShortcutFileName;
			}
			set
			{
				this.mDesktopShortcutFileName = value;
			}
		}

		// Token: 0x170001F2 RID: 498
		// (get) Token: 0x060006DC RID: 1756 RVA: 0x00006D05 File Offset: 0x00004F05
		// (set) Token: 0x060006DD RID: 1757 RVA: 0x00006D3D File Offset: 0x00004F3D
		public string BlueStacksApkHandlerTitle
		{
			get
			{
				if (string.IsNullOrEmpty(this.mBlueStacksApkHandlerTitle) || this.mBlueStacksApkHandlerTitle.Equals("BlueStacksApkHandlerTitle"))
				{
					this.mBlueStacksApkHandlerTitle = LocaleStrings.GetLocalizedString("STRING_BLUESTACKS_APK_HANDLER_TITLE", false);
				}
				return this.mBlueStacksApkHandlerTitle;
			}
			set
			{
				this.mBlueStacksApkHandlerTitle = value;
			}
		}

		// Token: 0x170001F3 RID: 499
		// (get) Token: 0x060006DE RID: 1758 RVA: 0x00006D46 File Offset: 0x00004F46
		// (set) Token: 0x060006DF RID: 1759 RVA: 0x00006D4E File Offset: 0x00004F4E
		public string CommonAppTitleText
		{
			get
			{
				return this.mCommonAppTitleText;
			}
			set
			{
				this.mCommonAppTitleText = value;
			}
		}

		// Token: 0x170001F4 RID: 500
		// (get) Token: 0x060006E0 RID: 1760 RVA: 0x00006D57 File Offset: 0x00004F57
		// (set) Token: 0x060006E1 RID: 1761 RVA: 0x00006D8F File Offset: 0x00004F8F
		public string SnapShotShareString
		{
			get
			{
				if (string.IsNullOrEmpty(this.mSnapShotShareString) || this.mSnapShotShareString.Equals("SnapShotShareString"))
				{
					this.mSnapShotShareString = LocaleStrings.GetLocalizedString("STRING_SNAPSHOT_SHARE_STRING", false);
				}
				return this.mSnapShotShareString;
			}
			set
			{
				this.mSnapShotShareString = value;
			}
		}

		// Token: 0x170001F5 RID: 501
		// (get) Token: 0x060006E2 RID: 1762 RVA: 0x00006D98 File Offset: 0x00004F98
		// (set) Token: 0x060006E3 RID: 1763 RVA: 0x00006DA0 File Offset: 0x00004FA0
		public string DMMApiPrefix
		{
			get
			{
				return this.mDmmApiPrefix;
			}
			set
			{
				this.mDmmApiPrefix = value;
			}
		}

		// Token: 0x170001F6 RID: 502
		// (get) Token: 0x060006E4 RID: 1764 RVA: 0x00006DA9 File Offset: 0x00004FA9
		// (set) Token: 0x060006E5 RID: 1765 RVA: 0x00006DB1 File Offset: 0x00004FB1
		public string ControlPanelDisplayName
		{
			get
			{
				return this.mControlPanelDisplayName;
			}
			set
			{
				this.mControlPanelDisplayName = value;
			}
		}

		// Token: 0x170001F7 RID: 503
		// (get) Token: 0x060006E6 RID: 1766 RVA: 0x00006DBA File Offset: 0x00004FBA
		// (set) Token: 0x060006E7 RID: 1767 RVA: 0x00006DC2 File Offset: 0x00004FC2
		public string StartMenuShortcutName
		{
			get
			{
				return this.mStartMenuShortcutName;
			}
			set
			{
				this.mStartMenuShortcutName = value;
			}
		}

		// Token: 0x170001F8 RID: 504
		// (get) Token: 0x060006E8 RID: 1768 RVA: 0x00006DCB File Offset: 0x00004FCB
		// (set) Token: 0x060006E9 RID: 1769 RVA: 0x00006DD3 File Offset: 0x00004FD3
		public bool CreateDesktopIcons
		{
			get
			{
				return this.mCreateDesktopIcons;
			}
			set
			{
				this.mCreateDesktopIcons = value;
			}
		}

		// Token: 0x170001F9 RID: 505
		// (get) Token: 0x060006EA RID: 1770 RVA: 0x00006DDC File Offset: 0x00004FDC
		// (set) Token: 0x060006EB RID: 1771 RVA: 0x00006DE4 File Offset: 0x00004FE4
		public bool CreateMultiInstanceManagerIcon
		{
			get
			{
				return this.mCreateMultiInstanceManagerIcon;
			}
			set
			{
				this.mCreateMultiInstanceManagerIcon = value;
			}
		}

		// Token: 0x170001FA RID: 506
		// (get) Token: 0x060006EC RID: 1772 RVA: 0x00006DED File Offset: 0x00004FED
		// (set) Token: 0x060006ED RID: 1773 RVA: 0x00006DF5 File Offset: 0x00004FF5
		public bool IsSwitchToAndroidHome
		{
			get
			{
				return this.mIsSwitchToAndroidHome;
			}
			set
			{
				this.mIsSwitchToAndroidHome = value;
			}
		}

		// Token: 0x04000591 RID: 1425
		private static volatile Oem sInstance;

		// Token: 0x04000592 RID: 1426
		private static object syncRoot = new object();

		// Token: 0x04000593 RID: 1427
		private static string sFileName = "Oem.cfg";

		// Token: 0x04000594 RID: 1428
		private static string sCurrentFilePath = Path.Combine(RegistryStrings.DataDir, Oem.sFileName);

		// Token: 0x04000595 RID: 1429
		private Dictionary<string, string> mPropertiesDictionary = new Dictionary<string, string>();

		// Token: 0x04000596 RID: 1430
		private ulong mWindowsOEMFeatures;

		// Token: 0x04000597 RID: 1431
		private ulong mAppsOEMFeaturesBits;

		// Token: 0x04000598 RID: 1432
		private string mMsgWindowClassName;

		// Token: 0x04000599 RID: 1433
		private string mMsgWindowTitle;

		// Token: 0x0400059A RID: 1434
		private uint mAndroidFeatureBits;

		// Token: 0x0400059B RID: 1435
		private bool mSendAppClickStatsFromClient;

		// Token: 0x0400059C RID: 1436
		private bool mIsPixelParityToBeIgnored;

		// Token: 0x0400059D RID: 1437
		private bool mIsShowVersionOnSysTrayToolTip = true;

		// Token: 0x0400059E RID: 1438
		private bool mIsVTPopupEnabled;

		// Token: 0x0400059F RID: 1439
		private bool mIsUseFrontendBanner;

		// Token: 0x040005A0 RID: 1440
		private bool mIsFrontendFormLocation6;

		// Token: 0x040005A1 RID: 1441
		private bool mIsMessageBoxToBeDisplayed = true;

		// Token: 0x040005A2 RID: 1442
		private int mPartnerControlBarHeight;

		// Token: 0x040005A3 RID: 1443
		private bool mIsResizeFrontendWindow = true;

		// Token: 0x040005A4 RID: 1444
		private bool mIsFrontendBorderHidden;

		// Token: 0x040005A5 RID: 1445
		private bool mIsOnlyStopButtonToBeAddedInContextMenuOFSysTray;

		// Token: 0x040005A6 RID: 1446
		private bool mIsCountryChina;

		// Token: 0x040005A7 RID: 1447
		private bool mIsLoadCACodeFromCloud = true;

		// Token: 0x040005A8 RID: 1448
		private bool mIsSendGameManagerRequest;

		// Token: 0x040005A9 RID: 1449
		private bool mIsHideMessageBoxIconInTaskBar;

		// Token: 0x040005AA RID: 1450
		private bool mIsLefClickOnTrayIconLaunchPartner;

		// Token: 0x040005AB RID: 1451
		private bool mIsGameManagerToBeStartedOnRunApp;

		// Token: 0x040005AC RID: 1452
		private bool mIsCreateDesktopIconForApp;

		// Token: 0x040005AD RID: 1453
		private bool mIsDownloadIconFromWeb;

		// Token: 0x040005AE RID: 1454
		private bool mIsSysTrayIconTextToBeBlueStacks3;

		// Token: 0x040005AF RID: 1455
		private bool mIsOEMWithBGPClient;

		// Token: 0x040005B0 RID: 1456
		private bool mIsLaunchUIOnRunApp;

		// Token: 0x040005B1 RID: 1457
		private bool mIsRemoveAccountOnExit;

		// Token: 0x040005B2 RID: 1458
		private bool mIsFormBorderStyleFixedSingle;

		// Token: 0x040005B3 RID: 1459
		private bool mIsBackupWarningVisible = true;

		// Token: 0x040005B4 RID: 1460
		private bool mIsWriteRegistryInfoInFile;

		// Token: 0x040005B5 RID: 1461
		private bool mIsCreateInstallApkRegistry = true;

		// Token: 0x040005B6 RID: 1462
		private bool mIsCreateDesktopAndStartMenuShortcut = true;

		// Token: 0x040005B7 RID: 1463
		private bool mIsDragDropEnabled = true;

		// Token: 0x040005B8 RID: 1464
		private bool mIsProductBeta;

		// Token: 0x040005B9 RID: 1465
		private bool mIsResetSigninRegistryForFreshVM = true;

		// Token: 0x040005BA RID: 1466
		private bool mCreateUninstallEntry = true;

		// Token: 0x040005BB RID: 1467
		private bool mCheckForAGAInInstaller;

		// Token: 0x040005BC RID: 1468
		private string mOem = "gamemanager";

		// Token: 0x040005BD RID: 1469
		private string mDnsValue = "8.8.8.8";

		// Token: 0x040005BE RID: 1470
		private string mDefaultTitle = "DefaultTitle";

		// Token: 0x040005BF RID: 1471
		private string mDesktopShortcutFileName = "";

		// Token: 0x040005C0 RID: 1472
		private string mBlueStacksApkHandlerTitle = "BlueStacksApkHandlerTitle";

		// Token: 0x040005C1 RID: 1473
		private string mCommonAppTitleText = "BlueStacks Android Plugin";

		// Token: 0x040005C2 RID: 1474
		private string mSnapShotShareString = "SnapShotShareString";

		// Token: 0x040005C3 RID: 1475
		private string mDmmApiPrefix = string.Empty;

		// Token: 0x040005C4 RID: 1476
		private string mControlPanelDisplayName = "BlueStacks App Player";

		// Token: 0x040005C5 RID: 1477
		private string mStartMenuShortcutName = "";

		// Token: 0x040005C6 RID: 1478
		private bool mCreateDesktopIcons = true;

		// Token: 0x040005C7 RID: 1479
		private bool mCreateMultiInstanceManagerIcon;

		// Token: 0x040005C8 RID: 1480
		private bool mIsSwitchToAndroidHome;
	}
}
