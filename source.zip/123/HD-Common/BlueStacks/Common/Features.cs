﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000B6 RID: 182
	public class Features
	{
		// Token: 0x06000504 RID: 1284 RVA: 0x0001B8F8 File Offset: 0x00019AF8
		public static ulong GetEnabledFeatures()
		{
			ulong num = (ulong)Convert.ToUInt32(RegistryManager.Instance.Features);
			return (ulong)Convert.ToUInt32(RegistryManager.Instance.FeaturesHigh) << 32 | num;
		}

		// Token: 0x06000505 RID: 1285 RVA: 0x0001B92C File Offset: 0x00019B2C
		public static void SetEnabledFeatures(ulong feature)
		{
			uint featuresHigh;
			uint features;
			Features.GetHighLowFeatures(feature, out featuresHigh, out features);
			RegistryManager.Instance.Features = (int)features;
			RegistryManager.Instance.FeaturesHigh = (int)featuresHigh;
		}

		// Token: 0x06000506 RID: 1286 RVA: 0x00004DC8 File Offset: 0x00002FC8
		public static void GetHighLowFeatures(ulong features, out uint featuresHigh, out uint featuresLow)
		{
			featuresLow = (uint)(features & (ulong)-1);
			featuresHigh = (uint)(features >> 32);
		}

		// Token: 0x06000507 RID: 1287 RVA: 0x0001B95C File Offset: 0x00019B5C
		public static bool IsFeatureEnabled(ulong featureMask)
		{
			ulong num = Features.GetEnabledFeatures();
			if (num == 0UL)
			{
				num = Oem.Instance.WindowsOEMFeatures;
			}
			return Features.IsFeatureEnabled(featureMask, num);
		}

		// Token: 0x06000508 RID: 1288 RVA: 0x00004DD8 File Offset: 0x00002FD8
		public static bool IsFeatureEnabled(ulong featureMask, ulong features)
		{
			return (features & featureMask) != 0UL;
		}

		// Token: 0x06000509 RID: 1289 RVA: 0x0001B984 File Offset: 0x00019B84
		public static void DisableFeature(ulong featureMask)
		{
			ulong enabledFeatures = Features.GetEnabledFeatures();
			if ((enabledFeatures & featureMask) == 0UL)
			{
				return;
			}
			Features.SetEnabledFeatures(enabledFeatures & ~featureMask);
		}

		// Token: 0x0600050A RID: 1290 RVA: 0x0001B9A8 File Offset: 0x00019BA8
		public static void EnableFeature(ulong featureMask)
		{
			ulong enabledFeatures = Features.GetEnabledFeatures();
			if ((enabledFeatures & featureMask) != 0UL)
			{
				return;
			}
			Features.SetEnabledFeatures(enabledFeatures | featureMask);
		}

		// Token: 0x0600050B RID: 1291 RVA: 0x00004DE2 File Offset: 0x00002FE2
		public static void EnableAllFeatures()
		{
			Features.SetEnabledFeatures(9223372034707292159UL);
		}

		// Token: 0x0600050C RID: 1292 RVA: 0x00004DF2 File Offset: 0x00002FF2
		public static void EnableFeaturesOfOem()
		{
			Features.SetEnabledFeatures(Oem.Instance.WindowsOEMFeatures);
		}

		// Token: 0x0600050D RID: 1293 RVA: 0x00004E03 File Offset: 0x00003003
		public static bool IsFullScreenToggleEnabled()
		{
			return Features.IsFeatureEnabled(2097152UL);
		}

		// Token: 0x0600050E RID: 1294 RVA: 0x00004E10 File Offset: 0x00003010
		public static bool IsHomeButtonEnabled()
		{
			return Features.IsFeatureEnabled(32768UL);
		}

		// Token: 0x0600050F RID: 1295 RVA: 0x00004E1D File Offset: 0x0000301D
		public static bool IsShareButtonEnabled()
		{
			return false;
		}

		// Token: 0x06000510 RID: 1296 RVA: 0x00004E20 File Offset: 0x00003020
		public static bool IsGraphicsDriverReminderEnabled()
		{
			return Features.IsFeatureEnabled(65536UL);
		}

		// Token: 0x06000511 RID: 1297 RVA: 0x00004E1D File Offset: 0x0000301D
		public static bool IsSettingsButtonEnabled()
		{
			return false;
		}

		// Token: 0x06000512 RID: 1298 RVA: 0x00004E1D File Offset: 0x0000301D
		public static bool IsBackButtonEnabled()
		{
			return false;
		}

		// Token: 0x06000513 RID: 1299 RVA: 0x00004E1D File Offset: 0x0000301D
		public static bool IsMenuButtonEnabled()
		{
			return false;
		}

		// Token: 0x06000514 RID: 1300 RVA: 0x00004E2D File Offset: 0x0000302D
		public static bool ExitOnHome()
		{
			return Features.IsFeatureEnabled(131072UL);
		}

		// Token: 0x06000515 RID: 1301 RVA: 0x00004E3A File Offset: 0x0000303A
		public static bool UpdateFrontendAppTitle()
		{
			return Features.IsFeatureEnabled(524288UL);
		}

		// Token: 0x06000516 RID: 1302 RVA: 0x00004E47 File Offset: 0x00003047
		public static bool UseDefaultNetworkText()
		{
			return Features.IsFeatureEnabled(1048576UL);
		}

		// Token: 0x04000441 RID: 1089
		public const ulong BROADCAST_MESSAGES = 1UL;

		// Token: 0x04000442 RID: 1090
		public const ulong INSTALL_NOTIFICATIONS = 2UL;

		// Token: 0x04000443 RID: 1091
		public const ulong UNINSTALL_NOTIFICATIONS = 4UL;

		// Token: 0x04000444 RID: 1092
		public const ulong CREATE_APP_SHORTCUTS = 8UL;

		// Token: 0x04000445 RID: 1093
		public const ulong LAUNCH_SETUP_APP = 16UL;

		// Token: 0x04000446 RID: 1094
		public const ulong SHOW_USAGE_STATS = 32UL;

		// Token: 0x04000447 RID: 1095
		public const ulong SYS_TRAY_SUPPORT = 64UL;

		// Token: 0x04000448 RID: 1096
		public const ulong SUGGESTED_APPS_SUPPORT = 128UL;

		// Token: 0x04000449 RID: 1097
		public const ulong OTA_SUPPORT = 256UL;

		// Token: 0x0400044A RID: 1098
		public const ulong SHOW_RESTART = 512UL;

		// Token: 0x0400044B RID: 1099
		public const ulong ANDROID_NOTIFICATIONS = 1024UL;

		// Token: 0x0400044C RID: 1100
		public const ulong RIGHT_ALIGN_PORTRAIT_MODE = 2048UL;

		// Token: 0x0400044D RID: 1101
		public const ulong LAUNCH_FRONTEND_AFTER_INSTALLTION = 4096UL;

		// Token: 0x0400044E RID: 1102
		public const ulong CREATE_LIBRARY = 8192UL;

		// Token: 0x0400044F RID: 1103
		public const ulong SHOW_AGENT_ICON_IN_SYSTRAY = 16384UL;

		// Token: 0x04000450 RID: 1104
		public const ulong IS_HOME_BUTTON_ENABLED = 32768UL;

		// Token: 0x04000451 RID: 1105
		public const ulong IS_GRAPHICS_DRIVER_REMINDER_ENABLED = 65536UL;

		// Token: 0x04000452 RID: 1106
		public const ulong EXIT_ON_HOME = 131072UL;

		// Token: 0x04000453 RID: 1107
		public const ulong MULTI_INSTANCE_SUPPORT = 262144UL;

		// Token: 0x04000454 RID: 1108
		public const ulong UPDATE_FRONTEND_APP_TITLE = 524288UL;

		// Token: 0x04000455 RID: 1109
		public const ulong USE_DEFAULT_NETWORK_TEXT = 1048576UL;

		// Token: 0x04000456 RID: 1110
		public const ulong IS_FULL_SCREEN_TOGGLE_ENABLED = 2097152UL;

		// Token: 0x04000457 RID: 1111
		public const ulong SET_CHINA_LOCALE_AND_TIMEZONE = 4194304UL;

		// Token: 0x04000458 RID: 1112
		public const ulong SHOW_TOGGLE_BUTTON_IN_LOADING_SCREEN = 8388608UL;

		// Token: 0x04000459 RID: 1113
		public const ulong ENABLE_ALT_CTRL_I_SHORTCUTS = 16777216UL;

		// Token: 0x0400045A RID: 1114
		public const ulong CREATE_LIBRARY_SHORTCUT_AT_DESKTOP = 33554432UL;

		// Token: 0x0400045B RID: 1115
		public const ulong CREATE_START_LAUNCHER_SHORTCUT = 67108864UL;

		// Token: 0x0400045C RID: 1116
		public const ulong WRITE_APP_CRASH_LOGS = 268435456UL;

		// Token: 0x0400045D RID: 1117
		public const ulong CHINA_CLOUD = 536870912UL;

		// Token: 0x0400045E RID: 1118
		public const ulong FORCE_DESKTOP_MODE = 1073741824UL;

		// Token: 0x0400045F RID: 1119
		public const ulong NOT_TO_BE_USED = 2147483648UL;

		// Token: 0x04000460 RID: 1120
		public const ulong ENABLE_ALT_CTRL_M_SHORTCUTS = 4294967296UL;

		// Token: 0x04000461 RID: 1121
		public const ulong COLLECT_APK_HANDLER_LOGS = 8589934592UL;

		// Token: 0x04000462 RID: 1122
		public const ulong SHOW_FRONTEND_FULL_SCREEN_TOAST = 17179869184UL;

		// Token: 0x04000463 RID: 1123
		public const ulong IS_CHINA_UI = 34359738368UL;

		// Token: 0x04000464 RID: 1124
		public const ulong NOT_TO_BE_USED_2 = 9223372036854775808UL;

		// Token: 0x04000465 RID: 1125
		public const ulong ALL_FEATURES = 9223372034707292159UL;

		// Token: 0x04000466 RID: 1126
		public const uint BST_HIDE_NAVIGATIONBAR = 1U;

		// Token: 0x04000467 RID: 1127
		public const uint BST_HIDE_STATUSBAR = 2U;

		// Token: 0x04000468 RID: 1128
		public const uint BST_HIDE_BACKBUTTON = 4U;

		// Token: 0x04000469 RID: 1129
		public const uint BST_HIDE_HOMEBUTTON = 8U;

		// Token: 0x0400046A RID: 1130
		public const uint BST_HIDE_RECENTSBUTTON = 16U;

		// Token: 0x0400046B RID: 1131
		public const uint BST_HIDE_SCREENSHOTBUTTON = 32U;

		// Token: 0x0400046C RID: 1132
		public const uint BST_HIDE_TOGGLEBUTTON = 64U;

		// Token: 0x0400046D RID: 1133
		public const uint BST_HIDE_CLOSEBUTTON = 128U;

		// Token: 0x0400046E RID: 1134
		public const uint BST_HIDE_GPS = 512U;

		// Token: 0x0400046F RID: 1135
		public const uint BST_SHOW_APKINSTALLBUTTON = 2048U;

		// Token: 0x04000470 RID: 1136
		public const uint BST_HIDE_HOMEAPPNEWLOADER = 65536U;

		// Token: 0x04000471 RID: 1137
		public const uint BST_SENDLETSGOS2PCLICKREPORT = 131072U;

		// Token: 0x04000472 RID: 1138
		public const uint BST_DISABLE_P2DM = 262144U;

		// Token: 0x04000473 RID: 1139
		public const uint BST_DISABLE_ARMTIPS = 524288U;

		// Token: 0x04000474 RID: 1140
		public const uint BST_DISABLE_S2P = 1048576U;

		// Token: 0x04000475 RID: 1141
		public const uint BST_SOGOUIME = 268435456U;

		// Token: 0x04000476 RID: 1142
		public const uint BST_BAIDUIME = 1073741824U;

		// Token: 0x04000477 RID: 1143
		public const uint BST_QQIME = 2147483648U;

		// Token: 0x04000478 RID: 1144
		public const uint BST_QEMU_3BT_COEXISTENCE_BIT = 536870912U;

		// Token: 0x04000479 RID: 1145
		public const uint BST_HIDE_S2P_SEARCH_BAIDU_IN_HOMEAPPNEW = 4194304U;

		// Token: 0x0400047A RID: 1146
		public const uint BST_NEW_TASK_ON_HOME = 2097152U;

		// Token: 0x0400047B RID: 1147
		public const uint BST_NO_REINSTALL = 67108864U;

		// Token: 0x0400047C RID: 1148
		public const int BST_HIDE_GUIDANCESCREEN = 1024;

		// Token: 0x0400047D RID: 1149
		public const int BST_USE_CHINESE_CDN = 4096;

		// Token: 0x0400047E RID: 1150
		public const int BST_ENALBE_ABOUT_PHONE_OPTION = 16777216;

		// Token: 0x0400047F RID: 1151
		public const int BST_ENABLE_SECURITY_OPTION = 33554432;

		// Token: 0x04000480 RID: 1152
		public const uint BST_SKIP_S2P_WHILE_LAUNCHING_APP = 2048U;

		// Token: 0x04000481 RID: 1153
		internal static string ConfigFeature = "net.";
	}
}
