﻿using System;
using Microsoft.Win32;

namespace BlueStacks.Common
{
	// Token: 0x020000B7 RID: 183
	public class InstanceRegistry
	{
		// Token: 0x06000519 RID: 1305 RVA: 0x0001B9CC File Offset: 0x00019BCC
		public InstanceRegistry(string vmId)
		{
			this.mVmId = vmId;
			this.Init();
		}

		// Token: 0x0600051A RID: 1306 RVA: 0x0001BAD4 File Offset: 0x00019CD4
		private void Init()
		{
			this.mBaseKeyPath = RegistryStrings.RegistryBaseKeyPath + RegistryManager.UPGRADE_TAG;
			this.mAndroidKeyPath = this.mBaseKeyPath + "\\Guests\\" + this.mVmId;
			this.mBlockDeviceKeyPath = this.mAndroidKeyPath + "\\BlockDevice";
			this.mBlockDevice0KeyPath = this.mAndroidKeyPath + "\\BlockDevice\\0";
			this.mBlockDevice1KeyPath = this.mAndroidKeyPath + "\\BlockDevice\\1";
			this.mBlockDevice2KeyPath = this.mAndroidKeyPath + "\\BlockDevice\\2";
			this.mBlockDevice3KeyPath = this.mAndroidKeyPath + "\\BlockDevice\\3";
			this.mBlockDevice4KeyPath = this.mAndroidKeyPath + "\\BlockDevice\\4";
			this.mVmConfigKeyPath = this.mAndroidKeyPath + "\\Config";
			this.mFrameBufferKeyPath = this.mAndroidKeyPath + "\\FrameBuffer";
			this.mFrameBuffer0KeyPath = this.mAndroidKeyPath + "\\FrameBuffer\\0";
			this.mNetworkKeyPath = this.mAndroidKeyPath + "\\Network";
			this.mNetwork0KeyPath = this.mAndroidKeyPath + "\\Network\\0";
			this.mNetworkRedirectKeyPath = this.mAndroidKeyPath + "\\Network\\Redirect";
			this.mSharedFolderKeyPath = this.mAndroidKeyPath + "\\SharedFolder";
			this.mSharedFolder0KeyPath = this.mAndroidKeyPath + "\\SharedFolder\\0";
			this.mSharedFolder1KeyPath = this.mAndroidKeyPath + "\\SharedFolder\\1";
			this.mSharedFolder2KeyPath = this.mAndroidKeyPath + "\\SharedFolder\\2";
			this.mSharedFolder3KeyPath = this.mAndroidKeyPath + "\\SharedFolder\\3";
			this.mSharedFolder4KeyPath = this.mAndroidKeyPath + "\\SharedFolder\\4";
			this.mSharedFolder5KeyPath = this.mAndroidKeyPath + "\\SharedFolder\\5";
			RegistryUtils.InitKey(this.mBlockDevice0KeyPath);
			RegistryUtils.InitKey(this.mBlockDevice1KeyPath);
			RegistryUtils.InitKey(this.mBlockDevice2KeyPath);
			RegistryUtils.InitKey(this.mBlockDevice3KeyPath);
			RegistryUtils.InitKey(this.mBlockDevice4KeyPath);
			RegistryUtils.InitKey(this.mVmConfigKeyPath);
			RegistryUtils.InitKey(this.mFrameBuffer0KeyPath);
			RegistryUtils.InitKey(this.mNetwork0KeyPath);
			RegistryUtils.InitKey(this.mNetworkRedirectKeyPath);
			RegistryUtils.InitKey(this.mSharedFolder0KeyPath);
			RegistryUtils.InitKey(this.mSharedFolder1KeyPath);
			RegistryUtils.InitKey(this.mSharedFolder2KeyPath);
			RegistryUtils.InitKey(this.mSharedFolder3KeyPath);
			RegistryUtils.InitKey(this.mSharedFolder4KeyPath);
			RegistryUtils.InitKey(this.mSharedFolder5KeyPath);
		}

		// Token: 0x1700014F RID: 335
		// (get) Token: 0x0600051B RID: 1307 RVA: 0x00004E60 File Offset: 0x00003060
		public string AndroidKeyPath
		{
			get
			{
				return this.mAndroidKeyPath;
			}
		}

		// Token: 0x17000150 RID: 336
		// (get) Token: 0x0600051C RID: 1308 RVA: 0x00004E68 File Offset: 0x00003068
		// (set) Token: 0x0600051D RID: 1309 RVA: 0x00004E86 File Offset: 0x00003086
		public int EmulatePortraitMode
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mFrameBuffer0KeyPath, "EmulatePortraitMode", -1, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mFrameBuffer0KeyPath, "EmulatePortraitMode", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000151 RID: 337
		// (get) Token: 0x0600051E RID: 1310 RVA: 0x00004EA1 File Offset: 0x000030A1
		// (set) Token: 0x0600051F RID: 1311 RVA: 0x00004EBF File Offset: 0x000030BF
		public int Depth
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mFrameBuffer0KeyPath, "Depth", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mFrameBuffer0KeyPath, "Depth", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000152 RID: 338
		// (get) Token: 0x06000520 RID: 1312 RVA: 0x00004EDA File Offset: 0x000030DA
		// (set) Token: 0x06000521 RID: 1313 RVA: 0x00004EF8 File Offset: 0x000030F8
		public int HideBootProgress
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mFrameBuffer0KeyPath, "HideBootProgress", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mFrameBuffer0KeyPath, "HideBootProgress", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000153 RID: 339
		// (get) Token: 0x06000522 RID: 1314 RVA: 0x00004F13 File Offset: 0x00003113
		// (set) Token: 0x06000523 RID: 1315 RVA: 0x00004F31 File Offset: 0x00003131
		public int WindowWidth
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mFrameBuffer0KeyPath, "WindowWidth", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mFrameBuffer0KeyPath, "WindowWidth", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000154 RID: 340
		// (get) Token: 0x06000524 RID: 1316 RVA: 0x00004F4C File Offset: 0x0000314C
		// (set) Token: 0x06000525 RID: 1317 RVA: 0x00004F6A File Offset: 0x0000316A
		public int WindowHeight
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mFrameBuffer0KeyPath, "WindowHeight", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mFrameBuffer0KeyPath, "WindowHeight", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000155 RID: 341
		// (get) Token: 0x06000526 RID: 1318 RVA: 0x00004F85 File Offset: 0x00003185
		// (set) Token: 0x06000527 RID: 1319 RVA: 0x00004FA3 File Offset: 0x000031A3
		public int GuestWidth
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mFrameBuffer0KeyPath, "GuestWidth", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mFrameBuffer0KeyPath, "GuestWidth", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000156 RID: 342
		// (get) Token: 0x06000528 RID: 1320 RVA: 0x00004FBE File Offset: 0x000031BE
		// (set) Token: 0x06000529 RID: 1321 RVA: 0x00004FDC File Offset: 0x000031DC
		public int GuestHeight
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mFrameBuffer0KeyPath, "GuestHeight", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mFrameBuffer0KeyPath, "GuestHeight", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000157 RID: 343
		// (get) Token: 0x0600052A RID: 1322 RVA: 0x00004FF7 File Offset: 0x000031F7
		// (set) Token: 0x0600052B RID: 1323 RVA: 0x00005015 File Offset: 0x00003215
		public int Memory
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mAndroidKeyPath, "Memory", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mAndroidKeyPath, "Memory", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000158 RID: 344
		// (get) Token: 0x0600052C RID: 1324 RVA: 0x00005030 File Offset: 0x00003230
		// (set) Token: 0x0600052D RID: 1325 RVA: 0x00005053 File Offset: 0x00003253
		public bool IsSidebarVisible
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mAndroidKeyPath, "IsSidebarVisible", 1, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mAndroidKeyPath, "IsSidebarVisible", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000159 RID: 345
		// (get) Token: 0x0600052E RID: 1326 RVA: 0x00005074 File Offset: 0x00003274
		// (set) Token: 0x0600052F RID: 1327 RVA: 0x00005097 File Offset: 0x00003297
		public bool IsSidebarInDefaultState
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mAndroidKeyPath, "IsSidebarInDefaultState", 1, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mAndroidKeyPath, "IsSidebarInDefaultState", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700015A RID: 346
		// (get) Token: 0x06000530 RID: 1328 RVA: 0x000050B8 File Offset: 0x000032B8
		// (set) Token: 0x06000531 RID: 1329 RVA: 0x000050D1 File Offset: 0x000032D1
		public string Kernel
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mAndroidKeyPath, "Kernel", null, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mAndroidKeyPath, "Kernel", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700015B RID: 347
		// (get) Token: 0x06000532 RID: 1330 RVA: 0x000050E7 File Offset: 0x000032E7
		// (set) Token: 0x06000533 RID: 1331 RVA: 0x00005100 File Offset: 0x00003300
		public string Initrd
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mAndroidKeyPath, "Initrd", null, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mAndroidKeyPath, "Initrd", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700015C RID: 348
		// (get) Token: 0x06000534 RID: 1332 RVA: 0x00005116 File Offset: 0x00003316
		// (set) Token: 0x06000535 RID: 1333 RVA: 0x00005134 File Offset: 0x00003334
		public int DisableRobustness
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mAndroidKeyPath, "DisableRobustness", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mAndroidKeyPath, "DisableRobustness", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700015D RID: 349
		// (get) Token: 0x06000536 RID: 1334 RVA: 0x0000514F File Offset: 0x0000334F
		// (set) Token: 0x06000537 RID: 1335 RVA: 0x0000516C File Offset: 0x0000336C
		public string VirtType
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mAndroidKeyPath, "VirtType", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mAndroidKeyPath, "VirtType", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700015E RID: 350
		// (get) Token: 0x06000538 RID: 1336 RVA: 0x00005182 File Offset: 0x00003382
		// (set) Token: 0x06000539 RID: 1337 RVA: 0x0000519F File Offset: 0x0000339F
		public string BootParameters
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mAndroidKeyPath, "BootParameters", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mAndroidKeyPath, "BootParameters", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700015F RID: 351
		// (get) Token: 0x0600053A RID: 1338 RVA: 0x000051B5 File Offset: 0x000033B5
		// (set) Token: 0x0600053B RID: 1339 RVA: 0x000051D8 File Offset: 0x000033D8
		public bool ShowSidebarInFullScreen
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "ShowSidebarInFullScreen", 1, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "ShowSidebarInFullScreen", (!value) ? 0 : 1, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000160 RID: 352
		// (get) Token: 0x0600053C RID: 1340 RVA: 0x000051F9 File Offset: 0x000033F9
		// (set) Token: 0x0600053D RID: 1341 RVA: 0x00005216 File Offset: 0x00003416
		public string BlockDevice0Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice0KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice0KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000161 RID: 353
		// (get) Token: 0x0600053E RID: 1342 RVA: 0x0000522C File Offset: 0x0000342C
		// (set) Token: 0x0600053F RID: 1343 RVA: 0x00005249 File Offset: 0x00003449
		public string BlockDevice0Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice0KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice0KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000162 RID: 354
		// (get) Token: 0x06000540 RID: 1344 RVA: 0x0000525F File Offset: 0x0000345F
		// (set) Token: 0x06000541 RID: 1345 RVA: 0x0000527C File Offset: 0x0000347C
		public string BlockDevice1Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice1KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice1KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000163 RID: 355
		// (get) Token: 0x06000542 RID: 1346 RVA: 0x00005292 File Offset: 0x00003492
		// (set) Token: 0x06000543 RID: 1347 RVA: 0x000052AF File Offset: 0x000034AF
		public string BlockDevice1Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice1KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice1KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000164 RID: 356
		// (get) Token: 0x06000544 RID: 1348 RVA: 0x000052C5 File Offset: 0x000034C5
		// (set) Token: 0x06000545 RID: 1349 RVA: 0x000052E2 File Offset: 0x000034E2
		public string BlockDevice2Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice2KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice2KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000165 RID: 357
		// (get) Token: 0x06000546 RID: 1350 RVA: 0x000052F8 File Offset: 0x000034F8
		// (set) Token: 0x06000547 RID: 1351 RVA: 0x00005315 File Offset: 0x00003515
		public string BlockDevice2Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice2KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice2KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000166 RID: 358
		// (get) Token: 0x06000548 RID: 1352 RVA: 0x0000532B File Offset: 0x0000352B
		// (set) Token: 0x06000549 RID: 1353 RVA: 0x00005348 File Offset: 0x00003548
		public string BlockDevice3Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice3KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice3KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000167 RID: 359
		// (get) Token: 0x0600054A RID: 1354 RVA: 0x0000535E File Offset: 0x0000355E
		// (set) Token: 0x0600054B RID: 1355 RVA: 0x0000537B File Offset: 0x0000357B
		public string BlockDevice3Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice3KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice3KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000168 RID: 360
		// (get) Token: 0x0600054C RID: 1356 RVA: 0x00005391 File Offset: 0x00003591
		// (set) Token: 0x0600054D RID: 1357 RVA: 0x000053AE File Offset: 0x000035AE
		public string BlockDevice4Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice4KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice4KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000169 RID: 361
		// (get) Token: 0x0600054E RID: 1358 RVA: 0x000053C4 File Offset: 0x000035C4
		// (set) Token: 0x0600054F RID: 1359 RVA: 0x000053E1 File Offset: 0x000035E1
		public string BlockDevice4Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice4KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice4KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700016A RID: 362
		// (get) Token: 0x06000550 RID: 1360 RVA: 0x000053F7 File Offset: 0x000035F7
		// (set) Token: 0x06000551 RID: 1361 RVA: 0x00005414 File Offset: 0x00003614
		public string Locale
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "Locale", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "Locale", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700016B RID: 363
		// (get) Token: 0x06000552 RID: 1362 RVA: 0x0000542A File Offset: 0x0000362A
		// (set) Token: 0x06000553 RID: 1363 RVA: 0x00005462 File Offset: 0x00003662
		public int VCPUs
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "VCPUs", Utils.GetRecommendedVCPUCount(this.mVmId == "Android"), RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "VCPUs", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700016C RID: 364
		// (get) Token: 0x06000554 RID: 1364 RVA: 0x0000547D File Offset: 0x0000367D
		// (set) Token: 0x06000555 RID: 1365 RVA: 0x0000549A File Offset: 0x0000369A
		public string EnableConsoleAccess
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "EnableConsoleAccess", string.Empty, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "EnableConsoleAccess", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700016D RID: 365
		// (get) Token: 0x06000556 RID: 1366 RVA: 0x000054B0 File Offset: 0x000036B0
		// (set) Token: 0x06000557 RID: 1367 RVA: 0x000054CE File Offset: 0x000036CE
		public int GlRenderMode
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GlRenderMode", -1, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GlRenderMode", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700016E RID: 366
		// (get) Token: 0x06000558 RID: 1368 RVA: 0x000054E9 File Offset: 0x000036E9
		// (set) Token: 0x06000559 RID: 1369 RVA: 0x00005508 File Offset: 0x00003708
		public int FPS
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "FPS", 60, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "FPS", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700016F RID: 367
		// (get) Token: 0x0600055A RID: 1370 RVA: 0x00005523 File Offset: 0x00003723
		// (set) Token: 0x0600055B RID: 1371 RVA: 0x00005541 File Offset: 0x00003741
		public int ShowFPS
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "ShowFPS", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "ShowFPS", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000170 RID: 368
		// (get) Token: 0x0600055C RID: 1372 RVA: 0x0000555C File Offset: 0x0000375C
		// (set) Token: 0x0600055D RID: 1373 RVA: 0x0000557A File Offset: 0x0000377A
		public int EnableHighFPS
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "EnableHighFPS", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "EnableHighFPS", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000171 RID: 369
		// (get) Token: 0x0600055E RID: 1374 RVA: 0x00005595 File Offset: 0x00003795
		// (set) Token: 0x0600055F RID: 1375 RVA: 0x000055B3 File Offset: 0x000037B3
		public int GlMode
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GlMode", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GlMode", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000172 RID: 370
		// (get) Token: 0x06000560 RID: 1376 RVA: 0x000055CE File Offset: 0x000037CE
		// (set) Token: 0x06000561 RID: 1377 RVA: 0x000055EC File Offset: 0x000037EC
		public int Camera
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "Camera", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "Camera", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000173 RID: 371
		// (get) Token: 0x06000562 RID: 1378 RVA: 0x00005607 File Offset: 0x00003807
		// (set) Token: 0x06000563 RID: 1379 RVA: 0x00005625 File Offset: 0x00003825
		public int ConfigSynced
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "ConfigSynced", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "ConfigSynced", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000174 RID: 372
		// (get) Token: 0x06000564 RID: 1380 RVA: 0x00005640 File Offset: 0x00003840
		// (set) Token: 0x06000565 RID: 1381 RVA: 0x0000565E File Offset: 0x0000385E
		public int HScroll
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "HScroll", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "HScroll", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000175 RID: 373
		// (get) Token: 0x06000566 RID: 1382 RVA: 0x00005679 File Offset: 0x00003879
		// (set) Token: 0x06000567 RID: 1383 RVA: 0x00005697 File Offset: 0x00003897
		public int GpsMode
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GpsMode", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GpsMode", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000176 RID: 374
		// (get) Token: 0x06000568 RID: 1384 RVA: 0x000056B2 File Offset: 0x000038B2
		// (set) Token: 0x06000569 RID: 1385 RVA: 0x000056D0 File Offset: 0x000038D0
		public int FileSystem
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "FileSystem", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "FileSystem", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000177 RID: 375
		// (get) Token: 0x0600056A RID: 1386 RVA: 0x000056EB File Offset: 0x000038EB
		// (set) Token: 0x0600056B RID: 1387 RVA: 0x00005709 File Offset: 0x00003909
		public int StopZygoteOnClose
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "StopZygoteOnClose", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "StopZygoteOnClose", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000178 RID: 376
		// (get) Token: 0x0600056C RID: 1388 RVA: 0x00005724 File Offset: 0x00003924
		// (set) Token: 0x0600056D RID: 1389 RVA: 0x00005742 File Offset: 0x00003942
		public int FenceSyncType
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "FenceSyncType", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "FenceSyncType", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000179 RID: 377
		// (get) Token: 0x0600056E RID: 1390 RVA: 0x0000575D File Offset: 0x0000395D
		// (set) Token: 0x0600056F RID: 1391 RVA: 0x0000577B File Offset: 0x0000397B
		public int FrontendNoClose
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "FrontendNoClose", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "FrontendNoClose", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700017A RID: 378
		// (get) Token: 0x06000570 RID: 1392 RVA: 0x00005796 File Offset: 0x00003996
		// (set) Token: 0x06000571 RID: 1393 RVA: 0x000057B4 File Offset: 0x000039B4
		public int GpsSource
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GpsSource", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GpsSource", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700017B RID: 379
		// (get) Token: 0x06000572 RID: 1394 RVA: 0x000057CF File Offset: 0x000039CF
		// (set) Token: 0x06000573 RID: 1395 RVA: 0x000057EC File Offset: 0x000039EC
		public string GpsLatitude
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GpsLatitude", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GpsLatitude", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700017C RID: 380
		// (get) Token: 0x06000574 RID: 1396 RVA: 0x00005802 File Offset: 0x00003A02
		// (set) Token: 0x06000575 RID: 1397 RVA: 0x0000581F File Offset: 0x00003A1F
		public string GpsLongitude
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GpsLongitude", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GpsLongitude", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700017D RID: 381
		// (get) Token: 0x06000576 RID: 1398 RVA: 0x00005835 File Offset: 0x00003A35
		// (set) Token: 0x06000577 RID: 1399 RVA: 0x00005853 File Offset: 0x00003A53
		public int GlPort
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GlPort", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GlPort", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700017E RID: 382
		// (get) Token: 0x06000578 RID: 1400 RVA: 0x0000586E File Offset: 0x00003A6E
		// (set) Token: 0x06000579 RID: 1401 RVA: 0x0000588B File Offset: 0x00003A8B
		public string GamingResolutionPubg
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GamingResolutionPubg", "1", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GamingResolutionPubg", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700017F RID: 383
		// (get) Token: 0x0600057A RID: 1402 RVA: 0x000058A1 File Offset: 0x00003AA1
		// (set) Token: 0x0600057B RID: 1403 RVA: 0x000058BE File Offset: 0x00003ABE
		public string DisplayQualityPubg
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "DisplayQualityPubg", "-1", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "DisplayQualityPubg", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000180 RID: 384
		// (get) Token: 0x0600057C RID: 1404 RVA: 0x000058D4 File Offset: 0x00003AD4
		// (set) Token: 0x0600057D RID: 1405 RVA: 0x000058F1 File Offset: 0x00003AF1
		public string GamingResolutionCOD
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GamingResolutionCOD", "720", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GamingResolutionCOD", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000181 RID: 385
		// (get) Token: 0x0600057E RID: 1406 RVA: 0x00005907 File Offset: 0x00003B07
		// (set) Token: 0x0600057F RID: 1407 RVA: 0x00005924 File Offset: 0x00003B24
		public string DisplayQualityCOD
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "DisplayQualityCOD", "-1", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "DisplayQualityCOD", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000182 RID: 386
		// (get) Token: 0x06000580 RID: 1408 RVA: 0x0000593A File Offset: 0x00003B3A
		// (set) Token: 0x06000581 RID: 1409 RVA: 0x00005958 File Offset: 0x00003B58
		public int HostSensorPort
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "HostSensorPort", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "HostSensorPort", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000183 RID: 387
		// (get) Token: 0x06000582 RID: 1410 RVA: 0x00005973 File Offset: 0x00003B73
		// (set) Token: 0x06000583 RID: 1411 RVA: 0x00005991 File Offset: 0x00003B91
		public int SoftControlBarHeightLandscape
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "SoftControlBarHeightLandscape", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "SoftControlBarHeightLandscape", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000184 RID: 388
		// (get) Token: 0x06000584 RID: 1412 RVA: 0x000059AC File Offset: 0x00003BAC
		// (set) Token: 0x06000585 RID: 1413 RVA: 0x000059CA File Offset: 0x00003BCA
		public int SoftControlBarHeightPortrait
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "SoftControlBarHeightPortrait", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "SoftControlBarHeightPortrait", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000185 RID: 389
		// (get) Token: 0x06000586 RID: 1414 RVA: 0x000059E5 File Offset: 0x00003BE5
		// (set) Token: 0x06000587 RID: 1415 RVA: 0x00005A03 File Offset: 0x00003C03
		public int GrabKeyboard
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GrabKeyboard", 1, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GrabKeyboard", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000186 RID: 390
		// (get) Token: 0x06000588 RID: 1416 RVA: 0x00005A1E File Offset: 0x00003C1E
		// (set) Token: 0x06000589 RID: 1417 RVA: 0x00005A3C File Offset: 0x00003C3C
		public int DisableDWM
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "DisableDWM", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "DisableDWM", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000187 RID: 391
		// (get) Token: 0x0600058A RID: 1418 RVA: 0x00005A57 File Offset: 0x00003C57
		// (set) Token: 0x0600058B RID: 1419 RVA: 0x00005A75 File Offset: 0x00003C75
		public int DisablePcIme
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "DisablePcIme", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "DisablePcIme", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000188 RID: 392
		// (get) Token: 0x0600058C RID: 1420 RVA: 0x00005A90 File Offset: 0x00003C90
		// (set) Token: 0x0600058D RID: 1421 RVA: 0x00005AAE File Offset: 0x00003CAE
		public int EnableBSTVC
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "EnableBSTVC", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "EnableBSTVC", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000189 RID: 393
		// (get) Token: 0x0600058E RID: 1422 RVA: 0x00005AC9 File Offset: 0x00003CC9
		// (set) Token: 0x0600058F RID: 1423 RVA: 0x00005AE7 File Offset: 0x00003CE7
		public int ForceVMLegacyMode
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "ForceVMLegacyMode", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "ForceVMLegacyMode", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700018A RID: 394
		// (get) Token: 0x06000590 RID: 1424 RVA: 0x00005B02 File Offset: 0x00003D02
		// (set) Token: 0x06000591 RID: 1425 RVA: 0x00005B24 File Offset: 0x00003D24
		public int FrontendServerPort
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "FrontendServerPort", 2881, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "FrontendServerPort", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700018B RID: 395
		// (get) Token: 0x06000592 RID: 1426 RVA: 0x00005B3F File Offset: 0x00003D3F
		// (set) Token: 0x06000593 RID: 1427 RVA: 0x00005B61 File Offset: 0x00003D61
		public int BstAndroidPort
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "BstAndroidPort", 9999, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "BstAndroidPort", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700018C RID: 396
		// (get) Token: 0x06000594 RID: 1428 RVA: 0x00005B7C File Offset: 0x00003D7C
		// (set) Token: 0x06000595 RID: 1429 RVA: 0x00005B9E File Offset: 0x00003D9E
		public int BstAdbPort
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "BstAdbPort", 5555, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "BstAdbPort", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700018D RID: 397
		// (get) Token: 0x06000596 RID: 1430 RVA: 0x00005BB9 File Offset: 0x00003DB9
		// (set) Token: 0x06000597 RID: 1431 RVA: 0x00005BDB File Offset: 0x00003DDB
		public int TriggerMemoryTrimThreshold
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "TriggerMemoryTrimThreshold", 700, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "TriggerMemoryTrimThreshold", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700018E RID: 398
		// (get) Token: 0x06000598 RID: 1432 RVA: 0x00005BF6 File Offset: 0x00003DF6
		// (set) Token: 0x06000599 RID: 1433 RVA: 0x00005C18 File Offset: 0x00003E18
		public int TriggerMemoryTrimTimerInterval
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "TriggerMemoryTrimTimerInterval", 60000, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "TriggerMemoryTrimTimerInterval", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700018F RID: 399
		// (get) Token: 0x0600059A RID: 1434 RVA: 0x00005C33 File Offset: 0x00003E33
		// (set) Token: 0x0600059B RID: 1435 RVA: 0x00005C51 File Offset: 0x00003E51
		public int UpdatedVersion
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "UpdatedVersion", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "UpdatedVersion", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000190 RID: 400
		// (get) Token: 0x0600059C RID: 1436 RVA: 0x00005C6C File Offset: 0x00003E6C
		// (set) Token: 0x0600059D RID: 1437 RVA: 0x00005C8A File Offset: 0x00003E8A
		public int GPSAvailable
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GPSAvailable", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GPSAvailable", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000191 RID: 401
		// (get) Token: 0x0600059E RID: 1438 RVA: 0x00005CA5 File Offset: 0x00003EA5
		// (set) Token: 0x0600059F RID: 1439 RVA: 0x00005CC2 File Offset: 0x00003EC2
		public string OpenSensorDeviceId
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "OpenSensorDeviceId", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "OpenSensorDeviceId", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000192 RID: 402
		// (get) Token: 0x060005A0 RID: 1440 RVA: 0x00005CD8 File Offset: 0x00003ED8
		// (set) Token: 0x060005A1 RID: 1441 RVA: 0x00005CF6 File Offset: 0x00003EF6
		public int HostForwardSensorPort
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "HostForwardSensorPort", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "HostForwardSensorPort", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000193 RID: 403
		// (get) Token: 0x060005A2 RID: 1442 RVA: 0x00005D11 File Offset: 0x00003F11
		// (set) Token: 0x060005A3 RID: 1443 RVA: 0x00005D2E File Offset: 0x00003F2E
		public string ImeSelected
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "ImeSelected", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "ImeSelected", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000194 RID: 404
		// (get) Token: 0x060005A4 RID: 1444 RVA: 0x00005D44 File Offset: 0x00003F44
		// (set) Token: 0x060005A5 RID: 1445 RVA: 0x00005D62 File Offset: 0x00003F62
		public int RunAppProcessId
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "RunAppProcessId", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "RunAppProcessId", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000195 RID: 405
		// (get) Token: 0x060005A6 RID: 1446 RVA: 0x00005D7D File Offset: 0x00003F7D
		// (set) Token: 0x060005A7 RID: 1447 RVA: 0x00005D9A File Offset: 0x00003F9A
		public string DisplayName
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "DisplayName", string.Empty, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "DisplayName", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000196 RID: 406
		// (get) Token: 0x060005A8 RID: 1448 RVA: 0x0001BD68 File Offset: 0x00019F68
		// (set) Token: 0x060005A9 RID: 1449 RVA: 0x00005DB0 File Offset: 0x00003FB0
		public string LastBootDate
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "LastBootDate", DateTime.Now.Date.ToShortDateString(), RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "LastBootDate", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000197 RID: 407
		// (get) Token: 0x060005AA RID: 1450 RVA: 0x00005DC6 File Offset: 0x00003FC6
		// (set) Token: 0x060005AB RID: 1451 RVA: 0x00005DE9 File Offset: 0x00003FE9
		public bool IsOneTimeSetupDone
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "IsOneTimeSetupDone", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "IsOneTimeSetupDone", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000198 RID: 408
		// (get) Token: 0x060005AC RID: 1452 RVA: 0x00005E0A File Offset: 0x0000400A
		// (set) Token: 0x060005AD RID: 1453 RVA: 0x00005E2D File Offset: 0x0000402D
		public bool IsMuted
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "IsMuted", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "IsMuted", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000199 RID: 409
		// (get) Token: 0x060005AE RID: 1454 RVA: 0x00005E4E File Offset: 0x0000404E
		// (set) Token: 0x060005AF RID: 1455 RVA: 0x00005E6C File Offset: 0x0000406C
		public int Volume
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "Volume", 5, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "Volume", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700019A RID: 410
		// (get) Token: 0x060005B0 RID: 1456 RVA: 0x00005E87 File Offset: 0x00004087
		// (set) Token: 0x060005B1 RID: 1457 RVA: 0x00005EAA File Offset: 0x000040AA
		public bool FixVboxConfig
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "FixVboxConfig", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "FixVboxConfig", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700019B RID: 411
		// (get) Token: 0x060005B2 RID: 1458 RVA: 0x00005ECB File Offset: 0x000040CB
		// (set) Token: 0x060005B3 RID: 1459 RVA: 0x00005EE8 File Offset: 0x000040E8
		public string WindowPlacement
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "WindowPlacement", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "WindowPlacement", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700019C RID: 412
		// (get) Token: 0x060005B4 RID: 1460 RVA: 0x00005EFE File Offset: 0x000040FE
		// (set) Token: 0x060005B5 RID: 1461 RVA: 0x00005F21 File Offset: 0x00004121
		public bool IsGoogleSigninDone
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "IsGoogleSigninDone", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "IsGoogleSigninDone", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700019D RID: 413
		// (get) Token: 0x060005B6 RID: 1462 RVA: 0x00005F42 File Offset: 0x00004142
		// (set) Token: 0x060005B7 RID: 1463 RVA: 0x00005F65 File Offset: 0x00004165
		public bool IsGoogleSigninPopupShown
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "IsGoogleSigninPopupShown", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "IsGoogleSigninPopupShown", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700019E RID: 414
		// (get) Token: 0x060005B8 RID: 1464 RVA: 0x00005F86 File Offset: 0x00004186
		// (set) Token: 0x060005B9 RID: 1465 RVA: 0x00005FA4 File Offset: 0x000041A4
		public string[] GrmDonotShowRuleList
		{
			get
			{
				return (string[])RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GrmDonotShowRuleList", new string[0], RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GrmDonotShowRuleList", value, RegistryValueKind.MultiString, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700019F RID: 415
		// (get) Token: 0x060005BA RID: 1466 RVA: 0x00005FBA File Offset: 0x000041BA
		// (set) Token: 0x060005BB RID: 1467 RVA: 0x00005FD7 File Offset: 0x000041D7
		public string GoogleAId
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "BstVmAId", string.Empty, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "BstVmAId", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001A0 RID: 416
		// (get) Token: 0x060005BC RID: 1468 RVA: 0x00005FED File Offset: 0x000041ED
		// (set) Token: 0x060005BD RID: 1469 RVA: 0x0000600A File Offset: 0x0000420A
		public string AndroidId
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "BstVmId", string.Empty, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "BstVmId", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001A1 RID: 417
		// (get) Token: 0x060005BE RID: 1470 RVA: 0x00006020 File Offset: 0x00004220
		// (set) Token: 0x060005BF RID: 1471 RVA: 0x0000603E File Offset: 0x0000423E
		public int PUBGLaunchedCount
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "PUBGLaunchedCount", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "PUBGLaunchedCount", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001A2 RID: 418
		// (get) Token: 0x060005C0 RID: 1472 RVA: 0x00006059 File Offset: 0x00004259
		// (set) Token: 0x060005C1 RID: 1473 RVA: 0x00006077 File Offset: 0x00004277
		public string[] SmartControlsEnabledApps
		{
			get
			{
				return (string[])RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "SmartControlsEnabledApps", new string[0], RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "SmartControlsEnabledApps", value, RegistryValueKind.MultiString, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001A3 RID: 419
		// (get) Token: 0x060005C2 RID: 1474 RVA: 0x0000608D File Offset: 0x0000428D
		// (set) Token: 0x060005C3 RID: 1475 RVA: 0x000060B0 File Offset: 0x000042B0
		public bool ShowMacroDeletePopup
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "ShowMacroDeletePopup", 1, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "ShowMacroDeletePopup", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001A4 RID: 420
		// (get) Token: 0x060005C4 RID: 1476 RVA: 0x000060D1 File Offset: 0x000042D1
		// (set) Token: 0x060005C5 RID: 1477 RVA: 0x000060F4 File Offset: 0x000042F4
		public bool ShowSchemeDeletePopup
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "ShowSchemeDeletePopup", 1, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "ShowSchemeDeletePopup", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001A5 RID: 421
		// (get) Token: 0x060005C6 RID: 1478 RVA: 0x00006115 File Offset: 0x00004315
		// (set) Token: 0x060005C7 RID: 1479 RVA: 0x00006138 File Offset: 0x00004338
		public bool IsFreeFireInGameSettingsCustomized
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "IsFreeFireInGameSettingsCustomized", 1, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "IsFreeFireInGameSettingsCustomized", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001A6 RID: 422
		// (get) Token: 0x060005C8 RID: 1480 RVA: 0x00006159 File Offset: 0x00004359
		// (set) Token: 0x060005C9 RID: 1481 RVA: 0x0000617C File Offset: 0x0000437C
		public bool IsClientOnTop
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "IsClientOnTop", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "IsClientOnTop", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001A7 RID: 423
		// (get) Token: 0x060005CA RID: 1482 RVA: 0x0000619D File Offset: 0x0000439D
		// (set) Token: 0x060005CB RID: 1483 RVA: 0x000061B6 File Offset: 0x000043B6
		public string[] NetworkInboundRules
		{
			get
			{
				return (string[])RegistryUtils.GetRegistryValue(this.mNetwork0KeyPath, "InboundRules", null, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mNetwork0KeyPath, "InboundRules", value, RegistryValueKind.MultiString, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001A8 RID: 424
		// (get) Token: 0x060005CC RID: 1484 RVA: 0x000061CC File Offset: 0x000043CC
		// (set) Token: 0x060005CD RID: 1485 RVA: 0x000061E5 File Offset: 0x000043E5
		public string AllowRemoteAccess
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mNetwork0KeyPath, "AllowRemoteAccess", null, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mNetwork0KeyPath, "AllowRemoteAccess", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001A9 RID: 425
		// (get) Token: 0x060005CE RID: 1486 RVA: 0x000061FB File Offset: 0x000043FB
		// (set) Token: 0x060005CF RID: 1487 RVA: 0x0000621D File Offset: 0x0000441D
		public int NetworkRedirectTcp5555
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mNetworkRedirectKeyPath, "tcp/5555", 5555, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mNetworkRedirectKeyPath, "tcp/5555", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001AA RID: 426
		// (get) Token: 0x060005D0 RID: 1488 RVA: 0x00006238 File Offset: 0x00004438
		// (set) Token: 0x060005D1 RID: 1489 RVA: 0x0000625A File Offset: 0x0000445A
		public int NetworkRedirectTcp6666
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mNetworkRedirectKeyPath, "tcp/6666", 6666, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mNetworkRedirectKeyPath, "tcp/6666", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001AB RID: 427
		// (get) Token: 0x060005D2 RID: 1490 RVA: 0x00006275 File Offset: 0x00004475
		// (set) Token: 0x060005D3 RID: 1491 RVA: 0x00006297 File Offset: 0x00004497
		public int NetworkRedirectTcp7777
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mNetworkRedirectKeyPath, "tcp/7777", 7777, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mNetworkRedirectKeyPath, "tcp/7777", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001AC RID: 428
		// (get) Token: 0x060005D4 RID: 1492 RVA: 0x000062B2 File Offset: 0x000044B2
		// (set) Token: 0x060005D5 RID: 1493 RVA: 0x000062D4 File Offset: 0x000044D4
		public int NetworkRedirectTcp9999
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mNetworkRedirectKeyPath, "tcp/9999", 8888, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mNetworkRedirectKeyPath, "tcp/9999", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001AD RID: 429
		// (get) Token: 0x060005D6 RID: 1494 RVA: 0x000062EF File Offset: 0x000044EF
		// (set) Token: 0x060005D7 RID: 1495 RVA: 0x00006311 File Offset: 0x00004511
		public int NetworkRedirectUdp12000
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mNetworkRedirectKeyPath, "udp/12000", 12000, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mNetworkRedirectKeyPath, "udp/12000", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001AE RID: 430
		// (get) Token: 0x060005D8 RID: 1496 RVA: 0x0000632C File Offset: 0x0000452C
		// (set) Token: 0x060005D9 RID: 1497 RVA: 0x00006349 File Offset: 0x00004549
		public string SharedFolder0Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder0KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder0KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001AF RID: 431
		// (get) Token: 0x060005DA RID: 1498 RVA: 0x0000635F File Offset: 0x0000455F
		// (set) Token: 0x060005DB RID: 1499 RVA: 0x0000637C File Offset: 0x0000457C
		public string SharedFolder0Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder0KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder0KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001B0 RID: 432
		// (get) Token: 0x060005DC RID: 1500 RVA: 0x00006392 File Offset: 0x00004592
		// (set) Token: 0x060005DD RID: 1501 RVA: 0x000063B0 File Offset: 0x000045B0
		public int SharedFolder0Writable
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mSharedFolder0KeyPath, "Writable", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder0KeyPath, "Writable", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001B1 RID: 433
		// (get) Token: 0x060005DE RID: 1502 RVA: 0x000063CB File Offset: 0x000045CB
		// (set) Token: 0x060005DF RID: 1503 RVA: 0x000063E8 File Offset: 0x000045E8
		public string SharedFolder1Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder1KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder1KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001B2 RID: 434
		// (get) Token: 0x060005E0 RID: 1504 RVA: 0x000063FE File Offset: 0x000045FE
		// (set) Token: 0x060005E1 RID: 1505 RVA: 0x0000641B File Offset: 0x0000461B
		public string SharedFolder1Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder1KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder1KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001B3 RID: 435
		// (get) Token: 0x060005E2 RID: 1506 RVA: 0x00006431 File Offset: 0x00004631
		// (set) Token: 0x060005E3 RID: 1507 RVA: 0x0000644F File Offset: 0x0000464F
		public int SharedFolder1Writable
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mSharedFolder1KeyPath, "Writable", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder1KeyPath, "Writable", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001B4 RID: 436
		// (get) Token: 0x060005E4 RID: 1508 RVA: 0x0000646A File Offset: 0x0000466A
		// (set) Token: 0x060005E5 RID: 1509 RVA: 0x00006487 File Offset: 0x00004687
		public string SharedFolder2Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder2KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder2KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001B5 RID: 437
		// (get) Token: 0x060005E6 RID: 1510 RVA: 0x0000649D File Offset: 0x0000469D
		// (set) Token: 0x060005E7 RID: 1511 RVA: 0x000064BA File Offset: 0x000046BA
		public string SharedFolder2Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder2KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder2KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001B6 RID: 438
		// (get) Token: 0x060005E8 RID: 1512 RVA: 0x000064D0 File Offset: 0x000046D0
		// (set) Token: 0x060005E9 RID: 1513 RVA: 0x000064EE File Offset: 0x000046EE
		public int SharedFolder2Writable
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mSharedFolder2KeyPath, "Writable", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder2KeyPath, "Writable", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001B7 RID: 439
		// (get) Token: 0x060005EA RID: 1514 RVA: 0x00006509 File Offset: 0x00004709
		// (set) Token: 0x060005EB RID: 1515 RVA: 0x00006526 File Offset: 0x00004726
		public string SharedFolder3Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder3KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder3KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001B8 RID: 440
		// (get) Token: 0x060005EC RID: 1516 RVA: 0x0000653C File Offset: 0x0000473C
		// (set) Token: 0x060005ED RID: 1517 RVA: 0x00006559 File Offset: 0x00004759
		public string SharedFolder3Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder3KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder3KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001B9 RID: 441
		// (get) Token: 0x060005EE RID: 1518 RVA: 0x0000656F File Offset: 0x0000476F
		// (set) Token: 0x060005EF RID: 1519 RVA: 0x0000658D File Offset: 0x0000478D
		public int SharedFolder3Writable
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mSharedFolder3KeyPath, "Writable", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder3KeyPath, "Writable", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001BA RID: 442
		// (get) Token: 0x060005F0 RID: 1520 RVA: 0x000065A8 File Offset: 0x000047A8
		// (set) Token: 0x060005F1 RID: 1521 RVA: 0x000065C5 File Offset: 0x000047C5
		public string SharedFolder4Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder4KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder4KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001BB RID: 443
		// (get) Token: 0x060005F2 RID: 1522 RVA: 0x000065DB File Offset: 0x000047DB
		// (set) Token: 0x060005F3 RID: 1523 RVA: 0x000065F8 File Offset: 0x000047F8
		public string SharedFolder4Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder4KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder4KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001BC RID: 444
		// (get) Token: 0x060005F4 RID: 1524 RVA: 0x0000660E File Offset: 0x0000480E
		// (set) Token: 0x060005F5 RID: 1525 RVA: 0x0000662C File Offset: 0x0000482C
		public int SharedFolder4Writable
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mSharedFolder4KeyPath, "Writable", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder4KeyPath, "Writable", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001BD RID: 445
		// (get) Token: 0x060005F6 RID: 1526 RVA: 0x00006647 File Offset: 0x00004847
		// (set) Token: 0x060005F7 RID: 1527 RVA: 0x00006664 File Offset: 0x00004864
		public string SharedFolder5Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder5KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder5KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001BE RID: 446
		// (get) Token: 0x060005F8 RID: 1528 RVA: 0x0000667A File Offset: 0x0000487A
		// (set) Token: 0x060005F9 RID: 1529 RVA: 0x00006697 File Offset: 0x00004897
		public string SharedFolder5Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder5KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder5KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001BF RID: 447
		// (get) Token: 0x060005FA RID: 1530 RVA: 0x000066AD File Offset: 0x000048AD
		// (set) Token: 0x060005FB RID: 1531 RVA: 0x000066CB File Offset: 0x000048CB
		public int SharedFolder5Writable
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mSharedFolder5KeyPath, "Writable", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder5KeyPath, "Writable", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x04000482 RID: 1154
		private string mVmId;

		// Token: 0x04000483 RID: 1155
		private string mBaseKeyPath = "";

		// Token: 0x04000484 RID: 1156
		private string mAndroidKeyPath = "";

		// Token: 0x04000485 RID: 1157
		private string mBlockDeviceKeyPath = "";

		// Token: 0x04000486 RID: 1158
		private string mBlockDevice0KeyPath = "";

		// Token: 0x04000487 RID: 1159
		private string mBlockDevice1KeyPath = "";

		// Token: 0x04000488 RID: 1160
		private string mBlockDevice2KeyPath = "";

		// Token: 0x04000489 RID: 1161
		private string mBlockDevice3KeyPath = "";

		// Token: 0x0400048A RID: 1162
		private string mBlockDevice4KeyPath = "";

		// Token: 0x0400048B RID: 1163
		private string mVmConfigKeyPath = "";

		// Token: 0x0400048C RID: 1164
		private string mFrameBufferKeyPath = "";

		// Token: 0x0400048D RID: 1165
		private string mFrameBuffer0KeyPath = "";

		// Token: 0x0400048E RID: 1166
		private string mNetworkKeyPath = "";

		// Token: 0x0400048F RID: 1167
		private string mNetwork0KeyPath = "";

		// Token: 0x04000490 RID: 1168
		private string mNetworkRedirectKeyPath = "";

		// Token: 0x04000491 RID: 1169
		private string mSharedFolderKeyPath = "";

		// Token: 0x04000492 RID: 1170
		private string mSharedFolder0KeyPath = "";

		// Token: 0x04000493 RID: 1171
		private string mSharedFolder1KeyPath = "";

		// Token: 0x04000494 RID: 1172
		private string mSharedFolder2KeyPath = "";

		// Token: 0x04000495 RID: 1173
		private string mSharedFolder3KeyPath = "";

		// Token: 0x04000496 RID: 1174
		private string mSharedFolder4KeyPath = "";

		// Token: 0x04000497 RID: 1175
		private string mSharedFolder5KeyPath = "";
	}
}
