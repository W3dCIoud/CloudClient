﻿using System;
using BstkTypeLib;

namespace BlueStacks.Common
{
	// Token: 0x0200012F RID: 303
	public class VboxUtilsBase
	{
		// Token: 0x06000A72 RID: 2674 RVA: 0x0002DFB8 File Offset: 0x0002C1B8
		protected bool Init()
		{
			Logger.Info("In VboxUtilsBase init");
			try
			{
				if (this.mVirtualBox != null)
				{
					return true;
				}
				VboxUtilsBase.sVirtualBoxClient = new VirtualBoxClientClass();
				this.mVirtualBox = VboxUtilsBase.sVirtualBoxClient.VirtualBox;
			}
			catch (Exception ex)
			{
				Logger.Warning("Virtual box init failed, error : {0}", new object[]
				{
					ex.ToString()
				});
				try
				{
					ComRegistration.Register();
					Logger.Info("Retrying to init VBox");
					if (this.mVirtualBox != null)
					{
						return true;
					}
					VboxUtilsBase.sVirtualBoxClient = new VirtualBoxClientClass();
					this.mVirtualBox = VboxUtilsBase.sVirtualBoxClient.VirtualBox;
				}
				catch (Exception ex2)
				{
					Logger.Error("Virtual box init failed, error : {0}", new object[]
					{
						ex2.ToString()
					});
					return false;
				}
			}
			return true;
		}

		// Token: 0x06000A73 RID: 2675 RVA: 0x0002E08C File Offset: 0x0002C28C
		protected void InternalOpenMachine(string vmName)
		{
			Logger.Info("In InternalOpenMachine");
			if (this.mVirtualBox == null)
			{
				this.Init();
			}
			this.mSession = VboxUtilsBase.sVirtualBoxClient.Session;
			this.mVirtualBox.FindMachine(vmName).LockMachine(this.mSession, 3);
			this.mConsole = this.mSession.Console;
			this.mMachine = this.mConsole.Machine;
		}

		// Token: 0x06000A74 RID: 2676 RVA: 0x0002E0FC File Offset: 0x0002C2FC
		protected void InternalCloseMachine()
		{
			Logger.Info("In InternalCloseMachine");
			if (this.mSession != null)
			{
				Logger.Info("Session state is {0}", new object[]
				{
					this.mSession.State
				});
			}
			if (this.mSession != null && this.mSession.State != 1)
			{
				try
				{
					this.mSession.UnlockMachine();
					Logger.Info("Successfully Unlocked machine");
				}
				catch (Exception ex)
				{
					Logger.Warning("Could not unlock the machine due to exception {0}", new object[]
					{
						ex.ToString()
					});
				}
			}
		}

		// Token: 0x06000A75 RID: 2677 RVA: 0x0002E198 File Offset: 0x0002C398
		protected IMediumAttachment[] GetMediumAttachments(ref string controllerName)
		{
			IMediumAttachment[] mediumAttachmentsOfController = this.mMachine.GetMediumAttachmentsOfController("SCSI");
			if (mediumAttachmentsOfController == null || mediumAttachmentsOfController.Length == 0)
			{
				mediumAttachmentsOfController = this.mMachine.GetMediumAttachmentsOfController("SATA");
				controllerName = "SATA";
			}
			else
			{
				controllerName = "SCSI";
			}
			return mediumAttachmentsOfController;
		}

		// Token: 0x04000767 RID: 1895
		protected static IVirtualBoxClient sVirtualBoxClient;

		// Token: 0x04000768 RID: 1896
		public IVirtualBox mVirtualBox;

		// Token: 0x04000769 RID: 1897
		public Session mSession;

		// Token: 0x0400076A RID: 1898
		public IConsole mConsole;

		// Token: 0x0400076B RID: 1899
		public IMachine mMachine;

		// Token: 0x0400076C RID: 1900
		public int sVmId;
	}
}
