﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Microsoft.Win32;

namespace BlueStacks.Common
{
	// Token: 0x020000E5 RID: 229
	public sealed class RegistryManager
	{
		// Token: 0x170001FB RID: 507
		// (get) Token: 0x060006F0 RID: 1776 RVA: 0x00006E28 File Offset: 0x00005028
		// (set) Token: 0x060006F1 RID: 1777 RVA: 0x00006E2F File Offset: 0x0000502F
		public static string UPGRADE_TAG
		{
			get
			{
				return RegistryManager.mUPGRADE_TAG;
			}
			set
			{
				RegistryManager.ClearRegistryMangerInstance();
				RegistryManager.mUPGRADE_TAG = value;
			}
		}

		// Token: 0x170001FC RID: 508
		// (get) Token: 0x060006F2 RID: 1778 RVA: 0x0001FF54 File Offset: 0x0001E154
		// (set) Token: 0x060006F3 RID: 1779 RVA: 0x00006E3C File Offset: 0x0000503C
		public static RegistryManager Instance
		{
			get
			{
				if (RegistryManager.sInstance == null)
				{
					object obj = RegistryManager.sLock;
					lock (obj)
					{
						if (RegistryManager.sInstance == null)
						{
							RegistryManager registryManager = new RegistryManager();
							registryManager.mIsAdmin = SystemUtils.IsAdministrator();
							registryManager.Init();
							RegistryManager.sInstance = registryManager;
						}
					}
				}
				return RegistryManager.sInstance;
			}
			set
			{
				RegistryManager.sInstance = value;
			}
		}

		// Token: 0x170001FD RID: 509
		// (get) Token: 0x060006F4 RID: 1780 RVA: 0x00006E44 File Offset: 0x00005044
		public Dictionary<string, InstanceRegistry> Guest
		{
			get
			{
				return this.mGuest;
			}
		}

		// Token: 0x170001FE RID: 510
		// (get) Token: 0x060006F5 RID: 1781 RVA: 0x00006E4C File Offset: 0x0000504C
		public InstanceRegistry DefaultGuest
		{
			get
			{
				return this.Guest[Strings.CurrentDefaultVmName];
			}
		}

		// Token: 0x170001FF RID: 511
		// (get) Token: 0x060006F6 RID: 1782 RVA: 0x00006E5E File Offset: 0x0000505E
		public string BaseKeyPath
		{
			get
			{
				return this.mBaseKeyPath;
			}
		}

		// Token: 0x17000200 RID: 512
		// (get) Token: 0x060006F7 RID: 1783 RVA: 0x00006E66 File Offset: 0x00005066
		public string ClientBaseKeyPath
		{
			get
			{
				return this.mClientBaseKeyPath;
			}
		}

		// Token: 0x17000201 RID: 513
		// (get) Token: 0x060006F8 RID: 1784 RVA: 0x00006E6E File Offset: 0x0000506E
		public string BTVKeyPath
		{
			get
			{
				return this.mBTVKeyPath;
			}
		}

		// Token: 0x17000202 RID: 514
		// (get) Token: 0x060006F9 RID: 1785 RVA: 0x00006E76 File Offset: 0x00005076
		public string HostConfigKeyPath
		{
			get
			{
				return this.mHostConfigKeyPath;
			}
		}

		// Token: 0x060006FA RID: 1786 RVA: 0x0001FFB4 File Offset: 0x0001E1B4
		private RegistryManager()
		{
		}

		// Token: 0x060006FB RID: 1787 RVA: 0x00006E7E File Offset: 0x0000507E
		private RegistryKey InitKeyWithSecurityCheck(string keyName)
		{
			if (!this.mIsAdmin)
			{
				return Registry.LocalMachine.OpenSubKey(keyName);
			}
			return Registry.LocalMachine.CreateSubKey(keyName);
		}

		// Token: 0x060006FC RID: 1788 RVA: 0x00006E9F File Offset: 0x0000509F
		public static void ClearRegistryMangerInstance()
		{
			RegistryManager.sInstance = null;
		}

		// Token: 0x060006FD RID: 1789 RVA: 0x00020020 File Offset: 0x0001E220
		private void Init()
		{
			this.mBaseKeyPath = RegistryStrings.RegistryBaseKeyPath + RegistryManager.UPGRADE_TAG;
			this.mHostConfigKeyPath = this.mBaseKeyPath + "\\Config";
			this.mClientBaseKeyPath = this.mBaseKeyPath + "\\Client";
			this.mBTVKeyPath = this.mBaseKeyPath + "\\BTV";
			this.mBaseKey = this.InitKeyWithSecurityCheck(this.mBaseKeyPath);
			this.mBTVKey = RegistryUtils.InitKey(this.mBaseKeyPath + "\\BTV");
			this.mBTVFilterKey = RegistryUtils.InitKey(this.mBaseKeyPath + "\\BTV\\Filters");
			this.mClientKey = RegistryUtils.InitKey(this.mBaseKeyPath + "\\Client");
			this.mUserKey = RegistryUtils.InitKey(this.mBaseKeyPath + "\\User");
			this.mHostConfigKey = RegistryUtils.InitKey(this.mBaseKeyPath + "\\Config");
			this.mGuestsKey = RegistryUtils.InitKey(this.mBaseKeyPath + "\\Guests");
			this.mMonitorsKey = RegistryUtils.InitKey(this.mBaseKeyPath + "\\Monitors");
			if (this.mClientKey == null)
			{
				if (SystemUtils.IsOs64Bit())
				{
					this.mClientKey = RegistryUtils.InitKey("Software\\Wow6432Node\\BlueStacksGP");
				}
				else
				{
					this.mClientKey = RegistryUtils.InitKey("Software\\BlueStacksGP");
				}
			}
			foreach (string text in this.VmList)
			{
				this.Guest[text] = new InstanceRegistry(text);
			}
		}

		// Token: 0x060006FE RID: 1790 RVA: 0x000201B0 File Offset: 0x0001E3B0
		public static void InitVmKeysForInstaller(List<string> vmList)
		{
			if (RegistryManager.sInstance == null)
			{
				RegistryManager.sInstance = new RegistryManager();
				RegistryManager.sInstance.mIsAdmin = SystemUtils.IsAdministrator();
				RegistryManager.sInstance.Init();
			}
			foreach (string text in vmList)
			{
				if (!RegistryManager.sInstance.Guest.ContainsKey(text))
				{
					RegistryManager.sInstance.Guest[text] = new InstanceRegistry(text);
				}
			}
		}

		// Token: 0x060006FF RID: 1791 RVA: 0x0002024C File Offset: 0x0001E44C
		public void SetAccessPermissions()
		{
			RegistryUtils.GrantAllAccessPermission(this.mHostConfigKey);
			RegistryUtils.GrantAllAccessPermission(this.mUserKey);
			RegistryUtils.GrantAllAccessPermission(this.mBTVKey);
			RegistryUtils.GrantAllAccessPermission(this.mClientKey);
			RegistryUtils.GrantAllAccessPermission(this.mGuestsKey);
			RegistryUtils.GrantAllAccessPermission(this.mMonitorsKey);
		}

		// Token: 0x06000700 RID: 1792 RVA: 0x0002029C File Offset: 0x0001E49C
		public bool DeleteAndroidSubKey(string vmName)
		{
			try
			{
				string subkey = string.Format("{0}\\Guests\\{1}", this.mBaseKeyPath, vmName);
				Registry.LocalMachine.DeleteSubKeyTree(subkey);
				this.Guest.Remove(vmName);
			}
			catch
			{
				return false;
			}
			return true;
		}

		// Token: 0x17000203 RID: 515
		// (get) Token: 0x06000701 RID: 1793 RVA: 0x00006EA7 File Offset: 0x000050A7
		// (set) Token: 0x06000702 RID: 1794 RVA: 0x00006ECC File Offset: 0x000050CC
		public string[] VmList
		{
			get
			{
				return (string[])this.mHostConfigKey.GetValue("VmList", new string[]
				{
					"Android"
				});
			}
			set
			{
				this.mHostConfigKey.SetValue("VmList", value, RegistryValueKind.MultiString);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000204 RID: 516
		// (get) Token: 0x06000703 RID: 1795 RVA: 0x00006EEB File Offset: 0x000050EB
		// (set) Token: 0x06000704 RID: 1796 RVA: 0x00006F08 File Offset: 0x00005108
		public string[] UpgradeVersionList
		{
			get
			{
				return (string[])this.mHostConfigKey.GetValue("UpgradeVersionList", new string[0]);
			}
			set
			{
				this.mHostConfigKey.SetValue("UpgradeVersionList", value, RegistryValueKind.MultiString);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000205 RID: 517
		// (get) Token: 0x06000705 RID: 1797 RVA: 0x00006F27 File Offset: 0x00005127
		// (set) Token: 0x06000706 RID: 1798 RVA: 0x00006F49 File Offset: 0x00005149
		public bool IsShootingModeTooltipVisible
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("IsShootingModeTooltipVisible", 1) != 0;
			}
			set
			{
				this.mHostConfigKey.SetValue("IsShootingModeTooltipVisible", (!value) ? 0 : 1);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000206 RID: 518
		// (get) Token: 0x06000707 RID: 1799 RVA: 0x00006F72 File Offset: 0x00005172
		// (set) Token: 0x06000708 RID: 1800 RVA: 0x00006F94 File Offset: 0x00005194
		public bool KeyMappingAvailablePromptEnabled
		{
			get
			{
				return (int)this.mClientKey.GetValue("KeyMappingAvailablePromptEnabled", 1) != 0;
			}
			set
			{
				this.mClientKey.SetValue("KeyMappingAvailablePromptEnabled", (!value) ? 0 : 1);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000207 RID: 519
		// (get) Token: 0x06000709 RID: 1801 RVA: 0x00006FBD File Offset: 0x000051BD
		// (set) Token: 0x0600070A RID: 1802 RVA: 0x00006FDF File Offset: 0x000051DF
		public bool ForceDedicatedGPU
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("ForceDedicatedGPU", 1) != 0;
			}
			set
			{
				this.mHostConfigKey.SetValue("ForceDedicatedGPU", (!value) ? 0 : 1);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000208 RID: 520
		// (get) Token: 0x0600070B RID: 1803 RVA: 0x00007008 File Offset: 0x00005208
		// (set) Token: 0x0600070C RID: 1804 RVA: 0x0000702A File Offset: 0x0000522A
		public bool OverlayAvailablePromptEnabled
		{
			get
			{
				return (int)this.mClientKey.GetValue("OverlayAvailablePromptEnabled", 0) != 0;
			}
			set
			{
				this.mClientKey.SetValue("OverlayAvailablePromptEnabled", (!value) ? 0 : 1);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000209 RID: 521
		// (get) Token: 0x0600070D RID: 1805 RVA: 0x00007053 File Offset: 0x00005253
		// (set) Token: 0x0600070E RID: 1806 RVA: 0x00007075 File Offset: 0x00005275
		public bool ShowKeyControlsOverlay
		{
			get
			{
				return (int)this.mClientKey.GetValue("ShowKeyControlsOverlay", 0) != 0;
			}
			set
			{
				this.mClientKey.SetValue("ShowKeyControlsOverlay", (!value) ? 0 : 1);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700020A RID: 522
		// (get) Token: 0x0600070F RID: 1807 RVA: 0x0000709E File Offset: 0x0000529E
		// (set) Token: 0x06000710 RID: 1808 RVA: 0x000070C0 File Offset: 0x000052C0
		public bool TranslucentControlsEnabled
		{
			get
			{
				return (int)this.mClientKey.GetValue("TranslucentControlsEnabled", 0) != 0;
			}
			set
			{
				this.mClientKey.SetValue("TranslucentControlsEnabled", (!value) ? 0 : 1);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700020B RID: 523
		// (get) Token: 0x06000711 RID: 1809 RVA: 0x000070E9 File Offset: 0x000052E9
		// (set) Token: 0x06000712 RID: 1810 RVA: 0x00007118 File Offset: 0x00005318
		public double TranslucentControlsTransparency
		{
			get
			{
				return double.Parse(this.mClientKey.GetValue("TranslucentControlsTransparency", 0.7).ToString(), CultureInfo.InvariantCulture);
			}
			set
			{
				this.mClientKey.SetValue("TranslucentControlsTransparency", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700020C RID: 524
		// (get) Token: 0x06000713 RID: 1811 RVA: 0x0000713B File Offset: 0x0000533B
		// (set) Token: 0x06000714 RID: 1812 RVA: 0x0000715E File Offset: 0x0000535E
		public bool ShowGamingSummary
		{
			get
			{
				return (int)this.mClientKey.GetValue("ShowGamingSummary", 1) == 1;
			}
			set
			{
				this.mClientKey.SetValue("ShowGamingSummary", value ? 1 : 0);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700020D RID: 525
		// (get) Token: 0x06000715 RID: 1813 RVA: 0x00007187 File Offset: 0x00005387
		// (set) Token: 0x06000716 RID: 1814 RVA: 0x000071AA File Offset: 0x000053AA
		public bool DiscordEnabled
		{
			get
			{
				return (int)this.mClientKey.GetValue("DiscordEnabled", 1) == 1;
			}
			set
			{
				this.mClientKey.SetValue("DiscordEnabled", value ? 1 : 0);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700020E RID: 526
		// (get) Token: 0x06000717 RID: 1815 RVA: 0x000071D3 File Offset: 0x000053D3
		// (set) Token: 0x06000718 RID: 1816 RVA: 0x000071F6 File Offset: 0x000053F6
		public bool CustomCursorEnabled
		{
			get
			{
				return (int)this.mClientKey.GetValue("CustomCursorEnabled", 1) == 1;
			}
			set
			{
				this.mClientKey.SetValue("CustomCursorEnabled", value ? 1 : 0);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700020F RID: 527
		// (get) Token: 0x06000719 RID: 1817 RVA: 0x0000721F File Offset: 0x0000541F
		// (set) Token: 0x0600071A RID: 1818 RVA: 0x00007242 File Offset: 0x00005442
		public bool GamepadDetectionEnabled
		{
			get
			{
				return (int)this.mClientKey.GetValue("GamepadDetectionEnabled", 1) == 1;
			}
			set
			{
				this.mClientKey.SetValue("GamepadDetectionEnabled", value ? 1 : 0);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000210 RID: 528
		// (get) Token: 0x0600071B RID: 1819 RVA: 0x0000726B File Offset: 0x0000546B
		// (set) Token: 0x0600071C RID: 1820 RVA: 0x0000728D File Offset: 0x0000548D
		public List<string> IgnoreAutoPlayPackageList
		{
			get
			{
				return ((string[])this.mClientKey.GetValue("ShownVideoOnFirstLaunchPackageList", new string[0])).ToList<string>();
			}
			set
			{
				this.mClientKey.SetValue("ShownVideoOnFirstLaunchPackageList", value.ToArray(), RegistryValueKind.MultiString);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000211 RID: 529
		// (get) Token: 0x0600071D RID: 1821 RVA: 0x000072B1 File Offset: 0x000054B1
		// (set) Token: 0x0600071E RID: 1822 RVA: 0x000072D3 File Offset: 0x000054D3
		public bool UpdateBstConfig
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("UpdateBstConfig", 0) != 0;
			}
			set
			{
				this.mHostConfigKey.SetValue("UpdateBstConfig", (!value) ? 0 : 1);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000212 RID: 530
		// (get) Token: 0x0600071F RID: 1823 RVA: 0x000072FC File Offset: 0x000054FC
		// (set) Token: 0x06000720 RID: 1824 RVA: 0x0000731A File Offset: 0x0000551A
		public int CommonFPS
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("CommonFPS", 60);
			}
			set
			{
				this.mHostConfigKey.SetValue("CommonFPS", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000213 RID: 531
		// (get) Token: 0x06000721 RID: 1825 RVA: 0x0000733D File Offset: 0x0000553D
		// (set) Token: 0x06000722 RID: 1826 RVA: 0x0000735B File Offset: 0x0000555B
		public int TrimMemoryDuration
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("TrimMemoryDuration", 15);
			}
			set
			{
				this.mHostConfigKey.SetValue("TrimMemoryDuration", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000214 RID: 532
		// (get) Token: 0x06000723 RID: 1827 RVA: 0x0000737E File Offset: 0x0000557E
		public int DevEnv
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("DevEnv", 0);
			}
		}

		// Token: 0x17000215 RID: 533
		// (get) Token: 0x06000724 RID: 1828 RVA: 0x0000739B File Offset: 0x0000559B
		// (set) Token: 0x06000725 RID: 1829 RVA: 0x000073B8 File Offset: 0x000055B8
		public int ArrangeWindowMode
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("ArrangeWindowModeConfig", 0);
			}
			set
			{
				this.mHostConfigKey.SetValue("ArrangeWindowModeConfig", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000216 RID: 534
		// (get) Token: 0x06000726 RID: 1830 RVA: 0x000073DB File Offset: 0x000055DB
		// (set) Token: 0x06000727 RID: 1831 RVA: 0x000073F8 File Offset: 0x000055F8
		public int TileWindowColumnCount
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("TileWindowColumnCount", 2);
			}
			set
			{
				this.mHostConfigKey.SetValue("TileWindowColumnCount", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000217 RID: 535
		// (get) Token: 0x06000728 RID: 1832 RVA: 0x0000741B File Offset: 0x0000561B
		// (set) Token: 0x06000729 RID: 1833 RVA: 0x0000743D File Offset: 0x0000563D
		public bool ManageGooglePlayPromptEnabled
		{
			get
			{
				return (int)this.mClientKey.GetValue("ManageGooglePlayPromptEnabled", 1) != 0;
			}
			set
			{
				this.mClientKey.SetValue("ManageGooglePlayPromptEnabled", (!value) ? 0 : 1);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000218 RID: 536
		// (get) Token: 0x0600072A RID: 1834 RVA: 0x00007466 File Offset: 0x00005666
		// (set) Token: 0x0600072B RID: 1835 RVA: 0x00007489 File Offset: 0x00005689
		public bool UseEscapeToExitFullScreen
		{
			get
			{
				return (int)this.mClientKey.GetValue("UseEscapeToExitFullScreen", 0) == 1;
			}
			set
			{
				this.mClientKey.SetValue("UseEscapeToExitFullScreen", value ? 1 : 0);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000219 RID: 537
		// (get) Token: 0x0600072C RID: 1836 RVA: 0x000074B2 File Offset: 0x000056B2
		// (set) Token: 0x0600072D RID: 1837 RVA: 0x000074D5 File Offset: 0x000056D5
		public bool IsVTXPopupEnable
		{
			get
			{
				return (int)this.mClientKey.GetValue("IsVTXPopupEnable", 1) == 1;
			}
			set
			{
				this.mClientKey.SetValue("IsVTXPopupEnable", value ? 1 : 0);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700021A RID: 538
		// (get) Token: 0x0600072E RID: 1838 RVA: 0x000074FE File Offset: 0x000056FE
		// (set) Token: 0x0600072F RID: 1839 RVA: 0x0000751B File Offset: 0x0000571B
		public int FrontendHeight
		{
			get
			{
				return (int)this.mClientKey.GetValue("FrontendHeight", 0);
			}
			set
			{
				this.mClientKey.SetValue("FrontendHeight", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700021B RID: 539
		// (get) Token: 0x06000730 RID: 1840 RVA: 0x0000753E File Offset: 0x0000573E
		// (set) Token: 0x06000731 RID: 1841 RVA: 0x0000755B File Offset: 0x0000575B
		public int FrontendWidth
		{
			get
			{
				return (int)this.mClientKey.GetValue("FrontendWidth", 0);
			}
			set
			{
				this.mClientKey.SetValue("FrontendWidth", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700021C RID: 540
		// (get) Token: 0x06000732 RID: 1842 RVA: 0x0000757E File Offset: 0x0000577E
		// (set) Token: 0x06000733 RID: 1843 RVA: 0x0000759A File Offset: 0x0000579A
		public string BossKey
		{
			get
			{
				return (string)this.mClientKey.GetValue("BossKey", "");
			}
			set
			{
				this.mClientKey.SetValue("BossKey", value);
			}
		}

		// Token: 0x1700021D RID: 541
		// (get) Token: 0x06000734 RID: 1844 RVA: 0x000075AD File Offset: 0x000057AD
		// (set) Token: 0x06000735 RID: 1845 RVA: 0x000075C9 File Offset: 0x000057C9
		public string CampaignMD5
		{
			get
			{
				return (string)this.mClientKey.GetValue("CampaignMD5", "");
			}
			set
			{
				this.mClientKey.SetValue("CampaignMD5", value);
				this.mClientKey.SetValue("FLECampaignMD5", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700021E RID: 542
		// (get) Token: 0x06000736 RID: 1846 RVA: 0x000075F8 File Offset: 0x000057F8
		public string FLECampaignMD5
		{
			get
			{
				return (string)this.mClientKey.GetValue("FLECampaignMD5", string.Empty);
			}
		}

		// Token: 0x1700021F RID: 543
		// (get) Token: 0x06000737 RID: 1847 RVA: 0x00007614 File Offset: 0x00005814
		// (set) Token: 0x06000738 RID: 1848 RVA: 0x00007630 File Offset: 0x00005830
		public string CampaignJson
		{
			get
			{
				return (string)this.mClientKey.GetValue("CampaignJson", "");
			}
			set
			{
				this.mClientKey.SetValue("CampaignJson", value);
				if (!string.IsNullOrEmpty(value))
				{
					this.DeleteFLECampaignMD5();
				}
				this.mClientKey.Flush();
			}
		}

		// Token: 0x06000739 RID: 1849 RVA: 0x0000765C File Offset: 0x0000585C
		public void DeleteFLECampaignMD5()
		{
			if (this.mClientKey.GetValue("FLECampaignMD5", null) != null)
			{
				this.mClientKey.DeleteValue("FLECampaignMD5");
			}
		}

		// Token: 0x17000220 RID: 544
		// (get) Token: 0x0600073A RID: 1850 RVA: 0x00007681 File Offset: 0x00005881
		// (set) Token: 0x0600073B RID: 1851 RVA: 0x0000769D File Offset: 0x0000589D
		public string CDNAppsTimeStamp
		{
			get
			{
				return (string)this.mClientKey.GetValue("CDNAppsTimeStamp", "");
			}
			set
			{
				this.mClientKey.SetValue("CDNAppsTimeStamp", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000221 RID: 545
		// (get) Token: 0x0600073C RID: 1852 RVA: 0x000076BB File Offset: 0x000058BB
		// (set) Token: 0x0600073D RID: 1853 RVA: 0x000076D7 File Offset: 0x000058D7
		public string SetupFolder
		{
			get
			{
				return (string)this.mClientKey.GetValue("SetupFolder", Strings.BlueStacksSetupFolder);
			}
			set
			{
				this.mClientKey.SetValue("SetupFolder", value);
			}
		}

		// Token: 0x17000222 RID: 546
		// (get) Token: 0x0600073E RID: 1854 RVA: 0x000076EA File Offset: 0x000058EA
		// (set) Token: 0x0600073F RID: 1855 RVA: 0x00007706 File Offset: 0x00005906
		public string EngineDataDir
		{
			get
			{
				return (string)this.mClientKey.GetValue("EngineDataDir", "");
			}
			set
			{
				this.mClientKey.SetValue("EngineDataDir", value);
			}
		}

		// Token: 0x17000223 RID: 547
		// (get) Token: 0x06000740 RID: 1856 RVA: 0x00007719 File Offset: 0x00005919
		// (set) Token: 0x06000741 RID: 1857 RVA: 0x00007735 File Offset: 0x00005935
		public string ClientInstallDir
		{
			get
			{
				return (string)this.mClientKey.GetValue("ClientInstallDir", "");
			}
			set
			{
				this.mClientKey.SetValue("ClientInstallDir", value);
			}
		}

		// Token: 0x17000224 RID: 548
		// (get) Token: 0x06000742 RID: 1858 RVA: 0x00007748 File Offset: 0x00005948
		// (set) Token: 0x06000743 RID: 1859 RVA: 0x0000777D File Offset: 0x0000597D
		public string ClientThemeName
		{
			get
			{
				if (string.IsNullOrEmpty(this.mThemeName))
				{
					this.mThemeName = (string)this.mClientKey.GetValue("ClientThemeName", "Assets");
				}
				return this.mThemeName;
			}
			set
			{
				this.mThemeName = value;
				this.mClientKey.SetValue("ClientThemeName", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000225 RID: 549
		// (get) Token: 0x06000744 RID: 1860 RVA: 0x000077A2 File Offset: 0x000059A2
		// (set) Token: 0x06000745 RID: 1861 RVA: 0x000077C5 File Offset: 0x000059C5
		public bool OpenThemeEditor
		{
			get
			{
				return (int)this.mClientKey.GetValue("OpenThemeEditor", 0) == 1;
			}
			set
			{
				this.mClientKey.SetValue("OpenThemeEditor", value ? 1 : 0);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000226 RID: 550
		// (get) Token: 0x06000746 RID: 1862 RVA: 0x000077EE File Offset: 0x000059EE
		// (set) Token: 0x06000747 RID: 1863 RVA: 0x0000780A File Offset: 0x00005A0A
		public string CefDataPath
		{
			get
			{
				return (string)this.mClientKey.GetValue("CefDataPath", string.Empty);
			}
			set
			{
				this.mClientKey.SetValue("CefDataPath", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000227 RID: 551
		// (get) Token: 0x06000748 RID: 1864 RVA: 0x00007828 File Offset: 0x00005A28
		public int CefDevEnv
		{
			get
			{
				return (int)this.mClientKey.GetValue("CefDevEnv", 0);
			}
		}

		// Token: 0x17000228 RID: 552
		// (get) Token: 0x06000749 RID: 1865 RVA: 0x00007845 File Offset: 0x00005A45
		// (set) Token: 0x0600074A RID: 1866 RVA: 0x00007866 File Offset: 0x00005A66
		public int LastBootTime
		{
			get
			{
				return (int)this.mClientKey.GetValue("LastBootTime", 120000);
			}
			set
			{
				this.mClientKey.SetValue("LastBootTime", value);
			}
		}

		// Token: 0x17000229 RID: 553
		// (get) Token: 0x0600074B RID: 1867 RVA: 0x0000787E File Offset: 0x00005A7E
		// (set) Token: 0x0600074C RID: 1868 RVA: 0x0000789B File Offset: 0x00005A9B
		public int NoOfBootCompleted
		{
			get
			{
				return (int)this.mClientKey.GetValue("NoOfBootCompleted", 0);
			}
			set
			{
				this.mClientKey.SetValue("NoOfBootCompleted", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700022A RID: 554
		// (get) Token: 0x0600074D RID: 1869 RVA: 0x000078BE File Offset: 0x00005ABE
		// (set) Token: 0x0600074E RID: 1870 RVA: 0x000078E1 File Offset: 0x00005AE1
		public bool IsScreenshotsLocationPopupEnabled
		{
			get
			{
				return (int)this.mClientKey.GetValue("ScreenshotsLocationPopupEnabled", 1) == 1;
			}
			set
			{
				this.mClientKey.SetValue("ScreenshotsLocationPopupEnabled", (!value) ? 0 : 1);
			}
		}

		// Token: 0x1700022B RID: 555
		// (get) Token: 0x0600074F RID: 1871 RVA: 0x000078FF File Offset: 0x00005AFF
		// (set) Token: 0x06000750 RID: 1872 RVA: 0x0000791F File Offset: 0x00005B1F
		public bool IsSynchronizerUsedStatSent
		{
			get
			{
				return (int)this.mClientKey.GetValue("IsSynchronizerUsedStatSent", 0) == 1;
			}
			set
			{
				this.mClientKey.SetValue("IsSynchronizerUsedStatSent", (!value) ? 0 : 1);
			}
		}

		// Token: 0x1700022C RID: 556
		// (get) Token: 0x06000751 RID: 1873 RVA: 0x0000793D File Offset: 0x00005B3D
		// (set) Token: 0x06000752 RID: 1874 RVA: 0x00007965 File Offset: 0x00005B65
		public string ScreenShotsPath
		{
			get
			{
				return (string)this.mClientKey.GetValue("ScreenShotsPath", Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), Strings.ProductTopBarDisplayName));
			}
			set
			{
				this.mClientKey.SetValue("ScreenShotsPath", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700022D RID: 557
		// (get) Token: 0x06000753 RID: 1875 RVA: 0x00007983 File Offset: 0x00005B83
		// (set) Token: 0x06000754 RID: 1876 RVA: 0x000079A6 File Offset: 0x00005BA6
		public bool RequirementConfigUpdateRequired
		{
			get
			{
				return (int)this.mClientKey.GetValue("RequirementConfigUpdateRequired", 0) == 1;
			}
			set
			{
				this.mClientKey.SetValue("RequirementConfigUpdateRequired", (!value) ? 0 : 1);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700022E RID: 558
		// (get) Token: 0x06000755 RID: 1877 RVA: 0x000079CF File Offset: 0x00005BCF
		public bool IsShowIconBorder
		{
			get
			{
				return (int)this.mClientKey.GetValue("ShowIconBorder", 0) == 1;
			}
		}

		// Token: 0x1700022F RID: 559
		// (get) Token: 0x06000756 RID: 1878 RVA: 0x000079F2 File Offset: 0x00005BF2
		// (set) Token: 0x06000757 RID: 1879 RVA: 0x00007A0E File Offset: 0x00005C0E
		public string UserSelectedLocale
		{
			get
			{
				return (string)this.mClientKey.GetValue("UserSelectedLocale", "");
			}
			set
			{
				if (!string.IsNullOrEmpty(value))
				{
					this.mClientKey.SetValue("UserSelectedLocale", value);
					this.mClientKey.Flush();
				}
			}
		}

		// Token: 0x17000230 RID: 560
		// (get) Token: 0x06000758 RID: 1880 RVA: 0x00007A34 File Offset: 0x00005C34
		public string TargetLocale
		{
			get
			{
				return (string)this.mClientKey.GetValue("TargetLocale", "");
			}
		}

		// Token: 0x17000231 RID: 561
		// (get) Token: 0x06000759 RID: 1881 RVA: 0x00007A50 File Offset: 0x00005C50
		public string TargetLocaleUrl
		{
			get
			{
				return (string)this.mClientKey.GetValue("TargetLocaleUrl", "");
			}
		}

		// Token: 0x17000232 RID: 562
		// (get) Token: 0x0600075A RID: 1882 RVA: 0x00007A6C File Offset: 0x00005C6C
		// (set) Token: 0x0600075B RID: 1883 RVA: 0x00007A88 File Offset: 0x00005C88
		public string FailedUpgradeVersion
		{
			get
			{
				return (string)this.mClientKey.GetValue("FailedUpgradeVersion", "");
			}
			set
			{
				this.mClientKey.SetValue("FailedUpgradeVersion", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000233 RID: 563
		// (get) Token: 0x0600075C RID: 1884 RVA: 0x00007AA6 File Offset: 0x00005CA6
		// (set) Token: 0x0600075D RID: 1885 RVA: 0x00007AC2 File Offset: 0x00005CC2
		public string LastUpdateSkippedVersion
		{
			get
			{
				return (string)this.mClientKey.GetValue("LastUpdateSkippedVersion", "");
			}
			set
			{
				this.mClientKey.SetValue("LastUpdateSkippedVersion", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000234 RID: 564
		// (get) Token: 0x0600075E RID: 1886 RVA: 0x00007AE0 File Offset: 0x00005CE0
		// (set) Token: 0x0600075F RID: 1887 RVA: 0x00007AFC File Offset: 0x00005CFC
		public string Partner
		{
			get
			{
				return (string)this.mClientKey.GetValue("Partner", "");
			}
			set
			{
				this.mClientKey.SetValue("Partner", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000235 RID: 565
		// (get) Token: 0x06000760 RID: 1888 RVA: 0x00007B1A File Offset: 0x00005D1A
		// (set) Token: 0x06000761 RID: 1889 RVA: 0x00007B36 File Offset: 0x00005D36
		public string DownloadedUpdateFile
		{
			get
			{
				return (string)this.mClientKey.GetValue("DownloadedUpdateFile", "");
			}
			set
			{
				this.mClientKey.SetValue("DownloadedUpdateFile", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000236 RID: 566
		// (get) Token: 0x06000762 RID: 1890 RVA: 0x000202F0 File Offset: 0x0001E4F0
		// (set) Token: 0x06000763 RID: 1891 RVA: 0x00007B54 File Offset: 0x00005D54
		public string ClientVersion
		{
			get
			{
				string text = (string)this.mBaseKey.GetValue("ClientVersion", "");
				if (string.IsNullOrEmpty(text))
				{
					text = (string)this.mClientKey.GetValue("ClientVersion", "");
				}
				return text;
			}
			set
			{
				this.mBaseKey.SetValue("ClientVersion", value);
				this.mBaseKey.Flush();
			}
		}

		// Token: 0x17000237 RID: 567
		// (get) Token: 0x06000764 RID: 1892 RVA: 0x00007B72 File Offset: 0x00005D72
		// (set) Token: 0x06000765 RID: 1893 RVA: 0x00007B8F File Offset: 0x00005D8F
		public int IsClientFirstLaunch
		{
			get
			{
				return (int)this.mClientKey.GetValue("IsClientFirstLaunch", 1);
			}
			set
			{
				this.mClientKey.SetValue("IsClientFirstLaunch", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000238 RID: 568
		// (get) Token: 0x06000766 RID: 1894 RVA: 0x00007BB2 File Offset: 0x00005DB2
		// (set) Token: 0x06000767 RID: 1895 RVA: 0x00007BCF File Offset: 0x00005DCF
		public int IsEngineUpgraded
		{
			get
			{
				return (int)this.mClientKey.GetValue("IsEngineUpgraded", 0);
			}
			set
			{
				this.mClientKey.SetValue("IsEngineUpgraded", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000239 RID: 569
		// (get) Token: 0x06000768 RID: 1896 RVA: 0x00007BF2 File Offset: 0x00005DF2
		// (set) Token: 0x06000769 RID: 1897 RVA: 0x00007C15 File Offset: 0x00005E15
		public bool IsShowRibbonNotification
		{
			get
			{
				return (int)this.mClientKey.GetValue("IsShowRibbonNotification", 1) == 1;
			}
			set
			{
				this.mClientKey.SetValue("IsShowRibbonNotification", value ? 1 : 0);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700023A RID: 570
		// (get) Token: 0x0600076A RID: 1898 RVA: 0x00007C3E File Offset: 0x00005E3E
		// (set) Token: 0x0600076B RID: 1899 RVA: 0x00007C61 File Offset: 0x00005E61
		public bool IsShowToastNotification
		{
			get
			{
				return (int)this.mClientKey.GetValue("IsShowToastNotification", 1) == 1;
			}
			set
			{
				this.mClientKey.SetValue("IsShowToastNotification", value ? 1 : 0);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700023B RID: 571
		// (get) Token: 0x0600076C RID: 1900 RVA: 0x00007C8A File Offset: 0x00005E8A
		// (set) Token: 0x0600076D RID: 1901 RVA: 0x00007CAD File Offset: 0x00005EAD
		public bool IsClientUpgraded
		{
			get
			{
				return (int)this.mClientKey.GetValue("IsClientUpgraded", 0) == 1;
			}
			set
			{
				this.mClientKey.SetValue("IsClientUpgraded", value ? 1 : 0);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700023C RID: 572
		// (get) Token: 0x0600076E RID: 1902 RVA: 0x00007CD6 File Offset: 0x00005ED6
		// (set) Token: 0x0600076F RID: 1903 RVA: 0x00007CF2 File Offset: 0x00005EF2
		public string AInfo
		{
			get
			{
				return (string)this.mClientKey.GetValue("AInfo", "");
			}
			set
			{
				this.mClientKey.SetValue("AInfo", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700023D RID: 573
		// (get) Token: 0x06000770 RID: 1904 RVA: 0x00007D10 File Offset: 0x00005F10
		// (set) Token: 0x06000771 RID: 1905 RVA: 0x00007D2C File Offset: 0x00005F2C
		public string BGPDevUrl
		{
			get
			{
				return (string)this.mClientKey.GetValue("BGPDevUrl", "");
			}
			set
			{
				this.mClientKey.SetValue("BGPDevUrl", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700023E RID: 574
		// (get) Token: 0x06000772 RID: 1906 RVA: 0x00004E1D File Offset: 0x0000301D
		public bool SoftwareOnly
		{
			get
			{
				return false;
			}
		}

		// Token: 0x1700023F RID: 575
		// (get) Token: 0x06000773 RID: 1907 RVA: 0x00007D4A File Offset: 0x00005F4A
		public string FriendsDevServer
		{
			get
			{
				return (string)this.mClientKey.GetValue("FriendsDevServer", "");
			}
		}

		// Token: 0x17000240 RID: 576
		// (get) Token: 0x06000774 RID: 1908 RVA: 0x00007D66 File Offset: 0x00005F66
		// (set) Token: 0x06000775 RID: 1909 RVA: 0x00007D82 File Offset: 0x00005F82
		public string PromotionId
		{
			get
			{
				return (string)this.mClientKey.GetValue("PromotionId", "");
			}
			set
			{
				this.mClientKey.SetValue("PromotionId", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000241 RID: 577
		// (get) Token: 0x06000776 RID: 1910 RVA: 0x00007DA0 File Offset: 0x00005FA0
		// (set) Token: 0x06000777 RID: 1911 RVA: 0x00007DBC File Offset: 0x00005FBC
		public string DMMRecommendedWindowUrl
		{
			get
			{
				return (string)this.mClientKey.GetValue("RecommendedWindowUrl", "http://site-gameplayer.dmm.com/emulator-recommend");
			}
			set
			{
				this.mClientKey.SetValue("RecommendedWindowUrl", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000242 RID: 578
		// (get) Token: 0x06000778 RID: 1912 RVA: 0x00007DDA File Offset: 0x00005FDA
		// (set) Token: 0x06000779 RID: 1913 RVA: 0x00007DF6 File Offset: 0x00005FF6
		public string DeviceProfileFromCloud
		{
			get
			{
				return (string)this.mClientKey.GetValue("DeviceProfileFromCloud", string.Empty);
			}
			set
			{
				this.mClientKey.SetValue("DeviceProfileFromCloud", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000243 RID: 579
		// (get) Token: 0x0600077A RID: 1914 RVA: 0x00007E14 File Offset: 0x00006014
		// (set) Token: 0x0600077B RID: 1915 RVA: 0x00007E31 File Offset: 0x00006031
		public int GlPlusTransportConfig
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("GlPlusTransportConfig", 3);
			}
			set
			{
				this.mHostConfigKey.SetValue("GlPlusTransportConfig", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000244 RID: 580
		// (get) Token: 0x0600077C RID: 1916 RVA: 0x00007E54 File Offset: 0x00006054
		// (set) Token: 0x0600077D RID: 1917 RVA: 0x00007E71 File Offset: 0x00006071
		public int GlLegacyTransportConfig
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("GlLegacyTransportConfig", 0);
			}
			set
			{
				this.mHostConfigKey.SetValue("GlLegacyTransportConfig", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000245 RID: 581
		// (get) Token: 0x0600077E RID: 1918 RVA: 0x00007E94 File Offset: 0x00006094
		// (set) Token: 0x0600077F RID: 1919 RVA: 0x00007ECE File Offset: 0x000060CE
		public string CurrentEngine
		{
			get
			{
				if (this.sCurrentEngine == "")
				{
					this.sCurrentEngine = (string)this.mHostConfigKey.GetValue("CurrentEngine", "plus");
				}
				return this.sCurrentEngine;
			}
			set
			{
				this.sCurrentEngine = value;
				this.mHostConfigKey.SetValue("CurrentEngine", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000246 RID: 582
		// (get) Token: 0x06000780 RID: 1920 RVA: 0x00007EF3 File Offset: 0x000060F3
		// (set) Token: 0x06000781 RID: 1921 RVA: 0x00007F0F File Offset: 0x0000610F
		public string EnginePreference
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("EnginePreference", "plus");
			}
			set
			{
				this.mHostConfigKey.SetValue("EnginePreference", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000247 RID: 583
		// (set) Token: 0x06000782 RID: 1922 RVA: 0x00007F2D File Offset: 0x0000612D
		public string InstallDir
		{
			set
			{
				this.mBaseKey.SetValue("InstallDir", value);
				this.mBaseKey.Flush();
			}
		}

		// Token: 0x17000248 RID: 584
		// (get) Token: 0x06000783 RID: 1923 RVA: 0x00007F4B File Offset: 0x0000614B
		// (set) Token: 0x06000784 RID: 1924 RVA: 0x00007F6E File Offset: 0x0000616E
		public bool IsUpgrade
		{
			get
			{
				return (int)this.mBaseKey.GetValue("IsUpgrade", 0) == 1;
			}
			set
			{
				this.mBaseKey.SetValue("IsUpgrade", value ? 1 : 0);
				this.mBaseKey.Flush();
			}
		}

		// Token: 0x17000249 RID: 585
		// (set) Token: 0x06000785 RID: 1925 RVA: 0x00007F97 File Offset: 0x00006197
		public string DataDir
		{
			set
			{
				this.mBaseKey.SetValue("DataDir", value);
				this.mBaseKey.Flush();
			}
		}

		// Token: 0x1700024A RID: 586
		// (get) Token: 0x06000786 RID: 1926 RVA: 0x0002033C File Offset: 0x0001E53C
		// (set) Token: 0x06000787 RID: 1927 RVA: 0x00007FB5 File Offset: 0x000061B5
		public string UserDefinedDir
		{
			get
			{
				if (this.sUserDefinedDir == null)
				{
					string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
					this.sUserDefinedDir = (string)this.mBaseKey.GetValue("UserDefinedDir", folderPath);
				}
				return this.sUserDefinedDir;
			}
			set
			{
				this.sUserDefinedDir = value;
				this.mBaseKey.SetValue("UserDefinedDir", value);
				this.mBaseKey.Flush();
			}
		}

		// Token: 0x1700024B RID: 587
		// (get) Token: 0x06000788 RID: 1928 RVA: 0x0002037C File Offset: 0x0001E57C
		// (set) Token: 0x06000789 RID: 1929 RVA: 0x00007FDA File Offset: 0x000061DA
		public string LogDir
		{
			get
			{
				string text = (string)this.mBaseKey.GetValue("LogDir", null);
				if (text == null)
				{
					text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Bluestacks\\Logs");
				}
				return text;
			}
			set
			{
				this.mBaseKey.SetValue("LogDir", value);
				this.mBaseKey.Flush();
			}
		}

		// Token: 0x1700024C RID: 588
		// (get) Token: 0x0600078A RID: 1930 RVA: 0x00007FF8 File Offset: 0x000061F8
		// (set) Token: 0x0600078B RID: 1931 RVA: 0x00008015 File Offset: 0x00006215
		public int PlusDebug
		{
			get
			{
				return (int)this.mBaseKey.GetValue("PlusDebug", 0);
			}
			set
			{
				this.mBaseKey.SetValue("PlusDebug", value);
				this.mBaseKey.Flush();
			}
		}

		// Token: 0x1700024D RID: 589
		// (get) Token: 0x0600078C RID: 1932 RVA: 0x00008038 File Offset: 0x00006238
		// (set) Token: 0x0600078D RID: 1933 RVA: 0x0000806F File Offset: 0x0000626F
		public string Version
		{
			get
			{
				if (this.sVersion != null)
				{
					return this.sVersion;
				}
				this.sVersion = (string)this.mBaseKey.GetValue("Version", "");
				return this.sVersion;
			}
			set
			{
				this.mBaseKey.SetValue("Version", value);
				this.mBaseKey.Flush();
				this.sVersion = value;
			}
		}

		// Token: 0x1700024E RID: 590
		// (get) Token: 0x0600078E RID: 1934 RVA: 0x00008094 File Offset: 0x00006294
		// (set) Token: 0x0600078F RID: 1935 RVA: 0x000080B0 File Offset: 0x000062B0
		public string UserGuid
		{
			get
			{
				return (string)this.mBaseKey.GetValue("USER_GUID", "");
			}
			set
			{
				this.mBaseKey.SetValue("USER_GUID", value);
				this.mBaseKey.Flush();
			}
		}

		// Token: 0x1700024F RID: 591
		// (get) Token: 0x06000790 RID: 1936 RVA: 0x000080CE File Offset: 0x000062CE
		// (set) Token: 0x06000791 RID: 1937 RVA: 0x000080EA File Offset: 0x000062EA
		public string ApiToken
		{
			get
			{
				return (string)this.mBaseKey.GetValue("ApiToken", "");
			}
			set
			{
				this.mBaseKey.SetValue("ApiToken", value);
				this.mBaseKey.Flush();
			}
		}

		// Token: 0x17000250 RID: 592
		// (get) Token: 0x06000792 RID: 1938 RVA: 0x00008108 File Offset: 0x00006308
		// (set) Token: 0x06000793 RID: 1939 RVA: 0x00008124 File Offset: 0x00006324
		public string SystemGuid
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("SYSTEM_GUID", "");
			}
			set
			{
				this.mHostConfigKey.SetValue("SYSTEM_GUID", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000251 RID: 593
		// (get) Token: 0x06000794 RID: 1940 RVA: 0x00008142 File Offset: 0x00006342
		// (set) Token: 0x06000795 RID: 1941 RVA: 0x00008165 File Offset: 0x00006365
		public bool IsIncludeMachineGUID
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("IsIncludeMachineGUID", 1) == 1;
			}
			set
			{
				this.mHostConfigKey.SetValue("IsIncludeMachineGUID", value ? 1 : 0);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000252 RID: 594
		// (get) Token: 0x06000796 RID: 1942 RVA: 0x0000818E File Offset: 0x0000638E
		// (set) Token: 0x06000797 RID: 1943 RVA: 0x000081B1 File Offset: 0x000063B1
		public bool IsBTVCheckedAfterUpdate
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("IsBTVCheckedAfterUpdate", 0) == 1;
			}
			set
			{
				this.mHostConfigKey.SetValue("IsBTVCheckedAfterUpdate", value ? 1 : 0);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000253 RID: 595
		// (get) Token: 0x06000798 RID: 1944 RVA: 0x000081DA File Offset: 0x000063DA
		// (set) Token: 0x06000799 RID: 1945 RVA: 0x000081F6 File Offset: 0x000063F6
		public string CurrentBtvVersionInstalled
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("CurrentBtvVersionInstalled", "");
			}
			set
			{
				this.mHostConfigKey.SetValue("CurrentBtvVersionInstalled", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000254 RID: 596
		// (get) Token: 0x0600079A RID: 1946 RVA: 0x000203B8 File Offset: 0x0001E5B8
		public bool IsFirstTimeCheck
		{
			get
			{
				bool result = (int)this.mHostConfigKey.GetValue("IsFirstTimeCheck", 1) == 1;
				this.mHostConfigKey.SetValue("IsFirstTimeCheck", 0);
				this.mHostConfigKey.Flush();
				return result;
			}
		}

		// Token: 0x17000255 RID: 597
		// (get) Token: 0x0600079B RID: 1947 RVA: 0x00008214 File Offset: 0x00006414
		// (set) Token: 0x0600079C RID: 1948 RVA: 0x00008231 File Offset: 0x00006431
		public int SystemInfoStats2
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("SystemInfoStats2", 0);
			}
			set
			{
				this.mHostConfigKey.SetValue("SystemInfoStats2", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000256 RID: 598
		// (get) Token: 0x0600079D RID: 1949 RVA: 0x00008254 File Offset: 0x00006454
		// (set) Token: 0x0600079E RID: 1950 RVA: 0x00008271 File Offset: 0x00006471
		public int Features
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("Features", 0);
			}
			set
			{
				this.mHostConfigKey.SetValue("Features", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000257 RID: 599
		// (get) Token: 0x0600079F RID: 1951 RVA: 0x00008294 File Offset: 0x00006494
		// (set) Token: 0x060007A0 RID: 1952 RVA: 0x000082B1 File Offset: 0x000064B1
		public int FeaturesHigh
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("FeaturesHigh", 0);
			}
			set
			{
				this.mHostConfigKey.SetValue("FeaturesHigh", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000258 RID: 600
		// (get) Token: 0x060007A1 RID: 1953 RVA: 0x000082D4 File Offset: 0x000064D4
		// (set) Token: 0x060007A2 RID: 1954 RVA: 0x000082F1 File Offset: 0x000064F1
		public int SystemStats
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("SystemStats", 0);
			}
			set
			{
				this.mHostConfigKey.SetValue("SystemStats", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000259 RID: 601
		// (get) Token: 0x060007A3 RID: 1955 RVA: 0x00008314 File Offset: 0x00006514
		// (set) Token: 0x060007A4 RID: 1956 RVA: 0x00008331 File Offset: 0x00006531
		public int SendBotsCheckStats
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("SendBotsCheckStats", 0);
			}
			set
			{
				this.mHostConfigKey.SetValue("SendBotsCheckStats", 1);
			}
		}

		// Token: 0x1700025A RID: 602
		// (get) Token: 0x060007A5 RID: 1957 RVA: 0x00008349 File Offset: 0x00006549
		// (set) Token: 0x060007A6 RID: 1958 RVA: 0x00008365 File Offset: 0x00006565
		public string BotsCheckStatsTime
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("BotsCheckStatsTime", "");
			}
			set
			{
				this.mHostConfigKey.SetValue("BotsCheckStatsTime", value);
			}
		}

		// Token: 0x1700025B RID: 603
		// (get) Token: 0x060007A7 RID: 1959 RVA: 0x00020408 File Offset: 0x0001E608
		// (set) Token: 0x060007A8 RID: 1960 RVA: 0x00008378 File Offset: 0x00006578
		public string Host
		{
			get
			{
				if (string.IsNullOrEmpty(this.mHost))
				{
					string value = (string)this.mHostConfigKey.GetValue("Host", "https://cloud.bluestacks.com");
					if (string.IsNullOrEmpty(value))
					{
						value = "https://cloud.bluestacks.com";
					}
					this.mHost = value;
				}
				return this.mHost;
			}
			set
			{
				this.mHostConfigKey.SetValue("Host", value);
				this.mHostConfigKey.Flush();
				this.mHost = value;
			}
		}

		// Token: 0x1700025C RID: 604
		// (get) Token: 0x060007A9 RID: 1961 RVA: 0x0000839D File Offset: 0x0000659D
		// (set) Token: 0x060007AA RID: 1962 RVA: 0x000083B9 File Offset: 0x000065B9
		public string Host2
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("Host2", "https://23.23.194.123");
			}
			set
			{
				this.mHostConfigKey.SetValue("Host2", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x1700025D RID: 605
		// (get) Token: 0x060007AB RID: 1963 RVA: 0x000083D7 File Offset: 0x000065D7
		// (set) Token: 0x060007AC RID: 1964 RVA: 0x000083F3 File Offset: 0x000065F3
		public string RedDotShownOnIcon
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("RedDotShownOnIcon", "");
			}
			set
			{
				this.mHostConfigKey.SetValue("RedDotShownOnIcon", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x1700025E RID: 606
		// (get) Token: 0x060007AD RID: 1965 RVA: 0x00008411 File Offset: 0x00006611
		// (set) Token: 0x060007AE RID: 1966 RVA: 0x0000842D File Offset: 0x0000662D
		public string TwitchServerPath
		{
			get
			{
				return (string)this.mBTVKey.GetValue("TwitchServerPath", "");
			}
			set
			{
				this.mBTVKey.SetValue("TwitchServerPath", value);
				this.mBTVKey.Flush();
			}
		}

		// Token: 0x1700025F RID: 607
		// (get) Token: 0x060007AF RID: 1967 RVA: 0x0000844B File Offset: 0x0000664B
		// (set) Token: 0x060007B0 RID: 1968 RVA: 0x0000846C File Offset: 0x0000666C
		public int CLRBrowserServerPort
		{
			get
			{
				return (int)this.mBTVKey.GetValue("CLRBrowserServerPort", 2911);
			}
			set
			{
				this.mBTVKey.SetValue("CLRBrowserServerPort", value);
				this.mBTVKey.Flush();
			}
		}

		// Token: 0x17000260 RID: 608
		// (get) Token: 0x060007B1 RID: 1969 RVA: 0x0000848F File Offset: 0x0000668F
		// (set) Token: 0x060007B2 RID: 1970 RVA: 0x000084AB File Offset: 0x000066AB
		public string BtvDevServer
		{
			get
			{
				return (string)this.mBTVKey.GetValue("BtvDevServer", "");
			}
			set
			{
				this.mBTVKey.SetValue("BtvDevServer", value);
				this.mBTVKey.Flush();
			}
		}

		// Token: 0x17000261 RID: 609
		// (get) Token: 0x060007B3 RID: 1971 RVA: 0x000084C9 File Offset: 0x000066C9
		// (set) Token: 0x060007B4 RID: 1972 RVA: 0x000084E5 File Offset: 0x000066E5
		public string BtvNetwork
		{
			get
			{
				return (string)this.mBTVKey.GetValue("Network", "");
			}
			set
			{
				this.mBTVKey.SetValue("Network", value);
				this.mBTVKey.Flush();
			}
		}

		// Token: 0x17000262 RID: 610
		// (get) Token: 0x060007B5 RID: 1973 RVA: 0x00008503 File Offset: 0x00006703
		// (set) Token: 0x060007B6 RID: 1974 RVA: 0x00008520 File Offset: 0x00006720
		public int StreamingResolution
		{
			get
			{
				return (int)this.mBTVKey.GetValue("StreamingResolution", 0);
			}
			set
			{
				this.mBTVKey.SetValue("StreamingResolution", value);
				this.mBTVKey.Flush();
			}
		}

		// Token: 0x17000263 RID: 611
		// (get) Token: 0x060007B7 RID: 1975 RVA: 0x00008543 File Offset: 0x00006743
		// (set) Token: 0x060007B8 RID: 1976 RVA: 0x0000855F File Offset: 0x0000675F
		public string SelectedCam
		{
			get
			{
				return (string)this.mBTVKey.GetValue("SelectedCam", string.Empty);
			}
			set
			{
				this.mBTVKey.SetValue("SelectedCam", value);
				this.mBTVKey.Flush();
			}
		}

		// Token: 0x17000264 RID: 612
		// (get) Token: 0x060007B9 RID: 1977 RVA: 0x0000857D File Offset: 0x0000677D
		// (set) Token: 0x060007BA RID: 1978 RVA: 0x0000859A File Offset: 0x0000679A
		public int ReplayBufferEnabled
		{
			get
			{
				return (int)this.mBTVKey.GetValue("ReplayBufferEnabled", 0);
			}
			set
			{
				this.mBTVKey.SetValue("ReplayBufferEnabled", value);
				this.mBTVKey.Flush();
			}
		}

		// Token: 0x17000265 RID: 613
		// (get) Token: 0x060007BB RID: 1979 RVA: 0x000085BD File Offset: 0x000067BD
		// (set) Token: 0x060007BC RID: 1980 RVA: 0x000085DE File Offset: 0x000067DE
		public int BTVServerPort
		{
			get
			{
				return (int)this.mBTVKey.GetValue("BTVServerPort", 2885);
			}
			set
			{
				this.mBTVKey.SetValue("BTVServerPort", value);
				this.mBTVKey.Flush();
			}
		}

		// Token: 0x17000266 RID: 614
		// (get) Token: 0x060007BD RID: 1981 RVA: 0x00008601 File Offset: 0x00006801
		// (set) Token: 0x060007BE RID: 1982 RVA: 0x0000861E File Offset: 0x0000681E
		public int AppViewLayout
		{
			get
			{
				return (int)this.mBTVKey.GetValue("AppViewLayout", 0);
			}
			set
			{
				this.mBTVKey.SetValue("AppViewLayout", value);
				this.mBTVKey.Flush();
			}
		}

		// Token: 0x17000267 RID: 615
		// (get) Token: 0x060007BF RID: 1983 RVA: 0x00008641 File Offset: 0x00006841
		public string FilterUrl
		{
			get
			{
				return (string)this.mBTVKey.GetValue("FilterUrl", "");
			}
		}

		// Token: 0x17000268 RID: 616
		// (get) Token: 0x060007C0 RID: 1984 RVA: 0x0000865D File Offset: 0x0000685D
		public string LayoutUrl
		{
			get
			{
				return (string)this.mBTVKey.GetValue("LayoutUrl", "");
			}
		}

		// Token: 0x17000269 RID: 617
		// (get) Token: 0x060007C1 RID: 1985 RVA: 0x00008679 File Offset: 0x00006879
		// (set) Token: 0x060007C2 RID: 1986 RVA: 0x00008695 File Offset: 0x00006895
		public string LayoutTheme
		{
			get
			{
				return (string)this.mBTVKey.GetValue("LayoutTheme", "");
			}
			set
			{
				this.mBTVKey.SetValue("LayoutTheme", value);
				this.mBTVKey.Flush();
			}
		}

		// Token: 0x1700026A RID: 618
		// (get) Token: 0x060007C3 RID: 1987 RVA: 0x000086B3 File Offset: 0x000068B3
		// (set) Token: 0x060007C4 RID: 1988 RVA: 0x000086CF File Offset: 0x000068CF
		public string LastCameraLayoutTheme
		{
			get
			{
				return (string)this.mBTVKey.GetValue("LastCameraLayoutTheme", "");
			}
			set
			{
				this.mBTVKey.SetValue("LastCameraLayoutTheme", value);
				this.mBTVKey.Flush();
			}
		}

		// Token: 0x1700026B RID: 619
		// (get) Token: 0x060007C5 RID: 1989 RVA: 0x000086ED File Offset: 0x000068ED
		// (set) Token: 0x060007C6 RID: 1990 RVA: 0x0000870A File Offset: 0x0000690A
		public int ScreenWidth
		{
			get
			{
				return (int)this.mBTVKey.GetValue("ScreenWidth", 0);
			}
			set
			{
				this.mBTVKey.SetValue("ScreenWidth", value);
				this.mBTVKey.Flush();
			}
		}

		// Token: 0x1700026C RID: 620
		// (get) Token: 0x060007C7 RID: 1991 RVA: 0x0000872D File Offset: 0x0000692D
		// (set) Token: 0x060007C8 RID: 1992 RVA: 0x0000874A File Offset: 0x0000694A
		public int ScreenHeight
		{
			get
			{
				return (int)this.mBTVKey.GetValue("ScreenHeight", 0);
			}
			set
			{
				this.mBTVKey.SetValue("ScreenHeight", value);
				this.mBTVKey.Flush();
			}
		}

		// Token: 0x1700026D RID: 621
		// (get) Token: 0x060007C9 RID: 1993 RVA: 0x0000876D File Offset: 0x0000696D
		public bool IsImeDebuggingEnabled
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("IsImeDebuggingEnabled", 0) == 1;
			}
		}

		// Token: 0x1700026E RID: 622
		// (get) Token: 0x060007CA RID: 1994 RVA: 0x00008790 File Offset: 0x00006990
		// (set) Token: 0x060007CB RID: 1995 RVA: 0x000087B1 File Offset: 0x000069B1
		public int OBSServerPort
		{
			get
			{
				return (int)this.mBTVKey.GetValue("OBSServerPort", 2851);
			}
			set
			{
				this.mBTVKey.SetValue("OBSServerPort", value);
				this.mBTVKey.Flush();
			}
		}

		// Token: 0x1700026F RID: 623
		// (get) Token: 0x060007CC RID: 1996 RVA: 0x000087D4 File Offset: 0x000069D4
		// (set) Token: 0x060007CD RID: 1997 RVA: 0x000087F6 File Offset: 0x000069F6
		public bool IsGameCaptureSupportedInMachine
		{
			get
			{
				return (int)this.mBTVKey.GetValue("IsGameCaptureSupportedInMachine", 1) != 0;
			}
			set
			{
				this.mBTVKey.SetValue("IsGameCaptureSupportedInMachine", (!value) ? 0 : 1);
				this.mBTVKey.Flush();
			}
		}

		// Token: 0x17000270 RID: 624
		// (get) Token: 0x060007CE RID: 1998 RVA: 0x0000881F File Offset: 0x00006A1F
		// (set) Token: 0x060007CF RID: 1999 RVA: 0x0000883B File Offset: 0x00006A3B
		public string StreamName
		{
			get
			{
				return (string)this.mBTVKey.GetValue("StreamName", "");
			}
			set
			{
				this.mBTVKey.SetValue("StreamName", value);
				this.mBTVKey.Flush();
			}
		}

		// Token: 0x17000271 RID: 625
		// (get) Token: 0x060007D0 RID: 2000 RVA: 0x00008859 File Offset: 0x00006A59
		// (set) Token: 0x060007D1 RID: 2001 RVA: 0x00008875 File Offset: 0x00006A75
		public string ServerLocation
		{
			get
			{
				return (string)this.mBTVKey.GetValue("ServerLocation", "");
			}
			set
			{
				this.mBTVKey.SetValue("ServerLocation", value);
				this.mBTVKey.Flush();
			}
		}

		// Token: 0x17000272 RID: 626
		// (get) Token: 0x060007D2 RID: 2002 RVA: 0x00008893 File Offset: 0x00006A93
		// (set) Token: 0x060007D3 RID: 2003 RVA: 0x000088AF File Offset: 0x00006AAF
		public string ChannelName
		{
			get
			{
				return (string)this.mBTVFilterKey.GetValue("ChannelName", "");
			}
			set
			{
				this.mBTVFilterKey.SetValue("ChannelName", value);
				this.mBTVFilterKey.Flush();
			}
		}

		// Token: 0x17000273 RID: 627
		// (get) Token: 0x060007D4 RID: 2004 RVA: 0x000088CD File Offset: 0x00006ACD
		// (set) Token: 0x060007D5 RID: 2005 RVA: 0x000088E9 File Offset: 0x00006AE9
		public string NotificationData
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("NotificationData", string.Empty);
			}
			set
			{
				this.mHostConfigKey.SetValue("NotificationData", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000274 RID: 628
		// (get) Token: 0x060007D6 RID: 2006 RVA: 0x00008907 File Offset: 0x00006B07
		// (set) Token: 0x060007D7 RID: 2007 RVA: 0x00008923 File Offset: 0x00006B23
		public string DeviceCaps
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("DeviceCaps", "");
			}
			set
			{
				this.mHostConfigKey.SetValue("DeviceCaps", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000275 RID: 629
		// (get) Token: 0x060007D8 RID: 2008 RVA: 0x00008941 File Offset: 0x00006B41
		// (set) Token: 0x060007D9 RID: 2009 RVA: 0x00008962 File Offset: 0x00006B62
		public int AgentServerPort
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("AgentServerPort", 2861);
			}
			set
			{
				this.mHostConfigKey.SetValue("AgentServerPort", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000276 RID: 630
		// (get) Token: 0x060007DA RID: 2010 RVA: 0x00008985 File Offset: 0x00006B85
		// (set) Token: 0x060007DB RID: 2011 RVA: 0x000089A1 File Offset: 0x00006BA1
		public string Oem
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("Oem", "gamemanager");
			}
			set
			{
				this.mHostConfigKey.SetValue("Oem", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000277 RID: 631
		// (get) Token: 0x060007DC RID: 2012 RVA: 0x000089BF File Offset: 0x00006BBF
		// (set) Token: 0x060007DD RID: 2013 RVA: 0x000089DC File Offset: 0x00006BDC
		public int BatchInstanceStartInterval
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("BatchInstanceStartInterval", 2);
			}
			set
			{
				this.mHostConfigKey.SetValue("BatchInstanceStartInterval", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000278 RID: 632
		// (get) Token: 0x060007DE RID: 2014 RVA: 0x000089FF File Offset: 0x00006BFF
		// (set) Token: 0x060007DF RID: 2015 RVA: 0x00008A1B File Offset: 0x00006C1B
		public string CampaignName
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("CampaignName", "");
			}
			set
			{
				this.mHostConfigKey.SetValue("CampaignName", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000279 RID: 633
		// (get) Token: 0x060007E0 RID: 2016 RVA: 0x00008A39 File Offset: 0x00006C39
		// (set) Token: 0x060007E1 RID: 2017 RVA: 0x00008A55 File Offset: 0x00006C55
		public string PartnerExePath
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("PartnerExePath", "");
			}
			set
			{
				this.mHostConfigKey.SetValue("PartnerExePath", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x1700027A RID: 634
		// (get) Token: 0x060007E2 RID: 2018 RVA: 0x00008A73 File Offset: 0x00006C73
		// (set) Token: 0x060007E3 RID: 2019 RVA: 0x00008A90 File Offset: 0x00006C90
		public int CamStatus
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("CamStatus", 0);
			}
			set
			{
				this.mHostConfigKey.SetValue("CamStatus", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x1700027B RID: 635
		// (get) Token: 0x060007E4 RID: 2020 RVA: 0x00008AB3 File Offset: 0x00006CB3
		// (set) Token: 0x060007E5 RID: 2021 RVA: 0x00008AD4 File Offset: 0x00006CD4
		public int PartnerServerPort
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("PartnerServerPort", 2871);
			}
			set
			{
				this.mHostConfigKey.SetValue("PartnerServerPort", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x1700027C RID: 636
		// (get) Token: 0x060007E6 RID: 2022 RVA: 0x00008AF7 File Offset: 0x00006CF7
		// (set) Token: 0x060007E7 RID: 2023 RVA: 0x00008B13 File Offset: 0x00006D13
		public string RegisteredEmail
		{
			get
			{
				return (string)this.mUserKey.GetValue("RegisteredEmail", "");
			}
			set
			{
				this.mUserKey.SetValue("RegisteredEmail", value);
				this.mUserKey.Flush();
			}
		}

		// Token: 0x1700027D RID: 637
		// (get) Token: 0x060007E8 RID: 2024 RVA: 0x00008B31 File Offset: 0x00006D31
		// (set) Token: 0x060007E9 RID: 2025 RVA: 0x00008B53 File Offset: 0x00006D53
		public bool IsTimelineStats4Enabled
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("IsTimelineStats4Enabled", 0) != 0;
			}
			set
			{
				this.mHostConfigKey.SetValue("IsTimelineStats4Enabled", (!value) ? 0 : 1);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x1700027E RID: 638
		// (get) Token: 0x060007EA RID: 2026 RVA: 0x00008B7C File Offset: 0x00006D7C
		// (set) Token: 0x060007EB RID: 2027 RVA: 0x00008B98 File Offset: 0x00006D98
		public string PikaWorldId
		{
			get
			{
				return (string)this.mUserKey.GetValue("PikaWorldId", "");
			}
			set
			{
				this.mUserKey.SetValue("PikaWorldId", value);
				this.mUserKey.Flush();
			}
		}

		// Token: 0x1700027F RID: 639
		// (get) Token: 0x060007EC RID: 2028 RVA: 0x00008BB6 File Offset: 0x00006DB6
		// (set) Token: 0x060007ED RID: 2029 RVA: 0x00008BD2 File Offset: 0x00006DD2
		public string Token
		{
			get
			{
				return (string)this.mUserKey.GetValue("Token", "");
			}
			set
			{
				this.mUserKey.SetValue("Token", value);
				this.mUserKey.Flush();
			}
		}

		// Token: 0x17000280 RID: 640
		// (get) Token: 0x060007EE RID: 2030 RVA: 0x00008BF0 File Offset: 0x00006DF0
		// (set) Token: 0x060007EF RID: 2031 RVA: 0x00008C13 File Offset: 0x00006E13
		public bool IsPremium
		{
			get
			{
				return (int)this.mUserKey.GetValue("IsPremium", 0) == 1;
			}
			set
			{
				this.mUserKey.SetValue("IsPremium", value ? 1 : 0);
				this.mUserKey.Flush();
			}
		}

		// Token: 0x17000281 RID: 641
		// (get) Token: 0x060007F0 RID: 2032 RVA: 0x00008C3C File Offset: 0x00006E3C
		// (set) Token: 0x060007F1 RID: 2033 RVA: 0x00008C5E File Offset: 0x00006E5E
		public bool AddDesktopShortcuts
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("AddDesktopShortcuts", 1) != 0;
			}
			set
			{
				this.mHostConfigKey.SetValue("AddDesktopShortcuts", (!value) ? 0 : 1);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000282 RID: 642
		// (get) Token: 0x060007F2 RID: 2034 RVA: 0x00008C87 File Offset: 0x00006E87
		// (set) Token: 0x060007F3 RID: 2035 RVA: 0x00008CA9 File Offset: 0x00006EA9
		public bool SwitchToAndroidHome
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("SwitchToAndroidHome", 0) != 0;
			}
			set
			{
				this.mHostConfigKey.SetValue("SwitchToAndroidHome", (!value) ? 0 : 1);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000283 RID: 643
		// (get) Token: 0x060007F4 RID: 2036 RVA: 0x00008CD2 File Offset: 0x00006ED2
		// (set) Token: 0x060007F5 RID: 2037 RVA: 0x00008CF4 File Offset: 0x00006EF4
		public bool SwitchKillWebTab
		{
			get
			{
				return (int)this.mClientKey.GetValue("SwitchKillWebTab", 1) != 0;
			}
			set
			{
				this.mClientKey.SetValue("SwitchKillWebTab", (!value) ? 0 : 1);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000284 RID: 644
		// (get) Token: 0x060007F6 RID: 2038 RVA: 0x00008D1D File Offset: 0x00006F1D
		// (set) Token: 0x060007F7 RID: 2039 RVA: 0x00008D3F File Offset: 0x00006F3F
		public bool GLES3
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("GLES3", 0) != 0;
			}
			set
			{
				this.mHostConfigKey.SetValue("GLES3", (!value) ? 0 : 1);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000285 RID: 645
		// (get) Token: 0x060007F8 RID: 2040 RVA: 0x00008D68 File Offset: 0x00006F68
		// (set) Token: 0x060007F9 RID: 2041 RVA: 0x00008D8A File Offset: 0x00006F8A
		public bool IsAutoShowGuidance
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("IsAutoShowGuidance", 1) != 0;
			}
			set
			{
				this.mHostConfigKey.SetValue("IsAutoShowGuidance", (!value) ? 0 : 1);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000286 RID: 646
		// (get) Token: 0x060007FA RID: 2042 RVA: 0x00008DB3 File Offset: 0x00006FB3
		// (set) Token: 0x060007FB RID: 2043 RVA: 0x00008DCF File Offset: 0x00006FCF
		public string InstallID
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("InstallID", string.Empty);
			}
			set
			{
				this.mHostConfigKey.SetValue("InstallID", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000287 RID: 647
		// (get) Token: 0x060007FC RID: 2044 RVA: 0x00008DED File Offset: 0x00006FED
		// (set) Token: 0x060007FD RID: 2045 RVA: 0x00008E09 File Offset: 0x00007009
		public string OldInstallID
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("OldInstallID", string.Empty);
			}
			set
			{
				this.mHostConfigKey.SetValue("OldInstallID", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000288 RID: 648
		// (get) Token: 0x060007FE RID: 2046 RVA: 0x00008E27 File Offset: 0x00007027
		// (set) Token: 0x060007FF RID: 2047 RVA: 0x00008E43 File Offset: 0x00007043
		public string ProposedGUID
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("ProposedGUID", string.Empty);
			}
			set
			{
				this.mHostConfigKey.SetValue("ProposedGUID", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000289 RID: 649
		// (get) Token: 0x06000800 RID: 2048 RVA: 0x00008E61 File Offset: 0x00007061
		// (set) Token: 0x06000801 RID: 2049 RVA: 0x00008E7D File Offset: 0x0000707D
		public string Base64GuidString
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("Base64GuidString", string.Empty);
			}
			set
			{
				this.mHostConfigKey.SetValue("Base64GuidString", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x1700028A RID: 650
		// (get) Token: 0x06000802 RID: 2050 RVA: 0x00008E9B File Offset: 0x0000709B
		// (set) Token: 0x06000803 RID: 2051 RVA: 0x00008EB7 File Offset: 0x000070B7
		public string HelperVersion
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("HelperVersion", string.Empty);
			}
			set
			{
				this.mHostConfigKey.SetValue("HelperVersion", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x1700028B RID: 651
		// (get) Token: 0x06000804 RID: 2052 RVA: 0x00008ED5 File Offset: 0x000070D5
		// (set) Token: 0x06000805 RID: 2053 RVA: 0x00008EF1 File Offset: 0x000070F1
		public string InstallerPkgName
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("InstallerPkgName", string.Empty);
			}
			set
			{
				this.mHostConfigKey.SetValue("InstallerPkgName", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x1700028C RID: 652
		// (get) Token: 0x06000806 RID: 2054 RVA: 0x00020458 File Offset: 0x0001E658
		// (set) Token: 0x06000807 RID: 2055 RVA: 0x00008F0F File Offset: 0x0000710F
		public InstallationTypes InstallationType
		{
			get
			{
				if (this.mInstallationType == InstallationTypes.None)
				{
					this.mInstallationType = (InstallationTypes)Enum.Parse(typeof(InstallationTypes), (string)this.mHostConfigKey.GetValue("InstallationType", InstallationTypes.FullEdition.ToString()), true);
				}
				return this.mInstallationType;
			}
			set
			{
				this.mHostConfigKey.SetValue("InstallationType", value);
				this.mHostConfigKey.Flush();
				this.mInstallationType = value;
			}
		}

		// Token: 0x1700028D RID: 653
		// (get) Token: 0x06000808 RID: 2056 RVA: 0x00008F39 File Offset: 0x00007139
		// (set) Token: 0x06000809 RID: 2057 RVA: 0x00008F55 File Offset: 0x00007155
		public string CurrentFirebaseHost
		{
			get
			{
				return (string)this.mClientKey.GetValue("CurrentFirebaseHost", string.Empty);
			}
			set
			{
				this.mClientKey.SetValue("CurrentFirebaseHost", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700028E RID: 654
		// (get) Token: 0x0600080A RID: 2058 RVA: 0x00008F73 File Offset: 0x00007173
		// (set) Token: 0x0600080B RID: 2059 RVA: 0x00008FA3 File Offset: 0x000071A3
		public string PendingLaunchAction
		{
			get
			{
				return (string)this.mClientKey.GetValue("PendingLaunchAction", string.Format("{0},{1}", GenericAction.None, string.Empty));
			}
			set
			{
				this.mClientKey.SetValue("PendingLaunchAction", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x1700028F RID: 655
		// (get) Token: 0x0600080C RID: 2060 RVA: 0x000204B4 File Offset: 0x0001E6B4
		// (set) Token: 0x0600080D RID: 2061 RVA: 0x00020514 File Offset: 0x0001E714
		public DateTime AnnouncementTime
		{
			get
			{
				string text = (string)this.mHostConfigKey.GetValue("AnnouncementTime", string.Empty);
				DateTime result = DateTime.Now;
				try
				{
					if (!string.IsNullOrEmpty(text))
					{
						result = DateTime.ParseExact(text, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
					}
				}
				catch
				{
				}
				return result;
			}
			set
			{
				string value2 = value.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
				this.mHostConfigKey.SetValue("AnnouncementTime", value2);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000290 RID: 656
		// (get) Token: 0x0600080E RID: 2062 RVA: 0x00008FC1 File Offset: 0x000071C1
		// (set) Token: 0x0600080F RID: 2063 RVA: 0x00008FDD File Offset: 0x000071DD
		public string RootVdiMd5Hash
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("RootVdiMd5Hash", string.Empty);
			}
			set
			{
				this.mHostConfigKey.SetValue("RootVdiMd5Hash", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000291 RID: 657
		// (get) Token: 0x06000810 RID: 2064 RVA: 0x00008FFB File Offset: 0x000071FB
		// (set) Token: 0x06000811 RID: 2065 RVA: 0x00009017 File Offset: 0x00007217
		public string Geo
		{
			get
			{
				return (string)this.mClientKey.GetValue("Geo", "");
			}
			set
			{
				this.mClientKey.SetValue("Geo", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000292 RID: 658
		// (get) Token: 0x06000812 RID: 2066 RVA: 0x00009035 File Offset: 0x00007235
		// (set) Token: 0x06000813 RID: 2067 RVA: 0x00009051 File Offset: 0x00007251
		public string QuitDefaultOption
		{
			get
			{
				return (string)this.mClientKey.GetValue("QuitDefaultOption", "STRING_CLOSE_CURRENT_INSTANCE");
			}
			set
			{
				this.mClientKey.SetValue("QuitDefaultOption", value);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000293 RID: 659
		// (get) Token: 0x06000814 RID: 2068 RVA: 0x0000906F File Offset: 0x0000726F
		// (set) Token: 0x06000815 RID: 2069 RVA: 0x00009091 File Offset: 0x00007291
		public bool IsQuitOptionSaved
		{
			get
			{
				return (int)this.mClientKey.GetValue("QuitOptionSaved", 0) != 0;
			}
			set
			{
				this.mClientKey.SetValue("QuitOptionSaved", (!value) ? 0 : 1);
				this.mClientKey.Flush();
			}
		}

		// Token: 0x17000294 RID: 660
		// (get) Token: 0x06000816 RID: 2070 RVA: 0x000090BA File Offset: 0x000072BA
		// (set) Token: 0x06000817 RID: 2071 RVA: 0x000090E5 File Offset: 0x000072E5
		public int VmId
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("VmId", Utils.GetMaxVmIdFromVmList(RegistryManager.Instance.VmList));
			}
			set
			{
				this.mHostConfigKey.SetValue("VmId", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000295 RID: 661
		// (get) Token: 0x06000818 RID: 2072 RVA: 0x00009108 File Offset: 0x00007308
		// (set) Token: 0x06000819 RID: 2073 RVA: 0x00009125 File Offset: 0x00007325
		public string[] BookmarkedScriptList
		{
			get
			{
				return (string[])this.mHostConfigKey.GetValue("BookmarkedScriptList", new string[0]);
			}
			set
			{
				this.mHostConfigKey.SetValue("BookmarkedScriptList", value, RegistryValueKind.MultiString);
			}
		}

		// Token: 0x17000296 RID: 662
		// (get) Token: 0x0600081A RID: 2074 RVA: 0x00009139 File Offset: 0x00007339
		// (set) Token: 0x0600081B RID: 2075 RVA: 0x0000915B File Offset: 0x0000735B
		public bool CurrentFarmModeStatus
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("CurrentFarmModeStatus", 0) != 0;
			}
			set
			{
				this.mHostConfigKey.SetValue("CurrentFarmModeStatus", (!value) ? 0 : 1);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000297 RID: 663
		// (get) Token: 0x0600081C RID: 2076 RVA: 0x00009184 File Offset: 0x00007384
		// (set) Token: 0x0600081D RID: 2077 RVA: 0x000091A0 File Offset: 0x000073A0
		public string DefaultShortcuts
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("DefaultShortcuts", "");
			}
			set
			{
				this.mHostConfigKey.SetValue("DefaultShortcuts", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000298 RID: 664
		// (get) Token: 0x0600081E RID: 2078 RVA: 0x000091BE File Offset: 0x000073BE
		// (set) Token: 0x0600081F RID: 2079 RVA: 0x000091DA File Offset: 0x000073DA
		public string UserDefinedShortcuts
		{
			get
			{
				return (string)this.mHostConfigKey.GetValue("UserDefinedShortcuts", "");
			}
			set
			{
				this.mHostConfigKey.SetValue("UserDefinedShortcuts", value);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x17000299 RID: 665
		// (get) Token: 0x06000820 RID: 2080 RVA: 0x000091F8 File Offset: 0x000073F8
		// (set) Token: 0x06000821 RID: 2081 RVA: 0x0000921A File Offset: 0x0000741A
		public bool AreAllInstancesMuted
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("AreAllInstancesMuted", 0) != 0;
			}
			set
			{
				this.mHostConfigKey.SetValue("AreAllInstancesMuted", (!value) ? 0 : 1);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x1700029A RID: 666
		// (get) Token: 0x06000822 RID: 2082 RVA: 0x00009243 File Offset: 0x00007443
		// (set) Token: 0x06000823 RID: 2083 RVA: 0x00009265 File Offset: 0x00007465
		public bool IsSamsungStorePresent
		{
			get
			{
				return (int)this.mHostConfigKey.GetValue("IsSamsungStorePresent", 0) != 0;
			}
			set
			{
				this.mHostConfigKey.SetValue("IsSamsungStorePresent", (!value) ? 0 : 1);
				this.mHostConfigKey.Flush();
			}
		}

		// Token: 0x040005C9 RID: 1481
		private static string mUPGRADE_TAG = string.Empty;

		// Token: 0x040005CA RID: 1482
		public const string UPGRADE_TAG_NEW = ".new";

		// Token: 0x040005CB RID: 1483
		private RegistryKey mBaseKey;

		// Token: 0x040005CC RID: 1484
		private RegistryKey mClientKey;

		// Token: 0x040005CD RID: 1485
		private RegistryKey mBTVKey;

		// Token: 0x040005CE RID: 1486
		private RegistryKey mBTVFilterKey;

		// Token: 0x040005CF RID: 1487
		private RegistryKey mUserKey;

		// Token: 0x040005D0 RID: 1488
		private RegistryKey mHostConfigKey;

		// Token: 0x040005D1 RID: 1489
		private RegistryKey mGuestsKey;

		// Token: 0x040005D2 RID: 1490
		private RegistryKey mMonitorsKey;

		// Token: 0x040005D3 RID: 1491
		private string mBaseKeyPath = "";

		// Token: 0x040005D4 RID: 1492
		private string mBTVKeyPath = "";

		// Token: 0x040005D5 RID: 1493
		private string mClientBaseKeyPath = "";

		// Token: 0x040005D6 RID: 1494
		private string mHostConfigKeyPath = "";

		// Token: 0x040005D7 RID: 1495
		private bool mIsAdmin;

		// Token: 0x040005D8 RID: 1496
		private static RegistryManager sInstance = null;

		// Token: 0x040005D9 RID: 1497
		private static object sLock = new object();

		// Token: 0x040005DA RID: 1498
		private Dictionary<string, InstanceRegistry> mGuest = new Dictionary<string, InstanceRegistry>();

		// Token: 0x040005DB RID: 1499
		public string mThemeName = string.Empty;

		// Token: 0x040005DC RID: 1500
		private string sCurrentEngine = "";

		// Token: 0x040005DD RID: 1501
		private string sUserDefinedDir;

		// Token: 0x040005DE RID: 1502
		private string sVersion;

		// Token: 0x040005DF RID: 1503
		private string mHost = string.Empty;

		// Token: 0x040005E0 RID: 1504
		private InstallationTypes mInstallationType;
	}
}
