﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200008A RID: 138
	public class Tasks
	{
		// Token: 0x0200008B RID: 139
		public enum Parameter
		{
			// Token: 0x04000338 RID: 824
			Create,
			// Token: 0x04000339 RID: 825
			Delete,
			// Token: 0x0400033A RID: 826
			Query,
			// Token: 0x0400033B RID: 827
			Run,
			// Token: 0x0400033C RID: 828
			End
		}

		// Token: 0x0200008C RID: 140
		public enum Frequency
		{
			// Token: 0x0400033E RID: 830
			MINUTE,
			// Token: 0x0400033F RID: 831
			HOURLY,
			// Token: 0x04000340 RID: 832
			DAILY,
			// Token: 0x04000341 RID: 833
			WEEKLY,
			// Token: 0x04000342 RID: 834
			MONTHLY,
			// Token: 0x04000343 RID: 835
			ONCE,
			// Token: 0x04000344 RID: 836
			ONSTART,
			// Token: 0x04000345 RID: 837
			ONLOGON,
			// Token: 0x04000346 RID: 838
			ONIDLE,
			// Token: 0x04000347 RID: 839
			ONEVENT
		}

		// Token: 0x0200008D RID: 141
		public enum Modifiers
		{
			// Token: 0x04000349 RID: 841
			MON,
			// Token: 0x0400034A RID: 842
			TUE,
			// Token: 0x0400034B RID: 843
			WED,
			// Token: 0x0400034C RID: 844
			THU,
			// Token: 0x0400034D RID: 845
			FRI,
			// Token: 0x0400034E RID: 846
			SAT,
			// Token: 0x0400034F RID: 847
			SUN
		}

		// Token: 0x0200008E RID: 142
		public enum Days
		{
			// Token: 0x04000351 RID: 849
			MON,
			// Token: 0x04000352 RID: 850
			TUE,
			// Token: 0x04000353 RID: 851
			WED,
			// Token: 0x04000354 RID: 852
			THU,
			// Token: 0x04000355 RID: 853
			FRI,
			// Token: 0x04000356 RID: 854
			SAT,
			// Token: 0x04000357 RID: 855
			SUN
		}
	}
}
