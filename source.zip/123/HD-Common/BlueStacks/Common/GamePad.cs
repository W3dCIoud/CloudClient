﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000CD RID: 205
	public struct GamePad
	{
		// Token: 0x04000502 RID: 1282
		public int X;

		// Token: 0x04000503 RID: 1283
		public int Y;

		// Token: 0x04000504 RID: 1284
		public int Z;

		// Token: 0x04000505 RID: 1285
		public int Rx;

		// Token: 0x04000506 RID: 1286
		public int Ry;

		// Token: 0x04000507 RID: 1287
		public int Rz;

		// Token: 0x04000508 RID: 1288
		public int Hat;

		// Token: 0x04000509 RID: 1289
		public uint Mask;
	}
}
