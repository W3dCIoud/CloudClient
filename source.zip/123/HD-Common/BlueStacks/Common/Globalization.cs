﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;

namespace BlueStacks.Common
{
	// Token: 0x02000166 RID: 358
	public class Globalization
	{
		// Token: 0x06000BAE RID: 2990 RVA: 0x00032508 File Offset: 0x00030708
		public static Dictionary<string, string> InitLocalization(string resourceLocation = null)
		{
			if (string.IsNullOrEmpty(resourceLocation))
			{
				Globalization.sResourceLocation = Path.Combine(Globalization.sUserDefinedDir, "Locales");
			}
			else
			{
				Globalization.sResourceLocation = resourceLocation;
			}
			Globalization.sLocalizedStringsDict = new Dictionary<string, string>(StringComparer.InvariantCultureIgnoreCase);
			Globalization.sLocale = Globalization.GetCurrentCultureSupportedLocaleName();
			if (Globalization.PopulateLocaleStrings("en-US"))
			{
				Logger.Info("Successfully populated {0} strings", new object[]
				{
					"en-US"
				});
			}
			if (string.Compare(Globalization.sLocale, "en-US") != 0)
			{
				bool flag = Globalization.PopulateLocaleStrings(Globalization.sLocale);
				Logger.Info("Populated strings for {0}: {1}", new object[]
				{
					Globalization.sLocale,
					flag
				});
			}
			return Globalization.sLocalizedStringsDict;
		}

		// Token: 0x06000BAF RID: 2991 RVA: 0x000325B8 File Offset: 0x000307B8
		private static string GetCurrentCultureSupportedLocaleName()
		{
			string text = Thread.CurrentThread.CurrentCulture.Name;
			if (!Globalization.sSupportedLocales.ContainsKey(text))
			{
				text = "en-US";
				string text2 = Globalization.sSupportedLocales.Keys.FirstOrDefault((string x) => x.StartsWith(Thread.CurrentThread.CurrentCulture.Parent.Name));
				if (!string.IsNullOrEmpty(text2))
				{
					text = text2;
				}
			}
			return text;
		}

		// Token: 0x06000BB0 RID: 2992 RVA: 0x00032624 File Offset: 0x00030824
		public static string GetLocalizedString(string id)
		{
			string result = id.Trim();
			try
			{
				if (Globalization.sLocalizedStringsDict == null)
				{
					Globalization.InitLocalization(null);
				}
				if (Globalization.sLocalizedStringsDict.ContainsKey(id.ToUpper()))
				{
					result = Globalization.sLocalizedStringsDict[id.ToUpper()];
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Localized string not available for: {0}. Ex: {1}", new object[]
				{
					id,
					ex.Message
				});
			}
			return result;
		}

		// Token: 0x06000BB1 RID: 2993 RVA: 0x0003269C File Offset: 0x0003089C
		private static bool PopulateLocaleStrings(string locale)
		{
			bool result;
			try
			{
				string localeFilePath = Globalization.GetLocaleFilePath(locale);
				if (!File.Exists(localeFilePath))
				{
					Logger.Info(string.Format("Localization file does not exist: {0}", localeFilePath));
					result = false;
				}
				else
				{
					Globalization.FillDictionary(localeFilePath);
					result = true;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Could not populate localized strings. Error: {0}", new object[]
				{
					ex
				});
				result = false;
			}
			return result;
		}

		// Token: 0x06000BB2 RID: 2994 RVA: 0x00032700 File Offset: 0x00030900
		private static string GetLocaleFilePath(string locale)
		{
			string path = string.Format("i18n.{0}.txt", locale);
			return Path.Combine(Globalization.sResourceLocation, path);
		}

		// Token: 0x06000BB3 RID: 2995 RVA: 0x00032724 File Offset: 0x00030924
		private static void FillDictionary(string filePath)
		{
			try
			{
				foreach (string text in File.ReadAllLines(filePath))
				{
					if (text.IndexOf("=") != -1)
					{
						string[] array2 = text.Split(new char[]
						{
							'='
						});
						string text2 = array2[1].Trim();
						if (text2.Contains("@@STRING_PRODUCT_NAME@@"))
						{
							text2 = text2.Replace("@@STRING_PRODUCT_NAME@@", Strings.ProductDisplayName);
						}
						text2 = text2.Replace("App Player App Player", "App Player");
						Globalization.sLocalizedStringsDict[array2[0].Trim().ToUpper()] = text2;
					}
				}
			}
			catch
			{
				throw;
			}
		}

		// Token: 0x0400080E RID: 2062
		public const string DEFAULT_LOCALE = "en-US";

		// Token: 0x0400080F RID: 2063
		public static string sLocale;

		// Token: 0x04000810 RID: 2064
		public static string sResourceLocation;

		// Token: 0x04000811 RID: 2065
		private static string sUserDefinedDir = (string)RegistryUtils.GetRegistryValue(Strings.RegistryBaseKeyPath, "UserDefinedDir", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);

		// Token: 0x04000812 RID: 2066
		public static Dictionary<string, string> sLocalizedStringsDict = null;

		// Token: 0x04000813 RID: 2067
		public static Dictionary<string, string> sSupportedLocales = new Dictionary<string, string>
		{
			{
				"en-US",
				new CultureInfo("en-US").NativeName
			},
			{
				"ar-EG",
				new CultureInfo("ar-EG").NativeName
			},
			{
				"de-DE",
				new CultureInfo("de-DE").NativeName
			},
			{
				"es-ES",
				new CultureInfo("es-ES").NativeName
			},
			{
				"fr-FR",
				new CultureInfo("fr-FR").NativeName
			},
			{
				"it-IT",
				new CultureInfo("it-IT").NativeName
			},
			{
				"ja-JP",
				new CultureInfo("ja-JP").NativeName
			},
			{
				"ko-KR",
				new CultureInfo("ko-KR").NativeName
			},
			{
				"pl-PL",
				new CultureInfo("pl-PL").NativeName
			},
			{
				"pt-BR",
				new CultureInfo("pt-BR").NativeName
			},
			{
				"ru-RU",
				new CultureInfo("ru-RU").NativeName
			},
			{
				"th-TH",
				new CultureInfo("th-TH").NativeName
			},
			{
				"tr-TR",
				new CultureInfo("tr-TR").NativeName
			},
			{
				"vi-VN",
				new CultureInfo("vi-VN").NativeName
			},
			{
				"zh-TW",
				new CultureInfo("zh-TW").NativeName
			}
		};
	}
}
