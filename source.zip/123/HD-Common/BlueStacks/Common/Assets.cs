﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000085 RID: 133
	public class Assets
	{
		// Token: 0x02000086 RID: 134
		public class Common
		{
			// Token: 0x0400030C RID: 780
			public const string CheckboxUnchecked = "bgpcheckbox";

			// Token: 0x0400030D RID: 781
			public const string CheckboxChecked = "bgpcheckbox_checked";
		}

		// Token: 0x02000087 RID: 135
		public class Topbar
		{
			// Token: 0x0400030E RID: 782
			public const string SidebarExpand = "sidebar_show";

			// Token: 0x0400030F RID: 783
			public const string SidebarCollapse = "sidebar_hide";
		}

		// Token: 0x02000088 RID: 136
		public class Sidebar
		{
			// Token: 0x04000310 RID: 784
			public const string Back = "sidebar_back";

			// Token: 0x04000311 RID: 785
			public const string Controls = "sidebar_controls";

			// Token: 0x04000312 RID: 786
			public const string Fullscreen = "sidebar_fullscreen";

			// Token: 0x04000313 RID: 787
			public const string FullscreenMinimize = "sidebar_fullscreen_minimize";

			// Token: 0x04000314 RID: 788
			public const string Gamepad = "sidebar_gamepad";

			// Token: 0x04000315 RID: 789
			public const string Home = "sidebar_home";

			// Token: 0x04000316 RID: 790
			public const string Location = "sidebar_location";

			// Token: 0x04000317 RID: 791
			public const string LockCursor = "sidebar_lock_cursor";

			// Token: 0x04000318 RID: 792
			public const string LockCursorActive = "sidebar_lock_cursor_active";

			// Token: 0x04000319 RID: 793
			public const string Macro = "sidebar_macro";

			// Token: 0x0400031A RID: 794
			public const string MediaFolder = "sidebar_media_folder";

			// Token: 0x0400031B RID: 795
			public const string MIManager = "sidebar_mm";

			// Token: 0x0400031C RID: 796
			public const string Operation = "sidebar_operation";

			// Token: 0x0400031D RID: 797
			public const string OptionsClose = "sidebar_options_close";

			// Token: 0x0400031E RID: 798
			public const string OptionsOpen = "sidebar_options_open";

			// Token: 0x0400031F RID: 799
			public const string Overlay = "sidebar_overlay";

			// Token: 0x04000320 RID: 800
			public const string OverlayInactive = "sidebar_overlay_inactive";

			// Token: 0x04000321 RID: 801
			public const string OverlayPopup = "sidebar_overlay_popup";

			// Token: 0x04000322 RID: 802
			public const string OverlayInactivePopup = "sidebar_overlay_inactive_popup";

			// Token: 0x04000323 RID: 803
			public const string Rotate = "sidebar_rotate";

			// Token: 0x04000324 RID: 804
			public const string Screenshot = "sidebar_screenshot";

			// Token: 0x04000325 RID: 805
			public const string Shake = "sidebar_shake";

			// Token: 0x04000326 RID: 806
			public const string Toggle = "sidebar_toggle";

			// Token: 0x04000327 RID: 807
			public const string ToggleOff = "sidebar_toggle_off";

			// Token: 0x04000328 RID: 808
			public const string Upfront = "sidebar_upfront";

			// Token: 0x04000329 RID: 809
			public const string VideoCapture = "sidebar_video_capture";

			// Token: 0x0400032A RID: 810
			public const string VideoLoading = "sidebar_video_loading";

			// Token: 0x0400032B RID: 811
			public const string VideoCaptureActive = "sidebar_video_capture_active";

			// Token: 0x0400032C RID: 812
			public const string Volume = "sidebar_volume";

			// Token: 0x0400032D RID: 813
			public const string VolumePopup = "sidebar_volume_popup";

			// Token: 0x0400032E RID: 814
			public const string VolumeMutedPopup = "sidebar_volume_muted_popup";

			// Token: 0x0400032F RID: 815
			public const string VolumeMuted = "sidebar_volume_muted";

			// Token: 0x04000330 RID: 816
			public const string VolumeUp = "sidebar_volume_up";

			// Token: 0x04000331 RID: 817
			public const string VolumeDown = "sidebar_volume_down";

			// Token: 0x04000332 RID: 818
			public const string StreamVideo = "sidebar_stream_video";

			// Token: 0x04000333 RID: 819
			public const string Settings = "sidebar_settings";

			// Token: 0x04000334 RID: 820
			public const string StreamVideoActive = "sidebar_stream_video_active";
		}

		// Token: 0x02000089 RID: 137
		public class SettingsDropdown
		{
			// Token: 0x04000335 RID: 821
			public const string ToggleOn = "toggle_on";

			// Token: 0x04000336 RID: 822
			public const string ToggleOff = "toggle_off";
		}
	}
}
