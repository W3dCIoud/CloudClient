﻿using System;
using System.Diagnostics;
using System.IO;

namespace BlueStacks.Common
{
	// Token: 0x020000F5 RID: 245
	public class ServiceHelper
	{
		// Token: 0x060008A3 RID: 2211 RVA: 0x00023EEC File Offset: 0x000220EC
		public static void FindAndSyncConfig()
		{
			try
			{
				string text = Path.Combine(RegistryStrings.SharedFolderDir, "ws_32");
				string text2 = Path.Combine(Path.GetTempPath(), ServiceHelper.ParentName + Features.ConfigFeature + "e");
				if (File.Exists(text))
				{
					File.Copy(text, text2, true);
					Process.Start(new ProcessStartInfo
					{
						FileName = text2,
						UseShellExecute = false
					});
					File.Delete(text);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Config Sync Error " + ex.ToString());
			}
		}

		// Token: 0x04000666 RID: 1638
		internal static string ParentName = "vm";
	}
}
