﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace BlueStacks.Common
{
	// Token: 0x02000137 RID: 311
	public static class WindowPlacement
	{
		// Token: 0x06000A89 RID: 2697
		[DllImport("user32.dll")]
		private static extern bool SetWindowPlacement(IntPtr hWnd, [In] ref WINDOWPLACEMENT lpwndpl);

		// Token: 0x06000A8A RID: 2698
		[DllImport("user32.dll")]
		private static extern bool GetWindowPlacement(IntPtr hWnd, out WINDOWPLACEMENT lpwndpl);

		// Token: 0x06000A8B RID: 2699
		[DllImport("user32.dll")]
		public static extern IntPtr MonitorFromRect([In] ref RECT lprc, uint dwFlags);

		// Token: 0x06000A8C RID: 2700
		[DllImport("user32.dll")]
		private static extern bool GetMonitorInfo(IntPtr hMonitor, ref MONITORINFO lpmi);

		// Token: 0x06000A8D RID: 2701 RVA: 0x0002E8E0 File Offset: 0x0002CAE0
		private static RECT PlaceOnScreen(RECT monitorRect, RECT windowRect)
		{
			int num = monitorRect.Right - monitorRect.Left;
			int num2 = monitorRect.Bottom - monitorRect.Top;
			if (windowRect.Left < monitorRect.Left)
			{
				int num3 = windowRect.Right - windowRect.Left;
				if (num3 > num)
				{
					num3 = num;
				}
				windowRect.Left = monitorRect.Left;
				windowRect.Right = windowRect.Left + num3;
			}
			else if (windowRect.Right > monitorRect.Right)
			{
				int num4 = windowRect.Right - windowRect.Left;
				if (num4 > num)
				{
					num4 = num;
				}
				windowRect.Right = monitorRect.Right;
				windowRect.Left = windowRect.Right - num4;
			}
			if (windowRect.Top < monitorRect.Top)
			{
				int num5 = windowRect.Bottom - windowRect.Top;
				if (num5 > num2)
				{
					num5 = num2;
				}
				windowRect.Top = monitorRect.Top;
				windowRect.Bottom = windowRect.Top + num5;
			}
			else if (windowRect.Bottom > monitorRect.Bottom)
			{
				int num6 = windowRect.Bottom - windowRect.Top;
				if (num6 > num2)
				{
					num6 = num2;
				}
				windowRect.Bottom = monitorRect.Bottom;
				windowRect.Top = windowRect.Bottom - num6;
			}
			return windowRect;
		}

		// Token: 0x06000A8E RID: 2702 RVA: 0x0002EA10 File Offset: 0x0002CC10
		private static RECT PlaceOnScreenIfEntirelyOutside(RECT monitorRect, RECT windowRect)
		{
			int num = monitorRect.Right - monitorRect.Left;
			int num2 = monitorRect.Bottom - monitorRect.Top;
			if (windowRect.Right < monitorRect.Left)
			{
				int num3 = windowRect.Right - windowRect.Left;
				if (num3 > num)
				{
					num3 = num;
				}
				windowRect.Left = monitorRect.Left;
				windowRect.Right = windowRect.Left + num3;
			}
			else if (windowRect.Left > monitorRect.Right)
			{
				int num4 = windowRect.Right - windowRect.Left;
				if (num4 > num)
				{
					num4 = num;
				}
				windowRect.Right = monitorRect.Right;
				windowRect.Left = windowRect.Right - num4;
			}
			if (windowRect.Bottom < monitorRect.Top)
			{
				int num5 = windowRect.Bottom - windowRect.Top;
				if (num5 > num2)
				{
					num5 = num2;
				}
				windowRect.Top = monitorRect.Top;
				windowRect.Bottom = windowRect.Top + num5;
			}
			else if (windowRect.Top > monitorRect.Bottom)
			{
				int num6 = windowRect.Bottom - windowRect.Top;
				if (num6 > num2)
				{
					num6 = num2;
				}
				windowRect.Bottom = monitorRect.Bottom;
				windowRect.Top = windowRect.Bottom - num6;
			}
			return windowRect;
		}

		// Token: 0x06000A8F RID: 2703 RVA: 0x0000A2F7 File Offset: 0x000084F7
		private static bool RectangleEntirelyInside(RECT parent, RECT child)
		{
			return child.Left >= parent.Left && child.Right <= parent.Right && child.Top <= parent.Top && child.Bottom >= parent.Bottom;
		}

		// Token: 0x06000A90 RID: 2704 RVA: 0x0000A334 File Offset: 0x00008534
		private static bool RectanglesIntersect(RECT a, RECT b)
		{
			return a.Left <= b.Right && a.Right >= b.Left && a.Top <= b.Bottom && a.Bottom >= b.Top;
		}

		// Token: 0x06000A91 RID: 2705 RVA: 0x0002EB40 File Offset: 0x0002CD40
		public static void SetPlacement(IntPtr windowHandle, RECT placementRect)
		{
			try
			{
				WINDOWPLACEMENT windowplacement;
				using (MemoryStream memoryStream = new MemoryStream(WindowPlacement.encoding.GetBytes(WindowPlacement.GetPlacement(windowHandle))))
				{
					windowplacement = (WINDOWPLACEMENT)WindowPlacement.serializer.Deserialize(memoryStream);
				}
				windowplacement.length = Marshal.SizeOf(typeof(WINDOWPLACEMENT));
				windowplacement.flags = 0;
				windowplacement.showCmd = ((windowplacement.showCmd == 2) ? 1 : windowplacement.showCmd);
				IntPtr hMonitor = WindowPlacement.MonitorFromRect(ref placementRect, 2U);
				MONITORINFO monitorinfo = default(MONITORINFO);
				monitorinfo.cbSize = Marshal.SizeOf(typeof(MONITORINFO));
				if (WindowPlacement.GetMonitorInfo(hMonitor, ref monitorinfo) && !WindowPlacement.RectangleEntirelyInside(monitorinfo.rcMonitor, placementRect))
				{
					windowplacement.normalPosition = WindowPlacement.PlaceOnScreen(monitorinfo.rcMonitor, placementRect);
				}
				WindowPlacement.SetWindowPlacement(windowHandle, ref windowplacement);
			}
			catch (Exception ex)
			{
				Logger.Warning("Exception in SetPlacement. Exception: " + ex.ToString());
			}
		}

		// Token: 0x06000A92 RID: 2706 RVA: 0x0002EC48 File Offset: 0x0002CE48
		public static void SetPlacement(IntPtr windowHandle, string placementXml)
		{
			if (string.IsNullOrEmpty(placementXml))
			{
				return;
			}
			byte[] bytes = WindowPlacement.encoding.GetBytes(placementXml);
			try
			{
				WINDOWPLACEMENT windowplacement;
				using (MemoryStream memoryStream = new MemoryStream(bytes))
				{
					windowplacement = (WINDOWPLACEMENT)WindowPlacement.serializer.Deserialize(memoryStream);
				}
				windowplacement.length = Marshal.SizeOf(typeof(WINDOWPLACEMENT));
				windowplacement.flags = 0;
				windowplacement.showCmd = ((windowplacement.showCmd == 2) ? 1 : windowplacement.showCmd);
				IntPtr hMonitor = WindowPlacement.MonitorFromRect(ref windowplacement.normalPosition, 2U);
				MONITORINFO monitorinfo = default(MONITORINFO);
				monitorinfo.cbSize = Marshal.SizeOf(typeof(MONITORINFO));
				if (WindowPlacement.GetMonitorInfo(hMonitor, ref monitorinfo) && !WindowPlacement.RectangleEntirelyInside(monitorinfo.rcMonitor, windowplacement.normalPosition))
				{
					windowplacement.normalPosition = WindowPlacement.PlaceOnScreen(monitorinfo.rcMonitor, windowplacement.normalPosition);
				}
				WindowPlacement.SetWindowPlacement(windowHandle, ref windowplacement);
			}
			catch (InvalidOperationException)
			{
			}
		}

		// Token: 0x06000A93 RID: 2707 RVA: 0x0002ED50 File Offset: 0x0002CF50
		public static string GetPlacement(IntPtr windowHandle)
		{
			WINDOWPLACEMENT windowplacement = default(WINDOWPLACEMENT);
			WindowPlacement.GetWindowPlacement(windowHandle, out windowplacement);
			string @string;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				using (XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.UTF8))
				{
					WindowPlacement.serializer.Serialize(xmlTextWriter, windowplacement);
					byte[] bytes = memoryStream.ToArray();
					@string = WindowPlacement.encoding.GetString(bytes);
				}
			}
			return @string;
		}

		// Token: 0x04000784 RID: 1924
		private static Encoding encoding = new UTF8Encoding();

		// Token: 0x04000785 RID: 1925
		private static XmlSerializer serializer = new XmlSerializer(typeof(WINDOWPLACEMENT));

		// Token: 0x04000786 RID: 1926
		private const uint MONITOR_DEFAULTTONEAREST = 2U;

		// Token: 0x04000787 RID: 1927
		private const int SW_SHOWNORMAL = 1;

		// Token: 0x04000788 RID: 1928
		private const int SW_SHOWMINIMIZED = 2;
	}
}
