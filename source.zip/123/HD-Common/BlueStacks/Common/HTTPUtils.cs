﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x020000BA RID: 186
	public class HTTPUtils
	{
		// Token: 0x170001C4 RID: 452
		// (get) Token: 0x06000611 RID: 1553 RVA: 0x0000672A File Offset: 0x0000492A
		public static string PartnerServerUrl
		{
			get
			{
				return string.Format("{0}:{1}", HTTPUtils.sLoopbackUrl, RegistryManager.Instance.PartnerServerPort);
			}
		}

		// Token: 0x170001C5 RID: 453
		// (get) Token: 0x06000612 RID: 1554 RVA: 0x0000674A File Offset: 0x0000494A
		public static string AgentServerUrl
		{
			get
			{
				return string.Format("{0}:{1}", HTTPUtils.sLoopbackUrl, RegistryManager.Instance.AgentServerPort);
			}
		}

		// Token: 0x06000613 RID: 1555 RVA: 0x0000676A File Offset: 0x0000496A
		public static string FrontendServerUrl(string vmName = "Android")
		{
			return string.Format("{0}:{1}", HTTPUtils.sLoopbackUrl, RegistryManager.Instance.Guest[vmName].FrontendServerPort);
		}

		// Token: 0x06000614 RID: 1556 RVA: 0x00006795 File Offset: 0x00004995
		public static string GuestServerUrl(string vmName = "Android")
		{
			return string.Format("{0}:{1}", HTTPUtils.sLoopbackUrl, RegistryManager.Instance.Guest[vmName].BstAndroidPort);
		}

		// Token: 0x170001C6 RID: 454
		// (get) Token: 0x06000615 RID: 1557 RVA: 0x000067C0 File Offset: 0x000049C0
		public static string BTvServerUrl
		{
			get
			{
				return string.Format("{0}:{1}", HTTPUtils.sLoopbackUrl, RegistryManager.Instance.BTVServerPort);
			}
		}

		// Token: 0x06000616 RID: 1558 RVA: 0x0001D03C File Offset: 0x0001B23C
		public static string Encode(Dictionary<string, string> data)
		{
			StringBuilder stringBuilder = new StringBuilder();
			foreach (KeyValuePair<string, string> keyValuePair in data)
			{
				stringBuilder.AppendFormat("{0}={1}&", keyValuePair.Key, HttpUtility.UrlEncode(keyValuePair.Value));
			}
			char[] trimChars = new char[]
			{
				'&'
			};
			return stringBuilder.ToString().TrimEnd(trimChars);
		}

		// Token: 0x06000617 RID: 1559 RVA: 0x0001D0C0 File Offset: 0x0001B2C0
		public static string UrlForBstCommandProcessor(string url)
		{
			try
			{
				Uri uri = new Uri(url);
				foreach (string text in RegistryManager.Instance.VmList)
				{
					if (uri.Segments.Length > 1 && string.Compare("ping", uri.Segments[1]) != 0 && uri.Port == RegistryManager.Instance.Guest[text].BstAndroidPort)
					{
						return text;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error Occured, Err: {0}", new object[]
				{
					ex.ToString()
				});
			}
			return null;
		}

		// Token: 0x06000618 RID: 1560 RVA: 0x0001D168 File Offset: 0x0001B368
		public static HttpWebRequest GetUpdatedRequestWithCommonHeadersAndUserAgent(HttpWebRequest req, string vmName)
		{
			req.Headers.Set("x_oem", RegistryManager.Instance.Oem);
			req.Headers.Set("x_email", RegistryManager.Instance.RegisteredEmail);
			if (!string.IsNullOrEmpty(vmName))
			{
				if (vmName.Contains("Android"))
				{
					req.Headers.Set("vmname", vmName);
					req.Headers.Set("x_google_aid", Utils.GetGoogleAdIdfromRegistry(vmName));
					req.Headers.Set("x_android_id", Utils.GetAndroidIdfromRegistry(vmName));
					if (string.Equals(vmName, "Android", StringComparison.InvariantCultureIgnoreCase))
					{
						req.Headers.Set("vmid", "0");
					}
					else
					{
						req.Headers.Set("vmid", vmName.Split(new char[]
						{
							'_'
						})[1]);
					}
				}
				else
				{
					req.Headers.Set("vmid", vmName);
					if (vmName.Equals("0"))
					{
						req.Headers.Set("vmname", "Android");
						req.Headers.Set("x_google_aid", Utils.GetGoogleAdIdfromRegistry("Android"));
						req.Headers.Set("x_android_id", Utils.GetAndroidIdfromRegistry("Android"));
					}
					else
					{
						req.Headers.Set("vmname", "Android_" + vmName);
						req.Headers.Set("x_google_aid", Utils.GetGoogleAdIdfromRegistry("Android_" + vmName));
						req.Headers.Set("x_android_id", Utils.GetAndroidIdfromRegistry("Android_" + vmName));
					}
				}
			}
			req.UserAgent = RegistryStrings.UserAgent;
			return req;
		}

		// Token: 0x06000619 RID: 1561 RVA: 0x000067E0 File Offset: 0x000049E0
		public static RequestData ParseRequest(HttpListenerRequest req)
		{
			return HTTPUtils.ParseRequest(req, true);
		}

		// Token: 0x0600061A RID: 1562 RVA: 0x0001D324 File Offset: 0x0001B524
		public static RequestData ParseRequest(HttpListenerRequest req, bool printData)
		{
			RequestData requestData = new RequestData();
			bool flag = false;
			string text = null;
			requestData.headers = req.Headers;
			requestData.requestVmId = 0;
			requestData.requestVmName = "Android";
			foreach (string text2 in requestData.headers.AllKeys)
			{
				if (requestData.headers[text2].Contains("multipart"))
				{
					text = "--" + requestData.headers[text2].Substring(requestData.headers[text2].LastIndexOf("=") + 1);
					Logger.Debug("boundary: {0}", new object[]
					{
						text
					});
					flag = true;
				}
				if (text2 == "vmid" && requestData.headers[text2] != null)
				{
					if (!requestData.headers[text2].Equals("0"))
					{
						requestData.requestVmId = int.Parse(requestData.headers["vmid"]);
						if (requestData.requestVmName == "Android")
						{
							RequestData requestData2 = requestData;
							requestData2.requestVmName = requestData2.requestVmName + "_" + requestData.headers[text2].ToString();
						}
					}
				}
				else if (text2 == "vmname" && requestData.headers[text2] != null)
				{
					requestData.requestVmName = requestData.headers[text2].ToString();
				}
			}
			requestData.queryString = req.QueryString;
			if (!req.HasEntityBody)
			{
				return requestData;
			}
			Stream inputStream = req.InputStream;
			byte[] array = new byte[16384];
			MemoryStream memoryStream = new MemoryStream();
			int count;
			while ((count = inputStream.Read(array, 0, array.Length)) > 0)
			{
				memoryStream.Write(array, 0, count);
			}
			byte[] array2 = memoryStream.ToArray();
			memoryStream.Close();
			inputStream.Close();
			Logger.Debug("byte array size {0}", new object[]
			{
				array2.Length
			});
			string @string = Encoding.UTF8.GetString(array2);
			if (!flag)
			{
				if (!req.ContentType.Contains("application/json", StringComparison.InvariantCultureIgnoreCase))
				{
					requestData.data = HttpUtility.ParseQueryString(@string);
				}
				else
				{
					JObject jobject = JObject.Parse(@string);
					NameValueCollection nameValueCollection = new NameValueCollection();
					foreach (string text3 in (from p in jobject.Properties()
					select p.Name).ToList<string>())
					{
						nameValueCollection.Add(text3, jobject[text3].ToString());
					}
					requestData.data = nameValueCollection;
				}
				return requestData;
			}
			byte[] bytes = Encoding.UTF8.GetBytes(text);
			List<int> list = HTTPUtils.IndexOf(array2, bytes);
			for (int j = 0; j < list.Count - 1; j++)
			{
				Logger.Info("Creating part");
				int num = list[j];
				int num2 = list[j + 1];
				int num3 = num2 - num;
				byte[] array3 = new byte[num3];
				Logger.Debug("Start: {0}, End: {1}, Length: {2}", new object[]
				{
					num,
					num2,
					num3
				});
				Logger.Debug("byteData length: {0}", new object[]
				{
					array2.Length
				});
				Buffer.BlockCopy(array2, num, array3, 0, num3);
				Logger.Debug("bytePart length: {0}", new object[]
				{
					array3.Length
				});
				string string2 = Encoding.UTF8.GetString(array3);
				Match match = new Regex("(?<=Content\\-Type:)(.*?)(?=\\r\\n)").Match(string2);
				Match match2 = new Regex("(?<=filename\\=\\\")(.*?)(?=\\\")").Match(string2);
				string text4 = new Regex("(?<=name\\=\\\")(.*?)(?=\\\")").Match(string2).Value.Trim();
				Logger.Info("Got name: {0}", new object[]
				{
					text4
				});
				if (match.Success && match2.Success)
				{
					Logger.Debug("Found file");
					string text5 = match.Value.Trim();
					Logger.Debug("Got contenttype: {0}", new object[]
					{
						text5
					});
					string text6 = match2.Value.Trim();
					Logger.Info("Got filename: {0}", new object[]
					{
						text6
					});
					int num4 = string2.IndexOf("\r\n\r\n") + "\r\n\r\n".Length;
					Encoding.UTF8.GetBytes("\r\n" + text);
					int num5 = num3 - num4;
					byte[] array4 = new byte[num5];
					Logger.Debug("startindex: {0}, contentlength: {1}", new object[]
					{
						num4,
						num5
					});
					Buffer.BlockCopy(array3, num4, array4, 0, num5);
					string path = RegistryStrings.BstUserDataDir;
					if (text6.StartsWith("tombstone"))
					{
						path = RegistryStrings.BstLogsDir;
					}
					string text7 = Path.Combine(path, text6);
					FileStream fileStream = File.OpenWrite(text7);
					fileStream.Write(array4, 0, num5);
					fileStream.Close();
					requestData.files.Add(text4, text7);
				}
				else
				{
					Logger.Info("No file in this part");
					int num6 = string2.LastIndexOf("\r\n\r\n");
					string text8 = string2.Substring(num6, string2.Length - num6);
					text8 = text8.Trim();
					if (printData)
					{
						Logger.Info("Got value: {0}", new object[]
						{
							text8
						});
					}
					else
					{
						Logger.Info("Value hidden");
					}
					requestData.data.Add(text4, text8);
				}
			}
			return requestData;
		}

		// Token: 0x0600061B RID: 1563 RVA: 0x0001D8E0 File Offset: 0x0001BAE0
		private static List<int> IndexOf(byte[] searchWithin, byte[] searchFor)
		{
			List<int> list = new List<int>();
			int startIndex = 0;
			int num = Array.IndexOf<byte>(searchWithin, searchFor[0], startIndex);
			Logger.Debug("boundary size = {0}", new object[]
			{
				searchFor.Length
			});
			do
			{
				int num2 = 0;
				while (num + num2 < searchWithin.Length && searchWithin[num + num2] == searchFor[num2])
				{
					num2++;
					if (num2 == searchFor.Length)
					{
						list.Add(num);
						Logger.Debug("Got boundary postion: {0}", new object[]
						{
							num
						});
						break;
					}
				}
				if (num + num2 > searchWithin.Length)
				{
					break;
				}
				num = Array.IndexOf<byte>(searchWithin, searchFor[0], num + num2);
			}
			while (num != -1);
			return list;
		}

		// Token: 0x0600061C RID: 1564 RVA: 0x0001D978 File Offset: 0x0001BB78
		public static string MergeQueryParams(string urlOriginal, string urlOverideParams, bool paramsOnly = false)
		{
			NameValueCollection nameValueCollection = new NameValueCollection();
			if (paramsOnly)
			{
				nameValueCollection = HttpUtility.ParseQueryString(urlOverideParams);
			}
			else
			{
				nameValueCollection = HttpUtility.ParseQueryString(new UriBuilder(urlOverideParams).Query);
			}
			UriBuilder uriBuilder = new UriBuilder(urlOriginal);
			NameValueCollection nameValueCollection2 = HttpUtility.ParseQueryString(uriBuilder.Query);
			foreach (object obj in nameValueCollection.Keys)
			{
				nameValueCollection2.Set(obj.ToString(), nameValueCollection[obj.ToString()]);
			}
			uriBuilder.Query = nameValueCollection2.ToString();
			return uriBuilder.Uri.OriginalString;
		}

		// Token: 0x0600061D RID: 1565 RVA: 0x000067E9 File Offset: 0x000049E9
		public static void Write(StringBuilder sb, HttpListenerResponse res)
		{
			HTTPUtils.Write(sb.ToString(), res);
		}

		// Token: 0x0600061E RID: 1566 RVA: 0x0001DA30 File Offset: 0x0001BC30
		public static void Write(string s, HttpListenerResponse res)
		{
			try
			{
				byte[] bytes = Encoding.UTF8.GetBytes(s);
				res.ContentLength64 = (long)bytes.Length;
				res.OutputStream.Write(bytes, 0, bytes.Length);
				res.OutputStream.Flush();
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in writing response to http output stream:{0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x0600061F RID: 1567 RVA: 0x0001DA98 File Offset: 0x0001BC98
		public static HTTPServer SetupServer(int startingPort, int maxPort, Dictionary<string, HTTPServer.RequestHandler> routes, string s_RootDir)
		{
			HTTPServer httpserver = null;
			int i;
			for (i = startingPort; i < maxPort; i++)
			{
				try
				{
					httpserver = new HTTPServer(i, routes, s_RootDir);
					httpserver.Start();
					i = httpserver.Port;
					Logger.Info("Server listening on port " + httpserver.Port);
					if (!string.IsNullOrEmpty(httpserver.RootDir))
					{
						Logger.Info("Serving static content from " + httpserver.RootDir);
					}
					break;
				}
				catch (Exception ex)
				{
					Logger.Warning(string.Format("Error occured, port : {0} Err: {1}", i, ex.ToString()));
				}
			}
			if (i == maxPort || httpserver == null)
			{
				Logger.Fatal("No free port available or server could not be started, exiting.");
				Environment.Exit(2);
			}
			return httpserver;
		}

		// Token: 0x06000620 RID: 1568 RVA: 0x0001DB50 File Offset: 0x0001BD50
		public static void SendRequestToClientAsync(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			if (retries == 1)
			{
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					try
					{
						HTTPUtils.SendRequestToClient(route, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec);
					}
					catch (Exception ex)
					{
						Logger.Error("An exception in SendRequestToClient. route: {0}, \n{1}", new object[]
						{
							route,
							ex
						});
					}
				});
				return;
			}
			new Thread(delegate()
			{
				try
				{
					HTTPUtils.SendRequestToClient(route, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec);
				}
				catch (Exception ex)
				{
					Logger.Error("An exception in SendRequestToClient. route: {0}, \n{1}", new object[]
					{
						route,
						ex
					});
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000621 RID: 1569 RVA: 0x0001DBD8 File Offset: 0x0001BDD8
		public static void SendRequestToEngineAsync(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			if (retries == 1)
			{
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					try
					{
						HTTPUtils.SendRequestToEngine(route, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, "");
					}
					catch (Exception ex)
					{
						Logger.Error("An exception in SendRequestToEngine. route: {0}, \n{1}", new object[]
						{
							route,
							ex
						});
					}
				});
				return;
			}
			new Thread(delegate()
			{
				try
				{
					HTTPUtils.SendRequestToEngine(route, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, "");
				}
				catch (Exception ex)
				{
					Logger.Error("An exception in SendRequestToEngine. route: {0}, \n{1}", new object[]
					{
						route,
						ex
					});
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000622 RID: 1570 RVA: 0x0001DC60 File Offset: 0x0001BE60
		public static void SendRequestToAgentAsync(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			if (retries == 1)
			{
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					try
					{
						HTTPUtils.SendRequestToAgent(route, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec);
					}
					catch (Exception ex)
					{
						Logger.Error("An exception in SendRequestToAgent. route: {0}, \n{1}", new object[]
						{
							route,
							ex
						});
					}
				});
				return;
			}
			new Thread(delegate()
			{
				try
				{
					HTTPUtils.SendRequestToAgent(route, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec);
				}
				catch (Exception ex)
				{
					Logger.Error("An exception in SendRequestToAgent. route: {0}, \n{1}", new object[]
					{
						route,
						ex
					});
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000623 RID: 1571 RVA: 0x0001DCE8 File Offset: 0x0001BEE8
		public static void SendRequestToGuestAsync(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			if (retries == 1)
			{
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					try
					{
						HTTPUtils.SendRequestToGuest(route, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec);
					}
					catch (Exception ex)
					{
						Logger.Error("An exception in SendRequestToGuest. route: {0}, \n{1}", new object[]
						{
							route,
							ex
						});
					}
				});
				return;
			}
			new Thread(delegate()
			{
				try
				{
					HTTPUtils.SendRequestToGuest(route, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec);
				}
				catch (Exception ex)
				{
					Logger.Error("An exception in SendRequestToGuest. route: {0}, \n{1}", new object[]
					{
						route,
						ex
					});
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000624 RID: 1572 RVA: 0x0001DD70 File Offset: 0x0001BF70
		public static void SendRequestToCloudAsync(string api, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			if (retries == 1)
			{
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					try
					{
						HTTPUtils.SendRequestToCloud(api, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
					}
					catch (Exception ex)
					{
						Logger.Error("An exception in SendRequestToCloud. route: {0}, \n{1}", new object[]
						{
							api,
							ex
						});
					}
				});
				return;
			}
			new Thread(delegate()
			{
				try
				{
					HTTPUtils.SendRequestToCloud(api, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
				}
				catch (Exception ex)
				{
					Logger.Error("An exception in SendRequestToCloud. route: {0}, \n{1}", new object[]
					{
						api,
						ex
					});
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000625 RID: 1573 RVA: 0x0001DDF8 File Offset: 0x0001BFF8
		public static void SendRequestToCloudWithParamsAsync(string api, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			if (retries == 1)
			{
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					try
					{
						HTTPUtils.SendRequestToCloudWithParams(api, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec);
					}
					catch (Exception ex)
					{
						Logger.Error("An exception in SendRequestToCloudWithParams. route: {0}, \n{1}", new object[]
						{
							api,
							ex
						});
					}
				});
				return;
			}
			new Thread(delegate()
			{
				try
				{
					HTTPUtils.SendRequestToCloudWithParams(api, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec);
				}
				catch (Exception ex)
				{
					Logger.Error("An exception in SendRequestToCloudWithParams. route: {0}, \n{1}", new object[]
					{
						api,
						ex
					});
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000626 RID: 1574 RVA: 0x0001DE80 File Offset: 0x0001C080
		public static string SendRequestToClient(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			return HTTPUtils.SendHTTPRequest(string.Format("{0}/{1}", HTTPUtils.PartnerServerUrl, route), data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
		}

		// Token: 0x06000627 RID: 1575 RVA: 0x0001DEB0 File Offset: 0x0001C0B0
		public static string SendRequestToEngine(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0, string destinationVmName = "")
		{
			if (string.IsNullOrEmpty(destinationVmName))
			{
				destinationVmName = vmName;
			}
			return HTTPUtils.SendHTTPRequest(string.Format("{0}/{1}", HTTPUtils.FrontendServerUrl(destinationVmName), route), data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
		}

		// Token: 0x06000628 RID: 1576 RVA: 0x0001DEEC File Offset: 0x0001C0EC
		public static string SendRequestToAgent(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			return HTTPUtils.SendHTTPRequest(string.Format("{0}/{1}", HTTPUtils.AgentServerUrl, route), data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
		}

		// Token: 0x06000629 RID: 1577 RVA: 0x0001DF1C File Offset: 0x0001C11C
		public static string SendRequestToGuest(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			return HTTPUtils.SendHTTPRequest(string.Format("{0}/{1}", HTTPUtils.GuestServerUrl(vmName), route), data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
		}

		// Token: 0x0600062A RID: 1578 RVA: 0x0001DF4C File Offset: 0x0001C14C
		public static string SendRequestToBTv(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			return HTTPUtils.SendHTTPRequest(string.Format("{0}/{1}", HTTPUtils.BTvServerUrl, route), data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
		}

		// Token: 0x0600062B RID: 1579 RVA: 0x0001DF7C File Offset: 0x0001C17C
		public static string SendRequestToCloud(string api, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0, bool isOnUIThreadOnPurpose = false)
		{
			return HTTPUtils.SendHTTPRequest(string.Format("{0}/{1}", RegistryManager.Instance.Host, api), data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, isOnUIThreadOnPurpose);
		}

		// Token: 0x0600062C RID: 1580 RVA: 0x0001DFB0 File Offset: 0x0001C1B0
		public static string SendRequestToCloudWithParams(string api, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			return HTTPUtils.SendHTTPRequest(WebHelper.GetUrlWithParams(string.Format("{0}/{1}", RegistryManager.Instance.Host, api)), data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
		}

		// Token: 0x0600062D RID: 1581 RVA: 0x0001DFE8 File Offset: 0x0001C1E8
		public static string SendRequestToNCSoftAgent(int port, string api, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			return HTTPUtils.SendHTTPRequest(string.Format("{0}:{1}/{2}", HTTPUtils.sLoopbackUrl, port, api), data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
		}

		// Token: 0x0600062E RID: 1582 RVA: 0x0001E020 File Offset: 0x0001C220
		private static string SendHTTPRequest(string url, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0, bool isOnUIThreadOnPurpose = false)
		{
			string text;
			if (data == null)
			{
				Logger.Info("Sending GET to {0}", new object[]
				{
					url
				});
				text = BstHttpClient.Get(url, headers, false, vmName, timeout, retries, sleepTimeMSec, isOnUIThreadOnPurpose);
			}
			else
			{
				Logger.Info("Sending POST to {0}", new object[]
				{
					url
				});
				text = BstHttpClient.Post(url, data, headers, false, vmName, timeout, retries, sleepTimeMSec, isOnUIThreadOnPurpose);
			}
			if (printResponse)
			{
				Logger.Info("Loopback resp: {0}", new object[]
				{
					text
				});
			}
			else
			{
				Logger.Debug("Loopback resp: {0}", new object[]
				{
					text
				});
			}
			return text;
		}

		// Token: 0x0600062F RID: 1583 RVA: 0x0001E0B0 File Offset: 0x0001C2B0
		public static void WriteSuccessArrayJson(HttpListenerResponse res, string reason = "")
		{
			if (string.IsNullOrEmpty(reason))
			{
				HTTPUtils.Write(JSonTemplates.SuccessArrayJSonTemplate, res);
				return;
			}
			HTTPUtils.Write(new JArray
			{
				new JObject
				{
					{
						"success",
						true
					},
					{
						"reason",
						reason
					}
				}
			}.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x06000630 RID: 1584 RVA: 0x0001E118 File Offset: 0x0001C318
		public static void WriteErrorArrayJson(HttpListenerResponse res, string reason = "")
		{
			if (string.IsNullOrEmpty(reason))
			{
				HTTPUtils.Write(JSonTemplates.FailedArrayJSonTemplate, res);
				return;
			}
			HTTPUtils.Write(new JArray
			{
				new JObject
				{
					{
						"success",
						false
					},
					{
						"reason",
						reason
					}
				}
			}.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x06000631 RID: 1585 RVA: 0x0001E180 File Offset: 0x0001C380
		public static void WriteArrayJson(HttpListenerResponse res, Dictionary<string, string> data)
		{
			JArray jarray = new JArray();
			JObject jobject = new JObject();
			foreach (KeyValuePair<string, string> keyValuePair in data)
			{
				jobject.Add(keyValuePair.Key, keyValuePair.Value);
			}
			jarray.Add(jobject);
			HTTPUtils.Write(jarray.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x06000632 RID: 1586 RVA: 0x0001E208 File Offset: 0x0001C408
		public static void WriteArrayJson(HttpListenerResponse res, Dictionary<string, object> data)
		{
			JArray jarray = new JArray();
			JObject jobject = new JObject();
			foreach (KeyValuePair<string, object> keyValuePair in data)
			{
				jobject.Add(keyValuePair.Key, JToken.FromObject(keyValuePair.Value));
			}
			jarray.Add(jobject);
			HTTPUtils.Write(jarray.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x06000633 RID: 1587 RVA: 0x0001E290 File Offset: 0x0001C490
		public static void WriteSuccessJson(HttpListenerResponse res, string reason = "")
		{
			if (string.IsNullOrEmpty(reason))
			{
				HTTPUtils.Write(JSonTemplates.SuccessJSonTemplate, res);
				return;
			}
			HTTPUtils.Write(new JObject
			{
				{
					"success",
					true
				},
				{
					"reason",
					reason
				}
			}.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x06000634 RID: 1588 RVA: 0x0001E2EC File Offset: 0x0001C4EC
		public static void WriteErrorJson(HttpListenerResponse res, string reason = "")
		{
			if (string.IsNullOrEmpty(reason))
			{
				HTTPUtils.Write(JSonTemplates.FailedJSonTemplate, res);
				return;
			}
			HTTPUtils.Write(new JObject
			{
				{
					"success",
					false
				},
				{
					"reason",
					reason
				}
			}.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x06000635 RID: 1589 RVA: 0x0001E348 File Offset: 0x0001C548
		public static void AddCommonRequestHeaders(ref HttpWebRequest req)
		{
			req.Headers.Set("x_oem", RegistryManager.Instance.Oem);
			req.Headers.Set("x_email", RegistryManager.Instance.RegisteredEmail);
			req.Headers.Set("x_machine_id", GuidUtils.GetBlueStacksMachineId());
			req.Headers.Set("x_version_machine_id", GuidUtils.GetBlueStacksVersionId());
			if (req.RequestUri.Host.Contains("localhost") || req.RequestUri.Host.Contains("127.0.0.1"))
			{
				req.Headers.Set("x_api_token", RegistryManager.Instance.ApiToken);
				return;
			}
			req.Headers.Remove("x_api_token");
		}

		// Token: 0x0400049C RID: 1180
		private static string sLoopbackUrl = "http://127.0.0.1";
	}
}
