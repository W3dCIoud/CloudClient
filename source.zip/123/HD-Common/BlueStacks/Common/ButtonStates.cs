﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000D0 RID: 208
	public enum ButtonStates
	{
		// Token: 0x0400051D RID: 1309
		MouseIn,
		// Token: 0x0400051E RID: 1310
		MouseOut,
		// Token: 0x0400051F RID: 1311
		MouseDown
	}
}
