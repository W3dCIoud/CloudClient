﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Markup;
using System.Windows.Media;

namespace BlueStacks.Common
{
	// Token: 0x02000095 RID: 149
	public class BrushToColorConvertor : MarkupExtension, IValueConverter
	{
		// Token: 0x06000369 RID: 873 RVA: 0x00003F19 File Offset: 0x00002119
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return BrushToColorConvertor.Convert(value, targetType);
		}

		// Token: 0x0600036A RID: 874 RVA: 0x00003F19 File Offset: 0x00002119
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return BrushToColorConvertor.Convert(value, targetType);
		}

		// Token: 0x0600036B RID: 875 RVA: 0x00003F22 File Offset: 0x00002122
		public static object Convert(object value, Type targetType)
		{
			if (typeof(SolidColorBrush).IsSubclassOf(targetType))
			{
				return value;
			}
			return (value as SolidColorBrush).Color;
		}

		// Token: 0x0600036C RID: 876 RVA: 0x00003F48 File Offset: 0x00002148
		public override object ProvideValue(IServiceProvider serviceProvider)
		{
			return this;
		}
	}
}
