﻿using System;
using System.Windows;
using System.Windows.Media;

namespace BlueStacks.Common
{
	// Token: 0x02000182 RID: 386
	public static class WpfUtils
	{
		// Token: 0x170002EF RID: 751
		// (get) Token: 0x06000C54 RID: 3156 RVA: 0x0000B1EA File Offset: 0x000093EA
		public static double PrimaryWidth
		{
			get
			{
				return SystemParameters.PrimaryScreenWidth;
			}
		}

		// Token: 0x170002F0 RID: 752
		// (get) Token: 0x06000C55 RID: 3157 RVA: 0x0000B1F1 File Offset: 0x000093F1
		public static double PrimaryHeight
		{
			get
			{
				return SystemParameters.PrimaryScreenHeight;
			}
		}

		// Token: 0x06000C56 RID: 3158 RVA: 0x00034810 File Offset: 0x00032A10
		public static childItem FindVisualChild<childItem>(DependencyObject obj) where childItem : DependencyObject
		{
			for (int i = 0; i < VisualTreeHelper.GetChildrenCount(obj); i++)
			{
				DependencyObject child = VisualTreeHelper.GetChild(obj, i);
				if (child != null && child is childItem)
				{
					return (childItem)((object)child);
				}
				childItem childItem = WpfUtils.FindVisualChild<childItem>(child);
				if (childItem != null)
				{
					return childItem;
				}
			}
			return default(childItem);
		}

		// Token: 0x06000C57 RID: 3159 RVA: 0x00034864 File Offset: 0x00032A64
		public static void GetDefaultSize(out double width, out double height, out double left, double aspectRatio, bool isGMWindow)
		{
			int num;
			if (WpfUtils.PrimaryWidth * 0.8 / aspectRatio <= WpfUtils.PrimaryHeight * 0.8)
			{
				num = (int)(WpfUtils.PrimaryWidth * 0.8);
			}
			else
			{
				num = (int)(WpfUtils.PrimaryHeight * 0.8 * aspectRatio);
			}
			if (!isGMWindow)
			{
				width = (double)(num / 4 * 3);
				left = (double)((int)(WpfUtils.PrimaryWidth - (double)num) / 2);
			}
			else
			{
				width = (double)num;
				left = (double)((int)(WpfUtils.PrimaryWidth - (double)num) / 2);
			}
			if (width < 912.0)
			{
				width = 912.0;
				left = 20.0;
			}
			height = (double)((int)width / 16 * 9);
		}

		// Token: 0x06000C58 RID: 3160 RVA: 0x0003491C File Offset: 0x00032B1C
		public static T FindVisualParent<T>(DependencyObject child) where T : DependencyObject
		{
			DependencyObject parent = VisualTreeHelper.GetParent(child);
			if (parent == null)
			{
				return default(T);
			}
			T t = parent as T;
			if (t != null)
			{
				return t;
			}
			return WpfUtils.FindVisualParent<T>(parent);
		}
	}
}
