﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Threading;

namespace BlueStacks.Common
{
	// Token: 0x020000F9 RID: 249
	public class Stats
	{
		// Token: 0x170002A1 RID: 673
		// (get) Token: 0x060008B9 RID: 2233 RVA: 0x000095A9 File Offset: 0x000077A9
		// (set) Token: 0x060008BA RID: 2234 RVA: 0x000095BD File Offset: 0x000077BD
		private static string SessionId
		{
			get
			{
				if (Stats.sSessionId == null)
				{
					Stats.ResetSessionId();
				}
				return Stats.sSessionId;
			}
			set
			{
				Stats.sSessionId = value;
			}
		}

		// Token: 0x060008BB RID: 2235 RVA: 0x000095C5 File Offset: 0x000077C5
		public static string GetSessionId()
		{
			return Stats.SessionId;
		}

		// Token: 0x060008BC RID: 2236 RVA: 0x000095CC File Offset: 0x000077CC
		public static string ResetSessionId()
		{
			Stats.SessionId = Stats.Timestamp;
			return Stats.SessionId;
		}

		// Token: 0x060008BD RID: 2237 RVA: 0x000095DD File Offset: 0x000077DD
		public static void SendAppStats(string appName, string packageName, string appVersion, string homeVersion, Stats.AppType appType, string vmName, string appVersionName = "")
		{
			Stats.SendAppStats(appName, packageName, appVersion, homeVersion, appType, null, vmName, appVersionName);
		}

		// Token: 0x060008BE RID: 2238 RVA: 0x00023F84 File Offset: 0x00022184
		public static void SendAppStats(string appName, string packageName, string appVersion, string homeVersion, Stats.AppType appType, string source, string vmName, string appVersionName)
		{
			new Thread(delegate()
			{
				try
				{
					string url = string.Format("{0}/{1}", RegistryManager.Instance.Host, "stats/appclickstats");
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					dictionary.Add("email", Stats.GetURLSafeBase64String(RegistryManager.Instance.RegisteredEmail));
					dictionary.Add("app_name", Stats.GetURLSafeBase64String(appName));
					dictionary.Add("app_pkg", Stats.GetURLSafeBase64String(packageName));
					dictionary.Add("app_ver", Stats.GetURLSafeBase64String(appVersion));
					dictionary.Add("home_app_ver", Stats.GetURLSafeBase64String(homeVersion));
					dictionary.Add("user_time", Stats.GetURLSafeBase64String(Stats.Timestamp));
					dictionary.Add("app_type", Stats.GetURLSafeBase64String(appType.ToString()));
					dictionary.Add("app_ver_name", Stats.GetURLSafeBase64String(appVersionName));
					if (source != null)
					{
						dictionary.Add("source", Stats.GetURLSafeBase64String(source));
					}
					Logger.Info("Sending App Stats for: {0}", new object[]
					{
						appName
					});
					BstHttpClient.Post(url, dictionary, null, false, vmName, 0, 1, 0, false);
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to send app stats. error: " + ex.ToString());
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060008BF RID: 2239 RVA: 0x00023FF0 File Offset: 0x000221F0
		public static void SendWebAppChannelStats(string appName, string packageName, string homeVersion, string source, string vmName)
		{
			new Thread(delegate()
			{
				string url = string.Format("{0}/{1}", RegistryManager.Instance.Host, "stats/webappchannelclickstats");
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary.Add("app_name", Stats.GetURLSafeBase64String(appName));
				dictionary.Add("app_pkg", Stats.GetURLSafeBase64String(packageName));
				dictionary.Add("home_app_ver", Stats.GetURLSafeBase64String(homeVersion));
				dictionary.Add("user_time", Stats.GetURLSafeBase64String(Stats.Timestamp));
				dictionary.Add("email", Stats.GetURLSafeBase64String(RegistryManager.Instance.RegisteredEmail));
				dictionary.Add("source", Stats.GetURLSafeBase64String(source));
				try
				{
					Logger.Info("Sending Channel App Stats for: {0}", new object[]
					{
						appName
					});
					string text = BstHttpClient.Post(url, dictionary, null, false, vmName, 0, 1, 0, false);
					Logger.Info("Got Channel App Stat response: {0}", new object[]
					{
						text
					});
				}
				catch (Exception ex)
				{
					Logger.Error(ex.ToString());
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060008C0 RID: 2240 RVA: 0x000095EF File Offset: 0x000077EF
		public static void SendSearchAppStats(string keyword, string vmName)
		{
			Stats.SendSearchAppStats(keyword, null, vmName);
		}

		// Token: 0x060008C1 RID: 2241 RVA: 0x000095F9 File Offset: 0x000077F9
		public static void SendSearchAppStats(string keyword, string source, string vmName)
		{
			new Thread(delegate()
			{
				string url = string.Format("{0}/{1}", RegistryManager.Instance.Host, "stats/searchappstats");
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary.Add("keyword", keyword);
				if (source != null)
				{
					dictionary.Add("source", source);
				}
				try
				{
					Logger.Info("Sending Search App Stats for: {0}", new object[]
					{
						keyword
					});
					string text = BstHttpClient.Post(url, dictionary, null, false, vmName, 0, 1, 0, false);
					Logger.Info("Got Search App Stat response: {0}", new object[]
					{
						text
					});
				}
				catch (Exception ex)
				{
					Logger.Error(ex.ToString());
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060008C2 RID: 2242 RVA: 0x00024044 File Offset: 0x00022244
		public static void SendAppInstallStats(string appName, string packageName, string appVersion, string appVersionName, string appInstall, string isUpdate, string source, string vmName, string campaignName, string clientVersion, string apkType = "")
		{
			new Thread(delegate()
			{
				string url = string.Format("{0}/{1}", RegistryManager.Instance.Host, "stats/appinstallstats");
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary.Add("email", Stats.GetURLSafeBase64String(RegistryManager.Instance.RegisteredEmail));
				dictionary.Add("app_name", Stats.GetURLSafeBase64String(appName));
				dictionary.Add("app_pkg", Stats.GetURLSafeBase64String(packageName));
				dictionary.Add("app_ver", Stats.GetURLSafeBase64String(appVersion));
				dictionary.Add("is_install", Stats.GetURLSafeBase64String(appInstall));
				dictionary.Add("is_update", Stats.GetURLSafeBase64String(isUpdate));
				dictionary.Add("user_time", Stats.GetURLSafeBase64String(Stats.Timestamp));
				dictionary.Add("install_source", Stats.GetURLSafeBase64String(source));
				dictionary.Add("utm_campaign", Stats.GetURLSafeBase64String(campaignName));
				dictionary.Add("client_ver", Stats.GetURLSafeBase64String(clientVersion));
				dictionary.Add("apk_type", Stats.GetURLSafeBase64String(apkType));
				dictionary.Add("app_ver_name", Stats.GetURLSafeBase64String(appVersionName));
				try
				{
					Logger.Info("Sending App Install Stats for: {0}", new object[]
					{
						appName
					});
					string text = BstHttpClient.Post(url, dictionary, null, false, vmName, 0, 1, 0, false);
					Logger.Debug("Got App Install Stat response: {0}", new object[]
					{
						text
					});
				}
				catch (Exception ex)
				{
					Logger.Error("Error in Sending AppInstallStats : " + ex.ToString());
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060008C3 RID: 2243 RVA: 0x00009631 File Offset: 0x00007831
		public static void SendSystemInfoStats(string vmName)
		{
			Stats.SendSystemInfoStatsAsync(null, true, null, null, null, vmName);
		}

		// Token: 0x060008C4 RID: 2244 RVA: 0x000240C8 File Offset: 0x000222C8
		public static void SendSystemInfoStatsAsync(string host, bool createRegKey, Dictionary<string, string> dataInfo, string guid, string pfDir, string vmName)
		{
			new Thread(delegate()
			{
				Stats.SendSystemInfoStatsSync(host, createRegKey, dataInfo, guid, pfDir, vmName);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060008C5 RID: 2245 RVA: 0x00024124 File Offset: 0x00022324
		public static string SendSystemInfoStatsSync(string host, bool createRegKey, Dictionary<string, string> dataInfo, string guid, string programFilesDir, string vmName)
		{
			string text = "not sent";
			try
			{
				Dictionary<string, string> dictionary = Profile.Info();
				Logger.Info("Got Device Profile Info:");
				foreach (KeyValuePair<string, string> keyValuePair in dictionary)
				{
					Logger.Info(keyValuePair.Key + " " + keyValuePair.Value);
				}
				if (host == null)
				{
					host = RegistryManager.Instance.Host;
				}
				string url = string.Format("{0}/{1}", host, "stats/systeminfostats");
				Dictionary<string, string> dictionary2 = new Dictionary<string, string>();
				dictionary2.Add("p", Stats.GetURLSafeBase64String(dictionary["Processor"]));
				dictionary2.Add("nop", Stats.GetURLSafeBase64String(dictionary["NumberOfProcessors"]));
				dictionary2.Add("g", Stats.GetURLSafeBase64String(dictionary["GPU"]));
				dictionary2.Add("gd", Stats.GetURLSafeBase64String(dictionary["GPUDriver"]));
				dictionary2.Add("o", Stats.GetURLSafeBase64String(dictionary["OS"]));
				dictionary2.Add("osv", Stats.GetURLSafeBase64String(dictionary["OSVersion"]));
				dictionary2.Add("sr", Stats.GetURLSafeBase64String(dictionary["ScreenResolution"]));
				dictionary2.Add("dnv", Stats.GetURLSafeBase64String(dictionary["DotNetVersion"]));
				dictionary2.Add("osl", Stats.GetURLSafeBase64String(CultureInfo.CurrentCulture.Name.ToLower()));
				dictionary2.Add("oem_info", Stats.GetURLSafeBase64String(dictionary["OEMInfo"]));
				dictionary2.Add("ram", Stats.GetURLSafeBase64String(dictionary["RAM"]));
				dictionary2.Add("machine_type", Stats.GetURLSafeBase64String(dictionary["OSVERSIONTYPE"]));
				if (dataInfo != null)
				{
					dictionary2.Add("glmode", Stats.GetURLSafeBase64String(dataInfo["GlMode"]));
					dictionary2.Add("glrendermode", Stats.GetURLSafeBase64String(dataInfo["GlRenderMode"]));
					dictionary2.Add("gl_vendor", Stats.GetURLSafeBase64String(dataInfo["GlVendor"]));
					dictionary2.Add("gl_renderer", Stats.GetURLSafeBase64String(dataInfo["GlRenderer"]));
					dictionary2.Add("gl_version", Stats.GetURLSafeBase64String(dataInfo["GlVersion"]));
					dictionary2.Add("bstr", Stats.GetURLSafeBase64String(dataInfo["BlueStacksResolution"]));
					if (dataInfo.ContainsKey("gl_check"))
					{
						dictionary2.Add("gl_check", Stats.GetURLSafeBase64String(dataInfo["gl_check"]));
					}
					if (dataInfo.ContainsKey("supported_glmodes"))
					{
						dictionary2.Add("supported_glmodes", Stats.GetURLSafeBase64String(dataInfo["supported_glmodes"]));
					}
					if (dataInfo.ContainsKey("IsVulkanSupported"))
					{
						dictionary2.Add("is_vulkan_supported", dataInfo["IsVulkanSupported"]);
					}
				}
				else
				{
					dictionary2.Add("bstr", Stats.GetURLSafeBase64String(dictionary["BlueStacksResolution"]));
					dictionary2.Add("glmode", Stats.GetURLSafeBase64String(dictionary["GlMode"]));
					dictionary2.Add("glrendermode", Stats.GetURLSafeBase64String(dictionary["GlRenderMode"]));
				}
				try
				{
					string text2 = "";
					string text3 = "";
					string text4 = "";
					bool graphicsInfo = Utils.GetGraphicsInfo(programFilesDir + "\\HD-GLCheck.exe", "2", out text2, out text3, out text4, false) != 0;
					int graphicsInfo2 = Utils.GetGraphicsInfo(programFilesDir + "\\HD-GLCheck.exe", "3", out text2, out text3, out text4, false);
					int graphicsInfo3 = Utils.GetGraphicsInfo(programFilesDir + "\\HD-GLCheck.exe", "1", out text2, out text3, out text4, false);
					string originalString;
					if (!graphicsInfo)
					{
						originalString = "1";
					}
					else
					{
						originalString = "0";
					}
					string originalString2;
					if (graphicsInfo2 == 0)
					{
						originalString2 = "1";
					}
					else
					{
						originalString2 = "0";
					}
					string originalString3;
					if (graphicsInfo3 == 0)
					{
						originalString3 = "1";
					}
					else
					{
						originalString3 = "0";
					}
					dictionary2.Add("dx9check", Stats.GetURLSafeBase64String(originalString));
					dictionary2.Add("dx11check", Stats.GetURLSafeBase64String(originalString2));
					dictionary2.Add("gl_check", Stats.GetURLSafeBase64String(originalString3));
				}
				catch (Exception ex)
				{
					Logger.Error("got exception when checking dxcheck and glcheck for sending to systeminfostats ex:{0}", new object[]
					{
						ex.ToString()
					});
				}
				bool flag = false;
				if (!Utils.CheckTwoCameraPresentOnDevice(ref flag))
				{
					Logger.Error("Check for Two Camera Present on Device Failed");
				}
				Logger.Info("Two Camera present on Device: " + flag.ToString());
				dictionary2.Add("two_camera", flag ? "1" : "0");
				Logger.Info("TwoCamera Value: " + dictionary2["two_camera"]);
				if (guid != null)
				{
					dictionary2.Add("guid", Stats.GetURLSafeBase64String(guid));
				}
				dictionary2.Add("install_id", RegistryManager.Instance.InstallID);
				Logger.Info("Sending System Info Stats");
				vmName = "";
				text = BstHttpClient.Post(url, dictionary2, null, false, vmName, 10000, 1, 0, false);
				Logger.Info("Got System Info  response: {0}", new object[]
				{
					text
				});
				if (createRegKey)
				{
					RegistryManager.Instance.SystemStats = 1;
				}
			}
			catch (Exception ex2)
			{
				Logger.Error(ex2.ToString());
			}
			return text;
		}

		// Token: 0x060008C6 RID: 2246 RVA: 0x000246B0 File Offset: 0x000228B0
		public static void SendFrontendStatusUpdate(string evt, string vmName)
		{
			Logger.Info("SendFrontendStatusUpdate: evt {0}", new object[]
			{
				evt
			});
			Thread thread = new Thread(delegate()
			{
				try
				{
					string arg = string.Format("http://127.0.0.1:{0}", RegistryManager.Instance.AgentServerPort);
					string text = string.Format("{0}/{1}", arg, "FrontendStatusUpdate");
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					dictionary.Add("event", evt);
					Dictionary<string, string> dictionary2 = new Dictionary<string, string>();
					if (!vmName.Equals("Android"))
					{
						dictionary2.Add("vmid", vmName.Split(new char[]
						{
							'_'
						})[1]);
					}
					Logger.Info("Sending FrontendStatusUpdate to {0}", new object[]
					{
						text
					});
					string text2 = BstHttpClient.Post(text, dictionary, dictionary2, false, vmName, 0, 10, 1000, false);
					Logger.Info("Got FrontendStatusUpdate response: {0}", new object[]
					{
						text2
					});
				}
				catch (Exception ex)
				{
					Logger.Error(string.Format("Error Occured, Err : {0}", ex.ToString()));
				}
			});
			thread.IsBackground = true;
			thread.Start();
			if (string.Compare(evt, "frontend-closed", true) == 0)
			{
				thread.Join(200);
			}
		}

		// Token: 0x060008C7 RID: 2247 RVA: 0x00024728 File Offset: 0x00022928
		public static void SendTimelineStats(long agent_timestamp, long sequence, string evt, long duration, string s1, string s2, string s3, string s4, string s5, string s6, string s7, string timezone, string locale, long from_timestamp, long to_timestamp, long from_ticks, long to_ticks, string vmName)
		{
			try
			{
				BstHttpClient.Post(string.Format("{0}/{1}", RegistryManager.Instance.Host, "stats/timelinestats4"), new Dictionary<string, string>
				{
					{
						"agent_timestamp",
						Stats.GetURLSafeBase64String(agent_timestamp.ToString())
					},
					{
						"sequence",
						Stats.GetURLSafeBase64String(sequence.ToString())
					},
					{
						"event",
						Stats.GetURLSafeBase64String(evt)
					},
					{
						"duration",
						Stats.GetURLSafeBase64String(duration.ToString())
					},
					{
						"s1",
						Stats.GetURLSafeBase64String(s1)
					},
					{
						"s2",
						Stats.GetURLSafeBase64String(s2)
					},
					{
						"s3",
						Stats.GetURLSafeBase64String(s3)
					},
					{
						"s4",
						Stats.GetURLSafeBase64String(s4)
					},
					{
						"s5",
						Stats.GetURLSafeBase64String(s5)
					},
					{
						"s6",
						Stats.GetURLSafeBase64String(s6)
					},
					{
						"s7",
						Stats.GetURLSafeBase64String(s7)
					},
					{
						"timezone",
						Stats.GetURLSafeBase64String(timezone)
					},
					{
						"locale",
						Stats.GetURLSafeBase64String(locale)
					},
					{
						"from_timestamp",
						Stats.GetURLSafeBase64String(from_timestamp.ToString())
					},
					{
						"to_timestamp",
						Stats.GetURLSafeBase64String(to_timestamp.ToString())
					},
					{
						"from_ticks",
						Stats.GetURLSafeBase64String(from_ticks.ToString())
					},
					{
						"to_ticks",
						Stats.GetURLSafeBase64String(to_ticks.ToString())
					}
				}, null, false, vmName, 0, 1, 0, false);
			}
			catch (Exception ex)
			{
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x060008C8 RID: 2248 RVA: 0x000248E4 File Offset: 0x00022AE4
		public static void SendBootStats(string type, bool booted, bool wait, string vmName)
		{
			Thread thread = new Thread(delegate()
			{
				string text = string.Format("{0}/{1}", RegistryManager.Instance.Host, "stats/bootstats");
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary.Add("type", Stats.GetURLSafeBase64String(type));
				dictionary.Add("booted", Stats.GetURLSafeBase64String(booted.ToString()));
				try
				{
					Logger.Info("Sending Boot Stats to {0}", new object[]
					{
						text
					});
					string text2 = BstHttpClient.Post(text, dictionary, null, false, vmName, 0, 1, 0, false);
					Logger.Info("Got Boot Stats response: {0}", new object[]
					{
						text2
					});
				}
				catch (Exception ex)
				{
					Logger.Error(ex.ToString());
				}
			});
			thread.IsBackground = true;
			thread.Start();
			if (wait && !thread.Join(5000))
			{
				thread.Abort();
			}
		}

		// Token: 0x060008C9 RID: 2249 RVA: 0x0000963E File Offset: 0x0000783E
		public static void SendHomeScreenDisplayedStats(string vmName)
		{
			new Thread(delegate()
			{
				string text = string.Format("{0}/{1}", RegistryManager.Instance.Host, "stats/homescreenstats");
				try
				{
					Logger.Info("Sending Home Screen Displayed Stats to {0}", new object[]
					{
						text
					});
					string text2 = BstHttpClient.Get(text, null, false, vmName, 0, 1, 0, false);
					Logger.Info("Got Home Screen Displayed Stats response: {0}", new object[]
					{
						text2
					});
				}
				catch (Exception ex)
				{
					Logger.Error(ex.ToString());
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060008CA RID: 2250 RVA: 0x00024940 File Offset: 0x00022B40
		public static void SendBtvFunnelStats(string network, string statEvent, string statDataKey, string statDataValue, bool createNewId, string vmName)
		{
			new Thread(delegate()
			{
				Stats.SendBtvFunnelStatsSync(network, statEvent, statDataKey, statDataValue, createNewId, vmName);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060008CB RID: 2251 RVA: 0x0002499C File Offset: 0x00022B9C
		public static void SendBtvFunnelStatsSync(string network, string statEvent, string statDataKey, string statDataValue, bool createNewId, string vmName)
		{
			string text = string.Format("{0}/{1}", RegistryManager.Instance.Host, "stats/btvfunnelstats");
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary.Add("session_id", Stats.SessionId);
			dictionary.Add("streaming_platform", network);
			dictionary.Add("event_type", statEvent);
			if (statDataKey != null)
			{
				dictionary.Add(statDataKey, statDataValue);
			}
			try
			{
				Logger.Info("Sending Btv Funnel Stats to {0}", new object[]
				{
					text
				});
				vmName = "";
				BstHttpClient.Post(text, dictionary, null, false, vmName, 0, 1, 0, false);
				Logger.Info("Sent Btv Funnel Stats");
			}
			catch (Exception ex)
			{
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x060008CC RID: 2252 RVA: 0x00009668 File Offset: 0x00007868
		public static void SendStyleAndThemeInfoStats(string actionName, string styleName, string themeName, string optionalParam, string vmName)
		{
			Stats.SendStyleAndThemeInfoStatsAsync(actionName, styleName, themeName, optionalParam, vmName);
		}

		// Token: 0x060008CD RID: 2253 RVA: 0x00024A50 File Offset: 0x00022C50
		public static void SendStyleAndThemeInfoStatsAsync(string actionName, string styleName, string themeName, string optionalParam, string vmName)
		{
			new Thread(delegate()
			{
				Stats.SendStyleAndThemeInfoStatsSync(actionName, styleName, themeName, optionalParam, vmName);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060008CE RID: 2254 RVA: 0x00024AA4 File Offset: 0x00022CA4
		public static void SendStyleAndThemeInfoStatsSync(string actionName, string styleName, string themeName, string optionalParam, string vmName)
		{
			try
			{
				Logger.Info("Sending Style and Theme Stats");
				Dictionary<string, string> dictionary = Stats.CollectStyleAndThemeData(actionName, styleName, themeName, optionalParam);
				foreach (KeyValuePair<string, string> keyValuePair in dictionary)
				{
					Logger.Info(keyValuePair.Key + " " + keyValuePair.Value);
				}
				Stats.SendData(string.Format("{0}/{1}", RegistryManager.Instance.Host, "/stats/miscellaneousstats"), dictionary, vmName, 0);
			}
			catch (Exception ex)
			{
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x060008CF RID: 2255 RVA: 0x00024B58 File Offset: 0x00022D58
		public static void SendMiscellaneousStatsSync(string tag, string arg1, string arg2, string arg3, string arg4, string arg5, string arg6 = null, string arg7 = null, string arg8 = null, string vmName = "Android", int timeOut = 0)
		{
			try
			{
				Logger.Info("Sending miscellaneous stats for tag: {0}", new object[]
				{
					tag
				});
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary.Add("tag", tag);
				dictionary.Add("arg1", arg1);
				dictionary.Add("arg2", arg2);
				dictionary.Add("arg3", arg3);
				dictionary.Add("arg4", arg4);
				dictionary.Add("arg5", arg5);
				dictionary.Add("arg6", arg6);
				dictionary.Add("arg7", arg7);
				dictionary.Add("arg8", arg8);
				foreach (KeyValuePair<string, string> keyValuePair in dictionary)
				{
					Logger.Debug(keyValuePair.Key + " " + keyValuePair.Value);
				}
				Stats.SendData(string.Format("{0}/{1}", RegistryManager.Instance.Host, "/stats/miscellaneousstats"), dictionary, vmName, timeOut);
			}
			catch (Exception ex)
			{
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x060008D0 RID: 2256 RVA: 0x00024C84 File Offset: 0x00022E84
		public static void SendMiscellaneousStatsAsync(string tag, string arg1, string arg2, string arg3, string arg4, string arg5, string arg6 = null, string arg7 = null, string arg8 = null, string vmName = "Android", int timeOut = 0)
		{
			new Thread(delegate()
			{
				Stats.SendMiscellaneousStatsSync(tag, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, vmName, timeOut);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060008D1 RID: 2257 RVA: 0x00024D08 File Offset: 0x00022F08
		public static void SendGamingMouseStats(string jsonData, string vmName)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary.Add("dataset_id", "SystemInfoStatsDataset");
			dictionary.Add("table_id", "GamingMouseStats");
			dictionary.Add("body", jsonData);
			foreach (KeyValuePair<string, string> keyValuePair in dictionary)
			{
				Logger.Info(keyValuePair.Key + " " + keyValuePair.Value);
			}
			string url = string.Format("{0}/{1}", RegistryManager.Instance.Host, "bigquery/uploadtobigquery");
			vmName = "";
			Stats.SendData(url, dictionary, vmName, 0);
		}

		// Token: 0x060008D2 RID: 2258 RVA: 0x00024DC8 File Offset: 0x00022FC8
		public static void SendData(string url, Dictionary<string, string> data, string vmName, int timeOut = 0)
		{
			Logger.Info("Sending stats to " + url);
			try
			{
				BstHttpClient.Post(url, data, null, false, vmName, timeOut, 1, 0, false);
			}
			catch (Exception ex)
			{
				Logger.Error(ex.ToString());
			}
			Logger.Info("Sent stats");
		}

		// Token: 0x060008D3 RID: 2259 RVA: 0x00024E1C File Offset: 0x0002301C
		private static Dictionary<string, string> CollectStyleAndThemeData(string actionName, string styleName, string themeName, string optionalParam)
		{
			return new Dictionary<string, string>
			{
				{
					"tag",
					"StyleAndThemeData"
				},
				{
					"arg1",
					RegistryManager.Instance.UserGuid
				},
				{
					"arg2",
					actionName
				},
				{
					"arg3",
					styleName
				},
				{
					"arg4",
					themeName
				},
				{
					"arg5",
					optionalParam
				}
			};
		}

		// Token: 0x170002A2 RID: 674
		// (get) Token: 0x060008D4 RID: 2260 RVA: 0x00024E84 File Offset: 0x00023084
		private static string Timestamp
		{
			get
			{
				long num = DateTime.Now.Ticks - DateTime.Parse("01/01/1970 00:00:00").Ticks;
				return (num / 10000000L).ToString();
			}
		}

		// Token: 0x060008D5 RID: 2261 RVA: 0x00009675 File Offset: 0x00007875
		private static string GetURLSafeBase64String(string originalString)
		{
			return Convert.ToBase64String(Encoding.UTF8.GetBytes(originalString));
		}

		// Token: 0x060008D6 RID: 2262 RVA: 0x00024EC4 File Offset: 0x000230C4
		public static void SendMultiInstanceStats(string vmId, string oem, string returnCode, string cloneType, string eventType, string timeCompletion, string exitCode, bool wait)
		{
			Thread thread = new Thread(delegate()
			{
				string text = string.Format("{0}/{1}", RegistryManager.Instance.Host, "stats/multiinstancestats");
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary.Add("vm_id", Stats.GetURLSafeBase64String(vmId));
				dictionary.Add("oem", Stats.GetURLSafeBase64String(oem));
				dictionary.Add("return_code", Stats.GetURLSafeBase64String(exitCode));
				dictionary.Add("clone_type", Stats.GetURLSafeBase64String(cloneType));
				dictionary.Add("event_type", Stats.GetURLSafeBase64String(eventType));
				dictionary.Add("time_completed", Stats.GetURLSafeBase64String(timeCompletion));
				try
				{
					Logger.Info("Sending MultiInstance Stats to {0}", new object[]
					{
						text
					});
					string text2 = BstHttpClient.Post(text, dictionary, null, false, vmId, 0, 1, 0, false);
					Logger.Info("Got MultiInstance Stats response: {0}", new object[]
					{
						text2
					});
				}
				catch (Exception ex)
				{
					Logger.Error(ex.ToString());
				}
			});
			thread.IsBackground = true;
			thread.Start();
			if (wait && !thread.Join(5000))
			{
				thread.Abort();
			}
		}

		// Token: 0x060008D7 RID: 2263 RVA: 0x00003337 File Offset: 0x00001537
		public static void SendGoogleLoginStatsASync(string name, string id, string vm)
		{
		}

		// Token: 0x060008D8 RID: 2264 RVA: 0x00009687 File Offset: 0x00007887
		public static void SendTroubleshooterStatsASync(string eventType, string issueName, string ver, string vm)
		{
			new Thread(delegate()
			{
				Logger.Info("Sending Troubleshooter stats");
				string url = string.Format("{0}/{1}", RegistryManager.Instance.Host, "stats/troubleshooterlogs");
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary.Add("guid", Utils.GetUserGUID());
				dictionary.Add("prod_ver", RegistryManager.Instance.Version);
				dictionary.Add("issue_name", issueName);
				dictionary.Add("event_type", eventType);
				dictionary.Add("country", Utils.GetUserCountry(vm));
				dictionary.Add("oem", RegistryManager.Instance.Oem);
				dictionary.Add("locale", CultureInfo.CurrentCulture.ToString());
				dictionary.Add("troubleshooter_ver", ver);
				try
				{
					BstHttpClient.Post(url, dictionary, null, false, vm, 5000, 1, 0, false);
				}
				catch (Exception ex)
				{
					Logger.Error(ex.ToString());
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060008D9 RID: 2265 RVA: 0x00024F38 File Offset: 0x00023138
		public static void SendGuidStats(Dictionary<string, string> data, string vm = "")
		{
			Logger.Debug("sending android guid stats");
			string url = string.Format("{0}/bs3/stats/{1}", RegistryManager.Instance.Host, "guid_debug_stats");
			try
			{
				BstHttpClient.Post(url, data, null, false, vm, 5000, 1, 0, false);
			}
			catch (Exception ex)
			{
				Logger.Info("Failed to send guid stats. Ignoring. Err: " + ex.ToString());
			}
		}

		// Token: 0x060008DA RID: 2266 RVA: 0x00024FA8 File Offset: 0x000231A8
		public static Dictionary<string, string> GetUnifiedInstallStatsCommonData()
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary.Add("os", Profile.OS);
			dictionary.Add("oem", "bgp");
			dictionary.Add("guid", RegistryManager.Instance.UserGuid);
			dictionary.Add("email", RegistryManager.Instance.RegisteredEmail);
			dictionary.Add("locale", RegistryManager.Instance.UserSelectedLocale);
			dictionary.Add("install_id", RegistryManager.Instance.InstallID);
			dictionary.Add("campaign_hash", RegistryManager.Instance.CampaignMD5);
			dictionary.Add("campaign_name", RegistryManager.Instance.CampaignName);
			dictionary.Add("client_version", "4.140.12.1002");
			dictionary.Add("engine_version", "4.140.12.1002");
			dictionary.Add("product_version", "4.140.12.1002");
			if (RegistryManager.Instance.InstallationType != InstallationTypes.FullEdition)
			{
				dictionary.Add("installation_type", RegistryManager.Instance.InstallationType.ToString());
				dictionary.Add("gaming_pkg_name", RegistryManager.Instance.InstallerPkgName);
			}
			return dictionary;
		}

		// Token: 0x060008DB RID: 2267 RVA: 0x000096C6 File Offset: 0x000078C6
		public static void SendUnifiedInstallStatsAsync(string eventName, string email = "")
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					Stats.SendUnifiedInstallStats(eventName, email);
				}
				catch (Exception ex)
				{
					Logger.Error("An exception in sending unified install stats. Ex: {0}", new object[]
					{
						ex
					});
				}
			});
		}

		// Token: 0x060008DC RID: 2268 RVA: 0x000250D0 File Offset: 0x000232D0
		public static string SendUnifiedInstallStats(string eventName, string email = "")
		{
			string text = "";
			Dictionary<string, string> unifiedInstallStatsCommonData = Stats.GetUnifiedInstallStatsCommonData();
			unifiedInstallStatsCommonData.Add("event", eventName);
			if (!string.IsNullOrEmpty(email))
			{
				unifiedInstallStatsCommonData["email"] = email;
			}
			try
			{
				HTTPUtils.SendRequestToCloud("/bs3/stats/unified_install_stats", unifiedInstallStatsCommonData, "Android", 0, null, false, 1, 0, false);
				Logger.Debug(string.Format("Response for event {0}: {1}", eventName, text));
			}
			catch (Exception ex)
			{
				Logger.Warning("Failed to send stats for event: {0}, Ex: {1}", new object[]
				{
					eventName,
					ex.Message
				});
			}
			return text;
		}

		// Token: 0x04000671 RID: 1649
		public const string AppInstall = "true";

		// Token: 0x04000672 RID: 1650
		public const string AppUninstall = "false";

		// Token: 0x04000673 RID: 1651
		private static string sSessionId;

		// Token: 0x020000FA RID: 250
		public enum AppType
		{
			// Token: 0x04000675 RID: 1653
			app,
			// Token: 0x04000676 RID: 1654
			market,
			// Token: 0x04000677 RID: 1655
			suggestedapps,
			// Token: 0x04000678 RID: 1656
			web
		}
	}
}
