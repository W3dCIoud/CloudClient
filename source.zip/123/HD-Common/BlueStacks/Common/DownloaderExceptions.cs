﻿using System;
using System.Net;

namespace BlueStacks.Common
{
	// Token: 0x02000152 RID: 338
	internal class DownloaderExceptions
	{
		// Token: 0x02000153 RID: 339
		public class ErrorCodes
		{
			// Token: 0x040007E4 RID: 2020
			public const int Success = 0;

			// Token: 0x040007E5 RID: 2021
			public const int ConnectFailure = 1;

			// Token: 0x040007E6 RID: 2022
			public const int ReceiveFailure = 2;

			// Token: 0x040007E7 RID: 2023
			public const int Timeout = 3;

			// Token: 0x040007E8 RID: 2024
			public const int UnexpectedHttpStatusCode = 4;

			// Token: 0x040007E9 RID: 2025
			public const int ResumeNotSupported = 5;

			// Token: 0x040007EA RID: 2026
			public const int UnknownError = 99;
		}

		// Token: 0x02000154 RID: 340
		[Serializable]
		public class NonResumableStreamException : Exception
		{
			// Token: 0x170002D4 RID: 724
			// (get) Token: 0x06000B5D RID: 2909 RVA: 0x0000A9E6 File Offset: 0x00008BE6
			public override string Message
			{
				get
				{
					return "The remote server does not support partial content stream.";
				}
			}

			// Token: 0x06000B5E RID: 2910 RVA: 0x0000A9ED File Offset: 0x00008BED
			public NonResumableStreamException(HttpStatusCode statusCode)
			{
				this.StatusCode = statusCode;
			}

			// Token: 0x040007EB RID: 2027
			public int ErrorCode = 5;

			// Token: 0x040007EC RID: 2028
			public HttpStatusCode StatusCode = HttpStatusCode.OK;
		}

		// Token: 0x02000155 RID: 341
		[Serializable]
		public class UnexpectedHttpStatusCodeException : Exception
		{
			// Token: 0x170002D5 RID: 725
			// (get) Token: 0x06000B5F RID: 2911 RVA: 0x0000AA0E File Offset: 0x00008C0E
			public override string Message
			{
				get
				{
					return "The remote server returned an unexpected status code.";
				}
			}

			// Token: 0x06000B60 RID: 2912 RVA: 0x0000AA15 File Offset: 0x00008C15
			public UnexpectedHttpStatusCodeException(HttpStatusCode statusCode)
			{
				this.StatusCode = statusCode;
			}

			// Token: 0x040007ED RID: 2029
			public int ErrorCode = 4;

			// Token: 0x040007EE RID: 2030
			public HttpStatusCode StatusCode = HttpStatusCode.OK;
		}

		// Token: 0x02000156 RID: 342
		[Serializable]
		public class ReceiveFailureException : Exception
		{
			// Token: 0x170002D6 RID: 726
			// (get) Token: 0x06000B61 RID: 2913 RVA: 0x0000AA36 File Offset: 0x00008C36
			// (set) Token: 0x06000B62 RID: 2914 RVA: 0x0000AA3E File Offset: 0x00008C3E
			public long BytesRecieved { get; private set; }

			// Token: 0x170002D7 RID: 727
			// (get) Token: 0x06000B63 RID: 2915 RVA: 0x0000AA47 File Offset: 0x00008C47
			public override string Message
			{
				get
				{
					return "A complete response was not received from the remote server.";
				}
			}

			// Token: 0x06000B64 RID: 2916 RVA: 0x0000AA4E File Offset: 0x00008C4E
			public ReceiveFailureException(long bytesRecieved, Exception innerException) : base("", innerException)
			{
				this.BytesRecieved = bytesRecieved;
			}

			// Token: 0x040007EF RID: 2031
			public int ErrorCode = 2;
		}

		// Token: 0x02000157 RID: 343
		[Serializable]
		public class NoResponseStreamException : Exception
		{
			// Token: 0x170002D8 RID: 728
			// (get) Token: 0x06000B65 RID: 2917 RVA: 0x0000AA6A File Offset: 0x00008C6A
			// (set) Token: 0x06000B66 RID: 2918 RVA: 0x0000AA72 File Offset: 0x00008C72
			public long BytesRecieved { get; private set; }

			// Token: 0x170002D9 RID: 729
			// (get) Token: 0x06000B67 RID: 2919 RVA: 0x0000AA7B File Offset: 0x00008C7B
			public override string Message
			{
				get
				{
					return "Could not get a response stream from the remote server.";
				}
			}

			// Token: 0x06000B68 RID: 2920 RVA: 0x0000AA82 File Offset: 0x00008C82
			public NoResponseStreamException(Exception innerException) : base("", innerException)
			{
			}

			// Token: 0x040007F1 RID: 2033
			public int ErrorCode = 2;
		}

		// Token: 0x02000158 RID: 344
		[Serializable]
		public class UnknownErrorException : Exception
		{
			// Token: 0x170002DA RID: 730
			// (get) Token: 0x06000B69 RID: 2921 RVA: 0x0000AA97 File Offset: 0x00008C97
			public override string Message
			{
				get
				{
					return "An exception of an unknown type has occurred.";
				}
			}

			// Token: 0x06000B6A RID: 2922 RVA: 0x0000AA9E File Offset: 0x00008C9E
			public UnknownErrorException(Exception innerException) : base("", innerException)
			{
			}

			// Token: 0x040007F3 RID: 2035
			public int ErrorCode = 99;
		}

		// Token: 0x02000159 RID: 345
		[Serializable]
		public class TimeoutException : Exception
		{
			// Token: 0x170002DB RID: 731
			// (get) Token: 0x06000B6B RID: 2923 RVA: 0x0000AAB4 File Offset: 0x00008CB4
			public override string Message
			{
				get
				{
					return "No response was received during the time-out period for the request.";
				}
			}

			// Token: 0x040007F4 RID: 2036
			public int ErrorCode = 3;
		}

		// Token: 0x0200015A RID: 346
		[Serializable]
		public class ConnectFailureException : Exception
		{
			// Token: 0x170002DC RID: 732
			// (get) Token: 0x06000B6D RID: 2925 RVA: 0x0000AACA File Offset: 0x00008CCA
			public override string Message
			{
				get
				{
					return "The remote service point could not be contacted.";
				}
			}

			// Token: 0x06000B6E RID: 2926 RVA: 0x0000AAD1 File Offset: 0x00008CD1
			public ConnectFailureException(Exception innerException) : base("", innerException)
			{
			}

			// Token: 0x040007F5 RID: 2037
			public int ErrorCode = 1;
		}
	}
}
