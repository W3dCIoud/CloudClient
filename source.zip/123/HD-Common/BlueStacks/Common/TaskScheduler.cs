﻿using System;
using System.Globalization;
using System.Reflection;

namespace BlueStacks.Common
{
	// Token: 0x0200008F RID: 143
	public class TaskScheduler
	{
		// Token: 0x060002E0 RID: 736 RVA: 0x0001238C File Offset: 0x0001058C
		public static int CreateTask(string taskName, string binaryToRun, Tasks.Frequency frequency, int modifierOrIdleTime, DateTime timeToStart)
		{
			if (string.IsNullOrEmpty(binaryToRun))
			{
				binaryToRun = Assembly.GetEntryAssembly().Location;
			}
			DateTimeFormatInfo dateTimeFormat = new CultureInfo("en-US", false).DateTimeFormat;
			string text = string.Format(string.Concat(new string[]
			{
				"/",
				Tasks.Parameter.Create.ToString(),
				" /SC ",
				frequency.ToString(),
				" /TN ",
				taskName,
				string.Format(" /TR \"{0}\"", binaryToRun),
				" /F"
			}), new object[0]);
			if (frequency != Tasks.Frequency.ONIDLE)
			{
				text = string.Format("{0} /ST {1}", text, timeToStart.ToString("HH:mm", dateTimeFormat));
				text = string.Format("{0} /MO {1}", text, modifierOrIdleTime.ToString());
			}
			else
			{
				text = string.Format("{0} /I " + modifierOrIdleTime.ToString(), text);
			}
			int num = TaskScheduler.RunSchedulerCommand(text);
			if (num != 0)
			{
				Logger.Error("An error occured while creating the task, exit code: {0}", new object[]
				{
					num
				});
			}
			return num;
		}

		// Token: 0x060002E1 RID: 737 RVA: 0x00012498 File Offset: 0x00010698
		public static int DeleteTask(string taskName)
		{
			int num = TaskScheduler.RunSchedulerCommand(string.Format(string.Concat(new string[]
			{
				"/",
				Tasks.Parameter.Delete.ToString(),
				" /TN ",
				taskName,
				" /F"
			}), new object[0]));
			if (num != 0)
			{
				Logger.Error("An error occured while deleting the task, exit code: {0}", new object[]
				{
					num
				});
			}
			return num;
		}

		// Token: 0x060002E2 RID: 738 RVA: 0x0001250C File Offset: 0x0001070C
		private static string QueryTaskArguments(string taskName)
		{
			return string.Format("/" + Tasks.Parameter.Query.ToString() + " /FO LIST /V  /TN " + taskName, new object[0]);
		}

		// Token: 0x060002E3 RID: 739 RVA: 0x00012544 File Offset: 0x00010744
		public static int QueryTask(string taskName)
		{
			int num = TaskScheduler.RunSchedulerCommand(TaskScheduler.QueryTaskArguments(taskName));
			if (num != 0)
			{
				Logger.Error("An error occured while querying the task, exit code: {0}", new object[]
				{
					num
				});
			}
			return num;
		}

		// Token: 0x060002E4 RID: 740 RVA: 0x0000392D File Offset: 0x00001B2D
		private static int RunSchedulerCommand(string args)
		{
			return RunCommand.RunCmd(TaskScheduler.BinaryName, args, true, true, false, 0).ExitCode;
		}

		// Token: 0x060002E5 RID: 741 RVA: 0x00003943 File Offset: 0x00001B43
		public static RunCommand.CmdRes GetTaskQueryCommandOutput(string taskName)
		{
			return RunCommand.RunCmd(TaskScheduler.BinaryName, TaskScheduler.QueryTaskArguments(taskName), false, true, false, 0);
		}

		// Token: 0x04000358 RID: 856
		private static string BinaryName = "schtasks.exe";
	}
}
