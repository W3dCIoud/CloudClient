﻿using System;
using System.Diagnostics;
using System.IO;

namespace BlueStacks.Common
{
	// Token: 0x02000073 RID: 115
	public class ServiceInstaller
	{
		// Token: 0x0600029A RID: 666 RVA: 0x00011B00 File Offset: 0x0000FD00
		public static int ReinstallService()
		{
			string args = "-reinstall -oem bgp";
			Process process = ProcessUtils.StartExe(ServiceInstaller.BinaryName, args, true);
			process.WaitForExit();
			return process.ExitCode;
		}

		// Token: 0x04000182 RID: 386
		private static string BinaryName = Path.Combine(RegistryStrings.InstallDir, "HD-ServiceInstaller.exe");
	}
}
