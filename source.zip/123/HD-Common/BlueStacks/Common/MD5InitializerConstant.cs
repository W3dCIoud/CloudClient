﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000186 RID: 390
	public enum MD5InitializerConstant : uint
	{
		// Token: 0x040009AD RID: 2477
		A = 1732584193U,
		// Token: 0x040009AE RID: 2478
		B = 4023233417U,
		// Token: 0x040009AF RID: 2479
		C = 2562383102U,
		// Token: 0x040009B0 RID: 2480
		D = 271733878U
	}
}
