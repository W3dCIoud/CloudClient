﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using Microsoft.Win32;

namespace BlueStacks.Common
{
	// Token: 0x0200006A RID: 106
	public partial class NotificationWindow : Window
	{
		// Token: 0x06000250 RID: 592
		[DllImport("user32.dll")]
		public static extern IntPtr GetWindowLong(IntPtr hWnd, int nIndex);

		// Token: 0x06000251 RID: 593 RVA: 0x00010EB8 File Offset: 0x0000F0B8
		public static IntPtr SetWindowLong(IntPtr hWnd, int nIndex, IntPtr dwNewLong)
		{
			IntPtr intPtr = IntPtr.Zero;
			NotificationWindow.SetLastError(0);
			int lastWin32Error;
			if (IntPtr.Size == 4)
			{
				int value = NotificationWindow.IntSetWindowLong(hWnd, nIndex, NotificationWindow.IntPtrToInt32(dwNewLong));
				lastWin32Error = Marshal.GetLastWin32Error();
				intPtr = new IntPtr(value);
			}
			else
			{
				intPtr = NotificationWindow.IntSetWindowLongPtr(hWnd, nIndex, dwNewLong);
				lastWin32Error = Marshal.GetLastWin32Error();
			}
			if (intPtr == IntPtr.Zero && lastWin32Error != 0)
			{
				throw new Win32Exception(lastWin32Error);
			}
			return intPtr;
		}

		// Token: 0x06000252 RID: 594
		[DllImport("user32.dll", EntryPoint = "SetWindowLongPtr", SetLastError = true)]
		private static extern IntPtr IntSetWindowLongPtr(IntPtr hWnd, int nIndex, IntPtr dwNewLong);

		// Token: 0x06000253 RID: 595
		[DllImport("user32.dll", EntryPoint = "SetWindowLong", SetLastError = true)]
		private static extern int IntSetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

		// Token: 0x06000254 RID: 596 RVA: 0x00003343 File Offset: 0x00001543
		private static int IntPtrToInt32(IntPtr intPtr)
		{
			return (int)intPtr.ToInt64();
		}

		// Token: 0x06000255 RID: 597
		[DllImport("kernel32.dll")]
		public static extern void SetLastError(int dwErrorCode);

		// Token: 0x06000256 RID: 598 RVA: 0x00003337 File Offset: 0x00001537
		private void NotificationWindow_Loaded(object sender, RoutedEventArgs e)
		{
		}

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x06000257 RID: 599 RVA: 0x0000334D File Offset: 0x0000154D
		public static NotificationWindow Instance
		{
			get
			{
				if (NotificationWindow.mInstance == null)
				{
					NotificationWindow.Init();
				}
				return NotificationWindow.mInstance;
			}
		}

		// Token: 0x06000258 RID: 600 RVA: 0x00003360 File Offset: 0x00001560
		public static void Init()
		{
			NotificationWindow.mInstance = new NotificationWindow();
			SystemEvents.DisplaySettingsChanged -= NotificationWindow.mInstance.HandleDisplaySettingsChanged;
			SystemEvents.DisplaySettingsChanged += NotificationWindow.mInstance.HandleDisplaySettingsChanged;
		}

		// Token: 0x06000259 RID: 601 RVA: 0x00010F20 File Offset: 0x0000F120
		private NotificationWindow()
		{
			this.InitializeComponent();
			base.Height = SystemParameters.FullPrimaryScreenHeight;
			base.Width = SystemParameters.FullPrimaryScreenWidth * 0.2;
			base.Left = SystemParameters.FullPrimaryScreenWidth - base.Width;
			base.Top = 0.0;
		}

		// Token: 0x0600025A RID: 602 RVA: 0x00010F8C File Offset: 0x0000F18C
		public void HandleDisplaySettingsChanged(object sender, EventArgs e)
		{
			try
			{
				base.Height = SystemParameters.FullPrimaryScreenHeight;
				base.Width = SystemParameters.FullPrimaryScreenWidth * 0.2;
				base.Left = SystemParameters.FullPrimaryScreenWidth * base.Width;
				base.Top = 0.0;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in HandleDisplaySettingsChanged. Exception: " + ex.ToString());
			}
		}

		// Token: 0x0600025B RID: 603 RVA: 0x00011004 File Offset: 0x0000F204
		public void AddAlert(string imagePath, string title, string displayMsg, bool autoClose, int duration, MouseButtonEventHandler clickHandler, bool hideMute, string vmName, bool isCloudNotification, MouseButtonEventHandler buttonClickHandler = null, MouseButtonEventHandler closeButtonHandler = null, MouseButtonEventHandler muteButtonHandler = null, bool showOnlyMute = false, string buttonText = "")
		{
			if (this.mIsPopupsEnabled)
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					MuteState muteState = NotificationManager.Instance.IsShowNotificationForKey(title);
					if (muteState == MuteState.NotMuted || muteState == MuteState.AutoHide)
					{
						if (this.Visibility == Visibility.Collapsed || this.Visibility == Visibility.Hidden)
						{
							this.Show();
						}
						if (this.mDictPopups.ContainsKey(title.ToUpper()))
						{
							this.RemovePopup(this.mDictPopups[title.ToUpper()]);
						}
						if (this.mDictPopups.Count >= 5)
						{
							this.RemovePopup((NotificationPopup)this.mStackPanel.Children[0]);
						}
						if (muteState == MuteState.AutoHide && !isCloudNotification)
						{
							autoClose = true;
							duration = 10000;
						}
						else
						{
							autoClose = false;
						}
						NotificationPopup notificationPopup = NotificationPopup.InitPopup(imagePath, title, displayMsg, autoClose, duration, clickHandler, hideMute, vmName, buttonClickHandler, closeButtonHandler, muteButtonHandler, showOnlyMute, buttonText);
						this.mStackPanel.Children.Add(notificationPopup);
						this.mDictPopups.Add(title.ToUpper(), notificationPopup);
					}
				}), new object[0]);
			}
		}

		// Token: 0x0600025C RID: 604 RVA: 0x000110B4 File Offset: 0x0000F2B4
		public void ForceShowAlert(string imagePath, string title, string displayMsg, bool autoClose, int duration, MouseButtonEventHandler clickHandler, bool hideMute, string vmName, bool isCloudNotification, MouseButtonEventHandler buttonClickHandler = null, MouseButtonEventHandler closeButtonHandler = null, MouseButtonEventHandler muteButtonHandler = null, bool showOnlyMute = false, string buttonText = "")
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				NotificationPopup notificationPopup = NotificationPopup.InitPopup(imagePath, title, displayMsg, autoClose, duration, clickHandler, hideMute, vmName, buttonClickHandler, closeButtonHandler, muteButtonHandler, showOnlyMute, buttonText);
				this.mStackPanel.Children.Add(notificationPopup);
				this.mDictPopups.Add(title.ToUpper(), notificationPopup);
				this.Topmost = false;
			}), new object[0]);
		}

		// Token: 0x0600025D RID: 605 RVA: 0x00011154 File Offset: 0x0000F354
		internal void RemovePopup(NotificationPopup popup)
		{
			this.mDictPopups.Remove(popup.Title.ToUpper());
			popup.mPopup.IsOpen = false;
			if (this.mStackPanel.Children.Contains(popup))
			{
				this.mStackPanel.Children.Remove(popup);
			}
			if (this.mDictPopups.Count == 0)
			{
				base.Hide();
			}
		}

		// Token: 0x0600025E RID: 606 RVA: 0x000111BC File Offset: 0x0000F3BC
		public void EnablePopups(bool visible)
		{
			if (visible)
			{
				this.mIsPopupsEnabled = true;
				return;
			}
			this.mIsPopupsEnabled = false;
			foreach (NotificationPopup popup in this.mDictPopups.Values.ToArray<NotificationPopup>())
			{
				this.RemovePopup(popup);
			}
		}

		// Token: 0x0400013E RID: 318
		private const int MAX_ALLOWED_NOTIFICATION = 5;

		// Token: 0x0400013F RID: 319
		private Dictionary<string, NotificationPopup> mDictPopups = new Dictionary<string, NotificationPopup>();

		// Token: 0x04000140 RID: 320
		private bool mIsPopupsEnabled = true;

		// Token: 0x04000141 RID: 321
		private static NotificationWindow mInstance;

		// Token: 0x0200006B RID: 107
		[Flags]
		public enum ExtendedWindowStyles
		{
			// Token: 0x04000145 RID: 325
			WS_EX_TOOLWINDOW = 128
		}

		// Token: 0x0200006C RID: 108
		public enum GetWindowLongFields
		{
			// Token: 0x04000147 RID: 327
			GWL_EXSTYLE = -20
		}
	}
}
