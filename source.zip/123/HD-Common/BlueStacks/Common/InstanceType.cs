﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000CE RID: 206
	public enum InstanceType
	{
		// Token: 0x0400050B RID: 1291
		engg,
		// Token: 0x0400050C RID: 1292
		preprod,
		// Token: 0x0400050D RID: 1293
		dev,
		// Token: 0x0400050E RID: 1294
		qa,
		// Token: 0x0400050F RID: 1295
		prod
	}
}
