﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Net;
using System.Threading;

namespace BlueStacks.Common
{
	// Token: 0x0200005A RID: 90
	public class HTTPServer
	{
		// Token: 0x17000089 RID: 137
		// (get) Token: 0x060001ED RID: 493 RVA: 0x00002F90 File Offset: 0x00001190
		public int Port
		{
			get
			{
				return this.mPort;
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x060001EE RID: 494 RVA: 0x00002F98 File Offset: 0x00001198
		public Dictionary<string, HTTPServer.RequestHandler> Routes
		{
			get
			{
				return this.mRoutes;
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x060001EF RID: 495 RVA: 0x00002FA0 File Offset: 0x000011A0
		// (set) Token: 0x060001F0 RID: 496 RVA: 0x00002FA8 File Offset: 0x000011A8
		public string RootDir
		{
			get
			{
				return this.mRootDir;
			}
			set
			{
				this.mRootDir = value;
			}
		}

		// Token: 0x060001F1 RID: 497 RVA: 0x00002FB1 File Offset: 0x000011B1
		public HTTPServer(int port, Dictionary<string, HTTPServer.RequestHandler> routes, string rootDir)
		{
			this.mPort = port;
			this.mRoutes = routes;
			this.mRootDir = rootDir;
		}

		// Token: 0x060001F2 RID: 498 RVA: 0x0000F4AC File Offset: 0x0000D6AC
		public void Start()
		{
			string uriPrefix = string.Format("http://{0}:{1}/", "*", this.mPort);
			this.mListener = new HttpListener();
			this.mListener.Prefixes.Add(uriPrefix);
			try
			{
				this.mShutDown = false;
				this.mListener.Start();
			}
			catch (HttpListenerException ex)
			{
				Logger.Error("Failed to start listener. err: " + ex.ToString());
				throw new HTTPServer.ENoPortAvailable(string.Format("No free port available", new object[0]));
			}
		}

		// Token: 0x060001F3 RID: 499 RVA: 0x0000F540 File Offset: 0x0000D740
		public void Run()
		{
			while (!this.mShutDown)
			{
				HttpListenerContext ctx = null;
				try
				{
					ctx = this.mListener.GetContext();
				}
				catch (Exception ex)
				{
					Logger.Error("Exception while processing HTTP context: " + ex.ToString());
					continue;
				}
				ThreadPool.QueueUserWorkItem(new WaitCallback(new HTTPServer.Worker(ctx, this.Routes, this.RootDir).ProcessRequest));
			}
		}

		// Token: 0x060001F4 RID: 500 RVA: 0x0000F5B4 File Offset: 0x0000D7B4
		public void Stop()
		{
			if (this.mListener != null)
			{
				try
				{
					this.mShutDown = true;
					this.mListener.Close();
				}
				catch (HttpListenerException ex)
				{
					Logger.Error("Failed to stop listener. err: " + ex.ToString());
				}
			}
		}

		// Token: 0x040000F5 RID: 245
		private HttpListener mListener;

		// Token: 0x040000F6 RID: 246
		private bool mShutDown;

		// Token: 0x040000F7 RID: 247
		public static bool sFileWriteComplete = true;

		// Token: 0x040000F8 RID: 248
		private int mPort;

		// Token: 0x040000F9 RID: 249
		private Dictionary<string, HTTPServer.RequestHandler> mRoutes;

		// Token: 0x040000FA RID: 250
		private string mRootDir;

		// Token: 0x0200005B RID: 91
		// (Invoke) Token: 0x060001F7 RID: 503
		public delegate void RequestHandler(HttpListenerRequest req, HttpListenerResponse res);

		// Token: 0x0200005C RID: 92
		public class ENoPortAvailable : Exception
		{
			// Token: 0x060001FA RID: 506 RVA: 0x00002FD6 File Offset: 0x000011D6
			public ENoPortAvailable(string reason) : base(reason)
			{
			}
		}

		// Token: 0x0200005D RID: 93
		private class Worker
		{
			// Token: 0x060001FB RID: 507 RVA: 0x00002FDF File Offset: 0x000011DF
			public Worker(HttpListenerContext ctx, Dictionary<string, HTTPServer.RequestHandler> routes, string rootDir)
			{
				this.mCtx = ctx;
				this.mRoutes = routes;
				this.mRootDir = rootDir;
			}

			// Token: 0x060001FC RID: 508 RVA: 0x0000F608 File Offset: 0x0000D808
			[STAThread]
			public void ProcessRequest(object stateInfo)
			{
				try
				{
					if (this.mCtx.Request.Url.AbsolutePath.StartsWith("/static/"))
					{
						this.StaticFileHandler(this.mCtx.Request, this.mCtx.Response);
					}
					else if (this.mCtx.Request.Url.AbsolutePath.StartsWith("/static2/"))
					{
						this.StaticFileChunkHandler(this.mCtx.Request, this.mCtx.Response, "");
					}
					else if (this.mCtx.Request.Url.AbsolutePath.StartsWith("/staticicon/"))
					{
						this.StaticFileChunkHandler(this.mCtx.Request, this.mCtx.Response, Path.Combine(RegistryManager.Instance.EngineDataDir, "UserData\\Gadget"));
					}
					else if (this.mRoutes.ContainsKey(this.mCtx.Request.Url.AbsolutePath))
					{
						HTTPServer.RequestHandler requestHandler = this.mRoutes[this.mCtx.Request.Url.AbsolutePath];
						if (requestHandler != null)
						{
							if (this.mCtx.Request.UserAgent != null)
							{
								Logger.Info("Request received {0}", new object[]
								{
									this.mCtx.Request.Url.AbsolutePath
								});
								Logger.Debug("UserAgent = {0}", new object[]
								{
									this.mCtx.Request.UserAgent
								});
							}
							if (this.IsTokenValid(this.mCtx.Request.Headers))
							{
								requestHandler(this.mCtx.Request, this.mCtx.Response);
							}
							else
							{
								Logger.Warning("Token validation check failed, unauthorized access");
								HTTPUtils.WriteErrorJson(this.mCtx.Response, "Unauthorized Access(401)");
								this.mCtx.Response.StatusCode = 401;
							}
						}
					}
					else
					{
						Logger.Warning("Exception: No Handler registered for " + this.mCtx.Request.Url.AbsolutePath);
						HTTPUtils.WriteErrorJson(this.mCtx.Response, "Request NotFound(404)");
						this.mCtx.Response.StatusCode = 404;
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception while processing HTTP handler: " + ex.ToString());
					HTTPUtils.WriteErrorJson(this.mCtx.Response, "Internal Server Error(500)");
					this.mCtx.Response.StatusCode = 500;
				}
				finally
				{
					try
					{
						this.mCtx.Response.OutputStream.Close();
					}
					catch (Exception ex2)
					{
						Logger.Warning("Exception during mCtx.Response.OutputStream.Close(): " + ex2.ToString());
					}
				}
			}

			// Token: 0x060001FD RID: 509 RVA: 0x00002FFC File Offset: 0x000011FC
			private bool IsTokenValid(NameValueCollection headers)
			{
				return headers["x_api_token"] != null && headers["x_api_token"].ToString().Equals(RegistryManager.Instance.ApiToken);
			}

			// Token: 0x060001FE RID: 510 RVA: 0x0000F91C File Offset: 0x0000DB1C
			public void StaticFileHandler(HttpListenerRequest req, HttpListenerResponse res)
			{
				string text = req.Url.AbsolutePath;
				text = text.Substring(text.Substring(1).IndexOf("/") + 2);
				string text2 = Path.Combine(this.mRootDir, text.Replace("/", "\\"));
				if (File.Exists(text2))
				{
					byte[] array = File.ReadAllBytes(text2);
					if (text2.EndsWith(".css"))
					{
						res.Headers.Add("Content-Type: text/css");
					}
					else if (text2.EndsWith(".js"))
					{
						res.Headers.Add("Content-Type: application/javascript");
					}
					res.OutputStream.Write(array, 0, array.Length);
					return;
				}
				Logger.Error(string.Format("File {0} doesn't exist", text2));
				res.StatusCode = 404;
				res.StatusDescription = "Not Found.";
			}

			// Token: 0x060001FF RID: 511 RVA: 0x0000F9F0 File Offset: 0x0000DBF0
			public void StaticFileChunkHandler(HttpListenerRequest req, HttpListenerResponse res, string dir = "")
			{
				string text = req.Url.AbsolutePath;
				text = text.Substring(text.Substring(1).IndexOf("/") + 2);
				string text2;
				if (string.IsNullOrEmpty(dir))
				{
					text2 = Path.Combine(this.mRootDir, text.Replace("/", "\\"));
				}
				else
				{
					text2 = Path.Combine(dir, text.Replace("/", "\\"));
				}
				Logger.Info(string.Format("StaticFileChunkHandler: serving {0} from {1}", req.Url, text2));
				int num = 50;
				while (!File.Exists(text2))
				{
					num++;
					Thread.Sleep(100);
					if (num == 50)
					{
						break;
					}
				}
				num = 0;
				if (File.Exists(text2))
				{
					if (text2.EndsWith(".flv"))
					{
						res.Headers.Add("Content-Type: video/x-flv");
					}
					int num2 = 1048576;
					FileStream fileStream = new FileStream(text2, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
					for (;;)
					{
						byte[] buffer = new byte[num2];
						int num3 = fileStream.Read(buffer, 0, num2);
						if (num3 != 0)
						{
							res.OutputStream.Write(buffer, 0, num3);
							num = 0;
						}
						else
						{
							Thread.Sleep(100);
							if (num++ == 50)
							{
								break;
							}
						}
					}
					fileStream.Close();
					return;
				}
				Logger.Error(string.Format("File {0} doesn't exist", text2));
				res.StatusCode = 404;
				res.StatusDescription = "Not Found.";
			}

			// Token: 0x040000FB RID: 251
			private Dictionary<string, HTTPServer.RequestHandler> mRoutes;

			// Token: 0x040000FC RID: 252
			private HttpListenerContext mCtx;

			// Token: 0x040000FD RID: 253
			private string mRootDir;
		}
	}
}
