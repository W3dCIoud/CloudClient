﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x02000052 RID: 82
	public static class ConfigConverter
	{
		// Token: 0x060001CE RID: 462 RVA: 0x0000E638 File Offset: 0x0000C838
		public static bool Convert(string oldConfigPath, string newConfigPath, string newVersion, bool isBuiltIn, bool useCustomName)
		{
			bool result;
			try
			{
				JObject jobject = JObject.Parse(File.ReadAllText(oldConfigPath));
				int? configVersion = ConfigConverter.GetConfigVersion(jobject);
				int num = 13;
				if (configVersion.GetValueOrDefault() <= num & configVersion != null)
				{
					JObject jobject2 = ConfigConverter.Convert(jobject, newVersion, isBuiltIn, useCustomName);
					if (jobject2 != null)
					{
						File.WriteAllText(newConfigPath, jobject2.ToString());
						return true;
					}
				}
				result = false;
			}
			catch (Exception ex)
			{
				Logger.Error(string.Format("Error while parsing config file {0}", oldConfigPath), new object[]
				{
					ex.Message
				});
				result = false;
			}
			return result;
		}

		// Token: 0x060001CF RID: 463 RVA: 0x0000E6D0 File Offset: 0x0000C8D0
		public static JObject Convert(JObject oldConfigJson, string newVersion, bool isBuiltIn, bool useCustomName)
		{
			if (useCustomName)
			{
				ConfigConverter.DEFAULT_PROFILE_NAME = "Custom";
			}
			List<string> list = new List<string>();
			JArray jarray;
			if ((jarray = (oldConfigJson["Primitives"] as JArray)) != null)
			{
				using (IEnumerator<JToken> enumerator = jarray.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						JArray jarray2;
						if ((jarray2 = (enumerator.Current["Tags"] as JArray)) != null)
						{
							foreach (JToken jtoken in jarray2)
							{
								list.Add(jtoken.ToString());
							}
						}
					}
				}
			}
			list = list.Distinct<string>().ToList<string>();
			string text = string.Empty;
			JArray jarray3 = new JArray();
			if (list.Count<string>() == 0)
			{
				jarray3.Add(new JObject
				{
					{
						"Name",
						ConfigConverter.DEFAULT_PROFILE_NAME
					},
					{
						"BuiltIn",
						isBuiltIn
					},
					{
						"Selected",
						true
					},
					{
						"IsBookMarked",
						false
					},
					{
						"KeyboardLayout",
						oldConfigJson["MetaData"]["KeyboardLayout"]
					},
					{
						"GameControls",
						new JArray()
					},
					{
						"Images",
						new JArray()
					}
				});
			}
			else
			{
				JArray source;
				if (oldConfigJson["Schemes"] != null && (source = (oldConfigJson["Schemes"] as JArray)) != null && source.Count<JToken>() > 0)
				{
					JToken jtoken2 = (from scheme in oldConfigJson["Schemes"]
					where bool.Parse(scheme["Selected"].ToString())
					select scheme).FirstOrDefault<JToken>();
					if (jtoken2 != null && jtoken2["Tag"] != null)
					{
						text = jtoken2["Tag"].ToString();
					}
				}
				foreach (string text2 in list)
				{
					jarray3.Add(new JObject
					{
						{
							"Name",
							text2.ToString()
						},
						{
							"BuiltIn",
							isBuiltIn
						},
						{
							"Selected",
							string.Equals(text, text2.ToString())
						},
						{
							"IsBookMarked",
							false
						},
						{
							"KeyboardLayout",
							oldConfigJson["MetaData"]["KeyboardLayout"]
						},
						{
							"GameControls",
							new JArray()
						},
						{
							"Images",
							new JArray()
						}
					});
				}
				if (string.IsNullOrEmpty(text))
				{
					jarray3[0]["Selected"] = true;
				}
			}
			foreach (JToken jtoken3 in ((IEnumerable<JToken>)oldConfigJson["Primitives"]))
			{
				JObject jobject = jtoken3.DeepClone() as JObject;
				if (jobject != null)
				{
					List<string> tags = new List<string>();
					if (jobject["Tags"] != null)
					{
						jobject["Tags"].ToList<JToken>().ForEach(delegate(JToken x)
						{
							tags.Add(x.ToString());
						});
						jobject["Tags"].Parent.Remove();
					}
					ConfigConverter.ConvertComboSequences(jobject);
					ConfigConverter.UpdateTiltAndStatePrimitives(jobject);
					if (tags.Count<string>() == 0)
					{
						ConfigConverter.AddPrimitiveToGameControls(jarray3, jobject);
					}
					else
					{
						ConfigConverter.AddPrimitiveToGameControls(from scheme in jarray3.ToList<JToken>()
						where tags.Contains(scheme["Name"].ToString())
						select scheme, jobject);
					}
				}
			}
			if (!string.IsNullOrEmpty(text) && !list.Contains(text))
			{
				jarray3.Add(new JObject
				{
					{
						"Name",
						text
					},
					{
						"BuiltIn",
						isBuiltIn
					},
					{
						"Selected",
						true
					},
					{
						"IsBookMarked",
						false
					},
					{
						"KeyboardLayout",
						oldConfigJson["MetaData"]["KeyboardLayout"]
					},
					{
						"GameControls",
						new JArray()
					},
					{
						"Images",
						new JArray()
					}
				});
			}
			return new JObject
			{
				{
					"MetaData",
					ConfigConverter.GetMetadata(oldConfigJson["MetaData"], newVersion)
				},
				{
					"ControlSchemes",
					jarray3
				},
				{
					"Strings",
					oldConfigJson["Strings"].DeepClone()
				}
			};
		}

		// Token: 0x060001D0 RID: 464 RVA: 0x0000EBB8 File Offset: 0x0000CDB8
		public static int? GetConfigVersion(string config)
		{
			int? result;
			try
			{
				result = ConfigConverter.GetConfigVersion(JObject.Parse(File.ReadAllText(config)));
			}
			catch (Exception ex)
			{
				Logger.Error(string.Format("Error while parsing config file {0}", config), new object[]
				{
					ex.Message
				});
				result = null;
			}
			return result;
		}

		// Token: 0x060001D1 RID: 465 RVA: 0x0000EC18 File Offset: 0x0000CE18
		public static int? GetConfigVersion(JObject configJson)
		{
			int value;
			if (configJson != null && configJson["MetaData"] != null && configJson["MetaData"]["ParserVersion"] != null && int.TryParse(configJson["MetaData"]["ParserVersion"].ToString(), out value))
			{
				return new int?(value);
			}
			return null;
		}

		// Token: 0x060001D2 RID: 466 RVA: 0x0000EC80 File Offset: 0x0000CE80
		private static void AddPrimitiveToGameControls(IEnumerable<JToken> controlSchemes, JToken primitiveCopy)
		{
			controlSchemes.ToList<JToken>().ForEach(delegate(JToken scheme)
			{
				JArray jarray;
				if ((jarray = (scheme["GameControls"] as JArray)) != null)
				{
					jarray.Add(primitiveCopy);
				}
			});
		}

		// Token: 0x060001D3 RID: 467 RVA: 0x00002E61 File Offset: 0x00001061
		private static JObject GetMetadata(JToken oldMetadata, string newVersion)
		{
			return new JObject
			{
				{
					"ParserVersion",
					newVersion
				},
				{
					"Comment",
					string.Format("Generated automatically from ver {0}", oldMetadata["ParserVersion"])
				}
			};
		}

		// Token: 0x060001D4 RID: 468 RVA: 0x0000ECB4 File Offset: 0x0000CEB4
		private static void ConvertComboSequences(JObject primitive)
		{
			if (primitive["Type"] != null && string.Equals(primitive["Type"].ToString(), "Combo"))
			{
				primitive.Add("X", ConfigConverter.GetLocationForPoint(ConfigConverter.mScriptCol, ConfigConverter.mMaxRowCol));
				primitive.Add("Y", ConfigConverter.GetLocationForPoint(ConfigConverter.mScriptRow, ConfigConverter.mMaxRowCol));
				ConfigConverter.mScriptCol++;
				if (ConfigConverter.mScriptCol == ConfigConverter.mMaxRowCol)
				{
					ConfigConverter.mScriptRow++;
					ConfigConverter.mScriptRow %= ConfigConverter.mMaxRowCol;
				}
				ConfigConverter.mScriptCol %= ConfigConverter.mMaxRowCol;
				primitive["Type"] = "Script";
				primitive["$type"] = "Script, Bluestacks";
				primitive["IsVisibleInOverlay"] = true;
				primitive["ShowOnOverlay"] = true;
				primitive.Add("Comment", primitive["Description"]);
				primitive["Description"].Parent.Remove();
				JArray jarray;
				if (primitive["Events"] != null && (jarray = (primitive["Events"] as JArray)) != null)
				{
					JArray jarray2 = new JArray();
					int num = 0;
					foreach (JToken jtoken in jarray)
					{
						int num2;
						if (int.TryParse(jtoken["Timestamp"].ToString(), out num2))
						{
							int num3 = num2 - num;
							jarray2.Add(string.Format("wait {0}", num3));
							ConfigConverter.ComboEventType comboEventType;
							if (jtoken["EventType"] != null && EnumHelper.TryParse<ConfigConverter.ComboEventType>(jtoken["EventType"].ToString(), out comboEventType))
							{
								switch (comboEventType)
								{
								case ConfigConverter.ComboEventType.MouseDown:
									jarray2.Add(string.Format("mouseDown {0} {1}", jtoken["X"].ToString(), jtoken["Y"].ToString()));
									break;
								case ConfigConverter.ComboEventType.MouseUp:
									jarray2.Add(string.Format("mouseUp {0} {1}", jtoken["X"].ToString(), jtoken["Y"].ToString()));
									break;
								case ConfigConverter.ComboEventType.MouseMove:
									jarray2.Add(string.Format("mouseMove {0} {1}", jtoken["X"].ToString(), jtoken["Y"].ToString()));
									break;
								case ConfigConverter.ComboEventType.MouseWheel:
									jarray2.Add(string.Format("mouseWheel {0} {1} {2}", jtoken["X"].ToString(), jtoken["Y"].ToString(), jtoken["Delta"].ToString()));
									break;
								case ConfigConverter.ComboEventType.KeyDown:
									jarray2.Add(string.Format("keyDown {0}", jtoken["KeyName"].ToString()));
									break;
								case ConfigConverter.ComboEventType.KeyUp:
									jarray2.Add(string.Format("keyUp {0}", jtoken["KeyName"].ToString()));
									break;
								case ConfigConverter.ComboEventType.IME:
								{
									string[] array = jtoken["Msg"].ToString().Split(new char[]
									{
										' '
									});
									string text = array[1].Split(new char[]
									{
										'='
									})[1];
									if (!string.Equals(text, "0"))
									{
										jarray2.Add(string.Format("text backspace {0}", text));
									}
									if (!string.IsNullOrEmpty(array[0].Split(new char[]
									{
										'_'
									})[1]))
									{
										jarray2.Add(string.Format("text {0}", array[0].Split(new char[]
										{
											'_'
										})[1]));
									}
									break;
								}
								}
							}
						}
						num = num2;
					}
					primitive.Add("Commands", jarray2);
					primitive["Events"].Parent.Remove();
				}
			}
		}

		// Token: 0x060001D5 RID: 469 RVA: 0x0000F11C File Offset: 0x0000D31C
		private static void UpdateTiltAndStatePrimitives(JObject primitive)
		{
			if ((primitive["Type"] != null && string.Equals(primitive["Type"].ToString(), "State")) || string.Equals(primitive["Type"].ToString(), "Tilt"))
			{
				primitive.Add("X", ConfigConverter.GetLocationForPoint(ConfigConverter.mTiltCol, ConfigConverter.mTiltMaxRowCol));
				primitive.Add("Y", ConfigConverter.GetLocationForPoint(ConfigConverter.mTiltRow, ConfigConverter.mTiltMaxRowCol));
				ConfigConverter.mTiltCol++;
				if (ConfigConverter.mTiltCol == ConfigConverter.mTiltMaxRowCol)
				{
					ConfigConverter.mTiltRow++;
					ConfigConverter.mTiltRow %= ConfigConverter.mTiltMaxRowCol;
				}
				ConfigConverter.mTiltCol %= ConfigConverter.mTiltMaxRowCol;
			}
		}

		// Token: 0x060001D6 RID: 470 RVA: 0x0000F1F4 File Offset: 0x0000D3F4
		private static int GetLocationForPoint(int _location, int _maxCol)
		{
			int num = 100 / _maxCol;
			return num / 2 + _location * num;
		}

		// Token: 0x040000B9 RID: 185
		private const int THRESHOLD_VERSION = 13;

		// Token: 0x040000BA RID: 186
		private const string METADATA = "MetaData";

		// Token: 0x040000BB RID: 187
		private const string PARSER_VERSION = "ParserVersion";

		// Token: 0x040000BC RID: 188
		private const string COMMENT = "Comment";

		// Token: 0x040000BD RID: 189
		private const string COMMENT_VALUE = "Generated automatically from ver {0}";

		// Token: 0x040000BE RID: 190
		private const string PRIMITIVES = "Primitives";

		// Token: 0x040000BF RID: 191
		private const string SCHEMES = "Schemes";

		// Token: 0x040000C0 RID: 192
		private const string TAGS = "Tags";

		// Token: 0x040000C1 RID: 193
		private const string TAG = "Tag";

		// Token: 0x040000C2 RID: 194
		private const string CONTROL_SCHEMES = "ControlSchemes";

		// Token: 0x040000C3 RID: 195
		private const string NAME = "Name";

		// Token: 0x040000C4 RID: 196
		private const string BUILT_IN = "BuiltIn";

		// Token: 0x040000C5 RID: 197
		private const string SELECTED = "Selected";

		// Token: 0x040000C6 RID: 198
		private const string IS_BOOKMARKED = "IsBookMarked";

		// Token: 0x040000C7 RID: 199
		private const string KEYBOARD_LAYOUT = "KeyboardLayout";

		// Token: 0x040000C8 RID: 200
		private const string IMAGES = "Images";

		// Token: 0x040000C9 RID: 201
		private const string GAME_CONTROLS = "GameControls";

		// Token: 0x040000CA RID: 202
		private const string STRINGS = "Strings";

		// Token: 0x040000CB RID: 203
		private const string TYPE = "Type";

		// Token: 0x040000CC RID: 204
		private const string TYPE_ = "$type";

		// Token: 0x040000CD RID: 205
		private const string COMBO = "Combo";

		// Token: 0x040000CE RID: 206
		private const string STATE = "State";

		// Token: 0x040000CF RID: 207
		private const string TILT = "Tilt";

		// Token: 0x040000D0 RID: 208
		private const string SCRIPT = "Script";

		// Token: 0x040000D1 RID: 209
		private const string SCRIPT_ = "Script, Bluestacks";

		// Token: 0x040000D2 RID: 210
		private const string DESCRIPTION = "Description";

		// Token: 0x040000D3 RID: 211
		private const string X = "X";

		// Token: 0x040000D4 RID: 212
		private const string Y = "Y";

		// Token: 0x040000D5 RID: 213
		private const string EVENTS = "Events";

		// Token: 0x040000D6 RID: 214
		private const string EVENT_TYPE = "EventType";

		// Token: 0x040000D7 RID: 215
		private const string TIMESTAMP = "Timestamp";

		// Token: 0x040000D8 RID: 216
		private const string KEY_NAME = "KeyName";

		// Token: 0x040000D9 RID: 217
		private const string MSG = "Msg";

		// Token: 0x040000DA RID: 218
		private const string DELTA = "Delta";

		// Token: 0x040000DB RID: 219
		private const string COMMANDS = "Commands";

		// Token: 0x040000DC RID: 220
		public const string OVERLAY = "IsVisibleInOverlay";

		// Token: 0x040000DD RID: 221
		public const string SHOW_OVERLAY = "ShowOnOverlay";

		// Token: 0x040000DE RID: 222
		private static readonly int mMaxRowCol = 8;

		// Token: 0x040000DF RID: 223
		private static string DEFAULT_PROFILE_NAME = "Default";

		// Token: 0x040000E0 RID: 224
		private static int mScriptRow = 0;

		// Token: 0x040000E1 RID: 225
		private static int mScriptCol = 0;

		// Token: 0x040000E2 RID: 226
		private static readonly int mTiltMaxRowCol = 2;

		// Token: 0x040000E3 RID: 227
		private static int mTiltCol = 0;

		// Token: 0x040000E4 RID: 228
		private static int mTiltRow = 0;

		// Token: 0x02000053 RID: 83
		private enum ComboEventType
		{
			// Token: 0x040000E6 RID: 230
			None,
			// Token: 0x040000E7 RID: 231
			MouseDown,
			// Token: 0x040000E8 RID: 232
			MouseUp,
			// Token: 0x040000E9 RID: 233
			MouseMove,
			// Token: 0x040000EA RID: 234
			MouseWheel,
			// Token: 0x040000EB RID: 235
			KeyDown,
			// Token: 0x040000EC RID: 236
			KeyUp,
			// Token: 0x040000ED RID: 237
			IME
		}
	}
}
