﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x020000A6 RID: 166
	public class CustomCheckbox : CheckBox, IComponentConnector, IStyleConnector
	{
		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x06000408 RID: 1032 RVA: 0x000042DA File Offset: 0x000024DA
		// (set) Token: 0x06000409 RID: 1033 RVA: 0x00019CE8 File Offset: 0x00017EE8
		public string Group
		{
			get
			{
				return this.mGroup;
			}
			set
			{
				this.mGroup = value;
				if (base.IsThreeState)
				{
					CustomCheckbox.dictInterminentTags[this.mGroup] = new Tuple<CustomCheckbox, List<CustomCheckbox>, List<CustomCheckbox>>(this, new List<CustomCheckbox>(), new List<CustomCheckbox>());
					return;
				}
				CustomCheckbox.dictInterminentTags[this.Group].Item3.Add(this);
			}
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x00019D40 File Offset: 0x00017F40
		public void SetInterminate()
		{
			if (base.IsChecked != null)
			{
				this._mSetInterminate = true;
				base.IsChecked = null;
			}
		}

		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x0600040B RID: 1035 RVA: 0x000042E2 File Offset: 0x000024E2
		public Image Image
		{
			get
			{
				if (this.mImage == null)
				{
					this.mImage = (Image)base.Template.FindName("mImage", this);
				}
				return this.mImage;
			}
		}

		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x0600040C RID: 1036 RVA: 0x0000430E File Offset: 0x0000250E
		public ColumnDefinition colDefMargin
		{
			get
			{
				return (ColumnDefinition)base.Template.FindName("colDefMargin", this);
			}
		}

		// Token: 0x170000FA RID: 250
		// (get) Token: 0x0600040D RID: 1037 RVA: 0x00004326 File Offset: 0x00002526
		public ColumnDefinition colDefHorizontalLabel
		{
			get
			{
				return (ColumnDefinition)base.Template.FindName("colDefHorizontalLabel", this);
			}
		}

		// Token: 0x170000FB RID: 251
		// (get) Token: 0x0600040E RID: 1038 RVA: 0x0000433E File Offset: 0x0000253E
		public Viewbox BottomLabel
		{
			get
			{
				return (Viewbox)base.Template.FindName("VerticalTextBlock", this);
			}
		}

		// Token: 0x170000FC RID: 252
		// (get) Token: 0x0600040F RID: 1039 RVA: 0x00004356 File Offset: 0x00002556
		public TextBlock CheckboxText
		{
			get
			{
				return (TextBlock)base.Template.FindName("HorizontalTextBlock", this);
			}
		}

		// Token: 0x170000FD RID: 253
		// (set) Token: 0x06000410 RID: 1040 RVA: 0x0000436E File Offset: 0x0000256E
		public Orientation Orientation
		{
			set
			{
				this.mOrientaion = value;
			}
		}

		// Token: 0x170000FE RID: 254
		// (set) Token: 0x06000411 RID: 1041 RVA: 0x00004377 File Offset: 0x00002577
		public Visibility LabelVisibility
		{
			set
			{
				this.mLabelVisibility = value;
			}
		}

		// Token: 0x06000412 RID: 1042 RVA: 0x00004380 File Offset: 0x00002580
		public CustomCheckbox()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x00019D74 File Offset: 0x00017F74
		private void CheckBox_MouseEnter(object sender, MouseEventArgs e)
		{
			if (base.IsChecked != null && !base.IsChecked.Value)
			{
				CustomPictureBox.SetBitmapImage(this.Image, "check_box_hover", false);
			}
		}

		// Token: 0x06000414 RID: 1044 RVA: 0x00019DB4 File Offset: 0x00017FB4
		private void CheckBox_MouseLeave(object sender, MouseEventArgs e)
		{
			if (base.IsChecked == null)
			{
				CustomPictureBox.SetBitmapImage(this.Image, "check_box_Indeterminate", false);
				return;
			}
			if (base.IsChecked.Value)
			{
				CustomPictureBox.SetBitmapImage(this.Image, "check_box_checked", false);
				return;
			}
			CustomPictureBox.SetBitmapImage(this.Image, "check_box", false);
		}

		// Token: 0x06000415 RID: 1045 RVA: 0x00019E18 File Offset: 0x00018018
		private void CheckBox_Checked(object sender, RoutedEventArgs e)
		{
			if (!string.IsNullOrEmpty(this.mGroup))
			{
				if (base.IsThreeState)
				{
					if (CustomCheckbox.dictInterminentTags[this.mGroup].Item3.Count > 0)
					{
						CustomCheckbox[] array = CustomCheckbox.dictInterminentTags[this.mGroup].Item3.ToArray();
						for (int i = 0; i < array.Length; i++)
						{
							array[i].IsChecked = new bool?(true);
						}
					}
				}
				else
				{
					CustomCheckbox.dictInterminentTags[this.mGroup].Item2.Add(this);
					CustomCheckbox.dictInterminentTags[this.mGroup].Item3.Remove(this);
					if (CustomCheckbox.dictInterminentTags[this.mGroup].Item3.Count == 0)
					{
						CustomCheckbox.dictInterminentTags[this.mGroup].Item1.IsChecked = new bool?(true);
					}
					else
					{
						CustomCheckbox.dictInterminentTags[this.mGroup].Item1.SetInterminate();
					}
				}
			}
			if (this.Image != null)
			{
				CustomPictureBox.SetBitmapImage(this.Image, "check_box_checked", false);
			}
		}

		// Token: 0x06000416 RID: 1046 RVA: 0x00004399 File Offset: 0x00002599
		private void CheckBox_Indeterminate(object sender, RoutedEventArgs e)
		{
			if (!this._mSetInterminate)
			{
				base.IsChecked = new bool?(false);
				return;
			}
			this._mSetInterminate = false;
			if (this.Image != null)
			{
				CustomPictureBox.SetBitmapImage(this.Image, "check_box_Indeterminate", false);
			}
		}

		// Token: 0x06000417 RID: 1047 RVA: 0x00019F44 File Offset: 0x00018144
		private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
		{
			if (!string.IsNullOrEmpty(this.mGroup))
			{
				if (base.IsThreeState)
				{
					if (CustomCheckbox.dictInterminentTags[this.mGroup].Item2.Count > 0)
					{
						CustomCheckbox[] array = CustomCheckbox.dictInterminentTags[this.mGroup].Item2.ToArray();
						for (int i = 0; i < array.Length; i++)
						{
							array[i].IsChecked = new bool?(false);
						}
					}
				}
				else
				{
					CustomCheckbox.dictInterminentTags[this.mGroup].Item2.Remove(this);
					CustomCheckbox.dictInterminentTags[this.mGroup].Item3.Add(this);
					if (CustomCheckbox.dictInterminentTags[this.mGroup].Item2.Count == 0)
					{
						CustomCheckbox.dictInterminentTags[this.mGroup].Item1.IsChecked = new bool?(false);
					}
					else
					{
						CustomCheckbox.dictInterminentTags[this.mGroup].Item1.SetInterminate();
					}
				}
			}
			if (base.IsMouseOver)
			{
				if (this.Image != null)
				{
					CustomPictureBox.SetBitmapImage(this.Image, "check_box_hover", false);
					return;
				}
			}
			else if (this.Image != null)
			{
				CustomPictureBox.SetBitmapImage(this.Image, "check_box", false);
			}
		}

		// Token: 0x06000418 RID: 1048 RVA: 0x0001A090 File Offset: 0x00018290
		private void CheckBox_Loaded(object sender, RoutedEventArgs e)
		{
			if (!DesignerProperties.GetIsInDesignMode(this))
			{
				if (this.mOrientaion == Orientation.Vertical)
				{
					Grid.SetRowSpan(this.Image, 1);
					this.colDefHorizontalLabel.Width = new GridLength(0.0);
					this.BottomLabel.Visibility = Visibility.Visible;
				}
				if (this.mLabelVisibility == Visibility.Hidden)
				{
					this.CheckboxText.Visibility = Visibility.Hidden;
					this.BottomLabel.Visibility = Visibility.Hidden;
				}
				if (this.Image != null)
				{
					if (base.IsChecked == null)
					{
						CustomPictureBox.SetBitmapImage(this.Image, "check_box__Indeterminate", false);
						return;
					}
					if (base.IsChecked != null && base.IsChecked.Value)
					{
						CustomPictureBox.SetBitmapImage(this.Image, "check_box_checked", false);
						return;
					}
					CustomPictureBox.SetBitmapImage(this.Image, "check_box", false);
				}
			}
		}

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x06000419 RID: 1049 RVA: 0x000043D0 File Offset: 0x000025D0
		// (set) Token: 0x0600041A RID: 1050 RVA: 0x000043E2 File Offset: 0x000025E2
		public Thickness ImageMargin
		{
			get
			{
				return (Thickness)base.GetValue(CustomCheckbox.ImageMarginProperty);
			}
			set
			{
				base.SetValue(CustomCheckbox.ImageMarginProperty, value);
			}
		}

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x0600041B RID: 1051 RVA: 0x000043F5 File Offset: 0x000025F5
		// (set) Token: 0x0600041C RID: 1052 RVA: 0x00004407 File Offset: 0x00002607
		public double TextFontSize
		{
			get
			{
				return (double)base.GetValue(CustomCheckbox.TextFontSizeProperty);
			}
			set
			{
				base.SetValue(CustomCheckbox.TextFontSizeProperty, value);
			}
		}

		// Token: 0x0600041D RID: 1053 RVA: 0x0000441A File Offset: 0x0000261A
		private void CheckBoxText_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (sender != null)
			{
				(sender as TextBlock).SetTextblockTooltip(null);
			}
		}

		// Token: 0x0600041E RID: 1054 RVA: 0x0001A170 File Offset: 0x00018370
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/customcheckbox.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600041F RID: 1055 RVA: 0x0001A1A0 File Offset: 0x000183A0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				((CustomCheckbox)target).MouseEnter += this.CheckBox_MouseEnter;
				((CustomCheckbox)target).MouseLeave += this.CheckBox_MouseLeave;
				((CustomCheckbox)target).Checked += this.CheckBox_Checked;
				((CustomCheckbox)target).Unchecked += this.CheckBox_Unchecked;
				((CustomCheckbox)target).Indeterminate += this.CheckBox_Indeterminate;
				((CustomCheckbox)target).Loaded += this.CheckBox_Loaded;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x06000420 RID: 1056 RVA: 0x0000442C File Offset: 0x0000262C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 2)
			{
				((TextBlock)target).SizeChanged += this.CheckBoxText_SizeChanged;
			}
		}

		// Token: 0x040003C6 RID: 966
		public static Dictionary<string, Tuple<CustomCheckbox, List<CustomCheckbox>, List<CustomCheckbox>>> dictInterminentTags = new Dictionary<string, Tuple<CustomCheckbox, List<CustomCheckbox>, List<CustomCheckbox>>>();

		// Token: 0x040003C7 RID: 967
		private string mGroup = string.Empty;

		// Token: 0x040003C8 RID: 968
		private bool _mSetInterminate;

		// Token: 0x040003C9 RID: 969
		private Image mImage;

		// Token: 0x040003CA RID: 970
		private Orientation mOrientaion;

		// Token: 0x040003CB RID: 971
		private Visibility mLabelVisibility;

		// Token: 0x040003CC RID: 972
		public static readonly DependencyProperty ImageMarginProperty = DependencyProperty.Register("ImageMargin", typeof(Thickness), typeof(CustomCheckbox), new PropertyMetadata(new Thickness(0.0)));

		// Token: 0x040003CD RID: 973
		public static readonly DependencyProperty TextFontSizeProperty = DependencyProperty.Register("TextFontSize", typeof(double), typeof(CustomCheckbox), new PropertyMetadata(16.0));

		// Token: 0x040003CE RID: 974
		private bool _contentLoaded;
	}
}
