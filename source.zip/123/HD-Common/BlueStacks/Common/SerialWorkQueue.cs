﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Timers;

namespace BlueStacks.Common
{
	// Token: 0x020000F0 RID: 240
	public class SerialWorkQueue
	{
		// Token: 0x06000889 RID: 2185 RVA: 0x00023CDC File Offset: 0x00021EDC
		public SerialWorkQueue()
		{
			string name = string.Format("SerialWorkQueue.{0}", Interlocked.Increment(ref SerialWorkQueue.sAutoId));
			this.Initialize(name);
		}

		// Token: 0x0600088A RID: 2186 RVA: 0x00009513 File Offset: 0x00007713
		public SerialWorkQueue(string name)
		{
			this.Initialize(name);
		}

		// Token: 0x0600088B RID: 2187 RVA: 0x00023D10 File Offset: 0x00021F10
		private void Initialize(string name)
		{
			this.mQueue = new Queue<SerialWorkQueue.Work>();
			this.mLock = new object();
			this.mThread = new Thread(new ThreadStart(this.Run));
			this.mThread.Name = name;
			this.mThread.IsBackground = true;
		}

		// Token: 0x170002A0 RID: 672
		// (set) Token: 0x0600088C RID: 2188 RVA: 0x00009522 File Offset: 0x00007722
		public SerialWorkQueue.ExceptionHandlerCallback ExceptionHandler
		{
			set
			{
				this.mExceptionHandler = value;
			}
		}

		// Token: 0x0600088D RID: 2189 RVA: 0x0000952B File Offset: 0x0000772B
		public void Start()
		{
			this.mThread.Start();
		}

		// Token: 0x0600088E RID: 2190 RVA: 0x00009538 File Offset: 0x00007738
		public void Join()
		{
			this.mThread.Join();
		}

		// Token: 0x0600088F RID: 2191 RVA: 0x00009545 File Offset: 0x00007745
		public void Stop()
		{
			this.Enqueue(null);
		}

		// Token: 0x06000890 RID: 2192 RVA: 0x00023D64 File Offset: 0x00021F64
		public void Enqueue(SerialWorkQueue.Work work)
		{
			object obj = this.mLock;
			lock (obj)
			{
				this.mQueue.Enqueue(work);
				Monitor.PulseAll(this.mLock);
			}
		}

		// Token: 0x06000891 RID: 2193 RVA: 0x0000954E File Offset: 0x0000774E
		public void DispatchAsync(SerialWorkQueue.Work work)
		{
			this.Enqueue(work);
		}

		// Token: 0x06000892 RID: 2194 RVA: 0x00023DB0 File Offset: 0x00021FB0
		public void DispatchAfter(double delay, SerialWorkQueue.Work work)
		{
			System.Timers.Timer timer = new System.Timers.Timer();
			timer.Elapsed += delegate(object source, ElapsedEventArgs evt)
			{
				this.DispatchSync(work);
				timer.Close();
			};
			timer.Interval = delay;
			timer.Enabled = true;
		}

		// Token: 0x06000893 RID: 2195 RVA: 0x00023E0C File Offset: 0x0002200C
		public void DispatchSync(SerialWorkQueue.Work work)
		{
			EventWaitHandle waitHandle = new EventWaitHandle(false, EventResetMode.ManualReset);
			this.Enqueue(delegate
			{
				work();
				waitHandle.Set();
			});
			waitHandle.WaitOne();
			waitHandle.Close();
		}

		// Token: 0x06000894 RID: 2196 RVA: 0x00009557 File Offset: 0x00007757
		public bool IsCurrentWorkQueue()
		{
			return Thread.CurrentThread == this.mThread;
		}

		// Token: 0x06000895 RID: 2197 RVA: 0x00023E5C File Offset: 0x0002205C
		private void Run()
		{
			for (;;)
			{
				object obj = this.mLock;
				SerialWorkQueue.Work work;
				lock (obj)
				{
					while (this.mQueue.Count == 0)
					{
						Monitor.Wait(this.mLock);
					}
					work = this.mQueue.Dequeue();
				}
				if (work != null)
				{
					try
					{
						work();
						continue;
					}
					catch (Exception exc)
					{
						if (this.mExceptionHandler != null)
						{
							this.mExceptionHandler(exc);
							continue;
						}
						throw;
					}
					break;
				}
				break;
			}
		}

		// Token: 0x0400065C RID: 1628
		private static int sAutoId;

		// Token: 0x0400065D RID: 1629
		private Thread mThread;

		// Token: 0x0400065E RID: 1630
		private Queue<SerialWorkQueue.Work> mQueue;

		// Token: 0x0400065F RID: 1631
		private object mLock;

		// Token: 0x04000660 RID: 1632
		private SerialWorkQueue.ExceptionHandlerCallback mExceptionHandler;

		// Token: 0x020000F1 RID: 241
		// (Invoke) Token: 0x06000898 RID: 2200
		public delegate void Work();

		// Token: 0x020000F2 RID: 242
		// (Invoke) Token: 0x0600089C RID: 2204
		public delegate void ExceptionHandlerCallback(Exception exc);
	}
}
