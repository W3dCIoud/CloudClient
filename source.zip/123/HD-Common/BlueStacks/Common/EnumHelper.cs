﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000CA RID: 202
	public class EnumHelper
	{
		// Token: 0x06000651 RID: 1617 RVA: 0x0000684B File Offset: 0x00004A4B
		public static TEnum Parse<TEnum>(string value, TEnum defaultValue)
		{
			if (value == null || !Enum.IsDefined(typeof(TEnum), value))
			{
				return defaultValue;
			}
			return (TEnum)((object)Enum.Parse(typeof(TEnum), value));
		}

		// Token: 0x06000652 RID: 1618 RVA: 0x0001E8E4 File Offset: 0x0001CAE4
		public static bool TryParse<TEnum>(string value, out TEnum result) where TEnum : struct, IConvertible
		{
			bool flag = value != null && Enum.IsDefined(typeof(TEnum), value);
			result = (flag ? ((TEnum)((object)Enum.Parse(typeof(TEnum), value))) : default(TEnum));
			return flag;
		}
	}
}
