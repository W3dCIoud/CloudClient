﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200010D RID: 269
	public enum CheckBoxType
	{
		// Token: 0x040006E4 RID: 1764
		Gray,
		// Token: 0x040006E5 RID: 1765
		White
	}
}
