﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x020000E0 RID: 224
	public class JsonParser
	{
		// Token: 0x0600065E RID: 1630 RVA: 0x0001EAC4 File Offset: 0x0001CCC4
		public JsonParser(string vmName)
		{
			if (string.IsNullOrEmpty(vmName))
			{
				this.mVmName = "";
				this.mAppsDotJsonFile = Path.Combine(RegistryStrings.GadgetDir, "systemApps.json");
			}
			else
			{
				this.mVmName = vmName;
				this.mAppsDotJsonFile = Path.Combine(RegistryStrings.GadgetDir, "apps_" + vmName + ".json");
			}
			using (Mutex mutex = new Mutex(false, "BlueStacks_AppJsonUpdate"))
			{
				if (mutex.WaitOne())
				{
					try
					{
						this.DeleteIfInvalidJsonFile(this.mAppsDotJsonFile);
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to delete invalid json file... Err : " + ex.ToString());
					}
					finally
					{
						mutex.ReleaseMutex();
					}
				}
			}
		}

		// Token: 0x0600065F RID: 1631 RVA: 0x0001EBA0 File Offset: 0x0001CDA0
		public static List<string> GetInstalledAppsList(string vmName)
		{
			List<string> list = new List<string>();
			AppInfo[] appList = new JsonParser(vmName).GetAppList();
			for (int i = 0; i < appList.Length; i++)
			{
				if (appList[i] != null && appList[i].package != null)
				{
					list.Add(appList[i].package);
				}
			}
			return list;
		}

		// Token: 0x06000660 RID: 1632 RVA: 0x0001EBEC File Offset: 0x0001CDEC
		public AppInfo[] GetAppList()
		{
			string json = "[]";
			using (Mutex mutex = new Mutex(false, "BlueStacks_AppJsonUpdate"))
			{
				if (mutex.WaitOne())
				{
					try
					{
						if (!File.Exists(this.mAppsDotJsonFile))
						{
							using (StreamWriter streamWriter = new StreamWriter(this.mAppsDotJsonFile, true))
							{
								streamWriter.Write("[");
								streamWriter.WriteLine();
								streamWriter.Write("]");
							}
						}
						StreamReader streamReader = new StreamReader(this.mAppsDotJsonFile);
						json = streamReader.ReadToEnd();
						streamReader.Close();
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to create empty app json... Err : " + ex.ToString());
					}
					finally
					{
						mutex.ReleaseMutex();
					}
				}
			}
			this.GetOriginalJson(JArray.Parse(json));
			return this.mOriginalJson;
		}

		// Token: 0x06000661 RID: 1633 RVA: 0x0001ECE0 File Offset: 0x0001CEE0
		private void GetOriginalJson(JArray input)
		{
			this.mOriginalJson = new AppInfo[input.Count];
			for (int i = 0; i < input.Count; i++)
			{
				this.mOriginalJson[i] = JsonConvert.DeserializeObject<AppInfo>(input[i].ToString());
			}
		}

		// Token: 0x06000662 RID: 1634 RVA: 0x0001ED28 File Offset: 0x0001CF28
		public int GetInstalledAppCount()
		{
			this.GetAppList();
			int num = 0;
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (string.Compare(this.mOriginalJson[i].activity, ".Main", true) != 0 && string.Compare(this.mOriginalJson[i].appstore, "yes", true) != 0)
				{
					num++;
				}
			}
			return num;
		}

		// Token: 0x06000663 RID: 1635 RVA: 0x0001ED8C File Offset: 0x0001CF8C
		public bool GetAppInfoFromAppName(string appName, out string packageName, out string imageName, out string activityName)
		{
			packageName = null;
			imageName = null;
			activityName = null;
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].name == appName)
				{
					packageName = this.mOriginalJson[i].package;
					imageName = this.mOriginalJson[i].img;
					activityName = this.mOriginalJson[i].activity;
					return true;
				}
			}
			return false;
		}

		// Token: 0x06000664 RID: 1636 RVA: 0x0001EE04 File Offset: 0x0001D004
		public bool GetAppInfoFromPackageName(string packageName, out string appName, out string imageName, out string activityName, out string appstore)
		{
			appName = "";
			imageName = "";
			activityName = "";
			appstore = "";
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].package == packageName)
				{
					appName = this.mOriginalJson[i].name;
					imageName = this.mOriginalJson[i].img;
					activityName = this.mOriginalJson[i].activity;
					appstore = this.mOriginalJson[i].appstore;
					return true;
				}
			}
			return false;
		}

		// Token: 0x06000665 RID: 1637 RVA: 0x0001EEA0 File Offset: 0x0001D0A0
		public AppInfo GetAppInfoFromPackageName(string packageName)
		{
			AppInfo result = null;
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].package == packageName)
				{
					result = this.mOriginalJson[i];
				}
			}
			return result;
		}

		// Token: 0x06000666 RID: 1638 RVA: 0x0001EEE8 File Offset: 0x0001D0E8
		public string GetAppNameFromPackageActivity(string packageName, string activityName)
		{
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].package == packageName && this.mOriginalJson[i].activity == activityName)
				{
					return this.mOriginalJson[i].name;
				}
			}
			return string.Empty;
		}

		// Token: 0x06000667 RID: 1639 RVA: 0x0001EF4C File Offset: 0x0001D14C
		public string GetAppNameFromPackage(string packageName)
		{
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].package == packageName)
				{
					return this.mOriginalJson[i].name;
				}
			}
			return string.Empty;
		}

		// Token: 0x06000668 RID: 1640 RVA: 0x0001EF9C File Offset: 0x0001D19C
		public bool GetGl3RequirementFromPackage(AppInfo[] appJson, string packageName)
		{
			for (int i = 0; i < appJson.Length; i++)
			{
				if (appJson[i].package == packageName)
				{
					return appJson[i].gl3required;
				}
			}
			return false;
		}

		// Token: 0x06000669 RID: 1641 RVA: 0x0001EFD4 File Offset: 0x0001D1D4
		public bool GetVideoPresentRequirementFromPackage(AppInfo[] appJson, string packageName)
		{
			for (int i = 0; i < appJson.Length; i++)
			{
				if (appJson[i].package == packageName)
				{
					return appJson[i].videopresent;
				}
			}
			return false;
		}

		// Token: 0x0600066A RID: 1642 RVA: 0x0001F00C File Offset: 0x0001D20C
		public string GetPackageNameFromActivityName(string activityName)
		{
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].activity == activityName)
				{
					return this.mOriginalJson[i].package;
				}
			}
			return string.Empty;
		}

		// Token: 0x0600066B RID: 1643 RVA: 0x0001F05C File Offset: 0x0001D25C
		public string GetActivityNameFromPackageName(string packageName)
		{
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].package == packageName)
				{
					return this.mOriginalJson[i].activity;
				}
			}
			return string.Empty;
		}

		// Token: 0x0600066C RID: 1644 RVA: 0x0001F0AC File Offset: 0x0001D2AC
		public bool IsPackageNameSystemApp(string packageName)
		{
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].package == packageName)
				{
					return this.mOriginalJson[i].system == "1";
				}
			}
			return false;
		}

		// Token: 0x0600066D RID: 1645 RVA: 0x0001F108 File Offset: 0x0001D308
		public bool IsAppNameSystemApp(string appName)
		{
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].name == appName)
				{
					return this.mOriginalJson[i].system == "1";
				}
			}
			return false;
		}

		// Token: 0x0600066E RID: 1646 RVA: 0x0001F164 File Offset: 0x0001D364
		public bool IsAppInstalled(string packageName)
		{
			string text;
			return this.IsAppInstalled(packageName, out text);
		}

		// Token: 0x0600066F RID: 1647 RVA: 0x0001F17C File Offset: 0x0001D37C
		public bool IsAppInstalled(string packageName, out string version)
		{
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].package == packageName)
				{
					version = this.mOriginalJson[i].version;
					return true;
				}
			}
			version = "NA";
			return false;
		}

		// Token: 0x06000670 RID: 1648 RVA: 0x0001F1D4 File Offset: 0x0001D3D4
		public bool GetAppData(string package, string activity, out string name, out string img)
		{
			this.GetAppList();
			name = "";
			img = "";
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].package == package && this.mOriginalJson[i].activity == activity)
				{
					name = this.mOriginalJson[i].name;
					img = this.mOriginalJson[i].img;
					Logger.Info("Got AppName: {0} and AppIcon: {1}", new object[]
					{
						name,
						img
					});
					return true;
				}
			}
			return false;
		}

		// Token: 0x06000671 RID: 1649 RVA: 0x0001F274 File Offset: 0x0001D474
		public void WriteJson(AppInfo[] json)
		{
			JArray jarray = new JArray();
			Logger.Info("JsonParser: Writing json object array to json writer");
			for (int i = 0; i < json.Length; i++)
			{
				JObject jobject = new JObject();
				jobject.Add("img", json[i].img);
				jobject.Add("name", json[i].name);
				jobject.Add("system", json[i].system);
				jobject.Add("package", json[i].package);
				jobject.Add("appstore", json[i].appstore);
				jobject.Add("activity", json[i].activity);
				jobject.Add("version", json[i].version);
				jobject.Add("versionName", json[i].versionName);
				jobject.Add("gl3required", json[i].gl3required);
				jobject.Add("videopresent", json[i].videopresent);
				if (json[i].url != null)
				{
					jobject.Add("url", json[i].url);
				}
				jarray.Add(jobject);
			}
			using (Mutex mutex = new Mutex(false, "BlueStacks_AppJsonUpdate"))
			{
				if (mutex.WaitOne())
				{
					try
					{
						StreamWriter streamWriter = new StreamWriter(this.mAppsDotJsonFile + ".tmp");
						streamWriter.Write(jarray.ToString(Formatting.None, new JsonConverter[0]));
						streamWriter.Close();
						File.Copy(this.mAppsDotJsonFile + ".tmp", this.mAppsDotJsonFile + ".bak", true);
						File.Delete(this.mAppsDotJsonFile);
						int num = 10;
						while (File.Exists(this.mAppsDotJsonFile) && num > 0)
						{
							num--;
							Thread.Sleep(100);
						}
						File.Move(this.mAppsDotJsonFile + ".tmp", this.mAppsDotJsonFile);
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to write in apps json file... Err : " + ex.ToString());
					}
					finally
					{
						mutex.ReleaseMutex();
					}
				}
			}
		}

		// Token: 0x06000672 RID: 1650 RVA: 0x0001F4D8 File Offset: 0x0001D6D8
		public int AddToJson(AppInfo json)
		{
			this.GetAppList();
			Logger.Info("Adding to Json");
			AppInfo[] array = new AppInfo[this.mOriginalJson.Length + 1];
			int i;
			for (i = 0; i < this.mOriginalJson.Length; i++)
			{
				array[i] = this.mOriginalJson[i];
			}
			array[i] = json;
			this.WriteJson(array);
			return this.mOriginalJson.Length;
		}

		// Token: 0x06000673 RID: 1651 RVA: 0x0001F538 File Offset: 0x0001D738
		public void DeleteIfInvalidJsonFile(string fileName)
		{
			try
			{
				if (!this.IsValidJsonFile(fileName))
				{
					File.Delete(fileName);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Some error in deleting file, ex: " + ex.Message);
			}
		}

		// Token: 0x06000674 RID: 1652 RVA: 0x0001F580 File Offset: 0x0001D780
		private bool IsValidJsonFile(string fileName)
		{
			bool result;
			try
			{
				JArray.Parse(File.ReadAllText(fileName));
				result = true;
			}
			catch (Exception ex)
			{
				Logger.Error("Invalid JSon file: " + fileName);
				Logger.Error(ex.Message);
				result = false;
			}
			return result;
		}

		// Token: 0x04000581 RID: 1409
		private string mAppsDotJsonFile;

		// Token: 0x04000582 RID: 1410
		private AppInfo[] mOriginalJson;

		// Token: 0x04000583 RID: 1411
		public string mVmName;
	}
}
