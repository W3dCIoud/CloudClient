﻿using System;
using System.Collections.Generic;

namespace BlueStacks.Common
{
	// Token: 0x02000080 RID: 128
	public class PackageActivityNames
	{
		// Token: 0x040002E8 RID: 744
		public const string DefaultBundledLauncher = "com.bluestacks.appmart";

		// Token: 0x040002E9 RID: 745
		public const string DefaultBundledLauncherMainActivity = "com.bluestacks.appmart.StartTopAppsActivity";

		// Token: 0x02000081 RID: 129
		public class Google
		{
			// Token: 0x040002EA RID: 746
			public const string GooglePlayStore = "com.android.vending";

			// Token: 0x040002EB RID: 747
			public const string GooglePlayServices = "com.google.android.gms";

			// Token: 0x040002EC RID: 748
			public const string Chrome = "com.android.chrome";
		}

		// Token: 0x02000082 RID: 130
		public class BlueStacks
		{
			// Token: 0x040002ED RID: 749
			public const string AppMart = "com.bluestacks.appmart";

			// Token: 0x040002EE RID: 750
			public const string AppMartMainActivity = "com.bluestacks.appmart.StartTopAppsActivity";

			// Token: 0x040002EF RID: 751
			public const string GamePopHome = "com.bluestacks.gamepophome";

			// Token: 0x040002F0 RID: 752
			public const string FileManager = "com.bluestacks.filemanager";

			// Token: 0x040002F1 RID: 753
			public const string Settings = "com.bluestacks.settings";

			// Token: 0x040002F2 RID: 754
			public const string ProvisionPackage = "com.android.provision";
		}

		// Token: 0x02000083 RID: 131
		public class ThirdParty
		{
			// Token: 0x040002F3 RID: 755
			public const string Camera = "com.android.camera2";

			// Token: 0x040002F4 RID: 756
			public const string PUBG_International = "com.tencent.ig";

			// Token: 0x040002F5 RID: 757
			public const string FreeFire = "com.dts.freefireth";

			// Token: 0x040002F6 RID: 758
			public const string GalaxyStrore = "com.sec.android.app.samsungapps";

			// Token: 0x040002F7 RID: 759
			public const string CODAppName = "Call of Duty: Mobile";

			// Token: 0x040002F8 RID: 760
			public const string PUBGAppName = "PUBG Mobile";

			// Token: 0x040002F9 RID: 761
			public static List<string> AllPUBGPackageNames = new List<string>
			{
				"com.tencent.ig",
				"com.rekoo.pubgm",
				"com.vng.pubgmobile",
				"com.pubg.krmobile",
				"com.tencent.tmgp.pubgmhd"
			};

			// Token: 0x040002FA RID: 762
			public static List<string> AllCallOfDutyPackageNames = new List<string>
			{
				"com.tencent.tmgp.kr.codm",
				"com.garena.game.codm",
				"com.activision.callofduty.shooter"
			};
		}
	}
}
