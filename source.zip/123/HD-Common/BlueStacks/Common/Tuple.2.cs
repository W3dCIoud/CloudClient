﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001A0 RID: 416
	public class Tuple<T1, T2> : Tuple<T1>
	{
		// Token: 0x06000CCF RID: 3279 RVA: 0x0000B661 File Offset: 0x00009861
		public Tuple(T1 item1, T2 item2) : base(item1)
		{
			this.Item2 = item2;
		}

		// Token: 0x170002FF RID: 767
		// (get) Token: 0x06000CD0 RID: 3280 RVA: 0x0000B671 File Offset: 0x00009871
		// (set) Token: 0x06000CD1 RID: 3281 RVA: 0x0000B679 File Offset: 0x00009879
		public T2 Item2 { get; set; }
	}
}
