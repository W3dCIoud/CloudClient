﻿using System;
using System.IO;
using Microsoft.Win32;

namespace BlueStacks.Common
{
	// Token: 0x02000161 RID: 353
	public class GuidUtils
	{
		// Token: 0x06000B80 RID: 2944 RVA: 0x00031AE8 File Offset: 0x0002FCE8
		public static string ReuseOrGenerateMachineId()
		{
			string text = "";
			try
			{
				string blueStacksMachineId = GuidUtils.GetBlueStacksMachineId();
				if (!string.IsNullOrEmpty(blueStacksMachineId))
				{
					return blueStacksMachineId;
				}
				text = Guid.NewGuid().ToString();
				GuidUtils.SetBlueStacksMachineId(text);
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't generate/find Machine ID. Ex: {0}", new object[]
				{
					ex.Message
				});
			}
			return text;
		}

		// Token: 0x06000B81 RID: 2945 RVA: 0x00031B5C File Offset: 0x0002FD5C
		public static string ReuseOrGenerateVersionId()
		{
			string text = "";
			try
			{
				string blueStacksVersionId = GuidUtils.GetBlueStacksVersionId();
				if (!string.IsNullOrEmpty(blueStacksVersionId))
				{
					return blueStacksVersionId;
				}
				text = Guid.NewGuid().ToString();
				GuidUtils.SetBlueStacksVersionId(text);
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't generate/find Version ID. Ex: {0}", new object[]
				{
					ex.Message
				});
			}
			return text;
		}

		// Token: 0x06000B82 RID: 2946 RVA: 0x0000AB53 File Offset: 0x00008D53
		public static string GetBlueStacksMachineId()
		{
			if (string.IsNullOrEmpty(GuidUtils.sBlueStacksMachineId))
			{
				GuidUtils.sBlueStacksMachineId = StringUtils.GetControlCharFreeString(GuidUtils.GetIdFromRegistryOrFile("MachineID").Trim());
			}
			return GuidUtils.sBlueStacksMachineId;
		}

		// Token: 0x06000B83 RID: 2947 RVA: 0x0000AB7F File Offset: 0x00008D7F
		public static bool SetBlueStacksMachineId(string newId)
		{
			return GuidUtils.SetIdInRegistryAndFile("MachineID", newId);
		}

		// Token: 0x06000B84 RID: 2948 RVA: 0x0000AB8C File Offset: 0x00008D8C
		public static string GetBlueStacksVersionId()
		{
			if (string.IsNullOrEmpty(GuidUtils.sBlueStacksVersionId))
			{
				GuidUtils.sBlueStacksVersionId = StringUtils.GetControlCharFreeString(GuidUtils.GetIdFromRegistryOrFile("VersionMachineId_4.140.12.1002").Trim());
			}
			return GuidUtils.sBlueStacksVersionId;
		}

		// Token: 0x06000B85 RID: 2949 RVA: 0x0000ABB8 File Offset: 0x00008DB8
		public static bool SetBlueStacksVersionId(string newId)
		{
			return GuidUtils.SetIdInRegistryAndFile("VersionMachineId_4.140.12.1002", newId);
		}

		// Token: 0x06000B86 RID: 2950 RVA: 0x00031BD0 File Offset: 0x0002FDD0
		public static string GetIdFromRegistryOrFile(string id)
		{
			string text = "";
			text = (string)RegistryUtils.GetRegistryValue(Strings.BlueStacksIdRegistryPath, id, "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			if (!string.IsNullOrEmpty(text))
			{
				return text;
			}
			try
			{
				string text2 = Path.Combine(new DirectoryInfo(ShortcutHelper.CommonDesktopPath).Parent.FullName, "BlueStacks");
				if (!Directory.Exists(text2))
				{
					Directory.CreateDirectory(text2);
				}
				string path = Path.Combine(text2, id);
				if (File.Exists(path))
				{
					string text3 = File.ReadAllText(path);
					if (!string.IsNullOrEmpty(text3))
					{
						text = text3;
					}
				}
			}
			catch
			{
			}
			if (!string.IsNullOrEmpty(text))
			{
				return text;
			}
			RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(Strings.BlueStacksIdRegistryPath);
			if (registryKey != null)
			{
				text = (string)registryKey.GetValue(id, "");
			}
			return text;
		}

		// Token: 0x06000B87 RID: 2951 RVA: 0x00031C9C File Offset: 0x0002FE9C
		public static bool SetIdInRegistryAndFile(string id, string value)
		{
			bool result = false;
			value = value.Trim();
			result = RegistryUtils.SetRegistryValue(Strings.BlueStacksIdRegistryPath, id, value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			try
			{
				string text = Path.Combine(new DirectoryInfo(ShortcutHelper.CommonDesktopPath).Parent.FullName, "BlueStacks");
				if (!Directory.Exists(text))
				{
					Directory.CreateDirectory(text);
				}
				string path = Path.Combine(text, id);
				if (File.Exists(path))
				{
					File.Delete(path);
				}
				File.WriteAllText(path, value);
				result = true;
			}
			catch (Exception ex)
			{
				Logger.Warning("Failed to write in in file. Error: " + ex.Message);
			}
			try
			{
				Registry.CurrentUser.CreateSubKey(Strings.BlueStacksIdRegistryPath).SetValue(id, value);
				result = true;
			}
			catch (Exception ex2)
			{
				Logger.Warning("Failed to write id in HKCU. Error: " + ex2.Message);
			}
			return result;
		}

		// Token: 0x04000804 RID: 2052
		private static string sBlueStacksMachineId;

		// Token: 0x04000805 RID: 2053
		private static string sBlueStacksVersionId;
	}
}
