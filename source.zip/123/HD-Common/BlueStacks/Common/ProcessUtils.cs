﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace BlueStacks.Common
{
	// Token: 0x0200016B RID: 363
	public class ProcessUtils
	{
		// Token: 0x06000BC6 RID: 3014 RVA: 0x0000AD4C File Offset: 0x00008F4C
		public static bool FindProcessByName(string name)
		{
			return Process.GetProcessesByName(name).Length != 0;
		}

		// Token: 0x06000BC7 RID: 3015 RVA: 0x00032AD8 File Offset: 0x00030CD8
		public static void KillProcessByName(string name)
		{
			foreach (Process process in Process.GetProcessesByName(name))
			{
				try
				{
					Logger.Debug("Attempting to kill: {0}", new object[]
					{
						process.ProcessName
					});
					process.Kill();
					if (!process.WaitForExit(5000))
					{
						Logger.Info("Timeout waiting for process {0} to die", new object[]
						{
							process.ProcessName
						});
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in killing process " + ex.Message);
				}
			}
		}

		// Token: 0x06000BC8 RID: 3016 RVA: 0x00032B70 File Offset: 0x00030D70
		public static void KillProcessesByName(string[] nameList)
		{
			for (int i = 0; i < nameList.Length; i++)
			{
				ProcessUtils.KillProcessByName(nameList[i]);
			}
		}

		// Token: 0x06000BC9 RID: 3017 RVA: 0x00032B98 File Offset: 0x00030D98
		public static Process GetProcessObject(string exePath, string args, bool isAdmin = false)
		{
			Process process = new Process();
			process.StartInfo.Arguments = args;
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.CreateNoWindow = true;
			process.StartInfo.FileName = exePath;
			if (isAdmin)
			{
				process.StartInfo.Verb = "runas";
				process.StartInfo.UseShellExecute = true;
			}
			return process;
		}

		// Token: 0x06000BCA RID: 3018 RVA: 0x00032BFC File Offset: 0x00030DFC
		public static bool IsProcessAlive(int pid)
		{
			bool result = false;
			try
			{
				Process.GetProcessById(pid);
				result = true;
			}
			catch (ArgumentException)
			{
			}
			return result;
		}

		// Token: 0x06000BCB RID: 3019 RVA: 0x0000AD58 File Offset: 0x00008F58
		public static bool IsLockInUse(string lockName)
		{
			return ProcessUtils.IsLockInUse(lockName, true);
		}

		// Token: 0x06000BCC RID: 3020 RVA: 0x00032C2C File Offset: 0x00030E2C
		public static bool IsLockInUse(string lockName, bool printLog)
		{
			Mutex mutex;
			if (ProcessUtils.IsAlreadyRunning(lockName, out mutex))
			{
				if (printLog)
				{
					Logger.Info(lockName + " running.");
				}
				return true;
			}
			if (mutex != null)
			{
				mutex.Close();
				mutex = null;
			}
			return false;
		}

		// Token: 0x06000BCD RID: 3021 RVA: 0x00032C64 File Offset: 0x00030E64
		public static bool IsAlreadyRunning(string name)
		{
			Mutex mutex;
			if (!ProcessUtils.IsAlreadyRunning(name, out mutex))
			{
				if (mutex != null)
				{
					mutex.Close();
				}
				return false;
			}
			return true;
		}

		// Token: 0x06000BCE RID: 3022 RVA: 0x00032C88 File Offset: 0x00030E88
		public static bool IsAlreadyRunning(string name, out Mutex lck)
		{
			bool flag = false;
			try
			{
				lck = new Mutex(true, name, ref flag);
			}
			catch (AbandonedMutexException ex)
			{
				lck = null;
				Logger.Warning("Abandoned mutex : " + name + ".  " + ex.ToString());
				return false;
			}
			catch (UnauthorizedAccessException ex2)
			{
				lck = null;
				Logger.Warning("UnauthorisedAccess on mutex : " + name + ".  " + ex2.ToString());
				return true;
			}
			if (!flag)
			{
				lck.Close();
				lck = null;
			}
			return !flag;
		}

		// Token: 0x06000BCF RID: 3023 RVA: 0x00032D1C File Offset: 0x00030F1C
		public static void KillProcessByNameIgnoreDirectory(string name, string IgnoreDirectory)
		{
			foreach (Process process in Process.GetProcessesByName(name))
			{
				string path = "";
				try
				{
					path = process.MainModule.FileName;
				}
				catch (Win32Exception ex)
				{
					Logger.Error("Got the excpetion {0}", new object[]
					{
						ex.Message
					});
					Logger.Info("Giving the exit code to start as admin");
					Environment.Exit(2);
				}
				catch (Exception ex2)
				{
					Logger.Error("Got exception: err {0}", new object[]
					{
						ex2.ToString()
					});
				}
				string text = Directory.GetParent(path).ToString();
				Logger.Debug("The Process Dir is {0}", new object[]
				{
					text
				});
				if (text.Equals(IgnoreDirectory, StringComparison.CurrentCultureIgnoreCase))
				{
					Logger.Debug("Process:{0} not killed since the process sir:{1} and ignore dir:{2} are the same", new object[]
					{
						process.ProcessName,
						text,
						IgnoreDirectory
					});
				}
				else
				{
					Logger.Info(string.Concat(new object[]
					{
						"Killing PID ",
						process.Id,
						" -> ",
						process.ProcessName
					}));
					try
					{
						process.Kill();
					}
					catch (Exception ex3)
					{
						Logger.Error(ex3.ToString());
						goto IL_125;
					}
					if (!process.WaitForExit(5000))
					{
						Logger.Info("Timeout waiting for process to die");
					}
				}
				IL_125:;
			}
		}

		// Token: 0x06000BD0 RID: 3024 RVA: 0x00032E84 File Offset: 0x00031084
		public static void LogParentProcessDetails()
		{
			try
			{
				Process currentProcessParent = ProcessDetails.CurrentProcessParent;
				if (currentProcessParent == null)
				{
					Logger.Info("Unable to retrieve information about invoking process");
				}
				else
				{
					Logger.Info("Invoking Process Details: (Name: {0}, Pid: {1})", new object[]
					{
						currentProcessParent.ProcessName,
						currentProcessParent.Id
					});
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Unable to get parent process details, Err: {0}", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x06000BD1 RID: 3025 RVA: 0x00032EFC File Offset: 0x000310FC
		public static void LogProcessContextDetails()
		{
			Logger.Info("PID {0}, CLR version {0}", new object[]
			{
				Process.GetCurrentProcess().Id,
				Environment.Version
			});
			Logger.Info("IsAdministrator: {0}", new object[]
			{
				SystemUtils.IsAdministrator()
			});
		}

		// Token: 0x06000BD2 RID: 3026 RVA: 0x00032F50 File Offset: 0x00031150
		public static Process StartExe(string exePath, string args, bool isAdmin = false)
		{
			Process process = new Process();
			process.StartInfo.Arguments = args;
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.CreateNoWindow = true;
			process.StartInfo.FileName = exePath;
			if (isAdmin)
			{
				process.StartInfo.Verb = "runas";
				process.StartInfo.UseShellExecute = true;
			}
			Logger.Info("Utils: Starting Process : " + exePath);
			process.Start();
			return process;
		}
	}
}
