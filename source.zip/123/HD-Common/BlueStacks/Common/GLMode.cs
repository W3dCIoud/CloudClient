﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200015D RID: 349
	public enum GLMode
	{
		// Token: 0x040007FC RID: 2044
		PGA = 1,
		// Token: 0x040007FD RID: 2045
		AGA
	}
}
