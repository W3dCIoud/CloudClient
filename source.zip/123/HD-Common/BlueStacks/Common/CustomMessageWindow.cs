﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BlueStacks.Common
{
	// Token: 0x020000AC RID: 172
	public class CustomMessageWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x17000104 RID: 260
		// (get) Token: 0x06000432 RID: 1074 RVA: 0x0000451E File Offset: 0x0000271E
		// (set) Token: 0x06000433 RID: 1075 RVA: 0x00004526 File Offset: 0x00002726
		public double ContentMaxWidth
		{
			get
			{
				return this.mContentMaxWidth;
			}
			set
			{
				this.mContentMaxWidth = value;
				this.mTitleGrid.MaxWidth = value;
				this.mBodyTextStackPanel.MaxWidth = value;
				this.mProgressGrid.MaxWidth = value;
			}
		}

		// Token: 0x17000105 RID: 261
		// (set) Token: 0x06000434 RID: 1076 RVA: 0x00004553 File Offset: 0x00002753
		public bool ProgressBarEnabled
		{
			set
			{
				this.mProgressGrid.Visibility = (value ? Visibility.Visible : Visibility.Collapsed);
			}
		}

		// Token: 0x17000106 RID: 262
		// (set) Token: 0x06000435 RID: 1077 RVA: 0x00004567 File Offset: 0x00002767
		public bool ProgressStatusEnabled
		{
			set
			{
				this.mProgressUpdatesGrid.Visibility = (value ? Visibility.Visible : Visibility.Collapsed);
			}
		}

		// Token: 0x17000107 RID: 263
		// (set) Token: 0x06000436 RID: 1078 RVA: 0x0000457B File Offset: 0x0000277B
		public bool IsWindowMinizable
		{
			set
			{
				if (value)
				{
					this.mCustomMessageBoxMinimizeButton.Visibility = Visibility.Visible;
					return;
				}
				this.mCustomMessageBoxMinimizeButton.Visibility = Visibility.Hidden;
			}
		}

		// Token: 0x17000108 RID: 264
		// (set) Token: 0x06000437 RID: 1079 RVA: 0x00004599 File Offset: 0x00002799
		public bool IsWindowClosable
		{
			set
			{
				if (value)
				{
					this.mCustomMessageBoxCloseButton.Visibility = Visibility.Visible;
					return;
				}
				this.mCustomMessageBoxCloseButton.Visibility = Visibility.Hidden;
			}
		}

		// Token: 0x17000109 RID: 265
		// (set) Token: 0x06000438 RID: 1080 RVA: 0x000045B7 File Offset: 0x000027B7
		public bool IsWindowCloseButtonDisabled
		{
			set
			{
				if (value)
				{
					this.mCustomMessageBoxCloseButton.ToolTip = null;
					this.mCustomMessageBoxCloseButton.IsDisabled = true;
					this.mCustomMessageBoxCloseButton.PreviewMouseLeftButtonUp -= this.Close_PreviewMouseLeftButtonUp;
				}
			}
		}

		// Token: 0x1700010A RID: 266
		// (set) Token: 0x06000439 RID: 1081 RVA: 0x000045EB File Offset: 0x000027EB
		public string ImageName
		{
			set
			{
				this.mTitleIcon.ImageName = value;
				if (!string.IsNullOrEmpty(value))
				{
					this.mTitleIcon.Visibility = Visibility.Visible;
				}
			}
		}

		// Token: 0x1700010B RID: 267
		// (set) Token: 0x0600043A RID: 1082 RVA: 0x0000460D File Offset: 0x0000280D
		public bool IsWithoutButtons
		{
			set
			{
				if (value)
				{
					this.mStackPanel.Visibility = Visibility.Collapsed;
					return;
				}
				this.mStackPanel.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x1700010C RID: 268
		// (get) Token: 0x0600043B RID: 1083 RVA: 0x0000462B File Offset: 0x0000282B
		public TextBlock TitleTextBlock
		{
			get
			{
				return this.mTitleText;
			}
		}

		// Token: 0x1700010D RID: 269
		// (get) Token: 0x0600043C RID: 1084 RVA: 0x00004633 File Offset: 0x00002833
		public CustomPictureBox MessageIcon
		{
			get
			{
				return this.mMessageIcon;
			}
		}

		// Token: 0x1700010E RID: 270
		// (get) Token: 0x0600043D RID: 1085 RVA: 0x0000463B File Offset: 0x0000283B
		public TextBlock BodyTextBlockTitle
		{
			get
			{
				return this.mBodyTextBlockTitle;
			}
		}

		// Token: 0x1700010F RID: 271
		// (get) Token: 0x0600043E RID: 1086 RVA: 0x00004643 File Offset: 0x00002843
		public TextBlock BodyTextBlock
		{
			get
			{
				return this.mBodyTextBlock;
			}
		}

		// Token: 0x17000110 RID: 272
		// (get) Token: 0x0600043F RID: 1087 RVA: 0x0000464B File Offset: 0x0000284B
		public TextBlock BodyWarningTextBlock
		{
			get
			{
				return this.mBodyWarningTextBlock;
			}
		}

		// Token: 0x17000111 RID: 273
		// (get) Token: 0x06000440 RID: 1088 RVA: 0x00004653 File Offset: 0x00002853
		public TextBlock AboveBodyWarningTextBlock
		{
			get
			{
				return this.mAboveBodyWarningTextBlock;
			}
		}

		// Token: 0x17000112 RID: 274
		// (get) Token: 0x06000441 RID: 1089 RVA: 0x0000465B File Offset: 0x0000285B
		public CustomPictureBox CloseButton
		{
			get
			{
				return this.mCustomMessageBoxCloseButton;
			}
		}

		// Token: 0x17000113 RID: 275
		// (get) Token: 0x06000442 RID: 1090 RVA: 0x00004663 File Offset: 0x00002863
		public TextBlock UrlTextBlock
		{
			get
			{
				return this.mUrlTextBlock;
			}
		}

		// Token: 0x17000114 RID: 276
		// (get) Token: 0x06000443 RID: 1091 RVA: 0x0000466B File Offset: 0x0000286B
		public Hyperlink UrlLink
		{
			get
			{
				return this.mUrlLink;
			}
		}

		// Token: 0x17000115 RID: 277
		// (get) Token: 0x06000444 RID: 1092 RVA: 0x00004673 File Offset: 0x00002873
		public CustomCheckbox CheckBox
		{
			get
			{
				return this.mCheckBox;
			}
		}

		// Token: 0x17000116 RID: 278
		// (get) Token: 0x06000445 RID: 1093 RVA: 0x0000467B File Offset: 0x0000287B
		public BlueProgressBar CustomProgressBar
		{
			get
			{
				return this.mProgressbar;
			}
		}

		// Token: 0x17000117 RID: 279
		// (get) Token: 0x06000446 RID: 1094 RVA: 0x00004683 File Offset: 0x00002883
		public TextBlock ProgressStatusTextBlock
		{
			get
			{
				return this.mProgressStatus;
			}
		}

		// Token: 0x17000118 RID: 280
		// (get) Token: 0x06000447 RID: 1095 RVA: 0x0000468B File Offset: 0x0000288B
		public Label ProgressPercentageTextBlock
		{
			get
			{
				return this.mProgressPercentage;
			}
		}

		// Token: 0x17000119 RID: 281
		// (get) Token: 0x06000448 RID: 1096 RVA: 0x00004693 File Offset: 0x00002893
		// (set) Token: 0x06000449 RID: 1097 RVA: 0x0000469B File Offset: 0x0000289B
		public bool IsClosed { get; private set; }

		// Token: 0x1700011A RID: 282
		// (get) Token: 0x0600044A RID: 1098 RVA: 0x000046A4 File Offset: 0x000028A4
		// (set) Token: 0x0600044B RID: 1099 RVA: 0x000046AC File Offset: 0x000028AC
		public bool IsDraggable { get; set; }

		// Token: 0x0600044C RID: 1100 RVA: 0x000046B5 File Offset: 0x000028B5
		protected override void OnClosed(EventArgs e)
		{
			base.OnClosed(e);
			this.IsClosed = true;
		}

		// Token: 0x0600044D RID: 1101 RVA: 0x0001A348 File Offset: 0x00018548
		public CustomMessageWindow()
		{
			this.InitializeComponent();
			base.Loaded += this.CustomMessageWindow_Loaded;
			base.SizeChanged += this.CustomMessageWindow_SizeChanged;
			this.mStackPanel.Children.Clear();
			this.ContentMaxWidth = 340.0;
		}

		// Token: 0x0600044E RID: 1102 RVA: 0x0001A3B8 File Offset: 0x000185B8
		private void CustomMessageWindow_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (this.mStackPanel.ActualWidth > this.ContentMaxWidth)
			{
				if (this.mButton2 != null)
				{
					this.mStackPanel.Orientation = Orientation.Vertical;
					this.mStackPanel.Height = 90.0;
					this.mButton1.Width = this.ContentMaxWidth;
					this.mButton1.Height = 36.0;
					this.mButton2.Width = this.ContentMaxWidth;
					this.mButton2.Height = 36.0;
					this.mButton2.Margin = new Thickness(0.0, 15.0, 0.0, 0.0);
					this.FitEnlargedButtonText(this.mButton1);
					this.FitEnlargedButtonText(this.mButton2);
					return;
				}
				this.mButton1.MaxWidth = this.ContentMaxWidth;
				this.FitEnlargedButtonText(this.mButton1);
			}
		}

		// Token: 0x0600044F RID: 1103 RVA: 0x0001A4BC File Offset: 0x000186BC
		private void FitEnlargedButtonText(CustomButton button)
		{
			double num = this.ContentMaxWidth - 60.0;
			DataTemplate contentTemplate = button.Resources["TextContentTemplate"] as DataTemplate;
			button.ContentTemplate = contentTemplate;
			ContentPresenter contentPresenter = WpfUtils.FindVisualChild<ContentPresenter>(button);
			contentPresenter.ApplyTemplate();
			TextBlock textBlock = (TextBlock)contentPresenter.ContentTemplate.FindName("wrapTextBlock", contentPresenter);
			textBlock.FontSize = 15.0;
			textBlock.TextWrapping = TextWrapping.NoWrap;
			textBlock.TextTrimming = TextTrimming.CharacterEllipsis;
			textBlock.FlowDirection = FlowDirection.LeftToRight;
			Typeface typeface = new Typeface(textBlock.FontFamily, textBlock.FontStyle, textBlock.FontWeight, textBlock.FontStretch);
			if (new FormattedText(textBlock.Text, Thread.CurrentThread.CurrentCulture, textBlock.FlowDirection, typeface, textBlock.FontSize, textBlock.Foreground).WidthIncludingTrailingWhitespace > num)
			{
				BlueStacksUIBinding.Bind(button, textBlock.Text, FrameworkElement.ToolTipProperty);
			}
			textBlock.MaxWidth = num;
		}

		// Token: 0x06000450 RID: 1104 RVA: 0x000046C5 File Offset: 0x000028C5
		public void CustomMessageWindow_Loaded(object sender, RoutedEventArgs e)
		{
			if (base.Owner == null || InteropWindow.FindMainWindowState(this) == WindowState.Minimized)
			{
				base.WindowStartupLocation = WindowStartupLocation.CenterScreen;
			}
			if (this.mButton2 != null)
			{
				base.UpdateLayout();
			}
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x000046ED File Offset: 0x000028ED
		public void CloseButtonHandle(Predicate<object> handle, object data = null)
		{
			this.mCloseButtonEventHandler = handle;
			this.mCloseButtonEventData = data;
		}

		// Token: 0x06000452 RID: 1106 RVA: 0x0001A5A8 File Offset: 0x000187A8
		public void CloseButtonHandle(EventHandler handle, object data = null)
		{
			this.mCloseButtonEventHandler = delegate(object o)
			{
				if (handle != null)
				{
					handle(o, new EventArgs());
				}
				return false;
			};
			this.mCloseButtonEventData = data;
		}

		// Token: 0x06000453 RID: 1107 RVA: 0x0001A5DC File Offset: 0x000187DC
		private void HandleMouseDrag(object sender, MouseButtonEventArgs e)
		{
			if (this.IsDraggable && e.OriginalSource.GetType() != typeof(CustomPictureBox))
			{
				try
				{
					base.DragMove();
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x000046FD File Offset: 0x000028FD
		public void AddWarning(string title, string imageName = "")
		{
			this.mBodyWarningTextBlock.Text = title;
			if (!string.IsNullOrEmpty(imageName))
			{
				this.mMessageIcon.Visibility = Visibility.Visible;
				this.mMessageIcon.ImageName = imageName;
			}
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x0000472B File Offset: 0x0000292B
		public void AddAboveBodyWarning(string title, string imageName = "")
		{
			this.mAboveBodyWarningTextBlock.Text = title;
		}

		// Token: 0x06000456 RID: 1110 RVA: 0x00004739 File Offset: 0x00002939
		public void AddButton(ButtonColors color, string text, EventHandler handle, string image = null, bool ChangeImageAlignment = false, object data = null)
		{
			this.AddButtonInUI(new CustomButton(color), color, text, handle, image, ChangeImageAlignment, data);
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x0001A624 File Offset: 0x00018824
		public void AddButtonInUI(CustomButton button, ButtonColors color, string text, EventHandler handle, string image, bool ChangeImageAlignment, object data)
		{
			if (this.mButton1 == null)
			{
				this.mButton1 = button;
			}
			else
			{
				this.mButton2 = button;
				button.Margin = new Thickness(15.0, 0.0, 0.0, 0.0);
			}
			button.Click += this.Button_Click;
			button.MinWidth = 100.0;
			button.Visibility = Visibility.Visible;
			BlueStacksUIBinding.Bind(button, text);
			if (image != null)
			{
				button.ImageName = image;
				if (ChangeImageAlignment)
				{
					button.FlowDirection = FlowDirection.RightToLeft;
				}
			}
			this.mStackPanel.Children.Add(button);
			this.mDictActions.Add(button, new Tuple<ButtonColors, EventHandler, object>(color, handle, data));
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x0001A6E8 File Offset: 0x000188E8
		public void AddHyperLinkInUI(string text, Uri navigateUri, RequestNavigateEventHandler handle)
		{
			Hyperlink hyperlink = new Hyperlink(new Run(text))
			{
				NavigateUri = navigateUri
			};
			hyperlink.RequestNavigate += handle.Invoke;
			hyperlink.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#047CD2"));
			this.mUrlTextBlock.Inlines.Clear();
			this.mUrlTextBlock.Inlines.Add(hyperlink);
			this.mUrlTextBlock.Visibility = Visibility.Visible;
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x0001A764 File Offset: 0x00018964
		public void Button_Click(object sender, RoutedEventArgs e)
		{
			this.ClickedButton = this.mDictActions[sender].Item1;
			if (this.mDictActions[sender].Item2 != null)
			{
				this.mDictActions[sender].Item2(this.mDictActions[sender].Item3, new EventArgs());
			}
			this.CloseWindow();
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x00004750 File Offset: 0x00002950
		private void Close_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mCloseButtonEventHandler != null && this.mCloseButtonEventHandler(this.mCloseButtonEventData))
			{
				return;
			}
			this.CloseWindow();
		}

		// Token: 0x0600045B RID: 1115 RVA: 0x00004774 File Offset: 0x00002974
		public void CloseWindow()
		{
			base.Close();
		}

		// Token: 0x0600045C RID: 1116 RVA: 0x0000477C File Offset: 0x0000297C
		private void Minimize_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			EventHandler minimizeEventHandler = this.MinimizeEventHandler;
			if (minimizeEventHandler != null)
			{
				minimizeEventHandler(this, null);
			}
			base.WindowState = WindowState.Minimized;
		}

		// Token: 0x0600045D RID: 1117 RVA: 0x0001A7D0 File Offset: 0x000189D0
		public void AddBulletInBody(string text)
		{
			Ellipse ellipse = new Ellipse();
			ellipse.Width = 9.0;
			ellipse.Height = 9.0;
			ellipse.VerticalAlignment = VerticalAlignment.Center;
			BlueStacksUIBinding.BindColor(ellipse, Shape.FillProperty, "ContextMenuItemForegroundDimColor");
			TextBlock textBlock = new TextBlock();
			textBlock.FontSize = 18.0;
			textBlock.MaxWidth = 300.0;
			textBlock.FontWeight = FontWeights.Regular;
			BlueStacksUIBinding.BindColor(textBlock, Control.ForegroundProperty, "ContextMenuItemForegroundDimColor");
			textBlock.TextWrapping = TextWrapping.Wrap;
			textBlock.Text = text;
			textBlock.HorizontalAlignment = HorizontalAlignment.Left;
			textBlock.VerticalAlignment = VerticalAlignment.Center;
			textBlock.Margin = new Thickness(0.0, 0.0, 0.0, 10.0);
			BulletDecorator bulletDecorator = new BulletDecorator();
			bulletDecorator.Bullet = ellipse;
			bulletDecorator.Child = textBlock;
			this.mBodyTextStackPanel.Children.Add(bulletDecorator);
		}

		// Token: 0x0600045E RID: 1118 RVA: 0x00004798 File Offset: 0x00002998
		private void mMessageIcon_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (this.mMessageIcon.Visibility == Visibility.Visible)
			{
				this.mTitleGrid.MaxWidth = this.ContentMaxWidth + 85.0;
				return;
			}
			this.mTitleGrid.MaxWidth = this.ContentMaxWidth;
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x0001A8C8 File Offset: 0x00018AC8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/custommessagewindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x00003339 File Offset: 0x00001539
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x0001A8F8 File Offset: 0x00018AF8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				this.mParentGrid = (Grid)target;
				this.mParentGrid.MouseDown += this.HandleMouseDrag;
				return;
			case 3:
				this.mTitleGrid = (Grid)target;
				return;
			case 4:
				this.mTitleIcon = (CustomPictureBox)target;
				return;
			case 5:
				this.mTitleText = (TextBlock)target;
				return;
			case 6:
				this.mCustomMessageBoxMinimizeButton = (CustomPictureBox)target;
				return;
			case 7:
				this.mCustomMessageBoxCloseButton = (CustomPictureBox)target;
				return;
			case 8:
				this.mMessageIcon = (CustomPictureBox)target;
				return;
			case 9:
				this.mTextBlockGrid = (Grid)target;
				return;
			case 10:
				this.mBodyTextStackPanel = (StackPanel)target;
				return;
			case 11:
				this.mBodyTextBlockTitle = (TextBlock)target;
				return;
			case 12:
				this.mAboveBodyWarningTextBlock = (TextBlock)target;
				return;
			case 13:
				this.mBodyTextBlock = (TextBlock)target;
				return;
			case 14:
				this.mBodyWarningTextBlock = (TextBlock)target;
				return;
			case 15:
				this.mUrlTextBlock = (TextBlock)target;
				return;
			case 16:
				this.mUrlLink = (Hyperlink)target;
				return;
			case 17:
				this.mCheckBox = (CustomCheckbox)target;
				return;
			case 18:
				this.mProgressGrid = (Grid)target;
				return;
			case 19:
				this.mProgressbar = (BlueProgressBar)target;
				return;
			case 20:
				this.mProgressUpdatesGrid = (Grid)target;
				return;
			case 21:
				this.mProgressStatus = (TextBlock)target;
				return;
			case 22:
				this.mProgressPercentage = (Label)target;
				return;
			case 23:
				this.mStackPanel = (StackPanel)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040003D7 RID: 983
		private Dictionary<object, Tuple<ButtonColors, EventHandler, object>> mDictActions = new Dictionary<object, Tuple<ButtonColors, EventHandler, object>>();

		// Token: 0x040003D8 RID: 984
		private Predicate<object> mCloseButtonEventHandler;

		// Token: 0x040003D9 RID: 985
		public EventHandler MinimizeEventHandler;

		// Token: 0x040003DA RID: 986
		private CustomButton mButton1;

		// Token: 0x040003DB RID: 987
		private CustomButton mButton2;

		// Token: 0x040003DC RID: 988
		private object mCloseButtonEventData;

		// Token: 0x040003DD RID: 989
		public ButtonColors ClickedButton = ButtonColors.Background;

		// Token: 0x040003DE RID: 990
		private double mContentMaxWidth;

		// Token: 0x040003E1 RID: 993
		internal Border mMaskBorder;

		// Token: 0x040003E2 RID: 994
		internal Grid mParentGrid;

		// Token: 0x040003E3 RID: 995
		internal Grid mTitleGrid;

		// Token: 0x040003E4 RID: 996
		internal CustomPictureBox mTitleIcon;

		// Token: 0x040003E5 RID: 997
		internal TextBlock mTitleText;

		// Token: 0x040003E6 RID: 998
		internal CustomPictureBox mCustomMessageBoxMinimizeButton;

		// Token: 0x040003E7 RID: 999
		internal CustomPictureBox mCustomMessageBoxCloseButton;

		// Token: 0x040003E8 RID: 1000
		internal CustomPictureBox mMessageIcon;

		// Token: 0x040003E9 RID: 1001
		internal Grid mTextBlockGrid;

		// Token: 0x040003EA RID: 1002
		internal StackPanel mBodyTextStackPanel;

		// Token: 0x040003EB RID: 1003
		internal TextBlock mBodyTextBlockTitle;

		// Token: 0x040003EC RID: 1004
		internal TextBlock mAboveBodyWarningTextBlock;

		// Token: 0x040003ED RID: 1005
		internal TextBlock mBodyTextBlock;

		// Token: 0x040003EE RID: 1006
		internal TextBlock mBodyWarningTextBlock;

		// Token: 0x040003EF RID: 1007
		internal TextBlock mUrlTextBlock;

		// Token: 0x040003F0 RID: 1008
		internal Hyperlink mUrlLink;

		// Token: 0x040003F1 RID: 1009
		internal CustomCheckbox mCheckBox;

		// Token: 0x040003F2 RID: 1010
		internal Grid mProgressGrid;

		// Token: 0x040003F3 RID: 1011
		internal BlueProgressBar mProgressbar;

		// Token: 0x040003F4 RID: 1012
		internal Grid mProgressUpdatesGrid;

		// Token: 0x040003F5 RID: 1013
		internal TextBlock mProgressStatus;

		// Token: 0x040003F6 RID: 1014
		internal Label mProgressPercentage;

		// Token: 0x040003F7 RID: 1015
		internal StackPanel mStackPanel;

		// Token: 0x040003F8 RID: 1016
		private bool _contentLoaded;
	}
}
