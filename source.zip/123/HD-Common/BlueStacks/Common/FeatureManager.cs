﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Xml;
using System.Xml.Serialization;

namespace BlueStacks.Common
{
	// Token: 0x020000B4 RID: 180
	public class FeatureManager
	{
		// Token: 0x17000123 RID: 291
		// (get) Token: 0x060004A1 RID: 1185 RVA: 0x0001B56C File Offset: 0x0001976C
		public static FeatureManager Instance
		{
			get
			{
				if (FeatureManager.sInstance == null)
				{
					object obj = FeatureManager.syncRoot;
					lock (obj)
					{
						if (FeatureManager.sInstance == null)
						{
							FeatureManager.sInstance = new FeatureManager();
							FeatureManager.Init(true);
						}
					}
				}
				return FeatureManager.sInstance;
			}
		}

		// Token: 0x060004A2 RID: 1186 RVA: 0x0001B5CC File Offset: 0x000197CC
		public static void Init(bool isAsync = true)
		{
			try
			{
				string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
				FeatureManager.sFilePath = Path.Combine(RegistryManager.Instance.ClientInstallDir, "bst_config");
				if (RegistryManager.Instance.UpdateBstConfig)
				{
					FeatureManager.DownloadBstConfig(isAsync);
				}
				else if (File.Exists(FeatureManager.sFilePath))
				{
					Logger.Info("Loading cfg from : " + FeatureManager.sFilePath);
					FeatureManager.LoadFile(FeatureManager.sFilePath, true);
				}
				else
				{
					Logger.Info("bst_config not found. Trying to fetch new file from cloud.");
					FeatureManager.DownloadBstConfig(isAsync);
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Error loading config" + ex.ToString());
			}
		}

		// Token: 0x060004A3 RID: 1187 RVA: 0x00004A66 File Offset: 0x00002C66
		private static void DownloadBstConfig(bool isAsync)
		{
			FeatureManager.SetDefaultSettings();
			if (isAsync)
			{
				FeatureManager.DownloadFileAsync();
				return;
			}
			FeatureManager.DownloadFile();
		}

		// Token: 0x060004A4 RID: 1188 RVA: 0x00004A7B File Offset: 0x00002C7B
		private static void DownloadFileAsync()
		{
			new Thread(delegate()
			{
				FeatureManager.DownloadFile();
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060004A5 RID: 1189 RVA: 0x0001B678 File Offset: 0x00019878
		private static void DownloadFile()
		{
			try
			{
				string urlWithParams = WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/serve_config_file");
				string directoryName = Path.GetDirectoryName(FeatureManager.sFilePath);
				if (!Directory.Exists(directoryName))
				{
					Logger.Info("--------- For debugging -------. FeatureManager was used before creating directory. This should not happen.");
					Directory.CreateDirectory(directoryName);
				}
				new WebClient().DownloadFile(urlWithParams, FeatureManager.sFilePath);
				RegistryManager.Instance.UpdateBstConfig = false;
			}
			catch (Exception ex)
			{
				Logger.Warning("Failed to download bst_config file. Err: " + ex.ToString());
				RegistryManager.Instance.UpdateBstConfig = true;
				return;
			}
			FeatureManager.LoadFile(FeatureManager.sFilePath, false);
		}

		// Token: 0x060004A6 RID: 1190 RVA: 0x00004AAD File Offset: 0x00002CAD
		private static void SetDefaultSettings()
		{
			if (FeatureManager.sInstance == null)
			{
				FeatureManager.sInstance = new FeatureManager();
			}
		}

		// Token: 0x060004A7 RID: 1191 RVA: 0x0001B71C File Offset: 0x0001991C
		public static void LoadFile(string filePath, bool retryOnError = true)
		{
			try
			{
				using (FileStream fileStream = File.OpenRead(filePath))
				{
					Logger.Info("Loading Oem Settings from " + filePath);
					FeatureManager.sInstance = (FeatureManager)new XmlSerializer(typeof(FeatureManager)).Deserialize(fileStream);
					fileStream.Flush();
				}
			}
			catch (Exception)
			{
				FeatureManager.SetDefaultSettings();
				try
				{
					if (retryOnError)
					{
						if (File.Exists(filePath))
						{
							File.Delete(filePath);
						}
						FeatureManager.DownloadFileAsync();
					}
				}
				catch (Exception)
				{
				}
			}
		}

		// Token: 0x060004A8 RID: 1192 RVA: 0x0001B7C0 File Offset: 0x000199C0
		internal void Save()
		{
			try
			{
				using (XmlTextWriter xmlTextWriter = new XmlTextWriter(FeatureManager.sFilePath, Encoding.UTF8))
				{
					xmlTextWriter.Formatting = Formatting.Indented;
					new XmlSerializer(typeof(FeatureManager)).Serialize(xmlTextWriter, FeatureManager.sInstance);
					xmlTextWriter.Flush();
				}
			}
			catch (Exception ex)
			{
				Logger.Info(ex.ToString());
			}
		}

		// Token: 0x17000124 RID: 292
		// (get) Token: 0x060004A9 RID: 1193 RVA: 0x00004AC4 File Offset: 0x00002CC4
		// (set) Token: 0x060004AA RID: 1194 RVA: 0x00004ACC File Offset: 0x00002CCC
		public bool IsBTVEnabled
		{
			get
			{
				return this.mIsBTVEnabled;
			}
			set
			{
				this.mIsBTVEnabled = value;
			}
		}

		// Token: 0x17000125 RID: 293
		// (get) Token: 0x060004AB RID: 1195 RVA: 0x00004AD5 File Offset: 0x00002CD5
		// (set) Token: 0x060004AC RID: 1196 RVA: 0x00004ADD File Offset: 0x00002CDD
		public bool IsWallpaperChangeDisabled
		{
			get
			{
				return this.mIsWallpaperChangeDisabled;
			}
			set
			{
				this.mIsWallpaperChangeDisabled = value;
			}
		}

		// Token: 0x17000126 RID: 294
		// (get) Token: 0x060004AD RID: 1197 RVA: 0x00004AE6 File Offset: 0x00002CE6
		// (set) Token: 0x060004AE RID: 1198 RVA: 0x00004AEE File Offset: 0x00002CEE
		public bool IsCreateBrowserOnStart
		{
			get
			{
				return this.mIsCreateBrowserOnStart;
			}
			set
			{
				this.mIsCreateBrowserOnStart = value;
			}
		}

		// Token: 0x17000127 RID: 295
		// (get) Token: 0x060004AF RID: 1199 RVA: 0x00004AF7 File Offset: 0x00002CF7
		// (set) Token: 0x060004B0 RID: 1200 RVA: 0x00004AFF File Offset: 0x00002CFF
		public bool IsOpenActivityFromAccountIcon
		{
			get
			{
				return this.mIsOpenActivityFromAccountIcon;
			}
			set
			{
				this.mIsOpenActivityFromAccountIcon = value;
			}
		}

		// Token: 0x17000128 RID: 296
		// (get) Token: 0x060004B1 RID: 1201 RVA: 0x00004B08 File Offset: 0x00002D08
		// (set) Token: 0x060004B2 RID: 1202 RVA: 0x00004B10 File Offset: 0x00002D10
		public bool IsBrowserKilledOnTabSwitch
		{
			get
			{
				return this.mIsBrowserKilledOnTabSwitch;
			}
			set
			{
				this.mIsBrowserKilledOnTabSwitch = value;
			}
		}

		// Token: 0x17000129 RID: 297
		// (get) Token: 0x060004B3 RID: 1203 RVA: 0x00004B19 File Offset: 0x00002D19
		// (set) Token: 0x060004B4 RID: 1204 RVA: 0x00004B21 File Offset: 0x00002D21
		public bool IsPromotionDisabled
		{
			get
			{
				return this.mIsPromotionDisabled;
			}
			set
			{
				this.mIsPromotionDisabled = value;
			}
		}

		// Token: 0x1700012A RID: 298
		// (get) Token: 0x060004B5 RID: 1205 RVA: 0x00004B2A File Offset: 0x00002D2A
		// (set) Token: 0x060004B6 RID: 1206 RVA: 0x00004B32 File Offset: 0x00002D32
		public bool IsGuidBackUpEnable
		{
			get
			{
				return this.mIsGuidBackUpEnable;
			}
			set
			{
				this.mIsGuidBackUpEnable = value;
			}
		}

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x060004B7 RID: 1207 RVA: 0x00004B3B File Offset: 0x00002D3B
		// (set) Token: 0x060004B8 RID: 1208 RVA: 0x00004B43 File Offset: 0x00002D43
		public bool IsCustomUIForDMMSandbox
		{
			get
			{
				return this.mIsCustomUIForDMMSandbox;
			}
			set
			{
				this.mIsCustomUIForDMMSandbox = value;
			}
		}

		// Token: 0x1700012C RID: 300
		// (get) Token: 0x060004B9 RID: 1209 RVA: 0x00004B4C File Offset: 0x00002D4C
		// (set) Token: 0x060004BA RID: 1210 RVA: 0x00004B54 File Offset: 0x00002D54
		public bool IsCustomUIForDMM
		{
			get
			{
				return this.mIsCustomUIForDMM;
			}
			set
			{
				this.mIsCustomUIForDMM = value;
			}
		}

		// Token: 0x1700012D RID: 301
		// (get) Token: 0x060004BB RID: 1211 RVA: 0x00004B5D File Offset: 0x00002D5D
		// (set) Token: 0x060004BC RID: 1212 RVA: 0x00004B65 File Offset: 0x00002D65
		public bool IsThemeEnabled
		{
			get
			{
				return this.mIsThemeEnabled;
			}
			set
			{
				this.mIsThemeEnabled = value;
			}
		}

		// Token: 0x1700012E RID: 302
		// (get) Token: 0x060004BD RID: 1213 RVA: 0x00004B6E File Offset: 0x00002D6E
		// (set) Token: 0x060004BE RID: 1214 RVA: 0x00004B76 File Offset: 0x00002D76
		public bool IsSearchBarVisible
		{
			get
			{
				return this.mIsSearchBarVisible;
			}
			set
			{
				this.mIsSearchBarVisible = value;
			}
		}

		// Token: 0x1700012F RID: 303
		// (get) Token: 0x060004BF RID: 1215 RVA: 0x00004B7F File Offset: 0x00002D7F
		// (set) Token: 0x060004C0 RID: 1216 RVA: 0x00004B87 File Offset: 0x00002D87
		public bool IsCustomResolutionInputAllowed
		{
			get
			{
				return this.mIsCustomResolutionInputAllowed;
			}
			set
			{
				this.mIsCustomResolutionInputAllowed = value;
			}
		}

		// Token: 0x17000130 RID: 304
		// (get) Token: 0x060004C1 RID: 1217 RVA: 0x00004B90 File Offset: 0x00002D90
		// (set) Token: 0x060004C2 RID: 1218 RVA: 0x00004B98 File Offset: 0x00002D98
		public bool ShowBeginnersGuidePreference
		{
			get
			{
				return this.mShowBeginnersGuidePreference;
			}
			set
			{
				this.mShowBeginnersGuidePreference = value;
			}
		}

		// Token: 0x17000131 RID: 305
		// (get) Token: 0x060004C3 RID: 1219 RVA: 0x00004BA1 File Offset: 0x00002DA1
		// (set) Token: 0x060004C4 RID: 1220 RVA: 0x00004BA9 File Offset: 0x00002DA9
		public bool IsShowNotificationCentre
		{
			get
			{
				return this.mIsShowNotificationCentre;
			}
			set
			{
				this.mIsShowNotificationCentre = value;
			}
		}

		// Token: 0x17000132 RID: 306
		// (get) Token: 0x060004C5 RID: 1221 RVA: 0x00004BB2 File Offset: 0x00002DB2
		// (set) Token: 0x060004C6 RID: 1222 RVA: 0x00004BBA File Offset: 0x00002DBA
		public bool IsUseWpfTextbox
		{
			get
			{
				return this.mIsUseWpfTextbox;
			}
			set
			{
				this.mIsUseWpfTextbox = value;
			}
		}

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x060004C7 RID: 1223 RVA: 0x00004BC3 File Offset: 0x00002DC3
		// (set) Token: 0x060004C8 RID: 1224 RVA: 0x00004BCB File Offset: 0x00002DCB
		public bool IsComboKeysDisabled
		{
			get
			{
				return this.mIsComboKeysDisabled;
			}
			set
			{
				this.mIsComboKeysDisabled = value;
			}
		}

		// Token: 0x17000134 RID: 308
		// (get) Token: 0x060004C9 RID: 1225 RVA: 0x00004BD4 File Offset: 0x00002DD4
		// (set) Token: 0x060004CA RID: 1226 RVA: 0x00004BDC File Offset: 0x00002DDC
		public bool IsMacroRecorderEnabled
		{
			get
			{
				return this.mIsMacroRecorderEnabled;
			}
			set
			{
				this.mIsMacroRecorderEnabled = value;
			}
		}

		// Token: 0x17000135 RID: 309
		// (get) Token: 0x060004CB RID: 1227 RVA: 0x00004BE5 File Offset: 0x00002DE5
		// (set) Token: 0x060004CC RID: 1228 RVA: 0x00004BED File Offset: 0x00002DED
		public bool IsFarmingModeDisabled
		{
			get
			{
				return this.mIsFarmingModeDisabled;
			}
			set
			{
				this.mIsFarmingModeDisabled = value;
			}
		}

		// Token: 0x17000136 RID: 310
		// (get) Token: 0x060004CD RID: 1229 RVA: 0x00004BF6 File Offset: 0x00002DF6
		// (set) Token: 0x060004CE RID: 1230 RVA: 0x00004BFE File Offset: 0x00002DFE
		public bool IsOperationsSyncEnabled
		{
			get
			{
				return this.mIsOperationsSyncEnabled;
			}
			set
			{
				this.mIsOperationsSyncEnabled = value;
			}
		}

		// Token: 0x17000137 RID: 311
		// (get) Token: 0x060004CF RID: 1231 RVA: 0x00004C07 File Offset: 0x00002E07
		// (set) Token: 0x060004D0 RID: 1232 RVA: 0x00004C0F File Offset: 0x00002E0F
		public bool IsRotateScreenDisabled
		{
			get
			{
				return this.mIsRotateScreenDisabled;
			}
			set
			{
				this.mIsRotateScreenDisabled = value;
			}
		}

		// Token: 0x17000138 RID: 312
		// (get) Token: 0x060004D1 RID: 1233 RVA: 0x00004C18 File Offset: 0x00002E18
		// (set) Token: 0x060004D2 RID: 1234 RVA: 0x00004C20 File Offset: 0x00002E20
		public bool IsUserAccountBtnEnabled
		{
			get
			{
				return this.mIsUserAccountBtnEnabled;
			}
			set
			{
				this.mIsUserAccountBtnEnabled = value;
			}
		}

		// Token: 0x17000139 RID: 313
		// (get) Token: 0x060004D3 RID: 1235 RVA: 0x00004C29 File Offset: 0x00002E29
		// (set) Token: 0x060004D4 RID: 1236 RVA: 0x00004C31 File Offset: 0x00002E31
		public bool IsWarningBtnEnabled
		{
			get
			{
				return this.mIsWarningBtnEnabled;
			}
			set
			{
				this.mIsWarningBtnEnabled = value;
			}
		}

		// Token: 0x1700013A RID: 314
		// (get) Token: 0x060004D5 RID: 1237 RVA: 0x00004C3A File Offset: 0x00002E3A
		// (set) Token: 0x060004D6 RID: 1238 RVA: 0x00004C42 File Offset: 0x00002E42
		public bool IsAppCenterTabVisible
		{
			get
			{
				return this.mIsAppCenterTabVisible;
			}
			set
			{
				this.mIsAppCenterTabVisible = value;
			}
		}

		// Token: 0x1700013B RID: 315
		// (get) Token: 0x060004D7 RID: 1239 RVA: 0x00004C4B File Offset: 0x00002E4B
		// (set) Token: 0x060004D8 RID: 1240 RVA: 0x00004C53 File Offset: 0x00002E53
		public bool IsMultiInstanceControlsGridVisible
		{
			get
			{
				return this.mIsMultiInstanceControlsGridVisible;
			}
			set
			{
				this.mIsMultiInstanceControlsGridVisible = value;
			}
		}

		// Token: 0x1700013C RID: 316
		// (get) Token: 0x060004D9 RID: 1241 RVA: 0x00004C5C File Offset: 0x00002E5C
		// (set) Token: 0x060004DA RID: 1242 RVA: 0x00004C64 File Offset: 0x00002E64
		public bool IsPromotionFixed
		{
			get
			{
				return this.mIsPromotionFixed;
			}
			set
			{
				this.mIsPromotionFixed = value;
			}
		}

		// Token: 0x1700013D RID: 317
		// (get) Token: 0x060004DB RID: 1243 RVA: 0x00004C6D File Offset: 0x00002E6D
		// (set) Token: 0x060004DC RID: 1244 RVA: 0x00004C75 File Offset: 0x00002E75
		public bool IsShowLanguagePreference
		{
			get
			{
				return this.mIsShowLanguagePreference;
			}
			set
			{
				this.mIsShowLanguagePreference = value;
			}
		}

		// Token: 0x1700013E RID: 318
		// (get) Token: 0x060004DD RID: 1245 RVA: 0x00004C7E File Offset: 0x00002E7E
		// (set) Token: 0x060004DE RID: 1246 RVA: 0x00004C86 File Offset: 0x00002E86
		public bool IsShowDesktopShortcutPreference
		{
			get
			{
				return this.mIsShowDektopShortcutPreference;
			}
			set
			{
				this.mIsShowDektopShortcutPreference = value;
			}
		}

		// Token: 0x1700013F RID: 319
		// (get) Token: 0x060004DF RID: 1247 RVA: 0x00004C8F File Offset: 0x00002E8F
		// (set) Token: 0x060004E0 RID: 1248 RVA: 0x00004C97 File Offset: 0x00002E97
		public bool IsShowGamingSummaryPreference
		{
			get
			{
				return this.mIsShowGamingSummaryPreference;
			}
			set
			{
				this.mIsShowGamingSummaryPreference = value;
			}
		}

		// Token: 0x17000140 RID: 320
		// (get) Token: 0x060004E1 RID: 1249 RVA: 0x00004CA0 File Offset: 0x00002EA0
		// (set) Token: 0x060004E2 RID: 1250 RVA: 0x00004CA8 File Offset: 0x00002EA8
		public bool IsShowSpeedUpTips
		{
			get
			{
				return this.mIsShowSpeedUpTips;
			}
			set
			{
				this.mIsShowSpeedUpTips = value;
			}
		}

		// Token: 0x17000141 RID: 321
		// (get) Token: 0x060004E3 RID: 1251 RVA: 0x00004CB1 File Offset: 0x00002EB1
		// (set) Token: 0x060004E4 RID: 1252 RVA: 0x00004CB9 File Offset: 0x00002EB9
		public bool IsShowPostOTSScreen
		{
			get
			{
				return this.mIsShowPostOTSScreen;
			}
			set
			{
				this.mIsShowPostOTSScreen = value;
			}
		}

		// Token: 0x17000142 RID: 322
		// (get) Token: 0x060004E5 RID: 1253 RVA: 0x00004CC2 File Offset: 0x00002EC2
		// (set) Token: 0x060004E6 RID: 1254 RVA: 0x00004CCA File Offset: 0x00002ECA
		public bool IsShowHelpCenter
		{
			get
			{
				return this.mIsShowHelpCenterGrid;
			}
			set
			{
				this.mIsShowHelpCenterGrid = value;
			}
		}

		// Token: 0x17000143 RID: 323
		// (get) Token: 0x060004E7 RID: 1255 RVA: 0x00004CD3 File Offset: 0x00002ED3
		// (set) Token: 0x060004E8 RID: 1256 RVA: 0x00004CDB File Offset: 0x00002EDB
		public bool IsAppSettingsAvailable
		{
			get
			{
				return this.mIsAppSettingsAvailable;
			}
			set
			{
				this.mIsAppSettingsAvailable = value;
			}
		}

		// Token: 0x17000144 RID: 324
		// (get) Token: 0x060004E9 RID: 1257 RVA: 0x00004CE4 File Offset: 0x00002EE4
		// (set) Token: 0x060004EA RID: 1258 RVA: 0x00004CEC File Offset: 0x00002EEC
		public bool IsShowPerformancePreference
		{
			get
			{
				return this.mIsShowPerformancePreference;
			}
			set
			{
				this.mIsShowPerformancePreference = value;
			}
		}

		// Token: 0x17000145 RID: 325
		// (get) Token: 0x060004EB RID: 1259 RVA: 0x00004CF5 File Offset: 0x00002EF5
		// (set) Token: 0x060004EC RID: 1260 RVA: 0x00004CFD File Offset: 0x00002EFD
		public bool IsShowDiscordPreference
		{
			get
			{
				return this.mIsShowDiscordPreference;
			}
			set
			{
				this.mIsShowDiscordPreference = value;
			}
		}

		// Token: 0x17000146 RID: 326
		// (get) Token: 0x060004ED RID: 1261 RVA: 0x00004D06 File Offset: 0x00002F06
		// (set) Token: 0x060004EE RID: 1262 RVA: 0x00004D0E File Offset: 0x00002F0E
		public bool IsCustomUIForNCSoft
		{
			get
			{
				return this.mIsCustomUIForNCSoft;
			}
			set
			{
				this.mIsCustomUIForNCSoft = value;
			}
		}

		// Token: 0x17000147 RID: 327
		// (get) Token: 0x060004EF RID: 1263 RVA: 0x00004D17 File Offset: 0x00002F17
		// (set) Token: 0x060004F0 RID: 1264 RVA: 0x00004D1F File Offset: 0x00002F1F
		public bool AllowADBSettingToggle
		{
			get
			{
				return this.mAllowADBSettingToggle;
			}
			set
			{
				this.mAllowADBSettingToggle = value;
			}
		}

		// Token: 0x17000148 RID: 328
		// (get) Token: 0x060004F1 RID: 1265 RVA: 0x00004D28 File Offset: 0x00002F28
		// (set) Token: 0x060004F2 RID: 1266 RVA: 0x00004D30 File Offset: 0x00002F30
		public bool ShowClientOnTopPreference
		{
			get
			{
				return this.mShowClientOnTopPreference;
			}
			set
			{
				this.mShowClientOnTopPreference = value;
			}
		}

		// Token: 0x17000149 RID: 329
		// (get) Token: 0x060004F3 RID: 1267 RVA: 0x00004D39 File Offset: 0x00002F39
		// (set) Token: 0x060004F4 RID: 1268 RVA: 0x00004D41 File Offset: 0x00002F41
		public bool IsAllowGameRecording { get; set; } = true;

		// Token: 0x1700014A RID: 330
		// (get) Token: 0x060004F5 RID: 1269 RVA: 0x00004D4A File Offset: 0x00002F4A
		// (set) Token: 0x060004F6 RID: 1270 RVA: 0x00004D52 File Offset: 0x00002F52
		public bool IsShowAppRecommendations
		{
			get
			{
				return this.mIsShowAppRecommendations;
			}
			set
			{
				this.mIsShowAppRecommendations = value;
			}
		}

		// Token: 0x1700014B RID: 331
		// (get) Token: 0x060004F7 RID: 1271 RVA: 0x00004D5B File Offset: 0x00002F5B
		// (set) Token: 0x060004F8 RID: 1272 RVA: 0x00004D63 File Offset: 0x00002F63
		public bool IsCheckForQuitPopup { get; set; } = true;

		// Token: 0x1700014C RID: 332
		// (get) Token: 0x060004F9 RID: 1273 RVA: 0x00004D6C File Offset: 0x00002F6C
		// (set) Token: 0x060004FA RID: 1274 RVA: 0x00004D74 File Offset: 0x00002F74
		public bool IsCustomCursorEnabled { get; set; }

		// Token: 0x1700014D RID: 333
		// (get) Token: 0x060004FB RID: 1275 RVA: 0x00004D7D File Offset: 0x00002F7D
		// (set) Token: 0x060004FC RID: 1276 RVA: 0x00004D85 File Offset: 0x00002F85
		public bool ForceEnableMacroAndSync { get; set; }

		// Token: 0x1700014E RID: 334
		// (get) Token: 0x060004FD RID: 1277 RVA: 0x00004D8E File Offset: 0x00002F8E
		// (set) Token: 0x060004FE RID: 1278 RVA: 0x00004D96 File Offset: 0x00002F96
		public bool IsHtmlSideBar { get; set; } = true;

		// Token: 0x04000410 RID: 1040
		private const string sConfigFilename = "bst_config";

		// Token: 0x04000411 RID: 1041
		private static string sFilePath = string.Empty;

		// Token: 0x04000412 RID: 1042
		private static volatile FeatureManager sInstance;

		// Token: 0x04000413 RID: 1043
		private static object syncRoot = new object();

		// Token: 0x04000414 RID: 1044
		private bool mIsBTVEnabled;

		// Token: 0x04000415 RID: 1045
		private bool mIsWallpaperChangeDisabled;

		// Token: 0x04000416 RID: 1046
		private bool mIsCreateBrowserOnStart;

		// Token: 0x04000417 RID: 1047
		private bool mIsOpenActivityFromAccountIcon;

		// Token: 0x04000418 RID: 1048
		private bool mIsBrowserKilledOnTabSwitch;

		// Token: 0x04000419 RID: 1049
		private bool mIsPromotionDisabled;

		// Token: 0x0400041A RID: 1050
		private bool mIsGuidBackUpEnable = true;

		// Token: 0x0400041B RID: 1051
		private bool mIsCustomUIForDMMSandbox;

		// Token: 0x0400041C RID: 1052
		private bool mIsCustomUIForDMM;

		// Token: 0x0400041D RID: 1053
		private bool mIsThemeEnabled = true;

		// Token: 0x0400041E RID: 1054
		private bool mIsSearchBarVisible = true;

		// Token: 0x0400041F RID: 1055
		private bool mIsCustomResolutionInputAllowed;

		// Token: 0x04000420 RID: 1056
		private bool mShowBeginnersGuidePreference = true;

		// Token: 0x04000421 RID: 1057
		private bool mIsShowNotificationCentre = true;

		// Token: 0x04000422 RID: 1058
		private bool mIsUseWpfTextbox;

		// Token: 0x04000423 RID: 1059
		private bool mIsComboKeysDisabled;

		// Token: 0x04000424 RID: 1060
		private bool mIsMacroRecorderEnabled;

		// Token: 0x04000425 RID: 1061
		private bool mIsFarmingModeDisabled;

		// Token: 0x04000426 RID: 1062
		private bool mIsOperationsSyncEnabled;

		// Token: 0x04000427 RID: 1063
		private bool mIsRotateScreenDisabled;

		// Token: 0x04000428 RID: 1064
		private bool mIsUserAccountBtnEnabled = true;

		// Token: 0x04000429 RID: 1065
		private bool mIsWarningBtnEnabled = true;

		// Token: 0x0400042A RID: 1066
		private bool mIsAppCenterTabVisible = true;

		// Token: 0x0400042B RID: 1067
		private bool mIsMultiInstanceControlsGridVisible = true;

		// Token: 0x0400042C RID: 1068
		private bool mIsPromotionFixed;

		// Token: 0x0400042D RID: 1069
		private bool mIsShowLanguagePreference = true;

		// Token: 0x0400042E RID: 1070
		private bool mIsShowDektopShortcutPreference = true;

		// Token: 0x0400042F RID: 1071
		private bool mIsShowGamingSummaryPreference = true;

		// Token: 0x04000430 RID: 1072
		private bool mIsShowSpeedUpTips = true;

		// Token: 0x04000431 RID: 1073
		private bool mIsShowPostOTSScreen = true;

		// Token: 0x04000432 RID: 1074
		private bool mIsShowHelpCenterGrid = true;

		// Token: 0x04000433 RID: 1075
		private bool mIsAppSettingsAvailable = true;

		// Token: 0x04000434 RID: 1076
		private bool mIsShowPerformancePreference = true;

		// Token: 0x04000435 RID: 1077
		private bool mIsShowDiscordPreference = true;

		// Token: 0x04000436 RID: 1078
		private bool mIsCustomUIForNCSoft;

		// Token: 0x04000437 RID: 1079
		private bool mAllowADBSettingToggle = true;

		// Token: 0x04000438 RID: 1080
		private bool mShowClientOnTopPreference = true;

		// Token: 0x0400043A RID: 1082
		private bool mIsShowAppRecommendations = true;
	}
}
