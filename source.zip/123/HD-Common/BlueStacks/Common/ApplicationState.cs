﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000C9 RID: 201
	public enum ApplicationState
	{
		// Token: 0x040004F4 RID: 1268
		Undefined,
		// Token: 0x040004F5 RID: 1269
		Running,
		// Token: 0x040004F6 RID: 1270
		NotRunning,
		// Token: 0x040004F7 RID: 1271
		Booting,
		// Token: 0x040004F8 RID: 1272
		Closing,
		// Token: 0x040004F9 RID: 1273
		Deleting
	}
}
