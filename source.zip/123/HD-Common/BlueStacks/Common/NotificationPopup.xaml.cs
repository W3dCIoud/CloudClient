﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x02000069 RID: 105
	public partial class NotificationPopup : System.Windows.Controls.UserControl
	{
		// Token: 0x1700009C RID: 156
		// (get) Token: 0x06000232 RID: 562 RVA: 0x0000318D File Offset: 0x0000138D
		// (set) Token: 0x06000233 RID: 563 RVA: 0x00003195 File Offset: 0x00001395
		public string Title
		{
			get
			{
				return this.mTitle;
			}
			set
			{
				this.mTitle = value;
				this.mLblHeader.Text = this.mTitle;
			}
		}

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x06000234 RID: 564 RVA: 0x000031AF File Offset: 0x000013AF
		// (set) Token: 0x06000235 RID: 565 RVA: 0x000031BC File Offset: 0x000013BC
		public bool AutoClose
		{
			get
			{
				return this.mTimer.Enabled;
			}
			set
			{
				this.mTimer.Enabled = value;
			}
		}

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x06000236 RID: 566 RVA: 0x000031CA File Offset: 0x000013CA
		// (set) Token: 0x06000237 RID: 567 RVA: 0x000031D2 File Offset: 0x000013D2
		public int Duration
		{
			get
			{
				return this.mDuration;
			}
			set
			{
				this.mDuration = value;
				this.mTimer.Interval = this.mDuration;
			}
		}

		// Token: 0x06000238 RID: 568 RVA: 0x000031EC File Offset: 0x000013EC
		private void MyTimer_Tick(object sender, EventArgs e)
		{
			this.Close();
		}

		// Token: 0x06000239 RID: 569 RVA: 0x000104C8 File Offset: 0x0000E6C8
		private void SetProperties()
		{
			this.mImgSettings.ToolTip = LocaleStrings.GetLocalizedString("STRING_MANAGE_NOTIFICATION", false);
			this.mImgMute.ToolTip = LocaleStrings.GetLocalizedString("STRING_MUTE_NOTIFICATION_TOOLTIP", false);
			this.mImgDismiss.ToolTip = LocaleStrings.GetLocalizedString("STRING_DISMISS_TOOLTIP", false);
			this.mLbl1Hour.Text = LocaleStrings.GetLocalizedString("STRING_HOUR", false);
			this.mLbl1Day.Text = LocaleStrings.GetLocalizedString("STRING_DAY", false);
			this.mLbl1Week.Text = LocaleStrings.GetLocalizedString("STRING_WEEK", false);
			this.mLblForever.Text = LocaleStrings.GetLocalizedString("STRING_FOREVER", false);
		}

		// Token: 0x0600023A RID: 570 RVA: 0x00010570 File Offset: 0x0000E770
		private NotificationPopup(string imagePath, string title, string displayMsg, bool autoClose, int duration, MouseButtonEventHandler clickHandler, bool hideMute, string vmName, MouseButtonEventHandler buttonClickHandler = null, MouseButtonEventHandler closeButtonHandler = null, MouseButtonEventHandler muteButtonHandler = null, bool showOnlyMute = false, string buttonText = "")
		{
			this.InitializeComponent();
			this.SetProperties();
			base.Width = NotificationWindow.Instance.ActualWidth;
			base.Height = NotificationWindow.Instance.ActualHeight / 10.0;
			this.mTimer.Tick += this.MyTimer_Tick;
			this.mTimer.Interval = duration;
			this.Title = title;
			this.mLblContent.Text = displayMsg;
			this.mVmName = vmName;
			if (clickHandler != null)
			{
				this.mPopup.MouseUp += clickHandler;
				this.mClickHandler = clickHandler;
			}
			if (buttonClickHandler != null)
			{
				this.mButton.PreviewMouseLeftButtonUp += buttonClickHandler;
				this.mButton.Visibility = Visibility.Visible;
				if (!string.IsNullOrEmpty(buttonText))
				{
					this.mButton.Content = buttonText;
				}
			}
			if (hideMute)
			{
				this.mImgMute.Visibility = Visibility.Hidden;
				this.mImgSettings.Visibility = Visibility.Hidden;
			}
			if (showOnlyMute)
			{
				this.mImgMute.Visibility = Visibility.Visible;
				this.mImgSettings.Visibility = Visibility.Collapsed;
			}
			if (closeButtonHandler != null)
			{
				this.mImgDismiss.MouseLeftButtonUp += closeButtonHandler;
			}
			if (muteButtonHandler != null)
			{
				this.mImgMute.MouseLeftButtonUp += muteButtonHandler;
			}
			this.AutoClose = autoClose;
			string localizedString = LocaleStrings.GetLocalizedString("STRING_INSTALL_SUCCESS", false);
			string localizedString2 = LocaleStrings.GetLocalizedString("STRING_INSTALL_UPDATES", false);
			string localizedString3 = LocaleStrings.GetLocalizedString("STRING_UNINSTALL_SUCCESS", false);
			string localizedString4 = LocaleStrings.GetLocalizedString("STRING_UPDATE_SUCCESS", false);
			if (displayMsg.Contains(localizedString) || displayMsg.Contains(localizedString2) || displayMsg.Contains(localizedString4))
			{
				if (displayMsg.Contains(localizedString))
				{
					this.mAppName = displayMsg.Substring(0, displayMsg.LastIndexOf(localizedString) - 1);
				}
				if (displayMsg.Contains(localizedString2))
				{
					this.mAppName = displayMsg.Substring(0, displayMsg.LastIndexOf(localizedString2) - 1);
				}
				if (displayMsg.Contains(localizedString4))
				{
					this.mAppName = displayMsg.Substring(0, displayMsg.LastIndexOf(localizedString4) - 1);
				}
			}
			else if (!displayMsg.Contains(localizedString3))
			{
				this.mAppName = title;
			}
			CustomPictureBox.SetBitmapImage(this.mImage, "bluestackslogo", false);
			if (!string.IsNullOrEmpty(imagePath))
			{
				CustomPictureBox.SetBitmapImage(this.mImage, imagePath, true);
				return;
			}
			try
			{
				string text = "com.bluestacks.appmart";
				string text2 = "com.bluestacks.appmart.StartTopAppsActivity";
				if (!string.IsNullOrEmpty(this.mAppName))
				{
					JsonParser jsonParser = new JsonParser(vmName);
					Logger.Info("mAppName: " + this.mAppName);
					Logger.Info("VmName: " + vmName);
					string text3;
					if (jsonParser.GetAppInfoFromAppName(this.mAppName, out text, out text3, out text2))
					{
						Logger.Info("imageName: " + text3);
						Logger.Info("ImagePath: " + Path.Combine(RegistryStrings.GadgetDir, text3));
						if (File.Exists(Path.Combine(RegistryStrings.GadgetDir, text3)))
						{
							CustomPictureBox.SetBitmapImage(this.mImage, Path.Combine(RegistryStrings.GadgetDir, text3), true);
						}
						else
						{
							Logger.Info("Image does not exist");
						}
					}
					else
					{
						Logger.Info("GetAppInfoFromAppName returns false");
					}
				}
			}
			catch
			{
				Logger.Error("Error loading app icon file");
			}
		}

		// Token: 0x0600023B RID: 571 RVA: 0x000031F4 File Offset: 0x000013F4
		public static void SettingsImageClickedHandle(EventHandler handle, object data = null)
		{
			NotificationPopup.mSettingsImageClickedHandler = handle;
			NotificationPopup.mSettingsImageClickedEventData = data;
		}

		// Token: 0x0600023C RID: 572 RVA: 0x000108AC File Offset: 0x0000EAAC
		internal static NotificationPopup InitPopup(string imagePath, string title, string displayMsg, bool autoClose, int duration, MouseButtonEventHandler clickHandler, bool hideMute, string vmName, MouseButtonEventHandler buttonClickHandler, MouseButtonEventHandler closeButtonHandler, MouseButtonEventHandler muteButtonHandler, bool showOnlyMute, string buttonText)
		{
			return new NotificationPopup(imagePath, title, displayMsg, autoClose, duration, clickHandler, hideMute, vmName, buttonClickHandler, closeButtonHandler, muteButtonHandler, showOnlyMute, buttonText);
		}

		// Token: 0x0600023D RID: 573 RVA: 0x000108D4 File Offset: 0x0000EAD4
		internal void UpdatePopup(string displayMsg, bool autoClose, int duration, MouseButtonEventHandler clickHandler)
		{
			if (autoClose)
			{
				this.Duration = duration;
			}
			this.mLblContent.Text = displayMsg;
			if (this.mClickHandler != null)
			{
				this.mPopup.MouseUp -= this.mClickHandler;
			}
			if (clickHandler != null)
			{
				this.mPopup.MouseUp += clickHandler;
				this.mClickHandler = clickHandler;
			}
		}

		// Token: 0x0600023E RID: 574 RVA: 0x0001092C File Offset: 0x0000EB2C
		private void mPopupConrol_LayoutUpdated(object sender, EventArgs e)
		{
			this.mPopup.VerticalOffset = this.mPopup.VerticalOffset + 1.0;
			this.mPopup.VerticalOffset = this.mPopup.VerticalOffset - 1.0;
		}

		// Token: 0x0600023F RID: 575 RVA: 0x00003202 File Offset: 0x00001402
		private void ImgMute_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.mMutePopup.IsOpen = true;
			e.Handled = true;
		}

		// Token: 0x06000240 RID: 576 RVA: 0x00003217 File Offset: 0x00001417
		private void ImgDismiss_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.Close();
			e.Handled = true;
		}

		// Token: 0x06000241 RID: 577 RVA: 0x00003226 File Offset: 0x00001426
		private void Close()
		{
			this.mMutePopup.IsOpen = false;
			this.mTimer.Enabled = false;
			NotificationWindow.Instance.RemovePopup(this);
		}

		// Token: 0x06000242 RID: 578 RVA: 0x0000324B File Offset: 0x0000144B
		private void ImgSetting_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.Close();
			if (NotificationPopup.mSettingsImageClickedHandler != null)
			{
				NotificationPopup.mSettingsImageClickedHandler(NotificationPopup.mSettingsImageClickedEventData, new EventArgs());
			}
			e.Handled = true;
		}

		// Token: 0x06000243 RID: 579 RVA: 0x0001097C File Offset: 0x0000EB7C
		private void mPopupConrol_MouseUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mMutePopup.IsOpen)
			{
				this.mMutePopup.IsOpen = false;
				return;
			}
			if (this.mClickHandler == null)
			{
				Logger.Info("Clicked on BalloonTip");
				try
				{
					if (string.Compare(this.mAppName, "Successfully copied files:", true) == 0 || string.Compare(this.mAppName, "Cannot copy files:", true) == 0)
					{
						NotificationPopup.LaunchExplorer(this.mLblContent.Text);
						return;
					}
					Logger.Info("launching " + this.mAppName);
					string text = "com.bluestacks.appmart";
					string arg = "com.bluestacks.appmart.StartTopAppsActivity";
					string fileName = RegistryStrings.InstallDir + "\\HD-RunApp.exe";
					string text2;
					if (!new JsonParser(this.mVmName).GetAppInfoFromAppName(this.mAppName, out text, out text2, out arg))
					{
						Logger.Error("Failed to launch app: {0}. No info found in json. Starting home app", new object[]
						{
							this.mAppName
						});
						if (!string.IsNullOrEmpty(text))
						{
							Process.Start(fileName, string.Format("-p {0} -a {1} -vmname:{2}", text, arg, this.mVmName));
						}
					}
					else
					{
						string arg2 = "-json \"" + new JObject
						{
							{
								"app_icon_url",
								""
							},
							{
								"app_name",
								this.mAppName
							},
							{
								"app_url",
								""
							},
							{
								"app_pkg",
								text
							}
						}.ToString(Formatting.None, new JsonConverter[0]).Replace("\"", "\\\"") + "\"";
						Process.Start(fileName, string.Format("{0} -vmname {1}", arg2, this.mVmName));
					}
				}
				catch (Exception ex)
				{
					Logger.Error(ex.ToString());
				}
			}
			this.Close();
			e.Handled = true;
		}

		// Token: 0x06000244 RID: 580 RVA: 0x00010B60 File Offset: 0x0000ED60
		public static void LaunchExplorer(string message)
		{
			try
			{
				string[] array = message.Split(new char[]
				{
					'\n'
				});
				string fullName = Directory.GetParent(array[0]).FullName;
				string fileName = "explorer.exe";
				string arguments;
				if (array.Length == 1)
				{
					arguments = string.Format("/Select, {0}", array[0]);
				}
				else
				{
					arguments = fullName;
				}
				Process.Start(fileName, arguments);
			}
			catch (Exception ex)
			{
				Logger.Error(string.Format("Error Occured, Err : {0}", ex.ToString()));
			}
		}

		// Token: 0x06000245 RID: 581 RVA: 0x00003275 File Offset: 0x00001475
		private void Lbl1Hour_MouseUp(object sender, MouseButtonEventArgs e)
		{
			NotificationManager.Instance.UpdateMuteState(MuteState.MutedFor1Hour, this.mTitle);
			this.Close();
			e.Handled = true;
		}

		// Token: 0x06000246 RID: 582 RVA: 0x00003295 File Offset: 0x00001495
		private void Lbl1Day_MouseUp(object sender, MouseButtonEventArgs e)
		{
			NotificationManager.Instance.UpdateMuteState(MuteState.MutedFor1Day, this.mTitle);
			this.Close();
			e.Handled = true;
		}

		// Token: 0x06000247 RID: 583 RVA: 0x000032B5 File Offset: 0x000014B5
		private void Lbl1Week_MouseUp(object sender, MouseButtonEventArgs e)
		{
			NotificationManager.Instance.UpdateMuteState(MuteState.MutedFor1Week, this.mTitle);
			this.Close();
			e.Handled = true;
		}

		// Token: 0x06000248 RID: 584 RVA: 0x000032D5 File Offset: 0x000014D5
		private void LblForever_MouseUp(object sender, MouseButtonEventArgs e)
		{
			NotificationManager.Instance.UpdateMuteState(MuteState.MutedForever, this.mTitle);
			this.Close();
			e.Handled = true;
		}

		// Token: 0x06000249 RID: 585 RVA: 0x000032F5 File Offset: 0x000014F5
		private void Grid_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			((Grid)sender).Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#DDDDDD"));
		}

		// Token: 0x0600024A RID: 586 RVA: 0x00003316 File Offset: 0x00001516
		private void Grid_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			((Grid)sender).Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFFFFF"));
		}

		// Token: 0x0600024B RID: 587 RVA: 0x00003337 File Offset: 0x00001537
		private void mButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
		}

		// Token: 0x04000123 RID: 291
		private Timer mTimer = new Timer();

		// Token: 0x04000124 RID: 292
		private string mTitle = string.Empty;

		// Token: 0x04000125 RID: 293
		private MouseButtonEventHandler mClickHandler;

		// Token: 0x04000126 RID: 294
		private static EventHandler mSettingsImageClickedHandler;

		// Token: 0x04000127 RID: 295
		private static object mSettingsImageClickedEventData;

		// Token: 0x04000128 RID: 296
		private int mDuration = int.MinValue;

		// Token: 0x04000129 RID: 297
		private string mAppName = string.Empty;

		// Token: 0x0400012A RID: 298
		public string mVmName = string.Empty;
	}
}
