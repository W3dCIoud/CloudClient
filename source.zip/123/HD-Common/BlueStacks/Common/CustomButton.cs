﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x020000A5 RID: 165
	public class CustomButton : Button, IComponentConnector, IStyleConnector
	{
		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x060003F4 RID: 1012 RVA: 0x00004249 File Offset: 0x00002449
		// (set) Token: 0x060003F5 RID: 1013 RVA: 0x0000425B File Offset: 0x0000245B
		public ButtonColors ButtonColor
		{
			get
			{
				return (ButtonColors)base.GetValue(CustomButton.ButtonColorProperty);
			}
			set
			{
				base.SetValue(CustomButton.ButtonColorProperty, value);
			}
		}

		// Token: 0x060003F6 RID: 1014 RVA: 0x000197A8 File Offset: 0x000179A8
		private static void ButtonColorChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
		{
			CustomButton customButton = source as CustomButton;
			if (!DesignerProperties.GetIsInDesignMode(customButton))
			{
				customButton.SetColor(false);
			}
		}

		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x060003F7 RID: 1015 RVA: 0x0000426E File Offset: 0x0000246E
		// (set) Token: 0x060003F8 RID: 1016 RVA: 0x00004276 File Offset: 0x00002476
		public string ImageName
		{
			get
			{
				return this.mImageName;
			}
			set
			{
				this.mImageName = value;
				this.SetImage();
			}
		}

		// Token: 0x060003F9 RID: 1017 RVA: 0x000197CC File Offset: 0x000179CC
		static CustomButton()
		{
			Control.FontWeightProperty.OverrideMetadata(typeof(CustomButton), new FrameworkPropertyMetadata(FontWeights.SemiBold));
		}

		// Token: 0x060003FA RID: 1018 RVA: 0x00004285 File Offset: 0x00002485
		public CustomButton()
		{
			this.InitializeComponent();
		}

		// Token: 0x060003FB RID: 1019 RVA: 0x0000429E File Offset: 0x0000249E
		public CustomButton(ButtonColors color) : this()
		{
			this.ButtonColor = color;
		}

		// Token: 0x060003FC RID: 1020 RVA: 0x000042AD File Offset: 0x000024AD
		private void CustomPictureBox_Loaded(object sender, RoutedEventArgs e)
		{
			this.mImage = (sender as CustomPictureBox);
			this.SetImage();
			this.SetColor(false);
		}

		// Token: 0x060003FD RID: 1021 RVA: 0x00019838 File Offset: 0x00017A38
		private void SetImage()
		{
			if (this.mImage != null)
			{
				if (!string.IsNullOrEmpty(this.mImageName))
				{
					this.mImage.ImageName = this.mImageName;
					this.mImage.Visibility = Visibility.Visible;
					return;
				}
				this.mImage.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x060003FE RID: 1022 RVA: 0x00019884 File Offset: 0x00017A84
		private void SetColor(bool isPressed = false)
		{
			if (!base.IsEnabled)
			{
				BlueStacksUIBinding.BindColor(this, Control.BorderBrushProperty, this.ButtonColor.ToString() + "DisabledBorderBackground");
				BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, this.ButtonColor.ToString() + "DisabledGridBackGround");
				BlueStacksUIBinding.BindColor(this, Control.ForegroundProperty, this.ButtonColor.ToString() + "DisabledForeGround");
				if (this.mImage != null)
				{
					this.mImage.SetDefaultImage();
					return;
				}
			}
			else if (base.IsPressed || isPressed)
			{
				BlueStacksUIBinding.BindColor(this, Control.BorderBrushProperty, this.ButtonColor.ToString() + "MouseDownBorderBackground");
				BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, this.ButtonColor.ToString() + "MouseDownGridBackGround");
				BlueStacksUIBinding.BindColor(this, Control.ForegroundProperty, this.ButtonColor.ToString() + "MouseDownForeGround");
				if (this.mImage != null)
				{
					this.mImage.SetClickedImage();
					return;
				}
			}
			else if (base.IsMouseOver)
			{
				BlueStacksUIBinding.BindColor(this, Control.BorderBrushProperty, this.ButtonColor.ToString() + "MouseInBorderBackground");
				BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, this.ButtonColor.ToString() + "MouseInGridBackGround");
				BlueStacksUIBinding.BindColor(this, Control.ForegroundProperty, this.ButtonColor.ToString() + "MouseInForeGround");
				if (this.mImage != null)
				{
					this.mImage.SetHoverImage();
					return;
				}
			}
			else
			{
				BlueStacksUIBinding.BindColor(this, Control.BorderBrushProperty, this.ButtonColor.ToString() + "MouseOutBorderBackground");
				BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, this.ButtonColor.ToString() + "MouseOutGridBackGround");
				BlueStacksUIBinding.BindColor(this, Control.ForegroundProperty, this.ButtonColor.ToString() + "MouseOutForeGround");
				if (this.mImage != null)
				{
					this.mImage.SetDefaultImage();
				}
			}
		}

		// Token: 0x060003FF RID: 1023 RVA: 0x000042C8 File Offset: 0x000024C8
		private void mButton_LayoutUpdated(object sender, EventArgs e)
		{
			this.SetColor(false);
		}

		// Token: 0x06000400 RID: 1024 RVA: 0x000042D1 File Offset: 0x000024D1
		private void mButton_MouseDown(object sender, EventArgs e)
		{
			this.SetColor(true);
		}

		// Token: 0x06000401 RID: 1025 RVA: 0x00019AF8 File Offset: 0x00017CF8
		private void Border_Initialized(object sender, EventArgs e)
		{
			try
			{
				Border border = sender as Border;
				CornerRadius cornerRadius = BlueStacksUIColorManager.AppliedTheme.DictCornerRadius["ButtonCornerRadius"];
				border.CornerRadius = new CornerRadius(base.ActualHeight / cornerRadius.TopLeft, base.ActualHeight / cornerRadius.TopRight, base.ActualHeight / cornerRadius.BottomRight, base.ActualHeight / cornerRadius.BottomLeft);
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000402 RID: 1026 RVA: 0x00019AF8 File Offset: 0x00017CF8
		private void Border_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			try
			{
				Border border = sender as Border;
				CornerRadius cornerRadius = BlueStacksUIColorManager.AppliedTheme.DictCornerRadius["ButtonCornerRadius"];
				border.CornerRadius = new CornerRadius(base.ActualHeight / cornerRadius.TopLeft, base.ActualHeight / cornerRadius.TopRight, base.ActualHeight / cornerRadius.BottomRight, base.ActualHeight / cornerRadius.BottomLeft);
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000403 RID: 1027 RVA: 0x00019AF8 File Offset: 0x00017CF8
		private void Border_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			try
			{
				Border border = sender as Border;
				CornerRadius cornerRadius = BlueStacksUIColorManager.AppliedTheme.DictCornerRadius["ButtonCornerRadius"];
				border.CornerRadius = new CornerRadius(base.ActualHeight / cornerRadius.TopLeft, base.ActualHeight / cornerRadius.TopRight, base.ActualHeight / cornerRadius.BottomRight, base.ActualHeight / cornerRadius.BottomLeft);
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000404 RID: 1028 RVA: 0x000042C8 File Offset: 0x000024C8
		private void mButton_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			this.SetColor(false);
		}

		// Token: 0x06000405 RID: 1029 RVA: 0x00019B78 File Offset: 0x00017D78
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/custombutton.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000406 RID: 1030 RVA: 0x00019BA8 File Offset: 0x00017DA8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mButton = (CustomButton)target;
				this.mButton.MouseEnter += new MouseEventHandler(this.mButton_LayoutUpdated);
				this.mButton.MouseLeave += new MouseEventHandler(this.mButton_LayoutUpdated);
				this.mButton.PreviewMouseDown += new MouseButtonEventHandler(this.mButton_MouseDown);
				this.mButton.MouseDown += new MouseButtonEventHandler(this.mButton_MouseDown);
				this.mButton.IsEnabledChanged += this.mButton_IsEnabledChanged;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x00019C44 File Offset: 0x00017E44
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 2)
			{
				((Border)target).Initialized += this.Border_Initialized;
				((Border)target).SizeChanged += this.Border_SizeChanged;
				((Border)target).IsVisibleChanged += this.Border_IsVisibleChanged;
				return;
			}
			if (connectionId != 3)
			{
				return;
			}
			((Border)target).Initialized += this.Border_Initialized;
			((Border)target).SizeChanged += this.Border_SizeChanged;
			((Border)target).IsVisibleChanged += this.Border_IsVisibleChanged;
		}

		// Token: 0x040003C1 RID: 961
		private CustomPictureBox mImage;

		// Token: 0x040003C2 RID: 962
		public static readonly DependencyProperty ButtonColorProperty = DependencyProperty.Register("ButtonColor", typeof(ButtonColors), typeof(CustomButton), new PropertyMetadata(ButtonColors.Blue, new PropertyChangedCallback(CustomButton.ButtonColorChanged)));

		// Token: 0x040003C3 RID: 963
		private string mImageName = string.Empty;

		// Token: 0x040003C4 RID: 964
		internal CustomButton mButton;

		// Token: 0x040003C5 RID: 965
		private bool _contentLoaded;
	}
}
