﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000067 RID: 103
	public enum BiosHvmState
	{
		// Token: 0x04000120 RID: 288
		False,
		// Token: 0x04000121 RID: 289
		True,
		// Token: 0x04000122 RID: 290
		Unknown
	}
}
