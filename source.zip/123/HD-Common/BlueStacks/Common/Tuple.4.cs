﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001A2 RID: 418
	public class Tuple<T1, T2, T3, T4> : Tuple<T1, T2, T3>
	{
		// Token: 0x06000CD5 RID: 3285 RVA: 0x0000B6A4 File Offset: 0x000098A4
		public Tuple(T1 item1, T2 item2, T3 item3, T4 item4) : base(item1, item2, item3)
		{
			this.Item4 = item4;
		}

		// Token: 0x17000301 RID: 769
		// (get) Token: 0x06000CD6 RID: 3286 RVA: 0x0000B6B7 File Offset: 0x000098B7
		// (set) Token: 0x06000CD7 RID: 3287 RVA: 0x0000B6BF File Offset: 0x000098BF
		public T4 Item4 { get; set; }
	}
}
