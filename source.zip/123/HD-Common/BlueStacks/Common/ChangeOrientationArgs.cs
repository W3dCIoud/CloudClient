﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000A9 RID: 169
	public class ChangeOrientationArgs : EventArgs
	{
		// Token: 0x06000428 RID: 1064 RVA: 0x0000449D File Offset: 0x0000269D
		public ChangeOrientationArgs(bool isPotrait)
		{
			this.IsPotrait = isPotrait;
		}

		// Token: 0x040003D2 RID: 978
		public bool IsPotrait;
	}
}
