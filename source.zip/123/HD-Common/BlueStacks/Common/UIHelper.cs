﻿using System;
using System.Windows.Controls;
using System.Windows.Forms;

namespace BlueStacks.Common
{
	// Token: 0x0200010F RID: 271
	public static class UIHelper
	{
		// Token: 0x06000947 RID: 2375 RVA: 0x00009AB0 File Offset: 0x00007CB0
		public static void SetDispatcher(UIHelper.dispatcher gameManagerWindowDispatcher)
		{
			UIHelper.obj = gameManagerWindowDispatcher;
		}

		// Token: 0x06000948 RID: 2376 RVA: 0x00009AB8 File Offset: 0x00007CB8
		public static void RunOnUIThread(System.Windows.Forms.Control control, UIHelper.Action action)
		{
			if (UIHelper.obj != null)
			{
				if (control.InvokeRequired)
				{
					UIHelper.obj(action, new object[0]);
				}
				return;
			}
			if (control.InvokeRequired)
			{
				control.Invoke(action);
				return;
			}
			action();
		}

		// Token: 0x06000949 RID: 2377 RVA: 0x00009AF3 File Offset: 0x00007CF3
		public static void AssertUIThread(System.Windows.Forms.Control control)
		{
			if (control.InvokeRequired)
			{
				throw new ApplicationException("Not running on UI thread");
			}
		}

		// Token: 0x0600094A RID: 2378 RVA: 0x00009B08 File Offset: 0x00007D08
		public static void AssertUIThread(System.Windows.Controls.Control control)
		{
			if (!control.Dispatcher.CheckAccess())
			{
				throw new ApplicationException("Not running on UI thread");
			}
		}

		// Token: 0x040006ED RID: 1773
		private static UIHelper.dispatcher obj;

		// Token: 0x02000110 RID: 272
		// (Invoke) Token: 0x0600094D RID: 2381
		public delegate object dispatcher(Delegate method, params object[] args);

		// Token: 0x02000111 RID: 273
		// (Invoke) Token: 0x06000951 RID: 2385
		public delegate void Action();
	}
}
