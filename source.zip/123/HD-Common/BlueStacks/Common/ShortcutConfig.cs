﻿using System;
using System.Collections.Generic;
using System.Windows.Input;
using Newtonsoft.Json;

namespace BlueStacks.Common
{
	// Token: 0x02000074 RID: 116
	[Serializable]
	public class ShortcutConfig
	{
		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x0600029E RID: 670 RVA: 0x000035E2 File Offset: 0x000017E2
		// (set) Token: 0x0600029F RID: 671 RVA: 0x000035EA File Offset: 0x000017EA
		public List<ShortcutKeys> Shortcut { get; set; }

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x060002A0 RID: 672 RVA: 0x000035F3 File Offset: 0x000017F3
		// (set) Token: 0x060002A1 RID: 673 RVA: 0x000035FB File Offset: 0x000017FB
		public string DefaultModifier { get; set; } = IMAPKeys.GetStringForFile(Key.LeftCtrl) + "," + IMAPKeys.GetStringForFile(Key.LeftShift);

		// Token: 0x060002A2 RID: 674 RVA: 0x00011B2C File Offset: 0x0000FD2C
		public static ShortcutConfig LoadShortcutsConfig()
		{
			try
			{
				string value = string.Empty;
				if (!string.IsNullOrEmpty(RegistryManager.Instance.UserDefinedShortcuts))
				{
					value = RegistryManager.Instance.UserDefinedShortcuts;
				}
				else
				{
					if (!string.IsNullOrEmpty(value) || string.IsNullOrEmpty(RegistryManager.Instance.DefaultShortcuts))
					{
						throw new Exception("Shortcuts registry entry not found.");
					}
					value = RegistryManager.Instance.DefaultShortcuts;
				}
				return JsonConvert.DeserializeObject<ShortcutConfig>(value, Utils.GetSerializerSettings());
			}
			catch (Exception ex)
			{
				Logger.Error("SHORTCUT: Exception in loading shortcuts config: " + ex.ToString());
			}
			return null;
		}
	}
}
