﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001A3 RID: 419
	public static class Tuple
	{
		// Token: 0x06000CD8 RID: 3288 RVA: 0x0000B6C8 File Offset: 0x000098C8
		public static Tuple<T1> Create<T1>(T1 item1)
		{
			return new Tuple<T1>(item1);
		}

		// Token: 0x06000CD9 RID: 3289 RVA: 0x0000B6D0 File Offset: 0x000098D0
		public static Tuple<T1, T2> Create<T1, T2>(T1 item1, T2 item2)
		{
			return new Tuple<T1, T2>(item1, item2);
		}

		// Token: 0x06000CDA RID: 3290 RVA: 0x0000B6D9 File Offset: 0x000098D9
		public static Tuple<T1, T2, T3> Create<T1, T2, T3>(T1 item1, T2 item2, T3 item3)
		{
			return new Tuple<T1, T2, T3>(item1, item2, item3);
		}
	}
}
