﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x020000B8 RID: 184
	public class BstHttpClient
	{
		// Token: 0x060005FC RID: 1532 RVA: 0x0001BDA0 File Offset: 0x00019FA0
		public static string Get(string url, Dictionary<string, string> headers, bool gzip, string vmName = "Android", int timeout = 0, int retries = 1, int sleepTimeMSec = 0, bool isOnUIThreadOnPurpose = false)
		{
			string withRetries;
			try
			{
				withRetries = BstHttpClient.GetWithRetries(url, headers, gzip, retries, sleepTimeMSec, timeout, vmName, isOnUIThreadOnPurpose);
			}
			catch (Exception ex)
			{
				if (url.Contains(RegistryManager.Instance.Host))
				{
					Logger.Error("GET failed: {0}", new object[]
					{
						ex.Message
					});
					url = url.Replace(RegistryManager.Instance.Host, RegistryManager.Instance.Host2);
					withRetries = BstHttpClient.GetWithRetries(url, headers, gzip, retries, sleepTimeMSec, timeout, vmName, isOnUIThreadOnPurpose);
				}
				else
				{
					if (!url.Contains(RegistryManager.Instance.Host2))
					{
						throw;
					}
					Logger.Error("GET failed: {0}", new object[]
					{
						ex.Message
					});
					url = url.Replace(RegistryManager.Instance.Host2, RegistryManager.Instance.Host);
					withRetries = BstHttpClient.GetWithRetries(url, headers, gzip, retries, sleepTimeMSec, timeout, vmName, isOnUIThreadOnPurpose);
				}
			}
			return withRetries;
		}

		// Token: 0x060005FD RID: 1533 RVA: 0x0001BE90 File Offset: 0x0001A090
		private static string GetWithRetries(string url, Dictionary<string, string> headers, bool gzip, int tries, int sleepTimeMSec, int timeout, string vmName, bool isOnUIThreadOnPurpose)
		{
			string result = null;
			int i = tries;
			while (i > 0)
			{
				try
				{
					result = BstHttpClient.GetInternal(url, headers, gzip, timeout, vmName, isOnUIThreadOnPurpose);
					break;
				}
				catch (Exception ex)
				{
					if (i == 1)
					{
						throw;
					}
					Logger.Warning("Exception when GET to url: {0}, Ex: {1}", new object[]
					{
						url,
						ex.Message
					});
				}
				i--;
				Thread.Sleep(sleepTimeMSec);
			}
			return result;
		}

		// Token: 0x060005FE RID: 1534 RVA: 0x0001BEFC File Offset: 0x0001A0FC
		private static string GetInternal(string url, Dictionary<string, string> headers, bool gzip, int timeout, string vmName, bool isOnUIThreadOnPurpose)
		{
			if (Thread.CurrentThread.ManagedThreadId == 1 && !isOnUIThreadOnPurpose)
			{
				StackTrace stackTrace = new StackTrace();
				Logger.Warning("WARNING: This network call is from the UI thread. StackTrace: {0}", new object[]
				{
					stackTrace
				});
			}
			HttpWebRequest httpWebRequest = WebRequest.Create(url) as HttpWebRequest;
			httpWebRequest.Method = "GET";
			if (timeout != 0)
			{
				httpWebRequest.Timeout = timeout;
			}
			if (gzip)
			{
				httpWebRequest.AutomaticDecompression = DecompressionMethods.GZip;
				httpWebRequest.Headers.Add(HttpRequestHeader.AcceptEncoding, "gzip");
			}
			if (headers != null)
			{
				foreach (KeyValuePair<string, string> keyValuePair in headers)
				{
					httpWebRequest.Headers.Set(StringUtils.GetControlCharFreeString(keyValuePair.Key), StringUtils.GetControlCharFreeString(keyValuePair.Value));
				}
			}
			HTTPUtils.AddCommonRequestHeaders(ref httpWebRequest);
			httpWebRequest = HTTPUtils.GetUpdatedRequestWithCommonHeadersAndUserAgent(httpWebRequest, vmName);
			string result = null;
			using (HttpWebResponse httpWebResponse = httpWebRequest.GetResponse() as HttpWebResponse)
			{
				using (Stream responseStream = httpWebResponse.GetResponseStream())
				{
					using (StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8))
					{
						result = streamReader.ReadToEnd();
					}
				}
			}
			return result;
		}

		// Token: 0x060005FF RID: 1535 RVA: 0x0001C05C File Offset: 0x0001A25C
		public static string Post(string url, Dictionary<string, string> data, Dictionary<string, string> headers = null, bool gzip = false, string vmName = "Android", int timeout = 0, int retries = 1, int sleepTimeMSec = 0, bool isOnUIThreadOnPurpose = false)
		{
			string result;
			try
			{
				if (Features.IsFeatureEnabled(536870912UL) && url.Contains(RegistryManager.Instance.Host))
				{
					url = url.Replace(RegistryManager.Instance.Host, RegistryManager.Instance.Host2);
				}
				result = BstHttpClient.PostWithRetries(url, data, headers, gzip, retries, sleepTimeMSec, timeout, vmName, isOnUIThreadOnPurpose);
			}
			catch (Exception ex)
			{
				if (url.Contains(RegistryManager.Instance.Host))
				{
					Logger.Error(ex.Message);
					url = url.Replace(RegistryManager.Instance.Host, RegistryManager.Instance.Host2);
					result = BstHttpClient.PostWithRetries(url, data, headers, gzip, retries, sleepTimeMSec, timeout, vmName, isOnUIThreadOnPurpose);
				}
				else
				{
					if (!url.Contains(RegistryManager.Instance.Host2))
					{
						throw;
					}
					Logger.Error(ex.Message);
					url = url.Replace(RegistryManager.Instance.Host2, RegistryManager.Instance.Host);
					result = BstHttpClient.PostWithRetries(url, data, headers, gzip, retries, sleepTimeMSec, timeout, vmName, isOnUIThreadOnPurpose);
				}
			}
			return result;
		}

		// Token: 0x06000600 RID: 1536 RVA: 0x0001C170 File Offset: 0x0001A370
		private static string PostWithRetries(string url, Dictionary<string, string> data, Dictionary<string, string> headers, bool gzip, int retries, int sleepTimeMSecs, int timeout, string vmName, bool isOnUIThreadOnPurpose)
		{
			string result = null;
			int i = retries;
			while (i > 0)
			{
				try
				{
					result = BstHttpClient.PostInternal(url, data, headers, gzip, timeout, vmName, isOnUIThreadOnPurpose);
					break;
				}
				catch (Exception ex)
				{
					if (i == 1)
					{
						throw;
					}
					Logger.Warning("Exception when posting to url: {0}, Ex: {1}", new object[]
					{
						url,
						ex.Message
					});
				}
				i--;
				Thread.Sleep(sleepTimeMSecs);
			}
			return result;
		}

		// Token: 0x06000601 RID: 1537 RVA: 0x0001C1E0 File Offset: 0x0001A3E0
		private static string PostInternal(string url, Dictionary<string, string> data, Dictionary<string, string> headers, bool gzip, int timeout, string vmId, bool isOnUIThreadOnPurpose)
		{
			if (Thread.CurrentThread.ManagedThreadId == 1 && !isOnUIThreadOnPurpose)
			{
				StackTrace stackTrace = new StackTrace();
				Logger.Warning("WARNING: This network call is from UI Thread and its stack trace is {0}", new object[]
				{
					stackTrace.ToString()
				});
			}
			HttpWebRequest httpWebRequest = WebRequest.Create(url) as HttpWebRequest;
			httpWebRequest.Method = "POST";
			if (timeout != 0)
			{
				httpWebRequest.Timeout = timeout;
			}
			if (gzip)
			{
				httpWebRequest.AutomaticDecompression = DecompressionMethods.GZip;
				httpWebRequest.Headers.Add(HttpRequestHeader.AcceptEncoding, "gzip");
			}
			if (headers != null)
			{
				foreach (KeyValuePair<string, string> keyValuePair in headers)
				{
					httpWebRequest.Headers.Set(StringUtils.GetControlCharFreeString(keyValuePair.Key), StringUtils.GetControlCharFreeString(keyValuePair.Value));
				}
			}
			HTTPUtils.AddCommonRequestHeaders(ref httpWebRequest);
			if (!string.IsNullOrEmpty(vmId))
			{
				if (vmId.Contains("Android"))
				{
					if (vmId.Equals("Android"))
					{
						httpWebRequest.Headers.Set("vmid", "0");
					}
					else
					{
						httpWebRequest.Headers.Set("vmid", vmId.Split(new char[]
						{
							'_'
						})[1]);
					}
					httpWebRequest.Headers.Set("vmname", vmId);
					httpWebRequest.Headers.Set("x_google_aid", Utils.GetGoogleAdIdfromRegistry(vmId));
					httpWebRequest.Headers.Set("x_android_id", Utils.GetAndroidIdfromRegistry(vmId));
				}
				else
				{
					httpWebRequest.Headers.Set("vmid", vmId);
					if (vmId.Equals("0"))
					{
						httpWebRequest.Headers.Set("vmname", "Android");
						httpWebRequest.Headers.Set("x_google_aid", Utils.GetGoogleAdIdfromRegistry("Android"));
						httpWebRequest.Headers.Set("x_android_id", Utils.GetAndroidIdfromRegistry("Android"));
					}
					else
					{
						httpWebRequest.Headers.Set("vmname", "Android_" + vmId);
						httpWebRequest.Headers.Set("x_google_aid", Utils.GetGoogleAdIdfromRegistry("Android_" + vmId));
						httpWebRequest.Headers.Set("x_android_id", Utils.GetAndroidIdfromRegistry("Android_" + vmId));
					}
				}
			}
			if (data == null)
			{
				data = new Dictionary<string, string>();
			}
			if (!url.Contains("localhost") && !url.Contains("127.0.0.1"))
			{
				data = Utils.AddCommonData(data);
			}
			byte[] bytes = Encoding.UTF8.GetBytes(HTTPUtils.Encode(data));
			httpWebRequest.ContentType = "application/x-www-form-urlencoded";
			httpWebRequest.ContentLength = (long)bytes.Length;
			httpWebRequest.UserAgent = Utils.GetUserAgent(RegistryManager.Instance.UserGuid, RegistryManager.Instance.Version);
			Uri uri = new Uri(url);
			if (!uri.Host.Contains("localhost") && !uri.Host.Contains("127.0.0.1"))
			{
				Logger.Debug("URI of proxy = " + httpWebRequest.Proxy.GetProxy(uri));
			}
			string result = null;
			using (Stream requestStream = httpWebRequest.GetRequestStream())
			{
				requestStream.Write(bytes, 0, bytes.Length);
				using (HttpWebResponse httpWebResponse = httpWebRequest.GetResponse() as HttpWebResponse)
				{
					using (Stream responseStream = httpWebResponse.GetResponseStream())
					{
						using (StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8))
						{
							result = streamReader.ReadToEnd();
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06000602 RID: 1538 RVA: 0x0001C598 File Offset: 0x0001A798
		public static string HTTPGaeFileUploader(string url, Dictionary<string, string> data, Dictionary<string, string> headers, string filepath, string contentType, bool gzip, string vmName)
		{
			string result;
			try
			{
				if (Features.IsFeatureEnabled(536870912UL) && url.Contains(RegistryManager.Instance.Host))
				{
					url = url.Replace(RegistryManager.Instance.Host, RegistryManager.Instance.Host2);
				}
				result = BstHttpClient.HTTPGaeFileUploaderInternal(url, data, headers, filepath, contentType, gzip, vmName);
			}
			catch (Exception ex)
			{
				if (url.Contains(RegistryManager.Instance.Host))
				{
					Logger.Error(ex.Message);
					url = url.Replace(RegistryManager.Instance.Host, RegistryManager.Instance.Host2);
					result = BstHttpClient.HTTPGaeFileUploaderInternal(url, data, headers, filepath, contentType, gzip, vmName);
				}
				else
				{
					if (!url.Contains(RegistryManager.Instance.Host2))
					{
						throw;
					}
					Logger.Error(ex.Message);
					url = url.Replace(RegistryManager.Instance.Host2, RegistryManager.Instance.Host);
					result = BstHttpClient.HTTPGaeFileUploaderInternal(url, data, headers, filepath, contentType, gzip, vmName);
				}
			}
			return result;
		}

		// Token: 0x06000603 RID: 1539 RVA: 0x0001C6A0 File Offset: 0x0001A8A0
		private static string HTTPGaeFileUploaderInternal(string url, Dictionary<string, string> data, Dictionary<string, string> headers, string filepath, string contentType, bool gzip, string vmName)
		{
			if (filepath == null || !File.Exists(filepath))
			{
				return BstHttpClient.Post(url, data, headers, gzip, vmName, 0, 1, 0, false);
			}
			JObject jobject = JObject.Parse(BstHttpClient.Get(url, null, false, vmName, 0, 1, 0, false));
			string url2 = null;
			string value = null;
			string value2 = "";
			if (jobject["success"].ToObject<bool>())
			{
				url2 = jobject["url"].ToString();
				try
				{
					value = jobject["country"].ToString();
				}
				catch
				{
					try
					{
						value = new RegionInfo(CultureInfo.CurrentCulture.Name).TwoLetterISORegionName;
					}
					catch
					{
						value = "US";
					}
				}
			}
			data.Add("country", value);
			if (Oem.Instance.IsOEMWithBGPClient)
			{
				value2 = RegistryManager.Instance.ClientVersion;
			}
			data.Add("client_ver", value2);
			return BstHttpClient.HttpUploadFile(url2, filepath, "file", contentType, headers, data);
		}

		// Token: 0x06000604 RID: 1540 RVA: 0x0001C79C File Offset: 0x0001A99C
		private static string HttpUploadFile(string url, string file, string paramName, string contentType, Dictionary<string, string> headers, Dictionary<string, string> data)
		{
			string result;
			try
			{
				if (Features.IsFeatureEnabled(536870912UL) && url.Contains(RegistryManager.Instance.Host))
				{
					url = url.Replace(RegistryManager.Instance.Host, RegistryManager.Instance.Host2);
				}
				result = BstHttpClient.HttpUploadFileInternal(url, file, paramName, contentType, headers, data);
			}
			catch (Exception ex)
			{
				if (url.Contains(RegistryManager.Instance.Host))
				{
					Logger.Error(ex.Message);
					url = url.Replace(RegistryManager.Instance.Host, RegistryManager.Instance.Host2);
					result = BstHttpClient.HttpUploadFileInternal(url, file, paramName, contentType, headers, data);
				}
				else
				{
					if (!url.Contains(RegistryManager.Instance.Host2))
					{
						throw;
					}
					Logger.Error(ex.Message);
					url = url.Replace(RegistryManager.Instance.Host2, RegistryManager.Instance.Host);
					result = BstHttpClient.HttpUploadFileInternal(url, file, paramName, contentType, headers, data);
				}
			}
			return result;
		}

		// Token: 0x06000605 RID: 1541 RVA: 0x0001C8A0 File Offset: 0x0001AAA0
		private static string HttpUploadFileInternal(string url, string file, string paramName, string contentType, Dictionary<string, string> headers, Dictionary<string, string> data)
		{
			Logger.Info(string.Format("Uploading {0} to {1}", file, url));
			string str = "---------------------------" + DateTime.Now.Ticks.ToString("x");
			byte[] bytes = Encoding.ASCII.GetBytes("\r\n--" + str + "\r\n");
			Uri uri = new Uri(url);
			HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
			httpWebRequest.ContentType = "multipart/form-data; boundary=" + str;
			httpWebRequest.Method = "POST";
			httpWebRequest.KeepAlive = true;
			httpWebRequest.Timeout = 300000;
			httpWebRequest.UserAgent = Utils.GetUserAgent(RegistryManager.Instance.UserGuid, null);
			if (!uri.Host.Contains("localhost") && !uri.Host.Contains("127.0.0.1"))
			{
				Logger.Debug("URI of proxy = " + httpWebRequest.Proxy.GetProxy(uri));
			}
			if (headers != null)
			{
				foreach (KeyValuePair<string, string> keyValuePair in headers)
				{
					httpWebRequest.Headers.Set(StringUtils.GetControlCharFreeString(keyValuePair.Key), StringUtils.GetControlCharFreeString(keyValuePair.Value));
				}
			}
			HTTPUtils.AddCommonRequestHeaders(ref httpWebRequest);
			if (data == null)
			{
				data = new Dictionary<string, string>();
			}
			Stream requestStream = httpWebRequest.GetRequestStream();
			string format = "Content-Disposition: form-data; name=\"{0}\"\r\n\r\n{1}";
			foreach (KeyValuePair<string, string> keyValuePair2 in data)
			{
				requestStream.Write(bytes, 0, bytes.Length);
				string s = string.Format(format, keyValuePair2.Key, keyValuePair2.Value);
				byte[] bytes2 = Encoding.UTF8.GetBytes(s);
				requestStream.Write(bytes2, 0, bytes2.Length);
			}
			requestStream.Write(bytes, 0, bytes.Length);
			string s2 = string.Format("Content-Disposition: form-data; name=\"{0}\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n", paramName, file, contentType);
			byte[] bytes3 = Encoding.UTF8.GetBytes(s2);
			requestStream.Write(bytes3, 0, bytes3.Length);
			string text = Environment.ExpandEnvironmentVariables("%TEMP%");
			text = Path.Combine(text, Path.GetFileName(file)) + "_bst";
			File.Copy(file, text);
			if (contentType.Equals("text/plain"))
			{
				int num = 1048576;
				string s3 = File.ReadAllText(text);
				byte[] array = new byte[num];
				array = Encoding.UTF8.GetBytes(s3);
				requestStream.Write(array, 0, array.Length);
			}
			else
			{
				FileStream fileStream = new FileStream(text, FileMode.Open, FileAccess.Read);
				byte[] array2 = new byte[4096];
				int count;
				while ((count = fileStream.Read(array2, 0, array2.Length)) != 0)
				{
					requestStream.Write(array2, 0, count);
				}
				fileStream.Close();
			}
			File.Delete(text);
			byte[] bytes4 = Encoding.ASCII.GetBytes("\r\n--" + str + "--\r\n");
			requestStream.Write(bytes4, 0, bytes4.Length);
			requestStream.Close();
			string text2 = null;
			WebResponse webResponse = null;
			try
			{
				webResponse = httpWebRequest.GetResponse();
				text2 = new StreamReader(webResponse.GetResponseStream()).ReadToEnd();
				Logger.Info(string.Format("File uploaded, server response is: {0}", text2));
			}
			catch (Exception ex)
			{
				Logger.Error("Error uploading file", new object[]
				{
					ex
				});
				if (webResponse != null)
				{
					webResponse.Close();
					webResponse = null;
				}
				throw;
			}
			finally
			{
				httpWebRequest = null;
			}
			return text2;
		}

		// Token: 0x06000606 RID: 1542 RVA: 0x0001CC2C File Offset: 0x0001AE2C
		public static string PostMultipart(string url, Dictionary<string, object> parameters, out byte[] dataArray)
		{
			string str = "---------------------------" + DateTime.Now.Ticks.ToString("x");
			byte[] bytes = Encoding.ASCII.GetBytes("\r\n--" + str + "\r\n");
			HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
			httpWebRequest.ContentType = "multipart/form-data; boundary=" + str;
			httpWebRequest.Method = "POST";
			httpWebRequest.KeepAlive = true;
			httpWebRequest.Credentials = CredentialCache.DefaultCredentials;
			if (parameters != null && parameters.Count > 0)
			{
				using (Stream requestStream = httpWebRequest.GetRequestStream())
				{
					foreach (KeyValuePair<string, object> keyValuePair in parameters)
					{
						requestStream.Write(bytes, 0, bytes.Length);
						if (keyValuePair.Value is FormFile)
						{
							FormFile formFile = keyValuePair.Value as FormFile;
							string s = string.Concat(new string[]
							{
								"Content-Disposition: form-data; name=\"",
								keyValuePair.Key,
								"\"; filename=\"",
								formFile.Name,
								"\"\r\nContent-Type: ",
								formFile.ContentType,
								"\r\n\r\n"
							});
							byte[] bytes2 = Encoding.UTF8.GetBytes(s);
							requestStream.Write(bytes2, 0, bytes2.Length);
							byte[] array = new byte[32768];
							int count;
							if (formFile.Stream == null)
							{
								using (FileStream fileStream = File.OpenRead(formFile.FilePath))
								{
									while ((count = fileStream.Read(array, 0, array.Length)) != 0)
									{
										requestStream.Write(array, 0, count);
									}
									fileStream.Close();
									continue;
								}
								goto IL_197;
							}
							IL_1A3:
							if ((count = formFile.Stream.Read(array, 0, array.Length)) == 0)
							{
								continue;
							}
							IL_197:
							requestStream.Write(array, 0, count);
							goto IL_1A3;
						}
						string s2 = string.Concat(new object[]
						{
							"Content-Disposition: form-data; name=\"",
							keyValuePair.Key,
							"\"\r\n\r\n",
							keyValuePair.Value
						});
						byte[] bytes3 = Encoding.UTF8.GetBytes(s2);
						requestStream.Write(bytes3, 0, bytes3.Length);
					}
					byte[] bytes4 = Encoding.ASCII.GetBytes("\r\n--" + str + "--\r\n");
					requestStream.Write(bytes4, 0, bytes4.Length);
					requestStream.Close();
				}
			}
			HttpStatusCode httpStatusCode = HttpStatusCode.BadRequest;
			string result = ((HttpWebResponse)httpWebRequest.GetResponse()).ToString();
			int num;
			using (HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse())
			{
				httpStatusCode = httpWebResponse.StatusCode;
				if (int.TryParse(httpWebResponse.Headers.Get("Content-Length"), out num))
				{
					Logger.Info("content lenght.." + num);
				}
				using (BinaryReader binaryReader = new BinaryReader(httpWebResponse.GetResponseStream()))
				{
					using (MemoryStream memoryStream = new MemoryStream())
					{
						byte[] array2 = binaryReader.ReadBytes(16384);
						while (array2.Length != 0)
						{
							memoryStream.Write(array2, 0, array2.Length);
							array2 = binaryReader.ReadBytes(16384);
						}
						dataArray = new byte[(int)memoryStream.Length];
						memoryStream.Position = 0L;
						memoryStream.Read(dataArray, 0, dataArray.Length);
					}
				}
			}
			if (httpStatusCode != HttpStatusCode.OK || num < 2000)
			{
				result = "error";
			}
			return result;
		}
	}
}
