﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000148 RID: 328
	public class ErrorStrings
	{
		// Token: 0x040007C8 RID: 1992
		public const string INVALID_VMNAME = "Invalid vmname";

		// Token: 0x040007C9 RID: 1993
		public const string CLIENT_PROCESS_NOT_RUNNING = "Client process is not running";

		// Token: 0x040007CA RID: 1994
		public const string CLIENT_INSTANCE_NOT_RUNNING = "Client Instance not running";

		// Token: 0x040007CB RID: 1995
		public const string GUEST_NOT_READY = "Guest not ready";

		// Token: 0x040007CC RID: 1996
		public const string PACKAGE_NAME_EMPTY = "Package name cannot be empty";

		// Token: 0x040007CD RID: 1997
		public const string CLIENT_NOT_RESPONDING = "Client not responding";

		// Token: 0x040007CE RID: 1998
		public const string MODEL_NAME_EMPTY = "Model cannot be empty";

		// Token: 0x040007CF RID: 1999
		public const string BRAND_NAME_EMPTY = "Brand cannot be empty";

		// Token: 0x040007D0 RID: 2000
		public const string MANUFACTURER_NAME_EMPTY = "Manufacturer cannot be empty";

		// Token: 0x040007D1 RID: 2001
		public const string INVALID_DEVICE_PROFILE = "Invalid parameters in device profile";

		// Token: 0x040007D2 RID: 2002
		public const string SUBDIR_EMPTY = "Subdir cannot be empty";

		// Token: 0x040007D3 RID: 2003
		public const string DEVICE_PROFILE_IN_USE = "Device profile already in use";

		// Token: 0x040007D4 RID: 2004
		public const string OLD_DEVICE_PROFILE_NOT_FOUND = "Cannot get old device profile from Android";

		// Token: 0x040007D5 RID: 2005
		public const string SHARED_FOLDER_NOT_MOUNTED = "Shared folder not mounted";

		// Token: 0x040007D6 RID: 2006
		public const string SHORTCUT_JSON_EMPTY = "Shortcut json cannot be empty";

		// Token: 0x040007D7 RID: 2007
		public const string INVALID_SHORTCUT_JSON = "Invalid shortcut json";

		// Token: 0x040007D8 RID: 2008
		public const string SHORTCUT_JSON_DOESNT_EXIST = "Shortcut json does not exist.";
	}
}
