﻿using System;
using System.IO;
using System.Net;
using System.Reflection;
using System.Threading;

namespace BlueStacks.Common
{
	// Token: 0x0200014A RID: 330
	public class Downloader
	{
		// Token: 0x14000008 RID: 8
		// (add) Token: 0x06000B24 RID: 2852 RVA: 0x00030F28 File Offset: 0x0002F128
		// (remove) Token: 0x06000B25 RID: 2853 RVA: 0x00030F60 File Offset: 0x0002F160
		public event Downloader.DownloadProgressChangedEventHandler DownloadProgressChanged;

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x06000B26 RID: 2854 RVA: 0x00030F98 File Offset: 0x0002F198
		// (remove) Token: 0x06000B27 RID: 2855 RVA: 0x00030FD0 File Offset: 0x0002F1D0
		public event Downloader.DownloadExceptionEventHandler DownloadException;

		// Token: 0x1400000A RID: 10
		// (add) Token: 0x06000B28 RID: 2856 RVA: 0x00031008 File Offset: 0x0002F208
		// (remove) Token: 0x06000B29 RID: 2857 RVA: 0x00031040 File Offset: 0x0002F240
		public event Downloader.DownloadFileCompletedEventHandler DownloadFileCompleted;

		// Token: 0x1400000B RID: 11
		// (add) Token: 0x06000B2A RID: 2858 RVA: 0x00031078 File Offset: 0x0002F278
		// (remove) Token: 0x06000B2B RID: 2859 RVA: 0x000310B0 File Offset: 0x0002F2B0
		public event Downloader.FilePayloadInfoReceivedHandler FilePayloadInfoReceived;

		// Token: 0x1400000C RID: 12
		// (add) Token: 0x06000B2C RID: 2860 RVA: 0x000310E8 File Offset: 0x0002F2E8
		// (remove) Token: 0x06000B2D RID: 2861 RVA: 0x00031120 File Offset: 0x0002F320
		public event Downloader.UnsupportedResumeEventHandler UnsupportedResume;

		// Token: 0x1400000D RID: 13
		// (add) Token: 0x06000B2E RID: 2862 RVA: 0x00031158 File Offset: 0x0002F358
		// (remove) Token: 0x06000B2F RID: 2863 RVA: 0x00031190 File Offset: 0x0002F390
		public event Downloader.DownloadRetryEventHandler DownloadRetry;

		// Token: 0x06000B30 RID: 2864 RVA: 0x0000A8D4 File Offset: 0x00008AD4
		protected virtual void OnDownloadProgressChanged(long bytes)
		{
			Downloader.DownloadProgressChangedEventHandler downloadProgressChanged = this.DownloadProgressChanged;
			if (downloadProgressChanged == null)
			{
				return;
			}
			downloadProgressChanged(bytes);
		}

		// Token: 0x06000B31 RID: 2865 RVA: 0x0000A8E7 File Offset: 0x00008AE7
		protected virtual void OnDownloadException(Exception e)
		{
			Downloader.DownloadExceptionEventHandler downloadException = this.DownloadException;
			if (downloadException == null)
			{
				return;
			}
			downloadException(e);
		}

		// Token: 0x06000B32 RID: 2866 RVA: 0x0000A8FA File Offset: 0x00008AFA
		protected virtual void OnDownloadFileCompleted()
		{
			Downloader.DownloadFileCompletedEventHandler downloadFileCompleted = this.DownloadFileCompleted;
			if (downloadFileCompleted == null)
			{
				return;
			}
			downloadFileCompleted();
		}

		// Token: 0x06000B33 RID: 2867 RVA: 0x0000A90C File Offset: 0x00008B0C
		protected virtual void OnFilePayloadInfoReceived(long size)
		{
			Downloader.FilePayloadInfoReceivedHandler filePayloadInfoReceived = this.FilePayloadInfoReceived;
			if (filePayloadInfoReceived == null)
			{
				return;
			}
			filePayloadInfoReceived(size);
		}

		// Token: 0x06000B34 RID: 2868 RVA: 0x0000A91F File Offset: 0x00008B1F
		protected virtual void OnUnsupportedResume(HttpStatusCode code)
		{
			Downloader.UnsupportedResumeEventHandler unsupportedResume = this.UnsupportedResume;
			if (unsupportedResume == null)
			{
				return;
			}
			unsupportedResume(code);
		}

		// Token: 0x06000B35 RID: 2869 RVA: 0x0000A932 File Offset: 0x00008B32
		protected virtual void OnDownloadRetryEvent()
		{
			Downloader.DownloadRetryEventHandler downloadRetry = this.DownloadRetry;
			if (downloadRetry == null)
			{
				return;
			}
			downloadRetry();
		}

		// Token: 0x06000B36 RID: 2870 RVA: 0x000311C8 File Offset: 0x0002F3C8
		public void DownloadFile(string url, string fileDestination)
		{
			FileStream fileStream = null;
			HttpWebRequest httpWebRequest = null;
			HttpWebResponse httpWebResponse = null;
			try
			{
				if (File.Exists(fileDestination))
				{
					Logger.Info("{0} already downloaded to {1}", new object[]
					{
						url,
						fileDestination
					});
					this.OnDownloadFileCompleted();
				}
				else
				{
					string text = fileDestination + ".tmp";
					try
					{
						fileStream = new FileStream(text, FileMode.Append, FileAccess.Write, FileShare.None);
					}
					catch (Exception e)
					{
						this.OnDownloadException(e);
						return;
					}
					long num = fileStream.Length;
					int num2 = 0;
					for (;;)
					{
						long num3 = num;
						try
						{
							httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
							this.AddRangeToRequest(httpWebRequest, string.Format("{0}-", num), "bytes");
							httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
						}
						catch (WebException ex)
						{
							HttpStatusCode statusCode = ((HttpWebResponse)ex.Response).StatusCode;
							if (statusCode == HttpStatusCode.RequestedRangeNotSatisfiable)
							{
								Logger.Warning("Unsupported resume! {0}", new object[]
								{
									statusCode
								});
								if (fileStream != null)
								{
									fileStream.Close();
								}
								this.OnUnsupportedResume(statusCode);
								return;
							}
							Logger.Warning("An error occured while creating a request. WebEx: {0}", new object[]
							{
								ex.Message
							});
							goto IL_2CF;
						}
						catch (Exception ex2)
						{
							Logger.Warning("An error occured while creating a request. Ex: {0}", new object[]
							{
								ex2.Message
							});
							goto IL_2CF;
						}
						goto IL_12F;
						IL_2CF:
						this.OnDownloadRetryEvent();
						if (num3 == num)
						{
							num2++;
						}
						if (num2 == 20)
						{
							this.OnDownloadException(new DownloaderExceptions.UnknownErrorException(null));
						}
						if (httpWebRequest != null)
						{
							httpWebRequest.Abort();
						}
						httpWebRequest = null;
						if (httpWebResponse != null)
						{
							httpWebResponse.Close();
						}
						httpWebResponse = null;
						int num4;
						if (num2 > 10)
						{
							num4 = 1800;
						}
						else
						{
							num4 = Convert.ToInt32(Math.Pow(2.0, (double)num2));
						}
						Logger.Info("Will retry after {0}s", new object[]
						{
							num4
						});
						Thread.Sleep(num4 * 1000);
						continue;
						IL_12F:
						if (httpWebResponse.StatusCode != HttpStatusCode.PartialContent && httpWebResponse.StatusCode != HttpStatusCode.OK)
						{
							Logger.Warning("Got an unexpected status code: {0}", new object[]
							{
								httpWebResponse.StatusCode
							});
							goto IL_2CF;
						}
						if (num != 0L && httpWebResponse.StatusCode != HttpStatusCode.PartialContent)
						{
							break;
						}
						long num5 = httpWebResponse.ContentLength + num;
						this.OnFilePayloadInfoReceived(num5);
						Stream responseStream;
						try
						{
							responseStream = httpWebResponse.GetResponseStream();
						}
						catch (Exception ex3)
						{
							Logger.Warning("An error occured while getting a response stream: {0}", new object[]
							{
								ex3.Message
							});
							goto IL_2CF;
						}
						byte[] buffer = new byte[10485760];
						for (;;)
						{
							int num6;
							try
							{
								num6 = responseStream.Read(buffer, 0, 10485760);
							}
							catch (Exception ex4)
							{
								Logger.Warning("Some error while reading from the stream. Ex: {0}", new object[]
								{
									ex4.Message
								});
								goto IL_2CF;
							}
							if (num6 == 0)
							{
								break;
							}
							try
							{
								fileStream.Write(buffer, 0, num6);
							}
							catch (Exception ex5)
							{
								Logger.Warning("Some error while writing the stream to file. Ex: {0}", new object[]
								{
									ex5.Message
								});
								this.OnDownloadException(ex5);
								return;
							}
							num += (long)num6;
							this.OnDownloadProgressChanged(num);
						}
						if (num != num5)
						{
							Logger.Error("Stream does not have more bytes to read. {0} != {1}", new object[]
							{
								num,
								num5
							});
							goto IL_2CF;
						}
						goto IL_240;
					}
					this.OnUnsupportedResume(httpWebResponse.StatusCode);
					return;
					IL_240:
					try
					{
						fileStream.Close();
						fileStream = null;
						File.Move(text, fileDestination);
						this.OnDownloadFileCompleted();
					}
					catch (Exception ex6)
					{
						Logger.Warning("Could not move file to destination. Ex: {0}", new object[]
						{
							ex6.Message
						});
						this.OnDownloadException(ex6);
					}
				}
			}
			catch (Exception ex7)
			{
				Logger.Error("Unable to download the file: {0}", new object[]
				{
					ex7.Message
				});
				this.ThrowOnFatalException(ex7);
				this.OnDownloadException(ex7);
			}
			finally
			{
				if (fileStream != null)
				{
					fileStream.Close();
				}
				if (httpWebRequest != null)
				{
					httpWebRequest.Abort();
				}
				if (httpWebResponse != null)
				{
					httpWebResponse.Close();
				}
			}
		}

		// Token: 0x06000B37 RID: 2871 RVA: 0x0000A944 File Offset: 0x00008B44
		private long GetSizeFromResponseHeaders(WebHeaderCollection headers)
		{
			return Convert.ToInt64(headers["Content-Range"].Split(new char[]
			{
				'/'
			})[1]);
		}

		// Token: 0x06000B38 RID: 2872 RVA: 0x0000A968 File Offset: 0x00008B68
		private void ThrowOnFatalException(Exception e)
		{
			if (e is ThreadAbortException || e is StackOverflowException || e is OutOfMemoryException)
			{
				throw e;
			}
		}

		// Token: 0x06000B39 RID: 2873 RVA: 0x00031658 File Offset: 0x0002F858
		private void AddRangeToRequest(WebRequest req, string range, string rangeSpecifier = "bytes")
		{
			MethodBase method = typeof(WebHeaderCollection).GetMethod("AddWithoutValidate", BindingFlags.Instance | BindingFlags.NonPublic);
			string text = "Range";
			string text2 = string.Format("{0}={1}", rangeSpecifier, range);
			method.Invoke(req.Headers, new object[]
			{
				text,
				text2
			});
		}

		// Token: 0x06000B3A RID: 2874 RVA: 0x0000D988 File Offset: 0x0000BB88
		private long GetSizeFromContentRange(HttpWebResponse webResponse)
		{
			string text = webResponse.Headers["Content-Range"];
			char[] separator = new char[]
			{
				'/'
			};
			string[] array = text.Split(separator);
			return Convert.ToInt64(array[array.Length - 1]);
		}

		// Token: 0x040007DF RID: 2015
		private const int DEFAULT_BUFFER_LENGTH = 10485760;

		// Token: 0x0200014B RID: 331
		// (Invoke) Token: 0x06000B3D RID: 2877
		public delegate void DownloadProgressChangedEventHandler(long bytes);

		// Token: 0x0200014C RID: 332
		// (Invoke) Token: 0x06000B41 RID: 2881
		public delegate void DownloadExceptionEventHandler(Exception e);

		// Token: 0x0200014D RID: 333
		// (Invoke) Token: 0x06000B45 RID: 2885
		public delegate void DownloadFileCompletedEventHandler();

		// Token: 0x0200014E RID: 334
		// (Invoke) Token: 0x06000B49 RID: 2889
		public delegate void FilePayloadInfoReceivedHandler(long size);

		// Token: 0x0200014F RID: 335
		// (Invoke) Token: 0x06000B4D RID: 2893
		public delegate void UnsupportedResumeEventHandler(HttpStatusCode sc);

		// Token: 0x02000150 RID: 336
		// (Invoke) Token: 0x06000B51 RID: 2897
		public delegate void DownloadRetryEventHandler();

		// Token: 0x02000151 RID: 337
		public class PayloadInfo
		{
			// Token: 0x170002D0 RID: 720
			// (get) Token: 0x06000B54 RID: 2900 RVA: 0x0000A984 File Offset: 0x00008B84
			public HttpStatusCode StatusCode
			{
				get
				{
					return this.mStatusCode;
				}
			}

			// Token: 0x170002D1 RID: 721
			// (get) Token: 0x06000B55 RID: 2901 RVA: 0x0000A98C File Offset: 0x00008B8C
			private bool SupportsRangeRequest
			{
				get
				{
					return this.mSupportsRangeRequest;
				}
			}

			// Token: 0x170002D2 RID: 722
			// (get) Token: 0x06000B56 RID: 2902 RVA: 0x0000A994 File Offset: 0x00008B94
			// (set) Token: 0x06000B57 RID: 2903 RVA: 0x0000A99C File Offset: 0x00008B9C
			public long Size
			{
				get
				{
					return this.mSize;
				}
				set
				{
					this.mSize = value;
				}
			}

			// Token: 0x170002D3 RID: 723
			// (get) Token: 0x06000B58 RID: 2904 RVA: 0x0000A9A5 File Offset: 0x00008BA5
			// (set) Token: 0x06000B59 RID: 2905 RVA: 0x0000A9AD File Offset: 0x00008BAD
			public long FileSize
			{
				get
				{
					return this.mFileSize;
				}
				set
				{
					this.mFileSize = value;
				}
			}

			// Token: 0x06000B5A RID: 2906 RVA: 0x0000A9B6 File Offset: 0x00008BB6
			public PayloadInfo(HttpStatusCode statusCode, long size, long fileSize = 0L, bool supportsRangeRequest = false)
			{
				this.mSupportsRangeRequest = supportsRangeRequest;
				this.mSize = size;
				this.mStatusCode = statusCode;
				if (fileSize == 0L)
				{
					this.mFileSize = size;
					return;
				}
				this.mFileSize = fileSize;
			}

			// Token: 0x040007E0 RID: 2016
			private long mSize;

			// Token: 0x040007E1 RID: 2017
			private long mFileSize;

			// Token: 0x040007E2 RID: 2018
			private readonly bool mSupportsRangeRequest;

			// Token: 0x040007E3 RID: 2019
			private readonly HttpStatusCode mStatusCode;
		}
	}
}
