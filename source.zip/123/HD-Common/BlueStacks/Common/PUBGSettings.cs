﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200009B RID: 155
	public class PUBGSettings
	{
		// Token: 0x04000392 RID: 914
		public const string Resolution720p = "1";

		// Token: 0x04000393 RID: 915
		public const string Resolution1080p = "1.5";

		// Token: 0x04000394 RID: 916
		public const string Resolution1440p = "2";

		// Token: 0x04000395 RID: 917
		public const string QualityAuto = "-1";

		// Token: 0x04000396 RID: 918
		public const string QualitySmooth = "0";

		// Token: 0x04000397 RID: 919
		public const string QualityBalanced = "1";

		// Token: 0x04000398 RID: 920
		public const string QualityHD = "2";
	}
}
