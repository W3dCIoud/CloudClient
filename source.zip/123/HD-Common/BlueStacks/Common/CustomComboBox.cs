﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x020000A7 RID: 167
	public class CustomComboBox : ComboBox, IComponentConnector, IStyleConnector
	{
		// Token: 0x06000422 RID: 1058 RVA: 0x00004449 File Offset: 0x00002649
		public CustomComboBox()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000423 RID: 1059 RVA: 0x00004457 File Offset: 0x00002657
		private void OnRequestBringIntoView(object sender, RequestBringIntoViewEventArgs e)
		{
			if (Keyboard.IsKeyDown(Key.Down) || Keyboard.IsKeyDown(Key.Up))
			{
				return;
			}
			e.Handled = true;
		}

		// Token: 0x06000424 RID: 1060 RVA: 0x0001A2D0 File Offset: 0x000184D0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/customcombobox.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000425 RID: 1061 RVA: 0x00004473 File Offset: 0x00002673
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			this._contentLoaded = true;
		}

		// Token: 0x06000426 RID: 1062 RVA: 0x0001A300 File Offset: 0x00018500
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				EventSetter eventSetter = new EventSetter();
				eventSetter.Event = FrameworkElement.RequestBringIntoViewEvent;
				eventSetter.Handler = new RequestBringIntoViewEventHandler(this.OnRequestBringIntoView);
				((Style)target).Setters.Add(eventSetter);
			}
		}

		// Token: 0x040003CF RID: 975
		private bool _contentLoaded;
	}
}
