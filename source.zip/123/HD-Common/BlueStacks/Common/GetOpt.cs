﻿using System;
using System.Collections;
using System.Reflection;
using System.Text;

namespace BlueStacks.Common
{
	// Token: 0x02000164 RID: 356
	public class GetOpt
	{
		// Token: 0x06000B95 RID: 2965 RVA: 0x00031F1C File Offset: 0x0003011C
		public void Parse(string[] args)
		{
			for (int i = 0; i < args.Length; i++)
			{
				int num = this.OptionPos(args[i]);
				if (num > 0)
				{
					if (this.GetOption(args, ref i, num))
					{
						this.mCount++;
					}
					else
					{
						this.InvalidOption(args[Math.Min(i, args.Length - 1)]);
					}
				}
				else
				{
					if (this.mArgs == null)
					{
						this.mArgs = new ArrayList();
					}
					this.mArgs.Add(args[i]);
					if (!this.IsValidArg(args[i]))
					{
						this.InvalidOption(args[i]);
					}
				}
			}
		}

		// Token: 0x170002DD RID: 733
		// (get) Token: 0x06000B96 RID: 2966 RVA: 0x0000AC18 File Offset: 0x00008E18
		public IList InvalidArgs
		{
			get
			{
				return this.mInvalidArgs;
			}
		}

		// Token: 0x170002DE RID: 734
		// (get) Token: 0x06000B97 RID: 2967 RVA: 0x0000AC20 File Offset: 0x00008E20
		public bool NoArgs
		{
			get
			{
				return this.ArgCount == 0 && this.mCount == 0;
			}
		}

		// Token: 0x170002DF RID: 735
		// (get) Token: 0x06000B98 RID: 2968 RVA: 0x0000AC35 File Offset: 0x00008E35
		public int ArgCount
		{
			get
			{
				if (this.mArgs != null)
				{
					return this.mArgs.Count;
				}
				return 0;
			}
		}

		// Token: 0x170002E0 RID: 736
		// (get) Token: 0x06000B99 RID: 2969 RVA: 0x0000AC4C File Offset: 0x00008E4C
		public bool IsInValid
		{
			get
			{
				return this.mIsInvalid;
			}
		}

		// Token: 0x06000B9A RID: 2970 RVA: 0x00031FAC File Offset: 0x000301AC
		protected virtual int OptionPos(string opt)
		{
			if (opt.Length < 2)
			{
				return 0;
			}
			char[] array;
			if (opt.Length > 2)
			{
				array = opt.ToCharArray(0, 3);
				if (array[0] == '-' && array[1] == '-' && this.IsOptionNameChar(array[2]))
				{
					return 2;
				}
			}
			else
			{
				array = opt.ToCharArray(0, 2);
			}
			if (array[0] == '-' && this.IsOptionNameChar(array[1]))
			{
				return 1;
			}
			return 0;
		}

		// Token: 0x06000B9B RID: 2971 RVA: 0x0000AC54 File Offset: 0x00008E54
		protected virtual bool IsOptionNameChar(char c)
		{
			return char.IsLetterOrDigit(c) || c == '?';
		}

		// Token: 0x06000B9C RID: 2972 RVA: 0x0000AC65 File Offset: 0x00008E65
		protected virtual void InvalidOption(string name)
		{
			this.mInvalidArgs.Add(name);
			this.mIsInvalid = true;
		}

		// Token: 0x06000B9D RID: 2973 RVA: 0x0000AC7B File Offset: 0x00008E7B
		protected virtual bool IsValidArg(string arg)
		{
			return true;
		}

		// Token: 0x06000B9E RID: 2974 RVA: 0x00032014 File Offset: 0x00030214
		protected virtual bool MatchName(MemberInfo field, string name)
		{
			object[] customAttributes = field.GetCustomAttributes(typeof(GetOpt.Arg), true);
			for (int i = 0; i < customAttributes.Length; i++)
			{
				if (string.Compare(((GetOpt.Arg)customAttributes[i]).Name, name, true) == 0)
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x06000B9F RID: 2975 RVA: 0x0003205C File Offset: 0x0003025C
		protected virtual PropertyInfo GetMemberProperty(string name)
		{
			foreach (PropertyInfo propertyInfo in base.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public))
			{
				if (string.Compare(propertyInfo.Name, name, true) == 0)
				{
					return propertyInfo;
				}
				if (this.MatchName(propertyInfo, name))
				{
					return propertyInfo;
				}
			}
			return null;
		}

		// Token: 0x06000BA0 RID: 2976 RVA: 0x000320A8 File Offset: 0x000302A8
		protected virtual FieldInfo GetMemberField(string name)
		{
			foreach (FieldInfo fieldInfo in base.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public))
			{
				if (string.Compare(fieldInfo.Name, name, true) == 0)
				{
					return fieldInfo;
				}
				if (this.MatchName(fieldInfo, name))
				{
					return fieldInfo;
				}
			}
			return null;
		}

		// Token: 0x06000BA1 RID: 2977 RVA: 0x000320F4 File Offset: 0x000302F4
		protected virtual object GetOptionValue(MemberInfo field)
		{
			object[] customAttributes = field.GetCustomAttributes(typeof(GetOpt.Arg), true);
			object[] array = customAttributes;
			for (int i = 0; i < array.Length; i++)
			{
				Console.WriteLine(array[i]);
			}
			if (customAttributes.Length != 0)
			{
				return ((GetOpt.Arg)customAttributes[0]).Value;
			}
			return null;
		}

		// Token: 0x06000BA2 RID: 2978 RVA: 0x00032140 File Offset: 0x00030340
		protected virtual bool GetOption(string[] args, ref int index, int pos)
		{
			try
			{
				object obj = null;
				string name = args[index].Substring(pos, args[index].Length - pos);
				this.SplitOptionAndValue(ref name, ref obj);
				FieldInfo memberField = this.GetMemberField(name);
				if (memberField != null)
				{
					object obj2 = this.GetOptionValue(memberField);
					if (obj2 == null)
					{
						if (memberField.FieldType == typeof(bool))
						{
							obj2 = true;
						}
						else if (memberField.FieldType == typeof(string))
						{
							object obj3;
							if (obj == null)
							{
								int num = index + 1;
								index = num;
								obj3 = args[num];
							}
							else
							{
								obj3 = obj;
							}
							obj2 = obj3;
							memberField.SetValue(this, Convert.ChangeType(obj2, memberField.FieldType));
							string text = (string)obj2;
							if (text == null || text.Length == 0)
							{
								return false;
							}
							return true;
						}
						else if (memberField.FieldType.IsEnum)
						{
							obj2 = Enum.Parse(memberField.FieldType, (string)obj, true);
						}
						else
						{
							object obj4;
							if (obj == null)
							{
								int num = index + 1;
								index = num;
								obj4 = args[num];
							}
							else
							{
								obj4 = obj;
							}
							obj2 = obj4;
						}
					}
					memberField.SetValue(this, Convert.ChangeType(obj2, memberField.FieldType));
					return true;
				}
				PropertyInfo memberProperty = this.GetMemberProperty(name);
				if (memberProperty != null)
				{
					object obj5 = this.GetOptionValue(memberProperty);
					if (obj5 == null)
					{
						if (memberProperty.PropertyType == typeof(bool))
						{
							obj5 = true;
						}
						else if (memberProperty.PropertyType == typeof(string))
						{
							object obj6;
							if (obj == null)
							{
								int num = index + 1;
								index = num;
								obj6 = args[num];
							}
							else
							{
								obj6 = obj;
							}
							obj5 = obj6;
							memberProperty.SetValue(this, Convert.ChangeType(obj5, memberProperty.PropertyType), null);
							string text2 = (string)obj5;
							if (text2 == null || text2.Length == 0)
							{
								return false;
							}
							return true;
						}
						else if (memberProperty.PropertyType.IsEnum)
						{
							obj5 = Enum.Parse(memberProperty.PropertyType, (string)obj, true);
						}
						else
						{
							object obj7;
							if (obj == null)
							{
								int num = index + 1;
								index = num;
								obj7 = args[num];
							}
							else
							{
								obj7 = obj;
							}
							obj5 = obj7;
						}
					}
					memberProperty.SetValue(this, Convert.ChangeType(obj5, memberProperty.PropertyType), null);
					return true;
				}
			}
			catch (Exception)
			{
			}
			return false;
		}

		// Token: 0x06000BA3 RID: 2979 RVA: 0x00032378 File Offset: 0x00030578
		protected virtual void SplitOptionAndValue(ref string opt, ref object val)
		{
			int num = opt.IndexOfAny(new char[]
			{
				':',
				'='
			});
			if (num < 1)
			{
				return;
			}
			val = opt.Substring(num + 1);
			opt = opt.Substring(0, num);
		}

		// Token: 0x06000BA4 RID: 2980 RVA: 0x0000AC7E File Offset: 0x00008E7E
		public virtual void Help()
		{
			Console.WriteLine(this.GetHelpText());
		}

		// Token: 0x06000BA5 RID: 2981 RVA: 0x000323BC File Offset: 0x000305BC
		public virtual string GetHelpText()
		{
			StringBuilder stringBuilder = new StringBuilder();
			FieldInfo[] fields = base.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public);
			char c = '-';
			foreach (FieldInfo fieldInfo in fields)
			{
				object[] customAttributes = fieldInfo.GetCustomAttributes(typeof(GetOpt.Arg), true);
				if (customAttributes.Length != 0)
				{
					GetOpt.Arg arg = (GetOpt.Arg)customAttributes[0];
					if (arg.Description != null)
					{
						string text = "";
						if (arg.Value == null)
						{
							if (fieldInfo.FieldType == typeof(int))
							{
								text = "[Integer]";
							}
							else if (fieldInfo.FieldType == typeof(float))
							{
								text = "[Float]";
							}
							else if (fieldInfo.FieldType == typeof(string))
							{
								text = "[String]";
							}
							else if (fieldInfo.FieldType == typeof(bool))
							{
								text = "[Boolean]";
							}
						}
						stringBuilder.AppendFormat("{0}{1,-20}\n\t{2}", c, fieldInfo.Name + text, arg.Description);
						if (arg.Name != null)
						{
							stringBuilder.AppendFormat(" (Name format: {0}{1}{2})", c, arg.Name, text);
						}
						stringBuilder.Append(Environment.NewLine);
					}
				}
			}
			return stringBuilder.ToString();
		}

		// Token: 0x04000807 RID: 2055
		protected ArrayList mArgs;

		// Token: 0x04000808 RID: 2056
		protected bool mIsInvalid;

		// Token: 0x04000809 RID: 2057
		public int mCount;

		// Token: 0x0400080A RID: 2058
		private ArrayList mInvalidArgs = new ArrayList();

		// Token: 0x02000165 RID: 357
		[AttributeUsage(AttributeTargets.Field)]
		public class Arg : Attribute
		{
			// Token: 0x170002E1 RID: 737
			// (get) Token: 0x06000BA7 RID: 2983 RVA: 0x0000AC9E File Offset: 0x00008E9E
			// (set) Token: 0x06000BA8 RID: 2984 RVA: 0x0000ACA6 File Offset: 0x00008EA6
			public string Name
			{
				get
				{
					return this.mName;
				}
				set
				{
					this.mName = value;
				}
			}

			// Token: 0x170002E2 RID: 738
			// (get) Token: 0x06000BA9 RID: 2985 RVA: 0x0000ACAF File Offset: 0x00008EAF
			// (set) Token: 0x06000BAA RID: 2986 RVA: 0x0000ACB7 File Offset: 0x00008EB7
			public object Value
			{
				get
				{
					return this.mValue;
				}
				set
				{
					this.mValue = value;
				}
			}

			// Token: 0x170002E3 RID: 739
			// (get) Token: 0x06000BAB RID: 2987 RVA: 0x0000ACC0 File Offset: 0x00008EC0
			// (set) Token: 0x06000BAC RID: 2988 RVA: 0x0000ACC8 File Offset: 0x00008EC8
			public string Description
			{
				get
				{
					return this.mDescription;
				}
				set
				{
					this.mDescription = value;
				}
			}

			// Token: 0x0400080B RID: 2059
			protected string mName;

			// Token: 0x0400080C RID: 2060
			protected object mValue;

			// Token: 0x0400080D RID: 2061
			protected string mDescription;
		}
	}
}
