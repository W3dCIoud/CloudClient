﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace BlueStacks.Common
{
	// Token: 0x020000B0 RID: 176
	public class CustomSettingsButton : Button, IComponentConnector
	{
		// Token: 0x0600046E RID: 1134 RVA: 0x0001AB9C File Offset: 0x00018D9C
		public CustomSettingsButton()
		{
			this.InitializeComponent();
			this.SetBackground();
			base.Loaded += this.CustomSettingsButton_Loaded;
			BlueStacksUIBinding.Instance.PropertyChanged += this.BlueStacksUIBinding_PropertyChanged;
		}

		// Token: 0x0600046F RID: 1135 RVA: 0x0000486B File Offset: 0x00002A6B
		private void CustomSettingsButton_Loaded(object sender, RoutedEventArgs e)
		{
			this.SetNotification();
			this.SetSelectedLine();
		}

		// Token: 0x06000470 RID: 1136 RVA: 0x00004879 File Offset: 0x00002A79
		private void BlueStacksUIBinding_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			if (e.PropertyName == "LocaleModel")
			{
				this.SetSelectedLine();
			}
		}

		// Token: 0x1700011C RID: 284
		// (get) Token: 0x06000471 RID: 1137 RVA: 0x00004893 File Offset: 0x00002A93
		// (set) Token: 0x06000472 RID: 1138 RVA: 0x0000489B File Offset: 0x00002A9B
		public string Group
		{
			get
			{
				return this.group;
			}
			set
			{
				this.group = value;
			}
		}

		// Token: 0x1700011D RID: 285
		// (get) Token: 0x06000473 RID: 1139 RVA: 0x000048A4 File Offset: 0x00002AA4
		// (set) Token: 0x06000474 RID: 1140 RVA: 0x000048AC File Offset: 0x00002AAC
		public string ImageName
		{
			get
			{
				return this.imageName;
			}
			set
			{
				this.imageName = value;
			}
		}

		// Token: 0x1700011E RID: 286
		// (get) Token: 0x06000475 RID: 1141 RVA: 0x000048B5 File Offset: 0x00002AB5
		// (set) Token: 0x06000476 RID: 1142 RVA: 0x0001ABFC File Offset: 0x00018DFC
		public bool IsSelected
		{
			get
			{
				return this.isSelected;
			}
			set
			{
				this.isSelected = value;
				this.SetBackground();
				this.SetForeGround();
				this.SetSelectedLine();
				if (this.IsSelected && !string.IsNullOrEmpty(this.Group))
				{
					if (CustomSettingsButton.dictSelecetedButtons.ContainsKey(this.Group))
					{
						CustomSettingsButton.dictSelecetedButtons[this.Group].IsSelected = false;
					}
					CustomSettingsButton.dictSelecetedButtons[this.Group] = this;
				}
			}
		}

		// Token: 0x1700011F RID: 287
		// (get) Token: 0x06000477 RID: 1143 RVA: 0x000048BD File Offset: 0x00002ABD
		// (set) Token: 0x06000478 RID: 1144 RVA: 0x000048C5 File Offset: 0x00002AC5
		public bool ShowButtonNotification
		{
			get
			{
				return this.showButtonNotification;
			}
			set
			{
				this.showButtonNotification = value;
				this.SetNotification();
			}
		}

		// Token: 0x06000479 RID: 1145 RVA: 0x0001AC70 File Offset: 0x00018E70
		private void SetNotification()
		{
			Ellipse ellipse = (Ellipse)base.Template.FindName("mBtnNotification", this);
			if (ellipse != null)
			{
				if (this.showButtonNotification)
				{
					ellipse.Visibility = Visibility.Visible;
					return;
				}
				ellipse.Visibility = Visibility.Hidden;
			}
		}

		// Token: 0x0600047A RID: 1146 RVA: 0x000048D4 File Offset: 0x00002AD4
		private void SetForeGround()
		{
			if (this.isSelected)
			{
				BlueStacksUIBinding.BindColor(this, Control.ForegroundProperty, "SettingsWindowTabMenuItemSelectedForeground");
				return;
			}
			BlueStacksUIBinding.BindColor(this, Control.ForegroundProperty, "SettingsWindowTabMenuItemForeground");
		}

		// Token: 0x0600047B RID: 1147 RVA: 0x000048FF File Offset: 0x00002AFF
		private void SetBackground()
		{
			if (this.IsSelected)
			{
				BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "SettingsWindowTabMenuItemSelectedBackground");
				return;
			}
			this.Button_MouseEvent(null, null);
		}

		// Token: 0x0600047C RID: 1148 RVA: 0x0001ACB0 File Offset: 0x00018EB0
		private void SetSelectedLine()
		{
			Line line = (Line)base.Template.FindName("mSelectedLine", this);
			ContentPresenter contentPresenter = (ContentPresenter)base.Template.FindName("contentPresenter", this);
			if (line != null)
			{
				if (this.isSelected)
				{
					line.Visibility = Visibility.Visible;
					TextBlock textBlock = (TextBlock)contentPresenter.Content;
					Typeface typeface = new Typeface(textBlock.FontFamily, textBlock.FontStyle, textBlock.FontWeight, textBlock.FontStretch);
					double widthIncludingTrailingWhitespace = new FormattedText(textBlock.Text, Thread.CurrentThread.CurrentCulture, textBlock.FlowDirection, typeface, textBlock.FontSize, textBlock.Foreground).WidthIncludingTrailingWhitespace;
					line.X2 = widthIncludingTrailingWhitespace;
					return;
				}
				line.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x0600047D RID: 1149 RVA: 0x00004922 File Offset: 0x00002B22
		private void Button_MouseEvent(object sender, MouseEventArgs e)
		{
			if (!this.IsSelected)
			{
				if (base.IsMouseOver)
				{
					BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "SettingsWindowTabMenuItemHoverBackground");
					return;
				}
				BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "SettingsWindowTabMenuItemBackground");
			}
		}

		// Token: 0x0600047E RID: 1150 RVA: 0x00004955 File Offset: 0x00002B55
		private void Button_Click(object sender, RoutedEventArgs e)
		{
			if (!this.IsSelected)
			{
				this.IsSelected = true;
			}
		}

		// Token: 0x0600047F RID: 1151 RVA: 0x00004966 File Offset: 0x00002B66
		private void Button_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (string.IsNullOrEmpty(this.group))
			{
				this.IsSelected = true;
			}
		}

		// Token: 0x06000480 RID: 1152 RVA: 0x0000497C File Offset: 0x00002B7C
		private void Button_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			if (string.IsNullOrEmpty(this.group))
			{
				this.IsSelected = false;
				this.Button_MouseEvent(null, null);
			}
		}

		// Token: 0x06000481 RID: 1153 RVA: 0x0001AD68 File Offset: 0x00018F68
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/customsettingsbutton.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000482 RID: 1154 RVA: 0x0001AD98 File Offset: 0x00018F98
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				((CustomSettingsButton)target).MouseEnter += this.Button_MouseEvent;
				((CustomSettingsButton)target).MouseLeave += this.Button_MouseEvent;
				((CustomSettingsButton)target).Click += this.Button_Click;
				((CustomSettingsButton)target).PreviewMouseDown += this.Button_PreviewMouseDown;
				((CustomSettingsButton)target).PreviewMouseUp += this.Button_PreviewMouseUp;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x040003FC RID: 1020
		private static Dictionary<string, CustomSettingsButton> dictSelecetedButtons = new Dictionary<string, CustomSettingsButton>();

		// Token: 0x040003FD RID: 1021
		private string group = string.Empty;

		// Token: 0x040003FE RID: 1022
		private string imageName = string.Empty;

		// Token: 0x040003FF RID: 1023
		private bool isSelected;

		// Token: 0x04000400 RID: 1024
		private bool showButtonNotification;

		// Token: 0x04000401 RID: 1025
		private bool _contentLoaded;
	}
}
