﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000136 RID: 310
	public struct MONITORINFO
	{
		// Token: 0x04000780 RID: 1920
		public int cbSize;

		// Token: 0x04000781 RID: 1921
		public RECT rcMonitor;

		// Token: 0x04000782 RID: 1922
		public RECT rcWork;

		// Token: 0x04000783 RID: 1923
		public uint dwFlags;
	}
}
