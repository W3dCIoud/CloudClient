﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Management;
using System.Runtime.InteropServices;
using System.Security.Principal;
using Microsoft.VisualBasic.Devices;

namespace BlueStacks.Common
{
	// Token: 0x02000170 RID: 368
	public class SystemUtils
	{
		// Token: 0x06000BE2 RID: 3042
		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool IsWow64Process(IntPtr proc, ref bool isWow);

		// Token: 0x06000BE3 RID: 3043
		[DllImport("gdi32.dll", CharSet = CharSet.Auto, ExactSpelling = true, SetLastError = true)]
		public static extern int GetDeviceCaps(IntPtr hDC, int nIndex);

		// Token: 0x06000BE4 RID: 3044 RVA: 0x0000AD8F File Offset: 0x00008F8F
		public static bool IsOSWinXP()
		{
			return Environment.OSVersion.Version.Major == 5;
		}

		// Token: 0x06000BE5 RID: 3045 RVA: 0x0000ADA3 File Offset: 0x00008FA3
		public static bool IsOSVista()
		{
			return Environment.OSVersion.Version.Major == 6 && Environment.OSVersion.Version.Minor == 0;
		}

		// Token: 0x06000BE6 RID: 3046 RVA: 0x0000ADCB File Offset: 0x00008FCB
		public static bool IsOSWin7()
		{
			return Environment.OSVersion.Version.Major == 6 && Environment.OSVersion.Version.Minor == 1;
		}

		// Token: 0x06000BE7 RID: 3047 RVA: 0x0000ADF3 File Offset: 0x00008FF3
		public static bool IsOSWin8()
		{
			return Environment.OSVersion.Version.Major == 6 && Environment.OSVersion.Version.Minor == 2;
		}

		// Token: 0x06000BE8 RID: 3048 RVA: 0x0000AE1B File Offset: 0x0000901B
		public static bool IsOSWin81()
		{
			return Environment.OSVersion.Version.Major == 6 && Environment.OSVersion.Version.Minor == 3;
		}

		// Token: 0x06000BE9 RID: 3049 RVA: 0x0000AE43 File Offset: 0x00009043
		private static bool IsOSWin10()
		{
			return ((string)RegistryUtils.GetRegistryValue("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", "ProductName", "", RegistryKeyKind.HKEY_LOCAL_MACHINE)).Contains("Windows 10");
		}

		// Token: 0x06000BEA RID: 3050 RVA: 0x000332FC File Offset: 0x000314FC
		public static int GetOSArchitecture()
		{
			string environmentVariable = Environment.GetEnvironmentVariable("PROCESSOR_ARCHITECTURE", EnvironmentVariableTarget.Machine);
			if (!string.IsNullOrEmpty(environmentVariable) && string.Compare(environmentVariable, 0, "x86", 0, 3, true) != 0)
			{
				return 64;
			}
			return 32;
		}

		// Token: 0x06000BEB RID: 3051 RVA: 0x00033334 File Offset: 0x00031534
		public static bool GetOSInfo(out string osName, out string servicePack, out string osArch)
		{
			osName = "";
			servicePack = "";
			osArch = "";
			OperatingSystem osversion = Environment.OSVersion;
			Version version = osversion.Version;
			if (osversion.Platform == PlatformID.Win32Windows)
			{
				int minor = version.Minor;
				if (minor != 0)
				{
					if (minor != 10)
					{
						if (minor == 90)
						{
							osName = "Me";
						}
					}
					else if (version.Revision.ToString() == "2222A")
					{
						osName = "98SE";
					}
					else
					{
						osName = "98";
					}
				}
				else
				{
					osName = "95";
				}
			}
			else if (osversion.Platform == PlatformID.Win32NT)
			{
				switch (version.Major)
				{
				case 3:
					osName = "NT 3.51";
					break;
				case 4:
					osName = "NT 4.0";
					break;
				case 5:
					if (version.Minor == 0)
					{
						osName = "2000";
					}
					else
					{
						osName = "XP";
					}
					break;
				case 6:
					if (version.Minor == 0)
					{
						osName = "Vista";
					}
					else if (version.Minor == 1)
					{
						osName = "7";
					}
					else if (version.Minor == 2)
					{
						osName = "8";
					}
					else if (version.Minor == 3)
					{
						osName = "8.1";
					}
					break;
				case 10:
					osName = "10";
					break;
				}
			}
			string text = osName;
			if (text != "")
			{
				text = "Windows " + text;
				if (osversion.ServicePack != "")
				{
					servicePack = osversion.ServicePack.Substring(osversion.ServicePack.LastIndexOf(' ') + 1);
					text = text + " " + osversion.ServicePack;
				}
				osArch = SystemUtils.GetOSArchitecture().ToString() + "-bit";
				text = text + " " + osArch;
				Logger.Info("Operating system details: " + text);
				return true;
			}
			return false;
		}

		// Token: 0x06000BEC RID: 3052 RVA: 0x00033520 File Offset: 0x00031720
		public static ulong GetSystemTotalPhysicalMemory()
		{
			ulong result = 0UL;
			try
			{
				result = ulong.Parse(new ComputerInfo().TotalPhysicalMemory.ToString());
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't get TotalPhysicalMemory, Ex: {0}", new object[]
				{
					ex.Message
				});
			}
			return result;
		}

		// Token: 0x06000BED RID: 3053 RVA: 0x0000AE69 File Offset: 0x00009069
		public static bool IsOs64Bit()
		{
			return IntPtr.Size == 8 || (IntPtr.Size == 4 && SystemUtils.Is32BitProcessOn64BitProcessor());
		}

		// Token: 0x06000BEE RID: 3054 RVA: 0x00033578 File Offset: 0x00031778
		private static bool Is32BitProcessOn64BitProcessor()
		{
			bool result = false;
			SystemUtils.IsWow64Process(Process.GetCurrentProcess().Handle, ref result);
			return result;
		}

		// Token: 0x06000BEF RID: 3055 RVA: 0x0003359C File Offset: 0x0003179C
		public static DateTime FromUnixEpochToLocal(long secs)
		{
			DateTime dateTime = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
			return dateTime.AddSeconds((double)secs).ToLocalTime();
		}

		// Token: 0x170002EB RID: 747
		// (get) Token: 0x06000BF0 RID: 3056 RVA: 0x0000AE85 File Offset: 0x00009085
		public static int CurrentDPI
		{
			get
			{
				if (SystemUtils.currentDPI.Equals(-2147483648))
				{
					SystemUtils.currentDPI = SystemUtils.GetDPI();
				}
				return SystemUtils.currentDPI;
			}
		}

		// Token: 0x06000BF1 RID: 3057 RVA: 0x000335CC File Offset: 0x000317CC
		public static int GetDPI()
		{
			Logger.Info("Getting DPI");
			IntPtr hdc = Graphics.FromHwnd(IntPtr.Zero).GetHdc();
			int num = SystemUtils.GetDeviceCaps(hdc, 88);
			int deviceCaps = SystemUtils.GetDeviceCaps(hdc, 10);
			int deviceCaps2 = SystemUtils.GetDeviceCaps(hdc, 117);
			float num2 = (float)deviceCaps / (float)deviceCaps2;
			num = (int)((float)num * num2);
			Logger.Info("DPI = {0}", new object[]
			{
				num
			});
			return num;
		}

		// Token: 0x06000BF2 RID: 3058 RVA: 0x00033634 File Offset: 0x00031834
		public static bool IsAdministrator()
		{
			bool result = false;
			try
			{
				WindowsIdentity current = WindowsIdentity.GetCurrent();
				if (current == null)
				{
					return false;
				}
				result = new WindowsPrincipal(current).IsInRole(WindowsBuiltInRole.Administrator);
			}
			catch
			{
			}
			return result;
		}

		// Token: 0x06000BF3 RID: 3059 RVA: 0x00030C6C File Offset: 0x0002EE6C
		public static string GetSysInfo(string query)
		{
			int num = 0;
			string text = "";
			try
			{
				foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher(query).Get())
				{
					ManagementBaseObject managementBaseObject2 = (ManagementObject)managementBaseObject;
					num++;
					foreach (PropertyData propertyData in managementBaseObject2.Properties)
					{
						text = text + propertyData.Value.ToString() + "\n";
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in getting sysinfo err:" + ex.ToString());
			}
			return text.Trim();
		}

		// Token: 0x0400083D RID: 2109
		public const int DEFAULT_DPI = 96;

		// Token: 0x0400083E RID: 2110
		private static int currentDPI = int.MinValue;

		// Token: 0x02000171 RID: 369
		public enum DeviceCap
		{
			// Token: 0x04000840 RID: 2112
			LOGPIXELSX = 88,
			// Token: 0x04000841 RID: 2113
			LOGPIXELSY = 90,
			// Token: 0x04000842 RID: 2114
			VERTRES = 10,
			// Token: 0x04000843 RID: 2115
			DESKTOPVERTRES = 117
		}
	}
}
