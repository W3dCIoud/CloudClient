﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000134 RID: 308
	[Serializable]
	public struct POINT
	{
		// Token: 0x06000A88 RID: 2696 RVA: 0x0000A2E7 File Offset: 0x000084E7
		public POINT(int x, int y)
		{
			this.X = x;
			this.Y = y;
		}

		// Token: 0x04000778 RID: 1912
		public int X;

		// Token: 0x04000779 RID: 1913
		public int Y;
	}
}
