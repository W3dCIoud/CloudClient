﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000065 RID: 101
	public class MultiInstanceStrings
	{
		// Token: 0x17000099 RID: 153
		// (get) Token: 0x06000229 RID: 553 RVA: 0x0000312F File Offset: 0x0000132F
		// (set) Token: 0x0600022A RID: 554 RVA: 0x00010330 File Offset: 0x0000E530
		public static string VmName
		{
			get
			{
				if (MultiInstanceStrings.sVmName == null)
				{
					return "Android";
				}
				return MultiInstanceStrings.sVmName;
			}
			set
			{
				if (MultiInstanceStrings.sVmName != null)
				{
					throw new Exception("VmName can be set only once");
				}
				MultiInstanceStrings.sVmName = value;
				if (MultiInstanceStrings.sVmName == "Android")
				{
					MultiInstanceStrings.sVmId = 0;
					return;
				}
				if (!int.TryParse(MultiInstanceStrings.sVmName.Split(new char[]
				{
					'_'
				})[1], out MultiInstanceStrings.sVmId))
				{
					throw new Exception("Invalid VM: " + MultiInstanceStrings.sVmName);
				}
			}
		}

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x0600022B RID: 555 RVA: 0x00003143 File Offset: 0x00001343
		// (set) Token: 0x0600022C RID: 556 RVA: 0x0000315F File Offset: 0x0000135F
		public static ushort BstServerPort
		{
			get
			{
				return (ushort)RegistryManager.Instance.Guest[MultiInstanceStrings.VmName].BstAndroidPort;
			}
			set
			{
				RegistryManager.Instance.Guest[MultiInstanceStrings.VmName].BstAndroidPort = (int)value;
			}
		}

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x0600022D RID: 557 RVA: 0x0000317B File Offset: 0x0000137B
		public static int VmId
		{
			get
			{
				return MultiInstanceStrings.sVmId;
			}
		}

		// Token: 0x04000119 RID: 281
		private static string sVmName;

		// Token: 0x0400011A RID: 282
		private static int sVmId;
	}
}
