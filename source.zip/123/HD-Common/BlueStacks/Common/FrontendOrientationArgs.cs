﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000A8 RID: 168
	public class FrontendOrientationArgs : EventArgs
	{
		// Token: 0x06000427 RID: 1063 RVA: 0x0000447C File Offset: 0x0000267C
		public FrontendOrientationArgs(bool isPotrait, string packageName)
		{
			this.IsPotrait = isPotrait;
			this.PackageName = packageName;
		}

		// Token: 0x040003D0 RID: 976
		public bool IsPotrait;

		// Token: 0x040003D1 RID: 977
		public string PackageName = string.Empty;
	}
}
