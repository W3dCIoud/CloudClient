﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x02000130 RID: 304
	public class VmCmdHandler
	{
		// Token: 0x06000A77 RID: 2679 RVA: 0x0002E1E4 File Offset: 0x0002C3E4
		public static void SyncConfig(string keyMapParserVersion, string vmName)
		{
			long num = (DateTime.UtcNow.Ticks - 621355968000000000L) / 10000L;
			VmCmdHandler.RunCommand(string.Format("settime {0}", num), vmName);
			Utils.SetTimeZoneInGuest(vmName);
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			string currentKeyboardLayout = Utils.GetCurrentKeyboardLayout();
			dictionary.Add("keyboardlayout", currentKeyboardLayout);
			string text = "setkeyboardlayout";
			Logger.Info("Sending request for " + text + " with data : ");
			foreach (KeyValuePair<string, string> keyValuePair in dictionary)
			{
				Logger.Info("key : " + keyValuePair.Key + " value : " + keyValuePair.Value);
			}
			JObject jobject;
			string text2 = VmCmdHandler.SendRequest(text, dictionary, vmName, out jobject);
			if (text2 == null || text2.Contains("error"))
			{
				Logger.Info("Failed to set keyboard layout in sync config...checking for latinime");
				try
				{
					if (Utils.IsLatinImeSelected(vmName))
					{
						HTTPUtils.SendRequestToEngine("setPcImeWorkflow", null, vmName, 0, null, false, 1, 0, "");
					}
					else if (Oem.Instance.IsSendGameManagerRequest)
					{
						HTTPUtils.SendRequestToClient("showIMESwitchPrompt", null, vmName, 0, null, false, 1, 0);
					}
				}
				catch (Exception ex)
				{
					Logger.Warning("Error in informing engine/client. Ex: {0}", new object[]
					{
						ex.Message
					});
				}
			}
			if (VmCmdHandler.RunCommand(string.Format("setkeymappingparserversion {0}", keyMapParserVersion), vmName) == null)
			{
				Logger.Error("setkeymappingparserversion did not work, will try again on frontend restart");
				return;
			}
			RegistryManager.Instance.Guest[vmName].ConfigSynced = 1;
		}

		// Token: 0x06000A78 RID: 2680 RVA: 0x0002E388 File Offset: 0x0002C588
		public static void SetMachineType(bool isDesktop, string vmName)
		{
			string cmd;
			if (isDesktop)
			{
				cmd = string.Format("isdesktop", new object[0]);
			}
			else
			{
				cmd = string.Format("istablet", new object[0]);
			}
			VmCmdHandler.RunCommand(cmd, vmName);
		}

		// Token: 0x06000A79 RID: 2681 RVA: 0x0002E3C4 File Offset: 0x0002C5C4
		public static void SetKeyboard(bool isDesktop, string vmName)
		{
			string cmd;
			if (isDesktop)
			{
				cmd = string.Format("usehardkeyboard", new object[0]);
			}
			else
			{
				cmd = string.Format("usesoftkeyboard", new object[0]);
			}
			VmCmdHandler.RunCommand(cmd, vmName);
		}

		// Token: 0x06000A7A RID: 2682 RVA: 0x0002E400 File Offset: 0x0002C600
		public static string FqdnSend(int port, string serverIn, string vmName)
		{
			string result;
			try
			{
				string arg;
				if (string.Compare(serverIn, "agent", true) == 0)
				{
					arg = "setWindowsAgentAddr";
				}
				else
				{
					if (string.Compare(serverIn, "frontend", true) != 0)
					{
						Logger.Error("Unknown server: " + serverIn);
						return null;
					}
					arg = "setWindowsFrontendAddr";
				}
				if (port == 0)
				{
					if (string.Compare(serverIn, "agent", true) == 0)
					{
						port = RegistryManager.Instance.AgentServerPort;
					}
					else if (string.Compare(serverIn, "frontend", true) == 0)
					{
						port = RegistryManager.Instance.Guest[vmName].FrontendServerPort;
					}
				}
				string arg2 = "10.0.2.2:" + port.ToString();
				result = VmCmdHandler.RunCommand(string.Format("{0} {1}", arg, arg2), vmName);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception when sending fqdn post request: " + ex.Message);
				result = null;
			}
			return result;
		}

		// Token: 0x06000A7B RID: 2683 RVA: 0x0002E4E8 File Offset: 0x0002C6E8
		public static string RunCommand(string cmd, string vmName)
		{
			int num = cmd.IndexOf(' ');
			string text;
			string text2;
			if (num == -1)
			{
				text = cmd;
				text2 = "";
			}
			else
			{
				text = cmd.Substring(0, num);
				text2 = cmd.Substring(num + 1);
			}
			Logger.Info("Will send command: {0} to {1}", new object[]
			{
				text2,
				text
			});
			JObject jobject;
			return VmCmdHandler.SendRequest(text, new Dictionary<string, string>
			{
				{
					"arg",
					text2
				}
			}, vmName, out jobject);
		}

		// Token: 0x06000A7C RID: 2684 RVA: 0x0002E554 File Offset: 0x0002C754
		public static string SendRequest(string path, Dictionary<string, string> data, string vmName, out JObject response)
		{
			int i = 60;
			int num = 3;
			response = null;
			while (i > 0)
			{
				try
				{
					if (num != 0)
					{
						num--;
					}
					string text;
					if (path == "runex" || path == "run" || path == "powerrun")
					{
						text = HTTPUtils.SendRequestToGuest(path, data, vmName, 3000, null, false, 1, 0);
					}
					else if (path == "setWindowsAgentAddr")
					{
						text = HTTPUtils.SendRequestToGuest(path, data, vmName, 1000, null, false, 1, 0);
					}
					else
					{
						text = HTTPUtils.SendRequestToGuest(path, data, vmName, 0, null, false, 1, 0);
					}
					Logger.Info("Got response for {0}: {1}", new object[]
					{
						path,
						text
					});
					response = JObject.Parse(text);
					VmCmdHandler.s_Received = (string)response["result"];
					if (VmCmdHandler.s_Received != "ok" && VmCmdHandler.s_Received != "error")
					{
						VmCmdHandler.s_Received = null;
					}
				}
				catch (Exception ex)
				{
					if (num != 0)
					{
						Logger.Error("Exception in SendRequest for {0}: {1}", new object[]
						{
							path,
							ex.Message
						});
					}
					VmCmdHandler.s_Received = null;
				}
				i--;
				if (VmCmdHandler.s_Received != null)
				{
					return VmCmdHandler.s_Received;
				}
				if (i > 0)
				{
					Thread.Sleep(1000);
				}
			}
			return null;
		}

		// Token: 0x06000A7D RID: 2685 RVA: 0x0000A222 File Offset: 0x00008422
		public static void RunCommandAsync(string cmd, UIHelper.Action continuation, Control control, string vmName)
		{
			new System.Threading.Timer(delegate(object obj)
			{
				VmCmdHandler.RunCommand(cmd, vmName);
				if (continuation != null)
				{
					UIHelper.RunOnUIThread(control, continuation);
				}
			}, null, 0, -1);
		}

		// Token: 0x0400076D RID: 1901
		private static string s_Received;
	}
}
