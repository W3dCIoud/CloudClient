﻿using System;
using System.Drawing;
using System.Windows.Media;

namespace BlueStacks.Common
{
	// Token: 0x0200009F RID: 159
	[Serializable]
	public class ColorUtils
	{
		// Token: 0x170000EC RID: 236
		// (get) Token: 0x06000390 RID: 912 RVA: 0x0000400B File Offset: 0x0000220B
		// (set) Token: 0x06000391 RID: 913 RVA: 0x00004013 File Offset: 0x00002213
		public byte R
		{
			get
			{
				return this.r;
			}
			set
			{
				this.r = value;
			}
		}

		// Token: 0x170000ED RID: 237
		// (get) Token: 0x06000392 RID: 914 RVA: 0x0000401C File Offset: 0x0000221C
		// (set) Token: 0x06000393 RID: 915 RVA: 0x00004024 File Offset: 0x00002224
		public byte G
		{
			get
			{
				return this.g;
			}
			set
			{
				this.g = value;
			}
		}

		// Token: 0x170000EE RID: 238
		// (get) Token: 0x06000394 RID: 916 RVA: 0x0000402D File Offset: 0x0000222D
		// (set) Token: 0x06000395 RID: 917 RVA: 0x00004035 File Offset: 0x00002235
		public byte B
		{
			get
			{
				return this.b;
			}
			set
			{
				this.b = value;
			}
		}

		// Token: 0x170000EF RID: 239
		// (get) Token: 0x06000396 RID: 918 RVA: 0x0000403E File Offset: 0x0000223E
		// (set) Token: 0x06000397 RID: 919 RVA: 0x00004046 File Offset: 0x00002246
		public byte A
		{
			get
			{
				return this.a;
			}
			set
			{
				this.a = value;
			}
		}

		// Token: 0x06000398 RID: 920 RVA: 0x0000404F File Offset: 0x0000224F
		public ColorUtils()
		{
			this.R = byte.MaxValue;
			this.G = byte.MaxValue;
			this.B = byte.MaxValue;
			this.A = byte.MaxValue;
		}

		// Token: 0x06000399 RID: 921 RVA: 0x00004083 File Offset: 0x00002283
		public ColorUtils(System.Windows.Media.Color value)
		{
			this.R = value.R;
			this.G = value.G;
			this.B = value.B;
			this.A = value.A;
		}

		// Token: 0x0600039A RID: 922 RVA: 0x000040BF File Offset: 0x000022BF
		public ColorUtils(System.Drawing.Color value)
		{
			this.R = value.R;
			this.G = value.G;
			this.B = value.B;
			this.A = value.A;
		}

		// Token: 0x0600039B RID: 923 RVA: 0x000040FB File Offset: 0x000022FB
		public static implicit operator System.Drawing.Color(ColorUtils rgb)
		{
			return System.Drawing.Color.FromArgb((int)rgb.A, (int)rgb.R, (int)rgb.G, (int)rgb.B);
		}

		// Token: 0x0600039C RID: 924 RVA: 0x0000411A File Offset: 0x0000231A
		public static explicit operator ColorUtils(System.Drawing.Color c)
		{
			return new ColorUtils(c);
		}

		// Token: 0x0600039D RID: 925 RVA: 0x00004122 File Offset: 0x00002322
		public static ColorUtils FromHSL(double H, double S, double L)
		{
			return ColorUtils.FromHSLA(H, S, L, 1.0);
		}

		// Token: 0x0600039E RID: 926 RVA: 0x00016CFC File Offset: 0x00014EFC
		public static ColorUtils FromHSLA(double H, double S, double L, double A)
		{
			if (H > 1.0)
			{
				H = 1.0;
			}
			if (S > 1.0)
			{
				S = 1.0;
			}
			if (L > 1.0)
			{
				L = 1.0;
			}
			if (H < 0.0)
			{
				H = 0.0;
			}
			if (S < 0.0)
			{
				S = 0.0;
			}
			if (L < 0.0)
			{
				L = 0.0;
			}
			if (A > 1.0)
			{
				A = 1.0;
			}
			double num = L;
			double num2 = L;
			double num3 = L;
			double num4 = (L <= 0.5) ? (L * (1.0 + S)) : (L + S - L * S);
			if (num4 > 0.0)
			{
				double num5 = L + L - num4;
				double num6 = (num4 - num5) / num4;
				H *= 6.0;
				int num7 = (int)H;
				double num8 = H - (double)num7;
				double num9 = num4 * num6 * num8;
				double num10 = num5 + num9;
				double num11 = num4 - num9;
				switch (num7)
				{
				case 0:
					num = num4;
					num2 = num10;
					num3 = num5;
					break;
				case 1:
					num = num11;
					num2 = num4;
					num3 = num5;
					break;
				case 2:
					num = num5;
					num2 = num4;
					num3 = num10;
					break;
				case 3:
					num = num5;
					num2 = num11;
					num3 = num4;
					break;
				case 4:
					num = num10;
					num2 = num5;
					num3 = num4;
					break;
				case 5:
					num = num4;
					num2 = num5;
					num3 = num11;
					break;
				}
			}
			return new ColorUtils
			{
				R = Convert.ToByte(num * 255.0),
				G = Convert.ToByte(num2 * 255.0),
				B = Convert.ToByte(num3 * 255.0),
				A = Convert.ToByte(A * 255.0)
			};
		}

		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x0600039F RID: 927 RVA: 0x00016ED8 File Offset: 0x000150D8
		public float H
		{
			get
			{
				return this.GetHue() / 360f;
			}
		}

		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x060003A0 RID: 928 RVA: 0x00016EFC File Offset: 0x000150FC
		public float S
		{
			get
			{
				return this.GetSaturation();
			}
		}

		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x060003A1 RID: 929 RVA: 0x00016F18 File Offset: 0x00015118
		public float L
		{
			get
			{
				return this.GetBrightness();
			}
		}

		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x060003A2 RID: 930 RVA: 0x00004135 File Offset: 0x00002335
		public System.Windows.Media.Color WPFColor
		{
			get
			{
				return System.Windows.Media.Color.FromArgb(this.A, this.R, this.G, this.B);
			}
		}

		// Token: 0x040003B0 RID: 944
		private byte r;

		// Token: 0x040003B1 RID: 945
		private byte g;

		// Token: 0x040003B2 RID: 946
		private byte b;

		// Token: 0x040003B3 RID: 947
		private byte a;
	}
}
