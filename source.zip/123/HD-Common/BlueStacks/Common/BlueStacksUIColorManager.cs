﻿using System;
using System.Collections.Generic;
using System.IO;

namespace BlueStacks.Common
{
	// Token: 0x02000094 RID: 148
	public class BlueStacksUIColorManager
	{
		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x0600035D RID: 861 RVA: 0x00003B5A File Offset: 0x00001D5A
		public static string ThemeFilePath
		{
			get
			{
				return Path.Combine(Path.Combine(RegistryManager.Instance.ClientInstallDir, RegistryManager.Instance.ClientThemeName), "ThemeFile");
			}
		}

		// Token: 0x0600035E RID: 862 RVA: 0x0001672C File Offset: 0x0001492C
		public static string GetThemeFilePath(string themeName)
		{
			string text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ThemeFile");
			if (File.Exists(text))
			{
				return text;
			}
			return Path.Combine(Path.Combine(RegistryManager.Instance.ClientInstallDir, themeName), "ThemeFile");
		}

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x06000360 RID: 864 RVA: 0x00016774 File Offset: 0x00014974
		public static BlueStacksUIColorManager Instance
		{
			get
			{
				if (BlueStacksUIColorManager.mInstance == null)
				{
					object obj = BlueStacksUIColorManager.syncRoot;
					lock (obj)
					{
						if (BlueStacksUIColorManager.mInstance == null)
						{
							BlueStacksUIColorManager.mInstance = new BlueStacksUIColorManager();
						}
					}
				}
				return BlueStacksUIColorManager.mInstance;
			}
		}

		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x06000361 RID: 865 RVA: 0x000167CC File Offset: 0x000149CC
		// (set) Token: 0x06000362 RID: 866 RVA: 0x00003EEA File Offset: 0x000020EA
		public static BluestacksUIColor AppliedTheme
		{
			get
			{
				if (BlueStacksUIColorManager.mAppliedTheme == null)
				{
					object obj = BlueStacksUIColorManager.syncRoot;
					lock (obj)
					{
						if (BlueStacksUIColorManager.mAppliedTheme == null)
						{
							BluestacksUIColor bluestacksUIColor = BluestacksUIColor.Load(BlueStacksUIColorManager.GetThemeFilePath(RegistryManager.Instance.ClientThemeName));
							if (bluestacksUIColor != null && bluestacksUIColor.DictBrush.Count > 0)
							{
								BlueStacksUIColorManager.mAppliedTheme = bluestacksUIColor;
							}
							if (BlueStacksUIColorManager.mAppliedTheme != null)
							{
								BlueStacksUIColorManager.mAppliedTheme.NotifyUIElements();
							}
						}
					}
				}
				return BlueStacksUIColorManager.mAppliedTheme;
			}
			private set
			{
				if (value != null)
				{
					BlueStacksUIColorManager.mAppliedTheme = value;
					BlueStacksUIColorManager.mAppliedTheme.NotifyUIElements();
				}
			}
		}

		// Token: 0x06000363 RID: 867 RVA: 0x00016850 File Offset: 0x00014A50
		public static void ReloadAppliedTheme(string themeName)
		{
			BluestacksUIColor bluestacksUIColor = BluestacksUIColor.Load(BlueStacksUIColorManager.GetThemeFilePath(themeName));
			if (bluestacksUIColor != null && bluestacksUIColor.DictBrush.Count > 0)
			{
				BlueStacksUIColorManager.AppliedTheme = bluestacksUIColor;
				RegistryManager.Instance.ClientThemeName = themeName;
				CustomPictureBox.UpdateImagesFromNewDirectory("");
			}
		}

		// Token: 0x06000364 RID: 868 RVA: 0x00016898 File Offset: 0x00014A98
		public static void ApplyDefaultTheme(string themeName)
		{
			BluestacksUIColor bluestacksUIColor = BluestacksUIColor.Load(BlueStacksUIColorManager.GetThemeFilePath(themeName));
			if (bluestacksUIColor != null && bluestacksUIColor.DictBrush.Count > 0)
			{
				BlueStacksUIColorManager.AppliedTheme = bluestacksUIColor;
				RegistryManager.Instance.mThemeName = themeName;
			}
		}

		// Token: 0x06000365 RID: 869 RVA: 0x000168D4 File Offset: 0x00014AD4
		public static IEnumerable<string> GetThemes()
		{
			List<string> list = new List<string>();
			foreach (string text in Directory.GetDirectories(RegistryManager.Instance.ClientInstallDir))
			{
				if (File.Exists(Path.Combine(text, "ThemeFile")))
				{
					list.Add(Path.GetFileName(text));
				}
			}
			return list;
		}

		// Token: 0x06000366 RID: 870 RVA: 0x00016928 File Offset: 0x00014B28
		public static string GetThemeName(string themeName)
		{
			string text = "";
			try
			{
				if (!File.Exists(BlueStacksUIColorManager.GetThemeFilePath(themeName)))
				{
					throw new Exception("Theme file not found exception " + themeName);
				}
				text = BluestacksUIColor.Load(BlueStacksUIColorManager.GetThemeFilePath(themeName)).DictThemeAvailable["ThemeDisplayName"];
				text = LocaleStrings.GetLocalizedString(text, false);
			}
			catch (Exception ex)
			{
				Logger.Warning("Error checking for theme availability in Theme file " + themeName + Environment.NewLine + ex.ToString());
				text = "";
			}
			return text;
		}

		// Token: 0x06000367 RID: 871 RVA: 0x000169B8 File Offset: 0x00014BB8
		public static void ApplyTheme(string themeName)
		{
			try
			{
				if (!File.Exists(BlueStacksUIColorManager.GetThemeFilePath(themeName)))
				{
					throw new Exception("Theme file not found exception " + themeName);
				}
				BluestacksUIColor bluestacksUIColor = BluestacksUIColor.Load(BlueStacksUIColorManager.GetThemeFilePath(themeName));
				if (bluestacksUIColor != null && bluestacksUIColor.DictBrush.Count > 0)
				{
					BlueStacksUIColorManager.AppliedTheme = bluestacksUIColor;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error checking for theme availability in Theme file " + themeName + Environment.NewLine + ex.ToString());
			}
		}

		// Token: 0x0400036E RID: 878
		public const string ThemeFileName = "ThemeFile";

		// Token: 0x0400036F RID: 879
		private static volatile BlueStacksUIColorManager mInstance = null;

		// Token: 0x04000370 RID: 880
		private static object syncRoot = new object();

		// Token: 0x04000371 RID: 881
		private static BluestacksUIColor mAppliedTheme = null;
	}
}
