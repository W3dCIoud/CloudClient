﻿using System;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x02000098 RID: 152
	public class CenterToolTipConverter : MarkupExtension, IMultiValueConverter
	{
		// Token: 0x06000378 RID: 888 RVA: 0x00016ABC File Offset: 0x00014CBC
		public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
		{
			if (values.FirstOrDefault((object v) => v == DependencyProperty.UnsetValue) != null)
			{
				return double.NaN;
			}
			double num = (double)values[0];
			double num2 = (double)values[1];
			return num / 2.0 - num2 / 2.0;
		}

		// Token: 0x06000379 RID: 889 RVA: 0x00003F65 File Offset: 0x00002165
		public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600037A RID: 890 RVA: 0x00003F48 File Offset: 0x00002148
		public override object ProvideValue(IServiceProvider serviceProvider)
		{
			return this;
		}
	}
}
