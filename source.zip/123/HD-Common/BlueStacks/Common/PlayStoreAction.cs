﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000D3 RID: 211
	public enum PlayStoreAction
	{
		// Token: 0x0400052B RID: 1323
		OpenApp,
		// Token: 0x0400052C RID: 1324
		SearchApp,
		// Token: 0x0400052D RID: 1325
		CustomActivity
	}
}
