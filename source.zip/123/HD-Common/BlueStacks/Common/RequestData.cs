﻿using System;
using System.Collections.Specialized;

namespace BlueStacks.Common
{
	// Token: 0x020000C2 RID: 194
	public class RequestData
	{
		// Token: 0x0600064D RID: 1613 RVA: 0x00006817 File Offset: 0x00004A17
		public RequestData()
		{
			this.headers = new NameValueCollection();
			this.queryString = new NameValueCollection();
			this.data = new NameValueCollection();
			this.files = new NameValueCollection();
		}

		// Token: 0x040004CF RID: 1231
		public NameValueCollection headers;

		// Token: 0x040004D0 RID: 1232
		public NameValueCollection queryString;

		// Token: 0x040004D1 RID: 1233
		public NameValueCollection data;

		// Token: 0x040004D2 RID: 1234
		public NameValueCollection files;

		// Token: 0x040004D3 RID: 1235
		public string requestVmName;

		// Token: 0x040004D4 RID: 1236
		public int requestVmId;
	}
}
