﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000066 RID: 102
	public enum CpuHvmState
	{
		// Token: 0x0400011C RID: 284
		False,
		// Token: 0x0400011D RID: 285
		True,
		// Token: 0x0400011E RID: 286
		Unknown
	}
}
