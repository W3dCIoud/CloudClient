﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x020000DF RID: 223
	public static class JsonExtensions
	{
		// Token: 0x06000654 RID: 1620 RVA: 0x0001E934 File Offset: 0x0001CB34
		public static IEnumerable<KeyValuePair<string, string>> ToStringStringEnumerableKvp(this JToken obj)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			foreach (KeyValuePair<string, string> keyValuePair in obj.ToObject<Dictionary<string, string>>())
			{
				dictionary.Add(keyValuePair.Key, keyValuePair.Value);
			}
			return dictionary;
		}

		// Token: 0x06000655 RID: 1621 RVA: 0x0001E99C File Offset: 0x0001CB9C
		public static IDictionary<string, T> ToDictionary<T>(this JToken obj)
		{
			Dictionary<string, T> dictionary = new Dictionary<string, T>();
			foreach (KeyValuePair<string, T> keyValuePair in obj.ToObject<IDictionary<string, T>>())
			{
				dictionary.Add(keyValuePair.Key, keyValuePair.Value);
			}
			return dictionary;
		}

		// Token: 0x06000656 RID: 1622 RVA: 0x0001EA00 File Offset: 0x0001CC00
		public static SerializableDictionary<string, T> ToSerializableDictionary<T>(this JToken obj)
		{
			SerializableDictionary<string, T> serializableDictionary = new SerializableDictionary<string, T>();
			foreach (KeyValuePair<string, T> keyValuePair in obj.ToObject<SerializableDictionary<string, T>>())
			{
				serializableDictionary.Add(keyValuePair.Key, keyValuePair.Value);
			}
			return serializableDictionary;
		}

		// Token: 0x06000657 RID: 1623 RVA: 0x0000687C File Offset: 0x00004A7C
		public static IEnumerable<string> ToIenumerableString(this JToken obj)
		{
			return obj.ToObject<List<string>>();
		}

		// Token: 0x06000658 RID: 1624 RVA: 0x00006884 File Offset: 0x00004A84
		public static bool AssignIfContains<T>(this JToken resJson, string key, Action<T> setter)
		{
			if (resJson != null && resJson[key] != null)
			{
				setter(resJson.Value<T>(key));
				return true;
			}
			return false;
		}

		// Token: 0x06000659 RID: 1625 RVA: 0x000068A2 File Offset: 0x00004AA2
		public static void AssignStringIfContains(this JToken resJson, string key, ref string result)
		{
			if (resJson != null && resJson[key] != null)
			{
				result = resJson[key].ToString();
			}
		}

		// Token: 0x0600065A RID: 1626 RVA: 0x000068BE File Offset: 0x00004ABE
		public static void AssignDoubleIfContains(this JToken resJson, string key, ref double result)
		{
			if (resJson != null && resJson[key] != null)
			{
				result = resJson[key].ToObject<double>();
			}
		}

		// Token: 0x0600065B RID: 1627 RVA: 0x000068DA File Offset: 0x00004ADA
		public static bool IsNullOrEmptyBrackets(string str)
		{
			str = Regex.Replace(str, "\\s+", "");
			return string.IsNullOrEmpty(str) || string.Compare(str, "{}", true) == 0;
		}

		// Token: 0x0600065C RID: 1628 RVA: 0x00006909 File Offset: 0x00004B09
		public static string GetValue(this JToken obj, string key)
		{
			if (obj != null && obj[key] != null)
			{
				return obj[key].ToString();
			}
			return string.Empty;
		}

		// Token: 0x0600065D RID: 1629 RVA: 0x0001EA68 File Offset: 0x0001CC68
		public static bool IsNullOrEmpty(this JToken token)
		{
			return token == null || (token.Type == JTokenType.Array && !token.HasValues) || (token.Type == JTokenType.Object && !token.HasValues) || (token.Type == JTokenType.String && token.ToString() == string.Empty) || token.Type == JTokenType.Null;
		}
	}
}
