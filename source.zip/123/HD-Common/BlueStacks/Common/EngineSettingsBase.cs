﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Navigation;
using Microsoft.VisualBasic.Devices;

namespace BlueStacks.Common
{
	// Token: 0x020000E8 RID: 232
	public class EngineSettingsBase : UserControl, IComponentConnector
	{
		// Token: 0x1700029C RID: 668
		// (get) Token: 0x06000844 RID: 2116 RVA: 0x00009332 File Offset: 0x00007532
		public CustomButton RestartNowBtn
		{
			get
			{
				return this.mRestartNowBtn;
			}
		}

		// Token: 0x1700029D RID: 669
		// (get) Token: 0x06000845 RID: 2117 RVA: 0x000219B0 File Offset: 0x0001FBB0
		public static string RAM
		{
			get
			{
				int num = 0;
				try
				{
					num = (int)(new ComputerInfo().TotalPhysicalMemory / 1048576UL);
				}
				catch (Exception ex)
				{
					Logger.Error("Exception when finding ram");
					Logger.Error(ex.ToString());
				}
				return num.ToString();
			}
		}

		// Token: 0x06000846 RID: 2118 RVA: 0x00003337 File Offset: 0x00001537
		protected virtual void RestartNowBtn_Click(object sender, RoutedEventArgs e)
		{
		}

		// Token: 0x06000847 RID: 2119 RVA: 0x00021A04 File Offset: 0x0001FC04
		public EngineSettingsBase()
		{
			this.LoadViewFromUri("/HD-Common;component/UIElements/EngineSettingsBase.xaml");
			base.Visibility = Visibility.Hidden;
			this.mRestartNowBtn.Visibility = Visibility.Hidden;
			this.mScrollBar.ScrollChanged += BluestacksUIColor.ScrollBarScrollChanged;
		}

		// Token: 0x06000848 RID: 2120 RVA: 0x00021AE8 File Offset: 0x0001FCE8
		public void Init()
		{
			this.mUserRAM = RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].Memory;
			this.mUserCPU = RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].VCPUs;
			this.mUseDedicatedGPU.IsChecked = new bool?(this.mUseDedicatedGraphicsInitValue);
			this.mUseDedicatedGPU.Content = string.Format("{0} {1}", LocaleStrings.GetLocalizedString("STRING_USE_DEDICATED_GPU", false), LocaleStrings.GetLocalizedString("STRING_NVIDIA_ONLY", false));
			this.mCurrentGLRenderMode = RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].GlRenderMode;
			this.mSelectedGLRenderMode = this.mCurrentGLRenderMode;
			this.mCurrentGLmode = RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].GlMode;
			this.mSelectedGLMode = this.mCurrentGLmode;
			this.mCurrentGraphicsBitPattern = this.GenerateGraphicsBitPattern(this.mCurrentGLmode, this.mCurrentGLRenderMode);
			if (this.mCurrentGLRenderMode == 1)
			{
				this.mOpenGLRadio.IsChecked = new bool?(true);
				this.previousGraphics = this.mOpenGLRadio;
			}
			else
			{
				this.mDirectXRadio.IsChecked = new bool?(true);
				this.previousGraphics = this.mDirectXRadio;
			}
			this.BuildCPUProperties();
			this.InitRAMProperties();
			this.BuildCPURAMComboProperties();
			this.mAdvanceGraphicsSettings.IsChecked = new bool?(Utils.GetValueInBootParams("GlMode", EngineSettingsBase.mVmName, "") == "2");
			this.mHyperLink.Inlines.Clear();
			this.mHyperLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_CLICK_HERE", false));
			string uriString = WebHelper.GetUrlWithParams(string.Format("{0}/{1}", WebHelper.GetServerHost(), "help_articles")) + "&article=bgp_kk_compat_version";
			this.mHyperLink.NavigateUri = new Uri(uriString);
			bool flag = RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].EnableHighFPS != 0;
			if (flag)
			{
				this.mMaxFPS = 240;
				this.mMaximumFrameRateText.Text = "240";
			}
			this.mCustomFPSSlider.Minimum = (double)this.mMinFPS;
			this.mCustomFPSSlider.Maximum = (double)this.mMaxFPS;
			EngineSettingsBase.mInitialFPSSliderValue = RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].FPS;
			this.mCustomFPSSlider.Value = (double)RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].FPS;
			if (!RegistryManager.Instance.CurrentFarmModeStatus || !Utils.GetRunningInstancesList().Contains(EngineSettingsBase.mVmName))
			{
				this.mCustomFPSSlider.IsEnabled = true;
			}
			else
			{
				this.mCustomFPSSlider.IsEnabled = false;
			}
			this.mCurrentFPSSliderTextBlock.Text = EngineSettingsBase.mInitialFPSSliderValue.ToString();
			if (Utils.IsGuestBooted(EngineSettingsBase.mVmName))
			{
				this.mDisplayFPSGrid.Visibility = Visibility.Visible;
				this.mDisplayFPS.IsChecked = new bool?(RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].ShowFPS != 0);
				this.mEnableHighFPSGrid.Visibility = Visibility.Visible;
				this.mEnableHighFPS.IsChecked = new bool?(flag);
			}
		}

		// Token: 0x06000849 RID: 2121 RVA: 0x00021E18 File Offset: 0x00020018
		private void InitCPURAMComboDict()
		{
			if (this.mCPURAMCombinationDict == null)
			{
				this.mCPURAMCombinationDict = new Dictionary<PerformanceSetting, Dictionary<PerformanceProperty, int>>();
				this.mCPURAMCombinationDict.Add(PerformanceSetting.High, new Dictionary<PerformanceProperty, int>
				{
					{
						PerformanceProperty.CPUCores,
						4
					},
					{
						PerformanceProperty.RAM,
						3072
					}
				});
				this.mCPURAMCombinationDict.Add(PerformanceSetting.Medium, new Dictionary<PerformanceProperty, int>
				{
					{
						PerformanceProperty.CPUCores,
						2
					},
					{
						PerformanceProperty.RAM,
						2048
					}
				});
				this.mCPURAMCombinationDict.Add(PerformanceSetting.Low, new Dictionary<PerformanceProperty, int>
				{
					{
						PerformanceProperty.CPUCores,
						1
					},
					{
						PerformanceProperty.RAM,
						1024
					}
				});
				this.mCPURAMCombinationDict.Add(PerformanceSetting.Custom, new Dictionary<PerformanceProperty, int>
				{
					{
						PerformanceProperty.CPUCores,
						0
					},
					{
						PerformanceProperty.RAM,
						0
					}
				});
			}
			this.SetCPURAMDictValues();
		}

		// Token: 0x0600084A RID: 2122 RVA: 0x0000933A File Offset: 0x0000753A
		private void BuildCPURAMComboProperties()
		{
			this.InitCPURAMComboDict();
			EngineSettingsBase.mInitialPerformanceSetting = this.GetCurrentAssignedPerformanceSetting();
			this.CreateCPURAMComboBox();
			if (EngineSettingsBase.mInitialPerformanceSetting == PerformanceSetting.Custom)
			{
				this.ToggleCPURAMGridVisibility(true);
				return;
			}
			this.ToggleCPURAMGridVisibility(false);
		}

		// Token: 0x0600084B RID: 2123 RVA: 0x00021ED4 File Offset: 0x000200D4
		private void CreateCPURAMComboBox()
		{
			this.mCPURAMComboBox.Items.Clear();
			foreach (PerformanceSetting performanceSetting in this.mCPURAMCombinationDict.Keys)
			{
				ComboBoxItem comboBoxItem = new ComboBoxItem();
				if (performanceSetting != PerformanceSetting.Custom)
				{
					string arg = string.Format("{0} {1}", this.mCPURAMCombinationDict[performanceSetting][PerformanceProperty.CPUCores], LocaleStrings.GetLocalizedString("STRING_CPU_CORES", false));
					string arg2 = string.Format("{0} {1}", this.mCPURAMCombinationDict[performanceSetting][PerformanceProperty.RAM], LocaleStrings.GetLocalizedString("STRING_MEMORY_LOWERCASE", false));
					string arg3 = "";
					if (performanceSetting == PerformanceSetting.High)
					{
						arg3 = LocaleStrings.GetLocalizedString("STRING_HIGH", false);
					}
					else if (performanceSetting == PerformanceSetting.Medium)
					{
						arg3 = LocaleStrings.GetLocalizedString("STRING_MEDIUM", false);
					}
					else if (performanceSetting == PerformanceSetting.Low)
					{
						arg3 = LocaleStrings.GetLocalizedString("STRING_LOW", false);
					}
					comboBoxItem.Content = string.Format("{0} {1}", arg3, string.Format(LocaleStrings.GetLocalizedString("STRING_BRACKETS_0_COMMA_1", false), arg, arg2));
				}
				else
				{
					comboBoxItem.Content = LocaleStrings.GetLocalizedString("STRING_CUSTOM1", false);
				}
				comboBoxItem.Tag = performanceSetting;
				this.mCPURAMComboBox.Items.Add(comboBoxItem);
				if (performanceSetting == EngineSettingsBase.mInitialPerformanceSetting)
				{
					this.mCPURAMComboBox.SelectedItem = comboBoxItem;
				}
			}
		}

		// Token: 0x0600084C RID: 2124 RVA: 0x00022058 File Offset: 0x00020258
		private void SetCPURAMDictValues()
		{
			if (this.mUserSupportedVCPUs == 3)
			{
				this.mCPURAMCombinationDict[PerformanceSetting.High][PerformanceProperty.CPUCores] = this.mUserSupportedVCPUs;
			}
			else if (this.mUserSupportedVCPUs <= 2)
			{
				this.mCPURAMCombinationDict[PerformanceSetting.High][PerformanceProperty.CPUCores] = this.mUserSupportedVCPUs;
				this.mCPURAMCombinationDict[PerformanceSetting.Medium][PerformanceProperty.CPUCores] = this.mUserSupportedVCPUs;
			}
			if (this.mMaxRam >= 2048 && this.mMaxRam < 3072)
			{
				this.mCPURAMCombinationDict[PerformanceSetting.High][PerformanceProperty.RAM] = this.mMaxRam;
				return;
			}
			if (this.mMaxRam >= 1024 && this.mMaxRam < 2048)
			{
				this.mCPURAMCombinationDict[PerformanceSetting.High][PerformanceProperty.RAM] = this.mMaxRam;
				this.mCPURAMCombinationDict[PerformanceSetting.Medium][PerformanceProperty.RAM] = this.mMaxRam;
				return;
			}
			if (this.mMaxRam < 1024)
			{
				this.mCPURAMCombinationDict[PerformanceSetting.High][PerformanceProperty.RAM] = this.mMaxRam;
				this.mCPURAMCombinationDict[PerformanceSetting.Medium][PerformanceProperty.RAM] = this.mMaxRam;
				this.mCPURAMCombinationDict[PerformanceSetting.Low][PerformanceProperty.RAM] = this.mMaxRam;
			}
		}

		// Token: 0x0600084D RID: 2125 RVA: 0x00022194 File Offset: 0x00020394
		private PerformanceSetting GetCurrentAssignedPerformanceSetting()
		{
			PerformanceSetting result = PerformanceSetting.Custom;
			if (this.mUserRAM == this.mCPURAMCombinationDict[PerformanceSetting.High][PerformanceProperty.RAM] && this.mUserCPU == this.mCPURAMCombinationDict[PerformanceSetting.High][PerformanceProperty.CPUCores])
			{
				result = PerformanceSetting.High;
			}
			else if (this.mUserRAM == this.mCPURAMCombinationDict[PerformanceSetting.Medium][PerformanceProperty.RAM] && this.mUserCPU == this.mCPURAMCombinationDict[PerformanceSetting.Medium][PerformanceProperty.CPUCores])
			{
				result = PerformanceSetting.Medium;
			}
			else if (this.mUserRAM == this.mCPURAMCombinationDict[PerformanceSetting.Low][PerformanceProperty.RAM] && this.mUserCPU == this.mCPURAMCombinationDict[PerformanceSetting.Low][PerformanceProperty.CPUCores])
			{
				result = PerformanceSetting.Low;
			}
			return result;
		}

		// Token: 0x0600084E RID: 2126 RVA: 0x0000936A File Offset: 0x0000756A
		private void InitRAMProperties()
		{
			BlueStacksUIBinding.Bind(this.mMemoryTitle, "STRING_MEMORY", "{0} (MB)");
			this.PopulateRAMRangeText();
		}

		// Token: 0x0600084F RID: 2127 RVA: 0x0002224C File Offset: 0x0002044C
		private void PopulateRAMRangeText()
		{
			try
			{
				int num;
				int.TryParse(EngineSettingsBase.RAM, out num);
				this.mMaxRam = (int)((double)num * 0.5);
				if (this.mMaxRam <= this.mMinRam)
				{
					this.mCustomRAMSlider.IsEnabled = false;
				}
				else
				{
					if (this.mMaxRam >= 4096)
					{
						this.mMaxRam = 4096;
					}
					if (EngineSettingsBase.mVmName.Equals(Strings.CurrentDefaultVmName))
					{
						if (num < 3072)
						{
							BlueStacksUIBinding.Bind(this.mReccomendedMemoryTextBlock, "STRING_REC_MEM", "{0} 600MB");
						}
						else
						{
							BlueStacksUIBinding.Bind(this.mReccomendedMemoryTextBlock, "STRING_REC_MEM", "{0} 1800 MB");
							if (SystemUtils.IsOs64Bit())
							{
								if (num <= 4 * this.oneGB)
								{
									BlueStacksUIBinding.Bind(this.mReccomendedMemoryTextBlock, "STRING_REC_MEM", "{0} 900 MB");
								}
								else if (num <= 5 * this.oneGB)
								{
									BlueStacksUIBinding.Bind(this.mReccomendedMemoryTextBlock, "STRING_REC_MEM", "{0} 1200 MB");
								}
								else if (num <= 6 * this.oneGB)
								{
									BlueStacksUIBinding.Bind(this.mReccomendedMemoryTextBlock, "STRING_REC_MEM", "{0} 1500 MB");
								}
								else if (num < 8 * this.oneGB)
								{
									BlueStacksUIBinding.Bind(this.mReccomendedMemoryTextBlock, "STRING_REC_MEM", "{0} 1800 MB");
								}
								else if (RegistryManager.Instance.CurrentEngine == "raw")
								{
									BlueStacksUIBinding.Bind(this.mReccomendedMemoryTextBlock, "STRING_REC_MEM", "{0} 3072 MB");
								}
								else
								{
									BlueStacksUIBinding.Bind(this.mReccomendedMemoryTextBlock, "STRING_REC_MEM", "{0} 4096 MB");
								}
							}
							else
							{
								BlueStacksUIBinding.Bind(this.mReccomendedMemoryTextBlock, "STRING_REC_MEM", "{0} 900 MB");
							}
						}
					}
					else if (SystemUtils.IsOs64Bit())
					{
						if (num < 4 * this.oneGB)
						{
							BlueStacksUIBinding.Bind(this.mReccomendedMemoryTextBlock, "STRING_REC_MEM", "{0} 800 MB");
						}
						else
						{
							BlueStacksUIBinding.Bind(this.mReccomendedMemoryTextBlock, "STRING_REC_MEM", "{0} 1100 MB");
						}
					}
					else
					{
						BlueStacksUIBinding.Bind(this.mReccomendedMemoryTextBlock, "STRING_REC_MEM", "{0} 600 MB");
					}
					if (RegistryManager.Instance.CurrentEngine == "raw" && this.mMaxRam >= 3072)
					{
						this.mMaxRam = 3072;
					}
					this.mCustomRAMSlider.Minimum = (double)this.mMinRam;
					this.mCustomRAMSlider.Maximum = (double)this.mMaxRam;
					this.mMinMemoryText.Text = this.mMinRam.ToString();
					this.mMaxMemoryText.Text = this.mMaxRam.ToString();
					this.mCustomRAMSlider.Value = (double)this.mUserRAM;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to set RAM range, {0}", new object[]
				{
					ex.Message
				});
			}
		}

		// Token: 0x06000850 RID: 2128 RVA: 0x00009387 File Offset: 0x00007587
		private void BuildCPUProperties()
		{
			if (RegistryManager.Instance.CurrentEngine != "raw")
			{
				this.mUserSupportedVCPUs = ((this.mUserCPUCores > 8) ? 8 : this.mUserCPUCores);
			}
			this.BuildCPUCoresList();
		}

		// Token: 0x06000851 RID: 2129 RVA: 0x00022518 File Offset: 0x00020718
		private void BuildCPUCoresList()
		{
			this.mCpuCoresComboBox.Items.Clear();
			for (int i = this.mMinCPUCores; i <= this.mUserSupportedVCPUs; i++)
			{
				ComboBoxItem comboBoxItem = new ComboBoxItem();
				comboBoxItem.Content = i.ToString();
				this.mCpuCoresComboBox.Items.Add(comboBoxItem);
			}
			this.mCpuCoresComboBox.SelectedIndex = this.mUserCPU - 1;
		}

		// Token: 0x06000852 RID: 2130 RVA: 0x00022584 File Offset: 0x00020784
		private void Graphics_Checked(object sender, RoutedEventArgs e)
		{
			if (this.mIsCompatibilityCheckRunning || this.previousGraphics == null)
			{
				e.Handled = true;
				return;
			}
			this.InitGraphicsCompatibilityPopUpGrid();
			this.currentGraphics = (sender as CustomRadioButton);
			string graphicsMode = (this.currentGraphics == this.mDirectXRadio) ? "DirectX" : "OpenGL";
			this.InitGraphicsLabelForContent(graphicsMode);
			if (this.currentGraphics != this.previousGraphics)
			{
				this.mSelectedGLRenderMode = ((this.currentGraphics == this.mDirectXRadio) ? 4 : 1);
				this.mMainGrid.RowDefinitions[0].Height = new GridLength(30.0, GridUnitType.Pixel);
				if (this.mDictForGraphicsCompatibility == null)
				{
					this.InitUiOnGlCheck(true);
					this.mDictForGraphicsCompatibility = new Dictionary<int, bool>();
					BackgroundWorker backgroundWorker = new BackgroundWorker();
					backgroundWorker.DoWork += this.BcwWorker_DoWork;
					backgroundWorker.RunWorkerCompleted += this.BcwWorker_RunWorkerCompleted;
					backgroundWorker.RunWorkerAsync();
				}
				else
				{
					this.HandleChangesForGlrenderModeValueChange();
				}
			}
			else if (this.mDictForGraphicsCompatibility != null && this.mCurrentGraphicsBitPattern != this.GenerateGraphicsBitPattern(this.mSelectedGLMode, this.mSelectedGLRenderMode))
			{
				this.mMainGrid.RowDefinitions[0].Height = new GridLength(30.0, GridUnitType.Pixel);
				this.mRestartAfterSelectedGraphicsModeGrid.Visibility = Visibility.Visible;
				this.UpdateRestartBtnVisibility(Visibility.Visible);
			}
			e.Handled = true;
		}

		// Token: 0x06000853 RID: 2131 RVA: 0x000226E0 File Offset: 0x000208E0
		private void HandleChangesForGlrenderModeValueChange()
		{
			int num = this.GenerateGraphicsBitPattern(this.mSelectedGLMode, this.mSelectedGLRenderMode);
			if (!this.mDictForGraphicsCompatibility[num])
			{
				this.mSelectedGraphicsModeNotSupportedGrid.Visibility = Visibility.Visible;
				return;
			}
			this.currentGraphics.IsChecked = new bool?(true);
			this.previousGraphics = this.currentGraphics;
			RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].GlRenderMode = this.mSelectedGLRenderMode;
			if (this.mCurrentGraphicsBitPattern != num)
			{
				this.mRestartAfterSelectedGraphicsModeGrid.Visibility = Visibility.Visible;
				this.UpdateRestartBtnVisibility(Visibility.Visible);
				return;
			}
			if (this.mCurrentRAMSliderValue == this.mUserRAM && this.mUserCPU == this.mSelectedVCPUCores)
			{
				this.mMainGrid.RowDefinitions[0].Height = new GridLength(0.0, GridUnitType.Pixel);
				this.UpdateRestartBtnVisibility(Visibility.Hidden);
				return;
			}
			this.mMainGrid.RowDefinitions[0].Height = new GridLength(0.0, GridUnitType.Pixel);
		}

		// Token: 0x06000854 RID: 2132 RVA: 0x000093BD File Offset: 0x000075BD
		private void BcwWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			this.mIsCompatibilityCheckRunning = false;
			this.HandleChangesForGlrenderModeValueChange();
		}

		// Token: 0x06000855 RID: 2133 RVA: 0x000093CC File Offset: 0x000075CC
		private void InitUiOnGlCheck(bool visible)
		{
			if (visible)
			{
				this.mCheckingForSupportedGraphicsGrid.Visibility = Visibility.Visible;
				return;
			}
			this.mCheckingForSupportedGraphicsGrid.Visibility = Visibility.Hidden;
		}

		// Token: 0x06000856 RID: 2134 RVA: 0x000093EA File Offset: 0x000075EA
		private void BcwWorker_DoWork(object sender, DoWorkEventArgs e)
		{
			this.mIsCompatibilityCheckRunning = true;
			this.CreateGraphicsCompatibilityDictionary();
		}

		// Token: 0x06000857 RID: 2135 RVA: 0x000227E4 File Offset: 0x000209E4
		private void CreateGraphicsCompatibilityDictionary()
		{
			string text = "";
			for (int i = 0; i < 4; i++)
			{
				if ((i & 1) == 0)
				{
					text += "4";
				}
				else
				{
					text += "1";
				}
				if ((i & 2) == 2)
				{
					text += " 2";
				}
				if (RunCommand.RunCmd(Path.Combine(RegistryStrings.InstallDir, "HD-GlCheck"), text, true, true, false, 0).ExitCode == 0)
				{
					this.mDictForGraphicsCompatibility.Add(i, true);
				}
				else
				{
					this.mDictForGraphicsCompatibility.Add(i, false);
				}
				text = "";
			}
		}

		// Token: 0x06000858 RID: 2136 RVA: 0x00022878 File Offset: 0x00020A78
		private int GenerateGraphicsBitPattern(int glMode, int glRenderMode)
		{
			int num = 0;
			if (glMode == 0)
			{
				num |= 0;
			}
			else if (glMode == 2)
			{
				num |= 2;
			}
			if (glRenderMode == 1)
			{
				num |= 1;
			}
			else if (glRenderMode == 4)
			{
				num |= 0;
			}
			return num;
		}

		// Token: 0x06000859 RID: 2137 RVA: 0x000228AC File Offset: 0x00020AAC
		private void InitGraphicsLabelForContent(string graphicsMode)
		{
			this.mRestartBluestacksBootLbl.Content = string.Format(LocaleStrings.GetLocalizedString("STRING_RESTART_BLUESTACKS_AFTER_GRAPHICS_CHANGE", false), graphicsMode);
			this.mCheckingCompatibilityLbl.Content = string.Format(LocaleStrings.GetLocalizedString("STRING_CHECKING_GRAPHICS_COMPATIBILITY", false), graphicsMode);
			this.mGraphicsNotSupportedLbl.Content = string.Format(LocaleStrings.GetLocalizedString("STRING_GRAPHICS_NOT_SUPPORTED_ON_MACHINE", false), graphicsMode);
		}

		// Token: 0x0600085A RID: 2138 RVA: 0x00022910 File Offset: 0x00020B10
		private void InitGraphicsCompatibilityPopUpGrid()
		{
			this.mMainGrid.RowDefinitions[0].Height = new GridLength(0.0, GridUnitType.Pixel);
			if (this.mCheckingForSupportedGraphicsGrid.Visibility == Visibility.Visible)
			{
				this.mCheckingForSupportedGraphicsGrid.Visibility = Visibility.Hidden;
			}
			if (this.mSelectedGraphicsModeNotSupportedGrid.Visibility == Visibility.Visible)
			{
				this.mSelectedGraphicsModeNotSupportedGrid.Visibility = Visibility.Hidden;
			}
			if (this.mRestartAfterSelectedGraphicsModeGrid.Visibility == Visibility.Visible)
			{
				this.mRestartAfterSelectedGraphicsModeGrid.Visibility = Visibility.Hidden;
			}
		}

		// Token: 0x0600085B RID: 2139 RVA: 0x00022990 File Offset: 0x00020B90
		private void AdvanceGraphicsSettings_Click(object sender, RoutedEventArgs e)
		{
			if (this.mIsCompatibilityCheckRunning)
			{
				this.mAdvanceGraphicsSettings.IsChecked = !this.mAdvanceGraphicsSettings.IsChecked;
				e.Handled = true;
				return;
			}
			this.InitGraphicsCompatibilityPopUpGrid();
			bool? isChecked = this.mAdvanceGraphicsSettings.IsChecked;
			bool flag = true;
			string graphicsMode;
			if (isChecked.GetValueOrDefault() == flag & isChecked != null)
			{
				graphicsMode = "Advanced Graphics";
				this.mSelectedGLMode = 2;
			}
			else
			{
				graphicsMode = "Legacy";
				this.mSelectedGLMode = 0;
			}
			this.InitGraphicsLabelForContent(graphicsMode);
			int num = this.GenerateGraphicsBitPattern(this.mSelectedGLMode, this.mSelectedGLRenderMode);
			if (this.mCurrentGraphicsBitPattern == num)
			{
				this.mMainGrid.RowDefinitions[0].Height = new GridLength(0.0, GridUnitType.Pixel);
				if (this.mCurrentRAMSliderValue == this.mUserRAM && this.mUserCPU == this.mSelectedVCPUCores)
				{
					this.UpdateRestartBtnVisibility(Visibility.Hidden);
				}
				return;
			}
			this.mMainGrid.RowDefinitions[0].Height = new GridLength(30.0, GridUnitType.Pixel);
			if (this.mDictForGraphicsCompatibility == null)
			{
				this.InitUiOnGlCheck(true);
				this.mDictForGraphicsCompatibility = new Dictionary<int, bool>();
				BackgroundWorker backgroundWorker = new BackgroundWorker();
				backgroundWorker.DoWork += this.BcwForGlMode_DoWork;
				backgroundWorker.RunWorkerCompleted += this.BcwForGlMode_RunWorkerCompleted;
				backgroundWorker.RunWorkerAsync();
				return;
			}
			this.ChangesForGlMode();
		}

		// Token: 0x0600085C RID: 2140 RVA: 0x00022B10 File Offset: 0x00020D10
		private void ChangesForGlMode()
		{
			bool? isChecked = this.mAdvanceGraphicsSettings.IsChecked;
			bool flag = true;
			if (isChecked.GetValueOrDefault() == flag & isChecked != null)
			{
				int num = this.GenerateGraphicsBitPattern(this.mSelectedGLMode, this.mSelectedGLRenderMode);
				if (!this.mDictForGraphicsCompatibility[num])
				{
					this.mSelectedGLMode = 0;
					this.mSelectedGraphicsModeNotSupportedGrid.Visibility = Visibility.Visible;
					this.mCheckingForSupportedGraphicsGrid.Visibility = Visibility.Hidden;
					this.mAdvanceGraphicsSettings.IsChecked = new bool?(false);
					return;
				}
				if (this.mCurrentGraphicsBitPattern != num)
				{
					Logger.Info("Setting GlMode to 2");
					Utils.UpdateValueInBootParams("GlMode", "2", EngineSettingsBase.mVmName, true);
					RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].GlMode = 2;
					this.mRestartAfterSelectedGraphicsModeGrid.Visibility = Visibility.Visible;
					this.UpdateRestartBtnVisibility(Visibility.Visible);
					return;
				}
			}
			else
			{
				int num2 = this.GenerateGraphicsBitPattern(this.mSelectedGLMode, this.mSelectedGLRenderMode);
				if (this.mDictForGraphicsCompatibility[num2])
				{
					if (this.mCurrentGraphicsBitPattern != num2)
					{
						Logger.Info("Setting GlMode to 1");
						Utils.UpdateValueInBootParams("GlMode", "1", EngineSettingsBase.mVmName, true);
						RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].GlMode = 1;
						this.mRestartAfterSelectedGraphicsModeGrid.Visibility = Visibility.Visible;
						this.UpdateRestartBtnVisibility(Visibility.Visible);
						return;
					}
				}
				else
				{
					this.mCheckingForSupportedGraphicsGrid.Visibility = Visibility.Hidden;
					this.mSelectedGraphicsModeNotSupportedGrid.Visibility = Visibility.Visible;
					this.mSelectedGLMode = 2;
					this.mAdvanceGraphicsSettings.IsChecked = new bool?(true);
				}
			}
		}

		// Token: 0x0600085D RID: 2141 RVA: 0x000093EA File Offset: 0x000075EA
		private void BcwForGlMode_DoWork(object sender, DoWorkEventArgs e)
		{
			this.mIsCompatibilityCheckRunning = true;
			this.CreateGraphicsCompatibilityDictionary();
		}

		// Token: 0x0600085E RID: 2142 RVA: 0x000093F9 File Offset: 0x000075F9
		private void BcwForGlMode_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			this.mIsCompatibilityCheckRunning = false;
			this.ChangesForGlMode();
		}

		// Token: 0x0600085F RID: 2143 RVA: 0x00022C94 File Offset: 0x00020E94
		private void CPUCoresChanged(object sender, SelectionChangedEventArgs e)
		{
			ComboBox comboBox = sender as ComboBox;
			int.TryParse((string)((ComboBoxItem)comboBox.SelectedItem).Content, out this.mSelectedVCPUCores);
			if (!comboBox.IsDropDownOpen)
			{
				return;
			}
			if (RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].VCPUs != this.mSelectedVCPUCores)
			{
				RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].VCPUs = this.mSelectedVCPUCores;
				this.UpdateRestartBtnVisibility(Visibility.Visible);
			}
			else if (this.mCurrentRAMSliderValue == this.mUserRAM && this.mCurrentGLRenderMode == this.mSelectedGLRenderMode)
			{
				this.UpdateRestartBtnVisibility(Visibility.Hidden);
			}
			e.Handled = true;
		}

		// Token: 0x06000860 RID: 2144 RVA: 0x00022D44 File Offset: 0x00020F44
		private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			Slider slider = sender as Slider;
			this.mCurrentRAMSliderValue = (int)slider.Value;
			this.mCurrentRAMSliderTextBlock.Text = string.Format("{0} MB", slider.Value);
			e.Handled = true;
		}

		// Token: 0x06000861 RID: 2145 RVA: 0x00022D8C File Offset: 0x00020F8C
		private void mCustomRAMSlider_DragCompleted(object sender, DragCompletedEventArgs e)
		{
			if (this.mCurrentRAMSliderValue != this.mUserRAM)
			{
				RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].Memory = this.mCurrentRAMSliderValue;
				this.UpdateRestartBtnVisibility(Visibility.Visible);
			}
			else if (this.mUserCPU != this.mUserSelectedCPU && this.mCurrentGLRenderMode == this.mSelectedGLRenderMode)
			{
				this.UpdateRestartBtnVisibility(Visibility.Hidden);
			}
			e.Handled = true;
		}

		// Token: 0x06000862 RID: 2146 RVA: 0x00022D8C File Offset: 0x00020F8C
		private void mCustomRAMSlider_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mCurrentRAMSliderValue != this.mUserRAM)
			{
				RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].Memory = this.mCurrentRAMSliderValue;
				this.UpdateRestartBtnVisibility(Visibility.Visible);
			}
			else if (this.mUserCPU != this.mUserSelectedCPU && this.mCurrentGLRenderMode == this.mSelectedGLRenderMode)
			{
				this.UpdateRestartBtnVisibility(Visibility.Hidden);
			}
			e.Handled = true;
		}

		// Token: 0x06000863 RID: 2147 RVA: 0x00022DFC File Offset: 0x00020FFC
		private void mHyperLink_RequestNavigate(object sender, RequestNavigateEventArgs e)
		{
			try
			{
				Logger.Info("Opening url: " + e.Uri.AbsoluteUri);
				Utils.OpenUrl(e.Uri.AbsoluteUri);
				e.Handled = true;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in opening url" + ex.ToString());
			}
		}

		// Token: 0x06000864 RID: 2148 RVA: 0x00009408 File Offset: 0x00007608
		private void UpdateRestartBtnVisibility(Visibility vis)
		{
			if (!base.GetType().Namespace.Equals("BlueStacks.MultiInstanceManager", StringComparison.InvariantCultureIgnoreCase))
			{
				this.mRestartNowBtn.Visibility = vis;
			}
		}

		// Token: 0x06000865 RID: 2149 RVA: 0x00022E64 File Offset: 0x00021064
		private void mCustomFPSSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			if (!RegistryManager.Instance.CurrentFarmModeStatus || !Utils.GetRunningInstancesList().Contains(EngineSettingsBase.mVmName))
			{
				int num = (int)(sender as Slider).Value;
				this.mCurrentFPSSliderTextBlock.Text = string.Format("{0}", num);
				e.Handled = true;
			}
		}

		// Token: 0x06000866 RID: 2150 RVA: 0x0000942E File Offset: 0x0000762E
		private void CustomFPSSlider_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (!RegistryManager.Instance.CurrentFarmModeStatus || !Utils.GetRunningInstancesList().Contains(EngineSettingsBase.mVmName))
			{
				EngineSettingsBase.ChangeFps(sender);
			}
		}

		// Token: 0x06000867 RID: 2151 RVA: 0x0000942E File Offset: 0x0000762E
		private void CustomFPSSlider_DragCompleted(object sender, DragCompletedEventArgs e)
		{
			if (!RegistryManager.Instance.CurrentFarmModeStatus || !Utils.GetRunningInstancesList().Contains(EngineSettingsBase.mVmName))
			{
				EngineSettingsBase.ChangeFps(sender);
			}
		}

		// Token: 0x06000868 RID: 2152 RVA: 0x00022EC0 File Offset: 0x000210C0
		private static void ChangeFps(object sender)
		{
			Slider slider = sender as Slider;
			RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].FPS = (int)slider.Value;
			Utils.UpdateValueInBootParams("fps", RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].FPS.ToString(), EngineSettingsBase.mVmName, true);
		}

		// Token: 0x06000869 RID: 2153 RVA: 0x00022F28 File Offset: 0x00021128
		private void UseDedicatedGPU_Click(object sender, RoutedEventArgs e)
		{
			bool value = this.mUseDedicatedGPU.IsChecked.Value;
			this.InitGraphicsCompatibilityPopUpGrid();
			this.InitGraphicsLabelForContent("Dedicated GPU Check");
			this.InitUiOnGlCheck(true);
			this.mMainGrid.RowDefinitions[0].Height = new GridLength(30.0, GridUnitType.Pixel);
			this.InitUiOnGlCheck(true);
			BackgroundWorker backgroundWorker = new BackgroundWorker();
			backgroundWorker.DoWork += this.AddDedicatedGPUProfile_DoWork;
			backgroundWorker.RunWorkerCompleted += this.AddDedicatedGPUProfile_RunWorkerCompleted;
			backgroundWorker.RunWorkerAsync(value);
		}

		// Token: 0x0600086A RID: 2154 RVA: 0x00022FC4 File Offset: 0x000211C4
		private void AddDedicatedGPUProfile_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			this.mIsCompatibilityCheckRunning = false;
			bool value = this.mUseDedicatedGPU.IsChecked.Value;
			bool flag = (bool)e.Result;
			if ((flag && value) || (!flag && !value))
			{
				this.mUseDedicatedGPU.IsChecked = new bool?(true);
				RegistryManager.Instance.ForceDedicatedGPU = true;
			}
			else
			{
				RegistryManager.Instance.ForceDedicatedGPU = false;
				this.mUseDedicatedGPU.IsChecked = new bool?(false);
			}
			value = this.mUseDedicatedGPU.IsChecked.Value;
			if (value != this.mUseDedicatedGraphicsInitValue)
			{
				this.UpdateRestartBtnVisibility(Visibility.Visible);
			}
			else if (this.mUserCPU != this.mUserSelectedCPU || this.mCurrentGLRenderMode != this.mSelectedGLRenderMode || this.mCurrentRAMSliderValue != this.mUserRAM)
			{
				this.UpdateRestartBtnVisibility(Visibility.Visible);
			}
			else
			{
				this.UpdateRestartBtnVisibility(Visibility.Hidden);
			}
			this.mMainGrid.RowDefinitions[0].Height = new GridLength(0.0, GridUnitType.Pixel);
		}

		// Token: 0x0600086B RID: 2155 RVA: 0x000230C4 File Offset: 0x000212C4
		private void AddDedicatedGPUProfile_DoWork(object sender, DoWorkEventArgs e)
		{
			this.mIsCompatibilityCheckRunning = true;
			bool flag = ForceDedicatedGPU.ToggleDedicatedGPU((bool)e.Argument, null);
			e.Result = flag;
		}

		// Token: 0x0600086C RID: 2156 RVA: 0x000230F8 File Offset: 0x000212F8
		private void DisplayFPS_Click(object sender, RoutedEventArgs e)
		{
			InstanceRegistry instanceRegistry = RegistryManager.Instance.Guest[EngineSettingsBase.mVmName];
			bool? isChecked = this.mDisplayFPS.IsChecked;
			bool flag = true;
			instanceRegistry.ShowFPS = ((isChecked.GetValueOrDefault() == flag & isChecked != null) ? 1 : 0);
			Utils.SendShowFPSToInstanceASync(EngineSettingsBase.mVmName, RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].ShowFPS);
			string tag = "DisplayFPSCheckboxClicked";
			string userGuid = RegistryManager.Instance.UserGuid;
			string clientVersion = RegistryManager.Instance.ClientVersion;
			string arg = "enginesettings";
			isChecked = this.mDisplayFPS.IsChecked;
			flag = true;
			Stats.SendMiscellaneousStatsAsync(tag, userGuid, clientVersion, arg, (isChecked.GetValueOrDefault() == flag & isChecked != null) ? "checked" : "unchecked", null, null, null, null, EngineSettingsBase.mVmName, 0);
		}

		// Token: 0x0600086D RID: 2157 RVA: 0x000231CC File Offset: 0x000213CC
		private void EnableHighFPS_Click(object sender, RoutedEventArgs e)
		{
			InstanceRegistry instanceRegistry = RegistryManager.Instance.Guest[EngineSettingsBase.mVmName];
			bool? isChecked = this.mEnableHighFPS.IsChecked;
			bool flag = true;
			instanceRegistry.EnableHighFPS = ((isChecked.GetValueOrDefault() == flag & isChecked != null) ? 1 : 0);
			isChecked = this.mEnableHighFPS.IsChecked;
			flag = true;
			if (isChecked.GetValueOrDefault() == flag & isChecked != null)
			{
				this.mCustomFPSSlider.Maximum = 365.0;
				this.mMaximumFrameRateText.Text = "365";
				return;
			}
			if ((int)this.mCustomFPSSlider.Value > 60)
			{
				this.mCustomFPSSlider.Value = 165.0;
				EngineSettingsBase.ChangeFps(this.mCustomFPSSlider);
			}
			this.mCustomFPSSlider.Maximum = 165.0;
			this.mMaximumFrameRateText.Text = "165";
		}

		// Token: 0x0600086E RID: 2158 RVA: 0x000232B4 File Offset: 0x000214B4
		private void MCPURAMComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			PerformanceSetting performanceSetting = (PerformanceSetting)((ComboBoxItem)(sender as ComboBox).SelectedItem).Tag;
			if (performanceSetting == PerformanceSetting.Custom)
			{
				this.ToggleCPURAMGridVisibility(true);
			}
			else
			{
				this.ToggleCPURAMGridVisibility(false);
				this.SetCPURAMPropertiesForPerformanceSetting(performanceSetting);
			}
			if (this.mUserCPU != this.mUserSelectedCPU || this.mCurrentGLRenderMode != this.mSelectedGLRenderMode || this.mCurrentRAMSliderValue != this.mUserRAM || EngineSettingsBase.mInitialPerformanceSetting != performanceSetting)
			{
				this.UpdateRestartBtnVisibility(Visibility.Visible);
				return;
			}
			this.UpdateRestartBtnVisibility(Visibility.Hidden);
		}

		// Token: 0x0600086F RID: 2159 RVA: 0x00023338 File Offset: 0x00021538
		private void SetCPURAMPropertiesForPerformanceSetting(PerformanceSetting setting)
		{
			if (setting != PerformanceSetting.Custom)
			{
				int memory = this.mCPURAMCombinationDict[setting][PerformanceProperty.RAM];
				int vcpus = this.mCPURAMCombinationDict[setting][PerformanceProperty.CPUCores];
				RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].Memory = memory;
				RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].VCPUs = vcpus;
			}
		}

		// Token: 0x06000870 RID: 2160 RVA: 0x00009453 File Offset: 0x00007653
		private void ToggleCPURAMGridVisibility(bool visible)
		{
			if (visible)
			{
				this.mCPUCoreSelectionGrid.Visibility = Visibility.Visible;
				this.mRAMGrid.Visibility = Visibility.Visible;
				return;
			}
			this.mCPUCoreSelectionGrid.Visibility = Visibility.Collapsed;
			this.mRAMGrid.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000871 RID: 2161 RVA: 0x000233A4 File Offset: 0x000215A4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/enginesettingsbase.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000872 RID: 2162 RVA: 0x00003339 File Offset: 0x00001539
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000873 RID: 2163 RVA: 0x000233D4 File Offset: 0x000215D4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMainGrid = (Grid)target;
				return;
			case 2:
				this.mGraphicsPopupGrid = (Grid)target;
				return;
			case 3:
				this.mSelectedGraphicsModeNotSupportedGrid = (Grid)target;
				return;
			case 4:
				this.mGraphicsNotSupportedLbl = (Label)target;
				return;
			case 5:
				this.mLearnMore = (TextBlock)target;
				return;
			case 6:
				this.mCheckingForSupportedGraphicsGrid = (Grid)target;
				return;
			case 7:
				this.mLoaderIcon = (CustomPictureBox)target;
				return;
			case 8:
				this.mCheckingCompatibilityLbl = (Label)target;
				return;
			case 9:
				this.mRestartAfterSelectedGraphicsModeGrid = (Grid)target;
				return;
			case 10:
				this.mRestartBluestacksBootLbl = (Label)target;
				return;
			case 11:
				this.mScrollBar = (ScrollViewer)target;
				return;
			case 12:
				this.mDirectXRadio = (CustomRadioButton)target;
				return;
			case 13:
				this.mOpenGLRadio = (CustomRadioButton)target;
				return;
			case 14:
				this.mAdvanceGraphicsSettings = (CustomCheckbox)target;
				return;
			case 15:
				this.mUseDedicatedGPU = (CustomCheckbox)target;
				return;
			case 16:
				this.mCPURAMSelectionGrid = (Grid)target;
				return;
			case 17:
				this.mCPURAMComboBox = (CustomComboBox)target;
				return;
			case 18:
				this.mCPUCoreSelectionGrid = (Grid)target;
				return;
			case 19:
				this.mCpuCoresComboBox = (CustomComboBox)target;
				return;
			case 20:
				this.mRAMGrid = (Grid)target;
				return;
			case 21:
				this.mMemoryTitle = (TextBlock)target;
				return;
			case 22:
				this.mCurrentRAMSliderTextBlock = (TextBlock)target;
				return;
			case 23:
				this.mReccomendedMemoryTextBlock = (TextBlock)target;
				return;
			case 24:
				this.mCustomRAMSlider = (Slider)target;
				this.mCustomRAMSlider.ValueChanged += this.Slider_ValueChanged;
				this.mCustomRAMSlider.AddHandler(Thumb.DragCompletedEvent, new DragCompletedEventHandler(this.mCustomRAMSlider_DragCompleted));
				this.mCustomRAMSlider.MouseLeftButtonUp += this.mCustomRAMSlider_MouseLeftButtonUp;
				return;
			case 25:
				this.mMinMemoryText = (TextBlock)target;
				return;
			case 26:
				this.mMaxMemoryText = (TextBlock)target;
				return;
			case 27:
				this.mCurrentFPSSliderTextBlock = (TextBlock)target;
				return;
			case 28:
				this.mCustomFPSSlider = (Slider)target;
				this.mCustomFPSSlider.ValueChanged += this.mCustomFPSSlider_ValueChanged;
				this.mCustomFPSSlider.AddHandler(Thumb.DragCompletedEvent, new DragCompletedEventHandler(this.CustomFPSSlider_DragCompleted));
				this.mCustomFPSSlider.MouseLeftButtonUp += this.CustomFPSSlider_MouseLeftButtonUp;
				return;
			case 29:
				this.mMaximumFrameRateText = (TextBlock)target;
				return;
			case 30:
				this.mEnableHighFPSGrid = (Grid)target;
				return;
			case 31:
				this.mEnableHighFPS = (CustomCheckbox)target;
				return;
			case 32:
				this.mDisplayFPSGrid = (Grid)target;
				return;
			case 33:
				this.mDisplayFPS = (CustomCheckbox)target;
				return;
			case 34:
				this.mDirectXWarningGrid = (Border)target;
				return;
			case 35:
				this.mWarningImage = (CustomPictureBox)target;
				return;
			case 36:
				this.mWarningTitleText = (TextBlock)target;
				return;
			case 37:
				this.mWarningText = (TextBlock)target;
				return;
			case 38:
				this.mHyperLink = (Hyperlink)target;
				this.mHyperLink.RequestNavigate += this.mHyperLink_RequestNavigate;
				return;
			case 39:
				this.mInfoIcon = (CustomPictureBox)target;
				return;
			case 40:
				this.mRestartNowBtn = (CustomButton)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400060C RID: 1548
		private CustomRadioButton currentGraphics;

		// Token: 0x0400060D RID: 1549
		private CustomRadioButton previousGraphics;

		// Token: 0x0400060E RID: 1550
		private int mMinRam = 600;

		// Token: 0x0400060F RID: 1551
		private int mMaxRam = 4096;

		// Token: 0x04000610 RID: 1552
		private int mMinCPUCores = 1;

		// Token: 0x04000611 RID: 1553
		private int mUserCPUCores = Environment.ProcessorCount;

		// Token: 0x04000612 RID: 1554
		private int mUserSupportedVCPUs = 1;

		// Token: 0x04000613 RID: 1555
		private int mCurrentRAMSliderValue = 1100;

		// Token: 0x04000614 RID: 1556
		private int mUserSelectedCPU = RegistryManager.Instance.Guest[EngineSettingsBase.mVmName].VCPUs;

		// Token: 0x04000615 RID: 1557
		private int mSelectedVCPUCores;

		// Token: 0x04000616 RID: 1558
		private int mSelectedGLRenderMode;

		// Token: 0x04000617 RID: 1559
		private int mCurrentGLRenderMode = 1;

		// Token: 0x04000618 RID: 1560
		private int mCurrentGLmode = 1;

		// Token: 0x04000619 RID: 1561
		private int mSelectedGLMode;

		// Token: 0x0400061A RID: 1562
		private int mUserRAM = 1100;

		// Token: 0x0400061B RID: 1563
		private int mUserCPU;

		// Token: 0x0400061C RID: 1564
		private int oneGB = 1024;

		// Token: 0x0400061D RID: 1565
		private int mCurrentGraphicsBitPattern;

		// Token: 0x0400061E RID: 1566
		private Dictionary<int, bool> mDictForGraphicsCompatibility;

		// Token: 0x0400061F RID: 1567
		private bool mIsCompatibilityCheckRunning;

		// Token: 0x04000620 RID: 1568
		private int mMinFPS = 1;

		// Token: 0x04000621 RID: 1569
		private int mMaxFPS = 60;

		// Token: 0x04000622 RID: 1570
		public static int mInitialFPSSliderValue;

		// Token: 0x04000623 RID: 1571
		private bool mUseDedicatedGraphicsInitValue = RegistryManager.Instance.ForceDedicatedGPU;

		// Token: 0x04000624 RID: 1572
		public static string mVmName = "Android";

		// Token: 0x04000625 RID: 1573
		private static PerformanceSetting mInitialPerformanceSetting = PerformanceSetting.Custom;

		// Token: 0x04000626 RID: 1574
		private Dictionary<PerformanceSetting, Dictionary<PerformanceProperty, int>> mCPURAMCombinationDict;

		// Token: 0x04000627 RID: 1575
		internal Grid mMainGrid;

		// Token: 0x04000628 RID: 1576
		internal Grid mGraphicsPopupGrid;

		// Token: 0x04000629 RID: 1577
		internal Grid mSelectedGraphicsModeNotSupportedGrid;

		// Token: 0x0400062A RID: 1578
		internal Label mGraphicsNotSupportedLbl;

		// Token: 0x0400062B RID: 1579
		internal TextBlock mLearnMore;

		// Token: 0x0400062C RID: 1580
		internal Grid mCheckingForSupportedGraphicsGrid;

		// Token: 0x0400062D RID: 1581
		internal CustomPictureBox mLoaderIcon;

		// Token: 0x0400062E RID: 1582
		internal Label mCheckingCompatibilityLbl;

		// Token: 0x0400062F RID: 1583
		internal Grid mRestartAfterSelectedGraphicsModeGrid;

		// Token: 0x04000630 RID: 1584
		internal Label mRestartBluestacksBootLbl;

		// Token: 0x04000631 RID: 1585
		internal ScrollViewer mScrollBar;

		// Token: 0x04000632 RID: 1586
		internal CustomRadioButton mDirectXRadio;

		// Token: 0x04000633 RID: 1587
		internal CustomRadioButton mOpenGLRadio;

		// Token: 0x04000634 RID: 1588
		internal CustomCheckbox mAdvanceGraphicsSettings;

		// Token: 0x04000635 RID: 1589
		internal CustomCheckbox mUseDedicatedGPU;

		// Token: 0x04000636 RID: 1590
		internal Grid mCPURAMSelectionGrid;

		// Token: 0x04000637 RID: 1591
		internal CustomComboBox mCPURAMComboBox;

		// Token: 0x04000638 RID: 1592
		internal Grid mCPUCoreSelectionGrid;

		// Token: 0x04000639 RID: 1593
		internal CustomComboBox mCpuCoresComboBox;

		// Token: 0x0400063A RID: 1594
		internal Grid mRAMGrid;

		// Token: 0x0400063B RID: 1595
		internal TextBlock mMemoryTitle;

		// Token: 0x0400063C RID: 1596
		internal TextBlock mCurrentRAMSliderTextBlock;

		// Token: 0x0400063D RID: 1597
		internal TextBlock mReccomendedMemoryTextBlock;

		// Token: 0x0400063E RID: 1598
		internal Slider mCustomRAMSlider;

		// Token: 0x0400063F RID: 1599
		internal TextBlock mMinMemoryText;

		// Token: 0x04000640 RID: 1600
		internal TextBlock mMaxMemoryText;

		// Token: 0x04000641 RID: 1601
		internal TextBlock mCurrentFPSSliderTextBlock;

		// Token: 0x04000642 RID: 1602
		internal Slider mCustomFPSSlider;

		// Token: 0x04000643 RID: 1603
		internal TextBlock mMaximumFrameRateText;

		// Token: 0x04000644 RID: 1604
		internal Grid mEnableHighFPSGrid;

		// Token: 0x04000645 RID: 1605
		internal CustomCheckbox mEnableHighFPS;

		// Token: 0x04000646 RID: 1606
		internal Grid mDisplayFPSGrid;

		// Token: 0x04000647 RID: 1607
		internal CustomCheckbox mDisplayFPS;

		// Token: 0x04000648 RID: 1608
		internal Border mDirectXWarningGrid;

		// Token: 0x04000649 RID: 1609
		internal CustomPictureBox mWarningImage;

		// Token: 0x0400064A RID: 1610
		internal TextBlock mWarningTitleText;

		// Token: 0x0400064B RID: 1611
		internal TextBlock mWarningText;

		// Token: 0x0400064C RID: 1612
		internal Hyperlink mHyperLink;

		// Token: 0x0400064D RID: 1613
		internal CustomPictureBox mInfoIcon;

		// Token: 0x0400064E RID: 1614
		internal CustomButton mRestartNowBtn;

		// Token: 0x0400064F RID: 1615
		private bool _contentLoaded;
	}
}
