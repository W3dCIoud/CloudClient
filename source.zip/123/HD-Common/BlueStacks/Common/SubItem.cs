﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000D1 RID: 209
	public enum SubItem
	{
		// Token: 0x04000521 RID: 1313
		GridBackGround,
		// Token: 0x04000522 RID: 1314
		BorderBackground,
		// Token: 0x04000523 RID: 1315
		ForeGround
	}
}
