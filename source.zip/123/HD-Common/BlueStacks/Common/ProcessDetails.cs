﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

namespace BlueStacks.Common
{
	// Token: 0x02000168 RID: 360
	public class ProcessDetails
	{
		// Token: 0x06000BB9 RID: 3001
		[DllImport("kernel32", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern IntPtr CreateToolhelp32Snapshot([In] uint dwFlags, [In] uint th32ProcessID);

		// Token: 0x06000BBA RID: 3002
		[DllImport("kernel32", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern bool Process32First([In] IntPtr hSnapshot, ref ProcessDetails.PROCESSENTRY32 lppe);

		// Token: 0x06000BBB RID: 3003
		[DllImport("kernel32", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern bool Process32Next([In] IntPtr hSnapshot, ref ProcessDetails.PROCESSENTRY32 lppe);

		// Token: 0x06000BBC RID: 3004
		[DllImport("kernel32", SetLastError = true)]
		[return: MarshalAs(UnmanagedType.Bool)]
		private static extern bool CloseHandle([In] IntPtr hObject);

		// Token: 0x06000BBD RID: 3005 RVA: 0x000329A0 File Offset: 0x00030BA0
		public static int? GetParentProcessId(int pid)
		{
			Process parentProcess = ProcessDetails.GetParentProcess(pid);
			if (parentProcess == null)
			{
				return null;
			}
			return new int?(parentProcess.Id);
		}

		// Token: 0x06000BBE RID: 3006 RVA: 0x000329CC File Offset: 0x00030BCC
		public static Process GetParentProcess(int pid)
		{
			Process result = null;
			int id = Process.GetCurrentProcess().Id;
			IntPtr intPtr = IntPtr.Zero;
			try
			{
				ProcessDetails.PROCESSENTRY32 processentry = default(ProcessDetails.PROCESSENTRY32);
				processentry.dwSize = (uint)Marshal.SizeOf(typeof(ProcessDetails.PROCESSENTRY32));
				intPtr = ProcessDetails.CreateToolhelp32Snapshot(2U, 0U);
				if (!ProcessDetails.Process32First(intPtr, ref processentry))
				{
					throw new ApplicationException(string.Format("Failed with win32 error code {0}", Marshal.GetLastWin32Error()));
				}
				while ((long)pid != (long)((ulong)processentry.th32ProcessID))
				{
					if (!ProcessDetails.Process32Next(intPtr, ref processentry))
					{
						return result;
					}
				}
				result = Process.GetProcessById((int)processentry.th32ParentProcessID);
			}
			catch (Exception ex)
			{
				Logger.Error("Can't get the process.", new object[]
				{
					ex.ToString()
				});
			}
			finally
			{
				ProcessDetails.CloseHandle(intPtr);
			}
			return result;
		}

		// Token: 0x170002E4 RID: 740
		// (get) Token: 0x06000BBF RID: 3007 RVA: 0x0000AD01 File Offset: 0x00008F01
		public static string CurrentProcessParentFileName
		{
			get
			{
				return Path.GetFileName(ProcessDetails.CurrentProcessParentFullPath);
			}
		}

		// Token: 0x170002E5 RID: 741
		// (get) Token: 0x06000BC0 RID: 3008 RVA: 0x0000AD0D File Offset: 0x00008F0D
		public static string CurrentProcessParentFullPath
		{
			get
			{
				return ProcessDetails.CurrentProcessParent.MainModule.FileName;
			}
		}

		// Token: 0x170002E6 RID: 742
		// (get) Token: 0x06000BC1 RID: 3009 RVA: 0x0000AD1E File Offset: 0x00008F1E
		public static Process CurrentProcessParent
		{
			get
			{
				return ProcessDetails.GetParentProcess(Process.GetCurrentProcess().Id);
			}
		}

		// Token: 0x170002E7 RID: 743
		// (get) Token: 0x06000BC2 RID: 3010 RVA: 0x0000AD2F File Offset: 0x00008F2F
		public static int? CurrentProcessParentId
		{
			get
			{
				return ProcessDetails.GetParentProcessId(Process.GetCurrentProcess().Id);
			}
		}

		// Token: 0x170002E8 RID: 744
		// (get) Token: 0x06000BC3 RID: 3011 RVA: 0x0000AD40 File Offset: 0x00008F40
		public static int CurrentProcessId
		{
			get
			{
				return Process.GetCurrentProcess().Id;
			}
		}

		// Token: 0x06000BC4 RID: 3012 RVA: 0x00032AA0 File Offset: 0x00030CA0
		public static int? GetNthParentPid(int pid, int order)
		{
			int? parentProcessId = new int?(pid);
			while (order > 0 && parentProcessId != null)
			{
				parentProcessId = ProcessDetails.GetParentProcessId(parentProcessId.Value);
				order--;
			}
			return parentProcessId;
		}

		// Token: 0x02000169 RID: 361
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
		private struct PROCESSENTRY32
		{
			// Token: 0x04000816 RID: 2070
			private const int MAX_PATH = 260;

			// Token: 0x04000817 RID: 2071
			internal uint dwSize;

			// Token: 0x04000818 RID: 2072
			internal uint cntUsage;

			// Token: 0x04000819 RID: 2073
			internal uint th32ProcessID;

			// Token: 0x0400081A RID: 2074
			internal IntPtr th32DefaultHeapID;

			// Token: 0x0400081B RID: 2075
			internal uint th32ModuleID;

			// Token: 0x0400081C RID: 2076
			internal uint cntThreads;

			// Token: 0x0400081D RID: 2077
			internal uint th32ParentProcessID;

			// Token: 0x0400081E RID: 2078
			internal int pcPriClassBase;

			// Token: 0x0400081F RID: 2079
			internal uint dwFlags;

			// Token: 0x04000820 RID: 2080
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
			internal string szExeFile;
		}

		// Token: 0x0200016A RID: 362
		[Flags]
		private enum SnapshotFlags : uint
		{
			// Token: 0x04000822 RID: 2082
			HeapList = 1U,
			// Token: 0x04000823 RID: 2083
			Process = 2U,
			// Token: 0x04000824 RID: 2084
			Thread = 4U,
			// Token: 0x04000825 RID: 2085
			Module = 8U,
			// Token: 0x04000826 RID: 2086
			Module32 = 16U,
			// Token: 0x04000827 RID: 2087
			Inherit = 2147483648U,
			// Token: 0x04000828 RID: 2088
			All = 31U,
			// Token: 0x04000829 RID: 2089
			NoHeaps = 1073741824U
		}
	}
}
