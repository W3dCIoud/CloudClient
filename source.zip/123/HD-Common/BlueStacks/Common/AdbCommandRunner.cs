﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x0200004F RID: 79
	public class AdbCommandRunner
	{
		// Token: 0x17000087 RID: 135
		// (get) Token: 0x060001B1 RID: 433 RVA: 0x00002CCF File Offset: 0x00000ECF
		// (set) Token: 0x060001B2 RID: 434 RVA: 0x00002CD7 File Offset: 0x00000ED7
		public bool IsHostConnected
		{
			get
			{
				return this.mIsHostConnected;
			}
			set
			{
				this.mIsHostConnected = value;
			}
		}

		// Token: 0x060001B3 RID: 435 RVA: 0x0000E300 File Offset: 0x0000C500
		public AdbCommandRunner(string vmName = "Android")
		{
			if (!string.IsNullOrEmpty(vmName))
			{
				this.mVmName = vmName;
				AdbCommandRunner.GUEST_URL = string.Format("http://127.0.0.1:{0}", RegistryManager.Instance.Guest[this.mVmName].BstAndroidPort);
			}
			this.mIsHostConnected = this.EnableADB();
		}

		// Token: 0x060001B4 RID: 436 RVA: 0x0000E368 File Offset: 0x0000C568
		private bool CheckIfGuestCommandSuccess(string res)
		{
			string text = JObject.Parse(res)["result"].ToString().Trim();
			if (string.Equals(text, "ok", StringComparison.InvariantCultureIgnoreCase))
			{
				return true;
			}
			Logger.Error("result: {0}", new object[]
			{
				text
			});
			return false;
		}

		// Token: 0x060001B5 RID: 437 RVA: 0x00002CE0 File Offset: 0x00000EE0
		public void Dispose()
		{
			this.DisableADB();
		}

		// Token: 0x060001B6 RID: 438 RVA: 0x0000E3B8 File Offset: 0x0000C5B8
		private bool EnableADB()
		{
			string api = "connectHost";
			return this.HitGuestAPI(api);
		}

		// Token: 0x060001B7 RID: 439 RVA: 0x0000E3D4 File Offset: 0x0000C5D4
		private bool DisableADB()
		{
			string api = "disconnectHost";
			return this.HitGuestAPI(api);
		}

		// Token: 0x060001B8 RID: 440 RVA: 0x0000E3F0 File Offset: 0x0000C5F0
		private bool HitGuestAPI(string api)
		{
			try
			{
				string res = HTTPUtils.SendRequestToGuest(api, null, this.mVmName, 0, null, false, 1, 0);
				return this.CheckIfGuestCommandSuccess(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Error in Sending request {0} to guest {1}", new object[]
				{
					api,
					ex.ToString()
				});
			}
			return false;
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x060001B9 RID: 441 RVA: 0x00002CE9 File Offset: 0x00000EE9
		// (set) Token: 0x060001BA RID: 442 RVA: 0x00002CF1 File Offset: 0x00000EF1
		public AdbCommandRunner.OutputLineHandlerDelegate OutputLineHandler
		{
			get
			{
				return this.mOutputLineHandler;
			}
			set
			{
				this.mOutputLineHandler = value;
			}
		}

		// Token: 0x060001BB RID: 443 RVA: 0x0000E450 File Offset: 0x0000C650
		public bool Connect(string vmName)
		{
			this.mPort = RegistryManager.Instance.Guest[vmName].BstAdbPort;
			this.mPath = Path.Combine(RegistryStrings.InstallDir, "HD-Adb.exe");
			if (!this.RunInternal(string.Format("connect 127.0.0.1:{0}", this.mPort), true))
			{
				return false;
			}
			this.RunInternal(string.Format("devices", new object[0]), true);
			return true;
		}

		// Token: 0x060001BC RID: 444 RVA: 0x0000E4C8 File Offset: 0x0000C6C8
		private bool RunInternal(string cmd, bool retry = true)
		{
			Logger.Info("ADB CMD: " + cmd);
			Process process = new Process();
			process.StartInfo.FileName = this.mPath;
			process.StartInfo.Arguments = cmd;
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.RedirectStandardOutput = true;
			process.StartInfo.RedirectStandardError = true;
			process.StartInfo.CreateNoWindow = true;
			process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs evt)
			{
				Logger.Info("ADB OUT: " + evt.Data);
			};
			process.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs evt)
			{
				if (!string.IsNullOrEmpty(evt.Data))
				{
					Logger.Info("ERR: " + evt.Data);
				}
			};
			process.Start();
			process.BeginOutputReadLine();
			process.BeginErrorReadLine();
			process.WaitForExit();
			int num = process.ExitCode;
			Logger.Info("ADB EXIT: " + num);
			if (num != 0 && retry)
			{
				Thread.Sleep(4000);
				num = (this.RunInternal(cmd, false) ? 0 : 1);
			}
			return num == 0;
		}

		// Token: 0x060001BD RID: 445 RVA: 0x00002CFA File Offset: 0x00000EFA
		public bool Push(string localPath, string remotePath)
		{
			Logger.Info("Pushing {0} to {1}", new object[]
			{
				localPath,
				remotePath
			});
			return this.RunInternal(string.Format("-s 127.0.0.1:{0} push \"{1}\" \"{2}\"", this.mPort, localPath, remotePath), true);
		}

		// Token: 0x060001BE RID: 446 RVA: 0x00002D32 File Offset: 0x00000F32
		public bool Pull(string filePath, string destPath)
		{
			Logger.Info("Pull file {0} in {1}", new object[]
			{
				filePath,
				destPath
			});
			return this.RunInternal(string.Format("-s 127.0.0.1:{0} pull \"{1}\" \"{2}\"", this.mPort, filePath, destPath), true);
		}

		// Token: 0x060001BF RID: 447 RVA: 0x00002D6A File Offset: 0x00000F6A
		public bool RunShell(string fmt, params object[] args)
		{
			return this.RunShell(string.Format(fmt, args));
		}

		// Token: 0x060001C0 RID: 448 RVA: 0x00002D79 File Offset: 0x00000F79
		public bool RunShell(string cmd)
		{
			Logger.Info("RunShell: " + cmd);
			return this.RunInternal(string.Format("-s 127.0.0.1:{0} shell {1}", this.mPort, cmd), true);
		}

		// Token: 0x060001C1 RID: 449 RVA: 0x0000E5D8 File Offset: 0x0000C7D8
		public bool RunShellScript(string[] cmdList)
		{
			foreach (string cmd in cmdList)
			{
				if (!this.RunShell(cmd))
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x060001C2 RID: 450 RVA: 0x00002DA8 File Offset: 0x00000FA8
		public bool RunShellPrivileged(string fmt, params object[] cmd)
		{
			return this.RunShellPrivileged(string.Format(fmt, cmd));
		}

		// Token: 0x060001C3 RID: 451 RVA: 0x00002DB7 File Offset: 0x00000FB7
		public bool RunShellPrivileged(string cmd)
		{
			Logger.Info("RunShellPrivileged: " + cmd);
			return this.RunInternal(string.Format("-s 127.0.0.1:{0} shell {1} -c {2}", this.mPort, "/system/xbin/bstk/su", cmd), true);
		}

		// Token: 0x060001C4 RID: 452 RVA: 0x0000E608 File Offset: 0x0000C808
		public bool RunShellScriptPrivileged(string[] cmdList)
		{
			foreach (string cmd in cmdList)
			{
				if (!this.RunShellPrivileged(cmd))
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x040000AF RID: 175
		private const string SU_PATH = "/system/xbin/bstk/su";

		// Token: 0x040000B0 RID: 176
		private static string GUEST_URL = string.Format("http://127.0.0.1:{0}", RegistryManager.Instance.Guest["Android"].BstAndroidPort);

		// Token: 0x040000B1 RID: 177
		public int mPort;

		// Token: 0x040000B2 RID: 178
		public string mPath;

		// Token: 0x040000B3 RID: 179
		private AdbCommandRunner.OutputLineHandlerDelegate mOutputLineHandler;

		// Token: 0x040000B4 RID: 180
		private string mVmName = "Android";

		// Token: 0x040000B5 RID: 181
		private bool mIsHostConnected;

		// Token: 0x02000050 RID: 80
		// (Invoke) Token: 0x060001C7 RID: 455
		public delegate void OutputLineHandlerDelegate(string line);
	}
}
