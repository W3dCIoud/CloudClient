﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000D6 RID: 214
	public enum SpecialUpgradeCases
	{
		// Token: 0x04000537 RID: 1335
		GameToBeInstalledInExistingFull,
		// Token: 0x04000538 RID: 1336
		ChangeSingleGameInstanceToFull,
		// Token: 0x04000539 RID: 1337
		UpgradeSingleGameInstanceToFull,
		// Token: 0x0400053A RID: 1338
		GameToAnotherGameSameOrLowerVersion,
		// Token: 0x0400053B RID: 1339
		GameToBeInstalledInExistingFullAfterUpgrade,
		// Token: 0x0400053C RID: 1340
		GameToAnotherGameUpgrade
	}
}
