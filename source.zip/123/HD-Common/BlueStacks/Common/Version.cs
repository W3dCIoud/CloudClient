﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001A9 RID: 425
	public class Version
	{
		// Token: 0x04000B58 RID: 2904
		public const string STRING = "4.140.12.1002";

		// Token: 0x04000B59 RID: 2905
		public const string CLIENT_VERSION_STRING = "4.140.12.1002";

		// Token: 0x04000B5A RID: 2906
		public const int IMAP_VERSION_STRING = 14;

		// Token: 0x04000B5B RID: 2907
		public const string COMPANY = "BlueStack Systems, Inc.";

		// Token: 0x04000B5C RID: 2908
		public const string PRODUCT = "BlueStacks";

		// Token: 0x04000B5D RID: 2909
		public const string COPYRIGHT = "Copyright 2011 BlueStack Systems, Inc.  All Rights Reserved.";

		// Token: 0x04000B5E RID: 2910
		public const string OEM = "bgp";
	}
}
