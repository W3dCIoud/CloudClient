﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000C6 RID: 198
	public enum ActionType
	{
		// Token: 0x040004E0 RID: 1248
		KeyDown,
		// Token: 0x040004E1 RID: 1249
		KeyUp,
		// Token: 0x040004E2 RID: 1250
		MouseDown,
		// Token: 0x040004E3 RID: 1251
		MouseUp
	}
}
