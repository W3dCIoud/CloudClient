﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001A1 RID: 417
	public class Tuple<T1, T2, T3> : Tuple<T1, T2>
	{
		// Token: 0x06000CD2 RID: 3282 RVA: 0x0000B682 File Offset: 0x00009882
		public Tuple(T1 item1, T2 item2, T3 item3) : base(item1, item2)
		{
			this.Item3 = item3;
		}

		// Token: 0x17000300 RID: 768
		// (get) Token: 0x06000CD3 RID: 3283 RVA: 0x0000B693 File Offset: 0x00009893
		// (set) Token: 0x06000CD4 RID: 3284 RVA: 0x0000B69B File Offset: 0x0000989B
		public T3 Item3 { get; set; }
	}
}
