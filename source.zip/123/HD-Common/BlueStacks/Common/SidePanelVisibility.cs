﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000DD RID: 221
	public enum SidePanelVisibility
	{
		// Token: 0x04000579 RID: 1401
		BothSearchBarAndSidepanelVisible,
		// Token: 0x0400057A RID: 1402
		OnlySearchBarVisible,
		// Token: 0x0400057B RID: 1403
		BothSearchBarAndSidepanelHidden,
		// Token: 0x0400057C RID: 1404
		OnlySidepanelVisible
	}
}
