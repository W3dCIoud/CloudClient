﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200018E RID: 398
	public static class ReturnCodesUInt
	{
		// Token: 0x04000A5D RID: 2653
		public static uint INSTALL_FAILED_DURING_BOOTING = 2147483648U;

		// Token: 0x04000A5E RID: 2654
		public static uint INSTALL_FAILED_BASE_VALUE = 3758096384U;

		// Token: 0x04000A5F RID: 2655
		public static uint INSTALL_FAILED_DURING_DOWNLOADING = 3221225472U;

		// Token: 0x04000A60 RID: 2656
		public static uint INSTALL_FAILED_INVALID_STATUS_CODE = 3221225473U;

		// Token: 0x04000A61 RID: 2657
		public static uint INSTALL_FAILED_HOSTNAME_NOT_RESOLVED = 3221225474U;

		// Token: 0x04000A62 RID: 2658
		public static uint INSTALL_FAILED_INVALID_DOWNLOAD_URL = 3221225475U;
	}
}
