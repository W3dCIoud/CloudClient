﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000CB RID: 203
	public enum PerformanceState
	{
		// Token: 0x040004FB RID: 1275
		VtxEnabled,
		// Token: 0x040004FC RID: 1276
		VtxDisabled,
		// Token: 0x040004FD RID: 1277
		NoVtxSupport
	}
}
