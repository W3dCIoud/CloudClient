﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Navigation;
using Newtonsoft.Json;

namespace BlueStacks.Common
{
	// Token: 0x02000112 RID: 274
	public static class UsefulExtensionMethod
	{
		// Token: 0x06000954 RID: 2388 RVA: 0x00026848 File Offset: 0x00024A48
		public static string ToDebugString<TKey, TValue>(this IDictionary<TKey, TValue> dictionary)
		{
			return "{" + string.Join(",", (from kv in dictionary
			select kv.Key + "=" + kv.Value).ToArray<string>()) + "}";
		}

		// Token: 0x06000955 RID: 2389 RVA: 0x00009B22 File Offset: 0x00007D22
		public static void AddIfNotContain<T>(this IList<T> list, T item)
		{
			if (!list.Contains(item))
			{
				list.Add(item);
			}
		}

		// Token: 0x06000956 RID: 2390 RVA: 0x00026898 File Offset: 0x00024A98
		public static void AddIfNotContain<T>(this IList<T> list, IList<T> itemList)
		{
			foreach (T item in itemList)
			{
				list.AddIfNotContain(item);
			}
		}

		// Token: 0x06000957 RID: 2391 RVA: 0x00009B34 File Offset: 0x00007D34
		public static T RandomElement<T>(this IEnumerable<T> enumerable)
		{
			return enumerable.RandomElementUsing(new Random());
		}

		// Token: 0x06000958 RID: 2392 RVA: 0x000268E0 File Offset: 0x00024AE0
		public static T RandomElementUsing<T>(this IEnumerable<T> enumerable, Random rand)
		{
			int index = rand.Next(0, enumerable.Count<T>());
			return enumerable.ElementAt(index);
		}

		// Token: 0x06000959 RID: 2393 RVA: 0x00009B41 File Offset: 0x00007D41
		public static bool Contains(this string source, string toCheck, StringComparison comp)
		{
			return source != null && source.IndexOf(toCheck, comp) >= 0;
		}

		// Token: 0x0600095A RID: 2394 RVA: 0x00026904 File Offset: 0x00024B04
		public static string GetDescription(this Enum value)
		{
			DescriptionAttribute descriptionAttribute = (DescriptionAttribute)Attribute.GetCustomAttribute(value.GetType().GetFields(BindingFlags.Static | BindingFlags.Public).Single((FieldInfo x) => x.GetValue(null).Equals(value)), typeof(DescriptionAttribute));
			if (descriptionAttribute != null)
			{
				return descriptionAttribute.Description;
			}
			return value.ToString();
		}

		// Token: 0x0600095B RID: 2395 RVA: 0x0002696C File Offset: 0x00024B6C
		public static void LoadViewFromUri(this UserControl userControl, string baseUri)
		{
			Uri uri = new Uri(baseUri, UriKind.Relative);
			Stream stream = ((PackagePart)typeof(Application).GetMethod("GetResourceOrContentPart", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, new object[]
			{
				uri
			})).GetStream();
			Uri baseUri2 = new Uri((Uri)typeof(BaseUriHelper).GetProperty("PackAppBaseUri", BindingFlags.Static | BindingFlags.NonPublic).GetValue(null, null), uri);
			ParserContext parserContext = new ParserContext
			{
				BaseUri = baseUri2
			};
			typeof(XamlReader).GetMethod("LoadBaml", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, new object[]
			{
				stream,
				parserContext,
				userControl,
				true
			});
		}

		// Token: 0x0600095C RID: 2396 RVA: 0x00009B56 File Offset: 0x00007D56
		public static T GetObjectOfType<T>(this string val, T defaultValue)
		{
			if (!string.IsNullOrEmpty(val))
			{
				return (T)((object)TypeDescriptor.GetConverter(typeof(T)).ConvertFromString(val));
			}
			return defaultValue;
		}

		// Token: 0x0600095D RID: 2397 RVA: 0x00026A20 File Offset: 0x00024C20
		public static T DeepCopy<T>(this T other)
		{
			T result;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				binaryFormatter.Serialize(memoryStream, other);
				memoryStream.Position = 0L;
				result = (T)((object)binaryFormatter.Deserialize(memoryStream));
			}
			return result;
		}

		// Token: 0x0600095E RID: 2398 RVA: 0x00026A78 File Offset: 0x00024C78
		public static void SetPlacement(this Window window, string placementXml)
		{
			try
			{
				WindowPlacement.SetPlacement(new WindowInteropHelper(window).Handle, placementXml);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in SetPlacement.Exception: " + ex.ToString());
			}
		}

		// Token: 0x0600095F RID: 2399 RVA: 0x00026AC0 File Offset: 0x00024CC0
		public static void SetPlacement(this Window window, double scalingFactor)
		{
			try
			{
				RECT placementRect = new RECT((int)Math.Floor(window.Left * scalingFactor), (int)Math.Floor(window.Top * scalingFactor), (int)Math.Floor((window.Left + window.ActualWidth) * scalingFactor), (int)Math.Floor((window.Top + window.ActualHeight) * scalingFactor));
				WindowPlacement.SetPlacement(new WindowInteropHelper(window).Handle, placementRect);
			}
			catch (Exception arg)
			{
				Logger.Warning("Exception in SetPlacement. " + arg);
			}
		}

		// Token: 0x06000960 RID: 2400 RVA: 0x00009B7C File Offset: 0x00007D7C
		public static string GetPlacement(this Window window)
		{
			return WindowPlacement.GetPlacement(new WindowInteropHelper(window).Handle);
		}

		// Token: 0x06000961 RID: 2401 RVA: 0x00026B50 File Offset: 0x00024D50
		public static object GetPropValue(this object obj, string name, out Type objType)
		{
			objType = typeof(string);
			foreach (string name2 in name.Split(new char[]
			{
				'.'
			}))
			{
				if (obj == null)
				{
					return null;
				}
				PropertyInfo property = obj.GetType().GetProperty(name2);
				if (property == null)
				{
					return null;
				}
				obj = property.GetValue(obj, null);
				objType = property.PropertyType;
			}
			return obj;
		}

		// Token: 0x06000962 RID: 2402 RVA: 0x00026BB8 File Offset: 0x00024DB8
		public static T GetPropValue<T>(this object obj, string name)
		{
			Type type;
			object propValue = obj.GetPropValue(name, out type);
			if (propValue == null)
			{
				return default(T);
			}
			return (T)((object)propValue);
		}

		// Token: 0x06000963 RID: 2403 RVA: 0x00026BE4 File Offset: 0x00024DE4
		public static object ChangeType(this object obj, Type type)
		{
			if (obj.IsList())
			{
				IEnumerable<object> source = ((IEnumerable)obj).Cast<object>().ToList<object>();
				Type containedType = type.GetGenericArguments().First<Type>();
				return (from item in source
				select Convert.ChangeType(item, containedType)).ToList<object>();
			}
			return Convert.ChangeType(obj, type);
		}

		// Token: 0x06000964 RID: 2404 RVA: 0x00009B8E File Offset: 0x00007D8E
		public static bool IsList(this object o)
		{
			return o != null && (o is IList && o.GetType().IsGenericType) && o.GetType().GetGenericTypeDefinition().IsAssignableFrom(typeof(List<>));
		}

		// Token: 0x06000965 RID: 2405 RVA: 0x00026C40 File Offset: 0x00024E40
		public static bool? SetTextblockTooltip(this TextBlock tb, string tooltipText = null)
		{
			if (tb != null)
			{
				Typeface typeface = new Typeface(tb.FontFamily, tb.FontStyle, tb.FontWeight, tb.FontStretch);
				if (tb.ToolTip != null || tooltipText != null)
				{
					if (new FormattedText((tooltipText == null) ? tb.ToolTip.ToString() : tooltipText, Thread.CurrentThread.CurrentCulture, tb.FlowDirection, typeface, tb.FontSize, tb.Foreground).WidthIncludingTrailingWhitespace - tb.ActualWidth > 0.1)
					{
						ToolTipService.SetIsEnabled(tb, true);
						return new bool?(true);
					}
					ToolTipService.SetIsEnabled(tb, false);
					return new bool?(false);
				}
			}
			return null;
		}

		// Token: 0x06000966 RID: 2406 RVA: 0x00026CEC File Offset: 0x00024EEC
		public static void SaveUserDefinedShortcuts(this ShortcutConfig mShortcutsConfigInstance)
		{
			if (mShortcutsConfigInstance != null)
			{
				JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
				serializerSettings.Formatting = Formatting.Indented;
				string userDefinedShortcuts = JsonConvert.SerializeObject(mShortcutsConfigInstance, serializerSettings);
				RegistryManager.Instance.UserDefinedShortcuts = userDefinedShortcuts;
			}
		}
	}
}
