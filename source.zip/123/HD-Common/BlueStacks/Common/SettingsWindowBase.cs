﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace BlueStacks.Common
{
	// Token: 0x0200010C RID: 268
	public abstract class SettingsWindowBase : UserControl, IComponentConnector
	{
		// Token: 0x170002AD RID: 685
		// (get) Token: 0x06000927 RID: 2343 RVA: 0x00009926 File Offset: 0x00007B26
		public CustomPopUp EnableVTPopup
		{
			get
			{
				return this.mEnableVTPopup;
			}
		}

		// Token: 0x170002AE RID: 686
		// (get) Token: 0x06000928 RID: 2344 RVA: 0x0000992E File Offset: 0x00007B2E
		public Grid SettingsWindowGrid
		{
			get
			{
				return this.settingsWindowGrid;
			}
		}

		// Token: 0x170002AF RID: 687
		// (get) Token: 0x06000929 RID: 2345 RVA: 0x00009936 File Offset: 0x00007B36
		public StackPanel SettingsWindowStackPanel
		{
			get
			{
				return this.settingsStackPanel;
			}
		}

		// Token: 0x0600092A RID: 2346 RVA: 0x00003337 File Offset: 0x00001537
		protected virtual void SetPopupOffset()
		{
		}

		// Token: 0x0600092B RID: 2347
		public abstract void CloseButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e);

		// Token: 0x0600092C RID: 2348 RVA: 0x0000993E File Offset: 0x00007B3E
		public SettingsWindowBase()
		{
			this.LoadViewFromUri("/HD-Common;component/UIElements/SettingsWindowBase.xaml");
		}

		// Token: 0x0600092D RID: 2349 RVA: 0x00009972 File Offset: 0x00007B72
		public void AddControlInGridAndDict(string btnName, UserControl control)
		{
			this.settingsWindowControlsDict[btnName] = control;
			if (!this.settingsWindowGrid.Children.Contains(control))
			{
				this.settingsWindowGrid.Children.Add(control);
			}
		}

		// Token: 0x0600092E RID: 2350 RVA: 0x000099A6 File Offset: 0x00007BA6
		public void BringToFront(UserControl control)
		{
			if (control == null)
			{
				return;
			}
			if (this.visibleControl != null && this.visibleControl != control)
			{
				this.visibleControl.Visibility = Visibility.Hidden;
			}
			control.Visibility = Visibility.Visible;
			this.visibleControl = control;
			this.SetPopupOffset();
		}

		// Token: 0x0600092F RID: 2351 RVA: 0x000099DD File Offset: 0x00007BDD
		public bool CheckWidth()
		{
			return this.settingsStackPanel.ActualWidth == this.settingsStackPanel.ActualWidth && this.settingsWindowGrid.ActualWidth == this.settingsWindowGrid.ActualWidth;
		}

		// Token: 0x06000930 RID: 2352 RVA: 0x00026460 File Offset: 0x00024660
		public void SettingsBtn_Click(object sender, RoutedEventArgs e)
		{
			CustomSettingsButton customSettingsButton = (CustomSettingsButton)sender;
			UserControl control = this.settingsWindowControlsDict[customSettingsButton.Name];
			Logger.Info("Clicked {0} button", new object[]
			{
				customSettingsButton.Name
			});
			this.BringToFront(control);
			if (customSettingsButton.Name.Equals("STRING_SHORTCUT_KEY_SETTINGS"))
			{
				Stats.SendMiscellaneousStatsAsync("KeyboardShortcuts", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "shortcut_open", null, null, null, null, null, "Android", 0);
			}
		}

		// Token: 0x06000931 RID: 2353 RVA: 0x00009A12 File Offset: 0x00007C12
		private void mCrossButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x06000932 RID: 2354 RVA: 0x000264E8 File Offset: 0x000246E8
		private void EnableVtInfo_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked Enable Vt popup Settings window");
			this.mIsVtxLearned = true;
			this.mEnableVTPopup.IsOpen = false;
			string text = WebHelper.GetUrlWithParams(string.Format("{0}/{1}", WebHelper.GetServerHost(), "help_articles"));
			text = string.Format("{0}&article={1}", text, "enable_virtualization");
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				text = "http://help.dmm.com/-/detail/=/qid=45997/";
			}
			Utils.OpenUrl(text);
		}

		// Token: 0x06000933 RID: 2355 RVA: 0x00026558 File Offset: 0x00024758
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/settingswindowbase.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000934 RID: 2356 RVA: 0x00003339 File Offset: 0x00001539
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000935 RID: 2357 RVA: 0x00026588 File Offset: 0x00024788
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mGrid = (Grid)target;
				return;
			case 2:
				this.mSettingsWindowIcon = (CustomPictureBox)target;
				return;
			case 3:
				this.mLblBlueStacksSettings = (Label)target;
				return;
			case 4:
				this.mCrossButton = (CustomPictureBox)target;
				return;
			case 5:
				this.mEnableVTPopup = (CustomPopUp)target;
				return;
			case 6:
				this.EnableVtInfo = (TextBlock)target;
				this.EnableVtInfo.PreviewMouseLeftButtonUp += this.EnableVtInfo_PreviewMouseLeftButtonUp;
				return;
			case 7:
				this.mBottomGrid = (Grid)target;
				return;
			case 8:
				this.settingsStackPanel = (StackPanel)target;
				return;
			case 9:
				this.mSelectedLine = (Line)target;
				return;
			case 10:
				this.settingsWindowGrid = (Grid)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040006D3 RID: 1747
		private UserControl visibleControl;

		// Token: 0x040006D4 RID: 1748
		public string mStartUpTab = "STRING_DISPLAY_SETTINGS";

		// Token: 0x040006D5 RID: 1749
		public List<string> settingsControlNameList = new List<string>();

		// Token: 0x040006D6 RID: 1750
		public Dictionary<string, UserControl> settingsWindowControlsDict = new Dictionary<string, UserControl>();

		// Token: 0x040006D7 RID: 1751
		public bool mIsVtxLearned;

		// Token: 0x040006D8 RID: 1752
		internal Grid mGrid;

		// Token: 0x040006D9 RID: 1753
		internal CustomPictureBox mSettingsWindowIcon;

		// Token: 0x040006DA RID: 1754
		internal Label mLblBlueStacksSettings;

		// Token: 0x040006DB RID: 1755
		internal CustomPictureBox mCrossButton;

		// Token: 0x040006DC RID: 1756
		internal CustomPopUp mEnableVTPopup;

		// Token: 0x040006DD RID: 1757
		internal TextBlock EnableVtInfo;

		// Token: 0x040006DE RID: 1758
		internal Grid mBottomGrid;

		// Token: 0x040006DF RID: 1759
		internal StackPanel settingsStackPanel;

		// Token: 0x040006E0 RID: 1760
		internal Line mSelectedLine;

		// Token: 0x040006E1 RID: 1761
		internal Grid settingsWindowGrid;

		// Token: 0x040006E2 RID: 1762
		private bool _contentLoaded;
	}
}
