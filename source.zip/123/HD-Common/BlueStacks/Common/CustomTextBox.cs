﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;

namespace BlueStacks.Common
{
	// Token: 0x020000B1 RID: 177
	public class CustomTextBox : TextBox, IComponentConnector
	{
		// Token: 0x06000484 RID: 1156 RVA: 0x000049A6 File Offset: 0x00002BA6
		public CustomTextBox()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000485 RID: 1157 RVA: 0x000049B4 File Offset: 0x00002BB4
		private void CustomTextBox_Loaded(object sender, RoutedEventArgs e)
		{
			if (string.IsNullOrEmpty(base.Text))
			{
				base.Text = this.WatermarkText;
			}
		}

		// Token: 0x17000120 RID: 288
		// (get) Token: 0x06000486 RID: 1158 RVA: 0x000049CF File Offset: 0x00002BCF
		// (set) Token: 0x06000487 RID: 1159 RVA: 0x000049E1 File Offset: 0x00002BE1
		public TextValidityOptions InputTextValidity
		{
			get
			{
				return (TextValidityOptions)base.GetValue(CustomTextBox.InputTextValidityProperty);
			}
			set
			{
				base.SetValue(CustomTextBox.InputTextValidityProperty, value);
			}
		}

		// Token: 0x17000121 RID: 289
		// (get) Token: 0x06000488 RID: 1160 RVA: 0x000049F4 File Offset: 0x00002BF4
		// (set) Token: 0x06000489 RID: 1161 RVA: 0x00004A06 File Offset: 0x00002C06
		public string WatermarkText
		{
			get
			{
				return (string)base.GetValue(CustomTextBox.WatermarkTextProperty);
			}
			set
			{
				base.SetValue(CustomTextBox.WatermarkTextProperty, value);
			}
		}

		// Token: 0x17000122 RID: 290
		// (get) Token: 0x0600048A RID: 1162 RVA: 0x00004A14 File Offset: 0x00002C14
		// (set) Token: 0x0600048B RID: 1163 RVA: 0x00004A26 File Offset: 0x00002C26
		public bool SelectAllOnStart
		{
			get
			{
				return (bool)base.GetValue(CustomTextBox.SelectAllOnStartProperty);
			}
			set
			{
				base.SetValue(CustomTextBox.SelectAllOnStartProperty, value);
			}
		}

		// Token: 0x0600048C RID: 1164 RVA: 0x0001AE24 File Offset: 0x00019024
		private void TextBox_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
		{
			if (base.Text.Equals(this.WatermarkText))
			{
				base.Clear();
				return;
			}
			if (this.SelectAllOnStart)
			{
				base.Dispatcher.BeginInvoke(new Action(delegate()
				{
					base.SelectAll();
				}), DispatcherPriority.ApplicationIdle, new object[0]);
			}
		}

		// Token: 0x0600048D RID: 1165 RVA: 0x000049B4 File Offset: 0x00002BB4
		private void TextBox_LostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
		{
			if (string.IsNullOrEmpty(base.Text))
			{
				base.Text = this.WatermarkText;
			}
		}

		// Token: 0x0600048E RID: 1166 RVA: 0x0001AE74 File Offset: 0x00019074
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/customtextbox.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600048F RID: 1167 RVA: 0x0001AEA4 File Offset: 0x000190A4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mTextBox = (CustomTextBox)target;
				this.mTextBox.Loaded += this.CustomTextBox_Loaded;
				this.mTextBox.GotKeyboardFocus += this.TextBox_GotKeyboardFocus;
				this.mTextBox.LostKeyboardFocus += this.TextBox_LostKeyboardFocus;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x04000402 RID: 1026
		public static readonly DependencyProperty InputTextValidityProperty = DependencyProperty.Register("InputTextValidity", typeof(TextValidityOptions), typeof(CustomTextBox), new PropertyMetadata(TextValidityOptions.Success));

		// Token: 0x04000403 RID: 1027
		public static readonly DependencyProperty WatermarkTextProperty = DependencyProperty.Register("WatermarkText", typeof(string), typeof(CustomTextBox), new PropertyMetadata(""));

		// Token: 0x04000404 RID: 1028
		public static readonly DependencyProperty SelectAllOnStartProperty = DependencyProperty.Register("SelectAllOnStart", typeof(bool), typeof(CustomTextBox), new PropertyMetadata(true));

		// Token: 0x04000405 RID: 1029
		internal CustomTextBox mTextBox;

		// Token: 0x04000406 RID: 1030
		private bool _contentLoaded;
	}
}
