﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000CC RID: 204
	public enum GamePadEventType
	{
		// Token: 0x040004FF RID: 1279
		TYPE_GAMEPAD_ATTACH,
		// Token: 0x04000500 RID: 1280
		TYPE_GAMEPAD_DETACH,
		// Token: 0x04000501 RID: 1281
		TYPE_GAMEPAD_UPDATE
	}
}
