﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200015B RID: 347
	public class FeatureBitHelper
	{
		// Token: 0x06000B6F RID: 2927 RVA: 0x00004DD8 File Offset: 0x00002FD8
		public static bool IsFeatureEnabled(ulong featureMask, ulong feature)
		{
			return (feature & featureMask) != 0UL;
		}

		// Token: 0x06000B70 RID: 2928 RVA: 0x0000AAE6 File Offset: 0x00008CE6
		public static ulong EnableFeature(ulong featureMask, ulong feature)
		{
			if ((feature & featureMask) != 0UL)
			{
				return feature;
			}
			return feature |= featureMask;
		}

		// Token: 0x06000B71 RID: 2929 RVA: 0x0000AAF5 File Offset: 0x00008CF5
		public static ulong DisableFeature(ulong featureMask, ulong feature)
		{
			if ((feature & featureMask) == 0UL)
			{
				return feature;
			}
			return feature & ~featureMask;
		}

		// Token: 0x06000B72 RID: 2930 RVA: 0x000316A8 File Offset: 0x0002F8A8
		public static ulong ToggleFeature(ulong featureMask, ulong feature)
		{
			ulong result;
			if (FeatureBitHelper.IsFeatureEnabled(featureMask, feature))
			{
				result = FeatureBitHelper.DisableFeature(featureMask, feature);
			}
			else
			{
				result = FeatureBitHelper.EnableFeature(featureMask, feature);
			}
			return result;
		}

		// Token: 0x06000B73 RID: 2931 RVA: 0x0000AB02 File Offset: 0x00008D02
		public static bool WasFeatureChanged(ulong featureMask, ulong newFeature, ulong originalFeature, out bool isEnabled)
		{
			bool flag = FeatureBitHelper.IsFeatureEnabled(featureMask, originalFeature);
			isEnabled = FeatureBitHelper.IsFeatureEnabled(featureMask, newFeature);
			return flag != isEnabled;
		}
	}
}
