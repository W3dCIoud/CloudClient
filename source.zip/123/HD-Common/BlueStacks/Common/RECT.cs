﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000133 RID: 307
	[Serializable]
	public struct RECT
	{
		// Token: 0x06000A87 RID: 2695 RVA: 0x0000A2C8 File Offset: 0x000084C8
		public RECT(int left, int top, int right, int bottom)
		{
			this.Left = left;
			this.Top = top;
			this.Right = right;
			this.Bottom = bottom;
		}

		// Token: 0x04000774 RID: 1908
		public int Left;

		// Token: 0x04000775 RID: 1909
		public int Top;

		// Token: 0x04000776 RID: 1910
		public int Right;

		// Token: 0x04000777 RID: 1911
		public int Bottom;
	}
}
