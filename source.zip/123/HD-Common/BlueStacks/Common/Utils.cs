﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Management;
using System.Net;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Principal;
using System.ServiceProcess;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Xml.Serialization;
using BlueStacks.Common.Interop;
using BlueStacks.VBoxUtils;
using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;

namespace BlueStacks.Common
{
	// Token: 0x02000116 RID: 278
	public class Utils
	{
		// Token: 0x0600096E RID: 2414
		[DllImport("urlmon.dll", CharSet = CharSet.Auto)]
		private static extern uint FindMimeFromData(uint pBC, [MarshalAs(UnmanagedType.LPStr)] string pwzUrl, [MarshalAs(UnmanagedType.LPArray)] byte[] pBuffer, uint cbSize, [MarshalAs(UnmanagedType.LPStr)] string pwzMimeProposed, uint dwMimeFlags, out uint ppwzMimeOut, uint dwReserverd);

		// Token: 0x0600096F RID: 2415
		[DllImport("shell32.dll", CharSet = CharSet.Auto)]
		public static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);

		// Token: 0x06000970 RID: 2416
		[DllImport("user32.dll")]
		private static extern IntPtr GetForegroundWindow();

		// Token: 0x06000971 RID: 2417
		[DllImport("user32.dll")]
		private static extern uint GetWindowThreadProcessId(IntPtr hwnd, IntPtr proccess);

		// Token: 0x06000972 RID: 2418
		[DllImport("user32.dll")]
		private static extern IntPtr GetKeyboardLayout(uint thread);

		// Token: 0x06000973 RID: 2419
		[DllImport("user32.dll")]
		private static extern int GetSystemMetrics(int smIndex);

		// Token: 0x06000974 RID: 2420
		[DllImport("setupapi.dll", SetLastError = true)]
		public static extern int SetupDiGetClassDevs(ref Guid lpGuid, IntPtr Enumerator, IntPtr hwndParent, Utils.ClassDevsFlags Flags);

		// Token: 0x06000975 RID: 2421
		[DllImport("setupapi.dll", SetLastError = true)]
		public static extern int SetupDiGetClassDevs(IntPtr guid, IntPtr Enumerator, IntPtr hwndParent, Utils.ClassDevsFlags Flags);

		// Token: 0x06000976 RID: 2422
		[DllImport("setupapi.dll", SetLastError = true)]
		public static extern int SetupDiEnumDeviceInfo(int DeviceInfoSet, int Index, ref Utils.SP_DEVINFO_DATA DeviceInfoData);

		// Token: 0x06000977 RID: 2423
		[DllImport("setupapi.dll", SetLastError = true)]
		public static extern int SetupDiEnumDeviceInterfaces(int DeviceInfoSet, int DeviceInfoData, ref Guid lpHidGuid, int MemberIndex, ref Utils.SP_DEVICE_INTERFACE_DATA lpDeviceInterfaceData);

		// Token: 0x06000978 RID: 2424
		[DllImport("setupapi.dll", SetLastError = true)]
		public static extern int SetupDiGetDeviceInterfaceDetail(int DeviceInfoSet, ref Utils.SP_DEVICE_INTERFACE_DATA lpDeviceInterfaceData, IntPtr aPtr, int detailSize, ref int requiredSize, IntPtr bPtr);

		// Token: 0x06000979 RID: 2425
		[DllImport("setupapi.dll", SetLastError = true)]
		public static extern int SetupDiGetDeviceInterfaceDetail(int DeviceInfoSet, ref Utils.SP_DEVICE_INTERFACE_DATA lpDeviceInterfaceData, ref Utils.PSP_DEVICE_INTERFACE_DETAIL_DATA myPSP_DEVICE_INTERFACE_DETAIL_DATA, int detailSize, ref int requiredSize, IntPtr bPtr);

		// Token: 0x0600097A RID: 2426
		[DllImport("setupapi.dll", SetLastError = true)]
		public static extern int SetupDiGetDeviceRegistryProperty(int DeviceInfoSet, ref Utils.SP_DEVINFO_DATA DeviceInfoData, Utils.RegPropertyType Property, IntPtr PropertyRegDataType, IntPtr PropertyBuffer, int PropertyBufferSize, ref int RequiredSize);

		// Token: 0x0600097B RID: 2427
		[DllImport("setupapi.dll", SetLastError = true)]
		public static extern int SetupDiGetDeviceRegistryProperty(int DeviceInfoSet, ref Utils.SP_DEVINFO_DATA DeviceInfoData, Utils.RegPropertyType Property, IntPtr PropertyRegDataType, ref Utils.DATA_BUFFER PropertyBuffer, int PropertyBufferSize, ref int RequiredSize);

		// Token: 0x14000006 RID: 6
		// (add) Token: 0x0600097C RID: 2428 RVA: 0x00026D1C File Offset: 0x00024F1C
		// (remove) Token: 0x0600097D RID: 2429 RVA: 0x00026D50 File Offset: 0x00024F50
		public static event EventHandler GuestBootCallBack;

		// Token: 0x0600097E RID: 2430 RVA: 0x00026D84 File Offset: 0x00024F84
		public static bool IsTargetForShortcut(string shortcutPath, string targetPath)
		{
			try
			{
				if (File.Exists(shortcutPath))
				{
					string shortcutArguments = ShortcutHelper.GetShortcutArguments(shortcutPath);
					if (shortcutArguments.ToLower().Contains(targetPath.ToLower().Trim()) && string.Compare(shortcutArguments, Path.Combine(RegistryStrings.InstallDir, targetPath), true) == 0)
					{
						Logger.Info("{0} is a shortcut for target {1}", new object[]
						{
							shortcutPath,
							targetPath
						});
						return true;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Ignoring exception while comparing TargetForShortcut: " + ex.Message);
			}
			return false;
		}

		// Token: 0x0600097F RID: 2431 RVA: 0x00026E18 File Offset: 0x00025018
		public static bool IsShortcutArgumentContainsPackage(string shortcutPath, string packageName)
		{
			try
			{
				if (File.Exists(shortcutPath))
				{
					ShellLink shellLink = new ShellLink();
					((IPersistFile)shellLink).Load(shortcutPath, 0);
					StringBuilder stringBuilder = new StringBuilder(1000);
					((IShellLink)shellLink).GetArguments(stringBuilder, stringBuilder.Capacity);
					if (stringBuilder.ToString().ToLower().Contains(packageName.ToLower()))
					{
						return true;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Ignoring exception " + ex.ToString());
			}
			return false;
		}

		// Token: 0x06000980 RID: 2432 RVA: 0x00026EA4 File Offset: 0x000250A4
		public static void NotifyBootFailureToParentWindow(string className, string windowName, int exitCode, string vmName)
		{
			Logger.Info("Sending BOOT_FAILURE message to class = {0}, window = {1}", new object[]
			{
				className,
				windowName
			});
			IntPtr intPtr = InteropWindow.FindWindow(className, windowName);
			try
			{
				if (intPtr == IntPtr.Zero)
				{
					Logger.Info("Unable to find window : {0}", new object[]
					{
						className
					});
				}
				else
				{
					uint num;
					if (vmName == "Android")
					{
						num = 0U;
					}
					else
					{
						num = (uint)int.Parse(vmName.Split(new char[]
						{
							'_'
						})[1]);
					}
					Logger.Info("Sending wparam : {0} and lparam : {1}", new object[]
					{
						(uint)exitCode,
						num
					});
					InteropWindow.SendMessage(intPtr, 1037U, (IntPtr)((long)((ulong)exitCode)), (IntPtr)((long)((ulong)num)));
					Logger.Info("Sent BOOT_FAILURE message");
				}
			}
			catch (Exception ex)
			{
				Logger.Error(string.Format("Error Occured, Err: {0}", ex.ToString()));
			}
		}

		// Token: 0x06000981 RID: 2433 RVA: 0x00009C18 File Offset: 0x00007E18
		public static bool IsDesktopPC()
		{
			return Utils.GetSystemMetrics(86) == 0;
		}

		// Token: 0x06000982 RID: 2434 RVA: 0x00026F94 File Offset: 0x00025194
		public static bool CopyRecursive(string srcPath, string dstPath)
		{
			bool result = true;
			try
			{
				Logger.Info("Copying {0} to {1}", new object[]
				{
					srcPath,
					dstPath
				});
				if (!Directory.Exists(dstPath))
				{
					Directory.CreateDirectory(dstPath);
				}
				DirectoryInfo directoryInfo = new DirectoryInfo(srcPath);
				foreach (FileInfo fileInfo in directoryInfo.GetFiles())
				{
					fileInfo.CopyTo(Path.Combine(dstPath, fileInfo.Name), true);
				}
				foreach (DirectoryInfo directoryInfo2 in directoryInfo.GetDirectories())
				{
					if (!Utils.CopyRecursive(Path.Combine(srcPath, directoryInfo2.Name), Path.Combine(dstPath, directoryInfo2.Name)))
					{
						result = false;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Ignoring exception in copy recursive src:{0} dst:{1}, exception:{2}", new object[]
				{
					srcPath,
					dstPath,
					ex.Message
				});
				result = false;
			}
			return result;
		}

		// Token: 0x06000983 RID: 2435 RVA: 0x00009C24 File Offset: 0x00007E24
		public static bool IsNumberWithinRange(int number, int lowerLimit, int upperLimit, bool includeLowerLimit = true)
		{
			if (includeLowerLimit)
			{
				return number >= lowerLimit && number < upperLimit;
			}
			return number > lowerLimit && number < upperLimit;
		}

		// Token: 0x06000984 RID: 2436 RVA: 0x0002707C File Offset: 0x0002527C
		public static int GetAndroidVMMemory(bool defaultInstance = true)
		{
			Logger.Info("Getting Android VM Memory");
			ulong num = 1048576UL;
			int num2 = 0;
			int num3 = 600;
			int num4 = 3072;
			int num5 = 4096;
			int num6 = 5120;
			int num7 = 6144;
			int upperLimit = 8192;
			try
			{
				int num8 = (int)(SystemUtils.GetSystemTotalPhysicalMemory() / num);
				Logger.Info("Total RAM = {0} MB", new object[]
				{
					num8
				});
				if (SystemUtils.IsOs64Bit())
				{
					if (defaultInstance)
					{
						if (num8 < num4)
						{
							num2 = num3;
						}
						else if (Utils.IsNumberWithinRange(num8, num4, num5, true))
						{
							num2 = 900;
						}
						else if (Utils.IsNumberWithinRange(num8, num5, num6, true))
						{
							num2 = 1200;
						}
						else if (Utils.IsNumberWithinRange(num8, num6, num7, true))
						{
							num2 = 1500;
						}
						else if (Utils.IsNumberWithinRange(num8, num7, upperLimit, true))
						{
							num2 = 1800;
						}
						else
						{
							num2 = 2048;
						}
					}
					else if (num8 > 4000)
					{
						num2 = 1024;
					}
					else
					{
						num2 = 800;
					}
				}
				else if (num8 < num4 || !defaultInstance)
				{
					num2 = num3;
				}
				else
				{
					num2 = 900;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to check physical memory. Err: " + ex.ToString());
				num2 = 1200;
			}
			Logger.Info("Using RAM: {0}MB", new object[]
			{
				num2
			});
			return num2;
		}

		// Token: 0x06000985 RID: 2437 RVA: 0x000271D4 File Offset: 0x000253D4
		public static void KillComServerSafe()
		{
			Logger.Info("KillComServerSafe()");
			ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(new WqlObjectQuery("SELECT * FROM Win32_Process WHERE Name = 'BstkSVC.exe'"));
			if (managementObjectSearcher.Get().Count != 0)
			{
				Logger.Info("Found BstkSVC. Waiting for it to exit automatically...");
				Thread.Sleep(5000);
			}
			foreach (ManagementBaseObject managementBaseObject in managementObjectSearcher.Get())
			{
				ManagementObject managementObject = (ManagementObject)managementBaseObject;
				Logger.Info(string.Concat(new object[]
				{
					"Considering ",
					managementObject["ProcessId"],
					" -> ",
					managementObject["ExecutablePath"]
				}));
				Process processById = Process.GetProcessById((int)((uint)managementObject["ProcessId"]));
				string text = (string)managementObject["ExecutablePath"];
				if (!string.IsNullOrEmpty(text))
				{
					string text2 = Directory.GetParent(text).ToString();
					string installDir = RegistryStrings.InstallDir;
					if (string.Compare(Path.GetFullPath(installDir).TrimEnd(new char[]
					{
						'\\'
					}), Path.GetFullPath(text2).TrimEnd(new char[]
					{
						'\\'
					}), StringComparison.InvariantCultureIgnoreCase) == 0)
					{
						Logger.Info("process BstkSVC not killed since the process Dir:{0} and Ignore Dir:{1} are same", new object[]
						{
							text2,
							installDir
						});
						continue;
					}
				}
				Logger.Info("Trying to kill BstkSvc PID " + processById.Id);
				processById.Kill();
				if (!processById.WaitForExit(10000))
				{
					Logger.Info("Timeout waiting for process to die");
				}
			}
		}

		// Token: 0x06000986 RID: 2438 RVA: 0x00027374 File Offset: 0x00025574
		public static bool CheckIfGuestReady(string vmName, int retries)
		{
			if (!Utils.sIsGuestReady.ContainsKey(vmName))
			{
				Utils.sIsGuestReady.Add(vmName, false);
			}
			if (!Utils.sIsGuestReady[vmName])
			{
				while (retries > 0)
				{
					retries--;
					try
					{
						if (JObject.Parse(HTTPUtils.SendRequestToGuest("checkIfGuestReady", null, vmName, 1000, null, false, 1, 0))["result"].ToString().Equals("ok"))
						{
							Logger.Info("Guest is ready");
							Utils.sIsGuestReady[vmName] = true;
							return Utils.sIsGuestReady[vmName];
						}
						Thread.Sleep(1000);
					}
					catch (Exception)
					{
						Thread.Sleep(1000);
					}
				}
				Logger.Error("Guest is not ready now after all retries");
			}
			return Utils.sIsGuestReady[vmName];
		}

		// Token: 0x06000987 RID: 2439 RVA: 0x00027450 File Offset: 0x00025650
		public static List<string> GetRunningInstancesList()
		{
			List<string> list = new List<string>();
			foreach (string text in RegistryManager.Instance.VmList)
			{
				if (Utils.IsAndroidPlayerRunning(text))
				{
					list.Add(text);
				}
			}
			return list;
		}

		// Token: 0x06000988 RID: 2440 RVA: 0x00009C40 File Offset: 0x00007E40
		private static bool CheckIfAndroidService(string serviceName)
		{
			return Regex.IsMatch(serviceName, "[bB]st[hH]d(Plus{1})?Android(_\\d+)?Svc");
		}

		// Token: 0x06000989 RID: 2441 RVA: 0x00027490 File Offset: 0x00025690
		public static string GetUserAgent(string tag = null, string version = null)
		{
			if (tag == null)
			{
				tag = RegistryManager.Instance.UserGuid;
			}
			string text;
			if (version == null)
			{
				text = string.Format("{0}/{1}/{2}", "BlueStacks", "4.140.12.1002", tag);
			}
			else
			{
				text = string.Format("{0}/{1}/{2}", "BlueStacks", version, tag);
			}
			text += " gzip";
			Logger.Debug("UserAgent = " + text);
			byte[] bytes = Encoding.Default.GetBytes(text);
			return Encoding.UTF8.GetString(bytes);
		}

		// Token: 0x0600098A RID: 2442 RVA: 0x00027514 File Offset: 0x00025714
		public static Process StartHiddenFrontend(string vmName)
		{
			if ("bgp".Equals("dmm"))
			{
				string args = vmName + " -h";
				return ProcessUtils.StartExe(RegistryManager.Instance.PartnerExePath, args, false);
			}
			Process process;
			try
			{
				string fileName = Path.Combine(RegistryStrings.InstallDir, "HD-Player.exe");
				process = new Process();
				process.StartInfo.UseShellExecute = false;
				process.StartInfo.CreateNoWindow = true;
				process.StartInfo.FileName = fileName;
				process.StartInfo.Arguments = vmName + " -h";
				Logger.Info("Sending vmName for vm calling {0}", new object[]
				{
					vmName
				});
				Logger.Info("Utils: Starting hidden Frontend");
				process.Start();
			}
			catch (Exception ex)
			{
				process = null;
				Logger.Error("Error starting process" + ex.ToString());
			}
			return process;
		}

		// Token: 0x0600098B RID: 2443 RVA: 0x000275F4 File Offset: 0x000257F4
		public static Process StartFrontend(string vmName)
		{
			string fileName = Path.Combine(RegistryStrings.InstallDir, "HD-RunApp.exe");
			Process process = new Process();
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.CreateNoWindow = true;
			process.StartInfo.FileName = fileName;
			process.StartInfo.Arguments = "-vmname:" + vmName;
			Logger.Info("Utils: Starting Frontend");
			process.Start();
			return process;
		}

		// Token: 0x0600098C RID: 2444 RVA: 0x00027664 File Offset: 0x00025864
		public static string GetMD5HashFromFile(string fileName)
		{
			try
			{
				return new _MD5
				{
					ValueAsFile = fileName
				}.FingerPrint.ToLower();
			}
			catch (Exception ex)
			{
				Logger.Error("Error in creating md5 hash: " + ex.ToString());
			}
			return string.Empty;
		}

		// Token: 0x0600098D RID: 2445 RVA: 0x000276BC File Offset: 0x000258BC
		public static bool IsCheckSumValid(string md5Compare, string filePath)
		{
			Logger.Info("Checking for valid checksum");
			string md5HashFromFile = Utils.GetMD5HashFromFile(filePath);
			Logger.Info("Computed MD5: " + md5HashFromFile);
			return string.Equals(md5Compare, md5HashFromFile, StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x0600098E RID: 2446 RVA: 0x000276F8 File Offset: 0x000258F8
		public static string GetSystemFontName()
		{
			string result;
			try
			{
				new Font("Arial", 8f, FontStyle.Regular, GraphicsUnit.Point, 0);
				result = "Arial";
			}
			catch (Exception)
			{
				Label label = new Label();
				try
				{
					new Font(label.Font.Name, 8f, FontStyle.Regular, GraphicsUnit.Point, 0);
				}
				catch (Exception)
				{
					if (Oem.Instance.IsMessageBoxToBeDisplayed)
					{
						MessageBox.Show("Failed to load Font set.", string.Format("{0} instance failed.", Strings.ProductDisplayName), MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					Environment.Exit(-1);
				}
				result = label.Font.Name;
			}
			return result;
		}

		// Token: 0x0600098F RID: 2447 RVA: 0x00009C4D File Offset: 0x00007E4D
		public static bool IsBlueStacksInstalled()
		{
			return !string.IsNullOrEmpty(RegistryManager.Instance.Version);
		}

		// Token: 0x06000990 RID: 2448 RVA: 0x00009C63 File Offset: 0x00007E63
		public static string GetLogoFile()
		{
			return Path.Combine(RegistryStrings.InstallDir, "ProductLogo.ico");
		}

		// Token: 0x06000991 RID: 2449 RVA: 0x000277A0 File Offset: 0x000259A0
		public static void AddUploadTextToImage(string inputImage, string outputImage)
		{
			System.Drawing.Image image = System.Drawing.Image.FromFile(inputImage);
			int width = image.Width;
			int height = image.Height + 100;
			Bitmap bitmap = new Bitmap(width, height);
			Graphics graphics = Graphics.FromImage(bitmap);
			graphics.DrawImage(image, new Rectangle(0, 0, image.Width, image.Height), new Rectangle(0, 0, image.Width, image.Height), GraphicsUnit.Pixel);
			System.Drawing.Image image2 = System.Drawing.Image.FromFile(Utils.GetLogoFile());
			graphics.DrawImage(image2, new Rectangle(65, image.Height, 40, 40), new Rectangle(80, 0, image2.Width, 40), GraphicsUnit.Pixel);
			SolidBrush brush = new SolidBrush(Color.White);
			float width2 = (float)image.Width;
			float height2 = 80f;
			RectangleF layoutRectangle = new RectangleF(120f, (float)(image.Height + 7), width2, height2);
			Pen pen = new Pen(Color.Black);
			graphics.DrawRectangle(pen, 120f, (float)image.Height, width2, height2);
			string snapShotShareString = Oem.Instance.SnapShotShareString;
			graphics.DrawString(snapShotShareString, new Font("Arial", 14f), brush, layoutRectangle);
			graphics.Save();
			image.Dispose();
			bitmap.Save(outputImage, ImageFormat.Jpeg);
		}

		// Token: 0x06000992 RID: 2450 RVA: 0x000278C8 File Offset: 0x00025AC8
		public static Utils.CmdRes RunCmd(string prog, string args, string outPath)
		{
			try
			{
				return Utils.RunCmdInternal(prog, args, outPath, true, false);
			}
			catch (Exception ex)
			{
				Logger.Error(ex.ToString());
			}
			return new Utils.CmdRes();
		}

		// Token: 0x06000993 RID: 2451 RVA: 0x00027908 File Offset: 0x00025B08
		public static string RunCmdNoLog(string prog, string args, int timeout)
		{
			Process process = new Process();
			new Utils.CmdRes();
			string output = "";
			process.StartInfo.FileName = prog;
			process.StartInfo.Arguments = args;
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.CreateNoWindow = true;
			process.StartInfo.RedirectStandardInput = true;
			process.StartInfo.RedirectStandardOutput = true;
			process.OutputDataReceived += delegate(object obj, DataReceivedEventArgs line)
			{
				string text = line.Data;
				if (text != null && (text = text.Trim()) != string.Empty)
				{
					output = output + text + "\n";
				}
			};
			process.Start();
			process.BeginOutputReadLine();
			process.WaitForExit(timeout);
			return output;
		}

		// Token: 0x06000994 RID: 2452 RVA: 0x000279A8 File Offset: 0x00025BA8
		private static Utils.CmdRes RunCmdInternal(string prog, string args, string outPath, bool enableLog, bool append = false)
		{
			StreamWriter writer = null;
			Process proc = new Process();
			Logger.Info("Running Command");
			Logger.Info("    prog: " + prog);
			Logger.Info("    args: " + args);
			Logger.Info("    out:  " + outPath);
			Utils.CmdRes res = new Utils.CmdRes();
			proc.StartInfo.FileName = prog;
			proc.StartInfo.Arguments = args;
			proc.StartInfo.UseShellExecute = false;
			proc.StartInfo.CreateNoWindow = true;
			if (outPath != null)
			{
				writer = new StreamWriter(outPath, append);
			}
			proc.StartInfo.RedirectStandardInput = true;
			proc.StartInfo.RedirectStandardOutput = true;
			proc.StartInfo.RedirectStandardError = true;
			proc.OutputDataReceived += delegate(object obj, DataReceivedEventArgs line)
			{
				if (outPath != null)
				{
					writer.WriteLine(line.Data);
				}
				string text = line.Data;
				if (text != null && (text = text.Trim()) != string.Empty)
				{
					if (enableLog)
					{
						Logger.Info(proc.Id + " OUT: " + text);
					}
					Utils.CmdRes res = res;
					res.StdOut = res.StdOut + text + "\n";
				}
			};
			proc.ErrorDataReceived += delegate(object obj, DataReceivedEventArgs line)
			{
				if (outPath != null)
				{
					writer.WriteLine(line.Data);
				}
				if (enableLog)
				{
					Logger.Error(proc.Id + " ERR: " + line.Data);
				}
				Utils.CmdRes res = res;
				res.StdErr = res.StdErr + line.Data + "\n";
			};
			proc.Start();
			proc.BeginOutputReadLine();
			proc.BeginErrorReadLine();
			proc.WaitForExit();
			res.ExitCode = proc.ExitCode;
			if (enableLog)
			{
				Logger.Info(proc.Id + " ExitCode: " + proc.ExitCode);
			}
			if (outPath != null)
			{
				writer.Close();
			}
			return res;
		}

		// Token: 0x06000995 RID: 2453 RVA: 0x00027B78 File Offset: 0x00025D78
		public static void RunCmdAsync(string prog, string args)
		{
			try
			{
				Utils.RunCmdAsyncInternal(prog, args);
			}
			catch (Exception ex)
			{
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x06000996 RID: 2454 RVA: 0x00027BAC File Offset: 0x00025DAC
		private static void RunCmdAsyncInternal(string prog, string args)
		{
			Process process = new Process();
			Logger.Info("Running Command Async");
			Logger.Info("    prog: " + prog);
			Logger.Info("    args: " + args);
			process.StartInfo.FileName = prog;
			process.StartInfo.Arguments = args;
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.CreateNoWindow = true;
			process.Start();
		}

		// Token: 0x06000997 RID: 2455 RVA: 0x00027C20 File Offset: 0x00025E20
		public static string GetPartnerExecutablePath()
		{
			string text = RegistryManager.Instance.PartnerExePath;
			if (string.IsNullOrEmpty(text))
			{
				text = Path.Combine(RegistryStrings.InstallDir, "BlueStacks.exe");
			}
			return text;
		}

		// Token: 0x06000998 RID: 2456 RVA: 0x00009C74 File Offset: 0x00007E74
		public static Process StartPartnerExe(string vm = "Android")
		{
			Process process = new Process();
			process.StartInfo.FileName = Utils.GetPartnerExecutablePath();
			process.StartInfo.Arguments = string.Format("-vmName={0}", vm);
			process.StartInfo.UseShellExecute = false;
			process.Start();
			return process;
		}

		// Token: 0x06000999 RID: 2457 RVA: 0x00009CB4 File Offset: 0x00007EB4
		public static bool RestartBlueStacks()
		{
			MessageBox.Show(string.Format("Application restart required to use internet on {0}", Strings.ProductDisplayName), Strings.ProductDisplayName, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			return true;
		}

		// Token: 0x0600099A RID: 2458 RVA: 0x00027C54 File Offset: 0x00025E54
		public static void GetGuestWidthAndHeight(int sWidth, int sHeight, out int width, out int height)
		{
			if (Oem.Instance.OEM.Equals("yoozoo"))
			{
				width = 1280;
				height = 720;
				return;
			}
			if (sWidth > 1920 && sHeight > 1080)
			{
				width = 1920;
				height = 1080;
				return;
			}
			if (sWidth < 1280 && sHeight < 720)
			{
				width = 1280;
				height = 720;
				return;
			}
			width = sWidth;
			height = sHeight;
		}

		// Token: 0x0600099B RID: 2459 RVA: 0x00027CCC File Offset: 0x00025ECC
		public static void GetWindowWidthAndHeight(out int width, out int height)
		{
			int width2 = Screen.PrimaryScreen.Bounds.Width;
			int height2 = Screen.PrimaryScreen.Bounds.Height;
			if (width2 > 1920 && height2 > 1080)
			{
				width = 1920;
				height = 1080;
				return;
			}
			if (width2 > 1600 && height2 > 900)
			{
				width = 1600;
				height = 900;
				return;
			}
			if (width2 > 1280 && height2 > 720)
			{
				width = 1280;
				height = 720;
				return;
			}
			width = 960;
			height = 540;
		}

		// Token: 0x0600099C RID: 2460 RVA: 0x00027D6C File Offset: 0x00025F6C
		public static void AddMessagingSupport(out Dictionary<string, string[]> oemWindowMapper)
		{
			oemWindowMapper = new Dictionary<string, string[]>();
			if (!string.IsNullOrEmpty(Oem.Instance.MsgWindowClassName) || !string.IsNullOrEmpty(Oem.Instance.MsgWindowTitle))
			{
				string[] value = new string[]
				{
					Oem.Instance.MsgWindowClassName,
					Oem.Instance.MsgWindowTitle
				};
				oemWindowMapper.Add(Oem.Instance.OEM, value);
			}
		}

		// Token: 0x0600099D RID: 2461 RVA: 0x00009CD4 File Offset: 0x00007ED4
		public static bool IsUIProcessAlive(string vmName)
		{
			return ProcessUtils.IsAlreadyRunning(Strings.GetPlayerLockName(vmName)) || ProcessUtils.IsAlreadyRunning("Global\\BlueStacks_BlueStacksUI_Lock");
		}

		// Token: 0x0600099E RID: 2462 RVA: 0x00009CF2 File Offset: 0x00007EF2
		public static bool IsAllUIProcessAlive(string vmName)
		{
			return ProcessUtils.IsAlreadyRunning(Strings.GetPlayerLockName(vmName)) && ProcessUtils.IsAlreadyRunning("Global\\BlueStacks_BlueStacksUI_Lock");
		}

		// Token: 0x0600099F RID: 2463 RVA: 0x00009D10 File Offset: 0x00007F10
		public static bool IsAndroidPlayerRunning(string vmName)
		{
			return ProcessUtils.IsAlreadyRunning(Strings.GetPlayerLockName(vmName));
		}

		// Token: 0x060009A0 RID: 2464 RVA: 0x00009D22 File Offset: 0x00007F22
		public static bool IsFileNullOrMissing(string file)
		{
			if (!File.Exists(file))
			{
				Logger.Info(file + " does not exist");
				return true;
			}
			if (new FileInfo(file).Length == 0L)
			{
				Logger.Info(file + " is null");
				return true;
			}
			return false;
		}

		// Token: 0x060009A1 RID: 2465 RVA: 0x00027DD8 File Offset: 0x00025FD8
		public static string GetUserGUID()
		{
			string text = null;
			string name = "Software\\\\BlueStacks";
			Logger.Info("Checking if guid present in HKCU");
			RegistryKey registryKey2;
			RegistryKey registryKey = registryKey2 = Registry.CurrentUser.OpenSubKey(name);
			try
			{
				if (registryKey != null)
				{
					text = (string)registryKey.GetValue("USER_GUID", null);
					if (text != null)
					{
						Logger.Info("Detected GUID in HKCU: " + text);
						return text;
					}
				}
			}
			finally
			{
				if (registryKey2 != null)
				{
					((IDisposable)registryKey2).Dispose();
				}
			}
			Logger.Info("Checking if guid present in HKLM");
			registryKey = (registryKey2 = Registry.LocalMachine.OpenSubKey(name));
			try
			{
				if (registryKey != null)
				{
					text = (string)registryKey.GetValue("USER_GUID", null);
					if (text != null)
					{
						Logger.Info("Detected User GUID in HKLM: " + text);
						return text;
					}
				}
			}
			finally
			{
				if (registryKey2 != null)
				{
					((IDisposable)registryKey2).Dispose();
				}
			}
			try
			{
				Logger.Info("Checking if guid present in %temp%");
				string environmentVariable = Environment.GetEnvironmentVariable("TEMP");
				Logger.Info("%TEMP% = " + environmentVariable);
				string path = Path.Combine(environmentVariable, "Bst_Guid_Backup");
				if (File.Exists(path))
				{
					string text2 = File.ReadAllText(path);
					if (!string.IsNullOrEmpty(text2))
					{
						text = text2;
						Logger.Info("Detected User GUID %temp%: " + text);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error(ex.ToString());
			}
			return text;
		}

		// Token: 0x060009A2 RID: 2466 RVA: 0x00027F34 File Offset: 0x00026134
		private static string GetOldPCode()
		{
			string path = Path.Combine(Environment.GetEnvironmentVariable("TEMP"), "Bst_PCode_Backup");
			string text = "";
			if (File.Exists(path))
			{
				text = File.ReadAllText(path);
				if (!string.IsNullOrEmpty(text))
				{
					Logger.Info(string.Format("Old PCode = {0}", text));
				}
				try
				{
					File.Delete(path);
				}
				catch (Exception ex)
				{
					Logger.Info(string.Format("Ignoring Error Occured, Err: {0}", ex.ToString()));
				}
			}
			return text;
		}

		// Token: 0x060009A3 RID: 2467 RVA: 0x00027FB8 File Offset: 0x000261B8
		private static bool IsCACodeValid(string caCode)
		{
			string[] array = new string[]
			{
				"4",
				"20",
				"5",
				"14",
				"8",
				"2",
				"9",
				"36"
			};
			for (int i = 0; i < array.Length; i++)
			{
				if (string.Compare(array[i], caCode, true) == 0)
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x060009A4 RID: 2468 RVA: 0x0002802C File Offset: 0x0002622C
		private static string GetOldCaCode()
		{
			string path = Path.Combine(Environment.GetEnvironmentVariable("TEMP"), "Bst_CaCode_Backup");
			string text = "";
			if (File.Exists(path))
			{
				Logger.Info("the ca code temp file exists");
				text = File.ReadAllText(path);
				if (!string.IsNullOrEmpty(text))
				{
					Logger.Info(string.Format("Old CaCode = {0}", text));
				}
				try
				{
					File.Delete(path);
				}
				catch (Exception ex)
				{
					Logger.Warning(string.Format("Error Occured, Err: {0}", ex.ToString()));
				}
			}
			if (!Utils.IsCACodeValid(text))
			{
				text = "";
			}
			return text;
		}

		// Token: 0x060009A5 RID: 2469 RVA: 0x000280C8 File Offset: 0x000262C8
		private static string GetOldCaSelector()
		{
			string path = Path.Combine(Environment.GetEnvironmentVariable("TEMP"), "Bst_CaSelector_Backup");
			string text = "";
			if (File.Exists(path))
			{
				Logger.Info("the ca selector temp file exists");
				text = File.ReadAllText(path);
				if (!string.IsNullOrEmpty(text))
				{
					Logger.Info(string.Format("Old CaSelector = {0}", text));
				}
				try
				{
					File.Delete(path);
				}
				catch (Exception ex)
				{
					Logger.Warning(string.Format("Error Occured, Err: {0}", ex.ToString()));
				}
			}
			return text;
		}

		// Token: 0x060009A6 RID: 2470 RVA: 0x00028154 File Offset: 0x00026354
		private static string GetRandomPCode()
		{
			string[] array = new string[]
			{
				"madw",
				"mtox",
				"optr",
				"pxln",
				"ofpn",
				"snpe",
				"segn",
				"ptxg"
			};
			int num = new Random().Next(array.Length);
			return array[num];
		}

		// Token: 0x060009A7 RID: 2471 RVA: 0x000281BC File Offset: 0x000263BC
		public static JObject JSonResponseFromCloud(string locale, string vmName, string campaignHash, string guid)
		{
			string url = string.Format("{0}/{1}", RegistryManager.Instance.Host, "api/getcacode");
			if (string.IsNullOrEmpty(guid))
			{
				guid = RegistryManager.Instance.UserGuid;
				campaignHash = RegistryManager.Instance.CampaignMD5;
			}
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary.Add("locale", locale);
			dictionary.Add("guid", guid);
			dictionary.Add("campaign_hash", campaignHash);
			string text = "";
			try
			{
				text = BstHttpClient.Post(url, dictionary, null, false, vmName, 0, 1, 0, false);
			}
			catch (Exception ex)
			{
				Logger.Error("An error occured while fetching info from cloud...Err : " + ex.ToString());
			}
			Logger.Info("Got resp: " + text);
			return JObject.Parse(text);
		}

		// Token: 0x060009A8 RID: 2472 RVA: 0x00028284 File Offset: 0x00026484
		public static void GetCodesAndCountryInfo(out string code, out string pcode, out string country, out string caSelector, out string noChangesDroidG, out string pcodeFromCloud, string locale, string upgradeDetected, string vmName, string campaignHash = "", string guid = "")
		{
			code = "";
			pcode = "";
			country = "";
			caSelector = "";
			noChangesDroidG = "";
			pcodeFromCloud = "";
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("Software");
			string text = (string)registryKey.GetValue("BstTestCA", "");
			string text2 = (string)registryKey.GetValue("BstTestPCode", "");
			string text3 = (string)registryKey.GetValue("BstTestCaSelector", "");
			string text4 = (string)registryKey.GetValue("BstTestNoChangesDroidG", "");
			if (text != "" && text2 != "")
			{
				Logger.Info("Using test CA/P codes");
				code = text;
				pcode = text2;
				caSelector = text3;
				noChangesDroidG = text4;
			}
			else
			{
				string oldPCode = Utils.GetOldPCode();
				string oldCaCode = Utils.GetOldCaCode();
				string oldCaSelector = Utils.GetOldCaSelector();
				if (oldCaCode != "")
				{
					Logger.Info("The CaCode taken from temp file");
					code = oldCaCode;
					pcode = oldPCode;
					caSelector = oldCaSelector;
					if (!Oem.Instance.IsLoadCACodeFromCloud)
					{
						goto IL_3C3;
					}
					Logger.Info("noChangesDroidG requested from cloud");
					try
					{
						JObject jobject = Utils.JSonResponseFromCloud(locale, vmName, campaignHash, guid);
						if (jobject["success"].ToString().Trim() == "true")
						{
							if (jobject.ToString().Contains("p_code"))
							{
								pcodeFromCloud = jobject["p_code"].ToString().Trim();
							}
							if (jobject.ToString().Contains("no_changes_droidg"))
							{
								noChangesDroidG = jobject["no_changes_droidg"].ToString().Trim();
							}
							if (caSelector == "" && upgradeDetected == "" && jobject.ToString().Contains("ca_selector"))
							{
								caSelector = jobject["ca_selector"].ToString().Trim();
							}
						}
						goto IL_3C3;
					}
					catch (Exception ex)
					{
						Logger.Error(ex.Message);
						goto IL_3C3;
					}
				}
				if (Oem.Instance.IsLoadCACodeFromCloud)
				{
					try
					{
						JObject jobject2 = Utils.JSonResponseFromCloud(locale, vmName, campaignHash, guid);
						if (jobject2["success"].ToString().Trim().Equals("true", StringComparison.InvariantCultureIgnoreCase))
						{
							code = jobject2["code"].ToString().Trim();
							if (jobject2.ToString().Contains("p_code"))
							{
								pcodeFromCloud = jobject2["p_code"].ToString().Trim();
							}
							if (upgradeDetected == "")
							{
								pcode = pcodeFromCloud;
							}
							else
							{
								pcode = "";
							}
							if (jobject2.ToString().Contains("ca_selector"))
							{
								caSelector = jobject2["ca_selector"].ToString().Trim();
							}
							if (jobject2.ToString().Contains("no_changes_droidg"))
							{
								noChangesDroidG = jobject2["no_changes_droidg"].ToString().Trim();
							}
						}
						else
						{
							pcode = "ofpn";
							code = "840";
							caSelector = "se_310260";
							Logger.Info("Setting default pcode = {0} cacode = {1} caselector = {2} ", new object[]
							{
								pcode,
								code,
								caSelector
							});
						}
						goto IL_3C3;
					}
					catch (Exception ex2)
					{
						Logger.Error("Failed to get cacode, pcode etc from cloud");
						Logger.Error(ex2.Message);
						pcode = "ofpn";
						code = "840";
						caSelector = "se_310260";
						Logger.Info("Setting default pcode = {0} cacode = {1} caselector = {2} ", new object[]
						{
							pcode,
							code,
							caSelector
						});
						goto IL_3C3;
					}
				}
				if (upgradeDetected == "")
				{
					pcode = Utils.GetRandomPCode();
				}
				else
				{
					pcode = "";
				}
				code = "156";
				Logger.Info("cacode = {0} and pcode = {1}", new object[]
				{
					code,
					pcode
				});
			}
			IL_3C3:
			if (Oem.Instance.IsCountryChina)
			{
				country = "CN";
				caSelector = "se_46000";
				return;
			}
			country = Utils.GetUserCountry(vmName);
		}

		// Token: 0x060009A9 RID: 2473 RVA: 0x000286AC File Offset: 0x000268AC
		public static bool IsAndroidFeatureBitEnabled(uint featureBit, string vmName)
		{
			try
			{
				string bootParameters = RegistryManager.Instance.Guest[vmName].BootParameters;
				uint num = 0U;
				string[] array = bootParameters.Split(new char[]
				{
					' '
				});
				for (int i = 0; i < array.Length; i++)
				{
					string[] array2 = array[i].Split(new char[]
					{
						'='
					});
					if (array2[0] == "OEMFEATURES")
					{
						num = Convert.ToUInt32(array2[1]);
						break;
					}
				}
				Logger.Info("the android oem feature bits are" + num.ToString());
				if ((num & featureBit) == 0U)
				{
					return false;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Got error while checking for android bit, err:{0}", new object[]
				{
					ex.ToString()
				});
				return false;
			}
			return true;
		}

		// Token: 0x060009AA RID: 2474 RVA: 0x00009D5E File Offset: 0x00007F5E
		public static void SetImeSelectedInReg(string imeSelected, string vmName)
		{
			RegistryManager.Instance.Guest[vmName].ImeSelected = imeSelected;
		}

		// Token: 0x060009AB RID: 2475 RVA: 0x00028774 File Offset: 0x00026974
		public static bool IsLatinImeSelected(string vmName)
		{
			string text = RegistryManager.Instance.Guest[vmName].ImeSelected;
			if (text.Equals("com.android.inputmethod.latin/.LatinIME", StringComparison.CurrentCultureIgnoreCase))
			{
				Logger.Info("LatinIme is selected");
				return true;
			}
			if (text == "")
			{
				try
				{
					Logger.Info("IME selected in registry is null, query currentImeId");
					string text2 = HTTPUtils.SendRequestToGuest("getCurrentIMEID", null, vmName, 5000, null, false, 1, 0);
					Logger.Debug("Response: {0}", new object[]
					{
						text2
					});
					text = JObject.Parse(text2)["currentIme"].ToString();
					Logger.Info("The currentIme: {0}", new object[]
					{
						text
					});
					if (text.Equals("com.android.inputmethod.latin/.LatinIME", StringComparison.CurrentCultureIgnoreCase))
					{
						Utils.SetImeSelectedInReg(text, vmName);
						return true;
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Got exception in checking CurrentImeSelected, ex : {0}", new object[]
					{
						ex.ToString()
					});
				}
				return false;
			}
			return false;
		}

		// Token: 0x060009AC RID: 2476 RVA: 0x00009D76 File Offset: 0x00007F76
		public static bool IsForcePcImeForLang(string locale)
		{
			if (locale.Equals("vi-VN"))
			{
				Logger.Info("the system locale is vi-vn, using pcime workflow");
				return true;
			}
			return false;
		}

		// Token: 0x060009AD RID: 2477 RVA: 0x00009D92 File Offset: 0x00007F92
		public static bool IsEastAsianLanguage(string lang)
		{
			return new List<string>
			{
				"zh-CN",
				"ja-JP",
				"ko-KR"
			}.Contains(lang);
		}

		// Token: 0x060009AE RID: 2478 RVA: 0x0002886C File Offset: 0x00026A6C
		public static bool WaitForSyncConfig(string vmName)
		{
			int i = 240;
			while (i > 0)
			{
				i--;
				if (RegistryManager.Instance.Guest[vmName].ConfigSynced != 0)
				{
					Logger.Info("Config is synced now");
					return true;
				}
				Logger.Info("Config not sycned, wait 1 second and try again");
				Thread.Sleep(1000);
			}
			return false;
		}

		// Token: 0x060009AF RID: 2479 RVA: 0x000288C4 File Offset: 0x00026AC4
		public static bool WaitForFrontendPingResponse(string vmName)
		{
			Logger.Info("In method WaitForFrontendPingResponse for vmName: " + vmName);
			int i = 50;
			while (i > 0)
			{
				i--;
				try
				{
					string text = HTTPUtils.SendRequestToEngine("pingVm", null, vmName, 1000, null, false, 1, 0, "");
					Logger.Debug("Response: " + text);
					if ((JArray.Parse(text)[0] as JObject)["success"].ToObject<bool>())
					{
						Logger.Info("Frontend server running");
						return true;
					}
					Thread.Sleep(1000);
				}
				catch (Exception)
				{
					Thread.Sleep(1000);
				}
			}
			Logger.Error("Frontend server not running after {0} retries", new object[]
			{
				i
			});
			return false;
		}

		// Token: 0x060009B0 RID: 2480 RVA: 0x00028990 File Offset: 0x00026B90
		public static bool WaitForAgentPingResponse(string vmName)
		{
			Logger.Info("In WaitForAgentPingResponse");
			int i = 50;
			while (i > 0)
			{
				i--;
				try
				{
					HTTPUtils.SendRequestToAgent("ping", null, vmName, 1000, null, false, 1, 0);
					Logger.Info("Agent server running");
					return true;
				}
				catch (Exception)
				{
					Thread.Sleep(1000);
					if (i <= 40 && !ProcessUtils.IsLockInUse("Global\\BlueStacks_HDAgent_Lock"))
					{
						return false;
					}
				}
			}
			Logger.Info("Agent server not running after {0} retries", new object[]
			{
				i
			});
			return false;
		}

		// Token: 0x060009B1 RID: 2481 RVA: 0x00009DC5 File Offset: 0x00007FC5
		public static bool WaitForBootComplete(string vmName)
		{
			return Utils.WaitForBootComplete(vmName, 180);
		}

		// Token: 0x060009B2 RID: 2482 RVA: 0x00028A28 File Offset: 0x00026C28
		public static bool WaitForBootComplete(string vmName, int retries)
		{
			if (!Utils.VmLockNamedata.ContainsKey(vmName))
			{
				Utils.VmLockNamedata.Add(vmName, new object());
			}
			if (!Utils.sIsGuestBooted.ContainsKey(vmName))
			{
				Utils.sIsGuestBooted.Add(vmName, false);
			}
			object obj = Utils.VmLockNamedata[vmName];
			lock (obj)
			{
				Utils.sIsWaitLockExist = true;
				Logger.Info("Checking if guest booted or not for {0} retries", new object[]
				{
					retries
				});
				while (retries > 0)
				{
					retries--;
					Utils.IsGuestBooted(vmName);
					if (Utils.sIsGuestBooted[vmName])
					{
						Utils.sIsWaitLockExist = false;
						return true;
					}
					Thread.Sleep(1000);
				}
				Logger.Info("Guest not booted after {0} retries", new object[]
				{
					retries
				});
				Utils.sIsWaitLockExist = false;
			}
			return false;
		}

		// Token: 0x060009B3 RID: 2483 RVA: 0x00028B0C File Offset: 0x00026D0C
		public static bool IsSharedFolderMounted(string vmName)
		{
			try
			{
				if (!Utils.sIsSharedFolderMounted.ContainsKey(vmName))
				{
					Utils.sIsSharedFolderMounted.Add(vmName, false);
				}
				if (!Utils.sIsSharedFolderMounted[vmName] && JObject.Parse(HTTPUtils.SendRequestToGuest("isSharedFolderMounted", null, vmName, 1000, null, false, 1, 0))["result"].ToString().Equals("ok", StringComparison.InvariantCultureIgnoreCase))
				{
					Utils.sIsSharedFolderMounted[vmName] = true;
					return true;
				}
			}
			catch (Exception ex)
			{
				Logger.Info("shared folder not mounted yet." + ex.Message);
			}
			return Utils.sIsSharedFolderMounted[vmName];
		}

		// Token: 0x060009B4 RID: 2484 RVA: 0x00028BBC File Offset: 0x00026DBC
		public static bool IsGuestBooted(string vmName)
		{
			try
			{
				if (!Utils.sIsGuestBooted.ContainsKey(vmName))
				{
					Utils.sIsGuestBooted.Add(vmName, false);
				}
				if (!Utils.sIsGuestBooted[vmName])
				{
					HTTPUtils.SendRequestToGuest("ping", null, vmName, 1000, null, false, 1, 0);
					Utils.sIsGuestBooted[vmName] = true;
					return true;
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Guest not booted yet." + ex.Message);
			}
			return Utils.sIsGuestBooted[vmName];
		}

		// Token: 0x060009B5 RID: 2485 RVA: 0x00009DD2 File Offset: 0x00007FD2
		public static void AddGuestBootCallBack(EventHandler agent_GuestBooted, string vmName)
		{
			if (Utils.IsGuestBooted(vmName))
			{
				agent_GuestBooted(null, new EventArgs());
				return;
			}
			Utils.GuestBootCallBack += agent_GuestBooted;
			Utils.CheckIfGuestReadyAndCallBack(vmName);
		}

		// Token: 0x060009B6 RID: 2486 RVA: 0x00028C4C File Offset: 0x00026E4C
		private static void CheckIfGuestReadyAndCallBack(string vmName)
		{
			try
			{
				if (!Utils.waitingForCallback)
				{
					Utils.waitingForCallback = true;
					if (Utils.WaitForBootComplete(vmName, 2147483647) && Utils.GuestBootCallBack != null)
					{
						Utils.GuestBootCallBack(null, new EventArgs());
						Utils.GuestBootCallBack = null;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in CheckIfGuestReadyAndCallBack " + ex.ToString());
			}
		}

		// Token: 0x060009B7 RID: 2487 RVA: 0x00028CBC File Offset: 0x00026EBC
		public static void ExtractImages(string targetDir, string resourceName)
		{
			try
			{
				Directory.Delete(targetDir, true);
			}
			catch (Exception)
			{
			}
			if (!Directory.Exists(targetDir))
			{
				Directory.CreateDirectory(targetDir);
			}
			ResourceManager resourceManager;
			try
			{
				resourceManager = new ResourceManager(resourceName, Assembly.GetExecutingAssembly());
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to extract resources. err: " + ex.ToString());
				return;
			}
			System.Drawing.Image image = (System.Drawing.Image)resourceManager.GetObject("bg");
			image.Save(Path.Combine(targetDir, "bg.jpg"), ImageFormat.Jpeg);
			bool flag = true;
			try
			{
				image = (System.Drawing.Image)resourceManager.GetObject("HomeScreen");
				image.Save(Path.Combine(targetDir, "HomeScreen.jpg"), ImageFormat.Jpeg);
			}
			catch (Exception)
			{
				flag = false;
			}
			try
			{
				image = (System.Drawing.Image)resourceManager.GetObject("ThankYouImage");
				image.Save(Path.Combine(targetDir, "ThankYouImage.jpg"), ImageFormat.Jpeg);
			}
			catch (Exception)
			{
			}
			int num = 0;
			try
			{
				for (;;)
				{
					num++;
					image = (System.Drawing.Image)resourceManager.GetObject("SetupImage" + Convert.ToString(num));
					image.Save(Path.Combine(targetDir, "SetupImage" + Convert.ToString(num) + ".jpg"), ImageFormat.Jpeg);
					if (!flag && num == 1)
					{
						image.Save(Path.Combine(targetDir, "HomeScreen.jpg"), ImageFormat.Jpeg);
					}
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x060009B8 RID: 2488 RVA: 0x00028E40 File Offset: 0x00027040
		public static string DownloadIcon(string package, string directory = "", bool isReDownload = false)
		{
			string url = string.Format("https://cloud.bluestacks.com/app/icon?pkg={0}&fallback=false", package);
			string fileNameWithExtension = package + ".png";
			return Utils.TinyDownloader(url, fileNameWithExtension, directory, isReDownload);
		}

		// Token: 0x060009B9 RID: 2489 RVA: 0x00028E6C File Offset: 0x0002706C
		public static string TinyDownloader(string url, string fileNameWithExtension, string directory = "", bool isReDownload = false)
		{
			string text = string.Empty;
			try
			{
				if (!string.IsNullOrEmpty(url) && !string.IsNullOrEmpty(fileNameWithExtension))
				{
					string path = Regex.Replace(fileNameWithExtension, "[\\x22\\\\\\/:*?|<>]", " ");
					if (string.IsNullOrEmpty(directory))
					{
						directory = RegistryStrings.GadgetDir;
					}
					text = Path.Combine(directory, path);
					if (!Directory.Exists(Directory.GetParent(text).FullName))
					{
						Directory.CreateDirectory(Directory.GetParent(text).FullName);
					}
					if (!File.Exists(text) || isReDownload)
					{
						using (WebClient webClient = new WebClient())
						{
							webClient.DownloadFile(url, text);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Cannot download icon file" + ex.ToString());
			}
			return text;
		}

		// Token: 0x060009BA RID: 2490 RVA: 0x00028F38 File Offset: 0x00027138
		public static string GetDNS2Value(string oem)
		{
			string result = "8.8.8.8";
			if (string.Compare(oem, "tc_dt", true) == 0 || string.Compare(oem, "china", true) == 0 || string.Compare(oem, "china_api", true) == 0 || string.Compare(oem, "ucweb_dt", true) == 0 || string.Compare(oem, "4399", true) == 0 || string.Compare(oem, "anquicafe", true) == 0 || string.Compare(oem, "yy_dt", true) == 0)
			{
				result = "114.114.114.114";
			}
			return result;
		}

		// Token: 0x060009BB RID: 2491 RVA: 0x00028FB4 File Offset: 0x000271B4
		public static bool IsInstallOrUpgradeRequired()
		{
			if (!Utils.IsBlueStacksInstalled())
			{
				return true;
			}
			string version = RegistryManager.Instance.Version;
			if (string.IsNullOrEmpty(version))
			{
				return true;
			}
			string version2 = version.Substring(0, version.LastIndexOf('.')) + ".0";
			string version3 = "4.140.12.1002".Substring(0, "4.140.12.1002".LastIndexOf('.')) + ".0";
			Version v = new Version(version2);
			Version v2 = new Version(version3);
			Logger.Info("Installed Version: {0}, new version: {1}", new object[]
			{
				version,
				"4.140.12.1002"
			});
			if (v2 > v)
			{
				Logger.Info("IMP: lower version: {0} is already installed. Forcing upgrade.", new object[]
				{
					version
				});
				return true;
			}
			return false;
		}

		// Token: 0x060009BC RID: 2492 RVA: 0x00009DF5 File Offset: 0x00007FF5
		public static void SendBrowserVersionStats(string version, string vmName)
		{
			new Thread(delegate()
			{
				try
				{
					string userGuid = RegistryManager.Instance.UserGuid;
					string url = "https://bluestacks-cloud.appspot.com/stats/ieversionstats";
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					dictionary.Add("ie_ver", version);
					dictionary.Add("guid", userGuid);
					dictionary.Add("prod_ver", "4.140.12.1002");
					Logger.Info("Sending browser version Stats");
					string text = BstHttpClient.Post(url, dictionary, null, false, vmName, 0, 1, 0, false);
					Logger.Info("Got browser version stat response: {0}", new object[]
					{
						text
					});
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to send app stats. error: " + ex.ToString());
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060009BD RID: 2493 RVA: 0x00029068 File Offset: 0x00027268
		public static bool IsRemoteFilePresent(string url)
		{
			bool result = true;
			HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
			httpWebRequest.Method = "Head";
			try
			{
				HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
				if (httpWebResponse.StatusCode == HttpStatusCode.NotFound)
				{
					result = false;
				}
				httpWebResponse.Close();
			}
			catch (Exception ex)
			{
				result = false;
				Logger.Error("Could not make http request: " + ex.ToString());
			}
			return result;
		}

		// Token: 0x060009BE RID: 2494 RVA: 0x000290DC File Offset: 0x000272DC
		public static string ConvertToIco(string imagePath, string iconsDir)
		{
			Logger.Info("Converting {0}", new object[]
			{
				imagePath
			});
			string fileName = Path.GetFileName(imagePath);
			int length = fileName.LastIndexOf(".");
			string path = fileName.Substring(0, length) + ".ico";
			string text = Path.Combine(iconsDir, path);
			IconHelper.ConvertToIcon(imagePath, text, 256, false);
			return text;
		}

		// Token: 0x060009BF RID: 2495 RVA: 0x00029138 File Offset: 0x00027338
		public static void ResizeImage(string imagePath)
		{
			bool flag = false;
			using (FileStream fileStream = File.OpenRead(imagePath))
			{
				using (System.Drawing.Image image = System.Drawing.Image.FromStream(fileStream))
				{
					int num = image.Width;
					int num2 = image.Height;
					if (num >= 256)
					{
						int num3 = 256;
						num2 = (int)((float)num2 / ((float)num / (float)num3));
						num = num3;
						flag = true;
					}
					if (num2 >= 256)
					{
						int num4 = 256;
						num = (int)((float)num / ((float)num2 / (float)num4));
						num2 = num4;
						flag = true;
					}
					if (num % 8 != 0)
					{
						num -= num % 8;
						flag = true;
					}
					if (num2 % 8 != 0)
					{
						num2 -= num2 % 8;
						flag = true;
					}
					if (flag)
					{
						using (System.Drawing.Image image2 = new Bitmap(num, num2))
						{
							Graphics graphics = Graphics.FromImage(image2);
							graphics.SmoothingMode = SmoothingMode.AntiAlias;
							graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
							graphics.DrawImage(image, 0, 0, image2.Width, image2.Height);
							File.Delete(imagePath);
							image2.Save(imagePath);
						}
					}
				}
			}
		}

		// Token: 0x060009C0 RID: 2496 RVA: 0x00009E26 File Offset: 0x00008026
		public static int GetSystemHeight()
		{
			return Utils.GetSystemMetrics(1);
		}

		// Token: 0x060009C1 RID: 2497 RVA: 0x00009E2E File Offset: 0x0000802E
		public static int GetSystemWidth()
		{
			return Utils.GetSystemMetrics(0);
		}

		// Token: 0x060009C2 RID: 2498 RVA: 0x00009E36 File Offset: 0x00008036
		public static int GetBstCommandProcessorPort(string vmName)
		{
			return RegistryManager.Instance.Guest[vmName].BstAndroidPort;
		}

		// Token: 0x060009C3 RID: 2499 RVA: 0x00009E4D File Offset: 0x0000804D
		public static bool IsHomeApp(string appInfo)
		{
			return appInfo.IndexOf("com.bluestacks.appmart") != -1 || appInfo.IndexOf("com.android.launcher2") != -1 || appInfo.IndexOf("com.uncube.launcher") != -1 || appInfo.IndexOf("com.bluestacks.gamepophome") != -1;
		}

		// Token: 0x060009C4 RID: 2500 RVA: 0x00009E8A File Offset: 0x0000808A
		public static bool IsValidEmail(string email)
		{
			return new Regex("^(([^<>()[\\]\\\\.,;:\\s@\\\"]+(\\.[^<>()[\\]\\\\.,;:\\s@\\\"]+)*)|(\\\".+\\\"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$").IsMatch(email);
		}

		// Token: 0x060009C5 RID: 2501 RVA: 0x00009E9C File Offset: 0x0000809C
		public static string GetFileURI(string path)
		{
			return new Uri(path).AbsoluteUri;
		}

		// Token: 0x060009C6 RID: 2502 RVA: 0x00029258 File Offset: 0x00027458
		public static string PostToBstCmdProcessorAfterServiceStart(string path, Dictionary<string, string> data, string vmName, bool isLaunchUI = true)
		{
			string result = null;
			if (!Utils.IsAllUIProcessAlive(vmName) && isLaunchUI)
			{
				Logger.Info("Starting Frontend in hidden mode.");
				Utils.StartHiddenFrontend(vmName);
			}
			int retries = 180;
			if (!Utils.CheckIfGuestReady(vmName, retries))
			{
				return new JArray
				{
					new JObject
					{
						{
							"result",
							"error"
						},
						{
							"reason",
							"Guest boot failed"
						}
					}
				}.ToString(Formatting.None, new JsonConverter[0]);
			}
			int bstCommandProcessorPort = Utils.GetBstCommandProcessorPort(vmName);
			Logger.Info("HTTPHandler: Sending post request to http://127.0.0.1:{0}/{1}", new object[]
			{
				bstCommandProcessorPort,
				path
			});
			string.Format("http://127.0.0.1:{0}/{1}", bstCommandProcessorPort, path);
			try
			{
				result = HTTPUtils.SendRequestToGuest(path, data, vmName, 0, null, false, 1, 0);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in PostAfterServiceStart");
				Logger.Error(ex.Message);
			}
			return result;
		}

		// Token: 0x060009C7 RID: 2503 RVA: 0x0002934C File Offset: 0x0002754C
		public static string GetToBstCmdProcessorAfterServiceStart(string path, string vmName)
		{
			string result = null;
			if (!Utils.IsUIProcessAlive(vmName))
			{
				Logger.Info("Starting Frontend in hidden mode.");
				Utils.StartHiddenFrontend(vmName).WaitForExit(60000);
			}
			try
			{
				result = HTTPUtils.SendRequestToGuest(path, null, vmName, 0, null, false, 1, 0);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GetToBstCmdProcessorAfterServiceStart");
				Logger.Error(ex.Message);
			}
			return result;
		}

		// Token: 0x060009C8 RID: 2504 RVA: 0x000293B8 File Offset: 0x000275B8
		public static bool IsAppInstalled(string package, string vmName, out string version)
		{
			string text = "";
			version = "";
			return Utils.IsAppInstalled(package, vmName, out version, out text, true);
		}

		// Token: 0x060009C9 RID: 2505 RVA: 0x000293E0 File Offset: 0x000275E0
		public static bool IsAppInstalled(string package, string vmName, out string version, out string failReason, bool isLaunchUI = true)
		{
			Logger.Info("Utils: IsAppInstalled Called for package {0}", new object[]
			{
				package
			});
			version = "";
			failReason = "App not installed";
			bool flag = false;
			try
			{
				string text = Utils.PostToBstCmdProcessorAfterServiceStart("isPackageInstalled", new Dictionary<string, string>
				{
					{
						"package",
						package
					}
				}, vmName, isLaunchUI);
				Logger.Info("Got response: {0}", new object[]
				{
					text
				});
				if (string.IsNullOrEmpty(text))
				{
					failReason = "The Api failed to get a response";
				}
				else
				{
					JObject jobject = JObject.Parse(text);
					string strA = jobject["result"].ToString().Trim();
					if (string.Compare(strA, "ok", true) == 0)
					{
						flag = true;
						version = jobject["version"].ToString().Trim();
					}
					else if (string.Compare(strA, "error", true) == 0)
					{
						failReason = jobject["reason"].ToString().Trim();
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error(string.Format("Error Occured, Err: {0}", ex.ToString()));
				failReason = ex.Message;
			}
			Logger.Info("Installed = {0}", new object[]
			{
				flag
			});
			return flag;
		}

		// Token: 0x060009CA RID: 2506 RVA: 0x00029514 File Offset: 0x00027714
		private static string FilterSystemApps(JArray packages, out bool isSamsungStorePresent)
		{
			isSamsungStorePresent = false;
			JArray jarray = new JArray();
			foreach (JObject jobject in packages.Children<JObject>())
			{
				if (jobject["package"].ToString().Trim().Equals("com.sec.android.app.samsungapps", StringComparison.Ordinal))
				{
					isSamsungStorePresent = true;
				}
				if (string.Compare(jobject["systemapp"].ToString().Trim(), "0") == 0)
				{
					bool flag = true;
					for (int i = 0; i < Utils.sListIgnoredApps.Count; i++)
					{
						if (string.Compare(jobject["package"].ToString().Trim(), Utils.sListIgnoredApps[i], true) == 0)
						{
							flag = false;
							break;
						}
					}
					if (flag)
					{
						jarray.Add(new JObject
						{
							{
								"package",
								jobject["package"].ToString().Trim()
							},
							{
								"version",
								jobject["version"].ToString().Trim()
							},
							{
								"appname",
								jobject["appname"].ToString().Trim()
							},
							{
								"gl3required",
								jobject["gl3required"].ToString().Trim()
							}
						});
					}
				}
			}
			return jarray.ToString(Formatting.None, new JsonConverter[0]);
		}

		// Token: 0x060009CB RID: 2507 RVA: 0x000296C8 File Offset: 0x000278C8
		public static string GetInstalledPackages(string vmName, out string failReason, out bool isSamsungStorePresent, int count = 0)
		{
			Logger.Info("Utils: GetInstalledPackages Called for VM: {0}", new object[]
			{
				vmName
			});
			failReason = "Unable to get list of installed apps";
			isSamsungStorePresent = false;
			string text = "";
			try
			{
				string toBstCmdProcessorAfterServiceStart = Utils.GetToBstCmdProcessorAfterServiceStart("installedPackages", vmName);
				Logger.Info("Got response: {0}", new object[]
				{
					toBstCmdProcessorAfterServiceStart
				});
				if (string.IsNullOrEmpty(toBstCmdProcessorAfterServiceStart))
				{
					failReason = "The Api failed to get a response";
				}
				else
				{
					JObject jobject = JObject.Parse(toBstCmdProcessorAfterServiceStart);
					string strA = jobject["result"].ToString().Trim();
					if (string.Compare(strA, "ok", true) == 0)
					{
						failReason = "";
						text = Utils.FilterSystemApps(jobject["installed_packages"] as JArray, out isSamsungStorePresent);
						Logger.Info("Filtered results: {0}", new object[]
						{
							text
						});
					}
					else if (string.Compare(strA, "error", true) == 0)
					{
						failReason = jobject["reason"].ToString().Trim();
						if (string.Compare(failReason, "system not ready", true) == 0 && count < 6)
						{
							Thread.Sleep(500);
							return Utils.GetInstalledPackages(vmName, out failReason, out isSamsungStorePresent, count++);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error(string.Format("Error Occurred, Err: {0}", ex.ToString()));
				failReason = ex.Message;
			}
			return text;
		}

		// Token: 0x060009CC RID: 2508 RVA: 0x0002981C File Offset: 0x00027A1C
		public static string GetInstalledPackagesFromAppsJSon(string vmName)
		{
			try
			{
				List<string> installedAppsList = JsonParser.GetInstalledAppsList(vmName);
				return string.Join(",", installedAppsList.ToArray());
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't get installed app list. Ex: {0}", new object[]
				{
					ex
				});
			}
			return "";
		}

		// Token: 0x060009CD RID: 2509 RVA: 0x00029874 File Offset: 0x00027A74
		public static AppInfo GetPackageDetails(string vmName, string package, bool videoPresent, out string failReason)
		{
			AppInfo result = null;
			try
			{
				string text = Utils.PostToBstCmdProcessorAfterServiceStart("getPackageDetails", new Dictionary<string, string>
				{
					{
						"package",
						package
					}
				}, vmName, true);
				if (string.IsNullOrEmpty(text))
				{
					failReason = "The api failed to get a response";
				}
				else
				{
					JObject jobject = JObject.Parse(text);
					if (string.Compare(jobject["result"].ToString().Trim(), "ok", true) == 0)
					{
						failReason = "";
						JArray jarray = JArray.Parse(jobject["activities"].ToString());
						result = new AppInfo(jobject["name"].ToString().Trim(), jarray[0]["img"].ToString().Trim(), jobject["package"].ToString().Trim(), (jarray[0] as JObject)["activity"].ToString().Trim(), "0", "no", jobject["version"].ToString().Trim(), jobject["gl3required"].ToObject<bool>(), videoPresent, jobject["versionName"].ToString().Trim());
					}
					else
					{
						failReason = "The api failed to get a response";
					}
				}
			}
			catch (Exception ex)
			{
				failReason = ex.Message;
			}
			return result;
		}

		// Token: 0x060009CE RID: 2510 RVA: 0x000299E4 File Offset: 0x00027BE4
		public static void SyncAppJson(string vmName)
		{
			Logger.Info("In SyncAppJson");
			if (Utils.sIsSyncAppJsonComplete)
			{
				return;
			}
			try
			{
				string value;
				bool flag;
				string installedPackages = Utils.GetInstalledPackages(vmName, out value, out flag, 0);
				if (flag && !RegistryManager.Instance.IsSamsungStorePresent)
				{
					RegistryManager.Instance.IsSamsungStorePresent = true;
					HTTPUtils.SendRequestToClient("reloadPromotions", null, vmName, 0, null, false, 1, 0);
				}
				if (string.IsNullOrEmpty(value))
				{
					JArray jarray = JArray.Parse(installedPackages);
					JsonParser jsonParser = new JsonParser(vmName);
					AppInfo[] appList = jsonParser.GetAppList();
					List<AppInfo> list = appList.ToList<AppInfo>();
					bool flag2 = false;
					bool videoPresent = false;
					using (IEnumerator<JObject> enumerator = jarray.Children<JObject>().GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							JObject installedAppsJsonObj = enumerator.Current;
							string package = installedAppsJsonObj["package"].ToString().Trim();
							if (jsonParser.GetAppInfoFromPackageName(package) != null)
							{
								if (!string.Equals(jsonParser.GetGl3RequirementFromPackage(appList, package).ToString().ToLower().Trim(), installedAppsJsonObj["gl3required"].ToString().ToLower().Trim()))
								{
									flag2 = true;
									(from x in list
									where x.package == package
									select x).FirstOrDefault<AppInfo>().gl3required = installedAppsJsonObj["gl3required"].ToObject<bool>();
								}
								videoPresent = jsonParser.GetVideoPresentRequirementFromPackage(appList, package);
								AppInfo appInfo2 = (from x in list
								where x.package == package
								select x).FirstOrDefault<AppInfo>();
								try
								{
									appInfo2.videopresent = installedAppsJsonObj["videopresent"].ToObject<bool>();
								}
								catch
								{
								}
							}
							if (!appList.Any((AppInfo _) => string.Compare(_.package.Trim(), installedAppsJsonObj["package"].ToString().Trim(), true) == 0))
							{
								flag2 = true;
								AppInfo packageDetails = Utils.GetPackageDetails(vmName, installedAppsJsonObj["package"].ToString().Trim(), videoPresent, out value);
								if (packageDetails != null)
								{
									list.Add(packageDetails);
								}
							}
						}
					}
					if (jarray.Count != list.Count || flag2)
					{
						List<string> list2 = new List<string>();
						using (List<AppInfo>.Enumerator enumerator2 = list.GetEnumerator())
						{
							while (enumerator2.MoveNext())
							{
								AppInfo appInfo = enumerator2.Current;
								if (!jarray.Children<JObject>().Any((JObject _) => string.Compare(_["package"].ToString().Trim(), appInfo.package.Trim(), true) == 0))
								{
									list2.Add(appInfo.package);
									flag2 = true;
								}
							}
						}
						using (List<string>.Enumerator enumerator3 = list2.GetEnumerator())
						{
							while (enumerator3.MoveNext())
							{
								string package = enumerator3.Current;
								list.RemoveAll((AppInfo _) => _.package == package);
							}
						}
						if (appList.Count<AppInfo>() != list.Count)
						{
							flag2 = true;
							list = new List<AppInfo>(jarray.Count);
							foreach (JObject jobject in jarray.Children<JObject>())
							{
								AppInfo packageDetails2 = Utils.GetPackageDetails(vmName, jobject["package"].ToString().Trim(), false, out value);
								if (packageDetails2 != null)
								{
									list.Add(packageDetails2);
								}
							}
							Logger.Info("Updating App Json from apps received from android. Details: " + installedPackages);
						}
					}
					if (flag2)
					{
						jsonParser.WriteJson(list.ToArray());
						try
						{
							Dictionary<string, string> data = new Dictionary<string, string>();
							HTTPUtils.SendRequestToClient("appJsonChanged", data, vmName, 0, null, false, 1, 0);
						}
						catch (Exception ex)
						{
							Logger.Error("Exception while sending appsync update to client: " + ex.ToString());
						}
					}
					Utils.sIsSyncAppJsonComplete = true;
				}
			}
			catch (Exception ex2)
			{
				Logger.Warning(string.Format("Unable to sync app.json file for vm:{0}. " + ex2.ToString(), vmName));
			}
		}

		// Token: 0x060009CF RID: 2511 RVA: 0x00029E9C File Offset: 0x0002809C
		public static bool UnsupportedProcessor()
		{
			try
			{
				Logger.Info("Checking if Processor Unsupported");
				string[] array = new string[]
				{
					"AMD64 Family 21 Model 16 Stepping 1 AuthenticAMD"
				};
				string text = Path.Combine(Path.GetTempPath(), "SystemInfo.txt");
				if (File.Exists(text))
				{
					File.Delete(text);
				}
				Utils.RunCmd("SystemInfo", null, text);
				string text2 = File.ReadAllText(text);
				foreach (string value in array)
				{
					if (text2.IndexOf(value) != -1)
					{
						return true;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in Checking if Processor Unsupported : {0}", new object[]
				{
					ex.ToString()
				});
			}
			return false;
		}

		// Token: 0x060009D0 RID: 2512 RVA: 0x00029F4C File Offset: 0x0002814C
		public static bool ReserveHTTPPorts()
		{
			bool result = false;
			try
			{
				string str = new SecurityIdentifier("S-1-1-0").Translate(typeof(NTAccount)).ToString();
				string cmd = "netsh.exe";
				int num = 2861;
				int num2 = 2961;
				Logger.Info("Reserving ports {0} - {1}", new object[]
				{
					num,
					num2
				});
				Logger.Info("---------------------------------------------------------------");
				bool flag = false;
				for (int i = num; i < num2; i++)
				{
					try
					{
						RunCommand.RunCmd(cmd, string.Format("http add urlacl url=http://*:{0}/ User=\\\"" + str + "\"", i), flag, flag, false, 0);
					}
					catch (Exception ex)
					{
						Logger.Error(string.Format("Error occured, Err: {0}", ex.ToString()));
					}
					flag = (i % 10 == 0);
				}
				result = true;
			}
			catch (Exception ex2)
			{
				Logger.Error("Error in reserving HTTP ports: {0}", new object[]
				{
					ex2.ToString()
				});
				result = false;
			}
			Logger.Info("---------------------------------------------------------------");
			return result;
		}

		// Token: 0x060009D1 RID: 2513 RVA: 0x0002A070 File Offset: 0x00028270
		public static void RestartService(string serviceName, int timeoutMilliseconds)
		{
			Logger.Info("Restarting {0} service", new object[]
			{
				serviceName
			});
			ServiceController serviceController = new ServiceController(serviceName);
			try
			{
				int tickCount = Environment.TickCount;
				TimeSpan timeout = TimeSpan.FromMilliseconds((double)timeoutMilliseconds);
				serviceController.Stop();
				serviceController.WaitForStatus(ServiceControllerStatus.Stopped, timeout);
				int tickCount2 = Environment.TickCount;
				timeout = TimeSpan.FromMilliseconds((double)(timeoutMilliseconds - (tickCount2 - tickCount)));
				serviceController.Start();
				serviceController.WaitForStatus(ServiceControllerStatus.Running, timeout);
			}
			catch (Exception ex)
			{
				Logger.Error("Error in restarting service " + ex.ToString());
			}
		}

		// Token: 0x060009D2 RID: 2514 RVA: 0x0002A100 File Offset: 0x00028300
		public static bool CheckOpenGlSupport(out int glRenderMode, out string glVendor, out string glRenderer, out string glVersion, string blueStacksProgramFiles)
		{
			Logger.Info("In CheckSupportedGlRenderMode");
			glRenderMode = 4;
			glVersion = "";
			glRenderer = "";
			glVendor = "";
			Logger.Info("Running glcheck from folder : " + blueStacksProgramFiles);
			Logger.Info("Checking for glRenderMode 1");
			if (Utils.GetGraphicsInfo(Path.Combine(blueStacksProgramFiles, "HD-GLCheck.exe"), "1", out glVendor, out glRenderer, out glVersion) == 0)
			{
				glRenderMode = 1;
				return true;
			}
			Logger.Info("Opengl not supported.");
			return false;
		}

		// Token: 0x060009D3 RID: 2515 RVA: 0x00009EA9 File Offset: 0x000080A9
		public static int GetCurrentGraphicsInfo(string args, out string glVendor, out string glRenderer, out string glVersion)
		{
			return Utils.GetGraphicsInfo(Path.Combine(RegistryStrings.InstallDir, "HD-GLCheck.exe"), args, out glVendor, out glRenderer, out glVersion, true);
		}

		// Token: 0x060009D4 RID: 2516 RVA: 0x00009EC4 File Offset: 0x000080C4
		public static int GetGraphicsInfo(string prog, string args, out string glVendor, out string glRenderer, out string glVersion)
		{
			return Utils.GetGraphicsInfo(prog, args, out glVendor, out glRenderer, out glVersion, true);
		}

		// Token: 0x060009D5 RID: 2517 RVA: 0x0002A178 File Offset: 0x00028378
		public static int GetGraphicsInfo(string prog, string args, out string glVendor, out string glRenderer, out string glVersion, bool enableLogging)
		{
			Logger.Info("Will run " + prog + " with args " + args);
			string vendor = "";
			string renderer = "";
			string version = "";
			glVendor = vendor;
			glRenderer = renderer;
			glVersion = version;
			int result = -1;
			Environment.GetEnvironmentVariable("TEMP");
			try
			{
				Process proc = new Process();
				proc.StartInfo.FileName = prog;
				proc.StartInfo.Arguments = args;
				proc.StartInfo.UseShellExecute = false;
				proc.StartInfo.CreateNoWindow = true;
				proc.StartInfo.RedirectStandardOutput = true;
				proc.OutputDataReceived += delegate(object sender, DataReceivedEventArgs outLine)
				{
					try
					{
						string text = (outLine.Data != null) ? outLine.Data : "";
						if (enableLogging)
						{
							Logger.Info(proc.Id + " OUT: " + text);
						}
						if (text.Contains("GL_VENDOR ="))
						{
							int num2 = text.IndexOf('=');
							vendor = text.Substring(num2 + 1).Trim();
							vendor = vendor.Replace(";", ";;");
						}
						if (text.Contains("GL_RENDERER ="))
						{
							int num2 = text.IndexOf('=');
							renderer = text.Substring(num2 + 1).Trim();
							renderer = renderer.Replace(";", ";;");
						}
						if (text.Contains("GL_VERSION ="))
						{
							int num2 = text.IndexOf('=');
							version = text.Substring(num2 + 1).Trim();
							version = version.Replace(";", ";;");
						}
					}
					catch (Exception ex2)
					{
						Logger.Error("A crash occured in the GLCheck delegate");
						Logger.Error(ex2.ToString());
					}
				};
				proc.Start();
				proc.BeginOutputReadLine();
				int num = 10000;
				bool flag = proc.WaitForExit(num);
				glVendor = vendor;
				glRenderer = renderer;
				glVersion = version;
				if (flag)
				{
					Logger.Info(proc.Id + " EXIT: " + proc.ExitCode);
					result = proc.ExitCode;
				}
				else
				{
					Logger.Error("Process killed after timeout: {0}s", new object[]
					{
						num / 1000
					});
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Some error while running graphics check. Ex: {0}", new object[]
				{
					ex
				});
			}
			return result;
		}

		// Token: 0x060009D6 RID: 2518 RVA: 0x0002A35C File Offset: 0x0002855C
		public static int CheckSsse3Info(string prog, out string ssse3Supported)
		{
			Logger.Info("Will run " + prog);
			int result = -1;
			string ssse3value = "";
			try
			{
				Process process = new Process();
				process.StartInfo.FileName = prog;
				process.StartInfo.UseShellExecute = false;
				process.StartInfo.CreateNoWindow = true;
				process.StartInfo.RedirectStandardOutput = true;
				Countdown countDown = new Countdown(1);
				process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs outLine)
				{
					if (outLine.Data != null)
					{
						try
						{
							string data = outLine.Data;
							if (data.Contains("value ="))
							{
								int num2 = data.IndexOf('=');
								ssse3value = data.Substring(num2 + 1).Trim();
							}
							return;
						}
						catch (Exception ex2)
						{
							Console.WriteLine("A crash occured in check cpu info delegate");
							Console.WriteLine(ex2.ToString());
							return;
						}
					}
					countDown.Signal();
				};
				process.Start();
				process.BeginOutputReadLine();
				int num = 10000;
				bool flag = process.WaitForExit(num);
				countDown.Wait();
				if (flag)
				{
					Logger.Info(process.Id + " EXIT: " + process.ExitCode);
					result = process.ExitCode;
				}
				else
				{
					Logger.Error("Process killed after timeout: {0}s", new object[]
					{
						num / 1000
					});
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Some error while running graphics check. Ex: {0}", new object[]
				{
					ex
				});
			}
			if (ssse3value == "1" || ssse3value == "")
			{
				ssse3Supported = "1";
			}
			else
			{
				ssse3Supported = "0";
			}
			return result;
		}

		// Token: 0x060009D7 RID: 2519 RVA: 0x0002A4C4 File Offset: 0x000286C4
		public static bool CheckTwoCameraPresentOnDevice(ref bool bBothCamera)
		{
			bool result;
			try
			{
				Guid guid = new Guid("{53F56307-B6BF-11D0-94F2-00A0C91EFB8B}");
				int num = Utils.SetupDiGetClassDevs(ref guid, IntPtr.Zero, IntPtr.Zero, Utils.ClassDevsFlags.DIGCF_PRESENT | Utils.ClassDevsFlags.DIGCF_ALLCLASSES);
				int num2 = -1;
				int num3 = 0;
				int num4 = 0;
				while (num2 != 0)
				{
					Utils.SP_DEVINFO_DATA sp_DEVINFO_DATA = default(Utils.SP_DEVINFO_DATA);
					sp_DEVINFO_DATA.cbSize = Marshal.SizeOf(sp_DEVINFO_DATA);
					num2 = Utils.SetupDiEnumDeviceInfo(num, num3, ref sp_DEVINFO_DATA);
					if (num2 == 1 && Utils.GetRegistryProperty(num, ref sp_DEVINFO_DATA, Utils.RegPropertyType.SPDRP_CLASSGUID).Equals("{6bdd1fc6-810f-11d0-bec7-08002be2092f}"))
					{
						num4++;
						if (num4 == 2)
						{
							bBothCamera = true;
						}
					}
					num3++;
					if (bBothCamera)
					{
						Logger.Info("Both Camera present on Device");
						break;
					}
				}
				result = true;
			}
			catch (Exception ex)
			{
				result = false;
				Logger.Info("Exception when trying to check Camera present on Device");
				Logger.Info(ex.ToString());
			}
			return result;
		}

		// Token: 0x060009D8 RID: 2520 RVA: 0x0002A590 File Offset: 0x00028790
		private static string GetRegistryProperty(int PnPHandle, ref Utils.SP_DEVINFO_DATA DeviceInfoData, Utils.RegPropertyType Property)
		{
			int num = 0;
			Utils.DATA_BUFFER data_BUFFER = default(Utils.DATA_BUFFER);
			Utils.SetupDiGetDeviceRegistryProperty(PnPHandle, ref DeviceInfoData, Property, IntPtr.Zero, ref data_BUFFER, 1024, ref num);
			return data_BUFFER.Buffer;
		}

		// Token: 0x060009D9 RID: 2521 RVA: 0x00009ED2 File Offset: 0x000080D2
		public static int CallApkInstaller(string apkPath, bool isSilentInstall)
		{
			return Utils.CallApkInstaller(apkPath, isSilentInstall, null);
		}

		// Token: 0x060009DA RID: 2522 RVA: 0x0002A5C4 File Offset: 0x000287C4
		public static int CallApkInstaller(string apkPath, bool isSilentInstall, string vmName)
		{
			Logger.Info("Installing apk :{0} vm name :{1} ", new object[]
			{
				apkPath,
				vmName
			});
			if (vmName == null)
			{
				vmName = "Android";
			}
			int result = -1;
			try
			{
				string installDir = RegistryStrings.InstallDir;
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				if (string.Equals(Path.GetExtension(apkPath), ".xapk", StringComparison.InvariantCultureIgnoreCase))
				{
					processStartInfo.FileName = Path.Combine(installDir, "HD-XapkHandler.exe");
					if (isSilentInstall)
					{
						processStartInfo.Arguments = string.Format("-xapk \"{0}\" -s -vmname {1}", apkPath, vmName);
					}
					else
					{
						processStartInfo.Arguments = string.Format("-xapk \"{0}\" -vmname {1}", apkPath, vmName);
					}
				}
				else
				{
					processStartInfo.FileName = Path.Combine(installDir, "HD-ApkHandler.exe");
					if (isSilentInstall)
					{
						processStartInfo.Arguments = string.Format("-apk \"{0}\" -s -vmname {1}", apkPath, vmName);
					}
					else
					{
						processStartInfo.Arguments = string.Format("-apk \"{0}\" -vmname {1}", apkPath, vmName);
					}
				}
				processStartInfo.UseShellExecute = false;
				processStartInfo.CreateNoWindow = true;
				Logger.Info("Console: installer path {0}", new object[]
				{
					processStartInfo.FileName
				});
				Process process = Process.Start(processStartInfo);
				process.WaitForExit();
				result = process.ExitCode;
				Logger.Info("Console: apk installer exit code: {0}", new object[]
				{
					process.ExitCode
				});
			}
			catch (Exception ex)
			{
				Logger.Info("Error Installing Apk : " + ex.ToString());
			}
			return result;
		}

		// Token: 0x060009DB RID: 2523 RVA: 0x00009EDC File Offset: 0x000080DC
		public static string GetInstallStatsUrl()
		{
			return string.Format("{0}/{1}", RegistryManager.Instance.Host, "stats/bsinstallstats");
		}

		// Token: 0x060009DC RID: 2524 RVA: 0x0002A710 File Offset: 0x00028910
		public static Dictionary<string, string> GetUserData()
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			string version = RegistryManager.Instance.Version;
			string registeredEmail = RegistryManager.Instance.RegisteredEmail;
			if (!string.IsNullOrEmpty(registeredEmail))
			{
				dictionary.Add("email", registeredEmail);
			}
			long num = DateTime.UtcNow.Ticks - 621355968000000000L;
			string value = (num / 10000000L).ToString();
			dictionary.Add("user_time", value);
			return dictionary;
		}

		// Token: 0x060009DD RID: 2525 RVA: 0x0002A784 File Offset: 0x00028984
		public static bool IsForegroundApplication()
		{
			bool result = false;
			IntPtr foregroundWindow = InteropWindow.GetForegroundWindow();
			if (foregroundWindow != IntPtr.Zero)
			{
				uint num = 0U;
				InteropWindow.GetWindowThreadProcessId(foregroundWindow, ref num);
				if ((ulong)num == (ulong)((long)Process.GetCurrentProcess().Id))
				{
					result = true;
				}
			}
			return result;
		}

		// Token: 0x060009DE RID: 2526 RVA: 0x0002A7C4 File Offset: 0x000289C4
		public static bool CheckWritePermissionForFolder(string DirectoryPath)
		{
			if (string.IsNullOrEmpty(DirectoryPath))
			{
				return false;
			}
			bool result;
			try
			{
				using (File.Create(Path.Combine(DirectoryPath, Path.GetRandomFileName()), 1, FileOptions.DeleteOnClose))
				{
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x060009DF RID: 2527 RVA: 0x0002A828 File Offset: 0x00028A28
		public static void UpdateRegistry(string registryKey, string name, object value, RegistryValueKind kind)
		{
			try
			{
				RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey(registryKey, true);
				registryKey2.SetValue(name, value, kind);
				registryKey2.Close();
				registryKey2.Flush();
			}
			catch (Exception ex)
			{
				Logger.Error("Exception occured in UpdateRegistry " + ex.ToString());
				throw;
			}
		}

		// Token: 0x060009E0 RID: 2528 RVA: 0x0002A880 File Offset: 0x00028A80
		public static Icon GetApplicationIcon()
		{
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				return new Icon(Path.Combine(RegistryStrings.InstallDir, "app_icon.ico"));
			}
			string productIconCompletePath = RegistryStrings.ProductIconCompletePath;
			if (File.Exists(productIconCompletePath))
			{
				return new Icon(productIconCompletePath);
			}
			return Icon.ExtractAssociatedIcon(Application.ExecutablePath);
		}

		// Token: 0x060009E1 RID: 2529 RVA: 0x00009EF7 File Offset: 0x000080F7
		public static bool IsHDPlusDebugMode()
		{
			return RegistryManager.Instance.PlusDebug != 0;
		}

		// Token: 0x060009E2 RID: 2530 RVA: 0x00009F08 File Offset: 0x00008108
		public static int GetGMStreamWindowWidth()
		{
			return 320 * SystemUtils.GetDPI() / 96;
		}

		// Token: 0x060009E3 RID: 2531 RVA: 0x0002A8D0 File Offset: 0x00028AD0
		public static void SetCurrentEngineStateAndGlTransportValue(EngineState state, string vmName)
		{
			Logger.Info("Setting CurrentEngineState: " + state.ToString());
			RegistryManager.Instance.CurrentEngine = state.ToString();
			string bootParameters = RegistryManager.Instance.Guest[vmName].BootParameters;
			string[] array = bootParameters.Split(new char[]
			{
				' '
			});
			string text = "";
			string text2 = "GlTransport";
			int num;
			if (state == EngineState.legacy)
			{
				num = RegistryManager.Instance.GlLegacyTransportConfig;
			}
			else
			{
				num = RegistryManager.Instance.GlPlusTransportConfig;
			}
			Logger.Info("setting GlValue to {0}", new object[]
			{
				num
			});
			if (bootParameters.IndexOf(text2) == -1)
			{
				text = string.Concat(new object[]
				{
					bootParameters,
					" ",
					text2,
					"=",
					num
				});
			}
			else
			{
				foreach (string text3 in array)
				{
					if (text3.IndexOf(text2) != -1)
					{
						if (!string.IsNullOrEmpty(text))
						{
							text += " ";
						}
						text = string.Concat(new object[]
						{
							text,
							text2,
							"=",
							num
						});
					}
					else
					{
						if (!string.IsNullOrEmpty(text))
						{
							text += " ";
						}
						text += text3;
					}
				}
			}
			RegistryManager.Instance.Guest[vmName].BootParameters = text;
		}

		// Token: 0x060009E4 RID: 2532 RVA: 0x0002AA50 File Offset: 0x00028C50
		public static bool RegisterComExe(string path, bool register)
		{
			bool result;
			try
			{
				result = (Utils.RunCmd(path, register ? "/RegServer" : "/UnregServer", null).ExitCode == 0);
			}
			catch (Exception ex)
			{
				Logger.Error("Command runner raised an exception: " + ex.ToString());
				result = false;
			}
			return result;
		}

		// Token: 0x060009E5 RID: 2533 RVA: 0x0002AAAC File Offset: 0x00028CAC
		public static string GetCurrentKeyboardLayout()
		{
			string result;
			try
			{
				result = new CultureInfo(Utils.GetKeyboardLayout(Utils.GetWindowThreadProcessId(Utils.GetForegroundWindow(), IntPtr.Zero)).ToInt32() & 65535).Name;
			}
			catch
			{
				result = "en-US";
			}
			return result;
		}

		// Token: 0x060009E6 RID: 2534 RVA: 0x0002AB04 File Offset: 0x00028D04
		public static bool IsEngineRaw()
		{
			bool result = false;
			try
			{
				if (JObject.Parse(RegistryManager.Instance.DeviceCaps)["engine_enabled"].ToString().Trim() == EngineState.raw.ToString())
				{
					result = true;
				}
			}
			catch (Exception ex)
			{
				Logger.Error(string.Format("Error Occured, Err: {0}", ex.ToString()));
			}
			Logger.Info("Engine mode Raw: " + result.ToString());
			return result;
		}

		// Token: 0x060009E7 RID: 2535 RVA: 0x0002AB90 File Offset: 0x00028D90
		public static string GetCampaignName()
		{
			string result = "";
			try
			{
				JObject jobject = JObject.Parse(RegistryManager.Instance.CampaignJson);
				if (jobject != null)
				{
					result = jobject["campaign_name"].ToString();
				}
			}
			catch (Exception)
			{
				Logger.Warning("Failed to get CampaignName.");
			}
			return result;
		}

		// Token: 0x060009E8 RID: 2536 RVA: 0x0002ABE8 File Offset: 0x00028DE8
		public static string GetUserCountry(string vmName)
		{
			string result;
			try
			{
				string text = BstHttpClient.Get(string.Format("{0}/{1}", RegistryManager.Instance.Host, "api/getcountryforip"), null, false, vmName, 0, 1, 0, false);
				Logger.Info("Got resp: " + text);
				result = JObject.Parse(text)["country"].ToString().Trim();
			}
			catch (Exception ex)
			{
				Logger.Error(ex.Message);
				result = "";
			}
			return result;
		}

		// Token: 0x060009E9 RID: 2537 RVA: 0x0002AC6C File Offset: 0x00028E6C
		public static void KillComServer()
		{
			Logger.Info("In KillComServer");
			string fullPath = Path.GetFullPath(RegistryStrings.InstallDir + "\\");
			foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher(new WqlObjectQuery("SELECT * FROM Win32_Process WHERE Name = 'BstkSVC.exe'")).Get())
			{
				ManagementObject managementObject = (ManagementObject)managementBaseObject;
				Logger.Info(string.Concat(new object[]
				{
					"Considering ",
					managementObject["ProcessId"],
					" -> ",
					managementObject["ExecutablePath"]
				}));
				if (string.Compare(Path.GetFullPath(Path.GetDirectoryName((string)managementObject["ExecutablePath"]) + "\\"), fullPath, true) == 0)
				{
					Process processById = Process.GetProcessById((int)((uint)managementObject["ProcessId"]));
					Logger.Info("Trying to kill PID " + processById.Id);
					processById.Kill();
					if (!processById.WaitForExit(10000))
					{
						Logger.Info("Timeout waiting for process to die");
					}
				}
			}
		}

		// Token: 0x060009EA RID: 2538 RVA: 0x0002ADA0 File Offset: 0x00028FA0
		public static void StopClientInstanceAsync(string vmName)
		{
			try
			{
				Logger.Info("Will send request stopInstance to " + vmName);
				List<string> list = new List<string>
				{
					vmName
				};
				if (string.IsNullOrEmpty(vmName))
				{
					list = RegistryManager.Instance.VmList.ToList<string>();
				}
				foreach (string text in list)
				{
					try
					{
						HTTPUtils.SendRequestToClientAsync("stopInstance", new Dictionary<string, string>
						{
							{
								"vmName",
								text
							}
						}, text, 0, null, false, 1, 0);
					}
					catch (Exception ex)
					{
						Logger.Warning("Exception in closing client for vm: {0} --> {1}", new object[]
						{
							text,
							ex.Message
						});
					}
				}
			}
			catch (Exception ex2)
			{
				Logger.Error("Exception in closing any frontend: " + ex2.ToString());
			}
		}

		// Token: 0x060009EB RID: 2539 RVA: 0x0002AE98 File Offset: 0x00029098
		public static void StopFrontend(string vmName)
		{
			try
			{
				Logger.Info("Will send request shutdown" + vmName);
				List<string> list = new List<string>
				{
					vmName
				};
				if (string.IsNullOrEmpty(vmName))
				{
					list = RegistryManager.Instance.VmList.ToList<string>();
				}
				foreach (string text in list)
				{
					try
					{
						HTTPUtils.SendRequestToEngine("shutdown", new Dictionary<string, string>
						{
							{
								"vmName",
								text
							}
						}, "Android", 0, null, false, 1, 0, text);
					}
					catch (Exception ex)
					{
						Logger.Warning("Exception in closing any frontend for vm = " + text + " -->" + ex.ToString());
					}
				}
			}
			catch (Exception ex2)
			{
				Logger.Error("Exception in closing any frontend: " + ex2.ToString());
			}
		}

		// Token: 0x060009EC RID: 2540 RVA: 0x0002AF94 File Offset: 0x00029194
		public static bool CheckIfAndroidBstkExistAndValid(string vmName)
		{
			Logger.Info("Checking if android bstk exist and valid");
			string text = Path.Combine(Path.Combine(RegistryStrings.DataDir, vmName), vmName + ".bstk");
			if (File.Exists(text))
			{
				if (new FileInfo(text).Length == 0L)
				{
					return false;
				}
				try
				{
					new XDocument();
					XDocument.Load(text);
					return true;
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in parsing bstk file" + ex.ToString());
					return false;
				}
				return false;
			}
			return false;
		}

		// Token: 0x060009ED RID: 2541 RVA: 0x0002B020 File Offset: 0x00029220
		public static void CreateBstkFileFromPrev(string vmName)
		{
			Logger.Info("Creating Bstk file from Bstk-Prev file");
			string path = Path.Combine(RegistryStrings.DataDir, vmName);
			string destFileName = Path.Combine(path, vmName + ".bstk");
			string text = Path.Combine(path, vmName + ".bstk-prev");
			if (!File.Exists(text))
			{
				Logger.Info("android.bstk-prev file not exist");
				return;
			}
			File.Copy(text, destFileName, true);
		}

		// Token: 0x060009EE RID: 2542 RVA: 0x0002B080 File Offset: 0x00029280
		public static bool IsFirstVersionHigher(string firstVersion, string secondVersion)
		{
			string[] array = firstVersion.Split(new char[]
			{
				'.'
			});
			string[] array2 = secondVersion.Split(new char[]
			{
				'.'
			});
			bool flag = false;
			int i = 0;
			int num = Math.Min(array.Length, array2.Length);
			while (i < num)
			{
				long num2 = Convert.ToInt64(array[i]);
				long num3 = Convert.ToInt64(array2[i]);
				long num4 = num2 - num3;
				if (num4 > 0L)
				{
					flag = true;
					break;
				}
				if (num4 < 0L)
				{
					break;
				}
				i++;
			}
			if (!flag && i < array.Length && i == array2.Length)
			{
				flag = true;
			}
			return flag;
		}

		// Token: 0x060009EF RID: 2543 RVA: 0x0002B108 File Offset: 0x00029308
		public static bool IsRunningInstanceClashWithAnotherInstance(string procName)
		{
			string installDir = RegistryStrings.InstallDir;
			string clientInstallDir = RegistryManager.Instance.ClientInstallDir;
			if (string.IsNullOrEmpty(installDir) && string.IsNullOrEmpty(clientInstallDir))
			{
				return false;
			}
			procName = procName.Replace(".exe", "");
			List<string> applicationPath = GetProcessExecutionPath.GetApplicationPath(Process.GetProcessesByName(procName));
			Logger.Debug("Number of running instances for the process {0} are {1} ", new object[]
			{
				procName,
				applicationPath.Count
			});
			foreach (string path in applicationPath)
			{
				try
				{
					string directoryName = Path.GetDirectoryName(path);
					if (!directoryName.Equals(installDir.TrimEnd(new char[]
					{
						'\\'
					}), StringComparison.InvariantCultureIgnoreCase) && !directoryName.Equals(clientInstallDir.TrimEnd(new char[]
					{
						'\\'
					}), StringComparison.InvariantCultureIgnoreCase))
					{
						return true;
					}
				}
				catch
				{
				}
			}
			return false;
		}

		// Token: 0x060009F0 RID: 2544 RVA: 0x0002B20C File Offset: 0x0002940C
		public static int GetVideoControllersNum()
		{
			int num = 0;
			try
			{
				ManagementObjectCollection managementObjectCollection = new ManagementObjectSearcher("SELECT * FROM Win32_VideoController").Get();
				num = managementObjectCollection.Count;
				Logger.Info("Win32_VideoController query count: ", new object[]
				{
					num
				});
				foreach (ManagementBaseObject managementBaseObject in managementObjectCollection)
				{
					foreach (PropertyData propertyData in ((ManagementObject)managementBaseObject).Properties)
					{
						string name = propertyData.Name;
						if (!(name == "Description"))
						{
							if (!(name == "DriverVersion"))
							{
								if (name == "DriverDate")
								{
									Logger.Info("DriverDate: {0}", new object[]
									{
										ManagementDateTimeConverter.ToDateTime(propertyData.Value.ToString()).ToUniversalTime().ToString("yyyy-MM-dd HH-mm-ss", DateTimeFormatInfo.InvariantInfo)
									});
								}
							}
							else
							{
								Logger.Info("DriverVersion: {0}", new object[]
								{
									propertyData.Value
								});
							}
						}
						else
						{
							Logger.Info("Description (Name): {0}", new object[]
							{
								propertyData.Value
							});
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while runninq query. Ex: ", new object[]
				{
					ex
				});
				Logger.Info("Ignoring and continuing...");
			}
			return num;
		}

		// Token: 0x060009F1 RID: 2545 RVA: 0x0002B3D4 File Offset: 0x000295D4
		public static void ParseGLVersion(string glVersion, out double version)
		{
			try
			{
				string text;
				if (glVersion.StartsWith("OpenGL"))
				{
					text = glVersion.Split(new char[]
					{
						'('
					})[0].Trim();
					text = text.Split(new char[]
					{
						'S'
					})[1].Trim();
				}
				else
				{
					text = glVersion.Split(new char[]
					{
						' '
					})[0].Trim();
					string[] array = text.Split(new char[]
					{
						'.'
					});
					text = string.Format("{0}.{1}", array[0], array[1]);
				}
				version = double.Parse(text, CultureInfo.InvariantCulture);
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't parse for GL3 string: {0}", new object[]
				{
					glVersion
				});
				Logger.Error(ex.ToString());
				version = 0.0;
			}
		}

		// Token: 0x060009F2 RID: 2546 RVA: 0x0002B4B0 File Offset: 0x000296B0
		public static string GetUpdatedBootParamsString(string var, string val, string oldBootParams)
		{
			Logger.Info("Attempting to update bootparam for {0}={1}", new object[]
			{
				var,
				val
			});
			bool flag = false;
			if (string.IsNullOrEmpty(val))
			{
				flag = true;
			}
			List<string[]> list = (from part in oldBootParams.Split(new char[]
			{
				' '
			}, StringSplitOptions.RemoveEmptyEntries)
			select part.Split(new char[]
			{
				'='
			}) into x
			where x.Length == 1
			select x).ToList<string[]>();
			Dictionary<string, string> dictionary = (from part in oldBootParams.Split(new char[]
			{
				' '
			}, StringSplitOptions.RemoveEmptyEntries)
			select part.Split(new char[]
			{
				'='
			}) into x
			where x.Length == 2
			select x).ToDictionary((string[] split) => split[0], (string[] split) => split[1]);
			if (flag)
			{
				string[] item = new string[]
				{
					var
				};
				bool flag2 = false;
				using (List<string[]>.Enumerator enumerator = list.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						if (enumerator.Current.Contains(var))
						{
							flag2 = true;
						}
					}
				}
				if (!flag2)
				{
					list.Add(item);
					Logger.Info("BootParams added for {0}", new object[]
					{
						var,
						val
					});
				}
				else
				{
					Logger.Info("BootParam already present");
				}
			}
			else
			{
				dictionary[var] = val;
				Logger.Info("BootParam added/updated");
			}
			List<string> list2 = (from x in dictionary
			select x.Key + "=" + x.Value).ToList<string>();
			list2.AddRange(list.SelectMany((string[] x) => x));
			return string.Join(" ", list2.ToArray());
		}

		// Token: 0x060009F3 RID: 2547 RVA: 0x0002B6E4 File Offset: 0x000298E4
		private static string GetServiceImagePath(string svcName)
		{
			string name = "SYSTEM\\CurrentControlSet\\Services\\" + svcName;
			using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(name))
			{
				if (registryKey != null)
				{
					return Environment.ExpandEnvironmentVariables(registryKey.GetValue("ImagePath", "").ToString());
				}
			}
			return "";
		}

		// Token: 0x060009F4 RID: 2548 RVA: 0x0002B74C File Offset: 0x0002994C
		public static bool IsRunningInstanceClashWithService(string[] servicePrefixes, out ServiceController runningSvc)
		{
			Logger.Info("In IsRunningInstanceClashWithService");
			runningSvc = null;
			ServiceController[] devices = ServiceController.GetDevices();
			List<ServiceController> list = new List<ServiceController>();
			foreach (ServiceController serviceController in devices)
			{
				foreach (string value in servicePrefixes)
				{
					if (serviceController.ServiceName.Contains(value))
					{
						list.Add(serviceController);
					}
				}
			}
			string a = RegistryStrings.InstallDir.TrimEnd(new char[]
			{
				'\\'
			});
			foreach (ServiceController serviceController2 in list)
			{
				string text = Path.GetDirectoryName(Utils.GetServiceImagePath(serviceController2.ServiceName));
				text = text.Substring(4, text.Length - 4);
				if (!string.Equals(a, text, StringComparison.InvariantCultureIgnoreCase) && serviceController2.Status == ServiceControllerStatus.Running)
				{
					runningSvc = serviceController2;
					return true;
				}
			}
			return false;
		}

		// Token: 0x060009F5 RID: 2549 RVA: 0x0002B854 File Offset: 0x00029A54
		public static double RoundUp(double input, int places)
		{
			double num = Math.Pow(10.0, Convert.ToDouble(places));
			return Math.Ceiling(input * num) / num;
		}

		// Token: 0x060009F6 RID: 2550 RVA: 0x00009F18 File Offset: 0x00008118
		public static void UpdateBlueStacksSizeToRegistryASync()
		{
			BackgroundWorker backgroundWorker = new BackgroundWorker();
			backgroundWorker.DoWork += Utils.UpdateBlueStacksSizeToRegistry;
			backgroundWorker.RunWorkerAsync();
		}

		// Token: 0x060009F7 RID: 2551 RVA: 0x0002B880 File Offset: 0x00029A80
		private static void UpdateBlueStacksSizeToRegistry(object sender, DoWorkEventArgs e)
		{
			try
			{
				string name = string.Empty;
				if (SystemUtils.IsOs64Bit())
				{
					name = string.Format("{0}\\BlueStacks{1}", "SOFTWARE\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall", Strings.GetOemTag());
				}
				else
				{
					name = string.Format("{0}\\BlueStacks{1}", "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall", Strings.GetOemTag());
				}
				long num = 0L;
				foreach (string path in RegistryManager.Instance.VmList.ToList<string>())
				{
					string text = Path.Combine(RegistryStrings.DataDir, path);
					if (Directory.Exists(text))
					{
						num += IOUtils.GetDirectorySize(text);
					}
				}
				num /= 1048576L;
				num += 1000L;
				int num2 = Convert.ToInt32(num);
				Logger.Info("Updating {0}MB BlueStacks size to registry", new object[]
				{
					num2
				});
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(name, true))
				{
					if (registryKey != null)
					{
						registryKey.SetValue("EstimatedSize", num2 * 1024, RegistryValueKind.DWord);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Couldn't update size to registry, ignoring error. Ex: {0}", new object[]
				{
					ex.Message
				});
			}
		}

		// Token: 0x060009F8 RID: 2552 RVA: 0x0002B9FC File Offset: 0x00029BFC
		public static object GetRegistryHKLMValue(string regPath, string key, object defaultValue)
		{
			try
			{
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(regPath))
				{
					if (registryKey != null)
					{
						return registryKey.GetValue(key, defaultValue);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in getting the reistry value " + ex.Message);
			}
			return defaultValue;
		}

		// Token: 0x060009F9 RID: 2553 RVA: 0x0002BA68 File Offset: 0x00029C68
		public static object GetRegistryHKCUValue(string regPath, string key, object defaultValue)
		{
			try
			{
				using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(regPath))
				{
					if (registryKey != null)
					{
						return registryKey.GetValue(key, defaultValue);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in getting the HKCU reistry value " + ex.Message);
			}
			return defaultValue;
		}

		// Token: 0x060009FA RID: 2554 RVA: 0x0002BAD4 File Offset: 0x00029CD4
		public static void BackUpGuid(string userGUID)
		{
			try
			{
				StreamWriter streamWriter = new StreamWriter(Path.Combine(Environment.GetEnvironmentVariable("TEMP"), "Bst_Guid_Backup"));
				streamWriter.Write(userGUID);
				streamWriter.Close();
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to backup guid...ignoring...printing exception");
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x060009FB RID: 2555 RVA: 0x0002BB30 File Offset: 0x00029D30
		public static void SetAttributesNormal(DirectoryInfo dir)
		{
			foreach (DirectoryInfo directoryInfo in dir.GetDirectories("*", SearchOption.AllDirectories))
			{
				Utils.SetAttributesNormal(directoryInfo);
				directoryInfo.Attributes = FileAttributes.Normal;
			}
			FileInfo[] files = dir.GetFiles("*", SearchOption.AllDirectories);
			for (int i = 0; i < files.Length; i++)
			{
				files[i].Attributes = FileAttributes.Normal;
			}
		}

		// Token: 0x060009FC RID: 2556 RVA: 0x00009F36 File Offset: 0x00008136
		public static string GetString(string currentValue, string defaultValue)
		{
			if (string.IsNullOrEmpty(currentValue))
			{
				return defaultValue;
			}
			return currentValue;
		}

		// Token: 0x060009FD RID: 2557 RVA: 0x00009F43 File Offset: 0x00008143
		public static int GetInt(int currentValue, int defaultValue)
		{
			if (currentValue == 0)
			{
				return defaultValue;
			}
			return currentValue;
		}

		// Token: 0x060009FE RID: 2558 RVA: 0x0002BB94 File Offset: 0x00029D94
		public static ulong GeneratePseudoRandomNumber()
		{
			DateTime now = DateTime.Now;
			return (ulong)(((long)now.Month * 1000000000L + (long)now.DayOfWeek * 100000000L + (long)now.Day * 1000000L + (long)now.Hour * 1000L + (long)now.Minute * 100L + (long)now.Second) * (long)now.Millisecond);
		}

		// Token: 0x060009FF RID: 2559 RVA: 0x0002BC08 File Offset: 0x00029E08
		public static string CreateRandomBstSharedFolder(string bstSharedFolder)
		{
			string result;
			try
			{
				ulong value = Utils.GeneratePseudoRandomNumber();
				string text;
				string path;
				for (;;)
				{
					text = string.Format("Bst_{0}", Convert.ToString(value));
					path = Path.Combine(bstSharedFolder, text);
					if (!Directory.Exists(path))
					{
						break;
					}
					value = Utils.GeneratePseudoRandomNumber();
				}
				Directory.CreateDirectory(path);
				result = text;
			}
			catch (Exception ex)
			{
				Logger.Info("Failed to create random shared folder... Err : " + ex.ToString());
				throw new Exception("Failed to create Bst Shared Folder");
			}
			return result;
		}

		// Token: 0x06000A00 RID: 2560 RVA: 0x0002BC84 File Offset: 0x00029E84
		public static string GetValueInBootParams(string name, string vmName, string bootparam = "")
		{
			string result = string.Empty;
			string text = bootparam;
			if (string.IsNullOrEmpty(text))
			{
				text = RegistryManager.Instance.Guest[vmName].BootParameters;
			}
			Dictionary<string, string> dictionary = (from part in text.Split(new char[]
			{
				' '
			}, StringSplitOptions.RemoveEmptyEntries)
			select part.Split(new char[]
			{
				'='
			}) into x
			where x.Length == 2
			select x).ToDictionary((string[] split) => split[0], (string[] split) => split[1]);
			if (dictionary.ContainsKey(name))
			{
				result = dictionary[name];
			}
			return result;
		}

		// Token: 0x06000A01 RID: 2561 RVA: 0x0002BD68 File Offset: 0x00029F68
		public static void UpdateValueInBootParams(string name, string value, string vmName, bool addIfNotPresent = true)
		{
			Dictionary<string, string> dictionary = (from part in RegistryManager.Instance.Guest[vmName].BootParameters.Split(new char[]
			{
				' '
			}, StringSplitOptions.RemoveEmptyEntries)
			select part.Split(new char[]
			{
				'='
			}) into x
			where x.Length == 2
			select x).ToDictionary((string[] split) => split[0], (string[] split) => split[1]);
			if (dictionary.ContainsKey(name))
			{
				dictionary[name] = value;
			}
			else if (addIfNotPresent)
			{
				dictionary.Add(name, value);
			}
			List<string> list = (from x in dictionary
			select x.Key + "=" + x.Value).ToList<string>();
			string bootParameters = string.Join(" ", list.ToArray());
			RegistryManager.Instance.Guest[vmName].BootParameters = bootParameters;
		}

		// Token: 0x06000A02 RID: 2562 RVA: 0x0002BE98 File Offset: 0x0002A098
		public static string GetDisplayName(string vmName)
		{
			if ("Android".Equals(vmName))
			{
				return Strings.ProductTopBarDisplayName;
			}
			if (!RegistryManager.Instance.Guest.ContainsKey(vmName))
			{
				return vmName.Replace("Android_", LocaleStrings.GetLocalizedString("STRING_INSTANCE", false) + " ");
			}
			if (string.IsNullOrEmpty(RegistryManager.Instance.Guest[vmName].DisplayName))
			{
				return vmName.Replace("Android_", LocaleStrings.GetLocalizedString("STRING_INSTANCE", false) + " ");
			}
			return RegistryManager.Instance.Guest[vmName].DisplayName;
		}

		// Token: 0x06000A03 RID: 2563 RVA: 0x0002BF40 File Offset: 0x0002A140
		public static bool IsAnyItemEmptyInStringList(List<string> strList)
		{
			using (List<string>.Enumerator enumerator = strList.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (string.IsNullOrEmpty(enumerator.Current))
					{
						return false;
					}
				}
			}
			return true;
		}

		// Token: 0x06000A04 RID: 2564 RVA: 0x0002BF94 File Offset: 0x0002A194
		public static VirtualBox GetVirtualBoxSerialisedObejct(string filePath)
		{
			try
			{
				Utils.SaveFileInUnicode(filePath);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to save file in unicode encoding... Err : " + ex.ToString());
			}
			Utils.ReplaceOldVirtualBoxNamespaceWithNew(filePath);
			FileStream fileStream = File.OpenRead(filePath);
			VirtualBox result = (VirtualBox)new XmlSerializer(typeof(VirtualBox)).Deserialize(fileStream);
			fileStream.Close();
			return result;
		}

		// Token: 0x06000A05 RID: 2565 RVA: 0x0002C000 File Offset: 0x0002A200
		public static void ReplaceOldVirtualBoxNamespaceWithNew(string filePath)
		{
			Logger.Info("In ReplaceOldVirtualBoxNamespaceWithNew");
			string text = File.ReadAllText(filePath);
			string text2 = "http://www.innotek.de/VirtualBox-settings";
			string newValue = "http://www.virtualbox.org/";
			if (text.Contains(text2))
			{
				text = text.Replace(text2, newValue);
				File.WriteAllText(filePath, text);
			}
		}

		// Token: 0x06000A06 RID: 2566 RVA: 0x0002C044 File Offset: 0x0002A244
		private static void SaveFileInUnicode(string filePath)
		{
			string value = File.ReadAllText(filePath);
			using (StreamWriter streamWriter = new StreamWriter(filePath, false, Encoding.Unicode))
			{
				streamWriter.Write(value);
				streamWriter.Flush();
				streamWriter.Close();
			}
		}

		// Token: 0x06000A07 RID: 2567 RVA: 0x00009F4B File Offset: 0x0000814B
		internal static Dictionary<string, string> AddCommonData(Dictionary<string, string> data)
		{
			if (!data.ContainsKey("install_id"))
			{
				data.Add("install_id", RegistryManager.Instance.InstallID);
			}
			return data;
		}

		// Token: 0x06000A08 RID: 2568 RVA: 0x00009F70 File Offset: 0x00008170
		public static string GetVmIdFromVmName(string vmName)
		{
			if (vmName == "Android")
			{
				return "0";
			}
			return vmName.Split(new char[]
			{
				'_'
			})[1];
		}

		// Token: 0x06000A09 RID: 2569 RVA: 0x0002C094 File Offset: 0x0002A294
		public static string GetAppRunAppJsonArg(string appName, string pkgName)
		{
			return string.Format("-json \"{0}\"", new JObject
			{
				{
					"app_icon_url",
					""
				},
				{
					"app_name",
					appName
				},
				{
					"app_url",
					""
				},
				{
					"app_pkg",
					pkgName
				}
			}.ToString(Formatting.None, new JsonConverter[0]).Replace("\"", "\\\""));
		}

		// Token: 0x06000A0A RID: 2570 RVA: 0x0002C11C File Offset: 0x0002A31C
		public static void DeleteFiles(List<string> listOfFiles)
		{
			foreach (string text in listOfFiles)
			{
				if (!Utils.DeleteFile(text))
				{
					Logger.Warning("Couldn't delete file: {0}", new object[]
					{
						text
					});
				}
			}
		}

		// Token: 0x06000A0B RID: 2571 RVA: 0x0002C180 File Offset: 0x0002A380
		public static bool DeleteFile(string filePath)
		{
			if (File.Exists(filePath))
			{
				try
				{
					File.Delete(filePath);
				}
				catch
				{
					return false;
				}
				return true;
			}
			return true;
		}

		// Token: 0x06000A0C RID: 2572 RVA: 0x00009F98 File Offset: 0x00008198
		public static void RemoveGamingRelatedFiles()
		{
			Logger.Info("Removing gaming related files");
			Utils.DeleteFiles(new List<string>
			{
				Path.Combine(RegistryManager.Instance.ClientInstallDir, "game_config.json")
			});
		}

		// Token: 0x06000A0D RID: 2573 RVA: 0x00009FC8 File Offset: 0x000081C8
		public static void UpgradeGamingRegistriesToFull()
		{
			Logger.Info("Setting registries for full edition");
			RegistryManager.Instance.InstallationType = InstallationTypes.FullEdition;
			RegistryManager.Instance.InstallerPkgName = string.Empty;
		}

		// Token: 0x06000A0E RID: 2574 RVA: 0x0002C1B8 File Offset: 0x0002A3B8
		public static void UpgradeToFullVersionAndCreateBstShortcut(bool updateUninstallEntryToo = false)
		{
			Logger.Info("Upgrading to full version of BlueStacks");
			Utils.UpgradeGamingRegistriesToFull();
			Utils.RemoveGamingRelatedFiles();
			Utils.RemoveAdminRelatedRegistryAndFiles(updateUninstallEntryToo);
			CommonInstallUtils.CreateDesktopAndStartMenuShortcuts(Strings.ProductDisplayName, RegistryStrings.ProductIconCompletePath, Path.Combine(RegistryManager.Instance.ClientInstallDir, "BlueStacks.exe"), "", "");
			Utils.SHChangeNotify(134217728, 4096, IntPtr.Zero, IntPtr.Zero);
		}

		// Token: 0x06000A0F RID: 2575 RVA: 0x0002C228 File Offset: 0x0002A428
		private static void RemoveAdminRelatedRegistryAndFiles(bool updateUninstallEntryToo)
		{
			Logger.Info("Removing admin related things");
			List<string> list = new List<string>
			{
				Path.Combine(RegistryStrings.InstallDir, "game_config.json"),
				Path.Combine(RegistryStrings.InstallDir, "app_icon.ico")
			};
			string[] files = Directory.GetFiles(RegistryStrings.InstallDir, "gameinstaller_*.png", SearchOption.TopDirectoryOnly);
			list.AddRange(files);
			string text = Path.Combine(Path.GetTempPath(), "RemoveGamingFiles.bat");
			using (StreamWriter streamWriter = new StreamWriter(text))
			{
				if (updateUninstallEntryToo)
				{
					Logger.Info("Exporting uninstall registry");
					int num = Utils.ExportUninstallEntry("\\BlueStacks" + Strings.GetOemTag(), Strings.UninstallRegistryExportedFilePath);
					Logger.Info("Exporting result: {0}", new object[]
					{
						num
					});
					Utils.UpdateUninstallRegistryFileForFullEdition(Strings.UninstallRegistryExportedFilePath);
					streamWriter.WriteLine(string.Format("REG IMPORT \"{0}\"", Strings.UninstallRegistryExportedFilePath));
				}
				foreach (string arg in list)
				{
					streamWriter.WriteLine(string.Format("DEL /F /Q \"{0}\"", arg));
				}
				streamWriter.Close();
			}
			Logger.Info("Executing: {0}", new object[]
			{
				text
			});
			Process process = new Process();
			process.StartInfo.Verb = "runas";
			process.StartInfo.FileName = text;
			process.StartInfo.WorkingDirectory = Path.GetTempPath();
			process.StartInfo.CreateNoWindow = true;
			try
			{
				process.Start();
				process.WaitForExit();
			}
			catch (Win32Exception ex)
			{
				Logger.Error("User cancelled UAC: " + ex.Message);
			}
			catch (Exception ex2)
			{
				Logger.Error("An error occured while executing the batch script: " + ex2.ToString());
			}
			finally
			{
				process.Dispose();
			}
			Logger.Info("All done!");
		}

		// Token: 0x06000A10 RID: 2576 RVA: 0x0002C43C File Offset: 0x0002A63C
		public static void UpdateUninstallEntryForFullEdition()
		{
			try
			{
				Logger.Info("Exporting uninstall registry");
				string uninstallRegistryExportedFilePath = Strings.UninstallRegistryExportedFilePath;
				int num = Utils.ExportUninstallEntry("\\BlueStacks" + Strings.GetOemTag(), uninstallRegistryExportedFilePath);
				Logger.Info("Exporting result: {0}", new object[]
				{
					num
				});
				Utils.UpdateUninstallRegistryFileForFullEdition(uninstallRegistryExportedFilePath);
				num = Utils.ImportRegistryFile(uninstallRegistryExportedFilePath, true);
				Logger.Info("Importing result: {0}", new object[]
				{
					num
				});
			}
			catch (Exception ex)
			{
				Logger.Warning("Couldn't update uninstall entry");
				Logger.Warning(ex.ToString());
			}
		}

		// Token: 0x06000A11 RID: 2577 RVA: 0x0002C4D8 File Offset: 0x0002A6D8
		private static void UpdateUninstallRegistryFileForFullEdition(string regFilePath)
		{
			Logger.Info("Updating exported file for full version");
			List<string> list = new List<string>();
			using (StreamReader streamReader = new StreamReader(regFilePath))
			{
				string text;
				while ((text = streamReader.ReadLine()) != null)
				{
					if (text.Contains("DisplayName"))
					{
						text = string.Format("\"DisplayName\"=\"{0}\"", Oem.Instance.ControlPanelDisplayName);
					}
					else if (text.Contains("DisplayIcon"))
					{
						text = string.Format("\"DisplayIcon\"=\"{0}\"", RegistryStrings.ProductIconCompletePath);
					}
					else if (text.Contains("Publisher"))
					{
						text = string.Format("\"Publisher\"=\"{0}\"", "BlueStack Systems, Inc.");
					}
					list.Add(text);
				}
				streamReader.Close();
			}
			using (StreamWriter streamWriter = new StreamWriter(regFilePath))
			{
				foreach (string value in list)
				{
					streamWriter.WriteLine(value);
				}
				streamWriter.Close();
			}
		}

		// Token: 0x06000A12 RID: 2578 RVA: 0x0002C5F8 File Offset: 0x0002A7F8
		public static int ExportUninstallEntry(string keyName, string destFilePath)
		{
			string cmd = "Reg.exe";
			string args = string.Format("EXPORT HKLM\\{0}{1} \"{2}\"", "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall", keyName, destFilePath);
			if (File.Exists(destFilePath))
			{
				File.Delete(destFilePath);
			}
			return RunCommand.RunCmd(cmd, args, true, true, false, 0).ExitCode;
		}

		// Token: 0x06000A13 RID: 2579 RVA: 0x0002C63C File Offset: 0x0002A83C
		public static int ImportRegistryFile(string regFilePath, bool requireAdminProc)
		{
			string cmd = "Reg.exe";
			string args = string.Format("IMPORT \"{0}\"", regFilePath);
			return RunCommand.RunCmd(cmd, args, true, true, requireAdminProc, 0).ExitCode;
		}

		// Token: 0x06000A14 RID: 2580 RVA: 0x0002C66C File Offset: 0x0002A86C
		public static string[] FixDuplicate7zArgs(string[] args)
		{
			string[] array;
			if (args.Length != 0)
			{
				if (args.Length == 1)
				{
					args[0] = args[0].Remove(args[0].Length / 2);
					array = args;
				}
				else
				{
					int num = args.Length / 2 + 1;
					array = new string[num];
					if (args[args.Length / 2].EndsWith(args[0]))
					{
						for (int i = 0; i <= num - 1; i++)
						{
							array[i] = args[i];
						}
						array[num - 1] = array[num - 1].Remove(array[num - 1].LastIndexOf(args[0]));
					}
				}
			}
			else
			{
				array = args;
			}
			return array;
		}

		// Token: 0x06000A15 RID: 2581 RVA: 0x00009FEE File Offset: 0x000081EE
		public static string GetMultiInstanceEventName(string vmName)
		{
			return string.Format("{0}-{1}", "BstClient", vmName);
		}

		// Token: 0x06000A16 RID: 2582 RVA: 0x0002C6F4 File Offset: 0x0002A8F4
		public static int GetVmIdToCreate()
		{
			int num = RegistryManager.Instance.VmId;
			for (;;)
			{
				string path = string.Format("Android_{0}", num);
				if (!Directory.Exists(Path.Combine(RegistryStrings.DataDir, path)))
				{
					break;
				}
				num++;
				Logger.Info("Incrementing vmId: {0}", new object[]
				{
					num
				});
			}
			RegistryManager.Instance.VmId = num + 1;
			return num;
		}

		// Token: 0x06000A17 RID: 2583 RVA: 0x0002C75C File Offset: 0x0002A95C
		public static JsonSerializerSettings GetSerializerSettings()
		{
			JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings();
			jsonSerializerSettings.NullValueHandling = NullValueHandling.Ignore;
			jsonSerializerSettings.MissingMemberHandling = MissingMemberHandling.Ignore;
			jsonSerializerSettings.Converters.Add(new StringEnumConverter());
			jsonSerializerSettings.TypeNameHandling = TypeNameHandling.Auto;
			jsonSerializerSettings.Error = (EventHandler<Newtonsoft.Json.Serialization.ErrorEventArgs>)Delegate.Combine(jsonSerializerSettings.Error, new EventHandler<Newtonsoft.Json.Serialization.ErrorEventArgs>(Utils.JsonSerializer_Error));
			jsonSerializerSettings.TypeNameAssemblyFormatHandling = TypeNameAssemblyFormatHandling.Simple;
			return jsonSerializerSettings;
		}

		// Token: 0x06000A18 RID: 2584 RVA: 0x0000A000 File Offset: 0x00008200
		private static void JsonSerializer_Error(object sender, Newtonsoft.Json.Serialization.ErrorEventArgs e)
		{
			e.ErrorContext.Handled = true;
			Logger.Error("Error loading JSON " + e.ErrorContext.Path + Environment.NewLine + e.ErrorContext.Error.ToString());
		}

		// Token: 0x06000A19 RID: 2585 RVA: 0x0002C7BC File Offset: 0x0002A9BC
		internal static void OpenUrl(string url)
		{
			try
			{
				Process.Start(url);
			}
			catch (Win32Exception)
			{
				try
				{
					Process.Start("IExplore.exe", url);
				}
				catch (Exception ex)
				{
					Logger.Warning("Not able to launch the url " + url + "Ignoring Exception: " + ex.ToString());
				}
			}
			catch (Exception ex2)
			{
				Logger.Warning("Not able to launch the url " + url + "Ignoring Exception: " + ex2.ToString());
			}
		}

		// Token: 0x06000A1A RID: 2586 RVA: 0x0002C848 File Offset: 0x0002AA48
		public static string GetDpiFromBootParameters(string bootParameterString)
		{
			string[] array = bootParameterString.Split(new char[]
			{
				' '
			});
			string text = null;
			foreach (string text2 in array)
			{
				if (text2.StartsWith("DPI=", StringComparison.OrdinalIgnoreCase))
				{
					text = text2.Split(new char[]
					{
						'='
					})[1];
					break;
				}
			}
			if (text == null)
			{
				text = "240";
			}
			return text;
		}

		// Token: 0x06000A1B RID: 2587 RVA: 0x0002C8AC File Offset: 0x0002AAAC
		public static void SetDPIInBootParameters(string bootParameterString, string updatedValue, string vmName)
		{
			string[] array = bootParameterString.Split(new char[]
			{
				' '
			});
			string text = null;
			foreach (string text2 in array)
			{
				if (text2.StartsWith("DPI=", StringComparison.OrdinalIgnoreCase))
				{
					text = text2.Split(new char[]
					{
						'='
					})[0];
					string text3 = text2.Split(new char[]
					{
						'='
					})[1];
					if (text3 != updatedValue)
					{
						string newValue = string.Format("DPI={0}", updatedValue);
						string oldValue = string.Format("DPI={0}", text3);
						string bootParameters = bootParameterString.Replace(oldValue, newValue);
						RegistryManager.Instance.Guest[vmName].BootParameters = bootParameters;
					}
				}
			}
			if (text == null)
			{
				string arg = string.Format("DPI={0}", updatedValue);
				string bootParameters2 = string.Format("{0} {1}", bootParameterString, arg);
				RegistryManager.Instance.Guest[vmName].BootParameters = bootParameters2;
			}
		}

		// Token: 0x06000A1C RID: 2588 RVA: 0x0002C99C File Offset: 0x0002AB9C
		public static IntPtr BringToFront(string windowName)
		{
			Logger.Info("Window name is = " + windowName);
			IntPtr result = IntPtr.Zero;
			try
			{
				result = InteropWindow.BringWindowToFront(windowName, false, true);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in bringing existing window to the foreground Err : " + ex.ToString());
			}
			return result;
		}

		// Token: 0x06000A1D RID: 2589 RVA: 0x0000A03D File Offset: 0x0000823D
		public static void SendChangeFPSToInstanceASync(string vmname, int newFps = 2147483647)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					VmCmdHandler.RunCommand(string.Format("setfpsvalue?fps={0}", (newFps == int.MaxValue) ? RegistryManager.Instance.Guest[vmname].FPS : newFps), vmname);
				}
				catch (Exception arg)
				{
					Logger.Warning("Exception in SendChangeFPSToInstanceASync. Error: " + arg);
				}
			});
		}

		// Token: 0x06000A1E RID: 2590 RVA: 0x0002C9F4 File Offset: 0x0002ABF4
		public static void SendShowFPSToInstanceASync(string vmname, int isShowFPS)
		{
			HTTPUtils.SendRequestToEngineAsync("showFPS", new Dictionary<string, string>
			{
				{
					"isshowfps",
					isShowFPS.ToString()
				}
			}, vmname, 0, null, true, 1, 0);
		}

		// Token: 0x06000A1F RID: 2591 RVA: 0x0002CA2C File Offset: 0x0002AC2C
		public static bool CheckMultiInstallBeforeRunQuitMultiInstall()
		{
			try
			{
				RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("Software");
				int num = 0;
				foreach (string text in registryKey.GetSubKeyNames())
				{
					if (text.StartsWith("BlueStacks") && !text.StartsWith("BlueStacksGP") && !text.StartsWith("BlueStacksInstaller"))
					{
						num++;
					}
				}
				if (num >= 2)
				{
					return true;
				}
			}
			catch (Exception ex)
			{
				Logger.Info("error at CheckMultiInstallBeforeRunQuitMultiInstall" + ex.ToString());
			}
			return false;
		}

		// Token: 0x06000A20 RID: 2592 RVA: 0x0002CAC8 File Offset: 0x0002ACC8
		public static bool PingPartner(string vmName)
		{
			try
			{
				int partnerServerPort = RegistryManager.Instance.PartnerServerPort;
				if (BstHttpClient.Get(string.Format("http://127.0.0.1:{0}/ping", partnerServerPort), null, false, vmName, 0, 1, 0, false).Contains("success"))
				{
					return true;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to ping partner server. Exc: " + ex.ToString());
			}
			return false;
		}

		// Token: 0x06000A21 RID: 2593 RVA: 0x0000A063 File Offset: 0x00008263
		public static void WriteAgentPortInFile(int port)
		{
			new Thread(delegate()
			{
				int i = 5;
				while (i > 0)
				{
					try
					{
						Utils.WriteToFile(Path.Combine(RegistryManager.Instance.UserDefinedDir, "bst_params.txt"), string.Format("agentserverport={0}", port), "agentserverport");
						break;
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to write agent port to bst_params.txt. Ex: " + ex.ToString());
					}
					Logger.Info("retrying..." + i);
					i--;
					Thread.Sleep(500);
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000A22 RID: 2594 RVA: 0x00019020 File Offset: 0x00017220
		private static void WriteToFile(string path, string text, string searchText = "")
		{
			bool flag = true;
			List<string> list = new List<string>();
			if (File.Exists(path))
			{
				foreach (string text2 in File.ReadAllLines(path))
				{
					if (text2.Contains("="))
					{
						if (text2.Contains(searchText))
						{
							list.Add(text);
							flag = false;
						}
						else
						{
							list.Add(text2);
						}
					}
				}
			}
			if (flag)
			{
				using (TextWriter textWriter = new StreamWriter(path, true))
				{
					textWriter.WriteLine(text);
					textWriter.Flush();
					return;
				}
			}
			using (TextWriter textWriter2 = new StreamWriter(path, false))
			{
				foreach (string value in list)
				{
					textWriter2.WriteLine(value);
				}
				textWriter2.Flush();
			}
		}

		// Token: 0x06000A23 RID: 2595 RVA: 0x0002CB3C File Offset: 0x0002AD3C
		public static int RunQuitMultiInstall()
		{
			string installDir = RegistryStrings.InstallDir;
			string text = "HD-QuitMultiInstall.exe";
			int exitCode;
			try
			{
				string text2 = Path.Combine(installDir, text);
				Process process = new Process();
				process.StartInfo.Arguments = "-in";
				process.StartInfo.UseShellExecute = false;
				process.StartInfo.CreateNoWindow = true;
				process.StartInfo.FileName = text2;
				Logger.Info("Complete path to QuitMultiInstall: " + text2);
				if (Environment.OSVersion.Version.Major <= 5)
				{
					process.StartInfo.Verb = "runas";
				}
				Logger.Info("Utils: Starting QuitMultiInstall with -in");
				process.Start();
				process.WaitForExit();
				exitCode = process.ExitCode;
			}
			catch (Exception ex)
			{
				Logger.Error("An error occured: {0}", new object[]
				{
					ex
				});
				Process process2 = new Process();
				process2.StartInfo.Arguments = "-in";
				process2.StartInfo.UseShellExecute = false;
				process2.StartInfo.CreateNoWindow = true;
				process2.StartInfo.FileName = text;
				process2.StartInfo.WorkingDirectory = installDir;
				Logger.Info("Running {0} with WorkingDir {1}", new object[]
				{
					text,
					installDir
				});
				if (Environment.OSVersion.Version.Major <= 5)
				{
					process2.StartInfo.Verb = "runas";
				}
				Logger.Info("Utils: Starting QuitMultiInstall with -in");
				process2.Start();
				process2.WaitForExit();
				exitCode = process2.ExitCode;
			}
			return exitCode;
		}

		// Token: 0x06000A24 RID: 2596 RVA: 0x0002CCC4 File Offset: 0x0002AEC4
		public static bool WaitForBGPClientPing(int retries = 40)
		{
			while (retries > 0)
			{
				try
				{
					if (JArray.Parse(HTTPUtils.SendRequestToClient("ping", null, "Android", 1000, null, false, 1, 0))[0]["success"].ToString().Trim().Equals("true", StringComparison.InvariantCultureIgnoreCase))
					{
						Logger.Debug("got ping response from client");
						return true;
					}
				}
				catch
				{
				}
				retries--;
				Thread.Sleep(500);
			}
			return false;
		}

		// Token: 0x06000A25 RID: 2597 RVA: 0x0000A08D File Offset: 0x0000828D
		public static IWin32Window GetIWin32Window(IntPtr handle)
		{
			return new Utils.OldWindow(handle);
		}

		// Token: 0x06000A26 RID: 2598 RVA: 0x0002CD54 File Offset: 0x0002AF54
		public static string GetPackageNameFromAPK(string apkFile)
		{
			string result = null;
			try
			{
				Process process = new Process();
				process.StartInfo.UseShellExecute = false;
				process.StartInfo.CreateNoWindow = true;
				process.StartInfo.RedirectStandardOutput = true;
				process.StartInfo.StandardOutputEncoding = Encoding.UTF8;
				process.StartInfo.FileName = Path.Combine(RegistryStrings.InstallDir, "hd-aapt.exe");
				process.StartInfo.Arguments = string.Format("dump badging \"{0}\"", apkFile);
				process.Start();
				string input = process.StandardOutput.ReadToEnd();
				process.WaitForExit();
				result = new Regex("package:\\sname='(.+?)'").Match(input).Groups[1].Value.ToString();
			}
			catch (Exception ex)
			{
				Logger.Error("Error getting apk name: {0}", new object[]
				{
					ex.Message
				});
			}
			return result;
		}

		// Token: 0x06000A27 RID: 2599 RVA: 0x0002CE3C File Offset: 0x0002B03C
		public static string GetFileAssemblyVersion(string path)
		{
			string result = string.Empty;
			if (File.Exists(path))
			{
				try
				{
					result = FileVersionInfo.GetVersionInfo(path).FileVersion;
				}
				catch (Exception ex)
				{
					Logger.Error("Error in parsing file version information: {0}", new object[]
					{
						ex.Message
					});
				}
			}
			return result;
		}

		// Token: 0x06000A28 RID: 2600 RVA: 0x0000A095 File Offset: 0x00008295
		public static string GetHelperInstalledPath()
		{
			return Path.Combine(Path.Combine(RegistryManager.Instance.ClientInstallDir, "Helper"), "BlueStacksHelper.exe");
		}

		// Token: 0x06000A29 RID: 2601 RVA: 0x0002CE94 File Offset: 0x0002B094
		public static string GetHelperTaskDetailsJSon()
		{
			try
			{
				RunCommand.CmdRes taskQueryCommandOutput = TaskScheduler.GetTaskQueryCommandOutput("BlueStacksHelper");
				JObject jobject = new JObject();
				string[] array = taskQueryCommandOutput.StdOut.Split(new char[]
				{
					'\n'
				});
				string[] array2 = taskQueryCommandOutput.StdErr.Split(new char[]
				{
					'\n'
				});
				JObject jobject2 = new JObject();
				int num = 1;
				foreach (string value in array)
				{
					if (!string.IsNullOrEmpty(value))
					{
						jobject2.Add(string.Format("line{0}", num), value);
						num++;
					}
				}
				jobject.Add("stdout", jobject2.ToString());
				jobject2 = new JObject();
				num = 1;
				foreach (string value2 in array2)
				{
					if (!string.IsNullOrEmpty(value2))
					{
						jobject2.Add(string.Format("line{0}", num), value2);
						num++;
					}
				}
				jobject.Add("stderr", jobject2.ToString());
				return jobject.ToString(Formatting.None, new JsonConverter[0]);
			}
			catch (Exception ex)
			{
				Logger.Error("Some error while creating json of the QueryTask: {0}", new object[]
				{
					ex
				});
			}
			return "";
		}

		// Token: 0x06000A2A RID: 2602 RVA: 0x0002D008 File Offset: 0x0002B208
		public static bool HasOneDayPassed(DateTime srcTime)
		{
			try
			{
				double totalMinutes = (DateTime.Now - srcTime).TotalMinutes;
				double num = 1440.0;
				if (totalMinutes > num)
				{
					return true;
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Couldn't check if the req time has passed. Ex: {0}", new object[]
				{
					ex.Message
				});
			}
			return false;
		}

		// Token: 0x06000A2B RID: 2603 RVA: 0x0002D06C File Offset: 0x0002B26C
		public static string GetTwoLetterISOLanguageNameFromLocale(string requestedLocale)
		{
			try
			{
				return new CultureInfo(requestedLocale).TwoLetterISOLanguageName;
			}
			catch
			{
			}
			return requestedLocale.Split(new char[]
			{
				'-'
			})[0];
		}

		// Token: 0x06000A2C RID: 2604 RVA: 0x0002D0B0 File Offset: 0x0002B2B0
		public static string GetRegionFromLocale(string requestedLocale)
		{
			try
			{
				return new RegionInfo(new CultureInfo(requestedLocale).LCID).Name;
			}
			catch
			{
			}
			string[] array = requestedLocale.Split(new char[]
			{
				'-'
			});
			return array[array.Length - 1];
		}

		// Token: 0x06000A2D RID: 2605 RVA: 0x0002D104 File Offset: 0x0002B304
		public static string GetAndroidIDFromAndroid(string vmName)
		{
			string result = string.Empty;
			try
			{
				JObject jobject = JObject.Parse(HTTPUtils.SendRequestToGuest("getAndroidID", null, vmName, 0, null, false, 1, 0));
				if (jobject["result"].ToString() == "ok")
				{
					result = jobject["androidID"].ToString();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in getting Android ID: {0}", new object[]
				{
					ex.ToString()
				});
			}
			return result;
		}

		// Token: 0x06000A2E RID: 2606 RVA: 0x0002D18C File Offset: 0x0002B38C
		public static string GetGoogleAdIDFromAndroid(string vmName)
		{
			string result = string.Empty;
			try
			{
				JObject jobject = JObject.Parse(HTTPUtils.SendRequestToGuest("getGoogleAdID", null, vmName, 0, null, false, 1, 0));
				if (jobject["result"].ToString() == "ok")
				{
					result = jobject["googleadid"].ToString();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in getting googleAd ID: {0}", new object[]
				{
					ex.ToString()
				});
			}
			return result;
		}

		// Token: 0x06000A2F RID: 2607 RVA: 0x0000A0B5 File Offset: 0x000082B5
		public static void SetGoogleAdIdAndAndroidIdFromAndroid(string vmName)
		{
			new Thread(delegate()
			{
				try
				{
					string googleAdIDFromAndroid = Utils.GetGoogleAdIDFromAndroid(vmName);
					if (!string.IsNullOrEmpty(googleAdIDFromAndroid))
					{
						RegistryManager.Instance.Guest[vmName].GoogleAId = UUID.Base64Encode(googleAdIDFromAndroid);
					}
					string androidIDFromAndroid = Utils.GetAndroidIDFromAndroid(vmName);
					if (!string.IsNullOrEmpty(androidIDFromAndroid))
					{
						RegistryManager.Instance.Guest[vmName].AndroidId = UUID.Base64Encode(androidIDFromAndroid);
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception while getting ids from android: {0}", new object[]
					{
						ex.ToString()
					});
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000A30 RID: 2608 RVA: 0x0002D214 File Offset: 0x0002B414
		public static string GetGoogleAdIdfromRegistry(string vmName)
		{
			string s = string.Empty;
			try
			{
				s = UUID.Base64Decode(RegistryManager.Instance.Guest[vmName].GoogleAId);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in decoding GoogleAid: {0}", new object[]
				{
					ex.ToString()
				});
			}
			return StringUtils.GetControlCharFreeString(s);
		}

		// Token: 0x06000A31 RID: 2609 RVA: 0x0002D278 File Offset: 0x0002B478
		public static string GetAndroidIdfromRegistry(string vmName)
		{
			string s = string.Empty;
			try
			{
				s = UUID.Base64Decode(RegistryManager.Instance.Guest[vmName].AndroidId);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in decoding AndroidID ID: {0}", new object[]
				{
					ex.ToString()
				});
			}
			return StringUtils.GetControlCharFreeString(s);
		}

		// Token: 0x06000A32 RID: 2610 RVA: 0x0000A0DF File Offset: 0x000082DF
		public static void CreateMD5HashOfRootVdi()
		{
			new Thread(delegate()
			{
				try
				{
					string blockDevice0Path = RegistryManager.Instance.Guest["Android"].BlockDevice0Path;
					RegistryManager.Instance.RootVdiMd5Hash = Utils.GetMD5HashFromFile(blockDevice0Path);
				}
				catch (Exception ex)
				{
					Logger.Error("Exception while checking md5 hash of root.vdi: {0}", new object[]
					{
						ex.ToString()
					});
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000A33 RID: 2611 RVA: 0x0002D2DC File Offset: 0x0002B4DC
		public static int GetMaxVmIdFromVmList(string[] vmList)
		{
			int num = 0;
			try
			{
				foreach (string text in vmList)
				{
					if (!(text == "Android"))
					{
						int num2;
						int.TryParse(text.Split(new char[]
						{
							'_'
						})[1], out num2);
						if (num < num2)
						{
							num = num2;
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in getting max VmId to create err:", new object[]
				{
					ex.ToString()
				});
			}
			return num + 1;
		}

		// Token: 0x06000A34 RID: 2612 RVA: 0x0002D364 File Offset: 0x0002B564
		public static int GetRecommendedVCPUCount(bool isDefaultVm)
		{
			int result = 2;
			if (!isDefaultVm)
			{
				result = 1;
			}
			return result;
		}

		// Token: 0x06000A35 RID: 2613 RVA: 0x0002D37C File Offset: 0x0002B57C
		public static void SetTimeZoneInGuest(string vmName)
		{
			string value = TimeZone.CurrentTimeZone.StandardName;
			TimeSpan utcOffset = TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now);
			string text = utcOffset.ToString();
			if (text[0] != '-')
			{
				text = string.Format("GMT+{0}", text);
			}
			else
			{
				text = string.Format("GMT{0}", text);
			}
			string text2 = TimeZone.CurrentTimeZone.IsDaylightSavingTime(DateTime.Now).ToString();
			string text3 = Profile.GetSysInfo("Select DaylightBias from Win32_TimeZone");
			string text4;
			if (text2.Equals("True", StringComparison.InvariantCultureIgnoreCase) && text3 != "")
			{
				text4 = utcOffset.Add(new TimeSpan(0, Convert.ToInt32(text3), 0)).ToString();
				if (text4[0] != '-')
				{
					text4 = string.Format("GMT+{0}", text4);
				}
				else
				{
					text4 = string.Format("GMT{0}", text4);
				}
			}
			else
			{
				text4 = text;
			}
			if (Features.IsFeatureEnabled(4194304UL))
			{
				text4 = "GMT+08:00:00";
				text2 = "False";
				text3 = "0";
				text = "GMT+08:00:00";
				value = "中国标准时间";
			}
			else if ("bgp".Equals("dmm"))
			{
				text4 = "GMT+09:00:00";
				text2 = "False";
				text3 = "0";
				text = "GMT+09:00:00";
				value = "日本の標準時";
			}
			JObject jobject;
			VmCmdHandler.SendRequest("settz", new Dictionary<string, string>
			{
				{
					"baseUtcOffset",
					text4
				},
				{
					"isDaylightSavingTime",
					text2
				},
				{
					"daylightBias",
					text3
				},
				{
					"utcOffset",
					text
				},
				{
					"standardName",
					value
				}
			}, vmName, out jobject);
		}

		// Token: 0x06000A36 RID: 2614 RVA: 0x0002D528 File Offset: 0x0002B728
		public static void RunHDQuit(bool isWaitForExit = false, bool isFromClient = false)
		{
			Logger.Info("Quit bluestacks called with args: {0}, {1}", new object[]
			{
				isWaitForExit,
				isFromClient
			});
			string fileName = Path.Combine(RegistryStrings.InstallDir, "HD-Quit.exe");
			Process process = new Process();
			process.StartInfo.FileName = fileName;
			if (!FeatureManager.Instance.IsCustomUIForDMM)
			{
				process.StartInfo.Arguments = "-ignoreAgent";
			}
			if (isFromClient)
			{
				ProcessStartInfo startInfo = process.StartInfo;
				startInfo.Arguments += " -isFromClient";
			}
			Logger.Debug("Quit Aguments = " + process.StartInfo.Arguments);
			process.Start();
			if (isWaitForExit)
			{
				process.WaitForExit();
			}
		}

		// Token: 0x06000A37 RID: 2615 RVA: 0x0002D5E0 File Offset: 0x0002B7E0
		public static JToken ExtractInfoFromXapk(string zipFilePath)
		{
			JToken result = null;
			string path = Path.Combine(Path.GetTempPath(), Path.GetFileName(zipFilePath));
			if (File.Exists(Path.Combine(path, "manifest.json")))
			{
				result = JToken.Parse(File.ReadAllText(Path.Combine(path, "manifest.json")));
			}
			return result;
		}

		// Token: 0x06000A38 RID: 2616 RVA: 0x0002D62C File Offset: 0x0002B82C
		public static bool CheckIfDeviceProfileChanged(JObject mCurrentDeviceProfile, JObject mChangedDeviceProfile)
		{
			return !string.Equals(mCurrentDeviceProfile["pcode"].ToString(), mChangedDeviceProfile["pcode"].ToString()) || (string.Equals(mCurrentDeviceProfile["pcode"].ToString(), "custom") && (!string.Equals(mCurrentDeviceProfile["model"].ToString(), mChangedDeviceProfile["model"].ToString()) || !string.Equals(mCurrentDeviceProfile["brand"].ToString(), mChangedDeviceProfile["brand"].ToString()) || !string.Equals(mCurrentDeviceProfile["manufacturer"].ToString(), mChangedDeviceProfile["manufacturer"].ToString())));
		}

		// Token: 0x06000A39 RID: 2617 RVA: 0x0002D6F8 File Offset: 0x0002B8F8
		public static bool CheckForInternetConnection()
		{
			bool result;
			try
			{
				using (WebClient webClient = new WebClient())
				{
					using (webClient.OpenRead("http://connectivitycheck.gstatic.com/generate_204"))
					{
						result = true;
					}
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000A3A RID: 2618 RVA: 0x0002D760 File Offset: 0x0002B960
		public static string[] AddVmNameInArgsIfNotPresent(string[] args)
		{
			if (!Utils.CheckIfVmNamePassedToArgs(args))
			{
				string text = Utils.CheckIfAnyVmRunning();
				List<string> list = args.ToList<string>();
				if (!string.IsNullOrEmpty(text))
				{
					list.Add("-vmname");
					list.Add(text);
				}
				args = list.ToArray();
			}
			return args;
		}

		// Token: 0x06000A3B RID: 2619 RVA: 0x0002D7A8 File Offset: 0x0002B9A8
		private static string CheckIfAnyVmRunning()
		{
			foreach (object obj in RegistryManager.Instance.VmList)
			{
				string text = obj as string;
				if (Utils.CheckIfGuestReady(text, 1))
				{
					return text;
				}
			}
			return null;
		}

		// Token: 0x06000A3C RID: 2620 RVA: 0x0002D7E8 File Offset: 0x0002B9E8
		private static bool CheckIfVmNamePassedToArgs(string[] args)
		{
			IEnumerable<string> first = args.ToList<string>();
			IList<string> second = new List<string>
			{
				"--vmname",
				"-vmname",
				"vmname"
			};
			return first.Intersect(second).Count<string>() > 0;
		}

		// Token: 0x06000A3E RID: 2622 RVA: 0x0002D834 File Offset: 0x0002BA34
		// Note: this type is marked as 'beforefieldinit'.
		static Utils()
		{
			Utils.GuestBootCallBack = null;
			Utils.sIsSyncAppJsonComplete = false;
			Utils.sIsWaitLockExist = false;
			Utils.VmLockNamedata = new Dictionary<string, object>();
			Utils.sIsGuestBooted = new Dictionary<string, bool>();
			Utils.sIsGuestReady = new Dictionary<string, bool>();
			Utils.sIsSharedFolderMounted = new Dictionary<string, bool>();
			Utils.waitingForCallback = false;
			Utils.sListIgnoredApps = new List<string>
			{
				"tv.gamepop.home",
				"com.pop.store",
				"com.pop.store51",
				"com.bluestacks.s2p5105",
				"mpi.v23",
				"com.google.android.gms",
				"com.google.android.gsf.login",
				"com.android.deskclock",
				"me.onemobile.android",
				"me.onemobile.lite.android",
				"android.rk.RockVideoPlayer.RockVideoPlayer",
				"com.bluestacks.chartapp",
				"com.bluestacks.setupapp",
				"com.android.gallery3d",
				"com.bluestacks.keymappingtool",
				"com.baidu.appsearch",
				"com.bluestacks.s2p",
				"com.bluestacks.windowsfilemanager",
				"com.android.quicksearchbox",
				"com.bluestacks.setup",
				"com.bluestacks.appsettings",
				"mpi.v23",
				"com.bluestacks.setup",
				"com.bluestacks.gamepophome",
				"com.bluestacks.appfinder",
				"com.android.providers.downloads.ui"
			};
		}

		// Token: 0x040006F2 RID: 1778
		private const int SM_TABLETPC = 86;

		// Token: 0x040006F3 RID: 1779
		private const int TASKBAR_HEIGHT = 48;

		// Token: 0x040006F4 RID: 1780
		public const int BTV_RIGHT_PANEL_WIDTH = 320;

		// Token: 0x040006F6 RID: 1782
		private static bool sIsSyncAppJsonComplete;

		// Token: 0x040006F7 RID: 1783
		private const int SM_CXSCREEN = 0;

		// Token: 0x040006F8 RID: 1784
		private const int SM_CYSCREEN = 1;

		// Token: 0x040006F9 RID: 1785
		public static bool sIsWaitLockExist;

		// Token: 0x040006FA RID: 1786
		private static Dictionary<string, object> VmLockNamedata;

		// Token: 0x040006FB RID: 1787
		public static Dictionary<string, bool> sIsGuestBooted;

		// Token: 0x040006FC RID: 1788
		public static Dictionary<string, bool> sIsGuestReady;

		// Token: 0x040006FD RID: 1789
		public static Dictionary<string, bool> sIsSharedFolderMounted;

		// Token: 0x040006FE RID: 1790
		private const int PROC_KILL_TIMEOUT = 10000;

		// Token: 0x040006FF RID: 1791
		private const int COMSERVER_EXIT_TIMEOUT = 5000;

		// Token: 0x04000700 RID: 1792
		private static bool waitingForCallback;

		// Token: 0x04000701 RID: 1793
		public static List<string> sListIgnoredApps;

		// Token: 0x02000117 RID: 279
		public struct SP_DEVINFO_DATA
		{
			// Token: 0x04000702 RID: 1794
			public int cbSize;

			// Token: 0x04000703 RID: 1795
			public Guid ClassGuid;

			// Token: 0x04000704 RID: 1796
			public int DevInst;

			// Token: 0x04000705 RID: 1797
			public int Reserved;
		}

		// Token: 0x02000118 RID: 280
		[Flags]
		public enum ClassDevsFlags
		{
			// Token: 0x04000707 RID: 1799
			DIGCF_DEFAULT = 1,
			// Token: 0x04000708 RID: 1800
			DIGCF_PRESENT = 2,
			// Token: 0x04000709 RID: 1801
			DIGCF_ALLCLASSES = 4,
			// Token: 0x0400070A RID: 1802
			DIGCF_PROFILE = 8,
			// Token: 0x0400070B RID: 1803
			DIGCF_DEVICEINTERFACE = 16
		}

		// Token: 0x02000119 RID: 281
		public struct SP_DEVICE_INTERFACE_DATA
		{
			// Token: 0x0400070C RID: 1804
			public int cbSize;

			// Token: 0x0400070D RID: 1805
			public Guid InterfaceClassGuid;

			// Token: 0x0400070E RID: 1806
			public int Flags;

			// Token: 0x0400070F RID: 1807
			public int Reserved;
		}

		// Token: 0x0200011A RID: 282
		public struct PSP_DEVICE_INTERFACE_DETAIL_DATA
		{
			// Token: 0x04000710 RID: 1808
			public int cbSize;

			// Token: 0x04000711 RID: 1809
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
			public string DevicePath;
		}

		// Token: 0x0200011B RID: 283
		public enum GamePadEventType
		{
			// Token: 0x04000713 RID: 1811
			TYPE_GAMEPAD_ATTACH,
			// Token: 0x04000714 RID: 1812
			TYPE_GAMEPAD_DETACH,
			// Token: 0x04000715 RID: 1813
			TYPE_GAMEPAD_UPDATE
		}

		// Token: 0x0200011C RID: 284
		public enum RegPropertyType
		{
			// Token: 0x04000717 RID: 1815
			SPDRP_DEVICEDESC,
			// Token: 0x04000718 RID: 1816
			SPDRP_HARDWAREID,
			// Token: 0x04000719 RID: 1817
			SPDRP_COMPATIBLEIDS,
			// Token: 0x0400071A RID: 1818
			SPDRP_UNUSED0,
			// Token: 0x0400071B RID: 1819
			SPDRP_SERVICE,
			// Token: 0x0400071C RID: 1820
			SPDRP_UNUSED1,
			// Token: 0x0400071D RID: 1821
			SPDRP_UNUSED2,
			// Token: 0x0400071E RID: 1822
			SPDRP_CLASS,
			// Token: 0x0400071F RID: 1823
			SPDRP_CLASSGUID,
			// Token: 0x04000720 RID: 1824
			SPDRP_DRIVER,
			// Token: 0x04000721 RID: 1825
			SPDRP_CONFIGFLAGS,
			// Token: 0x04000722 RID: 1826
			SPDRP_MFG,
			// Token: 0x04000723 RID: 1827
			SPDRP_FRIENDLYNAME,
			// Token: 0x04000724 RID: 1828
			SPDRP_LOCATION_INFORMATION,
			// Token: 0x04000725 RID: 1829
			SPDRP_PHYSICAL_DEVICE_OBJECT_NAME,
			// Token: 0x04000726 RID: 1830
			SPDRP_CAPABILITIES,
			// Token: 0x04000727 RID: 1831
			SPDRP_UI_NUMBER,
			// Token: 0x04000728 RID: 1832
			SPDRP_UPPERFILTERS,
			// Token: 0x04000729 RID: 1833
			SPDRP_LOWERFILTERS,
			// Token: 0x0400072A RID: 1834
			SPDRP_BUSTYPEGUID,
			// Token: 0x0400072B RID: 1835
			SPDRP_LEGACYBUSTYPE,
			// Token: 0x0400072C RID: 1836
			SPDRP_BUSNUMBER,
			// Token: 0x0400072D RID: 1837
			SPDRP_ENUMERATOR_NAME,
			// Token: 0x0400072E RID: 1838
			SPDRP_SECURITY,
			// Token: 0x0400072F RID: 1839
			SPDRP_SECURITY_SDS,
			// Token: 0x04000730 RID: 1840
			SPDRP_DEVTYPE,
			// Token: 0x04000731 RID: 1841
			SPDRP_EXCLUSIVE,
			// Token: 0x04000732 RID: 1842
			SPDRP_CHARACTERISTICS,
			// Token: 0x04000733 RID: 1843
			SPDRP_ADDRESS,
			// Token: 0x04000734 RID: 1844
			SPDRP_UI_NUMBER_DESC_FORMAT = 30,
			// Token: 0x04000735 RID: 1845
			SPDRP_MAXIMUM_PROPERTY
		}

		// Token: 0x0200011D RID: 285
		public struct DATA_BUFFER
		{
			// Token: 0x04000736 RID: 1846
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 1024)]
			public string Buffer;
		}

		// Token: 0x0200011E RID: 286
		public class CmdRes
		{
			// Token: 0x04000737 RID: 1847
			public string StdOut = "";

			// Token: 0x04000738 RID: 1848
			public string StdErr = "";

			// Token: 0x04000739 RID: 1849
			public int ExitCode;
		}

		// Token: 0x0200011F RID: 287
		private class OldWindow : IWin32Window
		{
			// Token: 0x06000A40 RID: 2624 RVA: 0x0000A12F File Offset: 0x0000832F
			public OldWindow(IntPtr handle)
			{
				this._handle = handle;
			}

			// Token: 0x170002B4 RID: 692
			// (get) Token: 0x06000A41 RID: 2625 RVA: 0x0000A13E File Offset: 0x0000833E
			IntPtr IWin32Window.Handle
			{
				get
				{
					return this._handle;
				}
			}

			// Token: 0x0400073A RID: 1850
			private readonly IntPtr _handle;
		}
	}
}
