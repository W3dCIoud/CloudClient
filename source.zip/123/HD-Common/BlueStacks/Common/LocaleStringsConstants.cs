﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200007F RID: 127
	public class LocaleStringsConstants
	{
		// Token: 0x040002E5 RID: 741
		public const string DefaultExitOption = "STRING_CLOSE_CURRENT_INSTANCE";

		// Token: 0x040002E6 RID: 742
		public static string[] ExitOptions = new string[]
		{
			"STRING_CLOSE_CURRENT_INSTANCE",
			"STRING_CLOSE_ALL_RUNNING_INSTANCES"
		};

		// Token: 0x040002E7 RID: 743
		public static string[] RestartOptions = new string[]
		{
			"STRING_RESTART_CURRENT_INSTANCE"
		};
	}
}
