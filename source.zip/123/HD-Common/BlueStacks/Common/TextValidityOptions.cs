﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000DE RID: 222
	public enum TextValidityOptions
	{
		// Token: 0x0400057E RID: 1406
		Success = 1,
		// Token: 0x0400057F RID: 1407
		Error = -1,
		// Token: 0x04000580 RID: 1408
		Warning
	}
}
