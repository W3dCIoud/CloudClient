﻿using System;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x020000E1 RID: 225
	public class AppInfo
	{
		// Token: 0x06000675 RID: 1653 RVA: 0x00006929 File Offset: 0x00004B29
		public AppInfo()
		{
		}

		// Token: 0x06000676 RID: 1654 RVA: 0x0001F5CC File Offset: 0x0001D7CC
		public AppInfo(JObject app)
		{
			this.name = app["name"].ToString();
			this.img = app["img"].ToString();
			this.package = app["package"].ToString();
			this.activity = app["activity"].ToString();
			this.system = app["system"].ToString();
			if (app.ContainsKey("url"))
			{
				this.url = app["url"].ToString();
			}
			else
			{
				this.url = null;
			}
			if (app.ContainsKey("appstore"))
			{
				this.appstore = app["appstore"].ToString();
			}
			else
			{
				this.appstore = "Unknown";
			}
			if (app.ContainsKey("version"))
			{
				this.version = app["version"].ToString();
			}
			else
			{
				this.version = "Unknown";
			}
			if (app.ContainsKey("gl3required"))
			{
				this.gl3required = app["gl3required"].ToObject<bool>();
			}
			else
			{
				this.gl3required = false;
			}
			if (app.ContainsKey("videopresent"))
			{
				this.videopresent = app["videopresent"].ToObject<bool>();
			}
			else
			{
				this.videopresent = false;
			}
			if (app.ContainsKey("versionName"))
			{
				this.versionName = app["versionName"].ToString();
			}
		}

		// Token: 0x06000677 RID: 1655 RVA: 0x0001F760 File Offset: 0x0001D960
		public AppInfo(string InName, string InImage, string InPackage, string InActivity, string InSystem, string InAppStore, string InVersion, bool InGl3required, bool InVideoPresent, string appVersionName)
		{
			this.name = InName;
			this.img = InImage;
			this.package = InPackage;
			this.activity = InActivity;
			this.system = InSystem;
			this.url = null;
			this.appstore = InAppStore;
			this.version = InVersion;
			this.gl3required = InGl3required;
			this.videopresent = InVideoPresent;
			this.versionName = appVersionName;
		}

		// Token: 0x04000584 RID: 1412
		public string name;

		// Token: 0x04000585 RID: 1413
		public string img;

		// Token: 0x04000586 RID: 1414
		public string package;

		// Token: 0x04000587 RID: 1415
		public string activity;

		// Token: 0x04000588 RID: 1416
		public string system;

		// Token: 0x04000589 RID: 1417
		public string url;

		// Token: 0x0400058A RID: 1418
		public string appstore;

		// Token: 0x0400058B RID: 1419
		public string version;

		// Token: 0x0400058C RID: 1420
		public string versionName = "Unknown";

		// Token: 0x0400058D RID: 1421
		public bool gl3required;

		// Token: 0x0400058E RID: 1422
		public bool videopresent;
	}
}
