﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000132 RID: 306
	public class WebHelper
	{
		// Token: 0x06000A82 RID: 2690 RVA: 0x0000A286 File Offset: 0x00008486
		public static string GetServerHost()
		{
			return RegistryManager.Instance.Host + "/bs3";
		}

		// Token: 0x06000A83 RID: 2691 RVA: 0x0000A29C File Offset: 0x0000849C
		public static string GetServerHostForFirebase()
		{
			return "https://us-central1-bluestacks-friends.cloudfunctions.net";
		}

		// Token: 0x06000A84 RID: 2692 RVA: 0x0002E6A0 File Offset: 0x0002C8A0
		public static string GetUrlWithParams(string url)
		{
			string str = "bgp";
			string clientVersion = RegistryManager.Instance.ClientVersion;
			string version = RegistryManager.Instance.Version;
			string userGuid = RegistryManager.Instance.UserGuid;
			string userSelectedLocale = RegistryManager.Instance.UserSelectedLocale;
			string partner = RegistryManager.Instance.Partner;
			string campaignMD = RegistryManager.Instance.CampaignMD5;
			string str2 = RegistryManager.Instance.InstallationType.ToString();
			string pkgName = GameConfig.Instance.PkgName;
			string text = "oem=";
			text += str;
			text += "&prod_ver=";
			text += clientVersion;
			text += "&eng_ver=";
			text += version;
			text += "&guid=";
			text += userGuid;
			text += "&locale=";
			text += userSelectedLocale;
			if (!string.IsNullOrEmpty(partner))
			{
				text += "&partner=";
			}
			text += partner;
			if (!string.IsNullOrEmpty(campaignMD))
			{
				text += "&campaign_md5=";
			}
			text += campaignMD;
			Uri uri = new Uri(url);
			if (uri.Host.Equals(WebHelper.sDefaultCloudHost.Host, StringComparison.InvariantCultureIgnoreCase) || uri.Host.Equals(WebHelper.sRegistryHost.Host, StringComparison.InvariantCultureIgnoreCase))
			{
				string registeredEmail = RegistryManager.Instance.RegisteredEmail;
				if (!string.IsNullOrEmpty(registeredEmail))
				{
					text += "&email=";
				}
				text += registeredEmail;
				string token = RegistryManager.Instance.Token;
				if (!string.IsNullOrEmpty(token))
				{
					text += "&token=";
				}
				text += token;
			}
			text += "&installation_type=";
			text += str2;
			if (!string.IsNullOrEmpty(pkgName))
			{
				text += "&gaming_pkg_name=";
			}
			text += pkgName;
			if (!url.Contains("://"))
			{
				url = "http://" + url;
			}
			url = HTTPUtils.MergeQueryParams(url, text, true);
			Logger.Debug("Returning updated URL: {0}", new object[]
			{
				url
			});
			return url;
		}

		// Token: 0x04000772 RID: 1906
		private static Uri sDefaultCloudHost = new Uri("https://cloud.bluestacks.com");

		// Token: 0x04000773 RID: 1907
		private static Uri sRegistryHost = new Uri(RegistryManager.Instance.Host);
	}
}
