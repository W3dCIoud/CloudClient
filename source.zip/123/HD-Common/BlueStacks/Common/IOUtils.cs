﻿using System;
using System.Collections.Generic;
using System.IO;

namespace BlueStacks.Common
{
	// Token: 0x02000163 RID: 355
	public class IOUtils
	{
		// Token: 0x06000B8C RID: 2956 RVA: 0x00031D7C File Offset: 0x0002FF7C
		public static void DeleteIfExists(IEnumerable<string> filesToDelete)
		{
			foreach (string text in filesToDelete)
			{
				try
				{
					if (File.Exists(text))
					{
						File.Delete(text);
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception while deleting file " + text + ex.ToString());
				}
			}
		}

		// Token: 0x06000B8D RID: 2957 RVA: 0x0000ABC5 File Offset: 0x00008DC5
		public static long GetAvailableDiskSpaceOfDrive(string path)
		{
			return new DriveInfo(path).AvailableFreeSpace;
		}

		// Token: 0x06000B8E RID: 2958 RVA: 0x0000ABD2 File Offset: 0x00008DD2
		public static string GetPartitionNameFromPath(string path)
		{
			return new DriveInfo(path).Name;
		}

		// Token: 0x06000B8F RID: 2959 RVA: 0x00031DF4 File Offset: 0x0002FFF4
		public static long GetDirectorySize(string dirPath)
		{
			if (!Directory.Exists(dirPath))
			{
				return 0L;
			}
			DirectoryInfo directoryInfo = new DirectoryInfo(dirPath);
			long num = 0L;
			foreach (FileInfo fileInfo in directoryInfo.GetFiles())
			{
				num += fileInfo.Length;
			}
			foreach (DirectoryInfo directoryInfo2 in directoryInfo.GetDirectories())
			{
				num += IOUtils.GetDirectorySize(directoryInfo2.FullName);
			}
			return num;
		}

		// Token: 0x06000B90 RID: 2960 RVA: 0x0000ABDF File Offset: 0x00008DDF
		public static bool IfPathExists(string path)
		{
			return new DirectoryInfo(path).Exists || new FileInfo(path).Exists;
		}

		// Token: 0x06000B91 RID: 2961 RVA: 0x00031E68 File Offset: 0x00030068
		public static string GetFileOrFolderName(string path)
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(path);
			if (directoryInfo.Exists)
			{
				return directoryInfo.Name;
			}
			FileInfo fileInfo = new FileInfo(path);
			if (fileInfo.Exists)
			{
				return fileInfo.Name;
			}
			throw new IOException("File or folder name does not exist");
		}

		// Token: 0x06000B92 RID: 2962 RVA: 0x00031EAC File Offset: 0x000300AC
		public static bool IsDirectoryEmpty(string dir)
		{
			bool result = true;
			if (!Directory.Exists(dir))
			{
				Logger.Info(dir + " does not exist");
				return result;
			}
			if (Directory.GetFiles(dir).Length == 0)
			{
				Logger.Info(dir + " is empty");
			}
			else
			{
				result = false;
			}
			foreach (string text in Directory.GetDirectories(dir))
			{
				Directory.GetFiles(text);
				if (!IOUtils.IsDirectoryEmpty(text))
				{
					result = false;
				}
			}
			return result;
		}

		// Token: 0x04000806 RID: 2054
		public static readonly char[] DisallowedCharsInDirs = new char[]
		{
			'&',
			'<',
			'>',
			'"',
			'\'',
			'^'
		};
	}
}
