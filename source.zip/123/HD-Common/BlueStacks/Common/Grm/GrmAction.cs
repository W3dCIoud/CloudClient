﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace BlueStacks.Common.Grm
{
	// Token: 0x020001C6 RID: 454
	public class GrmAction
	{
		// Token: 0x17000345 RID: 837
		// (get) Token: 0x06000DEC RID: 3564 RVA: 0x0000BE45 File Offset: 0x0000A045
		// (set) Token: 0x06000DED RID: 3565 RVA: 0x0000BE4D File Offset: 0x0000A04D
		[JsonProperty(PropertyName = "actionType")]
		public string ActionType { get; set; } = string.Empty;

		// Token: 0x17000346 RID: 838
		// (get) Token: 0x06000DEE RID: 3566 RVA: 0x0000BE56 File Offset: 0x0000A056
		// (set) Token: 0x06000DEF RID: 3567 RVA: 0x0000BE5E File Offset: 0x0000A05E
		[JsonProperty(PropertyName = "actionDictionary")]
		public Dictionary<string, string> ActionDictionary { get; set; } = new Dictionary<string, string>();
	}
}
