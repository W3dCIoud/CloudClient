﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace BlueStacks.Common.Grm
{
	// Token: 0x020001C9 RID: 457
	public class GrmExpression
	{
		// Token: 0x17000347 RID: 839
		// (get) Token: 0x06000DF5 RID: 3573 RVA: 0x0000BE85 File Offset: 0x0000A085
		// (set) Token: 0x06000DF6 RID: 3574 RVA: 0x0000BE8D File Offset: 0x0000A08D
		[JsonProperty(PropertyName = "leftOperand")]
		public string LeftOperand { get; set; } = string.Empty;

		// Token: 0x17000348 RID: 840
		// (get) Token: 0x06000DF7 RID: 3575 RVA: 0x0000BE96 File Offset: 0x0000A096
		// (set) Token: 0x06000DF8 RID: 3576 RVA: 0x0000BE9E File Offset: 0x0000A09E
		[JsonProperty(PropertyName = "operator")]
		public string Operator { get; set; } = string.Empty;

		// Token: 0x17000349 RID: 841
		// (get) Token: 0x06000DF9 RID: 3577 RVA: 0x0000BEA7 File Offset: 0x0000A0A7
		// (set) Token: 0x06000DFA RID: 3578 RVA: 0x0000BEAF File Offset: 0x0000A0AF
		[JsonProperty(PropertyName = "rightOperand")]
		public string RightOperand { get; set; } = string.Empty;

		// Token: 0x1700034A RID: 842
		// (get) Token: 0x06000DFB RID: 3579 RVA: 0x0000BEB8 File Offset: 0x0000A0B8
		// (set) Token: 0x06000DFC RID: 3580 RVA: 0x0000BEC0 File Offset: 0x0000A0C0
		[JsonProperty(PropertyName = "contextJson")]
		public string ContextJson { get; set; } = string.Empty;

		// Token: 0x06000DFD RID: 3581 RVA: 0x00039DD0 File Offset: 0x00037FD0
		public bool EvaluateExpression(GrmRuleSetContext context)
		{
			bool result;
			try
			{
				context.ContextJson = this.ContextJson;
				GrmOperand operand = (GrmOperand)Enum.Parse(typeof(GrmOperand), this.LeftOperand, true);
				GrmOperator grmOperator = (GrmOperator)Enum.Parse(typeof(GrmOperator), this.Operator, true);
				result = EvaluatorFactory.CreateandReturnEvaluator(operand).Evaluate(context, grmOperator, this.RightOperand);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while parsing operand for grmrule. operand: {0} operator: {1} rulesetid:{2} exception: {3}", new object[]
				{
					this.LeftOperand,
					this.Operator,
					context.RuleSetId,
					ex.Message
				});
				if (!GrmExpression._rulesetsWithException.Contains(context.RuleSetId))
				{
					GrmExpression._rulesetsWithException.Add(context.RuleSetId);
					Stats.SendMiscellaneousStatsAsync("grm_evaluation_error", RegistryManager.Instance.UserGuid, context.RuleSetId, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, "bgp", context.PackageName, ex.Message, null, context.VmName, 0);
				}
				result = false;
			}
			return result;
		}

		// Token: 0x04000BBB RID: 3003
		private static List<string> _rulesetsWithException = new List<string>();
	}
}
