﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace BlueStacks.Common.Grm
{
	// Token: 0x020001CC RID: 460
	public class GrmRule
	{
		// Token: 0x17000352 RID: 850
		// (get) Token: 0x06000E10 RID: 3600 RVA: 0x0000BFDD File Offset: 0x0000A1DD
		// (set) Token: 0x06000E11 RID: 3601 RVA: 0x0000BFE5 File Offset: 0x0000A1E5
		[JsonProperty(PropertyName = "expressions")]
		public List<GrmExpression> Expressions { get; set; } = new List<GrmExpression>();
	}
}
