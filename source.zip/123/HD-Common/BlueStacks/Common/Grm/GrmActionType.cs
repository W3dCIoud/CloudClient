﻿using System;

namespace BlueStacks.Common.Grm
{
	// Token: 0x020001D0 RID: 464
	public enum GrmActionType
	{
		// Token: 0x04000BD2 RID: 3026
		UpdateRam,
		// Token: 0x04000BD3 RID: 3027
		UserBrowser,
		// Token: 0x04000BD4 RID: 3028
		DownloadFileAndExecute,
		// Token: 0x04000BD5 RID: 3029
		NoAction,
		// Token: 0x04000BD6 RID: 3030
		ContinueAnyway,
		// Token: 0x04000BD7 RID: 3031
		GlMode,
		// Token: 0x04000BD8 RID: 3032
		DeviceProfile,
		// Token: 0x04000BD9 RID: 3033
		BootParam,
		// Token: 0x04000BDA RID: 3034
		DPI,
		// Token: 0x04000BDB RID: 3035
		CpuCores,
		// Token: 0x04000BDC RID: 3036
		Resolution,
		// Token: 0x04000BDD RID: 3037
		RestartBluestacks,
		// Token: 0x04000BDE RID: 3038
		RestartMachine,
		// Token: 0x04000BDF RID: 3039
		Fps,
		// Token: 0x04000BE0 RID: 3040
		EditRegistry
	}
}
