﻿using System;

namespace BlueStacks.Common.Grm
{
	// Token: 0x020001D3 RID: 467
	public enum GlMode
	{
		// Token: 0x04000C04 RID: 3076
		PGA_DX,
		// Token: 0x04000C05 RID: 3077
		AGA_DX,
		// Token: 0x04000C06 RID: 3078
		PGA_GL,
		// Token: 0x04000C07 RID: 3079
		AGA_GL
	}
}
