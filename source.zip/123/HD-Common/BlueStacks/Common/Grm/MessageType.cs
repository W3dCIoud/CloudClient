﻿using System;

namespace BlueStacks.Common.Grm
{
	// Token: 0x020001CF RID: 463
	public enum MessageType
	{
		// Token: 0x04000BCE RID: 3022
		None,
		// Token: 0x04000BCF RID: 3023
		Info,
		// Token: 0x04000BD0 RID: 3024
		Error
	}
}
