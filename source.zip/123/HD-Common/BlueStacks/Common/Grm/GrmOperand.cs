﻿using System;

namespace BlueStacks.Common.Grm
{
	// Token: 0x020001D1 RID: 465
	public enum GrmOperand
	{
		// Token: 0x04000BE2 RID: 3042
		AppVersionCode,
		// Token: 0x04000BE3 RID: 3043
		ProductVersion,
		// Token: 0x04000BE4 RID: 3044
		Geo,
		// Token: 0x04000BE5 RID: 3045
		Gpu,
		// Token: 0x04000BE6 RID: 3046
		Ram,
		// Token: 0x04000BE7 RID: 3047
		PhysicalRam,
		// Token: 0x04000BE8 RID: 3048
		GlMode,
		// Token: 0x04000BE9 RID: 3049
		EngineMode,
		// Token: 0x04000BEA RID: 3050
		Is64Bit,
		// Token: 0x04000BEB RID: 3051
		CpuCoresAllocated,
		// Token: 0x04000BEC RID: 3052
		PhysicalCoresAvailable,
		// Token: 0x04000BED RID: 3053
		Dpi,
		// Token: 0x04000BEE RID: 3054
		Fps,
		// Token: 0x04000BEF RID: 3055
		Resolution,
		// Token: 0x04000BF0 RID: 3056
		GuestOs,
		// Token: 0x04000BF1 RID: 3057
		Oem,
		// Token: 0x04000BF2 RID: 3058
		InstalledOems,
		// Token: 0x04000BF3 RID: 3059
		CustomKeyMappingExists,
		// Token: 0x04000BF4 RID: 3060
		RegistryKeyValue,
		// Token: 0x04000BF5 RID: 3061
		BootParam,
		// Token: 0x04000BF6 RID: 3062
		DeviceProfile
	}
}
