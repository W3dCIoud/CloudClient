﻿using System;

namespace BlueStacks.Common.Grm
{
	// Token: 0x020001CE RID: 462
	internal interface IGrmOperatorComparer<T>
	{
		// Token: 0x06000E1C RID: 3612
		bool Contains(T left, string right);

		// Token: 0x06000E1D RID: 3613
		bool LessThan(T left, string right);

		// Token: 0x06000E1E RID: 3614
		bool GreaterThan(T left, string right);

		// Token: 0x06000E1F RID: 3615
		bool Equal(T left, string right);

		// Token: 0x06000E20 RID: 3616
		bool NotEqual(T left, string right);

		// Token: 0x06000E21 RID: 3617
		bool LessThanEqual(T left, string right);

		// Token: 0x06000E22 RID: 3618
		bool GreaterThanEqual(T left, string right);

		// Token: 0x06000E23 RID: 3619
		bool StartsWith(T left, string right, string contextJson);

		// Token: 0x06000E24 RID: 3620
		bool LikeRegex(T left, string right, string contextJson);

		// Token: 0x06000E25 RID: 3621
		bool In(T left, string right);

		// Token: 0x06000E26 RID: 3622
		bool NotIn(T left, string right);
	}
}
