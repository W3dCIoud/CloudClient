﻿using System;

namespace BlueStacks.Common.Grm
{
	// Token: 0x020001D2 RID: 466
	public enum GrmOperator
	{
		// Token: 0x04000BF8 RID: 3064
		LessThan,
		// Token: 0x04000BF9 RID: 3065
		GreaterThan,
		// Token: 0x04000BFA RID: 3066
		Equal,
		// Token: 0x04000BFB RID: 3067
		NotEqual,
		// Token: 0x04000BFC RID: 3068
		LessThanEqual,
		// Token: 0x04000BFD RID: 3069
		GreaterThanEqual,
		// Token: 0x04000BFE RID: 3070
		StartsWith,
		// Token: 0x04000BFF RID: 3071
		Contains,
		// Token: 0x04000C00 RID: 3072
		LikeRegex,
		// Token: 0x04000C01 RID: 3073
		In,
		// Token: 0x04000C02 RID: 3074
		NotIn
	}
}
