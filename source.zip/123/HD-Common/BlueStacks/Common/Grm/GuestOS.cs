﻿using System;

namespace BlueStacks.Common.Grm
{
	// Token: 0x020001D4 RID: 468
	public enum GuestOS
	{
		// Token: 0x04000C09 RID: 3081
		Kitkat,
		// Token: 0x04000C0A RID: 3082
		Nougat
	}
}
