﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common.Grm.Comparers
{
	// Token: 0x020001ED RID: 493
	internal class GenericComparer<T> : IGrmOperatorComparer<T> where T : IComparable<T>, IConvertible
	{
		// Token: 0x06000E7E RID: 3710 RVA: 0x0000C16C File Offset: 0x0000A36C
		public bool Contains(T left, string right)
		{
			return left.ToString().Contains(right, StringComparison.InvariantCultureIgnoreCase);
		}

		// Token: 0x06000E7F RID: 3711 RVA: 0x0003A864 File Offset: 0x00038A64
		public bool Equal(T left, string right)
		{
			T y = (T)((object)Convert.ChangeType(right, typeof(T)));
			return EqualityComparer<T>.Default.Equals(left, y);
		}

		// Token: 0x06000E80 RID: 3712 RVA: 0x0003A894 File Offset: 0x00038A94
		public bool GreaterThan(T left, string right)
		{
			T other = (T)((object)Convert.ChangeType(right, typeof(T)));
			return left.CompareTo(other) > 0;
		}

		// Token: 0x06000E81 RID: 3713 RVA: 0x0003A8C8 File Offset: 0x00038AC8
		public bool GreaterThanEqual(T left, string right)
		{
			T other = (T)((object)Convert.ChangeType(right, typeof(T)));
			return left.CompareTo(other) >= 0;
		}

		// Token: 0x06000E82 RID: 3714 RVA: 0x0003A900 File Offset: 0x00038B00
		public bool In(T left, string right)
		{
			return (from element in right.Split(new char[]
			{
				','
			})
			select (T)((object)Convert.ChangeType(element.Trim(), typeof(T)))).ToList<T>().Contains(left);
		}

		// Token: 0x06000E83 RID: 3715 RVA: 0x0003A950 File Offset: 0x00038B50
		public bool LessThan(T left, string right)
		{
			T other = (T)((object)Convert.ChangeType(right, typeof(T)));
			return left.CompareTo(other) < 0;
		}

		// Token: 0x06000E84 RID: 3716 RVA: 0x0003A984 File Offset: 0x00038B84
		public bool LessThanEqual(T left, string right)
		{
			T other = (T)((object)Convert.ChangeType(right, typeof(T)));
			return left.CompareTo(other) <= 0;
		}

		// Token: 0x06000E85 RID: 3717 RVA: 0x0003A9BC File Offset: 0x00038BBC
		public bool LikeRegex(T left, string right, string contextJson)
		{
			JObject jobject = JsonConvert.DeserializeObject(contextJson, Utils.GetSerializerSettings()) as JObject;
			int options = 1;
			if (jobject != null && jobject.ContainsKey("regexOptions") && !string.IsNullOrEmpty(jobject["regexOptions"].Value<string>()))
			{
				options = int.Parse(jobject["regexOptions"].Value<string>());
			}
			return new Regex(right, (RegexOptions)options).IsMatch(left.ToString());
		}

		// Token: 0x06000E86 RID: 3718 RVA: 0x0003AA34 File Offset: 0x00038C34
		public bool NotEqual(T left, string right)
		{
			T y = (T)((object)Convert.ChangeType(right, typeof(T)));
			return !EqualityComparer<T>.Default.Equals(left, y);
		}

		// Token: 0x06000E87 RID: 3719 RVA: 0x0003AA68 File Offset: 0x00038C68
		public bool NotIn(T left, string right)
		{
			return !(from element in right.Split(new char[]
			{
				','
			})
			select (T)((object)Convert.ChangeType(element.Trim(), typeof(T)))).ToList<T>().Contains(left);
		}

		// Token: 0x06000E88 RID: 3720 RVA: 0x0003AAB8 File Offset: 0x00038CB8
		public bool StartsWith(T left, string right, string contextJson)
		{
			JObject jobject = JsonConvert.DeserializeObject(contextJson, Utils.GetSerializerSettings()) as JObject;
			int comparisonType = 3;
			if (jobject != null && jobject.ContainsKey("stringComparison") && !string.IsNullOrEmpty(jobject["stringComparison"].Value<string>()))
			{
				comparisonType = int.Parse(jobject["stringComparison"].Value<string>());
			}
			return left.ToString().StartsWith(right, (StringComparison)comparisonType);
		}
	}
}
