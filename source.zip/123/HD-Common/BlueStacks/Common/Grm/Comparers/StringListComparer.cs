﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common.Grm.Comparers
{
	// Token: 0x020001F1 RID: 497
	internal class StringListComparer : IGrmOperatorComparer<List<string>>
	{
		// Token: 0x06000E9E RID: 3742 RVA: 0x0003ACB4 File Offset: 0x00038EB4
		public bool Contains(List<string> left, string right)
		{
			using (List<string>.Enumerator enumerator = left.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.Contains(right, StringComparison.InvariantCultureIgnoreCase))
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x06000E9F RID: 3743 RVA: 0x0003AD0C File Offset: 0x00038F0C
		public bool Equal(List<string> left, string right)
		{
			using (List<string>.Enumerator enumerator = left.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.Equals(right, StringComparison.InvariantCultureIgnoreCase))
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x06000EA0 RID: 3744 RVA: 0x0000C20A File Offset: 0x0000A40A
		public bool GreaterThan(List<string> left, string right)
		{
			throw new ArgumentException("Operator GreaterThan is not supported with list of string expression");
		}

		// Token: 0x06000EA1 RID: 3745 RVA: 0x0000C216 File Offset: 0x0000A416
		public bool GreaterThanEqual(List<string> left, string right)
		{
			throw new ArgumentException("Operator GreaterThanEqual is not supported with list of string expression");
		}

		// Token: 0x06000EA2 RID: 3746 RVA: 0x0003AD64 File Offset: 0x00038F64
		public bool In(List<string> left, string right)
		{
			return (from _ in right.Split(new char[]
			{
				','
			})
			select _.Trim()).ToList<string>().Intersect(left).Count<string>() > 0;
		}

		// Token: 0x06000EA3 RID: 3747 RVA: 0x0000C222 File Offset: 0x0000A422
		public bool LessThan(List<string> left, string right)
		{
			throw new ArgumentException("Operator LessThan is not supported with list of string expression");
		}

		// Token: 0x06000EA4 RID: 3748 RVA: 0x0000C22E File Offset: 0x0000A42E
		public bool LessThanEqual(List<string> left, string right)
		{
			throw new ArgumentException("Operator LessThanEqual is not supported with list of string expression");
		}

		// Token: 0x06000EA5 RID: 3749 RVA: 0x0003ADBC File Offset: 0x00038FBC
		public bool LikeRegex(List<string> left, string right, string contextJson)
		{
			JObject jobject = JsonConvert.DeserializeObject(contextJson, Utils.GetSerializerSettings()) as JObject;
			int options = 1;
			if (jobject != null && jobject.ContainsKey("regexOptions") && !string.IsNullOrEmpty(jobject["regexOptions"].Value<string>()))
			{
				options = int.Parse(jobject["regexOptions"].Value<string>());
			}
			Regex regex = new Regex(right, (RegexOptions)options);
			foreach (string input in left)
			{
				if (regex.IsMatch(input))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x06000EA6 RID: 3750 RVA: 0x0003AE70 File Offset: 0x00039070
		public bool NotEqual(List<string> left, string right)
		{
			using (List<string>.Enumerator enumerator = left.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.Equals(right, StringComparison.InvariantCultureIgnoreCase))
					{
						return false;
					}
				}
			}
			return true;
		}

		// Token: 0x06000EA7 RID: 3751 RVA: 0x0003AEC8 File Offset: 0x000390C8
		public bool NotIn(List<string> left, string right)
		{
			return (from _ in right.Split(new char[]
			{
				','
			})
			select _.Trim()).ToList<string>().Intersect(left).Count<string>() == 0;
		}

		// Token: 0x06000EA8 RID: 3752 RVA: 0x0003AF20 File Offset: 0x00039120
		public bool StartsWith(List<string> left, string right, string contextJson)
		{
			JObject jobject = JsonConvert.DeserializeObject(contextJson, Utils.GetSerializerSettings()) as JObject;
			int comparisonType = 3;
			if (jobject != null && jobject.ContainsKey("stringComparison") && !string.IsNullOrEmpty(jobject["stringComparison"].Value<string>()))
			{
				comparisonType = int.Parse(jobject["stringComparison"].Value<string>());
			}
			using (List<string>.Enumerator enumerator = left.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.StartsWith(right, (StringComparison)comparisonType))
					{
						return true;
					}
				}
			}
			return false;
		}
	}
}
