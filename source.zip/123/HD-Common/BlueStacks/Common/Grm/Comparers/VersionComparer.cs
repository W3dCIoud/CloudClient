﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common.Grm.Comparers
{
	// Token: 0x020001F3 RID: 499
	internal class VersionComparer : IGrmOperatorComparer<Version>
	{
		// Token: 0x06000EAE RID: 3758 RVA: 0x0000C246 File Offset: 0x0000A446
		public bool Contains(Version left, string right)
		{
			return left.ToString().Contains(right, StringComparison.InvariantCultureIgnoreCase);
		}

		// Token: 0x06000EAF RID: 3759 RVA: 0x0003AFC8 File Offset: 0x000391C8
		public bool Equal(Version left, string right)
		{
			Version v = new Version(right);
			return left == v;
		}

		// Token: 0x06000EB0 RID: 3760 RVA: 0x0003AFE4 File Offset: 0x000391E4
		public bool GreaterThan(Version left, string right)
		{
			Version v = new Version(right);
			return left > v;
		}

		// Token: 0x06000EB1 RID: 3761 RVA: 0x0003B000 File Offset: 0x00039200
		public bool GreaterThanEqual(Version left, string right)
		{
			Version v = new Version(right);
			return left >= v;
		}

		// Token: 0x06000EB2 RID: 3762 RVA: 0x0003B01C File Offset: 0x0003921C
		public bool In(Version left, string right)
		{
			return (from _ in right.Split(new char[]
			{
				','
			})
			select new Version(_.Trim())).ToList<Version>().Contains(left);
		}

		// Token: 0x06000EB3 RID: 3763 RVA: 0x0003B06C File Offset: 0x0003926C
		public bool LessThan(Version left, string right)
		{
			Version v = new Version(right);
			return left < v;
		}

		// Token: 0x06000EB4 RID: 3764 RVA: 0x0003B088 File Offset: 0x00039288
		public bool LessThanEqual(Version left, string right)
		{
			Version v = new Version(right);
			return left <= v;
		}

		// Token: 0x06000EB5 RID: 3765 RVA: 0x0003B0A4 File Offset: 0x000392A4
		public bool LikeRegex(Version left, string right, string contextJson)
		{
			JObject jobject = JsonConvert.DeserializeObject(contextJson, Utils.GetSerializerSettings()) as JObject;
			int options = 1;
			if (jobject != null && jobject.ContainsKey("regexOptions") && !string.IsNullOrEmpty(jobject["regexOptions"].Value<string>()))
			{
				options = int.Parse(jobject["regexOptions"].Value<string>());
			}
			return new Regex(right, (RegexOptions)options).IsMatch(left.ToString());
		}

		// Token: 0x06000EB6 RID: 3766 RVA: 0x0003B114 File Offset: 0x00039314
		public bool NotEqual(Version left, string right)
		{
			Version v = new Version(right);
			return left != v;
		}

		// Token: 0x06000EB7 RID: 3767 RVA: 0x0003B130 File Offset: 0x00039330
		public bool NotIn(Version left, string right)
		{
			return !(from _ in right.Split(new char[]
			{
				','
			})
			select new Version(_.Trim())).ToList<Version>().Contains(left);
		}

		// Token: 0x06000EB8 RID: 3768 RVA: 0x0003B180 File Offset: 0x00039380
		public bool StartsWith(Version left, string right, string contextJson)
		{
			JObject jobject = JsonConvert.DeserializeObject(contextJson, Utils.GetSerializerSettings()) as JObject;
			int comparisonType = 3;
			if (jobject != null && jobject.ContainsKey("stringComparison") && !string.IsNullOrEmpty(jobject["stringComparison"].Value<string>()))
			{
				comparisonType = int.Parse(jobject["stringComparison"].Value<string>());
			}
			return left.ToString().StartsWith(right, (StringComparison)comparisonType);
		}
	}
}
