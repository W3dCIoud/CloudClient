﻿using System;

namespace BlueStacks.Common.Grm.Comparers
{
	// Token: 0x020001EC RID: 492
	internal class BooleanComparer : IGrmOperatorComparer<bool>
	{
		// Token: 0x06000E72 RID: 3698 RVA: 0x0000C0FC File Offset: 0x0000A2FC
		public bool Contains(bool left, string right)
		{
			return left.ToString().Contains(right, StringComparison.InvariantCultureIgnoreCase);
		}

		// Token: 0x06000E73 RID: 3699 RVA: 0x0003A830 File Offset: 0x00038A30
		public bool Equal(bool left, string right)
		{
			bool flag = Convert.ToBoolean(right);
			return left == flag;
		}

		// Token: 0x06000E74 RID: 3700 RVA: 0x0000C10C File Offset: 0x0000A30C
		public bool GreaterThan(bool left, string right)
		{
			throw new ArgumentException("Operator GreaterThan is not supported with boolean expression");
		}

		// Token: 0x06000E75 RID: 3701 RVA: 0x0000C118 File Offset: 0x0000A318
		public bool GreaterThanEqual(bool left, string right)
		{
			throw new ArgumentException("Operator GreaterThanEqual is not supported with boolean expression");
		}

		// Token: 0x06000E76 RID: 3702 RVA: 0x0000C124 File Offset: 0x0000A324
		public bool In(bool left, string right)
		{
			throw new ArgumentException("Operator In is not supported with boolean expression");
		}

		// Token: 0x06000E77 RID: 3703 RVA: 0x0000C130 File Offset: 0x0000A330
		public bool LessThan(bool left, string right)
		{
			throw new ArgumentException("Operator LessThan is not supported with boolean expression");
		}

		// Token: 0x06000E78 RID: 3704 RVA: 0x0000C13C File Offset: 0x0000A33C
		public bool LessThanEqual(bool left, string right)
		{
			throw new ArgumentException("Operator LessThanEqual is not supported with boolean expression");
		}

		// Token: 0x06000E79 RID: 3705 RVA: 0x0000C148 File Offset: 0x0000A348
		public bool LikeRegex(bool left, string right, string contextJson)
		{
			throw new ArgumentException("Operator LikeRegex is not supported with boolean expression");
		}

		// Token: 0x06000E7A RID: 3706 RVA: 0x0003A848 File Offset: 0x00038A48
		public bool NotEqual(bool left, string right)
		{
			bool flag = Convert.ToBoolean(right);
			return left != flag;
		}

		// Token: 0x06000E7B RID: 3707 RVA: 0x0000C154 File Offset: 0x0000A354
		public bool NotIn(bool left, string right)
		{
			throw new ArgumentException("Operator notin is not supported with boolean expression");
		}

		// Token: 0x06000E7C RID: 3708 RVA: 0x0000C160 File Offset: 0x0000A360
		public bool StartsWith(bool left, string right, string contextJson)
		{
			throw new ArgumentException("Operator StartsWith is not supported with boolean expression");
		}
	}
}
