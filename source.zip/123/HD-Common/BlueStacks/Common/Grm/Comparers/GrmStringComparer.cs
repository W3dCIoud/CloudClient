﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common.Grm.Comparers
{
	// Token: 0x020001EF RID: 495
	internal class GrmStringComparer : IGrmOperatorComparer<string>
	{
		// Token: 0x06000E8E RID: 3726 RVA: 0x0000C1AA File Offset: 0x0000A3AA
		public bool Contains(string left, string right)
		{
			return left.Contains(right, StringComparison.InvariantCultureIgnoreCase);
		}

		// Token: 0x06000E8F RID: 3727 RVA: 0x0000C1B4 File Offset: 0x0000A3B4
		public bool Equal(string left, string right)
		{
			return left == right;
		}

		// Token: 0x06000E90 RID: 3728 RVA: 0x0000C1BD File Offset: 0x0000A3BD
		public bool GreaterThan(string left, string right)
		{
			throw new ArgumentException("Operator GreaterThan is not supported with string expression");
		}

		// Token: 0x06000E91 RID: 3729 RVA: 0x0000C1C9 File Offset: 0x0000A3C9
		public bool GreaterThanEqual(string left, string right)
		{
			throw new ArgumentException("Operator GreaterThanEqual is not supported with string expression");
		}

		// Token: 0x06000E92 RID: 3730 RVA: 0x0003AB2C File Offset: 0x00038D2C
		public bool In(string left, string right)
		{
			return (from _ in right.Split(new char[]
			{
				','
			})
			select _.Trim()).ToList<string>().Contains(left.Trim(), StringComparer.InvariantCultureIgnoreCase);
		}

		// Token: 0x06000E93 RID: 3731 RVA: 0x0000C1D5 File Offset: 0x0000A3D5
		public bool LessThan(string left, string right)
		{
			throw new ArgumentException("Operator LessThan is not supported with string expression");
		}

		// Token: 0x06000E94 RID: 3732 RVA: 0x0000C1E1 File Offset: 0x0000A3E1
		public bool LessThanEqual(string left, string right)
		{
			throw new ArgumentException("Operator LessThanEqual is not supported with string expression");
		}

		// Token: 0x06000E95 RID: 3733 RVA: 0x0003AB84 File Offset: 0x00038D84
		public bool LikeRegex(string left, string right, string contextJson)
		{
			JObject jobject = JsonConvert.DeserializeObject(contextJson, Utils.GetSerializerSettings()) as JObject;
			int options = 1;
			if (jobject != null && jobject.ContainsKey("regexOptions") && !string.IsNullOrEmpty(jobject["regexOptions"].Value<string>()))
			{
				options = int.Parse(jobject["regexOptions"].Value<string>());
			}
			return new Regex(right, (RegexOptions)options).IsMatch(left);
		}

		// Token: 0x06000E96 RID: 3734 RVA: 0x0000C1ED File Offset: 0x0000A3ED
		public bool NotEqual(string left, string right)
		{
			return left != right;
		}

		// Token: 0x06000E97 RID: 3735 RVA: 0x0003ABF0 File Offset: 0x00038DF0
		public bool NotIn(string left, string right)
		{
			return !(from _ in right.Split(new char[]
			{
				','
			})
			select _.Trim()).ToList<string>().Contains(left.Trim(), StringComparer.InvariantCultureIgnoreCase);
		}

		// Token: 0x06000E98 RID: 3736 RVA: 0x0003AC4C File Offset: 0x00038E4C
		public bool StartsWith(string left, string right, string contextJson)
		{
			JObject jobject = JsonConvert.DeserializeObject(contextJson, Utils.GetSerializerSettings()) as JObject;
			int comparisonType = 3;
			if (jobject != null && jobject.ContainsKey("stringComparison") && !string.IsNullOrEmpty(jobject["stringComparison"].Value<string>()))
			{
				comparisonType = int.Parse(jobject["stringComparison"].Value<string>());
			}
			return left.StartsWith(right, (StringComparison)comparisonType);
		}
	}
}
