﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace BlueStacks.Common.Grm
{
	// Token: 0x020001C4 RID: 452
	public class AppRequirement
	{
		// Token: 0x17000343 RID: 835
		// (get) Token: 0x06000DE4 RID: 3556 RVA: 0x0000BE10 File Offset: 0x0000A010
		// (set) Token: 0x06000DE5 RID: 3557 RVA: 0x0000BE18 File Offset: 0x0000A018
		[JsonProperty(PropertyName = "pkgName")]
		public string PackageName { get; set; }

		// Token: 0x17000344 RID: 836
		// (get) Token: 0x06000DE6 RID: 3558 RVA: 0x0000BE21 File Offset: 0x0000A021
		// (set) Token: 0x06000DE7 RID: 3559 RVA: 0x0000BE29 File Offset: 0x0000A029
		[JsonProperty(PropertyName = "RuleSets")]
		public List<GrmRuleSet> GrmRuleSets { get; set; } = new List<GrmRuleSet>();

		// Token: 0x06000DE8 RID: 3560 RVA: 0x000398CC File Offset: 0x00037ACC
		public GrmRuleSet EvaluateRequirement(string packageName, string vmName)
		{
			GrmRuleSetContext grmRuleSetContext = new GrmRuleSetContext
			{
				PackageName = packageName,
				VmName = vmName
			};
			foreach (GrmRuleSet grmRuleSet in this.GrmRuleSets)
			{
				if (!RegistryManager.Instance.Guest[vmName].GrmDonotShowRuleList.Contains(grmRuleSet.RuleId))
				{
					grmRuleSetContext.RuleSetId = grmRuleSet.RuleId;
					bool flag = false;
					foreach (GrmRule grmRule in grmRuleSet.Rules)
					{
						bool flag2 = true;
						foreach (GrmExpression grmExpression in grmRule.Expressions)
						{
							flag2 = (flag2 && grmExpression.EvaluateExpression(grmRuleSetContext));
							if (!flag2)
							{
								break;
							}
						}
						if (flag2)
						{
							flag = true;
							break;
						}
					}
					if (flag)
					{
						return grmRuleSet;
					}
				}
			}
			return null;
		}
	}
}
