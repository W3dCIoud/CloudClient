﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace BlueStacks.Common.Grm
{
	// Token: 0x020001CD RID: 461
	public class GrmRuleSet
	{
		// Token: 0x17000353 RID: 851
		// (get) Token: 0x06000E13 RID: 3603 RVA: 0x0000C001 File Offset: 0x0000A201
		// (set) Token: 0x06000E14 RID: 3604 RVA: 0x0000C009 File Offset: 0x0000A209
		public string RuleId { get; set; }

		// Token: 0x17000354 RID: 852
		// (get) Token: 0x06000E15 RID: 3605 RVA: 0x0000C012 File Offset: 0x0000A212
		// (set) Token: 0x06000E16 RID: 3606 RVA: 0x0000C01A File Offset: 0x0000A21A
		public string Description { get; set; }

		// Token: 0x17000355 RID: 853
		// (get) Token: 0x06000E17 RID: 3607 RVA: 0x0000C023 File Offset: 0x0000A223
		// (set) Token: 0x06000E18 RID: 3608 RVA: 0x0000C02B File Offset: 0x0000A22B
		[JsonProperty(PropertyName = "rules")]
		public List<GrmRule> Rules { get; set; } = new List<GrmRule>();

		// Token: 0x17000356 RID: 854
		// (get) Token: 0x06000E19 RID: 3609 RVA: 0x0000C034 File Offset: 0x0000A234
		// (set) Token: 0x06000E1A RID: 3610 RVA: 0x0000C03C File Offset: 0x0000A23C
		[JsonProperty(PropertyName = "messageWindow")]
		public GrmMessageWindow MessageWindow { get; set; }
	}
}
