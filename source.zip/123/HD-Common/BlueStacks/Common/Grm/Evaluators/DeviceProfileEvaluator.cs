﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001D7 RID: 471
	internal class DeviceProfileEvaluator : IRequirementEvaluator
	{
		// Token: 0x1700035C RID: 860
		// (get) Token: 0x06000E33 RID: 3635 RVA: 0x0000C0A0 File Offset: 0x0000A2A0
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.DeviceProfile;
			}
		}

		// Token: 0x06000E34 RID: 3636 RVA: 0x00039F5C File Offset: 0x0003815C
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			string valueInBootParams = Utils.GetValueInBootParams("pcode", context.VmName, "");
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, valueInBootParams, rightOperand, context);
		}
	}
}
