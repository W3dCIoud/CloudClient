﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001E6 RID: 486
	internal class PhysicalCoresAvailableEvaluator : IRequirementEvaluator
	{
		// Token: 0x1700036B RID: 875
		// (get) Token: 0x06000E60 RID: 3680 RVA: 0x0000C0EA File Offset: 0x0000A2EA
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.PhysicalCoresAvailable;
			}
		}

		// Token: 0x06000E61 RID: 3681 RVA: 0x0003A418 File Offset: 0x00038618
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			int left = 1;
			if (RegistryManager.Instance.CurrentEngine != "raw")
			{
				left = ((Environment.ProcessorCount > 8) ? 8 : Environment.ProcessorCount);
			}
			return GrmComparer<int>.Evaluate(this.EvaluatorForOperandType, grmOperator, left, rightOperand, context);
		}
	}
}
