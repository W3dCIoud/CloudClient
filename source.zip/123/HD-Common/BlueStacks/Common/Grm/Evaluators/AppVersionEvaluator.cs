﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001D9 RID: 473
	internal class AppVersionEvaluator : IRequirementEvaluator
	{
		// Token: 0x1700035E RID: 862
		// (get) Token: 0x06000E39 RID: 3641 RVA: 0x00004E1D File Offset: 0x0000301D
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.AppVersionCode;
			}
		}

		// Token: 0x06000E3A RID: 3642 RVA: 0x00039FD4 File Offset: 0x000381D4
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			int left = int.Parse(new JsonParser(context.VmName).GetAppInfoFromPackageName(context.PackageName).version);
			return GrmComparer<int>.Evaluate(this.EvaluatorForOperandType, grmOperator, left, rightOperand, context);
		}
	}
}
