﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001EB RID: 491
	internal class ResolutionEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000370 RID: 880
		// (get) Token: 0x06000E6F RID: 3695 RVA: 0x0000C0F8 File Offset: 0x0000A2F8
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.Resolution;
			}
		}

		// Token: 0x06000E70 RID: 3696 RVA: 0x0003A7B0 File Offset: 0x000389B0
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			int guestWidth = RegistryManager.Instance.Guest[context.VmName].GuestWidth;
			int guestHeight = RegistryManager.Instance.Guest[context.VmName].GuestHeight;
			string left = guestWidth.ToString() + "x" + guestHeight.ToString();
			rightOperand = rightOperand.Replace(" ", string.Empty);
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, left, rightOperand, context);
		}
	}
}
