﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Win32;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001E2 RID: 482
	internal class InstalledOemEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000367 RID: 871
		// (get) Token: 0x06000E55 RID: 3669 RVA: 0x0000C0CA File Offset: 0x0000A2CA
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.InstalledOems;
			}
		}

		// Token: 0x06000E56 RID: 3670 RVA: 0x0003A2D4 File Offset: 0x000384D4
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			List<string> list = new List<string>();
			try
			{
				foreach (string text in Registry.LocalMachine.OpenSubKey("Software").GetSubKeyNames())
				{
					if (text.StartsWith("BlueStacks") && !text.StartsWith("BlueStacksGP") && !text.StartsWith("BlueStacksInstaller") && !string.IsNullOrEmpty((string)Utils.GetRegistryHKLMValue("Software\\" + text, "Version", "")))
					{
						if (text.Split(new char[]
						{
							'_'
						}).Count<string>() > 1)
						{
							list.Add(text.Split(new char[]
							{
								'_'
							}).ToList<string>()[1]);
						}
						else
						{
							list.Add("bgp");
						}
					}
				}
				list = list.Distinct<string>().ToList<string>();
			}
			catch (Exception ex)
			{
				Logger.Info("Error in finding installed oems " + ex.ToString());
			}
			return GrmComparer<List<string>>.Evaluate(this.EvaluatorForOperandType, grmOperator, list, rightOperand, context);
		}
	}
}
