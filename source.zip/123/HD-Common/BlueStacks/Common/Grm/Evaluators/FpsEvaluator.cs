﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001DE RID: 478
	internal class FpsEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000363 RID: 867
		// (get) Token: 0x06000E48 RID: 3656 RVA: 0x0000C0B6 File Offset: 0x0000A2B6
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.Fps;
			}
		}

		// Token: 0x06000E49 RID: 3657 RVA: 0x0003A16C File Offset: 0x0003836C
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			int fps = RegistryManager.Instance.Guest[context.VmName].FPS;
			return GrmComparer<int>.Evaluate(this.EvaluatorForOperandType, grmOperator, fps, rightOperand, context);
		}
	}
}
