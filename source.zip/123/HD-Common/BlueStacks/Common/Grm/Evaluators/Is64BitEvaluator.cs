﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001E4 RID: 484
	internal class Is64BitEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000369 RID: 873
		// (get) Token: 0x06000E5A RID: 3674 RVA: 0x0000C0CE File Offset: 0x0000A2CE
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.Is64Bit;
			}
		}

		// Token: 0x06000E5B RID: 3675 RVA: 0x0003A3F4 File Offset: 0x000385F4
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			bool is64BitOperatingSystem = CommonInstallUtils.is64BitOperatingSystem;
			return GrmComparer<bool>.Evaluate(this.EvaluatorForOperandType, grmOperator, is64BitOperatingSystem, rightOperand, context);
		}
	}
}
