﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001DC RID: 476
	internal class DpiEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000361 RID: 865
		// (get) Token: 0x06000E42 RID: 3650 RVA: 0x0000C0AF File Offset: 0x0000A2AF
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.Dpi;
			}
		}

		// Token: 0x06000E43 RID: 3651 RVA: 0x0003A094 File Offset: 0x00038294
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			string dpiFromBootParameters = Utils.GetDpiFromBootParameters(RegistryManager.Instance.Guest[context.VmName].BootParameters);
			return GrmComparer<int>.Evaluate(this.EvaluatorForOperandType, grmOperator, Convert.ToInt32(dpiFromBootParameters), rightOperand, context);
		}
	}
}
