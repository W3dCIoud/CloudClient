﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001DF RID: 479
	internal class GeoEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000364 RID: 868
		// (get) Token: 0x06000E4B RID: 3659 RVA: 0x0000B80A File Offset: 0x00009A0A
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.Geo;
			}
		}

		// Token: 0x06000E4C RID: 3660 RVA: 0x0003A1A4 File Offset: 0x000383A4
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			string geo = RegistryManager.Instance.Geo;
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, geo, rightOperand, context);
		}
	}
}
