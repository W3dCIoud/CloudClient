﻿using System;
using System.IO;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001DB RID: 475
	internal class CustomKeyMappingExistsEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000360 RID: 864
		// (get) Token: 0x06000E3F RID: 3647 RVA: 0x0000C0AB File Offset: 0x0000A2AB
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.CustomKeyMappingExists;
			}
		}

		// Token: 0x06000E40 RID: 3648 RVA: 0x0003A04C File Offset: 0x0003824C
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			bool left = File.Exists(Path.Combine(Path.Combine(RegistryStrings.InputMapperFolder, "UserFiles"), context.PackageName + ".cfg"));
			return GrmComparer<bool>.Evaluate(this.EvaluatorForOperandType, grmOperator, left, rightOperand, context);
		}
	}
}
