﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001E3 RID: 483
	internal interface IRequirementEvaluator
	{
		// Token: 0x17000368 RID: 872
		// (get) Token: 0x06000E58 RID: 3672
		GrmOperand EvaluatorForOperandType { get; }

		// Token: 0x06000E59 RID: 3673
		bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand);
	}
}
