﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001D8 RID: 472
	internal class EngineModeEvaluator : IRequirementEvaluator
	{
		// Token: 0x1700035D RID: 861
		// (get) Token: 0x06000E36 RID: 3638 RVA: 0x0000C0A4 File Offset: 0x0000A2A4
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.EngineMode;
			}
		}

		// Token: 0x06000E37 RID: 3639 RVA: 0x00039F90 File Offset: 0x00038190
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			EngineState engineState = EngineState.plus;
			if (RegistryManager.Instance.CurrentEngine == "raw")
			{
				engineState = EngineState.raw;
			}
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, engineState.ToString(), rightOperand, context);
		}
	}
}
