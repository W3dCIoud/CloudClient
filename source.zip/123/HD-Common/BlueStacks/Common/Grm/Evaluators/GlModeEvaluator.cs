﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001DD RID: 477
	internal class GlModeEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000362 RID: 866
		// (get) Token: 0x06000E45 RID: 3653 RVA: 0x0000C0B3 File Offset: 0x0000A2B3
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.GlMode;
			}
		}

		// Token: 0x06000E46 RID: 3654 RVA: 0x0003A0D8 File Offset: 0x000382D8
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			int glRenderMode = RegistryManager.Instance.Guest[context.VmName].GlRenderMode;
			int glMode = RegistryManager.Instance.Guest[context.VmName].GlMode;
			GlMode glMode2;
			if (glRenderMode == 1 && glMode == 1)
			{
				glMode2 = GlMode.PGA_GL;
			}
			else if (glRenderMode == 1 && glMode == 2)
			{
				glMode2 = GlMode.AGA_GL;
			}
			else if (glMode == 1)
			{
				glMode2 = GlMode.PGA_DX;
			}
			else
			{
				if (glMode != 2)
				{
					throw new Exception("Could not determine the engine mode for current build.");
				}
				glMode2 = GlMode.AGA_DX;
			}
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, glMode2.ToString(), rightOperand, context);
		}
	}
}
