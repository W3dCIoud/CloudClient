﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001E7 RID: 487
	internal class PhysicalRamEvaluator : IRequirementEvaluator
	{
		// Token: 0x1700036C RID: 876
		// (get) Token: 0x06000E63 RID: 3683 RVA: 0x0000C0EE File Offset: 0x0000A2EE
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.PhysicalRam;
			}
		}

		// Token: 0x06000E64 RID: 3684 RVA: 0x0003A460 File Offset: 0x00038660
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			int num;
			int.TryParse(EngineSettingsBase.RAM, out num);
			int num2 = (int)((double)num * 0.5);
			if (num2 >= 4096)
			{
				num2 = 4096;
			}
			if (RegistryManager.Instance.CurrentEngine == "raw" && num2 >= 3072)
			{
				num2 = 3072;
			}
			return GrmComparer<int>.Evaluate(this.EvaluatorForOperandType, grmOperator, num2, rightOperand, context);
		}
	}
}
