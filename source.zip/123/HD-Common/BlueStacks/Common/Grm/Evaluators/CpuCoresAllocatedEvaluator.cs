﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001DA RID: 474
	internal class CpuCoresAllocatedEvaluator : IRequirementEvaluator
	{
		// Token: 0x1700035F RID: 863
		// (get) Token: 0x06000E3C RID: 3644 RVA: 0x0000C0A7 File Offset: 0x0000A2A7
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.CpuCoresAllocated;
			}
		}

		// Token: 0x06000E3D RID: 3645 RVA: 0x0003A014 File Offset: 0x00038214
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			int vcpus = RegistryManager.Instance.Guest[context.VmName].VCPUs;
			return GrmComparer<int>.Evaluate(this.EvaluatorForOperandType, grmOperator, vcpus, rightOperand, context);
		}
	}
}
