﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001D6 RID: 470
	internal class BootParamEvaluator : IRequirementEvaluator
	{
		// Token: 0x1700035B RID: 859
		// (get) Token: 0x06000E30 RID: 3632 RVA: 0x0000C09C File Offset: 0x0000A29C
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.BootParam;
			}
		}

		// Token: 0x06000E31 RID: 3633 RVA: 0x00039EEC File Offset: 0x000380EC
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			JObject jobject = JsonConvert.DeserializeObject(context.ContextJson, Utils.GetSerializerSettings()) as JObject;
			if (jobject == null || !jobject.ContainsKey("param"))
			{
				throw new ArgumentException("BootParamEvaluator requires contextjson with param key.");
			}
			string valueInBootParams = Utils.GetValueInBootParams(jobject["param"].Value<string>(), context.VmName, "");
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, valueInBootParams, rightOperand, context);
		}
	}
}
