﻿using System;
using System.Collections.Generic;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001E0 RID: 480
	internal class GpuEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000365 RID: 869
		// (get) Token: 0x06000E4E RID: 3662 RVA: 0x0000BA07 File Offset: 0x00009C07
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.Gpu;
			}
		}

		// Token: 0x06000E4F RID: 3663 RVA: 0x0003A1CC File Offset: 0x000383CC
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			if (!GpuEvaluator.mVmNameGpu.ContainsKey(context.VmName) || string.IsNullOrEmpty(GpuEvaluator.mVmNameGpu[context.VmName]))
			{
				string str;
				string str2;
				string text;
				Utils.GetCurrentGraphicsInfo(RegistryManager.Instance.Guest[context.VmName].GlRenderMode + " " + RegistryManager.Instance.Guest[context.VmName].GlMode, out str, out str2, out text);
				string text2 = str + " " + str2;
				GpuEvaluator.mVmNameGpu[context.VmName] = text2;
				Logger.Info("GpuEvaluator " + text2);
			}
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, GpuEvaluator.mVmNameGpu[context.VmName], rightOperand, context);
		}

		// Token: 0x04000C0F RID: 3087
		private static Dictionary<string, string> mVmNameGpu = new Dictionary<string, string>();
	}
}
