﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001E9 RID: 489
	internal class RamEvaluator : IRequirementEvaluator
	{
		// Token: 0x1700036E RID: 878
		// (get) Token: 0x06000E69 RID: 3689 RVA: 0x0000C0F1 File Offset: 0x0000A2F1
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.Ram;
			}
		}

		// Token: 0x06000E6A RID: 3690 RVA: 0x0003A4F8 File Offset: 0x000386F8
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			int memory = RegistryManager.Instance.Guest[context.VmName].Memory;
			return GrmComparer<int>.Evaluate(this.EvaluatorForOperandType, grmOperator, memory, rightOperand, context);
		}
	}
}
