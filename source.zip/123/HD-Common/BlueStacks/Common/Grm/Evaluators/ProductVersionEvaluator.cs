﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001E8 RID: 488
	internal class ProductVersionEvaluator : IRequirementEvaluator
	{
		// Token: 0x1700036D RID: 877
		// (get) Token: 0x06000E66 RID: 3686 RVA: 0x0000AC7B File Offset: 0x00008E7B
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.ProductVersion;
			}
		}

		// Token: 0x06000E67 RID: 3687 RVA: 0x0003A4CC File Offset: 0x000386CC
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			Version left = new Version(RegistryManager.Instance.Version);
			return GrmComparer<Version>.Evaluate(this.EvaluatorForOperandType, grmOperator, left, rightOperand, context);
		}
	}
}
