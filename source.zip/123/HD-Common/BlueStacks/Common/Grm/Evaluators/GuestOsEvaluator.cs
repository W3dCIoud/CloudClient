﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001E1 RID: 481
	internal class GuestOsEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000366 RID: 870
		// (get) Token: 0x06000E52 RID: 3666 RVA: 0x0000C0C6 File Offset: 0x0000A2C6
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.GuestOs;
			}
		}

		// Token: 0x06000E53 RID: 3667 RVA: 0x0003A2A8 File Offset: 0x000384A8
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			GuestOS guestOS = GuestOS.Nougat;
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, guestOS.ToString(), rightOperand, context);
		}
	}
}
