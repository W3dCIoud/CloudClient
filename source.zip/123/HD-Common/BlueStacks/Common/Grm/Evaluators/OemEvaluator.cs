﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x020001E5 RID: 485
	internal class OemEvaluator : IRequirementEvaluator
	{
		// Token: 0x1700036A RID: 874
		// (get) Token: 0x06000E5D RID: 3677 RVA: 0x0000C0D1 File Offset: 0x0000A2D1
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.Oem;
			}
		}

		// Token: 0x06000E5E RID: 3678 RVA: 0x0000C0D5 File Offset: 0x0000A2D5
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, "bgp", rightOperand, context);
		}
	}
}
