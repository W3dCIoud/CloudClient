﻿using System;

namespace BlueStacks.Common.Grm
{
	// Token: 0x020001D5 RID: 469
	public class GrmRuleSetContext
	{
		// Token: 0x17000357 RID: 855
		// (get) Token: 0x06000E27 RID: 3623 RVA: 0x0000C058 File Offset: 0x0000A258
		// (set) Token: 0x06000E28 RID: 3624 RVA: 0x0000C060 File Offset: 0x0000A260
		public string PackageName { get; set; }

		// Token: 0x17000358 RID: 856
		// (get) Token: 0x06000E29 RID: 3625 RVA: 0x0000C069 File Offset: 0x0000A269
		// (set) Token: 0x06000E2A RID: 3626 RVA: 0x0000C071 File Offset: 0x0000A271
		public string VmName { get; set; }

		// Token: 0x17000359 RID: 857
		// (get) Token: 0x06000E2B RID: 3627 RVA: 0x0000C07A File Offset: 0x0000A27A
		// (set) Token: 0x06000E2C RID: 3628 RVA: 0x0000C082 File Offset: 0x0000A282
		public string RuleSetId { get; set; }

		// Token: 0x1700035A RID: 858
		// (get) Token: 0x06000E2D RID: 3629 RVA: 0x0000C08B File Offset: 0x0000A28B
		// (set) Token: 0x06000E2E RID: 3630 RVA: 0x0000C093 File Offset: 0x0000A293
		public string ContextJson { get; set; }
	}
}
