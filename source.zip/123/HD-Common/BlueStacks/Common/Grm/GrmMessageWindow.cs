﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace BlueStacks.Common.Grm
{
	// Token: 0x020001CB RID: 459
	public class GrmMessageWindow
	{
		// Token: 0x1700034D RID: 845
		// (get) Token: 0x06000E05 RID: 3589 RVA: 0x0000BF54 File Offset: 0x0000A154
		// (set) Token: 0x06000E06 RID: 3590 RVA: 0x0000BF5C File Offset: 0x0000A15C
		[JsonProperty(PropertyName = "messageType")]
		public string MessageType { get; set; } = "None";

		// Token: 0x1700034E RID: 846
		// (get) Token: 0x06000E07 RID: 3591 RVA: 0x0000BF65 File Offset: 0x0000A165
		// (set) Token: 0x06000E08 RID: 3592 RVA: 0x0000BF6D File Offset: 0x0000A16D
		[JsonProperty(PropertyName = "headerStringKey")]
		public string HeaderStringKey { get; set; } = string.Empty;

		// Token: 0x1700034F RID: 847
		// (get) Token: 0x06000E09 RID: 3593 RVA: 0x0000BF76 File Offset: 0x0000A176
		// (set) Token: 0x06000E0A RID: 3594 RVA: 0x0000BF7E File Offset: 0x0000A17E
		[JsonProperty(PropertyName = "messageStringKey")]
		public string MessageStringKey { get; set; } = string.Empty;

		// Token: 0x17000350 RID: 848
		// (get) Token: 0x06000E0B RID: 3595 RVA: 0x0000BF87 File Offset: 0x0000A187
		// (set) Token: 0x06000E0C RID: 3596 RVA: 0x0000BF8F File Offset: 0x0000A18F
		[JsonProperty(PropertyName = "dontShowOption")]
		public bool DontShowOption { get; set; }

		// Token: 0x17000351 RID: 849
		// (get) Token: 0x06000E0D RID: 3597 RVA: 0x0000BF98 File Offset: 0x0000A198
		// (set) Token: 0x06000E0E RID: 3598 RVA: 0x0000BFA0 File Offset: 0x0000A1A0
		[JsonProperty(PropertyName = "buttons")]
		public List<GrmMessageButton> Buttons { get; set; } = new List<GrmMessageButton>();
	}
}
