﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace BlueStacks.Common.Grm
{
	// Token: 0x020001CA RID: 458
	public class GrmMessageButton
	{
		// Token: 0x1700034B RID: 843
		// (get) Token: 0x06000E00 RID: 3584 RVA: 0x0000BF09 File Offset: 0x0000A109
		// (set) Token: 0x06000E01 RID: 3585 RVA: 0x0000BF11 File Offset: 0x0000A111
		[JsonProperty(PropertyName = "buttonColor")]
		public string ButtonColor { get; set; } = "Blue";

		// Token: 0x1700034C RID: 844
		// (get) Token: 0x06000E02 RID: 3586 RVA: 0x0000BF1A File Offset: 0x0000A11A
		// (set) Token: 0x06000E03 RID: 3587 RVA: 0x0000BF22 File Offset: 0x0000A122
		[JsonProperty(PropertyName = "buttonStringKey")]
		public string ButtonStringKey { get; set; } = string.Empty;

		// Token: 0x04000BC2 RID: 3010
		[JsonProperty(PropertyName = "actions")]
		public List<GrmAction> Actions = new List<GrmAction>();
	}
}
