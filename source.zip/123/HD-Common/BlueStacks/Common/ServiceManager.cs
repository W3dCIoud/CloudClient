﻿using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.ServiceProcess;
using System.Threading;
using Microsoft.Win32;

namespace BlueStacks.Common
{
	// Token: 0x02000174 RID: 372
	public class ServiceManager
	{
		// Token: 0x06000BFA RID: 3066
		[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern IntPtr OpenSCManager(string lpMachineName, string lpDatabaseName, ServiceManager.ServiceManagerRights dwDesiredAccess);

		// Token: 0x06000BFB RID: 3067
		[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern IntPtr OpenService(IntPtr hSCManager, string lpServiceName, ServiceManager.ServiceRights dwDesiredAccess);

		// Token: 0x06000BFC RID: 3068
		[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern IntPtr CreateService(IntPtr hSCManager, string lpServiceName, string lpDisplayName, ServiceManager.ServiceRights dwDesiredAccess, int dwServiceType, ServiceManager.ServiceBootFlag dwStartType, ServiceManager.ServiceError dwErrorControl, string lpBinaryPathName, string lpLoadOrderGroup, IntPtr lpdwTagId, string lpDependencies, string lp, string lpPassword);

		// Token: 0x06000BFD RID: 3069
		[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern int CloseServiceHandle(IntPtr hSCObject);

		// Token: 0x06000BFE RID: 3070
		[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern int QueryServiceStatus(IntPtr hService, ServiceManager.SERVICE_STATUS lpServiceStatus);

		// Token: 0x06000BFF RID: 3071
		[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern int DeleteService(IntPtr hService);

		// Token: 0x06000C00 RID: 3072
		[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern int ControlService(IntPtr hService, ServiceManager.ServiceControl dwControl, ServiceManager.SERVICE_STATUS lpServiceStatus);

		// Token: 0x06000C01 RID: 3073
		[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern int StartService(IntPtr hService, int dwNumServiceArgs, int lpServiceArgVectors);

		// Token: 0x06000C02 RID: 3074
		[DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern bool QueryServiceObjectSecurity(SafeHandle serviceHandle, SecurityInfos secInfo, byte[] lpSecDesrBuf, uint bufSize, out uint bufSizeNeeded);

		// Token: 0x06000C03 RID: 3075
		[DllImport("advapi32.dll", SetLastError = true)]
		private static extern bool SetServiceObjectSecurity(SafeHandle serviceHandle, SecurityInfos secInfos, byte[] lpSecDesrBuf);

		// Token: 0x06000C04 RID: 3076 RVA: 0x0003367C File Offset: 0x0003187C
		public static bool UninstallService(string serviceName, bool isKernelDriverService = false)
		{
			Logger.Info("{0} {1}", new object[]
			{
				MethodBase.GetCurrentMethod().Name,
				serviceName
			});
			IntPtr intPtr = ServiceManager.OpenSCManager(ServiceManager.ServiceManagerRights.Connect);
			bool result = true;
			try
			{
				IntPtr intPtr2 = ServiceManager.OpenService(intPtr, serviceName, (ServiceManager.ServiceRights)983076);
				if (intPtr2 == IntPtr.Zero)
				{
					Logger.Info("Service " + serviceName + " is not installed or inaccessible.");
					return true;
				}
				try
				{
					ServiceManager.StopService(intPtr2, isKernelDriverService);
					if (ServiceManager.DeleteService(intPtr2) == 0)
					{
						int lastWin32Error = Marshal.GetLastWin32Error();
						throw new Exception("Could not delete service " + lastWin32Error);
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to uninstall service... Err : " + ex.ToString());
					result = false;
				}
				finally
				{
					ServiceManager.CloseServiceHandle(intPtr2);
				}
			}
			finally
			{
				ServiceManager.CloseServiceHandle(intPtr);
			}
			return result;
		}

		// Token: 0x06000C05 RID: 3077 RVA: 0x00033770 File Offset: 0x00031970
		public static bool ServiceIsInstalled(string serviceName)
		{
			IntPtr intPtr = ServiceManager.OpenSCManager(ServiceManager.ServiceManagerRights.Connect);
			bool result;
			try
			{
				IntPtr intPtr2 = ServiceManager.OpenService(intPtr, serviceName, ServiceManager.ServiceRights.QueryStatus);
				if (intPtr2 == IntPtr.Zero)
				{
					result = false;
				}
				else
				{
					ServiceManager.CloseServiceHandle(intPtr2);
					result = true;
				}
			}
			finally
			{
				ServiceManager.CloseServiceHandle(intPtr);
			}
			return result;
		}

		// Token: 0x06000C06 RID: 3078 RVA: 0x000337C4 File Offset: 0x000319C4
		public static void InstallKernelDriver(string serviceName, string displayName, string fileName)
		{
			Logger.Info("{0} {1}", new object[]
			{
				MethodBase.GetCurrentMethod().Name,
				serviceName
			});
			IntPtr intPtr = ServiceManager.OpenSCManager(ServiceManager.ServiceManagerRights.AllAccess);
			try
			{
				if (ServiceManager.OpenService(intPtr, serviceName, ServiceManager.ServiceRights.QueryStatus | ServiceManager.ServiceRights.Start) != IntPtr.Zero)
				{
					Logger.Info("service is already installed...uninstalling it first");
					ServiceManager.UninstallService(serviceName, true);
				}
				IntPtr value = ServiceManager.CreateService(intPtr, serviceName, displayName, ServiceManager.ServiceRights.AllAccess, 1, ServiceManager.ServiceBootFlag.AutoStart, ServiceManager.ServiceError.Normal, fileName, null, IntPtr.Zero, null, null, null);
				int lastWin32Error = Marshal.GetLastWin32Error();
				if (value == IntPtr.Zero)
				{
					Logger.Info("Error in creating kernel driver service...last win32 error = " + lastWin32Error);
					throw new Exception("Failed to create service.");
				}
				Logger.Info("Successfully created service = " + serviceName + "...setting DACL now");
				ServiceManager.SetServicePermissions(serviceName);
				Logger.Info("Successfully set DACL");
			}
			catch (Exception ex)
			{
				ServiceManager.CloseServiceHandle(intPtr);
				Logger.Error("Failed to install kernel driver... Err : " + ex.ToString());
				throw new Exception(ex.Message);
			}
		}

		// Token: 0x06000C07 RID: 3079 RVA: 0x000338D0 File Offset: 0x00031AD0
		public static void Install(string serviceName, string displayName, string fileName)
		{
			Logger.Info("{0} {1}", new object[]
			{
				MethodBase.GetCurrentMethod().Name,
				serviceName
			});
			IntPtr intPtr = ServiceManager.OpenSCManager(ServiceManager.ServiceManagerRights.AllAccess);
			try
			{
				if (ServiceManager.OpenService(intPtr, serviceName, ServiceManager.ServiceRights.QueryStatus | ServiceManager.ServiceRights.Start) != IntPtr.Zero)
				{
					Logger.Info("service is already installed...uninstalling it first");
					ServiceManager.UninstallService(serviceName, false);
				}
				IntPtr value = ServiceManager.CreateService(intPtr, serviceName, displayName, ServiceManager.ServiceRights.AllAccess, 16, ServiceManager.ServiceBootFlag.AutoStart, ServiceManager.ServiceError.Normal, fileName, null, IntPtr.Zero, null, null, null);
				Logger.Info("Successfully created service = " + serviceName + "...setting DACL now");
				ServiceManager.SetServicePermissions(serviceName);
				Logger.Info("Successfully set DACL");
				if (value == IntPtr.Zero)
				{
					throw new Exception("Failed to install service.");
				}
			}
			catch (Exception ex)
			{
				ServiceManager.CloseServiceHandle(intPtr);
				Logger.Error("Failed to install kernel driver... Err : " + ex.ToString());
				throw new Exception(ex.Message);
			}
		}

		// Token: 0x06000C08 RID: 3080 RVA: 0x000339C4 File Offset: 0x00031BC4
		public static void StartService(string name, bool isKernelDriverService = false)
		{
			IntPtr intPtr = ServiceManager.OpenSCManager(ServiceManager.ServiceManagerRights.Connect);
			try
			{
				IntPtr intPtr2 = ServiceManager.OpenService(intPtr, name, ServiceManager.ServiceRights.QueryStatus | ServiceManager.ServiceRights.Start);
				if (intPtr2 == IntPtr.Zero)
				{
					throw new Exception("Could not open service.");
				}
				try
				{
					ServiceManager.StartService(intPtr2, isKernelDriverService);
				}
				finally
				{
					ServiceManager.CloseServiceHandle(intPtr2);
				}
			}
			finally
			{
				ServiceManager.CloseServiceHandle(intPtr);
			}
		}

		// Token: 0x06000C09 RID: 3081 RVA: 0x00033A30 File Offset: 0x00031C30
		public static void StopService(string name, bool isKernelDriverService = false)
		{
			Logger.Info("{0} {1}", new object[]
			{
				MethodBase.GetCurrentMethod().Name,
				name
			});
			IntPtr intPtr = ServiceManager.OpenSCManager(ServiceManager.ServiceManagerRights.Connect);
			try
			{
				IntPtr intPtr2 = ServiceManager.OpenService(intPtr, name, ServiceManager.ServiceRights.QueryStatus | ServiceManager.ServiceRights.Stop);
				if (!(intPtr2 == IntPtr.Zero))
				{
					try
					{
						ServiceManager.StopService(intPtr2, isKernelDriverService);
					}
					finally
					{
						ServiceManager.CloseServiceHandle(intPtr2);
					}
				}
			}
			finally
			{
				ServiceManager.CloseServiceHandle(intPtr);
			}
		}

		// Token: 0x06000C0A RID: 3082 RVA: 0x00033AB4 File Offset: 0x00031CB4
		private static void StartService(IntPtr hService, bool isKernelDriverService = false)
		{
			Logger.Info("{0} {1}", new object[]
			{
				MethodBase.GetCurrentMethod().Name,
				Convert.ToString(hService)
			});
			int num = ServiceManager.StartService(hService, 0, 0);
			if (num == 0)
			{
				int lastWin32Error = Marshal.GetLastWin32Error();
				Logger.Warning("Error in starting service, StartService ret: {0}, Last win32 error: {1}", new object[]
				{
					num,
					lastWin32Error
				});
			}
			ServiceManager.SERVICE_STATUS ssStatus = new ServiceManager.SERVICE_STATUS(isKernelDriverService);
			ServiceManager.WaitForServiceStatus(hService, ServiceManager.ServiceState.StartPending, ServiceManager.ServiceState.Running, ssStatus);
		}

		// Token: 0x06000C0B RID: 3083 RVA: 0x00033B34 File Offset: 0x00031D34
		private static void StopService(IntPtr hService, bool isKernelDriverService = false)
		{
			Logger.Info("{0} {1}", new object[]
			{
				MethodBase.GetCurrentMethod().Name,
				Convert.ToString(hService)
			});
			ServiceManager.SERVICE_STATUS service_STATUS = new ServiceManager.SERVICE_STATUS(isKernelDriverService);
			ServiceManager.ControlService(hService, ServiceManager.ServiceControl.Stop, service_STATUS);
			ServiceManager.WaitForServiceStatus(hService, ServiceManager.ServiceState.StopPending, ServiceManager.ServiceState.Stopped, service_STATUS);
		}

		// Token: 0x06000C0C RID: 3084 RVA: 0x00033B88 File Offset: 0x00031D88
		private static bool WaitForServiceStatus(IntPtr hService, ServiceManager.ServiceState waitStatus, ServiceManager.ServiceState desiredStatus, ServiceManager.SERVICE_STATUS ssStatus)
		{
			ServiceManager.QueryServiceStatus(hService, ssStatus);
			if (ssStatus.dwCurrentState == desiredStatus)
			{
				return true;
			}
			int tickCount = Environment.TickCount;
			int dwCheckPoint = ssStatus.dwCheckPoint;
			while (ssStatus.dwCurrentState == waitStatus)
			{
				int num = ssStatus.dwWaitHint / 10;
				if (num < 1000)
				{
					num = 1000;
				}
				else if (num > 10000)
				{
					num = 10000;
				}
				Thread.Sleep(num);
				if (ServiceManager.QueryServiceStatus(hService, ssStatus) == 0)
				{
					break;
				}
				if (ssStatus.dwCheckPoint > dwCheckPoint)
				{
					tickCount = Environment.TickCount;
					dwCheckPoint = ssStatus.dwCheckPoint;
				}
				else if (Environment.TickCount - tickCount > ssStatus.dwWaitHint)
				{
					break;
				}
			}
			return ssStatus.dwCurrentState == desiredStatus;
		}

		// Token: 0x06000C0D RID: 3085 RVA: 0x0000AEFB File Offset: 0x000090FB
		private static IntPtr OpenSCManager(ServiceManager.ServiceManagerRights rights)
		{
			Logger.Info("{0}", new object[]
			{
				MethodBase.GetCurrentMethod().Name
			});
			IntPtr intPtr = ServiceManager.OpenSCManager(null, null, rights);
			if (intPtr == IntPtr.Zero)
			{
				throw new Exception("Could not connect to service control manager.");
			}
			return intPtr;
		}

		// Token: 0x06000C0E RID: 3086 RVA: 0x00033C28 File Offset: 0x00031E28
		public static void SetServicePermissions(string serviceName)
		{
			Logger.Info("{0} {1}", new object[]
			{
				MethodBase.GetCurrentMethod().Name,
				serviceName
			});
			ServiceController serviceController = new ServiceController(serviceName, ".");
			ServiceControllerStatus status = serviceController.Status;
			byte[] array = new byte[0];
			uint num;
			bool flag = ServiceManager.QueryServiceObjectSecurity(serviceController.ServiceHandle, SecurityInfos.DiscretionaryAcl, array, 0U, out num);
			if (!flag)
			{
				int lastWin32Error = Marshal.GetLastWin32Error();
				if (lastWin32Error != 122 && lastWin32Error != 0)
				{
					throw new Exception("error calling QueryServiceObjectSecurity() to get DACL : error code=" + lastWin32Error);
				}
				array = new byte[num];
				flag = ServiceManager.QueryServiceObjectSecurity(serviceController.ServiceHandle, SecurityInfos.DiscretionaryAcl, array, num, out num);
			}
			if (!flag)
			{
				throw new Exception("error calling QueryServiceObjectSecurity(2) to get DACL : error code=" + Marshal.GetLastWin32Error());
			}
			RawSecurityDescriptor rawSecurityDescriptor = new RawSecurityDescriptor(array, 0);
			RawAcl discretionaryAcl = rawSecurityDescriptor.DiscretionaryAcl;
			DiscretionaryAcl discretionaryAcl2 = new DiscretionaryAcl(false, false, discretionaryAcl);
			SecurityIdentifier sid = new SecurityIdentifier(WellKnownSidType.InteractiveSid, null);
			discretionaryAcl2.AddAccess(AccessControlType.Allow, sid, 983551, InheritanceFlags.None, PropagationFlags.None);
			byte[] binaryForm = new byte[discretionaryAcl2.BinaryLength];
			discretionaryAcl2.GetBinaryForm(binaryForm, 0);
			rawSecurityDescriptor.DiscretionaryAcl = new RawAcl(binaryForm, 0);
			byte[] array2 = new byte[rawSecurityDescriptor.BinaryLength];
			rawSecurityDescriptor.GetBinaryForm(array2, 0);
			if (!ServiceManager.SetServiceObjectSecurity(serviceController.ServiceHandle, SecurityInfos.DiscretionaryAcl, array2))
			{
				throw new Exception("error calling SetServiceObjectSecurity(); error code=" + Marshal.GetLastWin32Error());
			}
		}

		// Token: 0x06000C0F RID: 3087 RVA: 0x00033D7C File Offset: 0x00031F7C
		public static int InstallBstkDrv(string installDir, string driverName = "")
		{
			Logger.Info("InstallService start");
			try
			{
				int num = ServiceManager.InstallPlusDriver(installDir, driverName);
				if (num != 0)
				{
					return num;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in installing BstkDrv, Err: " + ex.Message);
			}
			return 0;
		}

		// Token: 0x06000C10 RID: 3088 RVA: 0x00033DD4 File Offset: 0x00031FD4
		private static int CheckStatusAndReturnResult(int result)
		{
			try
			{
				Logger.Info("Install failed due to: {0}", new object[]
				{
					(InstallerCodes)result
				});
			}
			catch
			{
			}
			return result;
		}

		// Token: 0x06000C11 RID: 3089 RVA: 0x00033E14 File Offset: 0x00032014
		private static int InstallPlusDriver(string installDir, string driverName = "")
		{
			Logger.Info("Installing driver");
			ServiceController[] devices = ServiceController.GetDevices();
			string text = Strings.BlueStacksDriverName;
			if (!string.IsNullOrEmpty(driverName))
			{
				text = driverName;
			}
			string blueStacksDriverDisplayName = Strings.BlueStacksDriverDisplayName;
			string text2 = Path.Combine(installDir, "BstkDrv.sys");
			Logger.Info("Registering driver with params: file path : {0}, DriverName {1}, DisplayName: {2}", new object[]
			{
				text2,
				text,
				blueStacksDriverDisplayName
			});
			if (!ServiceManager.IsServiceAlreadyExists(devices, text, installDir) && !ServiceManager.InstallDriver(text, text2, blueStacksDriverDisplayName))
			{
				Logger.Error("Failed to install driver");
				return -40;
			}
			Logger.Info("Successfully Installed Driver");
			return 0;
		}

		// Token: 0x06000C12 RID: 3090 RVA: 0x00033E9C File Offset: 0x0003209C
		private static bool InstallDriver(string driverName, string driverPath, string driverDisplayName)
		{
			try
			{
				ServiceManager.StopService(driverName, false);
				ServiceManager.UninstallService(driverName, true);
			}
			catch (Exception ex)
			{
				Logger.Info("Ignore Error, when stopping and uninstalling driver ex : {0}", new object[]
				{
					ex.ToString()
				});
			}
			bool result;
			try
			{
				ServiceManager.InstallKernelDriver(driverName, driverDisplayName, driverPath);
				result = true;
			}
			catch (Exception ex2)
			{
				Logger.Error(string.Format("Error Occured, Err: {0}", ex2.ToString()));
				result = false;
			}
			return result;
		}

		// Token: 0x06000C13 RID: 3091 RVA: 0x00033F1C File Offset: 0x0003211C
		private static string GetImagePathOfService(string serviceName)
		{
			string result;
			try
			{
				Logger.Info("Checking for marked for deletion flag in service {0}", new object[]
				{
					serviceName
				});
				string name = Path.Combine("System\\CurrentControlSet\\Services", serviceName);
				result = (string)Registry.LocalMachine.OpenSubKey(name).GetValue("ImagePath");
			}
			catch (Exception ex)
			{
				Logger.Error("Could not get the image path for service {0}, ex: {1}", new object[]
				{
					serviceName,
					ex.ToString()
				});
				result = null;
			}
			return result;
		}

		// Token: 0x06000C14 RID: 3092 RVA: 0x00033F9C File Offset: 0x0003219C
		private static bool CheckIfInstalledServicePathAndInstallDirPathMatch(string serviceName, string installDir)
		{
			Logger.Info("Checking file path for {0}", new object[]
			{
				serviceName
			});
			string imagePathOfService = ServiceManager.GetImagePathOfService(serviceName);
			if (string.IsNullOrEmpty(imagePathOfService))
			{
				Logger.Error("The code checking image path of service returned null");
				return false;
			}
			string installDirOfService = ServiceManager.GetInstallDirOfService(imagePathOfService);
			if (installDirOfService != installDir)
			{
				Logger.Error("Service {0} is already installed but at incorrect path {1}, required path is {2}", new object[]
				{
					serviceName,
					installDirOfService,
					installDir
				});
				return false;
			}
			return true;
		}

		// Token: 0x06000C15 RID: 3093 RVA: 0x00034008 File Offset: 0x00032208
		private static string GetInstallDirOfService(string servicePath)
		{
			int num = servicePath.IndexOf(".sys");
			if (num != -1)
			{
				return Path.GetDirectoryName(servicePath.Substring(4, num));
			}
			num = servicePath.IndexOf(".exe");
			if (num == -1)
			{
				return null;
			}
			return Path.GetDirectoryName(servicePath.Substring(0, num + 4).Replace("\"", ""));
		}

		// Token: 0x06000C16 RID: 3094 RVA: 0x00034064 File Offset: 0x00032264
		private static bool IsServiceAlreadyExists(ServiceController[] services, string serviceName, string installDir)
		{
			Logger.Info("Checking if service {0} exists on user's machine", new object[]
			{
				serviceName
			});
			try
			{
				for (int i = 0; i < services.Length; i++)
				{
					if (services[i].ServiceName.Equals(serviceName, StringComparison.OrdinalIgnoreCase))
					{
						Logger.Info("Found service: " + serviceName);
						return true;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Exception in checking if service {0} is installed ex: {1}", new object[]
				{
					serviceName,
					ex.ToString()
				});
			}
			return false;
		}

		// Token: 0x06000C17 RID: 3095 RVA: 0x0000AF3A File Offset: 0x0000913A
		public static int CheckForBlueStacksServicesMarkForDeletion(string serviceName)
		{
			if (ServiceManager.CheckIfServiceHasBeenMarkedForDeletion(serviceName))
			{
				return -30;
			}
			return 0;
		}

		// Token: 0x06000C18 RID: 3096 RVA: 0x000340F0 File Offset: 0x000322F0
		private static bool CheckIfServiceHasBeenMarkedForDeletion(string serviceName)
		{
			try
			{
				Logger.Info("checking for marked for deletion flag in service {0}", new object[]
				{
					serviceName
				});
				string name = Path.Combine("system\\CurrentControlSet\\services", serviceName);
				if ((int)Registry.LocalMachine.OpenSubKey(name).GetValue("DeleteFlag") == 1)
				{
					Logger.Info("the  service {0} has been marked for deletion.", new object[]
					{
						serviceName
					});
					return true;
				}
			}
			catch (Exception)
			{
				Logger.Warning("Could not check for service marked for deletion. should be safe to ignore in most cases.");
			}
			return false;
		}

		// Token: 0x04000846 RID: 2118
		private const int SERVICE_WIN32_OWN_PROCESS = 16;

		// Token: 0x04000847 RID: 2119
		private const int SERVICE_KERNEL_DRIVER = 1;

		// Token: 0x02000175 RID: 373
		[Flags]
		public enum ServiceManagerRights
		{
			// Token: 0x04000849 RID: 2121
			Connect = 1,
			// Token: 0x0400084A RID: 2122
			CreateService = 2,
			// Token: 0x0400084B RID: 2123
			EnumerateService = 4,
			// Token: 0x0400084C RID: 2124
			Lock = 8,
			// Token: 0x0400084D RID: 2125
			QueryLockStatus = 16,
			// Token: 0x0400084E RID: 2126
			ModifyBootConfig = 32,
			// Token: 0x0400084F RID: 2127
			StandardRightsRequired = 983040,
			// Token: 0x04000850 RID: 2128
			AllAccess = 983103
		}

		// Token: 0x02000176 RID: 374
		[Flags]
		public enum ServiceRights
		{
			// Token: 0x04000852 RID: 2130
			QueryConfig = 1,
			// Token: 0x04000853 RID: 2131
			ChangeConfig = 2,
			// Token: 0x04000854 RID: 2132
			QueryStatus = 4,
			// Token: 0x04000855 RID: 2133
			EnumerateDependants = 8,
			// Token: 0x04000856 RID: 2134
			Start = 16,
			// Token: 0x04000857 RID: 2135
			Stop = 32,
			// Token: 0x04000858 RID: 2136
			PauseContinue = 64,
			// Token: 0x04000859 RID: 2137
			Interrogate = 128,
			// Token: 0x0400085A RID: 2138
			UserDefinedControl = 256,
			// Token: 0x0400085B RID: 2139
			Delete = 65536,
			// Token: 0x0400085C RID: 2140
			StandardRightsRequired = 983040,
			// Token: 0x0400085D RID: 2141
			ReadControl = 131072,
			// Token: 0x0400085E RID: 2142
			AllAccess = 983551
		}

		// Token: 0x02000177 RID: 375
		public enum ServiceBootFlag
		{
			// Token: 0x04000860 RID: 2144
			BootStart,
			// Token: 0x04000861 RID: 2145
			SystemStart,
			// Token: 0x04000862 RID: 2146
			AutoStart,
			// Token: 0x04000863 RID: 2147
			DemandStart,
			// Token: 0x04000864 RID: 2148
			Disabled
		}

		// Token: 0x02000178 RID: 376
		public enum ServiceControl
		{
			// Token: 0x04000866 RID: 2150
			Stop = 1,
			// Token: 0x04000867 RID: 2151
			Pause,
			// Token: 0x04000868 RID: 2152
			Continue,
			// Token: 0x04000869 RID: 2153
			Interrogate,
			// Token: 0x0400086A RID: 2154
			Shutdown,
			// Token: 0x0400086B RID: 2155
			ParamChange,
			// Token: 0x0400086C RID: 2156
			NetBindAdd,
			// Token: 0x0400086D RID: 2157
			NetBindRemove,
			// Token: 0x0400086E RID: 2158
			NetBindEnable,
			// Token: 0x0400086F RID: 2159
			NetBindDisable
		}

		// Token: 0x02000179 RID: 377
		public enum ServiceError
		{
			// Token: 0x04000871 RID: 2161
			Ignore,
			// Token: 0x04000872 RID: 2162
			Normal,
			// Token: 0x04000873 RID: 2163
			Severe,
			// Token: 0x04000874 RID: 2164
			Critical
		}

		// Token: 0x0200017A RID: 378
		public enum ServiceState
		{
			// Token: 0x04000876 RID: 2166
			Unknown = -1,
			// Token: 0x04000877 RID: 2167
			NotFound,
			// Token: 0x04000878 RID: 2168
			Stopped,
			// Token: 0x04000879 RID: 2169
			StartPending,
			// Token: 0x0400087A RID: 2170
			StopPending,
			// Token: 0x0400087B RID: 2171
			Running,
			// Token: 0x0400087C RID: 2172
			ContinuePending,
			// Token: 0x0400087D RID: 2173
			PausePending,
			// Token: 0x0400087E RID: 2174
			Paused
		}

		// Token: 0x0200017B RID: 379
		[StructLayout(LayoutKind.Sequential)]
		private class SERVICE_STATUS
		{
			// Token: 0x06000C1A RID: 3098 RVA: 0x0000AF48 File Offset: 0x00009148
			public SERVICE_STATUS(bool isKernelDriver)
			{
				if (isKernelDriver)
				{
					this.dwServiceType = 1;
				}
			}

			// Token: 0x0400087F RID: 2175
			public int dwServiceType = 16;

			// Token: 0x04000880 RID: 2176
			public ServiceManager.ServiceState dwCurrentState;

			// Token: 0x04000881 RID: 2177
			public int dwControlsAccepted;

			// Token: 0x04000882 RID: 2178
			public int dwWin32ExitCode;

			// Token: 0x04000883 RID: 2179
			public int dwServiceSpecificExitCode;

			// Token: 0x04000884 RID: 2180
			public int dwCheckPoint;

			// Token: 0x04000885 RID: 2181
			public int dwWaitHint;
		}
	}
}
