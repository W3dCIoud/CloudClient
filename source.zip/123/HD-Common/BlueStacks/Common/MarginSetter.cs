﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x020000E2 RID: 226
	public class MarginSetter : MarkupExtension
	{
		// Token: 0x06000678 RID: 1656 RVA: 0x0000693C File Offset: 0x00004B3C
		private static Thickness GetMargin(DependencyObject obj)
		{
			return (Thickness)obj.GetValue(MarginSetter.MarginProperty);
		}

		// Token: 0x06000679 RID: 1657 RVA: 0x0000694E File Offset: 0x00004B4E
		public static void SetMargin(DependencyObject obj, Thickness value)
		{
			obj.SetValue(MarginSetter.MarginProperty, value);
		}

		// Token: 0x0600067A RID: 1658 RVA: 0x0001F7D4 File Offset: 0x0001D9D4
		public static void CreateThicknesForChildren(object sender, DependencyPropertyChangedEventArgs e)
		{
			Panel panel = sender as Panel;
			if (panel == null)
			{
				return;
			}
			foreach (object obj in panel.Children)
			{
				FrameworkElement frameworkElement = obj as FrameworkElement;
				if (frameworkElement != null)
				{
					frameworkElement.Margin = MarginSetter.GetMargin(panel);
				}
			}
		}

		// Token: 0x0600067B RID: 1659 RVA: 0x00003F48 File Offset: 0x00002148
		public override object ProvideValue(IServiceProvider serviceProvider)
		{
			return this;
		}

		// Token: 0x0400058F RID: 1423
		public static readonly DependencyProperty MarginProperty = DependencyProperty.RegisterAttached("Margin", typeof(Thickness), typeof(MarginSetter), new UIPropertyMetadata(default(Thickness), new PropertyChangedCallback(MarginSetter.CreateThicknesForChildren)));
	}
}
