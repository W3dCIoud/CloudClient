﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000D5 RID: 213
	public enum InstallationTypes
	{
		// Token: 0x04000532 RID: 1330
		None,
		// Token: 0x04000533 RID: 1331
		GamingEdition,
		// Token: 0x04000534 RID: 1332
		FullEdition,
		// Token: 0x04000535 RID: 1333
		ClientOnly
	}
}
