﻿using System;
using System.IO;

namespace BlueStacks.Common
{
	// Token: 0x02000084 RID: 132
	public class RegistryStrings
	{
		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x060002C3 RID: 707 RVA: 0x00003694 File Offset: 0x00001894
		public static string DataDir
		{
			get
			{
				if (RegistryStrings.sDataDir == null)
				{
					RegistryStrings.sDataDir = (string)RegistryUtils.GetRegistryValue(Strings.RegistryBaseKeyPath, "DataDir", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
				}
				return RegistryStrings.sDataDir;
			}
		}

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x060002C4 RID: 708 RVA: 0x000036C1 File Offset: 0x000018C1
		public static string InstallDir
		{
			get
			{
				if (RegistryStrings.sInstallDir == null)
				{
					RegistryStrings.sInstallDir = (string)RegistryUtils.GetRegistryValue(Strings.RegistryBaseKeyPath, "InstallDir", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
				}
				return RegistryStrings.sInstallDir;
			}
		}

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x060002C5 RID: 709 RVA: 0x000036EE File Offset: 0x000018EE
		public static string UserDefinedDir
		{
			get
			{
				if (RegistryStrings.sUserDefinedDir == null)
				{
					RegistryStrings.sUserDefinedDir = (string)RegistryUtils.GetRegistryValue(Strings.RegistryBaseKeyPath, "UserDefinedDir", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
				}
				return RegistryStrings.sUserDefinedDir;
			}
		}

		// Token: 0x060002C6 RID: 710 RVA: 0x0000371B File Offset: 0x0000191B
		public static string GetBstAndroidDir(string vmName)
		{
			return Path.Combine(RegistryStrings.DataDir, vmName);
		}

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x060002C7 RID: 711 RVA: 0x00003728 File Offset: 0x00001928
		public static string ProductIconCompletePath
		{
			get
			{
				if (RegistryStrings.sProductIconCompletePath == null)
				{
					RegistryStrings.sProductIconCompletePath = Path.Combine(RegistryStrings.InstallDir, "ProductLogo.ico");
				}
				return RegistryStrings.sProductIconCompletePath;
			}
		}

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x060002C8 RID: 712 RVA: 0x0000374A File Offset: 0x0000194A
		public static string ProductImageCompletePath
		{
			get
			{
				if (RegistryStrings.sProductImageCompletePath == null)
				{
					RegistryStrings.sProductImageCompletePath = Path.Combine(RegistryStrings.InstallDir, "ProductLogo.png");
				}
				return RegistryStrings.sProductImageCompletePath;
			}
		}

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x060002C9 RID: 713 RVA: 0x0000376C File Offset: 0x0000196C
		public static string BstUserDataDir
		{
			get
			{
				if (RegistryStrings.sBstUserDataDir == null)
				{
					RegistryStrings.sBstUserDataDir = Path.Combine(RegistryStrings.DataDir, "UserData");
				}
				return RegistryStrings.sBstUserDataDir;
			}
		}

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x060002CA RID: 714 RVA: 0x0000378E File Offset: 0x0000198E
		public static string BstLogsDir
		{
			get
			{
				if (RegistryStrings.sBstLogsDir == null)
				{
					RegistryStrings.sBstLogsDir = Path.Combine(RegistryManager.Instance.UserDefinedDir, "Logs");
				}
				return RegistryStrings.sBstLogsDir;
			}
		}

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x060002CB RID: 715 RVA: 0x000037B5 File Offset: 0x000019B5
		public static string GadgetDir
		{
			get
			{
				if (RegistryStrings.sGadgetDir == null)
				{
					RegistryStrings.sGadgetDir = Path.Combine(RegistryStrings.BstUserDataDir, "Gadget");
				}
				return RegistryStrings.sGadgetDir;
			}
		}

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x060002CC RID: 716 RVA: 0x000037D7 File Offset: 0x000019D7
		public static string InputMapperFolder
		{
			get
			{
				if (RegistryStrings.sInputMapperFolder == null)
				{
					RegistryStrings.sInputMapperFolder = Path.Combine(RegistryStrings.BstUserDataDir, "InputMapper");
				}
				return RegistryStrings.sInputMapperFolder;
			}
		}

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x060002CD RID: 717 RVA: 0x000037F9 File Offset: 0x000019F9
		public static string SharedFolderDir
		{
			get
			{
				if (RegistryStrings.sSharedFolderDir == null)
				{
					RegistryStrings.sSharedFolderDir = Path.Combine(RegistryStrings.BstUserDataDir, "SharedFolder");
				}
				return RegistryStrings.sSharedFolderDir;
			}
		}

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x060002CE RID: 718 RVA: 0x0000381B File Offset: 0x00001A1B
		public static string LibraryDir
		{
			get
			{
				if (RegistryStrings.sLibraryDir == null)
				{
					RegistryStrings.sLibraryDir = Path.Combine(RegistryStrings.BstUserDataDir, "Library");
				}
				return RegistryStrings.sLibraryDir;
			}
		}

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x060002CF RID: 719 RVA: 0x0000383D File Offset: 0x00001A3D
		public static string PromotionDirectory
		{
			get
			{
				if (RegistryStrings.sPromotionDirectory == null)
				{
					RegistryStrings.sPromotionDirectory = Path.Combine(RegistryManager.Instance.ClientInstallDir, "Promo");
				}
				return RegistryStrings.sPromotionDirectory;
			}
		}

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x060002D0 RID: 720 RVA: 0x00003864 File Offset: 0x00001A64
		public static string OperationsScriptFolder
		{
			get
			{
				if (RegistryStrings.sOperationsScriptFolder == null)
				{
					RegistryStrings.sOperationsScriptFolder = Path.Combine(RegistryStrings.InputMapperFolder, "UserScripts");
				}
				return RegistryStrings.sOperationsScriptFolder;
			}
		}

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x060002D1 RID: 721 RVA: 0x00003886 File Offset: 0x00001A86
		public static string BstManagerDir
		{
			get
			{
				if (RegistryStrings.sBstManagerDir == null)
				{
					RegistryStrings.sBstManagerDir = Path.Combine(RegistryStrings.DataDir, "Manager");
				}
				return RegistryStrings.sBstManagerDir;
			}
		}

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x060002D2 RID: 722 RVA: 0x000038A8 File Offset: 0x00001AA8
		public static string RegistryBaseKeyPath
		{
			get
			{
				if (RegistryStrings.sRegistryBaseKeyPath == null)
				{
					RegistryStrings.sRegistryBaseKeyPath = Strings.RegistryBaseKeyPath + RegistryManager.UPGRADE_TAG;
				}
				return RegistryStrings.sRegistryBaseKeyPath;
			}
		}

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x060002D3 RID: 723 RVA: 0x000038CA File Offset: 0x00001ACA
		public static string UserAgent
		{
			get
			{
				if (RegistryStrings.sUserAgent == null)
				{
					RegistryStrings.sUserAgent = Utils.GetUserAgent(null, null);
				}
				return RegistryStrings.sUserAgent;
			}
		}

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x060002D4 RID: 724 RVA: 0x000038E4 File Offset: 0x00001AE4
		public static string CursorPath
		{
			get
			{
				return Path.Combine(CustomPictureBox.AssetsDir, "Mouse_cursor.png");
			}
		}

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x060002D5 RID: 725 RVA: 0x000038F5 File Offset: 0x00001AF5
		public static string BtvDir
		{
			get
			{
				return Path.Combine(RegistryManager.Instance.UserDefinedDir, "BTV");
			}
		}

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x060002D6 RID: 726 RVA: 0x0000390B File Offset: 0x00001B0B
		public static string ObsDir
		{
			get
			{
				return Path.Combine(RegistryStrings.BtvDir, "OBS");
			}
		}

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x060002D7 RID: 727 RVA: 0x0000391C File Offset: 0x00001B1C
		public static string ObsBinaryPath
		{
			get
			{
				return Path.Combine(RegistryStrings.ObsDir, "HD-OBS.exe");
			}
		}

		// Token: 0x040002FB RID: 763
		private static string sDataDir = null;

		// Token: 0x040002FC RID: 764
		private static string sInstallDir = null;

		// Token: 0x040002FD RID: 765
		private static string sUserDefinedDir = null;

		// Token: 0x040002FE RID: 766
		private static string sProductIconCompletePath = null;

		// Token: 0x040002FF RID: 767
		private static string sProductImageCompletePath = null;

		// Token: 0x04000300 RID: 768
		private static string sBstUserDataDir = null;

		// Token: 0x04000301 RID: 769
		private static string sBstLogsDir = null;

		// Token: 0x04000302 RID: 770
		private static string sGadgetDir = null;

		// Token: 0x04000303 RID: 771
		private static string sInputMapperFolder = null;

		// Token: 0x04000304 RID: 772
		private static string sSharedFolderDir = null;

		// Token: 0x04000305 RID: 773
		private static string sLibraryDir = null;

		// Token: 0x04000306 RID: 774
		private static string sPromotionDirectory = null;

		// Token: 0x04000307 RID: 775
		private static string sOperationsScriptFolder = null;

		// Token: 0x04000308 RID: 776
		private static string sBstManagerDir = null;

		// Token: 0x04000309 RID: 777
		private static string sRegistryBaseKeyPath = null;

		// Token: 0x0400030A RID: 778
		private static string sUserAgent = null;

		// Token: 0x0400030B RID: 779
		public static string ScreenshotDefaultPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), Strings.ProductTopBarDisplayName);
	}
}
