﻿using System;
using System.IO;

namespace BlueStacks.Common
{
	// Token: 0x02000184 RID: 388
	public class Strings
	{
		// Token: 0x170002F2 RID: 754
		// (get) Token: 0x06000C5C RID: 3164 RVA: 0x0000B21B File Offset: 0x0000941B
		public static string OEMTag
		{
			get
			{
				return Strings.GetOemTag();
			}
		}

		// Token: 0x06000C5D RID: 3165 RVA: 0x0000B222 File Offset: 0x00009422
		public static string GetOemTag()
		{
			if (Strings.sOemTag == null)
			{
				Strings.sOemTag = ("bgp".Equals("bgp") ? "" : "_bgp");
			}
			return Strings.sOemTag;
		}

		// Token: 0x170002F3 RID: 755
		// (get) Token: 0x06000C5E RID: 3166 RVA: 0x0000B252 File Offset: 0x00009452
		public static string BlueStacksDriverDisplayName
		{
			get
			{
				if (string.IsNullOrEmpty(Strings.GetOemTag()))
				{
					return "BlueStacks Hypervisor";
				}
				return string.Format("BlueStacks Hypervisor{0}", Strings.GetOemTag());
			}
		}

		// Token: 0x170002F4 RID: 756
		// (get) Token: 0x06000C5F RID: 3167 RVA: 0x0000B275 File Offset: 0x00009475
		// (set) Token: 0x06000C60 RID: 3168 RVA: 0x0000B27C File Offset: 0x0000947C
		public static string CurrentDefaultVmName
		{
			get
			{
				return Strings.mCurrentDefaultVmName;
			}
			set
			{
				Strings.mCurrentDefaultVmName = value;
				if (string.IsNullOrEmpty(Strings.mCurrentDefaultVmName))
				{
					Strings.mCurrentDefaultVmName = "Android";
				}
			}
		}

		// Token: 0x170002F5 RID: 757
		// (get) Token: 0x06000C61 RID: 3169 RVA: 0x0000B29A File Offset: 0x0000949A
		public static string DefaultWindowTitle
		{
			get
			{
				return "App Player";
			}
		}

		// Token: 0x170002F6 RID: 758
		// (get) Token: 0x06000C62 RID: 3170 RVA: 0x0000B2A1 File Offset: 0x000094A1
		// (set) Token: 0x06000C63 RID: 3171 RVA: 0x0000B2B5 File Offset: 0x000094B5
		public static string AppTitle
		{
			get
			{
				if (Strings.s_AppTitle != null)
				{
					return Strings.s_AppTitle;
				}
				return Strings.DefaultWindowTitle;
			}
			set
			{
				Strings.s_AppTitle = value;
			}
		}

		// Token: 0x170002F7 RID: 759
		// (get) Token: 0x06000C64 RID: 3172 RVA: 0x0000B2BD File Offset: 0x000094BD
		public static string BlueStacksSetupFolder
		{
			get
			{
				if (string.IsNullOrEmpty(Strings.sBlueStacksSetupFolder))
				{
					Strings.sBlueStacksSetupFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "BlueStacksSetup");
				}
				return Strings.sBlueStacksSetupFolder;
			}
		}

		// Token: 0x06000C65 RID: 3173 RVA: 0x000349C0 File Offset: 0x00032BC0
		public static string AddOrdinal(int num)
		{
			if (num < 0)
			{
				return num.ToString();
			}
			if (num % 100 - 11 <= 2)
			{
				return num + "th";
			}
			switch (num % 10)
			{
			case 1:
				return num + "st";
			case 2:
				return num + "nd";
			case 3:
				return num + "rd";
			default:
				return num + "th";
			}
		}

		// Token: 0x06000C66 RID: 3174 RVA: 0x0000B2E6 File Offset: 0x000094E6
		public static string GetPlayerLockName(string vmName)
		{
			return string.Format("Global\\BlueStacks_{0}_Player_Lock", vmName);
		}

		// Token: 0x06000C67 RID: 3175 RVA: 0x0000B2F3 File Offset: 0x000094F3
		public static string GetHDApkInstallerLockName(string vmName)
		{
			return string.Format("Global\\BlueStacks_HDApkInstaller_{0}_Lock", vmName);
		}

		// Token: 0x06000C68 RID: 3176 RVA: 0x0000B300 File Offset: 0x00009500
		public static string GetHDXapkInstallerLockName(string vmName)
		{
			return string.Format("Global\\BlueStacks_HDXapkInstaller_{0}_Lock", vmName);
		}

		// Token: 0x06000C69 RID: 3177 RVA: 0x0000B30D File Offset: 0x0000950D
		public static string GetClientInstanceLockName(string vmName)
		{
			return string.Format("Global\\BlueStacks_Client_Instance_{0}_Lock", vmName);
		}

		// Token: 0x040008A8 RID: 2216
		public const string DefaultOEM = "bgp";

		// Token: 0x040008A9 RID: 2217
		private static string sOemTag = null;

		// Token: 0x040008AA RID: 2218
		public const string DefaultVmName = "Android";

		// Token: 0x040008AB RID: 2219
		private static string mCurrentDefaultVmName = "Android";

		// Token: 0x040008AC RID: 2220
		private static string s_AppTitle = null;

		// Token: 0x040008AD RID: 2221
		private static string sBlueStacksSetupFolder = "";

		// Token: 0x040008AE RID: 2222
		public static string BlueStacksOldDriverName = "BstkDrv" + Strings.OEMTag;

		// Token: 0x040008AF RID: 2223
		public const string BlueStacksDriverNameWithoutOEM = "BlueStacksDrv";

		// Token: 0x040008B0 RID: 2224
		public static string BlueStacksDriverName = "BlueStacksDrv" + Strings.OEMTag;

		// Token: 0x040008B1 RID: 2225
		public static string BlueStacksIdRegistryPath = "Software\\BlueStacksInstaller";

		// Token: 0x040008B2 RID: 2226
		public static string ClientRegistry32BitPath = "Software\\BlueStacksGP" + Strings.OEMTag;

		// Token: 0x040008B3 RID: 2227
		public static string ClientRegistry64BitPath = "Software\\WOW6432Node\\BlueStacksGP" + Strings.OEMTag;

		// Token: 0x040008B4 RID: 2228
		public const string RegistryBaseKeyPathWithoutOEM = "Software\\BlueStacks";

		// Token: 0x040008B5 RID: 2229
		public static string RegistryBaseKeyPath = "Software\\BlueStacks" + Strings.OEMTag;

		// Token: 0x040008B6 RID: 2230
		public static string UninstallRegistryExportedFilePath = Path.Combine(Path.GetTempPath(), "BSTUninstall.reg");

		// Token: 0x040008B7 RID: 2231
		public static string BGPKeyName = "BlueStacksGP" + Strings.OEMTag;

		// Token: 0x040008B8 RID: 2232
		public const string BlueStacksUIClosingLockName = "Global\\BlueStacks_BlueStacksUI_Closing_Lock";

		// Token: 0x040008B9 RID: 2233
		public const string MultiInsLockName = "Global\\BlueStacks_MULTI_INS_Frontend_Lock";

		// Token: 0x040008BA RID: 2234
		public const string LogCollectorLockName = "Global\\BlueStacks_Log_Collector_Lock";

		// Token: 0x040008BB RID: 2235
		public const string HDAgentLockName = "Global\\BlueStacks_HDAgent_Lock";

		// Token: 0x040008BC RID: 2236
		public const string HDQuitMultiInstallLockName = "Global\\BlueStacks_HDQuitMultiInstall_Lock";

		// Token: 0x040008BD RID: 2237
		public const string ComRegistrarLockName = "Global\\BlueStacks_UnRegRegCom_Lock";

		// Token: 0x040008BE RID: 2238
		public const string GetBlueStacksUILockName = "Global\\BlueStacks_BlueStacksUI_Lock";

		// Token: 0x040008BF RID: 2239
		public const string DataManagerLock = "Global\\BlueStacks_Downloader_Lock";

		// Token: 0x040008C0 RID: 2240
		public const string UninstallerLock = "Global\\BlueStacks_Uninstaller_Lock";

		// Token: 0x040008C1 RID: 2241
		public const string MultiInstanceManagerLock = "Global\\BlueStacks_MultiInstanceManager_Lock";

		// Token: 0x040008C2 RID: 2242
		public const string InstallerLockName = "Global\\BlueStacks_Installer_Lock";

		// Token: 0x040008C3 RID: 2243
		public const string CloudWatcherLock = "Global\\BlueStacks_CloudWatcher_Lock";

		// Token: 0x040008C4 RID: 2244
		public const string DiskCompactorLock = "Global\\BlueStacks_DiskCompactor_Lock";

		// Token: 0x040008C5 RID: 2245
		public const string MicroInstallerLock = "Global\\BlueStacks_MicroInstaller_Lock";

		// Token: 0x040008C6 RID: 2246
		public const string InputMapperDLL = "HD-Imap-Native.dll";

		// Token: 0x040008C7 RID: 2247
		public const string InstancePrefix = "Android_";

		// Token: 0x040008C8 RID: 2248
		public const string AppInstallFinished = "appinstallfinished";

		// Token: 0x040008C9 RID: 2249
		public const string AppInstallProgress = "appinstallprogress";

		// Token: 0x040008CA RID: 2250
		public const string BluestacksMultiInstanceManager = "BlueStacks Multi-Instance Manager";

		// Token: 0x040008CB RID: 2251
		public const string DiskCleanup = "Disk cleanup";

		// Token: 0x040008CC RID: 2252
		public const string MultiInstanceManagerBinName = "HD-MultiInstanceManager.exe";

		// Token: 0x040008CD RID: 2253
		public const string ProductIconName = "ProductLogo.ico";

		// Token: 0x040008CE RID: 2254
		public const string ProductImageName = "ProductLogo.png";

		// Token: 0x040008CF RID: 2255
		public const string GameIconFileName = "app_icon.ico";

		// Token: 0x040008D0 RID: 2256
		public const string ApkHandlerBaseKeyName = "BlueStacks.Apk";

		// Token: 0x040008D1 RID: 2257
		public const string ScriptFileWhichRemovesGamingEdition = "RemoveGamingFiles.bat";

		// Token: 0x040008D2 RID: 2258
		public const string UninstallCurrentVersionRegPath = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall";

		// Token: 0x040008D3 RID: 2259
		public const string UninstallCurrentVersionRegPath32Bit = "SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall";

		// Token: 0x040008D4 RID: 2260
		public const string UninstallCurrentVersion32RegPath = "SOFTWARE\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall";

		// Token: 0x040008D5 RID: 2261
		public const string UninstallKey = "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall";

		// Token: 0x040008D6 RID: 2262
		public const string ShowEnableVtPopupUrl = "showenablevtpopup";

		// Token: 0x040008D7 RID: 2263
		public const string SharePicUrl = "sharepic";

		// Token: 0x040008D8 RID: 2264
		public const string ShowGuidanceUrl = "controller_guidance_pressed";

		// Token: 0x040008D9 RID: 2265
		public const string AgentCrashReportUrl = "stats/agentcrashreport";

		// Token: 0x040008DA RID: 2266
		public const string AppClickStatsUrl = "stats/appclickstats";

		// Token: 0x040008DB RID: 2267
		public const string WebAppChannelClickStatsUrl = "stats/webappchannelclickstats";

		// Token: 0x040008DC RID: 2268
		public const string FrontendStatusUpdateUrl = "FrontendStatusUpdate";

		// Token: 0x040008DD RID: 2269
		public const string SearchAppStatsUrl = "stats/searchappstats";

		// Token: 0x040008DE RID: 2270
		public const string AppInstallStatsUrl = "stats/appinstallstats";

		// Token: 0x040008DF RID: 2271
		public const string SystemInfoStatsUrl = "stats/systeminfostats";

		// Token: 0x040008E0 RID: 2272
		public const string BootStatsUrl = "stats/bootstats";

		// Token: 0x040008E1 RID: 2273
		public const string TimelineStatsUrl = "stats/timelinestats4";

		// Token: 0x040008E2 RID: 2274
		public const string HomeScreenStatsUrl = "stats/homescreenstats";

		// Token: 0x040008E3 RID: 2275
		public const string BsInstallStatsUrl = "stats/bsinstallstats";

		// Token: 0x040008E4 RID: 2276
		public const string MiscellaneousStatsUrl = "/stats/miscellaneousstats";

		// Token: 0x040008E5 RID: 2277
		public const string KeyMappingUIStatsStatsUrl = "/stats/keymappinguistats";

		// Token: 0x040008E6 RID: 2278
		public const string UploadtobigqueryUrl = "bigquery/uploadtobigquery";

		// Token: 0x040008E7 RID: 2279
		public const string BtvFunnelStatsUrl = "stats/btvfunnelstats";

		// Token: 0x040008E8 RID: 2280
		public const string TroubleshooterStatsUrl = "stats/troubleshooterlogs";

		// Token: 0x040008E9 RID: 2281
		public const string GetCACodeUrl = "api/getcacode";

		// Token: 0x040008EA RID: 2282
		public const string GetCountryUrl = "api/getcountryforip";

		// Token: 0x040008EB RID: 2283
		public const string UploadDebugLogsUrl = "uploaddebuglogs";

		// Token: 0x040008EC RID: 2284
		public const string UploadDebugLogsApkInstallFailureUrl = "logs/appinstallfailurelog";

		// Token: 0x040008ED RID: 2285
		public const string UploadDebugLogsBootFailureUrl = "logs/bootfailurelog";

		// Token: 0x040008EE RID: 2286
		public const string UploadDebugLogsCrashUrl = "logs/crashlog";

		// Token: 0x040008EF RID: 2287
		public const string UserDataDir = "UserData";

		// Token: 0x040008F0 RID: 2288
		public const string UsersPath = "UsersPath";

		// Token: 0x040008F1 RID: 2289
		public const string UserProfile = "userprofile";

		// Token: 0x040008F2 RID: 2290
		public const string IdSeparator = "##";

		// Token: 0x040008F3 RID: 2291
		public const string UserDefinedDir = "UserDefinedDir";

		// Token: 0x040008F4 RID: 2292
		public const string StoreAppsDir = "App Stores";

		// Token: 0x040008F5 RID: 2293
		public const string IconsDir = "Icons";

		// Token: 0x040008F6 RID: 2294
		public const string CloudHost2 = "https://23.23.194.123";

		// Token: 0x040008F7 RID: 2295
		public const string CloudHost = "https://cloud.bluestacks.com";

		// Token: 0x040008F8 RID: 2296
		public const string LibraryName = "Apps";

		// Token: 0x040008F9 RID: 2297
		public const string BstPrefix = "Bst-";

		// Token: 0x040008FA RID: 2298
		public const string GameManagerBannerImageDir = "sendappdisplayed";

		// Token: 0x040008FB RID: 2299
		public const string SharedFolderName = "BstSharedFolder";

		// Token: 0x040008FC RID: 2300
		public const string SharedFolder = "SharedFolder";

		// Token: 0x040008FD RID: 2301
		public const string Library = "Library";

		// Token: 0x040008FE RID: 2302
		public const string InputMapperFolderName = "InputMapper";

		// Token: 0x040008FF RID: 2303
		public const string CaCodeBackUpFileName = "Bst_CaCode_Backup";

		// Token: 0x04000900 RID: 2304
		public const string PCodeBackUpFileName = "Bst_PCode_Backup";

		// Token: 0x04000901 RID: 2305
		public const string CaSelectorBackUpFileName = "Bst_CaSelector_Backup";

		// Token: 0x04000902 RID: 2306
		public const string UserInfoBackupFileName = "Bst_UserInfo_Backup";

		// Token: 0x04000903 RID: 2307
		public const string BlueStacksPackagePrefix = "com.bluestacks";

		// Token: 0x04000904 RID: 2308
		public const string LatinImeId = "com.android.inputmethod.latin/.LatinIME";

		// Token: 0x04000905 RID: 2309
		public const string FrontendPortBootParam = "WINDOWSFRONTEND";

		// Token: 0x04000906 RID: 2310
		public const string AgentPortBootParam = "WINDOWSAGENT";

		// Token: 0x04000907 RID: 2311
		public const string VMXBitIsOn = "Cannot run guest while VMX is in use";

		// Token: 0x04000908 RID: 2312
		public const string InvalidOpCode = "invalid_op";

		// Token: 0x04000909 RID: 2313
		public const string KernelPanic = "Kernel panic";

		// Token: 0x0400090A RID: 2314
		public const string Ext4Error = ".*EXT4-fs error \\(device sd[a-b]1\\): (mb_free_blocks|ext4_mb_generate_buddy|ext4_lookup|.*deleted inode referenced):";

		// Token: 0x0400090B RID: 2315
		public const string PgaCtlInitFailedString = "BlueStacks.Frontend.Interop.Opengl.GetPgaServerInitStatus()";

		// Token: 0x0400090C RID: 2316
		public const string AppCrashInfoFile = "App_C_Info.txt";

		// Token: 0x0400090D RID: 2317
		public const string LogDirName = "Logs";

		// Token: 0x0400090E RID: 2318
		public const string AppNotInstalledString = "package not installed";

		// Token: 0x0400090F RID: 2319
		public const string NetEaseReportProblemUrl = "http://gh.163.com/m";

		// Token: 0x04000910 RID: 2320
		public const string NetEaseOpenBrowserString = "问题咨询";

		// Token: 0x04000911 RID: 2321
		public const string OEMNameBluestacks = "bluestacks";

		// Token: 0x04000912 RID: 2322
		public const string InstallDirKeyName = "InstallDir";

		// Token: 0x04000913 RID: 2323
		public const string StyleThemeStatsTag = "StyleAndThemeData";

		// Token: 0x04000914 RID: 2324
		public const string ConfigParam = "32";

		// Token: 0x04000915 RID: 2325
		public const string OemPrimaryInfo = "e";

		// Token: 0x04000916 RID: 2326
		public const string WorldWideToggleDisabledAppListUrl = "http://cdn3.bluestacks.com/public/appsettings/ToggleDisableAppList.cfg";

		// Token: 0x04000917 RID: 2327
		public const string TombStoneFilePrefix = "tombstone";

		// Token: 0x04000918 RID: 2328
		public const string GuidDebugStats = "guid_debug_stats";

		// Token: 0x04000919 RID: 2329
		public const string MultiInstanceStatsUrl = "stats/multiinstancestats";

		// Token: 0x0400091A RID: 2330
		public const string VmManagerExe = "HD-VmManager.exe";

		// Token: 0x0400091B RID: 2331
		public const string BluestacksServiceString = "BlueStacks Service";

		// Token: 0x0400091C RID: 2332
		public const string ReportProblemWindowTitle = "BlueStacks Report Problem";

		// Token: 0x0400091D RID: 2333
		public const string XapkHandlerBaseKeyName = "BlueStacks.Xapk";

		// Token: 0x0400091E RID: 2334
		public const int AgentServerStartingPort = 2861;

		// Token: 0x0400091F RID: 2335
		public const int HTTPServerPortRangeAgent = 10;

		// Token: 0x04000920 RID: 2336
		public const int ClientServerStartingPort = 2871;

		// Token: 0x04000921 RID: 2337
		public const int HTTPServerPortRangeClient = 10;

		// Token: 0x04000922 RID: 2338
		public const int PlayerServerStartingPort = 2881;

		// Token: 0x04000923 RID: 2339
		public const int VmMonitorServerStartingPort = 2921;

		// Token: 0x04000924 RID: 2340
		public const int HTTPServerVmPortRange = 40;

		// Token: 0x04000925 RID: 2341
		public const int DefaultBlueStacksSize = 2047;

		// Token: 0x04000926 RID: 2342
		public const string ChannelsProdTwitchServerUrl = "https://cloud.bluestacks.com/btv/GetTwitchServers";

		// Token: 0x04000927 RID: 2343
		public const string VideoTutorialUrl = "videoTutorial";

		// Token: 0x04000928 RID: 2344
		public const string ComExceptionErrorString = "com exception";

		// Token: 0x04000929 RID: 2345
		public const string BootFailedTimeoutString = "boot timeout exception";

		// Token: 0x0400092A RID: 2346
		public const long MinimumRAMRequiredForInstallationInGB = 1L;

		// Token: 0x0400092B RID: 2347
		public const long MinimumSpaceRequiredFreshInstallationInGB = 5L;

		// Token: 0x0400092C RID: 2348
		public const long MinimumSpaceRequiredFreshInstallationInInstallDirMB = 500L;

		// Token: 0x0400092D RID: 2349
		public const long MinimumSpaceRequiredFreshInstallationInMB = 5120L;

		// Token: 0x0400092E RID: 2350
		public const string UninstallerFileName = "BlueStacksUninstaller.exe";

		// Token: 0x0400092F RID: 2351
		public const string ArchInstallerFile64 = "64bit";

		// Token: 0x04000930 RID: 2352
		public const string TestRollbackRegistryKeyName = "TestRollback";

		// Token: 0x04000931 RID: 2353
		public const string TestRollbackFailRegistryKeyName = "TestRollbackFail";

		// Token: 0x04000932 RID: 2354
		public const string UnifiedInstallStats = "/bs3/stats/unified_install_stats";

		// Token: 0x04000933 RID: 2355
		public const string OEMConfigFileName = "Oem.cfg";

		// Token: 0x04000934 RID: 2356
		public const string RunAppBinaryName = "HD-RunApp.exe";

		// Token: 0x04000935 RID: 2357
		public const string BlueStacksBinaryName = "BlueStacks.exe";

		// Token: 0x04000936 RID: 2358
		public const string BlueStacksSetupFolderName = "BlueStacksSetup";

		// Token: 0x04000937 RID: 2359
		public const string GlModeString = "GlMode";

		// Token: 0x04000938 RID: 2360
		public const string MinimumClientVersionForUpgrade = "3.52.66.1905";

		// Token: 0x04000939 RID: 2361
		public const string MinimumEngineVersionForUpgrade = "2.52.66.8704";

		// Token: 0x0400093A RID: 2362
		public const string DiskCompactionToolMinSupportVersion = "4.60.00.0000";

		// Token: 0x0400093B RID: 2363
		public const string FirstIMapBuildVersion = "4.30.33.1590";

		// Token: 0x0400093C RID: 2364
		public const string FirstUnifiedInstallerBuildVersion = "4.20.21";

		// Token: 0x0400093D RID: 2365
		public const string CommonInstallUtilsZipFileName = "CommonInstallUtils.zip";

		// Token: 0x0400093E RID: 2366
		public const string RollbackCompletedStatString = "ROLLBACK_COMPLETED";

		// Token: 0x0400093F RID: 2367
		public const string HandleBinaryName = "HD-Handle.exe";

		// Token: 0x04000940 RID: 2368
		public const string HandleHivePath = "Software\\Sysinternals\\Handle";

		// Token: 0x04000941 RID: 2369
		public const string HandleEULAKeyName = "EulaAccepted";

		// Token: 0x04000942 RID: 2370
		public const string BootStrapperFileName = "Bootstrapper.exe";

		// Token: 0x04000943 RID: 2371
		public const string TakeBackupURL = "Backup_and_Restore";

		// Token: 0x04000944 RID: 2372
		public const string CloudImageTranslateUrl = "/translate/postimage";

		// Token: 0x04000945 RID: 2373
		public const string RemoteAccessRequestString = "May I please have remote access?";

		// Token: 0x04000946 RID: 2374
		public const string UninstallRegistryFileName = "BSTUninstall.reg";

		// Token: 0x04000947 RID: 2375
		public const string BuildVersionForUpgradeFromParserVersion13To14 = "4.140.00.0000";

		// Token: 0x04000948 RID: 2376
		public const string AnnouncementActionPopupSimple = "simple_popup";

		// Token: 0x04000949 RID: 2377
		public const string AnnouncementActionPopupRich = "rich_popup";

		// Token: 0x0400094A RID: 2378
		public const string AnnouncementActionPopupCenter = "center_popup";

		// Token: 0x0400094B RID: 2379
		public const string AnnouncementActionDownloadExecute = "download_execute";

		// Token: 0x0400094C RID: 2380
		public const string AnnouncementActionSilentLogCollect = "silent_logcollect";

		// Token: 0x0400094D RID: 2381
		public const string AnnouncementActionSilentExecute = "silent_execute";

		// Token: 0x0400094E RID: 2382
		public const string AnnouncementActionSelfUpdate = "self_update";

		// Token: 0x0400094F RID: 2383
		public const string AnnouncementActionWebURLGM = "web_url_gm";

		// Token: 0x04000950 RID: 2384
		public const string AnnouncementActionWebURL = "web_url";

		// Token: 0x04000951 RID: 2385
		public const string AnnouncementActionStartAndroidApp = "start_android_app";

		// Token: 0x04000952 RID: 2386
		public const string AnnouncementActionSilentInstall = "silent_install";

		// Token: 0x04000953 RID: 2387
		public const string AnnouncementActionDisablePermanently = "disable_permanently";

		// Token: 0x04000954 RID: 2388
		public const string CloudStuckAtBoot = "https://cloud.bluestacks.com/bs3/page/stuck_at_boot";

		// Token: 0x04000955 RID: 2389
		public const string CloudEnhancePerformance = "https://cloud.bluestacks.com/bs3/page/enhance_performance";

		// Token: 0x04000956 RID: 2390
		public const string CloudWhyGoogle = "https://cloud.bluestacks.com/bs3/page/why_google";

		// Token: 0x04000957 RID: 2391
		public const string CloudTroubleSigningIn = "https://cloud.bluestacks.com/bs3/page/trouble_signing";

		// Token: 0x04000958 RID: 2392
		public const string ExitPopupTagBoot = "exit_popup_boot";

		// Token: 0x04000959 RID: 2393
		public const string ExitPopupTagOTS = "exit_popup_ots";

		// Token: 0x0400095A RID: 2394
		public const string ExitPopupEventShown = "popup_shown";

		// Token: 0x0400095B RID: 2395
		public const string ExitPopupEventClosedButton = "popup_closed";

		// Token: 0x0400095C RID: 2396
		public const string ExitPopupEventClosedCross = "click_action_close";

		// Token: 0x0400095D RID: 2397
		public const string ExitPopupEventClosedContinue = "click_action_continue_bluestacks";

		// Token: 0x0400095E RID: 2398
		public const string ExitPopupEventAutoHidden = "popup_auto_hidden";

		// Token: 0x0400095F RID: 2399
		public const string GL_MODE = "GlMode";

		// Token: 0x04000960 RID: 2400
		public const string BootPromotionImageName = "BootPromo";

		// Token: 0x04000961 RID: 2401
		public const string BackgroundPromotionImageName = "BackPromo";

		// Token: 0x04000962 RID: 2402
		public const string AppSuggestionImageName = "AppSuggestion";

		// Token: 0x04000963 RID: 2403
		public const string AppSuggestionRemovedFileName = "app_suggestion_removed";

		// Token: 0x04000964 RID: 2404
		public const string ClientPromoDir = "Promo";

		// Token: 0x04000965 RID: 2405
		public const string BGPDataDirFolderName = "Engine";

		// Token: 0x04000966 RID: 2406
		public const string EngineActivityUri = "engine_activity";

		// Token: 0x04000967 RID: 2407
		public const string EmulatorActivityUri = "emulator_activity";

		// Token: 0x04000968 RID: 2408
		public const string AppInstallUri = "app_install";

		// Token: 0x04000969 RID: 2409
		public const string DeviceProfileListUrl = "get_device_profile_list";

		// Token: 0x0400096A RID: 2410
		public const string AppActivityUri = "app_activity";

		// Token: 0x0400096B RID: 2411
		public const string HelpArticles = "help_articles";

		// Token: 0x0400096C RID: 2412
		public const string CloudWatcherFolderName = "Helper";

		// Token: 0x0400096D RID: 2413
		public const string CloudWatcherBinaryName = "BlueStacksHelper.exe";

		// Token: 0x0400096E RID: 2414
		public const string CloudWatcherTaskName = "BlueStacksHelper";

		// Token: 0x0400096F RID: 2415
		public const string CloudWatcherIdleTaskName = "BlueStacksHelperTask";

		// Token: 0x04000970 RID: 2416
		public const string DirectX = "DirectX";

		// Token: 0x04000971 RID: 2417
		public const string OpenGL = "OpenGL";

		// Token: 0x04000972 RID: 2418
		public const string AdvancedGraphics = "Advanced Graphics";

		// Token: 0x04000973 RID: 2419
		public const string Legacy = "Legacy";

		// Token: 0x04000974 RID: 2420
		public const string LogCollectorZipFileName = "BlueStacks-Support.7z";

		// Token: 0x04000975 RID: 2421
		public const string BstClient = "BstClient";

		// Token: 0x04000976 RID: 2422
		public const string OperationSynchronization = "operation_synchronization";

		// Token: 0x04000977 RID: 2423
		public const string SetIframeUrl = "setIframeUrl";

		// Token: 0x04000978 RID: 2424
		public const string OnBrowserVisibilityChange = "onBrowserVisibilityChange";

		// Token: 0x04000979 RID: 2425
		public const string CloudAnnouncementTimeFormat = "dd/MM/yyyy HH:mm:ss";

		// Token: 0x0400097A RID: 2426
		public const string GadgetDir = "Gadget";

		// Token: 0x0400097B RID: 2427
		public const string MachineID = "MachineID";

		// Token: 0x0400097C RID: 2428
		public const string VersionMachineID = "VersionMachineId_4.140.12.1002";

		// Token: 0x0400097D RID: 2429
		public const string UserScripts = "UserScripts";

		// Token: 0x0400097E RID: 2430
		public const string PcodeString = "pcode";

		// Token: 0x0400097F RID: 2431
		public const string ROOT_VDI_UUID = "fca296ce-8268-4ed7-a57f-d32ec11ab304";

		// Token: 0x04000980 RID: 2432
		public const string LocaleFileNameFormat = "i18n.{0}.txt";

		// Token: 0x04000981 RID: 2433
		public const string MicroInstallerWindowTitle = "BlueStacks Installer";

		// Token: 0x04000982 RID: 2434
		public const string Bit64 = "x64 (64-bit)";

		// Token: 0x04000983 RID: 2435
		public const string Bit32 = "x86 (32-bit)";

		// Token: 0x04000984 RID: 2436
		public const int MaxRequiredAvailablePhysicalMemory = 2148;

		// Token: 0x04000985 RID: 2437
		public const string MediaFilesPathSetStatsTag = "MediaFilesPathSet";

		// Token: 0x04000986 RID: 2438
		public const string MediaFileSaveSuccess = "MediaFileSaveSuccess";

		// Token: 0x04000987 RID: 2439
		public const string VideoRecording = "VideoRecording";

		// Token: 0x04000988 RID: 2440
		public const string RestoreDefaultKeymappingStatsTag = "RestoreDefaultKeymappingClicked";

		// Token: 0x04000989 RID: 2441
		public const string ImportKeymappingStatsTag = "ImportKeymappingClicked";

		// Token: 0x0400098A RID: 2442
		public const string ExportKeymappingStatsTag = "ExportKeymappingClicked";

		// Token: 0x0400098B RID: 2443
		public const string ForceGPUBinaryName = "HD-ForceGPU.exe";

		// Token: 0x0400098C RID: 2444
		public const int ForceDedicatedGPUDefaultValue = 1;

		// Token: 0x0400098D RID: 2445
		public const string DMMEnableVtUrl = "http://help.dmm.com/-/detail/=/qid=45997/";

		// Token: 0x0400098E RID: 2446
		public const string ObsBinaryName = "HD-OBS.exe";

		// Token: 0x0400098F RID: 2447
		public const string NCSoftSharedMemoryName = "ngpmmf";

		// Token: 0x04000990 RID: 2448
		public const string SidebarElementsDefaultFile = "sidebar_config.json";

		// Token: 0x04000991 RID: 2449
		public const string SidebarElementsFileName = "SidebarConfig_{0}.json";

		// Token: 0x04000992 RID: 2450
		public const string AnotherInstanceRunningPromptText1ForDMM = "同時に起動できないプログラムが既に動いています。";

		// Token: 0x04000993 RID: 2451
		public const string AnotherInstanceRunningPromptText2ForDMM = "既に動いているプログラムを閉じて続行しますか？";

		// Token: 0x04000994 RID: 2452
		public const string GlTextureFolder = "UCT";

		// Token: 0x04000995 RID: 2453
		public const string ServiceInstallerBinaryName = "HD-ServiceInstaller.exe";

		// Token: 0x04000996 RID: 2454
		public const string MacroRecorder = "MacroOperations";

		// Token: 0x04000997 RID: 2455
		public const string GLCheckBinaryName = "HD-GLCheck.exe";

		// Token: 0x04000998 RID: 2456
		public const string BTVFolderName = "BTV";

		// Token: 0x04000999 RID: 2457
		public const string KeyboardShortcuts = "KeyboardShortcuts";

		// Token: 0x0400099A RID: 2458
		public const string ComRegistrationBinaryName = "HD-ComRegistrar.exe";

		// Token: 0x0400099B RID: 2459
		public const string CurrentParserVersion = "14";

		// Token: 0x0400099C RID: 2460
		public const string InternetConnectivityCheckUrl = "http://connectivitycheck.gstatic.com/generate_204";

		// Token: 0x0400099D RID: 2461
		public const string DecreaseVolumeImageName = "decrease";

		// Token: 0x0400099E RID: 2462
		public const string DecreaseVolumeDisableImageName = "decrease_disable";

		// Token: 0x0400099F RID: 2463
		public const string IncreaseVolumeImageName = "increase";

		// Token: 0x040009A0 RID: 2464
		public const string IncreseVolumeDisableImageName = "increase_disable";

		// Token: 0x040009A1 RID: 2465
		public const string MuteVolumeImageName = "volume_switch_off";

		// Token: 0x040009A2 RID: 2466
		public const string UnmuteVolumeImageName = "volume_switch_on";

		// Token: 0x040009A3 RID: 2467
		public const string Custom = "Custom";

		// Token: 0x040009A4 RID: 2468
		public static string ProductDisplayName = "云客户端 ン";

		// Token: 0x040009A5 RID: 2469
		public static string TitleBarIconImageName = "ProductLogo";

		// Token: 0x040009A6 RID: 2470
		public static string ProductTopBarDisplayName = Strings.ProductDisplayName;

		// Token: 0x040009A7 RID: 2471
		public static string UninstallerTitleName = "云客户端 ン Uninstaller";

		// Token: 0x040009A8 RID: 2472
		public static string UninstallCancelBtnColor = "White";

		// Token: 0x040009A9 RID: 2473
		public static string MaterialDesignPrimaryBtnStyle = "MaterialDesignButton";

		// Token: 0x040009AA RID: 2474
		public const string ProductMajorVersion = " 4";

		// Token: 0x02000185 RID: 389
		public class VersionConstants
		{
			// Token: 0x040009AB RID: 2475
			public const string SmartControlsCOD = "4.140.10.1000";
		}
	}
}
