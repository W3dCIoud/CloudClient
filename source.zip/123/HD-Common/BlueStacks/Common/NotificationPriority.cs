﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000D4 RID: 212
	public enum NotificationPriority
	{
		// Token: 0x0400052F RID: 1327
		Important,
		// Token: 0x04000530 RID: 1328
		Normal
	}
}
