﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;

namespace BlueStacks.Common
{
	// Token: 0x020001A4 RID: 420
	public class ShortcutHelper
	{
		// Token: 0x06000CDB RID: 3291
		[DllImport("shell32.dll")]
		private static extern bool SHGetSpecialFolderPath(IntPtr hwndOwner, [Out] StringBuilder lpszPath, int nFolder, bool fCreate);

		// Token: 0x17000302 RID: 770
		// (get) Token: 0x06000CDC RID: 3292 RVA: 0x000373B4 File Offset: 0x000355B4
		public static string CommonStartMenuPath
		{
			get
			{
				if (string.IsNullOrEmpty(ShortcutHelper.sCommonStartMenuPath))
				{
					StringBuilder stringBuilder = new StringBuilder(260);
					ShortcutHelper.SHGetSpecialFolderPath(IntPtr.Zero, stringBuilder, 22, false);
					ShortcutHelper.sCommonStartMenuPath = Path.Combine(stringBuilder.ToString(), "Programs");
				}
				return ShortcutHelper.sCommonStartMenuPath;
			}
		}

		// Token: 0x17000303 RID: 771
		// (get) Token: 0x06000CDD RID: 3293 RVA: 0x00037404 File Offset: 0x00035604
		public static string CommonDesktopPath
		{
			get
			{
				if (string.IsNullOrEmpty(ShortcutHelper.sCommonDesktopPath))
				{
					StringBuilder stringBuilder = new StringBuilder(260);
					ShortcutHelper.SHGetSpecialFolderPath(IntPtr.Zero, stringBuilder, 25, false);
					ShortcutHelper.sCommonDesktopPath = stringBuilder.ToString();
				}
				return ShortcutHelper.sCommonDesktopPath;
			}
		}

		// Token: 0x06000CDE RID: 3294 RVA: 0x0000B6E3 File Offset: 0x000098E3
		private static void DeleteFileIfExists(string filePath)
		{
			filePath = ShortcutHelper.FixFileName(filePath);
			if (File.Exists(filePath))
			{
				Logger.Info("Deleting: " + filePath);
				File.Delete(filePath);
			}
		}

		// Token: 0x06000CDF RID: 3295 RVA: 0x00037448 File Offset: 0x00035648
		private static string FixFileName(string fileName)
		{
			string text = ".lnk";
			string result = fileName;
			if (!fileName.EndsWith(text, StringComparison.InvariantCultureIgnoreCase))
			{
				result = fileName + text;
			}
			return result;
		}

		// Token: 0x06000CE0 RID: 3296 RVA: 0x0000B70B File Offset: 0x0000990B
		public static void DeleteDesktopShortcut(string shortcutName)
		{
			ShortcutHelper.DeleteFileIfExists(Path.Combine(ShortcutHelper.sDesktopPath, shortcutName));
		}

		// Token: 0x06000CE1 RID: 3297 RVA: 0x0000B71D File Offset: 0x0000991D
		public static void DeleteStartMenuShortcut(string shortcutName)
		{
			ShortcutHelper.DeleteFileIfExists(Path.Combine(ShortcutHelper.CommonStartMenuPath, shortcutName));
		}

		// Token: 0x06000CE2 RID: 3298 RVA: 0x0000B72F File Offset: 0x0000992F
		public static void DeleteCommonDesktopShortcut(string shortcutName)
		{
			ShortcutHelper.DeleteFileIfExists(Path.Combine(ShortcutHelper.CommonDesktopPath, shortcutName));
		}

		// Token: 0x06000CE3 RID: 3299 RVA: 0x0000B71D File Offset: 0x0000991D
		public static void DeleteCommonStartMenuShortcut(string shortcutName)
		{
			ShortcutHelper.DeleteFileIfExists(Path.Combine(ShortcutHelper.CommonStartMenuPath, shortcutName));
		}

		// Token: 0x06000CE4 RID: 3300 RVA: 0x0000B741 File Offset: 0x00009941
		public static void CreateCommonDesktopShortcut(string shortcutName, string shortcutIconPath, string targetApplication, string paramsString, string description)
		{
			ShortcutHelper.CreateShortcut(Path.Combine(ShortcutHelper.CommonDesktopPath, shortcutName), shortcutIconPath, targetApplication, paramsString, description);
		}

		// Token: 0x06000CE5 RID: 3301 RVA: 0x0000B758 File Offset: 0x00009958
		public static void CreateCommonStartMenuShortcut(string shortcutName, string shortcutIconPath, string targetApplication, string paramsString, string description)
		{
			ShortcutHelper.CreateShortcut(Path.Combine(ShortcutHelper.CommonStartMenuPath, shortcutName), shortcutIconPath, targetApplication, paramsString, description);
		}

		// Token: 0x06000CE6 RID: 3302 RVA: 0x0000B76F File Offset: 0x0000996F
		public static void CreateDesktopShortcut(string shortcutName, string shortcutIconPath, string targetApplication, string paramsString, string description)
		{
			ShortcutHelper.CreateShortcut(Path.Combine(ShortcutHelper.sDesktopPath, shortcutName), shortcutIconPath, targetApplication, paramsString, description);
		}

		// Token: 0x06000CE7 RID: 3303 RVA: 0x0000B758 File Offset: 0x00009958
		public static void CreateStartMenuShortcut(string shortcutName, string shortcutIconPath, string targetApplication, string paramsString, string description)
		{
			ShortcutHelper.CreateShortcut(Path.Combine(ShortcutHelper.CommonStartMenuPath, shortcutName), shortcutIconPath, targetApplication, paramsString, description);
		}

		// Token: 0x06000CE8 RID: 3304 RVA: 0x00037470 File Offset: 0x00035670
		public static void CreateShortcut(string shortcutPath, string shortcutIconPath, string targetApplication, string paramsString, string description)
		{
			try
			{
				shortcutPath = ShortcutHelper.FixFileName(shortcutPath);
				ShortcutHelper.DeleteFileIfExists(shortcutPath);
				ShortcutHelper.IShellLink shellLink = (ShortcutHelper.IShellLink)new ShortcutHelper.ShellLink();
				shellLink.SetDescription(description);
				shellLink.SetPath(targetApplication);
				shellLink.SetIconLocation(shortcutIconPath, 0);
				shellLink.SetArguments(paramsString);
				((IPersistFile)shellLink).Save(shortcutPath, false);
			}
			catch (Exception ex)
			{
				Logger.Warning("Could not create shortcut for " + shortcutPath + " . " + ex.ToString());
			}
		}

		// Token: 0x06000CE9 RID: 3305 RVA: 0x000374F0 File Offset: 0x000356F0
		public static string GetShortcutArguments(string shortcutPath)
		{
			try
			{
				ShortcutHelper.IShellLink shellLink = (ShortcutHelper.IShellLink)new ShortcutHelper.ShellLink();
				((IPersistFile)shellLink).Load(shortcutPath, 0);
				StringBuilder stringBuilder = new StringBuilder(260);
				ShortcutHelper.WIN32_FIND_DATAW win32_FIND_DATAW = default(ShortcutHelper.WIN32_FIND_DATAW);
				shellLink.GetPath(stringBuilder, stringBuilder.Capacity, out win32_FIND_DATAW, 0);
				return stringBuilder.ToString().Trim();
			}
			catch (Exception ex)
			{
				Logger.Warning("Could not get Shortcut target path. " + ex.ToString());
			}
			return string.Empty;
		}

		// Token: 0x06000CEA RID: 3306 RVA: 0x00037574 File Offset: 0x00035774
		public static string GetShortcutIconLocation(string shortcutPath)
		{
			try
			{
				ShortcutHelper.IShellLink shellLink = (ShortcutHelper.IShellLink)new ShortcutHelper.ShellLink();
				((IPersistFile)shellLink).Load(shortcutPath, 0);
				StringBuilder stringBuilder = new StringBuilder(260);
				int num;
				shellLink.GetIconLocation(stringBuilder, stringBuilder.Capacity, out num);
				return stringBuilder.ToString().Trim();
			}
			catch (Exception ex)
			{
				Logger.Warning("Could not get Shortcut target path. " + ex.ToString());
			}
			return string.Empty;
		}

		// Token: 0x06000CEB RID: 3307 RVA: 0x000375F0 File Offset: 0x000357F0
		public static void UpdateTargetPathAndIcon(string shortcutPath, string target, string iconPath)
		{
			try
			{
				ShortcutHelper.IShellLink shellLink = (ShortcutHelper.IShellLink)new ShortcutHelper.ShellLink();
				((IPersistFile)shellLink).Load(shortcutPath, 0);
				shellLink.SetPath(target);
				shellLink.SetIconLocation(iconPath, 0);
				((IPersistFile)shellLink).Save(shortcutPath, false);
			}
			catch (Exception ex)
			{
				Logger.Warning("Could not get Shortcut target path. " + ex.ToString());
			}
		}

		// Token: 0x04000B49 RID: 2889
		private const int CSIDL_COMMON_DESKTOPDIRECTORY = 25;

		// Token: 0x04000B4A RID: 2890
		private const int CSIDL_COMMON_STARTMENU = 22;

		// Token: 0x04000B4B RID: 2891
		public static string sDesktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

		// Token: 0x04000B4C RID: 2892
		private static string sCommonStartMenuPath = null;

		// Token: 0x04000B4D RID: 2893
		private static string sCommonDesktopPath = null;

		// Token: 0x020001A5 RID: 421
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
		internal struct WIN32_FIND_DATAW
		{
			// Token: 0x04000B4E RID: 2894
			public uint dwFileAttributes;

			// Token: 0x04000B4F RID: 2895
			public long ftCreationTime;

			// Token: 0x04000B50 RID: 2896
			public long ftLastAccessTime;

			// Token: 0x04000B51 RID: 2897
			public long ftLastWriteTime;

			// Token: 0x04000B52 RID: 2898
			public uint nFileSizeHigh;

			// Token: 0x04000B53 RID: 2899
			public uint nFileSizeLow;

			// Token: 0x04000B54 RID: 2900
			public uint dwReserved0;

			// Token: 0x04000B55 RID: 2901
			public uint dwReserved1;

			// Token: 0x04000B56 RID: 2902
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
			public string cFileName;

			// Token: 0x04000B57 RID: 2903
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 14)]
			public string cAlternateFileName;
		}

		// Token: 0x020001A6 RID: 422
		[Guid("00021401-0000-0000-C000-000000000046")]
		[ComImport]
		internal class ShellLink
		{
			// Token: 0x06000CEE RID: 3310
			[MethodImpl(MethodImplOptions.InternalCall)]
			public extern ShellLink();
		}

		// Token: 0x020001A7 RID: 423
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[Guid("000214F9-0000-0000-C000-000000000046")]
		[ComImport]
		internal interface IShellLink
		{
			// Token: 0x06000CEF RID: 3311
			void GetPath([MarshalAs(UnmanagedType.LPWStr)] [Out] StringBuilder pszFile, int cchMaxPath, out ShortcutHelper.WIN32_FIND_DATAW pfd, int fFlags);

			// Token: 0x06000CF0 RID: 3312
			void GetIDList(out IntPtr ppidl);

			// Token: 0x06000CF1 RID: 3313
			void SetIDList(IntPtr pidl);

			// Token: 0x06000CF2 RID: 3314
			void GetDescription([MarshalAs(UnmanagedType.LPWStr)] [Out] StringBuilder pszName, int cchMaxName);

			// Token: 0x06000CF3 RID: 3315
			void SetDescription([MarshalAs(UnmanagedType.LPWStr)] string pszName);

			// Token: 0x06000CF4 RID: 3316
			void GetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] [Out] StringBuilder pszDir, int cchMaxPath);

			// Token: 0x06000CF5 RID: 3317
			void SetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] string pszDir);

			// Token: 0x06000CF6 RID: 3318
			void GetArguments([MarshalAs(UnmanagedType.LPWStr)] [Out] StringBuilder pszArgs, int cchMaxPath);

			// Token: 0x06000CF7 RID: 3319
			void SetArguments([MarshalAs(UnmanagedType.LPWStr)] string pszArgs);

			// Token: 0x06000CF8 RID: 3320
			void GetHotkey(out short pwHotkey);

			// Token: 0x06000CF9 RID: 3321
			void SetHotkey(short wHotkey);

			// Token: 0x06000CFA RID: 3322
			void GetShowCmd(out int piShowCmd);

			// Token: 0x06000CFB RID: 3323
			void SetShowCmd(int iShowCmd);

			// Token: 0x06000CFC RID: 3324
			void GetIconLocation([MarshalAs(UnmanagedType.LPWStr)] [Out] StringBuilder pszIconPath, int cchIconPath, out int piIcon);

			// Token: 0x06000CFD RID: 3325
			void SetIconLocation([MarshalAs(UnmanagedType.LPWStr)] string pszIconPath, int iIcon);

			// Token: 0x06000CFE RID: 3326
			void SetRelativePath([MarshalAs(UnmanagedType.LPWStr)] string pszPathRel, int dwReserved);

			// Token: 0x06000CFF RID: 3327
			void Resolve(IntPtr hwnd, int fFlags);

			// Token: 0x06000D00 RID: 3328
			void SetPath([MarshalAs(UnmanagedType.LPWStr)] string pszFile);
		}
	}
}
