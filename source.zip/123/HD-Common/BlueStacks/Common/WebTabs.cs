﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000D2 RID: 210
	internal enum WebTabs
	{
		// Token: 0x04000525 RID: 1317
		MyApp,
		// Token: 0x04000526 RID: 1318
		AppCenter,
		// Token: 0x04000527 RID: 1319
		Gift,
		// Token: 0x04000528 RID: 1320
		Feedback,
		// Token: 0x04000529 RID: 1321
		Default
	}
}
