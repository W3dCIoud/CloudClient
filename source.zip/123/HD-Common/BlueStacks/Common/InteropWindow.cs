﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Forms;
using System.Windows.Interop;

namespace BlueStacks.Common
{
	// Token: 0x02000197 RID: 407
	public class InteropWindow
	{
		// Token: 0x06000C88 RID: 3208
		[DllImport("user32.dll")]
		public static extern uint MapVirtualKey(uint uCode, uint uMapType);

		// Token: 0x06000C89 RID: 3209
		[DllImport("user32.dll")]
		public static extern IntPtr GetKeyboardLayout(uint idThread);

		// Token: 0x06000C8A RID: 3210
		[DllImport("user32.dll")]
		public static extern int ToUnicodeEx(uint wVirtKey, uint wScanCode, byte[] lpKeyState, [MarshalAs(UnmanagedType.LPWStr)] [Out] StringBuilder pwszBuff, int cchBuff, uint wFlags, IntPtr dwhkl);

		// Token: 0x06000C8B RID: 3211 RVA: 0x0000B506 File Offset: 0x00009706
		public static IntPtr GetHwnd(Popup popup)
		{
			return ((HwndSource)PresentationSource.FromVisual(popup.Child)).Handle;
		}

		// Token: 0x06000C8C RID: 3212
		[DllImport("user32.dll")]
		public static extern IntPtr SetFocus(IntPtr hWnd);

		// Token: 0x06000C8D RID: 3213
		[DllImport("imm32.dll")]
		public static extern bool ImmSetOpenStatus(IntPtr hIMC, bool open);

		// Token: 0x06000C8E RID: 3214
		[DllImport("Imm32.dll", CharSet = CharSet.Auto)]
		public static extern IntPtr ImmGetContext(IntPtr hWnd);

		// Token: 0x06000C8F RID: 3215
		[DllImport("Imm32.dll")]
		public static extern bool ImmReleaseContext(IntPtr hWnd, IntPtr hIMC);

		// Token: 0x06000C90 RID: 3216
		[DllImport("Imm32.dll", CharSet = CharSet.Unicode)]
		private static extern int ImmGetCompositionStringW(IntPtr hIMC, int dwIndex, byte[] lpBuf, int dwBufLen);

		// Token: 0x06000C91 RID: 3217
		[DllImport("imm32.dll")]
		public static extern bool ImmSetCompositionWindow(IntPtr hIMC, out InteropWindow.COMPOSITIONFORM lpptPos);

		// Token: 0x06000C92 RID: 3218
		[DllImport("user32.dll")]
		public static extern int GetSystemMetrics(int which);

		// Token: 0x06000C93 RID: 3219
		[DllImport("user32.dll")]
		public static extern bool SetWindowPos(IntPtr hwnd, IntPtr hwndInsertAfter, int x, int y, int w, int h, uint flags);

		// Token: 0x06000C94 RID: 3220
		[DllImport("user32.dll", SetLastError = true)]
		public static extern bool AdjustWindowRect(out InteropWindow.RECT lpRect, int dwStyle, bool bMenu);

		// Token: 0x06000C95 RID: 3221
		[DllImport("user32.dll")]
		public static extern bool MoveWindow(IntPtr hWnd, int X, int Y, int nWidth, int nHeight, bool bRepaint);

		// Token: 0x06000C96 RID: 3222
		[DllImport("gdi32.dll")]
		private static extern IntPtr CreateDC(string driver, string name, string output, IntPtr mode);

		// Token: 0x06000C97 RID: 3223
		[DllImport("gdi32.dll")]
		private static extern bool DeleteDC(IntPtr hdc);

		// Token: 0x06000C98 RID: 3224
		[DllImport("gdi32.dll")]
		private static extern int GetDeviceCaps(IntPtr hdc, int index);

		// Token: 0x170002FC RID: 764
		// (get) Token: 0x06000C99 RID: 3225 RVA: 0x0000B51D File Offset: 0x0000971D
		public static int ScreenWidth
		{
			get
			{
				return InteropWindow.GetSystemMetrics(0);
			}
		}

		// Token: 0x170002FD RID: 765
		// (get) Token: 0x06000C9A RID: 3226 RVA: 0x0000B525 File Offset: 0x00009725
		public static int ScreenHeight
		{
			get
			{
				return InteropWindow.GetSystemMetrics(1);
			}
		}

		// Token: 0x06000C9B RID: 3227
		[DllImport("user32.dll")]
		public static extern bool HideCaret(IntPtr hWnd);

		// Token: 0x06000C9C RID: 3228
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, int wMsg, bool wParam, int lParam);

		// Token: 0x06000C9D RID: 3229
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

		// Token: 0x06000C9E RID: 3230
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, ref InteropWindow.COPYGAMEPADDATASTRUCT cds);

		// Token: 0x06000C9F RID: 3231
		[DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
		public static extern IntPtr FindWindow(string cls, string name);

		// Token: 0x06000CA0 RID: 3232
		[DllImport("user32.dll", SetLastError = true)]
		public static extern bool SetForegroundWindow(IntPtr handle);

		// Token: 0x06000CA1 RID: 3233
		[DllImport("user32.dll")]
		public static extern bool ShowWindow(IntPtr handle, int cmd);

		// Token: 0x06000CA2 RID: 3234
		[DllImport("user32.dll", ExactSpelling = true)]
		public static extern IntPtr GetAncestor(IntPtr hwnd, InteropWindow.GetAncestorFlags flags);

		// Token: 0x06000CA3 RID: 3235
		[DllImport("user32.dll")]
		public static extern IntPtr GetParent(IntPtr handle);

		// Token: 0x06000CA4 RID: 3236
		[DllImport("user32.dll", SetLastError = true)]
		public static extern IntPtr SetParent(IntPtr hWndChild, IntPtr hWndNewParent);

		// Token: 0x06000CA5 RID: 3237
		[DllImport("user32.dll")]
		public static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string lpszWindow);

		// Token: 0x06000CA6 RID: 3238
		[DllImport("kernel32.dll")]
		public static extern bool FreeConsole();

		// Token: 0x06000CA7 RID: 3239
		[DllImport("user32.dll")]
		[return: MarshalAs(UnmanagedType.Bool)]
		public static extern bool IsWindowVisible(IntPtr hWnd);

		// Token: 0x06000CA8 RID: 3240
		[DllImport("user32.dll")]
		[return: MarshalAs(UnmanagedType.Bool)]
		public static extern bool IsWindow(IntPtr hWnd);

		// Token: 0x06000CA9 RID: 3241
		[DllImport("user32.dll")]
		public static extern IntPtr GetForegroundWindow();

		// Token: 0x06000CAA RID: 3242
		[DllImport("user32.dll")]
		public static extern uint GetWindowThreadProcessId(IntPtr hWnd, ref uint ProcessId);

		// Token: 0x06000CAB RID: 3243
		[DllImport("kernel32.dll")]
		public static extern uint GetCurrentThreadId();

		// Token: 0x06000CAC RID: 3244
		[DllImport("user32.dll")]
		public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);

		// Token: 0x06000CAD RID: 3245
		[DllImport("user32.dll", SetLastError = true)]
		public static extern int GetWindowLong(IntPtr hWnd, int nIndex);

		// Token: 0x06000CAE RID: 3246
		[DllImport("user32.dll")]
		public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

		// Token: 0x06000CAF RID: 3247
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		public static extern int GetWindowTextLength(IntPtr hWnd);

		// Token: 0x06000CB0 RID: 3248
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

		// Token: 0x06000CB1 RID: 3249
		[DllImport("user32.dll")]
		public static extern bool GetWindowRect(IntPtr hwnd, ref InteropWindow.RECT rect);

		// Token: 0x06000CB2 RID: 3250
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		public static extern bool EnableWindow(IntPtr hwnd, bool enable);

		// Token: 0x06000CB3 RID: 3251
		[DllImport("User32.dll")]
		public static extern InteropWindow.DPI_AWARENESS_CONTEXT SetThreadDpiAwarenessContext(InteropWindow.DPI_AWARENESS_CONTEXT dpiContext);

		// Token: 0x06000CB4 RID: 3252 RVA: 0x0000B52D File Offset: 0x0000972D
		public static IntPtr MinimizeWindow(string name)
		{
			IntPtr intPtr = InteropWindow.FindWindow(null, name);
			if (intPtr == IntPtr.Zero)
			{
				throw new SystemException("Cannot find window '" + name + "'", new Win32Exception(Marshal.GetLastWin32Error()));
			}
			InteropWindow.ShowWindow(intPtr, 6);
			return intPtr;
		}

		// Token: 0x06000CB5 RID: 3253 RVA: 0x000354E0 File Offset: 0x000336E0
		public static IntPtr BringWindowToFront(string name, bool fullScreen, bool isRetoreMinimizedWindow = false)
		{
			IntPtr intPtr = InteropWindow.FindWindow(null, name);
			if (intPtr == IntPtr.Zero)
			{
				throw new SystemException("Cannot find window '" + name + "'", new Win32Exception(Marshal.GetLastWin32Error()));
			}
			if (!InteropWindow.SetForegroundWindow(intPtr))
			{
				throw new SystemException("Cannot set foreground window", new Win32Exception(Marshal.GetLastWin32Error()));
			}
			if (isRetoreMinimizedWindow)
			{
				InteropWindow.ShowWindow(intPtr, 9);
			}
			else
			{
				InteropWindow.ShowWindow(intPtr, 5);
			}
			return intPtr;
		}

		// Token: 0x06000CB6 RID: 3254 RVA: 0x00035558 File Offset: 0x00033758
		public static void RemoveWindowFromAltTabUI(IntPtr handle)
		{
			int windowLong = InteropWindow.GetWindowLong(handle, -20);
			InteropWindow.SetWindowLong(handle, -20, windowLong | 128);
		}

		// Token: 0x06000CB7 RID: 3255 RVA: 0x0000B56B File Offset: 0x0000976B
		public static IntPtr GetWindowHandle(string name)
		{
			IntPtr intPtr = InteropWindow.FindWindow(null, name);
			if (intPtr == IntPtr.Zero)
			{
				throw new SystemException("Cannot find window '" + name + "'", new Win32Exception(Marshal.GetLastWin32Error()));
			}
			return intPtr;
		}

		// Token: 0x06000CB8 RID: 3256 RVA: 0x00035580 File Offset: 0x00033780
		public static bool ForceSetForegroundWindow(IntPtr h)
		{
			if (h == IntPtr.Zero)
			{
				return false;
			}
			IntPtr foregroundWindow = InteropWindow.GetForegroundWindow();
			if (foregroundWindow == IntPtr.Zero)
			{
				return InteropWindow.SetForegroundWindow(h);
			}
			if (h == foregroundWindow)
			{
				return true;
			}
			uint num = 0U;
			uint windowThreadProcessId = InteropWindow.GetWindowThreadProcessId(foregroundWindow, ref num);
			uint currentThreadId = InteropWindow.GetCurrentThreadId();
			if (currentThreadId == windowThreadProcessId)
			{
				return InteropWindow.SetForegroundWindow(h);
			}
			if (windowThreadProcessId != 0U)
			{
				if (!InteropWindow.AttachThreadInput(currentThreadId, windowThreadProcessId, true))
				{
					return false;
				}
				if (!InteropWindow.SetForegroundWindow(h))
				{
					InteropWindow.AttachThreadInput(currentThreadId, windowThreadProcessId, false);
					return false;
				}
				InteropWindow.AttachThreadInput(currentThreadId, windowThreadProcessId, false);
			}
			return true;
		}

		// Token: 0x06000CB9 RID: 3257 RVA: 0x0003560C File Offset: 0x0003380C
		public static int GetScreenDpi()
		{
			IntPtr intPtr = InteropWindow.CreateDC("DISPLAY", null, null, IntPtr.Zero);
			if (intPtr == IntPtr.Zero)
			{
				return -1;
			}
			int num = InteropWindow.GetDeviceCaps(intPtr, 88);
			if (num == 0)
			{
				num = 96;
			}
			InteropWindow.DeleteDC(intPtr);
			return num;
		}

		// Token: 0x06000CBA RID: 3258 RVA: 0x0000B5A1 File Offset: 0x000097A1
		public static void SetFullScreen(IntPtr hwnd)
		{
			InteropWindow.SetFullScreen(hwnd, 0, 0, InteropWindow.ScreenWidth, InteropWindow.ScreenHeight);
		}

		// Token: 0x06000CBB RID: 3259 RVA: 0x0000B5B5 File Offset: 0x000097B5
		public static void SetFullScreen(IntPtr hwnd, int X, int Y, int cx, int cy)
		{
			if (!InteropWindow.SetWindowPos(hwnd, InteropWindow.HWND_TOP, X, Y, cx, cy, 64U))
			{
				throw new SystemException("Cannot call SetWindowPos()", new Win32Exception(Marshal.GetLastWin32Error()));
			}
		}

		// Token: 0x06000CBC RID: 3260 RVA: 0x00035654 File Offset: 0x00033854
		public static string CurrentCompStr(IntPtr handle)
		{
			int dwIndex = 8;
			IntPtr hIMC = InteropWindow.ImmGetContext(handle);
			string result;
			try
			{
				int num = InteropWindow.ImmGetCompositionStringW(hIMC, dwIndex, null, 0);
				if (num > 0)
				{
					byte[] array = new byte[num];
					InteropWindow.ImmGetCompositionStringW(hIMC, dwIndex, array, num);
					result = Encoding.Unicode.GetString(array);
				}
				else
				{
					result = string.Empty;
				}
			}
			finally
			{
				InteropWindow.ImmReleaseContext(handle, hIMC);
			}
			return result;
		}

		// Token: 0x06000CBD RID: 3261 RVA: 0x000356BC File Offset: 0x000338BC
		public static IntPtr GetWindowHandle(Window window)
		{
			HwndSource hwndSource = (HwndSource)PresentationSource.FromVisual(window);
			if (hwndSource != null)
			{
				return hwndSource.Handle;
			}
			return IntPtr.Zero;
		}

		// Token: 0x06000CBE RID: 3262 RVA: 0x0000B5E0 File Offset: 0x000097E0
		public static bool IsWindowTopMost(IntPtr hWnd)
		{
			return (InteropWindow.GetWindowLong(hWnd, -20) & 8) == 8;
		}

		// Token: 0x06000CBF RID: 3263 RVA: 0x0000B5EF File Offset: 0x000097EF
		public static Window GetTopmostOwnerWindow(Window window)
		{
			while (window.Owner != null)
			{
				window = window.Owner;
			}
			return window;
		}

		// Token: 0x06000CC0 RID: 3264 RVA: 0x000356E4 File Offset: 0x000338E4
		public static int GetAForegroundApplicationProcessId()
		{
			IntPtr foregroundWindow = InteropWindow.GetForegroundWindow();
			if (foregroundWindow == IntPtr.Zero)
			{
				return 0;
			}
			uint result = 0U;
			InteropWindow.GetWindowThreadProcessId(foregroundWindow, ref result);
			return (int)result;
		}

		// Token: 0x06000CC1 RID: 3265
		[DllImport("user32.dll")]
		private static extern long GetKeyboardLayoutName(StringBuilder pwszKLID);

		// Token: 0x06000CC2 RID: 3266 RVA: 0x0000B604 File Offset: 0x00009804
		private static string GetLayoutCode()
		{
			StringBuilder stringBuilder = new StringBuilder(9);
			InteropWindow.GetKeyboardLayoutName(stringBuilder);
			return stringBuilder.ToString();
		}

		// Token: 0x06000CC3 RID: 3267 RVA: 0x00035714 File Offset: 0x00033914
		public static string MapLayoutName(string code = null)
		{
			if (code == null)
			{
				code = InteropWindow.GetLayoutCode();
			}
			uint num = <PrivateImplementationDetails>.ComputeStringHash(code);
			if (num <= 2706750745U)
			{
				if (num <= 1667082820U)
				{
					if (num <= 712032952U)
					{
						if (num <= 231296871U)
						{
							if (num <= 99068648U)
							{
								if (num <= 15474743U)
								{
									if (num != 3522856U)
									{
										if (num == 15474743U)
										{
											if (code == "00010418")
											{
												return "Romanian (standard)";
											}
										}
									}
									else if (code == "00000C04")
									{
										return "Chinese (traditional, hong kong s.a.r.) - us keyboard";
									}
								}
								else if (num != 50162814U)
								{
									if (num != 65513410U)
									{
										if (num == 99068648U)
										{
											if (code == "00010437")
											{
												return "Georgian (qwerty)";
											}
										}
									}
									else if (code == "00010439")
									{
										return "Hindi traditional";
									}
								}
								else if (code == "00010480")
								{
									return "Uyghur";
								}
							}
							else if (num <= 110845946U)
							{
								if (num != 101545860U)
								{
									if (num == 110845946U)
									{
										if (code == "00050408")
										{
											return "Greek latin";
										}
									}
								}
								else if (code == "0000080C")
								{
									return "Belgian French";
								}
							}
							else if (num != 127623565U)
							{
								if (num != 135101098U)
								{
									if (num == 231296871U)
									{
										if (code == "00001809")
										{
											return "Irish";
										}
									}
								}
								else if (code == "0000080A")
								{
									return "Latin america";
								}
							}
							else if (code == "00050409")
							{
								return "United States - dvorak right hand";
							}
						}
						else if (num <= 503517168U)
						{
							if (num <= 389408093U)
							{
								if (num != 240518203U)
								{
									if (num == 389408093U)
									{
										if (code == "00000C0C")
										{
											return "Canada French (legacy)";
										}
									}
								}
								else if (code == "0001083B")
								{
									return "Finnish with sami";
								}
							}
							else if (num != 453037216U)
							{
								if (num != 471089250U)
								{
									if (num == 503517168U)
									{
										if (code == "00000843")
										{
											return "Uzbek cyrillic";
										}
									}
								}
								else if (code == "0002083B")
								{
									return "Sami extended finland-sweden";
								}
							}
							else if (code == "00000850")
							{
								return "Mongolian (mongolian script)";
							}
						}
						else if (num <= 631482070U)
						{
							if (num != 509862881U)
							{
								if (num == 631482070U)
								{
									if (code == "00004009")
									{
										return "United States - india";
									}
								}
							}
							else if (code == "0002041E")
							{
								return "Thai Kedmanee (non-shiftlock)";
							}
						}
						else if (num != 694269595U)
						{
							if (num != 694416690U)
							{
								if (num == 712032952U)
								{
									if (code == "00020445")
									{
										return "Bengali - inscript";
									}
								}
							}
							else if (code == "00020418")
							{
								return "Romanian (programmers)";
							}
						}
						else if (code == "00020422")
						{
							return "Ukrainian (enhanced)";
						}
					}
					else if (num <= 1465751392U)
					{
						if (num <= 1004864568U)
						{
							if (num <= 744602452U)
							{
								if (num != 744455357U)
								{
									if (num == 744602452U)
									{
										if (code == "00020427")
										{
											return "Lithuanian standard";
										}
									}
								}
								else if (code == "00020437")
								{
									return "Georgian (ergonomic)";
								}
							}
							else if (num != 803790914U)
							{
								if (num != 959994234U)
								{
									if (num == 1004864568U)
									{
										if (code == "00011009")
										{
											return "Canada Multilingual";
										}
									}
								}
								else if (code == "00000C1A")
								{
									return "Serbian (cyrillic)";
								}
							}
							else if (code == "0003041E")
							{
								return "Thai Pattachote (non-shiftlock)";
							}
						}
						else if (num <= 1163000852U)
						{
							if (num != 1117879927U)
							{
								if (num == 1163000852U)
								{
									if (code == "00001404")
									{
										return "Chinese (traditional, macao s.a.r.) - us keyboard";
									}
								}
							}
							else if (code == "00060408")
							{
								return "Greek polyonic";
							}
						}
						else if (num != 1335701245U)
						{
							if (num != 1432049059U)
							{
								if (num == 1465751392U)
								{
									if (code == "00000429")
									{
										return "Persian";
									}
								}
							}
							else if (code == "00000437")
							{
								return "Georgian";
							}
						}
						else if (code == "0000100C")
						{
							return "Swiss french";
						}
					}
					else if (num <= 1616749963U)
					{
						if (num <= 1482529011U)
						{
							if (num != 1482381916U)
							{
								if (num == 1482529011U)
								{
									if (code == "00000428")
									{
										return "Tajik";
									}
								}
							}
							else if (code == "00000432")
							{
								return "Setswana";
							}
						}
						else if (num != 1483703617U)
						{
							if (num != 1550625225U)
							{
								if (num == 1616749963U)
								{
									if (code == "00000420")
									{
										return "Urdu";
									}
								}
							}
							else if (code == "00000488")
							{
								return "Wolof";
							}
						}
						else if (code == "0000201A")
						{
							return "Bosnian (cyrillic)";
						}
					}
					else if (num <= 1650305201U)
					{
						if (num != 1633527582U)
						{
							if (num != 1650158106U)
							{
								if (num == 1650305201U)
								{
									if (code == "00000422")
									{
										return "Ukrainian";
									}
								}
							}
							else if (code == "00000438")
							{
								return "Faeroese";
							}
						}
						else if (code == "00000423")
						{
							return "Belarusian";
						}
					}
					else if (num != 1650452296U)
					{
						if (num != 1666935725U)
						{
							if (num == 1667082820U)
							{
								if (code == "00000425")
								{
									return "Estonian";
								}
							}
						}
						else if (code == "00000439")
						{
							return "Deanagari - inscript";
						}
					}
					else if (code == "00000454")
					{
						return "Lao";
					}
				}
				else if (num <= 1801156677U)
				{
					if (num <= 1717562772U)
					{
						if (num <= 1684154629U)
						{
							if (num <= 1668068558U)
							{
								if (num != 1667377010U)
								{
									if (num == 1668068558U)
									{
										if (code == "00000481")
										{
											return "Maroi";
										}
									}
								}
								else if (code == "00000449")
								{
									return "Tamil";
								}
							}
							else if (num != 1683713344U)
							{
								if (num != 1683860439U)
								{
									if (num == 1684154629U)
									{
										if (code == "00000448")
										{
											return "Oriya";
										}
									}
								}
								else if (code == "00000424")
								{
									return "Slovenian";
								}
							}
							else if (code == "0000043F")
							{
								return "Kazakh";
							}
						}
						else if (num <= 1700638058U)
						{
							if (num != 1684846177U)
							{
								if (num == 1700638058U)
								{
									if (code == "00000427")
									{
										return "Lithuanian ibm";
									}
								}
							}
							else if (code == "00000480")
							{
								return "Uyghur (legacy)";
							}
						}
						else if (num != 1700932248U)
						{
							if (num != 1717415677U)
							{
								if (num == 1717562772U)
								{
									if (code == "00000450")
									{
										return "Mongolian cyrillic";
									}
								}
							}
							else if (code == "00000426")
							{
								return "Latvian";
							}
						}
						else if (code == "00000447")
						{
							return "Gujarati";
						}
					}
					else if (num <= 1750823820U)
					{
						if (num <= 1734340391U)
						{
							if (num != 1717709867U)
							{
								if (num == 1734340391U)
								{
									if (code == "00000451")
									{
										return "Tibetan (prc)";
									}
								}
							}
							else if (code == "00000446")
							{
								return "Punjabi";
							}
						}
						else if (num != 1734487486U)
						{
							if (num != 1735179034U)
							{
								if (num == 1750823820U)
								{
									if (code == "0000043B")
									{
										return "Norwegian with sami";
									}
								}
							}
							else if (code == "00000485")
							{
								return "Yakut";
							}
						}
						else if (code == "00000445")
						{
							return "Bengali";
						}
					}
					else if (num <= 1751265105U)
					{
						if (num != 1751118010U)
						{
							if (num == 1751265105U)
							{
								if (code == "00000444")
								{
									return "Tatar";
								}
							}
						}
						else if (code == "00000452")
						{
							return "United Kingdom Extended";
						}
					}
					else if (num != 1767895629U)
					{
						if (num != 1784820343U)
						{
							if (num == 1801156677U)
							{
								if (code == "0000043A")
								{
									return "Maltese 47-key";
								}
							}
						}
						else if (code == "00000442")
						{
							return "Turkmen";
						}
					}
					else if (code == "00000453")
					{
						return "Khmer";
					}
				}
				else if (num <= 2472408532U)
				{
					if (num <= 2229575998U)
					{
						if (num <= 1973250767U)
						{
							if (num != 1818375581U)
							{
								if (num == 1973250767U)
								{
									if (code == "00001009")
									{
										return "Canada French";
									}
								}
							}
							else if (code == "00000440")
							{
								return "Kyrgyz cyrillic";
							}
						}
						else if (num != 2011172761U)
						{
							if (num != 2023583624U)
							{
								if (num == 2229575998U)
								{
									if (code == "00010426")
									{
										return "Latvian (qwerty)";
									}
								}
							}
							else if (code == "00001004")
							{
								return "Chinese (simplified, singapore) - us keyboard";
							}
						}
						else if (code == "00010445")
						{
							return "Bengali - inscript (legacy)";
						}
					}
					else if (num <= 2405298056U)
					{
						if (num != 2246353617U)
						{
							if (num == 2405298056U)
							{
								if (code == "0000042A")
								{
									return "Vietnamese";
								}
							}
						}
						else if (code == "00010427")
						{
							return "Lithuanian";
						}
					}
					else if (num != 2438853294U)
					{
						if (num != 2455630913U)
						{
							if (num == 2472408532U)
							{
								if (code == "0000042E")
								{
									return "Sorbian standard (legacy)";
								}
							}
						}
						else if (code == "0000042B")
						{
							return "Armenian eastern";
						}
					}
					else if (code == "0000042C")
					{
						return "Azeri Latin";
					}
				}
				else if (num <= 2598830711U)
				{
					if (num <= 2523324256U)
					{
						if (num != 2522741389U)
						{
							if (num == 2523324256U)
							{
								if (code == "00020401")
								{
									return "Arabic (102) Azerty";
								}
							}
						}
						else if (code == "0000042F")
						{
							return "Macedonian (fyrom)";
						}
					}
					else if (num != 2573657113U)
					{
						if (num != 2590434732U)
						{
							if (num == 2598830711U)
							{
								if (code == "0001043B")
								{
									return "Sami extended norway";
								}
							}
						}
						else if (code == "00020405")
						{
							return "Czech programmers";
						}
					}
					else if (code == "00020402")
					{
						return "Bulgarian (phonetic)";
					}
				}
				else if (num <= 2673195507U)
				{
					if (num != 2615608330U)
					{
						if (num != 2657545208U)
						{
							if (num == 2673195507U)
							{
								if (code == "0000041A")
								{
									return "Croatian";
								}
							}
						}
						else if (code == "00020409")
						{
							return "United States - international";
						}
					}
					else if (code == "0001043A")
					{
						return "Maltese 48-key";
					}
				}
				else if (num != 2674322827U)
				{
					if (num != 2689973126U)
					{
						if (num == 2706750745U)
						{
							if (code == "0000041C")
							{
								return "Albanian";
							}
						}
					}
					else if (code == "0000041B")
					{
						return "Slovak";
					}
				}
				else if (code == "00020408")
				{
					return "Greek (319)";
				}
			}
			else if (num <= 3546764528U)
			{
				if (num <= 3219517787U)
				{
					if (num <= 2953637922U)
					{
						if (num <= 2758216435U)
						{
							if (num <= 2740305983U)
							{
								if (num != 2723528364U)
								{
									if (num == 2740305983U)
									{
										if (code == "0000041E")
										{
											return "Thai Kedmanee";
										}
									}
								}
								else if (code == "0000041D")
								{
									return "Swedish";
								}
							}
							else if (num != 2741438816U)
							{
								if (num != 2757083602U)
								{
									if (num == 2758216435U)
									{
										if (code == "0000046D")
										{
											return "Bashkir";
										}
									}
								}
								else if (code == "0000041F")
								{
									return "Turkish Q";
								}
							}
							else if (code == "0000046E")
							{
								return "Luxembourgish";
							}
						}
						else if (num <= 2808549292U)
						{
							if (num != 2791771673U)
							{
								if (num == 2808549292U)
								{
									if (code == "0000046A")
									{
										return "Yoruba";
									}
								}
							}
							else if (code == "0000046F")
							{
								return "Greenlandic";
							}
						}
						else if (num != 2842104530U)
						{
							if (num != 2903452160U)
							{
								if (num == 2953637922U)
								{
									if (code == "00000809")
									{
										return "United Kingdom";
									}
								}
							}
							else if (code == "0000083B")
							{
								return "Swedish with sami";
							}
						}
						else if (code == "0000046C")
						{
							return "Sesotho sa Leboa";
						}
					}
					else if (num <= 3054156541U)
					{
						if (num <= 2987193160U)
						{
							if (num != 2970268446U)
							{
								if (num == 2987193160U)
								{
									if (code == "00000807")
									{
										return "Swiss german";
									}
								}
							}
							else if (code == "00000816")
							{
								return "Portuguese";
							}
						}
						else if (num != 3037526017U)
						{
							if (num != 3042527671U)
							{
								if (num == 3054156541U)
								{
									if (code == "00000813")
									{
										return "Belgian (period)";
									}
								}
							}
							else if (code == "0001080C")
							{
								return "Belgian (comma)";
							}
						}
						else if (code == "00000804")
						{
							return "Chinese (simplified) -us keyboard";
						}
					}
					else if (num <= 3093327530U)
					{
						if (num != 3076549911U)
						{
							if (num == 3093327530U)
							{
								if (code == "0000045B")
								{
									return "Sinhala";
								}
							}
						}
						else if (code == "0000045A")
						{
							return "Syriac";
						}
					}
					else if (num != 3102074454U)
					{
						if (num != 3202740168U)
						{
							if (num == 3219517787U)
							{
								if (code == "00030409")
								{
									return "United States - dvorak left hand";
								}
							}
						}
						else if (code == "00030408")
						{
							return "Greek (220) latin";
						}
					}
					else if (code == "00030402")
					{
						return "Bulgarian";
					}
				}
				else if (num <= 3472905468U)
				{
					if (num <= 3327669743U)
					{
						if (num <= 3260559267U)
						{
							if (num != 3243781648U)
							{
								if (num == 3260559267U)
								{
									if (code == "0000040B")
									{
										return "Finnish";
									}
								}
							}
							else if (code == "0000040C")
							{
								return "French";
							}
						}
						else if (num != 3277336886U)
						{
							if (num != 3286860185U)
							{
								if (num == 3327669743U)
								{
									if (code == "0000040F")
									{
										return "Icelandic";
									}
								}
							}
							else if (code == "0001040A")
							{
								return "Spanish variation";
							}
						}
						else if (code == "0000040A")
						{
							return "Spanish";
						}
					}
					else if (num <= 3353970661U)
					{
						if (num != 3344447362U)
						{
							if (num == 3353970661U)
							{
								if (code == "0001040E")
								{
									return "Hungarian 101 key";
								}
							}
						}
						else if (code == "0000040E")
						{
							return "Hungarian";
						}
					}
					else if (num != 3361224981U)
					{
						if (num != 3461743600U)
						{
							if (num == 3472905468U)
							{
								if (code == "0000085D")
								{
									return "Inuktitut - latin";
								}
							}
						}
						else if (code == "00000410")
						{
							return "Italian";
						}
					}
					else if (code == "0000040D")
					{
						return "Hebrew";
					}
				}
				else if (num <= 3528854076U)
				{
					if (num <= 3487750328U)
					{
						if (num != 3478521219U)
						{
							if (num == 3487750328U)
							{
								if (code == "0001045A")
								{
									return "Syriac phonetic";
								}
							}
						}
						else if (code == "00000411")
						{
							return "Japanese";
						}
					}
					else if (num != 3495298838U)
					{
						if (num != 3512076457U)
						{
							if (num == 3528854076U)
							{
								if (code == "00000414")
								{
									return "Norwegian";
								}
							}
						}
						else if (code == "00000413")
						{
							return "Dutch";
						}
					}
					else if (code == "00000412")
					{
						return "Korean";
					}
				}
				else if (num <= 3538083185U)
				{
					if (num != 3529001171U)
					{
						if (num != 3529839814U)
						{
							if (num == 3538083185U)
							{
								if (code == "0001045B")
								{
									return "Sinhala -Wij 9";
								}
							}
						}
						else if (code == "00000470")
						{
							return "Igbo";
						}
					}
					else if (code == "00000402")
					{
						return "Bulgarian(typewriter)";
					}
				}
				else if (num != 3545631695U)
				{
					if (num != 3545778790U)
					{
						if (num == 3546764528U)
						{
							if (code == "00000465")
							{
								return "Divehi phonetic";
							}
						}
					}
					else if (code == "00000401")
					{
						return "Arabic (101)";
					}
				}
				else if (code == "00000415")
				{
					return "Polish (programmers)";
				}
			}
			else if (num <= 3764873575U)
			{
				if (num <= 3613580814U)
				{
					if (num <= 3591481634U)
					{
						if (num <= 3571638423U)
						{
							if (num != 3562409314U)
							{
								if (num == 3571638423U)
								{
									if (code == "0001045D")
									{
										return "Inuktitut - naqittaut";
									}
								}
							}
							else if (code == "00000416")
							{
								return "Portuguese (brazillian abnt)";
							}
						}
						else if (num != 3573443440U)
						{
							if (num != 3579334028U)
							{
								if (num == 3591481634U)
								{
									if (code == "0000082C")
									{
										return "Azeri Cyrillic";
									}
								}
							}
							else if (code == "00000407")
							{
								return "German";
							}
						}
						else if (code == "00011809")
						{
							return "Gaelic";
						}
					}
					else if (num <= 3596111647U)
					{
						if (num != 3595964552U)
						{
							if (num == 3596111647U)
							{
								if (code == "00000406")
								{
									return "Danish";
								}
							}
						}
						else if (code == "00000418")
						{
							return "Romanian (legacy)";
						}
					}
					else if (num != 3612742171U)
					{
						if (num != 3612889266U)
						{
							if (num == 3613580814U)
							{
								if (code == "0000044E")
								{
									return "Marathi";
								}
							}
						}
						else if (code == "00000405")
						{
							return "Czech";
						}
					}
					else if (code == "00000419")
					{
						return "Russian";
					}
				}
				else if (num <= 3647430242U)
				{
					if (num <= 3629666885U)
					{
						if (num != 3613875004U)
						{
							if (num == 3629666885U)
							{
								if (code == "00000404")
								{
									return "Chinese (traditional) - us keyboard";
								}
							}
						}
						else if (code == "00000461")
						{
							return "Nepali";
						}
					}
					else if (num != 3630358433U)
					{
						if (num != 3647136052U)
						{
							if (num == 3647430242U)
							{
								if (code == "00000463")
								{
									return "Pashto (afghanistan)";
								}
							}
						}
						else if (code == "0000044C")
						{
							return "Malayalam";
						}
					}
					else if (code == "0000044D")
					{
						return "Assamese - inscript";
					}
				}
				else if (num <= 3679999742U)
				{
					if (num != 3663913671U)
					{
						if (num == 3679999742U)
						{
							if (code == "00000409")
							{
								return "United States";
							}
						}
					}
					else if (code == "0000044B")
					{
						return "Kannada";
					}
				}
				else if (num != 3680691290U)
				{
					if (num != 3696777361U)
					{
						if (num == 3764873575U)
						{
							if (code == "00000468")
							{
								return "Hausa";
							}
						}
					}
					else if (code == "00000408")
					{
						return "Greek";
					}
				}
				else if (code == "0000044A")
				{
					return "Telugu";
				}
			}
			else if (num <= 4101573375U)
			{
				if (num <= 4041853040U)
				{
					if (num <= 3825927015U)
					{
						if (num != 3823891088U)
						{
							if (num == 3825927015U)
							{
								if (code == "0000081A")
								{
									return "Serbian (latin)";
								}
							}
						}
						else if (code == "0001041E")
						{
							return "Thai Pattachote";
						}
					}
					else if (num != 3874223945U)
					{
						if (num != 3941334421U)
						{
							if (num == 4041853040U)
							{
								if (code == "00010402")
								{
									return "Bulgarian (latin)";
								}
							}
						}
						else if (code == "0001041B")
						{
							return "Slovak (qwerty)";
						}
					}
					else if (code == "0001041F")
					{
						return "Turkish F";
					}
				}
				else if (num <= 4091891707U)
				{
					if (num != 4091200159U)
					{
						if (num == 4091891707U)
						{
							if (code == "0001042E")
							{
								return "Sorbian extended";
							}
						}
					}
					else if (code == "00010465")
					{
						return "Divehi typewriter";
					}
				}
				else if (num != 4092185897U)
				{
					if (num != 4092332992U)
					{
						if (num == 4101573375U)
						{
							if (code == "00040402")
							{
								return "Bulgarian (phonetic traditional)";
							}
						}
					}
					else if (code == "00010415")
					{
						return "Polish (214)";
					}
				}
				else if (code == "00010401")
				{
					return "Arabic (102)";
				}
			}
			else if (num <= 4175779802U)
			{
				if (num <= 4125741135U)
				{
					if (num != 4108669326U)
					{
						if (num == 4125741135U)
						{
							if (code == "00010407")
							{
								return "German (ibm)";
							}
						}
					}
					else if (code == "0001042F")
					{
						return "Macedonian (fyrom) - standard";
					}
				}
				else if (num != 4142665849U)
				{
					if (num != 4159296373U)
					{
						if (num == 4175779802U)
						{
							if (code == "0001042B")
							{
								return "Armenian Western";
							}
						}
					}
					else if (code == "00010405")
					{
						return "Czech (qwerty)";
					}
				}
				else if (code == "00010416")
				{
					return "Portuguese (brazillian abnt2)";
				}
			}
			else if (num <= 4226406849U)
			{
				if (num != 4176221087U)
				{
					if (num != 4209629230U)
					{
						if (num == 4226406849U)
						{
							if (code == "00010409")
							{
								return "United States - dvorak";
							}
						}
					}
					else if (code == "00010408")
					{
						return "Greek (220)";
					}
				}
				else if (code == "00010410")
				{
					return "Italian (142)";
				}
			}
			else if (num != 4267799274U)
			{
				if (num != 4269349565U)
				{
					if (num == 4293664420U)
					{
						if (code == "00010419")
						{
							return "Russian (typewriter)";
						}
					}
				}
				else if (code == "00040408")
				{
					return "Greek (319) latin";
				}
			}
			else if (code == "0002042E")
			{
				return "Sorbian standard";
			}
			return code;
		}

		// Token: 0x06000CC4 RID: 3268 RVA: 0x0000B619 File Offset: 0x00009819
		public static WindowState FindMainWindowState(Window window)
		{
			if (window.Owner == null)
			{
				return window.WindowState;
			}
			return InteropWindow.FindMainWindowState(window.Owner);
		}

		// Token: 0x06000CC5 RID: 3269
		[DllImport("User32.dll", BestFitMapping = false, CharSet = CharSet.Ansi, ThrowOnUnmappableChar = true)]
		public static extern IntPtr LoadCursorFromFile(string str);

		// Token: 0x06000CC6 RID: 3270
		[DllImport("user32.dll")]
		[return: MarshalAs(UnmanagedType.Bool)]
		public static extern bool GetIconInfo(IntPtr hIcon, ref InteropWindow.IconInfo pIconInfo);

		// Token: 0x06000CC7 RID: 3271
		[DllImport("user32.dll")]
		public static extern IntPtr CreateIconIndirect(ref InteropWindow.IconInfo icon);

		// Token: 0x06000CC8 RID: 3272 RVA: 0x000372F0 File Offset: 0x000354F0
		public static Cursor CreateCursor(Bitmap bmp, int xHotSpot, int yHotSpot, float scalingFactor)
		{
			int num = (int)(32f * scalingFactor);
			int num2 = (int)(32f * scalingFactor);
			IntPtr hicon = new Bitmap(bmp, num, num2).GetHicon();
			InteropWindow.IconInfo iconInfo = default(InteropWindow.IconInfo);
			InteropWindow.GetIconInfo(hicon, ref iconInfo);
			iconInfo.xHotspot = (int)((float)xHotSpot * scalingFactor * ((float)num / (float)bmp.Width));
			iconInfo.yHotspot = (int)((float)yHotSpot * scalingFactor * ((float)num2 / (float)bmp.Height));
			iconInfo.fIcon = false;
			return new Cursor(InteropWindow.CreateIconIndirect(ref iconInfo));
		}

		// Token: 0x04000ABB RID: 2747
		public const int WM_CREATE = 1;

		// Token: 0x04000ABC RID: 2748
		public const int WM_CLOSE = 16;

		// Token: 0x04000ABD RID: 2749
		public const int WM_INPUT = 255;

		// Token: 0x04000ABE RID: 2750
		public const int WM_USER = 1024;

		// Token: 0x04000ABF RID: 2751
		public const int WM_USER_SHOW_WINDOW = 1025;

		// Token: 0x04000AC0 RID: 2752
		public const int WM_USER_SWITCH_TO_LAUNCHER = 1026;

		// Token: 0x04000AC1 RID: 2753
		public const int WM_USER_RESIZE_WINDOW = 1027;

		// Token: 0x04000AC2 RID: 2754
		public const int WM_USER_FE_STATE_CHANGE = 1028;

		// Token: 0x04000AC3 RID: 2755
		public const int WM_USER_FE_APP_DISPLAYED = 1029;

		// Token: 0x04000AC4 RID: 2756
		public const int WM_USER_FE_ORIENTATION_CHANGE = 1030;

		// Token: 0x04000AC5 RID: 2757
		public const int WM_USER_FE_RESIZE = 1031;

		// Token: 0x04000AC6 RID: 2758
		public const int WM_USER_INSTALL_COMPLETED = 1032;

		// Token: 0x04000AC7 RID: 2759
		public const int WM_USER_UNINSTALL_COMPLETED = 1033;

		// Token: 0x04000AC8 RID: 2760
		public const int WM_USER_APP_CRASHED = 1034;

		// Token: 0x04000AC9 RID: 2761
		public const int WM_USER_EXE_CRASHED = 1035;

		// Token: 0x04000ACA RID: 2762
		public const int WM_USER_UPGRADE_FAILED = 1036;

		// Token: 0x04000ACB RID: 2763
		public const int WM_USER_BOOT_FAILURE = 1037;

		// Token: 0x04000ACC RID: 2764
		public const int WM_USER_FE_SHOOTMODE_STATE = 1038;

		// Token: 0x04000ACD RID: 2765
		public const int WM_USER_TOGGLE_FULLSCREEN = 1056;

		// Token: 0x04000ACE RID: 2766
		public const int WM_USER_GO_BACK = 1057;

		// Token: 0x04000ACF RID: 2767
		public const int WM_USER_SHOW_GUIDANCE = 1058;

		// Token: 0x04000AD0 RID: 2768
		public const int WM_USER_AUDIO_MUTE = 1059;

		// Token: 0x04000AD1 RID: 2769
		public const int WM_USER_AUDIO_UNMUTE = 1060;

		// Token: 0x04000AD2 RID: 2770
		public const int WM_USER_AT_HOME = 1061;

		// Token: 0x04000AD3 RID: 2771
		public const int WM_USER_ACTIVATE = 1062;

		// Token: 0x04000AD4 RID: 2772
		public const int WM_USER_HIDE_WINDOW = 1063;

		// Token: 0x04000AD5 RID: 2773
		public const int WM_USER_VMX_BIT_ON = 1064;

		// Token: 0x04000AD6 RID: 2774
		public const int WM_USER_DEACTIVATE = 1065;

		// Token: 0x04000AD7 RID: 2775
		public const int WM_USER_LOGS_REPORTING = 1072;

		// Token: 0x04000AD8 RID: 2776
		public const int WM_NCHITTEST = 132;

		// Token: 0x04000AD9 RID: 2777
		public const int WM_MOUSEMOVE = 512;

		// Token: 0x04000ADA RID: 2778
		public const int WM_MOUSEWHEEL = 522;

		// Token: 0x04000ADB RID: 2779
		public const int WM_RBUTTONDOWN = 516;

		// Token: 0x04000ADC RID: 2780
		public const int WM_RBUTTONUP = 517;

		// Token: 0x04000ADD RID: 2781
		public const int WM_LBUTTONDOWN = 513;

		// Token: 0x04000ADE RID: 2782
		public const int WM_LBUTTONUP = 514;

		// Token: 0x04000ADF RID: 2783
		public const int WM_MBUTTONDOWN = 519;

		// Token: 0x04000AE0 RID: 2784
		public const int WM_MBUTTONUP = 520;

		// Token: 0x04000AE1 RID: 2785
		public const int WM_XBUTTONDOWN = 523;

		// Token: 0x04000AE2 RID: 2786
		public const int WM_XBUTTONUP = 524;

		// Token: 0x04000AE3 RID: 2787
		public const int WM_LBUTTONDBLCLK = 515;

		// Token: 0x04000AE4 RID: 2788
		public const int WM_DISPLAYCHANGE = 126;

		// Token: 0x04000AE5 RID: 2789
		public const int WM_INPUTLANGCHANGEREQUEST = 80;

		// Token: 0x04000AE6 RID: 2790
		public const int WM_IME_ENDCOMPOSITION = 270;

		// Token: 0x04000AE7 RID: 2791
		public const int WM_IME_COMPOSITION = 271;

		// Token: 0x04000AE8 RID: 2792
		public const int WM_IME_CHAR = 646;

		// Token: 0x04000AE9 RID: 2793
		public const int WM_CHAR = 258;

		// Token: 0x04000AEA RID: 2794
		public const int WM_IME_NOTIFY = 642;

		// Token: 0x04000AEB RID: 2795
		public const int WM_NCLBUTTONDOWN = 161;

		// Token: 0x04000AEC RID: 2796
		public const int HT_CAPTION = 2;

		// Token: 0x04000AED RID: 2797
		public const int WM_IME_SETCONTEXT = 641;

		// Token: 0x04000AEE RID: 2798
		public const int WM_USER_TROUBLESHOOT_STUCK_AT_LOADING = 1088;

		// Token: 0x04000AEF RID: 2799
		public const int WM_USER_TROUBLESHOOT_BLACK_SCREEN = 1089;

		// Token: 0x04000AF0 RID: 2800
		public const int WM_USER_TROUBLESHOOT_RPC = 1090;

		// Token: 0x04000AF1 RID: 2801
		public const int WM_SYSKEYDOWN = 260;

		// Token: 0x04000AF2 RID: 2802
		public const int WM_SYSCHAR = 262;

		// Token: 0x04000AF3 RID: 2803
		public const int VK_MENU = 18;

		// Token: 0x04000AF4 RID: 2804
		public const int VK_F10 = 121;

		// Token: 0x04000AF5 RID: 2805
		public const int VK_SPACE = 32;

		// Token: 0x04000AF6 RID: 2806
		public const int GWL_EXSTYLE = -20;

		// Token: 0x04000AF7 RID: 2807
		public const int WS_EX_TOOLWINDOW = 128;

		// Token: 0x04000AF8 RID: 2808
		public const int WS_EX_APPWINDOW = 262144;

		// Token: 0x04000AF9 RID: 2809
		public const int WS_EX_TOPMOST = 8;

		// Token: 0x04000AFA RID: 2810
		private const int GCS_COMPSTR = 8;

		// Token: 0x04000AFB RID: 2811
		public const int WM_COPYDATA = 74;

		// Token: 0x04000AFC RID: 2812
		public const int SC_KEYMENU = 61696;

		// Token: 0x04000AFD RID: 2813
		public const int SC_MAXIMIZE = 61488;

		// Token: 0x04000AFE RID: 2814
		public const int SC_MAXIMIZE2 = 61490;

		// Token: 0x04000AFF RID: 2815
		public const int SC_RESTORE = 61728;

		// Token: 0x04000B00 RID: 2816
		public const int SC_RESTORE2 = 61730;

		// Token: 0x04000B01 RID: 2817
		public const int WM_SYSCOMMAND = 274;

		// Token: 0x04000B02 RID: 2818
		public const int WM_ERASEBKGND = 20;

		// Token: 0x04000B03 RID: 2819
		public const int SM_CXSCREEN = 0;

		// Token: 0x04000B04 RID: 2820
		public const int SM_CYSCREEN = 1;

		// Token: 0x04000B05 RID: 2821
		public const int SWP_ASYNCWINDOWPOS = 16384;

		// Token: 0x04000B06 RID: 2822
		public const int SWP_DEFERERASE = 8192;

		// Token: 0x04000B07 RID: 2823
		public const int SWP_DRAWFRAME = 32;

		// Token: 0x04000B08 RID: 2824
		public const int SWP_FRAMECHANGED = 32;

		// Token: 0x04000B09 RID: 2825
		public const int SWP_HIDEWINDOW = 128;

		// Token: 0x04000B0A RID: 2826
		public const int SWP_NOACTIVATE = 16;

		// Token: 0x04000B0B RID: 2827
		public const int SWP_NOCOPYBITS = 256;

		// Token: 0x04000B0C RID: 2828
		public const int SWP_NOMOVE = 2;

		// Token: 0x04000B0D RID: 2829
		public const int SWP_NOOWNERZORDER = 512;

		// Token: 0x04000B0E RID: 2830
		public const int SWP_NOREDRAW = 8;

		// Token: 0x04000B0F RID: 2831
		public const int SWP_NOREPOSITION = 512;

		// Token: 0x04000B10 RID: 2832
		public const int SWP_NOSENDCHANGING = 1024;

		// Token: 0x04000B11 RID: 2833
		public const int SWP_NOSIZE = 1;

		// Token: 0x04000B12 RID: 2834
		public const int SWP_NOZORDER = 4;

		// Token: 0x04000B13 RID: 2835
		public const int SWP_SHOWWINDOW = 64;

		// Token: 0x04000B14 RID: 2836
		public const int WS_OVERLAPPED = 0;

		// Token: 0x04000B15 RID: 2837
		public const int WS_CAPTION = 12582912;

		// Token: 0x04000B16 RID: 2838
		public const int WS_SYSMENU = 524288;

		// Token: 0x04000B17 RID: 2839
		public const int WS_THICKFRAME = 262144;

		// Token: 0x04000B18 RID: 2840
		public const int WS_MINIMIZEBOX = 131072;

		// Token: 0x04000B19 RID: 2841
		public const int WS_MAXIMIZEBOX = 65536;

		// Token: 0x04000B1A RID: 2842
		public const int WS_OVERLAPPEDWINDOW = 13565952;

		// Token: 0x04000B1B RID: 2843
		private const int LOGPIXELSX = 88;

		// Token: 0x04000B1C RID: 2844
		public const int WM_SETREDRAW = 11;

		// Token: 0x04000B1D RID: 2845
		public static IntPtr HWND_TOP = IntPtr.Zero;

		// Token: 0x04000B1E RID: 2846
		public const int SW_HIDE = 0;

		// Token: 0x04000B1F RID: 2847
		public const int SW_SHOWMAXIMIZED = 3;

		// Token: 0x04000B20 RID: 2848
		public const int SW_SHOW = 5;

		// Token: 0x04000B21 RID: 2849
		public const int SW_MINIMIZE = 6;

		// Token: 0x04000B22 RID: 2850
		public const int SW_SHOWNA = 8;

		// Token: 0x04000B23 RID: 2851
		public const int SW_RESTORE = 9;

		// Token: 0x04000B24 RID: 2852
		public const int SW_SHOWNORMAL = 1;

		// Token: 0x04000B25 RID: 2853
		public const int GWL_STYLE = -16;

		// Token: 0x04000B26 RID: 2854
		public const uint WS_POPUP = 2147483648U;

		// Token: 0x04000B27 RID: 2855
		public const uint WS_CHILD = 1073741824U;

		// Token: 0x04000B28 RID: 2856
		public const uint WS_DISABLED = 134217728U;

		// Token: 0x04000B29 RID: 2857
		private const int KL_NAMELENGTH = 9;

		// Token: 0x02000198 RID: 408
		public struct COMPOSITIONFORM
		{
			// Token: 0x04000B2A RID: 2858
			public int dwStyle;

			// Token: 0x04000B2B RID: 2859
			public System.Drawing.Point ptCurrentPos;

			// Token: 0x04000B2C RID: 2860
			public InteropWindow.RECT rcArea;
		}

		// Token: 0x02000199 RID: 409
		public struct RECT
		{
			// Token: 0x04000B2D RID: 2861
			public int left;

			// Token: 0x04000B2E RID: 2862
			public int top;

			// Token: 0x04000B2F RID: 2863
			public int right;

			// Token: 0x04000B30 RID: 2864
			public int bottom;
		}

		// Token: 0x0200019A RID: 410
		public struct COPYDATASTRUCT
		{
			// Token: 0x06000CCB RID: 3275 RVA: 0x00037370 File Offset: 0x00035570
			public static InteropWindow.COPYDATASTRUCT CreateForString(int dwData, string value, bool Unicode = false)
			{
				return new InteropWindow.COPYDATASTRUCT
				{
					dwData = (IntPtr)dwData,
					cbData = (value.Length + 1) * 2,
					lpData = Marshal.StringToHGlobalUni(value)
				};
			}

			// Token: 0x04000B31 RID: 2865
			public IntPtr dwData;

			// Token: 0x04000B32 RID: 2866
			public int cbData;

			// Token: 0x04000B33 RID: 2867
			public IntPtr lpData;
		}

		// Token: 0x0200019B RID: 411
		public struct COPYGAMEPADDATASTRUCT
		{
			// Token: 0x04000B34 RID: 2868
			public IntPtr dwData;

			// Token: 0x04000B35 RID: 2869
			public int size;

			// Token: 0x04000B36 RID: 2870
			public IntPtr lpData;
		}

		// Token: 0x0200019C RID: 412
		public enum GetAncestorFlags
		{
			// Token: 0x04000B38 RID: 2872
			GetParent = 1,
			// Token: 0x04000B39 RID: 2873
			GetRoot,
			// Token: 0x04000B3A RID: 2874
			GetRootOwner
		}

		// Token: 0x0200019D RID: 413
		public enum DPI_AWARENESS_CONTEXT
		{
			// Token: 0x04000B3C RID: 2876
			DPI_AWARENESS_CONTEXT_DEFAULT,
			// Token: 0x04000B3D RID: 2877
			DPI_AWARENESS_CONTEXT_UNAWARE = -1,
			// Token: 0x04000B3E RID: 2878
			DPI_AWARENESS_CONTEXT_SYSTEM_AWARE = -2,
			// Token: 0x04000B3F RID: 2879
			DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE = -3
		}

		// Token: 0x0200019E RID: 414
		public struct IconInfo
		{
			// Token: 0x04000B40 RID: 2880
			public bool fIcon;

			// Token: 0x04000B41 RID: 2881
			public int xHotspot;

			// Token: 0x04000B42 RID: 2882
			public int yHotspot;

			// Token: 0x04000B43 RID: 2883
			public IntPtr hbmMask;

			// Token: 0x04000B44 RID: 2884
			public IntPtr hbmColor;
		}
	}
}
