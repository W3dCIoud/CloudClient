﻿using System;
using System.IO;

namespace BlueStacks.Common
{
	// Token: 0x020000B9 RID: 185
	public class FormFile
	{
		// Token: 0x170001C0 RID: 448
		// (get) Token: 0x06000608 RID: 1544 RVA: 0x000066E6 File Offset: 0x000048E6
		// (set) Token: 0x06000609 RID: 1545 RVA: 0x000066EE File Offset: 0x000048EE
		public string Name { get; set; }

		// Token: 0x170001C1 RID: 449
		// (get) Token: 0x0600060A RID: 1546 RVA: 0x000066F7 File Offset: 0x000048F7
		// (set) Token: 0x0600060B RID: 1547 RVA: 0x000066FF File Offset: 0x000048FF
		public string ContentType { get; set; }

		// Token: 0x170001C2 RID: 450
		// (get) Token: 0x0600060C RID: 1548 RVA: 0x00006708 File Offset: 0x00004908
		// (set) Token: 0x0600060D RID: 1549 RVA: 0x00006710 File Offset: 0x00004910
		public string FilePath { get; set; }

		// Token: 0x170001C3 RID: 451
		// (get) Token: 0x0600060E RID: 1550 RVA: 0x00006719 File Offset: 0x00004919
		// (set) Token: 0x0600060F RID: 1551 RVA: 0x00006721 File Offset: 0x00004921
		public Stream Stream { get; set; }
	}
}
