﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x02000096 RID: 150
	public class CornerRadiusToThicknessConvertor : MarkupExtension, IValueConverter
	{
		// Token: 0x0600036E RID: 878 RVA: 0x00003F53 File Offset: 0x00002153
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return CornerRadiusToThicknessConvertor.Convert(value, targetType);
		}

		// Token: 0x0600036F RID: 879 RVA: 0x00003F53 File Offset: 0x00002153
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return CornerRadiusToThicknessConvertor.Convert(value, targetType);
		}

		// Token: 0x06000370 RID: 880 RVA: 0x00016A38 File Offset: 0x00014C38
		public static object Convert(object value, Type targetType)
		{
			if (typeof(Thickness).Equals(targetType))
			{
				CornerRadius cornerRadius = (CornerRadius)value;
				return new Thickness(cornerRadius.TopLeft, cornerRadius.TopRight, cornerRadius.BottomRight, cornerRadius.BottomLeft);
			}
			return value;
		}

		// Token: 0x06000371 RID: 881 RVA: 0x00003F48 File Offset: 0x00002148
		public override object ProvideValue(IServiceProvider serviceProvider)
		{
			return this;
		}
	}
}
