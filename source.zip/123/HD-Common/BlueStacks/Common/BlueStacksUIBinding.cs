﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace BlueStacks.Common
{
	// Token: 0x02000091 RID: 145
	public class BlueStacksUIBinding : INotifyPropertyChanged
	{
		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x060002EB RID: 747 RVA: 0x0000397C File Offset: 0x00001B7C
		// (set) Token: 0x060002EC RID: 748 RVA: 0x00003994 File Offset: 0x00001B94
		public static BlueStacksUIBinding Instance
		{
			get
			{
				if (BlueStacksUIBinding._Instance == null)
				{
					BlueStacksUIBinding._Instance = new BlueStacksUIBinding();
				}
				return BlueStacksUIBinding._Instance;
			}
			set
			{
				BlueStacksUIBinding._Instance = value;
			}
		}

		// Token: 0x060002ED RID: 749 RVA: 0x0000399C File Offset: 0x00001B9C
		public BlueStacksUIBinding()
		{
			LocaleStrings.SourceUpdatedEvent += this.Locale_Updated;
			BluestacksUIColor.SourceUpdatedEvent += this.BluestacksUIColor_Updated;
			CustomPictureBox.SourceUpdatedEvent += this.BluestacksImage_Updated;
		}

		// Token: 0x060002EE RID: 750 RVA: 0x000039D7 File Offset: 0x00001BD7
		public void Locale_Updated(object sender, EventArgs e)
		{
			this.NotifyPropertyChanged("LocaleModel");
		}

		// Token: 0x060002EF RID: 751 RVA: 0x000039E4 File Offset: 0x00001BE4
		public void BluestacksUIColor_Updated(object sender, EventArgs e)
		{
			this.NotifyPropertyChanged("ColorModel");
			this.NotifyPropertyChanged("GeometryModel");
			this.NotifyPropertyChanged("CornerRadiusModel");
			this.NotifyPropertyChanged("TransformModel");
		}

		// Token: 0x060002F0 RID: 752 RVA: 0x00003A12 File Offset: 0x00001C12
		public void BluestacksImage_Updated(object sender, EventArgs e)
		{
			this.NotifyPropertyChanged("ImageModel");
		}

		// Token: 0x14000002 RID: 2
		// (add) Token: 0x060002F1 RID: 753 RVA: 0x000125AC File Offset: 0x000107AC
		// (remove) Token: 0x060002F2 RID: 754 RVA: 0x000125E4 File Offset: 0x000107E4
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x060002F3 RID: 755 RVA: 0x00003A1F File Offset: 0x00001C1F
		// (set) Token: 0x060002F4 RID: 756 RVA: 0x00003337 File Offset: 0x00001537
		public Dictionary<string, Brush> ColorModel
		{
			get
			{
				return BlueStacksUIColorManager.AppliedTheme.DictBrush;
			}
			set
			{
			}
		}

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x060002F5 RID: 757 RVA: 0x00003A2B File Offset: 0x00001C2B
		// (set) Token: 0x060002F6 RID: 758 RVA: 0x00003337 File Offset: 0x00001537
		public Dictionary<string, Geometry> GeometryModel
		{
			get
			{
				return BlueStacksUIColorManager.AppliedTheme.DictGeometry;
			}
			set
			{
			}
		}

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x060002F7 RID: 759 RVA: 0x00003A37 File Offset: 0x00001C37
		// (set) Token: 0x060002F8 RID: 760 RVA: 0x00003337 File Offset: 0x00001537
		public Dictionary<string, CornerRadius> CornerRadiusModel
		{
			get
			{
				return BlueStacksUIColorManager.AppliedTheme.DictCornerRadius;
			}
			set
			{
			}
		}

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x060002F9 RID: 761 RVA: 0x00003A43 File Offset: 0x00001C43
		// (set) Token: 0x060002FA RID: 762 RVA: 0x00003337 File Offset: 0x00001537
		public Dictionary<string, Transform> TransformModel
		{
			get
			{
				return BlueStacksUIColorManager.AppliedTheme.DictTransform;
			}
			set
			{
			}
		}

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x060002FB RID: 763 RVA: 0x00003A4F File Offset: 0x00001C4F
		// (set) Token: 0x060002FC RID: 764 RVA: 0x00003337 File Offset: 0x00001537
		public Dictionary<string, string> LocaleModel
		{
			get
			{
				return LocaleStrings.DictLocalizedString;
			}
			set
			{
			}
		}

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x060002FD RID: 765 RVA: 0x00003A56 File Offset: 0x00001C56
		// (set) Token: 0x060002FE RID: 766 RVA: 0x00003337 File Offset: 0x00001537
		public Dictionary<string, Tuple<BitmapImage, bool>> ImageModel
		{
			get
			{
				return CustomPictureBox.sImageAssetsDict;
			}
			set
			{
			}
		}

		// Token: 0x060002FF RID: 767 RVA: 0x00003A5D File Offset: 0x00001C5D
		public void NotifyPropertyChanged(string name)
		{
			if (this.PropertyChanged != null)
			{
				this.PropertyChanged(this, new PropertyChangedEventArgs(name));
			}
		}

		// Token: 0x06000300 RID: 768 RVA: 0x00003A79 File Offset: 0x00001C79
		public static void Bind(UserControl uc, string path)
		{
			BindingOperations.SetBinding(uc, FrameworkElement.ToolTipProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x06000301 RID: 769 RVA: 0x00003A8D File Offset: 0x00001C8D
		public static void Bind(CustomRadioButton tb, string path)
		{
			BindingOperations.SetBinding(tb, ContentControl.ContentProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x06000302 RID: 770 RVA: 0x00003A8D File Offset: 0x00001C8D
		public static void Bind(ToggleButton tb, string path)
		{
			BindingOperations.SetBinding(tb, ContentControl.ContentProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x06000303 RID: 771 RVA: 0x00003AA1 File Offset: 0x00001CA1
		public static void Bind(GroupBox gb, string path)
		{
			BindingOperations.SetBinding(gb, HeaderedContentControl.HeaderProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x06000304 RID: 772 RVA: 0x00003A8D File Offset: 0x00001C8D
		public static void Bind(Label label, string path)
		{
			BindingOperations.SetBinding(label, ContentControl.ContentProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x06000305 RID: 773 RVA: 0x00003AB5 File Offset: 0x00001CB5
		public static void Bind(Run run, string path)
		{
			BindingOperations.SetBinding(run, TextBlock.TextProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x06000306 RID: 774 RVA: 0x00003AC9 File Offset: 0x00001CC9
		public static void Bind(Window wind, string path)
		{
			BindingOperations.SetBinding(wind, Window.TitleProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x06000307 RID: 775 RVA: 0x0001261C File Offset: 0x0001081C
		public static void Bind(TextBlock tb, string path, string stringFormat = "")
		{
			Binding localeBinding = BlueStacksUIBinding.GetLocaleBinding(path);
			if (!string.IsNullOrEmpty(stringFormat))
			{
				localeBinding.StringFormat = stringFormat;
			}
			BindingOperations.SetBinding(tb, TextBlock.TextProperty, localeBinding);
		}

		// Token: 0x06000308 RID: 776 RVA: 0x00003ADD File Offset: 0x00001CDD
		public static void Bind(DependencyObject icon, string path, DependencyProperty dp)
		{
			BindingOperations.SetBinding(icon, dp, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x06000309 RID: 777 RVA: 0x00003AED File Offset: 0x00001CED
		public static void ClearBind(DependencyObject icon, DependencyProperty dp)
		{
			BindingOperations.ClearBinding(icon, dp);
		}

		// Token: 0x0600030A RID: 778 RVA: 0x00003A8D File Offset: 0x00001C8D
		public static void Bind(ComboBoxItem comboBoxItem, string path)
		{
			BindingOperations.SetBinding(comboBoxItem, ContentControl.ContentProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x0600030B RID: 779 RVA: 0x00003A8D File Offset: 0x00001C8D
		public static void Bind(Button button, string path)
		{
			BindingOperations.SetBinding(button, ContentControl.ContentProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x0600030C RID: 780 RVA: 0x00003A79 File Offset: 0x00001C79
		public static void Bind(Image button, string path)
		{
			BindingOperations.SetBinding(button, FrameworkElement.ToolTipProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x0600030D RID: 781 RVA: 0x00003AF6 File Offset: 0x00001CF6
		public static void Bind(TextBox textBox, string path)
		{
			BindingOperations.SetBinding(textBox, TextBox.TextProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x0600030E RID: 782 RVA: 0x0001264C File Offset: 0x0001084C
		public static Binding GetLocaleBinding(string path)
		{
			Binding binding = new Binding();
			binding.Source = BlueStacksUIBinding.Instance;
			string text = "";
			for (int i = 0; i < path.Length; i++)
			{
				text = text + "^" + path[i].ToString();
			}
			binding.Path = new PropertyPath("Instance.LocaleModel.[" + text.ToUpper() + "]", new object[0]);
			binding.Mode = BindingMode.OneWay;
			binding.FallbackValue = LocaleStrings.RemoveConstants(path);
			binding.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
			LocaleStrings.AppendLocaleIfDoesntExist(path, LocaleStrings.RemoveConstants(path));
			return binding;
		}

		// Token: 0x0600030F RID: 783 RVA: 0x00003B0A File Offset: 0x00001D0A
		public static void BindColor(DependencyObject dObj, DependencyProperty dp, string path)
		{
			BindingOperations.SetBinding(dObj, dp, BlueStacksUIBinding.GetColorBinding(path));
		}

		// Token: 0x06000310 RID: 784 RVA: 0x00003B1A File Offset: 0x00001D1A
		public static void BindCornerRadius(DependencyObject dObj, DependencyProperty dp, string path)
		{
			BindingOperations.SetBinding(dObj, dp, BlueStacksUIBinding.GetCornerRadiusBinding(path));
		}

		// Token: 0x06000311 RID: 785 RVA: 0x00003B2A File Offset: 0x00001D2A
		public static void BindCornerRadiusToDouble(DependencyObject dObj, DependencyProperty dp, string path)
		{
			BindingOperations.SetBinding(dObj, dp, BlueStacksUIBinding.GetCornerRadiusDoubleBinding(path));
		}

		// Token: 0x06000312 RID: 786 RVA: 0x000126F0 File Offset: 0x000108F0
		public static Binding GetColorBinding(string path)
		{
			return new Binding
			{
				Converter = new BrushToColorConvertor(),
				Source = BlueStacksUIBinding.Instance,
				Path = new PropertyPath("Instance.ColorModel.[" + path + "]", new object[0]),
				Mode = BindingMode.OneWay,
				UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
			};
		}

		// Token: 0x06000313 RID: 787 RVA: 0x0001274C File Offset: 0x0001094C
		public static Binding GetCornerRadiusBinding(string path)
		{
			return new Binding
			{
				Converter = new CornerRadiusToThicknessConvertor(),
				Source = BlueStacksUIBinding.Instance,
				Path = new PropertyPath("Instance.CornerRadiusModel.[" + path + "]", new object[0]),
				Mode = BindingMode.OneWay,
				UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
			};
		}

		// Token: 0x06000314 RID: 788 RVA: 0x000127A8 File Offset: 0x000109A8
		public static Binding GetCornerRadiusDoubleBinding(string path)
		{
			return new Binding
			{
				Converter = new CornerRadiusToDoubleConvertor(),
				Source = BlueStacksUIBinding.Instance,
				Path = new PropertyPath("Instance.CornerRadiusModel.[" + path + "]", new object[0]),
				Mode = BindingMode.OneWay,
				UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
			};
		}

		// Token: 0x06000315 RID: 789 RVA: 0x00003B3A File Offset: 0x00001D3A
		public static void Bind(Image button, DependencyProperty dp, string path)
		{
			BindingOperations.SetBinding(button, dp, BlueStacksUIBinding.GetImageBinding(path));
		}

		// Token: 0x06000316 RID: 790 RVA: 0x00012804 File Offset: 0x00010A04
		public static Binding GetImageBinding(string path)
		{
			return new Binding
			{
				Source = BlueStacksUIBinding.Instance,
				Path = new PropertyPath("Instance.ImageModel.[" + path + "].Item1", new object[0]),
				Mode = BindingMode.OneWay,
				UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
			};
		}

		// Token: 0x06000317 RID: 791 RVA: 0x00003B4A File Offset: 0x00001D4A
		public static void BindTransform(DependencyObject button, DependencyProperty dp, string path)
		{
			BindingOperations.SetBinding(button, dp, BlueStacksUIBinding.GetTransformBinding(path));
		}

		// Token: 0x06000318 RID: 792 RVA: 0x00012854 File Offset: 0x00010A54
		public static Binding GetTransformBinding(string path)
		{
			return new Binding
			{
				Source = BlueStacksUIBinding.Instance,
				Path = new PropertyPath("Instance.TransformModel.[" + path + "]", new object[0]),
				Mode = BindingMode.OneWay,
				UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
			};
		}

		// Token: 0x0400035A RID: 858
		public static BlueStacksUIBinding _Instance;
	}
}
