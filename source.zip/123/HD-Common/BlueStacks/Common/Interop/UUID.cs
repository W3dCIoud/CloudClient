﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Management;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Microsoft.Win32;
using Microsoft.Win32.SafeHandles;

namespace BlueStacks.Common.Interop
{
	// Token: 0x020001BB RID: 443
	public class UUID
	{
		// Token: 0x06000DB0 RID: 3504
		[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
		private static extern long GetVolumeInformation(string PathName, StringBuilder VolumeNameBuffer, uint VolumeNameSize, ref uint VolumeSerialNumber, ref uint MaximumComponentLength, ref uint FileSystemFlags, StringBuilder FileSystemNameBuffer, uint FileSystemNameSize);

		// Token: 0x06000DB1 RID: 3505
		[DllImport("rpcrt4.dll")]
		private static extern int UuidCreateSequential(out Guid guid);

		// Token: 0x06000DB2 RID: 3506 RVA: 0x0000BD36 File Offset: 0x00009F36
		public static Guid GenerateUUID(UUID.UUIDTYPE type)
		{
			return UUID.CreateGuid();
		}

		// Token: 0x06000DB3 RID: 3507 RVA: 0x00037D80 File Offset: 0x00035F80
		public static bool CreateUserGuid(out string guid)
		{
			try
			{
				guid = UUID.CreateGuid().ToString();
			}
			catch
			{
				Logger.Info("Could not generate guid. Using dotNet's method to generate guid");
				guid = Guid.NewGuid().ToString();
			}
			return true;
		}

		// Token: 0x06000DB4 RID: 3508 RVA: 0x00037DD8 File Offset: 0x00035FD8
		public static string GetUserGUID()
		{
			string text = null;
			string registryBaseKeyPath = Strings.RegistryBaseKeyPath;
			RegistryKey registryKey2;
			RegistryKey registryKey = registryKey2 = Registry.CurrentUser.OpenSubKey(registryBaseKeyPath);
			try
			{
				if (registryKey != null)
				{
					text = (string)registryKey.GetValue("USER_GUID", null);
					if (text != null)
					{
						Logger.Info("TODO: Fix GUID generation. This should not happen. Detected GUID in HKCU: " + text);
						return text;
					}
				}
			}
			finally
			{
				if (registryKey2 != null)
				{
					((IDisposable)registryKey2).Dispose();
				}
			}
			registryKey = (registryKey2 = Registry.LocalMachine.OpenSubKey(registryBaseKeyPath));
			try
			{
				if (registryKey != null)
				{
					text = (string)registryKey.GetValue("USER_GUID", null);
					if (text != null)
					{
						Logger.Info("TODO: Fix GUID generation. This should not happen. Detected GUID in HKLM: " + text);
						return text;
					}
				}
			}
			finally
			{
				if (registryKey2 != null)
				{
					((IDisposable)registryKey2).Dispose();
				}
			}
			try
			{
				string path = Path.Combine(Environment.GetEnvironmentVariable("TEMP"), "Bst_Guid_Backup");
				if (File.Exists(path))
				{
					string text2 = File.ReadAllText(path);
					if (!string.IsNullOrEmpty(text2))
					{
						text = text2;
						Logger.Info("Detected User GUID %temp%: " + text);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error(ex.ToString());
			}
			return text;
		}

		// Token: 0x06000DB5 RID: 3509 RVA: 0x00037F00 File Offset: 0x00036100
		public static void GetGuidAndMakeBackup(out string guid, out string oldGUID)
		{
			guid = string.Empty;
			oldGUID = string.Empty;
			if (FeatureManager.Instance.IsGuidBackUpEnable)
			{
				string userGUID = UUID.GetUserGUID();
				if (!string.IsNullOrEmpty(userGUID))
				{
					try
					{
						guid = new Guid(userGUID).ToString();
						oldGUID = guid;
					}
					catch
					{
						oldGUID = string.Empty;
					}
				}
			}
			if (string.IsNullOrEmpty(oldGUID))
			{
				string empty = string.Empty;
				if (!UUID.CreateUserGuid(out empty))
				{
					Logger.Warning("Cannot create user guid");
				}
				else
				{
					guid = empty;
				}
			}
			Utils.BackUpGuid(guid);
		}

		// Token: 0x06000DB6 RID: 3510 RVA: 0x0000BD3D File Offset: 0x00009F3D
		public static void SendFrontEndGuidStats(string oldProposedGuid)
		{
			new Thread(delegate()
			{
				string text = UUID.identifier("Win32_BaseBoard", "Manufacturer");
				string text2 = UUID.identifier("Win32_BaseBoard", "SerialNumber");
				string text3 = UUID.identifier("Win32_BIOS", "Manufacturer");
				string text4 = UUID.identifier("Win32_BIOS", "SerialNumber");
				string empty = string.Empty;
				string volumeSerialNumberSystemDriveWithoutWMI = UUID.GetVolumeSerialNumberSystemDriveWithoutWMI();
				string hddserialNumber = UUID.GetHDDSerialNumber(out empty);
				string macaddress = UUID.GetMACAddress();
				string value = UUID.CreateAndGetUniqueGeneratedID(RegistryManager.Instance.InstallID);
				string machineID = UUID.getMachineID(true);
				string hash = UUID.GetHash(string.Concat(new string[]
				{
					text3.Trim().ToUpper(),
					text4.Trim().ToUpper(),
					text.Trim().ToUpper(),
					text2.Trim().ToUpper(),
					empty.Trim().ToUpper(),
					hddserialNumber.Trim().ToUpper(),
					volumeSerialNumberSystemDriveWithoutWMI.Trim().ToUpper(),
					machineID.Trim().ToUpper(),
					macaddress.Trim().ToUpper()
				}));
				if (string.Equals(hash.ToLower(), oldProposedGuid.ToLower()))
				{
					return;
				}
				RegistryManager.Instance.ProposedGUID = hash;
				Logger.Info("sending android guid stats");
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary.Add("event", "proposed_guid_changed");
				dictionary.Add("guid", RegistryManager.Instance.UserGuid);
				dictionary.Add("old_proposed_guid", oldProposedGuid);
				dictionary.Add("client_ver", "4.140.12.1002");
				dictionary.Add("engine_ver", "4.140.12.1002");
				dictionary.Add("oem", "bgp");
				dictionary.Add("cpu_id", UUID.cpuId());
				dictionary.Add("bios_id", UUID.biosIdWithSeparator());
				dictionary.Add("baseboard_id", UUID.baseIdWithSeparator());
				dictionary.Add("hdd_id", UUID.getHDDId());
				dictionary.Add("mac_addr_wmi", UUID.macId());
				dictionary.Add("machine_guid", machineID);
				dictionary.Add("system_guid", RegistryManager.Instance.SystemGuid);
				dictionary.Add("mac_addr_win32", UUID.GetMACAddressWinAPI());
				dictionary.Add("is_included_machine_guid", RegistryManager.Instance.IsIncludeMachineGUID.ToString());
				dictionary.Add("bios_manufacturer", text3);
				dictionary.Add("bios_serial", text4);
				dictionary.Add("baseboard_manufacturer", text);
				dictionary.Add("baseboard_serial", text2);
				dictionary.Add("system_drive_model", empty);
				dictionary.Add("system_drive_serial", hddserialNumber);
				dictionary.Add("system_volume_serial", volumeSerialNumberSystemDriveWithoutWMI);
				dictionary.Add("install_id", RegistryManager.Instance.InstallID);
				dictionary.Add("generated_id", value);
				dictionary.Add("root_adapter_mac_addr", macaddress);
				dictionary.Add("proposed_guid", hash);
				string text5 = string.Format("{0}/bs3/stats/{1}", RegistryManager.Instance.Host, "guid_debug_stats");
				Logger.Info("sending guid debug stats to url : " + text5);
				try
				{
					string str = BstHttpClient.Post(text5, dictionary, null, false, "Android", 5000, 1, 0, false);
					Logger.Info("Response of http call to sending android stats.." + str);
				}
				catch (Exception ex)
				{
					Logger.Error(ex.ToString());
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000DB7 RID: 3511 RVA: 0x00037F9C File Offset: 0x0003619C
		public static void SendInstallerGuidStats(string guid, bool isUpgrade, bool isNewGuid, string installID, string oldSystemGuid)
		{
			new Thread(delegate()
			{
				string text = UUID.identifier("Win32_BaseBoard", "Manufacturer");
				string text2 = UUID.identifier("Win32_BaseBoard", "SerialNumber");
				string text3 = UUID.identifier("Win32_BIOS", "Manufacturer");
				string text4 = UUID.identifier("Win32_BIOS", "SerialNumber");
				string empty = string.Empty;
				string volumeSerialNumberSystemDriveWithoutWMI = UUID.GetVolumeSerialNumberSystemDriveWithoutWMI();
				string hddserialNumber = UUID.GetHDDSerialNumber(out empty);
				string macaddress = UUID.GetMACAddress();
				string value = UUID.CreateAndGetUniqueGeneratedID(installID);
				string machineID = UUID.getMachineID(true);
				string hash = UUID.GetHash(string.Concat(new string[]
				{
					text3.Trim().ToUpper(),
					text4.Trim().ToUpper(),
					text.Trim().ToUpper(),
					text2.Trim().ToUpper(),
					empty.Trim().ToUpper(),
					hddserialNumber.Trim().ToUpper(),
					volumeSerialNumberSystemDriveWithoutWMI.Trim().ToUpper(),
					machineID.Trim().ToUpper(),
					macaddress.Trim().ToUpper()
				}));
				RegistryManager.Instance.ProposedGUID = hash;
				Logger.Info("sending installer guid stats");
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				if (isUpgrade)
				{
					dictionary.Add("event", "client_upgrade_started");
				}
				else
				{
					dictionary.Add("event", "client_install_started");
				}
				dictionary.Add("guid", guid);
				dictionary.Add("is_new_user_guid", isNewGuid.ToString());
				dictionary.Add("client_ver", "4.140.12.1002");
				dictionary.Add("engine_ver", "4.140.12.1002");
				dictionary.Add("oem", "bgp");
				dictionary.Add("cpu_id", UUID.cpuId());
				dictionary.Add("bios_id", UUID.biosIdWithSeparator());
				dictionary.Add("baseboard_id", UUID.baseIdWithSeparator());
				dictionary.Add("hdd_id", UUID.getHDDId());
				dictionary.Add("mac_addr_wmi", UUID.macId());
				dictionary.Add("machine_guid", UUID.getMachineID(true));
				dictionary.Add("system_guid", oldSystemGuid);
				dictionary.Add("mac_addr_win32", UUID.GetMACAddressWinAPI());
				dictionary.Add("bios_manufacturer", text3);
				dictionary.Add("bios_serial", text4);
				dictionary.Add("baseboard_manufacturer", text);
				dictionary.Add("baseboard_serial", text2);
				dictionary.Add("system_drive_model", empty);
				dictionary.Add("system_drive_serial", hddserialNumber);
				dictionary.Add("system_volume_serial", volumeSerialNumberSystemDriveWithoutWMI);
				dictionary.Add("install_id", installID);
				dictionary.Add("generated_id", value);
				dictionary.Add("root_adapter_mac_addr", macaddress);
				dictionary.Add("proposed_guid", hash);
				Logger.Info("machine_guid in stats.." + machineID);
				string text5 = string.Format("{0}/bs3/stats/{1}", "https://cloud.bluestacks.com", "guid_debug_stats");
				Logger.Info("sending installer guid debug stats to url : " + text5);
				try
				{
					string arg = BstHttpClient.Post(text5, dictionary, null, false, null, 0, 1, 0, false);
					Logger.Info(string.Format("Response for url {0}: {1}", text5, arg));
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to send guid stats: " + ex.ToString());
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000DB8 RID: 3512 RVA: 0x00037FF0 File Offset: 0x000361F0
		public static Guid CreateGuid()
		{
			UUID.IsOneSystemIdentifierAvailable = false;
			string machineID = UUID.getMachineID(true);
			return new Guid(UUID.GetHash(string.Concat(new string[]
			{
				"CPU >> ",
				UUID.cpuId(),
				"\nBIOS >> ",
				UUID.biosId(),
				"\nBASE >> ",
				UUID.baseId(),
				"\nDISK >> ",
				UUID.getHDDId(),
				"\nMAC >> ",
				UUID.macId(),
				"\nMachineID >> ",
				machineID,
				"\nBLUESTACKS >> ",
				UUID.getBluestacksID()
			})));
		}

		// Token: 0x06000DB9 RID: 3513 RVA: 0x00038094 File Offset: 0x00036294
		public static Guid CreateSystemGuid()
		{
			UUID.IsOneSystemIdentifierAvailable = false;
			string machineID = UUID.getMachineID(RegistryManager.Instance.IsIncludeMachineGUID);
			string text = UUID.Base64Decode(RegistryManager.Instance.Base64GuidString);
			if (!string.IsNullOrEmpty(text) && !string.IsNullOrEmpty(machineID) && text.Contains(machineID))
			{
				return new Guid(UUID.GetHash(text));
			}
			string text2 = string.Concat(new string[]
			{
				"CPU >> ",
				UUID.cpuId(),
				"\nBIOS >> ",
				UUID.biosId(),
				"\nBASE >> ",
				UUID.baseId(),
				"\nDISK >> ",
				UUID.getHDDId(),
				"\nMAC >> ",
				UUID.macId(),
				"\nMachineID >> ",
				machineID,
				"\nBLUESTACKS >> ",
				UUID.getBluestacksID()
			});
			RegistryManager.Instance.Base64GuidString = UUID.Base64Encode(text2);
			string hash = UUID.GetHash(text2);
			if (RegistryManager.Instance.IsFirstTimeCheck)
			{
				Logger.Debug("old system guid :" + RegistryManager.Instance.SystemGuid);
				Logger.Debug("new system guid :" + hash);
				if (string.Equals(hash.ToLower(), RegistryManager.Instance.SystemGuid.ToLower()) && !string.Empty.Equals(machineID))
				{
					RegistryManager.Instance.IsIncludeMachineGUID = true;
				}
				else
				{
					RegistryManager.Instance.IsIncludeMachineGUID = false;
					text2 = string.Concat(new string[]
					{
						"CPU >> ",
						UUID.cpuId(),
						"\nBIOS >> ",
						UUID.biosId(),
						"\nBASE >> ",
						UUID.baseId(),
						"\nDISK >> ",
						UUID.getHDDId(),
						"\nMAC >> ",
						UUID.macId(),
						"\nMachineID >> ",
						string.Empty,
						"\nBLUESTACKS >> ",
						UUID.getBluestacksID()
					});
					RegistryManager.Instance.Base64GuidString = UUID.Base64Encode(text2);
					hash = UUID.GetHash(text2);
				}
			}
			return new Guid(hash);
		}

		// Token: 0x06000DBA RID: 3514 RVA: 0x00009675 File Offset: 0x00007875
		public static string Base64Encode(string plainText)
		{
			return Convert.ToBase64String(Encoding.UTF8.GetBytes(plainText));
		}

		// Token: 0x06000DBB RID: 3515 RVA: 0x0003829C File Offset: 0x0003649C
		public static string Base64Decode(string base64EncodedData)
		{
			byte[] bytes = Convert.FromBase64String(base64EncodedData);
			return Encoding.UTF8.GetString(bytes);
		}

		// Token: 0x06000DBC RID: 3516 RVA: 0x000382BC File Offset: 0x000364BC
		public static string CreateAndGetUniqueGeneratedID(string installId)
		{
			string text = string.Empty;
			try
			{
				Logger.Info("Checking if generated id present in %temp%");
				string environmentVariable = Environment.GetEnvironmentVariable("TEMP");
				Logger.Info("%TEMP% = " + environmentVariable);
				string path = Path.Combine(environmentVariable, "Bst_GeneratedID_Backup");
				if (File.Exists(path))
				{
					string text2 = File.ReadAllText(path);
					if (!string.IsNullOrEmpty(text2))
					{
						text = text2;
						Logger.Info("Detected generated id %temp%: " + text);
					}
					else
					{
						text = installId;
						UUID.BackUpGeneratedID(text);
					}
				}
				else
				{
					text = installId;
					UUID.BackUpGeneratedID(text);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in getting generated id.." + ex.ToString());
			}
			return text;
		}

		// Token: 0x06000DBD RID: 3517 RVA: 0x0003836C File Offset: 0x0003656C
		public static void BackUpGeneratedID(string generatedID)
		{
			try
			{
				StreamWriter streamWriter = new StreamWriter(Path.Combine(Environment.GetEnvironmentVariable("TEMP"), "Bst_GeneratedID_Backup"));
				streamWriter.Write(generatedID);
				streamWriter.Close();
			}
			catch (Exception ex)
			{
				Logger.Error("error in back up generated id.." + ex.ToString());
			}
		}

		// Token: 0x06000DBE RID: 3518 RVA: 0x0000BD67 File Offset: 0x00009F67
		private static string getBluestacksID()
		{
			return "BGP";
		}

		// Token: 0x06000DBF RID: 3519 RVA: 0x0000BD6E File Offset: 0x00009F6E
		private static string GetHash(string s)
		{
			if (UUID.IsOneSystemIdentifierAvailable)
			{
				UUID.CheckPreviousFIPSState();
				return UUID.FormatMD5String(new _MD5
				{
					Value = s
				}.FingerPrint.ToLower());
			}
			throw new UUID.EUUIDLocalOnly();
		}

		// Token: 0x06000DC0 RID: 3520 RVA: 0x000383C8 File Offset: 0x000365C8
		private static void CheckPreviousFIPSState()
		{
			try
			{
				RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Lsa");
				UUID.sPreviousFipsAlgorithmPolicy = (int)registryKey.GetValue("FIPSALGORITHMPOLICY", -1);
				registryKey.Close();
			}
			catch
			{
				UUID.sPreviousFipsAlgorithmPolicy = 0;
			}
			if (UUID.sPreviousFipsAlgorithmPolicy == 1)
			{
				UUID.SetFIPSState(0);
			}
		}

		// Token: 0x06000DC1 RID: 3521 RVA: 0x00038430 File Offset: 0x00036630
		private static void SetFIPSState(int state)
		{
			try
			{
				Logger.Info("Setting FIPS algo policy to " + state + " in registry");
				RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Lsa", true);
				registryKey.SetValue("FIPSALGORITHMPOLICY", state);
				registryKey.Flush();
				registryKey.Close();
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to set FIPS algo policy... Err : " + ex.ToString());
			}
		}

		// Token: 0x06000DC2 RID: 3522 RVA: 0x000384B0 File Offset: 0x000366B0
		private static string FormatMD5String(string s)
		{
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = 0; i < s.Length; i++)
			{
				stringBuilder.Append(s[i]);
				if (i == 7 || i == 11 || i == 15 || i == 19)
				{
					stringBuilder.Append('-');
				}
			}
			return stringBuilder.ToString();
		}

		// Token: 0x06000DC3 RID: 3523 RVA: 0x00038504 File Offset: 0x00036704
		private static string GetHexString(byte[] bt)
		{
			string text = string.Empty;
			for (int i = 0; i < bt.Length; i++)
			{
				byte b = bt[i];
				int num = (int)(b & 15);
				int num2 = b >> 4 & 15;
				if (num2 > 9)
				{
					text += ((char)(num2 - 10 + 65)).ToString();
				}
				else
				{
					text += num2.ToString();
				}
				if (num > 9)
				{
					text += ((char)(num - 10 + 65)).ToString();
				}
				else
				{
					text += num.ToString();
				}
				if (i == 3 || i == 5 || i == 7 || i == 9)
				{
					text += "-";
				}
			}
			return text;
		}

		// Token: 0x06000DC4 RID: 3524 RVA: 0x000385B4 File Offset: 0x000367B4
		private static string identifier(string wmiClass, string wmiProperty, string wmiMustBeTrue)
		{
			string text = "";
			try
			{
				foreach (ManagementBaseObject managementBaseObject in new ManagementClass(wmiClass).GetInstances())
				{
					ManagementObject managementObject = (ManagementObject)managementBaseObject;
					if (managementObject[wmiMustBeTrue].ToString().Equals("True", StringComparison.InvariantCultureIgnoreCase) && text == "")
					{
						try
						{
							text = managementObject[wmiProperty].ToString();
							UUID.IsOneSystemIdentifierAvailable = true;
							break;
						}
						catch
						{
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("exception while getting wmi property: {0} is {1}", new object[]
				{
					wmiProperty,
					ex.ToString()
				});
			}
			return text;
		}

		// Token: 0x06000DC5 RID: 3525 RVA: 0x00038684 File Offset: 0x00036884
		private static string identifier(string wmiClass, string wmiProperty)
		{
			string text = "";
			try
			{
				foreach (ManagementBaseObject managementBaseObject in new ManagementClass(wmiClass).GetInstances())
				{
					ManagementObject managementObject = (ManagementObject)managementBaseObject;
					if (text == "")
					{
						try
						{
							text = managementObject[wmiProperty].ToString();
							UUID.IsOneSystemIdentifierAvailable = true;
							break;
						}
						catch
						{
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("exception while getting wmi property: {0} is {1}", new object[]
				{
					wmiProperty,
					ex.ToString()
				});
			}
			return text;
		}

		// Token: 0x06000DC6 RID: 3526 RVA: 0x0003873C File Offset: 0x0003693C
		private static string cpuId()
		{
			string text = UUID.identifier("Win32_Processor", "UniqueId");
			if (text == "")
			{
				text = UUID.identifier("Win32_Processor", "ProcessorId");
				if (text == "")
				{
					text = UUID.identifier("Win32_Processor", "Name");
					if (text == "")
					{
						text = UUID.identifier("Win32_Processor", "Manufacturer");
					}
					text += UUID.identifier("Win32_Processor", "MaxClockSpeed");
				}
			}
			return text;
		}

		// Token: 0x06000DC7 RID: 3527 RVA: 0x000387C8 File Offset: 0x000369C8
		private static string biosId()
		{
			return string.Concat(new string[]
			{
				UUID.identifier("Win32_BIOS", "Manufacturer"),
				UUID.identifier("Win32_BIOS", "SMBIOSBIOSVersion"),
				UUID.identifier("Win32_BIOS", "IdentificationCode"),
				UUID.identifier("Win32_BIOS", "SerialNumber"),
				UUID.identifier("Win32_BIOS", "ReleaseDate"),
				UUID.identifier("Win32_BIOS", "Version")
			});
		}

		// Token: 0x06000DC8 RID: 3528 RVA: 0x0003884C File Offset: 0x00036A4C
		private static string biosIdWithSeparator()
		{
			return string.Concat(new string[]
			{
				UUID.identifier("Win32_BIOS", "Manufacturer"),
				"##",
				UUID.identifier("Win32_BIOS", "SMBIOSBIOSVersion"),
				"##",
				UUID.identifier("Win32_BIOS", "IdentificationCode"),
				"##",
				UUID.identifier("Win32_BIOS", "SerialNumber"),
				"##",
				UUID.identifier("Win32_BIOS", "ReleaseDate"),
				"##",
				UUID.identifier("Win32_BIOS", "Version")
			});
		}

		// Token: 0x06000DC9 RID: 3529 RVA: 0x000388FC File Offset: 0x00036AFC
		private static string diskId()
		{
			return UUID.identifier("Win32_DiskDrive", "Model") + UUID.identifier("Win32_DiskDrive", "Manufacturer") + UUID.identifier("Win32_DiskDrive", "Signature") + UUID.identifier("Win32_DiskDrive", "TotalHeads");
		}

		// Token: 0x06000DCA RID: 3530 RVA: 0x0003894C File Offset: 0x00036B4C
		private static string baseId()
		{
			return UUID.identifier("Win32_BaseBoard", "Model") + UUID.identifier("Win32_BaseBoard", "Manufacturer") + UUID.identifier("Win32_BaseBoard", "Name") + UUID.identifier("Win32_BaseBoard", "SerialNumber");
		}

		// Token: 0x06000DCB RID: 3531 RVA: 0x0003899C File Offset: 0x00036B9C
		private static string baseIdWithSeparator()
		{
			return string.Concat(new string[]
			{
				UUID.identifier("Win32_BaseBoard", "Model"),
				"##",
				UUID.identifier("Win32_BaseBoard", "Manufacturer"),
				"##",
				UUID.identifier("Win32_BaseBoard", "Name"),
				"##",
				UUID.identifier("Win32_BaseBoard", "SerialNumber")
			});
		}

		// Token: 0x06000DCC RID: 3532 RVA: 0x0000BD9D File Offset: 0x00009F9D
		private static string videoId()
		{
			return UUID.identifier("Win32_VideoController", "DriverVersion") + UUID.identifier("Win32_VideoController", "Name");
		}

		// Token: 0x06000DCD RID: 3533 RVA: 0x0000BDC2 File Offset: 0x00009FC2
		private static string macId()
		{
			return UUID.identifier("Win32_NetworkAdapterConfiguration", "MACAddress", "IPEnabled");
		}

		// Token: 0x06000DCE RID: 3534 RVA: 0x00038A14 File Offset: 0x00036C14
		public static string getMachineID(bool isIncludeMachineGUID)
		{
			string result = string.Empty;
			try
			{
				if (isIncludeMachineGUID)
				{
					RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Cryptography");
					if (registryKey != null)
					{
						result = (string)registryKey.GetValue("MachineGuid", string.Empty);
						UUID.IsOneSystemIdentifierAvailable = true;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error while getting machine guid value from registry.." + ex.ToString());
			}
			return result;
		}

		// Token: 0x06000DCF RID: 3535 RVA: 0x00038A84 File Offset: 0x00036C84
		public static string getMachineID32or64()
		{
			string result = string.Empty;
			try
			{
				RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Cryptography");
				if (registryKey != null)
				{
					result = (string)registryKey.GetValue("MachineGuid", string.Empty);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error while getting machine guid value from registry.." + ex.ToString());
			}
			return result;
		}

		// Token: 0x06000DD0 RID: 3536 RVA: 0x00038AEC File Offset: 0x00036CEC
		public static string getHDDId()
		{
			string text = string.Empty;
			try
			{
				string str = "C";
				ManagementObject managementObject = new ManagementObject("win32_logicaldisk.deviceid=\"" + str + ":\"");
				managementObject.Get();
				text = managementObject["VolumeSerialNumber"].ToString();
				if (!string.IsNullOrEmpty(text))
				{
					UUID.IsOneSystemIdentifierAvailable = true;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("error while getting HDD serial number.." + ex.ToString());
			}
			return text;
		}

		// Token: 0x06000DD1 RID: 3537 RVA: 0x00038B6C File Offset: 0x00036D6C
		public static string GetMACAddressWinAPI()
		{
			string text = string.Empty;
			try
			{
				foreach (NetworkInterface networkInterface in NetworkInterface.GetAllNetworkInterfaces())
				{
					if (text == string.Empty)
					{
						text = networkInterface.GetPhysicalAddress().ToString();
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in getting mac address from winAPI.." + ex.ToString());
			}
			return text;
		}

		// Token: 0x06000DD2 RID: 3538 RVA: 0x00038BE0 File Offset: 0x00036DE0
		private static string GetMACAddress()
		{
			List<string> list = new List<string>();
			try
			{
				ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_NetworkAdapter");
				string empty = string.Empty;
				foreach (ManagementBaseObject managementBaseObject in managementObjectSearcher.Get())
				{
					ManagementObject managementObject = (ManagementObject)managementBaseObject;
					if (managementObject["PNPDeviceID"] != null && managementObject["PNPDeviceID"].ToString().Contains("PCI") && managementObject["Name"] != null)
					{
						list.Add(managementObject["Name"].ToString());
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("error in get name of physical network adapters :" + ex.ToString());
			}
			if (list.Count == 0)
			{
				return string.Empty;
			}
			string result = string.Empty;
			try
			{
				NetworkInterface[] allNetworkInterfaces = NetworkInterface.GetAllNetworkInterfaces();
				List<long> list2 = new List<long>();
				List<long> list3 = new List<long>();
				foreach (NetworkInterface networkInterface in allNetworkInterfaces)
				{
					if (list.Contains(networkInterface.Description))
					{
						if (networkInterface.NetworkInterfaceType == NetworkInterfaceType.Ethernet)
						{
							string text = networkInterface.GetPhysicalAddress().ToString();
							if (!string.IsNullOrEmpty(text))
							{
								list2.Add(long.Parse(text, NumberStyles.HexNumber));
							}
						}
						else if (networkInterface.NetworkInterfaceType == NetworkInterfaceType.Wireless80211)
						{
							string text2 = networkInterface.GetPhysicalAddress().ToString();
							if (!string.IsNullOrEmpty(text2))
							{
								list3.Add(long.Parse(text2, NumberStyles.HexNumber));
							}
						}
					}
				}
				if (list2.Count > 0)
				{
					result = list2.Min().ToString("X");
				}
				else if (list3.Count > 0)
				{
					result = list3.Min().ToString("X");
				}
			}
			catch (Exception ex2)
			{
				Logger.Error("Exception in getting mac address of physical network adapters.." + ex2.ToString());
			}
			return result;
		}

		// Token: 0x06000DD3 RID: 3539 RVA: 0x00038DE4 File Offset: 0x00036FE4
		public static string GetVolumeSerialNumberSystemDriveWithoutWMI()
		{
			string result = string.Empty;
			try
			{
				string pathRoot = Path.GetPathRoot(Environment.SystemDirectory);
				uint num = 0U;
				uint num2 = 0U;
				StringBuilder stringBuilder = new StringBuilder(256);
				uint num3 = 0U;
				StringBuilder stringBuilder2 = new StringBuilder(256);
				if (UUID.GetVolumeInformation(pathRoot, stringBuilder, (uint)stringBuilder.Capacity, ref num, ref num2, ref num3, stringBuilder2, (uint)stringBuilder2.Capacity) != 0L)
				{
					result = string.Format("{0:X}", num);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in getting volume serial number of system drive.." + ex.ToString());
			}
			return result;
		}

		// Token: 0x06000DD4 RID: 3540 RVA: 0x00038E7C File Offset: 0x0003707C
		public static string GetHDDSerialNumber(out string model)
		{
			string result = string.Empty;
			model = string.Empty;
			string indexOfSystemDrive = UUID.GetIndexOfSystemDrive();
			try
			{
				foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive").Get())
				{
					ManagementObject managementObject = (ManagementObject)managementBaseObject;
					if (string.Equals(managementObject["index"].ToString().ToLower(), indexOfSystemDrive.ToLower()))
					{
						if (managementObject["SerialNumber"] != null)
						{
							result = managementObject["SerialNumber"].ToString();
						}
						if (managementObject["Model"] != null)
						{
							model = managementObject["Model"].ToString();
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in win 32 disk drive.." + ex.ToString());
			}
			return result;
		}

		// Token: 0x06000DD5 RID: 3541 RVA: 0x00038F6C File Offset: 0x0003716C
		public static string GetIndexOfSystemDrive()
		{
			string result = "0";
			try
			{
				string str = Path.GetPathRoot(Environment.SystemDirectory).TrimEnd(new char[]
				{
					'\\'
				});
				using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("ASSOCIATORS OF {Win32_LogicalDisk.DeviceID='" + str + "'} WHERE ResultClass=Win32_DiskPartition"))
				{
					foreach (ManagementBaseObject managementBaseObject in managementObjectSearcher.Get())
					{
						using (ManagementObjectSearcher managementObjectSearcher2 = new ManagementObjectSearcher("ASSOCIATORS OF {Win32_DiskPartition.DeviceID='" + managementBaseObject["DeviceID"] + "'} WHERE ResultClass=Win32_DiskDrive"))
						{
							foreach (ManagementBaseObject managementBaseObject2 in managementObjectSearcher2.Get())
							{
								if (managementBaseObject2["Index"] != null)
								{
									result = managementBaseObject2["Index"].ToString();
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("exception in get index of system drive..." + ex.ToString());
			}
			return result;
		}

		// Token: 0x06000DD6 RID: 3542 RVA: 0x000390CC File Offset: 0x000372CC
		private static RegistryKey _openSubKey(RegistryKey parentKey, string subKeyName, bool writable, UUID.RegWow64Options options)
		{
			if (parentKey == null || UUID._getRegistryKeyHandle(parentKey) == IntPtr.Zero)
			{
				return null;
			}
			int num = 131097;
			if (writable)
			{
				num = 131078;
			}
			int value;
			if (UUID.RegOpenKeyEx(UUID._getRegistryKeyHandle(parentKey), subKeyName, 0, num | (int)options, out value) != 0)
			{
				return null;
			}
			return UUID._pointerToRegistryKey((IntPtr)value, writable, false);
		}

		// Token: 0x06000DD7 RID: 3543 RVA: 0x0000BDD8 File Offset: 0x00009FD8
		private static IntPtr _getRegistryKeyHandle(RegistryKey registryKey)
		{
			return ((SafeHandle)typeof(RegistryKey).GetField("hkey", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(registryKey)).DangerousGetHandle();
		}

		// Token: 0x06000DD8 RID: 3544 RVA: 0x00039124 File Offset: 0x00037324
		private static RegistryKey _pointerToRegistryKey(IntPtr hKey, bool writable, bool ownsHandle)
		{
			BindingFlags bindingAttr = BindingFlags.Instance | BindingFlags.NonPublic;
			Type type = typeof(SafeHandleZeroOrMinusOneIsInvalid).Assembly.GetType("Microsoft.Win32.SafeHandles.SafeRegistryHandle");
			Type[] types = new Type[]
			{
				typeof(IntPtr),
				typeof(bool)
			};
			object obj = type.GetConstructor(bindingAttr, null, types, null).Invoke(new object[]
			{
				hKey,
				ownsHandle
			});
			Type typeFromHandle = typeof(RegistryKey);
			Type[] types2 = new Type[]
			{
				type,
				typeof(bool)
			};
			return (RegistryKey)typeFromHandle.GetConstructor(bindingAttr, null, types2, null).Invoke(new object[]
			{
				obj,
				writable
			});
		}

		// Token: 0x06000DD9 RID: 3545
		[DllImport("advapi32.dll", CharSet = CharSet.Auto)]
		public static extern int RegOpenKeyEx(IntPtr hKey, string subKey, int ulOptions, int samDesired, out int phkResult);

		// Token: 0x04000BA2 RID: 2978
		private const long RPC_S_OK = 0L;

		// Token: 0x04000BA3 RID: 2979
		private const long RPC_S_UUID_LOCAL_ONLY = 1824L;

		// Token: 0x04000BA4 RID: 2980
		private const long RPC_S_UUID_NO_ADDRESS = 1739L;

		// Token: 0x04000BA5 RID: 2981
		private static bool IsOneSystemIdentifierAvailable;

		// Token: 0x04000BA6 RID: 2982
		private static int sPreviousFipsAlgorithmPolicy = -1;

		// Token: 0x020001BC RID: 444
		public class EUUID : Exception
		{
			// Token: 0x06000DDC RID: 3548 RVA: 0x0000233F File Offset: 0x0000053F
			public EUUID()
			{
			}

			// Token: 0x06000DDD RID: 3549 RVA: 0x00002FD6 File Offset: 0x000011D6
			public EUUID(string reason) : base(reason)
			{
			}
		}

		// Token: 0x020001BD RID: 445
		public class EUUIDLocalOnly : UUID.EUUID
		{
		}

		// Token: 0x020001BE RID: 446
		public class EUUIDNoAddress : UUID.EUUID
		{
		}

		// Token: 0x020001BF RID: 447
		public enum UUIDTYPE
		{
			// Token: 0x04000BA8 RID: 2984
			GLOBAL,
			// Token: 0x04000BA9 RID: 2985
			LOCAL
		}

		// Token: 0x020001C0 RID: 448
		private enum RegWow64Options
		{
			// Token: 0x04000BAB RID: 2987
			None,
			// Token: 0x04000BAC RID: 2988
			KEY_WOW64_64KEY = 256,
			// Token: 0x04000BAD RID: 2989
			KEY_WOW64_32KEY = 512
		}

		// Token: 0x020001C1 RID: 449
		private enum RegistryRights
		{
			// Token: 0x04000BAF RID: 2991
			ReadKey = 131097,
			// Token: 0x04000BB0 RID: 2992
			WriteKey = 131078
		}
	}
}
