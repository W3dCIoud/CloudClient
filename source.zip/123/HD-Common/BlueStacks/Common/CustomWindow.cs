﻿using System;
using System.Windows;
using System.Windows.Interop;

namespace BlueStacks.Common
{
	// Token: 0x02000181 RID: 385
	public class CustomWindow : Window
	{
		// Token: 0x170002ED RID: 749
		// (get) Token: 0x06000C4B RID: 3147 RVA: 0x0000B195 File Offset: 0x00009395
		// (set) Token: 0x06000C4C RID: 3148 RVA: 0x0000B19D File Offset: 0x0000939D
		public virtual bool ShowWithParentWindow
		{
			get
			{
				return this.mShowWithParentWindow;
			}
			set
			{
				this.mShowWithParentWindow = value;
			}
		}

		// Token: 0x170002EE RID: 750
		// (get) Token: 0x06000C4D RID: 3149 RVA: 0x0000B1A6 File Offset: 0x000093A6
		// (set) Token: 0x06000C4E RID: 3150 RVA: 0x0000B1AE File Offset: 0x000093AE
		public bool IsShowGLWindow { get; set; }

		// Token: 0x06000C4F RID: 3151 RVA: 0x0000B1B7 File Offset: 0x000093B7
		public CustomWindow()
		{
			this.SetWindowTitle();
			base.SourceInitialized += this.CustomWindow_SourceInitialized;
		}

		// Token: 0x06000C50 RID: 3152 RVA: 0x0000B1D7 File Offset: 0x000093D7
		private void SetWindowTitle()
		{
			base.Title = base.GetType().Name;
		}

		// Token: 0x06000C51 RID: 3153 RVA: 0x0000480A File Offset: 0x00002A0A
		private void CustomWindow_SourceInitialized(object sender, EventArgs e)
		{
			RenderHelper.ChangeRenderModeToSoftware(sender);
		}

		// Token: 0x06000C52 RID: 3154 RVA: 0x00034780 File Offset: 0x00032980
		protected override void OnSourceInitialized(EventArgs e)
		{
			base.OnSourceInitialized(e);
			HwndSource hwndSource = PresentationSource.FromVisual(this) as HwndSource;
			if (hwndSource != null)
			{
				hwndSource.AddHook(new HwndSourceHook(CustomWindow.WndProc));
			}
		}

		// Token: 0x06000C53 RID: 3155 RVA: 0x000347B8 File Offset: 0x000329B8
		private static IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
		{
			if (msg == 260 && (wParam == (IntPtr)18 || wParam == (IntPtr)121))
			{
				handled = true;
			}
			if (msg == 262 && wParam == (IntPtr)32)
			{
				handled = true;
			}
			return IntPtr.Zero;
		}

		// Token: 0x040008A5 RID: 2213
		private bool mShowWithParentWindow;
	}
}
