﻿using System;
using System.Collections.Generic;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000146 RID: 326
	public class HttpHandlerSetup
	{
		// Token: 0x06000CBC RID: 3260 RVA: 0x00054F18 File Offset: 0x00053118
		public static void InitHTTPServer(Dictionary<string, HTTPServer.RequestHandler> routes, string homeDir)
		{
			int num = 2871;
			int maxPort = num + 10;
			HttpHandlerSetup.Server = HTTPUtils.SetupServer(num, maxPort, routes, string.Empty);
			RegistryManager.Instance.PartnerServerPort = HttpHandlerSetup.Server.Port;
			HttpHandlerSetup.Server.Run();
		}

		// Token: 0x0400092D RID: 2349
		public static HTTPServer Server;
	}
}
