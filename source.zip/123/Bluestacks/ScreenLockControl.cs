﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200006C RID: 108
	public class ScreenLockControl : UserControl, IDimOverlayControl, IComponentConnector
	{
		// Token: 0x060004AA RID: 1194 RVA: 0x0000514E File Offset: 0x0000334E
		public ScreenLockControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x17000138 RID: 312
		// (get) Token: 0x060004AB RID: 1195 RVA: 0x00004D85 File Offset: 0x00002F85
		// (set) Token: 0x060004AC RID: 1196 RVA: 0x00004BF2 File Offset: 0x00002DF2
		bool IDimOverlayControl.IsCloseOnOverLayClick
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		// Token: 0x17000139 RID: 313
		// (get) Token: 0x060004AD RID: 1197 RVA: 0x0000515C File Offset: 0x0000335C
		// (set) Token: 0x060004AE RID: 1198 RVA: 0x00005164 File Offset: 0x00003364
		public bool ShowControlInSeparateWindow
		{
			get
			{
				return this.mShowControlInSeparateWindow;
			}
			set
			{
				this.mShowControlInSeparateWindow = value;
			}
		}

		// Token: 0x060004AF RID: 1199 RVA: 0x0000516D File Offset: 0x0000336D
		public bool Close()
		{
			base.Visibility = Visibility.Hidden;
			return true;
		}

		// Token: 0x060004B0 RID: 1200 RVA: 0x00004DA3 File Offset: 0x00002FA3
		public bool Show()
		{
			base.Visibility = Visibility.Visible;
			return true;
		}

		// Token: 0x060004B1 RID: 1201 RVA: 0x0001F4DC File Offset: 0x0001D6DC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/screenlockcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060004B2 RID: 1202 RVA: 0x00005177 File Offset: 0x00003377
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mScreenLockImage = (CustomPictureBox)target;
				return;
			}
			if (connectionId != 2)
			{
				this._contentLoaded = true;
				return;
			}
			this.mScreenLockText = (TextBlock)target;
		}

		// Token: 0x040002D1 RID: 721
		private bool mShowControlInSeparateWindow;

		// Token: 0x040002D2 RID: 722
		internal CustomPictureBox mScreenLockImage;

		// Token: 0x040002D3 RID: 723
		internal TextBlock mScreenLockText;

		// Token: 0x040002D4 RID: 724
		private bool _contentLoaded;
	}
}
