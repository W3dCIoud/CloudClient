﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000EB RID: 235
	public class SchemeComboBox : UserControl, IComponentConnector
	{
		// Token: 0x17000179 RID: 377
		// (get) Token: 0x060009F2 RID: 2546 RVA: 0x000082BE File Offset: 0x000064BE
		// (set) Token: 0x060009F3 RID: 2547 RVA: 0x000082C6 File Offset: 0x000064C6
		public string SelectedItem
		{
			get
			{
				return this.mSelectedItem;
			}
			set
			{
				this.mSelectedItem = value;
			}
		}

		// Token: 0x060009F4 RID: 2548 RVA: 0x000082CF File Offset: 0x000064CF
		public SchemeComboBox()
		{
			this.InitializeComponent();
		}

		// Token: 0x060009F5 RID: 2549 RVA: 0x000082DD File Offset: 0x000064DD
		private void OnRequestBringIntoView(object sender, RequestBringIntoViewEventArgs e)
		{
			if (Keyboard.IsKeyDown(Key.Down) || Keyboard.IsKeyDown(Key.Up))
			{
				return;
			}
			e.Handled = true;
		}

		// Token: 0x060009F6 RID: 2550 RVA: 0x0000553B File Offset: 0x0000373B
		private void ComboBoxItem_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x060009F7 RID: 2551 RVA: 0x000082F9 File Offset: 0x000064F9
		private void ComboBoxItem_Selected(object sender, RoutedEventArgs e)
		{
			((ComboBoxSchemeControl)sender).mBookmarkImg.Visibility = Visibility.Collapsed;
		}

		// Token: 0x060009F8 RID: 2552 RVA: 0x0000830C File Offset: 0x0000650C
		private void Grid_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			this.mItems.IsOpen = !this.mItems.IsOpen;
			e.Handled = true;
		}

		// Token: 0x060009F9 RID: 2553 RVA: 0x0000832E File Offset: 0x0000652E
		private void NewProfile_MouseDown(object sender, MouseButtonEventArgs e)
		{
			KMManager.AddNewControlSchemeAndSelect(null);
			KMManager.CanvasWindow.ClearWindow();
		}

		// Token: 0x060009FA RID: 2554 RVA: 0x000467E8 File Offset: 0x000449E8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/schemecombobox.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060009FB RID: 2555 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060009FC RID: 2556 RVA: 0x00046818 File Offset: 0x00044A18
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this._this = (SchemeComboBox)target;
				return;
			case 2:
				this.mGrid = (Grid)target;
				return;
			case 3:
				this.mBorder = (Border)target;
				return;
			case 4:
				((Grid)target).PreviewMouseUp += this.Grid_PreviewMouseDown;
				return;
			case 5:
				this.mName = (TextBlock)target;
				return;
			case 6:
				this.Arrow = (Path)target;
				return;
			case 7:
				this.mItems = (CustomPopUp)target;
				return;
			case 8:
				this.mSchemesListScrollbar = (ScrollViewer)target;
				return;
			case 9:
				this.Items = (StackPanel)target;
				return;
			case 10:
				this.NewProfile = (Grid)target;
				this.NewProfile.MouseDown += this.NewProfile_MouseDown;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400073B RID: 1851
		public string mSelectedItem;

		// Token: 0x0400073C RID: 1852
		public static readonly DependencyProperty SelectedItemProperty = DependencyProperty.Register("SelectedItem", typeof(string), typeof(ComboBoxSchemeControl), new UIPropertyMetadata(string.Empty));

		// Token: 0x0400073D RID: 1853
		internal SchemeComboBox _this;

		// Token: 0x0400073E RID: 1854
		internal Grid mGrid;

		// Token: 0x0400073F RID: 1855
		internal Border mBorder;

		// Token: 0x04000740 RID: 1856
		internal TextBlock mName;

		// Token: 0x04000741 RID: 1857
		internal Path Arrow;

		// Token: 0x04000742 RID: 1858
		internal CustomPopUp mItems;

		// Token: 0x04000743 RID: 1859
		internal ScrollViewer mSchemesListScrollbar;

		// Token: 0x04000744 RID: 1860
		internal StackPanel Items;

		// Token: 0x04000745 RID: 1861
		internal Grid NewProfile;

		// Token: 0x04000746 RID: 1862
		private bool _contentLoaded;
	}
}
