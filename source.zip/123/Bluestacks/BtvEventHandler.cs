﻿using System;
using System.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200004C RID: 76
	public class BtvEventHandler
	{
		// Token: 0x0600036A RID: 874 RVA: 0x00004490 File Offset: 0x00002690
		internal static void WindowEvent(string topic, string data)
		{
			if (topic == "ShowWebPage")
			{
				BtvEventHandler.showWebPage(topic, data);
			}
		}

		// Token: 0x0600036B RID: 875 RVA: 0x00018F84 File Offset: 0x00017184
		private static void showWebPage(string title, string webUrl)
		{
			MainWindow activatedWindow = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				activatedWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			activatedWindow.Dispatcher.Invoke(new Action(delegate()
			{
				activatedWindow.mTopBar.mAppTabButtons.AddWebTab(webUrl, title, null, true, "", false);
			}), new object[0]);
		}
	}
}
