﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000DD RID: 221
	public class CanvasElement : UserControl, IComponentConnector
	{
		// Token: 0x17000172 RID: 370
		// (get) Token: 0x06000938 RID: 2360 RVA: 0x00007BAC File Offset: 0x00005DAC
		public List<IMAction> lstActionItem
		{
			get
			{
				return this.mLstAction;
			}
		}

		// Token: 0x17000173 RID: 371
		// (get) Token: 0x06000939 RID: 2361 RVA: 0x00007BB4 File Offset: 0x00005DB4
		// (set) Token: 0x0600093A RID: 2362 RVA: 0x00007BBC File Offset: 0x00005DBC
		public KeyActionType ActionType
		{
			get
			{
				return this.mType;
			}
			set
			{
				this.mType = value;
				this.SetActiveImage(false);
			}
		}

		// Token: 0x17000174 RID: 372
		// (get) Token: 0x0600093B RID: 2363 RVA: 0x00007BCC File Offset: 0x00005DCC
		// (set) Token: 0x0600093C RID: 2364 RVA: 0x00007BD4 File Offset: 0x00005DD4
		public bool IsRemoveIfEmpty { get; internal set; }

		// Token: 0x0600093D RID: 2365 RVA: 0x0003DFA4 File Offset: 0x0003C1A4
		public CanvasElement(KeymapCanvasWindow window, MainWindow parentWindow)
		{
			this.mParentWindow = window;
			this.ParentWindow = parentWindow;
			this.InitializeComponent();
		}

		// Token: 0x0600093E RID: 2366 RVA: 0x0003E008 File Offset: 0x0003C208
		internal void AddAction(IMAction action)
		{
			this.mLstAction.Add(action);
			this.ActionType = (KeyActionType)Enum.Parse(typeof(KeyActionType), action.GetType().ToString());
			this.SetKeysForActions(this.mLstAction);
			this.SetSize(action);
			this.SetElementLayout(true);
		}

		// Token: 0x0600093F RID: 2367 RVA: 0x0003E060 File Offset: 0x0003C260
		private void SetKeysForActions(List<IMAction> lst)
		{
			foreach (KeyValuePair<Positions, Tuple<string, TextBox, TextBlock, List<IMAction>>> keyValuePair in this.dictTextElemets)
			{
				keyValuePair.Value.Item3.Visibility = Visibility.Collapsed;
			}
			foreach (IMAction keysForAction in lst)
			{
				this.SetKeysForAction(keysForAction);
			}
		}

		// Token: 0x06000940 RID: 2368 RVA: 0x0003E0FC File Offset: 0x0003C2FC
		private void SetKeysForAction(IMAction action)
		{
			KeyActionType type = action.Type;
			switch (type)
			{
			case KeyActionType.Tap:
				this.SetKeys(action, "Key", "", "", "", "");
				return;
			case KeyActionType.Swipe:
				this.mColumn0.Width = new GridLength(0.0, GridUnitType.Star);
				this.mColumn1.Width = new GridLength(30.0, GridUnitType.Star);
				this.mColumn2.Width = new GridLength(40.0, GridUnitType.Star);
				this.mColumn3.Width = new GridLength(30.0, GridUnitType.Star);
				this.mColumn4.Width = new GridLength(0.0, GridUnitType.Star);
				this.mRow0.Height = new GridLength(5.0, GridUnitType.Star);
				this.mRow1.Height = new GridLength(20.0, GridUnitType.Star);
				this.mRow2.Height = new GridLength(50.0, GridUnitType.Star);
				this.mRow3.Height = new GridLength(20.0, GridUnitType.Star);
				this.mRow4.Height = new GridLength(5.0, GridUnitType.Star);
				if (action.Direction == Direction.Left)
				{
					this.SetKeys(action, "", "Key", "", "", "");
					return;
				}
				if (action.Direction == Direction.Right)
				{
					this.SetKeys(action, "", "", "", "Key", "");
					return;
				}
				if (action.Direction == Direction.Up)
				{
					this.SetKeys(action, "", "", "Key", "", "");
					return;
				}
				if (action.Direction == Direction.Down)
				{
					this.SetKeys(action, "", "", "", "", "Key");
					return;
				}
				break;
			case KeyActionType.Dpad:
				this.mColumn0.Width = new GridLength(10.0, GridUnitType.Star);
				this.mColumn1.Width = new GridLength(30.0, GridUnitType.Star);
				this.mColumn2.Width = new GridLength(20.0, GridUnitType.Star);
				this.mColumn3.Width = new GridLength(30.0, GridUnitType.Star);
				this.mColumn4.Width = new GridLength(10.0, GridUnitType.Star);
				this.mRow0.Height = new GridLength(15.0, GridUnitType.Star);
				this.mRow1.Height = new GridLength(20.0, GridUnitType.Star);
				this.mRow2.Height = new GridLength(30.0, GridUnitType.Star);
				this.mRow3.Height = new GridLength(20.0, GridUnitType.Star);
				this.mRow4.Height = new GridLength(15.0, GridUnitType.Star);
				this.SetKeys(action, "", "KeyLeft", "KeyUp", "KeyRight", "KeyDown");
				return;
			case KeyActionType.Zoom:
				this.mColumn0.Width = new GridLength(6.0, GridUnitType.Star);
				this.mColumn1.Width = new GridLength(72.0);
				this.mColumn2.Width = new GridLength(70.0, GridUnitType.Star);
				this.mColumn3.Width = new GridLength(30.0);
				this.mColumn4.Width = new GridLength(6.0, GridUnitType.Star);
				this.mRow0.Height = new GridLength(80.0, GridUnitType.Star);
				this.mRow1.Height = new GridLength(35.0);
				this.mRow2.Height = new GridLength(35.0);
				this.mRow3.Height = new GridLength(0.0);
				this.mRow4.Height = new GridLength(80.0, GridUnitType.Star);
				this.SetKeys(action, "", "KeyOut", "KeyIn", "", "");
				return;
			case KeyActionType.Tilt:
				this.mColumn0.Width = new GridLength(0.0, GridUnitType.Star);
				this.mColumn1.Width = new GridLength(30.0, GridUnitType.Star);
				this.mColumn2.Width = new GridLength(40.0, GridUnitType.Star);
				this.mColumn3.Width = new GridLength(30.0, GridUnitType.Star);
				this.mColumn4.Width = new GridLength(0.0, GridUnitType.Star);
				this.mRow0.Height = new GridLength(5.0, GridUnitType.Star);
				this.mRow1.Height = new GridLength(20.0, GridUnitType.Star);
				this.mRow2.Height = new GridLength(50.0, GridUnitType.Star);
				this.mRow3.Height = new GridLength(20.0, GridUnitType.Star);
				this.mRow4.Height = new GridLength(5.0, GridUnitType.Star);
				this.SetKeys(action, "", "KeyLeft", "KeyUp", "KeyRight", "KeyDown");
				return;
			case KeyActionType.Pan:
			{
				Pan pan = action as Pan;
				this.SetKeys(action, "KeyStartStop", "", "", "", "");
				if (this.mParentWindow.dictCanvasElement.ContainsKey(action) && pan.IsLookAroundEnabled && this.mParentWindow.dictCanvasElement.ContainsKey(pan.mLookAround))
				{
					this.mParentWindow.dictCanvasElement[pan.mLookAround].SetKeysForAction(pan.mLookAround);
					return;
				}
				break;
			}
			case KeyActionType.MOBADpad:
				this.SetKeys(action, "", "", "", "", "");
				return;
			case KeyActionType.MOBASkill:
			{
				MOBASkill mobaskill = action as MOBASkill;
				this.SetKeys(action, "KeyActivate", "", "", "", "");
				if (this.mParentWindow.dictCanvasElement.ContainsKey(action) && mobaskill.IsCancelSkillEnabled && this.mParentWindow.dictCanvasElement.ContainsKey(mobaskill.mMOBASkillCancel))
				{
					this.mParentWindow.dictCanvasElement[mobaskill.mMOBASkillCancel].SetKeysForAction(mobaskill.mMOBASkillCancel);
					return;
				}
				break;
			}
			case KeyActionType.Raw:
			case KeyActionType.KeyInput:
			case KeyActionType.SendOriginalKeys:
			case KeyActionType.Rotate:
				break;
			case KeyActionType.Script:
				this.SetKeys(action, "Key", "", "", "", "");
				break;
			case KeyActionType.TapRepeat:
				this.mRow1.Height = new GridLength(0.0);
				this.mRow2.Height = new GridLength(30.0, GridUnitType.Star);
				this.mRow3.Height = new GridLength(4.0, GridUnitType.Star);
				this.mCountText.Text = ((TapRepeat)action).Count.ToString();
				this.mKeyRepeatGrid.Visibility = Visibility.Visible;
				this.SetToggleModeValues(action);
				this.SetKeys(action, "Key", "", "", "", "");
				return;
			case KeyActionType.State:
				if (KMManager.sIsDeveloperModeOn)
				{
					this.SetKeys(action, "Key", "", "", "", "");
					return;
				}
				break;
			case KeyActionType.FreeLook:
				this.SetToggleModeValues(action);
				return;
			default:
				switch (type)
				{
				case KeyActionType.LookAround:
					this.SetKeys(action, "Key", "", "", "", "");
					return;
				case KeyActionType.PanShoot:
					if (this.mParentWindow.IsInOverlayMode)
					{
						this.SetKeys(action, "Key", "", "", "", "");
						return;
					}
					break;
				case KeyActionType.MOBASkillCancel:
					this.SetKeys(action, "Key", "", "", "", "");
					return;
				default:
					return;
				}
				break;
			}
		}

		// Token: 0x06000941 RID: 2369 RVA: 0x0003E934 File Offset: 0x0003CB34
		internal void SetToggleModeValues(IMAction action)
		{
			this.mToggleModeGrid.Visibility = Visibility.Visible;
			KeyActionType type = action.Type;
			if (type != KeyActionType.TapRepeat)
			{
				if (type != KeyActionType.FreeLook)
				{
					return;
				}
				BlueStacksUIBinding.Bind(this.mToggleMode1, "STRING_KEYBOARD_MODE", "");
				BlueStacksUIBinding.Bind(this.mToggleMode2, "STRING_MOUSE_MODE", "");
				if (((FreeLook)action).DeviceType == 0)
				{
					base.MinHeight = 190.0;
					this.mToggleImage.ImageName = "left_switch";
					this.mColumn0.Width = new GridLength(0.0);
					this.mColumn1.Width = new GridLength(25.0, GridUnitType.Star);
					this.mColumn2.Width = new GridLength(40.0, GridUnitType.Star);
					this.mColumn3.Width = new GridLength(25.0, GridUnitType.Star);
					this.mColumn4.Width = new GridLength(0.0);
					this.mRow0.Height = new GridLength(10.0, GridUnitType.Star);
					this.mRow1.Height = new GridLength(25.0, GridUnitType.Star);
					this.mRow2.Height = new GridLength(30.0, GridUnitType.Star);
					this.mRow3.Height = new GridLength(25.0, GridUnitType.Star);
					this.mRow4.Height = new GridLength(10.0, GridUnitType.Star);
					this.SetKeys(action, "", "KeyLeft", "KeyUp", "KeyRight", "KeyDown");
				}
				else if (((FreeLook)action).DeviceType == 1)
				{
					base.MinHeight = 94.0;
					this.mToggleImage.ImageName = "right_switch";
					this.SetKeys(action, "Key", "", "", "", "");
				}
				this.SetActiveImage(true);
				return;
			}
			else
			{
				base.MinHeight = 92.0;
				BlueStacksUIBinding.Bind(this.mToggleMode1, "STRING_TAP_MODE", "");
				BlueStacksUIBinding.Bind(this.mToggleMode2, "STRING_LONG_PRESS_MODE", "");
				if (((TapRepeat)action).RepeatUntilKeyUp)
				{
					this.mToggleImage.ImageName = "right_switch";
					return;
				}
				this.mToggleImage.ImageName = "left_switch";
				return;
			}
		}

		// Token: 0x06000942 RID: 2370 RVA: 0x0003EB98 File Offset: 0x0003CD98
		private void InsertScriptSettingsClickGrid()
		{
			Grid grid = new Grid();
			grid.Height = 15.0;
			grid.Width = 15.0;
			grid.HorizontalAlignment = HorizontalAlignment.Center;
			grid.VerticalAlignment = VerticalAlignment.Bottom;
			grid.Margin = new Thickness(30.0, 0.0, 0.0, 3.0);
			grid.Background = Brushes.Black;
			grid.Opacity = 0.0001;
			Grid.SetRow(grid, 3);
			Grid.SetRowSpan(grid, 2);
			Grid.SetColumn(grid, 3);
			grid.PreviewMouseLeftButtonUp += this.ScriptSettingsGrid_MouseLeftButtonUp;
			grid.MouseEnter += this.ScriptSettingsGrid_MouseEnter;
			grid.MouseLeave += this.ScriptSettingsGrid_MouseLeave;
			this.mGrid.Children.Add(grid);
		}

		// Token: 0x06000943 RID: 2371 RVA: 0x0003EC80 File Offset: 0x0003CE80
		private void ScriptSettingsGrid_MouseLeave(object sender, MouseEventArgs e)
		{
			string str = this.ActionType.ToString();
			this.mActionIcon.ImageName = str + "_canvas";
		}

		// Token: 0x06000944 RID: 2372 RVA: 0x0003ECB8 File Offset: 0x0003CEB8
		private void ScriptSettingsGrid_MouseEnter(object sender, MouseEventArgs e)
		{
			string str = this.ActionType.ToString();
			this.mActionIcon.ImageName = str + "_canvas_hover";
		}

		// Token: 0x06000945 RID: 2373 RVA: 0x0003ECF0 File Offset: 0x0003CEF0
		private void SetKeys(IMAction action, string center, string left, string up, string right, string down)
		{
			if (this.mParentWindow.IsInOverlayMode && action.Type == KeyActionType.FreeLook)
			{
				this.ShowOverlayKeysOnImage(Positions.Center, center, action, 0, 0);
			}
			if (!this.mParentWindow.IsInOverlayMode && action.Type == KeyActionType.Script)
			{
				this.mColumn4.Width = new GridLength(5.0, GridUnitType.Star);
				this.mRow4.Height = new GridLength(5.0, GridUnitType.Star);
				this.mColumn0.Width = new GridLength(2.0, GridUnitType.Star);
				this.InsertScriptSettingsClickGrid();
			}
			if (!string.IsNullOrEmpty(center))
			{
				if (this.mParentWindow.IsInOverlayMode)
				{
					if (!string.IsNullOrEmpty(action[center].ToString()) && action.Type != KeyActionType.Zoom && action.Type != KeyActionType.Swipe && action.Type != KeyActionType.Tilt && action.Type != KeyActionType.State)
					{
						if (action.Type == KeyActionType.Tap)
						{
							this.mColumn4.Width = new GridLength(5.0, GridUnitType.Star);
							this.mRow4.Height = new GridLength(5.0, GridUnitType.Star);
							this.mColumn0.Width = new GridLength(5.0, GridUnitType.Star);
						}
						else if (action.Type == KeyActionType.TapRepeat)
						{
							base.MinWidth = 40.0;
							base.MinHeight = 40.0;
							this.mColumn4.Width = new GridLength(5.0, GridUnitType.Star);
							this.mRow4.Height = new GridLength(5.0, GridUnitType.Star);
							this.mRow1.Height = new GridLength(1.0, GridUnitType.Auto);
							this.mRow2.Height = new GridLength(3.0, GridUnitType.Star);
							this.mRow3.Height = new GridLength(1.0, GridUnitType.Auto);
							this.mColumn0.Width = new GridLength(5.0, GridUnitType.Star);
						}
						else if (action.Type == KeyActionType.MOBASkill)
						{
							this.mColumn4.Width = new GridLength(5.0, GridUnitType.Star);
							this.mRow4.Height = new GridLength(5.0, GridUnitType.Star);
							this.mColumn0.Width = new GridLength(5.0, GridUnitType.Star);
						}
						else if (action.Type == KeyActionType.MOBASkillCancel || action.Type == KeyActionType.Script)
						{
							this.mColumn4.Width = new GridLength(6.0, GridUnitType.Star);
							this.mRow4.Height = new GridLength(5.0, GridUnitType.Star);
							this.mColumn0.Width = new GridLength(6.0, GridUnitType.Star);
						}
						else if (action.Type == KeyActionType.Pan || action.Type == KeyActionType.PanShoot || action.Type == KeyActionType.LookAround)
						{
							this.mColumn4.Width = new GridLength(5.0, GridUnitType.Star);
							this.mRow4.Height = new GridLength(5.0, GridUnitType.Star);
							this.mColumn0.Width = new GridLength(5.0, GridUnitType.Star);
						}
						if (action.Type != KeyActionType.FreeLook)
						{
							this.GetLabelsForOverlay(Positions.Center, center, action, 4, 4);
						}
					}
				}
				else
				{
					TextBlock newTextBlock = this.GetNewTextBlock(Positions.Center, center, action);
					if (action.Type == KeyActionType.Script)
					{
						Grid.SetColumn(newTextBlock, 3);
						Grid.SetRow(newTextBlock, 3);
					}
					else
					{
						Grid.SetColumn(newTextBlock, 2);
						Grid.SetRow(newTextBlock, 2);
					}
					BlueStacksUIBinding.Bind(newTextBlock, KMManager.GetStringsToShowInUI(action[center].ToString()), "");
					newTextBlock.Visibility = Visibility.Visible;
				}
			}
			if (!string.IsNullOrEmpty(left))
			{
				if (this.mParentWindow.IsInOverlayMode)
				{
					if (!string.IsNullOrEmpty(action[left].ToString()) && action.Type != KeyActionType.Zoom && action.Type != KeyActionType.Swipe && action.Type != KeyActionType.Tilt && action.Type != KeyActionType.State)
					{
						if (action.Type == KeyActionType.Dpad)
						{
							this.mColumn1.Width = new GridLength(50.0, GridUnitType.Star);
						}
						if (action.Type == KeyActionType.FreeLook)
						{
							this.mColumn2.Width = new GridLength(30.0, GridUnitType.Star);
							this.mColumn3.Width = new GridLength(40.0, GridUnitType.Star);
							this.GetLabelsForOverlay(Positions.Left, left, action, 2, 2);
						}
						else
						{
							this.GetLabelsForOverlay(Positions.Left, left, action, 2, 1);
						}
					}
				}
				else
				{
					TextBlock newTextBlock2 = this.GetNewTextBlock(Positions.Left, left, action);
					if (action.Type == KeyActionType.Zoom)
					{
						Grid.SetColumn(newTextBlock2, 2);
						Grid.SetRow(newTextBlock2, 2);
					}
					else
					{
						Grid.SetColumn(newTextBlock2, 1);
						Grid.SetRow(newTextBlock2, 2);
					}
					BlueStacksUIBinding.Bind(newTextBlock2, Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(action[left].ToString()), "");
					newTextBlock2.Visibility = Visibility.Visible;
					if (action.Type == KeyActionType.Zoom)
					{
						BlueStacksUIBinding.BindColor(newTextBlock2, TextBlock.BackgroundProperty, "CanvasElementsBackgroundColor");
					}
				}
			}
			if (!string.IsNullOrEmpty(up))
			{
				if (this.mParentWindow.IsInOverlayMode)
				{
					if (!string.IsNullOrEmpty(action[up].ToString()) && action.Type != KeyActionType.Zoom && action.Type != KeyActionType.Swipe && action.Type != KeyActionType.Tilt && action.Type != KeyActionType.State)
					{
						if (action.Type == KeyActionType.Dpad)
						{
							this.mColumn2.Width = new GridLength(50.0, GridUnitType.Star);
						}
						if (action.Type == KeyActionType.FreeLook)
						{
							this.GetLabelsForOverlay(Positions.Up, up, action, 1, 3);
						}
						else
						{
							this.GetLabelsForOverlay(Positions.Up, up, action, 1, 2);
						}
					}
				}
				else
				{
					TextBlock newTextBlock3 = this.GetNewTextBlock(Positions.Up, up, action);
					Grid.SetColumn(newTextBlock3, 2);
					Grid.SetRow(newTextBlock3, 1);
					BlueStacksUIBinding.Bind(newTextBlock3, Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(action[up].ToString()), "");
					newTextBlock3.Visibility = Visibility.Visible;
					if (action.Type == KeyActionType.Zoom)
					{
						BlueStacksUIBinding.BindColor(newTextBlock3, TextBlock.BackgroundProperty, "CanvasElementsBackgroundColor");
					}
				}
			}
			if (!string.IsNullOrEmpty(right))
			{
				if (this.mParentWindow.IsInOverlayMode)
				{
					if (!string.IsNullOrEmpty(action[right].ToString()) && action.Type != KeyActionType.Zoom && action.Type != KeyActionType.Swipe && action.Type != KeyActionType.Tilt && action.Type != KeyActionType.State)
					{
						if (action.Type == KeyActionType.Dpad)
						{
							this.mColumn3.Width = new GridLength(50.0, GridUnitType.Star);
						}
						if (action.Type == KeyActionType.FreeLook)
						{
							this.mColumn3.Width = new GridLength(70.0);
							this.mColumn4.Width = new GridLength(30.0, GridUnitType.Star);
							this.GetLabelsForOverlay(Positions.Right, right, action, 2, 4);
						}
						else
						{
							this.GetLabelsForOverlay(Positions.Right, right, action, 2, 3);
						}
					}
				}
				else
				{
					TextBlock newTextBlock4 = this.GetNewTextBlock(Positions.Right, right, action);
					Grid.SetColumn(newTextBlock4, 3);
					Grid.SetRow(newTextBlock4, 2);
					BlueStacksUIBinding.Bind(newTextBlock4, Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(action[right].ToString()), "");
					newTextBlock4.Visibility = Visibility.Visible;
				}
			}
			if (!string.IsNullOrEmpty(down))
			{
				if (this.mParentWindow.IsInOverlayMode)
				{
					if (!string.IsNullOrEmpty(action[down].ToString()) && action.Type != KeyActionType.Zoom && action.Type != KeyActionType.Swipe && action.Type != KeyActionType.Tilt && action.Type != KeyActionType.State)
					{
						if (action.Type == KeyActionType.Dpad)
						{
							this.mColumn2.Width = new GridLength(50.0, GridUnitType.Star);
						}
						if (action.Type == KeyActionType.FreeLook)
						{
							this.GetLabelsForOverlay(Positions.Down, down, action, 3, 3);
						}
						else
						{
							this.GetLabelsForOverlay(Positions.Down, down, action, 3, 2);
						}
					}
				}
				else
				{
					TextBlock newTextBlock5 = this.GetNewTextBlock(Positions.Down, down, action);
					Grid.SetColumn(newTextBlock5, 2);
					Grid.SetRow(newTextBlock5, 3);
					BlueStacksUIBinding.Bind(newTextBlock5, Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(action[down].ToString()), "");
					newTextBlock5.Visibility = Visibility.Visible;
				}
			}
			if (action.Type == KeyActionType.Dpad && (action as Dpad).IsMOBADpadEnabled && this.mParentWindow.IsInOverlayMode)
			{
				this.mGrid.Visibility = Visibility.Visible;
				this.mColumn2.Width = new GridLength(70.0, GridUnitType.Star);
				this.mRow2.Height = new GridLength(70.0, GridUnitType.Star);
				this.GetLabelsForOverlay(Positions.Center, string.Empty, action, 2, 2);
			}
			if (this.mParentWindow.IsInOverlayMode)
			{
				this.mCanvasGrid.Visibility = Visibility.Collapsed;
				this.mToggleModeGrid.Visibility = Visibility.Collapsed;
				return;
			}
			this.mCanvasGrid.Visibility = Visibility.Visible;
			if (action.Type == KeyActionType.TapRepeat || action.Type == KeyActionType.FreeLook)
			{
				this.mToggleModeGrid.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x06000946 RID: 2374 RVA: 0x0003F5EC File Offset: 0x0003D7EC
		private void ShowOverlayKeysOnImage(Positions p, string s, IMAction action, int row, int column)
		{
			Grid grid = new Grid();
			grid.MinHeight = 20.0;
			grid.MinWidth = 20.0;
			grid.Visibility = Visibility.Visible;
			grid.HorizontalAlignment = HorizontalAlignment.Center;
			grid.VerticalAlignment = VerticalAlignment.Center;
			CustomPictureBox customPictureBox = new CustomPictureBox();
			customPictureBox.Visibility = Visibility.Visible;
			customPictureBox.HorizontalAlignment = HorizontalAlignment.Center;
			customPictureBox.VerticalAlignment = VerticalAlignment.Center;
			if (((FreeLook)action).DeviceType == 0)
			{
				customPictureBox.Height = 196.0;
				customPictureBox.Width = 98.0;
				customPictureBox.ImageName = "overlay_keyboard";
				customPictureBox.Margin = new Thickness(0.0, 6.0, 0.0, 0.0);
				grid.Children.Add(customPictureBox);
				Grid.SetRow(grid, row);
				Grid.SetColumn(grid, 1);
				Grid.SetRowSpan(grid, 5);
				Grid.SetColumnSpan(grid, 5);
			}
			else
			{
				customPictureBox.Height = 40.0;
				customPictureBox.Width = 40.0;
				customPictureBox.ImageName = "overlay_mouse";
				Label label = new Label();
				BlueStacksUIBinding.Bind(label, Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(action[s].ToString()));
				label.Margin = new Thickness(2.0, 0.0, 2.0, 1.0);
				label.Padding = new Thickness(2.0);
				label.FontSize = 11.0;
				label.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#6EFFFFFF"));
				label.FontWeight = FontWeights.DemiBold;
				label.HorizontalAlignment = HorizontalAlignment.Center;
				label.VerticalAlignment = VerticalAlignment.Center;
				grid.Children.Add(customPictureBox);
				grid.Children.Add(label);
				Grid.SetRow(grid, 2);
				Grid.SetRowSpan(grid, 4);
				Grid.SetColumn(grid, column);
			}
			this.mGrid.Children.Add(grid);
		}

		// Token: 0x06000947 RID: 2375 RVA: 0x0003F7FC File Offset: 0x0003D9FC
		private void GetLabelsForOverlay(Positions p, string s, IMAction action, int row, int column)
		{
			if (ShowImagesOnOverlay.mListShowImagesForKeys.Contains(action[s].ToString()))
			{
				Grid grid = new Grid();
				grid.MinHeight = 23.0;
				grid.MinWidth = 23.0;
				grid.Visibility = Visibility.Visible;
				grid.HorizontalAlignment = HorizontalAlignment.Center;
				grid.VerticalAlignment = VerticalAlignment.Center;
				CustomPictureBox customPictureBox = new CustomPictureBox();
				customPictureBox.Height = 22.0;
				customPictureBox.Width = 22.0;
				customPictureBox.Visibility = Visibility.Visible;
				customPictureBox.HorizontalAlignment = HorizontalAlignment.Center;
				customPictureBox.VerticalAlignment = VerticalAlignment.Center;
				customPictureBox.ImageName = "Imap_" + action[s].ToString();
				grid.Children.Add(customPictureBox);
				this.mGrid.Children.Add(grid);
				Grid.SetRow(grid, row);
				Grid.SetColumn(grid, column);
				return;
			}
			if (action.Type == KeyActionType.Dpad || action.Type == KeyActionType.MOBASkill || action.Type == KeyActionType.FreeLook)
			{
				if (action.Type == KeyActionType.Dpad)
				{
					if ((action as Dpad).IsMOBADpadEnabled)
					{
						Grid grid2 = new Grid();
						grid2.MinHeight = 54.0;
						grid2.MinWidth = 54.0;
						grid2.Visibility = Visibility.Visible;
						grid2.HorizontalAlignment = HorizontalAlignment.Center;
						grid2.VerticalAlignment = VerticalAlignment.Center;
						CustomPictureBox customPictureBox2 = new CustomPictureBox();
						customPictureBox2.Height = 54.0;
						customPictureBox2.Width = 54.0;
						customPictureBox2.Visibility = Visibility.Visible;
						customPictureBox2.HorizontalAlignment = HorizontalAlignment.Center;
						customPictureBox2.VerticalAlignment = VerticalAlignment.Center;
						customPictureBox2.ImageName = "Imap_MOBADpad";
						grid2.Children.Add(customPictureBox2);
						this.mGrid.Children.Add(grid2);
						Grid.SetRow(grid2, row);
						Grid.SetColumn(grid2, column);
						return;
					}
					Grid labelGrid = this.GetLabelGrid(s, action);
					Grid.SetRow(labelGrid, row);
					Grid.SetColumn(labelGrid, column);
					return;
				}
				else
				{
					Grid labelGrid2 = this.GetLabelGrid(s, action);
					Grid.SetRow(labelGrid2, row);
					Grid.SetColumn(labelGrid2, column);
					if (p.Equals(Positions.Up))
					{
						labelGrid2.Margin = new Thickness(0.0, 20.0, 0.0, 0.0);
					}
					if (p.Equals(Positions.Down))
					{
						labelGrid2.Margin = new Thickness(0.0, -14.0, 0.0, 0.0);
						return;
					}
				}
			}
			else
			{
				OverlayLabelControl overlayLabelControl = new OverlayLabelControl();
				BlueStacksUIBinding.Bind(overlayLabelControl.lbl, KMManager.GetStringsToShowInUI(action[s].ToString()));
				overlayLabelControl.MinHeight = 22.0;
				overlayLabelControl.MinWidth = 22.0;
				overlayLabelControl.lbl.HorizontalAlignment = HorizontalAlignment.Center;
				overlayLabelControl.lbl.VerticalAlignment = VerticalAlignment.Center;
				overlayLabelControl.lbl.Margin = new Thickness(3.0, 0.0, 3.0, 1.0);
				overlayLabelControl.lbl.Padding = new Thickness(1.0);
				overlayLabelControl.lbl.FontSize = 11.0;
				this.mGrid.Children.Add(overlayLabelControl);
				Grid.SetRow(overlayLabelControl, row);
				Grid.SetColumn(overlayLabelControl, column);
			}
		}

		// Token: 0x06000948 RID: 2376 RVA: 0x0003FB74 File Offset: 0x0003DD74
		private Grid GetLabelGrid(string s, IMAction action)
		{
			Grid grid = new Grid();
			grid.MinHeight = 23.0;
			grid.MinWidth = 23.0;
			grid.Visibility = Visibility.Visible;
			grid.HorizontalAlignment = HorizontalAlignment.Center;
			grid.VerticalAlignment = VerticalAlignment.Center;
			Border border = new Border();
			Label label = new Label();
			BlueStacksUIBinding.BindColor(border, Border.BorderBrushProperty, "OverlayLabelBorderColor");
			RenderOptions.SetEdgeMode(border, EdgeMode.Aliased);
			BlueStacksUIBinding.BindColor(border, Border.BackgroundProperty, "OverlayLabelBackgroundColor");
			border.ClipToBounds = false;
			border.CornerRadius = new CornerRadius(15.0);
			border.BorderThickness = new Thickness(1.0);
			BlueStacksUIBinding.Bind(label, Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(action[s].ToString()));
			label.Margin = new Thickness(2.0, 0.0, 2.0, 1.0);
			label.Padding = new Thickness(2.0);
			label.FontSize = 11.0;
			label.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#6EFFFFFF"));
			label.FontWeight = FontWeights.DemiBold;
			label.HorizontalAlignment = HorizontalAlignment.Center;
			label.VerticalAlignment = VerticalAlignment.Center;
			grid.Children.Add(border);
			grid.Children.Add(label);
			this.mGrid.Children.Add(grid);
			return grid;
		}

		// Token: 0x06000949 RID: 2377 RVA: 0x0003FCF0 File Offset: 0x0003DEF0
		private TextBlock GetNewTextBlock(Positions p, string s, IMAction action)
		{
			TextBlock textBlock;
			if (this.dictTextElemets.ContainsKey(p))
			{
				this.dictTextElemets[p].Item4.Add(action);
				textBlock = this.dictTextElemets[p].Item3;
			}
			else
			{
				textBlock = new TextBlock();
				textBlock.FontSize = 14.0;
				textBlock.FontWeight = FontWeights.Bold;
				textBlock.Background = Brushes.Transparent;
				textBlock.TextWrapping = TextWrapping.Wrap;
				textBlock.Padding = new Thickness(5.0, 2.0, 5.0, 2.0);
				textBlock.Foreground = Brushes.Black;
				textBlock.HorizontalAlignment = HorizontalAlignment.Center;
				textBlock.VerticalAlignment = VerticalAlignment.Center;
				textBlock.PreviewMouseUp += this.TxtBlock_PreviewMouseUp;
				textBlock.Name = p.ToString();
				TextBox textBox = new TextBox();
				textBox.FontSize = 14.0;
				textBox.FontWeight = FontWeights.Bold;
				BlueStacksUIBinding.BindColor(textBox, Control.BackgroundProperty, "ComboBoxBackgroundColor");
				BlueStacksUIBinding.BindColor(textBox, Control.BorderBrushProperty, "ComboBoxBorderColor");
				BlueStacksUIBinding.BindColor(textBox, Control.ForegroundProperty, "ComboBoxForegroundColor");
				textBox.Padding = new Thickness(0.0, 1.0, 0.0, 1.0);
				textBox.HorizontalAlignment = HorizontalAlignment.Center;
				textBox.VerticalAlignment = VerticalAlignment.Center;
				textBox.TextAlignment = TextAlignment.Center;
				textBox.LostFocus += this.TxtBox_LostFocus;
				textBox.GotFocus += this.TxtBox_GotFocus;
				textBox.MinWidth = 24.0;
				textBox.TextWrapping = TextWrapping.Wrap;
				InputMethod.SetIsInputMethodEnabled(textBox, false);
				textBox.Name = p.ToString();
				textBox.Visibility = Visibility.Collapsed;
				textBox.PreviewMouseLeftButtonDown += this.SelectivelyIgnoreMouseButton;
				textBox.PreviewMouseDown += this.TxtBox_PreviewMouseDown;
				textBox.PreviewKeyDown += this.TxtBox_PreviewKeyDown;
				textBox.KeyUp += this.TxtBox_KeyUp;
				textBox.TextChanged += this.TxtBox_TextChanged;
				this.mGrid.Children.Add(textBlock);
				this.mGrid.Children.Add(textBox);
				this.dictTextElemets.Add(p, new Tuple<string, TextBox, TextBlock, List<IMAction>>(s, textBox, textBlock, new List<IMAction>
				{
					action
				}));
			}
			return textBlock;
		}

		// Token: 0x0600094A RID: 2378 RVA: 0x0003FF68 File Offset: 0x0003E168
		private void TxtBox_KeyUp(object sender, KeyEventArgs e)
		{
			TextBox textBox = sender as TextBox;
			if (this.ActionType == KeyActionType.Tap || this.lstActionItem[0].Type == KeyActionType.TapRepeat || this.lstActionItem[0].Type == KeyActionType.Script)
			{
				string text = string.Empty;
				string tag = string.Empty;
				if (this.mKeyList.Count >= 2)
				{
					text = IMAPKeys.GetStringForUI(this.mKeyList.ElementAt(this.mKeyList.Count - 2)) + " + " + IMAPKeys.GetStringForUI(this.mKeyList.ElementAt(this.mKeyList.Count - 1));
					tag = IMAPKeys.GetStringForFile(this.mKeyList.ElementAt(this.mKeyList.Count - 2)) + " + " + IMAPKeys.GetStringForFile(this.mKeyList.ElementAt(this.mKeyList.Count - 1));
					textBox.Text = text;
					textBox.Tag = tag;
					this.SetValueHandling(sender);
				}
				else if (this.mKeyList.Count == 1)
				{
					text = IMAPKeys.GetStringForUI(this.mKeyList.ElementAt(0));
					tag = IMAPKeys.GetStringForFile(this.mKeyList.ElementAt(0));
					textBox.Text = text;
					textBox.Tag = tag;
					this.SetValueHandling(sender);
				}
				textBox.CaretIndex = textBox.Text.Length;
				this.mKeyList.Clear();
				return;
			}
			e.Handled = true;
		}

		// Token: 0x0600094B RID: 2379 RVA: 0x00007BDD File Offset: 0x00005DDD
		internal void SetMousePoint(Point mousePoint)
		{
			this.mMousePointForTap = new Point?(mousePoint);
		}

		// Token: 0x0600094C RID: 2380 RVA: 0x00007BEB File Offset: 0x00005DEB
		private void TxtBox_TextChanged(object sender, TextChangedEventArgs e)
		{
			this.SetValueHandling(sender);
		}

		// Token: 0x0600094D RID: 2381 RVA: 0x000400DC File Offset: 0x0003E2DC
		private void SetValueHandling(object sender)
		{
			TextBox textBox = sender as TextBox;
			Positions key = EnumHelper.Parse<Positions>(textBox.Name.ToString(), Positions.Center);
			string item = this.dictTextElemets[key].Item1;
			string value = this.dictTextElemets[key].Item4[0][item].ToString();
			if (textBox.Tag != null)
			{
				value = textBox.Tag.ToString();
			}
			this.Setvalue(textBox, value);
		}

		// Token: 0x0600094E RID: 2382 RVA: 0x00040154 File Offset: 0x0003E354
		private void Setvalue(TextBox mKeyTextBox, string value)
		{
			Positions key = EnumHelper.Parse<Positions>(mKeyTextBox.Name.ToString(), Positions.Center);
			string item = this.dictTextElemets[key].Item1;
			foreach (IMAction imaction in this.dictTextElemets[key].Item4)
			{
				if (!imaction[item].ToString().Equals(value))
				{
					imaction[item] = value;
					KeymapCanvasWindow.sIsDirty = true;
				}
			}
			if (item.StartsWith("Key"))
			{
				mKeyTextBox.Text = mKeyTextBox.Text;
			}
		}

		// Token: 0x0600094F RID: 2383 RVA: 0x0004020C File Offset: 0x0003E40C
		private void TxtBox_PreviewKeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Escape)
			{
				return;
			}
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
			}
			if (this.IsRemoveIfEmpty)
			{
				this.IsRemoveIfEmpty = false;
				this.UpdatePosition(Canvas.GetTop(this), Canvas.GetLeft(this));
			}
			TextBox textBox = sender as TextBox;
			if (this.ActionType == KeyActionType.Tap || this.ActionType == KeyActionType.TapRepeat || this.ActionType == KeyActionType.Script)
			{
				if (e.Key == Key.Back || e.SystemKey == Key.Back)
				{
					textBox.Tag = string.Empty;
					BlueStacksUIBinding.Bind(textBox, Constants.ImapLocaleStringsConstant + textBox.Tag);
				}
				else if (IMAPKeys.mDictKeys.ContainsKey(e.SystemKey) || IMAPKeys.mDictKeys.ContainsKey(e.Key))
				{
					if (e.SystemKey == Key.LeftAlt || e.SystemKey == Key.RightAlt || e.SystemKey == Key.F10)
					{
						this.mKeyList.AddIfNotContain(e.SystemKey);
					}
					else if (e.KeyboardDevice.Modifiers != ModifierKeys.None)
					{
						if (e.KeyboardDevice.Modifiers == ModifierKeys.Alt)
						{
							this.mKeyList.AddIfNotContain(e.SystemKey);
						}
						else if (e.KeyboardDevice.Modifiers == (ModifierKeys.Alt | ModifierKeys.Shift))
						{
							this.mKeyList.AddIfNotContain(e.SystemKey);
						}
						else
						{
							this.mKeyList.AddIfNotContain(e.Key);
						}
					}
					else
					{
						this.mKeyList.AddIfNotContain(e.Key);
					}
				}
			}
			else if (e.Key == Key.System && IMAPKeys.mDictKeys.ContainsKey(e.SystemKey))
			{
				textBox.Tag = IMAPKeys.GetStringForFile(e.SystemKey);
				BlueStacksUIBinding.Bind(textBox, Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(e.SystemKey));
			}
			else if (IMAPKeys.mDictKeys.ContainsKey(e.Key))
			{
				textBox.Tag = IMAPKeys.GetStringForFile(e.Key);
				BlueStacksUIBinding.Bind(textBox, Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(e.Key));
			}
			else if (e.Key == Key.Back)
			{
				textBox.Tag = string.Empty;
				BlueStacksUIBinding.Bind(textBox, Constants.ImapLocaleStringsConstant + textBox.Tag);
			}
			e.Handled = true;
			textBox.Focus();
			textBox.SelectAll();
		}

		// Token: 0x06000950 RID: 2384 RVA: 0x00040478 File Offset: 0x0003E678
		private void TxtBox_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.IsRemoveIfEmpty)
			{
				this.IsRemoveIfEmpty = false;
				this.UpdatePosition(Canvas.GetTop(this), Canvas.GetLeft(this));
			}
			TextBox textBox = sender as TextBox;
			if (e.MiddleButton == MouseButtonState.Pressed)
			{
				e.Handled = true;
				textBox.Tag = "MouseMButton";
				BlueStacksUIBinding.Bind(textBox, Constants.ImapLocaleStringsConstant + "MouseMButton");
			}
			else if (e.RightButton == MouseButtonState.Pressed)
			{
				e.Handled = true;
				textBox.Tag = "MouseRButton";
				BlueStacksUIBinding.Bind(textBox, Constants.ImapLocaleStringsConstant + "MouseRButton");
			}
			else if (e.XButton1 == MouseButtonState.Pressed)
			{
				e.Handled = true;
				textBox.Tag = "MouseXButton1";
				BlueStacksUIBinding.Bind(textBox, Constants.ImapLocaleStringsConstant + "MouseXButton1");
			}
			else if (e.XButton2 == MouseButtonState.Pressed)
			{
				e.Handled = true;
				textBox.Tag = "MouseXButton2";
				BlueStacksUIBinding.Bind(textBox, Constants.ImapLocaleStringsConstant + "MouseXButton2");
			}
			if (e.LeftButton == MouseButtonState.Pressed && textBox.IsKeyboardFocusWithin)
			{
				e.Handled = true;
			}
			textBox.Focus();
			textBox.SelectAll();
		}

		// Token: 0x06000951 RID: 2385 RVA: 0x0004059C File Offset: 0x0003E79C
		private void SelectivelyIgnoreMouseButton(object sender, MouseButtonEventArgs e)
		{
			TextBox textBox = sender as TextBox;
			if (textBox != null && !textBox.IsKeyboardFocusWithin)
			{
				e.Handled = true;
				textBox.Focus();
			}
		}

		// Token: 0x06000952 RID: 2386 RVA: 0x000405CC File Offset: 0x0003E7CC
		private void TxtBlock_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			if (Math.Abs(this.TopOnClick - Canvas.GetTop(this)) < 2.0 && Math.Abs(this.LeftOnClick - Canvas.GetLeft(this)) < 2.0)
			{
				this.ShowTextBox(sender);
			}
		}

		// Token: 0x06000953 RID: 2387 RVA: 0x0004061C File Offset: 0x0003E81C
		internal void ShowTextBox(object sender)
		{
			Positions key = EnumHelper.Parse<Positions>((sender as TextBlock).Name.ToString(), Positions.Center);
			this.dictTextElemets[key].Item2.Visibility = Visibility.Visible;
			this.dictTextElemets[key].Item3.Visibility = Visibility.Collapsed;
			this.dictTextElemets[key].Item2.Text = this.dictTextElemets[key].Item3.Text;
			Grid.SetColumn(this.dictTextElemets[key].Item2, Grid.GetColumn(this.dictTextElemets[key].Item3));
			Grid.SetRow(this.dictTextElemets[key].Item2, Grid.GetRow(this.dictTextElemets[key].Item3));
			MiscUtils.SetFocusAsync(this.dictTextElemets[key].Item2, 100);
			if (CanvasElement.sFocusedTextBox == null)
			{
				CanvasElement.sFocusedTextBox = this.dictTextElemets[key].Item2;
			}
			if (this.lstActionItem.First<IMAction>().Type == KeyActionType.MOBASkill)
			{
				this.mActionIcon.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x06000954 RID: 2388 RVA: 0x00007BF4 File Offset: 0x00005DF4
		private void TxtBox_GotFocus(object sender, RoutedEventArgs e)
		{
			CanvasElement.sFocusedTextBox = sender;
			this.SetActiveImage(true);
		}

		// Token: 0x06000955 RID: 2389 RVA: 0x00040748 File Offset: 0x0003E948
		internal void TxtBox_LostFocus(object sender, RoutedEventArgs e)
		{
			if ((sender as TextBox).Visibility != Visibility.Visible)
			{
				return;
			}
			CanvasElement.sFocusedTextBox = null;
			Positions key = EnumHelper.Parse<Positions>((sender as TextBox).Name.ToString(), Positions.Center);
			this.dictTextElemets[key].Item3.Visibility = Visibility.Visible;
			this.dictTextElemets[key].Item2.Visibility = Visibility.Collapsed;
			this.dictTextElemets[key].Item3.Text = this.dictTextElemets[key].Item2.Text;
			this.SetActiveImage(false);
			if (this.IsRemoveIfEmpty)
			{
				this.DeleteElement();
			}
			if (this.lstActionItem.First<IMAction>().Type == KeyActionType.MOBASkill)
			{
				this.mActionIcon.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x06000956 RID: 2390 RVA: 0x00040810 File Offset: 0x0003EA10
		internal void ShowOtherIcons(bool isShow = true)
		{
			if (isShow)
			{
				if (this.lstActionItem.First<IMAction>().RadiusProperty != -1.0)
				{
					this.mResizeIcon.Visibility = Visibility.Visible;
				}
				if (this.lstActionItem.First<IMAction>().Type == KeyActionType.MOBASkill)
				{
					this.AssignMOBASkillImage();
					if (base.ActualWidth < 70.0)
					{
						this.mSkillImage.Margin = new Thickness(-50.0, 30.0, 10.0, 0.0);
					}
					this.mSkillImage.Visibility = Visibility.Visible;
					return;
				}
			}
			else
			{
				this.mSkillImage.Visibility = Visibility.Hidden;
				this.mResizeIcon.Visibility = Visibility.Hidden;
			}
		}

		// Token: 0x06000957 RID: 2391 RVA: 0x000408D0 File Offset: 0x0003EAD0
		private void AssignMOBASkillImage()
		{
			if (!((MOBASkill)this.lstActionItem.First<IMAction>()).AdvancedMode && !((MOBASkill)this.lstActionItem.First<IMAction>()).AutocastEnabled)
			{
				this.mSkillImage.ImageName = "manual_cast";
				BlueStacksUIBinding.Bind(this.mSkillIconHeaderText, "STRING_MANUAL_MODE", "");
				BlueStacksUIBinding.Bind(this.mSkillIconText, "STRING_MANUAL_MODE_SKILL_CAST", "");
				return;
			}
			if (((MOBASkill)this.lstActionItem.First<IMAction>()).AdvancedMode && !((MOBASkill)this.lstActionItem.First<IMAction>()).AutocastEnabled)
			{
				this.mSkillImage.ImageName = "auto_cast";
				BlueStacksUIBinding.Bind(this.mSkillIconHeaderText, "STRING_AUTOCAST", "");
				BlueStacksUIBinding.Bind(this.mSkillIconText, "STRING_AUTOCAST_SKILL_DESCRIPTION", "");
				return;
			}
			if (((MOBASkill)this.lstActionItem.First<IMAction>()).AdvancedMode && ((MOBASkill)this.lstActionItem.First<IMAction>()).AutocastEnabled)
			{
				this.mSkillImage.ImageName = "quick_cast";
				BlueStacksUIBinding.Bind(this.mSkillIconHeaderText, "STRING_QUICK_CAST", "");
				BlueStacksUIBinding.Bind(this.mSkillIconText, "STRING_QUICK_CAST_SKILL_DESCRIPTION", "");
			}
		}

		// Token: 0x06000958 RID: 2392 RVA: 0x00007C03 File Offset: 0x00005E03
		private void SetSize(IMAction action)
		{
			if (string.IsNullOrEmpty(IMAction.sRadiusPropertyName[action.Type]))
			{
				this.mActionIcon.IsAlwaysHalfSize = true;
				base.MaxHeight = this.mActionIcon.MaxHeight;
			}
		}

		// Token: 0x06000959 RID: 2393 RVA: 0x00040A18 File Offset: 0x0003EC18
		internal void UpdatePosition(double top, double left)
		{
			Canvas mCanvas = this.mParentWindow.mCanvas;
			double value = (left + base.ActualWidth / 2.0) / mCanvas.ActualWidth * 100.0;
			double value2 = (top + base.ActualHeight / 2.0) / mCanvas.ActualHeight * 100.0;
			double value3 = base.ActualWidth / mCanvas.ActualWidth * 50.0;
			foreach (IMAction imaction in this.lstActionItem)
			{
				imaction.PositionX = Math.Round(value, 2);
				imaction.PositionY = Math.Round(value2, 2);
				imaction.RadiusProperty = Math.Round(value3, 2);
			}
		}

		// Token: 0x0600095A RID: 2394 RVA: 0x00040AF8 File Offset: 0x0003ECF8
		internal static List<CanvasElement> GetCanvasElement(IMAction action, KeymapCanvasWindow window, MainWindow mainWindow)
		{
			List<CanvasElement> list = new List<CanvasElement>();
			object[] customAttributes = action.GetType().GetCustomAttributes(typeof(DescriptionAttribute), true);
			if (customAttributes.Length != 0)
			{
				DescriptionAttribute descriptionAttribute = customAttributes[0] as DescriptionAttribute;
				if (descriptionAttribute != null)
				{
					if (descriptionAttribute.Description.Contains("Dependent"))
					{
						if (CanvasElement.dictPoints.ContainsKey(action.PositionX + "~" + action.PositionY))
						{
							CanvasElement canvasElement = CanvasElement.dictPoints[action.PositionX + "~" + action.PositionY];
							canvasElement.AddAction(action);
							list.Add(canvasElement);
						}
						else
						{
							CanvasElement canvasElement2 = new CanvasElement(window, mainWindow);
							canvasElement2.AddAction(action);
							canvasElement2.ShowOtherIcons(true);
							CanvasElement.dictPoints.Add(action.PositionX + "~" + action.PositionY, canvasElement2);
							list.Add(canvasElement2);
						}
					}
					else if (descriptionAttribute.Description.Contains("ParentElement"))
					{
						CanvasElement canvasElement3 = new CanvasElement(window, mainWindow);
						canvasElement3.AddAction(action);
						canvasElement3.ShowOtherIcons(true);
						list.Add(canvasElement3);
						if (action is Pan)
						{
							Pan pan = action as Pan;
							if (pan.mLookAround != null)
							{
								list.Add(CanvasElement.GetCanvasElement(pan.mLookAround, window, mainWindow).First<CanvasElement>());
							}
							if (pan.mPanShoot != null)
							{
								list.Add(CanvasElement.GetCanvasElement(pan.mPanShoot, window, mainWindow).First<CanvasElement>());
							}
						}
						else if (action is MOBASkill)
						{
							MOBASkill mobaskill = action as MOBASkill;
							if (mobaskill.mMOBASkillCancel != null)
							{
								list.Add(CanvasElement.GetCanvasElement(mobaskill.mMOBASkillCancel, window, mainWindow).First<CanvasElement>());
							}
						}
					}
					else
					{
						CanvasElement canvasElement4 = new CanvasElement(window, mainWindow);
						canvasElement4.AddAction(action);
						canvasElement4.ShowOtherIcons(true);
						list.Add(canvasElement4);
					}
				}
			}
			return list;
		}

		// Token: 0x0600095B RID: 2395 RVA: 0x00007C39 File Offset: 0x00005E39
		internal void RemoveAction()
		{
			if (this.lstActionItem.Count > 1)
			{
				this.lstActionItem.RemoveAt(0);
				return;
			}
			if (base.Parent != null)
			{
				(base.Parent as Canvas).Children.Remove(this);
			}
		}

		// Token: 0x0600095C RID: 2396 RVA: 0x00007C74 File Offset: 0x00005E74
		private void CanvasElement_PreviewMouseRightButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.OpenPopup();
		}

		// Token: 0x0600095D RID: 2397 RVA: 0x00040CEC File Offset: 0x0003EEEC
		internal void OpenPopup()
		{
			List<IMAction> list = new List<IMAction>();
			if (this.lstActionItem.First<IMAction>().IsChildAction)
			{
				list = new List<IMAction>
				{
					this.lstActionItem.First<IMAction>().ParentAction
				};
				this.SetActiveImage(true);
			}
			else
			{
				list = this.mLstAction;
			}
			if (list.Count != 0)
			{
				KeymapExtraSettingWindow keymapExtraSettingWindow = new KeymapExtraSettingWindow(this.ParentWindow);
				keymapExtraSettingWindow.mLstAction = list;
				keymapExtraSettingWindow.mCanvasElement = this;
				keymapExtraSettingWindow.Placement = PlacementMode.RelativePoint;
				keymapExtraSettingWindow.PlacementTarget = this;
				keymapExtraSettingWindow.StaysOpen = false;
				keymapExtraSettingWindow.Init(false);
				this.SetActiveImage(false);
				keymapExtraSettingWindow.IsOpen = true;
				Point position = Mouse.GetPosition(this);
				keymapExtraSettingWindow.HorizontalOffset = position.X;
				keymapExtraSettingWindow.VerticalOffset = position.Y;
				keymapExtraSettingWindow.Closed += this.ExtraSettingPopup_Closed;
			}
		}

		// Token: 0x0600095E RID: 2398 RVA: 0x00040DBC File Offset: 0x0003EFBC
		private void SetActiveImage(bool isActive = true)
		{
			string text = this.mType.ToString();
			if (this.mType == KeyActionType.MOBASkill && this.mParentWindow.IsInOverlayMode)
			{
				text = KeyActionType.Tap.ToString();
			}
			if (this.mType == KeyActionType.Dpad)
			{
				if (this.lstActionItem.Count != 0 && (this.lstActionItem.First<IMAction>() as Dpad).IsMOBADpadEnabled)
				{
					text = "moba_" + text;
					this.mGrid.Visibility = Visibility.Collapsed;
				}
				else
				{
					this.mGrid.Visibility = Visibility.Visible;
				}
			}
			if (this.mType == KeyActionType.FreeLook)
			{
				if ((this.lstActionItem.First<IMAction>() as FreeLook).DeviceType == 0)
				{
					text += "_keyboard";
				}
				else
				{
					text += "_mouse";
				}
			}
			if (isActive)
			{
				this.mActionIcon.ImageName = text + "_canvas_active";
				this.mActionIcon2.ImageName = this.mActionIcon.ImageName + "_2";
			}
			else
			{
				this.mActionIcon.ImageName = text + "_canvas";
				this.mActionIcon2.ImageName = this.mActionIcon.ImageName + "_2";
			}
			this.mActionIcon.Visibility = Visibility.Visible;
			this.mActionIcon2.Visibility = Visibility.Visible;
			if (this.mType == KeyActionType.State && !KMManager.sIsDeveloperModeOn)
			{
				this.mCloseIcon.Visibility = Visibility.Collapsed;
				this.mResizeIcon.Visibility = Visibility.Collapsed;
				this.mActionIcon.Visibility = Visibility.Collapsed;
				this.mActionIcon2.Visibility = Visibility.Collapsed;
			}
			if (this.mType == KeyActionType.Zoom)
			{
				this.mCloseIcon.Margin = new Thickness(-20.0, 20.0, 20.0, -20.0);
				this.mActionIcon2.Margin = new Thickness(-55.0, 0.0, 0.0, 0.0);
				this.mResizeIcon.Margin = new Thickness(-20.0, -20.0, 20.0, 20.0);
			}
			if (this.mType == KeyActionType.MOBASkill)
			{
				if (base.ActualWidth < 70.0)
				{
					this.mSkillImage.Margin = new Thickness(-50.0, 30.0, 10.0, 0.0);
				}
				if (CanvasElement.sFocusedTextBox == null)
				{
					this.mActionIcon.Visibility = Visibility.Collapsed;
				}
			}
			if (this.lstActionItem.Count != 0 && this.lstActionItem.First<IMAction>().IsChildAction && this.mParentWindow.dictCanvasElement.ContainsKey(this.lstActionItem.First<IMAction>().ParentAction))
			{
				this.mParentWindow.dictCanvasElement[this.lstActionItem.First<IMAction>().ParentAction].SetActiveImage(isActive);
			}
		}

		// Token: 0x0600095F RID: 2399 RVA: 0x000410CC File Offset: 0x0003F2CC
		internal void ExtraSettingPopup_Closed(object sender, EventArgs e)
		{
			if (!this.mParentWindow.mIsClosing)
			{
				KeymapExtraSettingWindow keymapExtraSettingWindow = sender as KeymapExtraSettingWindow;
				string text = keymapExtraSettingWindow.mGuidanceCategoryComboBox.mAutoComboBox.Text;
				foreach (IMAction imaction in keymapExtraSettingWindow.mLstAction)
				{
					if (!imaction.GuidanceCategory.Equals(text))
					{
						imaction.GuidanceCategory = text;
						KeymapCanvasWindow.sIsDirty = true;
						this.ParentWindow.SelectedConfig.AddString(imaction.GuidanceCategory);
					}
				}
				this.SetKeysForActions(this.lstActionItem);
				this.SetActiveImage(false);
				if (this.lstActionItem.First<IMAction>().Type == KeyActionType.Zoom)
				{
					this.lstActionItem.First<IMAction>().RadiusProperty = this.lstActionItem.First<IMAction>().RadiusProperty;
				}
				if (this.ParentWindow.SelectedConfig.ControlSchemes == null)
				{
					this.ParentWindow.SelectedConfig.ControlSchemes = new List<IMControlScheme>();
				}
				AdvancedGameControlWindow sidebarWindow = this.mParentWindow.SidebarWindow;
				KMManager.sGamepadDualTextbox = null;
				KMManager.sGamepadKeyElement = null;
				KMManager.CallGamepadHandler("false");
				this.SetElementLayout(false);
			}
		}

		// Token: 0x06000960 RID: 2400 RVA: 0x00007C7C File Offset: 0x00005E7C
		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			if (this.mLstAction.Count != 0)
			{
				this.SetElementLayout(true);
			}
			this.mIsLoadingfromFile = false;
			this.mMousePointForTap = null;
		}

		// Token: 0x06000961 RID: 2401 RVA: 0x00041208 File Offset: 0x0003F408
		internal void SetElementLayout(bool isLoaded = false)
		{
			IMAction imaction = this.mLstAction.First<IMAction>();
			double num;
			if (imaction.RadiusProperty == -1.0 || (this.mParentWindow.IsInOverlayMode && imaction.Type == KeyActionType.MOBASkill))
			{
				num = base.ActualWidth;
			}
			else
			{
				num = imaction.RadiusProperty * 2.0 / 100.0 * this.mParentWindow.mCanvas.ActualWidth;
				base.Width = num;
			}
			base.Height = num;
			if (imaction.PositionX == -1.0)
			{
				Point point;
				if (this.mMousePointForTap != null)
				{
					point = this.mMousePointForTap.Value;
				}
				else
				{
					point = Mouse.GetPosition(base.Parent as IInputElement);
				}
				if (!isLoaded && (imaction.Type == KeyActionType.Tilt || imaction.Type == KeyActionType.State))
				{
					return;
				}
				if (!isLoaded || !this.mIsLoadingfromFile)
				{
					Canvas.SetTop(this, point.Y - num / 2.0);
					Canvas.SetLeft(this, point.X - num / 2.0);
					return;
				}
				if (imaction.Type == KeyActionType.Tilt || (imaction.Type == KeyActionType.State && KMManager.sIsDeveloperModeOn))
				{
					Canvas.SetTop(this, 0.0);
					Canvas.SetLeft(this, 0.0);
					return;
				}
			}
			else
			{
				double num2 = imaction.PositionX / 100.0 * this.mParentWindow.mCanvas.ActualWidth;
				double num3 = imaction.PositionY / 100.0 * this.mParentWindow.mCanvas.ActualHeight;
				num2 = ((num2 < 0.0) ? 0.0 : num2);
				num3 = ((num3 < 0.0) ? 0.0 : num3);
				num2 = ((num2 > this.mParentWindow.mCanvas.ActualWidth) ? this.mParentWindow.mCanvas.ActualWidth : num2);
				num3 = ((num3 > this.mParentWindow.mCanvas.ActualHeight) ? this.mParentWindow.mCanvas.ActualHeight : num3);
				double length = num2 - num / 2.0;
				double length2 = num3 - num / 2.0;
				Canvas.SetLeft(this, length);
				Canvas.SetTop(this, length2);
			}
		}

		// Token: 0x06000962 RID: 2402 RVA: 0x00007CA5 File Offset: 0x00005EA5
		private void MoveIcon_MouseEnter(object sender, MouseEventArgs e)
		{
			if (!this.mResizeIcon.IsMouseOver)
			{
				base.Cursor = Cursors.Hand;
			}
		}

		// Token: 0x06000963 RID: 2403 RVA: 0x00007CBF File Offset: 0x00005EBF
		private void MoveIcon_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.mParentWindow.mCanvasElement == null)
			{
				base.Cursor = Cursors.Arrow;
			}
			if (this.lstActionItem.First<IMAction>().Type == KeyActionType.MOBASkill)
			{
				this.mActionIcon.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x06000964 RID: 2404 RVA: 0x00007CF8 File Offset: 0x00005EF8
		private void ResizeIcon_MouseEnter(object sender, MouseEventArgs e)
		{
			base.Cursor = Cursors.SizeNWSE;
			e.Handled = true;
		}

		// Token: 0x06000965 RID: 2405 RVA: 0x00007D0C File Offset: 0x00005F0C
		private void ResizeIcon_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.mParentWindow.mCanvasElement == null)
			{
				base.Cursor = Cursors.Arrow;
				e.Handled = true;
				if (base.IsMouseOver)
				{
					base.Cursor = Cursors.Hand;
				}
			}
		}

		// Token: 0x06000966 RID: 2406 RVA: 0x0004145C File Offset: 0x0003F65C
		private void DeleteIcon_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
			KeymapCanvasWindow.sIsDirty = true;
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
			}
			this.DeleteElement();
		}

		// Token: 0x06000967 RID: 2407 RVA: 0x000414A8 File Offset: 0x0003F6A8
		private void DeleteElement()
		{
			KeyActionType type = this.lstActionItem.First<IMAction>().Type;
			if (type == KeyActionType.MOBADpad)
			{
				if (this.mParentWindow.dictCanvasElement.ContainsKey(this.lstActionItem.First<IMAction>()))
				{
					this.mParentWindow.dictCanvasElement[this.lstActionItem.First<IMAction>()].RemoveAction();
					this.mParentWindow.dictCanvasElement.Remove(this.lstActionItem.First<IMAction>());
				}
				this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Remove(this.lstActionItem.First<IMAction>());
				Dpad dpad = (this.lstActionItem.First<IMAction>() as MOBADpad).ParentAction as Dpad;
				dpad.mMOBADpad.OriginX = (dpad.mMOBADpad.OriginY = -1.0);
				this.mParentWindow.dictCanvasElement[dpad].SetActiveImage(false);
				return;
			}
			switch (type)
			{
			case KeyActionType.LookAround:
			{
				if (this.mParentWindow.dictCanvasElement.ContainsKey(this.lstActionItem.First<IMAction>()))
				{
					this.mParentWindow.dictCanvasElement[this.lstActionItem.First<IMAction>()].RemoveAction();
					this.mParentWindow.dictCanvasElement.Remove(this.lstActionItem.First<IMAction>());
				}
				Pan pan = (this.lstActionItem.First<IMAction>() as LookAround).ParentAction as Pan;
				pan.LookAroundX = (pan.LookAroundY = -1.0);
				return;
			}
			case KeyActionType.PanShoot:
			{
				if (this.mParentWindow.dictCanvasElement.ContainsKey(this.lstActionItem.First<IMAction>()))
				{
					this.mParentWindow.dictCanvasElement[this.lstActionItem.First<IMAction>()].RemoveAction();
					this.mParentWindow.dictCanvasElement.Remove(this.lstActionItem.First<IMAction>());
				}
				Pan pan2 = (this.lstActionItem.First<IMAction>() as PanShoot).ParentAction as Pan;
				pan2.LButtonX = (pan2.LButtonY = -1.0);
				return;
			}
			case KeyActionType.MOBASkillCancel:
			{
				if (this.mParentWindow.dictCanvasElement.ContainsKey(this.lstActionItem.First<IMAction>()))
				{
					this.mParentWindow.dictCanvasElement[this.lstActionItem.First<IMAction>()].RemoveAction();
					this.mParentWindow.dictCanvasElement.Remove(this.lstActionItem.First<IMAction>());
				}
				MOBASkill mobaskill = (this.lstActionItem.First<IMAction>() as MOBASkillCancel).ParentAction as MOBASkill;
				mobaskill.CancelX = (mobaskill.CancelY = -1.0);
				return;
			}
			default:
				foreach (IMAction item in this.lstActionItem)
				{
					this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Remove(item);
				}
				if (base.Parent != null)
				{
					(base.Parent as Canvas).Children.Remove(this);
					foreach (KeyValuePair<IMAction, CanvasElement> keyValuePair in this.mParentWindow.dictCanvasElement)
					{
						if (keyValuePair.Key.ParentAction == this.lstActionItem.First<IMAction>())
						{
							keyValuePair.Value.RemoveAction();
							this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Remove(keyValuePair.Value.lstActionItem.First<IMAction>());
						}
					}
				}
				return;
			}
		}

		// Token: 0x06000968 RID: 2408 RVA: 0x00041870 File Offset: 0x0003FA70
		private void UpArrow_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			int num = Convert.ToInt32(this.mCountText.Text);
			num++;
			this.mCountText.Text = num.ToString();
			if (this.lstActionItem.First<IMAction>().Type == KeyActionType.TapRepeat)
			{
				((TapRepeat)this.lstActionItem.First<IMAction>()).Count = num;
				((TapRepeat)this.lstActionItem.First<IMAction>()).Delay = 1000 / (2 * num);
			}
		}

		// Token: 0x06000969 RID: 2409 RVA: 0x000418EC File Offset: 0x0003FAEC
		private void DownArrow_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			int num = Convert.ToInt32(this.mCountText.Text);
			num--;
			if (num <= 1)
			{
				this.mCountText.Text = "1";
			}
			else
			{
				this.mCountText.Text = num.ToString();
			}
			if (this.lstActionItem.First<IMAction>().Type == KeyActionType.TapRepeat)
			{
				((TapRepeat)this.lstActionItem.First<IMAction>()).Count = Convert.ToInt32(this.mCountText.Text);
				((TapRepeat)this.lstActionItem.First<IMAction>()).Delay = 1000 / (2 * ((TapRepeat)this.lstActionItem.First<IMAction>()).Count);
			}
		}

		// Token: 0x0600096A RID: 2410 RVA: 0x000419A4 File Offset: 0x0003FBA4
		private void mToggleImage_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			try
			{
				if (CanvasElement.sFocusedTextBox != null)
				{
					WpfUtils.FindVisualParent<CanvasElement>(CanvasElement.sFocusedTextBox as DependencyObject).TxtBox_LostFocus(CanvasElement.sFocusedTextBox, new RoutedEventArgs());
				}
				if (this.mToggleImage.ImageName.Equals("right_switch"))
				{
					this.mToggleImage.ImageName = "left_switch";
					if (this.lstActionItem.First<IMAction>().Type == KeyActionType.TapRepeat)
					{
						((TapRepeat)this.lstActionItem.First<IMAction>()).RepeatUntilKeyUp = false;
					}
					else if (this.lstActionItem.First<IMAction>().Type == KeyActionType.FreeLook)
					{
						((FreeLook)this.lstActionItem.First<IMAction>()).DeviceType = 0;
						this.SetKeysForActions(this.lstActionItem);
					}
				}
				else
				{
					this.mToggleImage.ImageName = "right_switch";
					if (this.lstActionItem.First<IMAction>().Type == KeyActionType.TapRepeat)
					{
						((TapRepeat)this.lstActionItem.First<IMAction>()).RepeatUntilKeyUp = true;
					}
					else if (this.lstActionItem.First<IMAction>().Type == KeyActionType.FreeLook)
					{
						((FreeLook)this.lstActionItem.First<IMAction>()).DeviceType = 1;
						this.SetKeysForActions(this.lstActionItem);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in toggleMode: " + ex.ToString());
			}
		}

		// Token: 0x0600096B RID: 2411 RVA: 0x00007D40 File Offset: 0x00005F40
		private void MSkillImage_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mMOBASkillSettingsPopup.IsOpen = true;
		}

		// Token: 0x0600096C RID: 2412 RVA: 0x00007D4E File Offset: 0x00005F4E
		private void MMOBASkillSettingsPopup_Opened(object sender, EventArgs e)
		{
			this.mSkillImage.IsEnabled = false;
		}

		// Token: 0x0600096D RID: 2413 RVA: 0x00007D5C File Offset: 0x00005F5C
		private void MMOBASkillSettingsPopup_Closed(object sender, EventArgs e)
		{
			this.mSkillImage.IsEnabled = true;
		}

		// Token: 0x0600096E RID: 2414 RVA: 0x00007D6A File Offset: 0x00005F6A
		private void Grid_MouseEnter(object sender, MouseEventArgs e)
		{
			(sender as Grid).Children.OfType<TextBlock>().First<TextBlock>().Foreground = Brushes.White;
		}

		// Token: 0x0600096F RID: 2415 RVA: 0x00007D8B File Offset: 0x00005F8B
		private void Grid_MouseLeave(object sender, MouseEventArgs e)
		{
			(sender as Grid).Children.OfType<TextBlock>().First<TextBlock>().Foreground = (SolidColorBrush)new BrushConverter().ConvertFrom("#99FFFFFF");
		}

		// Token: 0x06000970 RID: 2416 RVA: 0x00041B10 File Offset: 0x0003FD10
		private void MManualModeGrid_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
			}
			this.mSkillImage.ImageName = "manual_cast";
			if (this.lstActionItem.First<IMAction>().Type == KeyActionType.MOBASkill)
			{
				((MOBASkill)this.lstActionItem.First<IMAction>()).AdvancedMode = false;
				((MOBASkill)this.lstActionItem.First<IMAction>()).AutocastEnabled = false;
				BlueStacksUIBinding.Bind(this.mSkillIconHeaderText, "STRING_MANUAL_MODE", "");
				BlueStacksUIBinding.Bind(this.mSkillIconText, "STRING_MANUAL_MODE_SKILL_CAST", "");
			}
		}

		// Token: 0x06000971 RID: 2417 RVA: 0x00041BC4 File Offset: 0x0003FDC4
		private void MAutocastGrid_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
			}
			this.mSkillImage.ImageName = "auto_cast";
			if (this.lstActionItem.First<IMAction>().Type == KeyActionType.MOBASkill)
			{
				((MOBASkill)this.lstActionItem.First<IMAction>()).AdvancedMode = true;
				((MOBASkill)this.lstActionItem.First<IMAction>()).AutocastEnabled = false;
				BlueStacksUIBinding.Bind(this.mSkillIconHeaderText, "STRING_AUTOCAST", "");
				BlueStacksUIBinding.Bind(this.mSkillIconText, "STRING_AUTOCAST_SKILL_DESCRIPTION", "");
			}
		}

		// Token: 0x06000972 RID: 2418 RVA: 0x00041C78 File Offset: 0x0003FE78
		private void MQuickCastGrid_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
			}
			this.mSkillImage.ImageName = "quick_cast";
			if (this.lstActionItem.First<IMAction>().Type == KeyActionType.MOBASkill)
			{
				((MOBASkill)this.lstActionItem.First<IMAction>()).AdvancedMode = true;
				((MOBASkill)this.lstActionItem.First<IMAction>()).AutocastEnabled = true;
				BlueStacksUIBinding.Bind(this.mSkillIconHeaderText, "STRING_QUICK_CAST", "");
				BlueStacksUIBinding.Bind(this.mSkillIconText, "STRING_QUICK_CAST_SKILL_DESCRIPTION", "");
			}
		}

		// Token: 0x06000973 RID: 2419 RVA: 0x00007DBB File Offset: 0x00005FBB
		private void MSkillImage_MouseEnter(object sender, MouseEventArgs e)
		{
			if (this.lstActionItem.First<IMAction>().Type == KeyActionType.MOBASkill)
			{
				this.mSkillIconToolTipPopup.IsOpen = true;
				this.mSkillIconToolTipPopup.StaysOpen = true;
			}
		}

		// Token: 0x06000974 RID: 2420 RVA: 0x00007DE8 File Offset: 0x00005FE8
		private void MSkillImage_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mSkillIconToolTipPopup.IsOpen = false;
		}

		// Token: 0x06000975 RID: 2421 RVA: 0x00007DF6 File Offset: 0x00005FF6
		private void ScriptSettingsGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mParentWindow.SidebarWindow.mLastScriptActionItem = this.lstActionItem;
			this.mParentWindow.SidebarWindow.ToggleAGCWindowVisiblity(true);
			ClientStats.SendKeyMappingUIStatsAsync("button_clicked", KMManager.sPackageName, "script_edit");
		}

		// Token: 0x06000976 RID: 2422 RVA: 0x00041D2C File Offset: 0x0003FF2C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/canvaselement.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000977 RID: 2423 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000978 RID: 2424 RVA: 0x00041D5C File Offset: 0x0003FF5C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mCanvasElement = (CanvasElement)target;
				this.mCanvasElement.MouseEnter += this.MoveIcon_MouseEnter;
				this.mCanvasElement.MouseLeave += this.MoveIcon_MouseLeave;
				this.mCanvasElement.PreviewMouseRightButtonUp += this.CanvasElement_PreviewMouseRightButtonUp;
				this.mCanvasElement.Loaded += this.UserControl_Loaded;
				return;
			case 2:
				this.mToggleModeGrid = (Grid)target;
				return;
			case 3:
				this.mToggleMode1 = (TextBlock)target;
				return;
			case 4:
				this.mToggleImage = (CustomPictureBox)target;
				this.mToggleImage.PreviewMouseLeftButtonUp += this.mToggleImage_PreviewMouseLeftButtonUp;
				return;
			case 5:
				this.mToggleMode2 = (TextBlock)target;
				return;
			case 6:
				this.mCanvasGrid = (Grid)target;
				return;
			case 7:
				this.mKeyRepeatGrid = (Grid)target;
				return;
			case 8:
				((CustomPictureBox)target).PreviewMouseLeftButtonUp += this.UpArrow_PreviewMouseDown;
				return;
			case 9:
				this.mCountText = (TextBlock)target;
				return;
			case 10:
				((CustomPictureBox)target).PreviewMouseLeftButtonUp += this.DownArrow_PreviewMouseDown;
				return;
			case 11:
				this.mActionIcon = (CustomPictureBox)target;
				return;
			case 12:
				this.mActionIcon2 = (CustomPictureBox)target;
				return;
			case 13:
				this.mCloseIcon = (CustomPictureBox)target;
				this.mCloseIcon.PreviewMouseDown += this.DeleteIcon_PreviewMouseDown;
				return;
			case 14:
				this.mResizeIcon = (CustomPictureBox)target;
				this.mResizeIcon.MouseEnter += this.ResizeIcon_MouseEnter;
				this.mResizeIcon.MouseLeave += this.ResizeIcon_MouseLeave;
				return;
			case 15:
				this.mSkillImage = (CustomPictureBox)target;
				this.mSkillImage.MouseLeftButtonUp += this.MSkillImage_MouseLeftButtonUp;
				this.mSkillImage.MouseEnter += this.MSkillImage_MouseEnter;
				this.mSkillImage.MouseLeave += this.MSkillImage_MouseLeave;
				return;
			case 16:
				this.mGrid = (Grid)target;
				return;
			case 17:
				this.mColumn0 = (ColumnDefinition)target;
				return;
			case 18:
				this.mColumn1 = (ColumnDefinition)target;
				return;
			case 19:
				this.mColumn2 = (ColumnDefinition)target;
				return;
			case 20:
				this.mColumn3 = (ColumnDefinition)target;
				return;
			case 21:
				this.mColumn4 = (ColumnDefinition)target;
				return;
			case 22:
				this.mRow0 = (RowDefinition)target;
				return;
			case 23:
				this.mRow1 = (RowDefinition)target;
				return;
			case 24:
				this.mRow2 = (RowDefinition)target;
				return;
			case 25:
				this.mRow3 = (RowDefinition)target;
				return;
			case 26:
				this.mRow4 = (RowDefinition)target;
				return;
			case 27:
				this.mMOBASkillSettingsPopup = (CustomPopUp)target;
				return;
			case 28:
				this.dummyGrid = (Grid)target;
				return;
			case 29:
				this.mMaskBorder = (Border)target;
				return;
			case 30:
				this.mManualModeGrid = (Grid)target;
				this.mManualModeGrid.MouseEnter += this.Grid_MouseEnter;
				this.mManualModeGrid.MouseLeave += this.Grid_MouseLeave;
				this.mManualModeGrid.PreviewMouseLeftButtonUp += this.MManualModeGrid_PreviewMouseLeftButtonUp;
				return;
			case 31:
				this.mManualModeText = (TextBlock)target;
				return;
			case 32:
				this.mAutocastGrid = (Grid)target;
				this.mAutocastGrid.MouseEnter += this.Grid_MouseEnter;
				this.mAutocastGrid.MouseLeave += this.Grid_MouseLeave;
				this.mAutocastGrid.PreviewMouseLeftButtonUp += this.MAutocastGrid_PreviewMouseLeftButtonUp;
				return;
			case 33:
				this.mAutocastText = (TextBlock)target;
				return;
			case 34:
				this.mQuickCastGrid = (Grid)target;
				this.mQuickCastGrid.MouseEnter += this.Grid_MouseEnter;
				this.mQuickCastGrid.MouseLeave += this.Grid_MouseLeave;
				this.mQuickCastGrid.PreviewMouseLeftButtonUp += this.MQuickCastGrid_PreviewMouseLeftButtonUp;
				return;
			case 35:
				this.mQuickCastText = (TextBlock)target;
				return;
			case 36:
				this.LeftArrow = (Path)target;
				return;
			case 37:
				this.mSkillIconToolTipPopup = (CustomPopUp)target;
				return;
			case 38:
				this.mMaskBorder1 = (Border)target;
				return;
			case 39:
				this.mSkillIconHeaderText = (TextBlock)target;
				return;
			case 40:
				this.mSkillIconText = (TextBlock)target;
				return;
			case 41:
				this.mDownArrow = (Path)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040006A5 RID: 1701
		internal bool mIsLoadingfromFile;

		// Token: 0x040006A6 RID: 1702
		internal Point Center;

		// Token: 0x040006A7 RID: 1703
		private Point? mMousePointForTap;

		// Token: 0x040006A8 RID: 1704
		private KeymapCanvasWindow mParentWindow;

		// Token: 0x040006A9 RID: 1705
		private MainWindow ParentWindow;

		// Token: 0x040006AA RID: 1706
		private List<Key> mKeyList = new List<Key>();

		// Token: 0x040006AB RID: 1707
		private List<KeyActionType> lstResizableAction = new List<KeyActionType>
		{
			KeyActionType.Dpad,
			KeyActionType.Swipe
		};

		// Token: 0x040006AC RID: 1708
		internal Dictionary<Positions, Tuple<string, TextBox, TextBlock, List<IMAction>>> dictTextElemets = new Dictionary<Positions, Tuple<string, TextBox, TextBlock, List<IMAction>>>();

		// Token: 0x040006AD RID: 1709
		internal static Dictionary<string, CanvasElement> dictPoints = new Dictionary<string, CanvasElement>();

		// Token: 0x040006AE RID: 1710
		private List<IMAction> mLstAction = new List<IMAction>();

		// Token: 0x040006AF RID: 1711
		private KeyActionType mType;

		// Token: 0x040006B0 RID: 1712
		internal double TopOnClick;

		// Token: 0x040006B1 RID: 1713
		internal double LeftOnClick;

		// Token: 0x040006B2 RID: 1714
		internal static object sFocusedTextBox;

		// Token: 0x040006B4 RID: 1716
		internal CanvasElement mCanvasElement;

		// Token: 0x040006B5 RID: 1717
		internal Grid mToggleModeGrid;

		// Token: 0x040006B6 RID: 1718
		internal TextBlock mToggleMode1;

		// Token: 0x040006B7 RID: 1719
		internal CustomPictureBox mToggleImage;

		// Token: 0x040006B8 RID: 1720
		internal TextBlock mToggleMode2;

		// Token: 0x040006B9 RID: 1721
		internal Grid mCanvasGrid;

		// Token: 0x040006BA RID: 1722
		internal Grid mKeyRepeatGrid;

		// Token: 0x040006BB RID: 1723
		internal TextBlock mCountText;

		// Token: 0x040006BC RID: 1724
		internal CustomPictureBox mActionIcon;

		// Token: 0x040006BD RID: 1725
		internal CustomPictureBox mActionIcon2;

		// Token: 0x040006BE RID: 1726
		internal CustomPictureBox mCloseIcon;

		// Token: 0x040006BF RID: 1727
		internal CustomPictureBox mResizeIcon;

		// Token: 0x040006C0 RID: 1728
		internal CustomPictureBox mSkillImage;

		// Token: 0x040006C1 RID: 1729
		internal Grid mGrid;

		// Token: 0x040006C2 RID: 1730
		internal ColumnDefinition mColumn0;

		// Token: 0x040006C3 RID: 1731
		internal ColumnDefinition mColumn1;

		// Token: 0x040006C4 RID: 1732
		internal ColumnDefinition mColumn2;

		// Token: 0x040006C5 RID: 1733
		internal ColumnDefinition mColumn3;

		// Token: 0x040006C6 RID: 1734
		internal ColumnDefinition mColumn4;

		// Token: 0x040006C7 RID: 1735
		internal RowDefinition mRow0;

		// Token: 0x040006C8 RID: 1736
		internal RowDefinition mRow1;

		// Token: 0x040006C9 RID: 1737
		internal RowDefinition mRow2;

		// Token: 0x040006CA RID: 1738
		internal RowDefinition mRow3;

		// Token: 0x040006CB RID: 1739
		internal RowDefinition mRow4;

		// Token: 0x040006CC RID: 1740
		internal CustomPopUp mMOBASkillSettingsPopup;

		// Token: 0x040006CD RID: 1741
		internal Grid dummyGrid;

		// Token: 0x040006CE RID: 1742
		internal Border mMaskBorder;

		// Token: 0x040006CF RID: 1743
		internal Grid mManualModeGrid;

		// Token: 0x040006D0 RID: 1744
		internal TextBlock mManualModeText;

		// Token: 0x040006D1 RID: 1745
		internal Grid mAutocastGrid;

		// Token: 0x040006D2 RID: 1746
		internal TextBlock mAutocastText;

		// Token: 0x040006D3 RID: 1747
		internal Grid mQuickCastGrid;

		// Token: 0x040006D4 RID: 1748
		internal TextBlock mQuickCastText;

		// Token: 0x040006D5 RID: 1749
		internal Path LeftArrow;

		// Token: 0x040006D6 RID: 1750
		internal CustomPopUp mSkillIconToolTipPopup;

		// Token: 0x040006D7 RID: 1751
		internal Border mMaskBorder1;

		// Token: 0x040006D8 RID: 1752
		internal TextBlock mSkillIconHeaderText;

		// Token: 0x040006D9 RID: 1753
		internal TextBlock mSkillIconText;

		// Token: 0x040006DA RID: 1754
		internal Path mDownArrow;

		// Token: 0x040006DB RID: 1755
		private bool _contentLoaded;
	}
}
