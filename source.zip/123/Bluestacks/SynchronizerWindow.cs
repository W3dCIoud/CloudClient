﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Navigation;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000C0 RID: 192
	public class SynchronizerWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x060007AD RID: 1965 RVA: 0x0003061C File Offset: 0x0002E81C
		public SynchronizerWindow(MainWindow parent)
		{
			this.ParentWindow = parent;
			base.Owner = parent;
			base.IsShowGLWindow = true;
			this.InitializeComponent();
			string str = WebHelper.GetUrlWithParams(string.Format("{0}/{1}", WebHelper.GetServerHost(), "help_articles")) + "&article=";
			this.mHyperLink.NavigateUri = new Uri(str + "operation_synchronization");
			this.mHyperLink.Inlines.Clear();
			this.mHyperLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_SYNC_HELP", false));
			BlueStacksUIBinding.Instance.PropertyChanged += this.Binding_PropertyChanged;
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.mSyncHelp.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x060007AE RID: 1966 RVA: 0x00006F5F File Offset: 0x0000515F
		private void Binding_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			if (e.PropertyName == "LocaleModel")
			{
				this.mHyperLink.Inlines.Clear();
				this.mHyperLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_SYNC_HELP", false));
			}
		}

		// Token: 0x060007AF RID: 1967 RVA: 0x000306E4 File Offset: 0x0002E8E4
		internal void Init()
		{
			this.mIsActiveWindowPresent = false;
			this.mActiveWindowsPanel.Children.Clear();
			foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
			{
				if (keyValuePair.Key != this.ParentWindow.mVmName && (!BlueStacksUIUtils.sSyncInvolvedInstances.Contains(keyValuePair.Key) || this.ParentWindow.mSelectedInstancesForSync.Contains(keyValuePair.Key)))
				{
					CustomCheckbox customCheckbox = new CustomCheckbox();
					customCheckbox.Content = this.GetInstanceGameOrDisplayName(keyValuePair.Key);
					customCheckbox.Tag = keyValuePair.Key;
					if (customCheckbox.Image != null)
					{
						customCheckbox.Image.Height = 16.0;
						customCheckbox.Image.Width = 16.0;
					}
					customCheckbox.Height = 25.0;
					customCheckbox.FontSize = 16.0;
					customCheckbox.Margin = new Thickness(12.0, 8.0, 0.0, 0.0);
					if (this.ParentWindow.mSelectedInstancesForSync.Contains(customCheckbox.Tag.ToString()))
					{
						customCheckbox.IsChecked = new bool?(true);
					}
					else
					{
						customCheckbox.IsChecked = new bool?(false);
					}
					customCheckbox.MouseEnter += this.InstanceCheckbox_MouseEnter;
					customCheckbox.MouseLeave += this.InstanceCheckbox_MouseLeave;
					customCheckbox.Checked += this.InstanceCheckbox_Checked;
					customCheckbox.Unchecked += this.InstanceCheckbox_Unchecked;
					this.mActiveWindowsPanel.Children.Add(customCheckbox);
					this.mIsActiveWindowPresent = true;
					this.mActiveWindowsListScrollbar.Visibility = Visibility.Visible;
				}
			}
			if (this.mIsActiveWindowPresent)
			{
				this.mLaunchInstanceManagerBtn.Visibility = Visibility.Collapsed;
				this.mNoActiveWindowsGrid.Visibility = Visibility.Collapsed;
				this.mStartSyncBtn.Visibility = Visibility.Visible;
				if (this.ParentWindow.mIsSynchronisationActive)
				{
					this.mStartSyncBtn.IsEnabled = false;
				}
				else
				{
					this.ToggleStartSyncButton();
				}
				this.ToggleSelectAllCheckboxSelection();
				return;
			}
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.Close_MouseLeftButtonUp(null, null);
				return;
			}
			this.mActiveWindowsListScrollbar.Visibility = Visibility.Collapsed;
			this.mNoActiveWindowsGrid.Visibility = Visibility.Visible;
			this.mStartSyncBtn.Visibility = Visibility.Collapsed;
			this.mLaunchInstanceManagerBtn.Visibility = Visibility.Visible;
		}

		// Token: 0x060007B0 RID: 1968 RVA: 0x00030984 File Offset: 0x0002EB84
		private void InstanceCheckbox_Unchecked(object sender, RoutedEventArgs e)
		{
			if (this.mStopEventFromPropagatingFurther)
			{
				return;
			}
			this.mStopEventFromPropagatingFurther = true;
			CustomCheckbox customCheckbox = sender as CustomCheckbox;
			customCheckbox.IsChecked = new bool?(false);
			this.ParentWindow.mSelectedInstancesForSync.Remove(customCheckbox.Tag.ToString());
			this.ToggleSelectAllCheckboxSelection();
			if (this.ParentWindow.mIsSynchronisationActive)
			{
				HTTPUtils.SendRequestToEngineAsync("stopSyncConsumer", null, customCheckbox.Tag.ToString(), 0, null, false, 1, 0);
				BlueStacksUIUtils.DictWindows[customCheckbox.Tag.ToString()]._TopBar.HideSyncPanel();
				if (BlueStacksUIUtils.sSyncInvolvedInstances.Contains(customCheckbox.Tag.ToString()))
				{
					BlueStacksUIUtils.sSyncInvolvedInstances.Remove(customCheckbox.Tag.ToString());
				}
				if (this.ParentWindow.mSelectedInstancesForSync.Count == 0)
				{
					this.ParentWindow.mIsSynchronisationActive = false;
					this.ParentWindow.mIsSyncMaster = false;
					if (BlueStacksUIUtils.sSyncInvolvedInstances.Contains(this.ParentWindow.mVmName))
					{
						BlueStacksUIUtils.sSyncInvolvedInstances.Remove(this.ParentWindow.mVmName);
					}
					this.ParentWindow._TopBar.HideSyncPanel();
					this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("stopOperationsSync", new Dictionary<string, string>());
				}
				this.UpdateOtherSyncWindows();
			}
			if (!this.ParentWindow.mIsSynchronisationActive)
			{
				this.ToggleStartSyncButton();
			}
			this.mStopEventFromPropagatingFurther = false;
		}

		// Token: 0x060007B1 RID: 1969 RVA: 0x00030AF0 File Offset: 0x0002ECF0
		private void InstanceCheckbox_Checked(object sender, RoutedEventArgs e)
		{
			if (this.mStopEventFromPropagatingFurther)
			{
				return;
			}
			this.mStopEventFromPropagatingFurther = true;
			CustomCheckbox customCheckbox = sender as CustomCheckbox;
			customCheckbox.IsChecked = new bool?(true);
			this.ParentWindow.mSelectedInstancesForSync.Add(customCheckbox.Tag.ToString());
			this.ToggleSelectAllCheckboxSelection();
			if (this.ParentWindow.mIsSynchronisationActive)
			{
				HTTPUtils.SendRequestToEngineAsync("startSyncConsumer", new Dictionary<string, string>
				{
					{
						"instance",
						this.ParentWindow.mVmName
					}
				}, BlueStacksUIUtils.DictWindows[(sender as CustomCheckbox).Tag.ToString()].mVmName, 0, null, false, 1, 0);
				BlueStacksUIUtils.DictWindows[customCheckbox.Tag.ToString()]._TopBar.ShowSyncPanel(false);
				if (!BlueStacksUIUtils.sSyncInvolvedInstances.Contains(customCheckbox.Tag.ToString()))
				{
					BlueStacksUIUtils.sSyncInvolvedInstances.Add(customCheckbox.Tag.ToString());
				}
				this.UpdateOtherSyncWindows();
			}
			else
			{
				this.ToggleStartSyncButton();
			}
			this.mStopEventFromPropagatingFurther = false;
		}

		// Token: 0x060007B2 RID: 1970 RVA: 0x00030C00 File Offset: 0x0002EE00
		private void mSelectAll_Checked(object sender, RoutedEventArgs e)
		{
			if (this.mStopEventFromPropagatingFurther)
			{
				return;
			}
			this.mStopEventFromPropagatingFurther = true;
			foreach (object obj in this.mActiveWindowsPanel.Children)
			{
				CustomCheckbox customCheckbox = (CustomCheckbox)obj;
				customCheckbox.IsChecked = new bool?(true);
				if (!this.ParentWindow.mSelectedInstancesForSync.Contains(customCheckbox.Tag.ToString()))
				{
					this.ParentWindow.mSelectedInstancesForSync.Add(customCheckbox.Tag.ToString());
					if (this.ParentWindow.mIsSynchronisationActive)
					{
						HTTPUtils.SendRequestToEngineAsync("startSyncConsumer", new Dictionary<string, string>
						{
							{
								"instance",
								this.ParentWindow.mVmName
							}
						}, customCheckbox.Tag.ToString(), 0, null, false, 1, 0);
						BlueStacksUIUtils.DictWindows[customCheckbox.Tag.ToString()]._TopBar.ShowSyncPanel(false);
						if (!BlueStacksUIUtils.sSyncInvolvedInstances.Contains(customCheckbox.Tag.ToString()))
						{
							BlueStacksUIUtils.sSyncInvolvedInstances.Add(customCheckbox.Tag.ToString());
						}
						this.UpdateOtherSyncWindows();
					}
				}
			}
			this.ToggleStartSyncButton();
			this.mStopEventFromPropagatingFurther = false;
		}

		// Token: 0x060007B3 RID: 1971 RVA: 0x00030D5C File Offset: 0x0002EF5C
		private void mSelectAll_Unchecked(object sender, RoutedEventArgs e)
		{
			if (this.mStopEventFromPropagatingFurther)
			{
				return;
			}
			this.mStopEventFromPropagatingFurther = true;
			foreach (object obj in this.mActiveWindowsPanel.Children)
			{
				CustomCheckbox customCheckbox = (CustomCheckbox)obj;
				customCheckbox.IsChecked = new bool?(false);
				if (this.ParentWindow.mSelectedInstancesForSync.Contains(customCheckbox.Tag.ToString()))
				{
					this.ParentWindow.mSelectedInstancesForSync.Remove(customCheckbox.Tag.ToString());
					if (this.ParentWindow.mIsSynchronisationActive)
					{
						HTTPUtils.SendRequestToEngineAsync("stopSyncConsumer", null, customCheckbox.Tag.ToString(), 0, null, false, 1, 0);
						BlueStacksUIUtils.DictWindows[customCheckbox.Tag.ToString()]._TopBar.HideSyncPanel();
						if (BlueStacksUIUtils.sSyncInvolvedInstances.Contains(customCheckbox.Tag.ToString()))
						{
							BlueStacksUIUtils.sSyncInvolvedInstances.Remove(customCheckbox.Tag.ToString());
						}
					}
				}
			}
			if (this.ParentWindow.mIsSynchronisationActive)
			{
				this.ParentWindow.mIsSynchronisationActive = false;
				this.ParentWindow.mIsSyncMaster = false;
				if (BlueStacksUIUtils.sSyncInvolvedInstances.Contains(this.ParentWindow.mVmName))
				{
					BlueStacksUIUtils.sSyncInvolvedInstances.Remove(this.ParentWindow.mVmName);
				}
				this.ParentWindow._TopBar.HideSyncPanel();
				this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("stopOperationsSync", new Dictionary<string, string>());
				this.UpdateOtherSyncWindows();
			}
			this.ToggleStartSyncButton();
			this.mStopEventFromPropagatingFurther = false;
		}

		// Token: 0x060007B4 RID: 1972 RVA: 0x00006F9E File Offset: 0x0000519E
		private void InstanceCheckbox_MouseLeave(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as CustomCheckbox, Control.BackgroundProperty, "SettingsWindowBackground");
		}

		// Token: 0x060007B5 RID: 1973 RVA: 0x00006FB5 File Offset: 0x000051B5
		private void InstanceCheckbox_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as CustomCheckbox, Control.BackgroundProperty, "GameControlNavigationBackgroundColor");
		}

		// Token: 0x060007B6 RID: 1974 RVA: 0x0001CBFC File Offset: 0x0001ADFC
		private void Topbar_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!e.OriginalSource.GetType().Equals(typeof(CustomPictureBox)))
			{
				try
				{
					base.DragMove();
				}
				catch
				{
				}
			}
		}

		// Token: 0x060007B7 RID: 1975 RVA: 0x00030F14 File Offset: 0x0002F114
		private void mStartSyncBtn_Click(object sender, RoutedEventArgs e)
		{
			this.mStartSyncBtn.IsEnabled = false;
			this.ParentWindow._TopBar.ShowSyncPanel(true);
			this.ParentWindow.mIsSyncMaster = true;
			if (!RegistryManager.Instance.IsSynchronizerUsedStatSent)
			{
				ClientStats.SendMiscellaneousStatsAsync("MultipleInstancesSynced", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null, null, null);
				RegistryManager.Instance.IsSynchronizerUsedStatSent = true;
			}
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			IEnumerable<CustomCheckbox> source = this.mActiveWindowsPanel.Children.OfType<CustomCheckbox>().Where(delegate(CustomCheckbox _)
			{
				bool? isChecked = _.IsChecked;
				bool flag = true;
				return isChecked.GetValueOrDefault() == flag & isChecked != null;
			});
			if (source.Count<CustomCheckbox>() > 0)
			{
				this.ParentWindow.mIsSynchronisationActive = true;
				dictionary.Add("instances", string.Join(",", (from _ in source
				select _.Tag.ToString()).ToArray<string>()));
				this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("startOperationsSync", dictionary);
				source.ToList<CustomCheckbox>().ForEach(delegate(CustomCheckbox customCheckbox)
				{
					BlueStacksUIUtils.DictWindows[customCheckbox.Tag.ToString()]._TopBar.ShowSyncPanel(false);
				});
			}
			foreach (CustomCheckbox customCheckbox2 in source.ToList<CustomCheckbox>())
			{
				if (!BlueStacksUIUtils.sSyncInvolvedInstances.Contains(customCheckbox2.Tag.ToString()))
				{
					BlueStacksUIUtils.sSyncInvolvedInstances.Add(customCheckbox2.Tag.ToString());
				}
			}
			if (!BlueStacksUIUtils.sSyncInvolvedInstances.Contains(this.ParentWindow.mVmName))
			{
				BlueStacksUIUtils.sSyncInvolvedInstances.Add(this.ParentWindow.mVmName);
			}
			this.UpdateOtherSyncWindows();
			this.Close_MouseLeftButtonUp(null, null);
		}

		// Token: 0x060007B8 RID: 1976 RVA: 0x00006FCC File Offset: 0x000051CC
		private void Close_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			base.Hide();
			this.ShowWithParentWindow = false;
			if (this.ParentWindow != null)
			{
				this.ParentWindow.Focus();
				this.ParentWindow.mFrontendHandler.ShowGLWindow();
			}
		}

		// Token: 0x060007B9 RID: 1977 RVA: 0x0002EF80 File Offset: 0x0002D180
		private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
		{
			try
			{
				Logger.Info("Opening url: " + e.Uri.AbsoluteUri);
				BlueStacksUIUtils.OpenUrl(e.Uri.AbsoluteUri);
				e.Handled = true;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in opening url" + ex.ToString());
			}
		}

		// Token: 0x060007BA RID: 1978 RVA: 0x00031110 File Offset: 0x0002F310
		private void mLaunchInstanceManagerBtn_Click(object sender, RoutedEventArgs e)
		{
			BlueStacksUIUtils.LaunchMultiInstanceManager();
			ClientStats.SendMiscellaneousStatsAsync("syncWindow", RegistryManager.Instance.UserGuid, "MultiInstance", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x060007BB RID: 1979 RVA: 0x00006FFF File Offset: 0x000051FF
		private void ToggleStartSyncButton()
		{
			if (this.ParentWindow.mSelectedInstancesForSync.Count > 0)
			{
				this.mStartSyncBtn.IsEnabled = true;
				return;
			}
			this.mStartSyncBtn.IsEnabled = false;
		}

		// Token: 0x060007BC RID: 1980 RVA: 0x00031160 File Offset: 0x0002F360
		private void ToggleSelectAllCheckboxSelection()
		{
			this.mStopEventFromPropagatingFurther = true;
			if (this.ParentWindow.mSelectedInstancesForSync.Count == this.mActiveWindowsPanel.Children.Count)
			{
				this.mSelectAllCheckbox.IsChecked = new bool?(true);
			}
			else
			{
				this.mSelectAllCheckbox.IsChecked = new bool?(false);
			}
			this.mStopEventFromPropagatingFurther = false;
		}

		// Token: 0x060007BD RID: 1981 RVA: 0x000311C4 File Offset: 0x0002F3C4
		private void SynchronizerWindow_Activated(object sender, EventArgs e)
		{
			if (this.mActiveWindowsPanel.Children.Count == 0)
			{
				if (FeatureManager.Instance.IsCustomUIForNCSoft)
				{
					this.Close_MouseLeftButtonUp(null, null);
				}
				else
				{
					this.mIsActiveWindowPresent = false;
					this.mActiveWindowsListScrollbar.Visibility = Visibility.Collapsed;
					this.mStartSyncBtn.Visibility = Visibility.Collapsed;
					this.mNoActiveWindowsGrid.Visibility = Visibility.Visible;
					this.mLaunchInstanceManagerBtn.Visibility = Visibility.Visible;
					this.mNoActiveWindowsGrid.Height = double.NaN;
					base.SizeToContent = SizeToContent.WidthAndHeight;
				}
			}
			base.Left = this.ParentWindow.Left + (this.ParentWindow.Width - base.Width) / 2.0;
			base.Top = this.ParentWindow.Top + (this.ParentWindow.Height - base.Height) / 2.0;
		}

		// Token: 0x060007BE RID: 1982 RVA: 0x000312A8 File Offset: 0x0002F4A8
		internal void PauseAllSyncOperations()
		{
			if (this.mStopEventFromPropagatingFurther)
			{
				return;
			}
			this.mStopEventFromPropagatingFurther = true;
			foreach (string key in this.ParentWindow.mSelectedInstancesForSync)
			{
				BlueStacksUIUtils.DictWindows[key]._TopBar.HideSyncPanel();
			}
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"pause",
					"true"
				}
			};
			HTTPUtils.SendRequestToEngineAsync("playPauseSync", data, this.ParentWindow.mVmName, 0, null, false, 1, 0);
			this.mStopEventFromPropagatingFurther = false;
		}

		// Token: 0x060007BF RID: 1983 RVA: 0x00031358 File Offset: 0x0002F558
		internal void StopAllSyncOperations()
		{
			if (this.mStopEventFromPropagatingFurther)
			{
				return;
			}
			this.mStopEventFromPropagatingFurther = true;
			this.ParentWindow.mIsSynchronisationActive = false;
			this.ParentWindow.mIsSyncMaster = false;
			foreach (string text in this.ParentWindow.mSelectedInstancesForSync)
			{
				BlueStacksUIUtils.DictWindows[text]._TopBar.HideSyncPanel();
				if (BlueStacksUIUtils.sSyncInvolvedInstances.Contains(text))
				{
					BlueStacksUIUtils.sSyncInvolvedInstances.Remove(text);
				}
			}
			if (BlueStacksUIUtils.sSyncInvolvedInstances.Contains(this.ParentWindow.mVmName))
			{
				BlueStacksUIUtils.sSyncInvolvedInstances.Remove(this.ParentWindow.mVmName);
			}
			this.UpdateOtherSyncWindows();
			this.ParentWindow.mSelectedInstancesForSync.Clear();
			this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("stopOperationsSync", new Dictionary<string, string>());
			this.Init();
			this.mStopEventFromPropagatingFurther = false;
		}

		// Token: 0x060007C0 RID: 1984 RVA: 0x0003146C File Offset: 0x0002F66C
		internal void PlayAllSyncOperations()
		{
			if (this.mStopEventFromPropagatingFurther)
			{
				return;
			}
			this.mStopEventFromPropagatingFurther = true;
			foreach (string key in this.ParentWindow.mSelectedInstancesForSync)
			{
				BlueStacksUIUtils.DictWindows[key]._TopBar.ShowSyncPanel(false);
			}
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"pause",
					"false"
				}
			};
			HTTPUtils.SendRequestToEngineAsync("playPauseSync", data, this.ParentWindow.mVmName, 0, null, false, 1, 0);
			this.mStopEventFromPropagatingFurther = false;
		}

		// Token: 0x060007C1 RID: 1985 RVA: 0x0003151C File Offset: 0x0002F71C
		private void UpdateOtherSyncWindows()
		{
			try
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
					{
						if (keyValuePair.Key != this.ParentWindow.mVmName && keyValuePair.Value.mSynchronizerWindow != null && keyValuePair.Value.mSynchronizerWindow.IsVisible)
						{
							keyValuePair.Value.mSynchronizerWindow.Init();
						}
					}
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in updating instances for sync operation: " + ex.ToString());
			}
		}

		// Token: 0x060007C2 RID: 1986 RVA: 0x00031574 File Offset: 0x0002F774
		private string GetInstanceGameOrDisplayName(string vmName)
		{
			string appName = BlueStacksUIUtils.DictWindows[vmName]._TopBar.AppName;
			string characterName = BlueStacksUIUtils.DictWindows[vmName]._TopBar.CharacterName;
			string result;
			if (!string.IsNullOrEmpty(appName) && !string.IsNullOrEmpty(characterName))
			{
				result = appName + " " + characterName;
			}
			else
			{
				result = Utils.GetDisplayName(vmName);
			}
			return result;
		}

		// Token: 0x060007C3 RID: 1987 RVA: 0x000315D4 File Offset: 0x0002F7D4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/synchronizerwindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060007C4 RID: 1988 RVA: 0x00031604 File Offset: 0x0002F804
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((SynchronizerWindow)target).Activated += this.SynchronizerWindow_Activated;
				return;
			case 2:
				this.mMaskBorder = (Border)target;
				return;
			case 3:
				this.mTopGrid = (Grid)target;
				this.mTopGrid.MouseDown += this.Topbar_MouseDown;
				return;
			case 4:
				((CustomPictureBox)target).MouseLeftButtonUp += this.Close_MouseLeftButtonUp;
				return;
			case 5:
				this.mLineSeperator = (Border)target;
				return;
			case 6:
				this.mNoActiveWindowsGrid = (Grid)target;
				return;
			case 7:
				this.mActiveWindowsListScrollbar = (ScrollViewer)target;
				return;
			case 8:
				this.mSelectAllCheckbox = (CustomCheckbox)target;
				this.mSelectAllCheckbox.Checked += this.mSelectAll_Checked;
				this.mSelectAllCheckbox.Unchecked += this.mSelectAll_Unchecked;
				return;
			case 9:
				this.mActiveWindowsPanel = (StackPanel)target;
				return;
			case 10:
				this.mBottomGrid = (Grid)target;
				return;
			case 11:
				this.mLineSeperator1 = (Border)target;
				return;
			case 12:
				this.mStartSyncBtn = (CustomButton)target;
				this.mStartSyncBtn.Click += this.mStartSyncBtn_Click;
				return;
			case 13:
				this.mLaunchInstanceManagerBtn = (CustomButton)target;
				this.mLaunchInstanceManagerBtn.Click += this.mLaunchInstanceManagerBtn_Click;
				return;
			case 14:
				this.mSyncHelp = (TextBlock)target;
				return;
			case 15:
				this.mHyperLink = (Hyperlink)target;
				this.mHyperLink.RequestNavigate += this.Hyperlink_RequestNavigate;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000587 RID: 1415
		private MainWindow ParentWindow;

		// Token: 0x04000588 RID: 1416
		private bool mIsActiveWindowPresent;

		// Token: 0x04000589 RID: 1417
		private bool mStopEventFromPropagatingFurther;

		// Token: 0x0400058A RID: 1418
		internal Border mMaskBorder;

		// Token: 0x0400058B RID: 1419
		internal Grid mTopGrid;

		// Token: 0x0400058C RID: 1420
		internal Border mLineSeperator;

		// Token: 0x0400058D RID: 1421
		internal Grid mNoActiveWindowsGrid;

		// Token: 0x0400058E RID: 1422
		internal ScrollViewer mActiveWindowsListScrollbar;

		// Token: 0x0400058F RID: 1423
		internal CustomCheckbox mSelectAllCheckbox;

		// Token: 0x04000590 RID: 1424
		internal StackPanel mActiveWindowsPanel;

		// Token: 0x04000591 RID: 1425
		internal Grid mBottomGrid;

		// Token: 0x04000592 RID: 1426
		internal Border mLineSeperator1;

		// Token: 0x04000593 RID: 1427
		internal CustomButton mStartSyncBtn;

		// Token: 0x04000594 RID: 1428
		internal CustomButton mLaunchInstanceManagerBtn;

		// Token: 0x04000595 RID: 1429
		internal TextBlock mSyncHelp;

		// Token: 0x04000596 RID: 1430
		internal Hyperlink mHyperLink;

		// Token: 0x04000597 RID: 1431
		private bool _contentLoaded;
	}
}
