﻿using System;

// Token: 0x02000004 RID: 4
[Serializable]
public class Alias : IMAction
{
	// Token: 0x1700001E RID: 30
	// (get) Token: 0x06000040 RID: 64 RVA: 0x000022E7 File Offset: 0x000004E7
	// (set) Token: 0x06000041 RID: 65 RVA: 0x000022EF File Offset: 0x000004EF
	public string KeyIn
	{
		get
		{
			return this.mKeyIn;
		}
		set
		{
			this.mKeyIn = value;
		}
	}

	// Token: 0x1700001F RID: 31
	// (get) Token: 0x06000042 RID: 66 RVA: 0x000022F8 File Offset: 0x000004F8
	// (set) Token: 0x06000043 RID: 67 RVA: 0x00002300 File Offset: 0x00000500
	public string KeyOut
	{
		get
		{
			return this.mKeyOut;
		}
		set
		{
			this.mKeyOut = value;
		}
	}

	// Token: 0x04000023 RID: 35
	private string mKeyIn;

	// Token: 0x04000024 RID: 36
	private string mKeyOut;
}
