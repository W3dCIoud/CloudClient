﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000A2 RID: 162
	public class QuitPopupControl : UserControl, IDimOverlayControl, IComponentConnector
	{
		// Token: 0x1700014E RID: 334
		// (get) Token: 0x060006EC RID: 1772 RVA: 0x00004D85 File Offset: 0x00002F85
		// (set) Token: 0x060006ED RID: 1773 RVA: 0x00004BF2 File Offset: 0x00002DF2
		bool IDimOverlayControl.IsCloseOnOverLayClick
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		// Token: 0x1700014F RID: 335
		// (get) Token: 0x060006EE RID: 1774 RVA: 0x0000681E File Offset: 0x00004A1E
		// (set) Token: 0x060006EF RID: 1775 RVA: 0x00006826 File Offset: 0x00004A26
		public bool ShowControlInSeparateWindow
		{
			get
			{
				return this.mShowControlInSeparateWindow;
			}
			set
			{
				this.mShowControlInSeparateWindow = value;
			}
		}

		// Token: 0x060006F0 RID: 1776 RVA: 0x0000682F File Offset: 0x00004A2F
		bool IDimOverlayControl.Close()
		{
			this.Close();
			return true;
		}

		// Token: 0x060006F1 RID: 1777 RVA: 0x00004DA3 File Offset: 0x00002FA3
		bool IDimOverlayControl.Show()
		{
			base.Visibility = Visibility.Visible;
			return true;
		}

		// Token: 0x060006F2 RID: 1778 RVA: 0x00006839 File Offset: 0x00004A39
		public QuitPopupControl(MainWindow window)
		{
			this.ParentWindow = window;
			this.InitializeComponent();
		}

		// Token: 0x060006F3 RID: 1779 RVA: 0x00006860 File Offset: 0x00004A60
		private void Close_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.Close();
			ClientStats.SendLocalQuitPopupStatsAsync(this.CurrentPopupTag, "click_action_close");
		}

		// Token: 0x17000150 RID: 336
		// (get) Token: 0x060006F4 RID: 1780 RVA: 0x00006879 File Offset: 0x00004A79
		public TextBlock TitleTextBlock
		{
			get
			{
				return this.mTitleText;
			}
		}

		// Token: 0x17000151 RID: 337
		// (get) Token: 0x060006F5 RID: 1781 RVA: 0x00006881 File Offset: 0x00004A81
		public CustomButton CloseBlueStacksButton
		{
			get
			{
				return this.mCloseBlueStacksButton;
			}
		}

		// Token: 0x17000152 RID: 338
		// (get) Token: 0x060006F6 RID: 1782 RVA: 0x00006889 File Offset: 0x00004A89
		public CustomPictureBox CrossButtonPictureBox
		{
			get
			{
				return this.mCrossButtonPictureBox;
			}
		}

		// Token: 0x060006F7 RID: 1783 RVA: 0x00006891 File Offset: 0x00004A91
		private void MCloseBlueStacksButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.Close();
			if (this.HasSuccessfulEventOccured)
			{
				ClientStats.SendLocalQuitPopupStatsAsync(this.CurrentPopupTag, "click_action_continue_bluestacks");
				return;
			}
			ClientStats.SendLocalQuitPopupStatsAsync(this.CurrentPopupTag, "popup_closed");
		}

		// Token: 0x17000153 RID: 339
		// (get) Token: 0x060006F8 RID: 1784 RVA: 0x000068C3 File Offset: 0x00004AC3
		// (set) Token: 0x060006F9 RID: 1785 RVA: 0x000068CB File Offset: 0x00004ACB
		public bool HasSuccessfulEventOccured
		{
			get
			{
				return this.mHasSuccessfulEventOccured;
			}
			set
			{
				if (value)
				{
					this.mHasSuccessfulEventOccured = value;
					this.mTitleGrid.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#0BA200");
				}
			}
		}

		// Token: 0x17000154 RID: 340
		// (get) Token: 0x060006FA RID: 1786 RVA: 0x000068F6 File Offset: 0x00004AF6
		// (set) Token: 0x060006FB RID: 1787 RVA: 0x000068FE File Offset: 0x00004AFE
		public string CurrentPopupTag { get; set; } = string.Empty;

		// Token: 0x060006FC RID: 1788 RVA: 0x0002B8F0 File Offset: 0x00029AF0
		public void AddQuitActionItem(QuitActionItem item)
		{
			QuitActionElement quitActionElement = new QuitActionElement();
			quitActionElement.Width = 190.0;
			quitActionElement.ActionElement = item;
			quitActionElement.ParentPopupTag = this.CurrentPopupTag;
			this.mQuitElementStackPanel.Children.Add(quitActionElement);
		}

		// Token: 0x060006FD RID: 1789 RVA: 0x0002B938 File Offset: 0x00029B38
		internal bool Close()
		{
			try
			{
				BlueStacksUIUtils.CloseContainerWindow(this);
				this.ParentWindow.HideDimOverlay();
				base.Visibility = Visibility.Hidden;
				return true;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while trying to close quitpopup from dimoverlay " + ex.ToString());
			}
			return false;
		}

		// Token: 0x060006FE RID: 1790 RVA: 0x0002B98C File Offset: 0x00029B8C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/quitpopupcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060006FF RID: 1791 RVA: 0x0002B9BC File Offset: 0x00029BBC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mParentGrid = (Grid)target;
				return;
			case 2:
				this.mTitleGrid = (Grid)target;
				return;
			case 3:
				this.mCrossButtonPictureBox = (CustomPictureBox)target;
				this.mCrossButtonPictureBox.PreviewMouseLeftButtonUp += this.Close_PreviewMouseLeftButtonUp;
				return;
			case 4:
				this.mTitleText = (TextBlock)target;
				return;
			case 5:
				this.mOptionsGrid = (Grid)target;
				return;
			case 6:
				this.mQuitElementStackPanel = (StackPanel)target;
				return;
			case 7:
				this.mFooterGrid = (Grid)target;
				return;
			case 8:
				this.mCloseBlueStacksButton = (CustomButton)target;
				this.mCloseBlueStacksButton.PreviewMouseLeftButtonUp += this.MCloseBlueStacksButton_PreviewMouseLeftButtonUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040004AF RID: 1199
		private bool mShowControlInSeparateWindow = true;

		// Token: 0x040004B0 RID: 1200
		private MainWindow ParentWindow;

		// Token: 0x040004B1 RID: 1201
		private bool mHasSuccessfulEventOccured;

		// Token: 0x040004B3 RID: 1203
		internal Grid mParentGrid;

		// Token: 0x040004B4 RID: 1204
		internal Grid mTitleGrid;

		// Token: 0x040004B5 RID: 1205
		internal CustomPictureBox mCrossButtonPictureBox;

		// Token: 0x040004B6 RID: 1206
		internal TextBlock mTitleText;

		// Token: 0x040004B7 RID: 1207
		internal Grid mOptionsGrid;

		// Token: 0x040004B8 RID: 1208
		internal StackPanel mQuitElementStackPanel;

		// Token: 0x040004B9 RID: 1209
		internal Grid mFooterGrid;

		// Token: 0x040004BA RID: 1210
		internal CustomButton mCloseBlueStacksButton;

		// Token: 0x040004BB RID: 1211
		private bool _contentLoaded;
	}
}
