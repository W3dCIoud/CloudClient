﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace BlueStacks.BlueStacksUI.Properties
{
	// Token: 0x0200023E RID: 574
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "14.0.0.0")]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x17000227 RID: 551
		// (get) Token: 0x060013E0 RID: 5088 RVA: 0x0000E0F2 File Offset: 0x0000C2F2
		public static Settings Default
		{
			get
			{
				return Settings.defaultInstance;
			}
		}

		// Token: 0x04000DDB RID: 3547
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());
	}
}
