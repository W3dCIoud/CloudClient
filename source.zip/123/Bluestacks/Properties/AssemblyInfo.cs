﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Security.Permissions;
using System.Windows.Resources;

[assembly: AssemblyVersion("3.0.0.0")]
[assembly: AssemblyTitle("CloudClient")]
[assembly: AssemblyCompany("dsc.gg/cloudclientbs")]
[assembly: AssemblyProduct("CloudClient")]
[assembly: AssemblyCopyright("By W3dCloud, dsc.gg/cloudclientbs")]
[assembly: AssemblyFileVersion("3.0")]
[assembly: AssemblyAssociatedContentFile("productlogo.ico")]
[assembly: CLSCompliant(true)]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
