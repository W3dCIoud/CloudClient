﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using System.Windows.Threading;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200006E RID: 110
	public class Sidebar : UserControl, IComponentConnector
	{
		// Token: 0x1700013A RID: 314
		// (get) Token: 0x060004C1 RID: 1217 RVA: 0x0000522E File Offset: 0x0000342E
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x060004C2 RID: 1218 RVA: 0x0001FD9C File Offset: 0x0001DF9C
		public Sidebar()
		{
			this.InitializeComponent();
			this.mMoreButton.Image.ImageName = "sidebar_options_close";
			if (this.mListPopups == null)
			{
				this.mListPopups = new List<CustomPopUp>(8);
				this.mListPopups.Add(this.mKeyMapPopup);
				this.mListPopups.Add(this.mChangeTransparencyPopup);
				this.mListPopups.Add(this.mVolumeSliderPopup);
				this.mListPopups.Add(this.mOverlayTooltip);
				this.mListPopups.Add(this.mMacroButtonPopup);
				this.mListPopups.Add(this.mGameControlButtonPopup);
				this.mListPopups.Add(this.mRecordScreenPopup);
				this.mListPopups.Add(this.mScreenshotPopup);
				this.mListPopups.Add(this.mMoreElements);
			}
			BlueStacksUIBinding.Instance.PropertyChanged += this.BlueStacksUIBinding_PropertyChanged;
		}

		// Token: 0x060004C3 RID: 1219 RVA: 0x0000524F File Offset: 0x0000344F
		private void BlueStacksUIBinding_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			if (e.PropertyName == "LocaleModel")
			{
				this.ParentWindow.mCommonHandler.ReloadTooltips();
			}
		}

		// Token: 0x060004C4 RID: 1220 RVA: 0x0001FEB4 File Offset: 0x0001E0B4
		internal void BindEvents()
		{
			this.ParentWindow.CursorLockChangedEvent += this.ParentWindow_CursorLockChangedEvent;
			this.ParentWindow.FullScreenChangedEvent += this.ParentWindow_FullScreenChangedEvent;
			this.ParentWindow.FrontendGridVisibleChangedEvent += this.ParentWindow_FrontendGridVisibleChangedEvent;
			this.ParentWindow.mCommonHandler.ScreenRecordingStateChangedEvent += this.ParentWindow_ScreenRecordingStateChangedEvent;
			this.ParentWindow.mCommonHandler.OverlayStateChangedEvent += this.ParentWindow_OverlayStateChangedEvent;
			this.ParentWindow.mCommonHandler.MacroButtonVisibilityChangedEvent += this.ParentWindow_MacroButtonVisibilityChangedEvent;
			this.ParentWindow.mCommonHandler.OperationSyncButtonVisibilityChangedEvent += this.ParentWindow_OperationSyncButtonVisibilityChangedEvent;
			this.ParentWindow.mCommonHandler.ScreenRecorderStateTransitioningEvent += this.ParentWindow_ScreenRecordingInitingEvent;
			this.ParentWindow.mCommonHandler.OBSResponseTimeoutEvent += this.ParentWindow_OBSResponseTimeoutEvent;
			this.ParentWindow.mCommonHandler.BTvDownloaderMinimizedEvent += this.ParentWindow_BTvDownloaderMinimizedEvent;
			this.ParentWindow.mCommonHandler.GamepadButtonVisibilityChangedEvent += this.ParentWindow_GamepadButtonVisibilityChangedEvent;
			this.ParentWindow.mCommonHandler.VolumeChangedEvent += this.ParentWindow_VolumeChangedEvent;
			this.ParentWindow.mCommonHandler.VolumeMutedEvent += this.ParentWindow_VolumeMutedEvent;
			PromotionObject.AppSpecificRulesHandler = (EventHandler)Delegate.Combine(PromotionObject.AppSpecificRulesHandler, new EventHandler(this.PromotionUpdated));
			if (this.ParentWindow.mGuestBootCompleted)
			{
				this.ParentWindow_GuestBootCompletedEvent();
				return;
			}
			this.ParentWindow.GuestBootCompletedEvent += this.ParentWindow_GuestBootCompletedEvent;
		}

		// Token: 0x060004C5 RID: 1221 RVA: 0x00005273 File Offset: 0x00003473
		private void PromotionUpdated(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.ToggleMacroAndSyncVisibility();
		}

		// Token: 0x060004C6 RID: 1222 RVA: 0x00005285 File Offset: 0x00003485
		public void UpdateMuteAllInstancesCheckbox()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (RegistryManager.Instance.AreAllInstancesMuted)
				{
					this.mMuteInstancesCheckboxImage.ImageName = "bgpcheckbox_checked";
					return;
				}
				this.mMuteInstancesCheckboxImage.ImageName = "bgpcheckbox";
			}), new object[0]);
		}

		// Token: 0x060004C7 RID: 1223 RVA: 0x0002006C File Offset: 0x0001E26C
		private void ParentWindow_VolumeMutedEvent(bool muted)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (muted)
				{
					this.mVolumeMuteUnmuteImage.ImageName = "sidebar_volume_muted_popup";
					this.UpdateImage("sidebar_volume", "sidebar_volume_muted");
					BlueStacksUIBinding.Bind(this.mVolumeMuteUnmuteImage, "STRING_UNMUTE_VOLUME");
				}
				else
				{
					this.mVolumeMuteUnmuteImage.ImageName = "sidebar_volume_popup";
					this.UpdateToDefaultImage("sidebar_volume");
					BlueStacksUIBinding.Bind(this.mVolumeMuteUnmuteImage, "STRING_MUTE_VOLUME");
				}
				this.UpdateMuteAllInstancesCheckbox();
			}), new object[0]);
		}

		// Token: 0x060004C8 RID: 1224 RVA: 0x000200B0 File Offset: 0x0001E2B0
		private void ParentWindow_VolumeChangedEvent(int volumeLevel)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.mVolumeSlider.Value = (double)volumeLevel;
				this.mCurrentVolumeValue.Text = volumeLevel.ToString();
			}), new object[0]);
		}

		// Token: 0x060004C9 RID: 1225 RVA: 0x000052AA File Offset: 0x000034AA
		private void ParentWindow_GamepadButtonVisibilityChangedEvent(bool visibility)
		{
			this.ChangeElementState("sidebar_gamepad", visibility);
		}

		// Token: 0x060004CA RID: 1226 RVA: 0x000200F4 File Offset: 0x0001E2F4
		private void ParentWindow_BTvDownloaderMinimizedEvent()
		{
			this.RecordScreenPopupHeader.Visibility = Visibility.Collapsed;
			this.RecordScreenPopupBody.Visibility = Visibility.Visible;
			this.RecordScreenPopupHyperlink.Visibility = Visibility.Collapsed;
			BlueStacksUIBinding.Bind(this.RecordScreenPopupBody, "STRING_DOWNLOAD_BACKGROUND", "");
			this.mRecordScreenPopup.StaysOpen = false;
			this.mRecordScreenPopup.IsOpen = true;
		}

		// Token: 0x060004CB RID: 1227 RVA: 0x000052B8 File Offset: 0x000034B8
		private void ParentWindow_OBSResponseTimeoutEvent()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				SidebarElement elementFromTag = this.GetElementFromTag("sidebar_video_capture");
				elementFromTag.Image.IsImageToBeRotated = false;
				this.UpdateToDefaultImage(elementFromTag);
			}), new object[0]);
		}

		// Token: 0x060004CC RID: 1228 RVA: 0x00020154 File Offset: 0x0001E354
		private void ParentWindow_ScreenRecordingInitingEvent()
		{
			SidebarElement elementFromTag = this.GetElementFromTag("sidebar_video_capture");
			this.UpdateImage(elementFromTag, "sidebar_video_loading");
			elementFromTag.Image.Visibility = Visibility.Hidden;
			elementFromTag.Image.IsImageToBeRotated = true;
			elementFromTag.Image.Visibility = Visibility.Visible;
			this.RecordScreenPopupHyperlink.Visibility = Visibility.Collapsed;
			this.RecordScreenPopupBody.Visibility = Visibility.Collapsed;
			this.mRecordScreenClose.Visibility = Visibility.Collapsed;
		}

		// Token: 0x060004CD RID: 1229 RVA: 0x000052DD File Offset: 0x000034DD
		private void ParentWindow_OperationSyncButtonVisibilityChangedEvent(bool isVisible)
		{
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				return;
			}
			this.ToggleElementVisibilty("sidebar_operation", isVisible);
		}

		// Token: 0x060004CE RID: 1230 RVA: 0x000201C4 File Offset: 0x0001E3C4
		private void ToggleElementVisibilty(SidebarElement ele, bool isVisible)
		{
			if (ele != null)
			{
				if (isVisible)
				{
					ele.Visibility = Visibility.Visible;
				}
				else
				{
					ele.Visibility = Visibility.Collapsed;
				}
				if (ele.IsInMainSidebar)
				{
					int num = this.mElementsStackPanel.Children.IndexOf(ele);
					int num2 = this.mListSidebarElements.IndexOf(ele);
					if (num != -1 && num != num2)
					{
						this.mElementsStackPanel.Children.RemoveAt(num);
						int count = this.mElementsStackPanel.Children.Count;
						if (num2 >= count)
						{
							ele.IsInMainSidebar = false;
						}
						else
						{
							this.mElementsStackPanel.Children.Insert(num2 + 1, ele);
						}
					}
				}
				this.FixMarginOfSurroundingElement(ele);
				this.UpdateTotalVisibleElementCount();
				this.ArrangeAllSidebarElements();
			}
		}

		// Token: 0x060004CF RID: 1231 RVA: 0x00020270 File Offset: 0x0001E470
		private SidebarElement GetPreviousVisibleSidebarElement(SidebarElement ele)
		{
			SidebarElement previousSidebarElement = this.GetPreviousSidebarElement(ele);
			if (previousSidebarElement.Visibility != Visibility.Visible)
			{
				return this.GetPreviousSidebarElement(previousSidebarElement);
			}
			return previousSidebarElement;
		}

		// Token: 0x060004D0 RID: 1232 RVA: 0x00020298 File Offset: 0x0001E498
		private SidebarElement GetPreviousSidebarElement(SidebarElement ele)
		{
			int num = this.mListSidebarElements.IndexOf(ele);
			if (num != 0)
			{
				return this.mListSidebarElements[num - 1];
			}
			return ele;
		}

		// Token: 0x060004D1 RID: 1233 RVA: 0x000202C8 File Offset: 0x0001E4C8
		private void FixMarginOfSurroundingElement(SidebarElement currentElement)
		{
			if (currentElement != null && currentElement.Visibility == Visibility.Visible)
			{
				if (currentElement.IsLastElementOfGroup)
				{
					if (currentElement.IsCurrentLastElementOfGroup)
					{
						return;
					}
					currentElement.IsCurrentLastElementOfGroup = true;
					this.IncreaseElementBottomMarginIfLast(currentElement);
					SidebarElement previousVisibleSidebarElement = this.GetPreviousVisibleSidebarElement(currentElement);
					if (previousVisibleSidebarElement != currentElement)
					{
						previousVisibleSidebarElement.IsCurrentLastElementOfGroup = false;
						this.DecreaseElementBottomMargin(previousVisibleSidebarElement);
						Thickness margin = previousVisibleSidebarElement.Margin;
						margin.Bottom = 2.0;
						previousVisibleSidebarElement.Margin = margin;
						return;
					}
				}
			}
			else if (currentElement.IsCurrentLastElementOfGroup)
			{
				currentElement.IsCurrentLastElementOfGroup = false;
				SidebarElement previousVisibleSidebarElement2 = this.GetPreviousVisibleSidebarElement(currentElement);
				if (previousVisibleSidebarElement2 != currentElement)
				{
					previousVisibleSidebarElement2.IsCurrentLastElementOfGroup = true;
					this.IncreaseElementBottomMarginIfLast(previousVisibleSidebarElement2);
				}
			}
		}

		// Token: 0x060004D2 RID: 1234 RVA: 0x00020364 File Offset: 0x0001E564
		private void ToggleElementVisibilty(string elementKey, bool isVisible)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.ToggleElementVisibilty(this.GetElementFromTag(elementKey), isVisible);
			}), new object[0]);
		}

		// Token: 0x060004D3 RID: 1235 RVA: 0x000052F8 File Offset: 0x000034F8
		private void ParentWindow_MacroButtonVisibilityChangedEvent(bool isVisible)
		{
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				return;
			}
			this.ToggleElementVisibilty("sidebar_macro", isVisible);
		}

		// Token: 0x060004D4 RID: 1236 RVA: 0x000203B0 File Offset: 0x0001E5B0
		private void ParentWindow_OverlayStateChangedEvent(bool isEnabled)
		{
			SidebarElement elementFromTag = this.GetElementFromTag("sidebar_overlay");
			if (isEnabled)
			{
				this.UpdateToDefaultImage(elementFromTag);
				if (RegistryManager.Instance.TranslucentControlsTransparency == 0.0)
				{
					if (this.mLastSliderValue == 0.0)
					{
						RegistryManager.Instance.TranslucentControlsTransparency = 0.5;
						this.transSlider.Value = 0.5;
						return;
					}
					RegistryManager.Instance.TranslucentControlsTransparency = this.mLastSliderValue;
					this.transSlider.Value = this.mLastSliderValue;
					return;
				}
			}
			else
			{
				this.UpdateImage(elementFromTag, "sidebar_overlay_inactive");
				double value = this.transSlider.Value;
				this.transSlider.Value = 0.0;
				this.mLastSliderValue = value;
			}
		}

		// Token: 0x060004D5 RID: 1237 RVA: 0x00005313 File Offset: 0x00003513
		private void MSidebarPopup_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mMoreElements.IsOpen)
			{
				this.mMoreElements.IsOpen = false;
			}
		}

		// Token: 0x060004D6 RID: 1238 RVA: 0x0002047C File Offset: 0x0001E67C
		private void ParentWindow_ScreenRecordingStateChangedEvent(bool isRecording)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				SidebarElement elementFromTag = this.GetElementFromTag("sidebar_video_capture");
				elementFromTag.Image.IsImageToBeRotated = false;
				if (isRecording)
				{
					this.UpdateImage(elementFromTag, "sidebar_video_capture_active");
					this.ChangeElementState("sidebar_fullscreen", false);
					BlueStacksUIBinding.Bind(this.RecordScreenPopupHeader, "STRING_STOP_RECORDING", "");
					this.RecordScreenPopupHyperlink.Visibility = Visibility.Collapsed;
					this.RecordScreenPopupBody.Visibility = Visibility.Collapsed;
					this.mRecordScreenClose.Visibility = Visibility.Collapsed;
				}
				else
				{
					this.UpdateToDefaultImage(elementFromTag);
					this.RecordScreenPopupBody.Visibility = Visibility.Visible;
					BlueStacksUIBinding.Bind(this.RecordScreenPopupHeader, "STRING_RECORDING_SAVED", "");
					BlueStacksUIBinding.Bind(this.RecordScreenPopupBody, "STRING_CLICK_TO_SEE_VIDEO", "");
					this.RecordScreenPopupBody.Visibility = Visibility.Collapsed;
					this.RecordScreenPopupHyperlink.Visibility = Visibility.Visible;
					BlueStacksUIBinding.Bind(this.mRecorderClickLink, "STRING_CLICK_TO_SEE_VIDEO", "");
					this.RecordScreenPopupBody.Visibility = Visibility.Visible;
					this.mRecordScreenClose.Visibility = Visibility.Visible;
					if (this.ParentWindow.mIsWindowInFocus && elementFromTag.IsInMainSidebar)
					{
						this.mRecordScreenPopup.PlacementTarget = elementFromTag;
						this.mRecordScreenPopup.StaysOpen = false;
						this.mRecordScreenPopup.IsOpen = true;
					}
					else
					{
						this.ParentWindow.ShowGeneralToast(LocaleStrings.GetLocalizedString("STRING_RECORDING_SAVED", false));
					}
					if (this.ParentWindow.mFrontendGrid.IsVisible)
					{
						this.ChangeElementState("sidebar_fullscreen", true);
					}
				}
				this.SetVideoRecordingTooltip(isRecording);
			}), new object[0]);
		}

		// Token: 0x060004D7 RID: 1239 RVA: 0x000204C0 File Offset: 0x0001E6C0
		internal void ShowScreenshotSavedPopup(string screenshotPath)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				SidebarElement elementFromTag = this.GetElementFromTag("sidebar_screenshot");
				this.SetSidebarElementTooltip(elementFromTag, "STRING_TOOLBAR_CAMERA");
				if (this.ParentWindow.mIsWindowInFocus && elementFromTag.IsInMainSidebar)
				{
					this.mScreenshotPopup.PlacementTarget = elementFromTag;
					this.mScreenshotPopup.StaysOpen = false;
					this.mScreenshotPopup.IsOpen = true;
					this.currentScreenshotSavedPath = screenshotPath;
				}
			}), new object[0]);
		}

		// Token: 0x060004D8 RID: 1240 RVA: 0x00020504 File Offset: 0x0001E704
		private void ParentWindow_FrontendGridVisibleChangedEvent(bool isVisible)
		{
			this.ChangeElementState("sidebar_lock_cursor", isVisible);
			if (!CommonHandlers.sIsRecordingVideo)
			{
				this.ChangeElementState("sidebar_fullscreen", isVisible);
			}
			this.ChangeElementState("sidebar_toggle", isVisible);
			this.ChangeElementState("sidebar_controls", isVisible);
			this.ChangeElementState("sidebar_overlay", isVisible);
			this.ChangeElementState("sidebar_back", isVisible);
			this.ChangeElementState("sidebar_home", isVisible);
			this.ChangeElementState("sidebar_screenshot", isVisible);
			this.ChangeElementState("sidebar_video_capture", isVisible);
			if (!isVisible)
			{
				this.ChangeElementState("sidebar_gamepad", isVisible);
			}
		}

		// Token: 0x060004D9 RID: 1241 RVA: 0x00020594 File Offset: 0x0001E794
		private void InitDefaultSettings()
		{
			if (this.ParentWindow.mIsFullScreen)
			{
				this.UpdateImage("sidebar_fullscreen", "sidebar_fullscreen_minimize");
			}
			if (!FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.ToggleElementVisibilty("sidebar_macro", false);
				this.ToggleElementVisibilty("sidebar_operation", false);
				if (RegistryManager.Instance.TranslucentControlsTransparency == 0.0)
				{
					this.UpdateImage("sidebar_overlay", "sidebar_overlay_inactive");
					this.mTranslucentControlsSliderButton.ImageName = "sidebar_overlay_inactive_popup";
				}
			}
			else
			{
				this.ToggleElementVisibilty("sidebar_overlay", false);
				this.ToggleElementVisibilty("sidebar_overlay_inactive", false);
			}
			this.SetupVolumeInitState();
			this.transSlider.Value = RegistryManager.Instance.TranslucentControlsTransparency;
			this.mOverlayPopUpMessage.Text = string.Format(LocaleStrings.GetLocalizedString("STRING_ON_SCREEN_CONTROLS_BODY", false), this.ParentWindow.mCommonHandler.GetShortcutKeyFromName("STRING_TOGGLE_OVERLAY", false));
		}

		// Token: 0x060004DA RID: 1242 RVA: 0x00020680 File Offset: 0x0001E880
		private void SetupVolumeInitState()
		{
			if (this.ParentWindow.EngineInstanceRegistry.IsMuted)
			{
				this.UpdateImage("sidebar_volume", "sidebar_volume_muted");
				this.mVolumeMuteUnmuteImage.ImageName = "sidebar_volume_muted_popup";
			}
			this.UpdateMuteAllInstancesCheckbox();
			this.mVolumeSlider.Value = (double)this.ParentWindow.Utils.CurrentVolumeLevel;
			this.mCurrentVolumeValue.Text = this.ParentWindow.Utils.CurrentVolumeLevel.ToString();
		}

		// Token: 0x060004DB RID: 1243 RVA: 0x00020704 File Offset: 0x0001E904
		internal void ToggleSidebarVisibilityInFullscreen(bool isVisible)
		{
			this.ParentWindow.mFullscreenSidebarPopup.IsOpen = isVisible;
			if (isVisible)
			{
				this.ParentWindow.mFullscreenSidebarPopup.Height = this.ParentWindow.MainGrid.ActualHeight;
				this.ParentWindow.mFullscreenSidebarPopup.HorizontalOffset = this.ParentWindow.MainGrid.ActualWidth / 2.0;
				this.ParentWindow.mFullscreenSidebarPopupInnerGrid.Height = this.ParentWindow.MainGrid.ActualHeight;
				return;
			}
			this.mListPopups.All((CustomPopUp x) => x.IsOpen = false);
		}

		// Token: 0x060004DC RID: 1244 RVA: 0x000207BC File Offset: 0x0001E9BC
		private void ParentWindow_FullScreenChangedEvent(bool isFullScreen)
		{
			object obj = this.mSyncRoot;
			lock (obj)
			{
				this.mIsInFullscreenMode = isFullScreen;
				this.SetupSidebarForFullscreen(isFullScreen);
				if (isFullScreen)
				{
					this.UpdateImage("sidebar_fullscreen", "sidebar_fullscreen_minimize");
					this.ChangeElementState("sidebar_lock_cursor", false);
				}
				else
				{
					this.UpdateImage("sidebar_fullscreen", "sidebar_fullscreen");
					this.ParentWindow.mFullscreenSidebarPopup.IsOpen = false;
					if (this.ParentWindow.mFrontendGrid.IsVisible)
					{
						this.ChangeElementState("sidebar_lock_cursor", true);
					}
				}
				this.ArrangeAllSidebarElements();
			}
		}

		// Token: 0x060004DD RID: 1245 RVA: 0x00020864 File Offset: 0x0001EA64
		private void SetupSidebarForFullscreen(bool isFullScreen)
		{
			if (isFullScreen)
			{
				if (this.ParentWindow.mMainWindowTopGrid.Children.Contains(this))
				{
					this.ParentWindow.mMainWindowTopGrid.Children.Remove(this);
					this.ParentWindow.mFullscreenSidebarPopupInnerGrid.Children.Add(this);
					base.MouseLeave += this.Sidebar_MouseLeave;
				}
				base.Visibility = Visibility.Visible;
				return;
			}
			if (this.ParentWindow.mFullscreenSidebarPopupInnerGrid.Children.Contains(this))
			{
				this.ParentWindow.mFullscreenSidebarPopupInnerGrid.Children.Remove(this);
				this.ParentWindow.mMainWindowTopGrid.Children.Add(this);
				base.MouseLeave -= this.Sidebar_MouseLeave;
			}
			if (this.ParentWindow.EngineInstanceRegistry.IsSidebarVisible)
			{
				base.Visibility = Visibility.Visible;
				return;
			}
			base.Visibility = Visibility.Collapsed;
		}

		// Token: 0x060004DE RID: 1246 RVA: 0x0000532E File Offset: 0x0000352E
		private void Sidebar_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!base.IsMouseOver)
			{
				if (this.mListPopups.All((CustomPopUp x) => !x.IsOpen))
				{
					this.ToggleSidebarVisibilityInFullscreen(false);
				}
			}
		}

		// Token: 0x060004DF RID: 1247 RVA: 0x0000536B File Offset: 0x0000356B
		private void ParentWindow_CursorLockChangedEvent(bool locked)
		{
			if (locked)
			{
				this.UpdateImage("sidebar_lock_cursor", "sidebar_lock_cursor_active");
				return;
			}
			this.UpdateImage("sidebar_lock_cursor", "sidebar_lock_cursor");
		}

		// Token: 0x060004E0 RID: 1248 RVA: 0x00005391 File Offset: 0x00003591
		private void ParentWindow_GuestBootCompletedEvent()
		{
			this.ToggleBootCompletedState();
		}

		// Token: 0x060004E1 RID: 1249 RVA: 0x00005399 File Offset: 0x00003599
		private void ToggleBootCompletedState()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.ChangeElementState("sidebar_stream_video", true);
				this.ChangeElementState("sidebar_volume", true);
				this.ChangeElementState("sidebar_macro", true);
				this.ChangeElementState("sidebar_operation", true);
				this.ChangeElementState("sidebar_location", true);
				this.ChangeElementState("sidebar_rotate", true);
			}), new object[0]);
		}

		// Token: 0x060004E2 RID: 1250 RVA: 0x000053BE File Offset: 0x000035BE
		private void ChangeElementState(SidebarElement ele, bool isEnabled)
		{
			if (ele != null)
			{
				ele.IsEnabled = isEnabled;
			}
		}

		// Token: 0x060004E3 RID: 1251 RVA: 0x0002094C File Offset: 0x0001EB4C
		private void ChangeElementState(string elementTag, bool isEnabled)
		{
			SidebarElement elementFromTag = this.GetElementFromTag(elementTag);
			this.ChangeElementState(elementFromTag, isEnabled);
		}

		// Token: 0x060004E4 RID: 1252 RVA: 0x0002096C File Offset: 0x0001EB6C
		private void Sidebar_Loaded(object sender, RoutedEventArgs e)
		{
			if (!this.mIsLoadedOnce)
			{
				this.mIsLoadedOnce = true;
				this.BindEvents();
				this.SetPlacementTargets();
				this.InitDefaultSettings();
				this.mMacroBookmarkPopup.SetParentWindowAndBindEvents(this.ParentWindow);
				this.ParentWindow.mCommonHandler.ToggleMacroAndSyncVisibility();
			}
			this.ParentWindow.mCommonHandler.ClipMouseCursorHandler(false, false, "", "");
			this.SetVideoRecordingTooltipForNCSoft();
		}

		// Token: 0x060004E5 RID: 1253 RVA: 0x000209E0 File Offset: 0x0001EBE0
		private void MMacroButtonAndPopup_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.mMacroButtonPopup.IsOpen)
			{
				if (this.mMacroBookmarkTimer == null)
				{
					this.mMacroBookmarkTimer = new DispatcherTimer();
					this.mMacroBookmarkTimer.Interval = new TimeSpan(0, 0, 0, 0, 500);
					this.mMacroBookmarkTimer.Tick += this.MMacroBookmarkTimer_Tick;
				}
				else
				{
					this.mMacroBookmarkTimer.Stop();
				}
				this.mMacroBookmarkTimer.Start();
			}
		}

		// Token: 0x060004E6 RID: 1254 RVA: 0x00020A58 File Offset: 0x0001EC58
		private void MMacroBookmarkTimer_Tick(object sender, EventArgs e)
		{
			if (!this.mMacroButtonPopup.IsMouseOver && !this.GetElementFromTag("sidebar_macro").IsMouseOver)
			{
				this.mMacroButtonPopup.IsOpen = false;
				if (this.mIsInFullscreenMode && !base.IsMouseOver)
				{
					this.ToggleSidebarVisibilityInFullscreen(false);
				}
			}
			(sender as DispatcherTimer).Stop();
		}

		// Token: 0x060004E7 RID: 1255 RVA: 0x00020AB4 File Offset: 0x0001ECB4
		private void MacroButtonHandler(object sender, EventArgs e)
		{
			if (this.ParentWindow.mIsOperationRecorderActive)
			{
				this.ParentWindow.ShowToast(LocaleStrings.GetLocalizedString("STRING_STOP_RECORDING_FIRST", false));
				return;
			}
			if (RegistryManager.Instance.BookmarkedScriptList.Length != 0 && !this.mMoreElements.IsOpen)
			{
				this.mMacroButtonPopup.IsOpen = true;
				return;
			}
			this.ParentWindow.mCommonHandler.OpenOperationRecorderWindow();
			this.mMacroButtonPopup.IsOpen = false;
			this.ToggleSidebarVisibilityInFullscreen(false);
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "MacroRecorder", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x060004E8 RID: 1256 RVA: 0x00020B70 File Offset: 0x0001ED70
		private void OperationSyncHandler(object sender, EventArgs e)
		{
			this.ParentWindow.ShowSynchronizerWindow();
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "OperationSync", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x060004E9 RID: 1257 RVA: 0x000053CA File Offset: 0x000035CA
		private void KeymapToggleHandler(object sender, EventArgs e)
		{
			this.KeyMapSwitchButtonHandler(sender as SidebarElement);
		}

		// Token: 0x060004EA RID: 1258 RVA: 0x00020BC8 File Offset: 0x0001EDC8
		private void KeyMapControlsButton_PreviewMouseRightButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Right Click on keymap control UI button ");
			try
			{
				if ((Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl)) && (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt)))
				{
					KMManager.sIsDeveloperModeOn = true;
				}
				else
				{
					KMManager.sIsDeveloperModeOn = false;
				}
				KMManager.CloseWindows();
				KMManager.LoadIMActions(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName);
				KMManager.ShowAdvancedSettings(this.ParentWindow);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception on right click on keymap button: " + ex.ToString());
			}
		}

		// Token: 0x060004EB RID: 1259 RVA: 0x00020C6C File Offset: 0x0001EE6C
		internal void KeyMapSwitchButtonHandler(SidebarElement ele)
		{
			bool fromSideBar = true;
			if (ele == null)
			{
				ele = this.GetElementFromTag("sidebar_toggle");
				fromSideBar = false;
			}
			if (ele == null)
			{
				return;
			}
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (!KMManager.sIsComboRecordingOn)
				{
					if (string.Equals(ele.Image.ImageName, "sidebar_toggle_off"))
					{
						this.UpdateToDefaultImage(ele);
						this.ParentWindow.mFrontendHandler.EnableKeyMapping(true);
						ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "ToggleKeymapOn", fromSideBar ? "MouseClick" : "Shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
						return;
					}
					this.UpdateImage(ele, "sidebar_toggle_off");
					this.ParentWindow.mFrontendHandler.EnableKeyMapping(false);
					ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "ToggleKeymapOff", fromSideBar ? "MouseClick" : "Shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
				}
			}), new object[0]);
		}

		// Token: 0x060004EC RID: 1260 RVA: 0x00020CE0 File Offset: 0x0001EEE0
		private void SetPlacementTargets()
		{
			this.mChangeTransparencyPopup.PlacementTarget = this.GetElementFromTag("sidebar_overlay");
			this.mVolumeSliderPopup.PlacementTarget = this.GetElementFromTag("sidebar_volume");
			this.mOverlayTooltip.PlacementTarget = this.GetElementFromTag("sidebar_overlay");
			this.mKeyMapPopup.PlacementTarget = this.GetElementFromTag("sidebar_controls");
			this.mRecordScreenPopup.PlacementTarget = this.GetElementFromTag("sidebar_video_capture");
			this.mScreenshotPopup.PlacementTarget = this.GetElementFromTag("sidebar_screenshot");
			this.mMacroButtonPopup.PlacementTarget = this.GetElementFromTag("sidebar_macro");
			this.mGameControlButtonPopup.PlacementTarget = this.GetElementFromTag("sidebar_controls");
		}

		// Token: 0x060004ED RID: 1261 RVA: 0x00020DA0 File Offset: 0x0001EFA0
		internal void InitElements()
		{
			SidebarConfig.sFilePath = System.IO.Path.Combine(RegistryStrings.GadgetDir, string.Format("SidebarConfig_{0}.json", this.ParentWindow.mVmName));
			foreach (List<string> ls in SidebarConfig.Instance.GroupElements)
			{
				this.CreateAndAddElementsToStackPanel(ls);
			}
			this.InitStaticElements();
			this.UpdateTotalVisibleElementCount();
		}

		// Token: 0x060004EE RID: 1262 RVA: 0x00020E28 File Offset: 0x0001F028
		private void UpdateTotalVisibleElementCount()
		{
			this.mTotalVisibleElements = (from item in this.mListSidebarElements
			where item.Visibility == Visibility.Visible
			select item).Count<SidebarElement>();
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.mTotalVisibleElements--;
				return;
			}
			this.mTotalVisibleElements -= 3;
		}

		// Token: 0x060004EF RID: 1263 RVA: 0x00020E94 File Offset: 0x0001F094
		private void InitStaticElements()
		{
			SidebarElement ele;
			if (!FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				ele = this.CreateElement("sidebar_settings", "STRING_SETTINGS", new EventHandler(this.GoSettingsHandler));
				this.AddElement(ele, true);
			}
			ele = this.CreateElement("sidebar_back", "STRING_BACK", new EventHandler(this.GoBackHandler));
			this.AddElement(ele, true);
			this.ChangeElementState(ele, false);
		}

		// Token: 0x060004F0 RID: 1264 RVA: 0x00020F00 File Offset: 0x0001F100
		private void CreateAndAddElementsToStackPanel(List<string> ls)
		{
			SidebarElement sidebarElement = null;
			foreach (string text in ls)
			{
				uint num = <PrivateImplementationDetails>.ComputeStringHash(text);
				if (num <= 1613331775U)
				{
					if (num <= 964859351U)
					{
						if (num <= 784514210U)
						{
							if (num != 33101451U)
							{
								if (num != 784514210U)
								{
									goto IL_60F;
								}
								if (!(text == "sidebar_lock_cursor"))
								{
									goto IL_60F;
								}
								sidebarElement = this.CreateElement("sidebar_lock_cursor", "STRING_TOGGLE_LOCK_CURSOR", new EventHandler(this.LockCursorHandler));
								this.AddElement(sidebarElement, false);
								this.ChangeElementState(sidebarElement, false);
							}
							else
							{
								if (!(text == "sidebar_gamepad"))
								{
									goto IL_60F;
								}
								sidebarElement = this.CreateElement("sidebar_gamepad", "STRING_GAMEPAD_CONTROLS", new EventHandler(this.GamepadControlsWindowHandler));
								this.AddElement(sidebarElement, false);
								this.ChangeElementState(sidebarElement, false);
							}
						}
						else if (num != 785324652U)
						{
							if (num != 964859351U)
							{
								goto IL_60F;
							}
							if (!(text == "sidebar_rotate"))
							{
								goto IL_60F;
							}
							sidebarElement = this.CreateElement("sidebar_rotate", "STRING_ROTATE", new EventHandler(this.RotateHandler));
							this.AddElement(sidebarElement, false);
							this.ChangeElementState(sidebarElement, false);
						}
						else
						{
							if (!(text == "sidebar_macro"))
							{
								goto IL_60F;
							}
							sidebarElement = this.CreateElement("sidebar_macro", "STRING_MACRO_RECORDER", new EventHandler(this.MacroButtonHandler));
							sidebarElement.MouseLeave += this.MMacroButtonAndPopup_MouseLeave;
							this.AddElement(sidebarElement, false);
						}
					}
					else if (num <= 1275655550U)
					{
						if (num != 1198477406U)
						{
							if (num != 1275655550U)
							{
								goto IL_60F;
							}
							if (!(text == "sidebar_video_capture"))
							{
								goto IL_60F;
							}
							sidebarElement = this.CreateElement("sidebar_video_capture", "STRING_RECORD_SCREEN", new EventHandler(this.ScreenRecorderButtonHandler));
							this.AddElement(sidebarElement, false);
							this.ChangeElementState(sidebarElement, false);
						}
						else
						{
							if (!(text == "sidebar_shake"))
							{
								goto IL_60F;
							}
							sidebarElement = this.CreateElement("sidebar_shake", "STRING_SHAKE", new EventHandler(this.ShakeHandler));
							this.AddElement(sidebarElement, false);
						}
					}
					else if (num != 1508932284U)
					{
						if (num != 1613331775U)
						{
							goto IL_60F;
						}
						if (!(text == "sidebar_location"))
						{
							goto IL_60F;
						}
						sidebarElement = this.CreateElement("sidebar_location", "STRING_SET_LOCATION", new EventHandler(this.LocationHandler));
						this.AddElement(sidebarElement, false);
						this.ChangeElementState(sidebarElement, false);
					}
					else
					{
						if (!(text == "sidebar_screenshot"))
						{
							goto IL_60F;
						}
						sidebarElement = this.CreateElement("sidebar_screenshot", "STRING_TOOLBAR_CAMERA", new EventHandler(this.ScreenshotHandler));
						this.AddElement(sidebarElement, false);
						this.ChangeElementState(sidebarElement, false);
					}
				}
				else if (num <= 2204537713U)
				{
					if (num <= 1828502634U)
					{
						if (num != 1740645932U)
						{
							if (num != 1828502634U)
							{
								goto IL_60F;
							}
							if (!(text == "sidebar_controls"))
							{
								goto IL_60F;
							}
							sidebarElement = this.CreateElement("sidebar_controls", "STRING_TOGGLE_KEYMAP_WINDOW", new EventHandler(this.GameControlButtonHandler));
							sidebarElement.PreviewMouseRightButtonUp += this.KeyMapControlsButton_PreviewMouseRightButtonUp;
							sidebarElement.MouseLeave += this.GameControlButtonPopup_MouseLeave;
							this.AddElement(sidebarElement, false);
							this.ChangeElementState(sidebarElement, false);
						}
						else
						{
							if (!(text == "sidebar_stream_video"))
							{
								goto IL_60F;
							}
							sidebarElement = this.CreateElement("sidebar_stream_video", "STRING_START_STREAMING", new EventHandler(this.StreamingHandler));
							this.AddElement(sidebarElement, false);
							this.ChangeElementState(sidebarElement, false);
						}
					}
					else if (num != 1902815577U)
					{
						if (num != 2204537713U)
						{
							goto IL_60F;
						}
						if (!(text == "sidebar_operation"))
						{
							goto IL_60F;
						}
						sidebarElement = this.CreateElement("sidebar_operation", "STRING_SYNCHRONISER", new EventHandler(this.OperationSyncHandler));
						this.AddElement(sidebarElement, false);
					}
					else
					{
						if (!(text == "sidebar_media_folder"))
						{
							goto IL_60F;
						}
						sidebarElement = this.CreateElement("sidebar_media_folder", "STRING_OPEN_MEDIA_FOLDER", new EventHandler(this.MediaFolderHandler));
						this.AddElement(sidebarElement, false);
					}
				}
				else if (num <= 3250257129U)
				{
					if (num != 2888420628U)
					{
						if (num != 3250257129U)
						{
							goto IL_60F;
						}
						if (!(text == "sidebar_fullscreen"))
						{
							goto IL_60F;
						}
						sidebarElement = this.CreateElement("sidebar_fullscreen", "STRING_UPDATED_FULLSCREEN_BUTTON_TOOLTIP", new EventHandler(this.FullScreenHandler));
						this.AddElement(sidebarElement, false);
						this.ChangeElementState(sidebarElement, false);
					}
					else
					{
						if (!(text == "sidebar_toggle"))
						{
							goto IL_60F;
						}
						sidebarElement = this.CreateElement("sidebar_toggle", "STRING_TOGGLE_KEYMAPPING_STATE", new EventHandler(this.KeymapToggleHandler));
						this.AddElement(sidebarElement, false);
						this.ChangeElementState(sidebarElement, false);
					}
				}
				else if (num != 3462101782U)
				{
					if (num != 3723511498U)
					{
						if (num != 3976567256U)
						{
							goto IL_60F;
						}
						if (!(text == "sidebar_overlay"))
						{
							goto IL_60F;
						}
						sidebarElement = this.CreateElement("sidebar_overlay", "STRING_TOGGLE_OVERLAY", new EventHandler(this.KeymappingControlsTransparencyButtonHandler));
						this.AddElement(sidebarElement, false);
						sidebarElement.MouseLeave += this.ChangeTransparencyPopup_MouseLeave;
						this.ChangeElementState(sidebarElement, false);
					}
					else
					{
						if (!(text == "sidebar_volume"))
						{
							goto IL_60F;
						}
						sidebarElement = this.CreateElement("sidebar_volume", "STRING_CHANGE_VOLUME", new EventHandler(this.VolumeButtonHandler));
						this.AddElement(sidebarElement, false);
						sidebarElement.MouseLeave += this.VolumeSliderPopup_MouseLeave;
						this.ChangeElementState(sidebarElement, false);
					}
				}
				else
				{
					if (!(text == "sidebar_mm"))
					{
						goto IL_60F;
					}
					sidebarElement = this.CreateElement("sidebar_mm", "STRING_TOGGLE_MULTIINSTANCE_WINDOW", new EventHandler(this.MIManagerHandler));
					this.AddElement(sidebarElement, false);
				}
				IL_623:
				if (text == ls.Last<string>())
				{
					sidebarElement.IsLastElementOfGroup = true;
					sidebarElement.IsCurrentLastElementOfGroup = true;
					this.IncreaseElementBottomMarginIfLast(sidebarElement);
					continue;
				}
				continue;
				IL_60F:
				Logger.Warning("Unhandled sidebar element found: {0}", new object[]
				{
					text
				});
				goto IL_623;
			}
		}

		// Token: 0x060004F1 RID: 1265 RVA: 0x0002158C File Offset: 0x0001F78C
		private void StreamingHandler(object sender, EventArgs e)
		{
			bool mIsStreaming = this.ParentWindow.mIsStreaming;
			NCSoftUtils.Instance.SendStreamingEvent(this.ParentWindow.mVmName, mIsStreaming ? "off" : "on");
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, mIsStreaming ? "StreamVideoOff" : "StreamVideoOn", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x060004F2 RID: 1266 RVA: 0x00021614 File Offset: 0x0001F814
		private void GamepadControlsWindowHandler(object sender, EventArgs e)
		{
			KMManager.HandleInputMapperWindow(this.ParentWindow, true, "gamepad");
			string tag = "sidebar";
			string userGuid = RegistryManager.Instance.UserGuid;
			string arg = "GamePad";
			string arg2 = "MouseClick";
			string clientVersion = RegistryManager.Instance.ClientVersion;
			string version = RegistryManager.Instance.Version;
			string oem = RegistryManager.Instance.Oem;
			AppTabButton selectedTab = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab;
			ClientStats.SendMiscellaneousStatsAsync(tag, userGuid, arg, arg2, clientVersion, version, oem, (selectedTab != null) ? selectedTab.PackageName : null, null);
		}

		// Token: 0x060004F3 RID: 1267 RVA: 0x00021690 File Offset: 0x0001F890
		private void MediaFolderHandler(object sender, EventArgs e)
		{
			CommonHandlers.OpenMediaFolder();
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "MediaFolder", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x060004F4 RID: 1268 RVA: 0x000216E0 File Offset: 0x0001F8E0
		private void GoBackHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.BackButtonHandler(false);
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "Back", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x060004F5 RID: 1269 RVA: 0x000053D8 File Offset: 0x000035D8
		private void GoHomeHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.HomeButtonHandler(true, false);
		}

		// Token: 0x060004F6 RID: 1270 RVA: 0x0002173C File Offset: 0x0001F93C
		private void GoSettingsHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.LaunchSettingsWindow();
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "Settings", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x060004F7 RID: 1271 RVA: 0x00021798 File Offset: 0x0001F998
		private void MIManagerHandler(object sender, EventArgs e)
		{
			try
			{
				Process.Start(System.IO.Path.Combine(RegistryStrings.InstallDir, "HD-MultiInstanceManager.exe"));
				ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "MultiInstance", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't launch MI Manager. Ex: {0}", new object[]
				{
					ex.Message
				});
			}
		}

		// Token: 0x060004F8 RID: 1272 RVA: 0x000053EC File Offset: 0x000035EC
		private void RotateHandler(object sender, EventArgs e)
		{
			this.RotateButtonHandler("MouseClick");
		}

		// Token: 0x060004F9 RID: 1273 RVA: 0x00021828 File Offset: 0x0001FA28
		internal void RotateButtonHandler(string action)
		{
			this.mIsUIInPortraitModeBeforeChange = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsPortraitModeTab;
			this.ParentWindow.AppForcedOrientationDict[this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName] = !this.mIsUIInPortraitModeBeforeChange;
			this.ParentWindow.ChangeOrientationFromClient(!this.mIsUIInPortraitModeBeforeChange, true);
			string text = this.mIsUIInPortraitModeBeforeChange ? "landscape" : "portrait";
			string tag = "sidebar";
			string userGuid = RegistryManager.Instance.UserGuid;
			string arg = "Rotate";
			string clientVersion = RegistryManager.Instance.ClientVersion;
			string version = RegistryManager.Instance.Version;
			string oem = RegistryManager.Instance.Oem;
			string arg2 = text;
			AppTabButton selectedTab = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab;
			ClientStats.SendMiscellaneousStatsAsync(tag, userGuid, arg, action, clientVersion, version, oem, arg2, (selectedTab != null) ? selectedTab.PackageName : null);
		}

		// Token: 0x060004FA RID: 1274 RVA: 0x00021914 File Offset: 0x0001FB14
		private void ShakeHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.ShakeButtonHandler();
			string tag = "sidebar";
			string userGuid = RegistryManager.Instance.UserGuid;
			string arg = "Shake";
			string arg2 = "MouseClick";
			string clientVersion = RegistryManager.Instance.ClientVersion;
			string version = RegistryManager.Instance.Version;
			string oem = RegistryManager.Instance.Oem;
			AppTabButton selectedTab = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab;
			ClientStats.SendMiscellaneousStatsAsync(tag, userGuid, arg, arg2, clientVersion, version, oem, (selectedTab != null) ? selectedTab.PackageName : null, null);
		}

		// Token: 0x060004FB RID: 1275 RVA: 0x00021990 File Offset: 0x0001FB90
		private void LocationHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.LocationButtonHandler();
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "SetLocation", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x060004FC RID: 1276 RVA: 0x000053F9 File Offset: 0x000035F9
		private void LockCursorHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.ClipMouseCursorHandler(false, true, "MouseClick", "sidebar");
		}

		// Token: 0x060004FD RID: 1277 RVA: 0x00005417 File Offset: 0x00003617
		private void ScreenshotHandler(object sender, EventArgs e)
		{
			ToolTipService.SetToolTip(sender as SidebarElement, null);
			this.mScreenshotPopup.IsOpen = false;
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				Thread.Sleep(100);
				this.ParentWindow.mCommonHandler.ScreenShotButtonHandler();
				ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "Screenshot", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
			});
		}

		// Token: 0x060004FE RID: 1278 RVA: 0x000219EC File Offset: 0x0001FBEC
		private void VolumeButtonHandler(object sender, EventArgs e)
		{
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, this.mVolumeSliderPopup.IsOpen ? "VolumeOff" : "VolumeOn", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
			if (!this.GetElementFromTag("sidebar_volume").IsInMainSidebar)
			{
				this.mVolumeSliderPopup.StaysOpen = false;
			}
			else
			{
				this.mVolumeSliderPopup.StaysOpen = true;
			}
			if (this.mVolumeSliderPopup.IsOpen)
			{
				this.mVolumeSliderPopup.IsOpen = false;
				return;
			}
			this.mVolumeSliderPopup.IsOpen = true;
		}

		// Token: 0x060004FF RID: 1279 RVA: 0x00005443 File Offset: 0x00003643
		private void FullScreenHandler(object sender, EventArgs e)
		{
			if (!this.ParentWindow.mStreamingModeEnabled)
			{
				this.ParentWindow.mCommonHandler.FullScreenButtonHandler("sidebar", "MouseClick");
			}
		}

		// Token: 0x06000500 RID: 1280 RVA: 0x00021AA0 File Offset: 0x0001FCA0
		internal SidebarElement GetElementFromTag(string tag)
		{
			if (this.mListSidebarElements.Count >= 1)
			{
				return (from item in this.mListSidebarElements
				where (string)item.Tag == tag
				select item).FirstOrDefault<SidebarElement>();
			}
			return null;
		}

		// Token: 0x06000501 RID: 1281 RVA: 0x0000546C File Offset: 0x0000366C
		public void AddElement(SidebarElement ele, bool isStaticElement = false)
		{
			if (isStaticElement)
			{
				this.mStaticButtonsStackPanel.Children.Add(ele);
				return;
			}
			this.mElementsStackPanel.Children.Add(ele);
		}

		// Token: 0x06000502 RID: 1282 RVA: 0x00005496 File Offset: 0x00003696
		public void UpdateToDefaultImage(string tag)
		{
			this.UpdateToDefaultImage(this.GetElementFromTag(tag));
		}

		// Token: 0x06000503 RID: 1283 RVA: 0x00021AE8 File Offset: 0x0001FCE8
		public void UpdateImage(string tag, string newImage)
		{
			SidebarElement elementFromTag = this.GetElementFromTag(tag);
			this.UpdateImage(elementFromTag, newImage);
		}

		// Token: 0x06000504 RID: 1284 RVA: 0x000054A5 File Offset: 0x000036A5
		public void UpdateToDefaultImage(SidebarElement ele)
		{
			if (ele != null)
			{
				ele.Image.ImageName = (string)ele.Tag;
			}
		}

		// Token: 0x06000505 RID: 1285 RVA: 0x000054C0 File Offset: 0x000036C0
		public void UpdateImage(SidebarElement ele, string newImage)
		{
			if (ele != null)
			{
				ele.Image.ImageName = newImage;
			}
		}

		// Token: 0x06000506 RID: 1286 RVA: 0x00021B08 File Offset: 0x0001FD08
		private void DecreaseElementBottomMargin(SidebarElement ele)
		{
			Thickness margin = ele.Margin;
			margin.Bottom = 2.0;
			ele.Margin = margin;
		}

		// Token: 0x06000507 RID: 1287 RVA: 0x00021B34 File Offset: 0x0001FD34
		private void IncreaseElementBottomMarginIfLast(SidebarElement ele)
		{
			if (ele.IsCurrentLastElementOfGroup)
			{
				Thickness margin = ele.Margin;
				margin.Bottom = 10.0;
				ele.Margin = margin;
			}
		}

		// Token: 0x06000508 RID: 1288 RVA: 0x00021B68 File Offset: 0x0001FD68
		private SidebarElement CreateElement(string imageName, string toolTipKey, EventHandler evt)
		{
			SidebarElement sidebarElement = new SidebarElement();
			sidebarElement.Margin = new Thickness(0.0, 2.0, 0.0, 2.0);
			sidebarElement.Visibility = Visibility.Visible;
			sidebarElement.mSidebarElementTooltipKey = toolTipKey;
			this.SetSidebarElementTooltip(sidebarElement, toolTipKey);
			sidebarElement.Image.ImageName = imageName;
			sidebarElement.Tag = imageName;
			sidebarElement.PreviewMouseLeftButtonUp += this.SidebarElement_PreviewMouseLeftButtonUp;
			sidebarElement.IsVisibleChanged += this.SidebarElement_IsVisibleChanged;
			this.mDictActions.Add(sidebarElement, evt);
			this.mListSidebarElements.Add(sidebarElement);
			return sidebarElement;
		}

		// Token: 0x06000509 RID: 1289 RVA: 0x00021C14 File Offset: 0x0001FE14
		internal void SetSidebarElementTooltip(SidebarElement ele, string toolTipKey)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				string shortcutKeyFromName = this.ParentWindow.mCommonHandler.GetShortcutKeyFromName(toolTipKey, false);
				if (string.IsNullOrEmpty(shortcutKeyFromName))
				{
					BlueStacksUIBinding.Bind(ele, toolTipKey);
					return;
				}
				toolTipKey = string.Format("{0}{1}({2})", LocaleStrings.GetLocalizedString(toolTipKey, false), Environment.NewLine, shortcutKeyFromName);
				if (!string.IsNullOrEmpty(toolTipKey))
				{
					ele.ToolTip = new ToolTip
					{
						Content = toolTipKey
					};
				}
			}), new object[0]);
		}

		// Token: 0x0600050A RID: 1290 RVA: 0x00021C60 File Offset: 0x0001FE60
		private void SidebarElement_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (!this.mIsOneSidebarElementLoadedBinded && (bool)e.NewValue)
			{
				this.mIsOneSidebarElementLoadedBinded = true;
				SidebarElement sidebarElement = sender as SidebarElement;
				if (sidebarElement != null && this.mSidebarElementApproxHeight == 0.0)
				{
					int num = (int)sidebarElement.Height + 2 * (int)sidebarElement.Margin.Top;
					int num2 = (from item in this.mListSidebarElements
					where item.IsLastElementOfGroup
					select item).Count<SidebarElement>();
					int num3 = num * this.mElementsStackPanel.Children.Count + (num2 - 1) * 8;
					this.mSidebarElementApproxHeight = (double)(num3 / this.mElementsStackPanel.Children.Count + 2);
					Logger.Info("Aprrox: {0}", new object[]
					{
						this.mSidebarElementApproxHeight
					});
				}
			}
			this.UpdateTotalVisibleElementCount();
		}

		// Token: 0x0600050B RID: 1291 RVA: 0x000054D1 File Offset: 0x000036D1
		private void OnRankChanged(int oldValue, int newValue)
		{
			this.ParentWindow.EngineInstanceRegistry.IsSidebarInDefaultState = false;
		}

		// Token: 0x0600050C RID: 1292 RVA: 0x00021D54 File Offset: 0x0001FF54
		private void SidebarElement_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			SidebarElement sidebarElement = sender as SidebarElement;
			if (this.mDictActions.ContainsKey(sidebarElement))
			{
				EventHandler eventHandler = this.mDictActions[sidebarElement];
				if (eventHandler == null)
				{
					return;
				}
				eventHandler(sidebarElement, new EventArgs());
			}
		}

		// Token: 0x0600050D RID: 1293 RVA: 0x000054E4 File Offset: 0x000036E4
		private void MSidebar_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			this.ArrangeAllSidebarElements();
		}

		// Token: 0x0600050E RID: 1294 RVA: 0x00021D94 File Offset: 0x0001FF94
		internal void ArrangeAllSidebarElements()
		{
			if (base.Visibility == Visibility.Visible)
			{
				int num = Math.Min((int)((base.ActualHeight - this.mBottomGrid.ActualHeight - this.mMoreButton.ActualHeight) / this.mSidebarElementApproxHeight), this.mTotalVisibleElements);
				List<SidebarElement> list = (from item in this.mElementsStackPanel.Children.OfType<SidebarElement>()
				where item.Visibility == Visibility.Visible
				select item).ToList<SidebarElement>();
				int count = list.Count;
				if (count > num)
				{
					int num2 = count - num;
					for (int i = 1; i <= num2; i++)
					{
						SidebarElement sidebarElement = list[count - i];
						this.mElementsStackPanel.Children.Remove(sidebarElement);
						sidebarElement.IsInMainSidebar = false;
					}
				}
				else if (count < num)
				{
					int num3 = num - count;
					SidebarElement[] array = (from item in this.mListSidebarElements
					where !item.IsInMainSidebar
					select item).ToArray<SidebarElement>();
					for (int j = 0; j < num3; j++)
					{
						if (array.Count<SidebarElement>() > j)
						{
							SidebarElement sidebarElement2 = array[j];
							sidebarElement2.IsInMainSidebar = true;
							this.AddToVisibleElementsPanel(sidebarElement2);
						}
					}
				}
				if ((from x in this.mListSidebarElements
				where !x.IsInMainSidebar
				select x).Count<SidebarElement>() > 0)
				{
					this.mMoreButton.Visibility = Visibility.Visible;
					return;
				}
				this.mMoreButton.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x0600050F RID: 1295 RVA: 0x000054EC File Offset: 0x000036EC
		private void AddToHiddenElementsPanel(SidebarElement ele)
		{
			this.mSidebarPopup.AddElement(ele);
		}

		// Token: 0x06000510 RID: 1296 RVA: 0x00021F18 File Offset: 0x00020118
		private void AddToVisibleElementsPanel(SidebarElement ele)
		{
			if (ele.Parent != null)
			{
				StackPanel stackPanel = ele.Parent as StackPanel;
				if (stackPanel != null)
				{
					stackPanel.Children.Remove(ele);
				}
			}
			this.mElementsStackPanel.Children.Add(ele);
			this.IncreaseElementBottomMarginIfLast(ele);
		}

		// Token: 0x06000511 RID: 1297 RVA: 0x000054FA File Offset: 0x000036FA
		public void SetHeight()
		{
			base.Height = this.ParentWindow.mContentGrid.ActualHeight;
		}

		// Token: 0x06000512 RID: 1298 RVA: 0x00021F64 File Offset: 0x00020164
		private void MMoreElements_Opened(object sender, EventArgs e)
		{
			this.SidebarPopupContentClear();
			this.mSidebarPopup.InitAllElements(from x in this.mListSidebarElements
			where !x.IsInMainSidebar
			select x);
			this.UpdateImage(this.mMoreButton, "sidebar_options_open");
			BlueStacksUIBinding.Bind(this.mMoreButton, "STRING_CLOSE");
		}

		// Token: 0x06000513 RID: 1299 RVA: 0x00005512 File Offset: 0x00003712
		private void MMoreElements_Closed(object sender, EventArgs e)
		{
			this.SidebarPopupContentClear();
			this.UpdateImage(this.mMoreButton, "sidebar_options_close");
			BlueStacksUIBinding.Bind(this.mMoreButton, "STRING_MORE_BUTTON");
		}

		// Token: 0x06000514 RID: 1300 RVA: 0x00021FD0 File Offset: 0x000201D0
		private void SidebarPopupContentClear()
		{
			foreach (object obj in this.mSidebarPopup.mMainStackPanel.Children)
			{
				((StackPanel)obj).Children.Clear();
			}
			this.mSidebarPopup.mMainStackPanel.Children.Clear();
		}

		// Token: 0x06000515 RID: 1301 RVA: 0x0000553B File Offset: 0x0000373B
		private void MSidebarPopup_PreviewMouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x06000516 RID: 1302 RVA: 0x00005544 File Offset: 0x00003744
		private void MMoreButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mMoreElements.IsOpen = !this.mMoreElements.IsOpen;
		}

		// Token: 0x06000517 RID: 1303 RVA: 0x0002204C File Offset: 0x0002024C
		private void MMoreButton_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.mMoreButton.IsMouseOver)
			{
				if (this.mListPopups.All((CustomPopUp x) => !x.IsMouseOver) && this.mMoreElements.IsOpen)
				{
					if (this.mSidebarPopupTimer == null)
					{
						this.mSidebarPopupTimer = new DispatcherTimer();
						this.mSidebarPopupTimer.Interval = new TimeSpan(0, 0, 0, 0, 500);
						this.mSidebarPopupTimer.Tick += this.SidebarPopupTimer_Tick;
					}
					else
					{
						this.mSidebarPopupTimer.Stop();
					}
					this.mSidebarPopupTimer.Start();
				}
			}
		}

		// Token: 0x06000518 RID: 1304 RVA: 0x00022100 File Offset: 0x00020300
		private void SidebarPopupTimer_Tick(object sender, EventArgs e)
		{
			if (!this.mMoreButton.IsMouseOver)
			{
				if (this.mListPopups.All((CustomPopUp x) => !x.IsMouseOver))
				{
					this.mListPopups.Select(delegate(CustomPopUp c)
					{
						c.IsOpen = false;
						return c;
					}).ToList<CustomPopUp>();
					if (this.mIsInFullscreenMode && !base.IsMouseOver)
					{
						this.ToggleSidebarVisibilityInFullscreen(false);
					}
				}
			}
			(sender as DispatcherTimer).Stop();
		}

		// Token: 0x06000519 RID: 1305 RVA: 0x0000555F File Offset: 0x0000375F
		private void KeyMapPopup_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.KeyMapButtonHandler("MouseClick", "sidebarpopup");
		}

		// Token: 0x0600051A RID: 1306 RVA: 0x0000557B File Offset: 0x0000377B
		private void ClosePopup_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mKeyMapPopup.IsOpen = false;
			e.Handled = true;
		}

		// Token: 0x0600051B RID: 1307 RVA: 0x00022198 File Offset: 0x00020398
		private void KeymappingDoNotShowCheckbox_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mKeymappingDoNotShowCheckbox.ImageName.Equals("bgpcheckbox"))
			{
				this.mKeymappingDoNotShowCheckbox.ImageName = "bgpcheckbox_checked";
				RegistryManager.Instance.KeyMappingAvailablePromptEnabled = false;
			}
			else
			{
				this.mKeymappingDoNotShowCheckbox.ImageName = "bgpcheckbox";
				RegistryManager.Instance.KeyMappingAvailablePromptEnabled = true;
			}
			e.Handled = true;
		}

		// Token: 0x0600051C RID: 1308 RVA: 0x000221FC File Offset: 0x000203FC
		private void mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.transSlider.Value == 0.0)
			{
				this.transSlider.Value = this.mLastSliderValue;
				this.mTranslucentControlsSliderButton.ImageName = "sidebar_overlay_popup";
				return;
			}
			double value = this.transSlider.Value;
			this.transSlider.Value = 0.0;
			this.mLastSliderValue = value;
			this.mTranslucentControlsSliderButton.ImageName = "sidebar_overlay_inactive_popup";
		}

		// Token: 0x0600051D RID: 1309 RVA: 0x00022278 File Offset: 0x00020478
		private void TransparencySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			KMManager.ChangeTransparency(this.ParentWindow, this.transSlider.Value);
			if (this.transSlider.Value == 0.0)
			{
				this.mTranslucentControlsSliderButton.ImageName = "sidebar_overlay_inactive_popup";
				if (!RegistryManager.Instance.ShowKeyControlsOverlay)
				{
					KMManager.ShowOverlayWindow(this.ParentWindow, false, false);
				}
				this.ParentWindow_OverlayStateChangedEvent(false);
			}
			else
			{
				this.mTranslucentControlsSliderButton.ImageName = "sidebar_overlay_popup";
				KMManager.ShowOverlayWindow(this.ParentWindow, true, false);
				this.ParentWindow_OverlayStateChangedEvent(true);
			}
			this.mLastSliderValue = this.transSlider.Value;
		}

		// Token: 0x0600051E RID: 1310 RVA: 0x00005590 File Offset: 0x00003790
		private void OverlayTooltipCPB_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mOverlayTooltip.IsOpen = false;
			this.mIsOverlayTooltipClosed = true;
			e.Handled = true;
		}

		// Token: 0x0600051F RID: 1311 RVA: 0x00022318 File Offset: 0x00020518
		private void OverlayDoNotShowCheckbox_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mOverlayDoNotShowCheckboxImage.ImageName.Equals("bgpcheckbox"))
			{
				this.mOverlayDoNotShowCheckboxImage.ImageName = "bgpcheckbox_checked";
				RegistryManager.Instance.OverlayAvailablePromptEnabled = false;
			}
			else
			{
				this.mOverlayDoNotShowCheckboxImage.ImageName = "bgpcheckbox";
				RegistryManager.Instance.OverlayAvailablePromptEnabled = true;
			}
			e.Handled = true;
		}

		// Token: 0x06000520 RID: 1312 RVA: 0x000055AC File Offset: 0x000037AC
		private void ScreenRecorderButtonHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.DownloadAndLaunchRecording("sidebar", "MouseClick");
		}

		// Token: 0x06000521 RID: 1313 RVA: 0x000055C8 File Offset: 0x000037C8
		private void RecordScreenPopupClose_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mRecordScreenPopup.IsOpen = false;
		}

		// Token: 0x06000522 RID: 1314 RVA: 0x0002237C File Offset: 0x0002057C
		private void RecordScreenPopup_Closed(object sender, EventArgs e)
		{
			if (CommonHandlers.sIsRecordingVideo)
			{
				BlueStacksUIBinding.Bind(this.RecordScreenPopupHeader, "STRING_STOP_RECORDING", "");
				this.RecordScreenPopupBody.Visibility = Visibility.Collapsed;
				this.mRecordScreenClose.Visibility = Visibility.Collapsed;
			}
			else
			{
				BlueStacksUIBinding.Bind(this.RecordScreenPopupHeader, "STRING_RECORD_SCREEN", "");
				BlueStacksUIBinding.Bind(this.RecordScreenPopupBody, "STRING_RECORD_SCREEN_PLAYING", "");
				this.RecordScreenPopupBody.Visibility = Visibility.Visible;
				this.mRecordScreenClose.Visibility = Visibility.Collapsed;
			}
			this.mRecordScreenPopup.StaysOpen = true;
			this.RecordScreenPopupHyperlink.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000523 RID: 1315 RVA: 0x0002241C File Offset: 0x0002061C
		private void KeymappingControlsTransparencyButtonHandler(object sender, EventArgs e)
		{
			RegistryManager.Instance.ShowKeyControlsOverlay = true;
			RegistryManager.Instance.OverlayAvailablePromptEnabled = false;
			KMManager.ShowOverlayWindow(this.ParentWindow, true, true);
			if (!this.GetElementFromTag("sidebar_overlay").IsInMainSidebar)
			{
				this.mChangeTransparencyPopup.StaysOpen = false;
			}
			else
			{
				this.mChangeTransparencyPopup.StaysOpen = true;
			}
			this.mChangeTransparencyPopup.IsOpen = true;
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "Overlay", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06000524 RID: 1316 RVA: 0x000055D6 File Offset: 0x000037D6
		private void RecordScreenPopupHyperlink_Click(object sender, RoutedEventArgs e)
		{
			CommonHandlers.OpenMediaFolderWithFileSelected(CommonHandlers.mSavedVideoRecordingFilePath);
			this.mRecordScreenPopup.IsOpen = false;
		}

		// Token: 0x06000525 RID: 1317 RVA: 0x000224C4 File Offset: 0x000206C4
		private void RecordScreenClose_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if ((bool)e.NewValue)
			{
				this.RecordScreenPopupHeader.Margin = new Thickness(0.0, 0.0, 20.0, 0.0);
				return;
			}
			this.RecordScreenPopupHeader.Margin = new Thickness(0.0);
		}

		// Token: 0x06000526 RID: 1318 RVA: 0x00022530 File Offset: 0x00020730
		private void MSidebar_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (!this.mIsInFullscreenMode && base.IsLoaded)
			{
				if ((bool)e.NewValue)
				{
					this.ParentWindow.ParentWindowWidthDiff = 62;
					this.ParentWindow.Width = this.ParentWindow.ActualWidth + base.Width;
					this.ArrangeAllSidebarElements();
				}
				else
				{
					this.ParentWindow.ParentWindowWidthDiff = 2;
					this.ParentWindow.Width = Math.Max(this.ParentWindow.ActualWidth - base.Width, this.ParentWindow.MinWidth);
				}
				this.ParentWindow.HandleDisplaySettingsChanged();
				this.ParentWindow.Height = this.ParentWindow.GetHeightFromWidth(this.ParentWindow.Width, false);
			}
		}

		// Token: 0x06000527 RID: 1319 RVA: 0x000055EE File Offset: 0x000037EE
		private void MMacroButtonPopup_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mMacroButtonPopup.IsOpen = true;
		}

		// Token: 0x06000528 RID: 1320 RVA: 0x000225FC File Offset: 0x000207FC
		internal void ShowOverlayTooltip(bool isShow, bool force = false)
		{
			if (this.GetElementFromTag("sidebar_overlay") == null || !RegistryManager.Instance.OverlayAvailablePromptEnabled)
			{
				return;
			}
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (isShow)
				{
					this.mIsPendingShowOverlayTooltip = true;
					this.ActualOverlayTooltip(force);
					return;
				}
				this.mKeyMapPopup.IsOpen = false;
				this.mOverlayTooltip.IsOpen = false;
			}), new object[0]);
		}

		// Token: 0x06000529 RID: 1321 RVA: 0x0002265C File Offset: 0x0002085C
		private void ActualOverlayTooltip(bool force = false)
		{
			if (RegistryManager.Instance.OverlayAvailablePromptEnabled && !this.mIsOverlayTooltipClosed && this.mIsPendingShowOverlayTooltip && (!RegistryManager.Instance.IsAutoShowGuidance || force) && !this.mIsInFullscreenMode && !FeatureManager.Instance.IsCustomUIForNCSoft && base.Visibility == Visibility.Visible)
			{
				this.mIsPendingShowOverlayTooltip = false;
				this.mOverlayTooltip.IsOpen = true;
			}
		}

		// Token: 0x0600052A RID: 1322 RVA: 0x000055FC File Offset: 0x000037FC
		private void ActualKeymapPopup()
		{
			if (RegistryManager.Instance.KeyMappingAvailablePromptEnabled)
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					if ((!RegistryManager.Instance.OverlayAvailablePromptEnabled || this.mIsOverlayTooltipClosed) && this.mIsPendingKeyMapTooltip && base.Visibility == Visibility.Visible)
					{
						this.mKeyMapPopup.IsOpen = true;
					}
				}), new object[0]);
			}
		}

		// Token: 0x0600052B RID: 1323 RVA: 0x000226C8 File Offset: 0x000208C8
		internal void ShowKeyMapPopup(bool isShow)
		{
			if (this.GetElementFromTag("sidebar_controls") == null)
			{
				return;
			}
			if (!isShow)
			{
				this.mIsPendingKeyMapTooltip = false;
				this.mKeyMapPopup.IsOpen = false;
				return;
			}
			if (RegistryManager.Instance.IsAutoShowGuidance)
			{
				KMManager.HandleInputMapperWindow(this.ParentWindow, false, "default");
				return;
			}
			this.mIsPendingKeyMapTooltip = true;
			this.ActualKeymapPopup();
		}

		// Token: 0x0600052C RID: 1324 RVA: 0x00022728 File Offset: 0x00020928
		private void OpenMacroGridPreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.OpenOperationRecorderWindow();
			this.mMacroButtonPopup.IsOpen = false;
			this.ToggleSidebarVisibilityInFullscreen(false);
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "MacroRecorder", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, "MacroBookmarkPopup", null);
		}

		// Token: 0x0600052D RID: 1325 RVA: 0x00005628 File Offset: 0x00003828
		private void OpenMacroGridMouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x0600052E RID: 1326 RVA: 0x0000563F File Offset: 0x0000383F
		private void OpenMacroGridMouseLeave(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "SidebarBackground");
		}

		// Token: 0x0600052F RID: 1327 RVA: 0x00005656 File Offset: 0x00003856
		private void VolumeImage_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.MuteUnmuteButtonHanlder();
		}

		// Token: 0x06000530 RID: 1328 RVA: 0x0002279C File Offset: 0x0002099C
		private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			this.mCurrentVolumeValue.Text = Math.Round(e.NewValue).ToString();
		}

		// Token: 0x06000531 RID: 1329 RVA: 0x000227C8 File Offset: 0x000209C8
		private void VolumeSlider_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			int volumeInFrontendAsync = Convert.ToInt32(this.mVolumeSlider.Value);
			this.ParentWindow.Utils.SetVolumeInFrontendAsync(volumeInFrontendAsync);
		}

		// Token: 0x06000532 RID: 1330 RVA: 0x000227F8 File Offset: 0x000209F8
		private void MuteInstancesCheckboxImage_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mMuteInstancesCheckboxImage.ImageName.Equals("bgpcheckbox"))
			{
				this.mMuteInstancesCheckboxImage.ImageName = "bgpcheckbox_checked";
				RegistryManager.Instance.AreAllInstancesMuted = true;
				this.SendMuteUnmuteRequestToAllInstances(true);
			}
			else
			{
				this.mMuteInstancesCheckboxImage.ImageName = "bgpcheckbox";
				RegistryManager.Instance.AreAllInstancesMuted = false;
				this.SendMuteUnmuteRequestToAllInstances(false);
			}
			e.Handled = true;
		}

		// Token: 0x06000533 RID: 1331 RVA: 0x0002286C File Offset: 0x00020A6C
		private void SendMuteUnmuteRequestToAllInstances(bool isMute)
		{
			foreach (string text in RegistryManager.Instance.VmList)
			{
				if (isMute)
				{
					if (BlueStacksUIUtils.DictWindows.Keys.Contains(text))
					{
						BlueStacksUIUtils.DictWindows[text].Utils.MuteApplication(true);
					}
				}
				else if (BlueStacksUIUtils.DictWindows.Keys.Contains(text))
				{
					BlueStacksUIUtils.DictWindows[text].Utils.UnmuteApplication(true);
				}
			}
		}

		// Token: 0x06000534 RID: 1332 RVA: 0x000228EC File Offset: 0x00020AEC
		private void ChangeTransparencyPopup_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.mChangeTransparencyPopup.IsOpen)
			{
				if (this.mChangeTransparencyPopupTimer == null)
				{
					this.mChangeTransparencyPopupTimer = new DispatcherTimer();
					this.mChangeTransparencyPopupTimer.Interval = new TimeSpan(0, 0, 0, 0, 500);
					this.mChangeTransparencyPopupTimer.Tick += this.ChangeTransparencyPopupTimer_Tick;
				}
				else
				{
					this.mChangeTransparencyPopupTimer.Stop();
				}
				this.mChangeTransparencyPopupTimer.Start();
			}
		}

		// Token: 0x06000535 RID: 1333 RVA: 0x00022964 File Offset: 0x00020B64
		private void ChangeTransparencyPopupTimer_Tick(object sender, EventArgs e)
		{
			if (!this.mChangeTransparencyPopup.IsMouseOver && !this.GetElementFromTag("sidebar_overlay").IsMouseOver)
			{
				this.mChangeTransparencyPopup.IsOpen = false;
				if (this.mIsInFullscreenMode && !base.IsMouseOver)
				{
					this.ToggleSidebarVisibilityInFullscreen(false);
				}
			}
			(sender as DispatcherTimer).Stop();
		}

		// Token: 0x06000536 RID: 1334 RVA: 0x00005668 File Offset: 0x00003868
		private void ChangeTransparencyPopup_MouseEnter(object sender, MouseEventArgs e)
		{
			if (!this.GetElementFromTag("sidebar_overlay").IsInMainSidebar)
			{
				this.mChangeTransparencyPopup.StaysOpen = false;
			}
			else
			{
				this.mChangeTransparencyPopup.StaysOpen = true;
			}
			this.mChangeTransparencyPopup.IsOpen = true;
		}

		// Token: 0x06000537 RID: 1335 RVA: 0x000056A2 File Offset: 0x000038A2
		private void VolumeSliderPopup_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mVolumeSliderPopup.IsOpen = true;
		}

		// Token: 0x06000538 RID: 1336 RVA: 0x000229C0 File Offset: 0x00020BC0
		private void VolumeSliderPopup_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.mVolumeSliderPopup.IsOpen)
			{
				if (this.mVolumeSliderPopupTimer == null)
				{
					this.mVolumeSliderPopupTimer = new DispatcherTimer();
					this.mVolumeSliderPopupTimer.Interval = new TimeSpan(0, 0, 1);
					this.mVolumeSliderPopupTimer.Tick += this.VolumeSliderPopupTimer_Tick;
				}
				else
				{
					this.mVolumeSliderPopupTimer.Stop();
				}
				this.mVolumeSliderPopupTimer.Start();
			}
		}

		// Token: 0x06000539 RID: 1337 RVA: 0x00022A30 File Offset: 0x00020C30
		internal void VolumeSliderPopupTimer_Tick(object sender, EventArgs e)
		{
			if (!this.mVolumeSliderPopup.IsMouseOver && !this.GetElementFromTag("sidebar_volume").IsMouseOver)
			{
				this.mVolumeSliderPopup.IsOpen = false;
				if (this.mIsInFullscreenMode && !base.IsMouseOver)
				{
					this.ToggleSidebarVisibilityInFullscreen(false);
				}
			}
			(sender as DispatcherTimer).Stop();
		}

		// Token: 0x0600053A RID: 1338 RVA: 0x000056B0 File Offset: 0x000038B0
		private void ScreenshotPopupClose_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mScreenshotPopup.IsOpen = false;
		}

		// Token: 0x0600053B RID: 1339 RVA: 0x000056BE File Offset: 0x000038BE
		private void ScreenshotPopupHyperlink_Click(object sender, RoutedEventArgs e)
		{
			CommonHandlers.OpenMediaFolderWithFileSelected(this.currentScreenshotSavedPath);
			this.mScreenshotPopup.IsOpen = false;
		}

		// Token: 0x0600053C RID: 1340 RVA: 0x000056D7 File Offset: 0x000038D7
		private void GameControlButtonPopup_MouseEnter(object sender, MouseEventArgs e)
		{
			if (!this.GetElementFromTag("sidebar_controls").IsInMainSidebar)
			{
				this.mGameControlButtonPopup.StaysOpen = false;
			}
			else
			{
				this.mGameControlButtonPopup.StaysOpen = true;
			}
			this.mGameControlButtonPopup.IsOpen = true;
		}

		// Token: 0x0600053D RID: 1341 RVA: 0x00022A8C File Offset: 0x00020C8C
		private void GameControlButtonPopup_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.mGameControlButtonPopup.IsOpen)
			{
				if (this.mGameControlBookmarkTimer == null)
				{
					this.mGameControlBookmarkTimer = new DispatcherTimer();
					this.mGameControlBookmarkTimer.Interval = new TimeSpan(0, 0, 0, 0, 500);
					this.mGameControlBookmarkTimer.Tick += this.GameControlBookmarkTimer_Tick;
				}
				else
				{
					this.mGameControlBookmarkTimer.Stop();
				}
				this.mGameControlBookmarkTimer.Start();
			}
		}

		// Token: 0x0600053E RID: 1342 RVA: 0x00022B04 File Offset: 0x00020D04
		private void GameControlBookmarkTimer_Tick(object sender, EventArgs e)
		{
			if (!this.mGameControlButtonPopup.IsMouseOver && !this.GetElementFromTag("sidebar_controls").IsMouseOver)
			{
				this.mGameControlButtonPopup.IsOpen = false;
				if (this.ParentWindow.mIsFullScreen)
				{
					this.ToggleSidebarVisibilityInFullscreen(false);
				}
			}
			(sender as DispatcherTimer).Stop();
		}

		// Token: 0x0600053F RID: 1343 RVA: 0x00022B5C File Offset: 0x00020D5C
		private void GameControlButtonHandler(object sender, EventArgs e)
		{
			bool flag = true;
			this.mBookmarkedSchemesStackPanel.Children.Clear();
			foreach (IMControlScheme imcontrolScheme in this.ParentWindow.SelectedConfig.ControlSchemes)
			{
				if (imcontrolScheme.IsBookMarked)
				{
					MacroBookmarkControl element = new MacroBookmarkControl(imcontrolScheme, this.ParentWindow);
					this.mBookmarkedSchemesStackPanel.Children.Add(element);
					flag = false;
				}
			}
			if (!flag)
			{
				if (!this.GetElementFromTag("sidebar_controls").IsInMainSidebar)
				{
					this.mGameControlButtonPopup.StaysOpen = false;
				}
				else
				{
					this.mGameControlButtonPopup.StaysOpen = true;
				}
				this.mGameControlButtonPopup.IsOpen = true;
				return;
			}
			this.ParentWindow.mCommonHandler.KeyMapButtonHandler("MouseClick", "sidebar");
			this.mGameControlButtonPopup.IsOpen = false;
			this.ToggleSidebarVisibilityInFullscreen(false);
		}

		// Token: 0x06000540 RID: 1344 RVA: 0x00005711 File Offset: 0x00003911
		private void OpenGameControlPreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.KeyMapButtonHandler("MouseClick", "sidebar");
			this.mGameControlButtonPopup.IsOpen = false;
			this.ToggleSidebarVisibilityInFullscreen(false);
		}

		// Token: 0x06000541 RID: 1345 RVA: 0x00005628 File Offset: 0x00003828
		private void OpenGameControlMouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x06000542 RID: 1346 RVA: 0x00005740 File Offset: 0x00003940
		private void OpenGameControlMouseLeave(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ComboBoxBackgroundColor");
		}

		// Token: 0x06000543 RID: 1347 RVA: 0x00022C58 File Offset: 0x00020E58
		internal void ChangeVideoRecordingImage(string imageName)
		{
			SidebarElement elementFromTag = this.GetElementFromTag("sidebar_video_capture");
			if (elementFromTag != null)
			{
				elementFromTag.Image.IsImageToBeRotated = false;
				this.UpdateImage(elementFromTag, imageName);
			}
		}

		// Token: 0x06000544 RID: 1348 RVA: 0x00022C88 File Offset: 0x00020E88
		private void SetVideoRecordingTooltipForNCSoft()
		{
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				SidebarElement elementFromTag = this.GetElementFromTag("sidebar_video_capture");
				if (elementFromTag != null)
				{
					ToolTip toolTip = elementFromTag.ToolTip as ToolTip;
					toolTip.Content = Convert.ToString(toolTip.Content).Replace(LocaleStrings.GetLocalizedString("STRING_RECORD_SCREEN", false), LocaleStrings.GetLocalizedString("STRING_RECORD_SCREEN_WITHOUT_BETA", false));
				}
			}
		}

		// Token: 0x06000545 RID: 1349 RVA: 0x00022CE8 File Offset: 0x00020EE8
		internal void SetVideoRecordingTooltip(bool isRecording)
		{
			SidebarElement elementFromTag = this.GetElementFromTag("sidebar_video_capture");
			if (elementFromTag != null)
			{
				ToolTip toolTip = elementFromTag.ToolTip as ToolTip;
				if (isRecording)
				{
					if (FeatureManager.Instance.IsCustomUIForNCSoft)
					{
						toolTip.Content = Convert.ToString(toolTip.Content).Replace(LocaleStrings.GetLocalizedString("STRING_RECORD_SCREEN_WITHOUT_BETA", false), LocaleStrings.GetLocalizedString("STRING_STOP_RECORDING", false));
						return;
					}
					toolTip.Content = Convert.ToString(toolTip.Content).Replace(LocaleStrings.GetLocalizedString("STRING_RECORD_SCREEN", false), LocaleStrings.GetLocalizedString("STRING_STOP_RECORDING", false));
					return;
				}
				else
				{
					if (FeatureManager.Instance.IsCustomUIForNCSoft)
					{
						toolTip.Content = Convert.ToString(toolTip.Content).Replace(LocaleStrings.GetLocalizedString("STRING_STOP_RECORDING", false), LocaleStrings.GetLocalizedString("STRING_RECORD_SCREEN_WITHOUT_BETA", false));
						return;
					}
					toolTip.Content = Convert.ToString(toolTip.Content).Replace(LocaleStrings.GetLocalizedString("STRING_STOP_RECORDING", false), LocaleStrings.GetLocalizedString("STRING_RECORD_SCREEN", false));
				}
			}
		}

		// Token: 0x06000546 RID: 1350 RVA: 0x00005757 File Offset: 0x00003957
		private void VolumeSliderPopup_Closed(object sender, EventArgs e)
		{
			if (!this.GetElementFromTag("sidebar_volume").IsInMainSidebar)
			{
				this.MMoreButton_MouseLeave(null, null);
			}
		}

		// Token: 0x06000547 RID: 1351 RVA: 0x00005773 File Offset: 0x00003973
		private void GameControlButtonPopup_Closed(object sender, EventArgs e)
		{
			if (!this.GetElementFromTag("sidebar_controls").IsInMainSidebar)
			{
				this.MMoreButton_MouseLeave(null, null);
			}
		}

		// Token: 0x06000548 RID: 1352 RVA: 0x0000578F File Offset: 0x0000398F
		private void ChangeTransparencyPopup_Closed(object sender, EventArgs e)
		{
			if (!this.GetElementFromTag("sidebar_overlay").IsInMainSidebar)
			{
				this.MMoreButton_MouseLeave(null, null);
			}
		}

		// Token: 0x06000549 RID: 1353 RVA: 0x00022DE4 File Offset: 0x00020FE4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/sidebar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600054A RID: 1354 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600054B RID: 1355 RVA: 0x00022E14 File Offset: 0x00021014
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mSidebar = (Sidebar)target;
				this.mSidebar.SizeChanged += this.MSidebar_SizeChanged;
				this.mSidebar.IsVisibleChanged += this.MSidebar_IsVisibleChanged;
				this.mSidebar.Loaded += this.Sidebar_Loaded;
				return;
			case 2:
				this.mBorder = (Border)target;
				return;
			case 3:
				this.mGrid = (Grid)target;
				return;
			case 4:
				this.mTopGrid = (Grid)target;
				return;
			case 5:
				this.mElementsStackPanel = (StackPanel)target;
				return;
			case 6:
				this.mMoreButton = (SidebarElement)target;
				return;
			case 7:
				this.mKeyMapPopup = (CustomPopUp)target;
				return;
			case 8:
				((Border)target).MouseLeftButtonUp += this.KeyMapPopup_PreviewMouseLeftButtonUp;
				return;
			case 9:
				this.mMaskBorder1 = (Border)target;
				return;
			case 10:
				((CustomPictureBox)target).MouseLeftButtonUp += this.ClosePopup_MouseLeftButtonUp;
				return;
			case 11:
				this.mKeyMappingPopUp1 = (TextBlock)target;
				return;
			case 12:
				this.mKeyMappingPopUp3 = (TextBlock)target;
				return;
			case 13:
				this.mKeymappingDoNotShowCheckbox = (CustomPictureBox)target;
				this.mKeymappingDoNotShowCheckbox.MouseLeftButtonUp += this.KeymappingDoNotShowCheckbox_MouseLeftButtonUp;
				return;
			case 14:
				this.mKeyMappingDontShowPopUp = (TextBlock)target;
				this.mKeyMappingDontShowPopUp.MouseLeftButtonUp += this.KeymappingDoNotShowCheckbox_MouseLeftButtonUp;
				return;
			case 15:
				this.RightArrow = (System.Windows.Shapes.Path)target;
				return;
			case 16:
				this.mChangeTransparencyPopup = (CustomPopUp)target;
				return;
			case 17:
				this.mMaskBorder2 = (Border)target;
				return;
			case 18:
				this.mTranslucentControlsSliderButton = (CustomPictureBox)target;
				this.mTranslucentControlsSliderButton.PreviewMouseLeftButtonUp += this.mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp;
				return;
			case 19:
				this.transSlider = (Slider)target;
				this.transSlider.ValueChanged += this.TransparencySlider_ValueChanged;
				return;
			case 20:
				this.mVolumeSliderPopup = (CustomPopUp)target;
				return;
			case 21:
				this.mMaskBorder3 = (Border)target;
				return;
			case 22:
				this.mVolumeMuteUnmuteImage = (CustomPictureBox)target;
				this.mVolumeMuteUnmuteImage.PreviewMouseLeftButtonUp += this.VolumeImage_PreviewMouseLeftButtonUp;
				return;
			case 23:
				this.mVolumeSlider = (Slider)target;
				this.mVolumeSlider.PreviewMouseLeftButtonUp += this.VolumeSlider_PreviewMouseLeftButtonUp;
				this.mVolumeSlider.ValueChanged += this.VolumeSlider_ValueChanged;
				return;
			case 24:
				this.mCurrentVolumeValue = (TextBlock)target;
				return;
			case 25:
				this.mMuteInstancesCheckboxImage = (CustomPictureBox)target;
				this.mMuteInstancesCheckboxImage.MouseLeftButtonUp += this.MuteInstancesCheckboxImage_MouseLeftButtonUp;
				return;
			case 26:
				this.mMuteAllInstancesTextBlock = (TextBlock)target;
				this.mMuteAllInstancesTextBlock.MouseLeftButtonUp += this.MuteInstancesCheckboxImage_MouseLeftButtonUp;
				return;
			case 27:
				this.mOverlayTooltip = (CustomPopUp)target;
				return;
			case 28:
				this.mMaskBorder4 = (Border)target;
				return;
			case 29:
				((CustomPictureBox)target).MouseLeftButtonUp += this.OverlayTooltipCPB_MouseLeftButtonUp;
				return;
			case 30:
				this.mOverlayPopUpTitle = (TextBlock)target;
				return;
			case 31:
				this.mOverlayPopUpMessage = (TextBlock)target;
				return;
			case 32:
				this.mOverlayDoNotShowCheckboxImage = (CustomPictureBox)target;
				this.mOverlayDoNotShowCheckboxImage.MouseLeftButtonUp += this.OverlayDoNotShowCheckbox_MouseLeftButtonUp;
				return;
			case 33:
				this.mOverlayDontShowPopUp = (TextBlock)target;
				this.mOverlayDontShowPopUp.MouseLeftButtonUp += this.OverlayDoNotShowCheckbox_MouseLeftButtonUp;
				return;
			case 34:
				this.mMacroButtonPopup = (CustomPopUp)target;
				return;
			case 35:
				this.mMaskBorder5 = (Border)target;
				return;
			case 36:
				this.mMacroBookmarkPopup = (MacroBookmarksPopup)target;
				return;
			case 37:
				this.mCustomiseSectionTag = (Grid)target;
				return;
			case 38:
				this.mCustomiseSectionBorderLine = (Separator)target;
				return;
			case 39:
				((Grid)target).PreviewMouseLeftButtonUp += this.OpenMacroGridPreviewMouseLeftButtonUp;
				((Grid)target).MouseEnter += this.OpenMacroGridMouseEnter;
				((Grid)target).MouseLeave += this.OpenMacroGridMouseLeave;
				return;
			case 40:
				this.mOpenMacroTextbox = (TextBlock)target;
				return;
			case 41:
				this.mGameControlButtonPopup = (CustomPopUp)target;
				return;
			case 42:
				this.mMaskBorder6 = (Border)target;
				return;
			case 43:
				this.mBookmarkedSchemesStackPanel = (StackPanel)target;
				return;
			case 44:
				((Grid)target).PreviewMouseLeftButtonUp += this.OpenGameControlPreviewMouseLeftButtonUp;
				((Grid)target).MouseEnter += this.OpenGameControlMouseEnter;
				((Grid)target).MouseLeave += this.OpenGameControlMouseLeave;
				return;
			case 45:
				this.mOpenGameControlTextbox = (TextBlock)target;
				return;
			case 46:
				this.mRecordScreenPopup = (CustomPopUp)target;
				return;
			case 47:
				this.mMaskBorder7 = (Border)target;
				return;
			case 48:
				this.mRecordScreenClose = (CustomPictureBox)target;
				this.mRecordScreenClose.IsVisibleChanged += this.RecordScreenClose_IsVisibleChanged;
				this.mRecordScreenClose.MouseLeftButtonUp += this.RecordScreenPopupClose_MouseLeftButtonUp;
				return;
			case 49:
				this.RecordScreenPopupHeader = (TextBlock)target;
				return;
			case 50:
				this.RecordScreenPopupBody = (TextBlock)target;
				return;
			case 51:
				this.RecordScreenPopupHyperlink = (TextBlock)target;
				return;
			case 52:
				((Hyperlink)target).Click += this.RecordScreenPopupHyperlink_Click;
				return;
			case 53:
				this.mRecorderClickLink = (TextBlock)target;
				return;
			case 54:
				this.mScreenshotPopup = (CustomPopUp)target;
				return;
			case 55:
				this.mMaskBorder8 = (Border)target;
				return;
			case 56:
				this.mScreenshotClose = (CustomPictureBox)target;
				this.mScreenshotClose.MouseLeftButtonUp += this.ScreenshotPopupClose_MouseLeftButtonUp;
				return;
			case 57:
				this.ScreenshotPopupHeader = (TextBlock)target;
				return;
			case 58:
				this.ScreenshotPopupHyperlink = (TextBlock)target;
				return;
			case 59:
				((Hyperlink)target).Click += this.ScreenshotPopupHyperlink_Click;
				return;
			case 60:
				this.mScreenshotClickLink = (TextBlock)target;
				return;
			case 61:
				this.mMoreElements = (CustomPopUp)target;
				return;
			case 62:
				this.mPopupGrid = (Grid)target;
				return;
			case 63:
				this.mMaskBorder = (Border)target;
				return;
			case 64:
				this.mSidebarPopup = (SidebarPopup)target;
				return;
			case 65:
				this.mBottomGrid = (Grid)target;
				return;
			case 66:
				this.mStaticButtonsStackPanel = (StackPanel)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040002EA RID: 746
		private Dictionary<SidebarElement, EventHandler> mDictActions = new Dictionary<SidebarElement, EventHandler>();

		// Token: 0x040002EB RID: 747
		internal List<SidebarElement> mListSidebarElements = new List<SidebarElement>();

		// Token: 0x040002EC RID: 748
		private int mTotalVisibleElements;

		// Token: 0x040002ED RID: 749
		private double mSidebarElementApproxHeight;

		// Token: 0x040002EE RID: 750
		internal bool mIsUIInPortraitModeBeforeChange;

		// Token: 0x040002EF RID: 751
		internal bool mIsOverlayTooltipClosed;

		// Token: 0x040002F0 RID: 752
		private bool mIsPendingShowOverlayTooltip;

		// Token: 0x040002F1 RID: 753
		private bool mIsPendingKeyMapTooltip;

		// Token: 0x040002F2 RID: 754
		internal double mLastSliderValue;

		// Token: 0x040002F3 RID: 755
		private bool mIsLoadedOnce;

		// Token: 0x040002F4 RID: 756
		private bool mIsInFullscreenMode;

		// Token: 0x040002F5 RID: 757
		private DispatcherTimer mMacroBookmarkTimer;

		// Token: 0x040002F6 RID: 758
		private DispatcherTimer mGameControlBookmarkTimer;

		// Token: 0x040002F7 RID: 759
		private DispatcherTimer mChangeTransparencyPopupTimer;

		// Token: 0x040002F8 RID: 760
		internal DispatcherTimer mVolumeSliderPopupTimer;

		// Token: 0x040002F9 RID: 761
		private DispatcherTimer mSidebarPopupTimer;

		// Token: 0x040002FA RID: 762
		private string currentScreenshotSavedPath;

		// Token: 0x040002FB RID: 763
		private readonly object mSyncRoot = new object();

		// Token: 0x040002FC RID: 764
		private MainWindow mMainWindow;

		// Token: 0x040002FD RID: 765
		private bool mIsOneSidebarElementLoadedBinded;

		// Token: 0x040002FE RID: 766
		internal List<CustomPopUp> mListPopups;

		// Token: 0x040002FF RID: 767
		internal Sidebar mSidebar;

		// Token: 0x04000300 RID: 768
		internal Border mBorder;

		// Token: 0x04000301 RID: 769
		internal Grid mGrid;

		// Token: 0x04000302 RID: 770
		internal Grid mTopGrid;

		// Token: 0x04000303 RID: 771
		internal StackPanel mElementsStackPanel;

		// Token: 0x04000304 RID: 772
		internal SidebarElement mMoreButton;

		// Token: 0x04000305 RID: 773
		internal CustomPopUp mKeyMapPopup;

		// Token: 0x04000306 RID: 774
		internal Border mMaskBorder1;

		// Token: 0x04000307 RID: 775
		internal TextBlock mKeyMappingPopUp1;

		// Token: 0x04000308 RID: 776
		internal TextBlock mKeyMappingPopUp3;

		// Token: 0x04000309 RID: 777
		internal CustomPictureBox mKeymappingDoNotShowCheckbox;

		// Token: 0x0400030A RID: 778
		internal TextBlock mKeyMappingDontShowPopUp;

		// Token: 0x0400030B RID: 779
		internal System.Windows.Shapes.Path RightArrow;

		// Token: 0x0400030C RID: 780
		internal CustomPopUp mChangeTransparencyPopup;

		// Token: 0x0400030D RID: 781
		internal Border mMaskBorder2;

		// Token: 0x0400030E RID: 782
		internal CustomPictureBox mTranslucentControlsSliderButton;

		// Token: 0x0400030F RID: 783
		internal Slider transSlider;

		// Token: 0x04000310 RID: 784
		internal CustomPopUp mVolumeSliderPopup;

		// Token: 0x04000311 RID: 785
		internal Border mMaskBorder3;

		// Token: 0x04000312 RID: 786
		internal CustomPictureBox mVolumeMuteUnmuteImage;

		// Token: 0x04000313 RID: 787
		internal Slider mVolumeSlider;

		// Token: 0x04000314 RID: 788
		internal TextBlock mCurrentVolumeValue;

		// Token: 0x04000315 RID: 789
		internal CustomPictureBox mMuteInstancesCheckboxImage;

		// Token: 0x04000316 RID: 790
		internal TextBlock mMuteAllInstancesTextBlock;

		// Token: 0x04000317 RID: 791
		internal CustomPopUp mOverlayTooltip;

		// Token: 0x04000318 RID: 792
		internal Border mMaskBorder4;

		// Token: 0x04000319 RID: 793
		internal TextBlock mOverlayPopUpTitle;

		// Token: 0x0400031A RID: 794
		internal TextBlock mOverlayPopUpMessage;

		// Token: 0x0400031B RID: 795
		internal CustomPictureBox mOverlayDoNotShowCheckboxImage;

		// Token: 0x0400031C RID: 796
		internal TextBlock mOverlayDontShowPopUp;

		// Token: 0x0400031D RID: 797
		internal CustomPopUp mMacroButtonPopup;

		// Token: 0x0400031E RID: 798
		internal Border mMaskBorder5;

		// Token: 0x0400031F RID: 799
		internal MacroBookmarksPopup mMacroBookmarkPopup;

		// Token: 0x04000320 RID: 800
		internal Grid mCustomiseSectionTag;

		// Token: 0x04000321 RID: 801
		internal Separator mCustomiseSectionBorderLine;

		// Token: 0x04000322 RID: 802
		internal TextBlock mOpenMacroTextbox;

		// Token: 0x04000323 RID: 803
		internal CustomPopUp mGameControlButtonPopup;

		// Token: 0x04000324 RID: 804
		internal Border mMaskBorder6;

		// Token: 0x04000325 RID: 805
		internal StackPanel mBookmarkedSchemesStackPanel;

		// Token: 0x04000326 RID: 806
		internal TextBlock mOpenGameControlTextbox;

		// Token: 0x04000327 RID: 807
		internal CustomPopUp mRecordScreenPopup;

		// Token: 0x04000328 RID: 808
		internal Border mMaskBorder7;

		// Token: 0x04000329 RID: 809
		internal CustomPictureBox mRecordScreenClose;

		// Token: 0x0400032A RID: 810
		internal TextBlock RecordScreenPopupHeader;

		// Token: 0x0400032B RID: 811
		internal TextBlock RecordScreenPopupBody;

		// Token: 0x0400032C RID: 812
		internal TextBlock RecordScreenPopupHyperlink;

		// Token: 0x0400032D RID: 813
		internal TextBlock mRecorderClickLink;

		// Token: 0x0400032E RID: 814
		internal CustomPopUp mScreenshotPopup;

		// Token: 0x0400032F RID: 815
		internal Border mMaskBorder8;

		// Token: 0x04000330 RID: 816
		internal CustomPictureBox mScreenshotClose;

		// Token: 0x04000331 RID: 817
		internal TextBlock ScreenshotPopupHeader;

		// Token: 0x04000332 RID: 818
		internal TextBlock ScreenshotPopupHyperlink;

		// Token: 0x04000333 RID: 819
		internal TextBlock mScreenshotClickLink;

		// Token: 0x04000334 RID: 820
		internal CustomPopUp mMoreElements;

		// Token: 0x04000335 RID: 821
		internal Grid mPopupGrid;

		// Token: 0x04000336 RID: 822
		internal Border mMaskBorder;

		// Token: 0x04000337 RID: 823
		internal SidebarPopup mSidebarPopup;

		// Token: 0x04000338 RID: 824
		internal Grid mBottomGrid;

		// Token: 0x04000339 RID: 825
		internal StackPanel mStaticButtonsStackPanel;

		// Token: 0x0400033A RID: 826
		private bool _contentLoaded;
	}
}
