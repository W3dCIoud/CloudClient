﻿using System;
using System.Collections.Generic;
using System.Threading;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000FD RID: 253
	internal class NCSoftUtils
	{
		// Token: 0x1700017C RID: 380
		// (get) Token: 0x06000A39 RID: 2617 RVA: 0x00048770 File Offset: 0x00046970
		internal static NCSoftUtils Instance
		{
			get
			{
				if (NCSoftUtils.mInstance == null)
				{
					object obj = NCSoftUtils.sync;
					lock (obj)
					{
						if (NCSoftUtils.mInstance == null)
						{
							NCSoftUtils.mInstance = new NCSoftUtils();
						}
					}
				}
				return NCSoftUtils.mInstance;
			}
		}

		// Token: 0x06000A3A RID: 2618 RVA: 0x000487C0 File Offset: 0x000469C0
		private int GetNCSoftAgentPort()
		{
			if (this.mNCSoftAgentPort != -1)
			{
				return this.mNCSoftAgentPort;
			}
			string sharedMemoryName = "ngpmmf";
			uint numBytes = 2U;
			try
			{
				this.mNCSoftAgentPort = MemoryMappedFile.GetNCSoftAgentPort(sharedMemoryName, numBytes);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to get ncsoft agent port");
				Logger.Error(ex.ToString());
			}
			return this.mNCSoftAgentPort;
		}

		// Token: 0x06000A3B RID: 2619 RVA: 0x00048820 File Offset: 0x00046A20
		internal void SendAppCrashEvent(string crashReason, string vmName)
		{
			try
			{
				int ncsoftAgentPort = this.GetNCSoftAgentPort();
				if (ncsoftAgentPort != -1)
				{
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					dictionary.Add("vm_name", vmName);
					dictionary.Add("err_message", crashReason);
					Logger.Info("Sending app crash event to NCSoft Agent for vm: " + vmName);
					Logger.Info("Reason: " + crashReason);
					string msg = HTTPUtils.SendRequestToNCSoftAgent(ncsoftAgentPort, "error/crash", dictionary, vmName, 0, null, false, 1, 0);
					Logger.Info("app crash event resp:");
					Logger.Info(msg);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to report app crash. Ex : " + ex.ToString());
			}
		}

		// Token: 0x06000A3C RID: 2620 RVA: 0x000084B6 File Offset: 0x000066B6
		internal void SendGoogleLoginEventAsync(string vmName)
		{
			ThreadPool.QueueUserWorkItem(delegate(object o)
			{
				try
				{
					int ncsoftAgentPort = this.GetNCSoftAgentPort();
					if (ncsoftAgentPort != -1)
					{
						Dictionary<string, string> dictionary = new Dictionary<string, string>();
						dictionary.Add("vm_name", vmName);
						dictionary.Add("first", "true");
						Logger.Info("Sending google login event to NCSoft Agent for vm: " + vmName);
						string msg = HTTPUtils.SendRequestToNCSoftAgent(ncsoftAgentPort, "account/google/login", dictionary, vmName, 0, null, false, 1, 0);
						Logger.Info("account google login event resp:");
						Logger.Info(msg);
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to report google login. Ex : " + ex.ToString());
				}
			});
		}

		// Token: 0x06000A3D RID: 2621 RVA: 0x000084DC File Offset: 0x000066DC
		internal void SendStreamingEvent(string vmName, string streamingStatus)
		{
			ThreadPool.QueueUserWorkItem(delegate(object o)
			{
				try
				{
					int ncsoftAgentPort = this.GetNCSoftAgentPort();
					if (ncsoftAgentPort != -1)
					{
						Dictionary<string, string> dictionary = new Dictionary<string, string>();
						dictionary.Add("button", "streaming");
						dictionary.Add("state", streamingStatus);
						dictionary.Add("vm_name", vmName);
						Logger.Info("Sending streaming event to NCSoft Agent for vm: " + vmName);
						Logger.Info("Status : " + streamingStatus);
						string msg = HTTPUtils.SendRequestToNCSoftAgent(ncsoftAgentPort, "action/button/streaming", dictionary, vmName, 0, null, false, 1, 0);
						Logger.Info("action button streaming event resp:");
						Logger.Info(msg);
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to report action button streaming. Ex : " + ex.ToString());
				}
			});
		}

		// Token: 0x040007B2 RID: 1970
		private static object sync = new object();

		// Token: 0x040007B3 RID: 1971
		internal List<string> BlackListedApps = new List<string>
		{
			"com.bluestacks",
			"com.google",
			"com.android",
			"com.uncube"
		};

		// Token: 0x040007B4 RID: 1972
		private int mNCSoftAgentPort = -1;

		// Token: 0x040007B5 RID: 1973
		private static NCSoftUtils mInstance = null;
	}
}
