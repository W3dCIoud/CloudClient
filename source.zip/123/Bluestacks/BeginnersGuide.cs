﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001DA RID: 474
	public class BeginnersGuide : UserControl, IComponentConnector
	{
		// Token: 0x0600105F RID: 4191 RVA: 0x00066EB8 File Offset: 0x000650B8
		public BeginnersGuide()
		{
			this.InitializeComponent();
			KeyboardNavigation.SetTabNavigation(this.grid, KeyboardNavigationMode.Cycle);
			this.mFisrtGrid.Visibility = Visibility.Visible;
			this.mSecondGrid.Visibility = Visibility.Hidden;
			this.mBackGroundScreen1.ImageName = string.Concat(new object[]
			{
				this.beginnersGuideFolderName,
				"\\Screen",
				this.imageCount,
				".jpg"
			});
			this.totalFileCount = this.GetFileCount();
		}

		// Token: 0x06001060 RID: 4192 RVA: 0x00066F50 File Offset: 0x00065150
		private int GetFileCount()
		{
			string path = Path.Combine(CustomPictureBox.AssetsDir, this.beginnersGuideFolderName);
			if (Directory.Exists(path))
			{
				return Directory.GetFiles(path, "*", SearchOption.TopDirectoryOnly).Length;
			}
			return 0;
		}

		// Token: 0x06001061 RID: 4193 RVA: 0x0000BAB1 File Offset: 0x00009CB1
		private void CloseBtn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			BlueStacksUIUtils.CloseContainerWindow(this);
			this.imageCount = 1;
		}

		// Token: 0x06001062 RID: 4194 RVA: 0x00066F88 File Offset: 0x00065188
		private void mNextBtn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.imageCount < this.totalFileCount)
			{
				this.imageCount++;
			}
			if (this.imageCount == this.totalFileCount)
			{
				this.mNextBtn.Visibility = Visibility.Hidden;
			}
			if (this.imageCount > 1)
			{
				this.mPrevBtn.Visibility = Visibility.Visible;
				this.mFisrtGrid.Visibility = Visibility.Hidden;
				this.mSecondGrid.Visibility = Visibility.Visible;
			}
			this.SetText();
		}

		// Token: 0x06001063 RID: 4195 RVA: 0x00067000 File Offset: 0x00065200
		private void mPrevBtn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.imageCount > 0)
			{
				this.imageCount--;
			}
			if (this.imageCount == 1)
			{
				this.mPrevBtn.Visibility = Visibility.Hidden;
				this.mFisrtGrid.Visibility = Visibility.Visible;
				this.mSecondGrid.Visibility = Visibility.Hidden;
			}
			if (this.imageCount <= this.totalFileCount)
			{
				this.mNextBtn.Visibility = Visibility.Visible;
			}
			this.SetText();
		}

		// Token: 0x06001064 RID: 4196 RVA: 0x00067074 File Offset: 0x00065274
		private void SetText()
		{
			this.mBackGroundScreen1.ImageName = string.Concat(new object[]
			{
				this.beginnersGuideFolderName,
				"\\Screen",
				this.imageCount,
				".jpg"
			});
			string arg = "SCREEN" + this.imageCount + "HeaderTEXT";
			string arg2 = "SCREEN" + this.imageCount + "PrefixTEXT";
			string arg3 = "SCREEN" + this.imageCount + "TEXT";
			string id = "SCREEN" + this.imageCount + "TITLE";
			this.mTitleScreen.Text = LocaleStrings.GetLocalizedString(id, true);
			this.mGuideInfoHeaderText1.Text = LocaleStrings.GetLocalizedString(arg + 1, true) + " ";
			this.mGuideInfoHeaderText2.Text = LocaleStrings.GetLocalizedString(arg + 2, true) + " ";
			this.mGuideInfoPrefixText1.Text = LocaleStrings.GetLocalizedString(arg2 + 1, true) + " ";
			this.mGuideInfoPrefixText2.Text = LocaleStrings.GetLocalizedString(arg2 + 2, true) + " ";
			this.mGuideInfoText1.Text = LocaleStrings.GetLocalizedString(arg3 + 1, true);
			this.mGuideInfoText2.Text = LocaleStrings.GetLocalizedString(arg3 + 2, true);
		}

		// Token: 0x06001065 RID: 4197 RVA: 0x00067214 File Offset: 0x00065414
		private void UserControl_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Left)
			{
				if (this.imageCount > 0)
				{
					this.imageCount--;
				}
				if (this.imageCount == 1)
				{
					this.mPrevBtn.Visibility = Visibility.Hidden;
					this.mFisrtGrid.Visibility = Visibility.Visible;
					this.mSecondGrid.Visibility = Visibility.Hidden;
				}
				if (this.imageCount <= this.totalFileCount)
				{
					this.mNextBtn.Visibility = Visibility.Visible;
				}
				this.SetText();
				return;
			}
			if (e.Key == Key.Right)
			{
				if (this.imageCount < this.totalFileCount)
				{
					this.imageCount++;
				}
				if (this.imageCount == this.totalFileCount)
				{
					this.mNextBtn.Visibility = Visibility.Hidden;
				}
				if (this.imageCount > 1)
				{
					this.mPrevBtn.Visibility = Visibility.Visible;
					this.mFisrtGrid.Visibility = Visibility.Hidden;
					this.mSecondGrid.Visibility = Visibility.Visible;
				}
				this.SetText();
				return;
			}
			if (e.Key == Key.Escape)
			{
				BlueStacksUIUtils.CloseContainerWindow(this);
				this.imageCount = 1;
			}
		}

		// Token: 0x06001066 RID: 4198 RVA: 0x0000BAC0 File Offset: 0x00009CC0
		private void grid_Loaded(object sender, RoutedEventArgs e)
		{
			this.grid.Focus();
		}

		// Token: 0x06001067 RID: 4199 RVA: 0x0006731C File Offset: 0x0006551C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/beginnersguide.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06001068 RID: 4200 RVA: 0x0006734C File Offset: 0x0006554C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((BeginnersGuide)target).PreviewKeyDown += this.UserControl_KeyDown;
				return;
			case 2:
				this.mGrid = (Grid)target;
				return;
			case 3:
				this.grid = (Grid)target;
				this.grid.Loaded += this.grid_Loaded;
				return;
			case 4:
				this.mBackGroundScreen1 = (CustomPictureBox)target;
				return;
			case 5:
				this.mTitleScreen = (TextBlock)target;
				return;
			case 6:
				this.mCloseBtn = (CustomPictureBox)target;
				this.mCloseBtn.MouseLeftButtonUp += this.CloseBtn_MouseLeftButtonUp;
				return;
			case 7:
				this.mPrevBtn = (CustomPictureBox)target;
				this.mPrevBtn.MouseLeftButtonUp += this.mPrevBtn_MouseLeftButtonUp;
				return;
			case 8:
				this.mNextBtn = (CustomPictureBox)target;
				this.mNextBtn.MouseLeftButtonUp += this.mNextBtn_MouseLeftButtonUp;
				return;
			case 9:
				this.mFisrtGrid = (Grid)target;
				return;
			case 10:
				this.mSecondGrid = (Grid)target;
				return;
			case 11:
				this.mTextGrid = (Grid)target;
				return;
			case 12:
				this.mGuideInfoHeaderText1 = (TextBlock)target;
				return;
			case 13:
				this.mGuideInfoHeaderText2 = (TextBlock)target;
				return;
			case 14:
				this.mGuideInfoPrefixText1 = (TextBlock)target;
				return;
			case 15:
				this.mGuideInfoPrefixText2 = (TextBlock)target;
				return;
			case 16:
				this.mGuideInfoText1 = (TextBlock)target;
				return;
			case 17:
				this.mGuideInfoText2 = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000B1D RID: 2845
		private string beginnersGuideFolderName = "EngScreens";

		// Token: 0x04000B1E RID: 2846
		private int imageCount = 1;

		// Token: 0x04000B1F RID: 2847
		private int totalFileCount;

		// Token: 0x04000B20 RID: 2848
		internal Grid mGrid;

		// Token: 0x04000B21 RID: 2849
		internal Grid grid;

		// Token: 0x04000B22 RID: 2850
		internal CustomPictureBox mBackGroundScreen1;

		// Token: 0x04000B23 RID: 2851
		internal TextBlock mTitleScreen;

		// Token: 0x04000B24 RID: 2852
		internal CustomPictureBox mCloseBtn;

		// Token: 0x04000B25 RID: 2853
		internal CustomPictureBox mPrevBtn;

		// Token: 0x04000B26 RID: 2854
		internal CustomPictureBox mNextBtn;

		// Token: 0x04000B27 RID: 2855
		internal Grid mFisrtGrid;

		// Token: 0x04000B28 RID: 2856
		internal Grid mSecondGrid;

		// Token: 0x04000B29 RID: 2857
		internal Grid mTextGrid;

		// Token: 0x04000B2A RID: 2858
		internal TextBlock mGuideInfoHeaderText1;

		// Token: 0x04000B2B RID: 2859
		internal TextBlock mGuideInfoHeaderText2;

		// Token: 0x04000B2C RID: 2860
		internal TextBlock mGuideInfoPrefixText1;

		// Token: 0x04000B2D RID: 2861
		internal TextBlock mGuideInfoPrefixText2;

		// Token: 0x04000B2E RID: 2862
		internal TextBlock mGuideInfoText1;

		// Token: 0x04000B2F RID: 2863
		internal TextBlock mGuideInfoText2;

		// Token: 0x04000B30 RID: 2864
		private bool _contentLoaded;
	}
}
