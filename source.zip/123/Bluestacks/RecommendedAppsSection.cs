﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000A5 RID: 165
	public class RecommendedAppsSection : UserControl, IComponentConnector
	{
		// Token: 0x06000718 RID: 1816 RVA: 0x000069E4 File Offset: 0x00004BE4
		public RecommendedAppsSection(string header)
		{
			this.InitializeComponent();
			this.mSectionHeader.Text = header;
		}

		// Token: 0x06000719 RID: 1817 RVA: 0x0002BFF0 File Offset: 0x0002A1F0
		internal void AddSuggestedApps(MainWindow ParentWindow, List<AppRecommendation> suggestedApps, int clientShowCount)
		{
			int num = 1;
			int num2 = 1;
			ParentWindow.mWelcomeTab.mHomeApp.sAppRecommendationsPool.Clear();
			foreach (AppRecommendation appRecommendation in suggestedApps)
			{
				if (!ParentWindow.mAppHandler.IsAppInstalled(appRecommendation.ExtraPayload["click_action_packagename"]))
				{
					RecommendedApps recommendedApps = new RecommendedApps();
					recommendedApps.Populate(ParentWindow, appRecommendation, num, num2);
					if (num <= clientShowCount)
					{
						this.mAppRecommendationsPanel.Children.Add(recommendedApps);
						num++;
					}
					else
					{
						ParentWindow.mWelcomeTab.mHomeApp.sAppRecommendationsPool.Add(recommendedApps);
					}
				}
				num2++;
			}
		}

		// Token: 0x0600071A RID: 1818 RVA: 0x0002C0B8 File Offset: 0x0002A2B8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/recommendedappssection.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600071B RID: 1819 RVA: 0x000069FE File Offset: 0x00004BFE
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mSectionHeader = (TextBlock)target;
				return;
			}
			if (connectionId != 2)
			{
				this._contentLoaded = true;
				return;
			}
			this.mAppRecommendationsPanel = (StackPanel)target;
		}

		// Token: 0x040004CC RID: 1228
		internal TextBlock mSectionHeader;

		// Token: 0x040004CD RID: 1229
		internal StackPanel mAppRecommendationsPanel;

		// Token: 0x040004CE RID: 1230
		private bool _contentLoaded;
	}
}
