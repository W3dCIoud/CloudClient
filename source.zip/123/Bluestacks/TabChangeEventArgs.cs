﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000C4 RID: 196
	public class TabChangeEventArgs : EventArgs
	{
		// Token: 0x060007E5 RID: 2021 RVA: 0x00007117 File Offset: 0x00005317
		public TabChangeEventArgs(string appName, string packageName, TabType tabType)
		{
			this.AppName = appName;
			this.PackageName = packageName;
			this.TabType = tabType;
		}

		// Token: 0x040005B2 RID: 1458
		public string AppName = string.Empty;

		// Token: 0x040005B3 RID: 1459
		public string PackageName = string.Empty;

		// Token: 0x040005B4 RID: 1460
		public TabType TabType;
	}
}
