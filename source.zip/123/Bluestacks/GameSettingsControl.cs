﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Markup;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000B7 RID: 183
	public class GameSettingsControl : UserControl, IComponentConnector
	{
		// Token: 0x06000760 RID: 1888 RVA: 0x0002E1BC File Offset: 0x0002C3BC
		public GameSettingsControl(MainWindow window, SettingsWindow settingsWindow)
		{
			this.ParentWindow = window;
			this.ParentSettingsWindow = settingsWindow;
			this.InitializeComponent();
			base.Visibility = Visibility.Hidden;
			this.Init();
			this.mScrollBar.ScrollChanged += BluestacksUIColor.ScrollBarScrollChanged;
			if (!this.ParentWindow.mGuestBootCompleted)
			{
				this.FreeFireGrid.Visibility = Visibility.Collapsed;
				this.mLineSeperator.Visibility = Visibility.Collapsed;
				this.CODGrid.Visibility = Visibility.Collapsed;
				this.mLineSeperatorCODFF.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x06000761 RID: 1889 RVA: 0x0002E29C File Offset: 0x0002C49C
		public void Init()
		{
			this.mCurrentPUBGResolution = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GamingResolutionPubg;
			if (!string.IsNullOrEmpty(this.mCurrentPUBGResolution))
			{
				if (this.mCurrentPUBGResolution == "1")
				{
					this.m720Resolution.IsChecked = new bool?(true);
				}
				else if (this.mCurrentPUBGResolution == "1.5")
				{
					this.m1080Resolution.IsChecked = new bool?(true);
				}
				else
				{
					this.m2kResolution.IsChecked = new bool?(true);
				}
			}
			else
			{
				this.m720Resolution.IsChecked = new bool?(true);
			}
			this.mSelectedPUBGResolution = this.mCurrentPUBGResolution;
			this.mCurrentPUBGDisplay = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityPubg;
			if (!string.IsNullOrEmpty(this.mCurrentPUBGDisplay))
			{
				if (this.mCurrentPUBGDisplay == "-1")
				{
					this.mAutoDisplay.IsChecked = new bool?(true);
				}
				else if (this.mCurrentPUBGDisplay == "0")
				{
					this.mSmoothDisplay.IsChecked = new bool?(true);
				}
				else if (this.mCurrentPUBGDisplay == "1")
				{
					this.mBalancedDisplay.IsChecked = new bool?(true);
				}
				else
				{
					this.mHDDisplay.IsChecked = new bool?(true);
				}
			}
			else
			{
				this.mAutoDisplay.IsChecked = new bool?(true);
			}
			this.mSelectedPUBGDisplay = this.mCurrentPUBGDisplay;
			this.mCustomCfgWarningGrid.Visibility = Visibility.Collapsed;
			this.mCurrentCODResolution = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GamingResolutionCOD;
			if (!string.IsNullOrEmpty(this.mCurrentCODResolution))
			{
				if (this.mCurrentCODResolution == "720")
				{
					this.mCOD720Resolution.IsChecked = new bool?(true);
				}
				else if (this.mCurrentCODResolution == "1080")
				{
					this.mCOD1080Resolution.IsChecked = new bool?(true);
				}
				else if (this.mCurrentCODResolution == "1440")
				{
					this.mCOD2kResolution.IsChecked = new bool?(true);
				}
				else
				{
					this.mCOD4kResolution.IsChecked = new bool?(true);
				}
			}
			else
			{
				this.mCOD720Resolution.IsChecked = new bool?(true);
			}
			this.mSelectedCODResolution = this.mCurrentCODResolution;
			this.mCurrentCODDisplay = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityCOD;
			if (!string.IsNullOrEmpty(this.mCurrentCODDisplay))
			{
				if (this.mCurrentCODDisplay == "-1")
				{
					this.mCODAutoDisplay.IsChecked = new bool?(true);
				}
				else if (this.mCurrentCODDisplay == "0")
				{
					this.mCODSmoothDisplay.IsChecked = new bool?(true);
				}
				else if (this.mCurrentCODDisplay == "1")
				{
					this.mCODBalancedDisplay.IsChecked = new bool?(true);
				}
				else
				{
					this.mCODHDDisplay.IsChecked = new bool?(true);
				}
			}
			else
			{
				this.mCODAutoDisplay.IsChecked = new bool?(true);
			}
			this.mSelectedCODDisplay = this.mCurrentCODDisplay;
			this.mCODCustomCfgWarningGrid.Visibility = Visibility.Collapsed;
			List<string> list = new List<string>(this.ParentWindow.EngineInstanceRegistry.SmartControlsEnabledApps);
			if (list.Contains("com.dts.freefireth"))
			{
				GameSettingsControl.mCurrentFeatures = FeatureBitHelper.EnableFeature(1UL, GameSettingsControl.mCurrentFeatures);
				GameSettingsControl.mNewFeatures = GameSettingsControl.mCurrentFeatures;
				this.mFreeFireSmartControlsOn = true;
				this.mSmartControlToggleCheckbox.IsChecked = new bool?(true);
			}
			foreach (string item in PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames)
			{
				if (list.Contains(item))
				{
					GameSettingsControl.mCurrentFeatures = FeatureBitHelper.EnableFeature(4UL, GameSettingsControl.mCurrentFeatures);
					GameSettingsControl.mNewFeatures = GameSettingsControl.mCurrentFeatures;
					this.mCODSmartControlsOn = true;
					this.mCODSmartControlToggleCheckbox.IsChecked = new bool?(true);
					break;
				}
			}
			string str = WebHelper.GetUrlWithParams(string.Format("{0}/{1}", WebHelper.GetServerHost(), "help_articles")) + "&article=";
			this.mKnowMoreAboutProfileChangeLink.NavigateUri = new Uri(str + "profile_settings_warning_pubg");
			this.mKnowMoreAboutProfileChangeLink.Inlines.Clear();
			this.mKnowMoreAboutProfileChangeLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_KNOW_MORE", false));
			this.mKnowMoreLink.NavigateUri = new Uri(str + "game_settings_know_more");
			this.mKnowMoreLink.Inlines.Clear();
			this.mKnowMoreLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_KNOW_MORE", false));
			if (this.ParentWindow.EngineInstanceRegistry.IsFreeFireInGameSettingsCustomized)
			{
				GameSettingsControl.mCurrentFeatures = FeatureBitHelper.EnableFeature(2UL, GameSettingsControl.mCurrentFeatures);
				GameSettingsControl.mNewFeatures = GameSettingsControl.mCurrentFeatures;
				this.mInGameFreeFireSettingsCheckBox.IsChecked = new bool?(true);
			}
		}

		// Token: 0x06000762 RID: 1890 RVA: 0x0002E7AC File Offset: 0x0002C9AC
		private void Resolution_Checked(object sender, RoutedEventArgs e)
		{
			if (this.m720Resolution.IsChecked.Value)
			{
				this.mSelectedPUBGResolution = "1";
			}
			else if (this.m1080Resolution.IsChecked.Value)
			{
				this.mSelectedPUBGResolution = "1.5";
			}
			else if (this.m2kResolution.IsChecked.Value)
			{
				this.mSelectedPUBGResolution = "2";
			}
			this.mCustomCfgWarningGrid.Visibility = Visibility.Visible;
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x06000763 RID: 1891 RVA: 0x0002E830 File Offset: 0x0002CA30
		private void Display_Checked(object sender, RoutedEventArgs e)
		{
			if (this.mAutoDisplay.IsChecked.Value)
			{
				this.mSelectedPUBGDisplay = "-1";
			}
			else if (this.mSmoothDisplay.IsChecked.Value)
			{
				this.mSelectedPUBGDisplay = "0";
			}
			else if (this.mBalancedDisplay.IsChecked.Value)
			{
				this.mSelectedPUBGDisplay = "1";
			}
			else if (this.mHDDisplay.IsChecked.Value)
			{
				this.mSelectedPUBGDisplay = "2";
			}
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x06000764 RID: 1892 RVA: 0x0002E8CC File Offset: 0x0002CACC
		private void SaveChangesBtn_Click(object sender, RoutedEventArgs e)
		{
			bool flag = false;
			bool flag2 = false;
			if (this.mSelectedPUBGResolution != this.mCurrentPUBGResolution)
			{
				RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GamingResolutionPubg = this.mSelectedPUBGResolution;
				this.mCurrentPUBGResolution = this.mSelectedPUBGResolution;
				flag = true;
				string a = this.mSelectedPUBGResolution;
				if (!(a == "1"))
				{
					if (!(a == "1.5"))
					{
						if (a == "2")
						{
							this.SendGameSettingsStat("pubg_res_1440");
						}
					}
					else
					{
						this.SendGameSettingsStat("pubg_res_1080");
					}
				}
				else
				{
					this.SendGameSettingsStat("pubg_res_720");
				}
			}
			if (this.mSelectedPUBGDisplay != this.mCurrentPUBGDisplay)
			{
				RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityPubg = this.mSelectedPUBGDisplay;
				this.mCurrentPUBGDisplay = this.mSelectedPUBGDisplay;
				flag = true;
				string a = this.mSelectedPUBGDisplay;
				if (!(a == "-1"))
				{
					if (!(a == "1"))
					{
						if (!(a == "2"))
						{
							if (a == "0")
							{
								this.SendGameSettingsStat("pubg_gfx_smooth");
							}
						}
						else
						{
							this.SendGameSettingsStat("pubg_gfx_hd");
						}
					}
					else
					{
						this.SendGameSettingsStat("pubg_gfx_balanced");
					}
				}
				else
				{
					this.SendGameSettingsStat("pubg_gfx_auto");
				}
			}
			if (this.mSelectedCODResolution != this.mCurrentCODResolution)
			{
				RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GamingResolutionCOD = this.mSelectedCODResolution;
				this.mCurrentCODResolution = this.mSelectedCODResolution;
				flag2 = true;
				string a = this.mSelectedCODResolution;
				if (!(a == "720"))
				{
					if (!(a == "1080"))
					{
						if (!(a == "1440"))
						{
							if (a == "2160")
							{
								this.SendGameSettingsStat("cod_res_1440");
							}
						}
						else
						{
							this.SendGameSettingsStat("cod_res_1440");
						}
					}
					else
					{
						this.SendGameSettingsStat("cod_res_1080");
					}
				}
				else
				{
					this.SendGameSettingsStat("cod_res_720");
				}
			}
			if (this.mSelectedCODDisplay != this.mCurrentCODDisplay)
			{
				RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityCOD = this.mSelectedCODDisplay;
				this.mCurrentCODDisplay = this.mSelectedCODDisplay;
				flag2 = true;
				string a = this.mSelectedCODDisplay;
				if (!(a == "-1"))
				{
					if (!(a == "1"))
					{
						if (!(a == "2"))
						{
							if (a == "0")
							{
								this.SendGameSettingsStat("cod_gfx_smooth");
							}
						}
						else
						{
							this.SendGameSettingsStat("cod_gfx_hd");
						}
					}
					else
					{
						this.SendGameSettingsStat("cod_gfx_balanced");
					}
				}
				else
				{
					this.SendGameSettingsStat("cod_gfx_auto");
				}
			}
			if (this.IsAnyFeatureDifferent())
			{
				if (this.WasFeatureChanged(1UL, out this.mFreeFireSmartControlsOn))
				{
					List<string> list = new List<string>(this.ParentWindow.EngineInstanceRegistry.SmartControlsEnabledApps);
					if (this.mFreeFireSmartControlsOn)
					{
						list.AddIfNotContain("com.dts.freefireth");
						this.SendGameSettingsStat("freefire_smartcontrols_enabled");
					}
					else
					{
						if (list.Contains("com.dts.freefireth"))
						{
							list.Remove("com.dts.freefireth");
						}
						this.SendGameSettingsStat("freefire_smartcontrols_disabled");
					}
					this.ParentWindow.EngineInstanceRegistry.SmartControlsEnabledApps = list.ToArray();
					BlueStacksUIUtils.RefreshKeyMap(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName);
				}
				if (this.WasFeatureChanged(4UL, out this.mCODSmartControlsOn))
				{
					List<string> list2 = new List<string>(this.ParentWindow.EngineInstanceRegistry.SmartControlsEnabledApps);
					if (this.mCODSmartControlsOn)
					{
						list2.AddIfNotContain(PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames);
						this.SendGameSettingsStat("cod_smartcontrols_enabled");
					}
					else
					{
						foreach (string item in PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames)
						{
							if (list2.Contains(item))
							{
								list2.Remove(item);
							}
						}
						this.SendGameSettingsStat("cod_smartcontrols_disabled");
					}
					this.ParentWindow.EngineInstanceRegistry.SmartControlsEnabledApps = list2.ToArray();
					BlueStacksUIUtils.RefreshKeyMap(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName);
				}
				bool flag3;
				if (this.WasFeatureChanged(2UL, out flag3))
				{
					this.SendGameSettingsEnabledToGuest("com.dts.freefireth", flag3);
					this.ParentWindow.EngineInstanceRegistry.IsFreeFireInGameSettingsCustomized = flag3;
					if (flag3)
					{
						this.SendGameSettingsStat("freefire_optimizegame_enabled");
					}
					else
					{
						this.SendGameSettingsStat("freefire_optimizegame_disabled");
					}
				}
			}
			if (flag)
			{
				this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_SAVE_CHANGES", false));
				int num = PackageActivityNames.ThirdParty.AllPUBGPackageNames.FindIndex((string x) => this.ParentWindow.mTopBar.mAppTabButtons.mDictTabs.ContainsKey(x));
				if (PackageActivityNames.ThirdParty.AllPUBGPackageNames.Contains(this.ParentWindow.StaticComponents.mSelectedTabButton.PackageName))
				{
					this.ParentSettingsWindow.mIsRestartPUBGTabOnClose = true;
					this.ParentSettingsWindow.mRestartTabPackageName = this.ParentWindow.StaticComponents.mSelectedTabButton.PackageName;
				}
				else if (num != -1)
				{
					this.ParentWindow.mTopBar.mAppTabButtons.mDictTabs[PackageActivityNames.ThirdParty.AllPUBGPackageNames[num]].mRestartPubgTab = true;
				}
			}
			if (flag2)
			{
				this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_SAVE_CHANGES", false));
				int num2 = PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.FindIndex((string x) => this.ParentWindow.mTopBar.mAppTabButtons.mDictTabs.ContainsKey(x));
				if (PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.Contains(this.ParentWindow.StaticComponents.mSelectedTabButton.PackageName))
				{
					this.ParentSettingsWindow.mIsRestartCODTabOnClose = true;
					this.ParentSettingsWindow.mRestartTabPackageName = this.ParentWindow.StaticComponents.mSelectedTabButton.PackageName;
				}
				else if (num2 != -1)
				{
					this.ParentWindow.mTopBar.mAppTabButtons.mDictTabs[PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames[num2]].mRestartCODTab = true;
				}
			}
			GameSettingsControl.mCurrentFeatures = GameSettingsControl.mNewFeatures;
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x06000765 RID: 1893 RVA: 0x0002EEE8 File Offset: 0x0002D0E8
		private void AddToastPopup(string message)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (this.mToastPopup == null)
				{
					this.mToastPopup = new CustomToastPopupControl(this);
				}
				Thickness value = new Thickness(0.0, 0.0, 0.0, 50.0);
				this.mToastPopup.Init(this, message, null, null, HorizontalAlignment.Center, VerticalAlignment.Bottom, new Thickness?(value), 12, null, null);
				this.mToastPopup.ShowPopup(1.3);
			}), new object[0]);
		}

		// Token: 0x06000766 RID: 1894 RVA: 0x0002EF28 File Offset: 0x0002D128
		private void UserControl_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (base.Visibility == Visibility.Visible)
			{
				this.ParentWindow.mTopBar.mSettingsBtnNotification.Visibility = Visibility.Hidden;
				this.ParentWindow.mTopBar.mPreferenceDropDownControl.mSettingsBtnNotification.Visibility = Visibility.Hidden;
				this.ParentSettingsWindow.gameSettingsButton.ShowButtonNotification = false;
			}
		}

		// Token: 0x06000767 RID: 1895 RVA: 0x0002EF80 File Offset: 0x0002D180
		private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
		{
			try
			{
				Logger.Info("Opening url: " + e.Uri.AbsoluteUri);
				BlueStacksUIUtils.OpenUrl(e.Uri.AbsoluteUri);
				e.Handled = true;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in opening url" + ex.ToString());
			}
		}

		// Token: 0x06000768 RID: 1896 RVA: 0x00006C31 File Offset: 0x00004E31
		private void SmartControlToggleCheckbox_Checked(object sender, RoutedEventArgs e)
		{
			GameSettingsControl.mNewFeatures = FeatureBitHelper.EnableFeature(1UL, GameSettingsControl.mNewFeatures);
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x06000769 RID: 1897 RVA: 0x00006C4A File Offset: 0x00004E4A
		private void SmartControlToggleCheckbox_Unchecked(object sender, RoutedEventArgs e)
		{
			GameSettingsControl.mNewFeatures = FeatureBitHelper.DisableFeature(1UL, GameSettingsControl.mNewFeatures);
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x0600076A RID: 1898 RVA: 0x00006C63 File Offset: 0x00004E63
		private void InGameFreeFireSettingsCheckBox_Checked(object sender, RoutedEventArgs e)
		{
			GameSettingsControl.mNewFeatures = FeatureBitHelper.EnableFeature(2UL, GameSettingsControl.mNewFeatures);
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x0600076B RID: 1899 RVA: 0x00006C7C File Offset: 0x00004E7C
		private void InGameFreeFireSettingsCheckBox_Unchecked(object sender, RoutedEventArgs e)
		{
			GameSettingsControl.mNewFeatures = FeatureBitHelper.DisableFeature(2UL, GameSettingsControl.mNewFeatures);
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x0600076C RID: 1900 RVA: 0x0002EFE8 File Offset: 0x0002D1E8
		private void SendGameSettingsEnabledToGuest(string pkgName, bool enabled)
		{
			string text = "{";
			text += string.Format("\"package_name\":\"{0}\",", "com.dts.freefireth");
			text += string.Format("\"game_settings_enabled\":\"{0}\"", enabled.ToString());
			text += "}";
			VmCmdHandler.RunCommandAsync(string.Format("{0} {1}", "gameSettingsEnabled", text), null, null, this.ParentWindow.mVmName);
		}

		// Token: 0x0600076D RID: 1901 RVA: 0x0002F058 File Offset: 0x0002D258
		private void CheckAndToggleSaveButton()
		{
			if (this.mSelectedPUBGResolution != this.mCurrentPUBGResolution || this.mSelectedPUBGDisplay != this.mCurrentPUBGDisplay || this.mSelectedCODResolution != this.mCurrentCODResolution || this.mSelectedCODDisplay != this.mCurrentCODDisplay || this.IsAnyFeatureDifferent())
			{
				this.mSaveChangesBtn.IsEnabled = true;
				return;
			}
			this.mSaveChangesBtn.IsEnabled = false;
		}

		// Token: 0x0600076E RID: 1902 RVA: 0x00006C95 File Offset: 0x00004E95
		private bool IsAnyFeatureDifferent()
		{
			return GameSettingsControl.mCurrentFeatures != GameSettingsControl.mNewFeatures;
		}

		// Token: 0x0600076F RID: 1903 RVA: 0x00006CA6 File Offset: 0x00004EA6
		private bool WasFeatureChanged(ulong featureMask, out bool isEnabled)
		{
			return FeatureBitHelper.WasFeatureChanged(featureMask, GameSettingsControl.mNewFeatures, GameSettingsControl.mCurrentFeatures, out isEnabled);
		}

		// Token: 0x06000770 RID: 1904 RVA: 0x0002F0D4 File Offset: 0x0002D2D4
		private void SendGameSettingsStat(string statsTag)
		{
			ClientStats.SendMiscellaneousStatsAsync("client_game_settings", RegistryManager.Instance.UserGuid, statsTag, RegistryManager.Instance.ClientVersion, ((GLMode)this.ParentWindow.EngineInstanceRegistry.GlMode).ToString(), ((GLRenderer)this.ParentWindow.EngineInstanceRegistry.GlRenderMode).ToString(), null, null, null);
		}

		// Token: 0x06000771 RID: 1905 RVA: 0x00006CB9 File Offset: 0x00004EB9
		private void CODSmartControlToggleCheckbox_Checked(object sender, RoutedEventArgs e)
		{
			GameSettingsControl.mNewFeatures = FeatureBitHelper.EnableFeature(4UL, GameSettingsControl.mNewFeatures);
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x06000772 RID: 1906 RVA: 0x00006CD2 File Offset: 0x00004ED2
		private void CODSmartControlToggleCheckbox_Unchecked(object sender, RoutedEventArgs e)
		{
			GameSettingsControl.mNewFeatures = FeatureBitHelper.DisableFeature(4UL, GameSettingsControl.mNewFeatures);
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x06000773 RID: 1907 RVA: 0x0002F140 File Offset: 0x0002D340
		private void CODResolution_Checked(object sender, RoutedEventArgs e)
		{
			if (this.mCOD720Resolution.IsChecked.Value)
			{
				this.mSelectedCODResolution = "720";
			}
			else if (this.mCOD1080Resolution.IsChecked.Value)
			{
				this.mSelectedCODResolution = "1080";
			}
			else if (this.mCOD2kResolution.IsChecked.Value)
			{
				this.mSelectedCODResolution = "1440";
			}
			else if (this.mCOD4kResolution.IsChecked.Value)
			{
				this.mSelectedCODResolution = "2160";
			}
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x06000774 RID: 1908 RVA: 0x0002F1DC File Offset: 0x0002D3DC
		private void CODDisplay_Checked(object sender, RoutedEventArgs e)
		{
			if (this.mCODAutoDisplay.IsChecked.Value)
			{
				this.mSelectedCODDisplay = "-1";
			}
			else if (this.mCODSmoothDisplay.IsChecked.Value)
			{
				this.mSelectedCODDisplay = "0";
			}
			else if (this.mCODBalancedDisplay.IsChecked.Value)
			{
				this.mSelectedCODDisplay = "1";
			}
			else if (this.mCODHDDisplay.IsChecked.Value)
			{
				this.mSelectedCODDisplay = "2";
			}
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x06000775 RID: 1909 RVA: 0x0002F278 File Offset: 0x0002D478
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/gamesettingscontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000776 RID: 1910 RVA: 0x0002F2A8 File Offset: 0x0002D4A8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((GameSettingsControl)target).IsVisibleChanged += this.UserControl_IsVisibleChanged;
				return;
			case 2:
				this.mScrollBar = (ScrollViewer)target;
				return;
			case 3:
				this.CODGrid = (Grid)target;
				return;
			case 4:
				this.mCODSmartControlsGrid = (Grid)target;
				return;
			case 5:
				this.mCODSmartControlToggleCheckbox = (CustomCheckbox)target;
				this.mCODSmartControlToggleCheckbox.Checked += this.CODSmartControlToggleCheckbox_Checked;
				this.mCODSmartControlToggleCheckbox.Unchecked += this.CODSmartControlToggleCheckbox_Unchecked;
				return;
			case 6:
				this.mCODSmartControlHelpMessageTextBlock = (TextBlock)target;
				return;
			case 7:
				this.mCODGamingResolutionGrid = (Grid)target;
				return;
			case 8:
				this.mCOD720Resolution = (CustomRadioButton)target;
				this.mCOD720Resolution.Checked += this.CODResolution_Checked;
				return;
			case 9:
				this.mCOD1080Resolution = (CustomRadioButton)target;
				this.mCOD1080Resolution.Checked += this.CODResolution_Checked;
				return;
			case 10:
				this.mCOD2kResolution = (CustomRadioButton)target;
				this.mCOD2kResolution.Checked += this.CODResolution_Checked;
				return;
			case 11:
				this.mCOD4kResolution = (CustomRadioButton)target;
				this.mCOD4kResolution.Checked += this.CODResolution_Checked;
				return;
			case 12:
				this.mCODDisplayQualityGrid = (Grid)target;
				return;
			case 13:
				this.mCODAutoDisplay = (CustomRadioButton)target;
				this.mCODAutoDisplay.Checked += this.CODDisplay_Checked;
				return;
			case 14:
				this.mCODSmoothDisplay = (CustomRadioButton)target;
				this.mCODSmoothDisplay.Checked += this.CODDisplay_Checked;
				return;
			case 15:
				this.mCODBalancedDisplay = (CustomRadioButton)target;
				this.mCODBalancedDisplay.Checked += this.CODDisplay_Checked;
				return;
			case 16:
				this.mCODHDDisplay = (CustomRadioButton)target;
				this.mCODHDDisplay.Checked += this.CODDisplay_Checked;
				return;
			case 17:
				this.mCODCustomCfgWarningGrid = (Grid)target;
				return;
			case 18:
				this.mKnowMoreAboutCODProfileChangeLink = (Hyperlink)target;
				this.mKnowMoreAboutCODProfileChangeLink.RequestNavigate += this.Hyperlink_RequestNavigate;
				return;
			case 19:
				this.mLineSeperatorCODFF = (Line)target;
				return;
			case 20:
				this.FreeFireGrid = (Grid)target;
				return;
			case 21:
				this.mSmartControlsGrid = (Grid)target;
				return;
			case 22:
				this.mSmartControlToggleCheckbox = (CustomCheckbox)target;
				this.mSmartControlToggleCheckbox.Checked += this.SmartControlToggleCheckbox_Checked;
				this.mSmartControlToggleCheckbox.Unchecked += this.SmartControlToggleCheckbox_Unchecked;
				return;
			case 23:
				this.mSmartControlHelpMessageTextBlock = (TextBlock)target;
				return;
			case 24:
				this.mOptimizedFreeFireSettings = (Grid)target;
				return;
			case 25:
				this.mInGameFreeFireSettingsCheckBox = (CustomCheckbox)target;
				this.mInGameFreeFireSettingsCheckBox.Checked += this.InGameFreeFireSettingsCheckBox_Checked;
				this.mInGameFreeFireSettingsCheckBox.Unchecked += this.InGameFreeFireSettingsCheckBox_Unchecked;
				return;
			case 26:
				this.mInGameFreeFireSettingsHelpTextBlock = (TextBlock)target;
				return;
			case 27:
				this.mLineSeperator = (Line)target;
				return;
			case 28:
				this.PUBGGrid = (Grid)target;
				return;
			case 29:
				this.mPUBGGamingResolutionGrid = (Grid)target;
				return;
			case 30:
				this.m720Resolution = (CustomRadioButton)target;
				this.m720Resolution.Checked += this.Resolution_Checked;
				return;
			case 31:
				this.m720ResolutionMessage = (TextBlock)target;
				return;
			case 32:
				this.m1080Resolution = (CustomRadioButton)target;
				this.m1080Resolution.Checked += this.Resolution_Checked;
				return;
			case 33:
				this.m2kResolution = (CustomRadioButton)target;
				this.m2kResolution.Checked += this.Resolution_Checked;
				return;
			case 34:
				this.mDisplayQualityGrid = (Grid)target;
				return;
			case 35:
				this.mAutoDisplay = (CustomRadioButton)target;
				this.mAutoDisplay.Checked += this.Display_Checked;
				return;
			case 36:
				this.mSmoothDisplay = (CustomRadioButton)target;
				this.mSmoothDisplay.Checked += this.Display_Checked;
				return;
			case 37:
				this.mBalancedDisplay = (CustomRadioButton)target;
				this.mBalancedDisplay.Checked += this.Display_Checked;
				return;
			case 38:
				this.mHDDisplay = (CustomRadioButton)target;
				this.mHDDisplay.Checked += this.Display_Checked;
				return;
			case 39:
				this.mCustomCfgWarningGrid = (Grid)target;
				return;
			case 40:
				this.mKnowMoreAboutProfileChangeLink = (Hyperlink)target;
				this.mKnowMoreAboutProfileChangeLink.RequestNavigate += this.Hyperlink_RequestNavigate;
				return;
			case 41:
				this.mSaveChangesBtn = (CustomButton)target;
				this.mSaveChangesBtn.Click += this.SaveChangesBtn_Click;
				return;
			case 42:
				this.mKnowMoreLink = (Hyperlink)target;
				this.mKnowMoreLink.RequestNavigate += this.Hyperlink_RequestNavigate;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400050D RID: 1293
		private MainWindow ParentWindow;

		// Token: 0x0400050E RID: 1294
		private SettingsWindow ParentSettingsWindow;

		// Token: 0x0400050F RID: 1295
		private const ulong FREEFIRE_ENABLE_SMART_CONTROLS = 1UL;

		// Token: 0x04000510 RID: 1296
		private const ulong FREEFIRE_ENABLE_OPTIMIZE_INGAME_SETTINGS = 2UL;

		// Token: 0x04000511 RID: 1297
		private const ulong COD_ENABLE_SMART_CONTROLS = 4UL;

		// Token: 0x04000512 RID: 1298
		private static ulong mCurrentFeatures;

		// Token: 0x04000513 RID: 1299
		private static ulong mNewFeatures;

		// Token: 0x04000514 RID: 1300
		private CustomToastPopupControl mToastPopup;

		// Token: 0x04000515 RID: 1301
		private string mCurrentPUBGResolution = "1";

		// Token: 0x04000516 RID: 1302
		private string mSelectedPUBGResolution = "1";

		// Token: 0x04000517 RID: 1303
		private string mCurrentPUBGDisplay = "-1";

		// Token: 0x04000518 RID: 1304
		private string mSelectedPUBGDisplay = "-1";

		// Token: 0x04000519 RID: 1305
		private string mCurrentCODResolution = "1";

		// Token: 0x0400051A RID: 1306
		private string mSelectedCODResolution = "1";

		// Token: 0x0400051B RID: 1307
		private string mCurrentCODDisplay = "-1";

		// Token: 0x0400051C RID: 1308
		private string mSelectedCODDisplay = "-1";

		// Token: 0x0400051D RID: 1309
		private bool mFreeFireSmartControlsOn;

		// Token: 0x0400051E RID: 1310
		private bool mCODSmartControlsOn;

		// Token: 0x0400051F RID: 1311
		internal ScrollViewer mScrollBar;

		// Token: 0x04000520 RID: 1312
		internal Grid CODGrid;

		// Token: 0x04000521 RID: 1313
		internal Grid mCODSmartControlsGrid;

		// Token: 0x04000522 RID: 1314
		internal CustomCheckbox mCODSmartControlToggleCheckbox;

		// Token: 0x04000523 RID: 1315
		internal TextBlock mCODSmartControlHelpMessageTextBlock;

		// Token: 0x04000524 RID: 1316
		internal Grid mCODGamingResolutionGrid;

		// Token: 0x04000525 RID: 1317
		internal CustomRadioButton mCOD720Resolution;

		// Token: 0x04000526 RID: 1318
		internal CustomRadioButton mCOD1080Resolution;

		// Token: 0x04000527 RID: 1319
		internal CustomRadioButton mCOD2kResolution;

		// Token: 0x04000528 RID: 1320
		internal CustomRadioButton mCOD4kResolution;

		// Token: 0x04000529 RID: 1321
		internal Grid mCODDisplayQualityGrid;

		// Token: 0x0400052A RID: 1322
		internal CustomRadioButton mCODAutoDisplay;

		// Token: 0x0400052B RID: 1323
		internal CustomRadioButton mCODSmoothDisplay;

		// Token: 0x0400052C RID: 1324
		internal CustomRadioButton mCODBalancedDisplay;

		// Token: 0x0400052D RID: 1325
		internal CustomRadioButton mCODHDDisplay;

		// Token: 0x0400052E RID: 1326
		internal Grid mCODCustomCfgWarningGrid;

		// Token: 0x0400052F RID: 1327
		internal Hyperlink mKnowMoreAboutCODProfileChangeLink;

		// Token: 0x04000530 RID: 1328
		internal Line mLineSeperatorCODFF;

		// Token: 0x04000531 RID: 1329
		internal Grid FreeFireGrid;

		// Token: 0x04000532 RID: 1330
		internal Grid mSmartControlsGrid;

		// Token: 0x04000533 RID: 1331
		internal CustomCheckbox mSmartControlToggleCheckbox;

		// Token: 0x04000534 RID: 1332
		internal TextBlock mSmartControlHelpMessageTextBlock;

		// Token: 0x04000535 RID: 1333
		internal Grid mOptimizedFreeFireSettings;

		// Token: 0x04000536 RID: 1334
		internal CustomCheckbox mInGameFreeFireSettingsCheckBox;

		// Token: 0x04000537 RID: 1335
		internal TextBlock mInGameFreeFireSettingsHelpTextBlock;

		// Token: 0x04000538 RID: 1336
		internal Line mLineSeperator;

		// Token: 0x04000539 RID: 1337
		internal Grid PUBGGrid;

		// Token: 0x0400053A RID: 1338
		internal Grid mPUBGGamingResolutionGrid;

		// Token: 0x0400053B RID: 1339
		internal CustomRadioButton m720Resolution;

		// Token: 0x0400053C RID: 1340
		internal TextBlock m720ResolutionMessage;

		// Token: 0x0400053D RID: 1341
		internal CustomRadioButton m1080Resolution;

		// Token: 0x0400053E RID: 1342
		internal CustomRadioButton m2kResolution;

		// Token: 0x0400053F RID: 1343
		internal Grid mDisplayQualityGrid;

		// Token: 0x04000540 RID: 1344
		internal CustomRadioButton mAutoDisplay;

		// Token: 0x04000541 RID: 1345
		internal CustomRadioButton mSmoothDisplay;

		// Token: 0x04000542 RID: 1346
		internal CustomRadioButton mBalancedDisplay;

		// Token: 0x04000543 RID: 1347
		internal CustomRadioButton mHDDisplay;

		// Token: 0x04000544 RID: 1348
		internal Grid mCustomCfgWarningGrid;

		// Token: 0x04000545 RID: 1349
		internal Hyperlink mKnowMoreAboutProfileChangeLink;

		// Token: 0x04000546 RID: 1350
		internal CustomButton mSaveChangesBtn;

		// Token: 0x04000547 RID: 1351
		internal Hyperlink mKnowMoreLink;

		// Token: 0x04000548 RID: 1352
		private bool _contentLoaded;

		// Token: 0x020000B8 RID: 184
		private class MiscStatsTag
		{
			// Token: 0x04000549 RID: 1353
			internal const string PUBGResolution720 = "pubg_res_720";

			// Token: 0x0400054A RID: 1354
			internal const string PUBGResolution1080 = "pubg_res_1080";

			// Token: 0x0400054B RID: 1355
			internal const string PUBGResolution1440 = "pubg_res_1440";

			// Token: 0x0400054C RID: 1356
			internal const string PUBGGraphicsAuto = "pubg_gfx_auto";

			// Token: 0x0400054D RID: 1357
			internal const string PUBGGraphicsSmooth = "pubg_gfx_smooth";

			// Token: 0x0400054E RID: 1358
			internal const string PUBGGraphicsBalanced = "pubg_gfx_balanced";

			// Token: 0x0400054F RID: 1359
			internal const string PUBGGraphicsHD = "pubg_gfx_hd";

			// Token: 0x04000550 RID: 1360
			internal const string FreeFireSmartControlsOn = "freefire_smartcontrols_enabled";

			// Token: 0x04000551 RID: 1361
			internal const string FreeFireSmartControlsOff = "freefire_smartcontrols_disabled";

			// Token: 0x04000552 RID: 1362
			internal const string FreeFireOptimizeIngameSettingsOn = "freefire_optimizegame_enabled";

			// Token: 0x04000553 RID: 1363
			internal const string FreeFireOptimizeIngameSettingsOff = "freefire_optimizegame_disabled";

			// Token: 0x04000554 RID: 1364
			internal const string CODSmartControlsOn = "cod_smartcontrols_enabled";

			// Token: 0x04000555 RID: 1365
			internal const string CODSmartControlsOff = "cod_smartcontrols_disabled";

			// Token: 0x04000556 RID: 1366
			internal const string CODResolution720 = "cod_res_720";

			// Token: 0x04000557 RID: 1367
			internal const string CODResolution1080 = "cod_res_1080";

			// Token: 0x04000558 RID: 1368
			internal const string CODResolution1440 = "cod_res_1440";

			// Token: 0x04000559 RID: 1369
			internal const string CODResolution2160 = "cod_res_2160";

			// Token: 0x0400055A RID: 1370
			internal const string CODGraphicsAuto = "cod_gfx_auto";

			// Token: 0x0400055B RID: 1371
			internal const string CODGraphicsSmooth = "cod_gfx_smooth";

			// Token: 0x0400055C RID: 1372
			internal const string CODGraphicsBalanced = "cod_gfx_balanced";

			// Token: 0x0400055D RID: 1373
			internal const string CODGraphicsHD = "cod_gfx_hd";
		}
	}
}
