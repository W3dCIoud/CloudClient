﻿using System;
using System.ComponentModel;

// Token: 0x02000016 RID: 22
[Description("Independent")]
[Serializable]
public class Tap : IMAction
{
	// Token: 0x170000A1 RID: 161
	// (get) Token: 0x06000158 RID: 344 RVA: 0x00002E41 File Offset: 0x00001041
	// (set) Token: 0x06000159 RID: 345 RVA: 0x00002E49 File Offset: 0x00001049
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X
	{
		get
		{
			return this.mX;
		}
		set
		{
			this.mX = value;
		}
	}

	// Token: 0x170000A2 RID: 162
	// (get) Token: 0x0600015A RID: 346 RVA: 0x00002E52 File Offset: 0x00001052
	// (set) Token: 0x0600015B RID: 347 RVA: 0x00002E5A File Offset: 0x0000105A
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y
	{
		get
		{
			return this.mY;
		}
		set
		{
			this.mY = value;
		}
	}

	// Token: 0x170000A3 RID: 163
	// (get) Token: 0x0600015C RID: 348 RVA: 0x00002E63 File Offset: 0x00001063
	// (set) Token: 0x0600015D RID: 349 RVA: 0x00002E6B File Offset: 0x0000106B
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key
	{
		get
		{
			return this.mKey;
		}
		set
		{
			this.mKey = value;
		}
	}

	// Token: 0x170000A4 RID: 164
	// (get) Token: 0x0600015E RID: 350 RVA: 0x00002E74 File Offset: 0x00001074
	// (set) Token: 0x0600015F RID: 351 RVA: 0x00002E7C File Offset: 0x0000107C
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key_alt1
	{
		get
		{
			return this.mKey_1;
		}
		set
		{
			this.mKey_1 = value;
		}
	}

	// Token: 0x170000A5 RID: 165
	// (get) Token: 0x06000160 RID: 352 RVA: 0x00002E85 File Offset: 0x00001085
	// (set) Token: 0x06000161 RID: 353 RVA: 0x00002E8D File Offset: 0x0000108D
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool ShowOnOverlay
	{
		get
		{
			return this.mShowOnOverlay;
		}
		set
		{
			this.mShowOnOverlay = value;
		}
	}

	// Token: 0x0400009E RID: 158
	private double mX = -1.0;

	// Token: 0x0400009F RID: 159
	private double mY = -1.0;

	// Token: 0x040000A0 RID: 160
	private string mKey;

	// Token: 0x040000A1 RID: 161
	private string mKey_1 = string.Empty;

	// Token: 0x040000A2 RID: 162
	internal bool mShowOnOverlay = true;
}
