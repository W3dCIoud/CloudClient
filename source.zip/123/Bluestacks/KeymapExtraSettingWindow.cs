﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000D4 RID: 212
	public class KeymapExtraSettingWindow : CustomPopUp, IComponentConnector
	{
		// Token: 0x060008C2 RID: 2242 RVA: 0x00038A30 File Offset: 0x00036C30
		public KeymapExtraSettingWindow(MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			this.mStackPanel = (this.mScrollBar.Content as StackPanel);
			this.AddGuidanceCategories();
			this.AddDualTextBlockControl();
			this.SetPopupDraggableProperty();
		}

		// Token: 0x060008C3 RID: 2243 RVA: 0x000078EE File Offset: 0x00005AEE
		private void AddDualTextBlockControl()
		{
			this.AddDualTextBlockControlToMOBAPanel();
			this.AddDualTextBlockControlToLookAroundPanel();
			this.AddDualTextBlockControlToShootGBPanel();
			this.AddDualTextBlockControlToMOBASkillCancelGBPanel();
			this.AddDualTextBlockControlToGroupBox();
		}

		// Token: 0x060008C4 RID: 2244 RVA: 0x00038A9C File Offset: 0x00036C9C
		private void AddDualTextBlockControlToGroupBox()
		{
			this.mEnableConditionTB = new DualTextBlockControl(this.ParentWindow);
			this.mEnableConditionTB.Margin = new Thickness(0.0, 5.0, 0.0, 0.0);
			this.mEnableConditionTB.VerticalAlignment = VerticalAlignment.Top;
			this.mEnableConditionTB.HorizontalAlignment = HorizontalAlignment.Stretch;
			this.mEnableConditionTB.Height = 32.0;
			this.mEnableConditionGB.Content = this.mEnableConditionTB;
		}

		// Token: 0x060008C5 RID: 2245 RVA: 0x00038B2C File Offset: 0x00036D2C
		internal void AddDualTextBlockControlToMOBASkillCancelGBPanel()
		{
			this.mMOBASkillCancelDTB = new DualTextBlockControl(this.ParentWindow);
			this.mMOBASkillCancelDTB.Margin = new Thickness(0.0, 5.0, 0.0, 0.0);
			this.mMOBASkillCancelGBPanel.Children.Add(this.mMOBASkillCancelDTB);
		}

		// Token: 0x060008C6 RID: 2246 RVA: 0x00038B98 File Offset: 0x00036D98
		private void AddDualTextBlockControlToShootGBPanel()
		{
			this.mShootXDTB = new DualTextBlockControl(this.ParentWindow);
			this.mShootXDTB.Margin = new Thickness(0.0, 5.0, 0.0, 0.0);
			this.mShootYDTB = new DualTextBlockControl(this.ParentWindow);
			this.mShootYDTB.Margin = new Thickness(0.0, 5.0, 0.0, 0.0);
			this.mShootDTB = new DualTextBlockControl(this.ParentWindow);
			this.mShootDTB.Margin = new Thickness(0.0, 5.0, 0.0, 0.0);
			this.mShootGBPanel.Children.Add(this.mShootXDTB);
			this.mShootGBPanel.Children.Add(this.mShootYDTB);
			this.mShootGBPanel.Children.Add(this.mShootDTB);
		}

		// Token: 0x060008C7 RID: 2247 RVA: 0x00038CBC File Offset: 0x00036EBC
		private void AddDualTextBlockControlToLookAroundPanel()
		{
			this.mLookAroundXDTB = new DualTextBlockControl(this.ParentWindow);
			this.mLookAroundXDTB.Margin = new Thickness(0.0, 5.0, 0.0, 0.0);
			this.mLookAroundYDTB = new DualTextBlockControl(this.ParentWindow);
			this.mLookAroundYDTB.Margin = new Thickness(0.0, 5.0, 0.0, 0.0);
			this.mLookAroundDTB = new DualTextBlockControl(this.ParentWindow);
			this.mLookAroundDTB.Margin = new Thickness(0.0, 5.0, 0.0, 0.0);
			this.mLookAroundPanel.Children.Add(this.mLookAroundXDTB);
			this.mLookAroundPanel.Children.Add(this.mLookAroundYDTB);
			this.mLookAroundPanel.Children.Add(this.mLookAroundDTB);
		}

		// Token: 0x060008C8 RID: 2248 RVA: 0x00038DE0 File Offset: 0x00036FE0
		private void AddDualTextBlockControlToMOBAPanel()
		{
			this.mMOBADpadOriginXDTB = new DualTextBlockControl(this.ParentWindow);
			this.mMOBADpadOriginXDTB.Margin = new Thickness(0.0, 5.0, 0.0, 0.0);
			this.mMOBADpadOriginYDTB = new DualTextBlockControl(this.ParentWindow);
			this.mMOBADpadOriginYDTB.Margin = new Thickness(0.0, 5.0, 0.0, 0.0);
			this.mMOBADpadCharSpeedDTB = new DualTextBlockControl(this.ParentWindow);
			this.mMOBADpadCharSpeedDTB.Margin = new Thickness(0.0, 5.0, 0.0, 0.0);
			this.mMOBAPanel.Children.Add(this.mMOBADpadOriginXDTB);
			this.mMOBAPanel.Children.Add(this.mMOBADpadOriginYDTB);
			this.mMOBAPanel.Children.Add(this.mMOBADpadCharSpeedDTB);
		}

		// Token: 0x060008C9 RID: 2249 RVA: 0x00038F04 File Offset: 0x00037104
		private void AddGuidanceCategories()
		{
			this.mListSuggestions.Clear();
			string item = string.Empty;
			foreach (IMAction imaction in this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls)
			{
				if (imaction.GuidanceCategory.Equals("MISC"))
				{
					item = LocaleStrings.GetLocalizedString("STRING_" + imaction.GuidanceCategory, false);
				}
				else
				{
					item = this.ParentWindow.SelectedConfig.GetUIString(imaction.GuidanceCategory);
				}
				if (!this.mListSuggestions.Contains(item))
				{
					this.mListSuggestions.Add(item);
				}
			}
		}

		// Token: 0x060008CA RID: 2250 RVA: 0x0000790E File Offset: 0x00005B0E
		private void AddListOfSuggestions()
		{
			this.mGuidanceCategoryComboBox.AddSuggestions(this.mListSuggestions);
		}

		// Token: 0x060008CB RID: 2251 RVA: 0x00007921 File Offset: 0x00005B21
		private void CloseButton_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			base.IsOpen = false;
		}

		// Token: 0x060008CC RID: 2252 RVA: 0x00038FCC File Offset: 0x000371CC
		private void DeleteButton_Click(object sender, RoutedEventArgs e)
		{
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
			}
			KeymapCanvasWindow.sIsDirty = true;
			foreach (IMAction item in this.mLstAction)
			{
				this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Remove(item);
			}
			(this.mCanvasElement.Parent as Canvas).Children.Remove(this.mCanvasElement);
			base.IsOpen = false;
			foreach (KeyValuePair<IMAction, CanvasElement> keyValuePair in KMManager.CanvasWindow.dictCanvasElement)
			{
				if (keyValuePair.Key.ParentAction == this.mLstAction.First<IMAction>())
				{
					keyValuePair.Value.RemoveAction();
					this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Remove(keyValuePair.Value.lstActionItem.First<IMAction>());
				}
			}
		}

		// Token: 0x060008CD RID: 2253 RVA: 0x00039120 File Offset: 0x00037320
		private void SetPopupDraggableProperty()
		{
			try
			{
				Thumb thumb = new Thumb
				{
					Width = 0.0,
					Height = 0.0
				};
				this.mHeaderGrid.Children.Add(thumb);
				this.mHeaderGrid.MouseDown += delegate(object sender, MouseButtonEventArgs e)
				{
					thumb.RaiseEvent(e);
				};
				thumb.DragDelta += delegate(object sender, DragDeltaEventArgs e)
				{
					base.HorizontalOffset += e.HorizontalChange;
					base.VerticalOffset += e.VerticalChange;
				};
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in draggable popup: " + ex.ToString());
			}
		}

		// Token: 0x060008CE RID: 2254 RVA: 0x000391CC File Offset: 0x000373CC
		internal void Init(bool isGamepadTabSelected = false)
		{
			bool sIsDirty = KeymapCanvasWindow.sIsDirty;
			this.mDictGroupBox.Clear();
			this.mDummyGrid.Children.Clear();
			this.mStackPanel.Children.Clear();
			this.mDictDualTextBox.Clear();
			BlueStacksUIBinding.Bind(this.mHeader, Constants.ImapLocaleStringsConstant + this.mLstAction.First<IMAction>().Type + "_Settings", "");
			if (KMManager.sIsDeveloperModeOn)
			{
				this.mEnableConditionTB.Visibility = Visibility.Visible;
				this.mEnableConditionGB.Visibility = Visibility.Visible;
				this.mEnableConditionTB.ActionItemProperty = "EnableCondition";
			}
			this.AddListOfSuggestions();
			this.mStackPanel.Children.Add(this.mGuidanceCategory);
			this.mStackPanel.Children.Add(this.mTabsGrid);
			if (isGamepadTabSelected)
			{
				this.mKeyboardTabBorder.BorderThickness = new Thickness(1.0, 1.0, 0.0, 1.0);
				this.mKeyboardTabBorder.Background = Brushes.Transparent;
				BlueStacksUIBinding.BindColor(this.mKeyboardTabBorder, Border.BorderBrushProperty, "GuidanceKeyBorderBackgroundColor");
				BlueStacksUIBinding.BindColor(this.mGamepadTabBorder, Border.BackgroundProperty, "GuidanceKeyBorderBackgroundColor");
				this.mGamepadTabBorder.BorderThickness = new Thickness(0.0);
			}
			else
			{
				this.mGamepadTabBorder.BorderThickness = new Thickness(0.0, 1.0, 1.0, 1.0);
				this.mGamepadTabBorder.Background = Brushes.Transparent;
				BlueStacksUIBinding.BindColor(this.mKeyboardTabBorder, Border.BackgroundProperty, "GuidanceKeyBorderBackgroundColor");
				this.mKeyboardTabBorder.BorderThickness = new Thickness(0.0);
			}
			foreach (IMAction imaction in this.mLstAction)
			{
				if (imaction.GuidanceCategory.Equals("MISC"))
				{
					this.mGuidanceCategoryComboBox.mAutoComboBox.Text = LocaleStrings.GetLocalizedString("STRING_" + imaction.GuidanceCategory, false);
				}
				else
				{
					this.mGuidanceCategoryComboBox.mAutoComboBox.Text = this.ParentWindow.SelectedConfig.GetUIString(imaction.GuidanceCategory);
				}
				if (KMManager.sIsDeveloperModeOn)
				{
					this.mEnableConditionGB.Visibility = Visibility.Visible;
					this.mEnableConditionTB.Visibility = Visibility.Visible;
					this.mEnableConditionTB.AddActionItem(imaction);
				}
				else
				{
					this.mEnableConditionGB.Visibility = Visibility.Collapsed;
				}
				foreach (KeyValuePair<string, PropertyInfo> item in IMAction.DictPopUpUIElements[imaction.Type])
				{
					if (item.Key.Equals("IsMOBADpadEnabled"))
					{
						this.mStackPanel.Children.Add(this.mMOBAGB);
						this.mMOBACB.IsChecked = new bool?(Convert.ToBoolean(imaction[item.Key]));
						this.mMOBADpadCharSpeedDTB.IsEnabled = this.mMOBACB.IsChecked.Value;
						this.mMOBADpadCharSpeedDTB.mKeyPropertyNameTextBox.IsEnabled = false;
						this.mMOBADpadCharSpeedDTB.ActionItemProperty = "CharSpeed";
						this.mMOBADpadCharSpeedDTB.AddActionItem((imaction as Dpad).mMOBADpad);
						this.mMOBADpadOriginXDTB.IsEnabled = this.mMOBACB.IsChecked.Value;
						this.mMOBADpadOriginXDTB.mKeyPropertyNameTextBox.IsEnabled = false;
						this.mMOBADpadOriginXDTB.ActionItemProperty = "OriginX";
						this.mMOBADpadOriginXDTB.AddActionItem((imaction as Dpad).mMOBADpad);
						this.mMOBADpadOriginYDTB.IsEnabled = this.mMOBACB.IsChecked.Value;
						this.mMOBADpadOriginYDTB.mKeyPropertyNameTextBox.IsEnabled = false;
						this.mMOBADpadOriginYDTB.ActionItemProperty = "OriginY";
						this.mMOBADpadOriginYDTB.AddActionItem((imaction as Dpad).mMOBADpad);
					}
					else if (item.Key.Equals("IsCancelSkillEnabled"))
					{
						this.mStackPanel.Children.Add(this.mMOBASkillCancelGB);
						this.mMOBASkillCancelCB.IsChecked = new bool?(Convert.ToBoolean(imaction[item.Key]));
						this.mMOBASkillCancelDTB.IsEnabled = this.mMOBASkillCancelCB.IsChecked.Value;
						this.mMOBASkillCancelDTB.ActionItemProperty = "KeyCancel";
						this.mMOBASkillCancelDTB.AddActionItem(imaction);
					}
					else if (item.Key.Equals("IsLookAroundEnabled"))
					{
						this.mStackPanel.Children.Add(this.mLookAroundGB);
						this.mLookAroundCB.IsChecked = new bool?(Convert.ToBoolean(imaction[item.Key]));
						this.mLookAroundDTB.IsEnabled = this.mLookAroundCB.IsChecked.Value;
						this.mLookAroundDTB.ActionItemProperty = "KeyLookAround";
						this.mLookAroundDTB.AddActionItem(imaction);
						this.mLookAroundXDTB.IsEnabled = this.mLookAroundCB.IsChecked.Value;
						this.mLookAroundXDTB.mKeyPropertyNameTextBox.IsEnabled = false;
						this.mLookAroundXDTB.ActionItemProperty = "LookAroundX";
						this.mLookAroundXDTB.AddActionItem(imaction);
						this.mLookAroundYDTB.IsEnabled = this.mLookAroundCB.IsChecked.Value;
						this.mLookAroundYDTB.mKeyPropertyNameTextBox.IsEnabled = false;
						this.mLookAroundYDTB.ActionItemProperty = "LookAroundY";
						this.mLookAroundYDTB.AddActionItem(imaction);
					}
					else if (item.Key.Equals("IsShootOnClickEnabled"))
					{
						this.mStackPanel.Children.Add(this.mShootGB);
						this.mShootCB.IsChecked = new bool?(Convert.ToBoolean(imaction[item.Key]));
						this.mShootDTB.IsEnabled = this.mShootCB.IsChecked.Value;
						this.mShootDTB.mKeyTextBox.IsEnabled = false;
						this.mShootDTB.ActionItemProperty = "KeyAction";
						this.mShootDTB.AddActionItem(imaction);
						this.mShootXDTB.IsEnabled = this.mShootCB.IsChecked.Value;
						this.mShootXDTB.mKeyPropertyNameTextBox.IsEnabled = false;
						this.mShootXDTB.ActionItemProperty = "LButtonX";
						this.mShootXDTB.AddActionItem(imaction);
						this.mShootYDTB.IsEnabled = this.mShootCB.IsChecked.Value;
						this.mShootYDTB.mKeyPropertyNameTextBox.IsEnabled = false;
						this.mShootYDTB.ActionItemProperty = "LButtonY";
						this.mShootYDTB.AddActionItem(imaction);
					}
					else if (item.Key.Equals("ShowOnOverlay"))
					{
						this.mOverlayCB.IsChecked = new bool?(Convert.ToBoolean(imaction[item.Key]));
						this.mOverlayCB.Tag = item.Key;
						if (!this.mStackPanel.Children.Contains(this.mOverlayGB))
						{
							this.mStackPanel.Children.Add(this.mOverlayGB);
						}
					}
					else if (imaction.Type == KeyActionType.FreeLook && (item.Key.Equals("Sensitivity") || item.Key.Equals("Speed") || item.Key.Equals("MouseAcceleration")))
					{
						if (((FreeLook)imaction).DeviceType == 0)
						{
							if (item.Key.Equals("Speed"))
							{
								this.AddFields(item, imaction, isGamepadTabSelected);
							}
						}
						else if (item.Key.Equals("Sensitivity") || item.Key.Equals("MouseAcceleration"))
						{
							this.AddFields(item, imaction, isGamepadTabSelected);
						}
					}
					else if (isGamepadTabSelected)
					{
						if (item.Key.ToString().EndsWith("_alt1") || !item.Key.ToString().StartsWith("Key"))
						{
							this.AddFields(item, imaction, isGamepadTabSelected);
						}
					}
					else if (!item.Key.ToString().EndsWith("_alt1"))
					{
						this.AddFields(item, imaction, isGamepadTabSelected);
					}
				}
				if (KMManager.sIsDeveloperModeOn && imaction.Type == KeyActionType.MOBASkill)
				{
					foreach (KeyValuePair<string, PropertyInfo> item2 in IMAction.sDictDevModeUIElements[imaction.Type])
					{
						if (isGamepadTabSelected)
						{
							if (item2.Key.ToString().EndsWith("_alt1") || !item2.Key.ToString().StartsWith("Key"))
							{
								this.AddFields(item2, imaction, isGamepadTabSelected);
							}
						}
						else if (!item2.Key.ToString().EndsWith("_alt1"))
						{
							this.AddFields(item2, imaction, isGamepadTabSelected);
						}
					}
				}
			}
			if (KMManager.sIsDeveloperModeOn)
			{
				this.mStackPanel.Children.Add(this.mEnableConditionGB);
			}
			this.UpdateFieldsForMOBADpad();
			KeymapCanvasWindow.sIsDirty = sIsDirty;
		}

		// Token: 0x060008CF RID: 2255 RVA: 0x00039BB8 File Offset: 0x00037DB8
		private void AddFields(KeyValuePair<string, PropertyInfo> item, IMAction action, bool isGamepadTabSelected = false)
		{
			bool isAddDirectionAttribute = false;
			object[] customAttributes = item.Value.GetCustomAttributes(typeof(CategoryAttribute), true);
			CategoryAttribute categoryAttribute = customAttributes[0] as CategoryAttribute;
			string category = categoryAttribute.Category;
			string text = categoryAttribute.Category + "~" + item.Key;
			customAttributes = item.Value.GetCustomAttributes(typeof(DescriptionAttribute), true);
			if (customAttributes.Length != 0 && (customAttributes[0] as DescriptionAttribute).Description.Contains("NotCommon"))
			{
				text = text + "~" + action.Direction;
				isAddDirectionAttribute = true;
			}
			GroupBox groupBox = this.GetGroupBox(category);
			if (this.mDictDualTextBox.ContainsKey(text))
			{
				this.mDictDualTextBox[text].AddActionItem(action);
				return;
			}
			DualTextBlockControl dualTextBlockControl = new DualTextBlockControl(this.ParentWindow);
			dualTextBlockControl.IsAddDirectionAttribute = isAddDirectionAttribute;
			dualTextBlockControl.ActionItemProperty = item.Key;
			dualTextBlockControl.AddActionItem(action);
			if (item.Key.Equals("GuidanceCategory"))
			{
				dualTextBlockControl.mKeyPropertyNameTextBox.IsEnabled = false;
				this.mStackPanel.Children.Remove(groupBox);
				this.mStackPanel.Children.Insert(0, groupBox);
			}
			(groupBox.Content as StackPanel).Children.Add(dualTextBlockControl);
			this.mDictDualTextBox[text] = dualTextBlockControl;
		}

		// Token: 0x060008D0 RID: 2256 RVA: 0x00039D18 File Offset: 0x00037F18
		private GroupBox GetGroupBox(string category)
		{
			GroupBox groupBox;
			if (this.mDictGroupBox.ContainsKey(category))
			{
				groupBox = this.mDictGroupBox[category];
			}
			else
			{
				groupBox = new GroupBox();
				this.mDictGroupBox.Add(category, groupBox);
				groupBox.Header = LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + category, false);
				this.mStackPanel.Children.Add(groupBox);
				groupBox.Content = new StackPanel();
			}
			return groupBox;
		}

		// Token: 0x060008D1 RID: 2257 RVA: 0x00007506 File Offset: 0x00005706
		private void CustomPictureBox_MouseEnter(object sender, MouseEventArgs e)
		{
			base.Cursor = Cursors.Hand;
		}

		// Token: 0x060008D2 RID: 2258 RVA: 0x0000792A File Offset: 0x00005B2A
		private void CustomPictureBox_MouseLeave(object sender, MouseEventArgs e)
		{
			if (KMManager.CanvasWindow.mCanvasElement == null)
			{
				base.Cursor = Cursors.Arrow;
			}
		}

		// Token: 0x060008D3 RID: 2259 RVA: 0x00039D8C File Offset: 0x00037F8C
		private void MOBAHeroCB_CheckedChanged(object sender, RoutedEventArgs e)
		{
			if (this.mLstAction != null)
			{
				if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
				{
					KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
				}
				this.mMOBADpadCharSpeedDTB.IsEnabled = this.mMOBACB.IsChecked.Value;
				this.mMOBADpadOriginXDTB.IsEnabled = this.mMOBACB.IsChecked.Value;
				this.mMOBADpadOriginYDTB.IsEnabled = this.mMOBACB.IsChecked.Value;
				Dpad dpad = this.mLstAction.First<IMAction>() as Dpad;
				if (this.mMOBACB.IsChecked.Value)
				{
					dpad.mMOBADpad.mDpad = dpad;
					dpad.mMOBADpad.ParentAction = dpad;
				}
				else if (dpad.IsMOBADpadEnabled)
				{
					MOBADpad.sListMOBADpad.Remove(dpad.mMOBADpad);
					if (KMManager.CanvasWindow.dictCanvasElement.ContainsKey(dpad.mMOBADpad))
					{
						KMManager.CanvasWindow.dictCanvasElement[dpad.mMOBADpad].RemoveAction();
						KMManager.CanvasWindow.dictCanvasElement.Remove(dpad.mMOBADpad);
					}
					this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Remove(dpad.mMOBADpad);
					dpad.mMOBADpad.OriginX = (dpad.mMOBADpad.OriginY = -1.0);
				}
				this.UpdateFieldsForMOBADpad();
				KeymapCanvasWindow.sIsDirty = true;
			}
			if (this.mMOBAPB != null)
			{
				this.mMOBAPB.IsEnabled = this.mMOBACB.IsChecked.Value;
			}
		}

		// Token: 0x060008D4 RID: 2260 RVA: 0x00039F48 File Offset: 0x00038148
		private void MOBAHeroPictureBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
			}
			base.IsOpen = false;
			Dpad dpad = this.mLstAction.First<IMAction>() as Dpad;
			if (KMManager.CanvasWindow.dictCanvasElement.ContainsKey(dpad.mMOBADpad))
			{
				CanvasElement element = KMManager.CanvasWindow.dictCanvasElement[dpad.mMOBADpad];
				KMManager.CanvasWindow.StartMoving(element, new Point(Canvas.GetLeft(element), Canvas.GetTop(element)));
				return;
			}
			dpad.mMOBADpad.X = dpad.X;
			dpad.mMOBADpad.Y = dpad.Y;
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
			}
			this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Add(dpad.mMOBADpad);
			this.AddUIInCanvas(dpad.mMOBADpad);
		}

		// Token: 0x060008D5 RID: 2261 RVA: 0x0003A060 File Offset: 0x00038260
		private void UpdateFieldsForMOBADpad()
		{
			if (this.mLstAction.First<IMAction>().Type == KeyActionType.Dpad && this.mMOBACB.IsChecked != null)
			{
				foreach (KeyValuePair<string, DualTextBlockControl> keyValuePair in this.mDictDualTextBox)
				{
					if (keyValuePair.Key.Contains("~Key"))
					{
						keyValuePair.Value.mKeyTextBox.IsEnabled = !this.mMOBACB.IsChecked.Value;
						keyValuePair.Value.mKeyPropertyNameTextBox.IsEnabled = !this.mMOBACB.IsChecked.Value;
						if (!keyValuePair.Value.mKeyTextBox.IsEnabled)
						{
							keyValuePair.Value.mKeyPropertyNameTextBox.Text = string.Empty;
							keyValuePair.Value.mKeyTextBox.Tag = string.Empty;
							keyValuePair.Value.mKeyTextBox.Text = string.Empty;
						}
					}
				}
			}
		}

		// Token: 0x060008D6 RID: 2262 RVA: 0x0003A19C File Offset: 0x0003839C
		private void MOBASkillCancelCB_CheckedChanged(object sender, RoutedEventArgs e)
		{
			if (this.mLstAction != null)
			{
				if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
				{
					KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
				}
				this.mMOBASkillCancelDTB.IsEnabled = this.mMOBASkillCancelCB.IsChecked.Value;
				MOBASkill mobaskill = this.mLstAction.First<IMAction>() as MOBASkill;
				if (this.mMOBASkillCancelCB.IsChecked.Value)
				{
					mobaskill.mMOBASkillCancel = new MOBASkillCancel(mobaskill);
				}
				else if (mobaskill.IsCancelSkillEnabled)
				{
					if (KMManager.CanvasWindow.dictCanvasElement.ContainsKey(mobaskill.mMOBASkillCancel))
					{
						KMManager.CanvasWindow.dictCanvasElement[mobaskill.mMOBASkillCancel].RemoveAction();
						KMManager.CanvasWindow.dictCanvasElement.Remove(mobaskill.mMOBASkillCancel);
					}
					mobaskill.CancelX = (mobaskill.CancelY = -1.0);
				}
				KeymapCanvasWindow.sIsDirty = true;
			}
			if (this.mMOBASkillCancelPB != null)
			{
				this.mMOBASkillCancelPB.IsEnabled = this.mMOBASkillCancelCB.IsChecked.Value;
			}
		}

		// Token: 0x060008D7 RID: 2263 RVA: 0x0003A2C8 File Offset: 0x000384C8
		private void MOBASkillCancelPictureBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
			}
			base.IsOpen = false;
			MOBASkill mobaskill = this.mLstAction.First<IMAction>() as MOBASkill;
			if (KMManager.CanvasWindow.dictCanvasElement.ContainsKey(mobaskill.mMOBASkillCancel))
			{
				CanvasElement element = KMManager.CanvasWindow.dictCanvasElement[mobaskill.mMOBASkillCancel];
				KMManager.CanvasWindow.StartMoving(element, new Point(Canvas.GetLeft(element), Canvas.GetTop(element)));
				return;
			}
			this.AddUIInCanvas(mobaskill.mMOBASkillCancel);
		}

		// Token: 0x060008D8 RID: 2264 RVA: 0x0003A370 File Offset: 0x00038570
		private void LookAroundCB_CheckedChanged(object sender, RoutedEventArgs e)
		{
			if (this.mLstAction != null)
			{
				if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
				{
					KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
				}
				this.mLookAroundXDTB.IsEnabled = this.mLookAroundCB.IsChecked.Value;
				this.mLookAroundYDTB.IsEnabled = this.mLookAroundCB.IsChecked.Value;
				this.mLookAroundDTB.IsEnabled = this.mLookAroundCB.IsChecked.Value;
				Pan pan = this.mLstAction.First<IMAction>() as Pan;
				if (this.mLookAroundCB.IsChecked.Value)
				{
					pan.mLookAround = new LookAround(pan);
				}
				else if (pan.IsLookAroundEnabled)
				{
					if (KMManager.CanvasWindow.dictCanvasElement.ContainsKey(pan.mLookAround))
					{
						KMManager.CanvasWindow.dictCanvasElement[pan.mLookAround].RemoveAction();
						KMManager.CanvasWindow.dictCanvasElement.Remove(pan.mLookAround);
					}
					pan.LookAroundX = (pan.LookAroundY = -1.0);
				}
				KeymapCanvasWindow.sIsDirty = true;
			}
			if (this.mLookAroundPB != null)
			{
				this.mLookAroundPB.IsEnabled = this.mLookAroundCB.IsChecked.Value;
			}
		}

		// Token: 0x060008D9 RID: 2265 RVA: 0x0003A4D8 File Offset: 0x000386D8
		private void LookAroundPictureBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
			}
			base.IsOpen = false;
			Pan pan = this.mLstAction.First<IMAction>() as Pan;
			if (KMManager.CanvasWindow.dictCanvasElement.ContainsKey(pan.mLookAround))
			{
				CanvasElement element = KMManager.CanvasWindow.dictCanvasElement[pan.mLookAround];
				KMManager.CanvasWindow.StartMoving(element, new Point(Canvas.GetLeft(element), Canvas.GetTop(element)));
				return;
			}
			this.AddUIInCanvas(pan.mLookAround);
		}

		// Token: 0x060008DA RID: 2266 RVA: 0x0003A580 File Offset: 0x00038780
		private void ShootCB_CheckedChanged(object sender, RoutedEventArgs e)
		{
			if (this.mLstAction != null)
			{
				if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
				{
					KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
				}
				this.mShootXDTB.IsEnabled = this.mShootCB.IsChecked.Value;
				this.mShootYDTB.IsEnabled = this.mShootCB.IsChecked.Value;
				this.mShootDTB.IsEnabled = this.mShootCB.IsChecked.Value;
				Pan pan = this.mLstAction.First<IMAction>() as Pan;
				if (this.mShootCB.IsChecked.Value)
				{
					pan.mPanShoot = new PanShoot(pan);
				}
				else if (pan.IsShootOnClickEnabled)
				{
					if (KMManager.CanvasWindow.dictCanvasElement.ContainsKey(pan.mPanShoot))
					{
						KMManager.CanvasWindow.dictCanvasElement[pan.mPanShoot].RemoveAction();
						KMManager.CanvasWindow.dictCanvasElement.Remove(pan.mPanShoot);
					}
					pan.LButtonX = (pan.LButtonY = -1.0);
				}
				KeymapCanvasWindow.sIsDirty = true;
			}
			if (this.mShootPB != null)
			{
				this.mShootPB.IsEnabled = this.mShootCB.IsChecked.Value;
			}
		}

		// Token: 0x060008DB RID: 2267 RVA: 0x0003A6E8 File Offset: 0x000388E8
		private void ShootPictureBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
			}
			base.IsOpen = false;
			Pan pan = this.mLstAction.First<IMAction>() as Pan;
			if (KMManager.CanvasWindow.dictCanvasElement.ContainsKey(pan.mPanShoot))
			{
				CanvasElement element = KMManager.CanvasWindow.dictCanvasElement[pan.mPanShoot];
				KMManager.CanvasWindow.StartMoving(element, new Point(Canvas.GetLeft(element), Canvas.GetTop(element)));
				return;
			}
			this.AddUIInCanvas(pan.mPanShoot);
		}

		// Token: 0x060008DC RID: 2268 RVA: 0x0003A790 File Offset: 0x00038990
		private void mOverlayCB_Checked(object sender, RoutedEventArgs e)
		{
			if (this.mLstAction != null)
			{
				if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
				{
					KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
				}
				foreach (IMAction imaction in this.mLstAction)
				{
					imaction.IsVisibleInOverlay = true;
				}
				KeymapCanvasWindow.sIsDirty = true;
			}
		}

		// Token: 0x060008DD RID: 2269 RVA: 0x0003A81C File Offset: 0x00038A1C
		private void mOverlayCB_Unchecked(object sender, RoutedEventArgs e)
		{
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
			}
			if (this.mLstAction != null)
			{
				foreach (IMAction imaction in this.mLstAction)
				{
					imaction.IsVisibleInOverlay = false;
				}
			}
			KeymapCanvasWindow.sIsDirty = true;
		}

		// Token: 0x060008DE RID: 2270 RVA: 0x00007943 File Offset: 0x00005B43
		private void AddUIInCanvas(IMAction hero)
		{
			base.Cursor = Cursors.Hand;
			KMManager.GetCanvasElement(hero, this.mCanvas, true);
		}

		// Token: 0x060008DF RID: 2271 RVA: 0x00007453 File Offset: 0x00005653
		private void mCanvas_PreviewMouseMove(object sender, MouseEventArgs e)
		{
			KMManager.RepositionCanvasElement();
		}

		// Token: 0x060008E0 RID: 2272 RVA: 0x0000745A File Offset: 0x0000565A
		private void mCanvas_MouseUp(object sender, MouseButtonEventArgs e)
		{
			base.Cursor = Cursors.Arrow;
			KMManager.ClearElement();
		}

		// Token: 0x060008E1 RID: 2273 RVA: 0x0003A8A8 File Offset: 0x00038AA8
		private void mGamepadTabBorder_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			try
			{
				if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
				{
					KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
				}
				foreach (IMAction imaction in this.mLstAction)
				{
					if (!imaction.GuidanceCategory.Equals(this.mGuidanceCategoryComboBox.mAutoComboBox.Text))
					{
						imaction.GuidanceCategory = this.mGuidanceCategoryComboBox.mAutoComboBox.Text;
						KeymapCanvasWindow.sIsDirty = true;
						this.ParentWindow.SelectedConfig.AddString(imaction.GuidanceCategory);
					}
				}
				this.mGamepadTabBorder.BorderThickness = new Thickness(0.0, 1.0, 1.0, 1.0);
				this.mGamepadTabBorder.Background = Brushes.Transparent;
				BlueStacksUIBinding.BindColor(this.mGamepadTabBorder, Border.BorderBrushProperty, "GuidanceKeyBorderBackgroundColor");
				BlueStacksUIBinding.BindColor(this.mKeyboardTabBorder, Border.BackgroundProperty, "GuidanceKeyBorderBackgroundColor");
				this.mKeyboardTabBorder.BorderThickness = new Thickness(0.0);
				this.AddGuidanceCategories();
				this.Init(true);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in switching to Gamepad tab: " + ex.ToString());
			}
		}

		// Token: 0x060008E2 RID: 2274 RVA: 0x0003AA44 File Offset: 0x00038C44
		private void mKeyboardTabBorder_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			try
			{
				if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
				{
					KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
				}
				foreach (IMAction imaction in this.mLstAction)
				{
					if (!imaction.GuidanceCategory.Equals(this.mGuidanceCategoryComboBox.mAutoComboBox.Text))
					{
						imaction.GuidanceCategory = this.mGuidanceCategoryComboBox.mAutoComboBox.Text;
						KeymapCanvasWindow.sIsDirty = true;
						this.ParentWindow.SelectedConfig.AddString(imaction.GuidanceCategory);
					}
				}
				this.AddGuidanceCategories();
				this.mKeyboardTabBorder.BorderThickness = new Thickness(1.0, 1.0, 0.0, 1.0);
				this.mKeyboardTabBorder.Background = Brushes.Transparent;
				BlueStacksUIBinding.BindColor(this.mGamepadTabBorder, Border.BackgroundProperty, "GuidanceKeyBorderBackgroundColor");
				this.mGamepadTabBorder.BorderThickness = new Thickness(0.0);
				this.Init(false);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in switching to Keyboard tab: " + ex.ToString());
			}
		}

		// Token: 0x060008E3 RID: 2275 RVA: 0x0003ABC8 File Offset: 0x00038DC8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/keymapextrasettingwindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060008E4 RID: 2276 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060008E5 RID: 2277 RVA: 0x0003ABF8 File Offset: 0x00038DF8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mHeaderGrid = (Grid)target;
				return;
			case 2:
				this.mHeader = (TextBlock)target;
				return;
			case 3:
				((CustomPictureBox)target).PreviewMouseLeftButtonDown += this.CloseButton_MouseLeftButtonDown;
				return;
			case 4:
				this.mScrollBar = (CustomScrollViewer)target;
				return;
			case 5:
				this.mDeleteButton = (CustomButton)target;
				this.mDeleteButton.Click += this.DeleteButton_Click;
				return;
			case 6:
				this.mDummyGrid = (Grid)target;
				return;
			case 7:
				this.mMOBAGB = (GroupBox)target;
				return;
			case 8:
				this.mMOBAPanel = (StackPanel)target;
				return;
			case 9:
				this.mMOBACB = (CustomCheckbox)target;
				this.mMOBACB.Checked += this.MOBAHeroCB_CheckedChanged;
				this.mMOBACB.Unchecked += this.MOBAHeroCB_CheckedChanged;
				return;
			case 10:
				this.mMOBAPB = (CustomPictureBox)target;
				this.mMOBAPB.MouseEnter += this.CustomPictureBox_MouseEnter;
				this.mMOBAPB.MouseLeave += this.CustomPictureBox_MouseLeave;
				this.mMOBAPB.MouseDown += this.MOBAHeroPictureBox_MouseDown;
				return;
			case 11:
				this.mGuidanceCategory = (GroupBox)target;
				return;
			case 12:
				this.mGuidanceCategoryComboBox = (AutoCompleteComboBox)target;
				return;
			case 13:
				this.mTabsGrid = (GroupBox)target;
				return;
			case 14:
				this.mKeyboardTabBorder = (Border)target;
				this.mKeyboardTabBorder.MouseLeftButtonUp += this.mKeyboardTabBorder_MouseLeftButtonUp;
				return;
			case 15:
				this.keyboardBtn = (TextBlock)target;
				return;
			case 16:
				this.mGamepadTabBorder = (Border)target;
				this.mGamepadTabBorder.MouseLeftButtonUp += this.mGamepadTabBorder_MouseLeftButtonUp;
				return;
			case 17:
				this.gamepadBtn = (TextBlock)target;
				return;
			case 18:
				this.mMOBASkillCancelGB = (GroupBox)target;
				return;
			case 19:
				this.mMOBASkillCancelGBPanel = (StackPanel)target;
				return;
			case 20:
				this.mMOBASkillCancelCB = (CustomCheckbox)target;
				this.mMOBASkillCancelCB.Checked += this.MOBASkillCancelCB_CheckedChanged;
				this.mMOBASkillCancelCB.Unchecked += this.MOBASkillCancelCB_CheckedChanged;
				return;
			case 21:
				this.mMOBASkillCancelPB = (CustomPictureBox)target;
				this.mMOBASkillCancelPB.MouseEnter += this.CustomPictureBox_MouseEnter;
				this.mMOBASkillCancelPB.MouseLeave += this.CustomPictureBox_MouseLeave;
				this.mMOBASkillCancelPB.MouseDown += this.MOBASkillCancelPictureBox_MouseDown;
				return;
			case 22:
				this.mLookAroundGB = (GroupBox)target;
				return;
			case 23:
				this.mLookAroundPanel = (StackPanel)target;
				return;
			case 24:
				this.mLookAroundCB = (CustomCheckbox)target;
				this.mLookAroundCB.Checked += this.LookAroundCB_CheckedChanged;
				this.mLookAroundCB.Unchecked += this.LookAroundCB_CheckedChanged;
				return;
			case 25:
				this.mLookAroundPB = (CustomPictureBox)target;
				this.mLookAroundPB.MouseEnter += this.CustomPictureBox_MouseEnter;
				this.mLookAroundPB.MouseLeave += this.CustomPictureBox_MouseLeave;
				this.mLookAroundPB.MouseDown += this.LookAroundPictureBox_MouseDown;
				return;
			case 26:
				this.mShootGB = (GroupBox)target;
				return;
			case 27:
				this.mShootGBPanel = (StackPanel)target;
				return;
			case 28:
				this.mShootCB = (CustomCheckbox)target;
				this.mShootCB.Checked += this.ShootCB_CheckedChanged;
				this.mShootCB.Unchecked += this.ShootCB_CheckedChanged;
				return;
			case 29:
				this.mShootPB = (CustomPictureBox)target;
				this.mShootPB.MouseEnter += this.CustomPictureBox_MouseEnter;
				this.mShootPB.MouseLeave += this.CustomPictureBox_MouseLeave;
				this.mShootPB.MouseDown += this.ShootPictureBox_MouseDown;
				return;
			case 30:
				this.mSchemesGB = (GroupBox)target;
				return;
			case 31:
				this.mEnableConditionGB = (GroupBox)target;
				return;
			case 32:
				this.mOverlayGB = (GroupBox)target;
				return;
			case 33:
				this.mOverlayCB = (CustomCheckbox)target;
				this.mOverlayCB.Checked += this.mOverlayCB_Checked;
				this.mOverlayCB.Unchecked += this.mOverlayCB_Unchecked;
				return;
			case 34:
				this.mCanvas = (Canvas)target;
				this.mCanvas.PreviewMouseMove += this.mCanvas_PreviewMouseMove;
				this.mCanvas.MouseUp += this.mCanvas_MouseUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000647 RID: 1607
		private Dictionary<string, GroupBox> mDictGroupBox = new Dictionary<string, GroupBox>();

		// Token: 0x04000648 RID: 1608
		private Dictionary<string, DualTextBlockControl> mDictDualTextBox = new Dictionary<string, DualTextBlockControl>();

		// Token: 0x04000649 RID: 1609
		public List<IMAction> mLstAction;

		// Token: 0x0400064A RID: 1610
		private List<string> mListSuggestions = new List<string>();

		// Token: 0x0400064B RID: 1611
		internal CanvasElement mCanvasElement;

		// Token: 0x0400064C RID: 1612
		private StackPanel mStackPanel;

		// Token: 0x0400064D RID: 1613
		private MainWindow ParentWindow;

		// Token: 0x0400064E RID: 1614
		private DualTextBlockControl mMOBADpadOriginXDTB;

		// Token: 0x0400064F RID: 1615
		private DualTextBlockControl mMOBADpadOriginYDTB;

		// Token: 0x04000650 RID: 1616
		private DualTextBlockControl mMOBADpadCharSpeedDTB;

		// Token: 0x04000651 RID: 1617
		private DualTextBlockControl mLookAroundXDTB;

		// Token: 0x04000652 RID: 1618
		private DualTextBlockControl mLookAroundYDTB;

		// Token: 0x04000653 RID: 1619
		private DualTextBlockControl mLookAroundDTB;

		// Token: 0x04000654 RID: 1620
		private DualTextBlockControl mShootXDTB;

		// Token: 0x04000655 RID: 1621
		private DualTextBlockControl mShootYDTB;

		// Token: 0x04000656 RID: 1622
		private DualTextBlockControl mShootDTB;

		// Token: 0x04000657 RID: 1623
		private DualTextBlockControl mMOBASkillCancelDTB;

		// Token: 0x04000658 RID: 1624
		private DualTextBlockControl mProfileTB;

		// Token: 0x04000659 RID: 1625
		private DualTextBlockControl mEnableConditionTB;

		// Token: 0x0400065A RID: 1626
		internal Grid mHeaderGrid;

		// Token: 0x0400065B RID: 1627
		internal TextBlock mHeader;

		// Token: 0x0400065C RID: 1628
		internal CustomScrollViewer mScrollBar;

		// Token: 0x0400065D RID: 1629
		internal CustomButton mDeleteButton;

		// Token: 0x0400065E RID: 1630
		internal Grid mDummyGrid;

		// Token: 0x0400065F RID: 1631
		internal GroupBox mMOBAGB;

		// Token: 0x04000660 RID: 1632
		internal StackPanel mMOBAPanel;

		// Token: 0x04000661 RID: 1633
		internal CustomCheckbox mMOBACB;

		// Token: 0x04000662 RID: 1634
		internal CustomPictureBox mMOBAPB;

		// Token: 0x04000663 RID: 1635
		internal GroupBox mGuidanceCategory;

		// Token: 0x04000664 RID: 1636
		internal AutoCompleteComboBox mGuidanceCategoryComboBox;

		// Token: 0x04000665 RID: 1637
		internal GroupBox mTabsGrid;

		// Token: 0x04000666 RID: 1638
		internal Border mKeyboardTabBorder;

		// Token: 0x04000667 RID: 1639
		internal TextBlock keyboardBtn;

		// Token: 0x04000668 RID: 1640
		internal Border mGamepadTabBorder;

		// Token: 0x04000669 RID: 1641
		internal TextBlock gamepadBtn;

		// Token: 0x0400066A RID: 1642
		internal GroupBox mMOBASkillCancelGB;

		// Token: 0x0400066B RID: 1643
		internal StackPanel mMOBASkillCancelGBPanel;

		// Token: 0x0400066C RID: 1644
		internal CustomCheckbox mMOBASkillCancelCB;

		// Token: 0x0400066D RID: 1645
		internal CustomPictureBox mMOBASkillCancelPB;

		// Token: 0x0400066E RID: 1646
		internal GroupBox mLookAroundGB;

		// Token: 0x0400066F RID: 1647
		internal StackPanel mLookAroundPanel;

		// Token: 0x04000670 RID: 1648
		internal CustomCheckbox mLookAroundCB;

		// Token: 0x04000671 RID: 1649
		internal CustomPictureBox mLookAroundPB;

		// Token: 0x04000672 RID: 1650
		internal GroupBox mShootGB;

		// Token: 0x04000673 RID: 1651
		internal StackPanel mShootGBPanel;

		// Token: 0x04000674 RID: 1652
		internal CustomCheckbox mShootCB;

		// Token: 0x04000675 RID: 1653
		internal CustomPictureBox mShootPB;

		// Token: 0x04000676 RID: 1654
		internal GroupBox mSchemesGB;

		// Token: 0x04000677 RID: 1655
		internal GroupBox mEnableConditionGB;

		// Token: 0x04000678 RID: 1656
		internal GroupBox mOverlayGB;

		// Token: 0x04000679 RID: 1657
		internal CustomCheckbox mOverlayCB;

		// Token: 0x0400067A RID: 1658
		internal Canvas mCanvas;

		// Token: 0x0400067B RID: 1659
		private bool _contentLoaded;
	}
}
