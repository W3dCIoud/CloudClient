﻿using System;
using System.Collections.Generic;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200003B RID: 59
	public class GenericNotificationDesignItem
	{
		// Token: 0x17000105 RID: 261
		// (get) Token: 0x06000302 RID: 770 RVA: 0x000040EC File Offset: 0x000022EC
		// (set) Token: 0x06000303 RID: 771 RVA: 0x000040F4 File Offset: 0x000022F4
		public double AutoHideTime
		{
			get
			{
				return this.mAutoHideTime;
			}
			set
			{
				this.mAutoHideTime = value;
			}
		}

		// Token: 0x17000106 RID: 262
		// (get) Token: 0x06000304 RID: 772 RVA: 0x000040FD File Offset: 0x000022FD
		// (set) Token: 0x06000305 RID: 773 RVA: 0x00004105 File Offset: 0x00002305
		public string LeftGifName
		{
			get
			{
				return this.mLeftGifName;
			}
			set
			{
				this.mLeftGifName = value;
			}
		}

		// Token: 0x17000107 RID: 263
		// (get) Token: 0x06000306 RID: 774 RVA: 0x0000410E File Offset: 0x0000230E
		// (set) Token: 0x06000307 RID: 775 RVA: 0x00004116 File Offset: 0x00002316
		public string LeftGifUrl
		{
			get
			{
				return this.mLeftGifUrl;
			}
			set
			{
				this.mLeftGifUrl = value;
			}
		}

		// Token: 0x17000108 RID: 264
		// (get) Token: 0x06000308 RID: 776 RVA: 0x0000411F File Offset: 0x0000231F
		// (set) Token: 0x06000309 RID: 777 RVA: 0x00004127 File Offset: 0x00002327
		public string TitleForeGroundColor
		{
			get
			{
				return this.mTitleForeGroundColor;
			}
			set
			{
				this.mTitleForeGroundColor = value;
			}
		}

		// Token: 0x17000109 RID: 265
		// (get) Token: 0x0600030A RID: 778 RVA: 0x00004130 File Offset: 0x00002330
		// (set) Token: 0x0600030B RID: 779 RVA: 0x00004138 File Offset: 0x00002338
		public string MessageForeGroundColor
		{
			get
			{
				return this.mMessageForeGroundColor;
			}
			set
			{
				this.mMessageForeGroundColor = value;
			}
		}

		// Token: 0x1700010A RID: 266
		// (get) Token: 0x0600030C RID: 780 RVA: 0x00004141 File Offset: 0x00002341
		// (set) Token: 0x0600030D RID: 781 RVA: 0x00004149 File Offset: 0x00002349
		public string BorderColor
		{
			get
			{
				return this.mBorderColor;
			}
			set
			{
				this.mBorderColor = value;
			}
		}

		// Token: 0x1700010B RID: 267
		// (get) Token: 0x0600030E RID: 782 RVA: 0x00004152 File Offset: 0x00002352
		// (set) Token: 0x0600030F RID: 783 RVA: 0x0000415A File Offset: 0x0000235A
		public string Ribboncolor
		{
			get
			{
				return this.mRibboncolor;
			}
			set
			{
				this.mRibboncolor = value;
			}
		}

		// Token: 0x1700010C RID: 268
		// (get) Token: 0x06000310 RID: 784 RVA: 0x00004163 File Offset: 0x00002363
		// (set) Token: 0x06000311 RID: 785 RVA: 0x0000416B File Offset: 0x0000236B
		public List<SerializableKeyValuePair<string, double>> BackgroundGradient
		{
			get
			{
				return this.mBackgroundGradient;
			}
			set
			{
				this.mBackgroundGradient = value;
			}
		}

		// Token: 0x1700010D RID: 269
		// (get) Token: 0x06000312 RID: 786 RVA: 0x00004174 File Offset: 0x00002374
		// (set) Token: 0x06000313 RID: 787 RVA: 0x0000417C File Offset: 0x0000237C
		public string HoverBorderColor
		{
			get
			{
				return this.mHoverBorderColor;
			}
			set
			{
				this.mHoverBorderColor = value;
			}
		}

		// Token: 0x1700010E RID: 270
		// (get) Token: 0x06000314 RID: 788 RVA: 0x00004185 File Offset: 0x00002385
		// (set) Token: 0x06000315 RID: 789 RVA: 0x0000418D File Offset: 0x0000238D
		public string HoverRibboncolor
		{
			get
			{
				return this.mHoverRibboncolor;
			}
			set
			{
				this.mHoverRibboncolor = value;
			}
		}

		// Token: 0x1700010F RID: 271
		// (get) Token: 0x06000316 RID: 790 RVA: 0x00004196 File Offset: 0x00002396
		// (set) Token: 0x06000317 RID: 791 RVA: 0x0000419E File Offset: 0x0000239E
		public List<SerializableKeyValuePair<string, double>> HoverBackGroundGradient
		{
			get
			{
				return this.mHoverBackGroundGradient;
			}
			set
			{
				this.mHoverBackGroundGradient = value;
			}
		}

		// Token: 0x0400019E RID: 414
		private string mTitleForeGroundColor;

		// Token: 0x0400019F RID: 415
		private string mMessageForeGroundColor;

		// Token: 0x040001A0 RID: 416
		private string mBorderColor;

		// Token: 0x040001A1 RID: 417
		private string mRibboncolor;

		// Token: 0x040001A2 RID: 418
		private string mHoverBorderColor;

		// Token: 0x040001A3 RID: 419
		private string mHoverRibboncolor;

		// Token: 0x040001A4 RID: 420
		private string mLeftGifName;

		// Token: 0x040001A5 RID: 421
		private string mLeftGifUrl;

		// Token: 0x040001A6 RID: 422
		private double mAutoHideTime = 3500.0;

		// Token: 0x040001A7 RID: 423
		private List<SerializableKeyValuePair<string, double>> mBackgroundGradient = new List<SerializableKeyValuePair<string, double>>();

		// Token: 0x040001A8 RID: 424
		private List<SerializableKeyValuePair<string, double>> mHoverBackGroundGradient = new List<SerializableKeyValuePair<string, double>>();
	}
}
