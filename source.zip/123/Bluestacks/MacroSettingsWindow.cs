﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000065 RID: 101
	public class MacroSettingsWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x06000437 RID: 1079 RVA: 0x0001C218 File Offset: 0x0001A418
		internal MacroSettingsWindow(MainWindow window, OperationsRecord record, OperationRecorderScriptControl operationRecorderScriptControl)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			base.Owner = this.ParentWindow;
			this.mOperationRecorderScriptControl = operationRecorderScriptControl;
			this.mOperationRecord = record;
			InputMethod.SetIsInputMethodEnabled(this.mLoopCountTextBox, false);
			InputMethod.SetIsInputMethodEnabled(this.mLoopHours, false);
			InputMethod.SetIsInputMethodEnabled(this.mLoopMinutes, false);
			InputMethod.SetIsInputMethodEnabled(this.mLoopSeconds, false);
			InputMethod.SetIsInputMethodEnabled(this.mLoopIntervalMinsTextBox, false);
			InputMethod.SetIsInputMethodEnabled(this.mRestartPlayerIntervalTextBox, false);
			InputMethod.SetIsInputMethodEnabled(this.mLoopIntervalSecondsTextBox, false);
			this.InitSettings();
		}

		// Token: 0x06000438 RID: 1080 RVA: 0x0001C2AC File Offset: 0x0001A4AC
		private void InitSettings()
		{
			this.mSettingsHeaderText.Text = string.Format("{0} {1}", this.mOperationRecord.Name, LocaleStrings.GetLocalizedString("STRING_SETTINGS", false).ToLower());
			this.mLoopCountTextBox.Text = this.mOperationRecord.LoopNumber.ToString();
			this.mLoopHours.Text = (this.mOperationRecord.LoopTime / 3600).ToString();
			this.mLoopMinutes.Text = (this.mOperationRecord.LoopTime / 60 % 60).ToString();
			this.mLoopSeconds.Text = (this.mOperationRecord.LoopTime % 60).ToString();
			this.mLoopIntervalMinsTextBox.Text = (this.mOperationRecord.LoopInterval / 60 % 60).ToString();
			this.mLoopIntervalSecondsTextBox.Text = (this.mOperationRecord.LoopInterval % 60).ToString();
			this.mRestartPlayerCheckBox.IsChecked = new bool?(this.mOperationRecord.RestartPlayer);
			this.mPlayOnStartCheckBox.IsChecked = new bool?(this.mOperationRecord.PlayOnStart);
			this.mRestartPlayerIntervalTextBox.Text = this.mOperationRecord.RestartPlayerAfterMinutes.ToString();
			this.mAccelerationCombobox.Items.Clear();
			for (int i = 0; i <= 8; i++)
			{
				ComboBoxItem comboBoxItem = new ComboBoxItem();
				comboBoxItem.Content = ((double)(i + 2) * 0.5).ToString() + "x";
				this.mAccelerationCombobox.Items.Add(comboBoxItem);
			}
			if (this.mOperationRecord.Acceleration == 0.0)
			{
				this.mAccelerationCombobox.SelectedIndex = 0;
			}
			else
			{
				this.mAccelerationCombobox.SelectedIndex = (int)(this.mOperationRecord.Acceleration / 0.5 - 2.0);
			}
			this.mRestartTextBlock.ToolTip = string.Format(string.Concat(new string[]
			{
				LocaleStrings.GetLocalizedString("STRING_AFTER", false),
				" ",
				this.mRestartPlayerIntervalTextBox.Text,
				" ",
				LocaleStrings.GetLocalizedString("STRING_RESTART_PLAYER_AFTER", false)
			}), new object[0]);
			this.SelectRepeatExecutionSetting();
		}

		// Token: 0x06000439 RID: 1081 RVA: 0x0001C514 File Offset: 0x0001A714
		private void SelectRepeatExecutionSetting()
		{
			switch (this.mOperationRecord.LoopType)
			{
			case OperationsLoopType.TillLoopNumber:
				this.mRepeatActionInSession.IsChecked = new bool?(true);
				return;
			case OperationsLoopType.TillTime:
				this.mRepeatActionTime.IsChecked = new bool?(true);
				return;
			case OperationsLoopType.UntilStopped:
				this.mRepeatSessionInfinite.IsChecked = new bool?(true);
				return;
			default:
				return;
			}
		}

		// Token: 0x0600043A RID: 1082 RVA: 0x00004D0A File Offset: 0x00002F0A
		private void Close_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.IsMacroSettingsChanged())
			{
				this.GetUnsavedChangesWindow().ShowDialog();
			}
			this.CloseWindow(null);
		}

		// Token: 0x0600043B RID: 1083 RVA: 0x0001C578 File Offset: 0x0001A778
		private void SaveButton_Click(object sender, RoutedEventArgs e)
		{
			if (string.IsNullOrEmpty(this.mLoopHours.Text))
			{
				this.mLoopHours.Text = "0";
			}
			if (string.IsNullOrEmpty(this.mLoopMinutes.Text))
			{
				this.mLoopMinutes.Text = "0";
			}
			if (string.IsNullOrEmpty(this.mLoopSeconds.Text))
			{
				this.mLoopSeconds.Text = "0";
			}
			if (string.IsNullOrEmpty(this.mLoopCountTextBox.Text))
			{
				this.mLoopCountTextBox.Text = "0";
			}
			if (string.IsNullOrEmpty(this.mLoopIntervalMinsTextBox.Text))
			{
				this.mLoopIntervalMinsTextBox.Text = "0";
			}
			if (string.IsNullOrEmpty(this.mLoopIntervalSecondsTextBox.Text))
			{
				this.mLoopIntervalSecondsTextBox.Text = "0";
			}
			if (string.IsNullOrEmpty(this.mRestartPlayerIntervalTextBox.Text))
			{
				this.mRestartPlayerIntervalTextBox.Text = "0";
			}
			bool flag = this.IsMacroSettingsChanged();
			if (!string.IsNullOrEmpty(this.mRestartPlayerIntervalTextBox.Text) && int.Parse(this.mRestartPlayerIntervalTextBox.Text) > 0)
			{
				if (!flag)
				{
					this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_CHANGES_SAVE", false), 4.0, true);
					return;
				}
				this.SaveScriptSettings();
				if (sender != null)
				{
					this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_SAVE_CHANGES", false), 4.0, true);
					return;
				}
			}
			else
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_MACRO_RESTART_INTERVAL_NULL", false), 4.0, true);
				this.mRestartPlayerIntervalTextBox.Text = this.mOperationRecord.RestartPlayerAfterMinutes.ToString();
			}
		}

		// Token: 0x0600043C RID: 1084 RVA: 0x0001C740 File Offset: 0x0001A940
		private CustomMessageWindow GetUnsavedChangesWindow()
		{
			CustomMessageWindow window = new CustomMessageWindow();
			window.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_MACRO_TOOL", false);
			window.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_UNSAVED_CHANGES_CLOSE_WINDOW", false);
			window.IsWindowClosable = false;
			window.AddButton(ButtonColors.Blue, LocaleStrings.GetLocalizedString("STRING_SAVE_CHANGE", false), delegate(object s, EventArgs e)
			{
				this.SaveAndCloseWindow(window);
			}, null, false, null);
			window.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_CLOSE", false), null, null, false, null);
			window.Owner = this.ParentWindow;
			return window;
		}

		// Token: 0x0600043D RID: 1085 RVA: 0x0001C800 File Offset: 0x0001AA00
		private void CloseWindow(CustomMessageWindow window = null)
		{
			if (window != null)
			{
				window.Close();
			}
			base.Close();
			this.mOperationRecorderScriptControl.mMacroSettingsWindow = null;
			this.mOperationRecorderScriptControl.mOperationRecorderWindow.mOverlayGrid.Visibility = Visibility.Hidden;
			this.mOperationRecorderScriptControl.mOperationRecorderWindow.Focus();
		}

		// Token: 0x0600043E RID: 1086 RVA: 0x0001C850 File Offset: 0x0001AA50
		private void SaveAndCloseWindow(CustomMessageWindow window)
		{
			this.SaveButton_Click(null, null);
			this.ParentWindow.mCommonHandler.AddToastPopup(this.mOperationRecorderScriptControl.mOperationRecorderWindow, LocaleStrings.GetLocalizedString("STRING_SAVE_CHANGES", false), 4.0, true);
			this.CloseWindow(window);
		}

		// Token: 0x0600043F RID: 1087 RVA: 0x00004D0A File Offset: 0x00002F0A
		private void CancelButton_Click(object sender, RoutedEventArgs e)
		{
			if (this.IsMacroSettingsChanged())
			{
				this.GetUnsavedChangesWindow().ShowDialog();
			}
			this.CloseWindow(null);
		}

		// Token: 0x06000440 RID: 1088 RVA: 0x0001C89C File Offset: 0x0001AA9C
		private void SaveScriptSettings()
		{
			try
			{
				this.mOperationRecord.LoopType = this.FindLoopType();
				if ((double)this.mAccelerationCombobox.SelectedIndex < 0.0)
				{
					this.mOperationRecord.Acceleration = 1.0;
				}
				else
				{
					this.mOperationRecord.Acceleration = (double)(this.mAccelerationCombobox.SelectedIndex + 2) * 0.5;
				}
				bool? isChecked = this.mPlayOnStartCheckBox.IsChecked;
				bool flag = true;
				if (isChecked.GetValueOrDefault() == flag & isChecked != null)
				{
					if (this.ParentWindow.mAutoRunMacro != null)
					{
						this.ParentWindow.mAutoRunMacro.PlayOnStart = false;
						this.ParentWindow.mCommonHandler.SerializeJsonOperationRecord(this.ParentWindow.mAutoRunMacro, this.ParentWindow.mAutoRunMacro.Name + ".json");
					}
					foreach (object obj in this.ParentWindow.OperationRecorderWindow.mScriptsStackPanel.Children)
					{
						OperationRecorderScriptControl operationRecorderScriptControl = (OperationRecorderScriptControl)obj;
						if (this.ParentWindow.mAutoRunMacro != null && operationRecorderScriptControl.mScriptName.Text == this.ParentWindow.mAutoRunMacro.Name)
						{
							operationRecorderScriptControl.mAutorunImage.Visibility = Visibility.Hidden;
						}
						if (operationRecorderScriptControl.mScriptName.Text == this.mOperationRecord.Name)
						{
							operationRecorderScriptControl.mAutorunImage.Visibility = Visibility.Visible;
						}
					}
					this.ParentWindow.mAutoRunMacro = this.mOperationRecord;
				}
				this.mOperationRecord.LoopTime = Convert.ToInt32(this.mLoopHours.Text) * 3600 + Convert.ToInt32(this.mLoopMinutes.Text) * 60 + Convert.ToInt32(this.mLoopSeconds.Text);
				this.mOperationRecord.LoopNumber = Convert.ToInt32(this.mLoopCountTextBox.Text);
				this.mOperationRecord.LoopInterval = Convert.ToInt32(this.mLoopIntervalMinsTextBox.Text) * 60 + Convert.ToInt32(this.mLoopIntervalSecondsTextBox.Text);
				this.mOperationRecord.PlayOnStart = Convert.ToBoolean(this.mPlayOnStartCheckBox.IsChecked);
				this.mOperationRecord.RestartPlayer = Convert.ToBoolean(this.mRestartPlayerCheckBox.IsChecked);
				this.mOperationRecord.RestartPlayerAfterMinutes = Convert.ToInt32(this.mRestartPlayerIntervalTextBox.Text);
				this.ParentWindow.mCommonHandler.SerializeJsonOperationRecord(this.mOperationRecord, this.mOperationRecord.Name + ".json");
				CommonHandlers.RefreshAllOperationRecorderWindow();
				this.ParentWindow.mCommonHandler.OnMacroSettingChanged(this.mOperationRecord);
			}
			catch (Exception ex)
			{
				Logger.Error("Error in saving macro settings: " + ex.ToString());
			}
		}

		// Token: 0x06000441 RID: 1089 RVA: 0x0001CBC0 File Offset: 0x0001ADC0
		private OperationsLoopType FindLoopType()
		{
			if (this.mRepeatActionInSession.IsChecked.Value)
			{
				return OperationsLoopType.TillLoopNumber;
			}
			if (this.mRepeatActionTime.IsChecked.Value)
			{
				return OperationsLoopType.TillTime;
			}
			return OperationsLoopType.UntilStopped;
		}

		// Token: 0x06000442 RID: 1090 RVA: 0x0001CBFC File Offset: 0x0001ADFC
		private void TopBar_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!e.OriginalSource.GetType().Equals(typeof(CustomPictureBox)))
			{
				try
				{
					base.DragMove();
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000443 RID: 1091 RVA: 0x00004D27 File Offset: 0x00002F27
		private void NumericTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
		{
			e.Handled = !this.IsTextAllowed(e.Text);
		}

		// Token: 0x06000444 RID: 1092 RVA: 0x00004D3E File Offset: 0x00002F3E
		private bool IsTextAllowed(string text)
		{
			return new Regex("^[0-9]+$").IsMatch(text) && text.IndexOf(' ') == -1;
		}

		// Token: 0x06000445 RID: 1093 RVA: 0x0001CC40 File Offset: 0x0001AE40
		private void NumericTextBox_Pasting(object sender, DataObjectPastingEventArgs e)
		{
			if (e.DataObject.GetDataPresent(typeof(string)))
			{
				string text = (string)e.DataObject.GetData(typeof(string));
				if (!this.IsTextAllowed(text))
				{
					e.CancelCommand();
					return;
				}
			}
			else
			{
				e.CancelCommand();
			}
		}

		// Token: 0x06000446 RID: 1094 RVA: 0x00004D5F File Offset: 0x00002F5F
		private void NumericTextBox_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Space)
			{
				e.Handled = true;
			}
		}

		// Token: 0x06000447 RID: 1095 RVA: 0x0001CC98 File Offset: 0x0001AE98
		private bool IsMacroSettingsChanged()
		{
			if (this.mLoopHours.Text != (this.mOperationRecord.LoopTime / 3600).ToString())
			{
				return true;
			}
			if (this.mLoopMinutes.Text != (this.mOperationRecord.LoopTime / 60 % 60).ToString())
			{
				return true;
			}
			if (this.mLoopSeconds.Text != (this.mOperationRecord.LoopTime % 60).ToString())
			{
				return true;
			}
			if (this.mLoopCountTextBox.Text != this.mOperationRecord.LoopNumber.ToString())
			{
				return true;
			}
			if (this.mLoopIntervalMinsTextBox.Text != (this.mOperationRecord.LoopInterval / 60 % 60).ToString())
			{
				return true;
			}
			if (this.mLoopIntervalSecondsTextBox.Text != (this.mOperationRecord.LoopInterval % 60).ToString())
			{
				return true;
			}
			bool? isChecked = this.mRestartPlayerCheckBox.IsChecked;
			bool flag = this.mOperationRecord.RestartPlayer;
			if (!(isChecked.GetValueOrDefault() == flag & isChecked != null))
			{
				return true;
			}
			isChecked = this.mPlayOnStartCheckBox.IsChecked;
			flag = this.mOperationRecord.PlayOnStart;
			return !(isChecked.GetValueOrDefault() == flag & isChecked != null) || this.mRestartPlayerIntervalTextBox.Text != this.mOperationRecord.RestartPlayerAfterMinutes.ToString() || this.FindLoopType() != this.mOperationRecord.LoopType || (this.mAccelerationCombobox.SelectedIndex != 0 && this.mOperationRecord.Acceleration == 0.0) || this.mAccelerationCombobox.SelectedIndex != (int)(this.mOperationRecord.Acceleration / 0.5 - 2.0);
		}

		// Token: 0x06000448 RID: 1096 RVA: 0x0001CE94 File Offset: 0x0001B094
		private void RestartTextBlock_ToolTipOpening(object sender, ToolTipEventArgs e)
		{
			this.mRestartTextBlock.ToolTip = string.Format(string.Concat(new string[]
			{
				LocaleStrings.GetLocalizedString("STRING_AFTER", false),
				" ",
				this.mRestartPlayerIntervalTextBox.Text,
				" ",
				LocaleStrings.GetLocalizedString("STRING_RESTART_PLAYER_AFTER", false)
			}), new object[0]);
		}

		// Token: 0x06000449 RID: 1097 RVA: 0x0001CEFC File Offset: 0x0001B0FC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/macrosettingswindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600044A RID: 1098 RVA: 0x0001CF2C File Offset: 0x0001B12C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				this.mSettingsHeaderText = (TextBlock)target;
				this.mSettingsHeaderText.MouseDown += this.TopBar_MouseDown;
				return;
			case 3:
				((CustomPictureBox)target).MouseLeftButtonUp += this.Close_MouseLeftButtonUp;
				return;
			case 4:
				this.mRepeactActionPanel = (StackPanel)target;
				return;
			case 5:
				this.mRepeatActionInSession = (CustomRadioButton)target;
				return;
			case 6:
				this.mRepeatActionInSessionGrid = (Grid)target;
				return;
			case 7:
				this.mLoopCountTextBox = (CustomTextBox)target;
				this.mLoopCountTextBox.PreviewTextInput += this.NumericTextBox_PreviewTextInput;
				this.mLoopCountTextBox.AddHandler(DataObject.PastingEvent, new DataObjectPastingEventHandler(this.NumericTextBox_Pasting));
				this.mLoopCountTextBox.PreviewKeyDown += this.NumericTextBox_KeyDown;
				return;
			case 8:
				this.mRepeatActionTime = (CustomRadioButton)target;
				return;
			case 9:
				this.mLoopHours = (CustomTextBox)target;
				this.mLoopHours.PreviewTextInput += this.NumericTextBox_PreviewTextInput;
				this.mLoopHours.AddHandler(DataObject.PastingEvent, new DataObjectPastingEventHandler(this.NumericTextBox_Pasting));
				this.mLoopHours.PreviewKeyDown += this.NumericTextBox_KeyDown;
				return;
			case 10:
				this.mLoopMinutes = (CustomTextBox)target;
				this.mLoopMinutes.PreviewTextInput += this.NumericTextBox_PreviewTextInput;
				this.mLoopMinutes.AddHandler(DataObject.PastingEvent, new DataObjectPastingEventHandler(this.NumericTextBox_Pasting));
				this.mLoopMinutes.PreviewKeyDown += this.NumericTextBox_KeyDown;
				return;
			case 11:
				this.mLoopSeconds = (CustomTextBox)target;
				this.mLoopSeconds.PreviewTextInput += this.NumericTextBox_PreviewTextInput;
				this.mLoopSeconds.AddHandler(DataObject.PastingEvent, new DataObjectPastingEventHandler(this.NumericTextBox_Pasting));
				this.mLoopSeconds.PreviewKeyDown += this.NumericTextBox_KeyDown;
				return;
			case 12:
				this.mRepeatSessionInfinite = (CustomRadioButton)target;
				return;
			case 13:
				this.mLoopIntervalMinsTextBox = (CustomTextBox)target;
				this.mLoopIntervalMinsTextBox.PreviewTextInput += this.NumericTextBox_PreviewTextInput;
				this.mLoopIntervalMinsTextBox.AddHandler(DataObject.PastingEvent, new DataObjectPastingEventHandler(this.NumericTextBox_Pasting));
				this.mLoopIntervalMinsTextBox.PreviewKeyDown += this.NumericTextBox_KeyDown;
				return;
			case 14:
				this.mLoopIntervalSecondsTextBox = (CustomTextBox)target;
				this.mLoopIntervalSecondsTextBox.PreviewTextInput += this.NumericTextBox_PreviewTextInput;
				this.mLoopIntervalSecondsTextBox.AddHandler(DataObject.PastingEvent, new DataObjectPastingEventHandler(this.NumericTextBox_Pasting));
				this.mLoopIntervalSecondsTextBox.PreviewKeyDown += this.NumericTextBox_KeyDown;
				return;
			case 15:
				this.mAccelerationCombobox = (CustomComboBox)target;
				return;
			case 16:
				this.mPlayOnStartCheckBox = (CustomCheckbox)target;
				return;
			case 17:
				this.mRestartPlayerCheckBox = (CustomCheckbox)target;
				return;
			case 18:
				this.mRestartPlayerIntervalTextBox = (CustomTextBox)target;
				this.mRestartPlayerIntervalTextBox.PreviewTextInput += this.NumericTextBox_PreviewTextInput;
				this.mRestartPlayerIntervalTextBox.AddHandler(DataObject.PastingEvent, new DataObjectPastingEventHandler(this.NumericTextBox_Pasting));
				this.mRestartPlayerIntervalTextBox.PreviewKeyDown += this.NumericTextBox_KeyDown;
				return;
			case 19:
				this.mRestartTextBlock = (TextBlock)target;
				this.mRestartTextBlock.ToolTipOpening += this.RestartTextBlock_ToolTipOpening;
				return;
			case 20:
				this.mSaveButton = (CustomButton)target;
				this.mSaveButton.Click += this.SaveButton_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000275 RID: 629
		private MainWindow ParentWindow;

		// Token: 0x04000276 RID: 630
		private OperationRecorderScriptControl mOperationRecorderScriptControl;

		// Token: 0x04000277 RID: 631
		private OperationsRecord mOperationRecord;

		// Token: 0x04000278 RID: 632
		internal Border mMaskBorder;

		// Token: 0x04000279 RID: 633
		internal TextBlock mSettingsHeaderText;

		// Token: 0x0400027A RID: 634
		internal StackPanel mRepeactActionPanel;

		// Token: 0x0400027B RID: 635
		internal CustomRadioButton mRepeatActionInSession;

		// Token: 0x0400027C RID: 636
		internal Grid mRepeatActionInSessionGrid;

		// Token: 0x0400027D RID: 637
		internal CustomTextBox mLoopCountTextBox;

		// Token: 0x0400027E RID: 638
		internal CustomRadioButton mRepeatActionTime;

		// Token: 0x0400027F RID: 639
		internal CustomTextBox mLoopHours;

		// Token: 0x04000280 RID: 640
		internal CustomTextBox mLoopMinutes;

		// Token: 0x04000281 RID: 641
		internal CustomTextBox mLoopSeconds;

		// Token: 0x04000282 RID: 642
		internal CustomRadioButton mRepeatSessionInfinite;

		// Token: 0x04000283 RID: 643
		internal CustomTextBox mLoopIntervalMinsTextBox;

		// Token: 0x04000284 RID: 644
		internal CustomTextBox mLoopIntervalSecondsTextBox;

		// Token: 0x04000285 RID: 645
		internal CustomComboBox mAccelerationCombobox;

		// Token: 0x04000286 RID: 646
		internal CustomCheckbox mPlayOnStartCheckBox;

		// Token: 0x04000287 RID: 647
		internal CustomCheckbox mRestartPlayerCheckBox;

		// Token: 0x04000288 RID: 648
		internal CustomTextBox mRestartPlayerIntervalTextBox;

		// Token: 0x04000289 RID: 649
		internal TextBlock mRestartTextBlock;

		// Token: 0x0400028A RID: 650
		internal CustomButton mSaveButton;

		// Token: 0x0400028B RID: 651
		private bool _contentLoaded;
	}
}
