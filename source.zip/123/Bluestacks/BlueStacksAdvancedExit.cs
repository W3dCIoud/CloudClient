﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000067 RID: 103
	public class BlueStacksAdvancedExit : UserControl, IDimOverlayControl, IComponentConnector
	{
		// Token: 0x1700012F RID: 303
		// (get) Token: 0x0600044D RID: 1101 RVA: 0x00004D85 File Offset: 0x00002F85
		// (set) Token: 0x0600044E RID: 1102 RVA: 0x00004BF2 File Offset: 0x00002DF2
		bool IDimOverlayControl.IsCloseOnOverLayClick
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		// Token: 0x17000130 RID: 304
		// (get) Token: 0x0600044F RID: 1103 RVA: 0x00004D88 File Offset: 0x00002F88
		// (set) Token: 0x06000450 RID: 1104 RVA: 0x00004D90 File Offset: 0x00002F90
		public bool ShowControlInSeparateWindow
		{
			get
			{
				return this.mShowControlInSeparateWindow;
			}
			set
			{
				this.mShowControlInSeparateWindow = value;
			}
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x00004D99 File Offset: 0x00002F99
		bool IDimOverlayControl.Close()
		{
			this.Close();
			return true;
		}

		// Token: 0x06000452 RID: 1106 RVA: 0x00004DA3 File Offset: 0x00002FA3
		bool IDimOverlayControl.Show()
		{
			base.Visibility = Visibility.Visible;
			return true;
		}

		// Token: 0x06000453 RID: 1107 RVA: 0x00004DAD File Offset: 0x00002FAD
		public BlueStacksAdvancedExit(MainWindow window)
		{
			this.ParentWindow = window;
			this.InitializeComponent();
			this.AddOptions();
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x00004DDF File Offset: 0x00002FDF
		private void AddOptions()
		{
			this.GenerateOptions("STRING_QUIT_BLUESTACKS", LocaleStringsConstants.ExitOptions);
			this.AddLineSeperator();
			this.GenerateOptions("STRING_RESTART_BLUESTACKS", LocaleStringsConstants.RestartOptions);
			this.AddLineSeperator();
			this.GenerateCheckBox();
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x0001D2F8 File Offset: 0x0001B4F8
		private void AddLineSeperator()
		{
			Line line = new Line();
			line.X1 = 0.0;
			line.X2 = 390.0;
			line.Y1 = (line.Y2 = 0.0);
			line.StrokeThickness = 1.0;
			line.Opacity = 0.5;
			line.Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
			BlueStacksUIBinding.BindColor(line, Shape.StrokeProperty, "SettingsWindowTabMenuItemForeground");
			this.mOptionsStackPanel.Children.Add(line);
		}

		// Token: 0x06000456 RID: 1110 RVA: 0x0001D3B0 File Offset: 0x0001B5B0
		private void GenerateCheckBox()
		{
			CustomCheckbox customCheckbox = new CustomCheckbox();
			BlueStacksUIBinding.Bind(customCheckbox, "STRING_DOWNLOAD_GOOGLE_APP_POPUP_STRING_04");
			if (customCheckbox.Image != null)
			{
				customCheckbox.Image.Height = 14.0;
				customCheckbox.Image.Width = 14.0;
			}
			customCheckbox.Height = 20.0;
			customCheckbox.Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
			customCheckbox.IsChecked = new bool?(false);
			customCheckbox.Checked += this.DontShowAgainCB_Checked;
			customCheckbox.Unchecked += this.DontShowAgainCB_Unchecked;
			this.mOptionsStackPanel.Children.Add(customCheckbox);
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x00004E13 File Offset: 0x00003013
		private void DontShowAgainCB_Checked(object sender, RoutedEventArgs e)
		{
			RegistryManager.Instance.IsQuitOptionSaved = true;
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x00004E20 File Offset: 0x00003020
		private void DontShowAgainCB_Unchecked(object sender, RoutedEventArgs e)
		{
			RegistryManager.Instance.IsQuitOptionSaved = false;
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x0001D480 File Offset: 0x0001B680
		private void GenerateOptions(string title, string[] childrenKeys)
		{
			TextBlock textBlock = new TextBlock();
			BlueStacksUIBinding.Bind(textBlock, title, "");
			textBlock.Padding = new Thickness(0.0);
			textBlock.FontSize = 16.0;
			textBlock.Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
			BlueStacksUIBinding.BindColor(textBlock, Control.ForegroundProperty, "SettingsWindowTabMenuItemSelectedForeground");
			textBlock.FontWeight = FontWeights.Normal;
			textBlock.HorizontalAlignment = HorizontalAlignment.Left;
			textBlock.VerticalAlignment = VerticalAlignment.Center;
			this.mOptionsStackPanel.Children.Add(textBlock);
			foreach (string text in childrenKeys)
			{
				CustomRadioButton customRadioButton = new CustomRadioButton();
				customRadioButton.Checked += this.Btn_Checked;
				customRadioButton.HorizontalAlignment = HorizontalAlignment.Left;
				BlueStacksUIBinding.Bind(customRadioButton, text);
				customRadioButton.Tag = text;
				customRadioButton.Margin = new Thickness(0.0, 10.0, 0.0, 5.0);
				this.mOptionsStackPanel.Children.Add(customRadioButton);
				if (text == this.mCurrentGlobalDefault)
				{
					customRadioButton.IsChecked = new bool?(true);
				}
			}
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x00004E2D File Offset: 0x0000302D
		private void Btn_Checked(object sender, RoutedEventArgs e)
		{
			RegistryManager.Instance.QuitDefaultOption = (sender as CustomRadioButton).Tag.ToString();
		}

		// Token: 0x17000131 RID: 305
		// (get) Token: 0x0600045B RID: 1115 RVA: 0x00004E49 File Offset: 0x00003049
		public CustomButton YesButton
		{
			get
			{
				return this.mYesButton;
			}
		}

		// Token: 0x17000132 RID: 306
		// (get) Token: 0x0600045C RID: 1116 RVA: 0x00004E51 File Offset: 0x00003051
		public CustomButton NoButton
		{
			get
			{
				return this.mNoButton;
			}
		}

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x0600045D RID: 1117 RVA: 0x00004E59 File Offset: 0x00003059
		public CustomPictureBox CrossButton
		{
			get
			{
				return this.mCrossButtonPictureBox;
			}
		}

		// Token: 0x0600045E RID: 1118 RVA: 0x0001D5D8 File Offset: 0x0001B7D8
		internal bool Close()
		{
			try
			{
				BlueStacksUIUtils.CloseContainerWindow(this);
				this.ParentWindow.HideDimOverlay();
				base.Visibility = Visibility.Hidden;
				return true;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while trying to close the advanced exit from dimoverlay " + ex.ToString());
			}
			return false;
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x00004E61 File Offset: 0x00003061
		private void Close_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.Close();
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x00004E61 File Offset: 0x00003061
		private void MYesButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.Close();
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x00004E61 File Offset: 0x00003061
		private void MNoButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.Close();
		}

		// Token: 0x06000462 RID: 1122 RVA: 0x0001D62C File Offset: 0x0001B82C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/bluestacksadvancedexit.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000463 RID: 1123 RVA: 0x0001D65C File Offset: 0x0001B85C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mParentGrid = (Grid)target;
				return;
			case 2:
				this.mTitleGrid = (Grid)target;
				return;
			case 3:
				this.mCrossButtonPictureBox = (CustomPictureBox)target;
				this.mCrossButtonPictureBox.PreviewMouseLeftButtonUp += this.Close_PreviewMouseLeftButtonUp;
				return;
			case 4:
				this.mTitleText = (TextBlock)target;
				return;
			case 5:
				this.mOptionsGrid = (Grid)target;
				return;
			case 6:
				this.mOptionsStackPanel = (StackPanel)target;
				return;
			case 7:
				this.mFooterGrid = (Grid)target;
				return;
			case 8:
				this.mNoButton = (CustomButton)target;
				this.mNoButton.PreviewMouseLeftButtonUp += this.MNoButton_PreviewMouseLeftButtonUp;
				return;
			case 9:
				this.mYesButton = (CustomButton)target;
				this.mYesButton.PreviewMouseLeftButtonUp += this.MYesButton_PreviewMouseLeftButtonUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400028E RID: 654
		private bool mShowControlInSeparateWindow = true;

		// Token: 0x0400028F RID: 655
		private MainWindow ParentWindow;

		// Token: 0x04000290 RID: 656
		private string mCurrentGlobalDefault = RegistryManager.Instance.QuitDefaultOption;

		// Token: 0x04000291 RID: 657
		internal Grid mParentGrid;

		// Token: 0x04000292 RID: 658
		internal Grid mTitleGrid;

		// Token: 0x04000293 RID: 659
		internal CustomPictureBox mCrossButtonPictureBox;

		// Token: 0x04000294 RID: 660
		internal TextBlock mTitleText;

		// Token: 0x04000295 RID: 661
		internal Grid mOptionsGrid;

		// Token: 0x04000296 RID: 662
		internal StackPanel mOptionsStackPanel;

		// Token: 0x04000297 RID: 663
		internal Grid mFooterGrid;

		// Token: 0x04000298 RID: 664
		internal CustomButton mNoButton;

		// Token: 0x04000299 RID: 665
		internal CustomButton mYesButton;

		// Token: 0x0400029A RID: 666
		private bool _contentLoaded;
	}
}
