﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200008A RID: 138
	public class OperationRecorderWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x1700014A RID: 330
		// (get) Token: 0x06000633 RID: 1587 RVA: 0x00006137 File Offset: 0x00004337
		// (set) Token: 0x06000634 RID: 1588 RVA: 0x0000613F File Offset: 0x0000433F
		public bool IsExportClicked
		{
			get
			{
				return this.mIsExportClicked;
			}
			set
			{
				this.mIsExportClicked = value;
			}
		}

		// Token: 0x06000635 RID: 1589 RVA: 0x00026FAC File Offset: 0x000251AC
		public OperationRecorderWindow(MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			base.Owner = this.ParentWindow;
			base.IsShowGLWindow = true;
			this.mScriptsStackPanel = (this.mScriptsListScrollbar.Content as StackPanel);
			window.mCommonHandler.MacroSettingChangedEvent += this.ParentWindow_MacroSettingChangedEvent;
			this.Init();
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.ParentWindow.mNCTopBar.mMacroPlayControl.ScriptPlayEvent -= this.ParentWindow_ScriptPlayEvent;
				this.ParentWindow.mNCTopBar.mMacroPlayControl.ScriptStopEvent -= this.MacroPlayControl_ScriptStopEvent;
				this.ParentWindow.mNCTopBar.mMacroPlayControl.ScriptPlayEvent += this.ParentWindow_ScriptPlayEvent;
				this.ParentWindow.mNCTopBar.mMacroPlayControl.ScriptStopEvent += this.MacroPlayControl_ScriptStopEvent;
				return;
			}
			this.ParentWindow.mTopBar.mMacroPlayControl.ScriptPlayEvent -= this.ParentWindow_ScriptPlayEvent;
			this.ParentWindow.mTopBar.mMacroPlayControl.ScriptStopEvent -= this.MacroPlayControl_ScriptStopEvent;
			this.ParentWindow.mTopBar.mMacroPlayControl.ScriptPlayEvent += this.ParentWindow_ScriptPlayEvent;
			this.ParentWindow.mTopBar.mMacroPlayControl.ScriptStopEvent += this.MacroPlayControl_ScriptStopEvent;
		}

		// Token: 0x06000636 RID: 1590 RVA: 0x00027138 File Offset: 0x00025338
		private void ParentWindow_MacroSettingChangedEvent(OperationsRecord record)
		{
			if (record.PlayOnStart)
			{
				foreach (object obj in this.mScriptsStackPanel.Children)
				{
					OperationRecorderScriptControl operationRecorderScriptControl = (OperationRecorderScriptControl)obj;
					if (operationRecorderScriptControl.mOperationRecord.Name.ToLower().Trim() == record.Name.ToLower().Trim())
					{
						this.ChangeAutorunImageVisibility(operationRecorderScriptControl.mAutorunImage, Visibility.Visible);
					}
					else
					{
						this.ChangeAutorunImageVisibility(operationRecorderScriptControl.mAutorunImage, Visibility.Hidden);
						if (operationRecorderScriptControl.mOperationRecord.PlayOnStart)
						{
							operationRecorderScriptControl.mOperationRecord.PlayOnStart = false;
							if (operationRecorderScriptControl.mMacroSettingsWindow != null)
							{
								operationRecorderScriptControl.mMacroSettingsWindow.mPlayOnStartCheckBox.IsChecked = new bool?(false);
							}
							JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
							serializerSettings.Formatting = Formatting.Indented;
							string contents = JsonConvert.SerializeObject(operationRecorderScriptControl.mOperationRecord, serializerSettings);
							File.WriteAllText(Path.Combine(RegistryStrings.OperationsScriptFolder, operationRecorderScriptControl.mOperationRecord.Name) + ".json", contents);
						}
					}
				}
			}
		}

		// Token: 0x06000637 RID: 1591 RVA: 0x00027264 File Offset: 0x00025464
		private void ChangeAutorunImageVisibility(CustomPictureBox cpb, Visibility visibility)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				cpb.Visibility = visibility;
			}), new object[0]);
		}

		// Token: 0x06000638 RID: 1592 RVA: 0x000272A4 File Offset: 0x000254A4
		private void MacroPlayControl_ScriptStopEvent(string tag)
		{
			OperationRecorderScriptControl controlFromTag = this.GetControlFromTag(tag);
			if (controlFromTag != null)
			{
				controlFromTag.ToggleScriptPlayPauseUi(false);
			}
			this.ParentWindow.mCommonHandler.ShowOperationRecorderWindow();
		}

		// Token: 0x06000639 RID: 1593 RVA: 0x000272D4 File Offset: 0x000254D4
		private void ParentWindow_ScriptPlayEvent(string tag)
		{
			OperationRecorderScriptControl controlFromTag = this.GetControlFromTag(tag);
			if (controlFromTag != null)
			{
				controlFromTag.ToggleScriptPlayPauseUi(true);
			}
		}

		// Token: 0x0600063A RID: 1594 RVA: 0x000272F4 File Offset: 0x000254F4
		public void Init()
		{
			this.ParentWindow.mIsScriptsPresent = false;
			this.AddScriptsToStackPanel();
			if (!this.ParentWindow.mIsScriptsPresent)
			{
				this.mNoScriptsGrid.Visibility = Visibility.Visible;
				this.mExport.IsEnabled = false;
				this.mExport.Opacity = 0.4;
			}
			else
			{
				this.mNoScriptsGrid.Visibility = Visibility.Collapsed;
				this.mExport.IsEnabled = true;
				this.mExport.Opacity = 1.0;
			}
			this.mIsExportClicked = false;
			if (this.ParentWindow.mIsOperationRecorderActive)
			{
				this.mStartMacroRecordingBtn.Visibility = Visibility.Collapsed;
				this.mStopMacroRecordingBtn.Visibility = Visibility.Visible;
			}
			else
			{
				this.mStartMacroRecordingBtn.Visibility = Visibility.Visible;
				this.mStopMacroRecordingBtn.Visibility = Visibility.Collapsed;
			}
			this.ToggleUI(this.ParentWindow.mIsOperationRecorderActive);
			if (this.ParentWindow.mIsMacroPlaying)
			{
				this.mStartMacroRecordingBtn.Visibility = Visibility.Hidden;
				this.mStopMacroRecordingBtn.Visibility = Visibility.Hidden;
			}
			this.ShowLoadingGrid(false);
		}

		// Token: 0x0600063B RID: 1595 RVA: 0x00027400 File Offset: 0x00025600
		private void AddScriptsToStackPanel()
		{
			if (Directory.Exists(RegistryStrings.OperationsScriptFolder))
			{
				foreach (FileInfo fileSystemInfo in (from p in new DirectoryInfo(RegistryStrings.OperationsScriptFolder).GetFiles()
				orderby p.CreationTime
				select p).ToArray<FileInfo>())
				{
					this.ParentWindow.mIsScriptsPresent = true;
					OperationsRecord operationsRecord = JsonConvert.DeserializeObject<OperationsRecord>(File.ReadAllText(fileSystemInfo.FullName), Utils.GetSerializerSettings());
					if (operationsRecord != null && !string.IsNullOrEmpty(operationsRecord.Name) && !string.IsNullOrEmpty(operationsRecord.TimeCreated) && operationsRecord.Events != null)
					{
						OperationRecorderScriptControl operationRecorderScriptControl = new OperationRecorderScriptControl(this.ParentWindow, operationsRecord, this);
						operationRecorderScriptControl.Tag = operationsRecord.Name;
						if (this.ParentWindow.mIsMacroPlaying && !this.ParentWindow.mMacroPlaying.Equals(operationsRecord.Name))
						{
							this.ParentWindow.mCommonHandler.DisableScriptControl(operationRecorderScriptControl);
						}
						else if (this.ParentWindow.mIsMacroPlaying)
						{
							operationRecorderScriptControl.mEditNameImg.IsEnabled = false;
						}
						else if (this.ParentWindow.mIsOperationRecorderActive)
						{
							this.ParentWindow.mCommonHandler.DisableScriptControl(operationRecorderScriptControl);
						}
						if (operationsRecord.PlayOnStart)
						{
							operationRecorderScriptControl.mAutorunImage.Visibility = Visibility.Visible;
						}
						this.mScriptsStackPanel.Children.Add(operationRecorderScriptControl);
					}
				}
			}
		}

		// Token: 0x0600063C RID: 1596 RVA: 0x00027570 File Offset: 0x00025770
		private OperationRecorderScriptControl GetControlFromTag(string tag)
		{
			foreach (object obj in this.mScriptsStackPanel.Children)
			{
				OperationRecorderScriptControl operationRecorderScriptControl = (OperationRecorderScriptControl)obj;
				if ((string)operationRecorderScriptControl.Tag == tag)
				{
					return operationRecorderScriptControl;
				}
			}
			return null;
		}

		// Token: 0x0600063D RID: 1597 RVA: 0x00006148 File Offset: 0x00004348
		private void OpenScriptFolder_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (Directory.Exists(RegistryStrings.OperationsScriptFolder))
			{
				new Process
				{
					StartInfo = 
					{
						UseShellExecute = true,
						FileName = RegistryStrings.OperationsScriptFolder
					}
				}.Start();
			}
		}

		// Token: 0x0600063E RID: 1598 RVA: 0x0000617D File Offset: 0x0000437D
		private void Close_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.HideOperationRecorderWindow();
			this.ParentWindow.Focus();
			this.ParentWindow.mFrontendHandler.ShowGLWindow();
		}

		// Token: 0x0600063F RID: 1599 RVA: 0x000275E4 File Offset: 0x000257E4
		private void mStartMacroRecordingBtn_Click(object sender, RoutedEventArgs e)
		{
			this.ParentWindow.mCommonHandler.StartMacroRecording();
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "new_macro_record", null, null, null, null, null);
		}

		// Token: 0x06000640 RID: 1600 RVA: 0x0002762C File Offset: 0x0002582C
		private void mStopMacroRecordingBtn_Click(object sender, RoutedEventArgs e)
		{
			this.ParentWindow.mCommonHandler.StopMacroRecording();
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_record_stop", null, null, null, null, null);
		}

		// Token: 0x06000641 RID: 1601 RVA: 0x000061AB File Offset: 0x000043AB
		internal void PerformStopMacroAfterSave()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.ParentWindow.mIsOperationRecorderActive = false;
				this.ParentWindow.mTopBar.HideRecordingIcons();
				this.ParentWindow.mCommonHandler.ShowOperationRecorderWindow();
				this.mStartMacroRecordingBtn.Visibility = Visibility.Visible;
				this.mStopMacroRecordingBtn.Visibility = Visibility.Collapsed;
			}), new object[0]);
		}

		// Token: 0x06000642 RID: 1602 RVA: 0x00027674 File Offset: 0x00025874
		internal void SaveOperation(string events)
		{
			try
			{
				if (!events.Equals("[]"))
				{
					string operationsScriptFolder = RegistryStrings.OperationsScriptFolder;
					OperationsRecord record = new OperationsRecord();
					string timeCreated = DateTime.Now.ToString("yyyyMMddTHHmmss");
					record.TimeCreated = timeCreated;
					record.Name = this.ParentWindow.mCommonHandler.GetMacroName("Script");
					record.Events = JsonConvert.DeserializeObject(events);
					MainWindow.sMacroScriptNames.Add(record.Name.ToLower().Trim());
					base.Dispatcher.Invoke(new Action(delegate()
					{
						foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
						{
							if (keyValuePair.Value.OperationRecorderWindow != null)
							{
								OperationRecorderScriptControl operationRecorderScriptControl = new OperationRecorderScriptControl(keyValuePair.Value, record, this);
								operationRecorderScriptControl.Tag = record.Name;
								BlueStacksUIBinding.BindColor(operationRecorderScriptControl.mGrid, System.Windows.Controls.Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
								BlueStacksUIBinding.BindColor(operationRecorderScriptControl.mScriptName, TextBlock.ForegroundProperty, "WhiteMouseOutBorderBackground");
								BlueStacksUIBinding.BindColor(operationRecorderScriptControl.mMacroShortcutTextBox, TextBlock.ForegroundProperty, "DualTextBlockForeground");
								keyValuePair.Value.OperationRecorderWindow.mNoScriptsGrid.Visibility = Visibility.Collapsed;
								this.mExport.IsEnabled = true;
								this.mExport.Opacity = 1.0;
								if (!keyValuePair.Value.mIsScriptsPresent)
								{
									keyValuePair.Value.mIsScriptsPresent = true;
								}
								keyValuePair.Value.OperationRecorderWindow.mScriptsStackPanel.Children.Add(operationRecorderScriptControl);
								keyValuePair.Value.OperationRecorderWindow.mScriptsListScrollbar.ScrollToEnd();
							}
						}
					}), new object[0]);
					this.ParentWindow.mCommonHandler.SerializeJsonOperationRecord(record, Path.Combine(operationsScriptFolder, record.Name + ".json"));
				}
				else
				{
					this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_OPERATION_MESSAGE", false), 4.0, true);
				}
				this.PerformStopMacroAfterSave();
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in SaveOperations. Exception: " + ex.ToString());
			}
		}

		// Token: 0x06000643 RID: 1603 RVA: 0x0001CBFC File Offset: 0x0001ADFC
		private void Topbar_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!e.OriginalSource.GetType().Equals(typeof(CustomPictureBox)))
			{
				try
				{
					base.DragMove();
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000644 RID: 1604 RVA: 0x000277D4 File Offset: 0x000259D4
		internal void ToggleUI(bool isRecording)
		{
			if (isRecording)
			{
				this.mStopMacroRecordingBtn.Visibility = Visibility.Visible;
				this.mStartMacroRecordingBtn.Visibility = Visibility.Collapsed;
				this.mNoScriptsGrid.Visibility = Visibility.Collapsed;
				this.mScriptsStackPanel.Visibility = Visibility.Visible;
				return;
			}
			this.mStopMacroRecordingBtn.Visibility = Visibility.Collapsed;
			this.mStartMacroRecordingBtn.Visibility = Visibility.Visible;
			if (this.ParentWindow.mIsScriptsPresent)
			{
				this.mNoScriptsGrid.Visibility = Visibility.Collapsed;
				this.mScriptsStackPanel.Visibility = Visibility.Visible;
				return;
			}
			this.mNoScriptsGrid.Visibility = Visibility.Visible;
			this.mScriptsStackPanel.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000645 RID: 1605 RVA: 0x0002786C File Offset: 0x00025A6C
		private void ShowLoadingGrid(bool isShow)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (isShow)
				{
					this.mLoadingGrid.Visibility = Visibility.Visible;
					return;
				}
				this.mLoadingGrid.Visibility = Visibility.Collapsed;
			}), new object[0]);
		}

		// Token: 0x06000646 RID: 1606 RVA: 0x000061CB File Offset: 0x000043CB
		private void ShowScriptsGrid()
		{
			this.mNoScriptsGrid.Visibility = Visibility.Collapsed;
			this.mScriptsStackPanel.Visibility = Visibility.Visible;
		}

		// Token: 0x06000647 RID: 1607 RVA: 0x000278AC File Offset: 0x00025AAC
		private void ExportBtn_Click(object sender, MouseButtonEventArgs e)
		{
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_window_export", null, null, null, null, null);
			if (this.ParentWindow.mIsScriptsPresent)
			{
				this.mOverlayGrid.Visibility = Visibility.Visible;
				if (this.mExportMacroWindow == null)
				{
					this.mExportMacroWindow = new ExportMacroWindow(this, this.ParentWindow);
					this.mExportMacroWindow.Owner = this;
					this.mExportMacroWindow.Init();
					this.mExportMacroWindow.Show();
					return;
				}
			}
			else
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_MACRO_AVAILABLE", false), 4.0, true);
			}
		}

		// Token: 0x06000648 RID: 1608 RVA: 0x00027960 File Offset: 0x00025B60
		private void ImportBtn_Click(object sender, MouseButtonEventArgs e)
		{
			try
			{
				ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_window_import", null, null, null, null, null);
				using (OpenFileDialog openFileDialog = new OpenFileDialog())
				{
					openFileDialog.Multiselect = true;
					openFileDialog.Filter = "Json files (*.json)|*.json";
					if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
					{
						BackgroundWorker backgroundWorker = new BackgroundWorker();
						backgroundWorker.DoWork += this.BgImport_DoWork;
						backgroundWorker.RunWorkerCompleted += this.BgImport_RunWorkerCompleted;
						this.ShowLoadingGrid(true);
						backgroundWorker.RunWorkerAsync(openFileDialog);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Importing file. err: " + ex.ToString());
				this.ShowLoadingGrid(false);
			}
		}

		// Token: 0x06000649 RID: 1609 RVA: 0x00027A38 File Offset: 0x00025C38
		private void BgImport_DoWork(object sender, DoWorkEventArgs e)
		{
			try
			{
				e.Result = this.CopyMacroScriptIfFileFormatSupported(e.Argument as OpenFileDialog);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Importing file. err: " + ex.ToString());
				e.Result = true;
			}
		}

		// Token: 0x0600064A RID: 1610 RVA: 0x00027A98 File Offset: 0x00025C98
		private void BgImport_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			this.ShowLoadingGrid(false);
			int num = (int)e.Result;
			if (num == 1)
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_FILE_FORMAT_NOT_SUPPORTED", false), 4.0, true);
				return;
			}
			if (num == 2)
			{
				this.ShowMacroImportWizard();
				return;
			}
			if (!Directory.Exists(RegistryStrings.OperationsScriptFolder))
			{
				Directory.CreateDirectory(RegistryStrings.OperationsScriptFolder);
			}
			CommonHandlers.RefreshAllOperationRecorderWindowWithScroll();
		}

		// Token: 0x0600064B RID: 1611 RVA: 0x00027B0C File Offset: 0x00025D0C
		private int CopyMacroScriptIfFileFormatSupported(OpenFileDialog fileDialog)
		{
			int i;
			try
			{
				this.mRenamingMacrosList.Clear();
				string[] fileNames = fileDialog.FileNames;
				bool flag = false;
				List<string> list = new List<string>();
				foreach (string path in fileNames)
				{
					OperationsRecord operationsRecord = JsonConvert.DeserializeObject<OperationsRecord>(File.ReadAllText(path), Utils.GetSerializerSettings());
					if (operationsRecord == null || string.IsNullOrEmpty(operationsRecord.Name) || string.IsNullOrEmpty(operationsRecord.TimeCreated) || operationsRecord.Events == null)
					{
						list.Add(Path.GetFileNameWithoutExtension(path));
					}
					else
					{
						operationsRecord.ShortCut = string.Empty;
						operationsRecord.PlayOnStart = false;
						if (this.CheckIfDuplicateMacroInImport(operationsRecord.Name.ToLower().Trim()) || !string.Equals(operationsRecord.Name, Path.GetFileNameWithoutExtension(path), StringComparison.OrdinalIgnoreCase))
						{
							Path.GetFileNameWithoutExtension(path);
							flag = true;
							this.mRenamingMacrosList.Add(operationsRecord);
						}
						else
						{
							operationsRecord.Name = operationsRecord.Name.Trim();
							MainWindow.sMacroScriptNames.Add(operationsRecord.Name.ToLower());
							this.ParentWindow.mCommonHandler.SerializeJsonOperationRecord(operationsRecord, operationsRecord.Name + ".json");
						}
					}
				}
				if (list.Count<string>() > 0)
				{
					string message = string.Format(LocaleStrings.GetLocalizedString("STRING_INVALID_FILES_LIST", false), string.Join(", ", list.ToArray()));
					this.ParentWindow.mCommonHandler.AddToastPopup(this, message, 4.0, true);
				}
				if (flag)
				{
					i = 2;
				}
				else
				{
					i = 0;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Wrong file format wont import. err:" + ex.ToString());
				i = 1;
			}
			return i;
		}

		// Token: 0x0600064C RID: 1612 RVA: 0x00027CD0 File Offset: 0x00025ED0
		private bool CheckIfDuplicateMacroInImport(string macroName)
		{
			macroName = Path.GetFileNameWithoutExtension(macroName);
			if (Directory.Exists(RegistryStrings.OperationsScriptFolder))
			{
				if (new List<string>(from _ in Directory.GetFiles(RegistryStrings.OperationsScriptFolder)
				select Path.GetFileNameWithoutExtension(_).ToLower()).Contains(macroName))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x0600064D RID: 1613 RVA: 0x000061E5 File Offset: 0x000043E5
		private void ShowMacroImportWizard()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mOverlayGrid.Visibility = Visibility.Visible;
				if (this.mImportMacroWindow == null)
				{
					this.mImportMacroWindow = new ImportMacroWindow(this, this.ParentWindow);
					this.mImportMacroWindow.Owner = this;
					this.mImportMacroWindow.Init();
					this.mImportMacroWindow.Show();
				}
			}), new object[0]);
		}

		// Token: 0x0600064E RID: 1614 RVA: 0x00006205 File Offset: 0x00004405
		private void MImportBtn_Click(object sender, RoutedEventArgs e)
		{
			CommonHandlers.RefreshAllOperationRecorderWindowWithScroll();
		}

		// Token: 0x0600064F RID: 1615 RVA: 0x00027D30 File Offset: 0x00025F30
		private void mBGMacroPlaybackWorker_DoWork(object sender, DoWorkEventArgs e, BackgroundWorker bg, OperationsRecord record)
		{
			if (File.Exists(Path.Combine(RegistryStrings.OperationsScriptFolder, record.Name + ".json")) && !this.ParentWindow.mIsMacroPlaying)
			{
				Logger.Debug("Macro Playback started");
				this.ParentWindow.mIsMacroPlaying = true;
				this.ParentWindow.mFrontendHandler.SendFrontendRequest("startMacroPlayback", new Dictionary<string, string>
				{
					{
						"scriptFilePath",
						Path.Combine(RegistryStrings.OperationsScriptFolder, record.Name + ".json")
					}
				});
				switch (record.LoopType)
				{
				case OperationsLoopType.TillLoopNumber:
					this.HandleMacroPlaybackTillLoopNumber(bg, record);
					return;
				case OperationsLoopType.TillTime:
					this.HandleMacroPlaybackTillTime(bg, record);
					return;
				case OperationsLoopType.UntilStopped:
					this.HandleMacroPlaybackUntillStopped(bg, record);
					break;
				default:
					return;
				}
			}
		}

		// Token: 0x06000650 RID: 1616 RVA: 0x00027E04 File Offset: 0x00026004
		internal void RunMacroOperation(OperationsRecord record)
		{
			BackgroundWorker bg = new BackgroundWorker();
			bg.WorkerSupportsCancellation = true;
			bg.DoWork += delegate(object obj, DoWorkEventArgs e)
			{
				this.mBGMacroPlaybackWorker_DoWork(obj, e, bg, record);
			};
			this.mBGMacroPlaybackWorker = bg;
			bg.RunWorkerAsync();
		}

		// Token: 0x06000651 RID: 1617 RVA: 0x00027E6C File Offset: 0x0002606C
		private void HandleMacroPlaybackUntillStopped(BackgroundWorker bg, OperationsRecord record)
		{
			try
			{
				EventWaitHandle eventWaitHandle = null;
				string macroPlaybackEventName = BlueStacksUIUtils.GetMacroPlaybackEventName(this.ParentWindow.mVmName);
				this.ParentWindow.mCommonHandler.InitUiOnMacroPlayback(record);
				int num = 1;
				this.UpdateMacroPlayBackUI(num, record);
				while (this.ParentWindow.mIsMacroPlaying && !bg.CancellationPending)
				{
					this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("runMacroUnit", null);
					if (eventWaitHandle == null)
					{
						eventWaitHandle = new EventWaitHandle(false, EventResetMode.AutoReset, macroPlaybackEventName);
					}
					this.UpdateMacroPlayBackUI(num, record);
					num++;
					eventWaitHandle.WaitOne();
					Thread.Sleep(record.LoopInterval * 1000);
				}
				eventWaitHandle.Close();
			}
			catch (Exception ex)
			{
				Logger.Error("Error in macroplaybackuntil stopped. err:" + ex.ToString());
			}
		}

		// Token: 0x06000652 RID: 1618 RVA: 0x00027F34 File Offset: 0x00026134
		private void HandleMacroPlaybackTillTime(BackgroundWorker bg, OperationsRecord record)
		{
			try
			{
				if (record.LoopTime > 0)
				{
					EventWaitHandle eventWaitHandle = null;
					string macroPlaybackEventName = BlueStacksUIUtils.GetMacroPlaybackEventName(this.ParentWindow.mVmName);
					this.mMacroLoopTimer = new System.Timers.Timer((double)record.LoopTime);
					this.mMacroLoopTimer.Interval = (double)(record.LoopTime * 1000);
					this.mMacroLoopTimer.Elapsed += delegate(object sender, ElapsedEventArgs e)
					{
						this.MacroLoopTimer_Elapsed(sender, e, record.Name);
					};
					DateTime now = DateTime.Now;
					TimeSpan timeSpan = DateTime.Now - now;
					this.ParentWindow.mCommonHandler.InitUiOnMacroPlayback(record);
					this.mMacroLoopTimer.Enabled = true;
					int i = 1;
					this.UpdateMacroPlayBackUI(i, record);
					while (timeSpan.TotalSeconds < (double)record.LoopTime && this.ParentWindow.mIsMacroPlaying && !bg.CancellationPending)
					{
						this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("runMacroUnit", null);
						if (eventWaitHandle == null)
						{
							eventWaitHandle = new EventWaitHandle(false, EventResetMode.AutoReset, macroPlaybackEventName);
						}
						eventWaitHandle.WaitOne();
						Thread.Sleep(record.LoopInterval * 1000);
						timeSpan = DateTime.Now - now;
					}
					eventWaitHandle.Close();
				}
				else
				{
					this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_TIMER_SET", false), 4.0, true);
					Logger.Debug("Macro timer set to ZERO");
					this.SendStopMacroEventsAndUpdateUi(record.Name);
				}
				if (this.mMacroLoopTimer != null)
				{
					this.mMacroLoopTimer.Enabled = false;
					this.mMacroLoopTimer = null;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in MacroPlaybacktillTime. err:" + ex.ToString());
			}
		}

		// Token: 0x06000653 RID: 1619 RVA: 0x0000620C File Offset: 0x0000440C
		private void MacroLoopTimer_Elapsed(object sender, ElapsedEventArgs e, string fileName)
		{
			Logger.Debug("Macro timer finished");
			this.SendStopMacroEventsAndUpdateUi(fileName);
		}

		// Token: 0x06000654 RID: 1620 RVA: 0x00028120 File Offset: 0x00026320
		private void SendStopMacroEventsAndUpdateUi(string fileName)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.ParentWindow.mCommonHandler.StopMacroScriptHandling();
				if (FeatureManager.Instance.IsCustomUIForNCSoft)
				{
					this.ParentWindow.mNCTopBar.mMacroPlayControl.OnScriptStopEvent(fileName);
					return;
				}
				this.ParentWindow.mTopBar.mMacroPlayControl.OnScriptStopEvent(fileName);
			}), new object[0]);
		}

		// Token: 0x06000655 RID: 1621 RVA: 0x00028164 File Offset: 0x00026364
		private void HandleMacroPlaybackTillLoopNumber(BackgroundWorker bg, OperationsRecord record)
		{
			try
			{
				string macroPlaybackEventName = BlueStacksUIUtils.GetMacroPlaybackEventName(this.ParentWindow.mVmName);
				if (record.LoopNumber >= 1)
				{
					this.ParentWindow.mCommonHandler.InitUiOnMacroPlayback(record);
				}
				else
				{
					this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_LOOP_ITERATION_SET", false), 4.0, true);
					Logger.Debug("Macro loop iterations set to ZERO");
				}
				EventWaitHandle eventWaitHandle = new EventWaitHandle(false, EventResetMode.AutoReset, macroPlaybackEventName);
				int num = 1;
				while (num <= record.LoopNumber && this.ParentWindow.mIsMacroPlaying && !bg.CancellationPending)
				{
					this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("runMacroUnit", null);
					this.UpdateMacroPlayBackUI(num, record);
					eventWaitHandle.WaitOne();
					if (num != record.LoopNumber)
					{
						Thread.Sleep(record.LoopInterval * 1000);
					}
					num++;
				}
				eventWaitHandle.Close();
				if (!bg.CancellationPending && this.ParentWindow.mIsMacroPlaying)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						this.ParentWindow.mCommonHandler.StopMacroPlaybackOperation();
						if (FeatureManager.Instance.IsCustomUIForNCSoft)
						{
							this.ParentWindow.mNCTopBar.mMacroPlayControl.OnScriptStopEvent(record.Name);
							return;
						}
						this.ParentWindow.mTopBar.mMacroPlayControl.OnScriptStopEvent(record.Name);
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception err: " + ex.ToString());
			}
		}

		// Token: 0x06000656 RID: 1622 RVA: 0x000282E4 File Offset: 0x000264E4
		private void UpdateMacroPlayBackUI(int i, OperationsRecord record)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (record.LoopType == OperationsLoopType.TillLoopNumber)
				{
					if (FeatureManager.Instance.IsCustomUIForNCSoft)
					{
						this.ParentWindow.mNCTopBar.mMacroPlayControl.mTimerDisplay.Visibility = Visibility.Collapsed;
						this.ParentWindow.mNCTopBar.mMacroPlayControl.mRunningIterations.Visibility = Visibility.Visible;
						this.ParentWindow.mNCTopBar.mMacroPlayControl.IncreaseIteration(i);
						return;
					}
					this.ParentWindow.mTopBar.mMacroPlayControl.mTimerDisplay.Visibility = Visibility.Collapsed;
					this.ParentWindow.mTopBar.mMacroPlayControl.mRunningIterations.Visibility = Visibility.Visible;
					this.ParentWindow.mTopBar.mMacroPlayControl.IncreaseIteration(i);
					return;
				}
				else if (record.LoopType == OperationsLoopType.TillTime)
				{
					if (FeatureManager.Instance.IsCustomUIForNCSoft)
					{
						this.ParentWindow.mNCTopBar.mMacroPlayControl.UpdateUiForIterationTillTime();
						return;
					}
					this.ParentWindow.mTopBar.mMacroPlayControl.UpdateUiForIterationTillTime();
					return;
				}
				else
				{
					if (FeatureManager.Instance.IsCustomUIForNCSoft)
					{
						this.ParentWindow.mNCTopBar.mMacroPlayControl.UpdateUiMacroPlaybackForInfiniteTime(i);
						return;
					}
					this.ParentWindow.mTopBar.mMacroPlayControl.UpdateUiMacroPlaybackForInfiniteTime(i);
					return;
				}
			}), new object[0]);
		}

		// Token: 0x06000657 RID: 1623 RVA: 0x00028330 File Offset: 0x00026530
		private void OpenFolder_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			try
			{
				if (!Directory.Exists(RegistryStrings.OperationsScriptFolder))
				{
					Directory.CreateDirectory(RegistryStrings.OperationsScriptFolder);
				}
				new Process
				{
					StartInfo = 
					{
						UseShellExecute = true,
						FileName = RegistryStrings.OperationsScriptFolder
					}
				}.Start();
			}
			catch (Exception ex)
			{
				Logger.Error("Some error in Open folder err: " + ex.ToString());
			}
		}

		// Token: 0x06000658 RID: 1624 RVA: 0x000283A8 File Offset: 0x000265A8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/operationrecorderwindow.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000659 RID: 1625 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600065A RID: 1626 RVA: 0x000283D8 File Offset: 0x000265D8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mOperationRecorderBorder = (Border)target;
				return;
			case 2:
				this.mMaskBorder = (Border)target;
				return;
			case 3:
				((Grid)target).MouseDown += this.Topbar_MouseDown;
				return;
			case 4:
				((CustomPictureBox)target).MouseLeftButtonUp += this.Close_MouseLeftButtonUp;
				return;
			case 5:
				this.mImport = (CustomPictureBox)target;
				this.mImport.MouseLeftButtonUp += this.ImportBtn_Click;
				return;
			case 6:
				this.mExport = (CustomPictureBox)target;
				this.mExport.MouseLeftButtonUp += this.ExportBtn_Click;
				return;
			case 7:
				this.mOpenFolder = (CustomPictureBox)target;
				this.mOpenFolder.MouseLeftButtonUp += this.OpenFolder_MouseLeftButtonUp;
				return;
			case 8:
				this.mStartMacroRecordingBtn = (CustomButton)target;
				this.mStartMacroRecordingBtn.Click += this.mStartMacroRecordingBtn_Click;
				return;
			case 9:
				this.mStopMacroRecordingBtn = (CustomButton)target;
				this.mStopMacroRecordingBtn.Click += this.mStopMacroRecordingBtn_Click;
				return;
			case 10:
				this.mNoScriptsGrid = (Grid)target;
				return;
			case 11:
				this.mScriptsListScrollbar = (ScrollViewer)target;
				return;
			case 12:
				this.mLoadingGrid = (BlueStacks.BlueStacksUI.ProgressBar)target;
				return;
			case 13:
				this.mOverlayGrid = (Grid)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000408 RID: 1032
		private MainWindow ParentWindow;

		// Token: 0x04000409 RID: 1033
		internal string mMacroOnRestart;

		// Token: 0x0400040A RID: 1034
		internal StackPanel mScriptsStackPanel;

		// Token: 0x0400040B RID: 1035
		private System.Timers.Timer mMacroLoopTimer;

		// Token: 0x0400040C RID: 1036
		internal ExportMacroWindow mExportMacroWindow;

		// Token: 0x0400040D RID: 1037
		internal ImportMacroWindow mImportMacroWindow;

		// Token: 0x0400040E RID: 1038
		internal List<OperationsRecord> mRenamingMacrosList = new List<OperationsRecord>();

		// Token: 0x0400040F RID: 1039
		private bool mIsExportClicked;

		// Token: 0x04000410 RID: 1040
		internal BackgroundWorker mBGMacroPlaybackWorker;

		// Token: 0x04000411 RID: 1041
		internal Border mOperationRecorderBorder;

		// Token: 0x04000412 RID: 1042
		internal Border mMaskBorder;

		// Token: 0x04000413 RID: 1043
		internal CustomPictureBox mImport;

		// Token: 0x04000414 RID: 1044
		internal CustomPictureBox mExport;

		// Token: 0x04000415 RID: 1045
		internal CustomPictureBox mOpenFolder;

		// Token: 0x04000416 RID: 1046
		internal CustomButton mStartMacroRecordingBtn;

		// Token: 0x04000417 RID: 1047
		internal CustomButton mStopMacroRecordingBtn;

		// Token: 0x04000418 RID: 1048
		internal Grid mNoScriptsGrid;

		// Token: 0x04000419 RID: 1049
		internal ScrollViewer mScriptsListScrollbar;

		// Token: 0x0400041A RID: 1050
		internal BlueStacks.BlueStacksUI.ProgressBar mLoadingGrid;

		// Token: 0x0400041B RID: 1051
		internal Grid mOverlayGrid;

		// Token: 0x0400041C RID: 1052
		private bool _contentLoaded;

		// Token: 0x0200008B RID: 139
		public enum ImportExitcodes
		{
			// Token: 0x0400041E RID: 1054
			Success,
			// Token: 0x0400041F RID: 1055
			FileFormatNotSupported,
			// Token: 0x04000420 RID: 1056
			ShowImportWizard
		}
	}
}
