﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000BF RID: 191
	public class SpeedUpBlueStacks : UserControl, IComponentConnector
	{
		// Token: 0x060007A6 RID: 1958 RVA: 0x00006F33 File Offset: 0x00005133
		public SpeedUpBlueStacks()
		{
			this.InitializeComponent();
			this.SetUrl();
			this.SetContent();
		}

		// Token: 0x060007A7 RID: 1959 RVA: 0x00030168 File Offset: 0x0002E368
		private void SetUrl()
		{
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				this.mEnableVt.mHyperLink.NavigateUri = new Uri("http://help.dmm.com/-/detail/=/qid=45997/");
				this.mUpgradeComputer.mHyperLink.NavigateUri = new Uri("http://help.dmm.com/-/detail/=/qid=45997/");
				this.mConfigureAntivirus.mHyperLink.NavigateUri = new Uri("http://help.dmm.com/-/detail/=/qid=45997/");
				this.mDiasbleHyperV.mHyperLink.NavigateUri = new Uri("http://help.dmm.com/-/detail/=/qid=45997/");
				this.mPowerPlan.mHyperLink.NavigateUri = new Uri("http://help.dmm.com/-/detail/=/qid=45997/");
				return;
			}
			string str = WebHelper.GetUrlWithParams(string.Format("{0}/{1}", WebHelper.GetServerHost(), "help_articles")) + "&article=";
			this.mEnableVt.mHyperLink.NavigateUri = new Uri(str + "enable_virtualization");
			this.mUpgradeComputer.mHyperLink.NavigateUri = new Uri(str + "bs3_nougat_min_requirements");
			this.mConfigureAntivirus.mHyperLink.NavigateUri = new Uri(str + "disable_antivirus");
			this.mDiasbleHyperV.mHyperLink.NavigateUri = new Uri(str + "disable_hypervisor");
			this.mPowerPlan.mHyperLink.NavigateUri = new Uri(str + "change_powerplan");
		}

		// Token: 0x060007A8 RID: 1960 RVA: 0x000302CC File Offset: 0x0002E4CC
		private void SetContent()
		{
			BlueStacksUIBinding.Bind(this.mEnableVt.mTitleText, "STRING_ENABLE_VIRT", "");
			BlueStacksUIBinding.Bind(this.mEnableVt.mBodyText, "STRING_ENABLE_VIRT_BODY", "");
			this.mEnableVt.mHyperLink.Inlines.Clear();
			this.mEnableVt.mHyperLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_ENABLE_VIRT_HYPERLINK", false));
			this.mEnableVt.mImage.ImageName = "virtualization";
			BlueStacksUIBinding.Bind(this.mDiasbleHyperV.mTitleText, "STRING_DISABLE_HYPERV", "");
			BlueStacksUIBinding.Bind(this.mDiasbleHyperV.mBodyText, "STRING_DISABLE_HYPERV_BODY", "");
			this.mDiasbleHyperV.mHyperLink.Inlines.Clear();
			this.mDiasbleHyperV.mHyperLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_DISABLE_HYPERV_HYPERLINK", false));
			this.mDiasbleHyperV.mImage.ImageName = "hypervisor";
			BlueStacksUIBinding.Bind(this.mConfigureAntivirus.mTitleText, "STRING_CONFIGURE_ANTIVIRUS", "");
			BlueStacksUIBinding.Bind(this.mConfigureAntivirus.mBodyText, "STRING_CONFIGURE_ANTIVIRUS_BODY", "");
			this.mConfigureAntivirus.mHyperLink.Inlines.Clear();
			this.mConfigureAntivirus.mHyperLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_CONFIGURE_ANTIVIRUS_HYPERLINK", false));
			this.mConfigureAntivirus.mImage.ImageName = "antivirus";
			BlueStacksUIBinding.Bind(this.mPowerPlan.mTitleText, "STRING_POWER_PLAN", "");
			BlueStacksUIBinding.Bind(this.mPowerPlan.mBodyText, "STRING_POWER_PLAN_BODY", "");
			this.mPowerPlan.mHyperLink.Inlines.Clear();
			this.mPowerPlan.mHyperLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_POWER_PLAN_HYPERLINK", false));
			this.mPowerPlan.mImage.ImageName = "powerplan";
			BlueStacksUIBinding.Bind(this.mUpgradeComputer.mTitleText, "STRING_UPGRADE_SYSTEM", "");
			BlueStacksUIBinding.Bind(this.mUpgradeComputer.mBodyText, "STRING_UPGRADE_SYSTEM_BODY", "");
			this.mUpgradeComputer.mHyperLink.Inlines.Clear();
			this.mUpgradeComputer.mHyperLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_UPGRADE_SYSTEM_HYPERLINK", false));
			this.mUpgradeComputer.mImage.ImageName = "upgrade";
		}

		// Token: 0x060007A9 RID: 1961 RVA: 0x00006F4D File Offset: 0x0000514D
		private void CloseBtn_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked close button speedUpBluestacks");
			BlueStacksUIUtils.CloseContainerWindow(this);
		}

		// Token: 0x060007AA RID: 1962 RVA: 0x00030550 File Offset: 0x0002E750
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/speedupbluestacks.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060007AB RID: 1963 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060007AC RID: 1964 RVA: 0x00030580 File Offset: 0x0002E780
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.CloseBtn = (CustomPictureBox)target;
				this.CloseBtn.PreviewMouseLeftButtonUp += this.CloseBtn_PreviewMouseLeftButtonUp;
				return;
			case 2:
				this.mEnableVt = (SpeedUpBluestacksUserControl)target;
				return;
			case 3:
				this.mConfigureAntivirus = (SpeedUpBluestacksUserControl)target;
				return;
			case 4:
				this.mDiasbleHyperV = (SpeedUpBluestacksUserControl)target;
				return;
			case 5:
				this.mPowerPlan = (SpeedUpBluestacksUserControl)target;
				return;
			case 6:
				this.mUpgradeComputer = (SpeedUpBluestacksUserControl)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000580 RID: 1408
		internal CustomPictureBox CloseBtn;

		// Token: 0x04000581 RID: 1409
		internal SpeedUpBluestacksUserControl mEnableVt;

		// Token: 0x04000582 RID: 1410
		internal SpeedUpBluestacksUserControl mConfigureAntivirus;

		// Token: 0x04000583 RID: 1411
		internal SpeedUpBluestacksUserControl mDiasbleHyperV;

		// Token: 0x04000584 RID: 1412
		internal SpeedUpBluestacksUserControl mPowerPlan;

		// Token: 0x04000585 RID: 1413
		internal SpeedUpBluestacksUserControl mUpgradeComputer;

		// Token: 0x04000586 RID: 1414
		private bool _contentLoaded;
	}
}
