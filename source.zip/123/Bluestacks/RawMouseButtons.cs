﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000ED RID: 237
	[Flags]
	public enum RawMouseButtons : ushort
	{
		// Token: 0x0400074D RID: 1869
		None = 0,
		// Token: 0x0400074E RID: 1870
		LeftDown = 1,
		// Token: 0x0400074F RID: 1871
		LeftUp = 2,
		// Token: 0x04000750 RID: 1872
		RightDown = 4,
		// Token: 0x04000751 RID: 1873
		RightUp = 8,
		// Token: 0x04000752 RID: 1874
		MiddleDown = 16,
		// Token: 0x04000753 RID: 1875
		MiddleUp = 32,
		// Token: 0x04000754 RID: 1876
		Button4Down = 64,
		// Token: 0x04000755 RID: 1877
		Button4Up = 128,
		// Token: 0x04000756 RID: 1878
		Button5Down = 256,
		// Token: 0x04000757 RID: 1879
		Button5Up = 512,
		// Token: 0x04000758 RID: 1880
		MouseWheel = 1024
	}
}
