﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000D0 RID: 208
	public class GameControlWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x06000871 RID: 2161 RVA: 0x00035248 File Offset: 0x00033448
		internal GameControlWindow(MainWindow window)
		{
			this.ParentWindow = window;
			this.mGuidanceVideoElement = new GuidanceVideoElement(this.ParentWindow);
			this.InitializeComponent();
			this.mGuidanceKeyPanel = (this.mGuidanceKeyScrollBar.Content as StackPanel);
			this.mGuidanceCategoryPanel = (this.mGuidanceCategoryScrollBar.Content as StackPanel);
			base.KeyDown += this.GameControlWindow_KeyDown;
			this.mShortcutLabel.Text = string.Format(LocaleStrings.GetLocalizedString("STRING_GAME_CONTROLS_WINDOW_FOOTER1", false), this.ParentWindow.mCommonHandler.GetShortcutKeyFromName("STRING_TOGGLE_KEYMAP_WINDOW", false));
		}

		// Token: 0x06000872 RID: 2162 RVA: 0x000352F4 File Offset: 0x000334F4
		private void GameControlWindow_KeyDown(object sender, KeyEventArgs e)
		{
			string text = string.Empty;
			if (e.Key != Key.None)
			{
				if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
				{
					text = IMAPKeys.GetStringForFile(Key.LeftCtrl) + " + ";
				}
				if (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt))
				{
					text = text + IMAPKeys.GetStringForFile(Key.LeftAlt) + " + ";
				}
				if (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift))
				{
					text = text + IMAPKeys.GetStringForFile(Key.LeftShift) + " + ";
				}
				text += IMAPKeys.GetStringForFile(e.Key);
			}
			Logger.Debug("SHORTCUT: KeyPressed.." + text);
			if (this.ParentWindow.mCommonHandler.mShortcutsConfigInstance != null)
			{
				foreach (ShortcutKeys shortcutKeys in this.ParentWindow.mCommonHandler.mShortcutsConfigInstance.Shortcut)
				{
					if (shortcutKeys.ShortcutKey.Equals(text) && shortcutKeys.ShortcutName.Equals("STRING_TOGGLE_KEYMAP_WINDOW"))
					{
						KMManager.HideKeymapWindowIfInView();
					}
				}
			}
		}

		// Token: 0x06000873 RID: 2163 RVA: 0x00035428 File Offset: 0x00033628
		private void AddElementsInUI()
		{
			foreach (AppInfo appInfo in new JsonParser(Strings.CurrentDefaultVmName).GetAppList().ToList<AppInfo>())
			{
				if (appInfo.package.Equals(KMManager.sPackageName))
				{
					this.mIsGuidanceVideoPresent = appInfo.videopresent;
				}
			}
			this.UpdateVideoElement(this.mIsGamePadTabSelected);
			this.AddVideoCategory();
			this.UpdateVideoElement(this.mIsGamePadTabSelected);
			foreach (KeyValuePair<string, Tuple<TextBlock, GroupBox, List<FrameworkElement>>> keyValuePair in this.mUIElements)
			{
				this.mGuidanceCategoryPanel.Children.Add(keyValuePair.Value.Item1);
				this.mGuidanceKeyPanel.Children.Add(keyValuePair.Value.Item2);
				foreach (FrameworkElement element in keyValuePair.Value.Item3)
				{
					(keyValuePair.Value.Item2.Content as StackPanel).Children.Add(element);
				}
			}
			this.mUIElements.First<KeyValuePair<string, Tuple<TextBlock, GroupBox, List<FrameworkElement>>>>().Value.Item2.Margin = new Thickness(0.0);
			this.HideEmptyCategories();
		}

		// Token: 0x06000874 RID: 2164 RVA: 0x000355D4 File Offset: 0x000337D4
		internal void FillProfileComboBox()
		{
			if (this.ParentWindow.SelectedConfig.ControlSchemes != null && this.ParentWindow.SelectedConfig.ControlSchemes.Count > 0)
			{
				this.mSchemesComboBox.Items.Clear();
				this.ParentWindow.SelectedConfig.ControlSchemesDict.Clear();
				ComboBoxItem comboBoxItem = null;
				foreach (IMControlScheme imcontrolScheme in this.ParentWindow.SelectedConfig.ControlSchemes)
				{
					ComboBoxItem comboBoxItem2 = new ComboBoxItem();
					comboBoxItem2.Content = LocaleStrings.GetLocalizedString(imcontrolScheme.Name, false);
					if (imcontrolScheme.Selected)
					{
						comboBoxItem = comboBoxItem2;
					}
					comboBoxItem2.ToolTip = comboBoxItem2.Content;
					this.mSchemesComboBox.Items.Add(comboBoxItem2);
					this.ParentWindow.SelectedConfig.ControlSchemesDict[imcontrolScheme.Name] = imcontrolScheme;
				}
				if (comboBoxItem == null)
				{
					comboBoxItem = (this.mSchemesComboBox.Items[0] as ComboBoxItem);
				}
				this.mSchemesComboBox.SelectedItem = comboBoxItem;
			}
			if (this.ParentWindow.SelectedConfig.ControlSchemes != null && this.ParentWindow.SelectedConfig.ControlSchemes.Count > 1)
			{
				this.mSchemesComboBox.Visibility = Visibility.Visible;
				return;
			}
			this.mSchemesComboBox.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000875 RID: 2165 RVA: 0x00035748 File Offset: 0x00033948
		private void AddVideoCategory()
		{
			if (!this.mGuidanceKeyPanel.Children.Contains(this.mGuidanceVideoElement))
			{
				GroupBox groupBox = new GroupBox();
				groupBox.Content = new StackPanel();
				groupBox.Header = LocaleStrings.GetLocalizedString("STRING_AAVideo", false);
				groupBox.Tag = "AAVideo";
				groupBox.Padding = new Thickness(0.0, 0.0, 0.0, 3.0);
				groupBox.FontSize = 12.0;
				groupBox.FontWeight = FontWeights.Bold;
				BlueStacksUIBinding.BindColor(groupBox, Control.ForegroundProperty, "GameControlSelectedCategoryHeaderForeground");
				groupBox.BorderThickness = new Thickness(0.0);
				this.mGuidanceKeyPanel.Children.Add(groupBox);
				this.mGuidanceVideoElement.Visibility = Visibility.Visible;
				this.mGuidanceKeyPanel.Children.Add(this.mGuidanceVideoElement);
				TextBlock textBlock = new TextBlock();
				textBlock.Text = LocaleStrings.GetLocalizedString("STRING_AAVideo", false);
				textBlock.Tag = "AAVideo";
				textBlock.FontSize = 12.0;
				textBlock.FontStretch = FontStretches.ExtraExpanded;
				textBlock.HorizontalAlignment = HorizontalAlignment.Center;
				textBlock.Margin = new Thickness(30.0, 10.0, 30.0, 10.0);
				textBlock.TextWrapping = TextWrapping.WrapWithOverflow;
				BlueStacksUIBinding.BindColor(textBlock, TextBlock.ForegroundProperty, "GameControlSelectedCategoryHeaderForeground");
				textBlock.FontWeight = FontWeights.Bold;
				textBlock.MouseUp += this.VideoCategoryLabel_MouseUp;
				this.mGuidanceCategoryPanel.Children.Add(textBlock);
			}
		}

		// Token: 0x06000876 RID: 2166 RVA: 0x0000764F File Offset: 0x0000584F
		private void VideoCategoryLabel_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.mGuidanceKeyScrollBar.ScrollToBottom();
			this.mGuidanceVideoElement.BringIntoView();
		}

		// Token: 0x06000877 RID: 2167 RVA: 0x000358F8 File Offset: 0x00033AF8
		private void UpdateVideoElement(bool isGamepadTabSelected = false)
		{
			bool isShow = false;
			this.CreateCategory("AAVideo");
			if (isGamepadTabSelected)
			{
				BlueStacksUIBinding.Bind(this.mGuidanceVideoElement.mBodyTextBlock, "IMAP_Gamepad_Video_Element_Body", "");
				BlueStacksUIBinding.Bind(this.mGuidanceVideoElement.mHeaderTextBlock, "IMAP_Gamepad_Video_Element_Header", "");
				KMManager.sVideoMode = "gamepad";
				isShow = true;
			}
			else if (this.mIsGuidanceVideoPresent)
			{
				BlueStacksUIBinding.Bind(this.mGuidanceVideoElement.mBodyTextBlock, "IMAP_Video_Element_Body", "");
				BlueStacksUIBinding.Bind(this.mGuidanceVideoElement.mHeaderTextBlock, "IMAP_Video_Element_Header", "");
				KMManager.sVideoMode = "special";
				isShow = true;
			}
			else if (this.lstMOBATags != null && (this.lstMOBATags.Contains(this.ParentWindow.SelectedConfig.SelectedControlScheme.Name) || this.lstMOBATags.Contains("GlobalValidTag")))
			{
				BlueStacksUIBinding.Bind(this.mGuidanceVideoElement.mBodyTextBlock, "IMAP_MOBA_Video_Element_Body", "");
				BlueStacksUIBinding.Bind(this.mGuidanceVideoElement.mHeaderTextBlock, "IMAP_MOBA_Video_Element_Header", "");
				KMManager.sVideoMode = "moba";
				isShow = true;
			}
			else if (this.lstPanTags != null && (this.lstPanTags.Contains(this.ParentWindow.SelectedConfig.SelectedControlScheme.Name) || this.lstPanTags.Contains("GlobalValidTag")))
			{
				BlueStacksUIBinding.Bind(this.mGuidanceVideoElement.mBodyTextBlock, "IMAP_Pan_Video_Element_Body", "");
				BlueStacksUIBinding.Bind(this.mGuidanceVideoElement.mHeaderTextBlock, "IMAP_Pan_Video_Element_Header", "");
				KMManager.sVideoMode = "pan";
				isShow = true;
			}
			this.UpdateTutorialCategory(isShow);
		}

		// Token: 0x06000878 RID: 2168 RVA: 0x00035AA8 File Offset: 0x00033CA8
		private void UpdateTutorialCategory(bool isShow)
		{
			try
			{
				foreach (object obj in this.mGuidanceCategoryPanel.Children)
				{
					if (obj != null && (obj as TextBlock).Tag.Equals("AAVideo"))
					{
						if (isShow)
						{
							(obj as TextBlock).Visibility = Visibility.Visible;
							break;
						}
						(obj as TextBlock).Visibility = Visibility.Collapsed;
						break;
					}
				}
				foreach (object obj2 in this.mGuidanceKeyPanel.Children)
				{
					if (obj2 != null && (obj2 as GroupBox).Tag.Equals("AAVideo"))
					{
						if (isShow)
						{
							(obj2 as GroupBox).Visibility = Visibility.Visible;
							this.mGuidanceVideoElement.Visibility = Visibility.Visible;
							break;
						}
						(obj2 as GroupBox).Visibility = Visibility.Collapsed;
						this.mGuidanceVideoElement.Visibility = Visibility.Collapsed;
						break;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception updating video category: " + ex.ToString());
			}
		}

		// Token: 0x06000879 RID: 2169 RVA: 0x00035BF0 File Offset: 0x00033DF0
		private void HideEmptyCategories()
		{
			foreach (Tuple<TextBlock, GroupBox, List<FrameworkElement>> tuple in this.mUIElements.Values)
			{
				tuple.Item1.Visibility = Visibility.Collapsed;
				tuple.Item2.Visibility = Visibility.Collapsed;
				using (List<FrameworkElement>.Enumerator enumerator2 = tuple.Item3.GetEnumerator())
				{
					while (enumerator2.MoveNext())
					{
						if (enumerator2.Current.Visibility == Visibility.Visible)
						{
							tuple.Item1.Visibility = Visibility.Visible;
							tuple.Item2.Visibility = Visibility.Visible;
							break;
						}
					}
				}
			}
		}

		// Token: 0x0600087A RID: 2170 RVA: 0x00035CB4 File Offset: 0x00033EB4
		internal bool Init()
		{
			this.mGuidanceKeyScrollBar.ScrollToTop();
			base.Height = this.ParentWindow.ActualHeight * 0.8;
			this.mUIElements.Clear();
			this.mGuidanceCategoryPanel.Children.Clear();
			this.mGuidanceKeyPanel.Children.Clear();
			this.mGuidanceCategoryPanel.MinWidth = 0.0;
			this.mAutoShowGuidanceCheckBox.IsChecked = new bool?(RegistryManager.Instance.IsAutoShowGuidance);
			if (this.InitUI())
			{
				this.FillProfileComboBox();
				return true;
			}
			return false;
		}

		// Token: 0x0600087B RID: 2171 RVA: 0x00035D54 File Offset: 0x00033F54
		internal bool InitUI()
		{
			bool flag = false;
			this.mIsGamePadTabSelected = false;
			if (KMManager.CheckIfGamepadPresent())
			{
				this.mTabsGrid.Visibility = Visibility.Visible;
			}
			else
			{
				this.mTabsGrid.Visibility = Visibility.Collapsed;
			}
			foreach (IMAction imaction in this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls)
			{
				if (imaction.Type == KeyActionType.Pan)
				{
					if (this.lstPanTags == null)
					{
						this.lstPanTags = new List<string>();
					}
					this.lstPanTags.Add(this.ParentWindow.SelectedConfig.SelectedControlScheme.Name);
				}
				else if (imaction.Type == KeyActionType.MOBADpad)
				{
					if (this.lstMOBATags == null)
					{
						this.lstMOBATags = new List<string>();
					}
					this.lstMOBATags.Add(this.ParentWindow.SelectedConfig.SelectedControlScheme.Name);
				}
				this.CreateCategory(imaction.GuidanceCategory);
				foreach (KeyValuePair<string, PropertyInfo> keyValuePair in IMAction.DictPropertyInfo[imaction.Type])
				{
					if (imaction.Guidance.ContainsKey(keyValuePair.Key) && !this.CheckIfDuplicateGuidanceKey(this.ParentWindow.SelectedConfig.GetUIString(imaction.Guidance[keyValuePair.Key]), imaction[keyValuePair.Key].ToString()) && !string.IsNullOrEmpty(imaction[keyValuePair.Key].ToString()) && !(Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(imaction[keyValuePair.Key].ToString())).Contains("Gamepad") && !keyValuePair.Key.ToString().Contains("Gamepad"))
					{
						GuidanceKeyElement guidanceKeyElement = new GuidanceKeyElement(this.ParentWindow);
						guidanceKeyElement.ActionItemProperty = keyValuePair.Key;
						guidanceKeyElement.lstActionItem = new List<IMAction>
						{
							imaction
						};
						guidanceKeyElement.mGuidenceTextBlock.Text = this.ParentWindow.SelectedConfig.GetUIString(imaction.Guidance[keyValuePair.Key]);
						if (guidanceKeyElement.lstActionItem.First<IMAction>().Type == KeyActionType.MOBASkill && guidanceKeyElement.ActionItemProperty.Contains("KeyActivate"))
						{
							string text = this.AppendMOBASkillModeInGuidance(guidanceKeyElement.lstActionItem.First<IMAction>());
							if (!string.IsNullOrEmpty(text))
							{
								TextBlock mGuidenceTextBlock = guidanceKeyElement.mGuidenceTextBlock;
								mGuidenceTextBlock.Text += text;
							}
						}
						guidanceKeyElement.mGuidenceTextBlock.Tag = imaction.Guidance[keyValuePair.Key];
						guidanceKeyElement.mKeyTextBox.Tag = imaction[keyValuePair.Key];
						BlueStacksUIBinding.Bind(guidanceKeyElement.mKeyTextBox, KMManager.GetStringsToShowInUI(imaction[keyValuePair.Key].ToString()));
						this.mUIElements[imaction.GuidanceCategory].Item3.Add(guidanceKeyElement);
						flag = true;
					}
				}
			}
			if (flag)
			{
				this.AddElementsInUI();
			}
			else
			{
				this.mUIElements.Clear();
				this.mGuidanceCategoryPanel.Children.Clear();
				this.mGuidanceKeyPanel.Children.Clear();
			}
			return flag;
		}

		// Token: 0x0600087C RID: 2172 RVA: 0x000360F0 File Offset: 0x000342F0
		private string AppendMOBASkillModeInGuidance(IMAction action)
		{
			string result = string.Empty;
			if (!((MOBASkill)action).AdvancedMode && !((MOBASkill)action).AutocastEnabled)
			{
				result = string.Format(" (" + LocaleStrings.GetLocalizedString("STRING_MANUAL_MODE", false) + ")", new object[0]);
			}
			else if (((MOBASkill)action).AdvancedMode && !((MOBASkill)action).AutocastEnabled)
			{
				result = string.Format(" (" + LocaleStrings.GetLocalizedString("STRING_AUTOCAST", false) + ")", new object[0]);
			}
			else if (((MOBASkill)action).AdvancedMode && ((MOBASkill)action).AutocastEnabled)
			{
				result = string.Format(" (" + LocaleStrings.GetLocalizedString("STRING_QUICK_CAST", false) + ")", new object[0]);
			}
			return result;
		}

		// Token: 0x0600087D RID: 2173 RVA: 0x000361CC File Offset: 0x000343CC
		private bool CheckIfDuplicateGuidanceKey(string name, string key)
		{
			foreach (Tuple<TextBlock, GroupBox, List<FrameworkElement>> tuple in this.mUIElements.Values)
			{
				foreach (FrameworkElement frameworkElement in tuple.Item3)
				{
					GuidanceKeyElement guidanceKeyElement = frameworkElement as GuidanceKeyElement;
					if (guidanceKeyElement != null && guidanceKeyElement.mKeyTextBox.Tag.ToString().Equals(key) && guidanceKeyElement.mGuidenceTextBlock.Text.ToString().Equals(name))
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x0600087E RID: 2174 RVA: 0x00036298 File Offset: 0x00034498
		public void CreateCategory(string name)
		{
			if (!this.mUIElements.ContainsKey(name))
			{
				if (name.Equals("AAVideo"))
				{
					return;
				}
				string text;
				if (name.Equals("MISC"))
				{
					text = LocaleStrings.GetLocalizedString("STRING_" + name, false);
				}
				else
				{
					text = this.ParentWindow.SelectedConfig.GetUIString(name);
				}
				GroupBox groupBox = new GroupBox();
				groupBox.Content = new StackPanel();
				groupBox.Header = text;
				groupBox.Tag = name;
				groupBox.Padding = new Thickness(0.0, 9.0, 0.0, 3.0);
				groupBox.Margin = new Thickness(0.0, 33.0, 0.0, 0.0);
				groupBox.FontSize = 12.0;
				groupBox.FontWeight = FontWeights.Bold;
				BlueStacksUIBinding.BindColor(groupBox, Control.ForegroundProperty, "GameControlSelectedCategoryHeaderForeground");
				groupBox.BorderThickness = new Thickness(0.0);
				TextBlock textBlock = new TextBlock();
				textBlock.Text = text;
				textBlock.Tag = name;
				textBlock.FontSize = 12.0;
				textBlock.FontStretch = FontStretches.ExtraExpanded;
				textBlock.HorizontalAlignment = HorizontalAlignment.Center;
				textBlock.Margin = new Thickness(30.0, 10.0, 30.0, 10.0);
				textBlock.TextWrapping = TextWrapping.WrapWithOverflow;
				BlueStacksUIBinding.BindColor(textBlock, TextBlock.ForegroundProperty, "GameControlCategoryHeaderForeground");
				textBlock.FontWeight = FontWeights.Bold;
				textBlock.MouseUp += this.CategoryLabel_MouseUp;
				this.mUIElements.Add(name, new Tuple<TextBlock, GroupBox, List<FrameworkElement>>(textBlock, groupBox, new List<FrameworkElement>()));
			}
		}

		// Token: 0x0600087F RID: 2175 RVA: 0x00007667 File Offset: 0x00005867
		private void CategoryLabel_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.mGuidanceKeyScrollBar.ScrollToBottom();
			this.mUIElements[(sender as TextBlock).Tag.ToString()].Item2.BringIntoView();
		}

		// Token: 0x06000880 RID: 2176 RVA: 0x00036464 File Offset: 0x00034664
		private void GuidanceKeyScrollBar_ScrollChanged(object sender, ScrollChangedEventArgs e)
		{
			if (this.mGuidanceKeyPanel.Children.Contains(this.mGuidanceVideoElement))
			{
				foreach (object obj in this.mGuidanceCategoryPanel.Children)
				{
					if ((obj as TextBlock).Tag.Equals("AAVideo"))
					{
						Rect rect = this.mGuidanceVideoElement.TransformToAncestor(sender as ScrollViewer).TransformBounds(new Rect(new Point(0.0, 0.0), this.mGuidanceVideoElement.RenderSize));
						if (Rect.Intersect(new Rect(new Point(0.0, 0.0), (sender as ScrollViewer).RenderSize), rect) == Rect.Empty)
						{
							BlueStacksUIBinding.BindColor(obj as TextBlock, TextBlock.ForegroundProperty, "GameControlCategoryHeaderForeground");
						}
						else
						{
							BlueStacksUIBinding.BindColor(obj as TextBlock, TextBlock.ForegroundProperty, "GameControlSelectedCategoryHeaderForeground");
						}
					}
				}
			}
			List<Tuple<TextBlock, GroupBox, List<FrameworkElement>>> list = this.mUIElements.Values.ToList<Tuple<TextBlock, GroupBox, List<FrameworkElement>>>();
			(sender as ScrollViewer).InvalidateVisual();
			if (e.VerticalChange < 0.0)
			{
				list.Reverse();
			}
			foreach (Tuple<TextBlock, GroupBox, List<FrameworkElement>> tuple in list)
			{
				Rect rect2 = tuple.Item2.TransformToAncestor(sender as ScrollViewer).TransformBounds(new Rect(new Point(0.0, 0.0), tuple.Item2.RenderSize));
				if (Rect.Intersect(new Rect(new Point(0.0, 0.0), (sender as ScrollViewer).RenderSize), rect2) == Rect.Empty)
				{
					BlueStacksUIBinding.BindColor(tuple.Item1, TextBlock.ForegroundProperty, "GameControlCategoryHeaderForeground");
				}
				else
				{
					BlueStacksUIBinding.BindColor(tuple.Item1, TextBlock.ForegroundProperty, "GameControlSelectedCategoryHeaderForeground");
					tuple.Item1.BringIntoView();
				}
			}
		}

		// Token: 0x06000881 RID: 2177 RVA: 0x000338D0 File Offset: 0x00031AD0
		private void Grid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			try
			{
				base.DragMove();
			}
			catch
			{
			}
		}

		// Token: 0x06000882 RID: 2178 RVA: 0x00007699 File Offset: 0x00005899
		private void EditKeysButton_Click(object sender, RoutedEventArgs e)
		{
			this.ReloadUIPanels(true);
			ClientStats.SendKeyMappingUIStatsAsync("button_clicked", KMManager.sPackageName, "edit_keys");
		}

		// Token: 0x06000883 RID: 2179 RVA: 0x000076B6 File Offset: 0x000058B6
		private void SaveKeysButton_Click(object sender, RoutedEventArgs e)
		{
			this.ReloadUIPanels(false);
			KMManager.SaveIMActions(true, false);
			this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_SAVE_CHANGES", false));
		}

		// Token: 0x06000884 RID: 2180 RVA: 0x000366C0 File Offset: 0x000348C0
		private void AddToastPopup(string message)
		{
			try
			{
				if (this.mToastPopup == null)
				{
					this.mToastPopup = new CustomToastPopupControl(this);
				}
				this.mToastPopup.Init(this, message, null, null, HorizontalAlignment.Center, VerticalAlignment.Bottom, null, 12, null, null, false);
				this.mToastPopup.ShowPopup(1.3);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in showing toast popup: " + ex.ToString());
			}
		}

		// Token: 0x06000885 RID: 2181 RVA: 0x00036748 File Offset: 0x00034948
		private void ReloadUIPanels(bool isReloadForSaveUI = false)
		{
			this.mGuidanceKeyScrollBar.ScrollToTop();
			Visibility visibility = Visibility.Collapsed;
			Visibility visibility2 = Visibility.Visible;
			if (isReloadForSaveUI)
			{
				visibility = Visibility.Visible;
				visibility2 = Visibility.Collapsed;
			}
			bool flag = isReloadForSaveUI;
			this.mEditButton.Visibility = visibility2;
			this.mViewHeaderTextBlock.Visibility = visibility2;
			this.mGuidanceBottomBar.Visibility = visibility2;
			this.mEditHeaderTextBlock.Visibility = visibility;
			this.mSaveButton.Visibility = visibility;
			this.mTipBottomBar.Visibility = visibility;
			this.mGuidanceCategoryPanel.MinWidth = this.mGuidanceCategoryPanel.ActualWidth;
			foreach (Tuple<TextBlock, GroupBox, List<FrameworkElement>> tuple in this.mUIElements.Values)
			{
				foreach (FrameworkElement frameworkElement in tuple.Item3)
				{
					GuidanceKeyElement guidanceKeyElement = frameworkElement as GuidanceKeyElement;
					if (guidanceKeyElement != null)
					{
						if (guidanceKeyElement.ActionItemProperty.Equals("KeyAction"))
						{
							guidanceKeyElement.Visibility = visibility2;
						}
						else
						{
							guidanceKeyElement.mKeyTextBox.Visibility = visibility;
							guidanceKeyElement.mKeyTextBox1.Visibility = visibility2;
						}
						if (flag)
						{
							flag = false;
							guidanceKeyElement.mKeyTextBox.Focus();
						}
					}
				}
			}
		}

		// Token: 0x06000886 RID: 2182 RVA: 0x000076D7 File Offset: 0x000058D7
		private void AdvancedButton_Click(object sender, RoutedEventArgs e)
		{
			KeymapCanvasWindow.sIsDirty = GameControlWindow.sIsDirty;
			GameControlWindow.sIsDirty = false;
			base.Close();
			KMManager.sGamepadKeyElement = null;
			KMManager.ShowAdvancedSettings(this.ParentWindow);
			ClientStats.SendKeyMappingUIStatsAsync("button_clicked", KMManager.sPackageName, "advanced");
		}

		// Token: 0x06000887 RID: 2183 RVA: 0x00007714 File Offset: 0x00005914
		private void CloseButton_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			base.Close();
			if (RegistryManager.Instance.OverlayAvailablePromptEnabled && !this.ParentWindow.mSidebar.mIsOverlayTooltipClosed)
			{
				this.ParentWindow.mSidebar.ShowOverlayTooltip(true, true);
			}
		}

		// Token: 0x06000888 RID: 2184 RVA: 0x000368A4 File Offset: 0x00034AA4
		internal void CloseWindow(CancelEventArgs evt)
		{
			if (GameControlWindow.sIsDirty)
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_BLUESTACKS_GAME_CONTROLS", false);
				customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_UNSAVED_CHANGES_CLOSE", false);
				customMessageWindow.AddButton(ButtonColors.Blue, LocaleStrings.GetLocalizedString("STRING_YES", false), delegate(object o, EventArgs e)
				{
					KMManager.SaveIMActions(true, false);
				}, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_NO", false), delegate(object o, EventArgs e)
				{
					GameControlWindow.sIsDirty = false;
				}, null, false, null);
				customMessageWindow.CloseButtonHandle(delegate(object o, EventArgs e)
				{
					this.mIsClosing = false;
					evt.Cancel = true;
				}, null);
				customMessageWindow.Owner = this;
				customMessageWindow.ShowDialog();
			}
		}

		// Token: 0x06000889 RID: 2185 RVA: 0x0000774C File Offset: 0x0000594C
		private void Window_Closing(object sender, CancelEventArgs e)
		{
			this.mIsClosing = true;
			this.CloseWindow(e);
		}

		// Token: 0x0600088A RID: 2186 RVA: 0x0000553B File Offset: 0x0000373B
		private void CustomPictureBox_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x0600088B RID: 2187 RVA: 0x00036988 File Offset: 0x00034B88
		private void CustomCheckbox_Checked(object sender, RoutedEventArgs e)
		{
			RegistryManager.Instance.IsAutoShowGuidance = this.mAutoShowGuidanceCheckBox.IsChecked.Value;
		}

		// Token: 0x0600088C RID: 2188 RVA: 0x000369B4 File Offset: 0x00034BB4
		private void ProfileComboBox_ProfileChanged(object sender, SelectionChangedEventArgs e)
		{
			if (this.mSchemesComboBox.SelectedItem != null)
			{
				string text = ((ComboBoxItem)this.mSchemesComboBox.SelectedItem).Content.ToString();
				if (this.ParentWindow.SelectedConfig.ControlSchemesDict.ContainsKey(text) && !this.ParentWindow.SelectedConfig.ControlSchemesDict[text].Selected)
				{
					this.ParentWindow.SelectedConfig.SelectedControlScheme.Selected = false;
					this.ParentWindow.SelectedConfig.SelectedControlScheme = this.ParentWindow.SelectedConfig.ControlSchemesDict[text];
					this.ParentWindow.SelectedConfig.SelectedControlScheme.Selected = true;
					this.mGuidanceKeyScrollBar.ScrollToTop();
					base.Height = this.ParentWindow.ActualHeight * 0.8;
					this.mUIElements.Clear();
					this.mGuidanceCategoryPanel.Children.Clear();
					this.mGuidanceKeyPanel.Children.Clear();
					this.mGuidanceCategoryPanel.MinWidth = 0.0;
					this.InitUI();
					this.ReloadUIPanels(this.mSaveButton.Visibility == Visibility.Visible);
				}
				this.HideEmptyCategories();
				this.UpdateVideoElement(this.mIsGamePadTabSelected);
				if (this.mEditButton.IsVisible)
				{
					GameControlWindow.sIsDirty = true;
					KMManager.SaveIMActions(true, false);
					this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_USING_SCHEME", false) + " : " + text);
				}
			}
		}

		// Token: 0x0600088D RID: 2189 RVA: 0x00036B44 File Offset: 0x00034D44
		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			InteropWindow.RemoveWindowFromAltTabUI(new WindowInteropHelper(this).Handle);
			double num = this.ParentWindow.Left;
			double num2 = this.ParentWindow.Top;
			if (this.ParentWindow.WindowState == WindowState.Maximized)
			{
				num = 0.0;
				num2 = 0.0;
			}
			base.Left = num + (this.ParentWindow.ActualWidth - base.ActualWidth) / 2.0;
			base.Top = num2 + (this.ParentWindow.ActualHeight - base.ActualHeight) / 2.0;
			this.SetPlacement(MainWindow.sScalingFactor);
		}

		// Token: 0x0600088E RID: 2190 RVA: 0x00004BF2 File Offset: 0x00002DF2
		private void gamepadBtn_Click(object sender, RoutedEventArgs e)
		{
		}

		// Token: 0x0600088F RID: 2191 RVA: 0x00036BF0 File Offset: 0x00034DF0
		private void mKeyboardTabBorder_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			bool isVisible = this.mSaveButton.IsVisible;
			this.mGamepadTabBorder.BorderThickness = new Thickness(0.0, 1.0, 1.0, 1.0);
			this.mGamepadTabBorder.Background = Brushes.Transparent;
			BlueStacksUIBinding.BindColor(this.mKeyboardTabBorder, Border.BackgroundProperty, "GuidanceKeyBorderBackgroundColor");
			this.mKeyboardTabBorder.BorderThickness = new Thickness(0.0);
			this.mIsGamePadTabSelected = false;
			this.Init();
			this.ReloadUIPanels(isVisible);
		}

		// Token: 0x06000890 RID: 2192 RVA: 0x0000775C File Offset: 0x0000595C
		internal void GuidanceWindowTabSelected(string mSelectedTab)
		{
			if (mSelectedTab == "gamepad" && this.mTabsGrid.Visibility == Visibility.Visible)
			{
				this.mGamepadTabBorder_MouseLeftButtonUp(null, null);
			}
		}

		// Token: 0x06000891 RID: 2193 RVA: 0x00036C90 File Offset: 0x00034E90
		private void mGamepadTabBorder_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			bool isVisible = this.mSaveButton.IsVisible;
			bool flag = false;
			this.mKeyboardTabBorder.BorderThickness = new Thickness(1.0, 1.0, 0.0, 1.0);
			this.mKeyboardTabBorder.Background = Brushes.Transparent;
			BlueStacksUIBinding.BindColor(this.mKeyboardTabBorder, Border.BorderBrushProperty, "GuidanceKeyBorderBackgroundColor");
			BlueStacksUIBinding.BindColor(this.mGamepadTabBorder, Border.BackgroundProperty, "GuidanceKeyBorderBackgroundColor");
			this.mGamepadTabBorder.BorderThickness = new Thickness(0.0);
			this.mIsGamePadTabSelected = true;
			this.mGuidanceKeyScrollBar.ScrollToTop();
			base.Height = this.ParentWindow.ActualHeight * 0.8;
			this.mUIElements.Clear();
			this.mGuidanceCategoryPanel.Children.Clear();
			this.mGuidanceKeyPanel.Children.Clear();
			this.mGuidanceCategoryPanel.MinWidth = 0.0;
			this.mAutoShowGuidanceCheckBox.IsChecked = new bool?(RegistryManager.Instance.IsAutoShowGuidance);
			foreach (IMAction imaction in this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls)
			{
				this.CreateCategory(imaction.GuidanceCategory);
				foreach (KeyValuePair<string, PropertyInfo> kvp in IMAction.DictPropertyInfo[imaction.Type])
				{
					int num = kvp.Key.ToString().IndexOf("_alt1");
					string text = string.Empty;
					if (num > 0)
					{
						text = kvp.Key.ToString().Substring(0, num);
					}
					else
					{
						text = kvp.Key.ToString();
					}
					if (imaction.Guidance.ContainsKey(text))
					{
						if (this.AddGuidanceKeyElementForGamepad(imaction, text, kvp))
						{
							flag = true;
						}
					}
					else if (imaction.Guidance.ContainsKey(kvp.Key.ToString()) && this.AddGuidanceKeyElementForGamepad(imaction, kvp.Key.ToString(), kvp))
					{
						flag = true;
					}
				}
			}
			if (flag)
			{
				this.AddElementsInUI();
			}
			else
			{
				this.mUIElements.Clear();
				this.mGuidanceCategoryPanel.Children.Clear();
				this.mGuidanceKeyPanel.Children.Clear();
			}
			this.ReloadUIPanels(isVisible);
		}

		// Token: 0x06000892 RID: 2194 RVA: 0x00036F58 File Offset: 0x00035158
		private bool AddGuidanceKeyElementForGamepad(IMAction item, string guidanceKey, KeyValuePair<string, PropertyInfo> kvp)
		{
			bool result = false;
			if (!string.IsNullOrEmpty(item[kvp.Key].ToString()) && ((Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(item[kvp.Key].ToString())).Contains("Gamepad") || kvp.Key.ToString().Contains("Gamepad")))
			{
				result = true;
				if (!this.CheckIfDuplicateGuidanceKey(this.ParentWindow.SelectedConfig.GetUIString(item.Guidance[guidanceKey]), item[kvp.Key].ToString()))
				{
					GuidanceKeyElement guidanceKeyElement = new GuidanceKeyElement(this.ParentWindow);
					guidanceKeyElement.ActionItemProperty = kvp.Key;
					guidanceKeyElement.lstActionItem = new List<IMAction>
					{
						item
					};
					guidanceKeyElement.mGuidenceTextBlock.Text = this.ParentWindow.SelectedConfig.GetUIString(item.Guidance[guidanceKey]);
					guidanceKeyElement.mGuidenceTextBlock.Tag = item.Guidance[guidanceKey];
					guidanceKeyElement.mKeyTextBox.Tag = item[kvp.Key];
					BlueStacksUIBinding.Bind(guidanceKeyElement.mKeyTextBox, Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(item[kvp.Key].ToString()));
					this.mUIElements[item.GuidanceCategory].Item3.Add(guidanceKeyElement);
				}
			}
			return result;
		}

		// Token: 0x06000893 RID: 2195 RVA: 0x000370D0 File Offset: 0x000352D0
		internal void RepositionWindowForDMM()
		{
			double num = (this.ParentWindow.Width - base.Width) / 2.0 + this.ParentWindow.Left;
			double num2 = (this.ParentWindow.Height - base.Height) / 2.0 + this.ParentWindow.Top;
			double num3 = num + base.Width;
			double num4 = num2 + base.Height;
			if (num > 0.0 && num3 < SystemParameters.PrimaryScreenWidth && num2 > 0.0 && num4 < SystemParameters.PrimaryScreenHeight)
			{
				base.Left = num;
				base.Top = num2;
			}
		}

		// Token: 0x06000894 RID: 2196 RVA: 0x00037178 File Offset: 0x00035378
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/gamecontrolwindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000895 RID: 2197 RVA: 0x000371A8 File Offset: 0x000353A8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((GameControlWindow)target).Loaded += this.Window_Loaded;
				((GameControlWindow)target).Closing += this.Window_Closing;
				return;
			case 2:
				this.mMaskBorder = (Border)target;
				return;
			case 3:
				((Grid)target).MouseLeftButtonDown += this.Grid_MouseLeftButtonDown;
				return;
			case 4:
				this.mViewHeaderTextBlock = (TextBlock)target;
				return;
			case 5:
				this.mEditHeaderTextBlock = (TextBlock)target;
				return;
			case 6:
				this.mSchemesComboBox = (CustomComboBox)target;
				this.mSchemesComboBox.SelectionChanged += this.ProfileComboBox_ProfileChanged;
				return;
			case 7:
				this.mEditButton = (CustomButton)target;
				this.mEditButton.Click += this.EditKeysButton_Click;
				return;
			case 8:
				this.mSaveButton = (CustomButton)target;
				this.mSaveButton.Click += this.SaveKeysButton_Click;
				return;
			case 9:
				((CustomPictureBox)target).PreviewMouseDown += this.CustomPictureBox_PreviewMouseDown;
				((CustomPictureBox)target).PreviewMouseUp += this.CloseButton_PreviewMouseUp;
				return;
			case 10:
				this.mGuidanceCategoryScrollBar = (ScrollViewer)target;
				return;
			case 11:
				this.mTabsGrid = (Grid)target;
				return;
			case 12:
				this.mKeyboardTabBorder = (Border)target;
				this.mKeyboardTabBorder.MouseLeftButtonUp += this.mKeyboardTabBorder_MouseLeftButtonUp;
				return;
			case 13:
				this.keyboardBtn = (TextBlock)target;
				return;
			case 14:
				this.mGamepadTabBorder = (Border)target;
				this.mGamepadTabBorder.MouseLeftButtonUp += this.mGamepadTabBorder_MouseLeftButtonUp;
				return;
			case 15:
				this.gamepadBtn = (TextBlock)target;
				return;
			case 16:
				this.mGuidanceKeyScrollBar = (ScrollViewer)target;
				this.mGuidanceKeyScrollBar.ScrollChanged += this.GuidanceKeyScrollBar_ScrollChanged;
				return;
			case 17:
				this.mGuidanceBottomBar = (Grid)target;
				return;
			case 18:
				this.mShortcutLabel = (TextBlock)target;
				return;
			case 19:
				this.mAutoShowGuidanceCheckBox = (CustomCheckbox)target;
				this.mAutoShowGuidanceCheckBox.Checked += this.CustomCheckbox_Checked;
				this.mAutoShowGuidanceCheckBox.Unchecked += this.CustomCheckbox_Checked;
				return;
			case 20:
				this.mTipBottomBar = (Grid)target;
				return;
			case 21:
				((CustomButton)target).Click += this.AdvancedButton_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000606 RID: 1542
		internal MainWindow ParentWindow;

		// Token: 0x04000607 RID: 1543
		private SortedDictionary<string, Tuple<TextBlock, GroupBox, List<FrameworkElement>>> mUIElements = new SortedDictionary<string, Tuple<TextBlock, GroupBox, List<FrameworkElement>>>();

		// Token: 0x04000608 RID: 1544
		private GuidanceVideoElement mGuidanceVideoElement;

		// Token: 0x04000609 RID: 1545
		private bool mIsGuidanceVideoPresent;

		// Token: 0x0400060A RID: 1546
		private StackPanel mGuidanceKeyPanel;

		// Token: 0x0400060B RID: 1547
		private StackPanel mGuidanceCategoryPanel;

		// Token: 0x0400060C RID: 1548
		private CustomToastPopupControl mToastPopup;

		// Token: 0x0400060D RID: 1549
		internal static bool sIsDirty;

		// Token: 0x0400060E RID: 1550
		internal bool mIsClosing;

		// Token: 0x0400060F RID: 1551
		private List<string> lstPanTags;

		// Token: 0x04000610 RID: 1552
		private List<string> lstMOBATags;

		// Token: 0x04000611 RID: 1553
		private bool mIsGamePadTabSelected;

		// Token: 0x04000612 RID: 1554
		internal Border mMaskBorder;

		// Token: 0x04000613 RID: 1555
		internal TextBlock mViewHeaderTextBlock;

		// Token: 0x04000614 RID: 1556
		internal TextBlock mEditHeaderTextBlock;

		// Token: 0x04000615 RID: 1557
		internal CustomComboBox mSchemesComboBox;

		// Token: 0x04000616 RID: 1558
		internal CustomButton mEditButton;

		// Token: 0x04000617 RID: 1559
		internal CustomButton mSaveButton;

		// Token: 0x04000618 RID: 1560
		internal ScrollViewer mGuidanceCategoryScrollBar;

		// Token: 0x04000619 RID: 1561
		internal Grid mTabsGrid;

		// Token: 0x0400061A RID: 1562
		internal Border mKeyboardTabBorder;

		// Token: 0x0400061B RID: 1563
		internal TextBlock keyboardBtn;

		// Token: 0x0400061C RID: 1564
		internal Border mGamepadTabBorder;

		// Token: 0x0400061D RID: 1565
		internal TextBlock gamepadBtn;

		// Token: 0x0400061E RID: 1566
		internal ScrollViewer mGuidanceKeyScrollBar;

		// Token: 0x0400061F RID: 1567
		internal Grid mGuidanceBottomBar;

		// Token: 0x04000620 RID: 1568
		internal TextBlock mShortcutLabel;

		// Token: 0x04000621 RID: 1569
		internal CustomCheckbox mAutoShowGuidanceCheckBox;

		// Token: 0x04000622 RID: 1570
		internal Grid mTipBottomBar;

		// Token: 0x04000623 RID: 1571
		private bool _contentLoaded;
	}
}
