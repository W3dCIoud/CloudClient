﻿using System;
using System.Collections.Generic;
using System.Threading;
using BlueStacks.BlueStacksUI.BTv;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000033 RID: 51
	internal class BGPHelper
	{
		// Token: 0x060002AF RID: 687 RVA: 0x00003D85 File Offset: 0x00001F85
		internal static void InitHttpServerAsync()
		{
			new Thread(new ThreadStart(BGPHelper.SetupHTTPServer))
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060002B0 RID: 688 RVA: 0x000165F4 File Offset: 0x000147F4
		internal static void SetupHTTPServer()
		{
			HttpHandlerSetup.InitHTTPServer(new Dictionary<string, HTTPServer.RequestHandler>(StringComparer.OrdinalIgnoreCase)
			{
				{
					"/ping",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.PingHandler)
				},
				{
					"/appDisplayed",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.AppDisplayedHandler)
				},
				{
					"/appLaunched",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.AppLaunchedHandler)
				},
				{
					"/showApp",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ShowAppHandler)
				},
				{
					"/showWindow",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ShowWindowHandler)
				},
				{
					"/isVisible",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.IsVisibleHandler)
				},
				{
					"/appUninstalled",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.AppUninstalledHandler)
				},
				{
					"/appInstalled",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.AppInstalledHandler)
				},
				{
					"/enableWndProcLogging",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.EnableWndProcLogging)
				},
				{
					"/quit",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ForceQuitHandler)
				},
				{
					"/google",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.OpenGoogleHandler)
				},
				{
					"/closeCrashedAppTab",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.AppCrashedHandler)
				},
				{
					"/showWebPage",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ShowWebPageHandler)
				},
				{
					"/showHomeTab",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ShowHomeTabHandler)
				},
				{
					"/closeTab",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.CloseTabHandler)
				},
				{
					"/updateUserInfo",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.UpdateUserInfoHandler)
				},
				{
					"/oneTimeSetupCompleted",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.OneTimeSetupCompletedHandler)
				},
				{
					"/appInstallStarted",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.AppInstallStarted)
				},
				{
					"/appInstallFailed",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.AppInstallFailed)
				},
				{
					"/googlePlayAppInstall",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.GooglePlayAppInstall)
				},
				{
					"/bootFailedPopup",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.BootFailedPopupHandler)
				},
				{
					"/dragDropInstall",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.DragDropInstallHandler)
				},
				{
					"/openPackage",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.OpenOrInstallPackageHandler)
				},
				{
					"/stopInstance",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.StopInstanceHandler)
				},
				{
					"/startInstance",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.StartInstanceHandler)
				},
				{
					"/hideBluestacks",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.HideBluestacksHandler)
				},
				{
					"/tileWindow",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.TileWindow)
				},
				{
					"/cascadeWindow",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.CascadeWindow)
				},
				{
					"/launchWebTab",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.LaunchWebTab)
				},
				{
					"/openNotificationSettings",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ShowSettingWindow)
				},
				{
					"/isAnyAppRunning",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.IsAnyAppRunning)
				},
				{
					"/launchDefaultWebApp",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.LaunchDefaultWebApp)
				},
				{
					"/toggleFarmMode",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ToggleFarmMode)
				},
				{
					"/changeTextOTS",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ChangeTextOTSHandler)
				},
				{
					"/macroCompleted",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.MacroCompleted)
				},
				{
					"/appInfoUpdated",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.AppInfoUpdated)
				},
				{
					"/sendAppDisplayed",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.SendAppDisplayed)
				},
				{
					"/static",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.IsBlueStacksUIVisible)
				},
				{
					"/restartFrontend",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.RestartFrontend)
				},
				{
					"/gcCollect",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.GCCollect)
				},
				{
					"/showWindowAndApp",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ShowWindowAndAppHandler)
				},
				{
					"/unsupportedCpuError",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.UnsupportedCPUError)
				},
				{
					"/changeOrientaion",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ChangeOrientaionHandler)
				},
				{
					"/shootingModeChanged",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ShootingModeChanged)
				},
				{
					"/guestBootCompleted",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.GuestBootCompleted)
				},
				{
					"/getRunningInstances",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.GetRunningInstances)
				},
				{
					"/appJsonChanged",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.AppJsonChangedHandler)
				},
				{
					"/getCurrentAppDetails",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.GetCurrentAppDetails)
				},
				{
					"/maintenanceWarning",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ShowMaintenanceWarning)
				},
				{
					"/updateSizeOfOverlay",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.UpdateSizeOfOverlay)
				},
				{
					"/androidLocaleChanged",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.AndroidLocaleChanged)
				},
				{
					"/saveComboEvents",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.SaveComboEvents)
				},
				{
					"/handleClientOperation",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.HandleClientOperation)
				},
				{
					"/handleGamepadConnection",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.HandleGamepadConnection)
				},
				{
					"/macroPlaybackComplete",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.MacroPlaybackCompleteHandler)
				},
				{
					"/toggleStreamingMode",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ToggleStreamingMode)
				},
				{
					"/handleClientGamepadButton",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.HandleClientGamepadButtonHandler)
				},
				{
					"/handleGamepadGuidanceButton",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.GamepadGuidanceButtonHandler)
				},
				{
					"/deviceProvisioned",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.DeviceProvisionedHandler)
				},
				{
					"/googleSignin",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.GoogleSigninHandler)
				},
				{
					"/showFullscreenSidebar",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.FullScreenSidebarHandler)
				},
				{
					"/setCurrentVolumeFromAndroid",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.SetCurrentVolumeFromAndroidHandler)
				},
				{
					"/enableDebugLogs",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.EnableDebugLogs)
				},
				{
					"/setDMMKeymapping",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.SetDMMKeymapping)
				},
				{
					"/ncSetGameInfoOnTopBar",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.NCSetGameInfoOnTopBarHandler)
				},
				{
					"/updateLocale",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.UpdateLocale)
				},
				{
					"/screenshotCaptured",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ScreenshotCaptured)
				},
				{
					"/hotKeyEvents",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ClientHotkeyHandler)
				},
				{
					"/launchPlay",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.LaunchPlay)
				},
				{
					"/enableKeyboardHookLogging",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.EnableKeyboardHookLogging)
				},
				{
					"/muteAllInstances",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.MuteAllInstancesHandler)
				},
				{
					"/screenLock",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ScreenLock)
				},
				{
					"/getHeightWidth",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.GetHeightWidth)
				},
				{
					"/accountSetupCompleted",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.AccountSetupCompleted)
				},
				{
					"/openThemeEditor",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.OpenThemeEditor)
				},
				{
					"/setStreamingStatus",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.SetStreamingStatus)
				},
				{
					"/playerScriptModifierClick",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.PlayerScriptModifierKeyUp)
				},
				{
					"/reloadShortcuts",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ReloadShortcuts)
				},
				{
					"/reloadPromotions",
					new HTTPServer.RequestHandler(BlueStacksUIHTTPHandler.ReloadPromotions)
				},
				{
					"/obsStatus",
					new HTTPServer.RequestHandler(BTVManager.ObsStatusHandler)
				},
				{
					"/reportObsError",
					new HTTPServer.RequestHandler(BTVManager.ReportObsErrorHandler)
				},
				{
					"/capturingError",
					new HTTPServer.RequestHandler(BTVManager.ReportCaptureError)
				},
				{
					"/openGLCapturingError",
					new HTTPServer.RequestHandler(BTVManager.ReportOpenGLCaptureError)
				}
			}, RegistryStrings.BtvDir);
		}
	}
}
