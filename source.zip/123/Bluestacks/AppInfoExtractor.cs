﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200015B RID: 347
	internal class AppInfoExtractor
	{
		// Token: 0x06000D58 RID: 3416 RVA: 0x00057028 File Offset: 0x00055228
		internal static AppInfoExtractor GetApkInfo(string apkFile)
		{
			AppInfoExtractor appInfoExtractor = new AppInfoExtractor();
			try
			{
				Process process = new Process();
				process.StartInfo.UseShellExecute = false;
				process.StartInfo.CreateNoWindow = true;
				process.StartInfo.RedirectStandardOutput = true;
				process.StartInfo.StandardOutputEncoding = Encoding.UTF8;
				process.StartInfo.FileName = Path.Combine(RegistryStrings.InstallDir, "hd-aapt.exe");
				process.StartInfo.Arguments = string.Format("dump badging \"{0}\"", apkFile);
				process.Start();
				string input = process.StandardOutput.ReadToEnd();
				process.WaitForExit();
				Match match = new Regex("package:\\sname='(.+?)'").Match(input);
				appInfoExtractor.PackageName = match.Groups[1].Value;
				if (!string.IsNullOrEmpty(appInfoExtractor.PackageName))
				{
					match = new Regex("application:\\slabel='(.+)'\\sicon='(.+?)'").Match(input);
					appInfoExtractor.AppName = match.Groups[1].Value;
					appInfoExtractor.AppName = Regex.Replace(appInfoExtractor.AppName, "[\\x22\\\\\\/:*?|<>]", "");
					match.Groups[2].Value.Replace("/", "\\");
					match = new Regex("launchable\\sactivity\\sname='(.+?)'").Match(input);
					appInfoExtractor.ActivityName = match.Groups[1].Value;
				}
			}
			catch
			{
				Logger.Error("Error getting file info");
			}
			return appInfoExtractor;
		}

		// Token: 0x06000D59 RID: 3417 RVA: 0x000571AC File Offset: 0x000553AC
		private static string DownloadIcon(string apkFile, string fileNameWithExtension, string iconInternalPath)
		{
			string result = string.Empty;
			try
			{
				string path = Regex.Replace(fileNameWithExtension, "[\\x22\\\\\\/:*?|<>]", " ");
				string text = Path.Combine(RegistryStrings.GadgetDir, path);
				if (File.Exists(text))
				{
					result = text;
				}
				else
				{
					iconInternalPath = iconInternalPath.Replace('\\', '/');
					ZipStorer zipStorer = ZipStorer.Open(apkFile, FileAccess.Read);
					foreach (ZipStorer.ZipFileEntry zipFileEntry in zipStorer.ReadCentralDir())
					{
						if (zipFileEntry.FilenameInZip.Equals(iconInternalPath))
						{
							zipStorer.ExtractFile(zipFileEntry, text);
							result = text;
							break;
						}
					}
					zipStorer.Close();
				}
			}
			catch
			{
			}
			return result;
		}

		// Token: 0x04000999 RID: 2457
		internal string PackageName;

		// Token: 0x0400099A RID: 2458
		internal string AppName;

		// Token: 0x0400099B RID: 2459
		internal string ActivityName;
	}
}
