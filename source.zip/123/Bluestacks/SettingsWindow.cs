﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000A6 RID: 166
	public class SettingsWindow : SettingsWindowBase
	{
		// Token: 0x0600071C RID: 1820 RVA: 0x0002C0E8 File Offset: 0x0002A2E8
		public SettingsWindow(MainWindow window, string startUpTab)
		{
			SettingsWindow <>4__this = this;
			this.ParentWindow = window;
			this.settingsControlNameList.Add("STRING_DISPLAY_SETTINGS");
			this.settingsControlNameList.Add("STRING_ENGINE_SETTING");
			this.settingsControlNameList.Add("STRING_SHORTCUT_KEY_SETTINGS");
			this.settingsControlNameList.Add("STRING_GAME_SETTINGS");
			this.settingsControlNameList.Add("STRING_ABOUT_SETTING");
			this.UpdateSettingsListAndStartTabForCustomOEMs();
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				<>4__this.SettingsWindow_Loaded(sender, e, window);
			};
			if (!string.IsNullOrEmpty(startUpTab))
			{
				this.mStartUpTab = startUpTab;
			}
			this.CreateAllButtons(this.mStartUpTab);
			UserControl userControl = this.GetUserControl(this.mStartUpTab, window);
			if (userControl == null)
			{
				userControl = this.GetUserControl("STRING_DISPLAY_SETTINGS", window);
			}
			base.AddControlInGridAndDict(this.mStartUpTab, userControl);
			base.BringToFront(userControl);
		}

		// Token: 0x0600071D RID: 1821 RVA: 0x0002C1F4 File Offset: 0x0002A3F4
		public void UpdateSettingsListAndStartTabForCustomOEMs()
		{
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				this.settingsControlNameList = new List<string>
				{
					"STRING_DISPLAY_SETTINGS",
					"STRING_ENGINE_SETTING",
					"STRING_SCREENSHOT"
				};
				return;
			}
			if (FeatureManager.Instance.IsCustomUIForDMMSandbox)
			{
				this.settingsControlNameList = new List<string>
				{
					"STRING_ABOUT_SETTING"
				};
				this.mStartUpTab = "STRING_ABOUT_SETTING";
				return;
			}
			if (Oem.Instance.OEM.Equals("yoozoo"))
			{
				this.settingsControlNameList = new List<string>
				{
					"STRING_DISPLAY_SETTINGS",
					"STRING_ENGINE_SETTING",
					"STRING_PREFERENCES"
				};
				return;
			}
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				this.settingsControlNameList = new List<string>
				{
					"STRING_DISPLAY_SETTINGS",
					"STRING_ENGINE_SETTING",
					"STRING_ABOUT_SETTING"
				};
				return;
			}
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.settingsControlNameList = new List<string>
				{
					"STRING_DISPLAY_SETTINGS",
					"STRING_ENGINE_SETTING",
					"STRING_PREFERENCES",
					"STRING_SHORTCUT_KEY_SETTINGS",
					"STRING_USER_DATA_SETTINGS"
				};
			}
		}

		// Token: 0x0600071E RID: 1822 RVA: 0x0002C334 File Offset: 0x0002A534
		private UserControl GetUserControl(string controlName, MainWindow window)
		{
			uint num = <PrivateImplementationDetails>.ComputeStringHash(controlName);
			if (num <= 2851124811U)
			{
				if (num <= 1158533478U)
				{
					if (num != 453138840U)
					{
						if (num == 1158533478U)
						{
							if (controlName == "STRING_NOTIFICATION")
							{
								return new NotificationsSettings(window);
							}
						}
					}
					else if (controlName == "STRING_ENGINE_SETTING")
					{
						return new EngineSettingsControl(window);
					}
				}
				else if (num != 2256989329U)
				{
					if (num != 2395752955U)
					{
						if (num == 2851124811U)
						{
							if (controlName == "STRING_DISPLAY_SETTINGS")
							{
								return new DisplaySettingsControl(window);
							}
						}
					}
					else if (controlName == "STRING_ADVANCED")
					{
						return new DeviceProfileControl(window);
					}
				}
				else if (controlName == "STRING_SCREENSHOT")
				{
					return new DMMScreenshotSettingControl(window);
				}
			}
			else if (num <= 3066349429U)
			{
				if (num != 2925263117U)
				{
					if (num == 3066349429U)
					{
						if (controlName == "STRING_GAME_SETTINGS")
						{
							return new GameSettingsControl(window, this);
						}
					}
				}
				else if (controlName == "STRING_USER_DATA_SETTINGS")
				{
					return new BackupRestoreSettingsControl(window);
				}
			}
			else if (num != 3082043033U)
			{
				if (num != 3350936637U)
				{
					if (num == 3467783225U)
					{
						if (controlName == "STRING_SHORTCUT_KEY_SETTINGS")
						{
							return new ShortcutKeysControl(window, this);
						}
					}
				}
				else if (controlName == "STRING_PREFERENCES")
				{
					return new PreferencesSettingsControl(window);
				}
			}
			else if (controlName == "STRING_ABOUT_SETTING")
			{
				return new AboutSettingsControl(window, this);
			}
			return null;
		}

		// Token: 0x0600071F RID: 1823 RVA: 0x0002C4D4 File Offset: 0x0002A6D4
		private void SettingsWindow_Loaded(object sender, RoutedEventArgs e, MainWindow window)
		{
			Window.GetWindow(this).Closing += this.SettingWindow_Closing;
			new Thread(delegate()
			{
				Thread.Sleep(500);
				using (List<string>.Enumerator enumerator = this.settingsControlNameList.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						string settingName = enumerator.Current;
						if (!settingName.Equals(this.mStartUpTab))
						{
							this.Dispatcher.Invoke(new Action(delegate()
							{
								UserControl userControl = this.GetUserControl(settingName, window);
								if (userControl != null)
								{
									this.AddControlInGridAndDict(settingName, userControl);
									foreach (object obj in this.SettingsWindowStackPanel.Children)
									{
										CustomSettingsButton customSettingsButton = (CustomSettingsButton)obj;
										if (customSettingsButton.Name == settingName)
										{
											customSettingsButton.IsEnabled = true;
										}
									}
								}
							}), new object[0]);
						}
					}
				}
				this.Dispatcher.Invoke(new Action(delegate()
				{
					this.SetPopupOffset();
				}), new object[0]);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000720 RID: 1824 RVA: 0x0002C528 File Offset: 0x0002A728
		private void SettingWindow_Closing(object sender, CancelEventArgs e)
		{
			try
			{
				if (this.mIsShortcutEdited && this.mIsShortcutSaveBtnEnabled)
				{
					this.ParentWindow.mCommonHandler.ReloadShortcutsForAllInstances();
				}
			}
			catch (Exception arg)
			{
				Logger.Error("Exception in SettingsWindowClosing. Exception: " + arg);
			}
		}

		// Token: 0x06000721 RID: 1825 RVA: 0x0002C57C File Offset: 0x0002A77C
		private void CreateAllButtons(string mstartUpTab)
		{
			foreach (string text in this.settingsControlNameList)
			{
				CustomSettingsButton customSettingsButton = new CustomSettingsButton();
				customSettingsButton.Name = text;
				customSettingsButton.Group = "Settings";
				TextBlock textBlock = new TextBlock();
				textBlock.FontSize = 15.0;
				textBlock.TextWrapping = TextWrapping.Wrap;
				BlueStacksUIBinding.Bind(textBlock, text, "");
				customSettingsButton.Content = textBlock;
				customSettingsButton.MinHeight = 40.0;
				customSettingsButton.FontWeight = FontWeights.Normal;
				customSettingsButton.IsTabStop = false;
				customSettingsButton.FocusVisualStyle = null;
				customSettingsButton.IsEnabled = false;
				customSettingsButton.Click += base.SettingsBtn_Click;
				base.SettingsWindowStackPanel.Children.Add(customSettingsButton);
				if (mstartUpTab == text)
				{
					customSettingsButton.IsEnabled = true;
					customSettingsButton.IsSelected = true;
				}
				if (text == "STRING_GAME_SETTINGS")
				{
					this.gameSettingsButton = customSettingsButton;
					if (this.ParentWindow.mTopBar.mSettingsBtnNotification.Visibility == Visibility.Visible)
					{
						customSettingsButton.ShowButtonNotification = true;
					}
				}
			}
		}

		// Token: 0x06000722 RID: 1826 RVA: 0x0002C6B4 File Offset: 0x0002A8B4
		protected override void SetPopupOffset()
		{
			if (this.ParentWindow.mTopBar.mSnailMode == PerformanceState.VtxDisabled && !this.mIsVtxLearned && base.CheckWidth())
			{
				base.EnableVTPopup.HorizontalOffset = base.SettingsWindowStackPanel.ActualWidth;
				base.EnableVTPopup.Width = base.SettingsWindowGrid.ActualWidth;
				base.EnableVTPopup.IsOpen = true;
			}
		}

		// Token: 0x06000723 RID: 1827 RVA: 0x0002C71C File Offset: 0x0002A91C
		public override void CloseButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked settings menu close button");
			if (EngineSettingsBase.mInitialFPSSliderValue != this.ParentWindow.EngineInstanceRegistry.FPS)
			{
				Utils.SendChangeFPSToInstanceASync(this.ParentWindow.mVmName, int.MaxValue);
			}
			this.ParentWindow.mWelcomeTab.mHomeApp.RequirementConfigUpdated();
			if (this.mIsShortcutEdited && this.mIsShortcutSaveBtnEnabled)
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_BLUESTACKS", "");
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_UNSAVED_CHANGES", "");
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_SAVE_CHANGE", delegate(object o, EventArgs evt)
				{
					this.ParentWindow.mCommonHandler.SaveAndReloadShortcuts();
					this.mIsShortcutEdited = false;
					BlueStacksUIUtils.CloseContainerWindow(this);
				}, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, "STRING_DISCARD", delegate(object o, EventArgs evt)
				{
					this.ParentWindow.mCommonHandler.ReloadShortcutsForAllInstances();
					BlueStacksUIUtils.CloseContainerWindow(this);
				}, null, false, null);
				customMessageWindow.Owner = this.ParentWindow;
				customMessageWindow.ShowDialog();
			}
			else if (this.mDuplicateShortcutsList.Count > 0)
			{
				this.ParentWindow.mCommonHandler.ReloadShortcutsForAllInstances();
				BlueStacksUIUtils.CloseContainerWindow(this);
			}
			else
			{
				BlueStacksUIUtils.CloseContainerWindow(this);
			}
			if (this.mIsRestartPUBGTabOnClose)
			{
				CustomMessageWindow customMessageWindow2 = new CustomMessageWindow();
				string path = string.Format(LocaleStrings.GetLocalizedString("STRING_RESTART_OBJECT", false), "Call of Duty: Mobile");
				BlueStacksUIBinding.Bind(customMessageWindow2.TitleTextBlock, path, "");
				string path2 = string.Format(LocaleStrings.GetLocalizedString("STRING_SETTING_CHANGED_RESTART_APP_MESSAGE", false), "PUBG Mobile");
				BlueStacksUIBinding.Bind(customMessageWindow2.BodyTextBlock, path2, "");
				customMessageWindow2.AddButton(ButtonColors.Blue, "STRING_RESTART_BLUESTACKS", new EventHandler(this.RestartConfirmationAcceptedHandler), null, false, null);
				customMessageWindow2.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
				customMessageWindow2.Owner = this.ParentWindow;
				customMessageWindow2.ShowDialog();
			}
			if (this.mIsRestartCODTabOnClose)
			{
				CustomMessageWindow customMessageWindow3 = new CustomMessageWindow();
				string path3 = string.Format("{0} {1}", LocaleStrings.GetLocalizedString("STRING_RESTART_BLUESTACKS", false), "Call of Duty: Mobile");
				BlueStacksUIBinding.Bind(customMessageWindow3.TitleTextBlock, path3, "");
				string path4 = string.Format(LocaleStrings.GetLocalizedString("STRING_SETTING_CHANGED_RESTART_APP_MESSAGE", false), "Call of Duty: Mobile");
				BlueStacksUIBinding.Bind(customMessageWindow3.BodyTextBlock, path4, "");
				customMessageWindow3.AddButton(ButtonColors.Blue, "STRING_RESTART_BLUESTACKS", new EventHandler(this.RestartConfirmationAcceptedHandler), null, false, null);
				customMessageWindow3.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow3.Owner = this.ParentWindow.mDimOverlay;
				customMessageWindow3.ShowDialog();
				this.ParentWindow.HideDimOverlay();
			}
		}

		// Token: 0x06000724 RID: 1828 RVA: 0x00006A2B File Offset: 0x00004C2B
		private void RestartConfirmationAcceptedHandler(object sender, EventArgs e)
		{
			Logger.Info("Restarting Pubg Mobile Tab.");
			new Thread(delegate()
			{
				this.ParentWindow.mTopBar.mAppTabButtons.RestartTab(this.mRestartTabPackageName);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x040004CF RID: 1231
		private MainWindow ParentWindow;

		// Token: 0x040004D0 RID: 1232
		internal CustomSettingsButton updateButton;

		// Token: 0x040004D1 RID: 1233
		internal CustomSettingsButton gameSettingsButton;

		// Token: 0x040004D2 RID: 1234
		internal bool mIsRestartPUBGTabOnClose;

		// Token: 0x040004D3 RID: 1235
		internal bool mIsRestartCODTabOnClose;

		// Token: 0x040004D4 RID: 1236
		internal string mRestartTabPackageName;

		// Token: 0x040004D5 RID: 1237
		internal bool mIsShortcutEdited;

		// Token: 0x040004D6 RID: 1238
		internal bool mIsShortcutSaveBtnEnabled;

		// Token: 0x040004D7 RID: 1239
		internal List<string> mDuplicateShortcutsList = new List<string>();
	}
}
