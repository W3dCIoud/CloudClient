﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000CB RID: 203
	internal interface IDimOverlayControl
	{
		// Token: 0x06000818 RID: 2072
		bool Close();

		// Token: 0x17000166 RID: 358
		// (get) Token: 0x06000819 RID: 2073
		// (set) Token: 0x0600081A RID: 2074
		bool IsCloseOnOverLayClick { get; set; }

		// Token: 0x0600081B RID: 2075
		bool Show();

		// Token: 0x17000167 RID: 359
		// (get) Token: 0x0600081C RID: 2076
		// (set) Token: 0x0600081D RID: 2077
		bool ShowControlInSeparateWindow { get; set; }

		// Token: 0x17000168 RID: 360
		// (get) Token: 0x0600081E RID: 2078
		// (set) Token: 0x0600081F RID: 2079
		double Height { get; set; }

		// Token: 0x17000169 RID: 361
		// (get) Token: 0x06000820 RID: 2080
		// (set) Token: 0x06000821 RID: 2081
		double Width { get; set; }
	}
}
