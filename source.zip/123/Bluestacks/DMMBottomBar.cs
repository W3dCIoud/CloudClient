﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000068 RID: 104
	public class DMMBottomBar : UserControl, IComponentConnector
	{
		// Token: 0x17000134 RID: 308
		// (get) Token: 0x06000464 RID: 1124 RVA: 0x00004E6A File Offset: 0x0000306A
		// (set) Token: 0x06000465 RID: 1125 RVA: 0x0001D75C File Offset: 0x0001B95C
		internal double CurrentTransparency
		{
			get
			{
				return DMMBottomBar.sCurrentTransparency;
			}
			set
			{
				DMMBottomBar.sCurrentTransparency = value;
				this.transSlider.ValueChanged -= this.TransparencySlider_ValueChanged;
				if (this.ParentWindow.mDMMFST != null)
				{
					this.ParentWindow.mDMMFST.transSlider.ValueChanged -= this.ParentWindow.mDMMFST.TransparencySlider_ValueChanged;
				}
				this.transSlider.Value = DMMBottomBar.sCurrentTransparency;
				if (this.ParentWindow.mDMMFST != null)
				{
					this.ParentWindow.mDMMFST.transSlider.Value = DMMBottomBar.sCurrentTransparency;
				}
				this.transSlider.ValueChanged += this.TransparencySlider_ValueChanged;
				if (this.ParentWindow.mDMMFST != null)
				{
					this.ParentWindow.mDMMFST.transSlider.ValueChanged += this.ParentWindow.mDMMFST.TransparencySlider_ValueChanged;
				}
			}
		}

		// Token: 0x17000135 RID: 309
		// (get) Token: 0x06000466 RID: 1126 RVA: 0x00004E71 File Offset: 0x00003071
		// (set) Token: 0x06000467 RID: 1127 RVA: 0x0001D844 File Offset: 0x0001BA44
		internal int CurrentVolume
		{
			get
			{
				return DMMBottomBar.sCurrentVolume;
			}
			set
			{
				DMMBottomBar.sCurrentVolume = value;
				this.mVolumeSlider.ValueChanged -= this.VolumeSlider_ValueChanged;
				if (this.ParentWindow.mDMMFST != null)
				{
					this.ParentWindow.mDMMFST.mVolumeSlider.ValueChanged -= this.ParentWindow.mDMMFST.VolumeSlider_ValueChanged;
				}
				this.mVolumeSlider.Value = (double)DMMBottomBar.sCurrentVolume;
				if (this.ParentWindow.mDMMFST != null && this.ParentWindow.mDMMFST.mVolumeSlider != null)
				{
					this.ParentWindow.mDMMFST.mVolumeSlider.Value = (double)DMMBottomBar.sCurrentVolume;
				}
				this.mVolumeSlider.ValueChanged += this.VolumeSlider_ValueChanged;
				this.ParentWindow.mDMMFST.mVolumeSlider.ValueChanged += this.ParentWindow.mDMMFST.VolumeSlider_ValueChanged;
				if (DMMBottomBar.sCurrentVolume < 1)
				{
					this.VolumeImageName = "volume_mute";
					return;
				}
				if (DMMBottomBar.sCurrentVolume <= 50)
				{
					this.VolumeImageName = "volume_small";
					return;
				}
				this.VolumeImageName = "volume_large";
			}
		}

		// Token: 0x17000136 RID: 310
		// (get) Token: 0x06000468 RID: 1128 RVA: 0x00004E78 File Offset: 0x00003078
		// (set) Token: 0x06000469 RID: 1129 RVA: 0x00004E8A File Offset: 0x0000308A
		public string VolumeImageName
		{
			get
			{
				return (string)base.GetValue(DMMBottomBar.VolumeImageNameProperty);
			}
			set
			{
				base.SetValue(DMMBottomBar.VolumeImageNameProperty, value);
			}
		}

		// Token: 0x0600046A RID: 1130 RVA: 0x0001D968 File Offset: 0x0001BB68
		private static void OnVolumeImageNameChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			(d as DMMBottomBar).ParentWindow.mDmmBottomBar.mVolumeBtn.ImageName = e.NewValue.ToString();
			(d as DMMBottomBar).ParentWindow.mDmmBottomBar.volumesSliderImage.ImageName = e.NewValue.ToString();
			(d as DMMBottomBar).ParentWindow.mDMMFST.mVolumeBtn.ImageName = e.NewValue.ToString();
			(d as DMMBottomBar).ParentWindow.mDMMFST.volumeSliderImage.ImageName = e.NewValue.ToString();
		}

		// Token: 0x0600046B RID: 1131 RVA: 0x00004E98 File Offset: 0x00003098
		public DMMBottomBar()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600046C RID: 1132 RVA: 0x00004EA6 File Offset: 0x000030A6
		public void Init(MainWindow window)
		{
			this.ParentWindow = window;
			this.VolumeImageName = "volume_small";
			this.mVolumeBtn.ImageName = "volume_small";
			this.CurrentTransparency = (DMMBottomBar.sPreviousTransparency = RegistryManager.Instance.TranslucentControlsTransparency);
		}

		// Token: 0x0600046D RID: 1133 RVA: 0x00004EE0 File Offset: 0x000030E0
		internal void Tab_Changed(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.SetDMMKeymapButtonsAndTransparency();
		}

		// Token: 0x0600046E RID: 1134 RVA: 0x00004EF2 File Offset: 0x000030F2
		private void FullScreenBtn_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.FullScreenButtonHandler("bottombarDmm", "MouseClick");
		}

		// Token: 0x0600046F RID: 1135 RVA: 0x00004F0E File Offset: 0x0000310E
		private void ScreenshotBtn_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.ScreenShotButtonHandler();
		}

		// Token: 0x06000470 RID: 1136 RVA: 0x00004F20 File Offset: 0x00003120
		private void VolumeBtn_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.mVolumePopup.IsOpen = !this.mVolumePopup.IsOpen;
		}

		// Token: 0x06000471 RID: 1137 RVA: 0x0001DA10 File Offset: 0x0001BC10
		internal void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			if (this.ParentWindow != null)
			{
				this.CurrentVolume = (int)Math.Floor(e.NewValue);
				DMMBottomBar.sPreviousVolume = (int)Math.Floor(e.NewValue);
				this.ParentWindow.Utils.SetCurrentVolumeForDMM((int)Math.Floor(e.OldValue), (int)Math.Floor(e.NewValue));
			}
		}

		// Token: 0x06000472 RID: 1138 RVA: 0x00004F3B File Offset: 0x0000313B
		private void SettingsBtn_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.LaunchSettingsWindow();
		}

		// Token: 0x06000473 RID: 1139 RVA: 0x0001DA70 File Offset: 0x0001BC70
		private void RecommendedWindowBtn_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow.WindowState == WindowState.Normal)
			{
				if (this.ParentWindow.mDMMRecommendedWindow == null)
				{
					this.ParentWindow.mDMMRecommendedWindow = new DMMRecommendedWindow(this.ParentWindow);
					this.ParentWindow.mDMMRecommendedWindow.Init(RegistryManager.Instance.DMMRecommendedWindowUrl);
				}
				if (this.ParentWindow.mDMMRecommendedWindow.Visibility != Visibility.Visible)
				{
					this.ParentWindow.mDMMRecommendedWindow.Visibility = Visibility.Visible;
					this.ParentWindow.mIsDMMRecommendedWindowOpen = true;
				}
				else
				{
					this.ParentWindow.mDMMRecommendedWindow.Visibility = Visibility.Hidden;
					this.ParentWindow.mIsDMMRecommendedWindowOpen = false;
				}
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					Thread.Sleep(500);
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						this.ParentWindow.Activate();
					}), new object[0]);
				});
			}
		}

		// Token: 0x06000474 RID: 1140 RVA: 0x0001DB2C File Offset: 0x0001BD2C
		private void DoNotPromptManageGP_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mDoNotPromptChkBx.ImageName.Equals("bgpcheckbox"))
			{
				this.mDoNotPromptChkBx.ImageName = "bgpcheckbox_checked";
				RegistryManager.Instance.KeyMappingAvailablePromptEnabled = false;
			}
			else
			{
				this.mDoNotPromptChkBx.ImageName = "bgpcheckbox";
				RegistryManager.Instance.KeyMappingAvailablePromptEnabled = true;
			}
			e.Handled = true;
		}

		// Token: 0x06000475 RID: 1141 RVA: 0x00004F4D File Offset: 0x0000314D
		private void ClosePopup_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mKeyMapPopup.IsOpen = false;
			e.Handled = true;
		}

		// Token: 0x06000476 RID: 1142 RVA: 0x00004F62 File Offset: 0x00003162
		private void KeyMapPopup_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mKeyMapPopup.IsOpen = false;
			this.ParentWindow.mCommonHandler.KeyMapButtonHandler("MouseClick", "bottombarpopup");
		}

		// Token: 0x06000477 RID: 1143 RVA: 0x00004F8A File Offset: 0x0000318A
		private void SwitchKeyMapButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.DMMSwitchKeyMapButtonHandler();
		}

		// Token: 0x06000478 RID: 1144 RVA: 0x0001DB90 File Offset: 0x0001BD90
		private void KeyMapButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab != null && this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName != null)
			{
				this.ParentWindow.mCommonHandler.KeyMapButtonHandler("MouseClick", "bottombar");
			}
		}

		// Token: 0x06000479 RID: 1145 RVA: 0x00004F9C File Offset: 0x0000319C
		private void TranslucentControlsButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.transSlider.Value = RegistryManager.Instance.TranslucentControlsTransparency;
			this.mChangeTransparencyPopup.PlacementTarget = this.mTranslucentControlsButton;
			this.mChangeTransparencyPopup.IsOpen = true;
		}

		// Token: 0x0600047A RID: 1146 RVA: 0x00004FD0 File Offset: 0x000031D0
		private void UserControl_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (!DesignerProperties.GetIsInDesignMode(this))
			{
				this.UpdateLayoutAndBounds();
			}
		}

		// Token: 0x0600047B RID: 1147 RVA: 0x00004FE0 File Offset: 0x000031E0
		internal void UpdateLayoutAndBounds()
		{
			if (this.mKeyMapPopup.IsOpen)
			{
				this.ShowKeyMapPopup(true);
			}
		}

		// Token: 0x0600047C RID: 1148 RVA: 0x0001DBEC File Offset: 0x0001BDEC
		internal void ShowKeyMapPopup(bool isShow)
		{
			if (isShow)
			{
				new Thread(delegate()
				{
					Thread.Sleep(500);
					base.Dispatcher.Invoke(new Action(delegate()
					{
						if (!RegistryManager.Instance.KeyMappingAvailablePromptEnabled)
						{
							if (RegistryManager.Instance.IsAutoShowGuidance && !this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.mIsKeyMappingTipDisplayed)
							{
								this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.mIsKeyMappingTipDisplayed = true;
								KMManager.HandleInputMapperWindow(this.ParentWindow, false, "default");
							}
							return;
						}
						this.mKeyMapPopup.IsOpen = false;
						this.mKeyMapPopup.PlacementTarget = this.mKeyMapButton;
						if (RegistryManager.Instance.IsAutoShowGuidance && !this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.mIsKeyMappingTipDisplayed)
						{
							this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.mIsKeyMappingTipDisplayed = true;
							KMManager.HandleInputMapperWindow(this.ParentWindow, false, "default");
							return;
						}
						this.mKeyMapPopup.IsOpen = true;
					}), new object[0]);
				})
				{
					IsBackground = true
				}.Start();
				return;
			}
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mKeyMapPopup.IsOpen = false;
			}), new object[0]);
		}

		// Token: 0x0600047D RID: 1149 RVA: 0x00004FF6 File Offset: 0x000031F6
		internal void TransparencySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			this.CurrentTransparency = e.NewValue;
			DMMBottomBar.sPreviousTransparency = e.NewValue;
			this.ChangeTransparency();
		}

		// Token: 0x0600047E RID: 1150 RVA: 0x0001DC38 File Offset: 0x0001BE38
		private void ChangeTransparency()
		{
			KMManager.ChangeTransparency(this.ParentWindow, this.CurrentTransparency);
			if (this.CurrentTransparency == 0.0)
			{
				KMManager.ShowOverlayWindow(this.ParentWindow, false, false);
				this.ParentWindow.mCommonHandler.SetTranslucentControlsBtnImageForDMM("eye_off");
				return;
			}
			KMManager.ShowOverlayWindow(this.ParentWindow, true, false);
			this.ParentWindow.mCommonHandler.SetTranslucentControlsBtnImageForDMM("eye");
		}

		// Token: 0x0600047F RID: 1151 RVA: 0x00005015 File Offset: 0x00003215
		internal void mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.CurrentTransparency = ((this.CurrentTransparency == 0.0) ? DMMBottomBar.sPreviousTransparency : 0.0);
			this.ChangeTransparency();
		}

		// Token: 0x06000480 RID: 1152 RVA: 0x0001DCAC File Offset: 0x0001BEAC
		internal void VolumeSliderImage_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow != null)
			{
				int currentVolume = this.CurrentVolume;
				this.CurrentVolume = ((this.CurrentVolume == 0) ? DMMBottomBar.sPreviousVolume : 0);
				int currentVolume2 = this.CurrentVolume;
				this.ParentWindow.Utils.SetCurrentVolumeForDMM(currentVolume, currentVolume2);
			}
		}

		// Token: 0x06000481 RID: 1153 RVA: 0x0001DCF8 File Offset: 0x0001BEF8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/dmmbottombar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000482 RID: 1154 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000483 RID: 1155 RVA: 0x0001DD28 File Offset: 0x0001BF28
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((DMMBottomBar)target).SizeChanged += this.UserControl_SizeChanged;
				return;
			case 2:
				this.DMMBottomGrid = (Grid)target;
				return;
			case 3:
				this.mKeyMapSwitch = (CustomPictureBox)target;
				this.mKeyMapSwitch.PreviewMouseLeftButtonUp += this.SwitchKeyMapButton_PreviewMouseLeftButtonUp;
				return;
			case 4:
				this.mKeyMapButton = (CustomPictureBox)target;
				this.mKeyMapButton.PreviewMouseLeftButtonUp += this.KeyMapButton_PreviewMouseLeftButtonUp;
				return;
			case 5:
				this.mTranslucentControlsButton = (CustomPictureBox)target;
				this.mTranslucentControlsButton.PreviewMouseLeftButtonUp += this.TranslucentControlsButton_PreviewMouseLeftButtonUp;
				return;
			case 6:
				this.mScreenshotBtn = (CustomPictureBox)target;
				this.mScreenshotBtn.PreviewMouseLeftButtonUp += this.ScreenshotBtn_MouseUp;
				return;
			case 7:
				this.mVolumeBtn = (CustomPictureBox)target;
				this.mVolumeBtn.PreviewMouseLeftButtonUp += this.VolumeBtn_MouseUp;
				return;
			case 8:
				this.mFullscreenBtn = (CustomPictureBox)target;
				this.mFullscreenBtn.PreviewMouseLeftButtonUp += this.FullScreenBtn_MouseUp;
				return;
			case 9:
				this.mSettingsBtn = (CustomPictureBox)target;
				this.mSettingsBtn.PreviewMouseLeftButtonUp += this.SettingsBtn_MouseUp;
				return;
			case 10:
				this.mRecommendedWindowBtn = (CustomPictureBox)target;
				this.mRecommendedWindowBtn.PreviewMouseLeftButtonUp += this.RecommendedWindowBtn_PreviewMouseLeftButtonUp;
				return;
			case 11:
				this.mVolumePopup = (CustomPopUp)target;
				return;
			case 12:
				this.volumesSliderImage = (CustomPictureBox)target;
				this.volumesSliderImage.PreviewMouseLeftButtonUp += this.VolumeSliderImage_PreviewMouseLeftButtonUp;
				return;
			case 13:
				this.mVolumeSlider = (Slider)target;
				this.mVolumeSlider.ValueChanged += this.VolumeSlider_ValueChanged;
				return;
			case 14:
				this.mKeyMapPopup = (CustomPopUp)target;
				return;
			case 15:
				((Border)target).MouseLeftButtonUp += this.KeyMapPopup_PreviewMouseLeftButtonUp;
				return;
			case 16:
				((CustomPictureBox)target).MouseLeftButtonUp += this.ClosePopup_MouseLeftButtonUp;
				return;
			case 17:
				this.mKeyMappingPopUp1 = (TextBlock)target;
				return;
			case 18:
				this.mKeyMappingPopUp3 = (TextBlock)target;
				return;
			case 19:
				this.mDoNotPromptChkBx = (CustomPictureBox)target;
				this.mDoNotPromptChkBx.MouseLeftButtonUp += this.DoNotPromptManageGP_MouseLeftButtonUp;
				return;
			case 20:
				this.mKeyMappingDontShowPopUp = (TextBlock)target;
				this.mKeyMappingDontShowPopUp.MouseLeftButtonUp += this.DoNotPromptManageGP_MouseLeftButtonUp;
				return;
			case 21:
				this.DownArrow = (Path)target;
				return;
			case 22:
				this.mChangeTransparencyPopup = (CustomPopUp)target;
				return;
			case 23:
				this.mTranslucentControlsSliderButton = (CustomPictureBox)target;
				this.mTranslucentControlsSliderButton.PreviewMouseLeftButtonUp += this.mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp;
				return;
			case 24:
				this.transSlider = (Slider)target;
				this.transSlider.ValueChanged += this.TransparencySlider_ValueChanged;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400029B RID: 667
		private MainWindow ParentWindow;

		// Token: 0x0400029C RID: 668
		private static double sCurrentTransparency = 0.0;

		// Token: 0x0400029D RID: 669
		private static double sPreviousTransparency = 0.0;

		// Token: 0x0400029E RID: 670
		private static int sCurrentVolume = 33;

		// Token: 0x0400029F RID: 671
		private static int sPreviousVolume = 33;

		// Token: 0x040002A0 RID: 672
		public static readonly DependencyProperty VolumeImageNameProperty = DependencyProperty.Register("VolumeImageName", typeof(string), typeof(DMMBottomBar), new FrameworkPropertyMetadata("volume_small", new PropertyChangedCallback(DMMBottomBar.OnVolumeImageNameChanged)));

		// Token: 0x040002A1 RID: 673
		internal Grid DMMBottomGrid;

		// Token: 0x040002A2 RID: 674
		internal CustomPictureBox mKeyMapSwitch;

		// Token: 0x040002A3 RID: 675
		internal CustomPictureBox mKeyMapButton;

		// Token: 0x040002A4 RID: 676
		internal CustomPictureBox mTranslucentControlsButton;

		// Token: 0x040002A5 RID: 677
		internal CustomPictureBox mScreenshotBtn;

		// Token: 0x040002A6 RID: 678
		internal CustomPictureBox mVolumeBtn;

		// Token: 0x040002A7 RID: 679
		internal CustomPictureBox mFullscreenBtn;

		// Token: 0x040002A8 RID: 680
		internal CustomPictureBox mSettingsBtn;

		// Token: 0x040002A9 RID: 681
		internal CustomPictureBox mRecommendedWindowBtn;

		// Token: 0x040002AA RID: 682
		internal CustomPopUp mVolumePopup;

		// Token: 0x040002AB RID: 683
		internal CustomPictureBox volumesSliderImage;

		// Token: 0x040002AC RID: 684
		internal Slider mVolumeSlider;

		// Token: 0x040002AD RID: 685
		internal CustomPopUp mKeyMapPopup;

		// Token: 0x040002AE RID: 686
		internal TextBlock mKeyMappingPopUp1;

		// Token: 0x040002AF RID: 687
		internal TextBlock mKeyMappingPopUp3;

		// Token: 0x040002B0 RID: 688
		internal CustomPictureBox mDoNotPromptChkBx;

		// Token: 0x040002B1 RID: 689
		internal TextBlock mKeyMappingDontShowPopUp;

		// Token: 0x040002B2 RID: 690
		internal Path DownArrow;

		// Token: 0x040002B3 RID: 691
		internal CustomPopUp mChangeTransparencyPopup;

		// Token: 0x040002B4 RID: 692
		internal CustomPictureBox mTranslucentControlsSliderButton;

		// Token: 0x040002B5 RID: 693
		internal Slider transSlider;

		// Token: 0x040002B6 RID: 694
		private bool _contentLoaded;
	}
}
