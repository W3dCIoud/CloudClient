﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Windows;
using System.Windows.Forms;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001A6 RID: 422
	internal class BlueStacksUIHTTPHandler
	{
		// Token: 0x06000FA5 RID: 4005 RVA: 0x0000B6BD File Offset: 0x000098BD
		private static void WriteSuccessJsonArray(HttpListenerResponse res)
		{
			HTTPUtils.Write(new JArray
			{
				new JObject
				{
					new JProperty("success", true)
				}
			}.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x06000FA6 RID: 4006 RVA: 0x0006211C File Offset: 0x0006031C
		private static void WriteErrorJsonArray(string reason, HttpListenerResponse res)
		{
			HTTPUtils.Write(new JArray
			{
				new JObject
				{
					new JProperty("success", false),
					new JProperty("reason", reason)
				}
			}.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x06000FA7 RID: 4007 RVA: 0x0000B6F7 File Offset: 0x000098F7
		private static void WriteErrorJSONObjectWithoutReason(HttpListenerResponse res)
		{
			HTTPUtils.Write(new JObject
			{
				{
					"success",
					false
				}
			}.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x06000FA8 RID: 4008 RVA: 0x0000B721 File Offset: 0x00009921
		public static void PingHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			BlueStacksUIHTTPHandler.WriteSuccessJsonWithVmName(HTTPUtils.ParseRequest(req).requestVmName, res);
		}

		// Token: 0x06000FA9 RID: 4009 RVA: 0x00062174 File Offset: 0x00060374
		internal static void EnableWndProcLogging(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				WindowWndProcHandler.isLogWndProc = !WindowWndProcHandler.isLogWndProc;
				Logger.Info("Got request for EnableWndProcLogging" + WindowWndProcHandler.isLogWndProc.ToString());
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in set EnableWndProcLogging... Err : " + ex.ToString());
			}
		}

		// Token: 0x06000FAA RID: 4010 RVA: 0x000621D4 File Offset: 0x000603D4
		internal static void EnableKeyboardHookLogging(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				GlobalKeyBoardMouseHooks.sIsEnableKeyboardHookLogging = !GlobalKeyBoardMouseHooks.sIsEnableKeyboardHookLogging;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in set EnableKeyboardHookLogging... Err : " + ex.ToString());
			}
		}

		// Token: 0x06000FAB RID: 4011 RVA: 0x00062218 File Offset: 0x00060418
		internal static void EnableDebugLogs(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				Logger.EnableDebugLogs();
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in EnableDebugLogs... Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FAC RID: 4012 RVA: 0x00062260 File Offset: 0x00060460
		public static void SendAppDisplayed(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				JObject jobject = new JObject();
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					jobject.Add("success", BlueStacksUIUtils.DictWindows[requestData.requestVmName].mAppHandler.mAppDisplayedOccured);
				}
				HTTPUtils.Write(jobject.ToString(Formatting.None, new JsonConverter[0]), res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server SendAppDisplayed. Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FAD RID: 4013 RVA: 0x000622FC File Offset: 0x000604FC
		internal static void RestartFrontend(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].RestartFrontend();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server RestartFrontend. Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FAE RID: 4014 RVA: 0x00062368 File Offset: 0x00060568
		internal static void GCCollect(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				GC.Collect();
				GC.WaitForPendingFinalizers();
				GC.Collect();
				BlueStacksUIHTTPHandler.WriteSuccessJsonWithVmName(requestData.requestVmName, res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server GCCollect. Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FAF RID: 4015 RVA: 0x000623C8 File Offset: 0x000605C8
		public static void IsBlueStacksUIVisible(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				JObject jobject = new JObject();
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					jobject.Add("success", BlueStacksUIUtils.DictWindows[requestData.requestVmName].IsVisible);
				}
				HTTPUtils.Write(jobject.ToString(Formatting.None, new JsonConverter[0]), res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server IsBlueStacksUIVisible. Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FB0 RID: 4016 RVA: 0x0006245C File Offset: 0x0006065C
		internal static void ToggleFarmMode(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				CommonHandlers.ToggleFarmMode();
				BlueStacksUIHTTPHandler.WriteSuccessJsonWithVmName(requestData.requestVmName, res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server ToggleFarmMode. Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FB1 RID: 4017 RVA: 0x000624B0 File Offset: 0x000606B0
		internal static void ToggleStreamingMode(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				bool state = bool.Parse(requestData.data["state"]);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					MainWindow mWindow = BlueStacksUIUtils.DictWindows[requestData.requestVmName];
					mWindow.Dispatcher.Invoke(new Action(delegate()
					{
						mWindow.mTopBar.mPreferenceDropDownControl.ToggleStreamingMode(state);
						mWindow.mFrontendHandler.ToggleStreamingMode(state);
					}), new object[0]);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonWithVmName(requestData.requestVmName, res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server ToggleStreamingMode. Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FB2 RID: 4018 RVA: 0x0006257C File Offset: 0x0006077C
		internal static void GamepadGuidanceButtonHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					MainWindow mWindow = BlueStacksUIUtils.DictWindows[requestData.requestVmName];
					mWindow.Dispatcher.Invoke(new Action(delegate()
					{
						if (KMManager.CheckIfKeymappingWindowVisible())
						{
							KMManager.CloseWindows();
							return;
						}
						KMManager.HandleInputMapperWindow(mWindow, true, "gamepad");
					}), new object[0]);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonWithVmName(requestData.requestVmName, res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GamepadGuidanceButtonHandler. Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FB3 RID: 4019 RVA: 0x00062620 File Offset: 0x00060820
		internal static void SetCurrentVolumeFromAndroidHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.requestVmName;
				int volumeLevelFromAndroid = Convert.ToInt32(requestData.data["volume"]);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestVmName].Utils.SetVolumeLevelFromAndroid(volumeLevelFromAndroid);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to set volume level. Er : " + ex.ToString());
			}
		}

		// Token: 0x06000FB4 RID: 4020 RVA: 0x0006269C File Offset: 0x0006089C
		internal static void NCSetGameInfoOnTopBarHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.requestVmName;
				string gameName = requestData.data["game"];
				string characterName = requestData.data["character"];
				MainWindow mWindow = BlueStacksUIUtils.DictWindows[requestVmName];
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestVmName))
				{
					mWindow.Dispatcher.Invoke(new Action(delegate()
					{
						mWindow.mNCTopBar.mAppName.Text = gameName;
						mWindow.mNCTopBar.mAppName.ToolTip = gameName;
						mWindow.mNCTopBar.mGamenameSeparator.Visibility = Visibility.Visible;
						mWindow.mNCTopBar.mCharacterName.Text = characterName;
						mWindow.mNCTopBar.mCharacterName.ToolTip = characterName;
					}), new object[0]);
					BlueStacksUIHTTPHandler.WriteSuccessJsonWithVmName(requestVmName, res);
				}
				else
				{
					BlueStacksUIHTTPHandler.WriteErrorJsonArray("Client Instance not running", res);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to set GameInfo err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x06000FB5 RID: 4021 RVA: 0x00062774 File Offset: 0x00060974
		internal static void OpenThemeEditor(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				if (RegistryManager.Instance.OpenThemeEditor)
				{
					BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>()[0].Dispatcher.Invoke(new Action(delegate()
					{
						ThemeEditorWindow.Instance.Show();
					}), new object[0]);
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000FB6 RID: 4022 RVA: 0x000627E8 File Offset: 0x000609E8
		internal static void MuteAllInstancesHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			bool flag = Convert.ToBoolean(HTTPUtils.ParseRequest(req).data["muteInstance"]);
			foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values)
			{
				if (flag)
				{
					mainWindow.Utils.MuteApplication(true);
				}
				else
				{
					mainWindow.Utils.UnmuteApplication(true);
				}
			}
		}

		// Token: 0x06000FB7 RID: 4023 RVA: 0x00062870 File Offset: 0x00060A70
		internal static void AccountSetupCompleted(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.requestVmName;
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName) && FeatureManager.Instance.IsCustomUIForNCSoft)
				{
					NCSoftUtils.Instance.SendGoogleLoginEventAsync(requestVmName);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in AccountSetupCompleted Handler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FB8 RID: 4024 RVA: 0x000628EC File Offset: 0x00060AEC
		internal static void GetHeightWidth(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.requestVmName;
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName) && BlueStacksUIUtils.DictWindows[vmName] != null)
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						try
						{
							MainWindow mainWindow = BlueStacksUIUtils.DictWindows[vmName];
							JArray jarray = new JArray();
							JObject jobject = new JObject();
							jobject.Add(new JProperty("success", true));
							JObject jobject2 = new JObject();
							jobject2.Add(new JProperty("cHeight", mainWindow.ActualHeight));
							jobject2.Add(new JProperty("cWidth", mainWindow.ActualWidth));
							jobject2.Add(new JProperty("gHeight", mainWindow.mContentGrid.ActualHeight));
							jobject2.Add(new JProperty("gWidth", mainWindow.mContentGrid.ActualWidth));
							jarray.Add(jobject);
							jarray.Add(new JObject
							{
								new JProperty("result", jobject2)
							});
							HTTPUtils.Write(jarray.ToString(Formatting.None, new JsonConverter[0]), res);
						}
						catch (Exception ex2)
						{
							Logger.Error("Some error in finding MainWindow instance err: " + ex2.ToString());
							BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex2.Message, res);
						}
					}), new object[0]);
				}
				else
				{
					BlueStacksUIHTTPHandler.WriteErrorJsonArray("Client Instance not running", res);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to GetHeightWidth err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x06000FB9 RID: 4025 RVA: 0x000629CC File Offset: 0x00060BCC
		internal static void ScreenLock(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.requestVmName;
				bool lockScreen = Convert.ToBoolean(requestData.data["lock"]);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						if (lockScreen)
						{
							BlueStacksUIUtils.DictWindows[vmName].ShowLockScreen();
							return;
						}
						BlueStacksUIUtils.DictWindows[vmName].HideLockScreen();
					}), new object[0]);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to lock screen err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x06000FBA RID: 4026 RVA: 0x00062A88 File Offset: 0x00060C88
		internal static void SetStreamingStatus(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.requestVmName;
				string status = requestData.data["status"];
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[vmName].mCommonHandler.SetNcSoftStreamingStatus(status);
					}), new object[0]);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to SetStreamingStatus err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x06000FBB RID: 4027 RVA: 0x00062B40 File Offset: 0x00060D40
		internal static void PlayerScriptModifierKeyUp(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.requestVmName;
				double x = Convert.ToDouble(requestData.data["X"]);
				double y = Convert.ToDouble(requestData.data["Y"]);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[vmName].mCommonHandler.AddCoordinatesToScriptText(x, y);
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to handle player script modifier key up: " + ex.ToString());
			}
		}

		// Token: 0x06000FBC RID: 4028 RVA: 0x00062C08 File Offset: 0x00060E08
		internal static void LaunchPlay(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string key = requestData.data["vmname"];
				string package = requestData.data["package"];
				if (BlueStacksUIUtils.DictWindows.ContainsKey(key))
				{
					BlueStacksUIUtils.DictWindows[key].Utils.HandleLaunchPlay(package);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to launch play store err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x06000FBD RID: 4029 RVA: 0x00062C9C File Offset: 0x00060E9C
		internal static void FullScreenSidebarHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.requestVmName;
				bool isVisible = Convert.ToBoolean(requestData.data["visible"]);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestVmName))
				{
					MainWindow window = BlueStacksUIUtils.ActivatedWindow;
					if (window != null && window.mIsFullScreen && !window.mFrontendHandler.IsShootingModeActivated)
					{
						window.Dispatcher.Invoke(new Action(delegate()
						{
							window.mSidebar.ToggleSidebarVisibilityInFullscreen(isVisible);
						}), new object[0]);
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000FBE RID: 4030 RVA: 0x00062D5C File Offset: 0x00060F5C
		internal static void HandleGamepadConnection(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				bool isGamepadConnected = bool.Parse(requestData.data["status"]);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].IsGamepadConnected = isGamepadConnected;
					if (!BlueStacksUIHTTPHandler.mSendGamepadStats)
					{
						ClientStats.SendMiscellaneousStatsAsync("GamePadConnectedStats", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, null, null, null, null, null, null);
						BlueStacksUIHTTPHandler.mSendGamepadStats = true;
					}
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonWithVmName(requestData.requestVmName, res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in HandleGamepadConnection. Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FBF RID: 4031 RVA: 0x00062E1C File Offset: 0x0006101C
		internal static void TileWindow(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				HTTPUtils.ParseRequest(req);
				CommonHandlers.ArrangeWindowInTiles();
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in tiling window. Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FC0 RID: 4032 RVA: 0x00062E6C File Offset: 0x0006106C
		internal static void CascadeWindow(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				CommonHandlers.ArrangeWindowInCascade();
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Cascading window. Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FC1 RID: 4033 RVA: 0x00062EBC File Offset: 0x000610BC
		internal static void UpdateLocale(HttpListenerRequest req, HttpListenerResponse res)
		{
			Logger.Info("Got UpdateLocale {0} request from {1}", new object[]
			{
				req.HttpMethod,
				req.RemoteEndPoint.ToString()
			});
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.requestVmName;
				string text = requestData.data["locale"].ToString();
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestVmName))
				{
					RegistryManager.Instance.UserSelectedLocale = text;
					Utils.UpdateValueInBootParams("LANG", text, requestVmName, false);
					BlueStacksUIUtils.DictWindows[requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						LocaleStrings.InitLocalization(null);
					}), new object[0]);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in UpdateLocale: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FC2 RID: 4034 RVA: 0x00062FB0 File Offset: 0x000611B0
		internal static void ScreenshotCaptured(HttpListenerRequest req, HttpListenerResponse res)
		{
			Logger.Info("Got ScreenshotCaptured {0} request from {1}", new object[]
			{
				req.HttpMethod,
				req.RemoteEndPoint.ToString()
			});
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.requestVmName;
				string path = requestData.data["path"].ToString();
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[vmName].mCommonHandler.PostScreenShotWork(path);
					}), new object[0]);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ScreenshotCaptured: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FC3 RID: 4035 RVA: 0x00063094 File Offset: 0x00061294
		internal static void ClientHotkeyHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.requestVmName;
				string value = requestData.data["keyevent"].ToString();
				ClientHotKeys clientHotKey = (ClientHotKeys)Enum.Parse(typeof(ClientHotKeys), value);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[vmName].HandleClientHotKey(clientHotKey);
					}), new object[0]);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ClientHotkeyHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FC4 RID: 4036 RVA: 0x00063168 File Offset: 0x00061368
		internal static void AndroidLocaleChanged(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				BlueStacksUIUtils.UpdateLocale(RegistryManager.Instance.UserSelectedLocale, requestData.requestVmName);
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in AndroidLocaleChanged. Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FC5 RID: 4037 RVA: 0x000631C8 File Offset: 0x000613C8
		internal static void HandleClientOperation(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					string operationString = requestData.data["data"];
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].mCommonHandler.HandleClientOperation(operationString);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in HandleClientOperation. Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FC6 RID: 4038 RVA: 0x00063250 File Offset: 0x00061450
		internal static void MacroPlaybackCompleteHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[requestData.requestVmName].SetMacroPlayBackEventHandle();
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in MacroPlaybackCompleteHandler. Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FC7 RID: 4039 RVA: 0x000632E8 File Offset: 0x000614E8
		internal static void HandleClientGamepadButtonHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						string text = requestData.data["data"];
						bool isDown;
						bool.TryParse(requestData.data["isDown"], out isDown);
						KMManager.UpdateUIForGamepadEvent(text, isDown);
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in HandleClientGamepadButtonHandler. Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FC8 RID: 4040 RVA: 0x00063380 File Offset: 0x00061580
		internal static void SaveComboEvents(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string events = requestData.data["events"];
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					if (BlueStacksUIUtils.DictWindows[requestData.requestVmName].mIsOperationRecorderActive)
					{
						if (BlueStacksUIUtils.DictWindows[requestData.requestVmName].OperationRecorderWindow != null)
						{
							BlueStacksUIUtils.DictWindows[requestData.requestVmName].OperationRecorderWindow.SaveOperation(events);
						}
					}
					else
					{
						BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
						{
							KMManager.mComboEvents = events;
						}), new object[0]);
					}
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in SaveComboEvents. Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FC9 RID: 4041 RVA: 0x00063478 File Offset: 0x00061678
		internal static void MacroCompleted(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[requestData.requestVmName].MacroOverlayControl.ShowPromptAndHideOverlay();
					}), new object[0]);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in MacroCompleted. Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FCA RID: 4042 RVA: 0x00063518 File Offset: 0x00061718
		internal static void ShowMaintenanceWarning(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.requestVmName;
				string message = requestData.data["message"];
				BlueStacksUIHTTPHandler.WriteJSON(new Dictionary<string, string>
				{
					{
						"result_code",
						"0"
					}
				}, res);
				BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
				{
					CustomMessageWindow customMessageWindow = new CustomMessageWindow();
					customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("BlueStacks", false) + " " + LocaleStrings.GetLocalizedString("STRING_WARNING", false);
					customMessageWindow.AddButton(ButtonColors.Blue, LocaleStrings.GetLocalizedString("STRING_OK", false), null, null, false, null);
					customMessageWindow.BodyTextBlock.Text = message;
					customMessageWindow.Owner = BlueStacksUIUtils.DictWindows[vmName];
					BlueStacksUIUtils.DictWindows[vmName].ShowDimOverlay(null);
					customMessageWindow.ShowDialog();
					BlueStacksUIUtils.DictWindows[vmName].HideDimOverlay();
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to ShowMaintenanceWarning app... Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteJSON(new Dictionary<string, string>
				{
					{
						"result_code",
						"-1"
					}
				}, res);
			}
		}

		// Token: 0x06000FCB RID: 4043 RVA: 0x0000B734 File Offset: 0x00009934
		internal static void WriteJSON(Dictionary<string, string> data, HttpListenerResponse res)
		{
			HTTPUtils.Write(JSONUtils.GetJSONArrayString(data), res);
		}

		// Token: 0x06000FCC RID: 4044 RVA: 0x000635E4 File Offset: 0x000617E4
		internal static void LaunchDefaultWebApp(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string text = requestData.data["action"];
				Logger.Info("Action : " + text);
				if (!(text == "browser"))
				{
					if (!(text == "email"))
					{
						BlueStacksUIHTTPHandler.WriteErrorJsonArray("wrong or empty action", res);
						goto IL_21A;
					}
				}
				else
				{
					string text2 = requestData.data["url"];
					Logger.Info("Url : " + text2);
					try
					{
						Process.Start(text2);
						BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
						goto IL_21A;
					}
					catch
					{
						BlueStacksUIHTTPHandler.WriteErrorJsonArray("Invalid or empty url", res);
						goto IL_21A;
					}
				}
				string text3 = "";
				string text4 = "";
				string text5 = "";
				string text6 = "";
				string text7 = "";
				string text8 = "";
				try
				{
					text3 = requestData.data["to"];
					text4 = requestData.data["cc"];
					text5 = requestData.data["bcc"];
					text6 = requestData.data["message"];
					text7 = requestData.data["subject"];
					text8 = requestData.data["mailto"];
				}
				catch
				{
				}
				bool flag = false;
				if (!string.IsNullOrEmpty(text3))
				{
					flag = (text3.Split(new char[]
					{
						'@'
					}).Length > 1);
				}
				Logger.Info(string.Concat(new string[]
				{
					"to : ",
					text3,
					", cc : ",
					text4,
					", bcc : ",
					text5,
					", subject = ",
					text7
				}));
				Logger.Info("mailto : " + text8);
				string text9;
				if (flag)
				{
					text9 = string.Format("mailto:{0}?cc={1}&bcc={2}&subject={3}&body={4}", new object[]
					{
						text3,
						text4,
						text5,
						text7,
						text6
					});
				}
				else
				{
					if (string.IsNullOrEmpty(text8))
					{
						BlueStacksUIHTTPHandler.WriteErrorJsonArray("to and mailto field cannot be empty", res);
						goto IL_21A;
					}
					text9 = text8;
				}
				Logger.Info("mail to request : " + text9);
				Process.Start(text9);
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
				IL_21A:;
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to LaunchDefaultWebApp app... Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x06000FCD RID: 4045 RVA: 0x00063880 File Offset: 0x00061A80
		public static void GetRunningInstances(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				List<string> list = new List<string>(BlueStacksUIUtils.DictWindows.Keys);
				HTTPUtils.ParseRequest(req);
				JObject jobject = new JObject();
				string text = string.Join(",", list.ToArray());
				Logger.Info("Running instances: " + text);
				jobject.Add("success", true);
				jobject.Add("vmname", text);
				HTTPUtils.Write(jobject.ToString(Formatting.None, new JsonConverter[0]), res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GetRunningInstances");
				Logger.Error(ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FCE RID: 4046 RVA: 0x0006392C File Offset: 0x00061B2C
		internal static void IsAnyAppRunning(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				JObject jobject = new JObject();
				jobject.Add("success", true);
				bool isAppRunning = false;
				if (BlueStacksUIUtils.DictWindows.Count > 0)
				{
					MainWindow window = BlueStacksUIUtils.DictWindows[BlueStacksUIUtils.DictWindows.Keys.ToList<string>()[0]];
					window.Dispatcher.Invoke(new Action(delegate()
					{
						isAppRunning = window.mTopBar.mAppTabButtons.IsAppRunning();
					}), new object[0]);
					jobject.Add("isanyapprunning", isAppRunning);
				}
				HTTPUtils.Write(jobject.ToString(Formatting.None, new JsonConverter[0]), res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in IsAnyAppRunning: {0}", new object[]
				{
					ex
				});
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FCF RID: 4047 RVA: 0x00063A24 File Offset: 0x00061C24
		internal static void GetCurrentAppDetails(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				JObject jobject = new JObject();
				jobject.Add("success", true);
				if (BlueStacksUIUtils.DictWindows.Count > 0)
				{
					MainWindow window = BlueStacksUIUtils.DictWindows[BlueStacksUIUtils.DictWindows.Keys.ToList<string>()[0]];
					string pkg = string.Empty;
					string appName = string.Empty;
					string tabType = string.Empty;
					window.Dispatcher.Invoke(new Action(delegate()
					{
						pkg = window.mTopBar.mAppTabButtons.SelectedTab.PackageName;
						appName = (string)window.mTopBar.mAppTabButtons.SelectedTab.mTabLabel.Content;
						tabType = window.mTopBar.mAppTabButtons.SelectedTab.mTabType.ToString();
					}), new object[0]);
					jobject.Add("pkgname", pkg);
					jobject.Add("appname", appName);
					jobject.Add("tabtype", tabType);
				}
				HTTPUtils.Write(jobject.ToString(Formatting.None, new JsonConverter[0]), res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GetCurrentAppDetails: {0}", new object[]
				{
					ex
				});
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FD0 RID: 4048 RVA: 0x00063B54 File Offset: 0x00061D54
		internal static void ShowSettingWindow(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					MainWindow window = BlueStacksUIUtils.DictWindows[requestData.requestVmName];
					window.Dispatcher.Invoke(new Action(delegate()
					{
						SettingsWindow control = new SettingsWindow(window, "NotificationText");
						int num = 500;
						int num2 = 750;
						new ContainerWindow(window, control, (double)num2, (double)num, false, true);
					}), new object[0]);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server ShowSettingWindow: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FD1 RID: 4049 RVA: 0x00063BF8 File Offset: 0x00061DF8
		internal static void LaunchWebTab(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					MainWindow window = BlueStacksUIUtils.DictWindows[requestData.requestVmName];
					window.Dispatcher.Invoke(new Action(delegate()
					{
						window.mTopBar.mAppTabButtons.AddWebTab(requestData.data["url"], requestData.data["name"], requestData.data["image"], true, "", false);
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server OneTimeSetupCompletedHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FD2 RID: 4050 RVA: 0x00063CB4 File Offset: 0x00061EB4
		internal static void OneTimeSetupCompletedHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				MainWindow mainWindow = BlueStacksUIUtils.DictWindows[requestData.requestVmName];
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					ClientStats.SendMiscellaneousStatsAsync("OTSActivityDisplayed", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "OTS Completed", "OTS Completed", null, RegistryManager.Instance.CurrentEngine, mainWindow.EngineInstanceRegistry.GlMode.ToString(), mainWindow.EngineInstanceRegistry.GlRenderMode.ToString());
					mainWindow.mAppHandler.IsOneTimeSetupCompleted = true;
					ClientStats.SendMiscellaneousStatsAsync("OTSActivityDisplayed", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "OTS Completed", "OTS Completed", RegistryManager.Instance.InstallID, RegistryManager.Instance.CurrentEngine, mainWindow.EngineInstanceRegistry.GlMode.ToString(), mainWindow.EngineInstanceRegistry.GlRenderMode.ToString());
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server OneTimeSetupCompletedHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FD3 RID: 4051 RVA: 0x00063DEC File Offset: 0x00061FEC
		internal static void AppJsonChangedHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].mWelcomeTab.mHomeApp.ReInitAppJson();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in AppjsonChangedHabdler " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FD4 RID: 4052 RVA: 0x00063E68 File Offset: 0x00062068
		internal static void StartInstanceHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				string requestVmName = HTTPUtils.ParseRequest(req).requestVmName;
				Logger.Info("start instance vm name :" + requestVmName);
				RegistryManager.ClearRegistryMangerInstance();
				BlueStacksUIUtils.RunInstance(requestVmName, false);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server StartInstanceHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FD5 RID: 4053 RVA: 0x00063ED4 File Offset: 0x000620D4
		internal static void StopInstanceHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				string requestVmName = HTTPUtils.ParseRequest(req).requestVmName;
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestVmName].ForceCloseWindow();
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server StopInstanceHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FD6 RID: 4054 RVA: 0x00063F48 File Offset: 0x00062148
		internal static void HideBluestacksHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				HTTPUtils.ParseRequest(req);
				Logger.Info("Hide Bluestacks received");
				BlueStacksUIUtils.HideUnhideBlueStacks(true);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server HideBluestacksHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FD7 RID: 4055 RVA: 0x00063FA4 File Offset: 0x000621A4
		internal static void OpenOrInstallPackageHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.requestVmName;
				string text = requestData.data["json"].ToString();
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIHTTPHandler.ShowWindowHandler(req, res);
					if (!string.IsNullOrEmpty(text))
					{
						if (BlueStacksUIUtils.DictWindows[requestData.requestVmName].mAppHandler.IsOneTimeSetupCompleted)
						{
							new DownloadInstallApk(BlueStacksUIUtils.DictWindows[requestVmName]).DownloadAndInstallAppFromJson(text, "openPackage");
						}
						else
						{
							Opt.Instance.Json = text;
						}
					}
				}
				else
				{
					Opt.Instance.Json = text;
					BlueStacksUIHTTPHandler.ShowWindowHandler(req, res);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in OpenOrInstallPackageHandler. Err : " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FD8 RID: 4056 RVA: 0x00064080 File Offset: 0x00062280
		internal static void GuestBootCompleted(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					bool isGuestReady = BlueStacksUIUtils.DictWindows[requestData.requestVmName].mAppHandler.IsGuestReady;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in server GuestBootCompleted: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FD9 RID: 4057 RVA: 0x000640F8 File Offset: 0x000622F8
		public static void AppDisplayedHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.data.AllKeys)
				{
					Logger.Debug("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.data[text]
					});
				}
				string text2 = requestData.data["packageName"];
				string text3 = requestData.data["appDisplayed"];
				object obj = BlueStacksUIHTTPHandler.sLockObject;
				lock (obj)
				{
					if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
					{
						MainWindow mainWindow = BlueStacksUIUtils.DictWindows[requestData.requestVmName];
						if (FeatureManager.Instance.IsCustomUIForDMM)
						{
							mainWindow.mAppHandler.HandleAppDisplayed(text2);
						}
						if (!mainWindow.EngineInstanceRegistry.IsOneTimeSetupDone && text2 != "com.bluestacks.appmart" && !mainWindow.mGuestBootCompleted)
						{
							int num = 20;
							while (!mainWindow.mAppHandler.IsGuestReady && num > 0)
							{
								num--;
								Thread.Sleep(1000);
							}
							if (text2 == mainWindow.mAppHandler.GetDefaultLauncher())
							{
								if (!FeatureManager.Instance.IsCustomUIForNCSoft)
								{
									Logger.Info("BOOT_STAGE: Calling guestboot_completed from AppDisplayedHandler");
									mainWindow.GuestBoot_Completed();
								}
								else
								{
									mainWindow.Utils.sBootCheckTimer.Enabled = false;
									mainWindow.mEnableLaunchPlayForNCSoft = true;
								}
							}
						}
					}
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server AppDisplayedHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FDA RID: 4058 RVA: 0x000642CC File Offset: 0x000624CC
		public static void AppLaunchedHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.data.AllKeys)
				{
					Logger.Debug("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.data[text]
					});
				}
				string text2 = requestData.data["package"];
				string text3 = requestData.data["activity"];
				string arg = requestData.data["callingPackage"];
				Logger.Info(string.Format("Package: {0}, activity: {1}, callingPackage: {2}", text2, text3, arg));
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					MainWindow mainWindow = BlueStacksUIUtils.DictWindows[requestData.requestVmName];
					if (!RegistryManager.Instance.Guest[requestData.requestVmName].IsGoogleSigninDone)
					{
						object obj = BlueStacksUIHTTPHandler.syncRoot;
						lock (obj)
						{
							if (string.Compare(BlueStacksUIHTTPHandler.mPreviousActivityReported.Replace("/", ""), text3.Replace("/", ""), true) != 0)
							{
								BlueStacksUIHTTPHandler.mPreviousActivityReported = text3;
								ClientStats.SendMiscellaneousStatsAsync("OTSActivityDisplayed", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, text2, text3, RegistryManager.Instance.InstallID, RegistryManager.Instance.CurrentEngine, mainWindow.EngineInstanceRegistry.GlMode.ToString(), mainWindow.EngineInstanceRegistry.GlRenderMode.ToString());
							}
						}
					}
					if (FeatureManager.Instance.IsCustomUIForNCSoft && !mainWindow.mGuestBootCompleted && !text2.Equals("com.bluestacks.appmart", StringComparison.OrdinalIgnoreCase) && !text2.Equals("com.android.provision", StringComparison.OrdinalIgnoreCase))
					{
						mainWindow.GuestBoot_Completed();
					}
					if (mainWindow.mGuestBootCompleted)
					{
						mainWindow.mAppHandler.AppLaunched(text2, false);
					}
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server AppLaunchedHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FDB RID: 4059 RVA: 0x00064514 File Offset: 0x00062714
		public static void AppCrashedHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.data.AllKeys)
				{
					Logger.Debug("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.data[text]
					});
				}
				string vmName = requestData.requestVmName;
				string package = requestData.data["package"];
				Logger.Info("package: " + package);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[vmName].mTopBar.mAppTabButtons.CloseTab(string.Format("app:{0}", package), false, false, true, false, "");
					}), new object[0]);
					if (FeatureManager.Instance.IsCustomUIForNCSoft && !NCSoftUtils.Instance.BlackListedApps.Any((string pkg) => package.StartsWith(pkg)))
					{
						NCSoftUtils.Instance.SendAppCrashEvent("check android logs", vmName);
					}
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server AppCrashedHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FDC RID: 4060 RVA: 0x00064674 File Offset: 0x00062874
		public static void MacroDownloaded(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.data.AllKeys)
				{
					Logger.Debug("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.data[text]
					});
				}
				string package = requestData.data["packageName"];
				BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
				{
					foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
					{
						if (keyValuePair.Value.mWelcomeTab.mHomeApp.GetAppIcon(package) != null && keyValuePair.Value.mWelcomeTab.mHomeApp.GetMacroAppIcon(package) == null)
						{
							keyValuePair.Value.mWelcomeTab.mHomeApp.AddMacroAppIcon(package);
						}
					}
				}), new object[0]);
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server MacroDownloaded: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FDD RID: 4061 RVA: 0x00064754 File Offset: 0x00062954
		internal static void AppInfoUpdated(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string package = requestData.data["packageName"];
				if (!string.IsNullOrEmpty(requestData.data["macro"]) && requestData.data["macro"].Equals("true", StringComparison.InvariantCultureIgnoreCase))
				{
					foreach (string text in requestData.data.AllKeys)
					{
						Logger.Debug("Key: {0}, Value: {1}", new object[]
						{
							text,
							requestData.data[text]
						});
					}
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
						{
							if (keyValuePair.Value.mWelcomeTab.mHomeApp.GetAppIcon(package) != null && keyValuePair.Value.mWelcomeTab.mHomeApp.GetMacroAppIcon(package) == null)
							{
								keyValuePair.Value.mWelcomeTab.mHomeApp.AddMacroAppIcon(package);
							}
						}
					}), new object[0]);
					BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
				}
				if (!string.IsNullOrEmpty(requestData.data["videoPresent"]) && BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					string value = requestData.data["videoPresent"].ToString();
					Dictionary<string, string> data = new Dictionary<string, string>
					{
						{
							"packageName",
							package
						},
						{
							"videoPresent",
							value
						}
					};
					HTTPUtils.SendRequestToAgentAsync("appJsonUpdatedForVideo", data, requestData.requestVmName, 0, null, true, 1, 0);
				}
				KMManager.ControlSchemesHandlingWhileCfgUpdateFromCloud(package);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server AppInfoDownload: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FDE RID: 4062 RVA: 0x00064908 File Offset: 0x00062B08
		public static void CloseTabHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.data.AllKeys)
				{
					Logger.Debug("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.data[text]
					});
				}
				string package = requestData.data["package"];
				Logger.Info("package: " + package);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						try
						{
							BlueStacksUIUtils.DictWindows[requestData.requestVmName].mTopBar.mAppTabButtons.CloseTab(package, false, false, true, false, "");
						}
						catch (Exception ex2)
						{
							Logger.Error("Exception in closing tab. Err : ", new object[]
							{
								ex2.ToString()
							});
						}
					}), new object[0]);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server TabCloseHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FDF RID: 4063 RVA: 0x00064A2C File Offset: 0x00062C2C
		public static void ShowAppHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.data.AllKeys)
				{
					Logger.Debug("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.data[text]
					});
				}
				string package = requestData.data["package"];
				string activity = requestData.data["activity"];
				string str = requestData.data["title"];
				Logger.Info("package: " + package);
				Logger.Info("activity: " + activity);
				Logger.Info("title : " + str);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					new Thread(delegate()
					{
						BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
						{
							if (!string.IsNullOrEmpty(package) && !string.IsNullOrEmpty(activity))
							{
								BlueStacksUIUtils.DictWindows[requestData.requestVmName].mAppHandler.SendRunAppRequestAsync(package, activity, false);
							}
						}), new object[0]);
					})
					{
						IsBackground = true
					}.Start();
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server ShowAppHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FE0 RID: 4064 RVA: 0x00064BA0 File Offset: 0x00062DA0
		public static void ShowWindowHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string text = requestData.requestVmName;
				if (requestData.data.AllKeys.Contains("vmname"))
				{
					text = requestData.data["vmname"];
				}
				bool flag = requestData.data["hidden"] != null && Convert.ToBoolean(requestData.data["hidden"]);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(text))
				{
					if (!flag)
					{
						BlueStacksUIUtils.DictWindows[text].ShowWindow(false);
					}
				}
				else
				{
					RegistryManager.ClearRegistryMangerInstance();
					BlueStacksUIUtils.RunInstance(text, flag);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server ShowWindowHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FE1 RID: 4065 RVA: 0x00064C7C File Offset: 0x00062E7C
		public static void ShowWindowAndAppHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIHTTPHandler.ShowWindowHandler(req, res);
						BlueStacksUIHTTPHandler.ShowAppHandler(req, res);
					}), new object[0]);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server ShowWindowAndAppHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FE2 RID: 4066 RVA: 0x00064D30 File Offset: 0x00062F30
		public static void IsVisibleHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					if (BlueStacksUIUtils.DictWindows[requestData.requestVmName].IsVisible)
					{
						BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
					}
					else
					{
						BlueStacksUIHTTPHandler.WriteErrorJsonArray("unused", res);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server IsVisibleHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FE3 RID: 4067 RVA: 0x00064DB8 File Offset: 0x00062FB8
		public static void AppUninstalledHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.data.AllKeys)
				{
					Logger.Debug("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.data[text]
					});
				}
				string package = requestData.data["package"];
				string title = requestData.data["name"];
				Logger.Info("package: " + package);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[requestData.requestVmName].mAppHandler.AppUninstalled(package);
					}), new object[0]);
				}
				NotificationManager.Instance.RemoveNotificationItem(title);
				ClientStats.SendClientStatsAsync("uninstall", "success", "app_install", package, "", "");
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server AppUninstalledHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FE4 RID: 4068 RVA: 0x00064F30 File Offset: 0x00063130
		public static void AppInstalledHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.data.AllKeys)
				{
					Logger.Info("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.data[text]
					});
				}
				string package = requestData.data["package"];
				Logger.Info("package: " + package);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[requestData.requestVmName].mAppHandler.AppInstalled(package);
					}), new object[0]);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server AppInstalledHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06000FE5 RID: 4069 RVA: 0x00065054 File Offset: 0x00063254
		public static void ShowHomeTabHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			RequestData requestData = HTTPUtils.ParseRequest(req);
			if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
			{
				BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
				{
					Logger.Info("Switching to Welcome tab");
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].mTopBar.mAppTabButtons.GoToTab("Home", true, false);
				}), new object[0]);
			}
		}

		// Token: 0x06000FE6 RID: 4070 RVA: 0x000650BC File Offset: 0x000632BC
		public static void ShowWebPageHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string title = requestData.data["title"].ToString();
				string webUrl = requestData.data["url"].ToString();
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIHTTPHandler.ShowWindowHandler(req, res);
						BlueStacksUIUtils.DictWindows[requestData.requestVmName].mTopBar.mAppTabButtons.AddWebTab(webUrl, title, "cef_tab", true, "", false);
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server ShowWebPageHandler : " + ex.ToString());
			}
		}

		// Token: 0x06000FE7 RID: 4071 RVA: 0x000651B4 File Offset: 0x000633B4
		public static void ForceQuitHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			Logger.Info("Quiting BlueStacksUI");
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				bool flag = false;
				try
				{
					flag = Convert.ToBoolean(requestData.data["softclose"].ToString());
				}
				catch
				{
				}
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					if (flag)
					{
						BlueStacksUIUtils.DictWindows[requestData.requestVmName].CloseWindow();
					}
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						App.ExitApplication();
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ForceQuit... Err : " + ex.ToString());
			}
		}

		// Token: 0x06000FE8 RID: 4072 RVA: 0x00065294 File Offset: 0x00063494
		public static void OpenGoogleHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			RequestData requestData = HTTPUtils.ParseRequest(req);
			int num = new Random().Next(100) + 1;
			string tabName = "tab_" + num;
			if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
			{
				BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].mTopBar.mAppTabButtons.AddWebTab("http://www.google.com", tabName, "cef_tab", true, "", false);
				}), new object[0]);
			}
		}

		// Token: 0x06000FE9 RID: 4073 RVA: 0x00065324 File Offset: 0x00063524
		private static void WriteSuccessJsonWithVmName(string vmName, HttpListenerResponse res)
		{
			HTTPUtils.Write(new JArray
			{
				new JObject
				{
					new JProperty("success", true),
					new JProperty("vmname", vmName)
				}
			}.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x06000FEA RID: 4074 RVA: 0x0006537C File Offset: 0x0006357C
		public static void UnsupportedCPUError(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string reason = requestData.data["PlusFailureReason"];
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						string localizedString = LocaleStrings.GetLocalizedString("STRING_INCOMPATIBLE_FRONTEND_QUIT_CAPTION", false);
						if (System.Windows.Forms.MessageBox.Show(LocaleStrings.GetLocalizedString("STRING_INCOMPATIBLE_FRONTEND_QUIT", false), localizedString, MessageBoxButtons.OK) == DialogResult.OK)
						{
							Logger.Info("Quit BlueStacksUI End with reason {0}", new object[]
							{
								reason
							});
							BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
							BlueStacksUIUtils.DictWindows[requestData.requestVmName].ForceCloseWindow();
						}
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in QuitBlueStacksUI: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x06000FEB RID: 4075 RVA: 0x00065450 File Offset: 0x00063650
		public static void UpdateUserInfoHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string text = requestData.data["result"].Trim();
				if (BlueStacksUIUtils.DictWindows[requestData.requestVmName].mPostOtsWelcomeWindow != null)
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].mPostOtsWelcomeWindow.ChangeBasedonTokenReceived(text);
				}
				if (text.Equals("true", StringComparison.InvariantCultureIgnoreCase) && BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[requestData.requestVmName].mTopBar.ChangeUserPremiumButton(RegistryManager.Instance.IsPremium);
					}), new object[0]);
					PromotionManager.CheckIsUserPremium();
					Action<bool> appRecommendationHandler = PromotionObject.AppRecommendationHandler;
					if (appRecommendationHandler != null)
					{
						appRecommendationHandler(false);
					}
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						if (BlueStacksUIUtils.DictWindows[requestData.requestVmName].mLaunchStartupTabWhenTokenReceived && PromotionObject.Instance.StartupTab != null)
						{
							BlueStacksUIUtils.DictWindows[requestData.requestVmName].Utils.HandleGenericActionFromDictionary(PromotionObject.Instance.StartupTab, "startup_action", "");
						}
					}), new object[0]);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in UpdateUserInfoHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x06000FEC RID: 4076 RVA: 0x000655B0 File Offset: 0x000637B0
		internal static void AppInstallStarted(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.data.AllKeys)
				{
					Logger.Info("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.data[text]
					});
				}
				string apkPath = requestData.data["filePath"];
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					string package = string.Empty;
					string appName = string.Empty;
					DownloadInstallApk downloader = new DownloadInstallApk(BlueStacksUIUtils.DictWindows[requestData.requestVmName]);
					if (string.Equals(Path.GetExtension(apkPath), ".xapk", StringComparison.InvariantCultureIgnoreCase))
					{
						JToken jtoken = Utils.ExtractInfoFromXapk(apkPath);
						if (jtoken != null)
						{
							package = jtoken.GetValue("package_name");
							appName = jtoken.GetValue("name");
							Logger.Debug("Package name from manifest.json.." + package);
						}
					}
					else
					{
						AppInfoExtractor apkInfo = AppInfoExtractor.GetApkInfo(apkPath);
						appName = apkInfo.AppName;
						package = apkInfo.PackageName;
					}
					BlueStacksUIHTTPHandler.dictFileNamesPackageName[apkPath] = package;
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[requestData.requestVmName].mWelcomeTab.mHomeApp.AddAppIcon(package, appName, string.Empty, downloader);
						BlueStacksUIUtils.DictWindows[requestData.requestVmName].mWelcomeTab.mHomeApp.ApkInstallStart(package, apkPath);
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GetUserInfo: " + ex.ToString());
			}
		}

		// Token: 0x06000FED RID: 4077 RVA: 0x000657D0 File Offset: 0x000639D0
		public static void AppInstallFailed(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.data.AllKeys)
				{
					Logger.Debug("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.data[text]
					});
				}
				string apkPath = requestData.data["filePath"];
				int errorCode = Convert.ToInt32(requestData.data["errorCode"]);
				string vmName = requestData.requestVmName;
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						try
						{
							BlueStacksUIUtils.DictWindows[vmName].mWelcomeTab.mHomeApp.ApkInstallFailed(BlueStacksUIHTTPHandler.dictFileNamesPackageName[apkPath]);
							BlueStacksUIHTTPHandler.ShowErrorPromptIfNeeded(vmName, errorCode);
						}
						catch (Exception ex2)
						{
							Logger.Error("error in install failed http call: {0}", new object[]
							{
								ex2
							});
						}
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in AppInstallFailed. Err : " + ex.ToString());
			}
		}

		// Token: 0x06000FEE RID: 4078 RVA: 0x000658D8 File Offset: 0x00063AD8
		private static void ShowErrorPromptIfNeeded(string vmName, int errorCode)
		{
			string text = string.Empty;
			if (errorCode == 10)
			{
				text = LocaleStrings.GetLocalizedString("STRING_INVALID_APK_BLACKLISTED_ERROR", false);
			}
			if (!string.IsNullOrEmpty(text))
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.TitleTextBlock.Text = string.Format("{0} {1}", LocaleStrings.GetLocalizedString("BlueStacks", false), LocaleStrings.GetLocalizedString("STRING_WARNING", false));
				customMessageWindow.AddButton(ButtonColors.Blue, LocaleStrings.GetLocalizedString("STRING_OK", false), null, null, false, null);
				customMessageWindow.BodyTextBlock.Text = text;
				customMessageWindow.Owner = BlueStacksUIUtils.DictWindows[vmName];
				BlueStacksUIUtils.DictWindows[vmName].ShowDimOverlay(null);
				customMessageWindow.ShowDialog();
				BlueStacksUIUtils.DictWindows[vmName].HideDimOverlay();
			}
		}

		// Token: 0x06000FEF RID: 4079 RVA: 0x00065994 File Offset: 0x00063B94
		public static void GooglePlayAppInstall(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.data.AllKeys)
				{
					Logger.Info("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.data[text]
					});
				}
				string packageName = requestData.data["packageName"];
				string appName = requestData.data["appName"];
				string isAdditionalFile = requestData.data["isAdditionalFile"];
				string status = requestData.data["status"];
				if (!string.IsNullOrEmpty(status) && BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						AppIcon appIcon = BlueStacksUIUtils.DictWindows[requestData.requestVmName].mWelcomeTab.mHomeApp.GetAppIcon(packageName);
						if (appIcon == null || !appIcon.mIsAppInstalled)
						{
							if (status.Equals("STARTED", StringComparison.InvariantCultureIgnoreCase))
							{
								BlueStacksUIUtils.DictWindows[requestData.requestVmName].mWelcomeTab.mHomeApp.AddAppIcon(packageName, appName, string.Empty, null);
								BlueStacksUIUtils.DictWindows[requestData.requestVmName].mWelcomeTab.mHomeApp.ApkInstallStart(packageName, string.Empty);
							}
							if (status.Equals("SUCCESS", StringComparison.InvariantCultureIgnoreCase) && isAdditionalFile.Equals(false.ToString()))
							{
								BlueStacksUIUtils.DictWindows[requestData.requestVmName].mWelcomeTab.mHomeApp.ApkInstallCompleted(packageName);
								return;
							}
							if (status.Equals("CANCELED", StringComparison.InvariantCultureIgnoreCase))
							{
								BlueStacksUIUtils.DictWindows[requestData.requestVmName].mWelcomeTab.mHomeApp.RemoveAppIcon(packageName);
							}
						}
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GooglePlayAppInstall: " + ex.ToString());
			}
		}

		// Token: 0x06000FF0 RID: 4080 RVA: 0x00065AF8 File Offset: 0x00063CF8
		internal static void ChangeTextOTSHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIBinding.Bind(BlueStacksUIUtils.DictWindows[requestData.requestVmName].mFrontendOTSControl.mBaseControl.mTitleLabel, "STRING_WELCOME_TO_BLUESTACKS");
						Logger.Info("String set after change text OTS .." + BlueStacksUIUtils.DictWindows[requestData.requestVmName].mFrontendOTSControl.mBaseControl.mTitleLabel.Content);
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("error in change ots text." + ex.ToString());
			}
		}

		// Token: 0x06000FF1 RID: 4081 RVA: 0x00065B8C File Offset: 0x00063D8C
		internal static void ShootingModeChanged(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[requestData.requestVmName].mFrontendHandler.IsShootingModeActivated = Convert.ToBoolean(requestData.data["IsShootingModeActivated"].ToString());
						if (BlueStacksUIUtils.DictWindows[requestData.requestVmName].mFrontendHandler.IsShootingModeActivated)
						{
							BlueStacksUIUtils.DictWindows[requestData.requestVmName].mFullscreenSidebarPopup.IsOpen = false;
							return;
						}
						BlueStacksUIUtils.DictWindows[requestData.requestVmName].mCommonHandler.ClipMouseCursorHandler(false, false, "", "");
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Shooting Mode Changed: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x06000FF2 RID: 4082 RVA: 0x00065C2C File Offset: 0x00063E2C
		internal static void ChangeOrientaionHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string packagename = requestData.data["package"].ToString();
				bool isPortrait = Convert.ToBoolean(requestData.data["is_portrait"]);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Frontend_OrientationChanged(packagename, isPortrait);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ChangeOrientaionHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FF3 RID: 4083 RVA: 0x00065CCC File Offset: 0x00063ECC
		internal static void UpdateSizeOfOverlay(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						try
						{
							IntPtr mLastMappableWindowHandle = new IntPtr(Convert.ToInt32(requestData.data["handle"]));
							BlueStacksUIUtils.DictWindows[requestData.requestVmName].StaticComponents.mLastMappableWindowHandle = mLastMappableWindowHandle;
							if (KMManager.dictOverlayWindow.ContainsKey(BlueStacksUIUtils.DictWindows[requestData.requestVmName]))
							{
								KMManager.dictOverlayWindow[BlueStacksUIUtils.DictWindows[requestData.requestVmName]].UpdateSize();
							}
						}
						catch (Exception ex2)
						{
							Logger.Error("Exception in UpdateSizeOfOverlay: " + ex2.ToString());
							BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex2.Message, res);
						}
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in UpdateSizeOfOverlay: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x06000FF4 RID: 4084 RVA: 0x00065D84 File Offset: 0x00063F84
		internal static void BootFailedPopupHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].Utils.SendGuestBootFailureStats("com exception");
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in BootFailedPopupHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FF5 RID: 4085 RVA: 0x00065E00 File Offset: 0x00064000
		internal static void DragDropInstallHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.requestVmName;
				string apkPath = requestData.data["filePath"].ToString();
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					new DownloadInstallApk(BlueStacksUIUtils.DictWindows[requestVmName]).InstallApk(apkPath, true);
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in DragDropInstallHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FF6 RID: 4086 RVA: 0x00065E90 File Offset: 0x00064090
		internal static void DeviceProvisionedHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.requestVmName;
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].mAppHandler.IsOneTimeSetupCompleted = true;
					Stats.SendUnifiedInstallStatsAsync("device_provisioned", "");
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in DeviceProvisionedHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FF7 RID: 4087 RVA: 0x00065F20 File Offset: 0x00064120
		internal static void GoogleSigninHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.requestVmName;
				string email = requestData.data["email"].ToString().Trim();
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.requestVmName))
				{
					RegistryManager.Instance.Guest[requestData.requestVmName].IsGoogleSigninDone = true;
					Stats.SendUnifiedInstallStatsAsync("google_login_completed", email);
					BlueStacksUIUtils.DictWindows[requestData.requestVmName].PostGoogleSigninCompleteTask();
				}
				BlueStacksUIHTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GoogleSigninHandler: " + ex.ToString());
				BlueStacksUIHTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06000FF8 RID: 4088 RVA: 0x00065FDC File Offset: 0x000641DC
		internal static void SetDMMKeymapping(HttpListenerRequest req, HttpListenerResponse res)
		{
			Logger.Info("Got SetKeymapping {0} request from {1}", new object[]
			{
				req.HttpMethod,
				req.RemoteEndPoint.ToString()
			});
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.requestVmName;
				string package = requestData.data["package"].ToString();
				bool isKeymapEnabled = Convert.ToBoolean(requestData.data["enablekeymap"]);
				Logger.Info("package : " + package + " enablekeymap : " + isKeymapEnabled.ToString());
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
				{
					int retries = 3;
					while (retries > 0)
					{
						BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
						{
							if (BlueStacksUIUtils.DictWindows[vmName].Visibility == Visibility.Visible && BlueStacksUIUtils.DictWindows[vmName].mTopBar.mAppTabButtons.mDictTabs.ContainsKey(package))
							{
								retries = 0;
								BlueStacksUIUtils.DictWindows[vmName].mTopBar.mAppTabButtons.mDictTabs[package].IsDMMKeymapEnabled = isKeymapEnabled;
							}
						}), new object[0]);
						if (retries > 0)
						{
							int retries2 = retries;
							retries = retries2 - 1;
							Thread.Sleep(1000);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server SetKeymapping: " + ex.ToString());
			}
		}

		// Token: 0x06000FF9 RID: 4089 RVA: 0x00066138 File Offset: 0x00064338
		internal static void ReloadShortcuts(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.requestVmName;
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[vmName].mCommonHandler.ReloadShortcutsForAllInstances();
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ReloadShortcuts: " + ex.ToString());
			}
		}

		// Token: 0x06000FFA RID: 4090 RVA: 0x000661C8 File Offset: 0x000643C8
		internal static void ReloadPromotions(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				string requestVmName = HTTPUtils.ParseRequest(req).requestVmName;
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestVmName))
				{
					PromotionManager.ReloadPromotionsAsync();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ReloadPromotions: " + ex.ToString());
			}
		}

		// Token: 0x04000AB3 RID: 2739
		private static object sLockObject = new object();

		// Token: 0x04000AB4 RID: 2740
		private static object sFrontendPositionRequestLock = new object();

		// Token: 0x04000AB5 RID: 2741
		internal static string lastPackage = string.Empty;

		// Token: 0x04000AB6 RID: 2742
		private static Dictionary<string, string> dictFileNamesPackageName = new Dictionary<string, string>();

		// Token: 0x04000AB7 RID: 2743
		private static bool mSendGamepadStats = false;

		// Token: 0x04000AB8 RID: 2744
		private static object syncRoot = new object();

		// Token: 0x04000AB9 RID: 2745
		private static string mPreviousActivityReported = "";
	}
}
