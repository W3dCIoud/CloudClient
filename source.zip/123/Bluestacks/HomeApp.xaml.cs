﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using BlueStacks.Common;
using BlueStacks.Common.Grm;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001E7 RID: 487
	public partial class HomeApp : System.Windows.Controls.UserControl
	{
		// Token: 0x14000021 RID: 33
		// (add) Token: 0x060010D7 RID: 4311 RVA: 0x000694A8 File Offset: 0x000676A8
		// (remove) Token: 0x060010D8 RID: 4312 RVA: 0x000694E0 File Offset: 0x000676E0
		internal event Action PlayGif;

		// Token: 0x14000022 RID: 34
		// (add) Token: 0x060010D9 RID: 4313 RVA: 0x00069518 File Offset: 0x00067718
		// (remove) Token: 0x060010DA RID: 4314 RVA: 0x00069550 File Offset: 0x00067750
		internal event Action PauseGif;

		// Token: 0x170001FC RID: 508
		// (get) Token: 0x060010DB RID: 4315 RVA: 0x0000C067 File Offset: 0x0000A267
		public string BackgroundImagePath
		{
			get
			{
				return System.IO.Path.Combine(RegistryManager.Instance.UserDefinedDir, "Client\\Assets\\backgroundImage");
			}
		}

		// Token: 0x170001FD RID: 509
		// (get) Token: 0x060010DC RID: 4316 RVA: 0x0000C07D File Offset: 0x0000A27D
		private MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x060010DD RID: 4317 RVA: 0x00069588 File Offset: 0x00067788
		public HomeApp(MainWindow window)
		{
			this.InitializeComponent();
			this.mMainWindow = window;
			this.SetWallpaper();
			this.InstalledAppsDrawer = (this.InstalledAppsDrawerScrollBar.Content as WrapPanel);
			this.SetLocalizedString();
			if (!DesignerProperties.GetIsInDesignMode(this) && PromotionObject.Instance != null)
			{
				PromotionObject.BackgroundPromotionHandler = (EventHandler)Delegate.Combine(PromotionObject.BackgroundPromotionHandler, new EventHandler(this.HomeApp_BackgroundPromotionHandler));
			}
			if (!FeatureManager.Instance.IsMultiInstanceControlsGridVisible)
			{
				this.mMultiInstanceControlsGrid.Visibility = Visibility.Hidden;
			}
			if (!FeatureManager.Instance.IsAppSettingsAvailable)
			{
				this.mAppSettings.Visibility = Visibility.Hidden;
				this.mGridSeparator.Visibility = Visibility.Hidden;
			}
			this.searchHoverTimer = new DispatcherTimer();
			this.searchHoverTimer.Interval = TimeSpan.FromMilliseconds(700.0);
			this.searchHoverTimer.Tick += delegate(object <p0>, EventArgs <p1>)
			{
				this.OpenSearchSuggestions();
			};
			this.Mask.CornerRadius = new CornerRadius(0.0, this.searchTextBoxBorder.CornerRadius.TopRight, this.searchTextBoxBorder.CornerRadius.BottomRight, 0.0);
		}

		// Token: 0x170001FE RID: 510
		// (get) Token: 0x060010DE RID: 4318 RVA: 0x0000C09E File Offset: 0x0000A29E
		// (set) Token: 0x060010DF RID: 4319 RVA: 0x0000C0A6 File Offset: 0x0000A2A6
		internal bool SideHtmlBrowserInited { get; set; }

		// Token: 0x170001FF RID: 511
		// (get) Token: 0x060010E0 RID: 4320 RVA: 0x0000C0AF File Offset: 0x0000A2AF
		// (set) Token: 0x060010E1 RID: 4321 RVA: 0x0000C0B7 File Offset: 0x0000A2B7
		internal BrowserControl SideHtmlBrowser { get; set; }

		// Token: 0x060010E2 RID: 4322 RVA: 0x0000C0C0 File Offset: 0x0000A2C0
		internal void CreateSideHtmlBrowserControl()
		{
			this.SideHtmlBrowserInited = true;
			base.Dispatcher.Invoke(new Action(delegate()
			{
				BrowserControl browserControl = new BrowserControl(this.ParentWindow.Utils.GetHtmlSidePanelUrl())
				{
					Visibility = Visibility.Visible
				};
				CustomPictureBox element = new CustomPictureBox
				{
					HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
					VerticalAlignment = VerticalAlignment.Center,
					Height = 30.0,
					Width = 30.0,
					ImageName = "loader",
					IsImageToBeRotated = true
				};
				this.mAppRecommendationsGrid.Children.Add(browserControl);
				this.mAppRecommendationsGrid.Children.Add(element);
				this.mAppRecommendationsGrid.Visibility = Visibility.Visible;
				browserControl.CreateNewBrowser();
				this.SideHtmlBrowser = browserControl;
			}), new object[0]);
		}

		// Token: 0x060010E3 RID: 4323 RVA: 0x000696E0 File Offset: 0x000678E0
		internal void ChangeSideRecommendationsVisibility(bool isAppRecommendationsVisible, bool isSearchBarVisible)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (!isAppRecommendationsVisible)
				{
					if (!isAppRecommendationsVisible)
					{
						this.mAppRecommendationsGrid.Visibility = Visibility.Collapsed;
						this.InstalledAppsDrawerScrollBar.SetValue(Grid.ColumnSpanProperty, 2);
						this.mMultiInstanceControlsGrid.SetValue(Grid.ColumnSpanProperty, 2);
						if (isSearchBarVisible)
						{
							this.mSearchGrid.Visibility = Visibility.Visible;
							this.mSearchGrid.Margin = new Thickness(0.0, 20.0, 20.0, 0.0);
							this.mSearchGrid.Width = 350.0;
							this.mIsShowSearchRecommendations = true;
							this.mSearchRecommendationBorder.Margin = new Thickness(0.0, 59.0, 20.0, 0.0);
							this.mSearchRecommendationBorder.Width = 350.0;
							return;
						}
						this.mSearchGrid.Visibility = Visibility.Collapsed;
					}
					return;
				}
				this.mAppRecommendationsGrid.Visibility = Visibility.Visible;
				this.InstalledAppsDrawerScrollBar.SetValue(Grid.ColumnSpanProperty, 1);
				this.mMultiInstanceControlsGrid.SetValue(Grid.ColumnSpanProperty, 1);
				if (isSearchBarVisible)
				{
					this.mDiscoverApps.Visibility = Visibility.Visible;
					this.appRecomScrollViewer.Visibility = Visibility.Visible;
					this.mSearchGrid.Visibility = Visibility.Visible;
					this.mSearchGrid.Margin = new Thickness(20.0, 54.0, 20.0, 0.0);
					this.mSearchGrid.Width = 240.0;
					this.mIsShowSearchRecommendations = false;
					this.mSearchRecommendationBorder.Margin = new Thickness(20.0, 88.0, 20.0, 0.0);
					this.mSearchRecommendationBorder.Width = 240.0;
					return;
				}
				this.mSearchGrid.Visibility = Visibility.Hidden;
				this.mDiscoverApps.Visibility = Visibility.Hidden;
				this.appRecomScrollViewer.Visibility = Visibility.Hidden;
				this.mAppRecommendationsGrid.Width = 345.0;
			}), new object[0]);
		}

		// Token: 0x060010E4 RID: 4324 RVA: 0x0000C0E7 File Offset: 0x0000A2E7
		internal void UpdateGamepadIcons()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				foreach (KeyValuePair<string, AppIcon> keyValuePair in this.dictAppIcons)
				{
					if (keyValuePair.Value.IsGamepadCompatible)
					{
						keyValuePair.Value.mGamepadIcon.ImageName = (this.ParentWindow.IsGamepadConnected ? "apps_connected_icon" : "apps_disconnected_icon");
					}
				}
			}), new object[0]);
		}

		// Token: 0x060010E5 RID: 4325 RVA: 0x0000C107 File Offset: 0x0000A307
		internal bool CheckDictAppIconFor(string packagename, Predicate<AppIcon> pred)
		{
			return this.dictAppIcons.ContainsKey(packagename) && pred(this.dictAppIcons[packagename]);
		}

		// Token: 0x060010E6 RID: 4326 RVA: 0x0000C12B File Offset: 0x0000A32B
		private void SetWallpaper()
		{
			if (File.Exists(this.BackgroundImagePath))
			{
				this.mBackgroundImage.IsFullImagePath = true;
				this.mBackgroundImage.ImageName = this.BackgroundImagePath;
			}
		}

		// Token: 0x060010E7 RID: 4327 RVA: 0x0000C157 File Offset: 0x0000A357
		private void HomeApp_BackgroundPromotionHandler(object sender, EventArgs e)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (string.IsNullOrEmpty(PromotionObject.Instance.BackgroundPromotionImagePath))
				{
					this.SetWallpaper();
					return;
				}
				this.mBackgroundImage.IsFullImagePath = true;
				this.mBackgroundImage.ImageName = PromotionObject.Instance.BackgroundPromotionImagePath;
			}), new object[0]);
		}

		// Token: 0x060010E8 RID: 4328 RVA: 0x0000C177 File Offset: 0x0000A377
		internal void HomeApp_AppSuggestionHandler(bool checkForAnimationIcon)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				new List<string>();
				this.RemoveIconIfExists();
				object syncRoot = ((ICollection)PromotionObject.Instance.AppSuggestionList).SyncRoot;
				lock (syncRoot)
				{
					foreach (AppSuggestionPromotion appSuggestionPromotion in PromotionObject.Instance.AppSuggestionList)
					{
						if (!new JsonParser(this.ParentWindow.mVmName).IsAppInstalled(appSuggestionPromotion.AppPackage))
						{
							if (this.CheckIfPresentInRedDotShownRegistry(appSuggestionPromotion.AppPackage))
							{
								appSuggestionPromotion.IsShowRedDot = false;
							}
							this.AddAppSuggestionIcon(appSuggestionPromotion);
						}
						else
						{
							if (!this.CheckIfPresentInRedDotShownRegistry(appSuggestionPromotion.AppPackage) && appSuggestionPromotion.IsShowRedDot)
							{
								this.AddRedDot(appSuggestionPromotion.AppPackage);
							}
							else
							{
								appSuggestionPromotion.IsShowRedDot = false;
							}
							this.AddBorderInIcon(appSuggestionPromotion);
						}
					}
				}
				this.StartGif();
			}), new object[0]);
		}

		// Token: 0x060010E9 RID: 4329 RVA: 0x0000C197 File Offset: 0x0000A397
		internal void AppSuggestionPromotion()
		{
			Action<bool> appSuggestionHandler = PromotionObject.AppSuggestionHandler;
			if (appSuggestionHandler == null)
			{
				return;
			}
			appSuggestionHandler(false);
		}

		// Token: 0x060010EA RID: 4330 RVA: 0x00069728 File Offset: 0x00067928
		internal bool CheckIfPresentInRedDotShownRegistry(string package)
		{
			string redDotShownOnIcon = RegistryManager.Instance.RedDotShownOnIcon;
			if (!string.IsNullOrEmpty(redDotShownOnIcon))
			{
				char[] separator = new char[]
				{
					','
				};
				foreach (string text in redDotShownOnIcon.Split(separator, StringSplitOptions.None))
				{
					if (!string.IsNullOrEmpty(package) && text.Equals(package, StringComparison.InvariantCultureIgnoreCase))
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x060010EB RID: 4331 RVA: 0x00069788 File Offset: 0x00067988
		internal void AddIconWithRedDot(string appPackage)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				object syncRoot = ((ICollection)PromotionObject.Instance.AppSuggestionList).SyncRoot;
				lock (syncRoot)
				{
					JsonParser jsonParser = new JsonParser(this.ParentWindow.mVmName);
					foreach (AppSuggestionPromotion appSuggestionPromotion in PromotionObject.Instance.AppSuggestionList)
					{
						if (appSuggestionPromotion.AppPackage.Equals(appPackage))
						{
							if (!jsonParser.IsAppInstalled(appSuggestionPromotion.AppPackage))
							{
								this.RemovePackageInRedDotShownRegistry(appSuggestionPromotion.AppPackage);
								this.AddAppSuggestionIcon(appSuggestionPromotion);
							}
							else
							{
								this.RemovePackageInRedDotShownRegistry(appSuggestionPromotion.AppPackage);
								this.AddRedDot(appPackage);
							}
						}
					}
				}
			}), new object[0]);
		}

		// Token: 0x060010EC RID: 4332 RVA: 0x000697C8 File Offset: 0x000679C8
		internal void RemoveIconIfExists()
		{
			List<string> list = new List<string>();
			JsonParser jsonParser = new JsonParser(this.ParentWindow.mVmName);
			using (Dictionary<string, AppIcon>.ValueCollection.Enumerator enumerator = this.dictAppIcons.Values.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					AppIcon icon = enumerator.Current;
					object syncRoot = ((ICollection)PromotionObject.Instance.AppSuggestionList).SyncRoot;
					lock (syncRoot)
					{
						if (!icon.IsAppSuggestionActive)
						{
							if (icon.IsInstalledApp)
							{
								continue;
							}
							if ((from _ in PromotionObject.Instance.AppSuggestionList
							where _.AppLocation.ToLower().Equals("more_apps")
							select _).Count<AppSuggestionPromotion>() <= 0)
							{
								continue;
							}
						}
						if ((from _ in PromotionObject.Instance.AppSuggestionList
						where string.Compare(_.AppPackage, icon.PackageName, true) == 0
						select _).Count<AppSuggestionPromotion>() == 0)
						{
							if (!jsonParser.IsAppInstalled(icon.PackageName))
							{
								list.Add(icon.PackageName);
							}
							else
							{
								icon.RemovePromotionBorderInstalledApp();
							}
						}
					}
				}
			}
			foreach (string package in list)
			{
				this.RemoveAppIcon(package);
			}
		}

		// Token: 0x060010ED RID: 4333 RVA: 0x00069958 File Offset: 0x00067B58
		internal void AddRedDot(string package)
		{
			try
			{
				if (this.dictAppIcons.ContainsKey(package))
				{
					this.dictAppIcons[package].mRedDotNotifIcon.Visibility = Visibility.Visible;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in showing red dot on installed app: " + ex.ToString());
			}
		}

		// Token: 0x060010EE RID: 4334 RVA: 0x000699B4 File Offset: 0x00067BB4
		internal void AddPackageInRedDotShownRegistry(string appPackage)
		{
			string text = RegistryManager.Instance.RedDotShownOnIcon;
			if (!string.IsNullOrEmpty(text))
			{
				text = text + "," + appPackage;
			}
			else
			{
				text = appPackage;
			}
			RegistryManager.Instance.RedDotShownOnIcon = text;
		}

		// Token: 0x060010EF RID: 4335 RVA: 0x000699F0 File Offset: 0x00067BF0
		internal void RemovePackageInRedDotShownRegistry(string appPackage)
		{
			string redDotShownOnIcon = RegistryManager.Instance.RedDotShownOnIcon;
			char[] separator = new char[]
			{
				','
			};
			string[] array = (from w in redDotShownOnIcon.Split(separator, StringSplitOptions.None)
			where !w.Contains(appPackage)
			select w).ToArray<string>();
			string text = string.Empty;
			foreach (string text2 in array)
			{
				if (!string.IsNullOrEmpty(text2))
				{
					text = text + text2.ToString() + ",";
				}
			}
			RegistryManager.Instance.RedDotShownOnIcon = text;
		}

		// Token: 0x060010F0 RID: 4336 RVA: 0x00069A88 File Offset: 0x00067C88
		public void RequirementConfigUpdated()
		{
			List<AppRequirement> appRequirements = AppRequirementsParser.Instance.Requirements;
			if (appRequirements == null)
			{
				return;
			}
			base.Dispatcher.Invoke(new Action(delegate()
			{
				foreach (KeyValuePair<string, AppIcon> keyValuePair in this.dictAppIcons)
				{
					keyValuePair.Value.RefreshGrmIndication(appRequirements);
				}
			}), new object[0]);
		}

		// Token: 0x060010F1 RID: 4337 RVA: 0x0000C1A9 File Offset: 0x0000A3A9
		internal void ReInitAppJson()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				foreach (AppIcon appIcon in (from x in this.InstalledAppsDrawer.Children.OfType<AppIcon>()
				where x.IsInstalledApp && !x.IsInstaling && !x.IsDownloading && !x.IsAppSuggestionActive
				select x).ToList<AppIcon>())
				{
					this.RemoveAppIcon(appIcon.PackageName);
				}
				this.InitIcons();
			}), new object[0]);
		}

		// Token: 0x060010F2 RID: 4338 RVA: 0x0000C1C9 File Offset: 0x0000A3C9
		internal void Init()
		{
			if (!DesignerProperties.GetIsInDesignMode(this))
			{
				this.InitSystemIcons();
				this.InitIcons();
			}
			this.GetSearchTextFromCloud();
		}

		// Token: 0x060010F3 RID: 4339 RVA: 0x0000C1E5 File Offset: 0x0000A3E5
		private void GetSearchTextFromCloud()
		{
			new Thread(delegate()
			{
				try
				{
					this.defaultSearchBoxText = LocaleStrings.GetLocalizedString("STRING_SEARCH", false);
					string urlWithParams = WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/app_center_searchdefaultquery");
					Logger.Debug("url for search api :" + urlWithParams);
					string text = BstHttpClient.Get(urlWithParams, null, false, string.Empty, 0, 1, 0, false);
					Logger.Debug("result for app_center_searchdefaultquery : " + text);
					JObject jobject = JObject.Parse(text);
					if ((bool)jobject["success"])
					{
						string text2 = jobject["result"].ToString().Trim();
						if (!string.IsNullOrEmpty(text2))
						{
							this.defaultSearchBoxText = text2;
						}
						Logger.Debug("response from search text cloud api :" + text2);
					}
				}
				catch (Exception ex)
				{
					Logger.Warning("Failed to fetch text from cloud... Err : " + ex.ToString());
				}
				base.Dispatcher.Invoke(new Action(delegate()
				{
					this.mSearchTextBox.Text = this.defaultSearchBoxText;
				}), new object[0]);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060010F4 RID: 4340 RVA: 0x00069ADC File Offset: 0x00067CDC
		internal void InitAppPromotionEvents()
		{
			if (PromotionObject.Instance != null)
			{
				PromotionObject.AppSuggestionHandler = (Action<bool>)Delegate.Combine(PromotionObject.AppSuggestionHandler, new Action<bool>(this.HomeApp_AppSuggestionHandler));
				PromotionObject.AppRecommendationHandler = (Action<bool>)Delegate.Combine(PromotionObject.AppRecommendationHandler, new Action<bool>(this.ShowAppRecommendations));
			}
		}

		// Token: 0x060010F5 RID: 4341 RVA: 0x00069B30 File Offset: 0x00067D30
		private void InitIcons()
		{
			foreach (AppInfo item in new JsonParser(this.ParentWindow.mVmName).GetAppList().ToList<AppInfo>())
			{
				this.AddIcon(item);
			}
		}

		// Token: 0x060010F6 RID: 4342 RVA: 0x00069B98 File Offset: 0x00067D98
		private void InitSystemIcons()
		{
			List<AppInfo> list = new JsonParser(string.Empty).GetAppList().ToList<AppInfo>();
			int num = 1;
			this.moreAppsIcon.AddToDock(50.0, 50.0);
			if (this.mMoreAppsDockPanel.Children.Count <= 1)
			{
				foreach (AppInfo appInfo in list)
				{
					if (string.Compare(appInfo.package, "com.android.vending", true) != 0 && string.Compare(appInfo.package, "com.google.android.play.games", true) != 0)
					{
						AppIcon newIconForKey = this.GetNewIconForKey(appInfo.package);
						newIconForKey.Init(appInfo);
						newIconForKey.AppName = "STRING_" + appInfo.name.ToUpper().Trim().Replace(" ", "_") + "_APP";
						newIconForKey.IsInstalledApp = false;
						newIconForKey.AddToMoreAppsDock(55.0, 55.0);
						this.AddMoreAppsDockPanelIcon(newIconForKey);
					}
					else
					{
						AppIcon newIconForKey2 = this.GetNewIconForKey(appInfo.package);
						newIconForKey2.Init(appInfo);
						newIconForKey2.IsInstalledApp = false;
						newIconForKey2.mIsAppRemovable = false;
						newIconForKey2.AppName = "STRING_" + appInfo.name.ToUpper().Trim().Replace(" ", "_") + "_APP";
						if (string.Compare(appInfo.package, "com.android.vending", true) == 0)
						{
							newIconForKey2.MyAppPriority = 0;
						}
						else
						{
							newIconForKey2.MyAppPriority = num;
							num++;
						}
						this.AddInstallDrawerIcon(newIconForKey2);
					}
				}
			}
		}

		// Token: 0x060010F7 RID: 4343 RVA: 0x0000C204 File Offset: 0x0000A404
		private void SetLocalizedString()
		{
			this.mLoadingGrid.ProgressText = "STRING_LOADING_ENGINE";
		}

		// Token: 0x060010F8 RID: 4344 RVA: 0x00069D6C File Offset: 0x00067F6C
		private AppIcon AddIcon(AppInfo item)
		{
			AppIcon newIconForKey = this.GetNewIconForKey(item.package);
			newIconForKey.Init(item);
			this.AddInstallDrawerIcon(newIconForKey);
			return newIconForKey;
		}

		// Token: 0x060010F9 RID: 4345 RVA: 0x00069D98 File Offset: 0x00067F98
		private void AddInstallDrawerIcon(AppIcon icon)
		{
			if (PromotionObject.Instance.MyAppsOrder.ContainsKey(icon.PackageName) && icon.MyAppPriority == 999)
			{
				icon.MyAppPriority = PromotionObject.Instance.MyAppsOrder[icon.PackageName];
			}
			int num = 0;
			using (IEnumerator<AppIcon> enumerator = this.InstalledAppsDrawer.Children.OfType<AppIcon>().GetEnumerator())
			{
				while (enumerator.MoveNext() && enumerator.Current.MyAppPriority <= icon.MyAppPriority)
				{
					num++;
				}
			}
			this.InstalledAppsDrawer.Children.Insert(num, icon);
		}

		// Token: 0x060010FA RID: 4346 RVA: 0x00069E4C File Offset: 0x0006804C
		internal void AddAppIcon(string package)
		{
			this.RemoveAppIcon(package);
			AppInfo appInfoFromPackageName = new JsonParser(this.ParentWindow.mVmName).GetAppInfoFromPackageName(package);
			if (appInfoFromPackageName != null)
			{
				this.AddIcon(appInfoFromPackageName);
			}
		}

		// Token: 0x060010FB RID: 4347 RVA: 0x00069E84 File Offset: 0x00068084
		internal void AddAppIcon(string package, string appName, string apkUrl, DownloadInstallApk downloader)
		{
			if (!string.IsNullOrEmpty(package))
			{
				AppIcon newIconForKey = this.GetNewIconForKey(package);
				newIconForKey.Init(package, appName, apkUrl, downloader);
				this.AddInstallDrawerIcon(newIconForKey);
			}
		}

		// Token: 0x060010FC RID: 4348 RVA: 0x00069EB4 File Offset: 0x000680B4
		internal void AddMacroAppIcon(string package)
		{
			if (!string.IsNullOrEmpty(package) && this.GetAppIcon(package) != null)
			{
				string key = package + "_macro";
				AppIcon newIconForKey = this.GetNewIconForKey(key);
				string appname = LocaleStrings.GetLocalizedString("STRING_REROLL_APP_PREFIX", false) + " - " + this.GetAppIcon(package).AppName;
				newIconForKey.InitRerollIcon(package, appname);
				this.AddInstallDrawerIcon(newIconForKey);
			}
		}

		// Token: 0x060010FD RID: 4349 RVA: 0x0000C216 File Offset: 0x0000A416
		private void TestEvent(object sender, RoutedEventArgs e)
		{
			System.Windows.MessageBox.Show("asjkhjkdf");
		}

		// Token: 0x060010FE RID: 4350 RVA: 0x0000C223 File Offset: 0x0000A423
		private void TestEvent2(object sender, RoutedEventArgs e)
		{
			System.Windows.MessageBox.Show("New Message!");
		}

		// Token: 0x060010FF RID: 4351 RVA: 0x0000C230 File Offset: 0x0000A430
		internal void StartGif()
		{
			if (this.PlayGif != null)
			{
				this.PlayGif();
			}
		}

		// Token: 0x06001100 RID: 4352 RVA: 0x0000C245 File Offset: 0x0000A445
		internal void StopGif()
		{
			if (this.PauseGif != null)
			{
				this.PauseGif();
			}
		}

		// Token: 0x06001101 RID: 4353 RVA: 0x00069F18 File Offset: 0x00068118
		internal AppIcon AddAppSuggestionIcon(AppSuggestionPromotion appSuggestionInfo)
		{
			string appPackage = appSuggestionInfo.AppPackage;
			double height = 50.0;
			double width = 50.0;
			AppIcon newIconForKey = this.GetNewIconForKey(appPackage);
			try
			{
				if (newIconForKey != null)
				{
					newIconForKey.IsAppSuggestionActive = true;
					newIconForKey.PackageName = appPackage;
					if (appSuggestionInfo.IsShowRedDot)
					{
						newIconForKey.mRedDotNotifIcon.Visibility = Visibility.Visible;
					}
					newIconForKey.Init(appSuggestionInfo);
					if (!appSuggestionInfo.IsEmailRequired || RegistryManager.Instance.Guest[this.ParentWindow.mVmName].IsGoogleSigninDone)
					{
						if (appSuggestionInfo.AppLocation.ToLower().Equals("dock"))
						{
							if (newIconForKey.IsGifIcon)
							{
								this.PlayGif += newIconForKey.GifAppIconPlay;
								this.PauseGif += newIconForKey.GifAppIconPause;
							}
							if (appSuggestionInfo.IconHeight != 0.0)
							{
								height = appSuggestionInfo.IconHeight;
							}
							if (appSuggestionInfo.IconWidth != 0.0)
							{
								width = appSuggestionInfo.IconWidth;
							}
							newIconForKey.AddToDock(height, width);
							this.AddDockPanelIcon(newIconForKey);
						}
						else if (appSuggestionInfo.AppLocation.ToLower().Equals("more_apps"))
						{
							newIconForKey.AddToMoreAppsDock(55.0, 55.0);
							this.AddMoreAppsDockPanelIcon(newIconForKey);
						}
						else
						{
							this.AddInstallDrawerIcon(newIconForKey);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in adding app suggestion icon: " + ex.ToString());
			}
			return newIconForKey;
		}

		// Token: 0x06001102 RID: 4354 RVA: 0x0006A0A0 File Offset: 0x000682A0
		private void AddDockPanelIcon(AppIcon icon)
		{
			if (PromotionObject.Instance.DockOrder.ContainsKey(icon.PackageName) && icon.MyAppPriority == 999)
			{
				icon.MyAppPriority = PromotionObject.Instance.DockOrder[icon.PackageName];
			}
			int num = 0;
			using (IEnumerator<AppIcon> enumerator = this.mDockPanel.Children.OfType<AppIcon>().GetEnumerator())
			{
				while (enumerator.MoveNext() && enumerator.Current.MyAppPriority <= icon.MyAppPriority)
				{
					num++;
				}
			}
			this.mDockPanel.Children.Insert(num, icon);
			this.mDockPanel.Children.Remove(this.moreAppsIcon);
			this.mDockPanel.Children.Add(this.moreAppsIcon);
		}

		// Token: 0x06001103 RID: 4355 RVA: 0x0006A180 File Offset: 0x00068380
		private void AddMoreAppsDockPanelIcon(AppIcon icon)
		{
			if (PromotionObject.Instance.MoreAppsDockOrder.ContainsKey(icon.PackageName) && icon.MyAppPriority == 999)
			{
				icon.MyAppPriority = PromotionObject.Instance.MoreAppsDockOrder[icon.PackageName];
			}
			int num = 0;
			using (IEnumerator<AppIcon> enumerator = this.mMoreAppsDockPanel.Children.OfType<AppIcon>().GetEnumerator())
			{
				while (enumerator.MoveNext() && enumerator.Current.MyAppPriority <= icon.MyAppPriority)
				{
					num++;
				}
			}
			if (icon.PackageName.Equals("macro_recorder"))
			{
				if (!FeatureManager.Instance.IsMacroRecorderEnabled)
				{
					return;
				}
				icon.Visibility = Visibility.Collapsed;
			}
			this.mMoreAppsDockPanel.Children.Insert(num, icon);
		}

		// Token: 0x06001104 RID: 4356 RVA: 0x0006A25C File Offset: 0x0006845C
		internal void AddBorderInIcon(AppSuggestionPromotion appSuggestion)
		{
			string appPackage = appSuggestion.AppPackage;
			if (this.dictAppIcons.ContainsKey(appPackage))
			{
				this.dictAppIcons[appPackage].AddPromotionBorderInstalledApp(appSuggestion);
			}
		}

		// Token: 0x06001105 RID: 4357 RVA: 0x0006A290 File Offset: 0x00068490
		private AppIcon GetNewIconForKey(string key)
		{
			this.RemoveAppIcon(key);
			AppIcon appIcon = new AppIcon();
			this.dictAppIcons[key] = appIcon;
			if (PromotionObject.Instance.MyAppsOrder.ContainsKey(key) && appIcon.MyAppPriority == 999)
			{
				appIcon.MyAppPriority = PromotionObject.Instance.MyAppsOrder[key];
			}
			return appIcon;
		}

		// Token: 0x06001106 RID: 4358 RVA: 0x0006A2F0 File Offset: 0x000684F0
		internal void RemoveAppIcon(string package)
		{
			if (package != null && this.dictAppIcons.ContainsKey(package))
			{
				if (this.dictAppIcons[package].IsGifIcon)
				{
					this.PlayGif -= this.dictAppIcons[package].GifAppIconPlay;
					this.PauseGif -= this.dictAppIcons[package].GifAppIconPause;
				}
				this.InstalledAppsDrawer.Children.Remove(this.dictAppIcons[package]);
				this.mDockPanel.Children.Remove(this.dictAppIcons[package]);
				this.mMoreAppsDockPanel.Children.Remove(this.dictAppIcons[package]);
				this.dictAppIcons.Remove(package);
			}
		}

		// Token: 0x06001107 RID: 4359 RVA: 0x0006A3C4 File Offset: 0x000685C4
		internal AppIcon GetAppIcon(string packageName)
		{
			if (FeatureManager.Instance.IsCustomUIForNCSoft && packageName == BlueStacksUIUtils.sUserAccountPackageName)
			{
				Logger.Info("Setting packageName to com.android.vending when com.uncube.account is received");
				packageName = "com.android.vending";
			}
			AppIcon result = null;
			if (this.dictAppIcons.ContainsKey(packageName) && !string.IsNullOrEmpty(packageName))
			{
				result = this.dictAppIcons[packageName];
			}
			return result;
		}

		// Token: 0x06001108 RID: 4360 RVA: 0x0000C25A File Offset: 0x0000A45A
		internal AppIcon GetMacroAppIcon(string packageName)
		{
			return this.GetAppIcon(packageName + "_macro");
		}

		// Token: 0x06001109 RID: 4361 RVA: 0x0006A424 File Offset: 0x00068624
		internal void DownloadStarted(string packageName)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					this.dictAppIcons[packageName].DownloadStarted();
				}
				catch
				{
				}
			}), new object[0]);
		}

		// Token: 0x0600110A RID: 4362 RVA: 0x0006A464 File Offset: 0x00068664
		internal void UpdateAppDownloadProgress(string packageName, int percent)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					this.dictAppIcons[packageName].UpdateAppDownloadProgress(percent);
				}
				catch
				{
				}
			}), new object[0]);
		}

		// Token: 0x0600110B RID: 4363 RVA: 0x0006A4AC File Offset: 0x000686AC
		internal void DownloadFailed(string packageName)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					this.dictAppIcons[packageName].DownloadFailed();
				}
				catch
				{
				}
			}), new object[0]);
		}

		// Token: 0x0600110C RID: 4364 RVA: 0x0006A4EC File Offset: 0x000686EC
		internal void DownloadCompleted(string packageName, string filePath)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					this.dictAppIcons[packageName].DownloadCompleted(filePath);
				}
				catch
				{
				}
			}), new object[0]);
		}

		// Token: 0x0600110D RID: 4365 RVA: 0x0006A534 File Offset: 0x00068734
		internal void ApkInstallStart(string packageName, string filePath)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					this.dictAppIcons[packageName].ApkInstallStart(filePath);
				}
				catch
				{
				}
			}), new object[0]);
		}

		// Token: 0x0600110E RID: 4366 RVA: 0x0006A57C File Offset: 0x0006877C
		internal void ApkInstallFailed(string packageName)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					this.dictAppIcons[packageName].ApkInstallFailed();
				}
				catch
				{
				}
			}), new object[0]);
		}

		// Token: 0x0600110F RID: 4367 RVA: 0x0006A5BC File Offset: 0x000687BC
		internal void ApkInstallCompleted(string packageName)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					this.dictAppIcons[packageName].ApkInstallCompleted();
				}
				catch
				{
				}
			}), new object[0]);
		}

		// Token: 0x06001110 RID: 4368 RVA: 0x0000C26D File Offset: 0x0000A46D
		private void HomeApp_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (e.OriginalSource == this.InstalledAppsDrawerScrollBar)
			{
				this.ParentWindow.StaticComponents.ShowUninstallButtons(false);
			}
		}

		// Token: 0x06001111 RID: 4369 RVA: 0x0000553B File Offset: 0x0000373B
		private void MultiInstanceContextMenu_ContextMenuOpening(object sender, ContextMenuEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x06001112 RID: 4370 RVA: 0x0000C28E File Offset: 0x0000A48E
		private void InstallApkIcon_Click(object sender, RoutedEventArgs e)
		{
			new DownloadInstallApk(this.ParentWindow).ChooseAndInstallApk();
		}

		// Token: 0x06001113 RID: 4371 RVA: 0x0000C2A0 File Offset: 0x0000A4A0
		private void UnInstallApkIcon_Click(object sender, RoutedEventArgs e)
		{
			this.ParentWindow.StaticComponents.ShowUninstallButtons(true);
		}

		// Token: 0x06001114 RID: 4372 RVA: 0x00005628 File Offset: 0x00003828
		private void Grid_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, System.Windows.Controls.Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x06001115 RID: 4373 RVA: 0x000046FF File Offset: 0x000028FF
		private void Grid_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			(sender as Grid).Background = System.Windows.Media.Brushes.Transparent;
		}

		// Token: 0x06001116 RID: 4374 RVA: 0x0006A5FC File Offset: 0x000687FC
		internal void RestoreWallpaperImage()
		{
			this.mBackgroundImage.IsFullImagePath = false;
			this.mBackgroundImage.ImageName = "fancybg.jpg";
			try
			{
				if (File.Exists(this.BackgroundImagePath))
				{
					File.Delete(this.BackgroundImagePath);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in deletion of image:" + ex.ToString());
			}
		}

		// Token: 0x06001117 RID: 4375 RVA: 0x0006A668 File Offset: 0x00068868
		public void ChooseWallpaper()
		{
			try
			{
				OpenFileDialog openFileDialog = new OpenFileDialog();
				openFileDialog.Title = LocaleStrings.GetLocalizedString("STRING_CHANGE_WALLPAPER", false);
				openFileDialog.RestoreDirectory = true;
				openFileDialog.DefaultExt = ".jpg";
				openFileDialog.Filter = "Image files (*.jpg, *.jpeg, *.png) | *.jpg; *.jpeg; *.png";
				if (openFileDialog.ShowDialog() == DialogResult.OK)
				{
					this.ApplyWallpaper(openFileDialog.FileName);
					ClientStats.SendMiscellaneousStatsAsync("WallPaperStats", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "Premium", "Changed_Wallpaper", null, null, null, null);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in changing wallpaper:" + ex.ToString());
				System.Windows.MessageBox.Show("Cannot change wallpaper.Please try again.", "Error");
			}
		}

		// Token: 0x06001118 RID: 4376 RVA: 0x0000C2B3 File Offset: 0x0000A4B3
		internal void ApplyWallpaper(string filepath)
		{
			Bitmap bitmap = new Bitmap(filepath);
			bitmap.Save(this.BackgroundImagePath);
			bitmap.Dispose();
			this.mBackgroundImage.ImageName = this.BackgroundImagePath;
			this.mBackgroundImage.ReloadImages();
		}

		// Token: 0x06001119 RID: 4377 RVA: 0x0000C2E8 File Offset: 0x0000A4E8
		private void ChooseNewGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ChooseWallpaper();
		}

		// Token: 0x0600111A RID: 4378 RVA: 0x0000C2F0 File Offset: 0x0000A4F0
		internal void OpenAppSuggestionPopup(AppSuggestionPromotion appInfoForShowingPopup, UIElement appNameTextBlock, bool staysOpen = true)
		{
			if (appInfoForShowingPopup.ToolTip != null)
			{
				this.mSuggestedAppPopUp.PlacementTarget = appNameTextBlock;
				this.mSuggestedAppPopUp.IsOpen = true;
				this.mSuggestedAppPopUp.StaysOpen = staysOpen;
				this.mAppSuggestionPopUp.Text = appInfoForShowingPopup.ToolTip;
			}
		}

		// Token: 0x0600111B RID: 4379 RVA: 0x0000C32F File Offset: 0x0000A52F
		internal void OpenGamepadSupportPopup(UIElement appNameTextBlock, bool staysOpen = true)
		{
			this.mGamepadSupportPopUp.PlacementTarget = appNameTextBlock;
			this.mGamepadSupportPopUp.IsOpen = true;
			this.mGamepadSupportPopUp.StaysOpen = staysOpen;
		}

		// Token: 0x0600111C RID: 4380 RVA: 0x0000C355 File Offset: 0x0000A555
		private void mAppSettings_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.mAppSettingsPopup.IsOpen = true;
		}

		// Token: 0x0600111D RID: 4381 RVA: 0x0000C28E File Offset: 0x0000A48E
		private void mInstallApkGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			new DownloadInstallApk(this.ParentWindow).ChooseAndInstallApk();
		}

		// Token: 0x0600111E RID: 4382 RVA: 0x0000C363 File Offset: 0x0000A563
		private void mDeleteAppsGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.StaticComponents.ShowUninstallButtons(true);
			this.mAppSettingsPopup.IsOpen = false;
		}

		// Token: 0x0600111F RID: 4383 RVA: 0x0000C382 File Offset: 0x0000A582
		private void mAppSettingsPopup_Opened(object sender, EventArgs e)
		{
			this.mAppSettings.IsEnabled = false;
		}

		// Token: 0x06001120 RID: 4384 RVA: 0x0000C390 File Offset: 0x0000A590
		private void mAppSettingsPopup_Closed(object sender, EventArgs e)
		{
			this.mAppSettings.IsEnabled = true;
		}

		// Token: 0x06001121 RID: 4385 RVA: 0x0006A724 File Offset: 0x00068924
		private void InstalledAppsDrawerScrollBar_ScrollChanged(object sender, ScrollChangedEventArgs e)
		{
			double verticalOffset = this.InstalledAppsDrawerScrollBar.VerticalOffset;
			if (this.InstalledAppsDrawerScrollBar.ComputedVerticalScrollBarVisibility != Visibility.Visible)
			{
				this.InstalledAppsDrawerScrollBar.OpacityMask = null;
				return;
			}
			if (verticalOffset <= 1.0)
			{
				this.InstalledAppsDrawerScrollBar.OpacityMask = BluestacksUIColor.mTopOpacityMask;
				return;
			}
			if (verticalOffset == this.InstalledAppsDrawerScrollBar.ScrollableHeight)
			{
				this.InstalledAppsDrawerScrollBar.OpacityMask = BluestacksUIColor.mBottomOpacityMask;
				return;
			}
			this.InstalledAppsDrawerScrollBar.OpacityMask = BluestacksUIColor.mScrolledOpacityMask;
		}

		// Token: 0x06001122 RID: 4386 RVA: 0x0000C39E File Offset: 0x0000A59E
		private void Close_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mMoreAppsDockPopup.IsOpen = false;
			this.mMoreAppsDockPopup.StaysOpen = false;
		}

		// Token: 0x06001123 RID: 4387 RVA: 0x0006A7A4 File Offset: 0x000689A4
		private void MoreAppsIcon_Click(object sender, RoutedEventArgs e)
		{
			AppIcon appIcon = sender as AppIcon;
			this.mDockAppIconToolTipPopup.IsOpen = false;
			this.mMoreAppsDockPopup.PlacementTarget = appIcon.mAppImage;
			this.mMoreAppsDockPopup.IsOpen = true;
		}

		// Token: 0x06001124 RID: 4388 RVA: 0x0000C3B8 File Offset: 0x0000A5B8
		private void mCloseAppSuggPopup_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.CloseAppSuggestionPopup();
		}

		// Token: 0x06001125 RID: 4389 RVA: 0x0000C3C0 File Offset: 0x0000A5C0
		internal void CloseAppSuggestionPopup()
		{
			this.mSuggestedAppPopUp.IsOpen = false;
		}

		// Token: 0x06001126 RID: 4390 RVA: 0x0000C3CE File Offset: 0x0000A5CE
		private void mCloseGamepadPopup_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mGamepadSupportPopUp.IsOpen = false;
		}

		// Token: 0x06001127 RID: 4391 RVA: 0x0006A7E4 File Offset: 0x000689E4
		internal void ShowAppRecommendations(bool isContentReloadRequired)
		{
			try
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					if ((this.ParentWindow != null && this.ParentWindow.ActualWidth <= 700.0) || FeatureManager.Instance.IsCustomUIForDMMSandbox || !FeatureManager.Instance.IsSearchBarVisible || RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
					{
						if (this.mCurrentSidePanelVisibility != null)
						{
							SidePanelVisibility? sidePanelVisibility = this.mCurrentSidePanelVisibility;
							SidePanelVisibility sidePanelVisibility2 = SidePanelVisibility.BothSearchBarAndSidepanelHidden;
							if (sidePanelVisibility.GetValueOrDefault() == sidePanelVisibility2 & sidePanelVisibility != null)
							{
								return;
							}
						}
						this.ChangeSideRecommendationsVisibility(false, false);
						this.mCurrentSidePanelVisibility = new SidePanelVisibility?(SidePanelVisibility.BothSearchBarAndSidepanelHidden);
						return;
					}
					if (RegistryManager.Instance.IsPremium || (!FeatureManager.Instance.IsHtmlSideBar && (!FeatureManager.Instance.IsShowAppRecommendations || (PromotionObject.Instance.AppRecommendations != null && PromotionObject.Instance.AppRecommendations.AppSuggestions.Count == 0))))
					{
						if (this.mCurrentSidePanelVisibility != null)
						{
							SidePanelVisibility? sidePanelVisibility = this.mCurrentSidePanelVisibility;
							SidePanelVisibility sidePanelVisibility2 = SidePanelVisibility.OnlySearchBarVisible;
							if (sidePanelVisibility.GetValueOrDefault() == sidePanelVisibility2 & sidePanelVisibility != null)
							{
								return;
							}
						}
						this.ChangeSideRecommendationsVisibility(false, true);
						this.mCurrentSidePanelVisibility = new SidePanelVisibility?(SidePanelVisibility.OnlySearchBarVisible);
						return;
					}
					if (FeatureManager.Instance.IsHtmlSideBar)
					{
						if (!RegistryManager.Instance.IsPremium)
						{
							if (this.mCurrentSidePanelVisibility != null)
							{
								SidePanelVisibility? sidePanelVisibility = this.mCurrentSidePanelVisibility;
								SidePanelVisibility sidePanelVisibility2 = SidePanelVisibility.OnlySidepanelVisible;
								if (sidePanelVisibility.GetValueOrDefault() == sidePanelVisibility2 & sidePanelVisibility != null)
								{
									return;
								}
							}
							this.ChangeSideRecommendationsVisibility(true, false);
							this.mCurrentSidePanelVisibility = new SidePanelVisibility?(SidePanelVisibility.OnlySidepanelVisible);
							return;
						}
					}
					else
					{
						if (isContentReloadRequired || !this.mIsSidePanelContentLoadedOnce)
						{
							this.mAppRecommendationSectionsPanel.Children.Clear();
							AppRecommendationSection appRecommendations = PromotionObject.Instance.AppRecommendations;
							RecommendedAppsSection recommendedAppsSection = new RecommendedAppsSection(appRecommendations.AppSuggestionHeader);
							recommendedAppsSection.AddSuggestedApps(this.ParentWindow, appRecommendations.AppSuggestions, appRecommendations.ClientShowCount);
							if (recommendedAppsSection.mAppRecommendationsPanel.Children.Count != 0)
							{
								this.mAppRecommendationSectionsPanel.Children.Add(recommendedAppsSection);
								this.mAppRecommendationSectionsPanel.Visibility = Visibility.Visible;
								this.mAppRecommendationsGenericMessages.Visibility = Visibility.Collapsed;
								this.SendAppRecommendationsImpressionStats();
							}
							this.mIsSidePanelContentLoadedOnce = true;
						}
						if (this.mCurrentSidePanelVisibility != null)
						{
							SidePanelVisibility? sidePanelVisibility = this.mCurrentSidePanelVisibility;
							SidePanelVisibility sidePanelVisibility2 = SidePanelVisibility.BothSearchBarAndSidepanelVisible;
							if (sidePanelVisibility.GetValueOrDefault() == sidePanelVisibility2 & sidePanelVisibility != null)
							{
								return;
							}
						}
						this.ChangeSideRecommendationsVisibility(true, true);
						this.mCurrentSidePanelVisibility = new SidePanelVisibility?(SidePanelVisibility.BothSearchBarAndSidepanelVisible);
					}
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Warning("Exception in showing app recommendations, " + ex.ToString());
			}
		}

		// Token: 0x06001128 RID: 4392 RVA: 0x0006A850 File Offset: 0x00068A50
		private void SendAppRecommendationsImpressionStats()
		{
			JArray jarray = new JArray();
			RecommendedAppsSection recommendedAppsSection = this.mAppRecommendationSectionsPanel.Children[0] as RecommendedAppsSection;
			for (int i = 0; i < recommendedAppsSection.mAppRecommendationsPanel.Children.Count; i++)
			{
				RecommendedApps recommendedApps = recommendedAppsSection.mAppRecommendationsPanel.Children[i] as RecommendedApps;
				jarray.Add(new JObject
				{
					{
						"app_loc",
						(recommendedApps.AppRecomendation.ExtraPayload["click_generic_action"] == "InstallCDN") ? "cdn" : "gplay"
					},
					{
						"app_pkg",
						recommendedApps.AppRecomendation.ExtraPayload["click_action_packagename"]
					},
					{
						"is_installed",
						this.ParentWindow.mAppHandler.IsAppInstalled(recommendedApps.AppRecomendation.ExtraPayload["click_action_packagename"]) ? "true" : "false"
					},
					{
						"app_position",
						recommendedApps.RecommendedAppPosition.ToString()
					},
					{
						"app_rank",
						recommendedApps.RecommendedAppRank.ToString()
					}
				});
			}
			ClientStats.SendFrontendClickStats("apps_recommendation", "impression", null, null, null, null, null, jarray.ToString(Formatting.None, new JsonConverter[0]));
		}

		// Token: 0x06001129 RID: 4393 RVA: 0x0006A9CC File Offset: 0x00068BCC
		internal void UpdateRecommendedAppsInstallStatus(string package)
		{
			if (this.mAppRecommendationSectionsPanel.Children.Count > 0)
			{
				int num = -1;
				RecommendedAppsSection recommendedAppsSection = this.mAppRecommendationSectionsPanel.Children[0] as RecommendedAppsSection;
				RecommendedApps recommendedApps = null;
				for (int i = 0; i < recommendedAppsSection.mAppRecommendationsPanel.Children.Count; i++)
				{
					RecommendedApps recommendedApps2 = recommendedAppsSection.mAppRecommendationsPanel.Children[i] as RecommendedApps;
					if (recommendedApps2.AppRecomendation.AppPackage.Equals(package, StringComparison.InvariantCultureIgnoreCase))
					{
						num = i;
						recommendedApps = recommendedApps2;
						break;
					}
				}
				if (num != -1)
				{
					recommendedAppsSection.mAppRecommendationsPanel.Children.RemoveAt(num);
					if (this.sAppRecommendationsPool.Count > 0)
					{
						int num2 = 1;
						for (int j = 0; j < this.sAppRecommendationsPool.Count; j++)
						{
							RecommendedApps recommendedApps3 = this.sAppRecommendationsPool[j];
							if (!this.ParentWindow.mAppHandler.IsAppInstalled(recommendedApps3.AppRecomendation.ExtraPayload["click_action_packagename"]))
							{
								recommendedApps3.RecommendedAppPosition = recommendedApps.RecommendedAppPosition;
								recommendedAppsSection.mAppRecommendationsPanel.Children.Insert(num, recommendedApps3);
								ClientStats.SendFrontendClickStats("apps_recommendation", "impression", null, null, null, null, null, new JArray
								{
									new JObject
									{
										{
											"app_loc",
											(recommendedApps3.AppRecomendation.ExtraPayload["click_generic_action"] == "InstallCDN") ? "cdn" : "gplay"
										},
										{
											"app_pkg",
											recommendedApps3.AppRecomendation.ExtraPayload["click_action_packagename"]
										},
										{
											"is_installed",
											this.ParentWindow.mAppHandler.IsAppInstalled(recommendedApps3.AppRecomendation.ExtraPayload["click_action_packagename"]) ? "true" : "false"
										},
										{
											"app_position",
											recommendedApps3.RecommendedAppPosition.ToString()
										},
										{
											"app_rank",
											recommendedApps3.RecommendedAppRank.ToString()
										}
									}
								}.ToString(Formatting.None, new JsonConverter[0]));
								break;
							}
							num2++;
						}
						this.sAppRecommendationsPool.RemoveRange(0, num2);
					}
					if (recommendedAppsSection.mAppRecommendationsPanel.Children.Count == 0)
					{
						this.mAppRecommendationSectionsPanel.Children.Remove(recommendedAppsSection);
					}
					if (this.mAppRecommendationSectionsPanel.Children.Count == 0)
					{
						this.mAppRecommendationSectionsPanel.Visibility = Visibility.Collapsed;
						this.mAppRecommendationsGenericMessages.Visibility = Visibility.Visible;
					}
				}
			}
		}

		// Token: 0x0600112A RID: 4394 RVA: 0x0006AC88 File Offset: 0x00068E88
		private void SearchTextBox_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
		{
			if (this.ParentWindow.mWelcomeTab.IsPromotionVisible)
			{
				return;
			}
			if (this.mSearchTextBox.Text == this.defaultSearchBoxText)
			{
				this.mSearchTextBox.Text = string.Empty;
			}
			this.OpenSearchSuggestions();
			BlueStacksUIBinding.BindColor(this.mSearchTextBox, System.Windows.Controls.Control.ForegroundProperty, "SearchGridForegroundFocusedColor");
		}

		// Token: 0x0600112B RID: 4395 RVA: 0x0006ACEC File Offset: 0x00068EEC
		private void SearchTextBox_LostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
		{
			if (!this.mSearchRecommendationBorder.IsMouseOver)
			{
				this.HideSearchSuggestions();
			}
			if (this.ParentWindow.mWelcomeTab.IsPromotionVisible)
			{
				return;
			}
			if (string.IsNullOrEmpty(this.mSearchTextBox.Text))
			{
				this.mSearchTextBox.Text = this.defaultSearchBoxText;
			}
			if (this.mSearchTextBox.Text.Equals(this.defaultSearchBoxText))
			{
				BlueStacksUIBinding.BindColor(this.mSearchTextBox, System.Windows.Controls.Control.ForegroundProperty, "SearchGridForegroundColor");
				return;
			}
			BlueStacksUIBinding.BindColor(this.mSearchTextBox, System.Windows.Controls.Control.ForegroundProperty, "SearchGridForegroundFocusedColor");
		}

		// Token: 0x0600112C RID: 4396 RVA: 0x0000C3DC File Offset: 0x0000A5DC
		private void CustomPictureBox_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.SearchApp();
		}

		// Token: 0x0600112D RID: 4397 RVA: 0x0000C3E4 File Offset: 0x0000A5E4
		private void SearchTextBox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			if (this.mSearchRecommendationBorder.Visibility == Visibility.Visible)
			{
				this.HideSearchSuggestions();
			}
			if (e.Key == Key.Return)
			{
				this.SearchApp();
			}
		}

		// Token: 0x0600112E RID: 4398 RVA: 0x0006AD88 File Offset: 0x00068F88
		private void SearchApp()
		{
			if (this.ParentWindow.mWelcomeTab.IsPromotionVisible)
			{
				return;
			}
			if (!string.IsNullOrEmpty(this.mSearchTextBox.Text))
			{
				this.ParentWindow.mCommonHandler.SearchAppCenter(this.mSearchTextBox.Text);
			}
		}

		// Token: 0x0600112F RID: 4399 RVA: 0x0006ADD8 File Offset: 0x00068FD8
		private void OpenSearchSuggestions()
		{
			try
			{
				if (this.mSearchRecommendationBorder.Visibility != Visibility.Visible && (string.IsNullOrEmpty(this.mSearchTextBox.Text) || this.mSearchTextBox.Text == this.defaultSearchBoxText) && PromotionObject.Instance.SearchRecommendations != null && PromotionObject.Instance.SearchRecommendations.Count > 0 && this.mIsShowSearchRecommendations)
				{
					this.searchRecomItems.Children.Clear();
					Separator separator = new Separator();
					separator.Margin = new Thickness(0.0);
					separator.Style = (base.FindResource(System.Windows.Controls.ToolBar.SeparatorStyleKey) as Style);
					BlueStacksUIBinding.BindColor(separator, System.Windows.Controls.Control.BackgroundProperty, "VerticalSeparator");
					this.searchRecomItems.Children.Add(separator);
					System.Windows.Controls.Label label = new System.Windows.Controls.Label();
					label.Content = LocaleStrings.GetLocalizedString("STRING_MOST_SEARCHED_APPS", false);
					BlueStacksUIBinding.BindColor(label, System.Windows.Controls.Control.ForegroundProperty, "SearchGridForegroundColor");
					label.FontSize = 14.0;
					label.Padding = new Thickness(10.0, 5.0, 5.0, 5.0);
					this.searchRecomItems.Children.Add(label);
					foreach (KeyValuePair<string, SearchRecommendation> keyValuePair in PromotionObject.Instance.SearchRecommendations)
					{
						RecommendedAppItem recommendedAppItem = new RecommendedAppItem();
						recommendedAppItem.Populate(this.ParentWindow, keyValuePair.Value);
						recommendedAppItem.Padding = new Thickness(5.0, 0.0, 0.0, 0.0);
						this.searchRecomItems.Children.Add(recommendedAppItem);
					}
					this.mSearchRecommendationBorder.CornerRadius = new CornerRadius(0.0, 0.0, this.searchTextBoxBorder.CornerRadius.BottomRight, this.searchTextBoxBorder.CornerRadius.BottomLeft);
					this.Mask.CornerRadius = new CornerRadius(0.0, this.searchTextBoxBorder.CornerRadius.TopRight, 0.0, 0.0);
					this.searchTextBoxBorder.CornerRadius = new CornerRadius(this.searchTextBoxBorder.CornerRadius.TopLeft, this.searchTextBoxBorder.CornerRadius.TopRight, 0.0, 0.0);
					this.mSearchRecommendationBorder.Visibility = Visibility.Visible;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception when trying to open search recommendations. " + ex.ToString());
			}
		}

		// Token: 0x06001130 RID: 4400 RVA: 0x0006B0EC File Offset: 0x000692EC
		private void HideSearchSuggestions()
		{
			if (this.mSearchRecommendationBorder.Visibility == Visibility.Visible)
			{
				this.searchTextBoxBorder.CornerRadius = new CornerRadius(this.searchTextBoxBorder.CornerRadius.TopLeft, this.searchTextBoxBorder.CornerRadius.TopRight, this.mSearchRecommendationBorder.CornerRadius.BottomRight, this.mSearchRecommendationBorder.CornerRadius.BottomLeft);
				this.Mask.CornerRadius = new CornerRadius(0.0, this.searchTextBoxBorder.CornerRadius.TopRight, this.mSearchRecommendationBorder.CornerRadius.BottomRight, 0.0);
				this.mSearchRecommendationBorder.Visibility = Visibility.Hidden;
			}
		}

		// Token: 0x06001131 RID: 4401 RVA: 0x0000C408 File Offset: 0x0000A608
		private void search_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.searchHoverTimer.Stop();
			if (!this.mSearchTextBox.IsFocused && !this.mSearchRecommendationBorder.IsMouseOver && !this.mSearchGrid.IsMouseOver)
			{
				this.HideSearchSuggestions();
			}
		}

		// Token: 0x06001132 RID: 4402 RVA: 0x0000C442 File Offset: 0x0000A642
		private void Search_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.searchHoverTimer.Start();
		}

		// Token: 0x06001133 RID: 4403 RVA: 0x0006B1BC File Offset: 0x000693BC
		internal void ShowAppPopupAfterUpgrade(string packageName)
		{
			try
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					if (this.dictAppIcons.ContainsKey(packageName) && File.Exists(KMManager.GetInputmapperUserFilePath(packageName)))
					{
						CustomMessageWindow customMessageWindow = new CustomMessageWindow();
						customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
						customMessageWindow.TitleTextBlock.Text = "Garena Free Fire - " + LocaleStrings.GetLocalizedString("STRING_UPDATE_SETTING", false);
						customMessageWindow.BodyTextBlock.Text = string.Format(LocaleStrings.GetLocalizedString("STRING_FREEFIRE_NOTIFICATION_MESSAGE", false), "Garena Free Fire");
						customMessageWindow.BodyWarningTextBlock.Visibility = Visibility.Visible;
						BlueStacksUIBinding.Bind(customMessageWindow.BodyWarningTextBlock, "STRING_FREEFIRE_NOTIFICATION_DETAIL", "");
						customMessageWindow.BodyWarningTextBlock.FontWeight = FontWeights.Light;
						BlueStacksUIBinding.BindColor(customMessageWindow.BodyWarningTextBlock, System.Windows.Controls.Control.ForegroundProperty, "SettingsWindowForegroundDimDimColor");
						customMessageWindow.UrlTextBlock.Visibility = Visibility.Visible;
						customMessageWindow.UrlLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_FREEFIRE_NOTIFICATION_LINK", false));
						string uriString = WebHelper.GetUrlWithParams(string.Format("{0}/{1}", WebHelper.GetServerHost(), "help_articles")) + "&article=smart_control";
						customMessageWindow.UrlLink.NavigateUri = new Uri(uriString);
						customMessageWindow.UrlLink.RequestNavigate += this.OpenSmartControlHelp;
						this.ParentWindow.ShowDimOverlay(null);
						customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
						customMessageWindow.ShowDialog();
						if (this.ParentWindow.mDimOverlay != null && this.ParentWindow.mDimOverlay.OwnedWindows.OfType<ContainerWindow>().Count<ContainerWindow>() == 0)
						{
							this.ParentWindow.HideDimOverlay();
						}
					}
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Warning("Exception in showing app notifications after upgrade: " + ex.ToString());
			}
		}

		// Token: 0x06001134 RID: 4404 RVA: 0x0000C44F File Offset: 0x0000A64F
		private void OpenSmartControlHelp(object sender, RequestNavigateEventArgs e)
		{
			BlueStacksUIUtils.OpenUrl(e.Uri.OriginalString);
		}

		// Token: 0x04000B87 RID: 2951
		private Dictionary<string, AppIcon> dictAppIcons = new Dictionary<string, AppIcon>();

		// Token: 0x04000B88 RID: 2952
		private WrapPanel InstalledAppsDrawer;

		// Token: 0x04000B89 RID: 2953
		private DispatcherTimer searchHoverTimer;

		// Token: 0x04000B8C RID: 2956
		private string defaultSearchBoxText = LocaleStrings.GetLocalizedString("STRING_SEARCH", false);

		// Token: 0x04000B8D RID: 2957
		private bool mIsShowSearchRecommendations;

		// Token: 0x04000B8E RID: 2958
		private SidePanelVisibility? mCurrentSidePanelVisibility;

		// Token: 0x04000B8F RID: 2959
		private bool mIsSidePanelContentLoadedOnce;

		// Token: 0x04000B90 RID: 2960
		internal List<RecommendedApps> sAppRecommendationsPool = new List<RecommendedApps>();

		// Token: 0x04000B91 RID: 2961
		private MainWindow mMainWindow;
	}
}
