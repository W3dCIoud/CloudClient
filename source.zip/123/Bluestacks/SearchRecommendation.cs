﻿using System;
using System.IO;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000040 RID: 64
	public class SearchRecommendation
	{
		// Token: 0x1700011B RID: 283
		// (get) Token: 0x0600033A RID: 826 RVA: 0x000042E8 File Offset: 0x000024E8
		// (set) Token: 0x0600033B RID: 827 RVA: 0x000042F0 File Offset: 0x000024F0
		public SerializableDictionary<string, string> ExtraPayload
		{
			get
			{
				return this.mExtraPayload;
			}
			set
			{
				this.mExtraPayload = value;
			}
		}

		// Token: 0x1700011C RID: 284
		// (get) Token: 0x0600033C RID: 828 RVA: 0x000042F9 File Offset: 0x000024F9
		// (set) Token: 0x0600033D RID: 829 RVA: 0x00004301 File Offset: 0x00002501
		public string IconId
		{
			get
			{
				return this.mIconId;
			}
			set
			{
				this.mIconId = value;
			}
		}

		// Token: 0x1700011D RID: 285
		// (get) Token: 0x0600033E RID: 830 RVA: 0x0000430A File Offset: 0x0000250A
		// (set) Token: 0x0600033F RID: 831 RVA: 0x00004312 File Offset: 0x00002512
		public string ImagePath
		{
			get
			{
				return this.sImagePath;
			}
			set
			{
				this.sImagePath = value;
			}
		}

		// Token: 0x06000340 RID: 832 RVA: 0x00018274 File Offset: 0x00016474
		internal void DeleteFile()
		{
			try
			{
				File.Delete(this.ImagePath);
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't delete SearchRecommendation file: " + this.ImagePath);
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x040001B6 RID: 438
		private SerializableDictionary<string, string> mExtraPayload = new SerializableDictionary<string, string>();

		// Token: 0x040001B7 RID: 439
		private string mIconId;

		// Token: 0x040001B8 RID: 440
		private string sImagePath = string.Empty;
	}
}
