﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Timers;
using BlueStacks.Common;
using DiscordRPC;
using DiscordRPC.Events;
using DiscordRPC.Message;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000C5 RID: 197
	public class Discord
	{
		// Token: 0x060007E6 RID: 2022 RVA: 0x0000714A File Offset: 0x0000534A
		public Discord(MainWindow window)
		{
			this.ParentWindow = window;
		}

		// Token: 0x060007E7 RID: 2023 RVA: 0x0000717A File Offset: 0x0000537A
		internal void Init()
		{
			this.SetSystemAppsAndClientID();
			this.InitDiscordClient();
		}

		// Token: 0x060007E8 RID: 2024 RVA: 0x00007188 File Offset: 0x00005388
		private void AssignTabChangeEventOnOpenedTabs()
		{
			if (this.ParentWindow != null)
			{
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					foreach (AppTabButton appTabButton in this.ParentWindow.mTopBar.mAppTabButtons.mDictTabs.Values.ToList<AppTabButton>())
					{
						if (appTabButton.EventOnTabChanged == null)
						{
							Logger.Info("discord attaching tab change event on tab.." + appTabButton.PackageName);
							this.AssignTabChangeEvent(appTabButton);
							if (appTabButton.IsSelected)
							{
								this.Tab_ChangeOrCreateEvent(null, new TabChangeEventArgs(appTabButton.AppName, appTabButton.PackageName, appTabButton.mTabType));
							}
						}
						else if (appTabButton.IsSelected)
						{
							this.Tab_ChangeOrCreateEvent(null, new TabChangeEventArgs(appTabButton.AppName, appTabButton.PackageName, appTabButton.mTabType));
						}
					}
				}), new object[0]);
			}
		}

		// Token: 0x060007E9 RID: 2025 RVA: 0x000071B5 File Offset: 0x000053B5
		private void RemoveTabChangeEventFromOpenedTabs()
		{
			if (this.ParentWindow != null)
			{
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					foreach (AppTabButton appTabButton in this.ParentWindow.mTopBar.mAppTabButtons.mDictTabs.Values.ToList<AppTabButton>())
					{
						if (appTabButton.EventOnTabChanged != null)
						{
							AppTabButton appTabButton2 = appTabButton;
							appTabButton2.EventOnTabChanged = (EventHandler<TabChangeEventArgs>)Delegate.Remove(appTabButton2.EventOnTabChanged, new EventHandler<TabChangeEventArgs>(this.Tab_ChangeOrCreateEvent));
						}
					}
				}), new object[0]);
			}
		}

		// Token: 0x060007EA RID: 2026 RVA: 0x00031D0C File Offset: 0x0002FF0C
		private void SetSystemAppsAndClientID()
		{
			if (PromotionObject.Instance != null)
			{
				this.mDiscordClientID = PromotionObject.Instance.DiscordClientID;
				this.mSystemApps = (from x in PromotionObject.Instance.AppSuggestionList
				where x.AppLocation.Equals("more_apps")
				select x).ToList<AppSuggestionPromotion>();
			}
		}

		// Token: 0x060007EB RID: 2027 RVA: 0x000071E2 File Offset: 0x000053E2
		internal void RemoveAppFromTimestampList(string package)
		{
			if (this.mAppStartTimestamp.ContainsKey(package))
			{
				this.mAppStartTimestamp.Remove(package);
			}
		}

		// Token: 0x060007EC RID: 2028 RVA: 0x000071FF File Offset: 0x000053FF
		internal bool IsDiscordClientReady()
		{
			return this.mDiscordClient != null && this.mDiscordClient.IsInitialized && this.mIsDiscordConnected;
		}

		// Token: 0x060007ED RID: 2029 RVA: 0x00031D6C File Offset: 0x0002FF6C
		private void Tab_ChangeOrCreateEvent(object sender, TabChangeEventArgs e)
		{
			try
			{
				if (!string.Equals(this.mPreviousAppPackage, e.PackageName) && this.IsDiscordClientReady())
				{
					Logger.Info("Discord tab changed event. PkgName: {0}, AppName: {1}", new object[]
					{
						e.PackageName,
						e.AppName
					});
					RichPresence richPresence = new RichPresence();
					TabType tabType = e.TabType;
					if (tabType != TabType.AppTab)
					{
						if (tabType - TabType.WebTab <= 1)
						{
							if (e.PackageName.Contains("bluestacks") && e.PackageName.Contains("appcenter"))
							{
								richPresence.State = "Searching";
								richPresence.Details = "Google Play Store";
								richPresence.Assets = new Assets
								{
									LargeImageKey = "bstk-logo",
									LargeImageText = "BlueStacks",
									SmallImageKey = "com_android_vending",
									SmallImageText = "Google Play"
								};
							}
							else
							{
								richPresence.State = "In Lobby";
								richPresence.Details = "About to start a game";
								richPresence.Assets = new Assets
								{
									LargeImageKey = "bstk-logo",
									LargeImageText = "BlueStacks",
									SmallImageKey = "",
									SmallImageText = ""
								};
							}
						}
					}
					else if ((from _ in this.mSystemApps
					where _.AppPackage == e.PackageName
					select _).Count<AppSuggestionPromotion>() > 0)
					{
						richPresence.State = "In Lobby";
						richPresence.Details = "About to start a game";
						richPresence.Assets = new Assets
						{
							LargeImageKey = "bstk-logo",
							LargeImageText = "BlueStacks",
							SmallImageKey = "",
							SmallImageText = ""
						};
					}
					else if (e.PackageName.Contains("android.vending"))
					{
						richPresence.State = "Searching";
						richPresence.Details = "Google Play Store";
						richPresence.Assets = new Assets
						{
							LargeImageKey = "bstk-logo",
							LargeImageText = "BlueStacks",
							SmallImageKey = "com_android_vending",
							SmallImageText = "Google Play"
						};
					}
					else
					{
						if (this.mAppStartTimestamp.ContainsKey(e.PackageName))
						{
							richPresence.Timestamps = this.mAppStartTimestamp[e.PackageName];
						}
						else
						{
							richPresence.Timestamps = Timestamps.Now;
							this.mAppStartTimestamp.Add(e.PackageName, Timestamps.Now);
						}
						richPresence.State = "Playing";
						richPresence.Details = e.AppName;
						richPresence.Assets = new Assets
						{
							LargeImageKey = this.GetMD5HashFromPackageName(e.PackageName),
							LargeImageText = e.AppName,
							SmallImageKey = "bstk-logo",
							SmallImageText = "BlueStacks"
						};
					}
					this.SetPresence(richPresence);
					this.mPreviousAppPackage = e.PackageName;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error while setting presence in discord with exception : {0}", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x060007EE RID: 2030 RVA: 0x000320B8 File Offset: 0x000302B8
		private string GetMD5HashFromPackageName(string package)
		{
			string text = string.Empty;
			text = new _MD5
			{
				Value = package
			}.FingerPrint.ToLower();
			Logger.Info("Md5 hash for package name: {0}..is {1}", new object[]
			{
				package,
				text
			});
			return text;
		}

		// Token: 0x060007EF RID: 2031 RVA: 0x0000721E File Offset: 0x0000541E
		internal void AssignTabChangeEvent(AppTabButton button)
		{
			if (button.EventOnTabChanged == null)
			{
				button.EventOnTabChanged = (EventHandler<TabChangeEventArgs>)Delegate.Combine(button.EventOnTabChanged, new EventHandler<TabChangeEventArgs>(this.Tab_ChangeOrCreateEvent));
			}
		}

		// Token: 0x060007F0 RID: 2032 RVA: 0x000320FC File Offset: 0x000302FC
		private void InitDiscordClient()
		{
			try
			{
				if (this.mDiscordClient == null)
				{
					Logger.Info("Initing discord");
					this.mDiscordClient = new DiscordRpcClient(this.mDiscordClientID);
					this.mDiscordClient.OnReady += delegate(object sender, ReadyMessage msg)
					{
						Logger.Info("Connected to discord with user {0}", new object[]
						{
							msg.User.Username
						});
					};
					this.mDiscordClient.OnPresenceUpdate += new OnPresenceUpdateEvent(this.Client_OnPresenceUpdate);
					this.mDiscordClient.OnError += new OnErrorEvent(this.Client_OnError);
					this.mDiscordClient.OnConnectionFailed += new OnConnectionFailedEvent(this.Client_OnConnectionFailed);
					this.mDiscordClient.OnConnectionEstablished += new OnConnectionEstablishedEvent(this.Client_OnConnectionEstablished);
					this.mDiscordClientInvokeTimer = new Timer(150.0);
					this.mDiscordClientInvokeTimer.Elapsed += delegate(object sender, ElapsedEventArgs evt)
					{
						this.mDiscordClient.Invoke();
					};
					this.mDiscordClientInvokeTimer.Start();
					bool flag = this.mDiscordClient.Initialize();
					Logger.Info("Discord client init: {0}", new object[]
					{
						flag
					});
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Exception in Discord init. ex:  " + ex.ToString());
			}
		}

		// Token: 0x060007F1 RID: 2033 RVA: 0x00032248 File Offset: 0x00030448
		internal void Dispose()
		{
			if (this.mDiscordClient != null)
			{
				this.mPreviousAppPackage = string.Empty;
				this.mIsDiscordConnected = false;
				this.mAppStartTimestamp.Clear();
				this.mDiscordClient.ClearPresence();
				this.mDiscordClientInvokeTimer.Dispose();
				this.mDiscordClient.Dispose();
				this.mDiscordClient = null;
				this.RemoveTabChangeEventFromOpenedTabs();
				this.ParentWindow.mDiscordhandler = null;
			}
		}

		// Token: 0x060007F2 RID: 2034 RVA: 0x000322B4 File Offset: 0x000304B4
		private void Client_OnPresenceUpdate(object sender, PresenceMessage args)
		{
			string str = "Discord presence has been updated with details.";
			string str2;
			if (args == null)
			{
				str2 = null;
			}
			else
			{
				RichPresence presence = args.Presence;
				str2 = ((presence != null) ? presence.Details : null);
			}
			Logger.Info(str + str2);
			if (args.Presence.Assets.LargeImageKey == null)
			{
				RichPresence richPresence = args.Presence.Clone();
				richPresence.Assets.LargeImageKey = "bstk-logo";
				richPresence.Assets.SmallImageKey = "";
				richPresence.Assets.SmallImageText = "";
				this.SetPresence(richPresence);
			}
		}

		// Token: 0x060007F3 RID: 2035 RVA: 0x0000724A File Offset: 0x0000544A
		private void SetPresence(RichPresence presence)
		{
			if (this.mDiscordClient != null && this.mDiscordClient.IsInitialized)
			{
				this.mDiscordClient.SetPresence(presence);
				return;
			}
			Logger.Warning("SetPresence called without a client being inited");
		}

		// Token: 0x060007F4 RID: 2036 RVA: 0x00032340 File Offset: 0x00030540
		private void Client_OnConnectionEstablished(object sender, ConnectionEstablishedMessage args)
		{
			Logger.Info("Discord connection Established");
			this.mIsDiscordConnected = true;
			this.AssignTabChangeEventOnOpenedTabs();
			ClientStats.SendMiscellaneousStatsAsync("DiscordConnected", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.RegisteredEmail, Oem.Instance.OEM, null, null, null, null);
		}

		// Token: 0x060007F5 RID: 2037 RVA: 0x0003239C File Offset: 0x0003059C
		private void Client_OnConnectionFailed(object sender, ConnectionFailedMessage args)
		{
			Logger.Info("Discord connection failed. ErrorCode: {0}", new object[]
			{
				args.Type
			});
			this.mIsDiscordConnected = false;
			this.Dispose();
			ClientStats.SendMiscellaneousStatsAsync("DiscordNotConnected", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.RegisteredEmail, Oem.Instance.OEM, null, null, null, null);
		}

		// Token: 0x060007F6 RID: 2038 RVA: 0x00007278 File Offset: 0x00005478
		private void Client_OnError(object sender, ErrorMessage args)
		{
			Logger.Info("Discord client error. ErrorCode: {0}, Message: {1}", new object[]
			{
				args.Code,
				args.Message
			});
		}

		// Token: 0x060007F7 RID: 2039 RVA: 0x000072A1 File Offset: 0x000054A1
		internal void ToggleDiscordState(bool state)
		{
			if (state)
			{
				if (this.mDiscordClient == null)
				{
					this.Init();
					return;
				}
			}
			else
			{
				this.Dispose();
			}
		}

		// Token: 0x040005B5 RID: 1461
		private DiscordRpcClient mDiscordClient;

		// Token: 0x040005B6 RID: 1462
		private Timer mDiscordClientInvokeTimer;

		// Token: 0x040005B7 RID: 1463
		private string mPreviousAppPackage;

		// Token: 0x040005B8 RID: 1464
		private List<AppSuggestionPromotion> mSystemApps = new List<AppSuggestionPromotion>();

		// Token: 0x040005B9 RID: 1465
		private string mDiscordClientID = string.Empty;

		// Token: 0x040005BA RID: 1466
		private Dictionary<string, Timestamps> mAppStartTimestamp = new Dictionary<string, Timestamps>();

		// Token: 0x040005BB RID: 1467
		private MainWindow ParentWindow;

		// Token: 0x040005BC RID: 1468
		private bool mIsDiscordConnected;
	}
}
