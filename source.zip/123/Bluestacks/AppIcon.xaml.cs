﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Xml;
using System.Xml.Serialization;
using BlueStacks.Common;
using BlueStacks.Common.Grm;
using Microsoft.Win32;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000024 RID: 36
	public partial class AppIcon : Button
	{
		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x060001D5 RID: 469 RVA: 0x0000334F File Offset: 0x0000154F
		private MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x14000001 RID: 1
		// (add) Token: 0x060001D6 RID: 470 RVA: 0x00010CC0 File Offset: 0x0000EEC0
		// (remove) Token: 0x060001D7 RID: 471 RVA: 0x00010CF8 File Offset: 0x0000EEF8
		private event EventHandler UninstallConfirmationClicked;

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x060001D8 RID: 472 RVA: 0x00003370 File Offset: 0x00001570
		// (set) Token: 0x060001D9 RID: 473 RVA: 0x00003378 File Offset: 0x00001578
		internal bool IsInstalledApp
		{
			get
			{
				return this.mIsInstalledApp;
			}
			set
			{
				this.mIsInstalledApp = value;
			}
		}

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x060001DA RID: 474 RVA: 0x00003381 File Offset: 0x00001581
		// (set) Token: 0x060001DB RID: 475 RVA: 0x00003389 File Offset: 0x00001589
		public AppRequirement Requirements
		{
			get
			{
				return this.mRequirements;
			}
			set
			{
				this.mRequirements = value;
			}
		}

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x060001DC RID: 476 RVA: 0x00003392 File Offset: 0x00001592
		// (set) Token: 0x060001DD RID: 477 RVA: 0x0000339A File Offset: 0x0000159A
		public GrmRuleSet PassedRuleSet { get; set; }

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x060001DE RID: 478 RVA: 0x000033A3 File Offset: 0x000015A3
		// (set) Token: 0x060001DF RID: 479 RVA: 0x000033AB File Offset: 0x000015AB
		public int MyAppPriority
		{
			get
			{
				return this.mMyAppPriority;
			}
			set
			{
				this.mMyAppPriority = value;
			}
		}

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x060001E0 RID: 480 RVA: 0x000033B4 File Offset: 0x000015B4
		// (set) Token: 0x060001E1 RID: 481 RVA: 0x000033C1 File Offset: 0x000015C1
		public string ImageName
		{
			get
			{
				return this.mAppImage.ImageName;
			}
			set
			{
				this.mAppImage.IsFullImagePath = true;
				this.mAppImage.ImageName = value;
			}
		}

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x060001E2 RID: 482 RVA: 0x000033DB File Offset: 0x000015DB
		// (set) Token: 0x060001E3 RID: 483 RVA: 0x000033E3 File Offset: 0x000015E3
		public string PackageName
		{
			get
			{
				return this.mPackageName;
			}
			set
			{
				this.mPackageName = value;
				this.LoadDownloadAppIcon();
			}
		}

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x060001E4 RID: 484 RVA: 0x000033F2 File Offset: 0x000015F2
		// (set) Token: 0x060001E5 RID: 485 RVA: 0x000033FA File Offset: 0x000015FA
		public string ActivityName
		{
			get
			{
				return this.mActivityName;
			}
			set
			{
				this.mActivityName = value;
			}
		}

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x060001E6 RID: 486 RVA: 0x00003403 File Offset: 0x00001603
		// (set) Token: 0x060001E7 RID: 487 RVA: 0x00003410 File Offset: 0x00001610
		public string AppName
		{
			get
			{
				return this.AppNameTextBox.Text;
			}
			set
			{
				BlueStacksUIBinding.Bind(this, value, FrameworkElement.ToolTipProperty);
				BlueStacksUIBinding.Bind(this.AppNameTextBox, value, "");
			}
		}

		// Token: 0x170000DC RID: 220
		// (get) Token: 0x060001E8 RID: 488 RVA: 0x0000342F File Offset: 0x0000162F
		// (set) Token: 0x060001E9 RID: 489 RVA: 0x00003437 File Offset: 0x00001637
		internal bool IsGamepadCompatible { get; set; }

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x060001EA RID: 490 RVA: 0x00003440 File Offset: 0x00001640
		// (set) Token: 0x060001EB RID: 491 RVA: 0x00003448 File Offset: 0x00001648
		public string ApkUrl
		{
			get
			{
				return this.mApkUrl;
			}
			set
			{
				this.mApkUrl = value;
			}
		}

		// Token: 0x170000DE RID: 222
		// (get) Token: 0x060001EC RID: 492 RVA: 0x00003451 File Offset: 0x00001651
		// (set) Token: 0x060001ED RID: 493 RVA: 0x00003459 File Offset: 0x00001659
		public bool IsDownloading
		{
			get
			{
				return this.mIsDownloading;
			}
			set
			{
				this.mIsDownloading = value;
			}
		}

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x060001EE RID: 494 RVA: 0x00003462 File Offset: 0x00001662
		// (set) Token: 0x060001EF RID: 495 RVA: 0x0000346A File Offset: 0x0000166A
		public bool IsGifIcon
		{
			get
			{
				return this.mIsGifIcon;
			}
			set
			{
				this.mIsGifIcon = value;
			}
		}

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x060001F0 RID: 496 RVA: 0x00003473 File Offset: 0x00001673
		// (set) Token: 0x060001F1 RID: 497 RVA: 0x0000347B File Offset: 0x0000167B
		public bool IsAppSuggestionActive
		{
			get
			{
				return this.mIsAppSuggestionActive;
			}
			set
			{
				this.mIsAppSuggestionActive = value;
			}
		}

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x060001F2 RID: 498 RVA: 0x00003484 File Offset: 0x00001684
		// (set) Token: 0x060001F3 RID: 499 RVA: 0x0000348C File Offset: 0x0000168C
		public bool IsDockLocation
		{
			get
			{
				return this.mIsDockLocation;
			}
			set
			{
				this.mIsDockLocation = value;
			}
		}

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x060001F4 RID: 500 RVA: 0x00003495 File Offset: 0x00001695
		// (set) Token: 0x060001F5 RID: 501 RVA: 0x0000349D File Offset: 0x0000169D
		public bool IsInstaling
		{
			get
			{
				return this.mIsInstalling;
			}
			set
			{
				this.mIsInstalling = value;
			}
		}

		// Token: 0x060001F6 RID: 502 RVA: 0x00010D30 File Offset: 0x0000EF30
		public AppIcon()
		{
			this.InitializeComponent();
			this.UninstallConfirmationClicked += this.AppIcon_UninstallConfirmationClicked;
		}

		// Token: 0x060001F7 RID: 503 RVA: 0x00010DA8 File Offset: 0x0000EFA8
		private void Init(string package, string appName)
		{
			if (AppHandler.sListIgnoredApps.Contains(package, StringComparer.InvariantCultureIgnoreCase))
			{
				base.Visibility = Visibility.Collapsed;
			}
			this.PackageName = package;
			this.AppName = appName;
			base.ToolTip = appName;
			if (RegistryManager.Instance.IsShowIconBorder)
			{
				this.ApplyBorder("appFrameIcon");
			}
			this.IsGamepadCompatible = KMManager.CheckGamepadCompatible(package);
			if (this.IsGamepadCompatible)
			{
				this.AppNameTextBox.TextWrapping = TextWrapping.NoWrap;
				this.mGamePadGrid.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x060001F8 RID: 504 RVA: 0x000034A6 File Offset: 0x000016A6
		internal void ApplyBorder(string path)
		{
			if (this.mPromotionId == null)
			{
				this.mSuggestedAppPromotionImage.ImageName = path;
				this.mSuggestedAppPromotionImage.Visibility = Visibility.Visible;
				this.mSuggestedAppPromotionImage.Clip = null;
			}
		}

		// Token: 0x060001F9 RID: 505 RVA: 0x00010E28 File Offset: 0x0000F028
		internal void AddToDock(double height = 50.0, double width = 50.0)
		{
			if (width > 68.0)
			{
				this.mMainGrid.ColumnDefinitions[3].Width = new GridLength(width - 68.0);
			}
			else
			{
				this.mMainGrid.ColumnDefinitions[2].Width = new GridLength(width);
			}
			if (height < 68.0)
			{
				this.mMainGrid.RowDefinitions[1].Height = new GridLength(height);
			}
			GridLength width2 = new GridLength(0.0);
			this.mMainGrid.ColumnDefinitions[1].Width = width2;
			this.mMainGrid.ColumnDefinitions[4].Width = width2;
			base.Margin = new Thickness(0.0, 43.0 - height, 0.0, 0.0);
			this.mAppImage.Height = height;
			this.mAppImage.Width = width;
			RectangleGeometry clip = new RectangleGeometry(new Rect(new Point(0.0, 0.0), new Point(width, height)), 10.0, 10.0);
			this.mAppImage.Clip = clip;
			this.AppNameTextBox.Visibility = Visibility.Collapsed;
			this.mIsAppRemovable = false;
			base.ToolTip = null;
			this.IsDockLocation = true;
		}

		// Token: 0x060001FA RID: 506 RVA: 0x00010F9C File Offset: 0x0000F19C
		internal void AddToMoreAppsDock(double height = 55.0, double width = 55.0)
		{
			if (width > 68.0)
			{
				this.mMainGrid.ColumnDefinitions[3].Width = new GridLength(width - 68.0);
			}
			else
			{
				this.mMainGrid.ColumnDefinitions[2].Width = new GridLength(width);
			}
			if (height < 68.0)
			{
				this.mMainGrid.RowDefinitions[1].Height = new GridLength(height);
			}
			GridLength gridLength = new GridLength(0.0);
			this.mMainGrid.ColumnDefinitions[1].Width = gridLength;
			this.mMainGrid.ColumnDefinitions[4].Width = gridLength;
			this.mMainGrid.RowDefinitions[3].Height = gridLength;
			this.mMainGrid.RowDefinitions[5].Height = gridLength;
			base.Margin = new Thickness(0.0, 43.0 - height, 0.0, 0.0);
			this.mAppImage.Height = height;
			this.mAppImage.Width = width;
			RectangleGeometry clip = new RectangleGeometry(new Rect(new Point(0.0, 0.0), new Point(width, height)), 10.0, 10.0);
			this.mAppImage.Clip = clip;
			this.AppNameTextBox.Visibility = Visibility.Collapsed;
			this.mIsAppRemovable = false;
			base.ToolTip = null;
			this.IsDockLocation = true;
		}

		// Token: 0x060001FB RID: 507 RVA: 0x000034D4 File Offset: 0x000016D4
		internal void Init(AppInfo item)
		{
			this.Init(item.package, item.name);
			this.mAppInfoItem = item;
			this.mActivityName = item.activity;
			if (item.gl3required)
			{
				this.IsGl3App = true;
			}
		}

		// Token: 0x060001FC RID: 508 RVA: 0x0000350A File Offset: 0x0000170A
		internal void InitRerollIcon(string package, string appname)
		{
			this.Init(package, appname);
			this.IsRerollIcon = true;
		}

		// Token: 0x060001FD RID: 509 RVA: 0x0000351B File Offset: 0x0000171B
		internal void Init(string package, string appName, string apkUrl, DownloadInstallApk downloader)
		{
			this.Init(package, appName);
			this.ApkUrl = apkUrl;
			this.mDownloader = downloader;
		}

		// Token: 0x060001FE RID: 510 RVA: 0x00011140 File Offset: 0x0000F340
		internal void Init(AppSuggestionPromotion appSuggestionInfo)
		{
			this.AppSuggestionInfo = appSuggestionInfo;
			this.AppName = appSuggestionInfo.AppName;
			this.mActivityName = appSuggestionInfo.AppActivity;
			this.IsAppSuggestionActive = true;
			if (string.IsNullOrEmpty(this.AppSuggestionInfo.ToolTip))
			{
				base.ToolTip = this.AppName;
			}
			else
			{
				base.ToolTip = null;
			}
			this.AppNameTextBox.TextWrapping = TextWrapping.Wrap;
			this.AppNameTextBox.TextTrimming = TextTrimming.CharacterEllipsis;
			if (this.AppSuggestionInfo.ExtraPayload.ContainsKey("click_generic_action") && (EnumHelper.Parse<GenericAction>(this.AppSuggestionInfo.ExtraPayload["click_generic_action"], GenericAction.None) & (GenericAction)448) != (GenericAction)0)
			{
				this.mIsAppRemovable = false;
				this.AppNameTextBox.TextWrapping = TextWrapping.NoWrap;
				this.AppNameTextBox.TextTrimming = TextTrimming.None;
			}
			BlueStacksUIBinding.ClearBind(this, FrameworkElement.ToolTipProperty);
			this.mIsAppInstalled = false;
			this.mPromotionId = this.AppSuggestionInfo.AppIconId;
			if (this.AppSuggestionInfo.AppIcon.EndsWith(".gif"))
			{
				this.IsGifIcon = true;
			}
			this.ImageName = this.AppSuggestionInfo.AppIconPath;
			if (this.AppSuggestionInfo.IsIconBorder)
			{
				this.mSuggestedAppPromotionImage.ImageName = System.IO.Path.Combine(RegistryStrings.PromotionDirectory, string.Format("{0}{1}.png", this.AppSuggestionInfo.IconBorderId, "app_suggestion_icon_border"));
				this.mSuggestedAppPromotionImage.Visibility = Visibility.Visible;
				this.mSuggestedAppPromotionImage.Clip = null;
			}
		}

		// Token: 0x060001FF RID: 511 RVA: 0x000112B8 File Offset: 0x0000F4B8
		internal void AddPromotionBorderInstalledApp(AppSuggestionPromotion appSuggestionInfo)
		{
			this.AppSuggestionInfo = appSuggestionInfo;
			BlueStacksUIBinding.ClearBind(this, FrameworkElement.ToolTipProperty);
			if (this.AppSuggestionInfo.IsIconBorder)
			{
				this.mSuggestedAppPromotionImage.ImageName = this.AppSuggestionInfo.IconBorderId + "app_suggestion_icon_border";
				this.mSuggestedAppPromotionImage.Visibility = Visibility.Visible;
				this.mSuggestedAppPromotionImage.Clip = null;
			}
		}

		// Token: 0x06000200 RID: 512 RVA: 0x00003534 File Offset: 0x00001734
		internal void RemovePromotionBorderInstalledApp()
		{
			this.mIsAppSuggestionActive = false;
			this.mSuggestedAppPromotionImage.ImageName = "";
			this.mSuggestedAppPromotionImage.Visibility = Visibility.Collapsed;
			this.mSuggestedAppPromotionImage.Clip = null;
		}

		// Token: 0x06000201 RID: 513 RVA: 0x0001131C File Offset: 0x0000F51C
		private void LoadDownloadAppIcon()
		{
			if (!string.IsNullOrEmpty(this.PackageName) && !this.IsAppSuggestionActive)
			{
				string path = Regex.Replace(this.PackageName + ".png", "[\\x22\\\\\\/:*?|<>]", " ");
				string filePath = System.IO.Path.Combine(RegistryStrings.GadgetDir, path);
				if (File.Exists(filePath))
				{
					this.ImageName = filePath;
					return;
				}
				if (!AppHandler.sListIgnoredApps.Contains(this.PackageName, StringComparer.InvariantCultureIgnoreCase))
				{
					Action <>9__1;
					ThreadPool.QueueUserWorkItem(delegate(object obj)
					{
						filePath = DownloadInstallApk.DownloadIcon(this.PackageName);
						Dispatcher dispatcher = this.Dispatcher;
						Action method;
						if ((method = <>9__1) == null)
						{
							method = (<>9__1 = delegate()
							{
								if (string.IsNullOrEmpty(filePath) || !File.Exists(filePath))
								{
									if (this.mAppInfoItem != null && !string.IsNullOrEmpty(this.mAppInfoItem.img))
									{
										filePath = System.IO.Path.Combine(RegistryStrings.GadgetDir, this.mAppInfoItem.img);
										if (File.Exists(filePath))
										{
											this.ImageName = filePath;
											return;
										}
									}
								}
								else if (File.Exists(filePath))
								{
									this.ImageName = filePath;
								}
							});
						}
						dispatcher.Invoke(method, new object[0]);
					});
				}
			}
		}

		// Token: 0x06000202 RID: 514 RVA: 0x000113C8 File Offset: 0x0000F5C8
		private void Button_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			if (this.threadShowingUninstallButton == null)
			{
				this.threadShowingUninstallButton = new Thread(delegate()
				{
					Thread.Sleep(1000);
					if (this.threadShowingUninstallButton != null)
					{
						this.Dispatcher.Invoke(new Action(delegate()
						{
							(sender as UIElement).ReleaseMouseCapture();
							this.ShowUninstallButtons();
							this.threadShowingUninstallButton = null;
						}), new object[0]);
					}
				})
				{
					IsBackground = true
				};
				this.threadShowingUninstallButton.Start();
			}
		}

		// Token: 0x06000203 RID: 515 RVA: 0x00003565 File Offset: 0x00001765
		private void Button_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.threadShowingUninstallButton != null && this.threadShowingUninstallButton.IsAlive)
			{
				this.threadShowingUninstallButton = null;
			}
		}

		// Token: 0x06000204 RID: 516 RVA: 0x00003583 File Offset: 0x00001783
		private void Button_MouseHoldAction(object sender, EventArgs e)
		{
			this.ShowAppUninstallButton(true);
		}

		// Token: 0x06000205 RID: 517 RVA: 0x0000358C File Offset: 0x0000178C
		private void AppIcon_HideUninstallButton(object sender, EventArgs e)
		{
			this.ShowAppUninstallButton(false);
		}

		// Token: 0x06000206 RID: 518 RVA: 0x00003595 File Offset: 0x00001795
		private void ShowAppUninstallButton(bool isShow)
		{
			if (isShow)
			{
				if (this.mIsAppRemovable && (!this.mIsInstalling || this.mIsInstallingFailed))
				{
					this.mUnInstallTabButton.Visibility = Visibility.Visible;
					return;
				}
			}
			else
			{
				this.mUnInstallTabButton.Visibility = Visibility.Hidden;
			}
		}

		// Token: 0x06000207 RID: 519 RVA: 0x0001141C File Offset: 0x0000F61C
		private void Button_Click(object sender, RoutedEventArgs e)
		{
			Logger.Info("Clicked app icon, package name {0}", new object[]
			{
				this.PackageName
			});
			if (this.mUnInstallTabButton.IsMouseOver)
			{
				this.UninstallButtonClicked();
				return;
			}
			if (this.mErrorGrid.IsVisible)
			{
				this.mErrorGrid.Visibility = Visibility.Hidden;
				if (this.mIsDownLoadingFailed)
				{
					this.mDownloader.DownloadApk(this.ApkUrl, this.PackageName, false, false, "");
					return;
				}
				if (this.mIsInstallingFailed)
				{
					this.mDownloader.InstallApk(this.PackageName, this.mApkFilePath, false, false, "");
					return;
				}
			}
			else if (!this.mIsDownloading)
			{
				if (this.mIsInstalling)
				{
					if (this.mDownloader == null)
					{
						this.ParentWindow.mWelcomeTab.mFrontendPopupControl.Init(this.PackageName, this.AppName, PlayStoreAction.OpenApp, false);
						return;
					}
				}
				else
				{
					if (this.IsRerollIcon)
					{
						this.HandleRerollClick();
						return;
					}
					if (this.IsAppSuggestionActive)
					{
						this.HandleAppSuggestionClick();
						if (this.mRedDotNotifIcon.Visibility == Visibility.Visible)
						{
							this.mRedDotNotifIcon.Visibility = Visibility.Hidden;
							this.ParentWindow.mWelcomeTab.mHomeApp.AddPackageInRedDotShownRegistry(this.PackageName);
							return;
						}
					}
					else
					{
						if (this.IsAppIncompat)
						{
							this.HandleCompatibility();
							return;
						}
						if (!string.IsNullOrEmpty(this.PackageName))
						{
							if (this.PackageName.Equals("help_center"))
							{
								this.ParentWindow.mTopBar.mAppTabButtons.AddWebTab(this.ParentWindow.Utils.GetHelpCenterUrl(), "STRING_FEEDBACK", "help_center", true, "STRING_FEEDBACK", false);
								return;
							}
							if (this.PackageName.Equals("instance_manager"))
							{
								BlueStacksUIUtils.LaunchMultiInstanceManager();
								return;
							}
							if (this.PackageName.Equals("macro_recorder"))
							{
								this.ParentWindow.mCommonHandler.OpenOperationRecorderWindow();
								return;
							}
							this.OpenApp();
						}
					}
				}
			}
		}

		// Token: 0x06000208 RID: 520 RVA: 0x000035CB File Offset: 0x000017CB
		private void HandleAppSuggestionClick()
		{
			this.ParentWindow.Utils.HandleGenericActionFromDictionary(this.AppSuggestionInfo.ExtraPayload, "my_apps", this.ImageName);
			this.SendAppSuggestionIconClickStats();
		}

		// Token: 0x06000209 RID: 521 RVA: 0x00011600 File Offset: 0x0000F800
		internal void OpenApp()
		{
			this.ParentWindow.mTopBar.mAppTabButtons.AddAppTab(this.AppName, this.PackageName, this.ActivityName, this.ImageName, false, true, this.PackageName, false);
			this.ParentWindow.mAppHandler.SwitchWhenPackageNameRecieved = this.PackageName;
			this.ParentWindow.mAppHandler.SendRunAppRequestAsync(this.PackageName, "", false);
			if (this.mRedDotNotifIcon.Visibility == Visibility.Visible)
			{
				this.mRedDotNotifIcon.Visibility = Visibility.Hidden;
				this.ParentWindow.mWelcomeTab.mHomeApp.AddPackageInRedDotShownRegistry(this.PackageName);
			}
			this.SendStats();
		}

		// Token: 0x0600020A RID: 522 RVA: 0x000116B0 File Offset: 0x0000F8B0
		private void SendStats()
		{
			if (this.PackageName == "com.android.vending")
			{
				ClientStats.SendGPlayClickStats(new Dictionary<string, string>
				{
					{
						"source",
						"bs3_myapps"
					}
				});
			}
			ClientStats.SendClientStatsAsync("init", "success", "app_activity", this.PackageName, "", "");
		}

		// Token: 0x0600020B RID: 523 RVA: 0x00011710 File Offset: 0x0000F910
		private void HandleRerollClick()
		{
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.AddButton(ButtonColors.Blue, "STRING_YES", new EventHandler(this.StartRerollAccepted), null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_NO", null, null, false, null);
			BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_START_REROLL", "");
			this.ParentWindow.ShowDimOverlay(null);
			customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
			customMessageWindow.ShowDialog();
			if (customMessageWindow.ClickedButton != ButtonColors.White)
			{
				this.ParentWindow.HideDimOverlay();
			}
		}

		// Token: 0x0600020C RID: 524 RVA: 0x0001179C File Offset: 0x0000F99C
		private void StartRerollAccepted(object sender, EventArgs e)
		{
			this.ParentWindow.ShowRerollOverlay();
			this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("startReroll", new Dictionary<string, string>
			{
				{
					"packageName",
					this.PackageName
				},
				{
					"rerollName",
					""
				}
			});
		}

		// Token: 0x0600020D RID: 525 RVA: 0x000117F0 File Offset: 0x0000F9F0
		internal void RefreshGrmIndication(List<AppRequirement> appRequirements)
		{
			try
			{
				if (this.IsAppIncompat && (from _ in appRequirements
				where string.Compare(_.PackageName, this.PackageName, true) == 0
				select _).Count<AppRequirement>() == 0)
				{
					this.RemoveAppCompatError();
				}
				AppRequirement appRequirement = (from _ in appRequirements
				where string.Compare(_.PackageName, this.PackageName, true) == 0
				select _).FirstOrDefault<AppRequirement>();
				if (appRequirement == null)
				{
					appRequirement = (from _ in appRequirements
					where _.PackageName.EndsWith("*") && this.PackageName.StartsWith(_.PackageName.Trim(new char[]
					{
						'*'
					}))
					select _).FirstOrDefault<AppRequirement>();
				}
				if (appRequirement != null)
				{
					GrmRuleSet grmRuleSet = appRequirement.EvaluateRequirement(this.PackageName, this.ParentWindow.mVmName);
					if (grmRuleSet != null)
					{
						this.AddGRMIndicationForIncompatibleApp(grmRuleSet, appRequirement);
					}
					else
					{
						this.RemoveAppCompatError();
					}
				}
			}
			catch (Exception arg)
			{
				Logger.Error("Exception in RefreshGrmIndication. Exception: " + arg);
			}
		}

		// Token: 0x0600020E RID: 526 RVA: 0x000118AC File Offset: 0x0000FAAC
		internal void AddGRMIndicationForIncompatibleApp(GrmRuleSet passedRuleSet, AppRequirement req)
		{
			switch (EnumHelper.Parse<MessageType>(passedRuleSet.MessageWindow.MessageType, MessageType.None))
			{
			case MessageType.None:
				this.IsAppIncompat = false;
				this.mGl3ErrorIcon.Visibility = Visibility.Hidden;
				this.mGl3InfoIcon.Visibility = Visibility.Hidden;
				break;
			case MessageType.Info:
				this.IsAppIncompat = true;
				this.mGl3ErrorIcon.Visibility = Visibility.Hidden;
				this.mGl3InfoIcon.Visibility = Visibility.Visible;
				break;
			case MessageType.Error:
				this.IsAppIncompat = true;
				this.mGl3ErrorIcon.Visibility = Visibility.Visible;
				this.mGl3InfoIcon.Visibility = Visibility.Hidden;
				break;
			}
			this.Requirements = req;
			this.PassedRuleSet = passedRuleSet;
		}

		// Token: 0x0600020F RID: 527 RVA: 0x000035F9 File Offset: 0x000017F9
		internal void RemoveAppCompatError()
		{
			this.IsAppIncompat = false;
			this.mGl3ErrorIcon.Visibility = Visibility.Hidden;
			this.mGl3InfoIcon.Visibility = Visibility.Hidden;
		}

		// Token: 0x06000210 RID: 528 RVA: 0x00011950 File Offset: 0x0000FB50
		private void PerformGrmActions(List<GrmAction> actions)
		{
			BackgroundWorker backgroundWorker = new BackgroundWorker();
			backgroundWorker.DoWork += delegate(object obj, DoWorkEventArgs e)
			{
				this.PerformGrmActionsWorker_DoWork(obj, e, actions);
			};
			backgroundWorker.RunWorkerCompleted += delegate(object obj, RunWorkerCompletedEventArgs e)
			{
				this.PerformGrmActionsWorker_RunWorkerCompleted(obj, e);
			};
			backgroundWorker.RunWorkerAsync();
		}

		// Token: 0x06000211 RID: 529 RVA: 0x000119A0 File Offset: 0x0000FBA0
		private void PerformGrmActionsWorker_DoWork(object obj, DoWorkEventArgs e, List<GrmAction> actions)
		{
			try
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					this.ParentWindow.mFrontendGrid.Visibility = Visibility.Hidden;
					this.ParentWindow.mExitProgressGrid.ProgressText = LocaleStrings.GetLocalizedString("STRING_PERFORMING_ACTIONS", false);
					this.ParentWindow.mExitProgressGrid.Visibility = Visibility.Visible;
				}), new object[0]);
				try
				{
					ClientStats.SendMiscellaneousStatsAsync("grm_action_clicked", RegistryManager.Instance.UserGuid, string.Join(",", (from _ in actions
					select _.ActionType.ToString()).ToArray<string>()), RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, "bgp", this.mPackageName, null, null);
				}
				catch (Exception arg)
				{
					Logger.Error("Exception while sending misc stat for grm. " + arg);
				}
				e.Result = false;
				foreach (GrmAction grmAction in actions)
				{
					GrmActionType grmActionType = EnumHelper.Parse<GrmActionType>(grmAction.ActionType, GrmActionType.NoAction);
					bool? flag = new bool?(false);
					switch (grmActionType)
					{
					case GrmActionType.UpdateRam:
					{
						int num = int.Parse(grmAction.ActionDictionary["actionValue"]);
						int num2 = 4096;
						int num3;
						if (int.TryParse(EngineSettingsBase.RAM, out num3))
						{
							num2 = (int)((double)num3 * 0.5);
						}
						if (RegistryManager.Instance.CurrentEngine == EngineState.raw.ToString() && num2 >= 3072)
						{
							num2 = 3072;
						}
						if (num2 < num)
						{
							num = num2;
						}
						RegistryManager.Instance.Guest[this.ParentWindow.mVmName].Memory = num;
						flag = new bool?(true);
						break;
					}
					case GrmActionType.UserBrowser:
						this.ParentWindow.Utils.HandleGenericActionFromDictionary(grmAction.ActionDictionary, "grm", "");
						flag = new bool?(false);
						break;
					case GrmActionType.DownloadFileAndExecute:
					{
						Random random = new Random();
						string text = grmAction.ActionDictionary["fileName"];
						text += " ";
						string text2 = text.Substring(0, text.IndexOf(' '));
						string text3 = text.Substring(text.IndexOf(' ') + 1);
						text2 = string.Format("{0}_{1}", random.Next(), text2);
						text2 = System.IO.Path.Combine(RegistryStrings.PromotionDirectory, text2);
						try
						{
							new WebClient().DownloadFile(grmAction.ActionDictionary["url"], text2);
							Thread.Sleep(2000);
							Process process = new Process();
							process.StartInfo.UseShellExecute = true;
							process.StartInfo.CreateNoWindow = true;
							if ((text2.ToLowerInvariant().EndsWith(".msi") || text2.ToLowerInvariant().EndsWith(".exe")) && !BlueStacksUtils.IsSignedByBlueStacks(text2))
							{
								Logger.Info("Not executing unsigned binary " + text2);
								this.GrmExceptionMessageBox();
								return;
							}
							if (text2.ToLowerInvariant().EndsWith(".msi"))
							{
								process.StartInfo.FileName = "msiexec";
								text3 = string.Format("/i {0} {1}", text2, text3);
								process.StartInfo.Arguments = text3;
							}
							else
							{
								process.StartInfo.FileName = text2;
								process.StartInfo.Arguments = text3;
							}
							Logger.Info("Starting process: {0} {1}", new object[]
							{
								process.StartInfo.FileName,
								text3
							});
							process.Start();
						}
						catch (Exception arg2)
						{
							this.GrmExceptionMessageBox();
							Logger.Error("Failed to download and execute. err: " + arg2);
						}
						flag = new bool?(false);
						break;
					}
					case GrmActionType.NoAction:
						flag = new bool?(false);
						break;
					case GrmActionType.ContinueAnyway:
						base.Dispatcher.Invoke(new Action(delegate()
						{
							this.ParentWindow.mFrontendGrid.Visibility = Visibility.Visible;
							this.ParentWindow.mExitProgressGrid.Visibility = Visibility.Hidden;
							if (this.PassedRuleSet.MessageWindow.DontShowOption)
							{
								this.DonotShowCheckboxHandling();
								this.RefreshGrmIndication(AppRequirementsParser.Instance.Requirements);
							}
							this.OpenApp();
						}), new object[0]);
						flag = null;
						break;
					case GrmActionType.GlMode:
					{
						string text4 = grmAction.ActionDictionary["actionValue"];
						int glRenderMode = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GlRenderMode;
						int glMode = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GlMode;
						GlMode glMode2 = GlMode.PGA_GL;
						if (glRenderMode == 1 && glMode == 1)
						{
							glMode2 = GlMode.PGA_GL;
						}
						else if (glRenderMode == 1 && glMode == 2)
						{
							glMode2 = GlMode.AGA_GL;
						}
						else if (glMode == 1)
						{
							glMode2 = GlMode.PGA_DX;
						}
						else if (glMode == 2)
						{
							glMode2 = GlMode.AGA_DX;
						}
						List<string> list = (from _ in text4.Split(new char[]
						{
							','
						})
						select _.Trim()).ToList<string>();
						if (list.Contains(glMode2.ToString(), StringComparer.InvariantCultureIgnoreCase))
						{
							flag = new bool?(false);
						}
						else
						{
							text4 = list.RandomElement<string>();
							string text5 = "";
							int glRenderMode2;
							if (string.Compare(text4.Split(new char[]
							{
								'_'
							})[1].Trim(), "GL", true) == 0)
							{
								glRenderMode2 = 1;
								text5 += "1";
							}
							else
							{
								glRenderMode2 = 4;
								text5 += "4";
							}
							int glMode3;
							if (string.Compare(text4.Split(new char[]
							{
								'_'
							})[0].Trim(), "PGA", true) == 0)
							{
								glMode3 = 1;
								text5 += "1";
							}
							else
							{
								glMode3 = 2;
								text5 += "2";
							}
							if (RunCommand.RunCmd(System.IO.Path.Combine(RegistryStrings.InstallDir, "HD-GlCheck"), text5, true, true, false, 0).ExitCode == 0)
							{
								RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GlRenderMode = glRenderMode2;
								Utils.UpdateValueInBootParams("GlMode", glMode3.ToString(), this.ParentWindow.mVmName, true);
								RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GlMode = glMode3;
							}
							else
							{
								this.GrmExceptionMessageBox();
								Logger.Info("GL check execution for the required combination failed.");
							}
							flag = new bool?(true);
						}
						break;
					}
					case GrmActionType.DeviceProfile:
					{
						string text6 = grmAction.ActionDictionary["pCode"];
						string text7 = string.Empty;
						if (string.Compare(text6, "custom", true) == 0)
						{
							text7 = "{";
							text7 += string.Format("\"createcustomprofile\":\"{0}\",", "true");
							text7 += string.Format("\"model\":\"{0}\",", grmAction.ActionDictionary["model"]);
							text7 += string.Format("\"brand\":\"{0}\",", grmAction.ActionDictionary["brand"]);
							text7 += string.Format("\"manufacturer\":\"{0}\"", grmAction.ActionDictionary["manufacturer"]);
							text7 += "}";
						}
						else
						{
							List<string> list2 = (from _ in text6.Split(new char[]
							{
								','
							})
							select _.Trim()).ToList<string>();
							string valueInBootParams = Utils.GetValueInBootParams("pcode", this.ParentWindow.mVmName, "");
							if (list2.Contains(valueInBootParams))
							{
								break;
							}
							text6 = list2.RandomElement<string>();
							text7 = "{";
							text7 += string.Format("\"createcustomprofile\":\"{0}\",", "false");
							text7 += string.Format("\"pcode\":\"{0}\"", text6);
							text7 += "}";
						}
						if (string.Equals(VmCmdHandler.RunCommand(string.Format("{0} {1}", "changePCode", text7), this.ParentWindow.mVmName), "ok"))
						{
							Utils.UpdateValueInBootParams("pcode", text6, this.ParentWindow.mVmName, false);
							if (PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.Contains(this.mPackageName))
							{
								HTTPUtils.SendRequestToAgentAsync("clearAppData", new Dictionary<string, string>
								{
									{
										"package",
										this.mPackageName
									}
								}, this.ParentWindow.mVmName, 0, null, false, 1, 0);
							}
						}
						else
						{
							this.GrmExceptionMessageBox();
							Logger.Error("Setting device profile for the required combination failed.");
						}
						flag = new bool?(false);
						break;
					}
					case GrmActionType.BootParam:
					{
						string name = grmAction.ActionDictionary["param"].Trim();
						string value = grmAction.ActionDictionary["actionValue"].Trim();
						Utils.UpdateValueInBootParams(name, value, this.ParentWindow.mVmName, true);
						flag = new bool?(true);
						break;
					}
					case GrmActionType.DPI:
					{
						string updatedValue = grmAction.ActionDictionary["actionValue"];
						Utils.SetDPIInBootParameters(RegistryManager.Instance.Guest[this.ParentWindow.mVmName].BootParameters, updatedValue, this.ParentWindow.mVmName);
						flag = new bool?(true);
						break;
					}
					case GrmActionType.CpuCores:
					{
						int num4 = int.Parse(grmAction.ActionDictionary["actionValue"]);
						if (RegistryManager.Instance.CurrentEngine != EngineState.raw.ToString())
						{
							RegistryManager.Instance.Guest[this.ParentWindow.mVmName].VCPUs = ((num4 > 8) ? 8 : num4);
						}
						flag = new bool?(true);
						break;
					}
					case GrmActionType.Resolution:
					{
						string text8 = grmAction.ActionDictionary["actionValue"];
						List<string> list3 = (from _ in text8.Split(new char[]
						{
							','
						})
						select _.Replace(" ", string.Empty)).ToList<string>();
						int guestWidth = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GuestWidth;
						int guestHeight = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GuestHeight;
						string value2 = guestWidth.ToString() + "x" + guestHeight.ToString();
						if (!list3.Contains(value2, StringComparer.InvariantCultureIgnoreCase))
						{
							text8 = list3.RandomElement<string>();
							RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GuestWidth = int.Parse(text8.Split(new char[]
							{
								'x'
							})[0].Trim());
							RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GuestHeight = int.Parse(text8.Split(new char[]
							{
								'x'
							})[1].Trim());
							flag = new bool?(true);
						}
						break;
					}
					case GrmActionType.RestartBluestacks:
						flag = new bool?(true);
						break;
					case GrmActionType.RestartMachine:
						Process.Start("shutdown.exe", "-r -t 0");
						break;
					case GrmActionType.Fps:
					{
						int num5 = int.Parse(grmAction.ActionDictionary["actionValue"]);
						RegistryManager.Instance.Guest[this.ParentWindow.mVmName].FPS = num5;
						Utils.UpdateValueInBootParams("fps", num5.ToString(), this.ParentWindow.mVmName, true);
						Utils.SendChangeFPSToInstanceASync(this.ParentWindow.mVmName, num5);
						flag = new bool?(false);
						break;
					}
					case GrmActionType.EditRegistry:
					{
						string strA = grmAction.ActionDictionary["location"];
						if (string.Compare(strA, "registryManager", true) == 0)
						{
							PropertyInfo property = typeof(RegistryManager).GetProperty(grmAction.ActionDictionary["propertyName"]);
							object value3 = Convert.ChangeType(grmAction.ActionDictionary["propertyValue"], Type.GetTypeCode(property.PropertyType));
							property.SetValue(RegistryManager.Instance, value3, null);
						}
						else if (string.Compare(strA, "instanceManager", true) == 0)
						{
							PropertyInfo property2 = typeof(InstanceRegistry).GetProperty(grmAction.ActionDictionary["propertyName"]);
							object value4 = Convert.ChangeType(grmAction.ActionDictionary["propertyValue"], Type.GetTypeCode(property2.PropertyType));
							property2.SetValue(RegistryManager.Instance.Guest[this.ParentWindow.mVmName], value4, null);
						}
						else
						{
							string registryPath = string.Format("Software\\BlueStacks{0}\\{1}", Strings.GetOemTag(), grmAction.ActionDictionary["propertyPath"].Replace("vmName", this.ParentWindow.mVmName));
							object value5 = null;
							RegistryValueKind registryValueKind = EnumHelper.Parse<RegistryValueKind>(grmAction.ActionDictionary["propertyRegistryKind"], RegistryValueKind.String);
							if (registryValueKind != RegistryValueKind.String)
							{
								if (registryValueKind == RegistryValueKind.DWord)
								{
									value5 = int.Parse(grmAction.ActionDictionary["propertyValue"]);
								}
							}
							else
							{
								value5 = grmAction.ActionDictionary["propertyValue"];
							}
							RegistryUtils.SetRegistryValue(registryPath, grmAction.ActionDictionary["propertyName"], value5, registryValueKind, RegistryKeyKind.HKEY_LOCAL_MACHINE);
						}
						flag = new bool?(false);
						break;
					}
					}
					bool? flag2 = flag;
					bool flag3 = true;
					if (flag2.GetValueOrDefault() == flag3 & flag2 != null)
					{
						e.Result = true;
					}
					else if (flag == null)
					{
						e.Result = null;
					}
				}
				Thread.Sleep(1000);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in performing grm actions, ex: " + ex.ToString());
				ClientStats.SendMiscellaneousStatsAsync("grm_action_error", RegistryManager.Instance.UserGuid, this.PassedRuleSet.RuleId, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, "bgp", this.mPackageName, ex.Message, null);
				this.GrmExceptionMessageBox();
				e.Result = null;
			}
		}

		// Token: 0x06000212 RID: 530 RVA: 0x000127A0 File Offset: 0x000109A0
		private void PerformGrmActionsWorker_RunWorkerCompleted(object obj, RunWorkerCompletedEventArgs e)
		{
			if (e.Result == null)
			{
				return;
			}
			if (!(bool)e.Result)
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					this.ParentWindow.mFrontendGrid.Visibility = Visibility.Visible;
					this.ParentWindow.mExitProgressGrid.Visibility = Visibility.Hidden;
				}), new object[0]);
				this.ParentWindow.mWelcomeTab.mHomeApp.RequirementConfigUpdated();
				return;
			}
			BlueStacksUIUtils.RestartInstance(this.ParentWindow.mVmName);
		}

		// Token: 0x06000213 RID: 531 RVA: 0x0000361A File Offset: 0x0000181A
		private void GrmExceptionMessageBox()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.ParentWindow.mFrontendGrid.Visibility = Visibility.Visible;
				this.ParentWindow.mExitProgressGrid.Visibility = Visibility.Hidden;
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_ERROR", false);
				customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_GRM_EXCEPTION_MESSAGE", false);
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
				customMessageWindow.Owner = this.ParentWindow;
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
			}), new object[0]);
		}

		// Token: 0x06000214 RID: 532 RVA: 0x00012808 File Offset: 0x00010A08
		internal void HandleCompatibility()
		{
			try
			{
				this.AppCompatErrorWindow = new CustomMessageWindow();
				this.AppCompatErrorWindow.TitleTextBlock.Text = this.AppName;
				if (!string.IsNullOrEmpty(AppRequirementsParser.Instance.GetLocalizedString(this.PassedRuleSet.MessageWindow.HeaderStringKey)))
				{
					this.AppCompatErrorWindow.BodyTextBlockTitle.Text = AppRequirementsParser.Instance.GetLocalizedString(this.PassedRuleSet.MessageWindow.HeaderStringKey);
					this.AppCompatErrorWindow.BodyTextBlockTitle.Visibility = Visibility.Visible;
				}
				this.AppCompatErrorWindow.BodyTextBlock.Text = AppRequirementsParser.Instance.GetLocalizedString(this.PassedRuleSet.MessageWindow.MessageStringKey);
				if (this.PassedRuleSet.MessageWindow.MessageType == MessageType.Info.ToString())
				{
					this.AppCompatErrorWindow.MessageIcon.ImageName = "message_info";
				}
				else if (this.PassedRuleSet.MessageWindow.MessageType == MessageType.Error.ToString())
				{
					this.AppCompatErrorWindow.MessageIcon.ImageName = "message_error";
				}
				this.AppCompatErrorWindow.MessageIcon.Visibility = Visibility.Visible;
				if (this.PassedRuleSet.MessageWindow.DontShowOption)
				{
					this.AppCompatErrorWindow.CheckBox.Content = LocaleStrings.GetLocalizedString("STRING_DOWNLOAD_GOOGLE_APP_POPUP_STRING_04", false);
					this.AppCompatErrorWindow.CheckBox.Visibility = Visibility.Visible;
				}
				using (List<GrmMessageButton>.Enumerator enumerator = this.PassedRuleSet.MessageWindow.Buttons.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						GrmMessageButton button = enumerator.Current;
						ButtonColors color = EnumHelper.Parse<ButtonColors>(button.ButtonColor, ButtonColors.Blue);
						this.AppCompatErrorWindow.AddButton(color, AppRequirementsParser.Instance.GetLocalizedString(button.ButtonStringKey), delegate(object o, EventArgs e)
						{
							this.PerformGrmActions(button.Actions);
						}, null, false, null);
					}
				}
				this.AppCompatErrorWindow.Owner = this.ParentWindow;
				this.ParentWindow.ShowDimOverlay(null);
				this.AppCompatErrorWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while showing appcompat message to user. Exception: " + ex.ToString());
				this.OpenApp();
			}
		}

		// Token: 0x06000215 RID: 533 RVA: 0x00012A9C File Offset: 0x00010C9C
		private void DonotShowCheckboxHandling()
		{
			bool? isChecked = this.AppCompatErrorWindow.CheckBox.IsChecked;
			bool flag = true;
			if (isChecked.GetValueOrDefault() == flag & isChecked != null)
			{
				List<string> list = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GrmDonotShowRuleList.ToList<string>();
				if (!list.Contains(this.PassedRuleSet.RuleId))
				{
					list.Add(this.PassedRuleSet.RuleId);
				}
				RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GrmDonotShowRuleList = list.ToArray();
			}
		}

		// Token: 0x06000216 RID: 534 RVA: 0x00012B40 File Offset: 0x00010D40
		private void SendAppSuggestionIconClickStats()
		{
			ClientStats.SendPromotionAppClickStatsAsync(new Dictionary<string, string>
			{
				{
					"op",
					"init"
				},
				{
					"status",
					"success"
				},
				{
					"app_pkg",
					this.PackageName
				},
				{
					"extraPayload",
					JsonConvert.SerializeObject(this.AppSuggestionInfo.ExtraPayload)
				},
				{
					"app_name",
					this.AppName
				},
				{
					"app_promotion_id",
					this.mPromotionId
				},
				{
					"promotion_type",
					"cross_promotion"
				}
			}, "app_activity");
		}

		// Token: 0x06000217 RID: 535 RVA: 0x00012BDC File Offset: 0x00010DDC
		private void UninstallButtonClicked()
		{
			try
			{
				if (this.mIsDownloading)
				{
					if (this.mDownloader != null)
					{
						this.mDownloader.AbortApkDownload(this.PackageName);
						this.ParentWindow.mWelcomeTab.mHomeApp.RemoveAppIcon(this.PackageName);
					}
				}
				else if (this.mIsInstalling)
				{
					if (this.mIsInstallingFailed)
					{
						this.ParentWindow.mWelcomeTab.mHomeApp.RemoveAppIcon(this.PackageName);
					}
				}
				else if (this.mIsAppSuggestionActive)
				{
					CustomMessageWindow customMessageWindow = new CustomMessageWindow();
					customMessageWindow.AddButton(ButtonColors.Red, LocaleStrings.GetLocalizedString("STRING_YES", false), new EventHandler(this.RemoveAppSuggestion), null, false, null);
					customMessageWindow.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_NO", false), null, null, false, null);
					customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_ICON_REMOVE", false);
					customMessageWindow.Owner = this.ParentWindow;
					this.ParentWindow.ShowDimOverlay(null);
					customMessageWindow.ShowDialog();
					this.ParentWindow.HideDimOverlay();
				}
				else
				{
					CustomMessageWindow customMessageWindow2 = new CustomMessageWindow();
					customMessageWindow2.AddButton(ButtonColors.Red, "STRING_YES", this.UninstallConfirmationClicked, null, false, null);
					customMessageWindow2.AddButton(ButtonColors.White, "STRING_NO", null, null, false, null);
					BlueStacksUIBinding.Bind(customMessageWindow2.BodyTextBlock, "STRING_UNINSTALL_APP_ASK", "");
					this.ParentWindow.ShowDimOverlay(null);
					customMessageWindow2.Owner = this.ParentWindow.mDimOverlay;
					customMessageWindow2.ShowDialog();
					this.ParentWindow.HideDimOverlay();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in UninstallButtonClicked. Err : " + ex.ToString());
			}
		}

		// Token: 0x06000218 RID: 536 RVA: 0x00012D88 File Offset: 0x00010F88
		private void RemoveAppSuggestion(object sender, EventArgs e)
		{
			this.ParentWindow.mWelcomeTab.mHomeApp.RemoveAppIcon(this.PackageName);
			ClientStats.SendMiscellaneousStatsAsync("cross_promotion_icon_removed", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, this.mPackageName, "bgp", null, null, null);
			try
			{
				XmlWriterSettings settings = new XmlWriterSettings
				{
					OmitXmlDeclaration = true,
					Indent = true
				};
				XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces(new XmlQualifiedName[]
				{
					new XmlQualifiedName("", "")
				});
				string text = System.IO.Path.Combine(RegistryStrings.PromotionDirectory, "app_suggestion_removed");
				string text2 = "";
				if (File.Exists(text))
				{
					text2 = File.ReadAllText(text);
				}
				List<string> list = new List<string>();
				if (!string.IsNullOrEmpty(text2))
				{
					list = AppIcon.DoDeserialize<List<string>>(text2);
				}
				if (!list.Contains(this.PackageName))
				{
					if (list.Count >= 20)
					{
						list.RemoveAt(0);
					}
					list.Add(this.PackageName);
				}
				using (XmlWriter xmlWriter = XmlWriter.Create(text, settings))
				{
					new XmlSerializer(typeof(List<string>)).Serialize(xmlWriter, list, namespaces);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in writing removed suggested app icon package name in file " + ex.ToString());
			}
		}

		// Token: 0x06000219 RID: 537 RVA: 0x00012EEC File Offset: 0x000110EC
		private static T DoDeserialize<T>(string data) where T : class
		{
			T result;
			using (MemoryStream memoryStream = new MemoryStream(Encoding.UTF8.GetBytes(data)))
			{
				result = (T)((object)new XmlSerializer(typeof(T)).Deserialize(memoryStream));
			}
			return result;
		}

		// Token: 0x0600021A RID: 538 RVA: 0x00012F44 File Offset: 0x00011144
		private void AppIcon_UninstallConfirmationClicked(object sender, EventArgs e)
		{
			Logger.Info("Clicked app icon uninstall popup package name {0}", new object[]
			{
				this.PackageName
			});
			this.ParentWindow.mAppInstaller.UninstallApp(this.PackageName);
			this.ParentWindow.mWelcomeTab.mHomeApp.RemoveAppIcon(this.PackageName);
		}

		// Token: 0x0600021B RID: 539 RVA: 0x0000363A File Offset: 0x0000183A
		internal void HideUninstallButtons()
		{
			this.ParentWindow.StaticComponents.ShowUninstallButtons(false);
		}

		// Token: 0x0600021C RID: 540 RVA: 0x0000364D File Offset: 0x0000184D
		internal void ShowUninstallButtons()
		{
			this.ParentWindow.StaticComponents.ShowUninstallButtons(true);
		}

		// Token: 0x0600021D RID: 541 RVA: 0x00012F9C File Offset: 0x0001119C
		private void Button_MouseEnter(object sender, MouseEventArgs e)
		{
			if (this.mIsDownloading)
			{
				this.ShowAppUninstallButton(true);
			}
			if (this.mIsDownLoadingFailed || this.mIsInstallingFailed)
			{
				this.mRetryGrid.Visibility = Visibility.Visible;
			}
			if (this.mBusyGrid.Visibility == Visibility.Visible)
			{
				return;
			}
			DropShadowEffect dropShadowEffect = new DropShadowEffect();
			BlueStacksUIBinding.BindColor(dropShadowEffect, DropShadowEffect.ColorProperty, "AppIconDropShadowBrush");
			dropShadowEffect.Direction = 270.0;
			dropShadowEffect.ShadowDepth = 1.0;
			dropShadowEffect.BlurRadius = 20.0;
			dropShadowEffect.Opacity = 1.0;
			this.mAppImageBorder.Effect = dropShadowEffect;
			ScaleTransform renderTransform = new ScaleTransform(1.02, 1.02);
			this.mAppImage.RenderTransformOrigin = new Point(0.5, 0.5);
			this.mAppImage.RenderTransform = renderTransform;
			this.AppNameTextBox.RenderTransformOrigin = new Point(0.5, 0.5);
			this.AppNameTextBox.RenderTransform = renderTransform;
			if (this.IsDockLocation)
			{
				this.ParentWindow.mWelcomeTab.mHomeApp.mDockIconText.Text = this.AppName;
				this.ParentWindow.mWelcomeTab.mHomeApp.mDockAppIconToolTipPopup.PlacementTarget = this.mAppImage;
				this.ParentWindow.mWelcomeTab.mHomeApp.mDockAppIconToolTipPopup.IsOpen = true;
				this.ParentWindow.mWelcomeTab.mHomeApp.mDockAppIconToolTipPopup.StaysOpen = true;
				dropShadowEffect.BlurRadius = 12.0;
				this.mAppImageBorder.Effect = dropShadowEffect;
			}
			if (this.mIsAppSuggestionActive)
			{
				this.ParentWindow.mWelcomeTab.mHomeApp.OpenAppSuggestionPopup(this.AppSuggestionInfo, this.AppNameTextBox, true);
			}
		}

		// Token: 0x0600021E RID: 542 RVA: 0x0001317C File Offset: 0x0001137C
		private void Button_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.ParentWindow.StaticComponents.IsDeleteButtonVisible)
			{
				this.ShowAppUninstallButton(false);
			}
			this.mRetryGrid.Visibility = Visibility.Hidden;
			ScaleTransform renderTransform = new ScaleTransform(1.0, 1.0);
			this.mAppImage.RenderTransformOrigin = new Point(0.0, 0.0);
			this.mAppImage.RenderTransform = renderTransform;
			this.AppNameTextBox.RenderTransformOrigin = new Point(0.0, 0.0);
			this.AppNameTextBox.RenderTransform = renderTransform;
			DropShadowEffect effect = new DropShadowEffect
			{
				Color = Colors.Black,
				Direction = 270.0,
				ShadowDepth = 1.0,
				BlurRadius = 6.0,
				Opacity = 0.3
			};
			this.mAppImageBorder.Effect = effect;
			if (this.mIsAppSuggestionActive)
			{
				this.ParentWindow.mWelcomeTab.mHomeApp.CloseAppSuggestionPopup();
			}
			if (this.IsDockLocation)
			{
				this.ParentWindow.mWelcomeTab.mHomeApp.mDockAppIconToolTipPopup.IsOpen = false;
			}
		}

		// Token: 0x0600021F RID: 543 RVA: 0x000132BC File Offset: 0x000114BC
		internal void DownloadStarted()
		{
			this.mIsAppInstalled = false;
			this.mIsDownLoadingFailed = false;
			this.mIsDownloading = true;
			this.ParentWindow.mTopBar.mAppTabButtons.GoToTab("Home", true, false);
			this.mErrorGrid.Visibility = Visibility.Hidden;
			this.mProgressGrid.Visibility = Visibility.Visible;
		}

		// Token: 0x06000220 RID: 544 RVA: 0x00003660 File Offset: 0x00001860
		internal void DownloadFailed()
		{
			this.mIsDownLoadingFailed = true;
			this.mErrorGrid.Visibility = Visibility.Visible;
		}

		// Token: 0x06000221 RID: 545 RVA: 0x00003675 File Offset: 0x00001875
		internal void UpdateAppDownloadProgress(int percent)
		{
			this.mProgressGrid.Visibility = Visibility.Visible;
			this.CustomProgressBar.Value = (double)percent;
		}

		// Token: 0x06000222 RID: 546 RVA: 0x00003690 File Offset: 0x00001890
		internal void DownloadCompleted(string filePath)
		{
			this.mApkFilePath = filePath;
			this.mIsDownloading = false;
			this.mIsInstalling = true;
			this.mProgressGrid.Visibility = Visibility.Hidden;
			this.mBusyGrid.Visibility = Visibility.Visible;
		}

		// Token: 0x06000223 RID: 547 RVA: 0x000036BF File Offset: 0x000018BF
		internal void ApkInstallStart(string filePath)
		{
			this.ShowAppUninstallButton(false);
			this.mIsAppInstalled = false;
			this.mIsInstalling = true;
			this.mApkFilePath = filePath;
			this.mIsInstallingFailed = false;
			this.mErrorGrid.Visibility = Visibility.Hidden;
			this.mBusyGrid.Visibility = Visibility.Visible;
		}

		// Token: 0x06000224 RID: 548 RVA: 0x000036FC File Offset: 0x000018FC
		internal void ApkInstallFailed()
		{
			if (!this.mIsAppInstalled)
			{
				this.mIsInstallingFailed = true;
				this.mBusyGrid.Visibility = Visibility.Hidden;
				this.mErrorGrid.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x06000225 RID: 549 RVA: 0x00003725 File Offset: 0x00001925
		internal void ApkInstallCompleted()
		{
			this.mIsAppInstalled = true;
			this.mIsInstalling = false;
			this.mDownloader = null;
			this.mBusyGrid.Visibility = Visibility.Hidden;
		}

		// Token: 0x06000226 RID: 550 RVA: 0x00013314 File Offset: 0x00011514
		private void Button_Loaded(object sender, RoutedEventArgs e)
		{
			if (!DesignerProperties.GetIsInDesignMode(this))
			{
				base.Loaded -= this.Button_Loaded;
				this.ParentWindow.StaticComponents.ShowAllUninstallButtons += this.Button_MouseHoldAction;
				this.ParentWindow.StaticComponents.HideAllUninstallButtons += this.AppIcon_HideUninstallButton;
				List<AppRequirement> requirements = AppRequirementsParser.Instance.Requirements;
				if (requirements != null)
				{
					this.RefreshGrmIndication(requirements);
				}
				if (this.IsGamepadCompatible)
				{
					this.mGamepadIcon.ImageName = (this.ParentWindow.IsGamepadConnected ? "apps_connected_icon" : "apps_disconnected_icon");
				}
			}
		}

		// Token: 0x06000227 RID: 551 RVA: 0x000133B8 File Offset: 0x000115B8
		internal void GifAppIconPlay()
		{
			try
			{
				this.mGifController = ImageBehavior.GetAnimationController(this.mAppImage);
				if (this.mGifController != null)
				{
					this.mGifController.Play();
				}
				else if (this.ImageName != null)
				{
					ImageSource value = new BitmapImage(new Uri(this.ImageName));
					ImageBehavior.SetAnimatedSource(this.mAppImage, value);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in animating appicon for package " + this.mPackageName + Environment.NewLine + ex.ToString());
			}
		}

		// Token: 0x06000228 RID: 552 RVA: 0x00013448 File Offset: 0x00011648
		internal void GifAppIconPause()
		{
			try
			{
				this.mGifController = ImageBehavior.GetAnimationController(this.mAppImage);
				this.mGifController.Pause();
			}
			catch (Exception ex)
			{
				Logger.Warning("Failed to pause gif. Err : " + ex.Message);
			}
		}

		// Token: 0x06000229 RID: 553 RVA: 0x0001349C File Offset: 0x0001169C
		private void GamepadIcon_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mIconText.Text = (this.ParentWindow.IsGamepadConnected ? LocaleStrings.GetLocalizedString("STRING_GAMEPAD_CONNECTED", false) : LocaleStrings.GetLocalizedString("STRING_GAMEPAD_DISCONNECTED", false));
			base.ToolTip = null;
			this.mGamePadToolTipPopup.PlacementTarget = this.mGamepadIcon;
			this.mGamePadToolTipPopup.IsOpen = true;
			this.mGamePadToolTipPopup.StaysOpen = true;
		}

		// Token: 0x0600022A RID: 554 RVA: 0x00003748 File Offset: 0x00001948
		private void GamepadIcon_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mGamePadToolTipPopup.IsOpen = false;
			base.ToolTip = this.AppName;
		}

		// Token: 0x040000F8 RID: 248
		private MainWindow mMainWindow;

		// Token: 0x040000F9 RID: 249
		private bool IsRerollIcon;

		// Token: 0x040000FA RID: 250
		private bool mIsInstalledApp = true;

		// Token: 0x040000FB RID: 251
		public bool mIsAppRemovable = true;

		// Token: 0x040000FC RID: 252
		public bool IsGl3App;

		// Token: 0x040000FD RID: 253
		public bool IsAppIncompat;

		// Token: 0x040000FE RID: 254
		private CustomMessageWindow AppCompatErrorWindow;

		// Token: 0x040000FF RID: 255
		private Thread threadShowingUninstallButton;

		// Token: 0x04000100 RID: 256
		internal bool mIsAppInstalled = true;

		// Token: 0x04000101 RID: 257
		private DownloadInstallApk mDownloader;

		// Token: 0x04000102 RID: 258
		private bool mIsDownloading;

		// Token: 0x04000103 RID: 259
		private bool mIsInstalling;

		// Token: 0x04000104 RID: 260
		private bool mIsDownLoadingFailed;

		// Token: 0x04000105 RID: 261
		private bool mIsInstallingFailed;

		// Token: 0x04000106 RID: 262
		private string mApkFilePath = string.Empty;

		// Token: 0x04000107 RID: 263
		private bool mIsAppSuggestionActive;

		// Token: 0x04000108 RID: 264
		private bool mIsDockLocation;

		// Token: 0x04000109 RID: 265
		private bool mIsGifIcon;

		// Token: 0x0400010A RID: 266
		private ImageAnimationController mGifController;

		// Token: 0x0400010C RID: 268
		private AppRequirement mRequirements;

		// Token: 0x0400010E RID: 270
		private int mMyAppPriority = 999;

		// Token: 0x0400010F RID: 271
		internal bool mCustomPopup;

		// Token: 0x04000110 RID: 272
		private string mPackageName = string.Empty;

		// Token: 0x04000111 RID: 273
		private string mActivityName = string.Empty;

		// Token: 0x04000113 RID: 275
		private string mApkUrl = string.Empty;

		// Token: 0x04000114 RID: 276
		private AppInfo mAppInfoItem;

		// Token: 0x04000115 RID: 277
		private string mPromotionId;

		// Token: 0x04000116 RID: 278
		internal AppSuggestionPromotion AppSuggestionInfo;
	}
}
