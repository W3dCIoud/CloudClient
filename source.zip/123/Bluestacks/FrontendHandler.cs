﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200013A RID: 314
	internal class FrontendHandler
	{
		// Token: 0x1400000F RID: 15
		// (add) Token: 0x06000C3B RID: 3131 RVA: 0x0005360C File Offset: 0x0005180C
		// (remove) Token: 0x06000C3C RID: 3132 RVA: 0x00053644 File Offset: 0x00051844
		internal event EventHandler mEventOnFrontendClosed;

		// Token: 0x06000C3D RID: 3133 RVA: 0x0005367C File Offset: 0x0005187C
		internal FrontendHandler(MainWindow window)
		{
			this.ParentWindow = window;
			this.mWindowTitle = Oem.Instance.CommonAppTitleText + this.ParentWindow.mVmName;
			this.StartFrontendAfterRAMCheck();
		}

		// Token: 0x06000C3E RID: 3134 RVA: 0x000097AF File Offset: 0x000079AF
		internal void StartFrontendAfterRAMCheck()
		{
			if (!FeatureManager.Instance.IsCustomUIForDMM && !this.ParentWindow.Utils.IsRequiredFreeRAMAvailable())
			{
				this.mIsSufficientRAMAvailable = false;
				return;
			}
			this.StartFrontend();
		}

		// Token: 0x06000C3F RID: 3135 RVA: 0x000536DC File Offset: 0x000518DC
		internal void FrontendHandler_ShowLowRAMMessage()
		{
			CustomMessageWindow cmw = new CustomMessageWindow();
			cmw.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_BLUESTACKS_WARNING_PROMPT", false);
			cmw.AddWarning(LocaleStrings.GetLocalizedString("STRING_LOW_AVAILABLE_RAM_TITLE", false), "message_error");
			cmw.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_LOW_AVAILABLE_RAM_TEXT1", false) + Environment.NewLine + LocaleStrings.GetLocalizedString("STRING_LOW_AVAILABLE_RAM_TEXT2", false);
			cmw.AddButton(ButtonColors.Red, LocaleStrings.GetLocalizedString("STRING_CONTINUE_ANYWAY", false), delegate(object o, EventArgs args)
			{
				cmw.Close();
				this.StartFrontend();
			}, null, false, null);
			cmw.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_CLOSE_BLUESTACKS", false), delegate(object o, EventArgs args)
			{
				this.ParentWindow.Close();
			}, null, false, null);
			cmw.Owner = this.ParentWindow;
			cmw.ShowDialog();
		}

		// Token: 0x06000C40 RID: 3136 RVA: 0x000097DD File Offset: 0x000079DD
		internal void StartFrontend()
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				Logger.Info("BOOT_STAGE: Starting player");
				if (ProcessUtils.IsLockInUse(Strings.GetPlayerLockName(this.ParentWindow.mVmName)))
				{
					this.KillFrontend();
				}
				this.mEventOnFrontendClosed = null;
				this.mIsSufficientRAMAvailable = true;
				this.mIsRestartFrontendWhenClosed = true;
				this.ParentWindow.Utils.CheckGuestFailedAsync();
				this.mFrontendStartTime = DateTime.Now;
				int num = BluestacksProcessHelper.StartFrontend(this.ParentWindow.mVmName);
				if (num == -5)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						Logger.Error("Hyper v enabled on this machine");
						CustomMessageWindow customMessageWindow = new CustomMessageWindow();
						BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_RESTART_UTILITY_CANNOT_START", "");
						customMessageWindow.AddWarning(LocaleStrings.GetLocalizedString("STRING_HYPERV_ENABLED_WARNING", false), "message_error");
						BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_HYPERV_ENABLED_MESSAGE", "");
						customMessageWindow.AddButton(ButtonColors.Blue, "STRING_CHECK_FAQ", delegate(object sender1, EventArgs e1)
						{
							BlueStacksUIUtils.OpenUrl(WebHelper.GetUrlWithParams(string.Format("{0}/{1}", WebHelper.GetServerHost(), "help_articles")) + "&article=disable_hypervisor");
						}, null, false, null);
						customMessageWindow.ShowDialog();
						Process.GetCurrentProcess().Kill();
					}), new object[0]);
					return;
				}
				if (num == -2)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						Logger.Error("Android File Integrity check failed");
						CustomMessageWindow customMessageWindow = new CustomMessageWindow();
						BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_INSTALLATION_ERROR", "");
						BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_CORRUPT_INSTALLATION_MESSAGE", "");
						customMessageWindow.AddButton(ButtonColors.Blue, "STRING_EXIT", null, null, false, null);
						customMessageWindow.ShowDialog();
						Process.GetCurrentProcess().Kill();
					}), new object[0]);
					return;
				}
				if (num == -6)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						Logger.Error("Unable to initialise audio on this machine");
						CustomMessageWindow customMessageWindow = new CustomMessageWindow();
						customMessageWindow.ImageName = "sound_error";
						BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_AUDIO_SERVICE_FAILURE", "");
						BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlockTitle, "STRING_AUDIO_SERVICE_FAILUE_FIX", "");
						customMessageWindow.BodyTextBlockTitle.Visibility = Visibility.Visible;
						BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_AUDIO_SERVICE_FAILURE_ALTERNATE_FIX", "");
						customMessageWindow.AddButton(ButtonColors.Blue, "STRING_READ_MORE", delegate(object sender1, EventArgs e1)
						{
							BlueStacksUIUtils.OpenUrl(WebHelper.GetUrlWithParams(string.Format("{0}/{1}", WebHelper.GetServerHost(), "help_articles")) + "&article=audio_service_issue");
						}, "external_link", true, null);
						customMessageWindow.ShowDialog();
						Process.GetCurrentProcess().Kill();
					}), new object[0]);
					return;
				}
				if (this.mIsRestartFrontendWhenClosed)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						if (this.frontendRestartAttempts < 2)
						{
							this.frontendRestartAttempts++;
							this.ParentWindow.RestartFrontend();
						}
					}), new object[0]);
				}
			});
		}

		// Token: 0x06000C41 RID: 3137 RVA: 0x000097F1 File Offset: 0x000079F1
		internal void KillFrontendAsync()
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				this.KillFrontend();
			});
		}

		// Token: 0x06000C42 RID: 3138 RVA: 0x000537D0 File Offset: 0x000519D0
		internal void KillFrontend()
		{
			try
			{
				this.mIsRestartFrontendWhenClosed = false;
				HTTPUtils.SendRequestToEngine("shutdown", null, "Android", 0, null, false, 1, 0, this.ParentWindow.mVmName);
			}
			catch
			{
			}
			finally
			{
				if (this.mEventOnFrontendClosed != null)
				{
					this.mEventOnFrontendClosed(this.ParentWindow.mVmName, null);
				}
			}
		}

		// Token: 0x06000C43 RID: 3139 RVA: 0x00053848 File Offset: 0x00051A48
		internal void EnableKeyMapping(bool isEnabled)
		{
			try
			{
				this.SendFrontendRequestAsync("setKeymappingState", new Dictionary<string, string>
				{
					{
						"keymapping",
						isEnabled.ToString()
					}
				});
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send EnableKeyMapping to frontend... Err : " + ex.ToString());
			}
		}

		// Token: 0x06000C44 RID: 3140 RVA: 0x000538A4 File Offset: 0x00051AA4
		internal void GetScreenShot(string filePath)
		{
			this.SendFrontendRequestAsync("getScreenshot", new Dictionary<string, string>
			{
				{
					"path",
					filePath
				}
			});
		}

		// Token: 0x06000C45 RID: 3141 RVA: 0x000538D0 File Offset: 0x00051AD0
		internal void FrontendVisibleChanged(bool value)
		{
			try
			{
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary.Add("new_value", Convert.ToString(value));
				if (RegistryManager.Instance.AreAllInstancesMuted || this.ParentWindow.EngineInstanceRegistry.IsMuted)
				{
					dictionary.Add("is_mute", Convert.ToString(true));
				}
				else
				{
					dictionary.Add("is_mute", Convert.ToString(false));
				}
				this.SendFrontendRequestAsync("frontendVisibleChanged", dictionary);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send refresh keymap to frontend... Err : " + ex.ToString());
			}
		}

		// Token: 0x06000C46 RID: 3142 RVA: 0x0005396C File Offset: 0x00051B6C
		internal void RefreshKeyMap(string packageName)
		{
			try
			{
				this.SendFrontendRequestAsync("refreshKeymap", new Dictionary<string, string>
				{
					{
						"package",
						packageName
					}
				});
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send refresh keymap to frontend... Err : " + ex.ToString());
			}
		}

		// Token: 0x06000C47 RID: 3143 RVA: 0x000539C4 File Offset: 0x00051BC4
		internal void DeactivateFrontend()
		{
			try
			{
				if (this.mFrontendHandle != IntPtr.Zero)
				{
					Logger.Debug("KMP deactivateFrontend");
					this.SendFrontendRequestAsync("deactivateFrontend", null);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send deactivate to frontend.. Err : " + ex.ToString());
			}
		}

		// Token: 0x06000C48 RID: 3144 RVA: 0x00053A24 File Offset: 0x00051C24
		internal void ToggleStreamingMode(bool state)
		{
			this.ParentWindow.mTopBar.mSettingsMenuPopup.IsOpen = false;
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				Logger.Info("Streaming mode toggle called with state.." + state.ToString());
				this.ParentWindow.mStreamingModeEnabled = state;
				string value = this.ParentWindow.Handle.ToString();
				if (state)
				{
					value = "0";
				}
				Rectangle windowRectangle = this.GetWindowRectangle();
				if (windowRectangle.Width == 0 && windowRectangle.Height == 0)
				{
					windowRectangle.Width = (int)this.ParentWindow.Width;
					windowRectangle.Height = (int)this.ParentWindow.Height;
				}
				Dictionary<string, string> dict = new Dictionary<string, string>
				{
					{
						"ParentHandle",
						value
					},
					{
						"X",
						windowRectangle.X.ToString()
					},
					{
						"Y",
						windowRectangle.Y.ToString()
					},
					{
						"Width",
						windowRectangle.Width.ToString()
					},
					{
						"Height",
						windowRectangle.Height.ToString()
					}
				};
				ThreadPool.QueueUserWorkItem(delegate(object obj1)
				{
					try
					{
						JObject jobject = JObject.Parse(JArray.Parse(this.SendFrontendRequest("setparent", dict))[0].ToString());
						if (jobject["success"].ToObject<bool>())
						{
							this.mFrontendHandle = new IntPtr(jobject["frontendhandle"].ToObject<int>());
						}
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to send Show event to engine... err : " + ex.ToString());
					}
				});
			}), new object[0]);
		}

		// Token: 0x06000C49 RID: 3145 RVA: 0x00053A80 File Offset: 0x00051C80
		internal void ShowGLWindow()
		{
			if (this.CanfrontendBeResizedAndFocused())
			{
				this.ResizeWindow();
				return;
			}
			if (!this.ParentWindow.mFrontendGrid.IsVisible)
			{
				this.sIsfrontendAlreadyVisible = false;
				if (this.mFrontendHandle != IntPtr.Zero)
				{
					InteropWindow.ShowWindow(this.mFrontendHandle, 0);
					if (KMManager.dictOverlayWindow.ContainsKey(this.ParentWindow) && this.ParentWindow.WindowState != WindowState.Maximized)
					{
						KMManager.ShowOverlayWindow(this.ParentWindow, false, false);
					}
				}
				return;
			}
			this.sIsfrontendAlreadyVisible = true;
			if (!this.ParentWindow.Handle.ToString().Equals("0") && this.mFrontendHandle == IntPtr.Zero)
			{
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					try
					{
						this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
						{
							Rectangle windowRectangle = this.GetWindowRectangle();
							Dictionary<string, string> dict = new Dictionary<string, string>
							{
								{
									"ParentHandle",
									(!this.ParentWindow.mStreamingModeEnabled) ? this.ParentWindow.Handle.ToString() : "0"
								},
								{
									"X",
									windowRectangle.X.ToString()
								},
								{
									"Y",
									windowRectangle.Y.ToString()
								},
								{
									"Width",
									windowRectangle.Width.ToString()
								},
								{
									"Height",
									windowRectangle.Height.ToString()
								}
							};
							if (windowRectangle.Width == 0 || windowRectangle.Height == 0)
							{
								this.sIsfrontendAlreadyVisible = false;
								return;
							}
							ThreadPool.QueueUserWorkItem(delegate(object obj1)
							{
								try
								{
									object obj2 = this.mLockObject;
									lock (obj2)
									{
										if (this.mFrontendHandle == IntPtr.Zero)
										{
											JObject jobject = JObject.Parse(JArray.Parse(this.SendFrontendRequest("setParent", dict))[0].ToString());
											if (jobject["success"].ToObject<bool>())
											{
												this.mFrontendHandle = new IntPtr(jobject["frontendhandle"].ToObject<int>());
											}
											Logger.Debug("Set parent call completed. handle: " + this.mFrontendHandle.ToString());
										}
									}
								}
								catch (Exception ex2)
								{
									Logger.Error("Failed to send Show event to engine... err : " + ex2.ToString());
								}
							});
						}), new object[0]);
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to send Show event to engine... err : " + ex.ToString());
					}
				});
				return;
			}
			this.ResizeWindow();
		}

		// Token: 0x06000C4A RID: 3146 RVA: 0x00009805 File Offset: 0x00007A05
		private bool CanfrontendBeResizedAndFocused()
		{
			return (this.ParentWindow.mDimOverlay == null || this.ParentWindow.mDimOverlay.Visibility == Visibility.Hidden) && this.ParentWindow.mFrontendGrid.IsVisible && this.sIsfrontendAlreadyVisible;
		}

		// Token: 0x06000C4B RID: 3147 RVA: 0x00053B50 File Offset: 0x00051D50
		internal void ResizeWindow()
		{
			Rectangle windowRectangle = this.GetWindowRectangle();
			if (this.ParentWindow.mStreamingModeEnabled)
			{
				InteropWindow.ShowWindow(this.mFrontendHandle, 5);
			}
			else
			{
				InteropWindow.SetWindowPos(this.mFrontendHandle, (IntPtr)0, windowRectangle.X, windowRectangle.Y, windowRectangle.Width, windowRectangle.Height, 16448U);
			}
			if (KMManager.dictOverlayWindow.ContainsKey(this.ParentWindow))
			{
				if (this.ParentWindow.StaticComponents.mLastMappableWindowHandle == IntPtr.Zero)
				{
					this.ParentWindow.StaticComponents.mLastMappableWindowHandle = this.mFrontendHandle;
				}
				KMManager.dictOverlayWindow[this.ParentWindow].UpdateSize();
			}
			this.FocusFrontend(false);
			RegistryManager.Instance.FrontendHeight = windowRectangle.Height;
			RegistryManager.Instance.FrontendWidth = windowRectangle.Width;
		}

		// Token: 0x06000C4C RID: 3148 RVA: 0x00053C38 File Offset: 0x00051E38
		internal Rectangle GetWindowRectangle()
		{
			Grid mFrontendGrid = this.ParentWindow.mFrontendGrid;
			System.Windows.Point point = mFrontendGrid.TranslatePoint(new System.Windows.Point(0.0, 0.0), this.ParentWindow);
			System.Drawing.Point location = new System.Drawing.Point((int)(MainWindow.sScalingFactor * point.X), (int)(MainWindow.sScalingFactor * point.Y));
			System.Drawing.Size size = new System.Drawing.Size((int)(mFrontendGrid.ActualWidth * MainWindow.sScalingFactor), (int)(mFrontendGrid.ActualHeight * MainWindow.sScalingFactor));
			return new Rectangle(location, size);
		}

		// Token: 0x06000C4D RID: 3149 RVA: 0x00053CC0 File Offset: 0x00051EC0
		internal void ChangeFrontendToPortraitMode()
		{
			Rectangle windowRectangle = this.GetWindowRectangle();
			InteropWindow.SetWindowPos(this.mFrontendHandle, (IntPtr)0, windowRectangle.X, windowRectangle.Y, windowRectangle.Width, windowRectangle.Height, 16448U);
		}

		// Token: 0x06000C4E RID: 3150 RVA: 0x00053D08 File Offset: 0x00051F08
		internal void FocusFrontend(bool forceFocus = false)
		{
			if (this.CanfrontendBeResizedAndFocused() && !this.ParentWindow.mStreamingModeEnabled)
			{
				InteropWindow.SetFocus(this.mFrontendHandle);
				Logger.Debug("KMP REFRESH Frontend");
				this.SendFrontendRequestAsync("refreshWindow", null);
				return;
			}
			Logger.Debug("KMP CanfrontendBeResizedAndFocused false " + this.ParentWindow.mFrontendGrid.IsVisible.ToString() + this.sIsfrontendAlreadyVisible.ToString());
		}

		// Token: 0x06000C4F RID: 3151 RVA: 0x00009843 File Offset: 0x00007A43
		internal void SendFrontendRequestAsync(string path, Dictionary<string, string> data = null)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				this.SendFrontendRequest(path, data);
			});
		}

		// Token: 0x06000C50 RID: 3152 RVA: 0x00053D80 File Offset: 0x00051F80
		internal string SendFrontendRequest(string path, Dictionary<string, string> data = null)
		{
			string result = string.Empty;
			try
			{
				result = HTTPUtils.SendRequestToEngine(path, data, this.ParentWindow.mVmName, 0, null, false, 1, 0, "");
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in SendFrontendRequest: " + ex.ToString());
			}
			return result;
		}

		// Token: 0x06000C51 RID: 3153 RVA: 0x00053DDC File Offset: 0x00051FDC
		internal void UpdateBootTimeInregistry(DateTime time)
		{
			try
			{
				int lastBootTime = (int)(DateTime.Now - time).TotalSeconds * 1000;
				int noOfBootCompleted = RegistryManager.Instance.NoOfBootCompleted;
				RegistryManager.Instance.LastBootTime = lastBootTime;
				RegistryManager.Instance.NoOfBootCompleted = noOfBootCompleted + 1;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in UpdateBootTimeInregistry: " + ex.ToString());
			}
		}

		// Token: 0x06000C52 RID: 3154 RVA: 0x00053E54 File Offset: 0x00052054
		internal void UpdateOverlaySizeStatus()
		{
			this.SendFrontendRequestAsync("sendGlWindowSize", new Dictionary<string, string>
			{
				{
					"updateSize",
					(this.ParentWindow.WindowState == WindowState.Maximized).ToString()
				}
			});
		}

		// Token: 0x04000906 RID: 2310
		private int frontendRestartAttempts;

		// Token: 0x04000907 RID: 2311
		private MainWindow ParentWindow;

		// Token: 0x04000908 RID: 2312
		internal string mWindowTitle;

		// Token: 0x04000909 RID: 2313
		private bool sIsfrontendAlreadyVisible;

		// Token: 0x0400090A RID: 2314
		internal IntPtr mFrontendHandle;

		// Token: 0x0400090B RID: 2315
		private bool mIsRestartFrontendWhenClosed;

		// Token: 0x0400090C RID: 2316
		internal DateTime mFrontendStartTime = DateTime.Now;

		// Token: 0x0400090E RID: 2318
		internal bool mIsSufficientRAMAvailable = true;

		// Token: 0x0400090F RID: 2319
		public bool IsShootingModeActivated;

		// Token: 0x04000910 RID: 2320
		private object mLockObject = new object();
	}
}
