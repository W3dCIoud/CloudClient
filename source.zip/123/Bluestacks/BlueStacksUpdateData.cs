﻿using System;
using System.Collections.Generic;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000159 RID: 345
	internal class BlueStacksUpdateData
	{
		// Token: 0x170001E5 RID: 485
		// (get) Token: 0x06000D3B RID: 3387 RVA: 0x0000A306 File Offset: 0x00008506
		// (set) Token: 0x06000D3C RID: 3388 RVA: 0x0000A30E File Offset: 0x0000850E
		public string ClientVersion
		{
			get
			{
				return this.mClientVersion;
			}
			set
			{
				this.mClientVersion = value;
			}
		}

		// Token: 0x170001E6 RID: 486
		// (get) Token: 0x06000D3D RID: 3389 RVA: 0x0000A317 File Offset: 0x00008517
		// (set) Token: 0x06000D3E RID: 3390 RVA: 0x0000A31F File Offset: 0x0000851F
		public string EngineVersion
		{
			get
			{
				return this.mEngineVersion;
			}
			set
			{
				this.mEngineVersion = value;
			}
		}

		// Token: 0x170001E7 RID: 487
		// (get) Token: 0x06000D3F RID: 3391 RVA: 0x0000A328 File Offset: 0x00008528
		// (set) Token: 0x06000D40 RID: 3392 RVA: 0x0000A330 File Offset: 0x00008530
		public bool IsFullInstaller
		{
			get
			{
				return this.mIsFullInstaller;
			}
			set
			{
				this.mIsFullInstaller = value;
			}
		}

		// Token: 0x170001E8 RID: 488
		// (get) Token: 0x06000D41 RID: 3393 RVA: 0x0000A339 File Offset: 0x00008539
		// (set) Token: 0x06000D42 RID: 3394 RVA: 0x0000A341 File Offset: 0x00008541
		public string Md5
		{
			get
			{
				return this.mMd5;
			}
			set
			{
				this.mMd5 = value;
			}
		}

		// Token: 0x170001E9 RID: 489
		// (get) Token: 0x06000D43 RID: 3395 RVA: 0x0000A34A File Offset: 0x0000854A
		// (set) Token: 0x06000D44 RID: 3396 RVA: 0x0000A352 File Offset: 0x00008552
		public string UpdateType
		{
			get
			{
				return this.mUpdateType;
			}
			set
			{
				this.mUpdateType = value;
			}
		}

		// Token: 0x170001EA RID: 490
		// (get) Token: 0x06000D45 RID: 3397 RVA: 0x0000A35B File Offset: 0x0000855B
		// (set) Token: 0x06000D46 RID: 3398 RVA: 0x0000A363 File Offset: 0x00008563
		public string DownloadUrl
		{
			get
			{
				return this.mDownloadUrl;
			}
			set
			{
				this.mDownloadUrl = value;
			}
		}

		// Token: 0x170001EB RID: 491
		// (get) Token: 0x06000D47 RID: 3399 RVA: 0x0000A36C File Offset: 0x0000856C
		// (set) Token: 0x06000D48 RID: 3400 RVA: 0x0000A374 File Offset: 0x00008574
		public List<string> UpdateDescrption
		{
			get
			{
				return this.mUpdateDescrption;
			}
			set
			{
				this.mUpdateDescrption = value;
			}
		}

		// Token: 0x170001EC RID: 492
		// (get) Token: 0x06000D49 RID: 3401 RVA: 0x0000A37D File Offset: 0x0000857D
		// (set) Token: 0x06000D4A RID: 3402 RVA: 0x0000A385 File Offset: 0x00008585
		public bool IsUpdateAvailble
		{
			get
			{
				return this.mIsUpdateAvailble;
			}
			set
			{
				this.mIsUpdateAvailble = value;
			}
		}

		// Token: 0x170001ED RID: 493
		// (get) Token: 0x06000D4B RID: 3403 RVA: 0x0000A38E File Offset: 0x0000858E
		// (set) Token: 0x06000D4C RID: 3404 RVA: 0x0000A396 File Offset: 0x00008596
		public string UpdateDownloadLocation
		{
			get
			{
				return this.mUpdateDownloadLocation;
			}
			set
			{
				this.mUpdateDownloadLocation = value;
			}
		}

		// Token: 0x170001EE RID: 494
		// (get) Token: 0x06000D4D RID: 3405 RVA: 0x0000A39F File Offset: 0x0000859F
		// (set) Token: 0x06000D4E RID: 3406 RVA: 0x0000A3A7 File Offset: 0x000085A7
		public string DetailedChangeLogsUrl
		{
			get
			{
				return this.mDetailedChangeLogsUrl;
			}
			set
			{
				this.mDetailedChangeLogsUrl = value;
			}
		}

		// Token: 0x170001EF RID: 495
		// (get) Token: 0x06000D4F RID: 3407 RVA: 0x0000A3B0 File Offset: 0x000085B0
		// (set) Token: 0x06000D50 RID: 3408 RVA: 0x0000A3B8 File Offset: 0x000085B8
		public bool IsTryAgain
		{
			get
			{
				return this.mIsTryAgain;
			}
			set
			{
				this.mIsTryAgain = value;
			}
		}

		// Token: 0x04000986 RID: 2438
		private bool mIsUpdateAvailble;

		// Token: 0x04000987 RID: 2439
		private string mClientVersion = "";

		// Token: 0x04000988 RID: 2440
		private string mEngineVersion = "";

		// Token: 0x04000989 RID: 2441
		private bool mIsFullInstaller;

		// Token: 0x0400098A RID: 2442
		private string mMd5 = "";

		// Token: 0x0400098B RID: 2443
		private string mUpdateType = "";

		// Token: 0x0400098C RID: 2444
		private string mDownloadUrl = "";

		// Token: 0x0400098D RID: 2445
		private List<string> mUpdateDescrption = new List<string>();

		// Token: 0x0400098E RID: 2446
		private string mUpdateDownloadLocation = "";

		// Token: 0x0400098F RID: 2447
		private string mDetailedChangeLogsUrl = "";

		// Token: 0x04000990 RID: 2448
		private bool mIsTryAgain;
	}
}
