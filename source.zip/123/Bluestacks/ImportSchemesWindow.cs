﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000E6 RID: 230
	public class ImportSchemesWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x060009D4 RID: 2516 RVA: 0x000081A3 File Offset: 0x000063A3
		public ImportSchemesWindow(KeymapCanvasWindow window, MainWindow mainWindow)
		{
			this.InitializeComponent();
			this.CanvasWindow = window;
			this.ParentWindow = mainWindow;
			this.mSchemesStackPanel = (this.mSchemesListScrollbar.Content as StackPanel);
		}

		// Token: 0x060009D5 RID: 2517 RVA: 0x000081E0 File Offset: 0x000063E0
		private void Close_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.CloseWindow();
		}

		// Token: 0x060009D6 RID: 2518 RVA: 0x000081E8 File Offset: 0x000063E8
		private void CloseWindow()
		{
			base.Close();
			this.CanvasWindow.SidebarWindow.mImportSchemesWindow = null;
			this.CanvasWindow.SidebarWindow.mOverlayGrid.Visibility = Visibility.Hidden;
			this.CanvasWindow.SidebarWindow.Focus();
		}

		// Token: 0x060009D7 RID: 2519 RVA: 0x0004587C File Offset: 0x00043A7C
		internal void Init(string fileName)
		{
			try
			{
				List<string> list = new List<string>();
				foreach (IMControlScheme imcontrolScheme in this.ParentWindow.SelectedConfig.ControlSchemes)
				{
					list.Add(imcontrolScheme.Name);
				}
				this.mSchemesStackPanel.Children.Clear();
				JObject jobject = JObject.Parse(File.ReadAllText(fileName));
				int? configVersion = ConfigConverter.GetConfigVersion(jobject);
				int num = 14;
				IMConfig deserializedIMConfigObject;
				if (configVersion.GetValueOrDefault() < num & configVersion != null)
				{
					object value = ConfigConverter.Convert(jobject, "14", false, true);
					JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
					serializerSettings.Formatting = Formatting.Indented;
					deserializedIMConfigObject = KMManager.GetDeserializedIMConfigObject(JsonConvert.SerializeObject(value, serializerSettings), false);
				}
				else
				{
					deserializedIMConfigObject = KMManager.GetDeserializedIMConfigObject(fileName, true);
				}
				this.mStringsToImport = deserializedIMConfigObject.Strings;
				foreach (IMControlScheme imcontrolScheme2 in deserializedIMConfigObject.ControlSchemes)
				{
					this.dict.Add(imcontrolScheme2.Name, imcontrolScheme2);
					ImportSchemesWindowControl importSchemesWindowControl = new ImportSchemesWindowControl(this, this.ParentWindow);
					importSchemesWindowControl.Width = this.mSchemesStackPanel.Width;
					importSchemesWindowControl.mContent.Content = imcontrolScheme2.Name;
					importSchemesWindowControl.Margin = new Thickness(0.0, 1.0, 0.0, 1.0);
					using (Dictionary<string, IMControlScheme>.KeyCollection.Enumerator enumerator2 = this.ParentWindow.SelectedConfig.ControlSchemesDict.Keys.GetEnumerator())
					{
						while (enumerator2.MoveNext())
						{
							if (enumerator2.Current.ToLower().Trim() == importSchemesWindowControl.mContent.Content.ToString().ToLower().Trim())
							{
								importSchemesWindowControl.mBlock.Visibility = Visibility.Visible;
								importSchemesWindowControl.mImportName.Text = KMManager.GetUniqueName(importSchemesWindowControl.mContent.Content.ToString().Trim(), list);
								break;
							}
						}
					}
					this.mSchemesStackPanel.Children.Add(importSchemesWindowControl);
				}
				this.mNumberOfSchemesSelectedForImport = 0;
			}
			catch (Exception ex)
			{
				Logger.Error("Error in import window init err: " + ex.ToString());
			}
		}

		// Token: 0x060009D8 RID: 2520 RVA: 0x00045B3C File Offset: 0x00043D3C
		internal void Box_Unchecked(object sender, RoutedEventArgs e)
		{
			this.mNumberOfSchemesSelectedForImport--;
			if (this.mNumberOfSchemesSelectedForImport == this.mSchemesStackPanel.Children.Count - 1)
			{
				this.mSelectAllBtn.IsChecked = new bool?(false);
			}
			if (this.mNumberOfSchemesSelectedForImport == 0)
			{
				this.mImportBtn.IsEnabled = false;
			}
		}

		// Token: 0x060009D9 RID: 2521 RVA: 0x00045B98 File Offset: 0x00043D98
		internal void Box_Checked(object sender, RoutedEventArgs e)
		{
			this.mNumberOfSchemesSelectedForImport++;
			if (this.mNumberOfSchemesSelectedForImport == this.mSchemesStackPanel.Children.Count)
			{
				this.mSelectAllBtn.IsChecked = new bool?(true);
			}
			if (this.mNumberOfSchemesSelectedForImport == 1)
			{
				this.mImportBtn.IsEnabled = true;
			}
		}

		// Token: 0x060009DA RID: 2522 RVA: 0x00045BF4 File Offset: 0x00043DF4
		private bool EditedNameIsAllowed(string text, ImportSchemesWindowControl item)
		{
			if (string.IsNullOrEmpty(text.Trim()))
			{
				BlueStacksUIBinding.Bind(item.mWarningMsg, LocaleStrings.GetLocalizedString("STRING_INVALID_NAME", false), "");
				return false;
			}
			if (text.Trim().IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
			{
				BlueStacksUIBinding.Bind(item.mWarningMsg, LocaleStrings.GetLocalizedString("STRING_INVALID_NAME", false), "");
				return false;
			}
			using (List<IMControlScheme>.Enumerator enumerator = this.ParentWindow.SelectedConfig.ControlSchemes.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.Name.ToLower().Trim() == text.ToLower().Trim())
					{
						return false;
					}
				}
			}
			foreach (object obj in this.mSchemesStackPanel.Children)
			{
				ImportSchemesWindowControl importSchemesWindowControl = (ImportSchemesWindowControl)obj;
				bool? isChecked = importSchemesWindowControl.mContent.IsChecked;
				bool flag = true;
				if ((isChecked.GetValueOrDefault() == flag & isChecked != null) && importSchemesWindowControl.mBlock.Visibility == Visibility.Visible && importSchemesWindowControl.mImportName.Text.ToLower().Trim() == text.ToLower().Trim() && importSchemesWindowControl.mContent.Content.ToString().Trim().ToLower() != item.mContent.Content.ToString().Trim().ToLower())
				{
					return false;
				}
				isChecked = importSchemesWindowControl.mContent.IsChecked;
				flag = true;
				if ((isChecked.GetValueOrDefault() == flag & isChecked != null) && importSchemesWindowControl.mContent.Content.ToString().ToLower().Trim() == text.ToLower().Trim())
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x060009DB RID: 2523 RVA: 0x00045E24 File Offset: 0x00044024
		private void ImportBtn_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				int num = 0;
				bool flag = true;
				List<IMControlScheme> list = new List<IMControlScheme>();
				foreach (object obj in this.mSchemesStackPanel.Children)
				{
					ImportSchemesWindowControl importSchemesWindowControl = (ImportSchemesWindowControl)obj;
					bool? isChecked = importSchemesWindowControl.mContent.IsChecked;
					bool flag2 = true;
					if (isChecked.GetValueOrDefault() == flag2 & isChecked != null)
					{
						list.Add(this.dict.ElementAt(num).Value);
						if ((from key in this.ParentWindow.SelectedConfig.ControlSchemesDict.Keys
						select key.ToLower().Trim()).Contains(importSchemesWindowControl.mContent.Content.ToString().ToLower().Trim()))
						{
							if (!this.EditedNameIsAllowed(importSchemesWindowControl.mImportName.Text, importSchemesWindowControl))
							{
								importSchemesWindowControl.mImportName.InputTextValidity = TextValidityOptions.Error;
								if (!string.IsNullOrEmpty(importSchemesWindowControl.mImportName.Text) && importSchemesWindowControl.mImportName.Text.Trim().IndexOfAny(Path.GetInvalidFileNameChars()) < 0)
								{
									BlueStacksUIBinding.Bind(importSchemesWindowControl.mWarningMsg, LocaleStrings.GetLocalizedString("STRING_DUPLICATE_SCHEME_NAME_WARNING", false), "");
								}
								importSchemesWindowControl.mWarningMsg.Visibility = Visibility.Visible;
								flag = false;
							}
							else
							{
								importSchemesWindowControl.mImportName.InputTextValidity = TextValidityOptions.Success;
								importSchemesWindowControl.mWarningMsg.Visibility = Visibility.Collapsed;
							}
						}
					}
					num++;
				}
				if (list.Count == 0)
				{
					this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_SCHEME_SELECTED", false), 1.3, false);
				}
				else if (flag)
				{
					foreach (IMControlScheme imcontrolScheme in list)
					{
						ImportSchemesWindowControl controlFromScheme = this.GetControlFromScheme(imcontrolScheme);
						if ((from key in this.ParentWindow.SelectedConfig.ControlSchemesDict.Keys
						select key.ToLower()).Contains(controlFromScheme.mContent.Content.ToString().ToLower().Trim()))
						{
							imcontrolScheme.Name = controlFromScheme.mImportName.Text.Trim();
						}
					}
					this.mStringsToImport = KMManager.CleanupGuidanceAccordingToSchemes(list, this.mStringsToImport);
					this.ImportSchemes(list, this.mStringsToImport);
					KeymapCanvasWindow.sIsDirty = true;
					KMManager.SaveIMActions(false, false);
					if (this.ParentWindow.SelectedConfig.SelectedControlScheme != null)
					{
						this.CanvasWindow.SidebarWindow.FillProfileCombo();
						this.CanvasWindow.SidebarWindow.ProfileChanged();
					}
					else
					{
						this.CanvasWindow.SidebarWindow.FillProfileCombo();
						this.CanvasWindow.SidebarWindow.ProfileChanged();
					}
					this.ParentWindow.mCommonHandler.AddToastPopup(this.CanvasWindow.SidebarWindow, LocaleStrings.GetLocalizedString("STRING_CONTROLS_IMPORTED", false), 1.3, false);
					this.CloseWindow();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error while importing script. err:" + ex.ToString());
			}
		}

		// Token: 0x060009DC RID: 2524 RVA: 0x000461C8 File Offset: 0x000443C8
		private ImportSchemesWindowControl GetControlFromScheme(IMControlScheme scheme)
		{
			foreach (object obj in this.mSchemesStackPanel.Children)
			{
				ImportSchemesWindowControl importSchemesWindowControl = (ImportSchemesWindowControl)obj;
				if (importSchemesWindowControl.mContent.Content.ToString().Trim().ToLower() == scheme.Name.ToLower().Trim())
				{
					return importSchemesWindowControl;
				}
			}
			return null;
		}

		// Token: 0x060009DD RID: 2525 RVA: 0x00046258 File Offset: 0x00044458
		private void ToggleCheckBoxForExport(bool isShow)
		{
			foreach (object obj in this.mSchemesStackPanel.Children)
			{
				((ImportSchemesWindowControl)obj).mContent.IsChecked = new bool?(false);
			}
		}

		// Token: 0x060009DE RID: 2526 RVA: 0x000462C0 File Offset: 0x000444C0
		private void ShowLoadingGrid(bool isShow)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (isShow)
				{
					this.mLoadingGrid.Visibility = Visibility.Visible;
					return;
				}
				this.mLoadingGrid.Visibility = Visibility.Hidden;
			}), new object[0]);
		}

		// Token: 0x060009DF RID: 2527 RVA: 0x00046300 File Offset: 0x00044500
		private void SelectAllBtn_Click(object sender, RoutedEventArgs e)
		{
			if (this.mSelectAllBtn.IsChecked.Value)
			{
				using (IEnumerator enumerator = this.mSchemesStackPanel.Children.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						object obj = enumerator.Current;
						((ImportSchemesWindowControl)obj).mContent.IsChecked = new bool?(true);
					}
					return;
				}
			}
			foreach (object obj2 in this.mSchemesStackPanel.Children)
			{
				((ImportSchemesWindowControl)obj2).mContent.IsChecked = new bool?(false);
			}
		}

		// Token: 0x060009E0 RID: 2528 RVA: 0x000463D0 File Offset: 0x000445D0
		internal void ImportSchemes(List<IMControlScheme> toCopyFromSchemes, Dictionary<string, Dictionary<string, string>> stringsToImport)
		{
			bool flag = false;
			bool flag2 = false;
			KMManager.MergeConflictingGuidanceStrings(this.ParentWindow.SelectedConfig, toCopyFromSchemes, stringsToImport);
			if (this.ParentWindow.SelectedConfig.ControlSchemes.Count > 0)
			{
				flag = true;
			}
			foreach (IMControlScheme imcontrolScheme in toCopyFromSchemes)
			{
				IMControlScheme imcontrolScheme2 = imcontrolScheme.DeepCopy();
				if (flag)
				{
					imcontrolScheme2.Selected = false;
				}
				imcontrolScheme2.BuiltIn = false;
				imcontrolScheme2.IsBookMarked = false;
				this.CanvasWindow.SidebarWindow.mSchemeComboBox.mName.Text = imcontrolScheme2.Name;
				this.ParentWindow.SelectedConfig.ControlSchemes.Add(imcontrolScheme2);
				this.ParentWindow.SelectedConfig.ControlSchemesDict.Add(imcontrolScheme2.Name, imcontrolScheme2);
				ComboBoxSchemeControl comboBoxSchemeControl = new ComboBoxSchemeControl(this.CanvasWindow, this.ParentWindow);
				comboBoxSchemeControl.mSchemeName.Text = LocaleStrings.GetLocalizedString(imcontrolScheme2.Name, false);
				comboBoxSchemeControl.IsEnabled = true;
				BlueStacksUIBinding.BindColor(comboBoxSchemeControl, Control.BackgroundProperty, "ComboBoxBackgroundColor");
				this.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children.Add(comboBoxSchemeControl);
			}
			if (!flag)
			{
				using (List<IMControlScheme>.Enumerator enumerator = this.ParentWindow.SelectedConfig.ControlSchemes.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						if (enumerator.Current.Selected)
						{
							flag2 = true;
							break;
						}
					}
				}
				if (!flag2)
				{
					this.ParentWindow.SelectedConfig.ControlSchemes[0].Selected = true;
				}
			}
		}

		// Token: 0x060009E1 RID: 2529 RVA: 0x00046594 File Offset: 0x00044794
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/importschemeswindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060009E2 RID: 2530 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060009E3 RID: 2531 RVA: 0x000465C4 File Offset: 0x000447C4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				((CustomPictureBox)target).MouseLeftButtonUp += this.Close_MouseLeftButtonUp;
				return;
			case 3:
				this.mSchemesListScrollbar = (ScrollViewer)target;
				return;
			case 4:
				this.mSelectAllBtn = (CustomCheckbox)target;
				this.mSelectAllBtn.Click += this.SelectAllBtn_Click;
				return;
			case 5:
				this.mImportBtn = (CustomButton)target;
				this.mImportBtn.Click += this.ImportBtn_Click;
				return;
			case 6:
				this.mLoadingGrid = (ProgressBar)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400071D RID: 1821
		private KeymapCanvasWindow CanvasWindow;

		// Token: 0x0400071E RID: 1822
		private MainWindow ParentWindow;

		// Token: 0x0400071F RID: 1823
		internal StackPanel mSchemesStackPanel;

		// Token: 0x04000720 RID: 1824
		internal int mNumberOfSchemesSelectedForImport;

		// Token: 0x04000721 RID: 1825
		private Dictionary<string, IMControlScheme> dict = new Dictionary<string, IMControlScheme>();

		// Token: 0x04000722 RID: 1826
		private Dictionary<string, Dictionary<string, string>> mStringsToImport;

		// Token: 0x04000723 RID: 1827
		internal Border mMaskBorder;

		// Token: 0x04000724 RID: 1828
		internal ScrollViewer mSchemesListScrollbar;

		// Token: 0x04000725 RID: 1829
		internal CustomCheckbox mSelectAllBtn;

		// Token: 0x04000726 RID: 1830
		internal CustomButton mImportBtn;

		// Token: 0x04000727 RID: 1831
		internal ProgressBar mLoadingGrid;

		// Token: 0x04000728 RID: 1832
		private bool _contentLoaded;
	}
}
