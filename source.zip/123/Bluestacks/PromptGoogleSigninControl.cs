﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200009F RID: 159
	public class PromptGoogleSigninControl : UserControl, IComponentConnector
	{
		// Token: 0x060006CB RID: 1739 RVA: 0x000066CA File Offset: 0x000048CA
		public PromptGoogleSigninControl(MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
		}

		// Token: 0x060006CC RID: 1740 RVA: 0x0000553B File Offset: 0x0000373B
		private void CloseBtn_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x060006CD RID: 1741 RVA: 0x0002B0F4 File Offset: 0x000292F4
		private void CloseBtn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			try
			{
				ClientStats.SendMiscellaneousStatsAsync("GoogleSigninClose", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, null, null, RegistryManager.Instance.InstallID, null, null, null);
				BlueStacksUIUtils.CloseContainerWindow(this);
			}
			catch (Exception arg)
			{
				Logger.Error("Exception in CloseBtn_MouseLeftButtonUp. Exception: " + arg);
			}
		}

		// Token: 0x060006CE RID: 1742 RVA: 0x0002B15C File Offset: 0x0002935C
		private void SigninBtn_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				AppIcon appIcon = this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon("com.android.vending");
				if (appIcon != null)
				{
					this.ParentWindow.mTopBar.mAppTabButtons.AddAppTab(appIcon.AppName, appIcon.PackageName, appIcon.ActivityName, appIcon.ImageName, true, true, appIcon.PackageName, false);
				}
				ClientStats.SendMiscellaneousStatsAsync("GoogleSigninClick", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, null, null, RegistryManager.Instance.InstallID, null, null, null);
				BlueStacksUIUtils.CloseContainerWindow(this);
			}
			catch (Exception arg)
			{
				Logger.Error("Exception in SigninBtn_Click. Exception: " + arg);
			}
		}

		// Token: 0x060006CF RID: 1743 RVA: 0x0002B218 File Offset: 0x00029418
		private void SigninLaterBtn_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				ClientStats.SendMiscellaneousStatsAsync("GoogleSigninLater", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, null, null, RegistryManager.Instance.InstallID, null, null, null);
				BlueStacksUIUtils.CloseContainerWindow(this);
			}
			catch (Exception arg)
			{
				Logger.Error("Exception in SigninLaterBtn_Click. Exception: " + arg);
			}
		}

		// Token: 0x060006D0 RID: 1744 RVA: 0x0002B280 File Offset: 0x00029480
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/promptgooglesignincontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060006D1 RID: 1745 RVA: 0x0002B2B0 File Offset: 0x000294B0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.CloseBtn = (CustomPictureBox)target;
				this.CloseBtn.PreviewMouseDown += this.CloseBtn_PreviewMouseDown;
				this.CloseBtn.MouseLeftButtonUp += this.CloseBtn_MouseLeftButtonUp;
				return;
			case 2:
				this.SigninLaterBtn = (CustomButton)target;
				this.SigninLaterBtn.Click += this.SigninLaterBtn_Click;
				return;
			case 3:
				this.SigninBtn = (CustomButton)target;
				this.SigninBtn.Click += this.SigninBtn_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000495 RID: 1173
		private MainWindow ParentWindow;

		// Token: 0x04000496 RID: 1174
		internal CustomPictureBox CloseBtn;

		// Token: 0x04000497 RID: 1175
		internal CustomButton SigninLaterBtn;

		// Token: 0x04000498 RID: 1176
		internal CustomButton SigninBtn;

		// Token: 0x04000499 RID: 1177
		private bool _contentLoaded;
	}
}
