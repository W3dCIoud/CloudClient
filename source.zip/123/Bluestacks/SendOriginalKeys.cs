﻿using System;

// Token: 0x0200000E RID: 14
[Serializable]
public class SendOriginalKeys : IMAction
{
	// Token: 0x17000079 RID: 121
	// (get) Token: 0x06000100 RID: 256 RVA: 0x00002AA4 File Offset: 0x00000CA4
	// (set) Token: 0x06000101 RID: 257 RVA: 0x00002AAC File Offset: 0x00000CAC
	public string Comments
	{
		get
		{
			return this.mComments;
		}
		set
		{
			this.mComments = value;
		}
	}

	// Token: 0x0400007C RID: 124
	private string mComments;
}
