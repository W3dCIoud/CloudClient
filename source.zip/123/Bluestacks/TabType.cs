﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200002A RID: 42
	public enum TabType
	{
		// Token: 0x0400013D RID: 317
		AppTab,
		// Token: 0x0400013E RID: 318
		WebTab,
		// Token: 0x0400013F RID: 319
		HomeTab
	}
}
