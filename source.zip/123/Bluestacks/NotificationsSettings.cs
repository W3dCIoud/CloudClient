﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000134 RID: 308
	public class NotificationsSettings : UserControl, IComponentConnector
	{
		// Token: 0x06000C11 RID: 3089 RVA: 0x00051E10 File Offset: 0x00050010
		public NotificationsSettings(MainWindow window)
		{
			NotificationsSettings.Instance = this;
			this.InitializeComponent();
			base.Visibility = Visibility.Hidden;
			this.mVmName = window.mVmName;
			this.mScroll.ScrollChanged += BluestacksUIColor.ScrollBarScrollChanged;
		}

		// Token: 0x06000C12 RID: 3090 RVA: 0x00051E64 File Offset: 0x00050064
		private void NotificationSettings_Loaded(object sender, RoutedEventArgs e)
		{
			NotificationManager.Instance.ReloadNotificationDetails();
			this.mCustomNotifications.IsChecked = new bool?(false);
			this.mStackPanel.Visibility = Visibility.Hidden;
			this.mTbMuteAll.IsThreeStateCheckBox = true;
			this.mTbMuteAll.mMuteCheckBox.Group = "NotificationMute";
			this.mTbMuteAll.mAutoHideCheckBox.Group = "NotificationAutoHide";
			this.mTbMuteAll.HideAppLable();
			this.mUseInstalledApps.HideShowButton();
			this.mUseInstalledApps.HideAppLable();
			this.mUseInstalledApps.mAutoHideCheckBox.Unchecked += this.mCustomNotifications_Unchecked;
			this.mUseInstalledApps.mAutoHideCheckBox.Checked += this.mCustomNotifications_Checked;
			BlueStacksUIBinding.Bind(this.mUseInstalledApps.mAutoHideCheckBox, "STRING_CUSTOM_NOTIFICATION_SETTING");
			this.mShowRibbonNotification.HideShowButton();
			this.mShowRibbonNotification.HideAppLable();
			BlueStacksUIBinding.Bind(this.mShowRibbonNotification.mAutoHideCheckBox, "STRING_SHOW_RIBBON");
			this.mShowRibbonNotification.mAutoHideCheckBox.Unchecked += this.mShowRibbonNotification_Unchecked;
			this.mShowRibbonNotification.mAutoHideCheckBox.Checked += this.mShowRibbonNotification_Checked;
			this.mShowRibbonNotification.mAutoHideCheckBox.IsChecked = new bool?(RegistryManager.Instance.IsShowRibbonNotification);
			this.mShowToastNotification.HideShowButton();
			this.mShowToastNotification.HideAppLable();
			BlueStacksUIBinding.Bind(this.mShowToastNotification.mAutoHideCheckBox, "STRING_SHOW_TOAST");
			this.mShowToastNotification.mAutoHideCheckBox.Unchecked += this.mShowToastNotification_Unchecked;
			this.mShowToastNotification.mAutoHideCheckBox.Checked += this.mShowToastNotification_Checked;
			this.mShowToastNotification.mAutoHideCheckBox.IsChecked = new bool?(RegistryManager.Instance.IsShowToastNotification);
			this.mTbMuteAll.AppLabel = "STRING_SHOW_NOTIFICATIONS";
			BlueStacksUIBinding.Bind(this.mTbMuteAll.mMuteCheckBox, "STRING_SHOW_NOTIFICATIONS");
			this.mTbMuteAll.CheckBoxOrientation = Orientation.Horizontal;
			List<AppInfo> list = new JsonParser(this.mVmName).GetAppList().ToList<AppInfo>();
			List<string> list2 = new List<string>();
			this.AddNotificationToggleButton("BlueStacks", string.Empty);
			foreach (AppInfo appInfo in list)
			{
				if (!list2.Contains(appInfo.package))
				{
					list2.Add(appInfo.package);
					this.AddNotificationToggleButton(appInfo.name, appInfo.img);
				}
			}
		}

		// Token: 0x06000C13 RID: 3091 RVA: 0x00052104 File Offset: 0x00050304
		private void AddNotificationToggleButton(string name, string imageName)
		{
			CustomToggleButton customToggleButton = new CustomToggleButton();
			customToggleButton.mMuteCheckBox.Group = "NotificationMute";
			customToggleButton.mAutoHideCheckBox.Group = "NotificationAutoHide";
			customToggleButton.AppLabel = name;
			customToggleButton.CheckBoxOrientation = Orientation.Horizontal;
			string text = Path.Combine(RegistryStrings.GadgetDir, imageName);
			if (File.Exists(text))
			{
				customToggleButton.Image = CustomPictureBox.GetBitmapImage(text, "", true);
			}
			customToggleButton.Margin = new Thickness(0.0, 0.0, 0.0, 10.0);
			this.mStackPanel.Children.Add(customToggleButton);
		}

		// Token: 0x06000C14 RID: 3092 RVA: 0x00009662 File Offset: 0x00007862
		private void mCustomNotifications_Unchecked(object sender, RoutedEventArgs e)
		{
			this.mStackPanel.Visibility = Visibility.Hidden;
		}

		// Token: 0x06000C15 RID: 3093 RVA: 0x00009670 File Offset: 0x00007870
		private void mCustomNotifications_Checked(object sender, RoutedEventArgs e)
		{
			this.mStackPanel.Visibility = Visibility.Visible;
		}

		// Token: 0x06000C16 RID: 3094 RVA: 0x0000967E File Offset: 0x0000787E
		private void mShowRibbonNotification_Unchecked(object sender, RoutedEventArgs e)
		{
			RegistryManager.Instance.IsShowRibbonNotification = false;
		}

		// Token: 0x06000C17 RID: 3095 RVA: 0x0000968B File Offset: 0x0000788B
		private void mShowRibbonNotification_Checked(object sender, RoutedEventArgs e)
		{
			RegistryManager.Instance.IsShowRibbonNotification = true;
		}

		// Token: 0x06000C18 RID: 3096 RVA: 0x00009698 File Offset: 0x00007898
		private void mShowToastNotification_Unchecked(object sender, RoutedEventArgs e)
		{
			RegistryManager.Instance.IsShowToastNotification = false;
		}

		// Token: 0x06000C19 RID: 3097 RVA: 0x000096A5 File Offset: 0x000078A5
		private void mShowToastNotification_Checked(object sender, RoutedEventArgs e)
		{
			RegistryManager.Instance.IsShowToastNotification = true;
		}

		// Token: 0x06000C1A RID: 3098 RVA: 0x000521AC File Offset: 0x000503AC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/notificationssettings.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000C1B RID: 3099 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000C1C RID: 3100 RVA: 0x000521DC File Offset: 0x000503DC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((NotificationsSettings)target).Loaded += this.NotificationSettings_Loaded;
				return;
			case 2:
				this.mScroll = (ScrollViewer)target;
				return;
			case 3:
				this.mTbMuteAll = (CustomToggleButton)target;
				return;
			case 4:
				this.mCustomNotifications = (CustomCheckbox)target;
				this.mCustomNotifications.Unchecked += this.mCustomNotifications_Unchecked;
				this.mCustomNotifications.Checked += this.mCustomNotifications_Checked;
				return;
			case 5:
				this.mUseInstalledApps = (CustomToggleButton)target;
				return;
			case 6:
				this.mShowRibbonNotification = (CustomToggleButton)target;
				return;
			case 7:
				this.mShowToastNotification = (CustomToggleButton)target;
				return;
			case 8:
				this.mStackPanel = (StackPanel)target;
				return;
			case 9:
				this.mInfoIcon = (CustomPictureBox)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040008C8 RID: 2248
		public static NotificationsSettings Instance;

		// Token: 0x040008C9 RID: 2249
		private string mVmName = "Android";

		// Token: 0x040008CA RID: 2250
		internal ScrollViewer mScroll;

		// Token: 0x040008CB RID: 2251
		internal CustomToggleButton mTbMuteAll;

		// Token: 0x040008CC RID: 2252
		internal CustomCheckbox mCustomNotifications;

		// Token: 0x040008CD RID: 2253
		internal CustomToggleButton mUseInstalledApps;

		// Token: 0x040008CE RID: 2254
		internal CustomToggleButton mShowRibbonNotification;

		// Token: 0x040008CF RID: 2255
		internal CustomToggleButton mShowToastNotification;

		// Token: 0x040008D0 RID: 2256
		internal StackPanel mStackPanel;

		// Token: 0x040008D1 RID: 2257
		internal CustomPictureBox mInfoIcon;

		// Token: 0x040008D2 RID: 2258
		private bool _contentLoaded;
	}
}
