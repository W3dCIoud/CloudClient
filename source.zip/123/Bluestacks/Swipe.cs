﻿using System;
using System.ComponentModel;
using BlueStacks.Common;

// Token: 0x02000015 RID: 21
[Description("Dependent")]
[Serializable]
public class Swipe : IMAction
{
	// Token: 0x17000098 RID: 152
	// (get) Token: 0x06000144 RID: 324 RVA: 0x00002DB7 File Offset: 0x00000FB7
	// (set) Token: 0x06000145 RID: 325 RVA: 0x00010148 File Offset: 0x0000E348
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X1
	{
		get
		{
			return this.mX1;
		}
		set
		{
			this.mX1 = value;
			if (this.Direction == Direction.Up || this.Direction == Direction.Down)
			{
				this.mX2 = this.X1;
				return;
			}
			if (this.Direction == Direction.Left)
			{
				this.mX2 = Math.Round(this.X1 - this.mRadius, 2);
				return;
			}
			if (this.Direction == Direction.Right)
			{
				this.mX2 = Math.Round(this.X1 + this.mRadius, 2);
			}
		}
	}

	// Token: 0x17000099 RID: 153
	// (get) Token: 0x06000146 RID: 326 RVA: 0x00002DBF File Offset: 0x00000FBF
	// (set) Token: 0x06000147 RID: 327 RVA: 0x000101C0 File Offset: 0x0000E3C0
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y1
	{
		get
		{
			return this.mY1;
		}
		set
		{
			this.mY1 = value;
			if (this.Direction == Direction.Left || this.Direction == Direction.Right)
			{
				this.mY2 = this.Y1;
				return;
			}
			if (this.Direction == Direction.Up)
			{
				this.mY2 = Math.Round(this.Y1 - this.mRadius, 2);
				return;
			}
			if (this.Direction == Direction.Down)
			{
				this.mY2 = Math.Round(this.Y1 + this.mRadius, 2);
			}
		}
	}

	// Token: 0x1700009A RID: 154
	// (get) Token: 0x06000148 RID: 328 RVA: 0x00002DC7 File Offset: 0x00000FC7
	// (set) Token: 0x06000149 RID: 329 RVA: 0x00002DCF File Offset: 0x00000FCF
	public double X2
	{
		get
		{
			return this.mX2;
		}
		set
		{
			this.mX2 = value;
			this.CheckDirection();
		}
	}

	// Token: 0x1700009B RID: 155
	// (get) Token: 0x0600014A RID: 330 RVA: 0x00002DDE File Offset: 0x00000FDE
	// (set) Token: 0x0600014B RID: 331 RVA: 0x00002DE6 File Offset: 0x00000FE6
	public double Y2
	{
		get
		{
			return this.mY2;
		}
		set
		{
			this.mY2 = value;
			this.CheckDirection();
		}
	}

	// Token: 0x1700009C RID: 156
	// (get) Token: 0x0600014C RID: 332 RVA: 0x00002DF5 File Offset: 0x00000FF5
	// (set) Token: 0x0600014D RID: 333 RVA: 0x00010238 File Offset: 0x0000E438
	[Description("IMAP_CanvasElementRadiusIMAP_PopupUIElement")]
	[Category("Fields")]
	internal double Radius
	{
		get
		{
			return this.mRadius;
		}
		set
		{
			this.mRadius = value;
			if (this.Direction == Direction.Left)
			{
				this.Y2 = this.Y1;
				this.X2 = Math.Round(this.X1 - value, 2);
				Logger.Debug(string.Concat(new object[]
				{
					"SWIPE_L: X2: ",
					this.X2,
					"...............Y2: ",
					this.Y2
				}));
				return;
			}
			if (this.Direction == Direction.Right)
			{
				this.Y2 = this.Y1;
				this.X2 = Math.Round(this.X1 + value, 2);
				Logger.Debug(string.Concat(new object[]
				{
					"SWIPE_R: X2: ",
					this.X2,
					"...............Y2: ",
					this.Y2
				}));
				return;
			}
			if (this.Direction == Direction.Up)
			{
				this.X2 = this.X1;
				this.Y2 = Math.Round(this.Y1 - value, 2);
				Logger.Debug(string.Concat(new object[]
				{
					"SWIPE_U: X2: ",
					this.X2,
					"...............Y2: ",
					this.Y2
				}));
				return;
			}
			if (this.Direction == Direction.Down)
			{
				this.X2 = this.X1;
				this.Y2 = Math.Round(this.Y1 + value, 2);
				Logger.Debug(string.Concat(new object[]
				{
					"SWIPE_D: X2: ",
					this.X2,
					"...............Y2: ",
					this.Y2
				}));
			}
		}
	}

	// Token: 0x1700009D RID: 157
	// (get) Token: 0x0600014E RID: 334 RVA: 0x00002DFD File Offset: 0x00000FFD
	// (set) Token: 0x0600014F RID: 335 RVA: 0x00002E05 File Offset: 0x00001005
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Speed
	{
		get
		{
			return this.mSpeed;
		}
		set
		{
			this.mSpeed = value;
		}
	}

	// Token: 0x1700009E RID: 158
	// (get) Token: 0x06000150 RID: 336 RVA: 0x00002E0E File Offset: 0x0000100E
	// (set) Token: 0x06000151 RID: 337 RVA: 0x00002E16 File Offset: 0x00001016
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool Hold
	{
		get
		{
			return this.mHold;
		}
		set
		{
			this.mHold = value;
		}
	}

	// Token: 0x1700009F RID: 159
	// (get) Token: 0x06000152 RID: 338 RVA: 0x00002E1F File Offset: 0x0000101F
	// (set) Token: 0x06000153 RID: 339 RVA: 0x00002E27 File Offset: 0x00001027
	[Description("IMAP_PopupUIElementNotCommon")]
	[Category("Fields")]
	public string Key
	{
		get
		{
			return this.mKey;
		}
		set
		{
			this.mKey = value;
		}
	}

	// Token: 0x170000A0 RID: 160
	// (get) Token: 0x06000154 RID: 340 RVA: 0x00002E30 File Offset: 0x00001030
	// (set) Token: 0x06000155 RID: 341 RVA: 0x00002E38 File Offset: 0x00001038
	[Description("IMAP_PopupUIElementNotCommon")]
	[Category("Fields")]
	public string Key_alt1
	{
		get
		{
			return this.mKey_1;
		}
		set
		{
			this.mKey_1 = value;
		}
	}

	// Token: 0x06000156 RID: 342 RVA: 0x000103E4 File Offset: 0x0000E5E4
	private void CheckDirection()
	{
		if (this.X1 != this.X2)
		{
			if (this.Y1 == this.Y2)
			{
				if (this.X1 > this.X2)
				{
					this.Direction = Direction.Left;
					this.mRadius = Math.Round(this.X1 - this.X2, 2);
					return;
				}
				this.Direction = Direction.Right;
				this.mRadius = Math.Round(this.X2 - this.X1, 2);
			}
			return;
		}
		if (this.Y1 > this.Y2)
		{
			this.Direction = Direction.Up;
			this.mRadius = Math.Round(this.Y1 - this.Y2, 2);
			return;
		}
		this.Direction = Direction.Down;
		this.mRadius = Math.Round(this.Y2 - this.Y1, 2);
	}

	// Token: 0x04000095 RID: 149
	private double mX1 = -1.0;

	// Token: 0x04000096 RID: 150
	private double mY1 = -1.0;

	// Token: 0x04000097 RID: 151
	private double mX2;

	// Token: 0x04000098 RID: 152
	private double mY2;

	// Token: 0x04000099 RID: 153
	private double mRadius = 10.0;

	// Token: 0x0400009A RID: 154
	private double mSpeed = 200.0;

	// Token: 0x0400009B RID: 155
	private bool mHold;

	// Token: 0x0400009C RID: 156
	private string mKey;

	// Token: 0x0400009D RID: 157
	private string mKey_1;
}
