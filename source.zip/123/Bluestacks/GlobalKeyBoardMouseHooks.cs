﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Threading;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001F8 RID: 504
	internal class GlobalKeyBoardMouseHooks
	{
		// Token: 0x06001177 RID: 4471
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern IntPtr SetWindowsHookEx(int idHook, GlobalKeyBoardMouseHooks.LowLevelMouseProc lpfn, IntPtr hMod, uint dwThreadId);

		// Token: 0x06001178 RID: 4472
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		[return: MarshalAs(UnmanagedType.Bool)]
		private static extern bool UnhookWindowsHookEx(IntPtr hhk);

		// Token: 0x06001179 RID: 4473
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

		// Token: 0x0600117A RID: 4474
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern IntPtr GetModuleHandle(string lpModuleName);

		// Token: 0x0600117B RID: 4475
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern IntPtr SetWindowsHookEx(int idHook, GlobalKeyBoardMouseHooks.LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

		// Token: 0x0600117C RID: 4476 RVA: 0x0006CCB8 File Offset: 0x0006AEB8
		private static IntPtr SetHook(GlobalKeyBoardMouseHooks.LowLevelMouseProc proc)
		{
			IntPtr result;
			using (Process currentProcess = Process.GetCurrentProcess())
			{
				using (ProcessModule mainModule = currentProcess.MainModule)
				{
					result = GlobalKeyBoardMouseHooks.SetWindowsHookEx(14, proc, GlobalKeyBoardMouseHooks.GetModuleHandle(mainModule.ModuleName), 0U);
				}
			}
			return result;
		}

		// Token: 0x0600117D RID: 4477 RVA: 0x0006CD1C File Offset: 0x0006AF1C
		private static IntPtr SetHook(GlobalKeyBoardMouseHooks.LowLevelKeyboardProc proc)
		{
			IntPtr result;
			using (Process currentProcess = Process.GetCurrentProcess())
			{
				using (ProcessModule mainModule = currentProcess.MainModule)
				{
					result = GlobalKeyBoardMouseHooks.SetWindowsHookEx(13, proc, GlobalKeyBoardMouseHooks.GetModuleHandle(mainModule.ModuleName), 0U);
				}
			}
			return result;
		}

		// Token: 0x0600117E RID: 4478 RVA: 0x0006CD80 File Offset: 0x0006AF80
		internal static void SetMouseMoveHook()
		{
			try
			{
				if (GlobalKeyBoardMouseHooks.mMouseHookId == IntPtr.Zero)
				{
					GlobalKeyBoardMouseHooks.mMouseHookId = GlobalKeyBoardMouseHooks.SetHook(GlobalKeyBoardMouseHooks.mMouseProc);
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Exception setting global mouse hook" + ex.ToString());
			}
		}

		// Token: 0x0600117F RID: 4479 RVA: 0x0006CDD8 File Offset: 0x0006AFD8
		internal static void SetBossKeyHook()
		{
			try
			{
				GlobalKeyBoardMouseHooks.SetKey(RegistryManager.Instance.BossKey);
				if (GlobalKeyBoardMouseHooks.mKeyboardHookID == IntPtr.Zero)
				{
					GlobalKeyBoardMouseHooks.mKeyboardHookID = GlobalKeyBoardMouseHooks.SetHook(GlobalKeyBoardMouseHooks.mKeyboardProc);
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Exception setting global hook" + ex.ToString());
			}
		}

		// Token: 0x06001180 RID: 4480 RVA: 0x0006CE40 File Offset: 0x0006B040
		internal static void SetKey(string key)
		{
			if (string.IsNullOrEmpty(key))
			{
				Logger.Warning("Cannot set an empty key");
				return;
			}
			string[] array = key.Split(new char[]
			{
				'+',
				' '
			}, StringSplitOptions.RemoveEmptyEntries);
			string bossKey = array[array.Length - 1];
			GlobalKeyBoardMouseHooks.sKey = IMAPKeys.mDictKeys.First((KeyValuePair<Key, string> x) => x.Value == bossKey).Key.ToString();
			GlobalKeyBoardMouseHooks.sIsControlUsedInBossKey = (GlobalKeyBoardMouseHooks.sIsAltUsedInBossKey = (GlobalKeyBoardMouseHooks.sIsShiftUsedInBossKey = false));
			foreach (string text in array)
			{
				if (text.Equals("Ctrl"))
				{
					GlobalKeyBoardMouseHooks.sIsControlUsedInBossKey = true;
				}
				else if (text.Equals("Alt"))
				{
					GlobalKeyBoardMouseHooks.sIsAltUsedInBossKey = true;
				}
				else if (text.Equals("Shift"))
				{
					GlobalKeyBoardMouseHooks.sIsShiftUsedInBossKey = true;
				}
			}
		}

		// Token: 0x06001181 RID: 4481 RVA: 0x0000C69C File Offset: 0x0000A89C
		internal static void UnsetKey()
		{
			GlobalKeyBoardMouseHooks.sKey = string.Empty;
			GlobalKeyBoardMouseHooks.sIsControlUsedInBossKey = false;
			GlobalKeyBoardMouseHooks.sIsAltUsedInBossKey = false;
			GlobalKeyBoardMouseHooks.sIsShiftUsedInBossKey = false;
		}

		// Token: 0x06001182 RID: 4482 RVA: 0x0000C6BA File Offset: 0x0000A8BA
		internal static void UnHookGlobalHooks()
		{
			GlobalKeyBoardMouseHooks.UnhookWindowsHookEx(GlobalKeyBoardMouseHooks.mKeyboardHookID);
			GlobalKeyBoardMouseHooks.mKeyboardHookID = IntPtr.Zero;
			GlobalKeyBoardMouseHooks.UnhookGlobalMouseHooks();
		}

		// Token: 0x06001183 RID: 4483 RVA: 0x0000C6D6 File Offset: 0x0000A8D6
		internal static void UnhookGlobalMouseHooks()
		{
			if (GlobalKeyBoardMouseHooks.mMouseHookId != IntPtr.Zero)
			{
				GlobalKeyBoardMouseHooks.UnhookWindowsHookEx(GlobalKeyBoardMouseHooks.mMouseHookId);
				GlobalKeyBoardMouseHooks.mMouseHookId = IntPtr.Zero;
			}
		}

		// Token: 0x06001184 RID: 4484 RVA: 0x0006CF2C File Offset: 0x0006B12C
		private static IntPtr KeyboardHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
		{
			try
			{
				if (GlobalKeyBoardMouseHooks.sIsEnableKeyboardHookLogging)
				{
					Logger.Info(string.Concat(new object[]
					{
						"Keyboard hook ..",
						nCode,
						"..",
						wParam.ToString(),
						"..",
						lParam.ToString()
					}));
				}
				MainWindow window = BlueStacksUIUtils.ActivatedWindow;
				if (nCode >= 0 && (wParam == (IntPtr)256 || wParam == (IntPtr)260 || wParam == (IntPtr)257))
				{
					int num = Marshal.ReadInt32(lParam);
					Logger.Debug(string.Concat(new object[]
					{
						"Keyboard hook ..",
						num,
						"..",
						GlobalKeyBoardMouseHooks.sKey
					}));
					if (wParam == (IntPtr)256 || wParam == (IntPtr)260)
					{
						if (!string.IsNullOrEmpty(GlobalKeyBoardMouseHooks.sKey) && num == (int)((Keys)Enum.Parse(typeof(Keys), GlobalKeyBoardMouseHooks.sKey, false)) && (wParam == (IntPtr)256 || wParam == (IntPtr)260))
						{
							if (GlobalKeyBoardMouseHooks.sIsControlUsedInBossKey == (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl)) && GlobalKeyBoardMouseHooks.sIsAltUsedInBossKey == (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt)) && GlobalKeyBoardMouseHooks.sIsShiftUsedInBossKey == (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift)))
							{
								ThreadPool.QueueUserWorkItem(delegate(object obj)
								{
									if (BlueStacksUIUtils.DictWindows.Values.Count > 0)
									{
										BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>()[0].Dispatcher.Invoke(new Action(delegate()
										{
											try
											{
												GlobalKeyBoardMouseHooks.mIsHidden = !GlobalKeyBoardMouseHooks.mIsHidden;
												BlueStacksUIUtils.HideUnhideBlueStacks(GlobalKeyBoardMouseHooks.mIsHidden);
											}
											catch
											{
											}
										}), new object[0]);
									}
								});
								return (IntPtr)1;
							}
						}
						else if (window != null && (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl)) && (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt)))
						{
							if (num >= 96 && num <= 105)
							{
								num -= 48;
							}
							Key key = KeyInterop.KeyFromVirtualKey(num);
							string vkString = IMAPKeys.GetStringForFile(key);
							if (MainWindow.sMacroMapping.Keys.Contains(vkString))
							{
								Action <>9__3;
								ThreadPool.QueueUserWorkItem(delegate(object obj)
								{
									try
									{
										Dispatcher dispatcher = window.Dispatcher;
										Action method;
										if ((method = <>9__3) == null)
										{
											method = (<>9__3 = delegate()
											{
												if (window.mSidebar.GetElementFromTag("sidebar_macro") != null && window.mSidebar.GetElementFromTag("sidebar_macro").Visibility == Visibility.Visible && window.mSidebar.GetElementFromTag("sidebar_macro").IsEnabled)
												{
													if (window.mIsOperationRecorderActive)
													{
														window.ShowToast(LocaleStrings.GetLocalizedString("STRING_STOP_RECORDING_FIRST", false));
														return;
													}
													if (window.mIsMacroPlaying)
													{
														CustomMessageWindow customMessageWindow = new CustomMessageWindow();
														BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_BLUESTACKS", "");
														customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
														BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_STOP_MACRO_SCRIPT", "");
														customMessageWindow.Owner = window;
														customMessageWindow.ShowDialog();
														return;
													}
													try
													{
														string path = Path.Combine(RegistryStrings.OperationsScriptFolder, MainWindow.sMacroMapping[vkString] + ".json");
														if (File.Exists(path))
														{
															OperationsRecord operationsRecord = JsonConvert.DeserializeObject<OperationsRecord>(File.ReadAllText(path), Utils.GetSerializerSettings());
															operationsRecord.Name = MainWindow.sMacroMapping[vkString];
															window.mCommonHandler.FullMacroScriptPlayHandler(operationsRecord);
															ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_play", "shortcut_keys", null, null, null, null);
														}
														return;
													}
													catch (Exception ex)
													{
														Logger.Error("Exception in macro play with shortcut: " + ex.ToString());
														return;
													}
												}
												Logger.Info("Macro not enabled for the current package: " + window.StaticComponents.mSelectedTabButton.PackageName);
											});
										}
										dispatcher.Invoke(method, new object[0]);
									}
									catch
									{
									}
								});
							}
						}
					}
				}
			}
			catch
			{
			}
			return GlobalKeyBoardMouseHooks.CallNextHookEx(GlobalKeyBoardMouseHooks.mKeyboardHookID, nCode, wParam, lParam);
		}

		// Token: 0x06001185 RID: 4485 RVA: 0x0006D1CC File Offset: 0x0006B3CC
		private static IntPtr MouseHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
		{
			return GlobalKeyBoardMouseHooks.CallNextHookEx(GlobalKeyBoardMouseHooks.mMouseHookId, nCode, wParam, lParam);
		}

		// Token: 0x06001186 RID: 4486 RVA: 0x0000C6FE File Offset: 0x0000A8FE
		private static void DisableAll()
		{
			GlobalKeyBoardMouseHooks.LControlKey = false;
		}

		// Token: 0x04000BF7 RID: 3063
		private static bool mIsHidden = false;

		// Token: 0x04000BF8 RID: 3064
		private const int WH_KEYBOARD_LL = 13;

		// Token: 0x04000BF9 RID: 3065
		private const int WM_KEYDOWN = 256;

		// Token: 0x04000BFA RID: 3066
		private const int WM_KEYUP = 257;

		// Token: 0x04000BFB RID: 3067
		private const int WM_SYSKEYDOWN = 260;

		// Token: 0x04000BFC RID: 3068
		private const int WM_SYSKEYUP = 261;

		// Token: 0x04000BFD RID: 3069
		private static readonly GlobalKeyBoardMouseHooks.LowLevelKeyboardProc mKeyboardProc = new GlobalKeyBoardMouseHooks.LowLevelKeyboardProc(GlobalKeyBoardMouseHooks.KeyboardHookCallback);

		// Token: 0x04000BFE RID: 3070
		private static IntPtr mKeyboardHookID = IntPtr.Zero;

		// Token: 0x04000BFF RID: 3071
		private static string sKey = null;

		// Token: 0x04000C00 RID: 3072
		private static bool sIsControlUsedInBossKey = false;

		// Token: 0x04000C01 RID: 3073
		private static bool sIsAltUsedInBossKey = false;

		// Token: 0x04000C02 RID: 3074
		private static bool sIsShiftUsedInBossKey = false;

		// Token: 0x04000C03 RID: 3075
		internal static bool sIsEnableKeyboardHookLogging = false;

		// Token: 0x04000C04 RID: 3076
		private static bool LControlKey = false;

		// Token: 0x04000C05 RID: 3077
		private static GlobalKeyBoardMouseHooks.LowLevelMouseProc mMouseProc = new GlobalKeyBoardMouseHooks.LowLevelMouseProc(GlobalKeyBoardMouseHooks.MouseHookCallback);

		// Token: 0x04000C06 RID: 3078
		private static IntPtr mMouseHookId = IntPtr.Zero;

		// Token: 0x04000C07 RID: 3079
		private const int WH_MOUSE_LL = 14;

		// Token: 0x020001F9 RID: 505
		// (Invoke) Token: 0x0600118A RID: 4490
		private delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);

		// Token: 0x020001FA RID: 506
		private enum MouseMessages
		{
			// Token: 0x04000C09 RID: 3081
			WM_LBUTTONDOWN = 513,
			// Token: 0x04000C0A RID: 3082
			WM_LBUTTONUP,
			// Token: 0x04000C0B RID: 3083
			WM_MOUSEMOVE = 512,
			// Token: 0x04000C0C RID: 3084
			WM_MOUSEWHEEL = 522,
			// Token: 0x04000C0D RID: 3085
			WM_RBUTTONDOWN = 516,
			// Token: 0x04000C0E RID: 3086
			WM_RBUTTONUP
		}

		// Token: 0x020001FB RID: 507
		private struct MSLLHOOKSTRUCT
		{
			// Token: 0x04000C0F RID: 3087
			public POINT pt;

			// Token: 0x04000C10 RID: 3088
			public uint mouseData;

			// Token: 0x04000C11 RID: 3089
			public uint flags;

			// Token: 0x04000C12 RID: 3090
			public uint time;

			// Token: 0x04000C13 RID: 3091
			public IntPtr dwExtraInfo;
		}

		// Token: 0x020001FC RID: 508
		// (Invoke) Token: 0x0600118E RID: 4494
		private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
	}
}
