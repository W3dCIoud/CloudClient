﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;
using Xilium.CefGlue.WPF;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000F7 RID: 247
	public partial class DMMRecommendedWindow : CustomWindow
	{
		// Token: 0x06000A03 RID: 2563 RVA: 0x00046B0C File Offset: 0x00044D0C
		public DMMRecommendedWindow(MainWindow window)
		{
			this.InitializeComponent();
			base.IsShowGLWindow = true;
			this.ParentWindow = window;
			base.Owner = this.ParentWindow;
			base.Topmost = false;
			base.Left = this.ParentWindow.Left + this.ParentWindow.ActualWidth;
			base.Top = this.ParentWindow.Top;
			base.Height = this.ParentWindow.Height;
			base.Width = (base.Height - (double)this.ParentWindow.ParentWindowHeightDiff) * 9.0 / 16.0 + (double)this.ParentWindow.ParentWindowWidthDiff;
			base.Closing += this.RecommendedWindow_Closing;
			base.IsVisibleChanged += this.RecommendedWindow_IsVisibleChanged;
		}

		// Token: 0x06000A04 RID: 2564 RVA: 0x0000836F File Offset: 0x0000656F
		private void RecommendedWindow_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (base.Visibility == Visibility.Visible)
			{
				this.ParentWindow.mDmmBottomBar.mRecommendedWindowBtn.ImageName = "recommend_click";
				return;
			}
			this.ParentWindow.mDmmBottomBar.mRecommendedWindowBtn.ImageName = "recommend";
		}

		// Token: 0x06000A05 RID: 2565 RVA: 0x000083AE File Offset: 0x000065AE
		private void RecommendedWindow_Closing(object sender, CancelEventArgs e)
		{
			this.ParentWindow.mDMMRecommendedWindow.mRecommendedBrowserControl.DisposeBrowser();
			this.ParentWindow.mDMMRecommendedWindow = null;
		}

		// Token: 0x06000A06 RID: 2566 RVA: 0x00046BE4 File Offset: 0x00044DE4
		public void Init(string url)
		{
			this.mRecommendedBrowserControl.mUrl = url;
			this.mRecommendedBrowserControl.mGrid = new Grid();
			this.mRecommendedBrowserControl.Content = this.mRecommendedBrowserControl.mGrid;
			this.mRecommendedBrowserControl.CreateNewBrowser();
			this.mRecommendedBrowserControl.ProcessMessageRecieved += new ProcessMessageEventHandler(this.MRecommendedBrowserControl_ProcessMessageRecieved);
		}

		// Token: 0x06000A07 RID: 2567 RVA: 0x00046C48 File Offset: 0x00044E48
		public void UpdateSize()
		{
			base.Top = this.ParentWindow.Top;
			base.Left = this.ParentWindow.Left + this.ParentWindow.ActualWidth;
			base.Height = this.ParentWindow.Height;
			base.Width = (this.ParentWindow.Height - (double)this.ParentWindow.ParentWindowHeightDiff) * 9.0 / 16.0 + (double)this.ParentWindow.ParentWindowWidthDiff;
		}

		// Token: 0x06000A08 RID: 2568 RVA: 0x000083D1 File Offset: 0x000065D1
		public void UpdateLocation()
		{
			base.Top = this.ParentWindow.Top;
			base.Left = this.ParentWindow.Left + this.ParentWindow.ActualWidth;
		}

		// Token: 0x06000A09 RID: 2569 RVA: 0x00004BF2 File Offset: 0x00002DF2
		private void MRecommendedBrowserControl_ProcessMessageRecieved(object sender, ProcessMessageEventArgs e)
		{
		}

		// Token: 0x06000A0A RID: 2570 RVA: 0x00046CD4 File Offset: 0x00044ED4
		private void mCloseBtn_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mIsDMMRecommendedWindowOpen = false;
			base.Hide();
			InteropWindow.ShowWindow(this.ParentWindow.Handle, 9);
			if (!this.ParentWindow.Topmost)
			{
				this.ParentWindow.Topmost = true;
				this.ParentWindow.Topmost = false;
			}
		}

		// Token: 0x0400077B RID: 1915
		private MainWindow ParentWindow;
	}
}
