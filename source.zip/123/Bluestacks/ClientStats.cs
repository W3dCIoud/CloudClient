﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200014D RID: 333
	internal class ClientStats
	{
		// Token: 0x170001D6 RID: 470
		// (get) Token: 0x06000D06 RID: 3334 RVA: 0x0005628C File Offset: 0x0005448C
		internal static Dictionary<string, string> GetCommonData
		{
			get
			{
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary.Add("guid", RegistryManager.Instance.UserGuid);
				dictionary.Add("engine_guid", RegistryManager.Instance.UserGuid);
				dictionary.Add("engine_ver", RegistryManager.Instance.Version);
				dictionary.Add("client_ver", RegistryManager.Instance.ClientVersion);
				dictionary.Add("oem", Oem.Instance.OEM);
				dictionary.Add("campaign_md5", RegistryManager.Instance.CampaignMD5);
				dictionary.Add("partner", RegistryManager.Instance.Partner);
				dictionary.Add("lang", RegistryManager.Instance.UserSelectedLocale);
				dictionary.Add("email", RegistryManager.Instance.RegisteredEmail);
				dictionary.Add("engine_mode", RegistryManager.Instance.DeviceCaps);
				string campaignJson = RegistryManager.Instance.CampaignJson;
				if (!string.IsNullOrEmpty(campaignJson))
				{
					try
					{
						JObject jobject = JObject.Parse(campaignJson);
						dictionary.Add("campaign_name", jobject["campaign_name"].ToString());
						return dictionary;
					}
					catch
					{
						dictionary.Add("campaign_name", "");
						return dictionary;
					}
				}
				dictionary.Add("campaign_name", "");
				return dictionary;
			}
		}

		// Token: 0x06000D07 RID: 3335 RVA: 0x000563DC File Offset: 0x000545DC
		internal static void SendClientStatsAsync(string op, string status, string uri, string package = "", string errorCode = "", string vmName = "")
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					ClientStats.SendStatsSync(op, status, uri, package, errorCode, vmName);
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to send stats for uri : " + uri + ". Reason : " + ex.ToString());
				}
			});
		}

		// Token: 0x06000D08 RID: 3336 RVA: 0x0005642C File Offset: 0x0005462C
		internal static void SendFrontendClickStats(string eventType, string keyword, string app_loc, string app_pkg, string is_installed, string app_position, string app_rank, string apps_recommendation_obj)
		{
			Dictionary<string, string> getCommonData = ClientStats.GetCommonData;
			getCommonData.Add("event", eventType);
			getCommonData.Add("keyword", keyword);
			getCommonData.Add("app_loc", app_loc);
			getCommonData.Add("app_pkg", app_pkg);
			getCommonData.Add("is_installed", is_installed);
			getCommonData.Add("app_position", app_position);
			getCommonData.Add("app_rank", app_rank);
			getCommonData.Add("apps_recommendation_obj", apps_recommendation_obj);
			ClientStats.SendStatsAsync(string.Format("{0}/bs3/stats/{1}", RegistryManager.Instance.Host, "frontend_click_stats"), getCommonData, null, "");
		}

		// Token: 0x06000D09 RID: 3337 RVA: 0x000564C8 File Offset: 0x000546C8
		internal static void SendStatsSync(string op, string status, string uri, string package, string errorCode = "", string vmname = "")
		{
			Dictionary<string, string> data = ClientStats.GetCommonData;
			data.Add("op", op);
			data.Add("status", status);
			string value;
			if (uri != "engine_activity")
			{
				value = "4.140.12.1002";
			}
			else
			{
				value = RegistryManager.Instance.Version;
			}
			data.Add("version", value);
			if (uri == "emulator_activity")
			{
				Dictionary<string, string> resolutionData = BlueStacksUIUtils.GetResolutionData();
				try
				{
					resolutionData.ToList<KeyValuePair<string, string>>().ForEach(delegate(KeyValuePair<string, string> kvp)
					{
						data[kvp.Key] = kvp.Value;
					});
				}
				catch (Exception ex)
				{
					Logger.Error("Merge dictionary failed. Ex : " + ex.ToString());
				}
			}
			if (errorCode != "")
			{
				data.Add("error_code", errorCode);
			}
			if (!string.IsNullOrEmpty(package))
			{
				data.Add("app_pkg", package);
			}
			ClientStats.SendStats(string.Format("{0}/bs3/stats/{1}", string.IsNullOrEmpty(ClientStats.sDevUrl) ? RegistryManager.Instance.Host : ClientStats.sDevUrl, uri), data, null, vmname);
		}

		// Token: 0x06000D0A RID: 3338 RVA: 0x0000A149 File Offset: 0x00008349
		internal static void SendGPlayClickStats(Dictionary<string, string> clientData)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					Dictionary<string, string> getCommonData = ClientStats.GetCommonData;
					if (clientData != null)
					{
						foreach (KeyValuePair<string, string> keyValuePair in clientData)
						{
							getCommonData.Add(keyValuePair.Key, keyValuePair.Value);
						}
					}
					ClientStats.SendStats(string.Format("{0}/bs3/stats/gplay_click_stats", string.IsNullOrEmpty(ClientStats.sDevUrl) ? RegistryManager.Instance.Host : ClientStats.sDevUrl), getCommonData, null, "");
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to send gplay stats... Err : " + ex.ToString());
				}
			});
		}

		// Token: 0x06000D0B RID: 3339 RVA: 0x00056604 File Offset: 0x00054804
		internal static void SendMiscellaneousStatsAsync(string tag, string arg1, string arg2, string arg3, string arg4, string arg5, string arg6 = null, string arg7 = null, string arg8 = null)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					Logger.Info("Sending miscellaneous Stats for tag : " + tag);
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					dictionary.Add("tag", tag);
					dictionary.Add("arg1", arg1);
					dictionary.Add("arg2", arg2);
					dictionary.Add("arg3", arg3);
					dictionary.Add("arg4", arg4);
					dictionary.Add("arg5", arg5);
					dictionary.Add("arg6", arg6);
					dictionary.Add("arg7", arg7);
					dictionary.Add("arg8", arg8);
					ClientStats.SendStats(string.Format("{0}/{1}", RegistryManager.Instance.Host, "/stats/miscellaneousstats"), dictionary, null, "");
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in sending miscellaneous stats async err : " + ex.ToString());
				}
			});
		}

		// Token: 0x06000D0C RID: 3340 RVA: 0x0000A168 File Offset: 0x00008368
		internal static void SendKeyMappingUIStatsAsync(string eventtype, string packageName, string extraInfo)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					Logger.Info("Sending KeyMappingUI Stats");
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					dictionary.Add("guid", RegistryManager.Instance.UserGuid);
					dictionary.Add("prod_ver", RegistryManager.Instance.ClientVersion);
					dictionary.Add("oem", RegistryManager.Instance.Oem);
					dictionary.Add("app_pkg", packageName);
					dictionary.Add("event_type", eventtype);
					dictionary.Add("email", RegistryManager.Instance.RegisteredEmail);
					dictionary.Add("extra_info", extraInfo);
					dictionary.Add("locale", RegistryManager.Instance.UserSelectedLocale);
					ClientStats.SendStats(string.Format("{0}/{1}", RegistryManager.Instance.Host, "/stats/keymappinguistats"), dictionary, null, "");
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in sending miscellaneous stats async err : " + ex.ToString());
				}
			});
		}

		// Token: 0x06000D0D RID: 3341 RVA: 0x0005666C File Offset: 0x0005486C
		internal static void SendLocalQuitPopupStatsAsync(string tag, string eventType)
		{
			Logger.Debug("Sending LocalQuitPopupStats for {0}", new object[]
			{
				eventType
			});
			string userGuid = RegistryManager.Instance.UserGuid;
			string clientVersion = RegistryManager.Instance.ClientVersion;
			string campaignMD = RegistryManager.Instance.CampaignMD5;
			ClientStats.SendMiscellaneousStatsAsync(tag, eventType, userGuid, clientVersion, campaignMD, "", null, null, null);
		}

		// Token: 0x06000D0E RID: 3342 RVA: 0x0000A195 File Offset: 0x00008395
		internal static void SendBluestacksUpdaterUIStatsAsync(string eventName, string comment = "")
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					Logger.Info("Sending Bluestacks Updater UI Stats");
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					dictionary.Add("event", eventName);
					dictionary.Add("install_id", RegistryManager.Instance.InstallID);
					dictionary.Add("engine_version", RegistryManager.Instance.Version);
					dictionary.Add("client_version", RegistryManager.Instance.ClientVersion);
					dictionary.Add("os", Profile.OS);
					string value = InstallerArchitectures.AMD64;
					if (!SystemUtils.IsOs64Bit())
					{
						value = InstallerArchitectures.X86;
					}
					dictionary.Add("installer_arch", value);
					dictionary.Add("guid", RegistryManager.Instance.UserGuid);
					dictionary.Add("oem", Oem.Instance.OEM);
					dictionary.Add("campaign_hash", RegistryManager.Instance.CampaignMD5);
					dictionary.Add("campaign_name", RegistryManager.Instance.CampaignName);
					dictionary.Add("locale", RegistryManager.Instance.UserSelectedLocale);
					dictionary.Add("comment", comment);
					dictionary.Add("installation_type", RegistryManager.Instance.InstallationType.ToString());
					dictionary.Add("gaming_pkg_name", RegistryManager.Instance.InstallerPkgName);
					ClientStats.SendStats(string.Format("{0}{1}", RegistryManager.Instance.Host, "/bs3/stats/unified_install_stats"), dictionary, null, "");
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in sending miscellaneous stats async err : " + ex.ToString());
				}
			});
		}

		// Token: 0x06000D0F RID: 3343 RVA: 0x000566C0 File Offset: 0x000548C0
		internal static void SendPopupBrowserStatsInMiscASync(string eventType, string url)
		{
			ClientStats.SendMiscellaneousStatsAsync("PopupBrowser", RegistryManager.Instance.UserGuid, eventType, url, RegistryManager.Instance.RegisteredEmail, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, null, null);
		}

		// Token: 0x06000D10 RID: 3344 RVA: 0x0000A1BB File Offset: 0x000083BB
		internal static void SendGeneralStats(string op, Dictionary<string, string> sourceData)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					Dictionary<string, string> getCommonData = ClientStats.GetCommonData;
					getCommonData.Add("op", op);
					if (sourceData != null)
					{
						foreach (KeyValuePair<string, string> keyValuePair in sourceData)
						{
							getCommonData.Add(keyValuePair.Key, keyValuePair.Value);
						}
					}
					getCommonData.Add("os_ver", string.Format("{0}.{1}", Environment.OSVersion.Version.Major, Environment.OSVersion.Version.Minor));
					ClientStats.SendStats(string.Format("{0}/bs3/stats/general_json", string.IsNullOrEmpty(ClientStats.sDevUrl) ? RegistryManager.Instance.Host : ClientStats.sDevUrl), getCommonData, null, "");
				}
				catch (Exception ex)
				{
					Logger.Info("Failed to send general stat for op : " + op + "...Err : " + ex.ToString());
				}
			});
		}

		// Token: 0x06000D11 RID: 3345 RVA: 0x0000A1E1 File Offset: 0x000083E1
		internal static void SendStatsAsync(string url, Dictionary<string, string> data, Dictionary<string, string> headers = null, string contentType = "")
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					ClientStats.SendStats(url, data, headers, "");
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to send stats for uri : " + url + ". Reason : " + ex.ToString());
				}
			});
		}

		// Token: 0x06000D12 RID: 3346 RVA: 0x0000A20E File Offset: 0x0000840E
		internal static void SendPromotionAppClickStatsAsync(Dictionary<string, string> appData, string uri)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				Dictionary<string, string> getCommonData = ClientStats.GetCommonData;
				foreach (KeyValuePair<string, string> keyValuePair in appData)
				{
					getCommonData.Add(keyValuePair.Key, keyValuePair.Value);
				}
				ClientStats.SendStats(string.Format("{0}/bs3/stats/{1}", string.IsNullOrEmpty(ClientStats.sDevUrl) ? RegistryManager.Instance.Host : ClientStats.sDevUrl, uri), getCommonData, null, "");
			});
		}

		// Token: 0x06000D13 RID: 3347 RVA: 0x00056704 File Offset: 0x00054904
		internal static void SendStats(string url, Dictionary<string, string> data, Dictionary<string, string> headers = null, string vmname = "")
		{
			try
			{
				BstHttpClient.Post(url, data, headers, false, vmname, 0, 1, 0, false);
			}
			catch (Exception ex)
			{
				Logger.Info("Failed to send stats for : " + url + ". Reason : " + ex.ToString());
			}
		}

		// Token: 0x04000962 RID: 2402
		private static string sDevUrl = RegistryManager.Instance.BGPDevUrl;
	}
}
