﻿using System;
using System.Collections.Generic;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

// Token: 0x0200001B RID: 27
[Serializable]
public class IMControlScheme
{
	// Token: 0x170000CA RID: 202
	// (get) Token: 0x060001B7 RID: 439 RVA: 0x00003246 File Offset: 0x00001446
	// (set) Token: 0x060001B8 RID: 440 RVA: 0x00003261 File Offset: 0x00001461
	public List<IMAction> GameControls
	{
		get
		{
			if (this.mGameControls == null)
			{
				this.mGameControls = new List<IMAction>();
			}
			return this.mGameControls;
		}
		set
		{
			this.mGameControls = value;
		}
	}

	// Token: 0x170000CB RID: 203
	// (get) Token: 0x060001B9 RID: 441 RVA: 0x0000326A File Offset: 0x0000146A
	// (set) Token: 0x060001BA RID: 442 RVA: 0x00003285 File Offset: 0x00001485
	public List<JObject> Images
	{
		get
		{
			if (this.mImages == null)
			{
				this.mImages = new List<JObject>();
			}
			return this.mImages;
		}
		set
		{
			this.mImages = value;
		}
	}

	// Token: 0x170000CC RID: 204
	// (get) Token: 0x060001BB RID: 443 RVA: 0x0000328E File Offset: 0x0000148E
	// (set) Token: 0x060001BC RID: 444 RVA: 0x00003296 File Offset: 0x00001496
	public string Name
	{
		get
		{
			return this.mName;
		}
		set
		{
			this.mName = value;
		}
	}

	// Token: 0x170000CD RID: 205
	// (get) Token: 0x060001BD RID: 445 RVA: 0x0000329F File Offset: 0x0000149F
	// (set) Token: 0x060001BE RID: 446 RVA: 0x000032A7 File Offset: 0x000014A7
	public bool BuiltIn
	{
		get
		{
			return this.mIsBuiltIn;
		}
		set
		{
			this.mIsBuiltIn = value;
		}
	}

	// Token: 0x170000CE RID: 206
	// (get) Token: 0x060001BF RID: 447 RVA: 0x000032B0 File Offset: 0x000014B0
	// (set) Token: 0x060001C0 RID: 448 RVA: 0x000032B8 File Offset: 0x000014B8
	public bool Selected
	{
		get
		{
			return this.mIsSelected;
		}
		set
		{
			this.mIsSelected = value;
		}
	}

	// Token: 0x170000CF RID: 207
	// (get) Token: 0x060001C1 RID: 449 RVA: 0x000032C1 File Offset: 0x000014C1
	// (set) Token: 0x060001C2 RID: 450 RVA: 0x000032C9 File Offset: 0x000014C9
	public bool IsBookMarked
	{
		get
		{
			return this.mIsBookMarked;
		}
		set
		{
			this.mIsBookMarked = value;
		}
	}

	// Token: 0x170000D0 RID: 208
	// (get) Token: 0x060001C3 RID: 451 RVA: 0x000032D2 File Offset: 0x000014D2
	public string KeyboardLayout
	{
		get
		{
			return InteropWindow.MapLayoutName(null);
		}
	}

	// Token: 0x060001C4 RID: 452 RVA: 0x00010BB8 File Offset: 0x0000EDB8
	public IMControlScheme DeepCopy()
	{
		IMControlScheme imcontrolScheme = (IMControlScheme)base.MemberwiseClone();
		List<IMAction> gameControls = this.GameControls;
		imcontrolScheme.GameControls = ((gameControls != null) ? gameControls.DeepCopy<List<IMAction>>() : null);
		imcontrolScheme.Images = this.Images.ConvertAll<JObject>((JObject jt) => (JObject)((jt != null) ? jt.DeepClone() : null));
		return imcontrolScheme;
	}

	// Token: 0x040000CB RID: 203
	private List<IMAction> mGameControls;

	// Token: 0x040000CC RID: 204
	private List<JObject> mImages;

	// Token: 0x040000CD RID: 205
	private string mName;

	// Token: 0x040000CE RID: 206
	private bool mIsBuiltIn;

	// Token: 0x040000CF RID: 207
	private bool mIsSelected;

	// Token: 0x040000D0 RID: 208
	private bool mIsBookMarked;
}
