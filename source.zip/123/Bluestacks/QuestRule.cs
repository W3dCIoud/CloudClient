﻿using System;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000123 RID: 291
	[JsonObject(MemberSerialization.OptIn)]
	public class QuestRule
	{
		// Token: 0x170001A1 RID: 417
		// (get) Token: 0x06000B71 RID: 2929 RVA: 0x00008F4E File Offset: 0x0000714E
		// (set) Token: 0x06000B72 RID: 2930 RVA: 0x00008F56 File Offset: 0x00007156
		[JsonProperty("rule_id")]
		public string RuleId
		{
			get
			{
				return this.mRuleId;
			}
			set
			{
				this.mRuleId = value;
			}
		}

		// Token: 0x170001A2 RID: 418
		// (get) Token: 0x06000B73 RID: 2931 RVA: 0x00008F5F File Offset: 0x0000715F
		// (set) Token: 0x06000B74 RID: 2932 RVA: 0x00008F67 File Offset: 0x00007167
		[JsonProperty("app_pkg", NullValueHandling = NullValueHandling.Ignore)]
		public string AppPackage
		{
			get
			{
				return this.mAppPackage;
			}
			set
			{
				this.mAppPackage = value;
			}
		}

		// Token: 0x170001A3 RID: 419
		// (get) Token: 0x06000B75 RID: 2933 RVA: 0x00008F70 File Offset: 0x00007170
		// (set) Token: 0x06000B76 RID: 2934 RVA: 0x00008F78 File Offset: 0x00007178
		[JsonProperty("usage_time", NullValueHandling = NullValueHandling.Ignore)]
		public int AppUsageTime
		{
			get
			{
				return this.mAppUsageTime;
			}
			set
			{
				this.mAppUsageTime = value;
			}
		}

		// Token: 0x170001A4 RID: 420
		// (get) Token: 0x06000B77 RID: 2935 RVA: 0x00008F81 File Offset: 0x00007181
		// (set) Token: 0x06000B78 RID: 2936 RVA: 0x00008F89 File Offset: 0x00007189
		[JsonProperty("user_interactions", NullValueHandling = NullValueHandling.Ignore)]
		public int MinUserInteraction
		{
			get
			{
				return this.mMinUserInteraction;
			}
			set
			{
				this.mMinUserInteraction = value;
			}
		}

		// Token: 0x170001A5 RID: 421
		// (get) Token: 0x06000B79 RID: 2937 RVA: 0x00008F92 File Offset: 0x00007192
		// (set) Token: 0x06000B7A RID: 2938 RVA: 0x00008F9A File Offset: 0x0000719A
		[JsonProperty("recurring", NullValueHandling = NullValueHandling.Ignore)]
		public bool IsRecurring
		{
			get
			{
				return this.mIsRecurring;
			}
			set
			{
				this.mIsRecurring = value;
			}
		}

		// Token: 0x170001A6 RID: 422
		// (get) Token: 0x06000B7B RID: 2939 RVA: 0x00008FA3 File Offset: 0x000071A3
		// (set) Token: 0x06000B7C RID: 2940 RVA: 0x00008FAB File Offset: 0x000071AB
		[JsonProperty("num_of_occurances", NullValueHandling = NullValueHandling.Ignore)]
		public int RecurringCount
		{
			get
			{
				return this.mRecurringCount;
			}
			set
			{
				this.mRecurringCount = value;
			}
		}

		// Token: 0x170001A7 RID: 423
		// (get) Token: 0x06000B7D RID: 2941 RVA: 0x00008FB4 File Offset: 0x000071B4
		// (set) Token: 0x06000B7E RID: 2942 RVA: 0x00008FBC File Offset: 0x000071BC
		[JsonProperty("cloud_handler", NullValueHandling = NullValueHandling.Ignore)]
		public string CloudHandler
		{
			get
			{
				return this.mCloudHandler;
			}
			set
			{
				this.mCloudHandler = value;
			}
		}

		// Token: 0x0400084D RID: 2125
		private string mRuleId;

		// Token: 0x0400084E RID: 2126
		private string mAppPackage = string.Empty;

		// Token: 0x0400084F RID: 2127
		private int mAppUsageTime;

		// Token: 0x04000850 RID: 2128
		private int mMinUserInteraction;

		// Token: 0x04000851 RID: 2129
		private bool mIsRecurring;

		// Token: 0x04000852 RID: 2130
		private int mRecurringCount;

		// Token: 0x04000853 RID: 2131
		private string mCloudHandler;
	}
}
