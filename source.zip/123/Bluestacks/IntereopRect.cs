﻿using System;
using System.Drawing;
using System.Globalization;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000202 RID: 514
	public struct IntereopRect
	{
		// Token: 0x0600119E RID: 4510 RVA: 0x0000C738 File Offset: 0x0000A938
		public IntereopRect(int left, int top, int right, int bottom)
		{
			this.Left = left;
			this.Top = top;
			this.Right = right;
			this.Bottom = bottom;
		}

		// Token: 0x0600119F RID: 4511 RVA: 0x0000C757 File Offset: 0x0000A957
		public IntereopRect(Rectangle r)
		{
			this = new IntereopRect(r.Left, r.Top, r.Right, r.Bottom);
		}

		// Token: 0x17000206 RID: 518
		// (get) Token: 0x060011A0 RID: 4512 RVA: 0x0000C77B File Offset: 0x0000A97B
		// (set) Token: 0x060011A1 RID: 4513 RVA: 0x0000C783 File Offset: 0x0000A983
		public int X
		{
			get
			{
				return this.Left;
			}
			set
			{
				this.Right -= this.Left - value;
				this.Left = value;
			}
		}

		// Token: 0x17000207 RID: 519
		// (get) Token: 0x060011A2 RID: 4514 RVA: 0x0000C7A1 File Offset: 0x0000A9A1
		// (set) Token: 0x060011A3 RID: 4515 RVA: 0x0000C7A9 File Offset: 0x0000A9A9
		public int Y
		{
			get
			{
				return this.Top;
			}
			set
			{
				this.Bottom -= this.Top - value;
				this.Top = value;
			}
		}

		// Token: 0x17000208 RID: 520
		// (get) Token: 0x060011A4 RID: 4516 RVA: 0x0000C7C7 File Offset: 0x0000A9C7
		// (set) Token: 0x060011A5 RID: 4517 RVA: 0x0000C7D6 File Offset: 0x0000A9D6
		public int Height
		{
			get
			{
				return this.Bottom - this.Top;
			}
			set
			{
				this.Bottom = value + this.Top;
			}
		}

		// Token: 0x17000209 RID: 521
		// (get) Token: 0x060011A6 RID: 4518 RVA: 0x0000C7E6 File Offset: 0x0000A9E6
		// (set) Token: 0x060011A7 RID: 4519 RVA: 0x0000C7F5 File Offset: 0x0000A9F5
		public int Width
		{
			get
			{
				return this.Right - this.Left;
			}
			set
			{
				this.Right = value + this.Left;
			}
		}

		// Token: 0x1700020A RID: 522
		// (get) Token: 0x060011A8 RID: 4520 RVA: 0x0000C805 File Offset: 0x0000AA05
		// (set) Token: 0x060011A9 RID: 4521 RVA: 0x0000C818 File Offset: 0x0000AA18
		public Point Location
		{
			get
			{
				return new Point(this.Left, this.Top);
			}
			set
			{
				this.X = value.X;
				this.Y = value.Y;
			}
		}

		// Token: 0x1700020B RID: 523
		// (get) Token: 0x060011AA RID: 4522 RVA: 0x0000C834 File Offset: 0x0000AA34
		// (set) Token: 0x060011AB RID: 4523 RVA: 0x0000C847 File Offset: 0x0000AA47
		public Size Size
		{
			get
			{
				return new Size(this.Width, this.Height);
			}
			set
			{
				this.Width = value.Width;
				this.Height = value.Height;
			}
		}

		// Token: 0x060011AC RID: 4524 RVA: 0x0000C863 File Offset: 0x0000AA63
		public static implicit operator Rectangle(IntereopRect r)
		{
			return new Rectangle(r.Left, r.Top, r.Width, r.Height);
		}

		// Token: 0x060011AD RID: 4525 RVA: 0x0000C884 File Offset: 0x0000AA84
		public static implicit operator IntereopRect(Rectangle r)
		{
			return new IntereopRect(r);
		}

		// Token: 0x060011AE RID: 4526 RVA: 0x0000C88C File Offset: 0x0000AA8C
		public static bool operator ==(IntereopRect r1, IntereopRect r2)
		{
			return r1.Equals(r2);
		}

		// Token: 0x060011AF RID: 4527 RVA: 0x0000C896 File Offset: 0x0000AA96
		public static bool operator !=(IntereopRect r1, IntereopRect r2)
		{
			return !r1.Equals(r2);
		}

		// Token: 0x060011B0 RID: 4528 RVA: 0x0000C8A3 File Offset: 0x0000AAA3
		public bool Equals(IntereopRect r)
		{
			return r.Left == this.Left && r.Top == this.Top && r.Right == this.Right && r.Bottom == this.Bottom;
		}

		// Token: 0x060011B1 RID: 4529 RVA: 0x0000C8DF File Offset: 0x0000AADF
		public override bool Equals(object obj)
		{
			if (obj is IntereopRect)
			{
				return this.Equals((IntereopRect)obj);
			}
			return obj is Rectangle && this.Equals(new IntereopRect((Rectangle)obj));
		}

		// Token: 0x060011B2 RID: 4530 RVA: 0x0006D59C File Offset: 0x0006B79C
		public override int GetHashCode()
		{
			return this.GetHashCode();
		}

		// Token: 0x060011B3 RID: 4531 RVA: 0x0006D5C4 File Offset: 0x0006B7C4
		public override string ToString()
		{
			return string.Format(CultureInfo.CurrentCulture, "{{Left={0},Top={1},Right={2},Bottom={3}}}", new object[]
			{
				this.Left,
				this.Top,
				this.Right,
				this.Bottom
			});
		}

		// Token: 0x04000C1E RID: 3102
		public int Left;

		// Token: 0x04000C1F RID: 3103
		public int Top;

		// Token: 0x04000C20 RID: 3104
		public int Right;

		// Token: 0x04000C21 RID: 3105
		public int Bottom;
	}
}
