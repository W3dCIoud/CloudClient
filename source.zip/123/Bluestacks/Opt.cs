﻿using System;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000139 RID: 313
	public sealed class Opt : GetOpt
	{
		// Token: 0x170001CC RID: 460
		// (get) Token: 0x06000C36 RID: 3126 RVA: 0x00009764 File Offset: 0x00007964
		// (set) Token: 0x06000C37 RID: 3127 RVA: 0x0000976C File Offset: 0x0000796C
		public string Json
		{
			get
			{
				return this.json;
			}
			set
			{
				this.json = Uri.UnescapeDataString(value);
			}
		}

		// Token: 0x06000C38 RID: 3128 RVA: 0x0000977A File Offset: 0x0000797A
		private Opt()
		{
		}

		// Token: 0x170001CD RID: 461
		// (get) Token: 0x06000C39 RID: 3129 RVA: 0x000535B4 File Offset: 0x000517B4
		public static Opt Instance
		{
			get
			{
				if (Opt.instance == null)
				{
					object obj = Opt.syncRoot;
					lock (obj)
					{
						if (Opt.instance == null)
						{
							Opt.instance = new Opt();
						}
					}
				}
				return Opt.instance;
			}
		}

		// Token: 0x040008FE RID: 2302
		private static volatile Opt instance;

		// Token: 0x040008FF RID: 2303
		private static object syncRoot = new object();

		// Token: 0x04000900 RID: 2304
		public string vmname = "Android";

		// Token: 0x04000901 RID: 2305
		public bool h;

		// Token: 0x04000902 RID: 2306
		public bool mergeCfg;

		// Token: 0x04000903 RID: 2307
		public bool isUpgradeFromImap13;

		// Token: 0x04000904 RID: 2308
		public string newPDPath = string.Empty;

		// Token: 0x04000905 RID: 2309
		private string json = "";
	}
}
