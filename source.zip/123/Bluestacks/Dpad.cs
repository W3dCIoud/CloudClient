﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Input;

// Token: 0x02000005 RID: 5
[Description("Independent")]
[Serializable]
public class Dpad : IMAction
{
	// Token: 0x06000045 RID: 69 RVA: 0x0000FC80 File Offset: 0x0000DE80
	public Dpad()
	{
		base.Type = KeyActionType.Dpad;
		Dpad.sListDpad.Add(this);
	}

	// Token: 0x17000020 RID: 32
	// (get) Token: 0x06000046 RID: 70 RVA: 0x00002311 File Offset: 0x00000511
	// (set) Token: 0x06000047 RID: 71 RVA: 0x00002319 File Offset: 0x00000519
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X
	{
		get
		{
			return this.mX;
		}
		set
		{
			this.mX = value;
			if (this.IsMOBADpadEnabled)
			{
				this.mMOBADpad.X = value;
			}
		}
	}

	// Token: 0x17000021 RID: 33
	// (get) Token: 0x06000048 RID: 72 RVA: 0x00002336 File Offset: 0x00000536
	// (set) Token: 0x06000049 RID: 73 RVA: 0x0000233E File Offset: 0x0000053E
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y
	{
		get
		{
			return this.mY;
		}
		set
		{
			this.mY = value;
			if (this.IsMOBADpadEnabled)
			{
				this.mMOBADpad.Y = value;
			}
		}
	}

	// Token: 0x17000022 RID: 34
	// (get) Token: 0x0600004A RID: 74 RVA: 0x0000235B File Offset: 0x0000055B
	// (set) Token: 0x0600004B RID: 75 RVA: 0x00002363 File Offset: 0x00000563
	[Description("IMAP_CanvasElementRadiusIMAP_PopupUIElement")]
	[Category("Fields")]
	public double XRadius
	{
		get
		{
			return this.mXRadius;
		}
		set
		{
			this.mXRadius = value;
		}
	}

	// Token: 0x17000023 RID: 35
	// (get) Token: 0x0600004C RID: 76 RVA: 0x0000236C File Offset: 0x0000056C
	// (set) Token: 0x0600004D RID: 77 RVA: 0x00002374 File Offset: 0x00000574
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyUp
	{
		get
		{
			return this.mKeyUp;
		}
		set
		{
			this.mKeyUp = value;
		}
	}

	// Token: 0x17000024 RID: 36
	// (get) Token: 0x0600004E RID: 78 RVA: 0x0000237D File Offset: 0x0000057D
	// (set) Token: 0x0600004F RID: 79 RVA: 0x00002385 File Offset: 0x00000585
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyUp_alt1
	{
		get
		{
			return this.mKeyUp_1;
		}
		set
		{
			this.mKeyUp_1 = value;
		}
	}

	// Token: 0x17000025 RID: 37
	// (get) Token: 0x06000050 RID: 80 RVA: 0x0000238E File Offset: 0x0000058E
	// (set) Token: 0x06000051 RID: 81 RVA: 0x00002396 File Offset: 0x00000596
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyDown
	{
		get
		{
			return this.mKeyDown;
		}
		set
		{
			this.mKeyDown = value;
		}
	}

	// Token: 0x17000026 RID: 38
	// (get) Token: 0x06000052 RID: 82 RVA: 0x0000239F File Offset: 0x0000059F
	// (set) Token: 0x06000053 RID: 83 RVA: 0x000023A7 File Offset: 0x000005A7
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyDown_alt1
	{
		get
		{
			return this.mKeyDown_1;
		}
		set
		{
			this.mKeyDown_1 = value;
		}
	}

	// Token: 0x17000027 RID: 39
	// (get) Token: 0x06000054 RID: 84 RVA: 0x000023B0 File Offset: 0x000005B0
	// (set) Token: 0x06000055 RID: 85 RVA: 0x000023B8 File Offset: 0x000005B8
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyLeft
	{
		get
		{
			return this.mKeyLeft;
		}
		set
		{
			this.mKeyLeft = value;
		}
	}

	// Token: 0x17000028 RID: 40
	// (get) Token: 0x06000056 RID: 86 RVA: 0x000023C1 File Offset: 0x000005C1
	// (set) Token: 0x06000057 RID: 87 RVA: 0x000023C9 File Offset: 0x000005C9
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyLeft_alt1
	{
		get
		{
			return this.mKeyLeft_1;
		}
		set
		{
			this.mKeyLeft_1 = value;
		}
	}

	// Token: 0x17000029 RID: 41
	// (get) Token: 0x06000058 RID: 88 RVA: 0x000023D2 File Offset: 0x000005D2
	// (set) Token: 0x06000059 RID: 89 RVA: 0x000023DA File Offset: 0x000005DA
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyRight
	{
		get
		{
			return this.mKeyRight;
		}
		set
		{
			this.mKeyRight = value;
		}
	}

	// Token: 0x1700002A RID: 42
	// (get) Token: 0x0600005A RID: 90 RVA: 0x000023E3 File Offset: 0x000005E3
	// (set) Token: 0x0600005B RID: 91 RVA: 0x000023EB File Offset: 0x000005EB
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyRight_alt1
	{
		get
		{
			return this.mKeyRight_1;
		}
		set
		{
			this.mKeyRight_1 = value;
		}
	}

	// Token: 0x1700002B RID: 43
	// (get) Token: 0x0600005C RID: 92 RVA: 0x000023F4 File Offset: 0x000005F4
	// (set) Token: 0x0600005D RID: 93 RVA: 0x000023FC File Offset: 0x000005FC
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string GamepadStick
	{
		get
		{
			return this.mGamepadStick;
		}
		set
		{
			this.mGamepadStick = value;
		}
	}

	// Token: 0x1700002C RID: 44
	// (get) Token: 0x0600005E RID: 94 RVA: 0x00002405 File Offset: 0x00000605
	// (set) Token: 0x0600005F RID: 95 RVA: 0x0000240D File Offset: 0x0000060D
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeySpeedModifier1
	{
		get
		{
			return this.mKeySpeedModifier1;
		}
		set
		{
			this.mKeySpeedModifier1 = value;
		}
	}

	// Token: 0x1700002D RID: 45
	// (get) Token: 0x06000060 RID: 96 RVA: 0x00002416 File Offset: 0x00000616
	// (set) Token: 0x06000061 RID: 97 RVA: 0x0000241E File Offset: 0x0000061E
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeySpeedModifier1_alt1
	{
		get
		{
			return this.mKeySpeedModifier1_alt1;
		}
		set
		{
			this.mKeySpeedModifier1_alt1 = value;
		}
	}

	// Token: 0x1700002E RID: 46
	// (get) Token: 0x06000062 RID: 98 RVA: 0x00002427 File Offset: 0x00000627
	// (set) Token: 0x06000063 RID: 99 RVA: 0x0000242F File Offset: 0x0000062F
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double XRadius1
	{
		get
		{
			return this.mXRadius1;
		}
		set
		{
			this.mXRadius1 = value;
		}
	}

	// Token: 0x1700002F RID: 47
	// (get) Token: 0x06000064 RID: 100 RVA: 0x00002438 File Offset: 0x00000638
	// (set) Token: 0x06000065 RID: 101 RVA: 0x00002440 File Offset: 0x00000640
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeySpeedModifier2
	{
		get
		{
			return this.mKeySpeedModifier2;
		}
		set
		{
			this.mKeySpeedModifier2 = value;
		}
	}

	// Token: 0x17000030 RID: 48
	// (get) Token: 0x06000066 RID: 102 RVA: 0x00002449 File Offset: 0x00000649
	// (set) Token: 0x06000067 RID: 103 RVA: 0x00002451 File Offset: 0x00000651
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeySpeedModifier2_alt1
	{
		get
		{
			return this.mKeySpeedModifier2_alt1;
		}
		set
		{
			this.mKeySpeedModifier2_alt1 = value;
		}
	}

	// Token: 0x17000031 RID: 49
	// (get) Token: 0x06000068 RID: 104 RVA: 0x0000245A File Offset: 0x0000065A
	// (set) Token: 0x06000069 RID: 105 RVA: 0x00002462 File Offset: 0x00000662
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double XRadius2
	{
		get
		{
			return this.mXRadius2;
		}
		set
		{
			this.mXRadius2 = value;
		}
	}

	// Token: 0x17000032 RID: 50
	// (get) Token: 0x0600006A RID: 106 RVA: 0x0000246B File Offset: 0x0000066B
	// (set) Token: 0x0600006B RID: 107 RVA: 0x00002473 File Offset: 0x00000673
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Speed
	{
		get
		{
			return this.mSpeed;
		}
		set
		{
			this.mSpeed = value;
		}
	}

	// Token: 0x17000033 RID: 51
	// (get) Token: 0x0600006C RID: 108 RVA: 0x0000247C File Offset: 0x0000067C
	// (set) Token: 0x0600006D RID: 109 RVA: 0x00002484 File Offset: 0x00000684
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int ActivationTime
	{
		get
		{
			return this.mActivationTime;
		}
		set
		{
			this.mActivationTime = value;
		}
	}

	// Token: 0x17000034 RID: 52
	// (get) Token: 0x0600006E RID: 110 RVA: 0x0000248D File Offset: 0x0000068D
	// (set) Token: 0x0600006F RID: 111 RVA: 0x00002495 File Offset: 0x00000695
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double ActivationSpeed
	{
		get
		{
			return this.mActivationSpeed;
		}
		set
		{
			this.mActivationSpeed = value;
		}
	}

	// Token: 0x17000035 RID: 53
	// (get) Token: 0x06000070 RID: 112 RVA: 0x0000249E File Offset: 0x0000069E
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	internal bool IsMOBADpadEnabled
	{
		get
		{
			return this.mMOBADpad.OriginX != -1.0 && this.mMOBADpad.OriginY != -1.0;
		}
	}

	// Token: 0x17000036 RID: 54
	// (get) Token: 0x06000071 RID: 113 RVA: 0x000024D1 File Offset: 0x000006D1
	// (set) Token: 0x06000072 RID: 114 RVA: 0x000024D9 File Offset: 0x000006D9
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool ShowOnOverlay
	{
		get
		{
			return this.mShowOnOverlay;
		}
		set
		{
			this.mShowOnOverlay = value;
		}
	}

	// Token: 0x04000025 RID: 37
	internal static List<Dpad> sListDpad = new List<Dpad>();

	// Token: 0x04000026 RID: 38
	internal MOBADpad mMOBADpad = new MOBADpad();

	// Token: 0x04000027 RID: 39
	private double mX = -1.0;

	// Token: 0x04000028 RID: 40
	private double mY = -1.0;

	// Token: 0x04000029 RID: 41
	private double mXRadius = 6.0;

	// Token: 0x0400002A RID: 42
	private string mKeyUp = IMAPKeys.GetStringForFile(Key.W);

	// Token: 0x0400002B RID: 43
	private string mKeyUp_1 = string.Empty;

	// Token: 0x0400002C RID: 44
	private string mKeyDown = IMAPKeys.GetStringForFile(Key.S);

	// Token: 0x0400002D RID: 45
	private string mKeyDown_1 = string.Empty;

	// Token: 0x0400002E RID: 46
	private string mKeyLeft = IMAPKeys.GetStringForFile(Key.A);

	// Token: 0x0400002F RID: 47
	private string mKeyLeft_1 = string.Empty;

	// Token: 0x04000030 RID: 48
	private string mKeyRight = IMAPKeys.GetStringForFile(Key.D);

	// Token: 0x04000031 RID: 49
	private string mKeyRight_1 = string.Empty;

	// Token: 0x04000032 RID: 50
	private string mGamepadStick = "";

	// Token: 0x04000033 RID: 51
	private string mKeySpeedModifier1;

	// Token: 0x04000034 RID: 52
	private string mKeySpeedModifier1_alt1;

	// Token: 0x04000035 RID: 53
	private double mXRadius1;

	// Token: 0x04000036 RID: 54
	private string mKeySpeedModifier2;

	// Token: 0x04000037 RID: 55
	private string mKeySpeedModifier2_alt1;

	// Token: 0x04000038 RID: 56
	private double mXRadius2;

	// Token: 0x04000039 RID: 57
	private double mSpeed = 200.0;

	// Token: 0x0400003A RID: 58
	private int mActivationTime;

	// Token: 0x0400003B RID: 59
	private double mActivationSpeed;

	// Token: 0x0400003C RID: 60
	internal bool mShowOnOverlay = true;
}
