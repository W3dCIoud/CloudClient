﻿using System;
using System.Windows;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000B6 RID: 182
	public class EngineSettingsControl : EngineSettingsBase
	{
		// Token: 0x0600075E RID: 1886 RVA: 0x0002E114 File Offset: 0x0002C314
		public EngineSettingsControl(MainWindow window)
		{
			this.ParentWindow = window;
			EngineSettingsBase.mVmName = window.mVmName;
			base.Init();
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				base.RestartNowBtn.Content = LocaleStrings.GetLocalizedString("STRING_QUIT_TEXT", false);
			}
		}

		// Token: 0x0600075F RID: 1887 RVA: 0x0002E164 File Offset: 0x0002C364
		protected override void RestartNowBtn_Click(object sender, RoutedEventArgs e)
		{
			Logger.Info("Restart now button pressed");
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				BlueStacksUIUtils.CloseContainerWindow(this);
				this.ParentWindow.Close();
				return;
			}
			BlueStacksUIBinding.Bind(base.RestartNowBtn, "STRING_RESTARTING");
			BlueStacksUIUtils.CloseContainerWindow(this);
			BlueStacksUIUtils.RestartInstance(EngineSettingsBase.mVmName);
		}

		// Token: 0x0400050C RID: 1292
		private MainWindow ParentWindow;
	}
}
