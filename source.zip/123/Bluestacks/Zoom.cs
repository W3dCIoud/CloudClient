﻿using System;
using System.ComponentModel;
using System.Windows.Input;

// Token: 0x02000018 RID: 24
[Description("Independent")]
[Serializable]
public class Zoom : IMAction
{
	// Token: 0x170000B4 RID: 180
	// (get) Token: 0x0600017F RID: 383 RVA: 0x000105B4 File Offset: 0x0000E7B4
	// (set) Token: 0x06000180 RID: 384 RVA: 0x00010630 File Offset: 0x0000E830
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	internal double X
	{
		get
		{
			if (this.mX1 == -1.0 && this.mX2 == -1.0)
			{
				this.mX = -1.0;
			}
			else if (this.Direction == Direction.Left || this.Direction == Direction.Right)
			{
				this.mX = this.mX1 + this.mRadius;
			}
			else
			{
				this.mX = this.mX1;
			}
			return this.mX;
		}
		set
		{
			this.mX = value;
			if (this.Direction == Direction.Right)
			{
				this.mX2 = Math.Round(this.mX + this.mRadius, 2);
				this.mX1 = Math.Round(this.mX - this.mRadius, 2);
				return;
			}
			if (this.Direction == Direction.Up)
			{
				this.mX1 = Math.Round(this.mX, 2);
				this.mX2 = this.X1;
			}
		}
	}

	// Token: 0x170000B5 RID: 181
	// (get) Token: 0x06000181 RID: 385 RVA: 0x000106A8 File Offset: 0x0000E8A8
	// (set) Token: 0x06000182 RID: 386 RVA: 0x00010720 File Offset: 0x0000E920
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	internal double Y
	{
		get
		{
			if (this.mY1 == -1.0 && this.mY2 == -1.0)
			{
				this.mY = -1.0;
			}
			else if (this.Direction == Direction.Up || this.Direction == Direction.Down)
			{
				this.mY = this.mY1 + this.mRadius;
			}
			else
			{
				this.mY = this.mY1;
			}
			return this.mY;
		}
		set
		{
			this.mY = value;
			if (this.Direction == Direction.Right)
			{
				this.mY1 = Math.Round(this.mY, 2);
				this.mY2 = this.Y1;
				return;
			}
			if (this.Direction == Direction.Up)
			{
				this.mY2 = Math.Round(this.mY + this.mRadius, 2);
				this.mY1 = Math.Round(this.mY - this.mRadius, 2);
			}
		}
	}

	// Token: 0x170000B6 RID: 182
	// (get) Token: 0x06000183 RID: 387 RVA: 0x00002FB6 File Offset: 0x000011B6
	// (set) Token: 0x06000184 RID: 388 RVA: 0x00002FBE File Offset: 0x000011BE
	public double X1
	{
		get
		{
			return this.mX1;
		}
		set
		{
			this.mX1 = value;
			this.CheckDirection();
			if (this.Direction == Direction.Up || this.Direction == Direction.Down)
			{
				this.mX2 = this.X1;
			}
		}
	}

	// Token: 0x170000B7 RID: 183
	// (get) Token: 0x06000185 RID: 389 RVA: 0x00002FEA File Offset: 0x000011EA
	// (set) Token: 0x06000186 RID: 390 RVA: 0x00002FF2 File Offset: 0x000011F2
	public double Y1
	{
		get
		{
			return this.mY1;
		}
		set
		{
			this.mY1 = value;
			this.CheckDirection();
			if (this.Direction == Direction.Left || this.Direction == Direction.Right)
			{
				this.mY2 = this.Y1;
			}
		}
	}

	// Token: 0x170000B8 RID: 184
	// (get) Token: 0x06000187 RID: 391 RVA: 0x0000301F File Offset: 0x0000121F
	// (set) Token: 0x06000188 RID: 392 RVA: 0x00003031 File Offset: 0x00001231
	[Category("Fields")]
	internal double Size
	{
		get
		{
			return this.Radius * 2.0;
		}
		set
		{
			this.Radius = value / 2.0;
		}
	}

	// Token: 0x170000B9 RID: 185
	// (get) Token: 0x06000189 RID: 393 RVA: 0x00003044 File Offset: 0x00001244
	// (set) Token: 0x0600018A RID: 394 RVA: 0x0000304C File Offset: 0x0000124C
	public double X2
	{
		get
		{
			return this.mX2;
		}
		set
		{
			this.mX2 = value;
			this.CheckDirection();
		}
	}

	// Token: 0x170000BA RID: 186
	// (get) Token: 0x0600018B RID: 395 RVA: 0x0000305B File Offset: 0x0000125B
	// (set) Token: 0x0600018C RID: 396 RVA: 0x00003063 File Offset: 0x00001263
	public double Y2
	{
		get
		{
			return this.mY2;
		}
		set
		{
			this.mY2 = value;
			this.CheckDirection();
		}
	}

	// Token: 0x170000BB RID: 187
	// (get) Token: 0x0600018D RID: 397 RVA: 0x00003072 File Offset: 0x00001272
	// (set) Token: 0x0600018E RID: 398 RVA: 0x00010798 File Offset: 0x0000E998
	[Description("IMAP_CanvasElementRadiusIMAP_PopupUIElement")]
	[Category("Fields")]
	internal double Radius
	{
		get
		{
			return this.mRadius;
		}
		set
		{
			this.mRadius = value;
			if (this.Direction == Direction.Right)
			{
				this.mX2 = Math.Round(this.mX + this.mRadius, 2);
				this.mX1 = Math.Round(this.mX - this.mRadius, 2);
				this.mY1 = Math.Round(this.mY, 2);
				this.mY2 = this.Y1;
				return;
			}
			if (this.Direction == Direction.Up)
			{
				this.mY2 = Math.Round(this.mY + this.mRadius, 2);
				this.mY1 = Math.Round(this.mY - this.mRadius, 2);
				this.mX1 = Math.Round(this.mX, 2);
				this.mX2 = this.X1;
			}
		}
	}

	// Token: 0x170000BC RID: 188
	// (get) Token: 0x0600018F RID: 399 RVA: 0x0000307A File Offset: 0x0000127A
	// (set) Token: 0x06000190 RID: 400 RVA: 0x00003082 File Offset: 0x00001282
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyIn
	{
		get
		{
			return this.mKeyIn;
		}
		set
		{
			this.mKeyIn = value;
		}
	}

	// Token: 0x170000BD RID: 189
	// (get) Token: 0x06000191 RID: 401 RVA: 0x0000308B File Offset: 0x0000128B
	// (set) Token: 0x06000192 RID: 402 RVA: 0x00003093 File Offset: 0x00001293
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyIn_alt1
	{
		get
		{
			return this.mKeyIn_1;
		}
		set
		{
			this.mKeyIn_1 = value;
		}
	}

	// Token: 0x170000BE RID: 190
	// (get) Token: 0x06000193 RID: 403 RVA: 0x0000309C File Offset: 0x0000129C
	// (set) Token: 0x06000194 RID: 404 RVA: 0x000030A4 File Offset: 0x000012A4
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyOut
	{
		get
		{
			return this.mKeyOut;
		}
		set
		{
			this.mKeyOut = value;
		}
	}

	// Token: 0x170000BF RID: 191
	// (get) Token: 0x06000195 RID: 405 RVA: 0x000030AD File Offset: 0x000012AD
	// (set) Token: 0x06000196 RID: 406 RVA: 0x000030B5 File Offset: 0x000012B5
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyOut_alt1
	{
		get
		{
			return this.mKeyOut_1;
		}
		set
		{
			this.mKeyOut_1 = value;
		}
	}

	// Token: 0x170000C0 RID: 192
	// (get) Token: 0x06000197 RID: 407 RVA: 0x000030BE File Offset: 0x000012BE
	// (set) Token: 0x06000198 RID: 408 RVA: 0x000030C6 File Offset: 0x000012C6
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyModifier
	{
		get
		{
			return this.mKeyModifier;
		}
		set
		{
			this.mKeyModifier = value;
		}
	}

	// Token: 0x170000C1 RID: 193
	// (get) Token: 0x06000199 RID: 409 RVA: 0x000030CF File Offset: 0x000012CF
	// (set) Token: 0x0600019A RID: 410 RVA: 0x000030D7 File Offset: 0x000012D7
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyModifier_alt1
	{
		get
		{
			return this.mKeyModifier_1;
		}
		set
		{
			this.mKeyModifier_1 = value;
		}
	}

	// Token: 0x170000C2 RID: 194
	// (get) Token: 0x0600019B RID: 411 RVA: 0x000030E0 File Offset: 0x000012E0
	// (set) Token: 0x0600019C RID: 412 RVA: 0x000030E8 File Offset: 0x000012E8
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Speed
	{
		get
		{
			return this.mSpeed;
		}
		set
		{
			this.mSpeed = value;
		}
	}

	// Token: 0x170000C3 RID: 195
	// (get) Token: 0x0600019D RID: 413 RVA: 0x000030F1 File Offset: 0x000012F1
	// (set) Token: 0x0600019E RID: 414 RVA: 0x000030F9 File Offset: 0x000012F9
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int Mode
	{
		get
		{
			return this.mMode;
		}
		set
		{
			this.mMode = value;
		}
	}

	// Token: 0x170000C4 RID: 196
	// (get) Token: 0x0600019F RID: 415 RVA: 0x00003102 File Offset: 0x00001302
	// (set) Token: 0x060001A0 RID: 416 RVA: 0x0000310A File Offset: 0x0000130A
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool Override
	{
		get
		{
			return this.mOverride;
		}
		set
		{
			this.mOverride = value;
		}
	}

	// Token: 0x060001A1 RID: 417 RVA: 0x00010860 File Offset: 0x0000EA60
	private void CheckDirection()
	{
		if (this.X1 == this.X2)
		{
			this.Direction = Direction.Up;
			this.mRadius = Math.Round(Math.Abs(this.Y2 - this.Y1) / 2.0, 2);
			return;
		}
		if (this.Y1 == this.Y2)
		{
			this.Direction = Direction.Right;
			this.mRadius = Math.Round(Math.Abs(this.X2 - this.X1) / 2.0, 2);
		}
	}

	// Token: 0x040000B0 RID: 176
	private double mX = -1.0;

	// Token: 0x040000B1 RID: 177
	private double mY = -1.0;

	// Token: 0x040000B2 RID: 178
	private double mX1 = -1.0;

	// Token: 0x040000B3 RID: 179
	private double mY1 = -1.0;

	// Token: 0x040000B4 RID: 180
	private double mX2 = -1.0;

	// Token: 0x040000B5 RID: 181
	private double mY2 = -1.0;

	// Token: 0x040000B6 RID: 182
	private double mRadius = 20.0;

	// Token: 0x040000B7 RID: 183
	private string mKeyIn = IMAPKeys.GetStringForFile(Key.OemPlus);

	// Token: 0x040000B8 RID: 184
	private string mKeyIn_1 = string.Empty;

	// Token: 0x040000B9 RID: 185
	private string mKeyOut = IMAPKeys.GetStringForFile(Key.OemMinus);

	// Token: 0x040000BA RID: 186
	private string mKeyOut_1 = string.Empty;

	// Token: 0x040000BB RID: 187
	private string mKeyModifier;

	// Token: 0x040000BC RID: 188
	private string mKeyModifier_1;

	// Token: 0x040000BD RID: 189
	private double mSpeed = 1.0;

	// Token: 0x040000BE RID: 190
	private int mMode;

	// Token: 0x040000BF RID: 191
	private bool mOverride = true;
}
