﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200015A RID: 346
	public class UpdateDownloadProgress : CustomWindow, IComponentConnector
	{
		// Token: 0x06000D52 RID: 3410 RVA: 0x0000A3C1 File Offset: 0x000085C1
		public UpdateDownloadProgress()
		{
			this.InitializeComponent();
			base.IsShowGLWindow = true;
		}

		// Token: 0x06000D53 RID: 3411 RVA: 0x0001CBFC File Offset: 0x0001ADFC
		private void Grid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			if (!e.OriginalSource.GetType().Equals(typeof(CustomPictureBox)))
			{
				try
				{
					base.DragMove();
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000D54 RID: 3412 RVA: 0x0000491B File Offset: 0x00002B1B
		private void HideBtn_Click(object sender, RoutedEventArgs e)
		{
			base.Hide();
		}

		// Token: 0x06000D55 RID: 3413 RVA: 0x0000491B File Offset: 0x00002B1B
		private void mCloseBtn_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			base.Hide();
		}

		// Token: 0x06000D56 RID: 3414 RVA: 0x00056F14 File Offset: 0x00055114
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/updatedownloadprogress.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000D57 RID: 3415 RVA: 0x00056F44 File Offset: 0x00055144
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mUpdateDownloadProgressUserControl = (UpdateDownloadProgress)target;
				return;
			case 2:
				this.mMaskBorder = (Border)target;
				return;
			case 3:
				((Grid)target).MouseLeftButtonDown += this.Grid_MouseLeftButtonDown;
				return;
			case 4:
				this.titleLabel = (TextBlock)target;
				return;
			case 5:
				this.mCloseBtn = (CustomPictureBox)target;
				this.mCloseBtn.PreviewMouseLeftButtonUp += this.mCloseBtn_PreviewMouseLeftButtonUp;
				return;
			case 6:
				this.mUpdateDownloadProgressBar = (BlueProgressBar)target;
				return;
			case 7:
				this.mUpdateDownloadProgressPercentage = (Label)target;
				return;
			case 8:
				this.mHideBtn = (CustomButton)target;
				this.mHideBtn.Click += this.HideBtn_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000991 RID: 2449
		internal UpdateDownloadProgress mUpdateDownloadProgressUserControl;

		// Token: 0x04000992 RID: 2450
		internal Border mMaskBorder;

		// Token: 0x04000993 RID: 2451
		internal TextBlock titleLabel;

		// Token: 0x04000994 RID: 2452
		internal CustomPictureBox mCloseBtn;

		// Token: 0x04000995 RID: 2453
		internal BlueProgressBar mUpdateDownloadProgressBar;

		// Token: 0x04000996 RID: 2454
		internal Label mUpdateDownloadProgressPercentage;

		// Token: 0x04000997 RID: 2455
		internal CustomButton mHideBtn;

		// Token: 0x04000998 RID: 2456
		private bool _contentLoaded;
	}
}
