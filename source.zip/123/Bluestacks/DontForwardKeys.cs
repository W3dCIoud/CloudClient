﻿using System;

// Token: 0x02000008 RID: 8
[Serializable]
public class DontForwardKeys : IMAction
{
}
