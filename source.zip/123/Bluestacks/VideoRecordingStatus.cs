﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000C3 RID: 195
	public class VideoRecordingStatus : UserControl, IComponentConnector
	{
		// Token: 0x060007DA RID: 2010 RVA: 0x000070AE File Offset: 0x000052AE
		public VideoRecordingStatus()
		{
			this.InitializeComponent();
		}

		// Token: 0x060007DB RID: 2011 RVA: 0x000070C3 File Offset: 0x000052C3
		private void StopRecord_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ResetTimer();
			Action recordingStoppedEvent = this.RecordingStoppedEvent;
			if (recordingStoppedEvent != null)
			{
				recordingStoppedEvent();
			}
			this.ParentWindow.mCommonHandler.StopRecordVideo();
		}

		// Token: 0x060007DC RID: 2012 RVA: 0x000070EC File Offset: 0x000052EC
		private void BlinkPlayingIcon_Tick(object sender, EventArgs e)
		{
			this.ToggleRecordingIcon();
		}

		// Token: 0x060007DD RID: 2013 RVA: 0x00031A90 File Offset: 0x0002FC90
		internal void StopTimer()
		{
			DispatcherTimer dispatcherTimer = this.mBlinkPlayingIconTimer;
			if (dispatcherTimer != null && dispatcherTimer.IsEnabled)
			{
				DispatcherTimer dispatcherTimer2 = this.mBlinkPlayingIconTimer;
				if (dispatcherTimer2 != null)
				{
					dispatcherTimer2.Stop();
				}
			}
			DispatcherTimer dispatcherTimer3 = this.mTimer;
			if (dispatcherTimer3 != null && dispatcherTimer3.IsEnabled)
			{
				DispatcherTimer dispatcherTimer4 = this.mTimer;
				if (dispatcherTimer4 == null)
				{
					return;
				}
				dispatcherTimer4.Stop();
			}
		}

		// Token: 0x060007DE RID: 2014 RVA: 0x000070F4 File Offset: 0x000052F4
		internal void StartTimer()
		{
			this.mBlinkPlayingIconTimer.Start();
		}

		// Token: 0x060007DF RID: 2015 RVA: 0x00031AE8 File Offset: 0x0002FCE8
		private void ToggleRecordingIcon()
		{
			if (this.mToggleBlinkImage)
			{
				this.mRecordingImage.ImageName = "sidebar_video_capture";
			}
			else
			{
				this.mRecordingImage.ImageName = "sidebar_video_capture_active";
			}
			if (FeatureManager.Instance.IsCustomUIForNCSoft && this.ParentWindow.mSidebar != null)
			{
				this.ParentWindow.mSidebar.ChangeVideoRecordingImage(this.mRecordingImage.ImageName);
			}
			this.mToggleBlinkImage = !this.mToggleBlinkImage;
		}

		// Token: 0x060007E0 RID: 2016 RVA: 0x00031B64 File Offset: 0x0002FD64
		internal void Init(MainWindow parentWindow)
		{
			this.ParentWindow = parentWindow;
			if (this.mBlinkPlayingIconTimer == null)
			{
				this.mBlinkPlayingIconTimer = new DispatcherTimer(new TimeSpan(0, 0, 0, 0, 500), DispatcherPriority.Render, new EventHandler(this.BlinkPlayingIcon_Tick), Dispatcher.CurrentDispatcher);
				this.mStartTime = DateTime.Now;
				this.mTimer = new DispatcherTimer(new TimeSpan(0, 0, 0, 0, 50), DispatcherPriority.Render, new EventHandler(this.T_Tick), Dispatcher.CurrentDispatcher);
				this.StartTimer();
			}
		}

		// Token: 0x060007E1 RID: 2017 RVA: 0x00031BE4 File Offset: 0x0002FDE4
		private void T_Tick(object sender, EventArgs e)
		{
			TimeSpan timeSpan = DateTime.Now - this.mStartTime;
			string text = string.Format("{0:00}:{1:00}:{2:00}", timeSpan.Minutes, timeSpan.Seconds, timeSpan.Milliseconds / 10);
			this.mTimerDisplay.Text = text;
		}

		// Token: 0x060007E2 RID: 2018 RVA: 0x00007101 File Offset: 0x00005301
		internal void ResetTimer()
		{
			this.StopTimer();
			this.mBlinkPlayingIconTimer = null;
			this.mTimer = null;
		}

		// Token: 0x060007E3 RID: 2019 RVA: 0x00031C40 File Offset: 0x0002FE40
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/videorecordingstatus.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060007E4 RID: 2020 RVA: 0x00031C70 File Offset: 0x0002FE70
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				this.mRecordingImage = (CustomPictureBox)target;
				return;
			case 3:
				this.mDescriptionPanel = (StackPanel)target;
				return;
			case 4:
				this.mRunningVideo = (TextBlock)target;
				return;
			case 5:
				this.mTimerDisplay = (TextBlock)target;
				return;
			case 6:
				this.mStopVideoRecordImg = (CustomPictureBox)target;
				this.mStopVideoRecordImg.PreviewMouseLeftButtonUp += this.StopRecord_PreviewMouseLeftButtonUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040005A5 RID: 1445
		private MainWindow ParentWindow;

		// Token: 0x040005A6 RID: 1446
		private DispatcherTimer mBlinkPlayingIconTimer;

		// Token: 0x040005A7 RID: 1447
		private DispatcherTimer mTimer;

		// Token: 0x040005A8 RID: 1448
		public DateTime mStartTime;

		// Token: 0x040005A9 RID: 1449
		private bool mToggleBlinkImage = true;

		// Token: 0x040005AA RID: 1450
		internal Action RecordingStoppedEvent;

		// Token: 0x040005AB RID: 1451
		internal Border mMaskBorder;

		// Token: 0x040005AC RID: 1452
		internal CustomPictureBox mRecordingImage;

		// Token: 0x040005AD RID: 1453
		internal StackPanel mDescriptionPanel;

		// Token: 0x040005AE RID: 1454
		internal TextBlock mRunningVideo;

		// Token: 0x040005AF RID: 1455
		internal TextBlock mTimerDisplay;

		// Token: 0x040005B0 RID: 1456
		internal CustomPictureBox mStopVideoRecordImg;

		// Token: 0x040005B1 RID: 1457
		private bool _contentLoaded;
	}
}
