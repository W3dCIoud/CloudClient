﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using System.Xml.Serialization;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000230 RID: 560
	public class AppHandler
	{
		// Token: 0x17000224 RID: 548
		// (get) Token: 0x0600139F RID: 5023 RVA: 0x0000DDC3 File Offset: 0x0000BFC3
		// (set) Token: 0x060013A0 RID: 5024 RVA: 0x00079560 File Offset: 0x00077760
		public bool IsOneTimeSetupCompleted
		{
			get
			{
				if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition && GameConfig.Instance.AppGenericAction == GenericAction.InstallCDN)
				{
					return true;
				}
				if (!this.mIsOneTimeSetupCompleted)
				{
					this.StartOTSCheckThread();
				}
				return this.mIsOneTimeSetupCompleted;
			}
			set
			{
				this.mIsOneTimeSetupCompleted = value;
				this.ParentWindow.EngineInstanceRegistry.IsOneTimeSetupDone = value;
				Logger.Info("One time setup completed. Will perform tasks now");
				object obj = this.sOTSLock;
				lock (obj)
				{
					Logger.Info("Performing OTS completed tasks");
					if (value && this.EventOnOneTimeSetupCompleted != null)
					{
						this.EventOnOneTimeSetupCompleted(this.ParentWindow, new EventArgs());
						this.EventOnOneTimeSetupCompleted = null;
					}
				}
			}
		}

		// Token: 0x060013A1 RID: 5025 RVA: 0x000795E8 File Offset: 0x000777E8
		private void StartOTSCheckThread()
		{
			if (this.mOtsCheckThread == null)
			{
				object obj = this.mOtsCheckLock;
				lock (obj)
				{
					if (this.mOtsCheckThread == null)
					{
						try
						{
							this.mOtsCheckThread = new Thread(delegate()
							{
								Logger.Info("Checking for if OTS completed");
								while (!this.mIsOneTimeSetupCompleted)
								{
									this.CheckingOneTimeSetupCompleted();
									Thread.Sleep(2 * this.oneSecond);
								}
							});
							this.mOtsCheckThread.IsBackground = true;
							this.mOtsCheckThread.Start();
						}
						catch (Exception ex)
						{
							Logger.Error("Failed to create ots check thread.");
							Logger.Error(ex.ToString());
						}
					}
				}
			}
		}

		// Token: 0x17000225 RID: 549
		// (get) Token: 0x060013A2 RID: 5026 RVA: 0x0000DDF5 File Offset: 0x0000BFF5
		// (set) Token: 0x060013A3 RID: 5027 RVA: 0x0000DE0B File Offset: 0x0000C00B
		public bool IsGuestReady
		{
			get
			{
				if (!this.mIsGuestReady)
				{
					this.SignalGuestReady();
				}
				return this.mIsGuestReady;
			}
			set
			{
				this.mIsGuestReady = value;
			}
		}

		// Token: 0x060013A4 RID: 5028 RVA: 0x0000DE14 File Offset: 0x0000C014
		private void SignalGuestReady()
		{
			if (!FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.ParentWindow.GuestBoot_Completed();
				return;
			}
			this.ParentWindow.Utils.sBootCheckTimer.Enabled = false;
			this.ParentWindow.mEnableLaunchPlayForNCSoft = true;
		}

		// Token: 0x060013A5 RID: 5029 RVA: 0x00079680 File Offset: 0x00077880
		private bool CheckIfGuestReady()
		{
			try
			{
				if (JObject.Parse(HTTPUtils.SendRequestToGuest("checkIfGuestReady", null, this.ParentWindow.mVmName, 1000, null, false, 1, 0))["result"].ToString().Equals("ok"))
				{
					Logger.Info("Received ok for isGuestReady.");
					return true;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Ignoring Exception in CheckifGuestReady, Error: " + ex.ToString());
			}
			return false;
		}

		// Token: 0x060013A6 RID: 5030 RVA: 0x00079708 File Offset: 0x00077908
		private void CheckingOneTimeSetupCompleted()
		{
			try
			{
				string text = JObject.Parse(HTTPUtils.SendRequestToGuest("isOTSCompleted", null, this.ParentWindow.mVmName, 1000, null, false, 1, 0))["result"].ToString();
				if (text.Equals("ok", StringComparison.InvariantCultureIgnoreCase))
				{
					Logger.Info("OTS result: {0}", new object[]
					{
						text
					});
					this.IsOneTimeSetupCompleted = true;
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Exception in checking OneTimeSetupCompleted with vmName {0}. Err: {1}", new object[]
				{
					this.ParentWindow.mVmName,
					ex.Message
				});
			}
		}

		// Token: 0x17000226 RID: 550
		// (get) Token: 0x060013A7 RID: 5031 RVA: 0x0000DE50 File Offset: 0x0000C050
		// (set) Token: 0x060013A8 RID: 5032 RVA: 0x0000DE58 File Offset: 0x0000C058
		public string SwitchWhenPackageNameRecieved
		{
			get
			{
				return this.mSwitchWhenPackageNameRecieved;
			}
			set
			{
				this.mSwitchWhenPackageNameRecieved = value;
				if (!string.IsNullOrEmpty(this.mSwitchWhenPackageNameRecieved) && this.mSwitchWhenPackageNameRecieved.Equals(this.mLastAppDisplayed, StringComparison.InvariantCultureIgnoreCase))
				{
					this.AppLaunched(this.mSwitchWhenPackageNameRecieved, true);
				}
			}
		}

		// Token: 0x060013A9 RID: 5033 RVA: 0x000797B0 File Offset: 0x000779B0
		internal AppHandler(MainWindow window)
		{
			this.ParentWindow = window;
			string cdnappsTimeStamp = RegistryManager.Instance.CDNAppsTimeStamp;
			if (!string.IsNullOrEmpty(cdnappsTimeStamp))
			{
				StringReader textReader = new StringReader(cdnappsTimeStamp);
				XmlSerializer xmlSerializer = new XmlSerializer(typeof(SerializableDictionary<string, DateTime>));
				this.mCdnAppdict = (SerializableDictionary<string, DateTime>)xmlSerializer.Deserialize(textReader);
			}
			this.mIsOneTimeSetupCompleted = this.ParentWindow.EngineInstanceRegistry.IsOneTimeSetupDone;
		}

		// Token: 0x060013AA RID: 5034 RVA: 0x000798A0 File Offset: 0x00077AA0
		public bool IsAppInstalled(string package)
		{
			bool result = false;
			string empty = string.Empty;
			if (new JsonParser(this.ParentWindow.mVmName).IsAppInstalled(package, out empty))
			{
				result = true;
			}
			return result;
		}

		// Token: 0x060013AB RID: 5035 RVA: 0x000798D4 File Offset: 0x00077AD4
		public bool IsAppInstalled(string package, out string version)
		{
			bool result = false;
			if (new JsonParser(this.ParentWindow.mVmName).IsAppInstalled(package, out version))
			{
				result = true;
			}
			return result;
		}

		// Token: 0x060013AC RID: 5036 RVA: 0x00079900 File Offset: 0x00077B00
		public void AppLaunched(string packageName, bool forced = false)
		{
			object obj = this.sLockObject;
			lock (obj)
			{
				if (!this.ParentWindow.mClosed)
				{
					if ((packageName == BlueStacksUIUtils.sUserAccountPackageName || packageName == "com.android.vending") && this.mSwitchWhenPackageNameRecieved == "com.android.vending")
					{
						packageName = this.mSwitchWhenPackageNameRecieved;
						if (string.Compare(this.mLastRunAppSentForSynced, packageName, true) == 0)
						{
							this.mSwitchWhenPackageNameRecieved = "";
						}
					}
					if (!packageName.Equals(this.mLastAppDisplayed, StringComparison.InvariantCultureIgnoreCase) || forced)
					{
						if (!this.mIsOneTimeSetupCompleted)
						{
							if (packageName.StartsWith("com.google.android.gms", StringComparison.InvariantCultureIgnoreCase) || packageName.Equals("com.google.android.setupwizard", StringComparison.InvariantCultureIgnoreCase))
							{
								this.StartOTSCheckThread();
							}
						}
						else
						{
							Logger.Info("SwitchWhenPackageNameRecieved: {0}", new object[]
							{
								this.mSwitchWhenPackageNameRecieved
							});
							this.ParentWindow.ShowLoadingGrid(false);
							bool receivedFromImap = string.Compare(this.mLastRunAppSentForSynced, packageName, true) == 0;
							if (receivedFromImap)
							{
								this.mLastRunAppSentForSynced = "";
							}
							if (!string.IsNullOrEmpty(this.mSwitchWhenPackageNameRecieved) && packageName.Equals(this.mSwitchWhenPackageNameRecieved, StringComparison.InvariantCultureIgnoreCase))
							{
								this.mSwitchWhenPackageNameRecieved = string.Empty;
								if (AppHandler.EventOnAppDisplayed == null)
								{
									this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
									{
										this.ParentWindow.mTopBar.mAppTabButtons.GoToTab(packageName, receivedFromImap, false);
									}), new object[0]);
								}
								else
								{
									EventHandler<EventArgs> eventOnAppDisplayed = AppHandler.EventOnAppDisplayed;
									AppHandler.EventOnAppDisplayed = null;
									eventOnAppDisplayed(this.ParentWindow, new EventArgs());
								}
							}
							else if (this.mDefaultLauncher.Equals(packageName, StringComparison.InvariantCultureIgnoreCase))
							{
								if (!FeatureManager.Instance.IsCustomUIForDMM)
								{
									Logger.Info("Assuming app is crashed/exited going to last tab");
									this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
									{
										if (this.ParentWindow.mFrontendGrid != null)
										{
											if (this.ParentWindow.mFrontendGrid.Parent as Grid == this.ParentWindow.FrontendParentGrid)
											{
												if (this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab != null && this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.mTabType == TabType.AppTab)
												{
													this.ParentWindow.mTopBar.mAppTabButtons.CloseTab(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.TabKey, false, false, true, false, packageName);
												}
												if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
												{
													this.PerformGamingAction("", "");
													return;
												}
											}
											else
											{
												this.ParentWindow.mWelcomeTab.mFrontendPopupControl.HideWindow();
											}
										}
									}), new object[0]);
								}
							}
							else
							{
								AppIcon icon = this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon(packageName);
								if (icon != null)
								{
									this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
									{
										this.ParentWindow.mTopBar.mAppTabButtons.AddAppTab(icon.AppName, icon.PackageName, icon.ActivityName, icon.ImageName, true, false, icon.PackageName, receivedFromImap);
									}), new object[0]);
								}
							}
							this.mLastAppDisplayed = packageName;
						}
					}
				}
			}
		}

		// Token: 0x060013AD RID: 5037 RVA: 0x00079BD8 File Offset: 0x00077DD8
		public void HandleAppDisplayed(string packageName)
		{
			this.mAppDisplayed = packageName;
			if (this.mAppDisplayed.Equals(this.mDefaultLauncher))
			{
				Logger.Info("Home app is displayed...closing tab");
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					if (this.ParentWindow.mFrontendGrid != null && this.ParentWindow.mFrontendGrid.Parent as Grid == this.ParentWindow.FrontendParentGrid && this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab != null && this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.mTabType == TabType.AppTab)
					{
						this.ParentWindow.mTopBar.mAppTabButtons.CloseTab(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.TabKey, false, false, true, false, "");
					}
				}), new object[0]);
			}
		}

		// Token: 0x060013AE RID: 5038 RVA: 0x0000DE8F File Offset: 0x0000C08F
		internal void GoHome()
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				VmCmdHandler.RunCommand("home", this.ParentWindow.mVmName);
			});
		}

		// Token: 0x060013AF RID: 5039 RVA: 0x00079C2C File Offset: 0x00077E2C
		public string GetDefaultLauncher()
		{
			string result = "com.bluestacks.appmart";
			try
			{
				string text = HTTPUtils.SendRequestToGuest("getDefaultLauncher", null, this.ParentWindow.mVmName, 0, null, false, 1, 0);
				Logger.Info("GetDefaultLauncher response = " + text);
				JObject jobject = JObject.Parse(text);
				string a = jobject["result"].ToString().Trim();
				if (a == "ok")
				{
					result = jobject["defaultLauncher"].ToString().Trim();
				}
				else if (a == "error" && jobject["reason"].ToString().Trim() == "no default launcher")
				{
					result = "none";
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GetDefauntLauncher. Err." + ex.ToString());
			}
			return result;
		}

		// Token: 0x060013B0 RID: 5040 RVA: 0x0000DEA3 File Offset: 0x0000C0A3
		internal void StartCustomActivity(Dictionary<string, string> data)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					Logger.Info("Starting a custom activity");
					foreach (KeyValuePair<string, string> keyValuePair in data)
					{
						Logger.Debug("Data = {0} , {1}", new object[]
						{
							keyValuePair.Key,
							keyValuePair.Value
						});
					}
					HTTPUtils.SendRequestToGuest("customStartActivity", data, this.ParentWindow.mVmName, 0, null, false, 1, 0);
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in launching custom activity. Err: " + ex.Message);
				}
			});
		}

		// Token: 0x060013B1 RID: 5041 RVA: 0x0000DEC9 File Offset: 0x0000C0C9
		internal void SetDefaultLauncher(string launcherName)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					string text = HTTPUtils.SendRequestToGuest("setDefaultLauncher", new Dictionary<string, string>
					{
						{
							"d",
							launcherName
						}
					}, this.ParentWindow.mVmName, 0, null, false, 1, 0);
					Logger.Info("Setlauncher res: {0}", new object[]
					{
						text
					});
					text = HTTPUtils.SendRequestToGuest("home", new Dictionary<string, string>
					{
						{
							"arg",
							""
						}
					}, this.ParentWindow.mVmName, 0, null, false, 1, 0);
					Logger.Info("the response for home command is {0}", new object[]
					{
						text
					});
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in SetDefaultLauncher. Err:{0}", new object[]
					{
						ex.ToString()
					});
				}
			});
		}

		// Token: 0x060013B2 RID: 5042 RVA: 0x00079D10 File Offset: 0x00077F10
		internal void AppUninstalled(string package)
		{
			this.ParentWindow.mWelcomeTab.mHomeApp.RemoveAppIcon(package);
			this.ParentWindow.mWelcomeTab.mHomeApp.RemoveAppIcon(package + "_macro");
			this.ParentWindow.mTopBar.mAppTabButtons.CloseTab(package, false, false, true, false, "");
			if (PackageActivityNames.ThirdParty.AllPUBGPackageNames.Contains(package))
			{
				this.ParentWindow.EngineInstanceRegistry.PUBGLaunchedCount = 0;
			}
		}

		// Token: 0x060013B3 RID: 5043 RVA: 0x00079D90 File Offset: 0x00077F90
		internal void AppInstalled(string package)
		{
			this.ParentWindow.mWelcomeTab.mHomeApp.AddAppIcon(package);
			if (FeatureManager.Instance.IsShowAppRecommendations || !RegistryManager.Instance.IsPremium)
			{
				this.ParentWindow.mWelcomeTab.mHomeApp.UpdateRecommendedAppsInstallStatus(package);
			}
			if (PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.Contains(package))
			{
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					this.ParentWindow.mTopBar.mSettingsBtnNotification.Visibility = Visibility.Visible;
					this.ParentWindow.mTopBar.mPreferenceDropDownControl.mSettingsBtnNotification.Visibility = Visibility.Visible;
				}), new object[0]);
			}
		}

		// Token: 0x060013B4 RID: 5044 RVA: 0x0000DEEF File Offset: 0x0000C0EF
		internal void UpdateDefaultLauncher()
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				string text = this.GetDefaultLauncher();
				Logger.Info("DefaultLauncher " + text);
				if (text.Equals("none", StringComparison.InvariantCultureIgnoreCase))
				{
					text = "com.bluestacks.appmart";
					this.SetDefaultLauncher(text);
				}
				if (text.Equals("com.android.provision", StringComparison.InvariantCultureIgnoreCase))
				{
					text = "com.bluestacks.appmart";
				}
				this.mDefaultLauncher = text;
			});
		}

		// Token: 0x060013B5 RID: 5045 RVA: 0x0000DF03 File Offset: 0x0000C103
		internal void SendSearchPlayRequestAsync(string searchQuery)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				if (searchQuery.Contains("search::"))
				{
					searchQuery = searchQuery.Remove(0, 8);
				}
				VmCmdHandler.RunCommand(string.Format("searchplay {0}", searchQuery), this.ParentWindow.mVmName);
			});
		}

		// Token: 0x060013B6 RID: 5046 RVA: 0x0000DF29 File Offset: 0x0000C129
		internal void LaunchPlayRequestAsync(string packageName)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				VmCmdHandler.RunCommand(string.Format("launchplay?pkgname={0}", packageName), this.ParentWindow.mVmName);
			});
		}

		// Token: 0x060013B7 RID: 5047 RVA: 0x0000DF4F File Offset: 0x0000C14F
		public void SendRunAppRequestAsync(string package, string activity = "", bool receivedFromImap = false)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				if (this.ParentWindow.SendClientActions && !receivedFromImap)
				{
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					Dictionary<string, string> dictionary2 = new Dictionary<string, string>();
					dictionary2.Add("EventAction", "RunApp");
					dictionary2.Add("Package", package);
					dictionary2.Add("Activity", activity);
					JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
					serializerSettings.Formatting = Formatting.None;
					dictionary.Add("operationData", JsonConvert.SerializeObject(dictionary2, serializerSettings));
					this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("handleClientOperation", dictionary);
				}
				if (receivedFromImap)
				{
					this.mLastRunAppSentForSynced = package;
					if (package == "com.android.vending")
					{
						this.mSwitchWhenPackageNameRecieved = package;
					}
				}
				if (string.IsNullOrEmpty(activity))
				{
					AppIcon appIcon = this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon(package);
					if (appIcon != null)
					{
						activity = appIcon.ActivityName;
					}
					if (string.IsNullOrEmpty(activity))
					{
						activity = ".Main";
						Logger.Info("Empty activity name ovveriding .Main for package: " + package);
					}
				}
				if (PackageActivityNames.ThirdParty.AllPUBGPackageNames.Contains(package))
				{
					string displayQualityPubg = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityPubg;
					string gamingResolutionPubg = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GamingResolutionPubg;
					if (string.Equals(displayQualityPubg, "-1") && string.Equals(gamingResolutionPubg, "1"))
					{
						this.SendRunex(package, activity);
						return;
					}
					StringBuilder stringBuilder = new StringBuilder();
					using (JsonWriter jsonWriter = new JsonTextWriter(new StringWriter(stringBuilder)))
					{
						jsonWriter.WriteStartObject();
						if (RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityPubg.Equals("-1"))
						{
							jsonWriter.WritePropertyName("renderqualitylevel");
							jsonWriter.WriteValue("0");
						}
						else
						{
							jsonWriter.WritePropertyName("renderqualitylevel");
							jsonWriter.WriteValue(RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityPubg);
						}
						jsonWriter.WritePropertyName("contentscale");
						jsonWriter.WriteValue(RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GamingResolutionPubg);
						jsonWriter.WriteEndObject();
					}
					string str = HTTPUtils.SendRequestToGuest("customStartActivity", new Dictionary<string, string>
					{
						{
							"component",
							package + "/" + activity
						},
						{
							"extras",
							stringBuilder.ToString()
						}
					}, this.ParentWindow.mVmName, 0, null, false, 1, 0);
					Logger.Info("The response we get is: " + str);
					return;
				}
				else
				{
					if (PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.Contains(package))
					{
						string displayQualityCOD = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityCOD;
						string gamingResolutionCOD = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GamingResolutionCOD;
						StringBuilder stringBuilder2 = new StringBuilder();
						using (JsonWriter jsonWriter2 = new JsonTextWriter(new StringWriter(stringBuilder2)))
						{
							jsonWriter2.WriteStartObject();
							if (RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityCOD.Equals("-1"))
							{
								jsonWriter2.WritePropertyName("QualityLevel");
								jsonWriter2.WriteValue("0");
							}
							else
							{
								jsonWriter2.WritePropertyName("QualityLevel");
								jsonWriter2.WriteValue(RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityCOD);
							}
							jsonWriter2.WritePropertyName("ResolutionHeight");
							jsonWriter2.WriteValue(RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GamingResolutionCOD);
							jsonWriter2.WritePropertyName("FrameRateLevel");
							jsonWriter2.WriteValue("1");
							jsonWriter2.WriteEndObject();
						}
						string str2 = HTTPUtils.SendRequestToGuest("customStartActivity", new Dictionary<string, string>
						{
							{
								"component",
								package + "/" + activity
							},
							{
								"extras",
								stringBuilder2.ToString()
							}
						}, this.ParentWindow.mVmName, 0, null, false, 1, 0);
						Logger.Info("The response we get is: " + str2);
						return;
					}
					this.SendRunex(package, activity);
					return;
				}
			});
		}

		// Token: 0x060013B8 RID: 5048 RVA: 0x0000DF83 File Offset: 0x0000C183
		internal void SendRunex(string package, string activity)
		{
			VmCmdHandler.RunCommand(string.Format("runex {0}/{1}", package, activity), this.ParentWindow.mVmName);
		}

		// Token: 0x060013B9 RID: 5049 RVA: 0x0000DFA2 File Offset: 0x0000C1A2
		internal void StopAppRequest(string packageName)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					Logger.Info("Will send stop {0} request", new object[]
					{
						packageName
					});
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					dictionary.Add("appPackage", packageName);
					string text = this.ParentWindow.mFrontendHandler.SendFrontendRequest("stopAppInfo", dictionary);
					Logger.Info("the response we get is {0}", new object[]
					{
						text
					});
					Logger.Info(VmCmdHandler.RunCommand(string.Format("StopApp {0}", packageName), this.ParentWindow.mVmName));
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in StopAppRequest. Err : " + ex.ToString());
				}
			});
		}

		// Token: 0x060013BA RID: 5050 RVA: 0x0000DFC8 File Offset: 0x0000C1C8
		internal void SendRequestToRemoveAccountAndCloseWindowASync(bool closeWindow = false)
		{
			Action <>9__1;
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					string str = HTTPUtils.SendRequestToGuest("removeAccountsInfo", null, this.ParentWindow.mVmName, 0, null, false, 1, 0);
					Logger.Info("Account removed response: " + str);
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in removing account, Ex: " + ex.Message);
				}
				if (closeWindow)
				{
					Dispatcher dispatcher = this.ParentWindow.Dispatcher;
					Action method;
					if ((method = <>9__1) == null)
					{
						method = (<>9__1 = delegate()
						{
							this.ParentWindow.ForceCloseWindow();
						});
					}
					dispatcher.Invoke(method, new object[0]);
				}
			});
		}

		// Token: 0x060013BB RID: 5051 RVA: 0x00079E14 File Offset: 0x00078014
		internal void WriteXMl(bool isAppInstall, string packageName, DateTime timestamp)
		{
			if (isAppInstall)
			{
				this.mCdnAppdict[packageName] = timestamp;
				StringWriter stringWriter = new StringWriter();
				new XmlSerializer(typeof(SerializableDictionary<string, DateTime>)).Serialize(stringWriter, this.mCdnAppdict);
				RegistryManager.Instance.CDNAppsTimeStamp = stringWriter.ToString();
				return;
			}
			if (this.mCdnAppdict.ContainsKey(packageName))
			{
				this.mCdnAppdict.Remove(packageName);
				StringWriter stringWriter2 = new StringWriter();
				new XmlSerializer(typeof(SerializableDictionary<string, DateTime>)).Serialize(stringWriter2, this.mCdnAppdict);
				RegistryManager.Instance.CDNAppsTimeStamp = stringWriter2.ToString();
			}
		}

		// Token: 0x060013BC RID: 5052 RVA: 0x00079EB0 File Offset: 0x000780B0
		internal void PerformGamingAction(string pkgName = "", string activityName = "")
		{
			GenericAction action;
			if (pkgName == "")
			{
				pkgName = GameConfig.Instance.PkgName;
				activityName = GameConfig.Instance.ActivityName;
				action = GameConfig.Instance.AppGenericAction;
			}
			else
			{
				action = GenericAction.InstallPlay;
			}
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (this.IsAppInstalled(pkgName))
				{
					this.SendRunAppRequestAsync(pkgName, "", false);
					return;
				}
				GenericAction action = action;
				if (action == GenericAction.InstallPlay)
				{
					this.LaunchPlayRequestAsync(pkgName);
				}
			}), new object[0]);
		}

		// Token: 0x04000DAB RID: 3499
		public SerializableDictionary<string, DateTime> mCdnAppdict = new SerializableDictionary<string, DateTime>();

		// Token: 0x04000DAC RID: 3500
		private MainWindow ParentWindow;

		// Token: 0x04000DAD RID: 3501
		public string mLastAppDisplayed = string.Empty;

		// Token: 0x04000DAE RID: 3502
		private string mAppDisplayed = string.Empty;

		// Token: 0x04000DAF RID: 3503
		public string mLastRunAppSentForSynced = string.Empty;

		// Token: 0x04000DB0 RID: 3504
		public string mAppDisplayedOccured = string.Empty;

		// Token: 0x04000DB1 RID: 3505
		private Thread mOtsCheckThread;

		// Token: 0x04000DB2 RID: 3506
		private object mOtsCheckLock = new object();

		// Token: 0x04000DB3 RID: 3507
		private int oneSecond = 1000;

		// Token: 0x04000DB4 RID: 3508
		public static List<string> sListIgnoredApps = new List<string>
		{
			"tv.gamepop.home",
			"com.pop.store",
			"com.pop.store51",
			"com.bluestacks.s2p5105",
			"com.bluestacks.help",
			"mpi.v23",
			"com.google.android.gms",
			"com.google.android.gsf.login",
			"com.android.deskclock",
			"me.onemobile.android",
			"me.onemobile.lite.android",
			"android.rk.RockVideoPlayer.RockVideoPlayer",
			"com.bluestacks.chartapp",
			"com.bluestacks.setupapp",
			"com.android.gallery3d",
			"com.bluestacks.keymappingtool",
			"com.baidu.appsearch",
			"com.bluestacks.s2p",
			"com.bluestacks.windowsfilemanager",
			"com.android.quicksearchbox",
			"com.bluestacks.setup",
			"com.bluestacks.appsettings",
			"mpi.v23",
			"com.bluestacks.setup",
			"com.bluestacks.gamepophome",
			"com.bluestacks.appfinder",
			"com.android.providers.downloads.ui",
			"com.google.android.instantapps.supervisor"
		};

		// Token: 0x04000DB5 RID: 3509
		private bool mIsOneTimeSetupCompleted;

		// Token: 0x04000DB6 RID: 3510
		private bool mIsGuestReady;

		// Token: 0x04000DB7 RID: 3511
		private object mGuestReadyCheckLock = new object();

		// Token: 0x04000DB8 RID: 3512
		internal bool mGuestReadyCheckStarted;

		// Token: 0x04000DB9 RID: 3513
		internal string mDefaultLauncher = "com.bluestacks.appmart";

		// Token: 0x04000DBA RID: 3514
		private object sLockObject = new object();

		// Token: 0x04000DBB RID: 3515
		private object sOTSLock = new object();

		// Token: 0x04000DBC RID: 3516
		private string mSwitchWhenPackageNameRecieved = string.Empty;

		// Token: 0x04000DBD RID: 3517
		public EventHandler<EventArgs> EventOnOneTimeSetupCompleted;

		// Token: 0x04000DBE RID: 3518
		public static EventHandler<EventArgs> EventOnAppDisplayed;
	}
}
