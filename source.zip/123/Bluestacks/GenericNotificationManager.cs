﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200003C RID: 60
	internal sealed class GenericNotificationManager
	{
		// Token: 0x06000319 RID: 793 RVA: 0x000041D4 File Offset: 0x000023D4
		private GenericNotificationManager()
		{
		}

		// Token: 0x17000110 RID: 272
		// (get) Token: 0x0600031A RID: 794 RVA: 0x00017E70 File Offset: 0x00016070
		public static GenericNotificationManager Instance
		{
			get
			{
				if (GenericNotificationManager.sInstance == null)
				{
					object obj = GenericNotificationManager.syncRoot;
					lock (obj)
					{
						if (GenericNotificationManager.sInstance == null)
						{
							GenericNotificationManager.sInstance = new GenericNotificationManager();
						}
					}
				}
				return GenericNotificationManager.sInstance;
			}
		}

		// Token: 0x17000111 RID: 273
		// (get) Token: 0x0600031B RID: 795 RVA: 0x000041E7 File Offset: 0x000023E7
		internal static string GenericNotificationFilePath
		{
			get
			{
				return Path.Combine(RegistryStrings.PromotionDirectory, "bst_genericNotification");
			}
		}

		// Token: 0x0600031C RID: 796 RVA: 0x00017EC8 File Offset: 0x000160C8
		public void AddNewNotification(GenericNotificationItem notificationItem, bool dontOverwrite = false)
		{
			int i = 3;
			while (i > 0)
			{
				i--;
				try
				{
					SerializableDictionary<string, GenericNotificationItem> savedNotifications = this.GetSavedNotifications();
					if (!dontOverwrite)
					{
						savedNotifications[notificationItem.Id] = notificationItem;
						this.SaveNotifications(savedNotifications);
					}
					else if (!savedNotifications.ContainsKey(notificationItem.Id))
					{
						savedNotifications[notificationItem.Id] = notificationItem;
						this.SaveNotifications(savedNotifications);
					}
					break;
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to add notification id : {0} titled : {1} and msg : {2}... Err : {3}", new object[]
					{
						notificationItem.Id,
						notificationItem.Title,
						notificationItem.Message,
						ex.ToString()
					});
				}
			}
		}

		// Token: 0x0600031D RID: 797 RVA: 0x00017F70 File Offset: 0x00016170
		private void SaveNotifications(SerializableDictionary<string, GenericNotificationItem> lstItem)
		{
			using (XmlTextWriter xmlTextWriter = new XmlTextWriter(GenericNotificationManager.GenericNotificationFilePath, Encoding.UTF8))
			{
				xmlTextWriter.Formatting = Formatting.Indented;
				new XmlSerializer(typeof(SerializableDictionary<string, GenericNotificationItem>)).Serialize(xmlTextWriter, lstItem);
				xmlTextWriter.Flush();
			}
			this.mDict = lstItem;
		}

		// Token: 0x0600031E RID: 798 RVA: 0x00017FD4 File Offset: 0x000161D4
		private SerializableDictionary<string, GenericNotificationItem> GetSavedNotifications()
		{
			SerializableDictionary<string, GenericNotificationItem> result = new SerializableDictionary<string, GenericNotificationItem>();
			if (File.Exists(GenericNotificationManager.GenericNotificationFilePath))
			{
				try
				{
					using (FileStream fileStream = File.OpenRead(GenericNotificationManager.GenericNotificationFilePath))
					{
						result = (SerializableDictionary<string, GenericNotificationItem>)new XmlSerializer(typeof(SerializableDictionary<string, GenericNotificationItem>)).Deserialize(fileStream);
						fileStream.Flush();
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception when reading saved notifications." + ex.ToString());
				}
			}
			return result;
		}

		// Token: 0x0600031F RID: 799 RVA: 0x00018064 File Offset: 0x00016264
		internal GenericNotificationItem GetNotificationItem(string id)
		{
			if (this.mDict.ContainsKey(id))
			{
				return this.mDict[id];
			}
			SerializableDictionary<string, GenericNotificationItem> notificationItems = this.GetNotificationItems((GenericNotificationItem _) => _.Id == id);
			if (notificationItems.Count > 0)
			{
				return notificationItems.First<KeyValuePair<string, GenericNotificationItem>>().Value;
			}
			return null;
		}

		// Token: 0x06000320 RID: 800 RVA: 0x000180D0 File Offset: 0x000162D0
		public SerializableDictionary<string, GenericNotificationItem> MarkNotification(IEnumerable<string> ids, Action<GenericNotificationItem> setter)
		{
			int i = 3;
			SerializableDictionary<string, GenericNotificationItem> serializableDictionary = new SerializableDictionary<string, GenericNotificationItem>();
			while (i > 0)
			{
				i--;
				try
				{
					serializableDictionary = this.GetSavedNotifications();
					foreach (string text in ids)
					{
						if (text != null && serializableDictionary.ContainsKey(text))
						{
							setter(serializableDictionary[text]);
						}
					}
					this.SaveNotifications(serializableDictionary);
					break;
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to mark notification... Err : " + ex.ToString());
				}
			}
			return serializableDictionary;
		}

		// Token: 0x06000321 RID: 801 RVA: 0x00018174 File Offset: 0x00016374
		public SerializableDictionary<string, GenericNotificationItem> GetNotificationItems(Predicate<GenericNotificationItem> getter)
		{
			int i = 3;
			SerializableDictionary<string, GenericNotificationItem> serializableDictionary = new SerializableDictionary<string, GenericNotificationItem>();
			SerializableDictionary<string, GenericNotificationItem> serializableDictionary2 = new SerializableDictionary<string, GenericNotificationItem>();
			while (i > 0)
			{
				i--;
				try
				{
					serializableDictionary = this.GetSavedNotifications();
					break;
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to get notification... Err : " + ex.ToString());
				}
			}
			foreach (KeyValuePair<string, GenericNotificationItem> keyValuePair in serializableDictionary)
			{
				if (getter(keyValuePair.Value))
				{
					serializableDictionary2.Add(keyValuePair.Key, keyValuePair.Value);
				}
			}
			return serializableDictionary2;
		}

		// Token: 0x040001A9 RID: 425
		private static volatile GenericNotificationManager sInstance;

		// Token: 0x040001AA RID: 426
		private static object syncRoot = new object();

		// Token: 0x040001AB RID: 427
		private SerializableDictionary<string, GenericNotificationItem> mDict = new SerializableDictionary<string, GenericNotificationItem>();
	}
}
