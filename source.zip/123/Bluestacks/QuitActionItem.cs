﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000041 RID: 65
	public enum QuitActionItem
	{
		// Token: 0x040001BA RID: 442
		None,
		// Token: 0x040001BB RID: 443
		StuckAtBoot,
		// Token: 0x040001BC RID: 444
		SomethingElseWrong,
		// Token: 0x040001BD RID: 445
		SlowPerformance,
		// Token: 0x040001BE RID: 446
		WhyGoogleAccount,
		// Token: 0x040001BF RID: 447
		TroubleSigningIn
	}
}
