﻿using System;
using System.Collections.Generic;
using System.Globalization;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000036 RID: 54
	internal sealed class CloudNotificationManager
	{
		// Token: 0x060002B7 RID: 695 RVA: 0x00003202 File Offset: 0x00001402
		private CloudNotificationManager()
		{
		}

		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x060002B8 RID: 696 RVA: 0x00016F18 File Offset: 0x00015118
		public static CloudNotificationManager Instance
		{
			get
			{
				if (CloudNotificationManager.sInstance == null)
				{
					object obj = CloudNotificationManager.syncRoot;
					lock (obj)
					{
						if (CloudNotificationManager.sInstance == null)
						{
							CloudNotificationManager.sInstance = new CloudNotificationManager();
						}
					}
				}
				return CloudNotificationManager.sInstance;
			}
		}

		// Token: 0x060002B9 RID: 697 RVA: 0x00016F70 File Offset: 0x00015170
		internal void HandleCloudNotification(string jsonReceived, string vmName)
		{
			try
			{
				Logger.Info("CloudFireBaseNotification response received: " + jsonReceived + " from vm: " + vmName);
				JObject jobject = JObject.Parse(jsonReceived);
				if (jobject.Property("bluestacks_notification") != null && jobject["bluestacks_notification"].ToObject<JObject>().Property("tag") != null && !JsonExtensions.IsNullOrEmptyBrackets(jobject["bluestacks_notification"].GetValue("tag")))
				{
					this.HandleTagsInfo(jobject, vmName, jsonReceived);
				}
				if (jobject.Property("bluestacks_notification") != null && jobject["bluestacks_notification"].ToObject<JObject>().Property("type") != null)
				{
					string a = jobject["bluestacks_notification"]["type"].ToString().ToLower();
					if (!(a == "genericnotification"))
					{
						if (!(a == "genericreddotnotification"))
						{
							if (!(a == "callmethod"))
							{
								Logger.Warning("No notification type found in HandleCloudNotification. json: " + jsonReceived);
							}
							else
							{
								this.HandleCallMethod(jobject, vmName);
							}
						}
						else
						{
							this.HandleGenericRedDotNotification(jobject, vmName);
						}
					}
					else
					{
						this.HandleGenericNotification(jobject, vmName);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in HandleCloudNotification. json: " + jsonReceived + " Error: " + ex.ToString());
			}
		}

		// Token: 0x060002BA RID: 698 RVA: 0x000170C8 File Offset: 0x000152C8
		private void HandleTagsInfo(JObject json, string vmName, string jsonReceived)
		{
			try
			{
				foreach (string text in json["bluestacks_notification"]["tag"].ToObject<List<string>>())
				{
					if (BrowserControl.mFirebaseTagsSubscribed.Contains(text))
					{
						this.SendNotifJsonToHtmlTag(text, jsonReceived);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in HandleTagsInfo: " + ex.ToString());
			}
		}

		// Token: 0x060002BB RID: 699 RVA: 0x00017164 File Offset: 0x00015364
		private void SendNotifJsonToHtmlTag(string tag, string data)
		{
			try
			{
				object[] array = new object[]
				{
					""
				};
				if (!string.IsNullOrEmpty(data))
				{
					array[0] = data;
				}
				foreach (BrowserControl browserControl in BrowserControl.sAllBrowserControls)
				{
					if (browserControl != null && browserControl.mBrowser != null)
					{
						browserControl.mBrowser.CallJs(browserControl.mFirebaseCallbackMethod, array);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in sending json to appcenter:" + ex.ToString());
			}
		}

		// Token: 0x060002BC RID: 700 RVA: 0x00017210 File Offset: 0x00015410
		internal SerializableDictionary<string, string> HandleExtraPayload(JObject json, NotificationPayloadType payloadType, string vmName)
		{
			return json.ToObject<SerializableDictionary<string, string>>();
		}

		// Token: 0x060002BD RID: 701 RVA: 0x0001722C File Offset: 0x0001542C
		internal void HandleGenericRedDotNotification(JObject resJson, string vmName)
		{
			JObject jobject = JObject.Parse(resJson["bluestacks_notification"]["payload"]["GenericRedDotNotificationItem"].ToString());
			if (!JsonExtensions.IsNullOrEmptyBrackets(jobject["myapps_cross_promotion"].ToString()))
			{
				PromotionManager.AddNewMyAppsCrossPromotion(jobject);
				PromotionObject.Instance.Save();
				string appPackage = string.Empty;
				appPackage = jobject["myapps_cross_promotion"]["app_pkg"].ToString();
				BlueStacksUIUtils.DictWindows[vmName].mWelcomeTab.mHomeApp.AddIconWithRedDot(appPackage);
			}
		}

		// Token: 0x060002BE RID: 702 RVA: 0x000172C8 File Offset: 0x000154C8
		internal void HandleGenericNotification(JObject resJson, string vmName)
		{
			GenericNotificationItem genericItem = new GenericNotificationItem();
			try
			{
				JObject jobject = JObject.Parse(resJson["bluestacks_notification"]["payload"]["GenericNotificationItem"].ToString());
				jobject.AssignIfContains("id", delegate(string x)
				{
					genericItem.Id = x;
				});
				jobject.AssignIfContains("priority", delegate(string x)
				{
					genericItem.Priority = EnumHelper.Parse<NotificationPriority>(x, NotificationPriority.Normal);
				});
				jobject.AssignIfContains("title", delegate(string x)
				{
					genericItem.Title = x;
				});
				jobject.AssignIfContains("isdeleted", delegate(bool x)
				{
					genericItem.IsDeleted = x;
				});
				jobject.AssignIfContains("message", delegate(string x)
				{
					genericItem.Message = x;
				});
				jobject.AssignIfContains("showribbon", delegate(bool x)
				{
					genericItem.ShowRibbon = x;
				});
				jobject.AssignIfContains("menuimagename", delegate(string x)
				{
					genericItem.NotificationMenuImageName = x;
				});
				jobject.AssignIfContains("menuimageurl", delegate(string x)
				{
					genericItem.NotificationMenuImageUrl = x;
				});
				jobject.AssignIfContains("isread", delegate(bool x)
				{
					genericItem.IsRead = x;
				});
				jobject.AssignIfContains("isdeleted", delegate(bool x)
				{
					genericItem.IsDeleted = x;
				});
				jobject.AssignIfContains("deferred", delegate(bool x)
				{
					genericItem.IsDeferred = x;
				});
				jobject.AssignIfContains("creationtime", delegate(string x)
				{
					genericItem.CreationTime = DateTime.ParseExact(x, "yyyy/MM/dd HH:mm:ss", CultureInfo.InvariantCulture);
				});
				if (!string.IsNullOrEmpty(genericItem.NotificationMenuImageName) && !string.IsNullOrEmpty(genericItem.NotificationMenuImageUrl))
				{
					genericItem.NotificationMenuImageName = Utils.TinyDownloader(genericItem.NotificationMenuImageUrl, genericItem.NotificationMenuImageName, RegistryStrings.PromotionDirectory, false);
				}
				if (jobject.Property("ExtraPayload") != null && !JsonExtensions.IsNullOrEmptyBrackets(jobject.GetValue("ExtraPayload").ToString()))
				{
					jobject["ExtraPayload"].AssignIfContains("payloadtype", delegate(string x)
					{
						genericItem.PayloadType = EnumHelper.Parse<NotificationPayloadType>(x, NotificationPayloadType.Generic);
					});
					genericItem.ExtraPayload = this.HandleExtraPayload(jobject.GetValue("ExtraPayload").ToObject<JObject>(), genericItem.PayloadType, vmName);
				}
				if (jobject.Property("conditions") != null && !JsonExtensions.IsNullOrEmptyBrackets(jobject.GetValue("conditions").ToString()))
				{
					jobject["conditions"].AssignIfContains("app_pkg_on_top", delegate(string x)
					{
						genericItem.DeferredApp = x;
					});
					jobject["conditions"].AssignIfContains("app_usage_seconds", delegate(long x)
					{
						genericItem.DeferredAppUsage = x;
					});
				}
				if (genericItem.ShowRibbon && resJson["bluestacks_notification"]["payload"].ToObject<JObject>().Property("RibbonDesign") != null && !JsonExtensions.IsNullOrEmptyBrackets(resJson["bluestacks_notification"]["payload"].GetValue("RibbonDesign")))
				{
					genericItem.NotificationDesignItem = new GenericNotificationDesignItem();
					JObject jobject2 = JObject.Parse(resJson["bluestacks_notification"]["payload"]["RibbonDesign"].ToString());
					jobject2.AssignIfContains("titleforegroundcolor", delegate(string x)
					{
						genericItem.NotificationDesignItem.TitleForeGroundColor = x;
					});
					jobject2.AssignIfContains("messageforegroundcolor", delegate(string x)
					{
						genericItem.NotificationDesignItem.MessageForeGroundColor = x;
					});
					jobject2.AssignIfContains("bordercolor", delegate(string x)
					{
						genericItem.NotificationDesignItem.BorderColor = x;
					});
					jobject2.AssignIfContains("ribboncolor", delegate(string x)
					{
						genericItem.NotificationDesignItem.Ribboncolor = x;
					});
					jobject2.AssignIfContains("auto_hide_timer", delegate(double x)
					{
						genericItem.NotificationDesignItem.AutoHideTime = x;
					});
					jobject2.AssignIfContains("hoverbordercolor", delegate(string x)
					{
						genericItem.NotificationDesignItem.HoverBorderColor = x;
					});
					jobject2.AssignIfContains("hoverribboncolor", delegate(string x)
					{
						genericItem.NotificationDesignItem.HoverRibboncolor = x;
					});
					jobject2.AssignIfContains("leftgifname", delegate(string x)
					{
						genericItem.NotificationDesignItem.LeftGifName = x;
					});
					jobject2.AssignIfContains("leftgifurl", delegate(string x)
					{
						genericItem.NotificationDesignItem.LeftGifUrl = x;
					});
					if (!string.IsNullOrEmpty(genericItem.NotificationDesignItem.LeftGifName) && !string.IsNullOrEmpty(genericItem.NotificationDesignItem.LeftGifUrl))
					{
						Utils.TinyDownloader(genericItem.NotificationDesignItem.LeftGifUrl, genericItem.NotificationDesignItem.LeftGifName, RegistryStrings.PromotionDirectory, false);
					}
					if (jobject2.Property("background_gradient") != null)
					{
						foreach (JObject jobject3 in JArray.Parse(jobject2["background_gradient"].ToString()).ToObject<List<JObject>>())
						{
							genericItem.NotificationDesignItem.BackgroundGradient.Add(new SerializableKeyValuePair<string, double>(jobject3["color"].ToString(), jobject3["offset"].ToObject<double>()));
						}
					}
					if (jobject2.Property("hover_background_gradient") != null)
					{
						foreach (JObject jobject4 in JArray.Parse(jobject2["hover_background_gradient"].ToString()).ToObject<List<JObject>>())
						{
							genericItem.NotificationDesignItem.HoverBackGroundGradient.Add(new SerializableKeyValuePair<string, double>(jobject4["color"].ToString(), jobject4["offset"].ToObject<double>()));
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while parsing generic notification. Not showing notification and not adding in notification menu." + ex.ToString());
				return;
			}
			try
			{
				if (string.IsNullOrEmpty(genericItem.Title) && string.IsNullOrEmpty(genericItem.Message))
				{
					genericItem.IsDeleted = true;
				}
				if (!genericItem.IsDeferred)
				{
					GenericNotificationManager.Instance.AddNewNotification(genericItem, false);
				}
				if (genericItem.ShowRibbon && resJson["bluestacks_notification"]["payload"].ToObject<JObject>().Property("RibbonDesign") != null && !JsonExtensions.IsNullOrEmptyBrackets(resJson["bluestacks_notification"]["payload"].GetValue("RibbonDesign")))
				{
					if (!genericItem.IsDeferred)
					{
						BlueStacksUIUtils.DictWindows[vmName].HandleGenericNotificationPopup(genericItem);
					}
					else
					{
						this.HandleDeferredNotification(genericItem);
					}
				}
				BlueStacksUIUtils.DictWindows[vmName].mTopBar.RefreshNotificationCentreButton();
			}
			catch (Exception ex2)
			{
				Logger.Error("Exception when handling notification json. Id " + genericItem.Id + " Error: " + ex2.ToString());
			}
		}

		// Token: 0x060002BF RID: 703 RVA: 0x00003DE6 File Offset: 0x00001FE6
		private void HandleDeferredNotification(GenericNotificationItem genericItem)
		{
			PromotionManager.sDeferredNotificationsList.Add(genericItem, AppUsageTimer.GetTotalTimeForPackageAfterReset(genericItem.DeferredApp.ToLower()));
		}

		// Token: 0x060002C0 RID: 704 RVA: 0x000179E8 File Offset: 0x00015BE8
		internal void HandleCallMethod(JObject resJson, string vmName)
		{
			string text = "";
			JObject.Parse(resJson["bluestacks_notification"]["payload"].ToString()).AssignStringIfContains("methodName", ref text);
			string a = text.ToLower();
			if (a == "appusagestats")
			{
				this.HandleUsageNotification(resJson, vmName);
				return;
			}
			if (a == "updatepromotions")
			{
				PromotionManager.ReloadPromotionsAsync();
				return;
			}
			if (a == "updatebstconfig")
			{
				this.UpdateBstConfig();
				return;
			}
			if (a == "openquitpopup")
			{
				this.OpenQuitPopup(resJson, vmName);
				return;
			}
			if (!(a == "updategrm"))
			{
				Logger.Error("No method type found in HandleCallMethod json: " + resJson);
				return;
			}
			GrmManager.UpdateGrmAsync(resJson["bluestacks_notification"]["payload"]["app_pkg_list"].ToIenumerableString());
		}

		// Token: 0x060002C1 RID: 705 RVA: 0x00003E03 File Offset: 0x00002003
		internal void UpdateBstConfig()
		{
			RegistryManager.Instance.UpdateBstConfig = true;
			FeatureManager.Init(true);
		}

		// Token: 0x060002C2 RID: 706 RVA: 0x00017ACC File Offset: 0x00015CCC
		internal void OpenQuitPopup(JObject resJson, string vmName)
		{
			string text = "";
			string package = "";
			string value = "";
			JObject resJson2 = JObject.Parse(resJson["bluestacks_notification"]["payload"].ToString());
			resJson2.AssignStringIfContains("url", ref text);
			if (!string.IsNullOrEmpty(text))
			{
				resJson2.AssignStringIfContains("app_pkg", ref package);
				resJson2.AssignStringIfContains("force_reload", ref value);
				bool isForceReload = false;
				bool.TryParse(value, out isForceReload);
				BlueStacksUIUtils.DictWindows[vmName].IsQuitPopupNotficationReceived = true;
				BlueStacksUIUtils.DictWindows[vmName].mQuitPopupBrowserControl.SetQuitPopParams(text, package, isForceReload);
				Logger.Info("Notification successfully received, IsQuitPopupNotificationReceived current value: " + BlueStacksUIUtils.DictWindows[vmName].IsQuitPopupNotficationReceived.ToString());
				text = WebHelper.GetUrlWithParams(text);
				object[] args = new object[]
				{
					text
				};
				BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
				{
					(BlueStacksUIUtils.DictWindows[vmName].mFirebaseBrowserControlGrid.Children[0] as BrowserControl).mBrowser.CallJs("setIframeUrl", args);
				}), new object[0]);
				return;
			}
			Logger.Info("Quit Popup notification received without url");
			BlueStacksUIUtils.DictWindows[vmName].IsQuitPopupNotficationReceived = false;
		}

		// Token: 0x060002C3 RID: 707 RVA: 0x00017C48 File Offset: 0x00015E48
		internal void HandleUsageNotification(JObject resJson, string vmName)
		{
			try
			{
				string str = "";
				string jsonobjectString = JSONUtils.GetJSONObjectString(AppUsageTimer.GetRealtimeDictionary());
				JObject.Parse(resJson["bluestacks_notification"]["payload"].ToString()).AssignStringIfContains("handler", ref str);
				string url = WebHelper.GetServerHost() + "/v2/" + str;
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary["oem"] = "bgp";
				dictionary["client_ver"] = RegistryManager.Instance.ClientVersion;
				dictionary["engine_ver"] = RegistryManager.Instance.Version;
				dictionary["guid"] = RegistryManager.Instance.UserGuid;
				dictionary["locale"] = RegistryManager.Instance.UserSelectedLocale;
				dictionary["partner"] = RegistryManager.Instance.Partner;
				dictionary["campaignMD5"] = RegistryManager.Instance.CampaignMD5;
				if (!string.IsNullOrEmpty(RegistryManager.Instance.RegisteredEmail))
				{
					dictionary["email"] = RegistryManager.Instance.RegisteredEmail;
				}
				dictionary["usage_data"] = jsonobjectString;
				if (!dictionary.ContainsKey("current_app"))
				{
					dictionary.Add("current_app", BlueStacksUIUtils.DictWindows[vmName].mTopBar.mAppTabButtons.SelectedTab.PackageName);
				}
				else
				{
					dictionary["current_app"] = BlueStacksUIUtils.DictWindows[vmName].mTopBar.mAppTabButtons.SelectedTab.PackageName;
				}
				string str2 = BstHttpClient.Post(url, dictionary, null, false, string.Empty, 0, 1, 0, false);
				Logger.Info("real time app usage response:" + str2);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in handling usage notification" + ex.ToString());
			}
		}

		// Token: 0x04000188 RID: 392
		private static volatile CloudNotificationManager sInstance;

		// Token: 0x04000189 RID: 393
		private static object syncRoot = new object();
	}
}
