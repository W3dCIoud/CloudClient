﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200005C RID: 92
	public class ImportMacroScriptsControl : UserControl, IComponentConnector
	{
		// Token: 0x060003EE RID: 1006 RVA: 0x00004A19 File Offset: 0x00002C19
		public ImportMacroScriptsControl(ImportMacroWindow importMacroWindow, MainWindow window)
		{
			this.InitializeComponent();
			this.mImportMacroWindow = importMacroWindow;
			this.ParentWindow = window;
		}

		// Token: 0x060003EF RID: 1007 RVA: 0x00004A35 File Offset: 0x00002C35
		private void Box_Checked(object sender, RoutedEventArgs e)
		{
			this.mImportMacroWindow.Box_Checked(sender, e);
		}

		// Token: 0x060003F0 RID: 1008 RVA: 0x00004A44 File Offset: 0x00002C44
		private void Box_Unchecked(object sender, RoutedEventArgs e)
		{
			this.mImportMacroWindow.Box_Unchecked(sender, e);
		}

		// Token: 0x060003F1 RID: 1009 RVA: 0x0001AE18 File Offset: 0x00019018
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/importmacroscriptscontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060003F2 RID: 1010 RVA: 0x0001AE48 File Offset: 0x00019048
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mContent = (CustomCheckbox)target;
				this.mContent.Checked += this.Box_Checked;
				this.mContent.Unchecked += this.Box_Unchecked;
				return;
			case 2:
				this.mBlock = (Grid)target;
				return;
			case 3:
				this.mImportName = (CustomTextBox)target;
				return;
			case 4:
				this.mWarningMsg = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400023F RID: 575
		internal ImportMacroWindow mImportMacroWindow;

		// Token: 0x04000240 RID: 576
		internal MainWindow ParentWindow;

		// Token: 0x04000241 RID: 577
		internal CustomCheckbox mContent;

		// Token: 0x04000242 RID: 578
		internal Grid mBlock;

		// Token: 0x04000243 RID: 579
		internal CustomTextBox mImportName;

		// Token: 0x04000244 RID: 580
		internal TextBlock mWarningMsg;

		// Token: 0x04000245 RID: 581
		private bool _contentLoaded;
	}
}
