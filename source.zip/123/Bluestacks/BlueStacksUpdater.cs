﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Threading;
using System.Windows;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000112 RID: 274
	internal class BlueStacksUpdater
	{
		// Token: 0x1700017E RID: 382
		// (get) Token: 0x06000AB7 RID: 2743 RVA: 0x00008998 File Offset: 0x00006B98
		// (set) Token: 0x06000AB8 RID: 2744 RVA: 0x0000899F File Offset: 0x00006B9F
		internal static BlueStacksUpdater.UpdateState SUpdateState
		{
			get
			{
				return BlueStacksUpdater.sUpdateState;
			}
			set
			{
				BlueStacksUpdater.sUpdateState = value;
				if (BlueStacksUpdater.StateChanged != null)
				{
					BlueStacksUpdater.StateChanged();
				}
			}
		}

		// Token: 0x14000006 RID: 6
		// (add) Token: 0x06000AB9 RID: 2745 RVA: 0x0004B978 File Offset: 0x00049B78
		// (remove) Token: 0x06000ABA RID: 2746 RVA: 0x0004B9AC File Offset: 0x00049BAC
		internal static event Action<Tuple<BlueStacksUpdateData, bool>> DownloadCompleted;

		// Token: 0x14000007 RID: 7
		// (add) Token: 0x06000ABB RID: 2747 RVA: 0x0004B9E0 File Offset: 0x00049BE0
		// (remove) Token: 0x06000ABC RID: 2748 RVA: 0x0004BA14 File Offset: 0x00049C14
		internal static event Action StateChanged;

		// Token: 0x06000ABD RID: 2749 RVA: 0x0004BA48 File Offset: 0x00049C48
		public static void SetupBlueStacksUpdater(MainWindow window, bool isStartup)
		{
			BlueStacksUpdater.ParentWindow = window;
			if (BlueStacksUpdater.sCheckUpdateBackgroundWorker == null)
			{
				BlueStacksUpdater.sCheckUpdateBackgroundWorker = new BackgroundWorker();
				BlueStacksUpdater.sCheckUpdateBackgroundWorker.DoWork += delegate(object sender, DoWorkEventArgs e)
				{
					bool flag = (bool)e.Argument;
					BlueStacksUpdateData item = BlueStacksUpdater.CheckForUpdate(!flag);
					BlueStacksUpdater.sBstUpdateData = item;
					e.Result = new Tuple<BlueStacksUpdateData, bool>(item, flag);
				};
				BlueStacksUpdater.sCheckUpdateBackgroundWorker.RunWorkerCompleted += BlueStacksUpdater.CheckUpdateBackgroundWorker_RunWorkerCompleted;
			}
			if (!BlueStacksUpdater.sCheckUpdateBackgroundWorker.IsBusy)
			{
				BlueStacksUpdater.sCheckUpdateBackgroundWorker.RunWorkerAsync(isStartup);
				return;
			}
			Logger.Info("Not launching update checking thread, since already running");
		}

		// Token: 0x06000ABE RID: 2750 RVA: 0x0004BAD4 File Offset: 0x00049CD4
		private static void CheckUpdateBackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			Tuple<BlueStacksUpdateData, bool> tuple = (Tuple<BlueStacksUpdateData, bool>)e.Result;
			BlueStacksUpdateData item = tuple.Item1;
			bool item2 = tuple.Item2;
			if (item.IsUpdateAvailble)
			{
				BlueStacksUpdater.ParentWindow.mTopBar.mConfigButton.ImageName = "cfgmenu_update";
				BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpgradeBluestacksStatus.Visibility = Visibility.Visible;
				BlueStacksUIBinding.Bind(BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpgradeBluestacksStatusTextBlock, "STRING_DOWNLOAD_UPDATE", "");
				BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpdateDownloadProgressPercentage.Visibility = Visibility.Collapsed;
				if (!item.IsFullInstaller)
				{
					Logger.Info("Only client installer update, starting download.");
					BlueStacksUpdater.DownloadNow(item, true);
					return;
				}
				if (item2)
				{
					if (item.UpdateType.Equals("hard", StringComparison.InvariantCultureIgnoreCase))
					{
						Logger.Info("Forced full installer update, starting download.");
						BlueStacksUpdater.DownloadNow(item, true);
						return;
					}
					if (item.UpdateType.Equals("soft", StringComparison.InvariantCultureIgnoreCase) && string.Compare(item.EngineVersion.Trim(), RegistryManager.Instance.LastUpdateSkippedVersion.Trim(), true) != 0)
					{
						ClientStats.SendBluestacksUpdaterUIStatsAsync(ClientStatsEvent.UpgradePopup, "");
						UpdatePrompt updatePrompt = new UpdatePrompt(item);
						updatePrompt.Height = 215.0;
						updatePrompt.Width = 400.0;
						new ContainerWindow(BlueStacksUpdater.ParentWindow, updatePrompt, (double)((int)updatePrompt.Width), (double)((int)updatePrompt.Height), false, true);
						return;
					}
				}
			}
			else
			{
				BlueStacksUpdater.SUpdateState = BlueStacksUpdater.UpdateState.NO_UPDATE;
			}
		}

		// Token: 0x06000ABF RID: 2751 RVA: 0x0004BC50 File Offset: 0x00049E50
		private static BlueStacksUpdateData CheckForUpdate(bool isManualCheck)
		{
			BlueStacksUpdateData blueStacksUpdateData = new BlueStacksUpdateData();
			BlueStacksUpdateData result;
			try
			{
				string urlWithParams = WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/check_upgrade");
				Logger.Debug("The URL for checking upgrade: {0}", new object[]
				{
					urlWithParams
				});
				string value;
				string text;
				string text2;
				SystemUtils.GetOSInfo(out value, out text, out text2);
				string value2 = InstallerArchitectures.AMD64;
				if (!SystemUtils.IsOs64Bit())
				{
					value2 = InstallerArchitectures.X86;
				}
				string text3 = BstHttpClient.Post(urlWithParams, new Dictionary<string, string>
				{
					{
						"installer_arch",
						value2
					},
					{
						"os",
						value
					},
					{
						"manual_check",
						isManualCheck.ToString()
					}
				}, null, false, string.Empty, 5000, 1, 0, false);
				Logger.Info("Response received for check for update: " + Environment.NewLine + text3);
				JObject jobject = JObject.Parse(text3);
				if (jobject["update_available"].ToString().Equals("true", StringComparison.InvariantCultureIgnoreCase) && RegistryManager.Instance.FailedUpgradeVersion != jobject["update_details"]["client_version"].ToString())
				{
					blueStacksUpdateData.IsUpdateAvailble = true;
					blueStacksUpdateData.UpdateType = jobject["update_details"]["upgrade_type"].ToString();
					blueStacksUpdateData.IsFullInstaller = jobject["update_details"]["is_full_installer"].ToObject<bool>();
					blueStacksUpdateData.Md5 = jobject["update_details"]["md5"].ToString();
					blueStacksUpdateData.ClientVersion = jobject["update_details"]["client_version"].ToString();
					blueStacksUpdateData.EngineVersion = jobject["update_details"]["engine_version"].ToString();
					blueStacksUpdateData.DownloadUrl = jobject["update_details"]["download_url"].ToString();
					blueStacksUpdateData.DetailedChangeLogsUrl = jobject["update_details"]["detailed_changelogs_url"].ToString();
					if (!Directory.Exists(RegistryManager.Instance.SetupFolder))
					{
						Directory.CreateDirectory(RegistryManager.Instance.SetupFolder);
					}
					if (blueStacksUpdateData.IsFullInstaller)
					{
						blueStacksUpdateData.UpdateDownloadLocation = Path.Combine(RegistryManager.Instance.SetupFolder, "BlueStacksInstaller_" + blueStacksUpdateData.ClientVersion + "_full.exe");
					}
					else
					{
						blueStacksUpdateData.UpdateDownloadLocation = Path.Combine(RegistryManager.Instance.SetupFolder, "BlueStacksInstaller_" + blueStacksUpdateData.ClientVersion + "_client.zip");
					}
					RegistryManager.Instance.DownloadedUpdateFile = blueStacksUpdateData.UpdateDownloadLocation;
					BlueStacksUpdater.sBstUpdateData = blueStacksUpdateData;
					BlueStacksUpdater.SUpdateState = BlueStacksUpdater.UpdateState.UPDATE_AVAILABLE;
				}
				result = blueStacksUpdateData;
			}
			catch (Exception ex)
			{
				Logger.Warning("Got error in checking for upgrade: {0}", new object[]
				{
					ex.ToString()
				});
				result = new BlueStacksUpdateData
				{
					IsTryAgain = true
				};
			}
			return result;
		}

		// Token: 0x06000AC0 RID: 2752 RVA: 0x0004BF44 File Offset: 0x0004A144
		private static void DownloadUpdate(BlueStacksUpdateData bluestacksUpdateData, bool hiddenMode)
		{
			new LegacyDownloader(3, bluestacksUpdateData.DownloadUrl, bluestacksUpdateData.UpdateDownloadLocation).Download(delegate(int percent)
			{
				Logger.Info("file download % {0}", new object[]
				{
					percent
				});
				BlueStacksUpdater.ParentWindow.mTopBar.ChangeDownloadPercent(percent);
				if (BlueStacksUpdater.sUpdateDownloadProgress != null)
				{
					BlueStacksUpdater.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUpdater.sUpdateDownloadProgress.mUpdateDownloadProgressPercentage.Content = percent + "%";
						BlueStacksUpdater.sUpdateDownloadProgress.mUpdateDownloadProgressBar.Value = (double)percent;
						BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpdateDownloadProgressPercentage.Content = percent + "%";
					}), new object[0]);
				}
			}, delegate(string filePath)
			{
				Logger.Info("file download completed for file path {0}", new object[]
				{
					filePath
				});
				BlueStacksUpdater.DownloadComplete(hiddenMode);
			}, delegate(Exception ex)
			{
				Logger.Error("Failed to download file: {0}. err: {1}", new object[]
				{
					bluestacksUpdateData.DownloadUrl,
					ex.Message
				});
				BlueStacksUpdater.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					CustomMessageWindow customMessageWindow = new CustomMessageWindow();
					customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
					BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_SOME_ERROR_OCCURED_DOWNLOAD", "");
					BlueStacksUpdater.ParentWindow.ShowDimOverlay(null);
					customMessageWindow.Owner = BlueStacksUpdater.ParentWindow.mDimOverlay;
					customMessageWindow.ShowDialog();
					BlueStacksUpdater.ParentWindow.HideDimOverlay();
					BlueStacksUpdater.sUpdateDownloadProgress.Hide();
				}), new object[0]);
			}, null, null, null);
		}

		// Token: 0x06000AC1 RID: 2753 RVA: 0x0004BFC0 File Offset: 0x0004A1C0
		private static void DownloadComplete(bool isStartup)
		{
			Logger.Info("Installer download completed");
			BlueStacksUpdater.SUpdateState = BlueStacksUpdater.UpdateState.DOWNLOADED;
			BlueStacksUpdater.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				BlueStacksUIBinding.Bind(BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpgradeBluestacksStatusTextBlock, "STRING_INSTALL_UPDATE", "");
				BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpdateDownloadProgressPercentage.Visibility = Visibility.Collapsed;
				if (BlueStacksUpdater.sUpdateDownloadProgress != null)
				{
					BlueStacksUpdater.sUpdateDownloadProgress.Close();
				}
			}), new object[0]);
			BlueStacksUpdater.DownloadCompleted(new Tuple<BlueStacksUpdateData, bool>(BlueStacksUpdater.sBstUpdateData, isStartup));
		}

		// Token: 0x06000AC2 RID: 2754 RVA: 0x000089B8 File Offset: 0x00006BB8
		internal static void DownloadNow(BlueStacksUpdateData bstUpdateData, bool hiddenMode)
		{
			new Thread(delegate()
			{
				BlueStacksUpdater.SUpdateState = BlueStacksUpdater.UpdateState.DOWNLOADING;
				if (File.Exists(bstUpdateData.UpdateDownloadLocation))
				{
					BlueStacksUpdater.DownloadComplete(hiddenMode);
					return;
				}
				BlueStacksUpdater.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					BlueStacksUIBinding.Bind(BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpgradeBluestacksStatusTextBlock, "STRING_DOWNLOADING_UPDATE", "");
					BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpdateDownloadProgressPercentage.Visibility = Visibility.Visible;
					BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpdateDownloadProgressPercentage.Content = "0%";
					BlueStacksUpdater.sUpdateDownloadProgress = new UpdateDownloadProgress();
					BlueStacksUpdater.sUpdateDownloadProgress.mUpdateDownloadProgressPercentage.Content = "0%";
					BlueStacksUpdater.sUpdateDownloadProgress.Owner = BlueStacksUpdater.ParentWindow;
					if (!hiddenMode)
					{
						BlueStacksUpdater.sUpdateDownloadProgress.Show();
					}
				}), new object[0]);
				BlueStacksUpdater.DownloadUpdate(bstUpdateData, hiddenMode);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000AC3 RID: 2755 RVA: 0x000089E9 File Offset: 0x00006BE9
		internal static void ShowDownloadProgress()
		{
			if (BlueStacksUpdater.sUpdateDownloadProgress != null)
			{
				BlueStacksUpdater.sUpdateDownloadProgress.Show();
			}
		}

		// Token: 0x06000AC4 RID: 2756 RVA: 0x0004C028 File Offset: 0x0004A228
		internal static void CheckDownloadedUpdateFileAndUpdate()
		{
			BackgroundWorker backgroundWorker = new BackgroundWorker();
			backgroundWorker.DoWork += delegate(object sender, DoWorkEventArgs args)
			{
				BlueStacksUpdater.HandleUpgrade(RegistryManager.Instance.DownloadedUpdateFile);
			};
			backgroundWorker.RunWorkerCompleted += delegate(object sender, RunWorkerCompletedEventArgs args2)
			{
				App.ExitApplication();
			};
			backgroundWorker.RunWorkerAsync();
		}

		// Token: 0x06000AC5 RID: 2757 RVA: 0x000089FC File Offset: 0x00006BFC
		internal static void HandleUpgrade(string downloadedFilePath)
		{
			if (BlueStacksUpdater.CheckIfUpdateIsFullOrClientOnly(downloadedFilePath) == BlueStacksUpdater.UpdateType.ClientOnly)
			{
				BlueStacksUpdater.HandleClientOnlyUpgrade(downloadedFilePath);
			}
			else
			{
				BlueStacksUpdater.HandleFullUpgrade(downloadedFilePath);
			}
			RegistryManager.Instance.DownloadedUpdateFile = "";
		}

		// Token: 0x06000AC6 RID: 2758 RVA: 0x00008A24 File Offset: 0x00006C24
		private static void HandleFullUpgrade(string downloadedFilePath)
		{
			Logger.Info("In HandleFullUpgrade");
			BluestacksProcessHelper.RunUpdateInstaller(downloadedFilePath, "-u -upgradesourcepath BluestacksUI", false);
		}

		// Token: 0x06000AC7 RID: 2759 RVA: 0x0004C08C File Offset: 0x0004A28C
		private static void HandleClientOnlyUpgrade(string downloadedFilePath)
		{
			Logger.Info("In HandleClientOnlyUpgrade");
			try
			{
				int num = BlueStacksUpdater.ExtractingClientInstaller(downloadedFilePath);
				if (num == 0)
				{
					BluestacksProcessHelper.RunUpdateInstaller(Path.Combine(Path.Combine(RegistryManager.Instance.SetupFolder, Path.GetFileNameWithoutExtension(downloadedFilePath)), "Bootstrapper.exe"), "", false);
				}
				else
				{
					Logger.Warning("Update extraction failed, ExitCode: {0}", new object[]
					{
						num
					});
					File.Delete(downloadedFilePath);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Some Error in Client Upgrade err: ", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x06000AC8 RID: 2760 RVA: 0x0004C128 File Offset: 0x0004A328
		internal static bool CheckIfDownloadedFileExist()
		{
			string downloadedUpdateFile = RegistryManager.Instance.DownloadedUpdateFile;
			return !string.IsNullOrEmpty(downloadedUpdateFile) && File.Exists(downloadedUpdateFile);
		}

		// Token: 0x06000AC9 RID: 2761 RVA: 0x00008A3C File Offset: 0x00006C3C
		private static BlueStacksUpdater.UpdateType CheckIfUpdateIsFullOrClientOnly(string downloadedFilePath)
		{
			if (string.Equals(Path.GetExtension(downloadedFilePath), ".zip", StringComparison.InvariantCultureIgnoreCase))
			{
				return BlueStacksUpdater.UpdateType.ClientOnly;
			}
			return BlueStacksUpdater.UpdateType.FullUpdate;
		}

		// Token: 0x06000ACA RID: 2762 RVA: 0x0004C154 File Offset: 0x0004A354
		private static int ExtractingClientInstaller(string updateFile)
		{
			string text = Path.Combine(RegistryManager.Instance.SetupFolder, Path.GetFileNameWithoutExtension(updateFile));
			Logger.Info("Extracting Zip file {0} at {1}", new object[]
			{
				updateFile,
				text
			});
			return MiscUtils.Extract7Zip(updateFile, text);
		}

		// Token: 0x040007F5 RID: 2037
		private static MainWindow ParentWindow;

		// Token: 0x040007F6 RID: 2038
		internal static BackgroundWorker sCheckUpdateBackgroundWorker;

		// Token: 0x040007F7 RID: 2039
		private static UpdateDownloadProgress sUpdateDownloadProgress;

		// Token: 0x040007F8 RID: 2040
		internal static BlueStacksUpdateData sBstUpdateData;

		// Token: 0x040007F9 RID: 2041
		private static BlueStacksUpdater.UpdateState sUpdateState;

		// Token: 0x02000113 RID: 275
		internal enum UpdateState
		{
			// Token: 0x040007FD RID: 2045
			NO_UPDATE,
			// Token: 0x040007FE RID: 2046
			UPDATE_AVAILABLE,
			// Token: 0x040007FF RID: 2047
			DOWNLOADING,
			// Token: 0x04000800 RID: 2048
			DOWNLOADED
		}

		// Token: 0x02000114 RID: 276
		internal enum UpdateType
		{
			// Token: 0x04000802 RID: 2050
			FullUpdate,
			// Token: 0x04000803 RID: 2051
			ClientOnly
		}
	}
}
