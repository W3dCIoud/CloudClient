﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000141 RID: 321
	internal class MainWindowsStaticComponents
	{
		// Token: 0x14000010 RID: 16
		// (add) Token: 0x06000C6A RID: 3178 RVA: 0x000545CC File Offset: 0x000527CC
		// (remove) Token: 0x06000C6B RID: 3179 RVA: 0x00054604 File Offset: 0x00052804
		internal event EventHandler ShowAllUninstallButtons;

		// Token: 0x14000011 RID: 17
		// (add) Token: 0x06000C6C RID: 3180 RVA: 0x0005463C File Offset: 0x0005283C
		// (remove) Token: 0x06000C6D RID: 3181 RVA: 0x00054674 File Offset: 0x00052874
		internal event EventHandler HideAllUninstallButtons;

		// Token: 0x06000C6E RID: 3182 RVA: 0x00009940 File Offset: 0x00007B40
		internal void ShowUninstallButtons(bool isShow)
		{
			this.IsDeleteButtonVisible = isShow;
			if (isShow)
			{
				if (this.ShowAllUninstallButtons != null)
				{
					this.ShowAllUninstallButtons(null, new EventArgs());
					return;
				}
			}
			else if (this.HideAllUninstallButtons != null)
			{
				this.HideAllUninstallButtons(null, new EventArgs());
			}
		}

		// Token: 0x04000924 RID: 2340
		internal AppTabButton mSelectedTabButton;

		// Token: 0x04000925 RID: 2341
		internal HomeAppTabButton mSelectedHomeAppTabButton;

		// Token: 0x04000926 RID: 2342
		internal bool IsDeleteButtonVisible;

		// Token: 0x04000927 RID: 2343
		internal IntPtr mLastMappableWindowHandle = IntPtr.Zero;
	}
}
