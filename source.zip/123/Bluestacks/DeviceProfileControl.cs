﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000AA RID: 170
	public class DeviceProfileControl : UserControl, IComponentConnector
	{
		// Token: 0x0600072F RID: 1839 RVA: 0x0002CB08 File Offset: 0x0002AD08
		public DeviceProfileControl(MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			base.Visibility = Visibility.Hidden;
			base.IsVisibleChanged += this.DeviceProfileControl_IsVisibleChanged;
			this.mManufacturerTextBox.TextChanged += this.MManufacturerTextBox_TextChanged;
			this.mModelNumberTextBox.TextChanged += this.MManufacturerTextBox_TextChanged;
			this.mBrandTextBox.TextChanged += this.MManufacturerTextBox_TextChanged;
			if (PromotionObject.Instance.IsRootAccessEnabled || FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.mRootAccessGrid.Visibility = Visibility.Visible;
				this.mCurrentRootAccessStatus = this.GetRootAccessStatusFromAndroid(this.ParentWindow.mVmName);
				this.mEnableRootAccessCheckBox.IsChecked = new bool?(this.mCurrentRootAccessStatus);
			}
			this.mScrollBar.ScrollChanged += BluestacksUIColor.ScrollBarScrollChanged;
		}

		// Token: 0x06000730 RID: 1840 RVA: 0x0002CC04 File Offset: 0x0002AE04
		private bool GetRootAccessStatusFromAndroid(string vmname)
		{
			bool result;
			try
			{
				JObject jobject = JObject.Parse(HTTPUtils.SendRequestToGuest("getprop", new Dictionary<string, string>
				{
					{
						"d",
						"bst.config.bindmount"
					}
				}, vmname, 0, null, false, 1, 0));
				if (string.Equals(jobject["result"].ToString(), "ok"))
				{
					if (string.Equals(jobject["value"].ToString(), "1"))
					{
						result = true;
					}
					else
					{
						result = false;
					}
				}
				else
				{
					result = false;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Getting root status from android: " + ex.ToString());
				result = false;
			}
			return result;
		}

		// Token: 0x06000731 RID: 1841 RVA: 0x0002CCB0 File Offset: 0x0002AEB0
		private void ChangeLoadingGridVisibility(bool state)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (state)
				{
					this.mProfileLoader.Visibility = Visibility.Visible;
					this.mNoInternetWarning.Visibility = Visibility.Collapsed;
					this.mChildGrid.Visibility = Visibility.Collapsed;
					this.mTryAgainBtnGrid.Visibility = Visibility.Collapsed;
					return;
				}
				this.mProfileLoader.Visibility = Visibility.Collapsed;
				this.mNoInternetWarning.Visibility = Visibility.Collapsed;
				this.mChildGrid.Visibility = Visibility.Visible;
				this.mTryAgainBtnGrid.Visibility = Visibility.Collapsed;
			}), new object[0]);
		}

		// Token: 0x06000732 RID: 1842 RVA: 0x0002CCF0 File Offset: 0x0002AEF0
		private void ChangeNoInternetGridVisibility(bool state)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (state)
				{
					this.mProfileLoader.Visibility = Visibility.Collapsed;
					this.mNoInternetWarning.Visibility = Visibility.Visible;
					this.mChildGrid.Visibility = Visibility.Collapsed;
					this.mTryAgainBtnGrid.Visibility = Visibility.Visible;
					return;
				}
				this.mProfileLoader.Visibility = Visibility.Visible;
				this.mNoInternetWarning.Visibility = Visibility.Collapsed;
				this.mChildGrid.Visibility = Visibility.Collapsed;
				this.mTryAgainBtnGrid.Visibility = Visibility.Collapsed;
			}), new object[0]);
		}

		// Token: 0x06000733 RID: 1843 RVA: 0x0002CD30 File Offset: 0x0002AF30
		private void DeviceProfileControl_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (base.IsVisible)
			{
				if (!this.mGettingProfilesFromCloud)
				{
					this.mGettingProfilesFromCloud = true;
					this.ChangeLoadingGridVisibility(true);
					this.ChangeNoInternetGridVisibility(false);
					this.GetPreDefinedProfilesFromCloud();
					return;
				}
			}
			else
			{
				this.mGettingProfilesFromCloud = false;
				this.mSaveChangesBtn.IsEnabled = false;
				this.mEnableRootAccessCheckBox.IsChecked = new bool?(this.mCurrentRootAccessStatus);
			}
		}

		// Token: 0x06000734 RID: 1844 RVA: 0x0002CD94 File Offset: 0x0002AF94
		private void SetUIAccordingToCurrentDeviceProfile()
		{
			this.mPredefinedProfilesComboBox.SelectionChanged -= this.mPredefinedProfilesComboBox_SelectionChanged;
			if (this.mCurrentDeviceProfileObject == null)
			{
				this.mPredefinedProfilesComboBox.Visibility = Visibility.Visible;
				this.mCustomProfileGrid.Visibility = Visibility.Collapsed;
			}
			else if (this.mCurrentDeviceProfileObject["pcode"].ToString().Equals("custom"))
			{
				this.mPredefinedProfilesComboBox.Visibility = Visibility.Collapsed;
				this.mCustomProfileGrid.Visibility = Visibility.Visible;
				this.mModelNumberTextBox.Text = this.mCurrentDeviceProfileObject["model"].ToString();
				this.mBrandTextBox.Text = this.mCurrentDeviceProfileObject["brand"].ToString();
				this.mManufacturerTextBox.Text = this.mCurrentDeviceProfileObject["manufacturer"].ToString();
				this.mCustomProfile.IsChecked = new bool?(true);
				this.mPredefinedProfilesComboBox.SelectedItem = null;
			}
			else
			{
				this.mPredefinedProfilesComboBox.Visibility = Visibility.Visible;
				this.mCustomProfileGrid.Visibility = Visibility.Collapsed;
				if (this.mdictComboBoxItems.ContainsKey(this.mCurrentDeviceProfileObject["pcode"].ToString()))
				{
					this.mPredefinedProfilesComboBox.SelectedItem = this.mdictComboBoxItems[this.mCurrentDeviceProfileObject["pcode"].ToString()];
				}
				this.mChooseProfile.IsChecked = new bool?(true);
				this.mModelNumberTextBox.Text = string.Empty;
				this.mBrandTextBox.Text = string.Empty;
				this.mManufacturerTextBox.Text = string.Empty;
			}
			this.mPredefinedProfilesComboBox.SelectionChanged += this.mPredefinedProfilesComboBox_SelectionChanged;
			this.ChangeLoadingGridVisibility(false);
		}

		// Token: 0x06000735 RID: 1845 RVA: 0x00006ACA File Offset: 0x00004CCA
		private void GetPreDefinedProfilesFromCloud()
		{
			new Thread(delegate()
			{
				try
				{
					this.GetCurrentDeviceProfileFromAndroid(this.ParentWindow.mVmName);
					if (this.mPreDefinedProfilesList.Count == 0)
					{
						JObject jobject = JObject.Parse(BstHttpClient.Post(WebHelper.GetUrlWithParams(string.Format("{0}/{1}/{2}", RegistryManager.Instance.Host, "bs4", "get_device_profile_list")), null, null, false, this.ParentWindow.mVmName, 0, 1, 0, false));
						if (jobject != null && (bool)jobject["success"] && !JsonExtensions.IsNullOrEmptyBrackets(jobject["device_profile_list"].ToString()))
						{
							foreach (JObject jobject2 in jobject["device_profile_list"].ToArray<JToken>())
							{
								this.mPreDefinedProfilesList[jobject2["pcode"].ToString()] = jobject2["display_name"].ToString();
							}
							this.AddPreDefinedProfilesinComboBox();
						}
					}
					else
					{
						this.AddPreDefinedProfilesinComboBox();
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Error while getting device profile from cloud : " + ex.ToString());
					this.ChangeNoInternetGridVisibility(true);
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000736 RID: 1846 RVA: 0x00006AE9 File Offset: 0x00004CE9
		internal void GetCurrentDeviceProfileFromAndroid(string vmName)
		{
			if (string.Equals(VmCmdHandler.SendRequest("currentdeviceprofile", null, vmName, out this.mCurrentDeviceProfileObject), "ok"))
			{
				this.mCurrentDeviceProfileObject.Remove("result");
			}
		}

		// Token: 0x06000737 RID: 1847 RVA: 0x00006B1A File Offset: 0x00004D1A
		private void AddPreDefinedProfilesinComboBox()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				foreach (string key in this.mPreDefinedProfilesList.Keys)
				{
					ComboBoxItem comboBoxItem = new ComboBoxItem();
					comboBoxItem.Content = this.mPreDefinedProfilesList[key];
					this.mPredefinedProfilesComboBox.Items.Add(comboBoxItem);
					if (this.mdictComboBoxItems.ContainsKey(key))
					{
						this.mdictComboBoxItems[key] = comboBoxItem;
					}
					else
					{
						this.mdictComboBoxItems.Add(key, comboBoxItem);
					}
				}
				this.SetUIAccordingToCurrentDeviceProfile();
			}), new object[0]);
		}

		// Token: 0x06000738 RID: 1848 RVA: 0x0002CF60 File Offset: 0x0002B160
		private void Profile_Checked(object sender, RoutedEventArgs e)
		{
			if (this.mChooseProfile.IsChecked.Value)
			{
				this.mPredefinedProfilesComboBox.Visibility = Visibility.Visible;
				this.mCustomProfileGrid.Visibility = Visibility.Collapsed;
				return;
			}
			if (this.mCustomProfile.IsChecked.Value)
			{
				this.mPredefinedProfilesComboBox.Visibility = Visibility.Collapsed;
				this.mCustomProfileGrid.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x06000739 RID: 1849 RVA: 0x00006B3A File Offset: 0x00004D3A
		private void mPredefinedProfilesComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			this.mSaveChangesBtn.IsEnabled = true;
		}

		// Token: 0x0600073A RID: 1850 RVA: 0x00006B3A File Offset: 0x00004D3A
		private void MManufacturerTextBox_TextChanged(object sender, TextChangedEventArgs e)
		{
			this.mSaveChangesBtn.IsEnabled = true;
		}

		// Token: 0x0600073B RID: 1851 RVA: 0x0002CFC8 File Offset: 0x0002B1C8
		private void SaveChangesBtn_Click(object sender, RoutedEventArgs e)
		{
			this.mSaveChangesBtn.IsEnabled = false;
			JObject mChangedDeviceProfileObject = new JObject();
			if (this.mChooseProfile.IsChecked.Value)
			{
				if (this.mPredefinedProfilesComboBox.SelectedItem != null)
				{
					string selectedDeviceProfile = (this.mPredefinedProfilesComboBox.SelectedItem as ComboBoxItem).Content.ToString();
					if (!string.IsNullOrEmpty(selectedDeviceProfile))
					{
						string pCode = this.mPreDefinedProfilesList.FirstOrDefault((KeyValuePair<string, string> x) => x.Value == selectedDeviceProfile).Key;
						string text = "{";
						text += string.Format("\"createcustomprofile\":\"{0}\",", "false");
						text += string.Format("\"pcode\":\"{0}\"", pCode);
						text += "}";
						mChangedDeviceProfileObject["pcode"] = pCode;
						if (Utils.CheckIfDeviceProfileChanged(this.mCurrentDeviceProfileObject, mChangedDeviceProfileObject))
						{
							string command = string.Format("{0} {1}", "changePCode", text);
							Logger.Info("Command for device profile change: " + command);
							new Thread(delegate()
							{
								try
								{
									string text3 = VmCmdHandler.RunCommand(command, this.ParentWindow.mVmName);
									Logger.Info("Result for device profile change command: " + text3);
									if (string.Equals(text3, "ok"))
									{
										this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_SAVE_CHANGES", false));
										this.SendStatsOfDeviceProfileChangeAsync("success", mChangedDeviceProfileObject, this.mCurrentDeviceProfileObject);
										this.mCurrentDeviceProfileObject = mChangedDeviceProfileObject;
										Utils.UpdateValueInBootParams("pcode", pCode, this.ParentWindow.mVmName, false);
										if (SecurityMetrics.SecurityMetricsInstanceList.ContainsKey(this.ParentWindow.mVmName))
										{
											SecurityMetrics.SecurityMetricsInstanceList[this.ParentWindow.mVmName].AddSecurityBreach(SecurityBreach.DEVICE_PROFILE_CHANGED, string.Empty);
										}
									}
									else
									{
										this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_SWITCH_PROFILE_FAILED", false));
										this.SendStatsOfDeviceProfileChangeAsync("failed", mChangedDeviceProfileObject, this.mCurrentDeviceProfileObject);
									}
									this.Dispatcher.Invoke(new Action(delegate()
									{
										this.SetUIAccordingToCurrentDeviceProfile();
									}), new object[0]);
								}
								catch (Exception ex)
								{
									Logger.Error("Exception in change to predefined Pcode call to android: " + ex.ToString());
								}
							})
							{
								IsBackground = true
							}.Start();
						}
					}
				}
			}
			else
			{
				string text2 = "{";
				text2 += string.Format("\"createcustomprofile\":\"{0}\",", "true");
				text2 += string.Format("\"model\":\"{0}\",", this.mModelNumberTextBox.Text);
				text2 += string.Format("\"brand\":\"{0}\",", this.mBrandTextBox.Text);
				text2 += string.Format("\"manufacturer\":\"{0}\"", this.mManufacturerTextBox.Text);
				text2 += "}";
				mChangedDeviceProfileObject["pcode"] = "custom";
				mChangedDeviceProfileObject["model"] = this.mModelNumberTextBox.Text;
				mChangedDeviceProfileObject["brand"] = this.mBrandTextBox.Text;
				mChangedDeviceProfileObject["manufacturer"] = this.mManufacturerTextBox.Text;
				if (Utils.CheckIfDeviceProfileChanged(this.mCurrentDeviceProfileObject, mChangedDeviceProfileObject))
				{
					string command = string.Format("{0} {1}", "changePCode", text2);
					Logger.Info("Command for device profile change: " + command);
					new Thread(delegate()
					{
						try
						{
							string text3 = VmCmdHandler.RunCommand(command, this.ParentWindow.mVmName);
							Logger.Info("Result for device profile change command: " + text3);
							if (string.Equals(text3, "ok"))
							{
								this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_SAVE_CHANGES", false));
								this.SendStatsOfDeviceProfileChangeAsync("success", mChangedDeviceProfileObject, this.mCurrentDeviceProfileObject);
								this.mCurrentDeviceProfileObject = mChangedDeviceProfileObject;
								Utils.UpdateValueInBootParams("pcode", "custom", this.ParentWindow.mVmName, false);
								if (SecurityMetrics.SecurityMetricsInstanceList.ContainsKey(this.ParentWindow.mVmName))
								{
									SecurityMetrics.SecurityMetricsInstanceList[this.ParentWindow.mVmName].AddSecurityBreach(SecurityBreach.DEVICE_PROFILE_CHANGED, string.Empty);
								}
							}
							else
							{
								this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_SWITCH_PROFILE_FAILED", false));
								this.SendStatsOfDeviceProfileChangeAsync("failed", mChangedDeviceProfileObject, this.mCurrentDeviceProfileObject);
							}
							this.Dispatcher.Invoke(new Action(delegate()
							{
								this.SetUIAccordingToCurrentDeviceProfile();
							}), new object[0]);
						}
						catch (Exception ex)
						{
							Logger.Error("Exception in change to custon Pcode call to android: " + ex.ToString());
						}
					})
					{
						IsBackground = true
					}.Start();
				}
			}
			bool? isChecked = this.mEnableRootAccessCheckBox.IsChecked;
			bool flag = this.mCurrentRootAccessStatus;
			if (!(isChecked.GetValueOrDefault() == flag & isChecked != null))
			{
				string res = null;
				new Thread(delegate()
				{
					try
					{
						if (!this.mCurrentRootAccessStatus)
						{
							res = HTTPUtils.SendRequestToGuest("bindmount", null, this.ParentWindow.mVmName, 0, null, false, 1, 0);
						}
						else
						{
							res = HTTPUtils.SendRequestToGuest("unbindmount", null, this.ParentWindow.mVmName, 0, null, false, 1, 0);
						}
						if (string.Equals(JObject.Parse(res)["result"].ToString(), "ok"))
						{
							this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_SAVE_CHANGES", false));
							this.mCurrentRootAccessStatus = !this.mCurrentRootAccessStatus;
							this.SendStatsOfRootAccessStatusAsync("success", this.mCurrentRootAccessStatus);
							if (SecurityMetrics.SecurityMetricsInstanceList.ContainsKey(this.ParentWindow.mVmName) && this.mCurrentRootAccessStatus)
							{
								SecurityMetrics.SecurityMetricsInstanceList[this.ParentWindow.mVmName].AddSecurityBreach(SecurityBreach.DEVICE_ROOTED, string.Empty);
							}
						}
						else
						{
							this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_ROOT_ACCESS_FAILURE", false));
							this.Dispatcher.Invoke(new Action(delegate()
							{
								this.mEnableRootAccessCheckBox.IsChecked = new bool?(this.mCurrentRootAccessStatus);
							}), new object[0]);
							this.SendStatsOfRootAccessStatusAsync("failed", this.mCurrentRootAccessStatus);
						}
					}
					catch (Exception ex)
					{
						Logger.Error("Exception in sending mount unmount request to Android: " + ex.ToString());
					}
				})
				{
					IsBackground = true
				}.Start();
			}
		}

		// Token: 0x0600073C RID: 1852 RVA: 0x0002D348 File Offset: 0x0002B548
		private void AddToastPopup(string message)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (this.mToastPopup == null)
				{
					this.mToastPopup = new CustomToastPopupControl(this);
				}
				Thickness value = new Thickness(0.0, 0.0, 0.0, 50.0);
				this.mToastPopup.Init(this, message, null, null, HorizontalAlignment.Center, VerticalAlignment.Bottom, new Thickness?(value), 12, null, null);
				this.mToastPopup.ShowPopup(1.3);
			}), new object[0]);
		}

		// Token: 0x0600073D RID: 1853 RVA: 0x0002D388 File Offset: 0x0002B588
		private void SendStatsOfDeviceProfileChangeAsync(string successString, JObject newDeviceProfile, JObject oldDeviceProfile)
		{
			ClientStats.SendMiscellaneousStatsAsync("DeviceProfileChangeStats", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, successString, JsonConvert.SerializeObject(newDeviceProfile), JsonConvert.SerializeObject(oldDeviceProfile), RegistryManager.Instance.Version, "DeviceProfileSetting", null);
		}

		// Token: 0x0600073E RID: 1854 RVA: 0x0002D3D0 File Offset: 0x0002B5D0
		private void SendStatsOfRootAccessStatusAsync(string successString, bool rootedstatus)
		{
			string arg = rootedstatus ? "Rooted" : "Unrooted";
			ClientStats.SendMiscellaneousStatsAsync("DeviceRootingStats", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, successString, arg, this.ParentWindow.mVmName, null, null);
		}

		// Token: 0x0600073F RID: 1855 RVA: 0x00006B48 File Offset: 0x00004D48
		private void TryAgainBtn_Click(object sender, RoutedEventArgs e)
		{
			this.ChangeNoInternetGridVisibility(false);
			this.ChangeLoadingGridVisibility(true);
			this.GetPreDefinedProfilesFromCloud();
		}

		// Token: 0x06000740 RID: 1856 RVA: 0x00006B3A File Offset: 0x00004D3A
		private void mEnableRootAccessCheckBox_Click(object sender, RoutedEventArgs e)
		{
			this.mSaveChangesBtn.IsEnabled = true;
		}

		// Token: 0x06000741 RID: 1857 RVA: 0x0002D424 File Offset: 0x0002B624
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/deviceprofilecontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000742 RID: 1858 RVA: 0x0002D454 File Offset: 0x0002B654
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mScrollBar = (ScrollViewer)target;
				return;
			case 2:
				this.mProfileLoader = (Border)target;
				return;
			case 3:
				this.mNoInternetWarning = (Border)target;
				return;
			case 4:
				this.mChildGrid = (Grid)target;
				return;
			case 5:
				this.mChooseProfile = (CustomRadioButton)target;
				this.mChooseProfile.Checked += this.Profile_Checked;
				return;
			case 6:
				this.mPredefinedProfilesComboBox = (CustomComboBox)target;
				this.mPredefinedProfilesComboBox.SelectionChanged += this.mPredefinedProfilesComboBox_SelectionChanged;
				return;
			case 7:
				this.mCustomProfile = (CustomRadioButton)target;
				this.mCustomProfile.Checked += this.Profile_Checked;
				return;
			case 8:
				this.mCustomProfileGrid = (Grid)target;
				return;
			case 9:
				this.mManufacturerTextBox = (CustomTextBox)target;
				return;
			case 10:
				this.mBrandTextBox = (CustomTextBox)target;
				return;
			case 11:
				this.mModelNumberTextBox = (CustomTextBox)target;
				return;
			case 12:
				this.mTryAgainBtnGrid = (Grid)target;
				return;
			case 13:
				((CustomButton)target).Click += this.TryAgainBtn_Click;
				return;
			case 14:
				this.mRootAccessGrid = (Grid)target;
				return;
			case 15:
				this.mEnableRootAccessCheckBox = (CustomCheckbox)target;
				this.mEnableRootAccessCheckBox.Click += this.mEnableRootAccessCheckBox_Click;
				return;
			case 16:
				this.mInfoIcon = (CustomPictureBox)target;
				return;
			case 17:
				this.mSaveChangesBtn = (CustomButton)target;
				this.mSaveChangesBtn.Click += this.SaveChangesBtn_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040004DE RID: 1246
		private JObject mCurrentDeviceProfileObject;

		// Token: 0x040004DF RID: 1247
		private Dictionary<string, string> mPreDefinedProfilesList = new Dictionary<string, string>();

		// Token: 0x040004E0 RID: 1248
		private Dictionary<string, ComboBoxItem> mdictComboBoxItems = new Dictionary<string, ComboBoxItem>();

		// Token: 0x040004E1 RID: 1249
		private CustomToastPopupControl mToastPopup;

		// Token: 0x040004E2 RID: 1250
		private MainWindow ParentWindow;

		// Token: 0x040004E3 RID: 1251
		private bool mGettingProfilesFromCloud;

		// Token: 0x040004E4 RID: 1252
		private bool mCurrentRootAccessStatus;

		// Token: 0x040004E5 RID: 1253
		internal ScrollViewer mScrollBar;

		// Token: 0x040004E6 RID: 1254
		internal Border mProfileLoader;

		// Token: 0x040004E7 RID: 1255
		internal Border mNoInternetWarning;

		// Token: 0x040004E8 RID: 1256
		internal Grid mChildGrid;

		// Token: 0x040004E9 RID: 1257
		internal CustomRadioButton mChooseProfile;

		// Token: 0x040004EA RID: 1258
		internal CustomComboBox mPredefinedProfilesComboBox;

		// Token: 0x040004EB RID: 1259
		internal CustomRadioButton mCustomProfile;

		// Token: 0x040004EC RID: 1260
		internal Grid mCustomProfileGrid;

		// Token: 0x040004ED RID: 1261
		internal CustomTextBox mManufacturerTextBox;

		// Token: 0x040004EE RID: 1262
		internal CustomTextBox mBrandTextBox;

		// Token: 0x040004EF RID: 1263
		internal CustomTextBox mModelNumberTextBox;

		// Token: 0x040004F0 RID: 1264
		internal Grid mTryAgainBtnGrid;

		// Token: 0x040004F1 RID: 1265
		internal Grid mRootAccessGrid;

		// Token: 0x040004F2 RID: 1266
		internal CustomCheckbox mEnableRootAccessCheckBox;

		// Token: 0x040004F3 RID: 1267
		internal CustomPictureBox mInfoIcon;

		// Token: 0x040004F4 RID: 1268
		internal CustomButton mSaveChangesBtn;

		// Token: 0x040004F5 RID: 1269
		private bool _contentLoaded;
	}
}
