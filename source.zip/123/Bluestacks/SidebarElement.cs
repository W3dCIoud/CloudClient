﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000079 RID: 121
	public class SidebarElement : UserControl, IComponentConnector
	{
		// Token: 0x1700013B RID: 315
		// (get) Token: 0x06000570 RID: 1392 RVA: 0x000058C6 File Offset: 0x00003AC6
		public CustomPictureBox Image
		{
			get
			{
				return this.mImage;
			}
		}

		// Token: 0x1700013C RID: 316
		// (get) Token: 0x06000571 RID: 1393 RVA: 0x000058CE File Offset: 0x00003ACE
		// (set) Token: 0x06000572 RID: 1394 RVA: 0x000058D6 File Offset: 0x00003AD6
		public bool IsLastElementOfGroup { get; set; }

		// Token: 0x1700013D RID: 317
		// (get) Token: 0x06000573 RID: 1395 RVA: 0x000058DF File Offset: 0x00003ADF
		// (set) Token: 0x06000574 RID: 1396 RVA: 0x000058E7 File Offset: 0x00003AE7
		public bool IsCurrentLastElementOfGroup { get; set; }

		// Token: 0x1700013E RID: 318
		// (get) Token: 0x06000575 RID: 1397 RVA: 0x000058F0 File Offset: 0x00003AF0
		// (set) Token: 0x06000576 RID: 1398 RVA: 0x000058F8 File Offset: 0x00003AF8
		public bool IsInMainSidebar { get; set; } = true;

		// Token: 0x06000577 RID: 1399 RVA: 0x00005901 File Offset: 0x00003B01
		public SidebarElement()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000578 RID: 1400 RVA: 0x00005921 File Offset: 0x00003B21
		private void SidebarElement_Loaded(object sender, RoutedEventArgs e)
		{
			this.SetColor(false);
		}

		// Token: 0x06000579 RID: 1401 RVA: 0x0000592A File Offset: 0x00003B2A
		private void MImage_Loaded(object sender, RoutedEventArgs e)
		{
			this.mImage = (sender as CustomPictureBox);
		}

		// Token: 0x0600057A RID: 1402 RVA: 0x00023AFC File Offset: 0x00021CFC
		private void SetColor(bool isPressed = false)
		{
			if (isPressed)
			{
				BlueStacksUIBinding.BindColor(this.mBorder, Control.BorderBrushProperty, "SidebarElementClick");
				BlueStacksUIBinding.BindColor(this.mBorder, Control.BackgroundProperty, "SidebarElementClick");
				BlueStacksUIBinding.BindColor(this, Control.ForegroundProperty, "SidebarElementClick");
				return;
			}
			if (base.IsMouseOver)
			{
				BlueStacksUIBinding.BindColor(this.mBorder, Control.BorderBrushProperty, "SidebarElementHover");
				BlueStacksUIBinding.BindColor(this.mBorder, Control.BackgroundProperty, "SidebarElementHover");
				BlueStacksUIBinding.BindColor(this, Control.ForegroundProperty, "SidebarElementHover");
				return;
			}
			BlueStacksUIBinding.BindColor(this.mBorder, Control.BorderBrushProperty, "SidebarElementNormal");
			BlueStacksUIBinding.BindColor(this.mBorder, Control.BackgroundProperty, "SidebarElementNormal");
			BlueStacksUIBinding.BindColor(this, Control.ForegroundProperty, "SidebarElementNormal");
		}

		// Token: 0x0600057B RID: 1403 RVA: 0x00005921 File Offset: 0x00003B21
		private void SidebarElement_MouseEnter(object sender, MouseEventArgs e)
		{
			this.SetColor(false);
		}

		// Token: 0x0600057C RID: 1404 RVA: 0x00005921 File Offset: 0x00003B21
		private void SidebarElement_MouseLeave(object sender, MouseEventArgs e)
		{
			this.SetColor(false);
		}

		// Token: 0x0600057D RID: 1405 RVA: 0x00005938 File Offset: 0x00003B38
		private void SidebarElement_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			this.SetColor(true);
		}

		// Token: 0x0600057E RID: 1406 RVA: 0x00005941 File Offset: 0x00003B41
		private void SidebarElement_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if ((bool)e.NewValue)
			{
				base.Opacity = 1.0;
				return;
			}
			base.Opacity = 0.5;
		}

		// Token: 0x0600057F RID: 1407 RVA: 0x00005921 File Offset: 0x00003B21
		private void SidebarElement_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			this.SetColor(false);
		}

		// Token: 0x06000580 RID: 1408 RVA: 0x00023BC4 File Offset: 0x00021DC4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/sidebarelement.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000581 RID: 1409 RVA: 0x00023BF4 File Offset: 0x00021DF4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mSidebarElement = (SidebarElement)target;
				this.mSidebarElement.MouseEnter += this.SidebarElement_MouseEnter;
				this.mSidebarElement.MouseLeave += this.SidebarElement_MouseLeave;
				this.mSidebarElement.PreviewMouseDown += this.SidebarElement_PreviewMouseDown;
				this.mSidebarElement.PreviewMouseUp += this.SidebarElement_PreviewMouseUp;
				this.mSidebarElement.Loaded += this.SidebarElement_Loaded;
				this.mSidebarElement.IsEnabledChanged += this.SidebarElement_IsEnabledChanged;
				return;
			case 2:
				this.mBorder = (Border)target;
				return;
			case 3:
				this.mGrid = (Grid)target;
				return;
			case 4:
				this.mImage = (CustomPictureBox)target;
				this.mImage.Loaded += this.MImage_Loaded;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400035F RID: 863
		public string mSidebarElementTooltipKey = string.Empty;

		// Token: 0x04000360 RID: 864
		internal SidebarElement mSidebarElement;

		// Token: 0x04000361 RID: 865
		internal Border mBorder;

		// Token: 0x04000362 RID: 866
		internal Grid mGrid;

		// Token: 0x04000363 RID: 867
		internal CustomPictureBox mImage;

		// Token: 0x04000364 RID: 868
		private bool _contentLoaded;
	}
}
