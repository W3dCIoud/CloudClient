﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000157 RID: 343
	internal class Stats
	{
		// Token: 0x170001D7 RID: 471
		// (get) Token: 0x06000D28 RID: 3368 RVA: 0x0000A260 File Offset: 0x00008460
		// (set) Token: 0x06000D29 RID: 3369 RVA: 0x0000A274 File Offset: 0x00008474
		private static string SessionId
		{
			get
			{
				if (Stats.sSessionId == null)
				{
					Stats.ResetSessionId();
				}
				return Stats.sSessionId;
			}
			set
			{
				Stats.sSessionId = value;
			}
		}

		// Token: 0x06000D2A RID: 3370 RVA: 0x0000A27C File Offset: 0x0000847C
		public static string GetSessionId()
		{
			return Stats.SessionId;
		}

		// Token: 0x06000D2B RID: 3371 RVA: 0x0000A283 File Offset: 0x00008483
		public static string ResetSessionId()
		{
			Stats.SessionId = Stats.Timestamp;
			return Stats.SessionId;
		}

		// Token: 0x170001D8 RID: 472
		// (get) Token: 0x06000D2C RID: 3372 RVA: 0x00056E68 File Offset: 0x00055068
		private static string Timestamp
		{
			get
			{
				long num = DateTime.Now.Ticks - DateTime.Parse("01/01/1970 00:00:00").Ticks;
				return (num / 10000000L).ToString();
			}
		}

		// Token: 0x04000980 RID: 2432
		internal string op;

		// Token: 0x04000981 RID: 2433
		internal string status;

		// Token: 0x04000982 RID: 2434
		internal string uri;

		// Token: 0x04000983 RID: 2435
		internal string versionToBeInstalled = "";

		// Token: 0x04000984 RID: 2436
		internal string packageName = "";

		// Token: 0x04000985 RID: 2437
		private static string sSessionId;
	}
}
