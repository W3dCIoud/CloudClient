﻿using System;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000124 RID: 292
	public class AppIconPromotionObject
	{
		// Token: 0x170001A8 RID: 424
		// (get) Token: 0x06000B80 RID: 2944 RVA: 0x00008FD8 File Offset: 0x000071D8
		// (set) Token: 0x06000B81 RID: 2945 RVA: 0x00008FE0 File Offset: 0x000071E0
		public string AppPromotionID
		{
			get
			{
				return this.mAppPromotionID;
			}
			set
			{
				this.mAppPromotionID = value;
			}
		}

		// Token: 0x170001A9 RID: 425
		// (get) Token: 0x06000B82 RID: 2946 RVA: 0x00008FE9 File Offset: 0x000071E9
		// (set) Token: 0x06000B83 RID: 2947 RVA: 0x00008FF1 File Offset: 0x000071F1
		public GenericAction AppPromotionAction
		{
			get
			{
				return this.mAppPromotionAction;
			}
			set
			{
				this.mAppPromotionAction = value;
			}
		}

		// Token: 0x170001AA RID: 426
		// (get) Token: 0x06000B84 RID: 2948 RVA: 0x00008FFA File Offset: 0x000071FA
		// (set) Token: 0x06000B85 RID: 2949 RVA: 0x00009002 File Offset: 0x00007202
		public string AppPromotionPackage
		{
			get
			{
				return this.mAppPromotionPackage;
			}
			set
			{
				this.mAppPromotionPackage = value;
			}
		}

		// Token: 0x170001AB RID: 427
		// (get) Token: 0x06000B86 RID: 2950 RVA: 0x0000900B File Offset: 0x0000720B
		// (set) Token: 0x06000B87 RID: 2951 RVA: 0x00009013 File Offset: 0x00007213
		public string AppPromotionName
		{
			get
			{
				return this.mAppPromotionName;
			}
			set
			{
				this.mAppPromotionName = value;
			}
		}

		// Token: 0x170001AC RID: 428
		// (get) Token: 0x06000B88 RID: 2952 RVA: 0x0000901C File Offset: 0x0000721C
		// (set) Token: 0x06000B89 RID: 2953 RVA: 0x00009024 File Offset: 0x00007224
		public string AppPromotionActionParam
		{
			get
			{
				return this.mAppPromotionActionParam;
			}
			set
			{
				this.mAppPromotionActionParam = value;
			}
		}

		// Token: 0x170001AD RID: 429
		// (get) Token: 0x06000B8A RID: 2954 RVA: 0x0000902D File Offset: 0x0000722D
		// (set) Token: 0x06000B8B RID: 2955 RVA: 0x00009035 File Offset: 0x00007235
		public string AppPromotionImagePath
		{
			get
			{
				return this.sAppPromotionImagePath;
			}
			set
			{
				this.sAppPromotionImagePath = value;
			}
		}

		// Token: 0x04000854 RID: 2132
		private string mAppPromotionID = string.Empty;

		// Token: 0x04000855 RID: 2133
		private GenericAction mAppPromotionAction = GenericAction.InstallPlay;

		// Token: 0x04000856 RID: 2134
		private string mAppPromotionPackage = string.Empty;

		// Token: 0x04000857 RID: 2135
		private string mAppPromotionName = string.Empty;

		// Token: 0x04000858 RID: 2136
		private string mAppPromotionActionParam = string.Empty;

		// Token: 0x04000859 RID: 2137
		private string sAppPromotionImagePath = string.Empty;
	}
}
