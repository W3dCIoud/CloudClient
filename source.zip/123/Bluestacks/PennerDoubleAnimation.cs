﻿using System;
using System.ComponentModel;
using System.Reflection;
using System.Windows;
using System.Windows.Media.Animation;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000147 RID: 327
	public class PennerDoubleAnimation : DoubleAnimationBase
	{
		// Token: 0x06000CBE RID: 3262 RVA: 0x00009DA2 File Offset: 0x00007FA2
		public PennerDoubleAnimation()
		{
		}

		// Token: 0x06000CBF RID: 3263 RVA: 0x00009DAA File Offset: 0x00007FAA
		public PennerDoubleAnimation(PennerDoubleAnimation.Equations type, double from, double to)
		{
			this.Equation = type;
			this.From = from;
			this.To = to;
		}

		// Token: 0x06000CC0 RID: 3264 RVA: 0x00009DC7 File Offset: 0x00007FC7
		public PennerDoubleAnimation(PennerDoubleAnimation.Equations type, double from, double to, Duration duration)
		{
			this.Equation = type;
			this.From = from;
			this.To = to;
			base.Duration = duration;
		}

		// Token: 0x06000CC1 RID: 3265 RVA: 0x00054F60 File Offset: 0x00053160
		protected override double GetCurrentValueCore(double startValue, double targetValue, AnimationClock clock)
		{
			double result;
			try
			{
				object[] parameters = new object[]
				{
					clock.CurrentTime.Value.TotalSeconds,
					this.From,
					this.To - this.From,
					base.Duration.TimeSpan.TotalSeconds
				};
				result = (double)this._EasingMethod.Invoke(this, parameters);
			}
			catch
			{
				result = this.From;
			}
			return result;
		}

		// Token: 0x06000CC2 RID: 3266 RVA: 0x00009DEC File Offset: 0x00007FEC
		protected override Freezable CreateInstanceCore()
		{
			return new PennerDoubleAnimation();
		}

		// Token: 0x06000CC3 RID: 3267 RVA: 0x00009DF3 File Offset: 0x00007FF3
		public static double Linear(double t, double b, double c, double d)
		{
			return c * t / d + b;
		}

		// Token: 0x06000CC4 RID: 3268 RVA: 0x00009DFC File Offset: 0x00007FFC
		public static double ExpoEaseOut(double t, double b, double c, double d)
		{
			if (t != d)
			{
				return c * (-Math.Pow(2.0, -10.0 * t / d) + 1.0) + b;
			}
			return b + c;
		}

		// Token: 0x06000CC5 RID: 3269 RVA: 0x00009E30 File Offset: 0x00008030
		public static double ExpoEaseIn(double t, double b, double c, double d)
		{
			if (t != 0.0)
			{
				return c * Math.Pow(2.0, 10.0 * (t / d - 1.0)) + b;
			}
			return b;
		}

		// Token: 0x06000CC6 RID: 3270 RVA: 0x00055008 File Offset: 0x00053208
		public static double ExpoEaseInOut(double t, double b, double c, double d)
		{
			if (t == 0.0)
			{
				return b;
			}
			if (t == d)
			{
				return b + c;
			}
			if ((t /= d / 2.0) < 1.0)
			{
				return c / 2.0 * Math.Pow(2.0, 10.0 * (t - 1.0)) + b;
			}
			return c / 2.0 * (-Math.Pow(2.0, -10.0 * (t -= 1.0)) + 2.0) + b;
		}

		// Token: 0x06000CC7 RID: 3271 RVA: 0x000550B8 File Offset: 0x000532B8
		public static double ExpoEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.ExpoEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.ExpoEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x06000CC8 RID: 3272 RVA: 0x00009E69 File Offset: 0x00008069
		public static double CircEaseOut(double t, double b, double c, double d)
		{
			return c * Math.Sqrt(1.0 - (t = t / d - 1.0) * t) + b;
		}

		// Token: 0x06000CC9 RID: 3273 RVA: 0x00009E90 File Offset: 0x00008090
		public static double CircEaseIn(double t, double b, double c, double d)
		{
			return -c * (Math.Sqrt(1.0 - (t /= d) * t) - 1.0) + b;
		}

		// Token: 0x06000CCA RID: 3274 RVA: 0x0005511C File Offset: 0x0005331C
		public static double CircEaseInOut(double t, double b, double c, double d)
		{
			if ((t /= d / 2.0) < 1.0)
			{
				return -c / 2.0 * (Math.Sqrt(1.0 - t * t) - 1.0) + b;
			}
			return c / 2.0 * (Math.Sqrt(1.0 - (t -= 2.0) * t) + 1.0) + b;
		}

		// Token: 0x06000CCB RID: 3275 RVA: 0x000551A8 File Offset: 0x000533A8
		public static double CircEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.CircEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.CircEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x06000CCC RID: 3276 RVA: 0x00009EB8 File Offset: 0x000080B8
		public static double QuadEaseOut(double t, double b, double c, double d)
		{
			return -c * (t /= d) * (t - 2.0) + b;
		}

		// Token: 0x06000CCD RID: 3277 RVA: 0x00009ED1 File Offset: 0x000080D1
		public static double QuadEaseIn(double t, double b, double c, double d)
		{
			return c * (t /= d) * t + b;
		}

		// Token: 0x06000CCE RID: 3278 RVA: 0x0005520C File Offset: 0x0005340C
		public static double QuadEaseInOut(double t, double b, double c, double d)
		{
			if ((t /= d / 2.0) < 1.0)
			{
				return c / 2.0 * t * t + b;
			}
			return -c / 2.0 * ((t -= 1.0) * (t - 2.0) - 1.0) + b;
		}

		// Token: 0x06000CCF RID: 3279 RVA: 0x0005527C File Offset: 0x0005347C
		public static double QuadEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.QuadEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.QuadEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x06000CD0 RID: 3280 RVA: 0x00009EDF File Offset: 0x000080DF
		public static double SineEaseOut(double t, double b, double c, double d)
		{
			return c * Math.Sin(t / d * 1.5707963267948966) + b;
		}

		// Token: 0x06000CD1 RID: 3281 RVA: 0x00009EF7 File Offset: 0x000080F7
		public static double SineEaseIn(double t, double b, double c, double d)
		{
			return -c * Math.Cos(t / d * 1.5707963267948966) + c + b;
		}

		// Token: 0x06000CD2 RID: 3282 RVA: 0x000552E0 File Offset: 0x000534E0
		public static double SineEaseInOut(double t, double b, double c, double d)
		{
			if ((t /= d / 2.0) < 1.0)
			{
				return c / 2.0 * Math.Sin(3.141592653589793 * t / 2.0) + b;
			}
			return -c / 2.0 * (Math.Cos(3.141592653589793 * (t -= 1.0) / 2.0) - 2.0) + b;
		}

		// Token: 0x06000CD3 RID: 3283 RVA: 0x00055374 File Offset: 0x00053574
		public static double SineEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.SineEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.SineEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x06000CD4 RID: 3284 RVA: 0x00009F12 File Offset: 0x00008112
		public static double CubicEaseOut(double t, double b, double c, double d)
		{
			return c * ((t = t / d - 1.0) * t * t + 1.0) + b;
		}

		// Token: 0x06000CD5 RID: 3285 RVA: 0x00009F36 File Offset: 0x00008136
		public static double CubicEaseIn(double t, double b, double c, double d)
		{
			return c * (t /= d) * t * t + b;
		}

		// Token: 0x06000CD6 RID: 3286 RVA: 0x000553D8 File Offset: 0x000535D8
		public static double CubicEaseInOut(double t, double b, double c, double d)
		{
			if ((t /= d / 2.0) < 1.0)
			{
				return c / 2.0 * t * t * t + b;
			}
			return c / 2.0 * ((t -= 2.0) * t * t + 2.0) + b;
		}

		// Token: 0x06000CD7 RID: 3287 RVA: 0x00055440 File Offset: 0x00053640
		public static double CubicEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.CubicEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.CubicEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x06000CD8 RID: 3288 RVA: 0x00009F46 File Offset: 0x00008146
		public static double QuartEaseOut(double t, double b, double c, double d)
		{
			return -c * ((t = t / d - 1.0) * t * t * t - 1.0) + b;
		}

		// Token: 0x06000CD9 RID: 3289 RVA: 0x00009F6D File Offset: 0x0000816D
		public static double QuartEaseIn(double t, double b, double c, double d)
		{
			return c * (t /= d) * t * t * t + b;
		}

		// Token: 0x06000CDA RID: 3290 RVA: 0x000554A4 File Offset: 0x000536A4
		public static double QuartEaseInOut(double t, double b, double c, double d)
		{
			if ((t /= d / 2.0) < 1.0)
			{
				return c / 2.0 * t * t * t * t + b;
			}
			return -c / 2.0 * ((t -= 2.0) * t * t * t - 2.0) + b;
		}

		// Token: 0x06000CDB RID: 3291 RVA: 0x00055510 File Offset: 0x00053710
		public static double QuartEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.QuartEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.QuartEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x06000CDC RID: 3292 RVA: 0x00009F7F File Offset: 0x0000817F
		public static double QuintEaseOut(double t, double b, double c, double d)
		{
			return c * ((t = t / d - 1.0) * t * t * t * t + 1.0) + b;
		}

		// Token: 0x06000CDD RID: 3293 RVA: 0x00009FA7 File Offset: 0x000081A7
		public static double QuintEaseIn(double t, double b, double c, double d)
		{
			return c * (t /= d) * t * t * t * t + b;
		}

		// Token: 0x06000CDE RID: 3294 RVA: 0x00055574 File Offset: 0x00053774
		public static double QuintEaseInOut(double t, double b, double c, double d)
		{
			if ((t /= d / 2.0) < 1.0)
			{
				return c / 2.0 * t * t * t * t * t + b;
			}
			return c / 2.0 * ((t -= 2.0) * t * t * t * t + 2.0) + b;
		}

		// Token: 0x06000CDF RID: 3295 RVA: 0x000555E4 File Offset: 0x000537E4
		public static double QuintEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.QuintEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.QuintEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x06000CE0 RID: 3296 RVA: 0x00055648 File Offset: 0x00053848
		public static double ElasticEaseOut(double t, double b, double c, double d)
		{
			if ((t /= d) == 1.0)
			{
				return b + c;
			}
			double num = d * 0.3;
			double num2 = num / 4.0;
			return c * Math.Pow(2.0, -10.0 * t) * Math.Sin((t * d - num2) * 6.283185307179586 / num) + c + b;
		}

		// Token: 0x06000CE1 RID: 3297 RVA: 0x000556B8 File Offset: 0x000538B8
		public static double ElasticEaseIn(double t, double b, double c, double d)
		{
			if ((t /= d) == 1.0)
			{
				return b + c;
			}
			double num = d * 0.3;
			double num2 = num / 4.0;
			return -(c * Math.Pow(2.0, 10.0 * (t -= 1.0)) * Math.Sin((t * d - num2) * 6.283185307179586 / num)) + b;
		}

		// Token: 0x06000CE2 RID: 3298 RVA: 0x00055734 File Offset: 0x00053934
		public static double ElasticEaseInOut(double t, double b, double c, double d)
		{
			if ((t /= d / 2.0) == 2.0)
			{
				return b + c;
			}
			double num = d * 0.44999999999999996;
			double num2 = num / 4.0;
			if (t < 1.0)
			{
				return -0.5 * (c * Math.Pow(2.0, 10.0 * (t -= 1.0)) * Math.Sin((t * d - num2) * 6.283185307179586 / num)) + b;
			}
			return c * Math.Pow(2.0, -10.0 * (t -= 1.0)) * Math.Sin((t * d - num2) * 6.283185307179586 / num) * 0.5 + c + b;
		}

		// Token: 0x06000CE3 RID: 3299 RVA: 0x00055820 File Offset: 0x00053A20
		public static double ElasticEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.ElasticEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.ElasticEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x06000CE4 RID: 3300 RVA: 0x00055884 File Offset: 0x00053A84
		public static double BounceEaseOut(double t, double b, double c, double d)
		{
			if ((t /= d) < 0.36363636363636365)
			{
				return c * (7.5625 * t * t) + b;
			}
			if (t < 0.7272727272727273)
			{
				return c * (7.5625 * (t -= 0.5454545454545454) * t + 0.75) + b;
			}
			if (t < 0.9090909090909091)
			{
				return c * (7.5625 * (t -= 0.8181818181818182) * t + 0.9375) + b;
			}
			return c * (7.5625 * (t -= 0.9545454545454546) * t + 0.984375) + b;
		}

		// Token: 0x06000CE5 RID: 3301 RVA: 0x00009FBB File Offset: 0x000081BB
		public static double BounceEaseIn(double t, double b, double c, double d)
		{
			return c - PennerDoubleAnimation.BounceEaseOut(d - t, 0.0, c, d) + b;
		}

		// Token: 0x06000CE6 RID: 3302 RVA: 0x00055948 File Offset: 0x00053B48
		public static double BounceEaseInOut(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.BounceEaseIn(t * 2.0, 0.0, c, d) * 0.5 + b;
			}
			return PennerDoubleAnimation.BounceEaseOut(t * 2.0 - d, 0.0, c, d) * 0.5 + c * 0.5 + b;
		}

		// Token: 0x06000CE7 RID: 3303 RVA: 0x000559C0 File Offset: 0x00053BC0
		public static double BounceEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.BounceEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.BounceEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x06000CE8 RID: 3304 RVA: 0x00009FD4 File Offset: 0x000081D4
		public static double BackEaseOut(double t, double b, double c, double d)
		{
			return c * ((t = t / d - 1.0) * t * (2.70158 * t + 1.70158) + 1.0) + b;
		}

		// Token: 0x06000CE9 RID: 3305 RVA: 0x0000A00C File Offset: 0x0000820C
		public static double BackEaseIn(double t, double b, double c, double d)
		{
			return c * (t /= d) * t * (2.70158 * t - 1.70158) + b;
		}

		// Token: 0x06000CEA RID: 3306 RVA: 0x00055A24 File Offset: 0x00053C24
		public static double BackEaseInOut(double t, double b, double c, double d)
		{
			double num = 1.70158;
			if ((t /= d / 2.0) < 1.0)
			{
				return c / 2.0 * (t * t * (((num *= 1.525) + 1.0) * t - num)) + b;
			}
			return c / 2.0 * ((t -= 2.0) * t * (((num *= 1.525) + 1.0) * t + num) + 2.0) + b;
		}

		// Token: 0x06000CEB RID: 3307 RVA: 0x00055AC8 File Offset: 0x00053CC8
		public static double BackEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.BackEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.BackEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x06000CEC RID: 3308 RVA: 0x0000A030 File Offset: 0x00008230
		private static void HandleEquationChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			(sender as PennerDoubleAnimation)._EasingMethod = typeof(PennerDoubleAnimation).GetMethod(e.NewValue.ToString());
		}

		// Token: 0x170001D2 RID: 466
		// (get) Token: 0x06000CED RID: 3309 RVA: 0x0000A058 File Offset: 0x00008258
		// (set) Token: 0x06000CEE RID: 3310 RVA: 0x0000A06A File Offset: 0x0000826A
		[TypeConverter(typeof(PennerDoubleAnimationTypeConverter))]
		public PennerDoubleAnimation.Equations Equation
		{
			get
			{
				return (PennerDoubleAnimation.Equations)base.GetValue(PennerDoubleAnimation.EquationProperty);
			}
			set
			{
				base.SetValue(PennerDoubleAnimation.EquationProperty, value);
				this._EasingMethod = base.GetType().GetMethod(value.ToString());
			}
		}

		// Token: 0x170001D3 RID: 467
		// (get) Token: 0x06000CEF RID: 3311 RVA: 0x0000A09B File Offset: 0x0000829B
		// (set) Token: 0x06000CF0 RID: 3312 RVA: 0x0000A0AD File Offset: 0x000082AD
		public double From
		{
			get
			{
				return (double)base.GetValue(PennerDoubleAnimation.FromProperty);
			}
			set
			{
				base.SetValue(PennerDoubleAnimation.FromProperty, value);
			}
		}

		// Token: 0x170001D4 RID: 468
		// (get) Token: 0x06000CF1 RID: 3313 RVA: 0x0000A0C0 File Offset: 0x000082C0
		// (set) Token: 0x06000CF2 RID: 3314 RVA: 0x0000A0D2 File Offset: 0x000082D2
		public double To
		{
			get
			{
				return (double)base.GetValue(PennerDoubleAnimation.ToProperty);
			}
			set
			{
				base.SetValue(PennerDoubleAnimation.ToProperty, value);
			}
		}

		// Token: 0x0400092E RID: 2350
		private MethodInfo _EasingMethod;

		// Token: 0x0400092F RID: 2351
		public static readonly DependencyProperty EquationProperty = DependencyProperty.Register("Equation", typeof(PennerDoubleAnimation.Equations), typeof(PennerDoubleAnimation), new PropertyMetadata(PennerDoubleAnimation.Equations.Linear, new PropertyChangedCallback(PennerDoubleAnimation.HandleEquationChanged)));

		// Token: 0x04000930 RID: 2352
		public static readonly DependencyProperty FromProperty = DependencyProperty.Register("From", typeof(double), typeof(PennerDoubleAnimation), new PropertyMetadata(0.0));

		// Token: 0x04000931 RID: 2353
		public static readonly DependencyProperty ToProperty = DependencyProperty.Register("To", typeof(double), typeof(PennerDoubleAnimation), new PropertyMetadata(0.0));

		// Token: 0x02000148 RID: 328
		public enum Equations
		{
			// Token: 0x04000933 RID: 2355
			Linear,
			// Token: 0x04000934 RID: 2356
			QuadEaseOut,
			// Token: 0x04000935 RID: 2357
			QuadEaseIn,
			// Token: 0x04000936 RID: 2358
			QuadEaseInOut,
			// Token: 0x04000937 RID: 2359
			QuadEaseOutIn,
			// Token: 0x04000938 RID: 2360
			ExpoEaseOut,
			// Token: 0x04000939 RID: 2361
			ExpoEaseIn,
			// Token: 0x0400093A RID: 2362
			ExpoEaseInOut,
			// Token: 0x0400093B RID: 2363
			ExpoEaseOutIn,
			// Token: 0x0400093C RID: 2364
			CubicEaseOut,
			// Token: 0x0400093D RID: 2365
			CubicEaseIn,
			// Token: 0x0400093E RID: 2366
			CubicEaseInOut,
			// Token: 0x0400093F RID: 2367
			CubicEaseOutIn,
			// Token: 0x04000940 RID: 2368
			QuartEaseOut,
			// Token: 0x04000941 RID: 2369
			QuartEaseIn,
			// Token: 0x04000942 RID: 2370
			QuartEaseInOut,
			// Token: 0x04000943 RID: 2371
			QuartEaseOutIn,
			// Token: 0x04000944 RID: 2372
			QuintEaseOut,
			// Token: 0x04000945 RID: 2373
			QuintEaseIn,
			// Token: 0x04000946 RID: 2374
			QuintEaseInOut,
			// Token: 0x04000947 RID: 2375
			QuintEaseOutIn,
			// Token: 0x04000948 RID: 2376
			CircEaseOut,
			// Token: 0x04000949 RID: 2377
			CircEaseIn,
			// Token: 0x0400094A RID: 2378
			CircEaseInOut,
			// Token: 0x0400094B RID: 2379
			CircEaseOutIn,
			// Token: 0x0400094C RID: 2380
			SineEaseOut,
			// Token: 0x0400094D RID: 2381
			SineEaseIn,
			// Token: 0x0400094E RID: 2382
			SineEaseInOut,
			// Token: 0x0400094F RID: 2383
			SineEaseOutIn,
			// Token: 0x04000950 RID: 2384
			ElasticEaseOut,
			// Token: 0x04000951 RID: 2385
			ElasticEaseIn,
			// Token: 0x04000952 RID: 2386
			ElasticEaseInOut,
			// Token: 0x04000953 RID: 2387
			ElasticEaseOutIn,
			// Token: 0x04000954 RID: 2388
			BounceEaseOut,
			// Token: 0x04000955 RID: 2389
			BounceEaseIn,
			// Token: 0x04000956 RID: 2390
			BounceEaseInOut,
			// Token: 0x04000957 RID: 2391
			BounceEaseOutIn,
			// Token: 0x04000958 RID: 2392
			BackEaseOut,
			// Token: 0x04000959 RID: 2393
			BackEaseIn,
			// Token: 0x0400095A RID: 2394
			BackEaseInOut,
			// Token: 0x0400095B RID: 2395
			BackEaseOutIn
		}
	}
}
