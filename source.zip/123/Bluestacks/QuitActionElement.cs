﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000A0 RID: 160
	public class QuitActionElement : UserControl, IComponentConnector
	{
		// Token: 0x060006D2 RID: 1746 RVA: 0x000066DF File Offset: 0x000048DF
		public QuitActionElement()
		{
			this.InitializeComponent();
		}

		// Token: 0x060006D3 RID: 1747 RVA: 0x0002B360 File Offset: 0x00029560
		private void SetProperties(QuitActionItem item)
		{
			string value = QuitActionCollection.Actions[item][QuitActionItemProperty.CallToAction];
			this.mBodyTextBlock.Text = QuitActionCollection.Actions[item][QuitActionItemProperty.BodyText];
			this.mMainImage.ImageName = QuitActionCollection.Actions[item][QuitActionItemProperty.ImageName];
			this.mHyperlinkTextBlock.Text = QuitActionCollection.Actions[item][QuitActionItemProperty.ActionText];
			this.mQuitActionValue = QuitActionCollection.Actions[item][QuitActionItemProperty.ActionValue];
			this.mCTAEventName = QuitActionCollection.Actions[item][QuitActionItemProperty.StatEventName];
			this.mCallToAction = (QuitActionItemCTA)Enum.Parse(typeof(QuitActionItemCTA), value, true);
		}

		// Token: 0x1700014B RID: 331
		// (get) Token: 0x060006D4 RID: 1748 RVA: 0x0000670E File Offset: 0x0000490E
		// (set) Token: 0x060006D5 RID: 1749 RVA: 0x00006720 File Offset: 0x00004920
		public QuitActionItem ActionElement
		{
			get
			{
				return (QuitActionItem)base.GetValue(QuitActionElement.ActionElementProperty);
			}
			set
			{
				base.SetValue(QuitActionElement.ActionElementProperty, value);
			}
		}

		// Token: 0x060006D6 RID: 1750 RVA: 0x0002B420 File Offset: 0x00029620
		private static void ActionElementPropertyChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			QuitActionElement quitActionElement = d as QuitActionElement;
			if (!DesignerProperties.GetIsInDesignMode(quitActionElement))
			{
				quitActionElement.SetProperties((QuitActionItem)e.NewValue);
			}
		}

		// Token: 0x060006D7 RID: 1751 RVA: 0x0002B450 File Offset: 0x00029650
		private void QAE_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			try
			{
				QuitActionItemCTA quitActionItemCTA = this.mCallToAction;
				if (quitActionItemCTA != QuitActionItemCTA.OpenLinkInBrowser)
				{
					if (quitActionItemCTA == QuitActionItemCTA.OpenApplication)
					{
						if (!string.IsNullOrEmpty(this.mQuitActionValue))
						{
							Process.Start(this.mQuitActionValue);
						}
						this.SendCTAStat();
					}
				}
				else
				{
					if (!string.IsNullOrEmpty(this.mQuitActionValue))
					{
						BlueStacksUIUtils.OpenUrl(this.mQuitActionValue);
					}
					this.SendCTAStat();
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Some error while CallToAction of QuitPopup. Ex: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x060006D8 RID: 1752 RVA: 0x00006733 File Offset: 0x00004933
		private void SendCTAStat()
		{
			ClientStats.SendLocalQuitPopupStatsAsync(this.ParentPopupTag, this.mCTAEventName);
		}

		// Token: 0x060006D9 RID: 1753 RVA: 0x00006746 File Offset: 0x00004946
		private void QAE_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mExternalLinkImage.Visibility = Visibility.Visible;
			BlueStacksUIBinding.BindColor(this.maskBorder, Border.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x060006DA RID: 1754 RVA: 0x00006769 File Offset: 0x00004969
		private void QAE_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mExternalLinkImage.Visibility = Visibility.Hidden;
			this.maskBorder.Background = Brushes.Transparent;
		}

		// Token: 0x060006DB RID: 1755 RVA: 0x0002B4D8 File Offset: 0x000296D8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/quitactionelement.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060006DC RID: 1756 RVA: 0x0002B508 File Offset: 0x00029708
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((QuitActionElement)target).MouseEnter += this.QAE_MouseEnter;
				((QuitActionElement)target).MouseLeave += this.QAE_MouseLeave;
				((QuitActionElement)target).PreviewMouseUp += this.QAE_PreviewMouseUp;
				return;
			case 2:
				this.maskBorder = (Border)target;
				return;
			case 3:
				this.mParentGrid = (Grid)target;
				return;
			case 4:
				this.mExternalLinkImage = (CustomPictureBox)target;
				return;
			case 5:
				this.mMainImage = (CustomPictureBox)target;
				return;
			case 6:
				this.mBodyTextBlock = (TextBlock)target;
				return;
			case 7:
				this.mHyperlinkTextBlock = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400049A RID: 1178
		private string mQuitActionValue = string.Empty;

		// Token: 0x0400049B RID: 1179
		private string mCTAEventName = string.Empty;

		// Token: 0x0400049C RID: 1180
		private QuitActionItemCTA mCallToAction;

		// Token: 0x0400049D RID: 1181
		public string ParentPopupTag = string.Empty;

		// Token: 0x0400049E RID: 1182
		public static readonly DependencyProperty ActionElementProperty = DependencyProperty.Register("ActionElement", typeof(QuitActionItem), typeof(QuitActionElement), new PropertyMetadata(QuitActionItem.None, new PropertyChangedCallback(QuitActionElement.ActionElementPropertyChangedCallback)));

		// Token: 0x0400049F RID: 1183
		internal Border maskBorder;

		// Token: 0x040004A0 RID: 1184
		internal Grid mParentGrid;

		// Token: 0x040004A1 RID: 1185
		internal CustomPictureBox mExternalLinkImage;

		// Token: 0x040004A2 RID: 1186
		internal CustomPictureBox mMainImage;

		// Token: 0x040004A3 RID: 1187
		internal TextBlock mBodyTextBlock;

		// Token: 0x040004A4 RID: 1188
		internal TextBlock mHyperlinkTextBlock;

		// Token: 0x040004A5 RID: 1189
		private bool _contentLoaded;
	}
}
