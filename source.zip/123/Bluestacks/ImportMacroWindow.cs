﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200005D RID: 93
	public class ImportMacroWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x060003F3 RID: 1011 RVA: 0x00004A53 File Offset: 0x00002C53
		public ImportMacroWindow(OperationRecorderWindow window, MainWindow mainWindow)
		{
			this.InitializeComponent();
			this.mOperationWindow = window;
			this.ParentWindow = mainWindow;
			this.mScriptsStackPanel = (this.mScriptsListScrollbar.Content as StackPanel);
		}

		// Token: 0x060003F4 RID: 1012 RVA: 0x00004A90 File Offset: 0x00002C90
		private void Close_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.CloseWindow();
		}

		// Token: 0x060003F5 RID: 1013 RVA: 0x00004A98 File Offset: 0x00002C98
		private void CloseWindow()
		{
			base.Close();
			this.mOperationWindow.mImportMacroWindow = null;
			this.mOperationWindow.mOverlayGrid.Visibility = Visibility.Hidden;
			this.mOperationWindow.Focus();
		}

		// Token: 0x060003F6 RID: 1014 RVA: 0x0001AED8 File Offset: 0x000190D8
		internal void Init()
		{
			try
			{
				this.mScriptsStackPanel.Children.Clear();
				foreach (OperationsRecord operationsRecord in this.ParentWindow.OperationRecorderWindow.mRenamingMacrosList)
				{
					ImportMacroScriptsControl importMacroScriptsControl = new ImportMacroScriptsControl(this, this.ParentWindow);
					importMacroScriptsControl.mContent.Content = operationsRecord.Name;
					importMacroScriptsControl.Margin = new Thickness(0.0, 5.0, 0.0, 5.0);
					string suggestedName = (!MainWindow.sMacroScriptNames.Contains(operationsRecord.Name.ToLower().Trim())) ? operationsRecord.Name : this.ParentWindow.mCommonHandler.GetMacroName(operationsRecord.Name);
					importMacroScriptsControl.mImportName.Text = this.ValidateSuggestedName(suggestedName);
					this.mScriptsStackPanel.Children.Add(importMacroScriptsControl);
					this.recordToBoxDict.Add(operationsRecord.GetHashCode(), importMacroScriptsControl);
				}
				this.mNumberOfFilesSelectedForImport = 0;
			}
			catch (Exception ex)
			{
				Logger.Error("Error in import window init err: " + ex.ToString());
			}
		}

		// Token: 0x060003F7 RID: 1015 RVA: 0x0001B04C File Offset: 0x0001924C
		private string ValidateSuggestedName(string suggestedName)
		{
			if (this.recordToBoxDict.Values.Any((ImportMacroScriptsControl box) => string.Equals(box.mImportName.Text.Trim().ToLower(), suggestedName)))
			{
				int num = suggestedName.LastIndexOf('(') + 1;
				int num2 = suggestedName.LastIndexOf(')');
				int num3;
				int.TryParse(suggestedName.Substring(num, num2 - num), out num3);
				suggestedName = suggestedName.Remove(num, num2 - num).Insert(num, (num3 + 1).ToString());
				return this.ValidateSuggestedName(suggestedName);
			}
			return suggestedName;
		}

		// Token: 0x060003F8 RID: 1016 RVA: 0x0001B0F4 File Offset: 0x000192F4
		private bool CheckIfEditedMacroNameIsAllowed(string text, ImportMacroScriptsControl item)
		{
			if (string.IsNullOrEmpty(text.Trim()))
			{
				BlueStacksUIBinding.Bind(item.mWarningMsg, LocaleStrings.GetLocalizedString("STRING_MACRO_NAME_NULL_MESSAGE", false), "");
				return false;
			}
			using (List<string>.Enumerator enumerator = MainWindow.sMacroScriptNames.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.ToLower().Trim() == text.ToLower().Trim())
					{
						return false;
					}
				}
			}
			foreach (object obj in this.mScriptsStackPanel.Children)
			{
				ImportMacroScriptsControl importMacroScriptsControl = (ImportMacroScriptsControl)obj;
				if (item != importMacroScriptsControl)
				{
					bool? isChecked = importMacroScriptsControl.mContent.IsChecked;
					bool flag = true;
					if ((isChecked.GetValueOrDefault() == flag & isChecked != null) && importMacroScriptsControl.mImportName.Text.ToLower().Trim() == text.ToLower().Trim())
					{
						return false;
					}
				}
			}
			return true;
		}

		// Token: 0x060003F9 RID: 1017 RVA: 0x0001B22C File Offset: 0x0001942C
		internal void Box_Unchecked(object sender, RoutedEventArgs e)
		{
			this.mNumberOfFilesSelectedForImport--;
			if (this.mNumberOfFilesSelectedForImport == 0)
			{
				this.mImportBtn.IsEnabled = false;
			}
			if (this.mNumberOfFilesSelectedForImport == this.mScriptsStackPanel.Children.Count - 1)
			{
				this.mSelectAllBtn.IsChecked = new bool?(false);
			}
		}

		// Token: 0x060003FA RID: 1018 RVA: 0x0001B288 File Offset: 0x00019488
		internal void Box_Checked(object sender, RoutedEventArgs e)
		{
			this.mNumberOfFilesSelectedForImport++;
			if (this.mNumberOfFilesSelectedForImport == 1)
			{
				this.mImportBtn.IsEnabled = true;
			}
			if (this.mNumberOfFilesSelectedForImport == this.mScriptsStackPanel.Children.Count)
			{
				this.mSelectAllBtn.IsChecked = new bool?(true);
			}
		}

		// Token: 0x060003FB RID: 1019 RVA: 0x0001B2E4 File Offset: 0x000194E4
		private void ImportBtn_Click(object sender, RoutedEventArgs e)
		{
			int num = 0;
			bool flag = false;
			bool flag2 = true;
			foreach (object obj in this.mScriptsStackPanel.Children)
			{
				ImportMacroScriptsControl importMacroScriptsControl = (ImportMacroScriptsControl)obj;
				bool? isChecked = importMacroScriptsControl.mContent.IsChecked;
				bool flag3 = true;
				if (isChecked.GetValueOrDefault() == flag3 & isChecked != null)
				{
					if (importMacroScriptsControl.mImportName.Text.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
					{
						string path = string.Format("{0} {1} {2}", LocaleStrings.GetLocalizedString("STRING_MACRO_NAME_ERROR", false), Environment.NewLine, "\\ / : * ? \" < > |");
						BlueStacksUIBinding.Bind(importMacroScriptsControl.mWarningMsg, path, "");
						importMacroScriptsControl.mImportName.InputTextValidity = TextValidityOptions.Error;
						importMacroScriptsControl.mWarningMsg.Visibility = Visibility.Visible;
						flag2 = false;
					}
					else if (!this.CheckIfEditedMacroNameIsAllowed(importMacroScriptsControl.mImportName.Text, importMacroScriptsControl))
					{
						if (!string.IsNullOrEmpty(importMacroScriptsControl.mImportName.Text.Trim()))
						{
							BlueStacksUIBinding.Bind(importMacroScriptsControl.mWarningMsg, LocaleStrings.GetLocalizedString("STRING_DUPLICATE_MACRO_NAME_WARNING", false), "");
						}
						importMacroScriptsControl.mImportName.InputTextValidity = TextValidityOptions.Error;
						importMacroScriptsControl.mWarningMsg.Visibility = Visibility.Visible;
						flag2 = false;
					}
					else
					{
						importMacroScriptsControl.mImportName.InputTextValidity = TextValidityOptions.Success;
						importMacroScriptsControl.mWarningMsg.Visibility = Visibility.Collapsed;
					}
					flag = true;
				}
				num++;
			}
			if (!flag)
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_IMPORT_MACRO_SELECTED", false), 4.0, true);
				return;
			}
			if (flag2)
			{
				if (!Directory.Exists(RegistryStrings.OperationsScriptFolder))
				{
					Directory.CreateDirectory(RegistryStrings.OperationsScriptFolder);
				}
				foreach (OperationsRecord operationsRecord in this.ParentWindow.OperationRecorderWindow.mRenamingMacrosList)
				{
					ImportMacroScriptsControl importMacroScriptsControl2 = this.recordToBoxDict[operationsRecord.GetHashCode()];
					if (importMacroScriptsControl2.mContent.IsChecked.GetValueOrDefault())
					{
						operationsRecord.Name = importMacroScriptsControl2.mImportName.Text.Trim();
						this.ParentWindow.mCommonHandler.SerializeJsonOperationRecord(operationsRecord, operationsRecord.Name.ToLower().Trim() + ".json");
						MainWindow.sMacroScriptNames.Add(operationsRecord.Name.ToLower().Trim());
					}
				}
				this.ParentWindow.OperationRecorderWindow.mRenamingMacrosList.Clear();
				CommonHandlers.RefreshAllOperationRecorderWindowWithScroll();
				this.CloseWindow();
			}
		}

		// Token: 0x060003FC RID: 1020 RVA: 0x00004AC9 File Offset: 0x00002CC9
		private void BgExport_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			this.ShowLoadingGrid(false);
			this.CloseWindow();
		}

		// Token: 0x060003FD RID: 1021 RVA: 0x0001B5C4 File Offset: 0x000197C4
		private void ShowLoadingGrid(bool isShow)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (isShow)
				{
					this.mLoadingGrid.Visibility = Visibility.Visible;
					return;
				}
				this.mLoadingGrid.Visibility = Visibility.Hidden;
			}), new object[0]);
		}

		// Token: 0x060003FE RID: 1022 RVA: 0x0001B604 File Offset: 0x00019804
		private void SelectAllBtn_Click(object sender, RoutedEventArgs e)
		{
			if (this.mSelectAllBtn.IsChecked.Value)
			{
				using (IEnumerator enumerator = this.mScriptsStackPanel.Children.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						object obj = enumerator.Current;
						(obj as ImportMacroScriptsControl).mContent.IsChecked = new bool?(true);
					}
					return;
				}
			}
			foreach (object obj2 in this.mScriptsStackPanel.Children)
			{
				(obj2 as ImportMacroScriptsControl).mContent.IsChecked = new bool?(false);
			}
		}

		// Token: 0x060003FF RID: 1023 RVA: 0x0001B6D4 File Offset: 0x000198D4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/importmacrowindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000400 RID: 1024 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000401 RID: 1025 RVA: 0x0001B704 File Offset: 0x00019904
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				((CustomPictureBox)target).MouseLeftButtonUp += this.Close_MouseLeftButtonUp;
				return;
			case 3:
				this.mScriptsListScrollbar = (ScrollViewer)target;
				return;
			case 4:
				this.mSelectAllBtn = (CustomCheckbox)target;
				this.mSelectAllBtn.Click += this.SelectAllBtn_Click;
				return;
			case 5:
				this.mImportBtn = (CustomButton)target;
				this.mImportBtn.Click += this.ImportBtn_Click;
				return;
			case 6:
				this.mLoadingGrid = (ProgressBar)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000246 RID: 582
		private OperationRecorderWindow mOperationWindow;

		// Token: 0x04000247 RID: 583
		private MainWindow ParentWindow;

		// Token: 0x04000248 RID: 584
		internal StackPanel mScriptsStackPanel;

		// Token: 0x04000249 RID: 585
		internal int mNumberOfFilesSelectedForImport;

		// Token: 0x0400024A RID: 586
		private Dictionary<int, ImportMacroScriptsControl> recordToBoxDict = new Dictionary<int, ImportMacroScriptsControl>();

		// Token: 0x0400024B RID: 587
		internal Border mMaskBorder;

		// Token: 0x0400024C RID: 588
		internal ScrollViewer mScriptsListScrollbar;

		// Token: 0x0400024D RID: 589
		internal CustomCheckbox mSelectAllBtn;

		// Token: 0x0400024E RID: 590
		internal CustomButton mImportBtn;

		// Token: 0x0400024F RID: 591
		internal ProgressBar mLoadingGrid;

		// Token: 0x04000250 RID: 592
		private bool _contentLoaded;
	}
}
