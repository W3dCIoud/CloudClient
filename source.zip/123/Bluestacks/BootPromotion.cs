﻿using System;
using System.IO;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200004E RID: 78
	public class BootPromotion
	{
		// Token: 0x17000123 RID: 291
		// (get) Token: 0x0600036F RID: 879 RVA: 0x000044D1 File Offset: 0x000026D1
		// (set) Token: 0x06000370 RID: 880 RVA: 0x000044D9 File Offset: 0x000026D9
		public int Order
		{
			get
			{
				return this.mOrder;
			}
			set
			{
				this.mOrder = value;
			}
		}

		// Token: 0x17000124 RID: 292
		// (get) Token: 0x06000371 RID: 881 RVA: 0x000044E2 File Offset: 0x000026E2
		// (set) Token: 0x06000372 RID: 882 RVA: 0x000044EA File Offset: 0x000026EA
		public SerializableDictionary<string, string> ExtraPayload
		{
			get
			{
				return this.mExtraPayload;
			}
			set
			{
				this.mExtraPayload = value;
			}
		}

		// Token: 0x17000125 RID: 293
		// (get) Token: 0x06000373 RID: 883 RVA: 0x000044F3 File Offset: 0x000026F3
		// (set) Token: 0x06000374 RID: 884 RVA: 0x000044FB File Offset: 0x000026FB
		public string Id
		{
			get
			{
				return this.mId;
			}
			set
			{
				this.mId = value;
			}
		}

		// Token: 0x17000126 RID: 294
		// (get) Token: 0x06000375 RID: 885 RVA: 0x00004504 File Offset: 0x00002704
		// (set) Token: 0x06000376 RID: 886 RVA: 0x0000450C File Offset: 0x0000270C
		public string ButtonText
		{
			get
			{
				return this.mButtonText;
			}
			set
			{
				this.mButtonText = value;
			}
		}

		// Token: 0x17000127 RID: 295
		// (get) Token: 0x06000377 RID: 887 RVA: 0x00004515 File Offset: 0x00002715
		// (set) Token: 0x06000378 RID: 888 RVA: 0x0000451D File Offset: 0x0000271D
		public string ImagePath
		{
			get
			{
				return this.sImagePath;
			}
			set
			{
				this.sImagePath = value;
			}
		}

		// Token: 0x17000128 RID: 296
		// (get) Token: 0x06000379 RID: 889 RVA: 0x00004526 File Offset: 0x00002726
		// (set) Token: 0x0600037A RID: 890 RVA: 0x0000452E File Offset: 0x0000272E
		public string ThemeEnabled
		{
			get
			{
				return this.mThemeEnabled;
			}
			set
			{
				this.mThemeEnabled = value;
			}
		}

		// Token: 0x17000129 RID: 297
		// (get) Token: 0x0600037B RID: 891 RVA: 0x00004537 File Offset: 0x00002737
		// (set) Token: 0x0600037C RID: 892 RVA: 0x0000453F File Offset: 0x0000273F
		public string ThemeName
		{
			get
			{
				return this.mThemeName;
			}
			set
			{
				this.mThemeName = value;
			}
		}

		// Token: 0x1700012A RID: 298
		// (get) Token: 0x0600037D RID: 893 RVA: 0x00004548 File Offset: 0x00002748
		// (set) Token: 0x0600037E RID: 894 RVA: 0x00004550 File Offset: 0x00002750
		public string PromoBtnClickStatusText
		{
			get
			{
				return this.mPromoBtnClickStatusText;
			}
			set
			{
				this.mPromoBtnClickStatusText = value;
			}
		}

		// Token: 0x0600037F RID: 895 RVA: 0x00018FF4 File Offset: 0x000171F4
		internal void DeleteFile()
		{
			try
			{
				File.Delete(this.ImagePath);
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't delete bootpromo file: " + this.ImagePath);
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x040001EA RID: 490
		private int mOrder;

		// Token: 0x040001EB RID: 491
		private SerializableDictionary<string, string> mExtraPayload = new SerializableDictionary<string, string>();

		// Token: 0x040001EC RID: 492
		private string mId;

		// Token: 0x040001ED RID: 493
		private string mButtonText = string.Empty;

		// Token: 0x040001EE RID: 494
		private string sImagePath = string.Empty;

		// Token: 0x040001EF RID: 495
		private string mThemeEnabled = string.Empty;

		// Token: 0x040001F0 RID: 496
		private string mThemeName = string.Empty;

		// Token: 0x040001F1 RID: 497
		private string mPromoBtnClickStatusText = string.Empty;
	}
}
