﻿using System;
using System.ComponentModel;
using System.Globalization;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000149 RID: 329
	public class PennerDoubleAnimationTypeConverter : TypeConverter
	{
		// Token: 0x06000CF4 RID: 3316 RVA: 0x0000A0E5 File Offset: 0x000082E5
		public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
		{
			return sourceType == typeof(string);
		}

		// Token: 0x06000CF5 RID: 3317 RVA: 0x0000A0F4 File Offset: 0x000082F4
		public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
		{
			return destinationType == typeof(Enum);
		}

		// Token: 0x06000CF6 RID: 3318 RVA: 0x00055BE0 File Offset: 0x00053DE0
		public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
		{
			foreach (object obj in Enum.GetValues(typeof(PennerDoubleAnimation.Equations)))
			{
				int num = (int)obj;
				if (Enum.GetName(typeof(PennerDoubleAnimation.Equations), num) == value.ToString())
				{
					return (PennerDoubleAnimation.Equations)num;
				}
			}
			return null;
		}

		// Token: 0x06000CF7 RID: 3319 RVA: 0x00055C6C File Offset: 0x00053E6C
		public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
		{
			if (value != null)
			{
				return ((PennerDoubleAnimation.Equations)value).ToString();
			}
			return null;
		}
	}
}
