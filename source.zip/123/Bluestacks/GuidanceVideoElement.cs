﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000E4 RID: 228
	public class GuidanceVideoElement : UserControl, IComponentConnector
	{
		// Token: 0x060009C8 RID: 2504 RVA: 0x0000813E File Offset: 0x0000633E
		public GuidanceVideoElement(MainWindow window)
		{
			this.ParentWindow = window;
			this.InitializeComponent();
		}

		// Token: 0x060009C9 RID: 2505 RVA: 0x000455A4 File Offset: 0x000437A4
		private void CustomPictureBox_MouseUp(object sender, MouseButtonEventArgs e)
		{
			GuidenceVideoWindow guidenceVideoWindow = new GuidenceVideoWindow();
			guidenceVideoWindow.Owner = Window.GetWindow(this);
			guidenceVideoWindow.Init(this.ParentWindow);
			guidenceVideoWindow.Width = this.ParentWindow.ActualWidth;
			guidenceVideoWindow.Height = this.ParentWindow.ActualHeight;
			if (guidenceVideoWindow.Width < 700.0)
			{
				guidenceVideoWindow.Width = 700.0;
			}
			guidenceVideoWindow.ShowDialog();
		}

		// Token: 0x060009CA RID: 2506 RVA: 0x00045618 File Offset: 0x00043818
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/guidancevideoelement.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060009CB RID: 2507 RVA: 0x00045648 File Offset: 0x00043848
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((CustomPictureBox)target).MouseUp += this.CustomPictureBox_MouseUp;
				return;
			case 2:
				this.otherGrid = (Grid)target;
				return;
			case 3:
				this.mHeaderTextBlock = (TextBlock)target;
				return;
			case 4:
				this.mBodyTextBlock = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000712 RID: 1810
		private MainWindow ParentWindow;

		// Token: 0x04000713 RID: 1811
		internal Grid otherGrid;

		// Token: 0x04000714 RID: 1812
		internal TextBlock mHeaderTextBlock;

		// Token: 0x04000715 RID: 1813
		internal TextBlock mBodyTextBlock;

		// Token: 0x04000716 RID: 1814
		private bool _contentLoaded;
	}
}
