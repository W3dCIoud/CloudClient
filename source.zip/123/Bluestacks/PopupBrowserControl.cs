﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000C2 RID: 194
	public class PopupBrowserControl : UserControl, IDimOverlayControl, IComponentConnector
	{
		// Token: 0x060007CB RID: 1995 RVA: 0x00007068 File Offset: 0x00005268
		bool IDimOverlayControl.Close()
		{
			base.Visibility = Visibility.Hidden;
			this.ClosePopupBrowser();
			return true;
		}

		// Token: 0x17000163 RID: 355
		// (get) Token: 0x060007CC RID: 1996 RVA: 0x00004D85 File Offset: 0x00002F85
		// (set) Token: 0x060007CD RID: 1997 RVA: 0x00004BF2 File Offset: 0x00002DF2
		bool IDimOverlayControl.IsCloseOnOverLayClick
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		// Token: 0x060007CE RID: 1998 RVA: 0x00004DA3 File Offset: 0x00002FA3
		bool IDimOverlayControl.Show()
		{
			base.Visibility = Visibility.Visible;
			return true;
		}

		// Token: 0x17000164 RID: 356
		// (get) Token: 0x060007CF RID: 1999 RVA: 0x00007078 File Offset: 0x00005278
		// (set) Token: 0x060007D0 RID: 2000 RVA: 0x00007080 File Offset: 0x00005280
		public bool ShowControlInSeparateWindow
		{
			get
			{
				return this.mShowControlInSeparateWindow;
			}
			set
			{
				this.mShowControlInSeparateWindow = value;
			}
		}

		// Token: 0x060007D1 RID: 2001 RVA: 0x00007089 File Offset: 0x00005289
		public PopupBrowserControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x060007D2 RID: 2002 RVA: 0x00031884 File Offset: 0x0002FA84
		public void Init(string url, string title, MainWindow window)
		{
			this.mTitle.Text = title;
			this.mBrowser.mUrl = url;
			this.mBrowser.mGrid = new Grid();
			this.mBrowser.Content = this.mBrowser.mGrid;
			this.mBrowser.CreateNewBrowser();
			window.SizeChanged += this.Window_SizeChanged;
			this.ParentWindow = window;
			this.mBrowser.ParentWindow = window;
			this.FixUpUILayout();
		}

		// Token: 0x060007D3 RID: 2003 RVA: 0x0000709E File Offset: 0x0000529E
		private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			this.FixUpUILayout();
		}

		// Token: 0x060007D4 RID: 2004 RVA: 0x00031908 File Offset: 0x0002FB08
		private void FixUpUILayout()
		{
			if (this.ParentWindow.mIsFullScreen || this.ParentWindow.WindowState == WindowState.Maximized)
			{
				base.Width = 880.0;
				base.Height = 530.0;
				return;
			}
			base.Width = 780.0;
			base.Height = 480.0;
		}

		// Token: 0x060007D5 RID: 2005 RVA: 0x00031970 File Offset: 0x0002FB70
		public void ClosePopupBrowser()
		{
			ClientStats.SendPopupBrowserStatsInMiscASync("closed", this.mBrowser.mUrl);
			if (this.ParentWindow != null)
			{
				this.ParentWindow.HideDimOverlay();
			}
			if (this.mBrowser.mBrowser != null)
			{
				this.mBrowser.DisposeBrowser();
			}
			base.Visibility = Visibility.Hidden;
		}

		// Token: 0x060007D6 RID: 2006 RVA: 0x000070A6 File Offset: 0x000052A6
		private void CloseBtn_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ClosePopupBrowser();
		}

		// Token: 0x060007D7 RID: 2007 RVA: 0x000319C4 File Offset: 0x0002FBC4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/popupbrowsercontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060007D8 RID: 2008 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060007D9 RID: 2009 RVA: 0x000319F4 File Offset: 0x0002FBF4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mGridBorder = (Border)target;
				return;
			case 2:
				this.mOuterGrid = (Grid)target;
				return;
			case 3:
				this.mTitle = (TextBlock)target;
				return;
			case 4:
				this.CloseBtn = (CustomPictureBox)target;
				this.CloseBtn.PreviewMouseLeftButtonUp += this.CloseBtn_PreviewMouseLeftButtonUp;
				return;
			case 5:
				this.mGrid = (Grid)target;
				return;
			case 6:
				this.mBrowser = (BrowserControl)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400059C RID: 1436
		private MainWindow ParentWindow;

		// Token: 0x0400059D RID: 1437
		private bool mShowControlInSeparateWindow = true;

		// Token: 0x0400059E RID: 1438
		internal Border mGridBorder;

		// Token: 0x0400059F RID: 1439
		internal Grid mOuterGrid;

		// Token: 0x040005A0 RID: 1440
		internal TextBlock mTitle;

		// Token: 0x040005A1 RID: 1441
		internal CustomPictureBox CloseBtn;

		// Token: 0x040005A2 RID: 1442
		internal Grid mGrid;

		// Token: 0x040005A3 RID: 1443
		internal BrowserControl mBrowser;

		// Token: 0x040005A4 RID: 1444
		private bool _contentLoaded;
	}
}
