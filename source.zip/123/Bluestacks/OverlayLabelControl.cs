﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000EA RID: 234
	public class OverlayLabelControl : UserControl, IComponentConnector
	{
		// Token: 0x060009EF RID: 2543 RVA: 0x000082B0 File Offset: 0x000064B0
		public OverlayLabelControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x060009F0 RID: 2544 RVA: 0x00046744 File Offset: 0x00044944
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/overlaylabelcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060009F1 RID: 2545 RVA: 0x00046774 File Offset: 0x00044974
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mBorder = (Border)target;
				return;
			case 2:
				this.clipMask = (Border)target;
				return;
			case 3:
				this.mGrid = (Grid)target;
				return;
			case 4:
				this.lbl = (Label)target;
				return;
			case 5:
				this.img = (CustomPictureBox)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000735 RID: 1845
		internal Border mBorder;

		// Token: 0x04000736 RID: 1846
		internal Border clipMask;

		// Token: 0x04000737 RID: 1847
		internal Grid mGrid;

		// Token: 0x04000738 RID: 1848
		internal Label lbl;

		// Token: 0x04000739 RID: 1849
		internal CustomPictureBox img;

		// Token: 0x0400073A RID: 1850
		private bool _contentLoaded;
	}
}
