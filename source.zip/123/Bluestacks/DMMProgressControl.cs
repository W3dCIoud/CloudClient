﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200007C RID: 124
	public class DMMProgressControl : System.Windows.Controls.UserControl, IComponentConnector
	{
		// Token: 0x060005A3 RID: 1443 RVA: 0x0002456C File Offset: 0x0002276C
		public DMMProgressControl()
		{
			this.InitializeComponent();
			if (!DesignerProperties.GetIsInDesignMode(this))
			{
				if (RegistryManager.Instance.NoOfBootCompleted > 0)
				{
					BlueStacksUIBinding.Bind(this.BootText, "STRING_BOOT_TIME", "");
				}
				else
				{
					BlueStacksUIBinding.Bind(this.BootText, "STRING_FIRST_BOOT", "");
				}
				if (RegistryManager.Instance.LastBootTime / 400 <= 0)
				{
					RegistryManager.Instance.LastBootTime = 120000;
					RegistryManager.Instance.NoOfBootCompleted = 0;
				}
			}
		}

		// Token: 0x060005A4 RID: 1444 RVA: 0x00024610 File Offset: 0x00022810
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/dmmprogresscontrol.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060005A5 RID: 1445 RVA: 0x00005AFD File Offset: 0x00003CFD
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.BootText = (TextBlock)target;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x0400037B RID: 891
		private double mProgress = 0.1;

		// Token: 0x0400037C RID: 892
		private bool mForceComplete;

		// Token: 0x0400037D RID: 893
		private Timer progressTimer = new Timer();

		// Token: 0x0400037E RID: 894
		internal TextBlock BootText;

		// Token: 0x0400037F RID: 895
		private bool _contentLoaded;
	}
}
