﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Markup;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200023D RID: 573
	public class GiftTabUserControl : BrowserControl, IComponentConnector
	{
		// Token: 0x060013DD RID: 5085 RVA: 0x0007AC38 File Offset: 0x00078E38
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/gifttabusercontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060013DE RID: 5086 RVA: 0x0000E0E1 File Offset: 0x0000C2E1
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			this._contentLoaded = true;
		}

		// Token: 0x04000DDA RID: 3546
		private bool _contentLoaded;
	}
}
