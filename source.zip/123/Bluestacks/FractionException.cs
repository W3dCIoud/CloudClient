﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000145 RID: 325
	public class FractionException : Exception
	{
		// Token: 0x06000CB9 RID: 3257 RVA: 0x00009D87 File Offset: 0x00007F87
		public FractionException()
		{
		}

		// Token: 0x06000CBA RID: 3258 RVA: 0x00009D8F File Offset: 0x00007F8F
		public FractionException(string Message) : base(Message)
		{
		}

		// Token: 0x06000CBB RID: 3259 RVA: 0x00009D98 File Offset: 0x00007F98
		public FractionException(string Message, Exception InnerException) : base(Message, InnerException)
		{
		}
	}
}
