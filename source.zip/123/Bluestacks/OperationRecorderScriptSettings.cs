﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000095 RID: 149
	public class OperationRecorderScriptSettings : UserControl, IComponentConnector
	{
		// Token: 0x06000671 RID: 1649 RVA: 0x000289E8 File Offset: 0x00026BE8
		internal OperationRecorderScriptSettings(MainWindow parentWindow, OperationsRecord record)
		{
			this.InitializeComponent();
			this.ParentWindow = parentWindow;
			this.mOperationRecord = record;
			this.mScriptName.Text = this.mOperationRecord.Name;
			DateTime dateTime = DateTime.ParseExact(this.mOperationRecord.TimeCreated, "yyyyMMddTHHmmss", CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal);
			this.mDateOfRecording.Text = dateTime.ToString("yyyyMMdd");
			this.mTimeOfRecording.Text = dateTime.ToString("HH:mm:ss");
			if (this.ParentWindow.mIsMacroPlaying && this.mOperationRecord.Name.Equals(this.ParentWindow.mMacroPlaying))
			{
				this.mPlayScriptImg.ImageName = "stop_icon";
				this.mScriptSettingsImg.Visibility = Visibility.Collapsed;
				this.mDeleteScriptImg.Visibility = Visibility.Collapsed;
				this.mRunningText.Visibility = Visibility.Visible;
				return;
			}
			this.mPlayScriptImg.ImageName = "play";
			this.mScriptSettingsImg.Visibility = Visibility.Visible;
			this.mDeleteScriptImg.Visibility = Visibility.Visible;
			this.mRunningText.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000672 RID: 1650 RVA: 0x000062AD File Offset: 0x000044AD
		public void MacroSettingsButtonHandle(EventHandler handle, object data = null)
		{
			this.mMacroSettingsButtonEventHandler = handle;
			this.mMacroSettingsButtonEventdata = data;
		}

		// Token: 0x06000673 RID: 1651 RVA: 0x00028B04 File Offset: 0x00026D04
		private void mPlayScriptImg_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (File.Exists(Path.Combine(RegistryStrings.OperationsScriptFolder, this.mOperationRecord.Name)) && !this.ParentWindow.mIsMacroPlaying)
			{
				this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("startMacroPlayback", new Dictionary<string, string>
				{
					{
						"scriptFilePath",
						Path.Combine(RegistryStrings.OperationsScriptFolder, this.mOperationRecord.Name)
					}
				});
				this.ParentWindow.mIsMacroPlaying = true;
				this.ParentWindow.mCommonHandler.HideOperationRecorderWindow();
				this.ParentWindow.Focus();
				this.ParentWindow.mFrontendHandler.ShowGLWindow();
				this.ParentWindow.mTopBar.ShowMacroPlaybackOnTopBar(this.mOperationRecord);
				this.ParentWindow.mMacroPlaying = this.mOperationRecord.Name;
				this.mScriptSettingsImg.Visibility = Visibility.Collapsed;
				this.mDeleteScriptImg.Visibility = Visibility.Collapsed;
				this.mRunningText.Visibility = Visibility.Visible;
				if (this.mOperationRecord.RestartPlayer)
				{
					this.ParentWindow.StartTimerForAppPlayerRestart(this.mOperationRecord.RestartPlayerAfterMinutes);
					return;
				}
			}
			else
			{
				this.mScriptSettingsImg.Visibility = Visibility.Visible;
				this.mDeleteScriptImg.Visibility = Visibility.Visible;
				this.mRunningText.Visibility = Visibility.Collapsed;
				this.ParentWindow.mIsMacroPlaying = false;
				this.ParentWindow.mTopBar.HideMacroPlaybackFromTopBar();
				this.mPlayScriptImg.ImageName = "play";
				this.ParentWindow.mMacroPlaying = string.Empty;
				if (this.ParentWindow.mMacroTimer != null && this.ParentWindow.mMacroTimer.Enabled)
				{
					this.ParentWindow.mMacroTimer.Enabled = false;
					this.ParentWindow.mMacroTimer.AutoReset = false;
					this.ParentWindow.mMacroTimer.Dispose();
				}
				this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("stopMacroPlayback", null);
			}
		}

		// Token: 0x06000674 RID: 1652 RVA: 0x000062BD File Offset: 0x000044BD
		private void mScriptSettingsImg_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mMacroSettingsButtonEventHandler != null)
			{
				this.mMacroSettingsButtonEventHandler(this.mMacroSettingsButtonEventdata, new EventArgs());
			}
			BlueStacksUIBinding.BindColor(this.mGrid, Panel.BackgroundProperty, "SettingsWindowBackground");
			this.ShowSettingsGrid();
		}

		// Token: 0x06000675 RID: 1653 RVA: 0x00028CF0 File Offset: 0x00026EF0
		public void ShowSettingsGrid()
		{
			if (this.mShowSettings)
			{
				BlueStacksUIBinding.BindColor(this.mGrid, Panel.BackgroundProperty, "SettingsWindowBackground");
				this.mScriptSettingsGrid.Visibility = Visibility.Collapsed;
				this.mShowSettings = false;
				return;
			}
			BlueStacksUIBinding.BindColor(this.mGrid, Panel.BackgroundProperty, "GameControlNavigationBackgroundColor");
			BlueStacksUIBinding.BindColor(this.mScriptGrid, Panel.BackgroundProperty, "GameControlNavigationBackgroundColor");
			this.mShowSettings = true;
			this.mScriptSettingsGrid.Visibility = Visibility.Visible;
			this.InitSettings();
			this.ConfigureSettings();
		}

		// Token: 0x06000676 RID: 1654 RVA: 0x00028D78 File Offset: 0x00026F78
		private void mDeleteScriptImg_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_BLUESTACKS", false);
			customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_DELETE_SCRIPT", false);
			customMessageWindow.AddButton(ButtonColors.Red, LocaleStrings.GetLocalizedString("STRING_YES", false), delegate(object o, EventArgs evt)
			{
				this.DeleteMacroScript();
			}, null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_NO", false), delegate(object o, EventArgs evt)
			{
			}, null, false, null);
			customMessageWindow.CloseButtonHandle(null, null);
			customMessageWindow.Owner = this.ParentWindow;
			customMessageWindow.ShowDialog();
		}

		// Token: 0x06000677 RID: 1655 RVA: 0x00028E28 File Offset: 0x00027028
		private void DeleteMacroScript()
		{
			string path = Path.Combine(RegistryStrings.OperationsScriptFolder, this.mOperationRecord.Name);
			if (File.Exists(path))
			{
				File.Delete(path);
				this.ParentWindow.mCommonHandler.RefreshOperationRecorderWindow();
				MainWindow.sMacroScriptNames.Remove(this.mOperationRecord.Name.ToLower().Trim());
			}
		}

		// Token: 0x06000678 RID: 1656 RVA: 0x00028E8C File Offset: 0x0002708C
		private void InitSettings()
		{
			this.mLoopCountCombobox.Items.Clear();
			this.mAccelerationCombobox.Items.Clear();
			ComboBoxItem comboBoxItem = new ComboBoxItem();
			comboBoxItem.Content = LocaleStrings.GetLocalizedString("STRING_TILL_LOOP_NUMBER", false);
			this.mLoopCountCombobox.Items.Add(comboBoxItem);
			ComboBoxItem comboBoxItem2 = new ComboBoxItem();
			comboBoxItem2.Content = LocaleStrings.GetLocalizedString("STRING_TILL_LOOP_TIME", false);
			this.mLoopCountCombobox.Items.Add(comboBoxItem2);
			ComboBoxItem comboBoxItem3 = new ComboBoxItem();
			comboBoxItem3.Content = LocaleStrings.GetLocalizedString("STRING_TILL_MANUAL", false);
			this.mLoopCountCombobox.Items.Add(comboBoxItem3);
			this.mLoopCountCombobox.SelectedIndex = 0;
			for (int i = 1; i < 6; i++)
			{
				ComboBoxItem comboBoxItem4 = new ComboBoxItem();
				comboBoxItem4.Content = i.ToString() + "x";
				this.mAccelerationCombobox.Items.Add(comboBoxItem4);
			}
			this.mAccelerationCombobox.SelectedIndex = 0;
		}

		// Token: 0x06000679 RID: 1657 RVA: 0x00028F8C File Offset: 0x0002718C
		private void ConfigureSettings()
		{
			this.mLoopCountCombobox.SelectedIndex = (int)this.mOperationRecord.LoopType;
			TimeSpan timeSpan = TimeSpan.FromSeconds((double)this.mOperationRecord.LoopTime);
			this.mLoopSeconds.Text = timeSpan.Seconds.ToString();
			this.mLoopMinutes.Text = timeSpan.Minutes.ToString();
			this.mLoopHours.Text = timeSpan.Hours.ToString();
			DateTime dateTime = DateTime.ParseExact(this.mOperationRecord.TimeCreated, "yyyyMMddTHHmmss", CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal);
			this.mDateOfRecording.Text = dateTime.ToString("yyyyMMdd");
			this.mTimeOfRecording.Text = dateTime.ToString("HH:mm:ss");
			this.SelectLoopTypeGrid(this.mLoopCountCombobox.SelectedIndex);
			this.mAccelerationCombobox.SelectedIndex = (int)this.mOperationRecord.Acceleration - 1;
			this.mLoopCount.Text = this.mOperationRecord.LoopNumber.ToString();
			this.mLoopInterval.Text = this.mOperationRecord.LoopInterval.ToString();
			this.mExecuteScriptOnRestart.IsChecked = new bool?(this.mOperationRecord.PlayOnStart);
			this.mExecuteScriptTime.IsChecked = new bool?(this.mOperationRecord.RestartPlayer);
			this.mRestartTime.Text = this.mOperationRecord.RestartPlayerAfterMinutes.ToString();
		}

		// Token: 0x0600067A RID: 1658 RVA: 0x00029114 File Offset: 0x00027314
		private void SelectLoopTypeGrid(int count)
		{
			switch (count)
			{
			case 0:
				this.mLoopNumberGrid.Visibility = Visibility.Visible;
				this.mLoopTimeGrid.Visibility = Visibility.Collapsed;
				this.mManualLoopGrid.Visibility = Visibility.Collapsed;
				return;
			case 1:
				this.mLoopTimeGrid.Visibility = Visibility.Visible;
				this.mManualLoopGrid.Visibility = Visibility.Collapsed;
				this.mLoopNumberGrid.Visibility = Visibility.Collapsed;
				return;
			case 2:
				this.mManualLoopGrid.Visibility = Visibility.Visible;
				this.mLoopNumberGrid.Visibility = Visibility.Collapsed;
				this.mLoopTimeGrid.Visibility = Visibility.Collapsed;
				return;
			default:
				this.mLoopNumberGrid.Visibility = Visibility.Visible;
				this.mLoopTimeGrid.Visibility = Visibility.Collapsed;
				this.mManualLoopGrid.Visibility = Visibility.Collapsed;
				return;
			}
		}

		// Token: 0x0600067B RID: 1659 RVA: 0x000062F8 File Offset: 0x000044F8
		private void mLoopCountCombobox_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			this.SelectLoopTypeGrid(this.mLoopCountCombobox.SelectedIndex);
		}

		// Token: 0x0600067C RID: 1660 RVA: 0x0000630B File Offset: 0x0000450B
		private void CancelButton_Click(object sender, RoutedEventArgs e)
		{
			BlueStacksUIBinding.BindColor(this.mGrid, Panel.BackgroundProperty, "SettingsWindowBackground");
			BlueStacksUIBinding.BindColor(this.mScriptGrid, Panel.BackgroundProperty, "SettingsWindowBackground");
			this.mScriptSettingsGrid.Visibility = Visibility.Collapsed;
			this.ConfigureSettings();
		}

		// Token: 0x0600067D RID: 1661 RVA: 0x00006349 File Offset: 0x00004549
		private void SaveButton_Click(object sender, RoutedEventArgs e)
		{
			BlueStacksUIBinding.BindColor(this.mGrid, Panel.BackgroundProperty, "SettingsWindowBackground");
			BlueStacksUIBinding.BindColor(this.mScriptGrid, Panel.BackgroundProperty, "SettingsWindowBackground");
			this.mScriptSettingsGrid.Visibility = Visibility.Collapsed;
			this.SaveScriptSettings();
		}

		// Token: 0x0600067E RID: 1662 RVA: 0x000291C8 File Offset: 0x000273C8
		private void SaveScriptSettings()
		{
			try
			{
				JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
				serializerSettings.Formatting = Formatting.Indented;
				this.mOperationRecord.Name = this.mScriptName.Text;
				this.mOperationRecord.LoopType = this.FindLoopType(this.mLoopCountCombobox.SelectedIndex);
				if ((double)this.mAccelerationCombobox.SelectedIndex < 0.0)
				{
					this.mOperationRecord.Acceleration = 1.0;
				}
				else
				{
					this.mOperationRecord.Acceleration = (double)(this.mAccelerationCombobox.SelectedIndex + 1);
				}
				this.mOperationRecord.LoopTime = Convert.ToInt32(this.mLoopHours.Text) * 3600 + Convert.ToInt32(this.mLoopMinutes.Text) * 60 + Convert.ToInt32(this.mLoopSeconds.Text);
				this.mOperationRecord.LoopNumber = Convert.ToInt32(this.mLoopCount.Text);
				this.mOperationRecord.LoopInterval = Convert.ToInt32(this.mLoopInterval.Text);
				this.mOperationRecord.PlayOnStart = Convert.ToBoolean(this.mExecuteScriptOnRestart.IsChecked);
				this.mOperationRecord.RestartPlayer = Convert.ToBoolean(this.mExecuteScriptTime.IsChecked);
				this.mOperationRecord.RestartPlayerAfterMinutes = Convert.ToInt32(this.mRestartTime.Text);
				if (this.mOperationRecord.PlayOnStart && this.ParentWindow.mAutoRunMacro != null)
				{
					this.ParentWindow.mAutoRunMacro.PlayOnStart = false;
					this.ParentWindow.mCommonHandler.SerializeJsonOperationRecord(this.ParentWindow.mAutoRunMacro, this.ParentWindow.mAutoRunMacro.Name + ".json");
					foreach (object obj in this.ParentWindow.OperationRecorderWindow.mScriptsStackPanel.Children)
					{
						OperationRecorderScriptControl operationRecorderScriptControl = (OperationRecorderScriptControl)obj;
						if (operationRecorderScriptControl.mScriptName.Text == this.mOperationRecord.Name)
						{
							operationRecorderScriptControl.mAutorunImage.Visibility = Visibility.Visible;
						}
						if (operationRecorderScriptControl.mScriptName.Text == this.ParentWindow.mAutoRunMacro.Name)
						{
							operationRecorderScriptControl.mAutorunImage.Visibility = Visibility.Hidden;
						}
					}
					this.ParentWindow.mAutoRunMacro = this.mOperationRecord;
				}
				string contents = JsonConvert.SerializeObject(this.mOperationRecord, serializerSettings);
				File.WriteAllText(Path.Combine(RegistryStrings.OperationsScriptFolder, this.mOperationRecord.Name) + ".json", contents);
				this.ParentWindow.mCommonHandler.OnMacroSettingChanged(this.mOperationRecord);
			}
			catch (Exception ex)
			{
				Logger.Error("Error in saving macro settings: " + ex.ToString());
			}
		}

		// Token: 0x0600067F RID: 1663 RVA: 0x00006387 File Offset: 0x00004587
		private OperationsLoopType FindLoopType(int index)
		{
			switch (index)
			{
			case 0:
				return OperationsLoopType.TillLoopNumber;
			case 1:
				return OperationsLoopType.TillTime;
			case 2:
				return OperationsLoopType.UntilStopped;
			default:
				return OperationsLoopType.TillLoopNumber;
			}
		}

		// Token: 0x06000680 RID: 1664 RVA: 0x000294E0 File Offset: 0x000276E0
		private void EditIcon_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mEditIcon.ImageName.Equals("edit_icon"))
			{
				this.mScriptName.BorderThickness = new Thickness(1.0);
				this.mScriptName.IsEnabled = true;
				this.mScriptName.Focus();
				this.mScriptName.CaretIndex = this.mScriptName.Text.Length;
				this.mEditIcon.ImageName = "macro_name_save";
				return;
			}
			this.mScriptName.IsEnabled = false;
			this.mScriptName.BorderThickness = new Thickness(0.0);
			this.mEditIcon.ImageName = "edit_icon";
			this.SaveScriptSettings();
		}

		// Token: 0x06000681 RID: 1665 RVA: 0x000063A4 File Offset: 0x000045A4
		private void UserControl_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(this.mGrid, Panel.BackgroundProperty, "GameControlNavigationBackgroundColor");
			BlueStacksUIBinding.BindColor(this.mScriptGrid, Panel.BackgroundProperty, "GameControlNavigationBackgroundColor");
		}

		// Token: 0x06000682 RID: 1666 RVA: 0x000063D0 File Offset: 0x000045D0
		private void UserControl_MouseLeave(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(this.mGrid, Panel.BackgroundProperty, "SettingsWindowBackground");
			BlueStacksUIBinding.BindColor(this.mScriptGrid, Panel.BackgroundProperty, "SettingsWindowBackground");
		}

		// Token: 0x06000683 RID: 1667 RVA: 0x0002959C File Offset: 0x0002779C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/operationrecorderscriptsettings.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000684 RID: 1668 RVA: 0x000295CC File Offset: 0x000277CC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((OperationRecorderScriptSettings)target).MouseEnter += this.UserControl_MouseEnter;
				((OperationRecorderScriptSettings)target).MouseLeave += this.UserControl_MouseLeave;
				return;
			case 2:
				this.mGrid = (Grid)target;
				return;
			case 3:
				this.mScriptGrid = (Grid)target;
				return;
			case 4:
				this.mScriptName = (TextBox)target;
				return;
			case 5:
				this.mEditIcon = (CustomPictureBox)target;
				this.mEditIcon.MouseLeftButtonUp += this.EditIcon_MouseLeftButtonUp;
				return;
			case 6:
				this.mDateOfRecording = (TextBlock)target;
				return;
			case 7:
				this.mTimeOfRecording = (TextBlock)target;
				return;
			case 8:
				this.mPlayScriptImg = (CustomPictureBox)target;
				this.mPlayScriptImg.PreviewMouseLeftButtonUp += this.mPlayScriptImg_PreviewMouseLeftButtonUp;
				return;
			case 9:
				this.mScriptSettingsImg = (CustomPictureBox)target;
				this.mScriptSettingsImg.PreviewMouseLeftButtonUp += this.mScriptSettingsImg_PreviewMouseLeftButtonUp;
				return;
			case 10:
				this.mDeleteScriptImg = (CustomPictureBox)target;
				this.mDeleteScriptImg.PreviewMouseLeftButtonUp += this.mDeleteScriptImg_PreviewMouseLeftButtonUp;
				return;
			case 11:
				this.mRunningText = (TextBlock)target;
				return;
			case 12:
				this.mScriptSettingsGrid = (Grid)target;
				return;
			case 13:
				this.mLoopCountCombobox = (CustomComboBox)target;
				this.mLoopCountCombobox.SelectionChanged += this.mLoopCountCombobox_SelectionChanged;
				return;
			case 14:
				this.mLoopNumberGrid = (Grid)target;
				return;
			case 15:
				this.mLoopCount = (TextBox)target;
				return;
			case 16:
				this.mLoopTimeGrid = (Grid)target;
				return;
			case 17:
				this.mLoopHours = (TextBox)target;
				return;
			case 18:
				this.mLoopMinutes = (TextBox)target;
				return;
			case 19:
				this.mLoopSeconds = (TextBox)target;
				return;
			case 20:
				this.mManualLoopGrid = (Grid)target;
				return;
			case 21:
				this.mLoopInterval = (TextBox)target;
				return;
			case 22:
				this.mAccelerationCombobox = (CustomComboBox)target;
				return;
			case 23:
				this.mExecuteScriptOnRestart = (CustomCheckbox)target;
				return;
			case 24:
				this.mExecuteScriptTime = (CustomCheckbox)target;
				return;
			case 25:
				this.mRestartTime = (TextBox)target;
				return;
			case 26:
				((CustomButton)target).Click += this.SaveButton_Click;
				return;
			case 27:
				((CustomButton)target).Click += this.CancelButton_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000436 RID: 1078
		private EventHandler mMacroSettingsButtonEventHandler;

		// Token: 0x04000437 RID: 1079
		private object mMacroSettingsButtonEventdata;

		// Token: 0x04000438 RID: 1080
		private MainWindow ParentWindow;

		// Token: 0x04000439 RID: 1081
		private OperationsRecord mOperationRecord;

		// Token: 0x0400043A RID: 1082
		internal bool mShowSettings;

		// Token: 0x0400043B RID: 1083
		internal Grid mGrid;

		// Token: 0x0400043C RID: 1084
		internal Grid mScriptGrid;

		// Token: 0x0400043D RID: 1085
		internal TextBox mScriptName;

		// Token: 0x0400043E RID: 1086
		internal CustomPictureBox mEditIcon;

		// Token: 0x0400043F RID: 1087
		internal TextBlock mDateOfRecording;

		// Token: 0x04000440 RID: 1088
		internal TextBlock mTimeOfRecording;

		// Token: 0x04000441 RID: 1089
		internal CustomPictureBox mPlayScriptImg;

		// Token: 0x04000442 RID: 1090
		internal CustomPictureBox mScriptSettingsImg;

		// Token: 0x04000443 RID: 1091
		internal CustomPictureBox mDeleteScriptImg;

		// Token: 0x04000444 RID: 1092
		internal TextBlock mRunningText;

		// Token: 0x04000445 RID: 1093
		internal Grid mScriptSettingsGrid;

		// Token: 0x04000446 RID: 1094
		internal CustomComboBox mLoopCountCombobox;

		// Token: 0x04000447 RID: 1095
		internal Grid mLoopNumberGrid;

		// Token: 0x04000448 RID: 1096
		internal TextBox mLoopCount;

		// Token: 0x04000449 RID: 1097
		internal Grid mLoopTimeGrid;

		// Token: 0x0400044A RID: 1098
		internal TextBox mLoopHours;

		// Token: 0x0400044B RID: 1099
		internal TextBox mLoopMinutes;

		// Token: 0x0400044C RID: 1100
		internal TextBox mLoopSeconds;

		// Token: 0x0400044D RID: 1101
		internal Grid mManualLoopGrid;

		// Token: 0x0400044E RID: 1102
		internal TextBox mLoopInterval;

		// Token: 0x0400044F RID: 1103
		internal CustomComboBox mAccelerationCombobox;

		// Token: 0x04000450 RID: 1104
		internal CustomCheckbox mExecuteScriptOnRestart;

		// Token: 0x04000451 RID: 1105
		internal CustomCheckbox mExecuteScriptTime;

		// Token: 0x04000452 RID: 1106
		internal TextBox mRestartTime;

		// Token: 0x04000453 RID: 1107
		private bool _contentLoaded;
	}
}
