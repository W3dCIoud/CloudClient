﻿using System;
using Xilium.CefGlue;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001A3 RID: 419
	internal sealed class RenderProcessHandler : CefRenderProcessHandler
	{
		// Token: 0x06000F3B RID: 3899 RVA: 0x00060B74 File Offset: 0x0005ED74
		protected override void OnWebKitInitialized()
		{
			string text = "var gmApi = function(jsonArg) {\r\n\r\n            native function MyNativeFunction(jsonArg);\r\n            return MyNativeFunction(jsonArg);\r\n        };\r\n        ";
			CefRuntime.RegisterExtension("MessageEvent", text, this.myCefV8Handler);
			base.OnWebKitInitialized();
		}

		// Token: 0x04000AAA RID: 2730
		private MyCustomCefV8Handler myCefV8Handler = new MyCustomCefV8Handler();
	}
}
