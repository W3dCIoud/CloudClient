﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200003F RID: 63
	public class AppRecommendationSection
	{
		// Token: 0x17000118 RID: 280
		// (get) Token: 0x06000333 RID: 819 RVA: 0x0000429B File Offset: 0x0000249B
		// (set) Token: 0x06000334 RID: 820 RVA: 0x000042A3 File Offset: 0x000024A3
		[JsonProperty(PropertyName = "section_header")]
		public string AppSuggestionHeader { get; set; }

		// Token: 0x17000119 RID: 281
		// (get) Token: 0x06000335 RID: 821 RVA: 0x000042AC File Offset: 0x000024AC
		// (set) Token: 0x06000336 RID: 822 RVA: 0x000042B4 File Offset: 0x000024B4
		[JsonProperty(PropertyName = "client_show_count", DefaultValueHandling = DefaultValueHandling.Populate)]
		[DefaultValue(3)]
		public int ClientShowCount { get; set; } = 3;

		// Token: 0x1700011A RID: 282
		// (get) Token: 0x06000337 RID: 823 RVA: 0x000042BD File Offset: 0x000024BD
		// (set) Token: 0x06000338 RID: 824 RVA: 0x000042C5 File Offset: 0x000024C5
		[JsonProperty(PropertyName = "suggested_apps")]
		public List<AppRecommendation> AppSuggestions { get; set; } = new List<AppRecommendation>();
	}
}
