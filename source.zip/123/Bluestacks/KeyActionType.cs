﻿using System;

// Token: 0x0200001E RID: 30
public enum KeyActionType
{
	// Token: 0x040000D5 RID: 213
	Alias,
	// Token: 0x040000D6 RID: 214
	Tap,
	// Token: 0x040000D7 RID: 215
	Swipe,
	// Token: 0x040000D8 RID: 216
	Dpad,
	// Token: 0x040000D9 RID: 217
	Zoom,
	// Token: 0x040000DA RID: 218
	Tilt,
	// Token: 0x040000DB RID: 219
	Pan,
	// Token: 0x040000DC RID: 220
	MOBADpad,
	// Token: 0x040000DD RID: 221
	MOBASkill,
	// Token: 0x040000DE RID: 222
	Raw,
	// Token: 0x040000DF RID: 223
	KeyInput,
	// Token: 0x040000E0 RID: 224
	SendOriginalKeys,
	// Token: 0x040000E1 RID: 225
	Script,
	// Token: 0x040000E2 RID: 226
	TapRepeat,
	// Token: 0x040000E3 RID: 227
	Rotate,
	// Token: 0x040000E4 RID: 228
	State,
	// Token: 0x040000E5 RID: 229
	FreeLook,
	// Token: 0x040000E6 RID: 230
	LookAround = 100,
	// Token: 0x040000E7 RID: 231
	PanShoot,
	// Token: 0x040000E8 RID: 232
	MOBASkillCancel
}
