﻿using System;
using System.Windows;
using System.Windows.Media.Animation;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000100 RID: 256
	public class Animator
	{
		// Token: 0x06000A44 RID: 2628 RVA: 0x00048A98 File Offset: 0x00046C98
		public static AnimationClock AnimatePenner(DependencyObject element, DependencyProperty prop, PennerDoubleAnimation.Equations type, double to, int durationMS, EventHandler callbackFunc)
		{
			return Animator.AnimatePenner(element, prop, type, null, to, durationMS, callbackFunc);
		}

		// Token: 0x06000A45 RID: 2629 RVA: 0x00048ABC File Offset: 0x00046CBC
		public static AnimationClock AnimatePenner(DependencyObject element, DependencyProperty prop, PennerDoubleAnimation.Equations type, double? from, double to, int durationMS, EventHandler callbackFunc)
		{
			double defaultValue = double.IsNaN((double)element.GetValue(prop)) ? 0.0 : ((double)element.GetValue(prop));
			PennerDoubleAnimation anim = new PennerDoubleAnimation(type, from.GetValueOrDefault(defaultValue), to);
			return Animator.Animate(element, prop, anim, durationMS, null, null, callbackFunc);
		}

		// Token: 0x06000A46 RID: 2630 RVA: 0x00048B24 File Offset: 0x00046D24
		public static AnimationClock AnimateDouble(DependencyObject element, DependencyProperty prop, double? from, double to, int durationMS, double? accel, double? decel, EventHandler callbackFunc)
		{
			double defaultValue = double.IsNaN((double)element.GetValue(prop)) ? 0.0 : ((double)element.GetValue(prop));
			return Animator.Animate(element, prop, new DoubleAnimation
			{
				From = new double?(from.GetValueOrDefault(defaultValue)),
				To = new double?(to)
			}, durationMS, accel, decel, callbackFunc);
		}

		// Token: 0x06000A47 RID: 2631 RVA: 0x0000851B File Offset: 0x0000671B
		public static void ClearAnimation(DependencyObject animatable, DependencyProperty property)
		{
			animatable.SetValue(property, animatable.GetValue(property));
			((IAnimatable)animatable).ApplyAnimationClock(property, null);
		}

		// Token: 0x06000A48 RID: 2632 RVA: 0x00048B94 File Offset: 0x00046D94
		private static AnimationClock Animate(DependencyObject animatable, DependencyProperty prop, AnimationTimeline anim, int duration, double? accel, double? decel, EventHandler func)
		{
			anim.AccelerationRatio = accel.GetValueOrDefault(0.0);
			anim.DecelerationRatio = decel.GetValueOrDefault(0.0);
			anim.Duration = TimeSpan.FromMilliseconds((double)duration);
			anim.Freeze();
			AnimationClock animClock = anim.CreateClock();
			EventHandler eh = null;
			eh = delegate(object sender, EventArgs e)
			{
				Animator.ClearAnimation(animatable, prop);
				animClock.Completed -= eh;
			};
			animClock.Completed += eh;
			if (func != null)
			{
				animClock.Completed += func;
			}
			animClock.Controller.Begin();
			Animator.ClearAnimation(animatable, prop);
			((IAnimatable)animatable).ApplyAnimationClock(prop, animClock);
			return animClock;
		}
	}
}
