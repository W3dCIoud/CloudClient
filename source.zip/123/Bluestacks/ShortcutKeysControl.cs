﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200006A RID: 106
	public class ShortcutKeysControl : UserControl, IComponentConnector
	{
		// Token: 0x0600049A RID: 1178 RVA: 0x0001EC94 File Offset: 0x0001CE94
		public ShortcutKeysControl(MainWindow window, SettingsWindow settingsWindow)
		{
			this.InitializeComponent();
			base.Visibility = Visibility.Hidden;
			this.ParentWindow = window;
			this.ParentSettingsWindow = settingsWindow;
			this.mShortcutKeyPanel = (this.mShortcutKeyScrollBar.Content as StackPanel);
			if (this.ParentWindow.mCommonHandler.mShortcutsConfigInstance != null)
			{
				this.AddShortcutKeyElements();
			}
			this.ParentWindow.mCommonHandler.ShortcutKeysChangedEvent += this.ShortcutKeysChangedEvent;
			this.mShortcutKeyScrollBar.ScrollChanged += BluestacksUIColor.ScrollBarScrollChanged;
		}

		// Token: 0x0600049B RID: 1179 RVA: 0x0000512C File Offset: 0x0000332C
		private void ShortcutKeysChangedEvent(bool isEnabled)
		{
			this.mSaveBtn.IsEnabled = isEnabled;
		}

		// Token: 0x0600049C RID: 1180 RVA: 0x0001ED30 File Offset: 0x0001CF30
		private void AddShortcutKeyElements()
		{
			try
			{
				new List<ShortcutKeys>();
				this.mShortcutKeyPanel.Children.Clear();
				this.mShortcutUIElements.Clear();
				foreach (ShortcutKeys shortcutKeys in this.ParentWindow.mCommonHandler.mShortcutsConfigInstance.Shortcut)
				{
					this.CreateShortcutCategory(shortcutKeys.ShortcutCategory);
					this.AddElement(shortcutKeys);
				}
				foreach (KeyValuePair<string, Tuple<GroupBox, List<FrameworkElement>>> keyValuePair in this.mShortcutUIElements)
				{
					this.mShortcutKeyPanel.Children.Add(keyValuePair.Value.Item1);
					foreach (FrameworkElement element in keyValuePair.Value.Item2)
					{
						(keyValuePair.Value.Item1.Content as StackPanel).Children.Add(element);
					}
				}
				this.mShortcutUIElements.First<KeyValuePair<string, Tuple<GroupBox, List<FrameworkElement>>>>().Value.Item1.Margin = new Thickness(0.0);
			}
			catch (Exception ex)
			{
				Logger.Error("Error in adding shortcut elements: " + ex.ToString());
			}
		}

		// Token: 0x0600049D RID: 1181 RVA: 0x0001EF04 File Offset: 0x0001D104
		private void AddElement(ShortcutKeys ele)
		{
			ShortcutKeyControlElement shortcutKeyControlElement = new ShortcutKeyControlElement(this.ParentWindow, this.ParentSettingsWindow);
			BlueStacksUIBinding.Bind(shortcutKeyControlElement.mShortcutNameTextBlock, ele.ShortcutName, "");
			string[] array = ele.ShortcutKey.Split(new char[]
			{
				'+',
				' '
			}, StringSplitOptions.RemoveEmptyEntries);
			string text = string.Empty;
			foreach (string key in array)
			{
				text = text + LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(key), false) + " + ";
			}
			this.mShortcutUIElements[ele.ShortcutCategory].Item2.Add(shortcutKeyControlElement);
			if (!string.IsNullOrEmpty(text))
			{
				shortcutKeyControlElement.mShortcutKeyTextBox.Text = text.Substring(0, text.Length - 3);
			}
			shortcutKeyControlElement.mUserDefinedConfigList = new List<ShortcutKeys>
			{
				ele
			};
			if (ele.ReadOnlyTextbox)
			{
				shortcutKeyControlElement.mShortcutKeyTextBox.IsEnabled = false;
			}
		}

		// Token: 0x0600049E RID: 1182 RVA: 0x0001EFF8 File Offset: 0x0001D1F8
		private void CreateShortcutCategory(string categoryName)
		{
			if (!this.mShortcutUIElements.ContainsKey(categoryName))
			{
				string localizedString = LocaleStrings.GetLocalizedString(categoryName, false);
				GroupBox groupBox = new GroupBox();
				groupBox.Content = new StackPanel();
				groupBox.Header = localizedString;
				groupBox.Tag = categoryName;
				groupBox.Margin = new Thickness(0.0, 20.0, 0.0, 0.0);
				groupBox.FontSize = 16.0;
				BlueStacksUIBinding.BindColor(groupBox, Control.ForegroundProperty, "SettingsWindowTabMenuItemLegendForeground");
				groupBox.BorderThickness = new Thickness(0.0);
				BlueStacksUIBinding.BindColor(new TextBlock
				{
					Text = localizedString,
					Tag = categoryName,
					FontStretch = FontStretches.ExtraExpanded,
					HorizontalAlignment = HorizontalAlignment.Center,
					Margin = new Thickness(0.0, 0.0, 0.0, 10.0),
					TextWrapping = TextWrapping.WrapWithOverflow
				}, TextBlock.ForegroundProperty, "SettingsWindowTabMenuItemLegendForeground");
				this.mShortcutUIElements.Add(categoryName, new Tuple<GroupBox, List<FrameworkElement>>(groupBox, new List<FrameworkElement>()));
			}
		}

		// Token: 0x0600049F RID: 1183 RVA: 0x0001F120 File Offset: 0x0001D320
		private void SaveBtnClick(object sender, RoutedEventArgs e)
		{
			this.ParentWindow.mCommonHandler.SaveAndReloadShortcuts();
			this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_SAVE_CHANGES", false));
			this.ParentSettingsWindow.mIsShortcutEdited = false;
			this.mSaveBtn.IsEnabled = false;
			if (this.ParentWindow.mCommonHandler.mShortcutsConfigInstance.Shortcut != null)
			{
				this.RefreshShortcutConfigForUI();
			}
		}

		// Token: 0x060004A0 RID: 1184 RVA: 0x0001F184 File Offset: 0x0001D384
		private void RefreshShortcutConfigForUI()
		{
			foreach (ShortcutKeys shortcutKeys in this.ParentWindow.mCommonHandler.mShortcutsConfigInstance.Shortcut)
			{
				foreach (FrameworkElement frameworkElement in this.mShortcutUIElements[shortcutKeys.ShortcutCategory].Item2)
				{
					ShortcutKeyControlElement shortcutKeyControlElement = frameworkElement as ShortcutKeyControlElement;
					if (shortcutKeyControlElement.mShortcutNameTextBlock.Text.Equals(LocaleStrings.GetLocalizedString(shortcutKeys.ShortcutName, false)))
					{
						shortcutKeyControlElement.mUserDefinedConfigList = new List<ShortcutKeys>
						{
							shortcutKeys
						};
					}
				}
			}
		}

		// Token: 0x060004A1 RID: 1185 RVA: 0x0001F264 File Offset: 0x0001D464
		private void RevertBtnClick(object sender, RoutedEventArgs e)
		{
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_BLUESTACKS", false);
			customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_RESTORE_SHORTCUTS", false);
			customMessageWindow.AddButton(ButtonColors.Red, LocaleStrings.GetLocalizedString("STRING_YES", false), delegate(object o, EventArgs evt)
			{
				this.RestoreDefaultShortcuts();
			}, null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_NO", false), delegate(object o, EventArgs evt)
			{
			}, null, false, null);
			customMessageWindow.CloseButtonHandle(null, null);
			customMessageWindow.Owner = this.ParentWindow;
			customMessageWindow.ShowDialog();
		}

		// Token: 0x060004A2 RID: 1186 RVA: 0x0001F314 File Offset: 0x0001D514
		private void RestoreDefaultShortcuts()
		{
			RegistryManager.Instance.UserDefinedShortcuts = string.Empty;
			this.ParentSettingsWindow.mIsShortcutEdited = false;
			this.ParentWindow.mCommonHandler.ReloadShortcutsForAllInstances();
			if (this.ParentWindow.mCommonHandler.mShortcutsConfigInstance != null)
			{
				this.AddShortcutKeyElements();
			}
			this.mSaveBtn.IsEnabled = false;
			Stats.SendMiscellaneousStatsAsync("KeyboardShortcuts", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "shortcut_restore_default", null, null, null, null, null, "Android", 0);
		}

		// Token: 0x060004A3 RID: 1187 RVA: 0x0001F3A0 File Offset: 0x0001D5A0
		private void AddToastPopup(string message)
		{
			try
			{
				if (this.mToastPopup == null)
				{
					this.mToastPopup = new CustomToastPopupControl(this);
				}
				this.mToastPopup.Init(this.ParentWindow, message, null, null, HorizontalAlignment.Center, VerticalAlignment.Bottom, null, 12, null, null, false);
				this.mToastPopup.ShowPopup(1.3);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in showing toast popup: " + ex.ToString());
			}
		}

		// Token: 0x060004A4 RID: 1188 RVA: 0x0001F42C File Offset: 0x0001D62C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/shortcutkeyscontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060004A5 RID: 1189 RVA: 0x0001F45C File Offset: 0x0001D65C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mShortcutKeyScrollBar = (ScrollViewer)target;
				return;
			case 2:
				this.mRevertBtn = (CustomButton)target;
				this.mRevertBtn.Click += this.RevertBtnClick;
				return;
			case 3:
				this.mSaveBtn = (CustomButton)target;
				this.mSaveBtn.Click += this.SaveBtnClick;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040002C6 RID: 710
		private MainWindow ParentWindow;

		// Token: 0x040002C7 RID: 711
		private SettingsWindow ParentSettingsWindow;

		// Token: 0x040002C8 RID: 712
		private StackPanel mShortcutKeyPanel;

		// Token: 0x040002C9 RID: 713
		private CustomToastPopupControl mToastPopup;

		// Token: 0x040002CA RID: 714
		private Dictionary<string, Tuple<GroupBox, List<FrameworkElement>>> mShortcutUIElements = new Dictionary<string, Tuple<GroupBox, List<FrameworkElement>>>();

		// Token: 0x040002CB RID: 715
		internal ScrollViewer mShortcutKeyScrollBar;

		// Token: 0x040002CC RID: 716
		internal CustomButton mRevertBtn;

		// Token: 0x040002CD RID: 717
		internal CustomButton mSaveBtn;

		// Token: 0x040002CE RID: 718
		private bool _contentLoaded;
	}
}
