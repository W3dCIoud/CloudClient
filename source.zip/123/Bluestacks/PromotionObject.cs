﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000121 RID: 289
	public class PromotionObject
	{
		// Token: 0x14000008 RID: 8
		// (add) Token: 0x06000B16 RID: 2838 RVA: 0x0004F784 File Offset: 0x0004D984
		// (remove) Token: 0x06000B17 RID: 2839 RVA: 0x0004F7B8 File Offset: 0x0004D9B8
		private static event EventHandler mBootPromotionHandler;

		// Token: 0x1700017F RID: 383
		// (get) Token: 0x06000B18 RID: 2840 RVA: 0x00008C0A File Offset: 0x00006E0A
		// (set) Token: 0x06000B19 RID: 2841 RVA: 0x00008C11 File Offset: 0x00006E11
		internal static EventHandler BootPromotionHandler
		{
			get
			{
				return PromotionObject.mBootPromotionHandler;
			}
			set
			{
				PromotionObject.mBootPromotionHandler = value;
			}
		}

		// Token: 0x06000B1A RID: 2842 RVA: 0x0004F7EC File Offset: 0x0004D9EC
		internal void SetDefaultMoreAppsOrder(bool overwrite = true)
		{
			if (this.MoreAppsDockOrder.Count == 0 || overwrite)
			{
				this.MoreAppsDockOrder = new SerializableDictionary<string, int>
				{
					{
						"com.android.chrome",
						2
					},
					{
						"com.android.camera2",
						2
					},
					{
						"com.bluestacks.settings",
						3
					},
					{
						"com.bluestacks.filemanager",
						4
					},
					{
						"instance_manager",
						5
					},
					{
						"help_center",
						6
					}
				};
			}
		}

		// Token: 0x06000B1B RID: 2843 RVA: 0x00008C19 File Offset: 0x00006E19
		internal void SetDefaultDockOrder(bool overwrite = true)
		{
			if (this.DockOrder.Count == 0 || overwrite)
			{
				this.DockOrder = new SerializableDictionary<string, int>
				{
					{
						"appcenter",
						1
					},
					{
						"pikaworld",
						2
					}
				};
			}
		}

		// Token: 0x06000B1C RID: 2844 RVA: 0x00008C50 File Offset: 0x00006E50
		internal void SetDefaultMyAppsOrder(bool overwrite = true)
		{
			if (this.mMyAppsOrder.Count == 0 || overwrite)
			{
				this.MyAppsOrder = new SerializableDictionary<string, int>
				{
					{
						"com.android.vending",
						1
					}
				};
			}
		}

		// Token: 0x06000B1D RID: 2845 RVA: 0x00008C7B File Offset: 0x00006E7B
		internal void SetDefaultOrder(bool overwrite = true)
		{
			this.SetDefaultMyAppsOrder(overwrite);
			this.SetDefaultDockOrder(overwrite);
			this.SetDefaultMoreAppsOrder(overwrite);
		}

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x06000B1E RID: 2846 RVA: 0x0004F860 File Offset: 0x0004DA60
		// (remove) Token: 0x06000B1F RID: 2847 RVA: 0x0004F894 File Offset: 0x0004DA94
		private static event EventHandler mBackgroundPromotionHandler;

		// Token: 0x17000180 RID: 384
		// (get) Token: 0x06000B20 RID: 2848 RVA: 0x00008C92 File Offset: 0x00006E92
		// (set) Token: 0x06000B21 RID: 2849 RVA: 0x00008C99 File Offset: 0x00006E99
		internal static EventHandler BackgroundPromotionHandler
		{
			get
			{
				return PromotionObject.mBackgroundPromotionHandler;
			}
			set
			{
				PromotionObject.mBackgroundPromotionHandler = value;
				if (!PromotionObject.mIsPromotionLoading)
				{
					PromotionObject.mBackgroundPromotionHandler(PromotionObject.Instance, new EventArgs());
				}
			}
		}

		// Token: 0x1400000A RID: 10
		// (add) Token: 0x06000B22 RID: 2850 RVA: 0x0004F8C8 File Offset: 0x0004DAC8
		// (remove) Token: 0x06000B23 RID: 2851 RVA: 0x0004F8FC File Offset: 0x0004DAFC
		private static event EventHandler mPromotionHandler;

		// Token: 0x17000181 RID: 385
		// (get) Token: 0x06000B24 RID: 2852 RVA: 0x00008CBE File Offset: 0x00006EBE
		// (set) Token: 0x06000B25 RID: 2853 RVA: 0x00008CC5 File Offset: 0x00006EC5
		internal static EventHandler PromotionHandler
		{
			get
			{
				return PromotionObject.mPromotionHandler;
			}
			set
			{
				PromotionObject.mPromotionHandler = value;
				if (!PromotionObject.mIsPromotionLoading)
				{
					PromotionObject.mPromotionHandler(PromotionObject.Instance, new EventArgs());
				}
			}
		}

		// Token: 0x1400000B RID: 11
		// (add) Token: 0x06000B26 RID: 2854 RVA: 0x0004F930 File Offset: 0x0004DB30
		// (remove) Token: 0x06000B27 RID: 2855 RVA: 0x0004F964 File Offset: 0x0004DB64
		private static event EventHandler mAppSpecificRulesHandler;

		// Token: 0x17000182 RID: 386
		// (get) Token: 0x06000B28 RID: 2856 RVA: 0x00008CEA File Offset: 0x00006EEA
		// (set) Token: 0x06000B29 RID: 2857 RVA: 0x00008CF1 File Offset: 0x00006EF1
		internal static EventHandler AppSpecificRulesHandler
		{
			get
			{
				return PromotionObject.mAppSpecificRulesHandler;
			}
			set
			{
				PromotionObject.mAppSpecificRulesHandler = value;
				if (!PromotionObject.mIsPromotionLoading)
				{
					PromotionObject.mAppSpecificRulesHandler(PromotionObject.Instance, new EventArgs());
				}
			}
		}

		// Token: 0x1400000C RID: 12
		// (add) Token: 0x06000B2A RID: 2858 RVA: 0x0004F998 File Offset: 0x0004DB98
		// (remove) Token: 0x06000B2B RID: 2859 RVA: 0x0004F9CC File Offset: 0x0004DBCC
		private static event Action<bool> mAppSuggestionHandler;

		// Token: 0x17000183 RID: 387
		// (get) Token: 0x06000B2C RID: 2860 RVA: 0x00008D16 File Offset: 0x00006F16
		// (set) Token: 0x06000B2D RID: 2861 RVA: 0x00008D1D File Offset: 0x00006F1D
		internal static Action<bool> AppSuggestionHandler
		{
			get
			{
				return PromotionObject.mAppSuggestionHandler;
			}
			set
			{
				PromotionObject.mAppSuggestionHandler = value;
			}
		}

		// Token: 0x1400000D RID: 13
		// (add) Token: 0x06000B2E RID: 2862 RVA: 0x0004FA00 File Offset: 0x0004DC00
		// (remove) Token: 0x06000B2F RID: 2863 RVA: 0x0004FA34 File Offset: 0x0004DC34
		private static event Action<bool> mAppRecommendationHandler;

		// Token: 0x17000184 RID: 388
		// (get) Token: 0x06000B30 RID: 2864 RVA: 0x00008D25 File Offset: 0x00006F25
		// (set) Token: 0x06000B31 RID: 2865 RVA: 0x00008D2C File Offset: 0x00006F2C
		internal static Action<bool> AppRecommendationHandler
		{
			get
			{
				return PromotionObject.mAppRecommendationHandler;
			}
			set
			{
				PromotionObject.mAppRecommendationHandler = value;
			}
		}

		// Token: 0x1400000E RID: 14
		// (add) Token: 0x06000B32 RID: 2866 RVA: 0x0004FA68 File Offset: 0x0004DC68
		// (remove) Token: 0x06000B33 RID: 2867 RVA: 0x0004FA9C File Offset: 0x0004DC9C
		private static event Action mQuestHandler;

		// Token: 0x17000185 RID: 389
		// (get) Token: 0x06000B34 RID: 2868 RVA: 0x00008D34 File Offset: 0x00006F34
		// (set) Token: 0x06000B35 RID: 2869 RVA: 0x00008D3B File Offset: 0x00006F3B
		internal static Action QuestHandler
		{
			get
			{
				return PromotionObject.mQuestHandler;
			}
			set
			{
				PromotionObject.mQuestHandler = value;
			}
		}

		// Token: 0x17000186 RID: 390
		// (get) Token: 0x06000B36 RID: 2870 RVA: 0x00008D43 File Offset: 0x00006F43
		private static string FilePath
		{
			get
			{
				return Path.Combine(RegistryStrings.PromotionDirectory, "bst_promotion");
			}
		}

		// Token: 0x06000B37 RID: 2871 RVA: 0x0004FAD0 File Offset: 0x0004DCD0
		internal static void LoadDataFromFile()
		{
			try
			{
				if (File.Exists(PromotionObject.FilePath))
				{
					if (PromotionObject.Instance != null)
					{
						PromotionObject.Instance.Save();
					}
					using (FileStream fileStream = File.OpenRead(PromotionObject.FilePath))
					{
						Logger.Info("vikramTest: Loading PromotionObject Settings from " + PromotionObject.FilePath);
						PromotionObject.Instance = (PromotionObject)new XmlSerializer(typeof(PromotionObject)).Deserialize(fileStream);
						Logger.Info("vikramTest: Done loading promotionObject.");
						PromotionObject.Instance.QuestHdPlayerRules = new SerializableDictionary<string, long>();
						PromotionObject.Instance.QuestRules = new List<QuestRule>();
						PromotionObject.Instance.ResetQuestRules = new SerializableDictionary<string, long[]>();
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error Loading PromotionObject Settings " + ex.ToString());
			}
			finally
			{
				if (PromotionObject.Instance == null)
				{
					PromotionObject.Instance = new PromotionObject();
				}
				if (PromotionObject.Instance.DockOrder.Count == 0)
				{
					PromotionObject.Instance.SetDefaultDockOrder(true);
				}
				PromotionObject.CacheOldBootPromotions();
			}
		}

		// Token: 0x06000B38 RID: 2872 RVA: 0x00008D54 File Offset: 0x00006F54
		private static void CacheOldBootPromotions()
		{
			if (PromotionObject.Instance.DictBootPromotions == null)
			{
				PromotionObject.Instance.DictBootPromotions = new SerializableDictionary<string, BootPromotion>();
			}
			PromotionObject.Instance.DictOldBootPromotions = PromotionObject.Instance.DictBootPromotions;
		}

		// Token: 0x06000B39 RID: 2873 RVA: 0x0004FBF4 File Offset: 0x0004DDF4
		internal void Save()
		{
			try
			{
				if (!Directory.Exists(Directory.GetParent(PromotionObject.FilePath).FullName))
				{
					Directory.CreateDirectory(Directory.GetParent(PromotionObject.FilePath).FullName);
				}
				using (XmlTextWriter xmlTextWriter = new XmlTextWriter(PromotionObject.FilePath, Encoding.UTF8))
				{
					xmlTextWriter.Formatting = Formatting.Indented;
					new XmlSerializer(typeof(PromotionObject)).Serialize(xmlTextWriter, PromotionObject.Instance);
					xmlTextWriter.Flush();
				}
			}
			catch (Exception ex)
			{
				Logger.Info(ex.ToString());
			}
		}

		// Token: 0x06000B3A RID: 2874 RVA: 0x0004FC9C File Offset: 0x0004DE9C
		internal void PromotionLoaded()
		{
			PromotionObject.mIsPromotionLoading = false;
			if (PromotionObject.mBootPromotionHandler != null)
			{
				PromotionObject.mBootPromotionHandler(this, new EventArgs());
			}
			if (PromotionObject.mBackgroundPromotionHandler != null)
			{
				PromotionObject.mBackgroundPromotionHandler(this, new EventArgs());
			}
			if (PromotionObject.mQuestHandler != null)
			{
				PromotionObject.mQuestHandler();
			}
			if (PromotionObject.mAppSuggestionHandler != null)
			{
				PromotionObject.mAppSuggestionHandler(true);
			}
			if (PromotionObject.mAppRecommendationHandler != null)
			{
				PromotionObject.mAppRecommendationHandler(true);
			}
			if (PromotionObject.mPromotionHandler != null)
			{
				PromotionObject.mPromotionHandler(this, new EventArgs());
			}
			PromotionObject.mAppSpecificRulesHandler(this, new EventArgs());
		}

		// Token: 0x17000187 RID: 391
		// (get) Token: 0x06000B3B RID: 2875 RVA: 0x00008D85 File Offset: 0x00006F85
		// (set) Token: 0x06000B3C RID: 2876 RVA: 0x00008D8D File Offset: 0x00006F8D
		[XmlIgnore]
		public List<string> AppSpecificRulesList
		{
			get
			{
				return this.mAppSpecificRulesList;
			}
			set
			{
				this.mAppSpecificRulesList = value;
			}
		}

		// Token: 0x17000188 RID: 392
		// (get) Token: 0x06000B3D RID: 2877 RVA: 0x00008D96 File Offset: 0x00006F96
		// (set) Token: 0x06000B3E RID: 2878 RVA: 0x00008D9E File Offset: 0x00006F9E
		public List<string> CustomCursorExcludedAppsList
		{
			get
			{
				return this.mCustomCursorExcludedAppsList;
			}
			set
			{
				this.mCustomCursorExcludedAppsList = value;
			}
		}

		// Token: 0x17000189 RID: 393
		// (get) Token: 0x06000B3F RID: 2879 RVA: 0x00008DA7 File Offset: 0x00006FA7
		// (set) Token: 0x06000B40 RID: 2880 RVA: 0x00008DAF File Offset: 0x00006FAF
		[XmlIgnore]
		public bool IsRootAccessEnabled
		{
			get
			{
				return this.mIsRootAccessEnabled;
			}
			set
			{
				this.mIsRootAccessEnabled = value;
			}
		}

		// Token: 0x1700018A RID: 394
		// (get) Token: 0x06000B41 RID: 2881 RVA: 0x00008DB8 File Offset: 0x00006FB8
		// (set) Token: 0x06000B42 RID: 2882 RVA: 0x00008DC0 File Offset: 0x00006FC0
		public string MyAppsPromotionID
		{
			get
			{
				return this.mMyAppsPromotionID;
			}
			set
			{
				this.mMyAppsPromotionID = value;
			}
		}

		// Token: 0x1700018B RID: 395
		// (get) Token: 0x06000B43 RID: 2883 RVA: 0x00008DC9 File Offset: 0x00006FC9
		// (set) Token: 0x06000B44 RID: 2884 RVA: 0x00008DD1 File Offset: 0x00006FD1
		public string MyAppsCrossPromotionID
		{
			get
			{
				return this.mMyAppsCrossPromotionID;
			}
			set
			{
				this.mMyAppsCrossPromotionID = value;
			}
		}

		// Token: 0x1700018C RID: 396
		// (get) Token: 0x06000B45 RID: 2885 RVA: 0x00008DDA File Offset: 0x00006FDA
		// (set) Token: 0x06000B46 RID: 2886 RVA: 0x00008DE2 File Offset: 0x00006FE2
		public string BackgroundPromotionID
		{
			get
			{
				return this.mBackgroundPromotionID;
			}
			set
			{
				this.mBackgroundPromotionID = value;
			}
		}

		// Token: 0x1700018D RID: 397
		// (get) Token: 0x06000B47 RID: 2887 RVA: 0x00008DEB File Offset: 0x00006FEB
		// (set) Token: 0x06000B48 RID: 2888 RVA: 0x00008DF3 File Offset: 0x00006FF3
		public string BackgroundPromotionImagePath
		{
			get
			{
				return this.mBackgroundPromotionImagePath;
			}
			set
			{
				this.mBackgroundPromotionImagePath = value;
			}
		}

		// Token: 0x1700018E RID: 398
		// (get) Token: 0x06000B49 RID: 2889 RVA: 0x00008DFC File Offset: 0x00006FFC
		// (set) Token: 0x06000B4A RID: 2890 RVA: 0x00008E04 File Offset: 0x00007004
		public SerializableDictionary<string, AppIconPromotionObject> DictAppsPromotions
		{
			get
			{
				return this.mDictAppsPromotions;
			}
			set
			{
				this.mDictAppsPromotions = value;
			}
		}

		// Token: 0x1700018F RID: 399
		// (get) Token: 0x06000B4B RID: 2891 RVA: 0x00008E0D File Offset: 0x0000700D
		// (set) Token: 0x06000B4C RID: 2892 RVA: 0x00008E15 File Offset: 0x00007015
		public string QuestName
		{
			get
			{
				return this.mQuestName;
			}
			set
			{
				this.mQuestName = value;
			}
		}

		// Token: 0x17000190 RID: 400
		// (get) Token: 0x06000B4D RID: 2893 RVA: 0x00008E1E File Offset: 0x0000701E
		// (set) Token: 0x06000B4E RID: 2894 RVA: 0x00008E26 File Offset: 0x00007026
		public string QuestActionType
		{
			get
			{
				return this.mQuestActionType;
			}
			set
			{
				this.mQuestActionType = value;
			}
		}

		// Token: 0x17000191 RID: 401
		// (get) Token: 0x06000B4F RID: 2895 RVA: 0x00008E2F File Offset: 0x0000702F
		// (set) Token: 0x06000B50 RID: 2896 RVA: 0x00008E37 File Offset: 0x00007037
		public SerializableDictionary<string, int> MyAppsOrder
		{
			get
			{
				return this.mMyAppsOrder;
			}
			set
			{
				this.mMyAppsOrder = value;
			}
		}

		// Token: 0x17000192 RID: 402
		// (get) Token: 0x06000B51 RID: 2897 RVA: 0x00008E40 File Offset: 0x00007040
		// (set) Token: 0x06000B52 RID: 2898 RVA: 0x00008E48 File Offset: 0x00007048
		public SerializableDictionary<string, int> DockOrder
		{
			get
			{
				return this.mDockOrder;
			}
			set
			{
				this.mDockOrder = value;
			}
		}

		// Token: 0x17000193 RID: 403
		// (get) Token: 0x06000B53 RID: 2899 RVA: 0x00008E51 File Offset: 0x00007051
		// (set) Token: 0x06000B54 RID: 2900 RVA: 0x00008E59 File Offset: 0x00007059
		public SerializableDictionary<string, int> MoreAppsDockOrder
		{
			get
			{
				return this.mMoreAppsDockOrder;
			}
			set
			{
				this.mMoreAppsDockOrder = value;
			}
		}

		// Token: 0x17000194 RID: 404
		// (get) Token: 0x06000B55 RID: 2901 RVA: 0x00008E62 File Offset: 0x00007062
		// (set) Token: 0x06000B56 RID: 2902 RVA: 0x00008E6A File Offset: 0x0000706A
		internal SerializableDictionary<string, BootPromotion> DictOldBootPromotions
		{
			get
			{
				return this.mDictOldBootPromotions;
			}
			set
			{
				this.mDictOldBootPromotions = value;
			}
		}

		// Token: 0x17000195 RID: 405
		// (get) Token: 0x06000B57 RID: 2903 RVA: 0x00008E73 File Offset: 0x00007073
		// (set) Token: 0x06000B58 RID: 2904 RVA: 0x00008E7B File Offset: 0x0000707B
		public int BootPromoDisplaytime
		{
			get
			{
				return this.mBootPromoDispTime;
			}
			set
			{
				this.mBootPromoDispTime = value;
			}
		}

		// Token: 0x17000196 RID: 406
		// (get) Token: 0x06000B59 RID: 2905 RVA: 0x00008E84 File Offset: 0x00007084
		// (set) Token: 0x06000B5A RID: 2906 RVA: 0x00008E8C File Offset: 0x0000708C
		public SerializableDictionary<string, BootPromotion> DictBootPromotions
		{
			get
			{
				return this.mDictBootPromotions;
			}
			set
			{
				this.mDictBootPromotions = value;
			}
		}

		// Token: 0x17000197 RID: 407
		// (get) Token: 0x06000B5B RID: 2907 RVA: 0x00008E95 File Offset: 0x00007095
		// (set) Token: 0x06000B5C RID: 2908 RVA: 0x00008E9D File Offset: 0x0000709D
		public SerializableDictionary<string, SearchRecommendation> SearchRecommendations
		{
			get
			{
				return this.mSearchRecommendations;
			}
			set
			{
				this.mSearchRecommendations = value;
			}
		}

		// Token: 0x17000198 RID: 408
		// (get) Token: 0x06000B5D RID: 2909 RVA: 0x00008EA6 File Offset: 0x000070A6
		// (set) Token: 0x06000B5E RID: 2910 RVA: 0x00008EAE File Offset: 0x000070AE
		public AppRecommendationSection AppRecommendations
		{
			get
			{
				return this.mAppRecommendations;
			}
			set
			{
				this.mAppRecommendations = value;
			}
		}

		// Token: 0x17000199 RID: 409
		// (get) Token: 0x06000B5F RID: 2911 RVA: 0x00008EB7 File Offset: 0x000070B7
		// (set) Token: 0x06000B60 RID: 2912 RVA: 0x0004FD3C File Offset: 0x0004DF3C
		public List<AppSuggestionPromotion> AppSuggestionList
		{
			get
			{
				return this.mAppSuggestionList;
			}
			set
			{
				object syncRoot = ((ICollection)this.mAppSuggestionList).SyncRoot;
				lock (syncRoot)
				{
					this.mAppSuggestionList = value;
				}
			}
		}

		// Token: 0x1700019A RID: 410
		// (get) Token: 0x06000B61 RID: 2913 RVA: 0x00008EBF File Offset: 0x000070BF
		// (set) Token: 0x06000B62 RID: 2914 RVA: 0x00008EC7 File Offset: 0x000070C7
		public List<string> BlackListedApplicationsList
		{
			get
			{
				return this.mBlackListedApplicationsList;
			}
			set
			{
				this.mBlackListedApplicationsList = value;
			}
		}

		// Token: 0x1700019B RID: 411
		// (get) Token: 0x06000B63 RID: 2915 RVA: 0x00008ED0 File Offset: 0x000070D0
		// (set) Token: 0x06000B64 RID: 2916 RVA: 0x00008ED8 File Offset: 0x000070D8
		public SerializableDictionary<string, string> StartupTab { get; set; }

		// Token: 0x1700019C RID: 412
		// (get) Token: 0x06000B65 RID: 2917 RVA: 0x00008EE1 File Offset: 0x000070E1
		// (set) Token: 0x06000B66 RID: 2918 RVA: 0x00008EE9 File Offset: 0x000070E9
		public bool IsShowOtsFeedback { get; set; }

		// Token: 0x1700019D RID: 413
		// (get) Token: 0x06000B67 RID: 2919 RVA: 0x00008EF2 File Offset: 0x000070F2
		// (set) Token: 0x06000B68 RID: 2920 RVA: 0x00008EFA File Offset: 0x000070FA
		public string DiscordClientID { get; set; }

		// Token: 0x1700019E RID: 414
		// (get) Token: 0x06000B69 RID: 2921 RVA: 0x00008F03 File Offset: 0x00007103
		// (set) Token: 0x06000B6A RID: 2922 RVA: 0x00008F0B File Offset: 0x0000710B
		public bool IsSecurityMetricsEnable { get; set; }

		// Token: 0x04000824 RID: 2084
		private static volatile bool mIsPromotionLoading = true;

		// Token: 0x04000825 RID: 2085
		internal static volatile bool mIsBootPromotionLoading = true;

		// Token: 0x0400082D RID: 2093
		private const string sPromotionFilename = "bst_promotion";

		// Token: 0x0400082E RID: 2094
		internal static PromotionObject Instance = null;

		// Token: 0x0400082F RID: 2095
		private List<string> mAppSpecificRulesList = new List<string>();

		// Token: 0x04000830 RID: 2096
		private List<string> mCustomCursorExcludedAppsList = new List<string>
		{
			"com.android.vending"
		};

		// Token: 0x04000831 RID: 2097
		private bool mIsRootAccessEnabled;

		// Token: 0x04000832 RID: 2098
		private string mMyAppsPromotionID = string.Empty;

		// Token: 0x04000833 RID: 2099
		private string mMyAppsCrossPromotionID = string.Empty;

		// Token: 0x04000834 RID: 2100
		private string mBackgroundPromotionID = string.Empty;

		// Token: 0x04000835 RID: 2101
		private string mBackgroundPromotionImagePath = string.Empty;

		// Token: 0x04000836 RID: 2102
		private SerializableDictionary<string, AppIconPromotionObject> mDictAppsPromotions = new SerializableDictionary<string, AppIconPromotionObject>();

		// Token: 0x04000837 RID: 2103
		private string mQuestName;

		// Token: 0x04000838 RID: 2104
		private string mQuestActionType;

		// Token: 0x04000839 RID: 2105
		public List<QuestRule> QuestRules = new List<QuestRule>();

		// Token: 0x0400083A RID: 2106
		public SerializableDictionary<string, long[]> ResetQuestRules = new SerializableDictionary<string, long[]>();

		// Token: 0x0400083B RID: 2107
		public SerializableDictionary<string, long> QuestHdPlayerRules = new SerializableDictionary<string, long>();

		// Token: 0x0400083C RID: 2108
		private SerializableDictionary<string, int> mMyAppsOrder = new SerializableDictionary<string, int>();

		// Token: 0x0400083D RID: 2109
		private SerializableDictionary<string, int> mDockOrder = new SerializableDictionary<string, int>
		{
			{
				"appcenter",
				1
			},
			{
				"com.android.vending",
				2
			},
			{
				"pikaworld",
				3
			},
			{
				"macro_recorder",
				4
			},
			{
				"instance_manager",
				5
			},
			{
				"help_center",
				6
			}
		};

		// Token: 0x0400083E RID: 2110
		private SerializableDictionary<string, int> mMoreAppsDockOrder = new SerializableDictionary<string, int>
		{
			{
				"appcenter",
				1
			},
			{
				"com.android.vending",
				2
			},
			{
				"pikaworld",
				3
			},
			{
				"macro_recorder",
				4
			},
			{
				"instance_manager",
				5
			},
			{
				"help_center",
				6
			}
		};

		// Token: 0x0400083F RID: 2111
		private SerializableDictionary<string, BootPromotion> mDictOldBootPromotions = new SerializableDictionary<string, BootPromotion>();

		// Token: 0x04000840 RID: 2112
		private int mBootPromoDispTime = 4000;

		// Token: 0x04000841 RID: 2113
		private SerializableDictionary<string, BootPromotion> mDictBootPromotions = new SerializableDictionary<string, BootPromotion>();

		// Token: 0x04000842 RID: 2114
		private SerializableDictionary<string, SearchRecommendation> mSearchRecommendations = new SerializableDictionary<string, SearchRecommendation>();

		// Token: 0x04000843 RID: 2115
		private AppRecommendationSection mAppRecommendations = new AppRecommendationSection();

		// Token: 0x04000844 RID: 2116
		private List<AppSuggestionPromotion> mAppSuggestionList = new List<AppSuggestionPromotion>();

		// Token: 0x04000845 RID: 2117
		private List<string> mBlackListedApplicationsList = new List<string>();

		// Token: 0x02000122 RID: 290
		public struct QuestRuleState
		{
			// Token: 0x1700019F RID: 415
			// (get) Token: 0x06000B6D RID: 2925 RVA: 0x00008F2C File Offset: 0x0000712C
			// (set) Token: 0x06000B6E RID: 2926 RVA: 0x00008F34 File Offset: 0x00007134
			public long Interaction { get; set; }

			// Token: 0x170001A0 RID: 416
			// (get) Token: 0x06000B6F RID: 2927 RVA: 0x00008F3D File Offset: 0x0000713D
			// (set) Token: 0x06000B70 RID: 2928 RVA: 0x00008F45 File Offset: 0x00007145
			public long TotalTime { get; set; }

			// Token: 0x0400084C RID: 2124
			public QuestRule QuestRules;
		}
	}
}
