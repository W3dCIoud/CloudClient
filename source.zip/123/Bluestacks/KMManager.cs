﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Interop;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000D6 RID: 214
	internal static class KMManager
	{
		// Token: 0x1700016E RID: 366
		// (get) Token: 0x060008E9 RID: 2281 RVA: 0x00007993 File Offset: 0x00005B93
		public static bool IsDragging
		{
			get
			{
				return KMManager.sDragCanvasElement != null;
			}
		}

		// Token: 0x060008EA RID: 2282 RVA: 0x0003B0D4 File Offset: 0x000392D4
		internal static void Init(MainWindow window)
		{
			KMManager.ParentWindow = window;
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				JObject jobject = JObject.Parse(window.mFrontendHandler.SendFrontendRequest("getkeymappingparserversion", null));
				if (jobject["success"].ToObject<bool>())
				{
					KMManager.ParserVersion = jobject["parserversion"].ToString();
				}
			});
			foreach (IMControlScheme imcontrolScheme in KMManager.ParentWindow.SelectedConfig.ControlSchemes)
			{
				if (imcontrolScheme.Selected)
				{
					KMManager.ParentWindow.SelectedConfig.SelectedControlScheme = imcontrolScheme;
				}
			}
		}

		// Token: 0x060008EB RID: 2283 RVA: 0x0003B16C File Offset: 0x0003936C
		internal static string GetInputmapperFile(string packageName = "")
		{
			string result = string.Empty;
			try
			{
				if (File.Exists(KMManager.GetInputmapperUserFilePath(packageName)))
				{
					result = KMManager.GetInputmapperUserFilePath(packageName);
				}
				else if (File.Exists(KMManager.GetInputmapperDefaultFilePath(packageName)))
				{
					result = KMManager.GetInputmapperDefaultFilePath(packageName);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Excpetion in GetInputMapper: " + ex.ToString());
			}
			return result;
		}

		// Token: 0x060008EC RID: 2284 RVA: 0x0003B1D4 File Offset: 0x000393D4
		internal static bool CheckGamepadCompatible(string packageName)
		{
			try
			{
				if (KMManager.dictGamepadEligibility.ContainsKey(packageName))
				{
					return KMManager.dictGamepadEligibility[packageName];
				}
				string inputmapperFile = KMManager.GetInputmapperFile(packageName);
				if (!string.IsNullOrEmpty(inputmapperFile))
				{
					string text = File.ReadAllText(inputmapperFile);
					foreach (string value in Constants.ImapGamepadEvents)
					{
						if (text.Contains(value))
						{
							KMManager.dictGamepadEligibility[packageName] = true;
							return true;
						}
					}
				}
				KMManager.dictGamepadEligibility[packageName] = false;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in CheckGamepadCompatible: " + ex.ToString());
			}
			return false;
		}

		// Token: 0x060008ED RID: 2285 RVA: 0x0000799D File Offset: 0x00005B9D
		internal static string GetInputmapperDefaultFilePath(string packageName = "")
		{
			if (string.IsNullOrEmpty(packageName))
			{
				packageName = KMManager.sPackageName;
			}
			return Path.Combine(RegistryStrings.InputMapperFolder, packageName + ".cfg");
		}

		// Token: 0x060008EE RID: 2286 RVA: 0x0003B288 File Offset: 0x00039488
		internal static void UpdateUIForGamepadEvent(string text, bool isDown)
		{
			if (KMManager.CanvasWindow != null && KMManager.CanvasWindow.IsVisible && KMManager.sGamepadDualTextbox != null)
			{
				if (KMManager.sGamepadDualTextbox.ActionItemProperty.Equals("GamepadStick"))
				{
					text = KMManager.CheckForAnalogEvent(text);
				}
				if (!string.IsNullOrEmpty(text))
				{
					if (KMManager.sGamepadDualTextbox.LstActionItem[0].Type != KeyActionType.Tap && KMManager.sGamepadDualTextbox.LstActionItem[0].Type != KeyActionType.TapRepeat && KMManager.sGamepadDualTextbox.LstActionItem[0].Type != KeyActionType.Script)
					{
						KMManager.sGamepadDualTextbox.mKeyTextBox.Text = LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + text, false);
						KMManager.sGamepadDualTextbox.Setvalue(text);
						KMManager.sGamepadDualTextbox.mKeyTextBox.ToolTip = KMManager.sGamepadDualTextbox.mKeyTextBox.Text;
						return;
					}
					KMManager.CheckItemToAddInList(text, isDown);
					if (KMManager.pressedGamepadKeyList.Count > 2)
					{
						KMManager.pressedGamepadKeyList.Clear();
						KMManager.sGamepadDualTextbox.mKeyTextBox.Text = string.Empty;
						KMManager.sGamepadDualTextbox.Setvalue(string.Empty);
						KMManager.sGamepadDualTextbox.mKeyTextBox.ToolTip = string.Empty;
						return;
					}
					if (KMManager.pressedGamepadKeyList.Count == 2)
					{
						string value = IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(0)) + " + " + IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(1));
						KMManager.sGamepadDualTextbox.mKeyTextBox.Text = LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(0)), false) + " + " + LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(1)), false);
						KMManager.sGamepadDualTextbox.Setvalue(value);
						KMManager.sGamepadDualTextbox.mKeyTextBox.ToolTip = KMManager.sGamepadDualTextbox.mKeyTextBox.Text;
						KMManager.pressedGamepadKeyList.Clear();
						return;
					}
					if (KMManager.pressedGamepadKeyList.Count == 1)
					{
						string stringForUI = IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(0));
						KMManager.sGamepadDualTextbox.mKeyTextBox.Text = LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + stringForUI, false);
						KMManager.sGamepadDualTextbox.Setvalue(stringForUI);
						KMManager.sGamepadDualTextbox.mKeyTextBox.ToolTip = KMManager.sGamepadDualTextbox.mKeyTextBox.Text;
						return;
					}
				}
			}
			else if (KMManager.GuidanceWindow != null && KMManager.GuidanceWindow.IsVisible && KMManager.sGamepadKeyElement != null)
			{
				if (KMManager.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
				{
					KMManager.AddNewControlSchemeAndSelect(KMManager.ParentWindow.SelectedConfig.SelectedControlScheme);
					if (KMManager.GuidanceWindow != null)
					{
						KMManager.GuidanceWindow.FillProfileComboBox();
					}
				}
				GameControlWindow.sIsDirty = true;
				if (KMManager.sGamepadKeyElement.ActionItemProperty.Equals("GamepadStick"))
				{
					text = KMManager.CheckForAnalogEvent(text);
				}
				if (!string.IsNullOrEmpty(text))
				{
					if (KMManager.sGamepadKeyElement.LstActionItem[0].Type == KeyActionType.Tap || KMManager.sGamepadKeyElement.LstActionItem[0].Type == KeyActionType.TapRepeat || KMManager.sGamepadKeyElement.LstActionItem[0].Type == KeyActionType.Script)
					{
						KMManager.CheckItemToAddInList(text, isDown);
						if (KMManager.pressedGamepadKeyList.Count > 2)
						{
							KMManager.pressedGamepadKeyList.Clear();
							KMManager.sGamepadKeyElement.mKeyTextBox.Text = string.Empty;
							KMManager.sGamepadKeyElement.Setvalue(string.Empty);
							KMManager.sGamepadKeyElement.mKeyTextBox.ToolTip = string.Empty;
							return;
						}
						if (KMManager.pressedGamepadKeyList.Count == 2)
						{
							string value2 = IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(0)) + " + " + IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(1));
							KMManager.sGamepadKeyElement.mKeyTextBox.Text = LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(0)), false) + " + " + LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(1)), false);
							KMManager.sGamepadKeyElement.Setvalue(value2);
							KMManager.sGamepadKeyElement.mKeyTextBox.ToolTip = KMManager.sGamepadKeyElement.mKeyTextBox.Text;
							KMManager.pressedGamepadKeyList.Clear();
							return;
						}
						if (KMManager.pressedGamepadKeyList.Count == 1)
						{
							string stringForUI2 = IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(0));
							KMManager.sGamepadKeyElement.mKeyTextBox.Text = LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + stringForUI2, false);
							KMManager.sGamepadKeyElement.Setvalue(stringForUI2);
							KMManager.sGamepadKeyElement.mKeyTextBox.ToolTip = KMManager.sGamepadKeyElement.mKeyTextBox.Text;
							return;
						}
					}
					else
					{
						KMManager.sGamepadKeyElement.mKeyTextBox.Text = LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(text), false);
						KMManager.sGamepadKeyElement.Setvalue(text);
						KMManager.sGamepadKeyElement.mKeyTextBox.ToolTip = KMManager.sGamepadKeyElement.mKeyTextBox.Text;
						KMManager.sGamepadKeyElement.mGuidanceKeyGrid.ToolTip = KMManager.sGamepadKeyElement.mKeyTextBox.Text;
					}
				}
			}
		}

		// Token: 0x060008EF RID: 2287 RVA: 0x0003B804 File Offset: 0x00039A04
		private static void CheckItemToAddInList(string text, bool isDown)
		{
			if (KMManager.pressedGamepadKeyList.ContainsKey(text) && KMManager.pressedGamepadKeyList[text] && !isDown)
			{
				KMManager.pressedGamepadKeyList.Remove(text);
			}
			if (!KMManager.pressedGamepadKeyList.ContainsKey(text) && isDown)
			{
				KMManager.pressedGamepadKeyList.Add(text, isDown);
			}
		}

		// Token: 0x060008F0 RID: 2288 RVA: 0x0003B858 File Offset: 0x00039A58
		private static string CheckForAnalogEvent(string text)
		{
			string str = string.Empty;
			string value = ".";
			string result = string.Empty;
			if (text.Contains(value))
			{
				str = text.Substring(text.IndexOf(value));
				text = text.Substring(0, text.IndexOf(value));
			}
			if (text.Equals("GamepadLStickUp") || text.Equals("GamepadLStickDown") || text.Equals("GamepadLStickLeft") || text.Equals("GamepadLStickRight"))
			{
				result = "LeftStick" + str;
			}
			else if (text.Equals("GamepadRStickUp") || text.Equals("GamepadRStickDown") || text.Equals("GamepadRStickLeft") || text.Equals("GamepadRStickRight"))
			{
				result = "RightStick" + str;
			}
			return result;
		}

		// Token: 0x060008F1 RID: 2289 RVA: 0x0003B924 File Offset: 0x00039B24
		internal static bool CheckIfGamepadPresent()
		{
			foreach (IMAction imaction in KMManager.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls)
			{
				foreach (KeyValuePair<string, PropertyInfo> keyValuePair in IMAction.DictPropertyInfo[imaction.Type])
				{
					if (keyValuePair.Key.ToString().StartsWith("Key"))
					{
						string text = IMAPKeys.GetStringForUI(imaction[keyValuePair.Key].ToString());
						if (text.Contains(".") || text.Contains("+"))
						{
							text = text.Split(new char[]
							{
								'.',
								'+'
							})[0].Trim();
						}
						if (Constants.ImapGamepadEvents.Contains(text))
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		// Token: 0x060008F2 RID: 2290 RVA: 0x000079C3 File Offset: 0x00005BC3
		internal static string GetInputmapperUserFilePath(string packageName = "")
		{
			if (string.IsNullOrEmpty(packageName))
			{
				packageName = KMManager.sPackageName;
			}
			return Path.Combine(Path.Combine(RegistryStrings.InputMapperFolder, "UserFiles"), packageName + ".cfg");
		}

		// Token: 0x060008F3 RID: 2291 RVA: 0x000079F3 File Offset: 0x00005BF3
		internal static bool KeyMappingFilesAvailable(string packageName)
		{
			return !string.IsNullOrEmpty(KMManager.GetInputmapperFile(packageName));
		}

		// Token: 0x060008F4 RID: 2292 RVA: 0x0003BA54 File Offset: 0x00039C54
		internal static void HandleInputMapperWindow(MainWindow window, bool isManualAction = true, string isSelectedTab = "default")
		{
			KMManager.ParentWindow = window;
			if (FeatureManager.Instance.IsCustomUIForNCSoft && KMManager.ParentWindow.mDimOverlay != null && KMManager.ParentWindow.mDimOverlay.Control != null && KMManager.ParentWindow.mDimOverlay.Control.GetType() == KMManager.ParentWindow.ScreenLockInstance.GetType() && KMManager.ParentWindow.ScreenLockInstance.IsVisible)
			{
				return;
			}
			KMManager.CloseWindows();
			if (window.mTopBar.mAppTabButtons.SelectedTab.mTabType != TabType.AppTab)
			{
				return;
			}
			KMManager.LoadIMActions(window.mTopBar.mAppTabButtons.SelectedTab.PackageName);
			bool flag = true;
			if (!FeatureManager.Instance.IsCustomUIForNCSoft && KMManager.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls != null && KMManager.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Count > 0)
			{
				KMManager.GuidanceWindow = new GameControlWindow(window);
				if (KMManager.GuidanceWindow.Init())
				{
					flag = false;
					KMManager.GuidanceWindow.Owner = window;
					KMManager.ShowOverlayWindow(window, false, false);
					KMManager.GuidanceWindow.GuidanceWindowTabSelected(isSelectedTab);
					KMManager.GuidanceWindow.ShowDialog();
					if (RegistryManager.Instance.ShowKeyControlsOverlay)
					{
						KMManager.ShowOverlayWindow(window, true, false);
					}
				}
			}
			if (isManualAction && flag)
			{
				KMManager.ShowAdvancedSettings(window);
			}
		}

		// Token: 0x060008F5 RID: 2293 RVA: 0x0003BBA4 File Offset: 0x00039DA4
		internal static void ResizeMainWindow(MainWindow window)
		{
			Screen screen = Screen.FromHandle(new WindowInteropHelper(window).Handle);
			double sScalingFactor = MainWindow.sScalingFactor;
			Rectangle rectangle = new Rectangle((int)((double)screen.WorkingArea.X / sScalingFactor), (int)((double)screen.WorkingArea.Y / sScalingFactor), (int)((double)screen.WorkingArea.Width / sScalingFactor), (int)((double)screen.WorkingArea.Height / sScalingFactor));
			if (window.Top + window.ActualHeight > (double)rectangle.Height)
			{
				window.Top = ((double)rectangle.Height - window.ActualHeight) / 2.0;
			}
			if (window.Left < 0.0 || window.Left + window.ActualWidth > (double)rectangle.Width)
			{
				window.Left = ((double)rectangle.Width - window.ActualWidth) / 2.0;
			}
		}

		// Token: 0x060008F6 RID: 2294 RVA: 0x0003BC94 File Offset: 0x00039E94
		internal static void ShowAdvancedSettings(MainWindow window)
		{
			KMManager.ParentWindow = window;
			if (window.WindowState != WindowState.Normal)
			{
				window.RestoreWindows();
				KeymapCanvasWindow.sWasMaximized = true;
			}
			KMManager.CloseWindows();
			KMManager.CanvasWindow = new KeymapCanvasWindow(window)
			{
				Owner = window
			};
			KMManager.CanvasWindow.InitLayout();
			KMManager.ShowOverlayWindow(window, false, false);
			KMManager.CanvasWindow.ShowDialog();
			if (RegistryManager.Instance.ShowKeyControlsOverlay)
			{
				KMManager.ShowOverlayWindow(window, true, false);
			}
		}

		// Token: 0x060008F7 RID: 2295 RVA: 0x0003BD04 File Offset: 0x00039F04
		internal static void ShowOverlayWindow(MainWindow window, bool isShow, bool isreload = false)
		{
			if (isShow && RegistryManager.Instance.TranslucentControlsTransparency != 0.0)
			{
				if (window != null && !KMManager.dictOverlayWindow.ContainsKey(window) && window != null)
				{
					TopBar mTopBar = window.mTopBar;
					bool flag;
					if (mTopBar == null)
					{
						flag = (null != null);
					}
					else
					{
						AppTabButtons mAppTabButtons = mTopBar.mAppTabButtons;
						if (mAppTabButtons == null)
						{
							flag = (null != null);
						}
						else
						{
							AppTabButton selectedTab = mAppTabButtons.SelectedTab;
							flag = (((selectedTab != null) ? selectedTab.PackageName : null) != null);
						}
					}
					if (flag)
					{
						KMManager.ParentWindow = window;
						if (FeatureManager.Instance.IsCustomUIForNCSoft && KMManager.ParentWindow.mDimOverlay != null && KMManager.ParentWindow.mDimOverlay.Control != null && KMManager.ParentWindow.mDimOverlay.Control.GetType() == KMManager.ParentWindow.ScreenLockInstance.GetType() && KMManager.ParentWindow.ScreenLockInstance.IsVisible)
						{
							return;
						}
						if (!KMManager.sIsInScriptEditingMode)
						{
							KMManager.LoadIMActions(window.mTopBar.mAppTabButtons.SelectedTab.PackageName);
						}
						KeymapCanvasWindow keymapCanvasWindow = new KeymapCanvasWindow(window);
						KMManager.dictOverlayWindow[window] = keymapCanvasWindow;
						keymapCanvasWindow.IsInOverlayMode = true;
						keymapCanvasWindow.Owner = window;
						keymapCanvasWindow.InitLayout();
						window.mFrontendHandler.ResizeWindow();
						keymapCanvasWindow.Opacity = RegistryManager.Instance.TranslucentControlsTransparency;
						if (!(window.StaticComponents.mLastMappableWindowHandle != IntPtr.Zero))
						{
							return;
						}
						keymapCanvasWindow.Show();
						if (KMManager.sIsInScriptEditingMode)
						{
							KMManager.CanvasWindow.SidebarWindow.Owner = keymapCanvasWindow;
							KMManager.CanvasWindow.SidebarWindow.Activate();
							return;
						}
						return;
					}
				}
				if (window != null && KMManager.dictOverlayWindow.ContainsKey(window) && isreload)
				{
					KMManager.dictOverlayWindow[window].ReloadCanvasWindow();
					return;
				}
			}
			else if (window != null && KMManager.dictOverlayWindow.ContainsKey(window) && !KMManager.dictOverlayWindow[window].mIsClosing)
			{
				KMManager.dictOverlayWindow[window].Close();
			}
		}

		// Token: 0x060008F8 RID: 2296 RVA: 0x00007A03 File Offset: 0x00005C03
		internal static void ChangeTransparency(MainWindow window, double value)
		{
			if (window != null && KMManager.dictOverlayWindow.ContainsKey(window))
			{
				KMManager.dictOverlayWindow[window].Opacity = value;
			}
			RegistryManager.Instance.TranslucentControlsTransparency = value;
		}

		// Token: 0x060008F9 RID: 2297 RVA: 0x0003BEE4 File Offset: 0x0003A0E4
		internal static void CloseWindows()
		{
			if (KMManager.GuidanceWindow != null && !KMManager.GuidanceWindow.mIsClosing)
			{
				try
				{
					KMManager.GuidanceWindow.Close();
				}
				catch (Exception ex)
				{
					Logger.Error("exception closing GameControlWindow " + ex.ToString());
				}
			}
			if (KMManager.CanvasWindow != null && !KMManager.CanvasWindow.mIsClosing)
			{
				try
				{
					KMManager.CanvasWindow.SidebarWindow.Close();
				}
				catch (Exception ex2)
				{
					Logger.Error("exception closing GameControlWindow " + ex2.ToString());
				}
			}
		}

		// Token: 0x060008FA RID: 2298 RVA: 0x0003BF80 File Offset: 0x0003A180
		internal static void LoadIMActions(string packageName)
		{
			KMManager.sPackageName = packageName;
			string inputmapperFile = KMManager.GetInputmapperFile("");
			try
			{
				KMManager.ClearConfig();
				if (File.Exists(inputmapperFile))
				{
					KMManager.ParentWindow.SelectedConfig = KMManager.GetDeserializedIMConfigObject(inputmapperFile, true);
					KMManager.ParentWindow.OriginalLoadedConfig = KMManager.ParentWindow.SelectedConfig.DeepCopy();
					foreach (IMControlScheme imcontrolScheme in KMManager.ParentWindow.SelectedConfig.ControlSchemes)
					{
						if (imcontrolScheme.Selected)
						{
							KMManager.ParentWindow.SelectedConfig.SelectedControlScheme = imcontrolScheme;
							break;
						}
					}
				}
				KMManager.CheckForShootingModeTooltip();
			}
			catch (Exception ex)
			{
				Logger.Error("Error parsing file " + inputmapperFile + ex.ToString());
			}
		}

		// Token: 0x060008FB RID: 2299 RVA: 0x0003C064 File Offset: 0x0003A264
		internal static void PopulateMOBADpadAsChildOfDpad(IMConfig imConfigObj)
		{
			foreach (IMControlScheme imcontrolScheme in imConfigObj.ControlSchemes)
			{
				List<Dpad> list = new List<Dpad>();
				List<MOBADpad> list2 = new List<MOBADpad>();
				foreach (IMAction imaction in imcontrolScheme.GameControls)
				{
					if (imaction.Type == KeyActionType.Dpad)
					{
						Dpad item = imaction as Dpad;
						list.Add(item);
					}
					else if (imaction.Type == KeyActionType.MOBADpad)
					{
						MOBADpad item2 = imaction as MOBADpad;
						list2.Add(item2);
					}
				}
				foreach (MOBADpad mobadpad in list2)
				{
					foreach (Dpad dpad in list)
					{
						if (mobadpad.X.Equals(dpad.X) && mobadpad.Y.Equals(dpad.Y))
						{
							dpad.mMOBADpad = mobadpad;
							mobadpad.mDpad = dpad;
							mobadpad.ParentAction = dpad;
							break;
						}
					}
				}
			}
		}

		// Token: 0x060008FC RID: 2300 RVA: 0x0003C22C File Offset: 0x0003A42C
		internal static MOBADpad GetMOBADPad()
		{
			foreach (IMAction imaction in KMManager.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls)
			{
				if (imaction.Type == KeyActionType.MOBADpad)
				{
					MOBADpad mobadpad = imaction as MOBADpad;
					if (mobadpad.OriginX != -1.0 && mobadpad.OriginY != -1.0)
					{
						return mobadpad;
					}
				}
			}
			return null;
		}

		// Token: 0x060008FD RID: 2301 RVA: 0x0003C2C0 File Offset: 0x0003A4C0
		internal static IMConfig GetDeserializedIMConfigObject(string fileName, bool isFileNameUsed = true)
		{
			IMConfig imconfig;
			if (!isFileNameUsed)
			{
				imconfig = JsonConvert.DeserializeObject<IMConfig>(fileName, Utils.GetSerializerSettings());
			}
			else
			{
				imconfig = JsonConvert.DeserializeObject<IMConfig>(File.ReadAllText(fileName), Utils.GetSerializerSettings());
			}
			KMManager.PopulateMOBADpadAsChildOfDpad(imconfig);
			return imconfig;
		}

		// Token: 0x060008FE RID: 2302 RVA: 0x00007A31 File Offset: 0x00005C31
		internal static IMControlScheme GetNewControlSchemes(string name)
		{
			return new IMControlScheme
			{
				Name = name
			};
		}

		// Token: 0x060008FF RID: 2303 RVA: 0x0003C2F8 File Offset: 0x0003A4F8
		internal static ComboBoxSchemeControl GetComboBoxSchemeControlFromName(string schemeName)
		{
			foreach (object obj in KMManager.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children)
			{
				ComboBoxSchemeControl comboBoxSchemeControl = (ComboBoxSchemeControl)obj;
				if (comboBoxSchemeControl.mSchemeName.Text == schemeName)
				{
					return comboBoxSchemeControl;
				}
			}
			return null;
		}

		// Token: 0x06000900 RID: 2304 RVA: 0x0003C378 File Offset: 0x0003A578
		internal static void AddNewControlSchemeAndSelect(IMControlScheme toCopyFromScheme = null)
		{
			bool flag = false;
			if (toCopyFromScheme != null && toCopyFromScheme.Selected)
			{
				MainWindow parentWindow = KMManager.ParentWindow;
				IMControlScheme imcontrolScheme;
				if (parentWindow == null)
				{
					imcontrolScheme = null;
				}
				else
				{
					IMConfig selectedConfig = parentWindow.SelectedConfig;
					imcontrolScheme = ((selectedConfig != null) ? selectedConfig.SelectedControlScheme : null);
				}
				if (imcontrolScheme == toCopyFromScheme)
				{
					flag = true;
				}
			}
			IMControlScheme imcontrolScheme2;
			if (toCopyFromScheme != null)
			{
				imcontrolScheme2 = toCopyFromScheme.DeepCopy();
				if (flag)
				{
					List<IMAction> gameControls = toCopyFromScheme.GameControls;
					toCopyFromScheme.GameControls = imcontrolScheme2.GameControls;
					imcontrolScheme2.GameControls = gameControls;
				}
			}
			else
			{
				imcontrolScheme2 = new IMControlScheme();
			}
			imcontrolScheme2.Name = KMManager.GetNewSchemeName(toCopyFromScheme);
			imcontrolScheme2.Selected = true;
			imcontrolScheme2.IsBookMarked = false;
			imcontrolScheme2.BuiltIn = false;
			KMManager.ParentWindow.SelectedConfig.ControlSchemes.Add(imcontrolScheme2);
			KMManager.ParentWindow.SelectedConfig.ControlSchemesDict.Add(imcontrolScheme2.Name, imcontrolScheme2);
			if (KMManager.CanvasWindow != null && KMManager.CanvasWindow.SidebarWindow != null)
			{
				KMManager.CanvasWindow.SidebarWindow.mSchemeComboBox.mName.Text = imcontrolScheme2.Name;
				ComboBoxSchemeControl comboBoxSchemeControl = new ComboBoxSchemeControl(KMManager.CanvasWindow, KMManager.ParentWindow);
				comboBoxSchemeControl.mSchemeName.Text = LocaleStrings.GetLocalizedString(imcontrolScheme2.Name, false);
				comboBoxSchemeControl.IsEnabled = true;
				BlueStacksUIBinding.BindColor(comboBoxSchemeControl, System.Windows.Controls.Control.BackgroundProperty, "AdvancedGameControlButtonGridBackground");
				KMManager.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children.Add(comboBoxSchemeControl);
			}
			if (KMManager.ParentWindow.SelectedConfig.SelectedControlScheme != null)
			{
				if (KMManager.CanvasWindow != null && KMManager.CanvasWindow.SidebarWindow != null)
				{
					ComboBoxSchemeControl comboBoxSchemeControlFromName = KMManager.GetComboBoxSchemeControlFromName(KMManager.ParentWindow.SelectedConfig.SelectedControlScheme.Name);
					if (comboBoxSchemeControlFromName != null)
					{
						BlueStacksUIBinding.BindColor(comboBoxSchemeControlFromName, System.Windows.Controls.Control.BackgroundProperty, "ComboBoxBackgroundColor");
					}
				}
				KMManager.ParentWindow.SelectedConfig.SelectedControlScheme.Selected = false;
			}
			KMManager.ParentWindow.SelectedConfig.SelectedControlScheme = imcontrolScheme2;
			KeymapCanvasWindow.sIsDirty = true;
			if (!flag)
			{
				KMManager.CanvasWindow.Init();
			}
			if (KMManager.CanvasWindow != null && KMManager.CanvasWindow.SidebarWindow != null)
			{
				KMManager.CanvasWindow.SidebarWindow.FillProfileCombo();
			}
		}

		// Token: 0x06000901 RID: 2305 RVA: 0x0003C578 File Offset: 0x0003A778
		internal static string GetNewSchemeName(IMControlScheme builtInScheme)
		{
			string baseName;
			if (builtInScheme == null)
			{
				baseName = "Custom";
			}
			else
			{
				baseName = builtInScheme.Name;
			}
			List<string> list = new List<string>();
			foreach (IMControlScheme imcontrolScheme in KMManager.ParentWindow.SelectedConfig.ControlSchemes)
			{
				list.Add(imcontrolScheme.Name);
			}
			return KMManager.GetUniqueName(baseName, list);
		}

		// Token: 0x06000902 RID: 2306 RVA: 0x0003C5F8 File Offset: 0x0003A7F8
		internal static string GetUniqueName(string baseName, IEnumerable<string> nameCollection)
		{
			int length = baseName.Length;
			int num = 0;
			bool flag = false;
			foreach (string text in nameCollection)
			{
				if (string.Compare(baseName, 0, text, 0, length, true) == 0)
				{
					flag = true;
					if (text.Length > length + 3 && text[length] == ' ' && text[length + 1] == '(' && text[text.Length - 1] == ')')
					{
						int num2;
						try
						{
							num2 = int.Parse(text.Substring(length + 2, text.Length - length - 3));
						}
						catch (Exception)
						{
							continue;
						}
						if (num2 > num)
						{
							num = num2;
						}
					}
				}
			}
			if (!flag)
			{
				return baseName;
			}
			return string.Format("{0} ({1})", baseName, num + 1);
		}

		// Token: 0x06000903 RID: 2307 RVA: 0x0003C6E4 File Offset: 0x0003A8E4
		internal static bool IsValidCfg(string fileName)
		{
			bool result;
			try
			{
				if (JsonConvert.DeserializeObject(File.ReadAllText(fileName)) == null)
				{
					result = false;
				}
				else
				{
					result = true;
				}
			}
			catch (Exception)
			{
				Logger.Error("invalid cfg file: {0}", new object[]
				{
					fileName
				});
				result = false;
			}
			return result;
		}

		// Token: 0x06000904 RID: 2308 RVA: 0x0003C730 File Offset: 0x0003A930
		private static void CheckForShootingModeTooltip()
		{
			try
			{
				if (Constants.ImapShootingModeAppsList.Contains(KMManager.sPackageName))
				{
					foreach (IMAction imaction in KMManager.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls)
					{
						if (imaction.Type == KeyActionType.Pan)
						{
							KMManager.sShootingModeKey = ((Pan)imaction).KeyStartStop.ToString();
						}
					}
					KMManager.ParentWindow.ToggleShootingModeTooltipVisibility(true);
				}
				else
				{
					KMManager.ParentWindow.ToggleShootingModeTooltipVisibility(false);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in showing shooting mode tooltip: " + ex.ToString());
			}
		}

		// Token: 0x06000905 RID: 2309 RVA: 0x0003C7F8 File Offset: 0x0003A9F8
		internal static void ClearConfig()
		{
			MOBADpad.sListMOBADpad.Clear();
			Dpad.sListDpad.Clear();
			if (KMManager.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls != null)
			{
				KMManager.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Clear();
			}
			if (KMManager.ParentWindow.SelectedConfig.ControlSchemes != null)
			{
				KMManager.ParentWindow.SelectedConfig.ControlSchemes.Clear();
			}
			if (KMManager.ParentWindow.SelectedConfig.Strings != null)
			{
				KMManager.ParentWindow.SelectedConfig.Strings.Clear();
			}
			KMManager.ParentWindow.SelectedConfig.SelectedControlScheme = null;
		}

		// Token: 0x06000906 RID: 2310 RVA: 0x0003C8A4 File Offset: 0x0003AAA4
		internal static void GetCanvasElement(IMAction action, Canvas canvas, bool addToCanvas = true)
		{
			KMManager.sDragCanvasElement = new CanvasElement(KMManager.CanvasWindow, KMManager.ParentWindow);
			KMManager.sDragCanvasElement.AddAction(action);
			KMManager.sDragCanvasElement.Opacity = 0.1;
			if (addToCanvas)
			{
				canvas.Children.Add(KMManager.sDragCanvasElement);
			}
			if (action.Type == KeyActionType.Swipe)
			{
				KMManager.AssignSwapValues(action);
				List<Direction> list = Enum.GetValues(typeof(Direction)).Cast<Direction>().ToList<Direction>();
				list.Remove(action.Direction);
				foreach (Direction direction in list)
				{
					IMAction imaction = action.DeepCopy<IMAction>();
					imaction.Direction = direction;
					imaction.RadiusProperty = action.RadiusProperty;
					KMManager.AssignSwapValues(imaction);
					KMManager.sDragCanvasElement.AddAction(imaction);
				}
				action.RadiusProperty = action.RadiusProperty;
			}
		}

		// Token: 0x06000907 RID: 2311 RVA: 0x0003C9A0 File Offset: 0x0003ABA0
		private static void AssignSwapValues(IMAction action)
		{
			if (action.Direction == Direction.Up)
			{
				(action as Swipe).Key = IMAPKeys.GetStringForUI(Key.Up);
				return;
			}
			if (action.Direction == Direction.Down)
			{
				(action as Swipe).Key = IMAPKeys.GetStringForUI(Key.Down);
				return;
			}
			if (action.Direction == Direction.Left)
			{
				(action as Swipe).Key = IMAPKeys.GetStringForUI(Key.Left);
				return;
			}
			(action as Swipe).Key = IMAPKeys.GetStringForUI(Key.Right);
		}

		// Token: 0x06000908 RID: 2312 RVA: 0x0003CA14 File Offset: 0x0003AC14
		internal static List<IMAction> ClearElement()
		{
			List<IMAction> result = null;
			if (KMManager.sDragCanvasElement != null)
			{
				result = KMManager.sDragCanvasElement.lstActionItem;
				System.Windows.Controls.Panel panel = KMManager.sDragCanvasElement.Parent as System.Windows.Controls.Panel;
				if (panel != null)
				{
					panel.Children.Remove(KMManager.sDragCanvasElement);
				}
				KMManager.sDragCanvasElement = null;
			}
			return result;
		}

		// Token: 0x06000909 RID: 2313 RVA: 0x0003CA60 File Offset: 0x0003AC60
		internal static void RepositionCanvasElement()
		{
			if (KMManager.sDragCanvasElement != null)
			{
				System.Windows.Point position = Mouse.GetPosition(KMManager.sDragCanvasElement.Parent as IInputElement);
				Canvas.SetTop(KMManager.sDragCanvasElement, position.Y - KMManager.sDragCanvasElement.ActualHeight / 2.0);
				Canvas.SetLeft(KMManager.sDragCanvasElement, position.X - KMManager.sDragCanvasElement.ActualWidth / 2.0);
			}
		}

		// Token: 0x0600090A RID: 2314 RVA: 0x0003CAD8 File Offset: 0x0003ACD8
		internal static void SaveIMActions(bool isSavedFromGameControlWindow, bool isdDeleteIfEmpty = false)
		{
			if (!GameControlWindow.sIsDirty && !KeymapCanvasWindow.sIsDirty && !isdDeleteIfEmpty)
			{
				Logger.Info("No changes were made in config file. Not saving");
				return;
			}
			KeymapCanvasWindow.sIsDirty = false;
			GameControlWindow.sIsDirty = false;
			string inputmapperUserFilePath = KMManager.GetInputmapperUserFilePath("");
			KMManager.CheckForShootingModeTooltip();
			try
			{
				string directoryName = Path.GetDirectoryName(inputmapperUserFilePath);
				if (!Directory.Exists(directoryName))
				{
					Directory.CreateDirectory(directoryName);
				}
				JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
				serializerSettings.Formatting = Formatting.Indented;
				string contents = JsonConvert.SerializeObject(KMManager.ParentWindow.SelectedConfig, serializerSettings);
				bool flag = false;
				if (!File.Exists(inputmapperUserFilePath))
				{
					flag = true;
				}
				File.WriteAllText(inputmapperUserFilePath, contents);
				KMManager.ParentWindow.OriginalLoadedConfig = KMManager.ParentWindow.SelectedConfig.DeepCopy();
				if (KMManager.CanvasWindow != null && KMManager.CanvasWindow.SidebarWindow != null)
				{
					if (KMManager.ParentWindow.OriginalLoadedConfig.ControlSchemes != null && KMManager.ParentWindow.OriginalLoadedConfig.ControlSchemes.Count > 0)
					{
						KMManager.CanvasWindow.SidebarWindow.mExport.IsEnabled = true;
					}
					else
					{
						KMManager.CanvasWindow.SidebarWindow.mExport.IsEnabled = false;
					}
				}
				ClientStats.SendKeyMappingUIStatsAsync("cfg_saved", KMManager.sPackageName, isSavedFromGameControlWindow ? "edit_keys" : "advanced");
				if (flag)
				{
					KMManager.ParentWindow.mWelcomeTab.mHomeApp.RequirementConfigUpdated();
				}
				BlueStacksUIUtils.RefreshKeyMap(KMManager.sPackageName);
				if (KMManager.dictGamepadEligibility.ContainsKey(KMManager.sPackageName))
				{
					KMManager.dictGamepadEligibility.Remove(KMManager.sPackageName);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error saving file  for " + inputmapperUserFilePath + Environment.NewLine + ex.ToString());
			}
		}

		// Token: 0x0600090B RID: 2315 RVA: 0x0003CC88 File Offset: 0x0003AE88
		internal static void SaveConfigToFile(string path, IMConfig config)
		{
			JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
			serializerSettings.Formatting = Formatting.Indented;
			string contents = JsonConvert.SerializeObject(config, serializerSettings);
			File.WriteAllText(path, contents);
		}

		// Token: 0x0600090C RID: 2316 RVA: 0x0003CCB4 File Offset: 0x0003AEB4
		internal static bool CheckIfKeymappingWindowVisible()
		{
			bool isVisible = false;
			try
			{
				BlueStacksUIUtils.LastActivatedWindow.Dispatcher.Invoke(new Action(delegate()
				{
					if (KMManager.GuidanceWindow != null && KMManager.GuidanceWindow.IsActive)
					{
						isVisible = true;
					}
					if (KMManager.CanvasWindow != null && KMManager.CanvasWindow.IsActive)
					{
						isVisible = true;
					}
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Info("Exception in checkifkeymappingwindowvisible: " + ex.ToString());
			}
			return isVisible;
		}

		// Token: 0x0600090D RID: 2317 RVA: 0x0003CD20 File Offset: 0x0003AF20
		internal static void HideKeymapWindowIfInView()
		{
			try
			{
				BlueStacksUIUtils.LastActivatedWindow.Dispatcher.Invoke(new Action(delegate()
				{
					Window window = null;
					if (KMManager.GuidanceWindow != null && KMManager.GuidanceWindow.IsActive)
					{
						window = KMManager.GuidanceWindow;
					}
					if (KMManager.CanvasWindow != null)
					{
						if (KMManager.CanvasWindow.IsActive)
						{
							window = KMManager.CanvasWindow;
						}
						else if (KMManager.CanvasWindow.SidebarWindow != null && KMManager.CanvasWindow.SidebarWindow.IsActive)
						{
							window = KMManager.CanvasWindow.SidebarWindow;
						}
					}
					if (window != null)
					{
						window.Close();
					}
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Info("Error hididng the window" + ex.ToString());
			}
		}

		// Token: 0x0600090E RID: 2318 RVA: 0x0003CD8C File Offset: 0x0003AF8C
		internal static void CallGamepadHandler(string isEnable = "true")
		{
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"enable",
					isEnable
				}
			};
			KMManager.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("toggleGamepadButton", data);
		}

		// Token: 0x0600090F RID: 2319 RVA: 0x0003CDC0 File Offset: 0x0003AFC0
		internal static string GetStringsToShowInUI(string text)
		{
			string[] array = text.ToString().Split(new char[]
			{
				'+'
			}, StringSplitOptions.RemoveEmptyEntries);
			string str = string.Empty;
			string str2 = string.Empty;
			string result = string.Empty;
			if (array.Count<string>() == 2)
			{
				str = IMAPKeys.GetStringForUI(array[0].Trim());
				str2 = IMAPKeys.GetStringForUI(array[1].Trim());
				result = Constants.ImapLocaleStringsConstant + str + " + " + str2;
			}
			else if (array.Count<string>() == 1)
			{
				str = IMAPKeys.GetStringForUI(array[0].Trim());
				result = Constants.ImapLocaleStringsConstant + str;
			}
			return result;
		}

		// Token: 0x06000910 RID: 2320 RVA: 0x0003CE54 File Offset: 0x0003B054
		internal static Dictionary<string, Dictionary<string, string>> CleanupGuidanceAccordingToSchemes(List<IMControlScheme> schemes, Dictionary<string, Dictionary<string, string>> locales)
		{
			HashSet<string> guidanceInUse = new HashSet<string>();
			foreach (IMControlScheme imcontrolScheme in schemes)
			{
				foreach (IMAction imaction in imcontrolScheme.GameControls)
				{
					guidanceInUse.UnionWith(imaction.Guidance.Values);
					guidanceInUse.Add(imaction.GuidanceCategory);
				}
			}
			Func<KeyValuePair<string, string>, bool> <>9__0;
			foreach (string key in locales.Keys)
			{
				IEnumerable<KeyValuePair<string, string>> source = locales[key];
				Func<KeyValuePair<string, string>, bool> predicate;
				if ((predicate = <>9__0) == null)
				{
					predicate = (<>9__0 = ((KeyValuePair<string, string> kv) => !guidanceInUse.Contains(kv.Key)));
				}
				foreach (KeyValuePair<string, string> keyValuePair in source.Where(predicate).ToList<KeyValuePair<string, string>>())
				{
					locales[key].Remove(keyValuePair.Key);
				}
			}
			return locales;
		}

		// Token: 0x06000911 RID: 2321 RVA: 0x0003CFD0 File Offset: 0x0003B1D0
		public static string GetPackageFromCfgFile(string cfgFileName)
		{
			string result = string.Empty;
			if (!string.IsNullOrEmpty(cfgFileName))
			{
				result = Path.GetFileNameWithoutExtension(cfgFileName);
			}
			return result;
		}

		// Token: 0x06000912 RID: 2322 RVA: 0x0003CFF4 File Offset: 0x0003B1F4
		public static void MergeConfig(string pdPath)
		{
			Logger.Info("In MergeConfig");
			try
			{
				string text = Path.Combine(pdPath, "Engine\\UserData\\InputMapper\\UserFiles");
				string[] files = Directory.GetFiles(text);
				for (int i = 0; i < files.Length; i++)
				{
					FileInfo fileInfo = new FileInfo(files[i]);
					string path = Path.Combine(pdPath, "Engine\\UserData\\InputMapper");
					string text2 = Path.Combine(path, fileInfo.Name);
					string text3 = Path.Combine(text, fileInfo.Name);
					IMConfig deserializedIMConfigObject = KMManager.GetDeserializedIMConfigObject(text3, true);
					if (deserializedIMConfigObject.ControlSchemes.Count == 1)
					{
						deserializedIMConfigObject.ControlSchemes[0].Selected = true;
					}
					if (!File.Exists(text2))
					{
						KMManager.SaveConfigToFile(Path.Combine(path, "UserFiles\\" + fileInfo.Name), deserializedIMConfigObject);
					}
					else
					{
						KMManager.ControlSchemesHandling(KMManager.GetPackageFromCfgFile(fileInfo.Name), text3, text2);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in merging cfg. err: " + ex.ToString());
			}
		}

		// Token: 0x06000913 RID: 2323 RVA: 0x0003D0FC File Offset: 0x0003B2FC
		internal static void MergeConflictingGuidanceStrings(IMConfig newConfig, List<IMControlScheme> toCopyFromSchemes, Dictionary<string, Dictionary<string, string>> stringsToImport)
		{
			HashSet<string> hashSet = new HashSet<string>();
			HashSet<string> hashSet2 = new HashSet<string>();
			foreach (string text in stringsToImport.Keys)
			{
				hashSet2.UnionWith(stringsToImport[text].Keys);
				if (newConfig.Strings.Keys.Contains(text))
				{
					hashSet2.UnionWith(newConfig.Strings[text].Keys);
					foreach (string text2 in stringsToImport[text].Keys)
					{
						if (newConfig.Strings[text].Keys.Contains(text2) && stringsToImport[text][text2] != newConfig.Strings[text][text2])
						{
							hashSet.Add(text2);
						}
					}
				}
			}
			foreach (string text3 in hashSet)
			{
				string uniqueName = KMManager.GetUniqueName(text3, hashSet2);
				foreach (IMControlScheme imcontrolScheme in toCopyFromSchemes)
				{
					foreach (IMAction imaction in imcontrolScheme.GameControls)
					{
						if (imaction.GuidanceCategory == text3)
						{
							imaction.GuidanceCategory = uniqueName;
						}
						foreach (string key in imaction.Guidance.Keys)
						{
							if (imaction.Guidance[key] == text3)
							{
								imaction.Guidance[key] = uniqueName;
								break;
							}
						}
					}
				}
				foreach (Dictionary<string, string> dictionary in stringsToImport.Values)
				{
					if (dictionary.ContainsKey(text3))
					{
						dictionary[uniqueName] = dictionary[text3];
						dictionary.Remove(text3);
					}
				}
			}
			foreach (KeyValuePair<string, Dictionary<string, string>> keyValuePair in stringsToImport)
			{
				if (newConfig.Strings.ContainsKey(keyValuePair.Key))
				{
					using (Dictionary<string, string>.Enumerator enumerator8 = keyValuePair.Value.GetEnumerator())
					{
						while (enumerator8.MoveNext())
						{
							KeyValuePair<string, string> keyValuePair2 = enumerator8.Current;
							newConfig.Strings[keyValuePair.Key][keyValuePair2.Key] = keyValuePair2.Value;
						}
						continue;
					}
				}
				newConfig.Strings[keyValuePair.Key] = keyValuePair.Value;
			}
		}

		// Token: 0x06000914 RID: 2324 RVA: 0x0003D510 File Offset: 0x0003B710
		public static void ControlSchemesHandlingWhileCfgUpdateFromCloud(string package)
		{
			string userFilesCfgPath = string.Format(Path.Combine(Path.Combine(RegistryStrings.InputMapperFolder, "UserFiles"), package) + ".cfg", new object[0]);
			string inputMapperCfgPath = string.Format(Path.Combine(RegistryStrings.InputMapperFolder, package) + ".cfg", new object[0]);
			KMManager.ControlSchemesHandling(package, userFilesCfgPath, inputMapperCfgPath);
		}

		// Token: 0x06000915 RID: 2325 RVA: 0x0003D574 File Offset: 0x0003B774
		private static void ControlSchemesHandling(string package, string userFilesCfgPath, string inputMapperCfgPath)
		{
			try
			{
				if (File.Exists(userFilesCfgPath))
				{
					IMConfig deserializedIMConfigObject = KMManager.GetDeserializedIMConfigObject(inputMapperCfgPath, true);
					IMConfig deserializedIMConfigObject2 = KMManager.GetDeserializedIMConfigObject(userFilesCfgPath, true);
					KMManager.MergeConflictingGuidanceStrings(deserializedIMConfigObject, deserializedIMConfigObject2.ControlSchemes, deserializedIMConfigObject2.Strings);
					deserializedIMConfigObject2.Strings = deserializedIMConfigObject.Strings;
					List<IMControlScheme> list = new List<IMControlScheme>();
					foreach (IMControlScheme imcontrolScheme in deserializedIMConfigObject.ControlSchemes)
					{
						if (imcontrolScheme.BuiltIn)
						{
							list.Add(imcontrolScheme);
						}
					}
					bool flag = KMManager.IsBuiltInSchemeSelected(deserializedIMConfigObject2);
					List<IMControlScheme> list2 = new List<IMControlScheme>();
					foreach (IMControlScheme imcontrolScheme2 in deserializedIMConfigObject2.ControlSchemes)
					{
						if (imcontrolScheme2.BuiltIn)
						{
							list2.Add(imcontrolScheme2);
						}
					}
					foreach (IMControlScheme item in list2)
					{
						deserializedIMConfigObject2.ControlSchemes.Remove(item);
					}
					List<string> list3 = (from scheme in list
					select scheme.Name).ToList<string>();
					List<string> list4 = (from scheme in deserializedIMConfigObject2.ControlSchemes
					select scheme.Name).ToList<string>();
					list4.AddRange(list3);
					string str = " (Custom)";
					foreach (IMControlScheme imcontrolScheme3 in deserializedIMConfigObject2.ControlSchemes)
					{
						if (list3.Contains(imcontrolScheme3.Name))
						{
							imcontrolScheme3.Name = KMManager.GetUniqueName(imcontrolScheme3.Name + str, list4);
							list4.Add(imcontrolScheme3.Name);
						}
					}
					foreach (IMControlScheme item2 in list)
					{
						deserializedIMConfigObject2.ControlSchemes.Add(item2);
					}
					if (!flag)
					{
						foreach (IMControlScheme imcontrolScheme4 in deserializedIMConfigObject2.ControlSchemes)
						{
							if (imcontrolScheme4.BuiltIn)
							{
								if (!Opt.Instance.isUpgradeFromImap13 || !string.Equals(package, "com.dts.freefireth", StringComparison.InvariantCultureIgnoreCase))
								{
									imcontrolScheme4.Selected = false;
								}
							}
							else if (Opt.Instance.isUpgradeFromImap13 && string.Equals(package, "com.dts.freefireth", StringComparison.InvariantCultureIgnoreCase))
							{
								imcontrolScheme4.Selected = false;
							}
						}
					}
					if (string.Equals(package, "com.dts.freefireth", StringComparison.InvariantCultureIgnoreCase))
					{
						IMControlScheme imcontrolScheme5 = new IMControlScheme();
						foreach (IMControlScheme imcontrolScheme6 in list)
						{
							if (imcontrolScheme6.Images != null && imcontrolScheme6.Images.Count > 0)
							{
								imcontrolScheme5 = imcontrolScheme6;
								break;
							}
						}
						foreach (IMControlScheme imcontrolScheme7 in deserializedIMConfigObject2.ControlSchemes)
						{
							if (imcontrolScheme7.Images != null && !imcontrolScheme7.BuiltIn && imcontrolScheme7.Images.Count > 0)
							{
								imcontrolScheme7.Images = imcontrolScheme5.Images;
								IEnumerable<IMAction> panControls = from control in imcontrolScheme5.GameControls
								where (control.Type == KeyActionType.Pan || control.Type == KeyActionType.PanShoot) && !string.IsNullOrEmpty(control.StartCondition)
								select control;
								if (panControls.Any<IMAction>())
								{
									List<IMAction> gameControls = imcontrolScheme7.GameControls;
									IEnumerable<IMAction> enumerable;
									if (gameControls == null)
									{
										enumerable = null;
									}
									else
									{
										enumerable = from control in gameControls
										where control.Type == KeyActionType.Pan || control.Type == KeyActionType.PanShoot
										select control;
									}
									IEnumerable<IMAction> enumerable2 = enumerable;
									if (enumerable2 != null && enumerable2.Any<IMAction>())
									{
										(from pan in enumerable2
										select pan.StartCondition = panControls.First<IMAction>().StartCondition).ToList<string>();
									}
								}
							}
						}
					}
					KMManager.SaveConfigToFile(userFilesCfgPath, deserializedIMConfigObject2);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in updating control schemes err: " + ex.ToString());
			}
		}

		// Token: 0x06000916 RID: 2326 RVA: 0x0003DA98 File Offset: 0x0003BC98
		private static bool IsBuiltInSchemeSelected(IMConfig prevConfig)
		{
			foreach (IMControlScheme imcontrolScheme in prevConfig.ControlSchemes)
			{
				if (imcontrolScheme.Selected)
				{
					return imcontrolScheme.BuiltIn;
				}
			}
			return false;
		}

		// Token: 0x0400067D RID: 1661
		internal static MainWindow ParentWindow = null;

		// Token: 0x0400067E RID: 1662
		internal static KeymapCanvasWindow CanvasWindow = null;

		// Token: 0x0400067F RID: 1663
		internal static GameControlWindow GuidanceWindow = null;

		// Token: 0x04000680 RID: 1664
		internal static string mComboEvents = string.Empty;

		// Token: 0x04000681 RID: 1665
		internal static bool sIsCancelComboClicked = false;

		// Token: 0x04000682 RID: 1666
		internal static bool sIsSaveComboClicked = false;

		// Token: 0x04000683 RID: 1667
		internal static bool sIsComboRecordingOn = false;

		// Token: 0x04000684 RID: 1668
		internal static DualTextBlockControl sGamepadDualTextbox = null;

		// Token: 0x04000685 RID: 1669
		internal static GuidanceKeyElement sGamepadKeyElement = null;

		// Token: 0x04000686 RID: 1670
		internal static Dictionary<string, bool> dictGamepadEligibility = new Dictionary<string, bool>();

		// Token: 0x04000687 RID: 1671
		internal static string sShootingModeKey = "F1";

		// Token: 0x04000688 RID: 1672
		public static Dictionary<string, bool> pressedGamepadKeyList = new Dictionary<string, bool>();

		// Token: 0x04000689 RID: 1673
		internal static bool sIsInScriptEditingMode = false;

		// Token: 0x0400068A RID: 1674
		internal static Dictionary<MainWindow, KeymapCanvasWindow> dictOverlayWindow = new Dictionary<MainWindow, KeymapCanvasWindow>();

		// Token: 0x0400068B RID: 1675
		internal static CanvasElement sDragCanvasElement;

		// Token: 0x0400068C RID: 1676
		public static string ParserVersion = "14";

		// Token: 0x0400068D RID: 1677
		internal static string sPackageName = string.Empty;

		// Token: 0x0400068E RID: 1678
		internal static string sVideoMode = string.Empty;

		// Token: 0x0400068F RID: 1679
		internal static bool sIsDeveloperModeOn = false;
	}
}
