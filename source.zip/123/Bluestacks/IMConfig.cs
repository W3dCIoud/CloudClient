﻿using System;
using System.Collections.Generic;
using System.Linq;
using BlueStacks.Common;
using Newtonsoft.Json;

// Token: 0x02000019 RID: 25
[Serializable]
internal class IMConfig
{
	// Token: 0x170000C5 RID: 197
	// (get) Token: 0x060001A3 RID: 419 RVA: 0x00003113 File Offset: 0x00001313
	// (set) Token: 0x060001A4 RID: 420 RVA: 0x0000312E File Offset: 0x0000132E
	public MetaData MetaData
	{
		get
		{
			if (this.mMetaData == null)
			{
				this.mMetaData = new MetaData();
			}
			return this.mMetaData;
		}
		set
		{
			this.mMetaData = value;
		}
	}

	// Token: 0x170000C6 RID: 198
	// (get) Token: 0x060001A5 RID: 421 RVA: 0x00003137 File Offset: 0x00001337
	// (set) Token: 0x060001A6 RID: 422 RVA: 0x00003152 File Offset: 0x00001352
	public List<IMControlScheme> ControlSchemes
	{
		get
		{
			if (this.mControlSchemes == null)
			{
				this.mControlSchemes = new List<IMControlScheme>();
			}
			return this.mControlSchemes;
		}
		set
		{
			this.mControlSchemes = value;
		}
	}

	// Token: 0x170000C7 RID: 199
	// (get) Token: 0x060001A7 RID: 423 RVA: 0x0000315B File Offset: 0x0000135B
	[JsonIgnore]
	public Dictionary<string, IMControlScheme> ControlSchemesDict
	{
		get
		{
			return this.mControlSchemesDict;
		}
	}

	// Token: 0x170000C8 RID: 200
	// (get) Token: 0x060001A8 RID: 424 RVA: 0x00003163 File Offset: 0x00001363
	// (set) Token: 0x060001A9 RID: 425 RVA: 0x0000316B File Offset: 0x0000136B
	public Dictionary<string, Dictionary<string, string>> Strings
	{
		get
		{
			return this.mStrings;
		}
		set
		{
			this.mStrings = value;
		}
	}

	// Token: 0x170000C9 RID: 201
	// (get) Token: 0x060001AA RID: 426 RVA: 0x00003174 File Offset: 0x00001374
	// (set) Token: 0x060001AB RID: 427 RVA: 0x0000318F File Offset: 0x0000138F
	[JsonIgnore]
	public IMControlScheme SelectedControlScheme
	{
		get
		{
			if (this.mSelectedControlScheme == null)
			{
				this.mSelectedControlScheme = new IMControlScheme();
			}
			return this.mSelectedControlScheme;
		}
		set
		{
			this.mSelectedControlScheme = value;
		}
	}

	// Token: 0x060001AC RID: 428 RVA: 0x000109B0 File Offset: 0x0000EBB0
	internal string GetUIString(string key)
	{
		string result = key;
		if (this.Strings.ContainsKey(LocaleStrings.sLocale) && this.Strings[LocaleStrings.sLocale].ContainsKey(key))
		{
			result = this.Strings[LocaleStrings.sLocale][key];
		}
		else if (this.Strings.ContainsKey("en-US") && this.Strings["en-US"].ContainsKey(key))
		{
			result = this.Strings["en-US"][key];
		}
		else if (this.Strings.ContainsKey("User-Defined") && this.Strings["User-Defined"].ContainsKey(key))
		{
			result = this.Strings["User-Defined"][key];
		}
		return result;
	}

	// Token: 0x060001AD RID: 429 RVA: 0x00003198 File Offset: 0x00001398
	internal void AddString(string key)
	{
		if (!this.Strings.ContainsKey("User-Defined"))
		{
			this.Strings.Add("User-Defined", new Dictionary<string, string>());
		}
		this.Strings["User-Defined"][key] = key;
	}

	// Token: 0x060001AE RID: 430 RVA: 0x00010A8C File Offset: 0x0000EC8C
	public IMConfig DeepCopy()
	{
		IMConfig imconfig = (IMConfig)base.MemberwiseClone();
		MetaData metaData = this.MetaData;
		imconfig.MetaData = ((metaData != null) ? metaData.DeepCopy<MetaData>() : null);
		List<IMControlScheme> controlSchemes = this.ControlSchemes;
		List<IMControlScheme> controlSchemes2;
		if (controlSchemes == null)
		{
			controlSchemes2 = null;
		}
		else
		{
			controlSchemes2 = controlSchemes.ConvertAll<IMControlScheme>(delegate(IMControlScheme cs)
			{
				if (cs == null)
				{
					return null;
				}
				return cs.DeepCopy();
			});
		}
		imconfig.ControlSchemes = controlSchemes2;
		Dictionary<string, IMControlScheme> dictionary = this.mControlSchemesDict;
		Dictionary<string, IMControlScheme> dictionary2;
		if (dictionary == null)
		{
			dictionary2 = null;
		}
		else
		{
			dictionary2 = dictionary.ToDictionary((KeyValuePair<string, IMControlScheme> kvp) => kvp.Key, delegate(KeyValuePair<string, IMControlScheme> kvp)
			{
				IMControlScheme value = kvp.Value;
				if (value == null)
				{
					return null;
				}
				return value.DeepCopy();
			});
		}
		imconfig.mControlSchemesDict = dictionary2;
		Dictionary<string, Dictionary<string, string>> strings = this.Strings;
		Dictionary<string, Dictionary<string, string>> strings2;
		if (strings == null)
		{
			strings2 = null;
		}
		else
		{
			strings2 = strings.ToDictionary((KeyValuePair<string, Dictionary<string, string>> kvp) => kvp.Key, (KeyValuePair<string, Dictionary<string, string>> kvp) => kvp.Value);
		}
		imconfig.Strings = strings2;
		IMControlScheme selectedControlScheme = this.SelectedControlScheme;
		imconfig.SelectedControlScheme = ((selectedControlScheme != null) ? selectedControlScheme.DeepCopy() : null);
		return imconfig;
	}

	// Token: 0x040000C0 RID: 192
	private MetaData mMetaData;

	// Token: 0x040000C1 RID: 193
	private List<IMControlScheme> mControlSchemes;

	// Token: 0x040000C2 RID: 194
	private Dictionary<string, IMControlScheme> mControlSchemesDict = new Dictionary<string, IMControlScheme>();

	// Token: 0x040000C3 RID: 195
	private Dictionary<string, Dictionary<string, string>> mStrings = new Dictionary<string, Dictionary<string, string>>();

	// Token: 0x040000C4 RID: 196
	internal IMControlScheme mSelectedControlScheme;
}
