﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000CD RID: 205
	public class AdvancedGameControlWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x06000828 RID: 2088 RVA: 0x00032C2C File Offset: 0x00030E2C
		internal AdvancedGameControlWindow(MainWindow window)
		{
			this.ParentWindow = window;
			this.InitializeComponent();
			if (KMManager.sIsDeveloperModeOn)
			{
				this.mStatePrimitive.Visibility = Visibility.Visible;
			}
			else
			{
				this.mStatePrimitive.Visibility = Visibility.Collapsed;
			}
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.mBrowserHelp.Visibility = Visibility.Collapsed;
			}
			base.Width = 0.0;
			base.Height = 0.0;
			BlueStacksUIBinding.Bind(this.mShowHelpHyperlink, "STRING_SCRIPT_GUIDE", "");
			AdvancedSettingsItemPanel advancedSettingsItemPanel = this.mTapPrimitive;
			advancedSettingsItemPanel.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel2 = this.mTapRepeatPrimitive;
			advancedSettingsItemPanel2.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel2.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel3 = this.mDpadPrimitive;
			advancedSettingsItemPanel3.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel3.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel4 = this.mZoomPrimitive;
			advancedSettingsItemPanel4.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel4.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel5 = this.mFreeLookPrimitive;
			advancedSettingsItemPanel5.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel5.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel6 = this.mPanPrimitive;
			advancedSettingsItemPanel6.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel6.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel7 = this.mMOBASkillPrimitive;
			advancedSettingsItemPanel7.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel7.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel8 = this.mSwipePrimitive;
			advancedSettingsItemPanel8.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel8.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel9 = this.mTiltPrimitive;
			advancedSettingsItemPanel9.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel9.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel10 = this.mStatePrimitive;
			advancedSettingsItemPanel10.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel10.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel11 = this.mScriptPrimitive;
			advancedSettingsItemPanel11.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel11.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel12 = this.mTapPrimitive;
			advancedSettingsItemPanel12.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel12.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel13 = this.mTapRepeatPrimitive;
			advancedSettingsItemPanel13.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel13.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel14 = this.mDpadPrimitive;
			advancedSettingsItemPanel14.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel14.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel15 = this.mZoomPrimitive;
			advancedSettingsItemPanel15.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel15.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel16 = this.mFreeLookPrimitive;
			advancedSettingsItemPanel16.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel16.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel17 = this.mPanPrimitive;
			advancedSettingsItemPanel17.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel17.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel18 = this.mMOBASkillPrimitive;
			advancedSettingsItemPanel18.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel18.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel19 = this.mSwipePrimitive;
			advancedSettingsItemPanel19.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel19.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel20 = this.mTiltPrimitive;
			advancedSettingsItemPanel20.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel20.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel21 = this.mStatePrimitive;
			advancedSettingsItemPanel21.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel21.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel22 = this.mScriptPrimitive;
			advancedSettingsItemPanel22.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel22.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
		}

		// Token: 0x06000829 RID: 2089 RVA: 0x000073C4 File Offset: 0x000055C4
		private void CloseButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.CloseWindow();
		}

		// Token: 0x0600082A RID: 2090 RVA: 0x000073CC File Offset: 0x000055CC
		private void CloseWindow()
		{
			KMManager.sIsDeveloperModeOn = false;
			base.Close();
		}

		// Token: 0x0600082B RID: 2091 RVA: 0x00033020 File Offset: 0x00031220
		internal void ToggleAGCWindowVisiblity(bool isScriptModeWindow)
		{
			KMManager.sIsInScriptEditingMode = isScriptModeWindow;
			this.mScriptModeDictionary["isInScriptMode"] = isScriptModeWindow.ToString();
			this.BindOrUnbindMouseEvents(isScriptModeWindow);
			if (isScriptModeWindow)
			{
				this.PrimaryGrid.Visibility = Visibility.Collapsed;
				this.KeySequenceScriptGrid.Visibility = Visibility.Visible;
				base.Owner = this.ParentWindow;
				this.PopulateScriptTextBox();
				this.CanvasWindow.Hide();
				this.ParentWindow.Utils.ToggleTopBarSidebarEnabled(false);
			}
			else
			{
				this.PrimaryGrid.Visibility = Visibility.Visible;
				this.KeySequenceScriptGrid.Visibility = Visibility.Collapsed;
				this.CanvasWindow.Show();
				base.Owner = this.CanvasWindow;
				base.Activate();
				this.ParentWindow.Utils.ToggleTopBarSidebarEnabled(true);
			}
			HTTPUtils.SendRequestToEngineAsync("scriptEditingModeEntered", this.mScriptModeDictionary, this.ParentWindow.mVmName, 0, null, false, 1, 0);
		}

		// Token: 0x0600082C RID: 2092 RVA: 0x00033104 File Offset: 0x00031304
		private void BindOrUnbindMouseEvents(bool bind)
		{
			base.MouseEnter -= this.AdvancedGameControlWindow_MouseEnter;
			base.MouseLeave -= this.AdvancedGameControlWindow_MouseLeave;
			if (bind)
			{
				base.MouseEnter += this.AdvancedGameControlWindow_MouseEnter;
				base.MouseLeave += this.AdvancedGameControlWindow_MouseLeave;
			}
		}

		// Token: 0x0600082D RID: 2093 RVA: 0x000073DA File Offset: 0x000055DA
		private void AdvancedGameControlWindow_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			if (this.ParentWindow.IsActive)
			{
				this.ParentWindow.mFrontendHandler.ShowGLWindow();
			}
		}

		// Token: 0x0600082E RID: 2094 RVA: 0x00004BF2 File Offset: 0x00002DF2
		private void AdvancedGameControlWindow_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
		}

		// Token: 0x0600082F RID: 2095 RVA: 0x0003315C File Offset: 0x0003135C
		private void CustomWindow_Closing(object sender, CancelEventArgs evt)
		{
			if (KeymapCanvasWindow.sIsDirty)
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_BLUESTACKS_GAME_CONTROLS", false);
				customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_UNSAVED_CHANGES_CLOSE", false);
				customMessageWindow.AddButton(ButtonColors.Blue, LocaleStrings.GetLocalizedString("STRING_SAVE_CHANGE", false), delegate(object o, EventArgs e)
				{
					KMManager.SaveIMActions(false, false);
				}, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_DISCARD", false), delegate(object o, EventArgs e)
				{
					KeymapCanvasWindow.sIsDirty = false;
				}, null, false, null);
				customMessageWindow.CloseButtonHandle(delegate(object o, EventArgs e)
				{
					this.CanvasWindow.mIsClosing = false;
					evt.Cancel = true;
				}, null);
				customMessageWindow.Owner = this.CanvasWindow;
				customMessageWindow.ShowDialog();
			}
			this.CanvasWindow.SidebarWindowLeft = base.Left;
			this.CanvasWindow.SidebarWindowTop = base.Top;
			this.ParentWindow.Activate();
			this.ParentWindow.Utils.ToggleTopBarSidebarEnabled(true);
		}

		// Token: 0x06000830 RID: 2096 RVA: 0x00033284 File Offset: 0x00031484
		private void CustomWindow_Closed(object sender, EventArgs e)
		{
			this.CanvasWindow.SidebarWindow = null;
			if (KeymapCanvasWindow.sWasMaximized)
			{
				this.ParentWindow.MaximizeWindow();
			}
			else
			{
				this.ParentWindow.ChangeHeightWidthTopLeft(this.CanvasWindow.mParentWindowWidth, this.CanvasWindow.mParentWindowHeight, this.CanvasWindow.mParentWindowTop, this.CanvasWindow.mParentWindowLeft);
			}
			KeymapCanvasWindow.sWasMaximized = false;
			this.CanvasWindow.Close();
			if (RegistryManager.Instance.ShowKeyControlsOverlay)
			{
				KMManager.ShowOverlayWindow(this.ParentWindow, true, true);
			}
		}

		// Token: 0x06000831 RID: 2097 RVA: 0x00033314 File Offset: 0x00031514
		internal void Init(KeymapCanvasWindow window)
		{
			this.CanvasWindow = window;
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.mNCTransSlider.Value = RegistryManager.Instance.TranslucentControlsTransparency;
				this.mLastSavedSliderValue = this.mNCTransSlider.Value;
				this.mNCTransparencyLevel.Text = ((int)(this.mNCTransSlider.Value * 100.0)).ToString();
				if (RegistryManager.Instance.TranslucentControlsTransparency == 0.0)
				{
					this.mNCTranslucentControlsSliderButton.ImageName = "sidebar_overlay_inactive";
				}
				this.ParentWindow.mCommonHandler.OverlayStateChangedEvent += this.ParentWindow_OverlayStateChangedEvent;
			}
			else
			{
				this.mNCTransparencySlider.Visibility = Visibility.Collapsed;
			}
			this.FillProfileCombo();
			this.ProfileChanged();
			this.mSaveBtn.IsEnabled = false;
			this.mRevertBtn.IsEnabled = false;
		}

		// Token: 0x06000832 RID: 2098 RVA: 0x000333FC File Offset: 0x000315FC
		internal void InsertXYInScript(double x, double y)
		{
			string text = " " + x.ToString("00.00") + " " + y.ToString("00.00");
			int selectionStart = this.mScriptText.SelectionStart + text.Length;
			this.mScriptText.Text = this.mScriptText.Text.Insert(this.mScriptText.SelectionStart, text);
			this.mScriptText.SelectionStart = selectionStart;
		}

		// Token: 0x06000833 RID: 2099 RVA: 0x00033478 File Offset: 0x00031678
		internal void OrderingControlSchemes()
		{
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			this.ParentWindow.SelectedConfig.ControlSchemes.Sort(new Comparison<IMControlScheme>(this.CompareSchemesAlphabetically));
			foreach (IMControlScheme imcontrolScheme in new List<IMControlScheme>(this.ParentWindow.SelectedConfig.ControlSchemes))
			{
				if (imcontrolScheme.BuiltIn)
				{
					if (imcontrolScheme.IsBookMarked)
					{
						this.ParentWindow.SelectedConfig.ControlSchemes.Remove(imcontrolScheme);
						this.ParentWindow.SelectedConfig.ControlSchemes.Insert(num3, imcontrolScheme);
						num3++;
						num2++;
						num++;
					}
					else
					{
						this.ParentWindow.SelectedConfig.ControlSchemes.Remove(imcontrolScheme);
						this.ParentWindow.SelectedConfig.ControlSchemes.Insert(num2, imcontrolScheme);
						num2++;
						num++;
					}
				}
				else if (imcontrolScheme.IsBookMarked)
				{
					this.ParentWindow.SelectedConfig.ControlSchemes.Remove(imcontrolScheme);
					this.ParentWindow.SelectedConfig.ControlSchemes.Insert(num, imcontrolScheme);
					num++;
				}
			}
		}

		// Token: 0x06000834 RID: 2100 RVA: 0x000335CC File Offset: 0x000317CC
		private int CompareSchemesAlphabetically(IMControlScheme x, IMControlScheme y)
		{
			string text = x.Name.ToLower().Trim();
			string text2 = y.Name.ToLower().Trim();
			if (text.Contains(text2))
			{
				return 1;
			}
			if (text2.Contains(text))
			{
				return -1;
			}
			if (string.CompareOrdinal(text, text2) < 0)
			{
				return -1;
			}
			return 1;
		}

		// Token: 0x06000835 RID: 2101 RVA: 0x00033620 File Offset: 0x00031820
		public void FillProfileCombo()
		{
			this.OrderingControlSchemes();
			ComboBoxSchemeControl comboBoxSchemeControl = null;
			this.ParentWindow.SelectedConfig.ControlSchemesDict.Clear();
			this.mSchemeComboBox.Items.Children.Clear();
			AdvancedGameControlWindow.sBookmarkedSchemes.Clear();
			if (this.ParentWindow.SelectedConfig.ControlSchemes != null && this.ParentWindow.SelectedConfig.ControlSchemes.Count > 0)
			{
				this.mProfileHeader.Visibility = Visibility.Visible;
				foreach (IMControlScheme imcontrolScheme in this.ParentWindow.SelectedConfig.ControlSchemes)
				{
					ComboBoxSchemeControl comboBoxSchemeControl2 = new ComboBoxSchemeControl(this.CanvasWindow, this.ParentWindow);
					comboBoxSchemeControl2.mSchemeName.Text = LocaleStrings.GetLocalizedString(imcontrolScheme.Name, false);
					comboBoxSchemeControl2.IsEnabled = true;
					if (imcontrolScheme.Selected)
					{
						comboBoxSchemeControl = comboBoxSchemeControl2;
						BlueStacksUIBinding.BindColor(comboBoxSchemeControl2, System.Windows.Controls.Control.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
					}
					if (imcontrolScheme.BuiltIn)
					{
						comboBoxSchemeControl2.mEditImg.Visibility = Visibility.Hidden;
						comboBoxSchemeControl2.mDeleteImg.Visibility = Visibility.Hidden;
					}
					if (imcontrolScheme.IsBookMarked)
					{
						comboBoxSchemeControl2.mBookmarkImg.ImageName = "bookmarked";
						AdvancedGameControlWindow.sBookmarkedSchemes.Add(comboBoxSchemeControl2);
					}
					this.mSchemeComboBox.Items.Children.Add(comboBoxSchemeControl2);
					this.ParentWindow.SelectedConfig.ControlSchemesDict[imcontrolScheme.Name] = imcontrolScheme;
				}
				if (comboBoxSchemeControl == null)
				{
					comboBoxSchemeControl = (this.mSchemeComboBox.Items.Children[0] as ComboBoxSchemeControl);
					this.ParentWindow.SelectedConfig.ControlSchemesDict[comboBoxSchemeControl.mSchemeName.Text].Selected = true;
					this.FillProfileCombo();
					return;
				}
				this.mSchemeComboBox.SelectedItem = comboBoxSchemeControl.mSchemeName.Text.ToString();
				this.ParentWindow.SelectedConfig.SelectedControlScheme = this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeComboBox.SelectedItem];
				this.mSchemeComboBox.mName.Text = this.mSchemeComboBox.SelectedItem;
			}
			else
			{
				BlueStacksUIBinding.Bind(this.CanvasWindow.SidebarWindow.mSchemeComboBox.mName, "Custom", "");
			}
			if (this.ParentWindow.OriginalLoadedConfig.ControlSchemes != null && this.ParentWindow.OriginalLoadedConfig.ControlSchemes.Count > 0)
			{
				this.mExport.IsEnabled = true;
				return;
			}
			this.mExport.IsEnabled = false;
		}

		// Token: 0x06000836 RID: 2102 RVA: 0x000338D0 File Offset: 0x00031AD0
		private void TopBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			try
			{
				base.DragMove();
			}
			catch
			{
			}
		}

		// Token: 0x06000837 RID: 2103 RVA: 0x0000553B File Offset: 0x0000373B
		private void CustomPictureBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x06000838 RID: 2104 RVA: 0x000338F8 File Offset: 0x00031AF8
		private void RevertButton_Click(object sender, RoutedEventArgs e)
		{
			this.RestoreConfigToPreviousSavedState(true);
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.mNCTransSlider.Value = this.mLastSavedSliderValue;
				this.mNCTransparencyLevel.Text = ((int)(this.mNCTransSlider.Value * 100.0)).ToString();
				RegistryManager.Instance.TranslucentControlsTransparency = this.mNCTransSlider.Value;
				if (this.mNCTransSlider.Value == 0.0)
				{
					this.mNCTranslucentControlsSliderButton.ImageName = "sidebar_overlay_inactive";
					return;
				}
				this.mNCTranslucentControlsSliderButton.ImageName = "sidebar_overlay";
			}
		}

		// Token: 0x06000839 RID: 2105 RVA: 0x000339A4 File Offset: 0x00031BA4
		private void RestoreConfigToPreviousSavedState(bool showToast = true)
		{
			try
			{
				KeymapCanvasWindow.sIsDirty = false;
				GameControlWindow.sIsDirty = false;
				string inputmapperUserFilePath = KMManager.GetInputmapperUserFilePath("");
				if (File.Exists(inputmapperUserFilePath))
				{
					KMManager.SaveConfigToFile(inputmapperUserFilePath, this.ParentWindow.OriginalLoadedConfig);
				}
				this.CanvasWindow.ReloadCanvasWindow();
				this.FillProfileCombo();
				this.ProfileChanged();
				if (showToast)
				{
					this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_RESTORE_CHANGES", false));
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error while restoring config. err:" + ex.ToString());
			}
		}

		// Token: 0x0600083A RID: 2106 RVA: 0x000073F9 File Offset: 0x000055F9
		private void SaveButton_Click(object sender, RoutedEventArgs e)
		{
			KMManager.SaveIMActions(false, false);
			this.mLastSavedSliderValue = this.mNCTransSlider.Value;
			this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_SAVE_CHANGES", false));
		}

		// Token: 0x0600083B RID: 2107 RVA: 0x00033A38 File Offset: 0x00031C38
		internal void AddToastPopup(string message)
		{
			try
			{
				if (this.mToastPopup == null)
				{
					this.mToastPopup = new CustomToastPopupControl(this);
				}
				this.mToastPopup.Init(this, message, null, null, System.Windows.HorizontalAlignment.Center, VerticalAlignment.Bottom, null, 12, null, null, false);
				this.mToastPopup.ShowPopup(1.3);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in showing toast popup: " + ex.ToString());
			}
		}

		// Token: 0x0600083C RID: 2108 RVA: 0x00007424 File Offset: 0x00005624
		private void AdvancedSettingsItemPanel_Tap(object sender, EventArgs e)
		{
			this.AddAdvancedControlToCanvas(sender as AdvancedSettingsItemPanel, true);
			KeymapCanvasWindow.sIsDirty = true;
		}

		// Token: 0x0600083D RID: 2109 RVA: 0x00007439 File Offset: 0x00005639
		private void AdvancedSettingsItemPanel_MouseDragStart(object sender, EventArgs e)
		{
			this.AddAdvancedControlToCanvas(sender as AdvancedSettingsItemPanel, false);
			base.Cursor = System.Windows.Input.Cursors.Arrow;
		}

		// Token: 0x0600083E RID: 2110 RVA: 0x00033AC0 File Offset: 0x00031CC0
		private void AddAdvancedControlToCanvas(AdvancedSettingsItemPanel sender, bool isTap = false)
		{
			if (this.ParentWindow.SelectedConfig.ControlSchemes.Count == 0)
			{
				KMManager.AddNewControlSchemeAndSelect(null);
			}
			else if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
			}
			if (!isTap)
			{
				base.Focus();
				base.Cursor = System.Windows.Input.Cursors.Hand;
			}
			KeyActionType actionType = sender.ActionType;
			IMAction imaction = Assembly.GetExecutingAssembly().CreateInstance(actionType.ToString()) as IMAction;
			imaction.Type = actionType;
			KMManager.GetCanvasElement(imaction, this.mCanvas, false);
			if (isTap)
			{
				List<IMAction> lstAction = KMManager.ClearElement();
				this.CanvasWindow.AddNewCanvasElement(lstAction, true);
				KMManager.ClearElement();
			}
			sender.ReatchedMouseMove();
		}

		// Token: 0x0600083F RID: 2111 RVA: 0x00007453 File Offset: 0x00005653
		private void mCanvas_PreviewMouseMove(object sender, System.Windows.Input.MouseEventArgs e)
		{
			KMManager.RepositionCanvasElement();
		}

		// Token: 0x06000840 RID: 2112 RVA: 0x0000745A File Offset: 0x0000565A
		private void mCanvas_MouseUp(object sender, MouseButtonEventArgs e)
		{
			base.Cursor = System.Windows.Input.Cursors.Arrow;
			KMManager.ClearElement();
		}

		// Token: 0x06000841 RID: 2113 RVA: 0x00033B88 File Offset: 0x00031D88
		private void mButtonsGrid_Loaded(object sender, RoutedEventArgs e)
		{
			base.MaxWidth = ((this.mButtonsGrid.ActualWidth < 320.0) ? 320.0 : this.mButtonsGrid.ActualWidth);
			base.MinWidth = base.MaxWidth;
			this.CustomWindow_IsVisibleChanged(null, default(DependencyPropertyChangedEventArgs));
			base.Left = ((this.CanvasWindow.SidebarWindowLeft == -1.0) ? (this.ParentWindow.Left + this.ParentWindow.ActualWidth - (double)(this.ParentWindow.EngineInstanceRegistry.IsSidebarVisible ? 60 : 0)) : this.CanvasWindow.SidebarWindowLeft);
			base.Top = ((this.CanvasWindow.SidebarWindowTop == -1.0) ? this.ParentWindow.Top : this.CanvasWindow.SidebarWindowTop);
			base.Height = this.ParentWindow.ActualHeight;
			Screen screen = Screen.FromHandle(new WindowInteropHelper(this).Handle);
			double sScalingFactor = MainWindow.sScalingFactor;
			Rectangle rectangle = new Rectangle((int)((double)screen.WorkingArea.X / sScalingFactor), (int)((double)screen.WorkingArea.Y / sScalingFactor), (int)((double)screen.WorkingArea.Width / sScalingFactor), (int)((double)screen.WorkingArea.Height / sScalingFactor));
			Rectangle rect = new Rectangle(new System.Drawing.Point((int)base.Left, (int)base.Top), new System.Drawing.Size((int)base.ActualWidth, (int)base.ActualHeight));
			if (!rectangle.Contains(rect))
			{
				base.Left = (double)rectangle.Width - base.Width;
			}
		}

		// Token: 0x06000842 RID: 2114 RVA: 0x00004BF2 File Offset: 0x00002DF2
		private void CustomWindow_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
		}

		// Token: 0x06000843 RID: 2115 RVA: 0x00033D38 File Offset: 0x00031F38
		public void ProfileChanged()
		{
			if (this.mSchemeComboBox.SelectedItem != null)
			{
				string selectedItem = this.mSchemeComboBox.SelectedItem;
				if (this.ParentWindow.SelectedConfig.ControlSchemesDict.ContainsKey(selectedItem))
				{
					if (!this.ParentWindow.SelectedConfig.ControlSchemesDict[selectedItem].Selected)
					{
						this.ParentWindow.SelectedConfig.SelectedControlScheme.Selected = false;
						foreach (object obj in this.mSchemeComboBox.Items.Children)
						{
							ComboBoxSchemeControl comboBoxSchemeControl = (ComboBoxSchemeControl)obj;
							if (comboBoxSchemeControl.mSchemeName.Text == this.ParentWindow.SelectedConfig.SelectedControlScheme.Name)
							{
								BlueStacksUIBinding.BindColor(comboBoxSchemeControl, System.Windows.Controls.Control.BackgroundProperty, "ComboBoxBackgroundColor");
								break;
							}
						}
						this.ParentWindow.SelectedConfig.SelectedControlScheme = this.ParentWindow.SelectedConfig.ControlSchemesDict[selectedItem];
						this.ParentWindow.SelectedConfig.SelectedControlScheme.Selected = true;
						KeymapCanvasWindow.sIsDirty = true;
					}
					this.CanvasWindow.Init();
				}
			}
		}

		// Token: 0x06000844 RID: 2116 RVA: 0x0000746D File Offset: 0x0000566D
		private void CustomWindow_Loaded(object sender, RoutedEventArgs e)
		{
			base.Activate();
		}

		// Token: 0x06000845 RID: 2117 RVA: 0x00005628 File Offset: 0x00003828
		private void Grid_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, System.Windows.Controls.Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x06000846 RID: 2118 RVA: 0x000046FF File Offset: 0x000028FF
		private void Grid_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			(sender as Grid).Background = System.Windows.Media.Brushes.Transparent;
		}

		// Token: 0x06000847 RID: 2119 RVA: 0x00033E88 File Offset: 0x00032088
		private void mExportGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			ClientStats.SendMiscellaneousStatsAsync("ExportKeymappingClicked", RegistryManager.Instance.UserGuid, KMManager.sPackageName, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, RegistryManager.Instance.RegisteredEmail, null, null);
			SaveFileDialog saveFileDialog = new SaveFileDialog
			{
				Filter = "BlueStacks config file (*.cfg)|*.cfg",
				FilterIndex = 1,
				RestoreDirectory = true,
				FileName = KMManager.sPackageName + ".cfg"
			};
			if (saveFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
			{
				string fullPath = Path.GetFullPath(saveFileDialog.FileName);
				if (Path.GetExtension(saveFileDialog.FileName) == ".cfg")
				{
					if (File.Exists(fullPath))
					{
						File.Delete(fullPath);
					}
					File.Copy(KMManager.GetInputmapperFile(KMManager.sPackageName), fullPath, true);
					this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_CONTROLS_EXPORTED", false));
					return;
				}
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_INVALID_PATH", "");
				customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_INVALID_PATH", false);
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
			}
		}

		// Token: 0x06000848 RID: 2120 RVA: 0x00033FDC File Offset: 0x000321DC
		private void mImportGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			ClientStats.SendMiscellaneousStatsAsync("ImportKeymappingClicked", RegistryManager.Instance.UserGuid, KMManager.sPackageName, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, RegistryManager.Instance.RegisteredEmail, null, null);
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_IMPORT_CONTROLS_TITLE", "");
			customMessageWindow.AddButton(ButtonColors.Blue, "STRING_CONTINUE", new EventHandler(this.ImportControlConfirmationHandler), null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
			customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_IMPORT_CONTROL_MESSAGE", false) + Environment.NewLine + LocaleStrings.GetLocalizedString("STRING_IMPORT_CONTROL_MESSAGE1", false);
			this.ParentWindow.ShowDimOverlay(null);
			customMessageWindow.Owner = KMManager.CanvasWindow;
			customMessageWindow.ShowDialog();
			this.ParentWindow.HideDimOverlay();
		}

		// Token: 0x06000849 RID: 2121 RVA: 0x00007476 File Offset: 0x00005676
		private void ImportControlConfirmationHandler(object sender, EventArgs e)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					OpenFileDialog openFileDialog = new OpenFileDialog
					{
						Filter = "BlueStacks config file (*.cfg)|*.cfg",
						RestoreDirectory = true
					};
					if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
					{
						try
						{
							this.GetBackUpOfCurrentUserCfgFile();
							Logger.Info("CFg file Selected : " + openFileDialog.FileName);
							string text = Path.Combine(Path.Combine(RegistryStrings.InputMapperFolder, "UserFiles"), KMManager.sPackageName + ".cfg");
							File.Copy(openFileDialog.FileName, text, true);
							if (!KMManager.IsValidCfg(text))
							{
								File.Delete(text);
								this.RestoreToPreviousState();
								this.ShowImportErrorPopup();
							}
							else
							{
								KeymapCanvasWindow.sIsDirty = true;
								GameControlWindow.sIsDirty = true;
								this.CanvasWindow.ReloadCanvasWindow();
								this.Init(this.CanvasWindow);
								KMManager.SaveIMActions(false, false);
								this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_CONTROLS_IMPORTED", false));
								this.RestoreOrDeleteCfgBackUpFile(false);
							}
						}
						catch (Exception arg)
						{
							Logger.Error("Exception in import cfg files" + arg);
						}
					}
				}), new object[0]);
			});
		}

		// Token: 0x0600084A RID: 2122 RVA: 0x000340C4 File Offset: 0x000322C4
		private void RestoreToPreviousState()
		{
			try
			{
				string text = Path.Combine(Path.Combine(RegistryStrings.InputMapperFolder, "UserFiles"), KMManager.sPackageName + ".bak");
				if (File.Exists(text))
				{
					File.Move(text, Path.ChangeExtension(text, ".cfg"));
					this.CanvasWindow.ReloadCanvasWindow();
					this.Init(this.CanvasWindow);
					KMManager.SaveIMActions(true, false);
				}
				else
				{
					this.RestoreConfigToPreviousSavedState(false);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Delete or restore back up cfg file: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x0600084B RID: 2123 RVA: 0x00034160 File Offset: 0x00032360
		private void GetBackUpOfCurrentUserCfgFile()
		{
			try
			{
				string inputmapperUserFilePath = KMManager.GetInputmapperUserFilePath("");
				if (File.Exists(inputmapperUserFilePath))
				{
					File.Move(inputmapperUserFilePath, Path.ChangeExtension(inputmapperUserFilePath, ".bak"));
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in backup cfg file: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x0600084C RID: 2124 RVA: 0x000341BC File Offset: 0x000323BC
		private void RestoreOrDeleteCfgBackUpFile(bool isRestore)
		{
			try
			{
				string text = Path.Combine(Path.Combine(RegistryStrings.InputMapperFolder, "UserFiles"), KMManager.sPackageName + ".bak");
				if (File.Exists(text))
				{
					if (isRestore)
					{
						File.Move(text, Path.ChangeExtension(text, ".cfg"));
					}
					else
					{
						File.Delete(text);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Delete or restore back up cfg file: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x0600084D RID: 2125 RVA: 0x0003423C File Offset: 0x0003243C
		private void ShowImportErrorPopup()
		{
			try
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_UNSUPPORTED_FILE_FORMAT", "");
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_IMPORT_ANOTHER", new EventHandler(this.ImportControlConfirmationHandler), null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
				customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_IMPORT_ERROE_MESSAGE", false) + Environment.NewLine + LocaleStrings.GetLocalizedString("STRING_IMPORT_ERROR_MESSAGE1", false);
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.Owner = KMManager.CanvasWindow;
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x0600084E RID: 2126 RVA: 0x000342F8 File Offset: 0x000324F8
		private void CustomWindow_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			string text = string.Empty;
			if (e.Key != Key.None)
			{
				if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
				{
					text = IMAPKeys.GetStringForFile(Key.LeftCtrl) + " + ";
				}
				if (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt))
				{
					text = text + IMAPKeys.GetStringForFile(Key.LeftAlt) + " + ";
				}
				if (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift))
				{
					text = text + IMAPKeys.GetStringForFile(Key.LeftShift) + " + ";
				}
				text += IMAPKeys.GetStringForFile(e.Key);
			}
			Logger.Debug("SHORTCUT: KeyPressed.." + text);
			if (this.ParentWindow.mCommonHandler.mShortcutsConfigInstance != null)
			{
				foreach (ShortcutKeys shortcutKeys in this.ParentWindow.mCommonHandler.mShortcutsConfigInstance.Shortcut)
				{
					if (shortcutKeys.ShortcutKey.Equals(text) && shortcutKeys.ShortcutName.Equals("STRING_TOGGLE_KEYMAP_WINDOW"))
					{
						KMManager.HideKeymapWindowIfInView();
					}
				}
			}
		}

		// Token: 0x0600084F RID: 2127 RVA: 0x0003442C File Offset: 0x0003262C
		private void OpenFolder_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			try
			{
				Process process = new Process();
				process.StartInfo.UseShellExecute = true;
				if (!Directory.Exists(Path.Combine(RegistryStrings.InputMapperFolder, "UserFiles")))
				{
					process.StartInfo.FileName = RegistryStrings.InputMapperFolder;
				}
				else
				{
					process.StartInfo.FileName = Path.Combine(RegistryStrings.InputMapperFolder, "UserFiles");
				}
				process.Start();
			}
			catch (Exception ex)
			{
				Logger.Error("Some error in Open folder err: " + ex.ToString());
			}
		}

		// Token: 0x06000850 RID: 2128 RVA: 0x000344C0 File Offset: 0x000326C0
		private void ExportBtn_Click(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow.OriginalLoadedConfig.ControlSchemes.Count > 0)
			{
				this.mOverlayGrid.Visibility = Visibility.Visible;
				if (this.mExportSchemesWindow == null)
				{
					this.mExportSchemesWindow = new ExportSchemesWindow(this.CanvasWindow, this.ParentWindow)
					{
						Owner = this
					};
					this.mExportSchemesWindow.Init();
					this.mExportSchemesWindow.Show();
					return;
				}
			}
			else
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_SCHEME_AVAILABLE", false), 1.3, false);
			}
		}

		// Token: 0x06000851 RID: 2129 RVA: 0x00034554 File Offset: 0x00032754
		private void ImportBtn_Click(object sender, MouseButtonEventArgs e)
		{
			this.mOverlayGrid.Visibility = Visibility.Visible;
			using (OpenFileDialog openFileDialog = new OpenFileDialog())
			{
				openFileDialog.Multiselect = true;
				openFileDialog.Filter = "Cfg files (*.cfg)|*.cfg";
				if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
				{
					this.mImportSchemesWindow = new ImportSchemesWindow(this.CanvasWindow, this.ParentWindow)
					{
						Owner = this
					};
					this.mImportSchemesWindow.Init(openFileDialog.FileName);
					this.mImportSchemesWindow.Show();
				}
				else
				{
					this.mOverlayGrid.Visibility = Visibility.Hidden;
					this.mImportSchemesWindow = null;
					base.Focus();
				}
			}
		}

		// Token: 0x06000852 RID: 2130 RVA: 0x00034600 File Offset: 0x00032800
		private void CancelBtn_Click(object sender, RoutedEventArgs e)
		{
			ClientStats.SendMiscellaneousStatsAsync("RestoreDefaultKeymappingClicked", RegistryManager.Instance.UserGuid, KMManager.sPackageName, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, RegistryManager.Instance.RegisteredEmail, null, null);
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("Bluestacks", false);
			customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_CANCEL_CONFIG_CHANGES", false);
			customMessageWindow.AddButton(ButtonColors.Red, LocaleStrings.GetLocalizedString("STRING_YES", false), delegate(object o, EventArgs evt)
			{
				this.RestoreConfigToPreviousSavedState(true);
				this.CloseWindow();
			}, null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_NO", false), delegate(object o, EventArgs evt)
			{
				KeymapCanvasWindow.sIsDirty = false;
				GameControlWindow.sIsDirty = false;
				this.CloseWindow();
			}, null, false, null);
			customMessageWindow.CloseButtonHandle(null, null);
			customMessageWindow.Owner = this.CanvasWindow;
			customMessageWindow.ShowDialog();
		}

		// Token: 0x06000853 RID: 2131 RVA: 0x0000748A File Offset: 0x0000568A
		private void mCloseScriptButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ToggleAGCWindowVisiblity(false);
			this.PopulateScriptTextBox();
			ClientStats.SendKeyMappingUIStatsAsync("button_clicked", KMManager.sPackageName, "script_close_click");
		}

		// Token: 0x06000854 RID: 2132 RVA: 0x000346E0 File Offset: 0x000328E0
		private void PopulateScriptTextBox()
		{
			if (this.mLastScriptActionItem != null)
			{
				IMAction imaction = this.mLastScriptActionItem.First<IMAction>();
				if (imaction.Type == KeyActionType.Script)
				{
					string text = string.Join(Environment.NewLine, (imaction as Script).Commands);
					this.mScriptText.Text = text;
					KeymapCanvasWindow.sIsDirty = true;
				}
			}
		}

		// Token: 0x06000855 RID: 2133 RVA: 0x000074AD File Offset: 0x000056AD
		private void ShowHelpHyperlink_Click(object sender, RoutedEventArgs e)
		{
			BlueStacksUIUtils.OpenUrl(WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/help_articles") + "&article=keymapping_script_faq");
		}

		// Token: 0x06000856 RID: 2134 RVA: 0x00034734 File Offset: 0x00032934
		private void mDoneScriptButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ToggleAGCWindowVisiblity(false);
			if (this.mLastScriptActionItem != null)
			{
				IMAction imaction = this.mLastScriptActionItem.First<IMAction>();
				if (imaction.Type == KeyActionType.Script)
				{
					string[] commands = this.mScriptText.Text.Split(new string[]
					{
						Environment.NewLine
					}, StringSplitOptions.None);
					(imaction as Script).Commands = commands;
				}
			}
			ClientStats.SendKeyMappingUIStatsAsync("button_clicked", KMManager.sPackageName, "script_done_click");
		}

		// Token: 0x06000857 RID: 2135 RVA: 0x000074D2 File Offset: 0x000056D2
		internal void UpdateXYCoordinates(double x, double y)
		{
			this.mXYCurrentCoordinatesText.Text = "X: " + x.ToString("00.00") + " Y: " + y.ToString("00.00");
		}

		// Token: 0x06000858 RID: 2136 RVA: 0x00004BF2 File Offset: 0x00002DF2
		internal void LoadScriptText(string tag)
		{
		}

		// Token: 0x06000859 RID: 2137 RVA: 0x000347A8 File Offset: 0x000329A8
		private void NCTranslucentControlsSliderButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mNCTransSlider.Value == 0.0)
			{
				this.mNCTransSlider.Value = this.mLastSliderValue;
				this.mNCTransparencyLevel.Text = ((int)(this.mNCTransSlider.Value * 100.0)).ToString();
				if (this.mLastSliderValue > 0.0)
				{
					this.mNCTranslucentControlsSliderButton.ImageName = "sidebar_overlay";
				}
				RegistryManager.Instance.ShowKeyControlsOverlay = true;
			}
			else
			{
				this.mNCTranslucentControlsSliderButton.ImageName = "sidebar_overlay_inactive";
				double value = this.mNCTransSlider.Value;
				this.mNCTransSlider.Value = 0.0;
				this.mNCTransparencyLevel.Text = ((int)(this.mNCTransSlider.Value * 100.0)).ToString();
				this.mLastSliderValue = value;
				RegistryManager.Instance.ShowKeyControlsOverlay = false;
			}
			KeymapCanvasWindow.sIsDirty = true;
		}

		// Token: 0x0600085A RID: 2138 RVA: 0x000348A4 File Offset: 0x00032AA4
		private void NCTransparencySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			KMManager.ChangeTransparency(this.ParentWindow, this.mNCTransSlider.Value);
			if (this.mNCTransSlider.Value == 0.0)
			{
				this.ParentWindow_OverlayStateChangedEvent(false);
			}
			else
			{
				this.ParentWindow_OverlayStateChangedEvent(true);
			}
			this.mLastSliderValue = this.mNCTransSlider.Value;
			this.mNCTransparencyLevel.Text = ((int)(this.mNCTransSlider.Value * 100.0)).ToString();
			if (this.mNCTransSlider.Value != RegistryManager.Instance.TranslucentControlsTransparency)
			{
				KeymapCanvasWindow.sIsDirty = true;
			}
		}

		// Token: 0x0600085B RID: 2139 RVA: 0x00034944 File Offset: 0x00032B44
		public void ParentWindow_OverlayStateChangedEvent(bool isEnabled)
		{
			if (isEnabled)
			{
				this.mNCTranslucentControlsSliderButton.ImageName = "sidebar_overlay";
				if (RegistryManager.Instance.TranslucentControlsTransparency == 0.0 && this.mLastSliderValue == 0.0)
				{
					RegistryManager.Instance.TranslucentControlsTransparency = 0.5;
					this.mNCTransSlider.Value = 0.5;
					this.mNCTransparencyLevel.Text = ((int)(this.mNCTransSlider.Value * 100.0)).ToString();
				}
				else if (this.mNCTransSlider.Value == 0.0)
				{
					RegistryManager.Instance.TranslucentControlsTransparency = this.mLastSliderValue;
				}
				else
				{
					RegistryManager.Instance.TranslucentControlsTransparency = this.mNCTransSlider.Value;
				}
				RegistryManager.Instance.ShowKeyControlsOverlay = true;
				return;
			}
			this.mNCTranslucentControlsSliderButton.ImageName = "sidebar_overlay_inactive";
			RegistryManager.Instance.TranslucentControlsTransparency = 0.0;
			double value = this.mNCTransSlider.Value;
			this.mNCTransSlider.Value = 0.0;
			this.mNCTransparencyLevel.Text = "0";
			this.mLastSliderValue = value;
			RegistryManager.Instance.ShowKeyControlsOverlay = false;
		}

		// Token: 0x0600085C RID: 2140 RVA: 0x00007506 File Offset: 0x00005706
		private void BrowserHelp_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			base.Cursor = System.Windows.Input.Cursors.Hand;
		}

		// Token: 0x0600085D RID: 2141 RVA: 0x00007513 File Offset: 0x00005713
		private void BrowserHelp_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			base.Cursor = System.Windows.Input.Cursors.Arrow;
		}

		// Token: 0x0600085E RID: 2142 RVA: 0x00007520 File Offset: 0x00005720
		private void Export_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (this.mExport.IsEnabled)
			{
				this.mExport.Opacity = 1.0;
				return;
			}
			this.mExport.Opacity = 0.4;
		}

		// Token: 0x0600085F RID: 2143 RVA: 0x00007558 File Offset: 0x00005758
		private void KeySequenceScriptGrid_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.KeySequenceScriptGrid.Visibility == Visibility.Visible && !this.mScriptText.IsMouseOver)
			{
				this.mAdvancedGameControlBorder.Focus();
			}
		}

		// Token: 0x06000860 RID: 2144 RVA: 0x00007580 File Offset: 0x00005780
		private void BrowserHelp_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			BlueStacksUIUtils.OpenUrl(WebHelper.GetUrlWithParams(string.Format("{0}/{1}", WebHelper.GetServerHost(), "help_articles")) + "&article=advanced_game_control");
		}

		// Token: 0x06000861 RID: 2145 RVA: 0x000075AA File Offset: 0x000057AA
		private void RevertBtn_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			this.FitEnlargedButtonText(this.mRevertBtn);
			this.FitEnlargedButtonText(this.mSaveBtn);
		}

		// Token: 0x06000862 RID: 2146 RVA: 0x00034A90 File Offset: 0x00032C90
		private void FitEnlargedButtonText(CustomButton button)
		{
			double num = 125.0;
			DataTemplate contentTemplate = button.Resources["TextContentTemplate"] as DataTemplate;
			button.ContentTemplate = contentTemplate;
			ContentPresenter contentPresenter = WpfUtils.FindVisualChild<ContentPresenter>(button);
			contentPresenter.ApplyTemplate();
			TextBlock textBlock = (TextBlock)contentPresenter.ContentTemplate.FindName("wrapTextBlock", contentPresenter);
			textBlock.FontSize = 15.0;
			textBlock.TextWrapping = TextWrapping.NoWrap;
			textBlock.TextTrimming = TextTrimming.CharacterEllipsis;
			textBlock.FlowDirection = System.Windows.FlowDirection.LeftToRight;
			Typeface typeface = new Typeface(textBlock.FontFamily, textBlock.FontStyle, textBlock.FontWeight, textBlock.FontStretch);
			if (new FormattedText(textBlock.Text, Thread.CurrentThread.CurrentCulture, textBlock.FlowDirection, typeface, textBlock.FontSize, textBlock.Foreground).WidthIncludingTrailingWhitespace > num)
			{
				BlueStacksUIBinding.Bind(button, textBlock.Text, FrameworkElement.ToolTipProperty);
			}
			textBlock.MaxWidth = num;
		}

		// Token: 0x06000863 RID: 2147 RVA: 0x00034B78 File Offset: 0x00032D78
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/advancedgamecontrolwindow.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000864 RID: 2148 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000865 RID: 2149 RVA: 0x00034BA8 File Offset: 0x00032DA8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((AdvancedGameControlWindow)target).Loaded += this.CustomWindow_Loaded;
				((AdvancedGameControlWindow)target).Closing += this.CustomWindow_Closing;
				((AdvancedGameControlWindow)target).Closed += this.CustomWindow_Closed;
				((AdvancedGameControlWindow)target).IsVisibleChanged += this.CustomWindow_IsVisibleChanged;
				((AdvancedGameControlWindow)target).KeyDown += this.CustomWindow_KeyDown;
				return;
			case 2:
				this.mAdvancedGameControlBorder = (Border)target;
				this.mAdvancedGameControlBorder.PreviewMouseDown += this.KeySequenceScriptGrid_PreviewMouseDown;
				return;
			case 3:
				this.PrimaryGrid = (Grid)target;
				return;
			case 4:
				((Grid)target).MouseLeftButtonDown += this.TopBar_MouseLeftButtonDown;
				return;
			case 5:
				((TextBlock)target).MouseLeftButtonDown += this.TopBar_MouseLeftButtonDown;
				return;
			case 6:
				this.mCloseSideBarWindow = (CustomPictureBox)target;
				this.mCloseSideBarWindow.MouseDown += this.CustomPictureBox_MouseDown;
				this.mCloseSideBarWindow.MouseLeftButtonUp += this.CloseButton_MouseLeftButtonUp;
				return;
			case 7:
				this.mProfileHeader = (TextBlock)target;
				return;
			case 8:
				this.mImport = (CustomPictureBox)target;
				this.mImport.MouseLeftButtonUp += this.ImportBtn_Click;
				return;
			case 9:
				this.mExport = (CustomPictureBox)target;
				this.mExport.IsEnabledChanged += this.Export_IsEnabledChanged;
				this.mExport.MouseLeftButtonUp += this.ExportBtn_Click;
				return;
			case 10:
				this.mOpenFolder = (CustomPictureBox)target;
				this.mOpenFolder.MouseLeftButtonUp += this.OpenFolder_MouseLeftButtonUp;
				return;
			case 11:
				this.mSchemeComboBox = (SchemeComboBox)target;
				return;
			case 12:
				this.mBrowserHelp = (CustomPictureBox)target;
				this.mBrowserHelp.MouseEnter += this.BrowserHelp_MouseEnter;
				this.mBrowserHelp.MouseLeave += this.BrowserHelp_MouseLeave;
				this.mBrowserHelp.MouseLeftButtonUp += this.BrowserHelp_MouseLeftButtonUp;
				return;
			case 13:
				this.mPrimitivesPanel = (WrapPanel)target;
				return;
			case 14:
				this.mTapPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 15:
				this.mTapRepeatPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 16:
				this.mDpadPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 17:
				this.mPanPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 18:
				this.mZoomPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 19:
				this.mMOBASkillPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 20:
				this.mSwipePrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 21:
				this.mFreeLookPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 22:
				this.mTiltPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 23:
				this.mStatePrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 24:
				this.mScriptPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 25:
				this.mNCTransparencySlider = (Grid)target;
				return;
			case 26:
				this.mNCTransparencyLevel = (CustomTextBox)target;
				return;
			case 27:
				this.mNCTranslucentControlsSliderButton = (CustomPictureBox)target;
				this.mNCTranslucentControlsSliderButton.PreviewMouseLeftButtonUp += this.NCTranslucentControlsSliderButton_PreviewMouseLeftButtonUp;
				return;
			case 28:
				this.mNCTransSlider = (Slider)target;
				this.mNCTransSlider.ValueChanged += this.NCTransparencySlider_ValueChanged;
				return;
			case 29:
				this.mButtonsGrid = (Grid)target;
				this.mButtonsGrid.Loaded += this.mButtonsGrid_Loaded;
				return;
			case 30:
				this.mRevertBtn = (CustomButton)target;
				this.mRevertBtn.Click += this.RevertButton_Click;
				this.mRevertBtn.SizeChanged += this.RevertBtn_SizeChanged;
				return;
			case 31:
				this.mSaveBtn = (CustomButton)target;
				this.mSaveBtn.Click += this.SaveButton_Click;
				return;
			case 32:
				this.mCanvas = (Canvas)target;
				this.mCanvas.PreviewMouseMove += this.mCanvas_PreviewMouseMove;
				this.mCanvas.PreviewMouseUp += this.mCanvas_MouseUp;
				return;
			case 33:
				this.mOverlayGrid = (Grid)target;
				return;
			case 34:
				this.KeySequenceScriptGrid = (Grid)target;
				return;
			case 35:
				this.mScriptHeaderGrid = (Grid)target;
				this.mScriptHeaderGrid.MouseLeftButtonDown += this.TopBar_MouseLeftButtonDown;
				return;
			case 36:
				this.mHeaderText = (TextBlock)target;
				return;
			case 37:
				this.mCloseScriptWindow = (CustomPictureBox)target;
				this.mCloseScriptWindow.MouseDown += this.CustomPictureBox_MouseDown;
				this.mCloseScriptWindow.MouseLeftButtonUp += this.mCloseScriptButton_MouseLeftButtonUp;
				return;
			case 38:
				this.mSubheadingText = (TextBlock)target;
				return;
			case 39:
				this.mScriptText = (CustomTextBox)target;
				return;
			case 40:
				this.mXYCurrentCoordinatesText = (TextBlock)target;
				return;
			case 41:
				((Hyperlink)target).Click += this.ShowHelpHyperlink_Click;
				return;
			case 42:
				this.mShowHelpHyperlink = (TextBlock)target;
				return;
			case 43:
				this.mFooterGrid = (Grid)target;
				return;
			case 44:
				this.mFooterText = (TextBlock)target;
				return;
			case 45:
				this.mKeySeqDoneButton = (CustomButton)target;
				this.mKeySeqDoneButton.PreviewMouseLeftButtonUp += this.mDoneScriptButton_MouseLeftButtonUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040005CD RID: 1485
		private MainWindow ParentWindow;

		// Token: 0x040005CE RID: 1486
		internal KeymapCanvasWindow CanvasWindow;

		// Token: 0x040005CF RID: 1487
		public static List<ComboBoxSchemeControl> sBookmarkedSchemes = new List<ComboBoxSchemeControl>();

		// Token: 0x040005D0 RID: 1488
		private CustomToastPopupControl mToastPopup;

		// Token: 0x040005D1 RID: 1489
		internal ExportSchemesWindow mExportSchemesWindow;

		// Token: 0x040005D2 RID: 1490
		internal ImportSchemesWindow mImportSchemesWindow;

		// Token: 0x040005D3 RID: 1491
		internal double mLastSliderValue;

		// Token: 0x040005D4 RID: 1492
		internal double mLastSavedSliderValue;

		// Token: 0x040005D5 RID: 1493
		internal Dictionary<string, string> mScriptModeDictionary = new Dictionary<string, string>();

		// Token: 0x040005D6 RID: 1494
		internal List<IMAction> mLastScriptActionItem;

		// Token: 0x040005D7 RID: 1495
		internal Border mAdvancedGameControlBorder;

		// Token: 0x040005D8 RID: 1496
		internal Grid PrimaryGrid;

		// Token: 0x040005D9 RID: 1497
		internal CustomPictureBox mCloseSideBarWindow;

		// Token: 0x040005DA RID: 1498
		internal TextBlock mProfileHeader;

		// Token: 0x040005DB RID: 1499
		internal CustomPictureBox mImport;

		// Token: 0x040005DC RID: 1500
		internal CustomPictureBox mExport;

		// Token: 0x040005DD RID: 1501
		internal CustomPictureBox mOpenFolder;

		// Token: 0x040005DE RID: 1502
		internal SchemeComboBox mSchemeComboBox;

		// Token: 0x040005DF RID: 1503
		internal CustomPictureBox mBrowserHelp;

		// Token: 0x040005E0 RID: 1504
		internal WrapPanel mPrimitivesPanel;

		// Token: 0x040005E1 RID: 1505
		internal AdvancedSettingsItemPanel mTapPrimitive;

		// Token: 0x040005E2 RID: 1506
		internal AdvancedSettingsItemPanel mTapRepeatPrimitive;

		// Token: 0x040005E3 RID: 1507
		internal AdvancedSettingsItemPanel mDpadPrimitive;

		// Token: 0x040005E4 RID: 1508
		internal AdvancedSettingsItemPanel mPanPrimitive;

		// Token: 0x040005E5 RID: 1509
		internal AdvancedSettingsItemPanel mZoomPrimitive;

		// Token: 0x040005E6 RID: 1510
		internal AdvancedSettingsItemPanel mMOBASkillPrimitive;

		// Token: 0x040005E7 RID: 1511
		internal AdvancedSettingsItemPanel mSwipePrimitive;

		// Token: 0x040005E8 RID: 1512
		internal AdvancedSettingsItemPanel mFreeLookPrimitive;

		// Token: 0x040005E9 RID: 1513
		internal AdvancedSettingsItemPanel mTiltPrimitive;

		// Token: 0x040005EA RID: 1514
		internal AdvancedSettingsItemPanel mStatePrimitive;

		// Token: 0x040005EB RID: 1515
		internal AdvancedSettingsItemPanel mScriptPrimitive;

		// Token: 0x040005EC RID: 1516
		internal Grid mNCTransparencySlider;

		// Token: 0x040005ED RID: 1517
		internal CustomTextBox mNCTransparencyLevel;

		// Token: 0x040005EE RID: 1518
		internal CustomPictureBox mNCTranslucentControlsSliderButton;

		// Token: 0x040005EF RID: 1519
		internal Slider mNCTransSlider;

		// Token: 0x040005F0 RID: 1520
		internal Grid mButtonsGrid;

		// Token: 0x040005F1 RID: 1521
		internal CustomButton mRevertBtn;

		// Token: 0x040005F2 RID: 1522
		internal CustomButton mSaveBtn;

		// Token: 0x040005F3 RID: 1523
		internal Canvas mCanvas;

		// Token: 0x040005F4 RID: 1524
		internal Grid mOverlayGrid;

		// Token: 0x040005F5 RID: 1525
		internal Grid KeySequenceScriptGrid;

		// Token: 0x040005F6 RID: 1526
		internal Grid mScriptHeaderGrid;

		// Token: 0x040005F7 RID: 1527
		internal TextBlock mHeaderText;

		// Token: 0x040005F8 RID: 1528
		internal CustomPictureBox mCloseScriptWindow;

		// Token: 0x040005F9 RID: 1529
		internal TextBlock mSubheadingText;

		// Token: 0x040005FA RID: 1530
		internal CustomTextBox mScriptText;

		// Token: 0x040005FB RID: 1531
		internal TextBlock mXYCurrentCoordinatesText;

		// Token: 0x040005FC RID: 1532
		internal TextBlock mShowHelpHyperlink;

		// Token: 0x040005FD RID: 1533
		internal Grid mFooterGrid;

		// Token: 0x040005FE RID: 1534
		internal TextBlock mFooterText;

		// Token: 0x040005FF RID: 1535
		internal CustomButton mKeySeqDoneButton;

		// Token: 0x04000600 RID: 1536
		private bool _contentLoaded;
	}
}
