﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200002B RID: 43
	public partial class AppTabButton : Button
	{
		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x06000246 RID: 582 RVA: 0x000038F1 File Offset: 0x00001AF1
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x06000247 RID: 583 RVA: 0x00003912 File Offset: 0x00001B12
		// (set) Token: 0x06000248 RID: 584 RVA: 0x0000391A File Offset: 0x00001B1A
		internal bool IsCursorClipped { get; set; }

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x06000249 RID: 585 RVA: 0x00003923 File Offset: 0x00001B23
		// (set) Token: 0x0600024A RID: 586 RVA: 0x0000392B File Offset: 0x00001B2B
		public bool IsPortraitModeTab
		{
			get
			{
				return this.mIsPortraitModeTab;
			}
			set
			{
				this.mIsPortraitModeTab = value;
				if (this.IsSelected && this.ParentWindow.IsUIInPortraitMode != this.mIsPortraitModeTab)
				{
					this.ParentWindow.SwitchToPortraitMode(this.mIsPortraitModeTab);
				}
			}
		}

		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x0600024B RID: 587 RVA: 0x00003960 File Offset: 0x00001B60
		// (set) Token: 0x0600024C RID: 588 RVA: 0x00003968 File Offset: 0x00001B68
		public bool IsMoreTabsButton
		{
			get
			{
				return this.mIsMoreTabsButton;
			}
			set
			{
				this.mIsMoreTabsButton = value;
				this.mAppTabIcon.IsEnabled = false;
			}
		}

		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x0600024D RID: 589 RVA: 0x0000397D File Offset: 0x00001B7D
		// (set) Token: 0x0600024E RID: 590 RVA: 0x00003985 File Offset: 0x00001B85
		public bool IsButtonInDropDown
		{
			get
			{
				return this.mIsButtonInDropDown;
			}
			set
			{
				this.mIsButtonInDropDown = value;
			}
		}

		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x0600024F RID: 591 RVA: 0x0000398E File Offset: 0x00001B8E
		public bool IsSelected
		{
			get
			{
				return this.mIsSelected;
			}
		}

		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x06000250 RID: 592 RVA: 0x00003996 File Offset: 0x00001B96
		// (set) Token: 0x06000251 RID: 593 RVA: 0x0000399E File Offset: 0x00001B9E
		public bool IsShootingModeTooltipEnabled
		{
			get
			{
				return this.mIsShootingModeTooltipEnabled;
			}
			set
			{
				this.mIsShootingModeTooltipEnabled = value;
			}
		}

		// Token: 0x06000252 RID: 594 RVA: 0x00013990 File Offset: 0x00011B90
		internal void Select(bool value, bool receivedFromImap = false)
		{
			if (this.ParentWindow.StaticComponents.mSelectedTabButton != this || !value)
			{
				this.mIsSelected = value;
				if (this.ParentWindow.StaticComponents.mSelectedTabButton != null)
				{
					AppTabButton mSelectedTabButton = this.ParentWindow.StaticComponents.mSelectedTabButton;
					this.ParentWindow.StaticComponents.mSelectedTabButton = null;
					mSelectedTabButton.Select(false, false);
					if (mSelectedTabButton.IsCursorClipped && this.mTabType == TabType.AppTab)
					{
						this.IsCursorClipped = true;
					}
					mSelectedTabButton.IsCursorClipped = false;
				}
				if (this.mIsSelected)
				{
					this.ParentWindow.mTopBar.mAppTabButtons.ListTabHistory.RemoveAll((string n) => n.Equals(this.TabKey, StringComparison.OrdinalIgnoreCase));
					this.ParentWindow.mTopBar.mAppTabButtons.ListTabHistory.Add(this.TabKey);
					this.ParentWindow.StaticComponents.mSelectedTabButton = this;
					this.ParentWindow.Utils.ResetPendingUIOperations();
					if (this.mTabType == TabType.WebTab)
					{
						BrowserControl browserControl = this.GetBrowserControl();
						if (browserControl == null)
						{
							this.mControlGrid = this.ParentWindow.AddBrowser(this.PackageName);
							this.Init(this.AppName, this.PackageName, this.mAppTabIcon.ImageName, this.mControlGrid, this.mTabKey);
						}
						else
						{
							try
							{
								object[] args = new object[0];
								if (browserControl.mBrowser != null)
								{
									browserControl.mBrowser.CallJs("webtabselected", args);
								}
							}
							catch (Exception ex)
							{
								Logger.Warning("Ignoring webtabselected exception. " + ex.Message);
							}
						}
						this.ParentWindow.ChangeWindowOrientaion(this, new ChangeOrientationArgs(true));
					}
					this.ParentWindow.ShowControlGrid(this.mControlGrid);
					if (this.mTabType == TabType.AppTab || this.mTabType == TabType.HomeTab)
					{
						if (this.ParentWindow.AppForcedOrientationDict.ContainsKey(this.PackageName))
						{
							this.ParentWindow.ChangeOrientationFromClient(this.ParentWindow.AppForcedOrientationDict[this.PackageName], true);
						}
						else
						{
							this.ParentWindow.ChangeOrientationFromClient(false, false);
						}
					}
					if (this.ParentWindow.mAspectRatio > 1L && this.IsPortraitModeTab != this.ParentWindow.IsUIInPortraitMode)
					{
						this.ParentWindow.ChangeWindowOrientaion(this, new ChangeOrientationArgs(this.IsPortraitModeTab));
					}
					if (this.mTabType == TabType.HomeTab)
					{
						if (this.ParentWindow.mWelcomeTab.mHomeApp.mSearchTextBox.IsFocused)
						{
							MiscUtils.SetFocusAsync(this.ParentWindow.mWelcomeTab.mHomeApp.mSearchTextBox, 100);
						}
						if (this.ParentWindow.mIsFullScreen)
						{
							this.ParentWindow.RestoreWindows();
						}
						this.ParentWindow.mWelcomeTab.mHomeApp.StartGif();
					}
					else if (!FeatureManager.Instance.IsCustomUIForDMM && this.mTabType == TabType.AppTab && !this.ParentWindow.mSidebar.mIsOverlayTooltipClosed && !this.mIsOverlayTooltipDisplayed && KMManager.KeyMappingFilesAvailable(this.PackageName))
					{
						this.mIsOverlayTooltipDisplayed = true;
						this.ParentWindow.mSidebar.ShowOverlayTooltip(true, false);
					}
					if (this.mTabType != TabType.HomeTab)
					{
						this.ParentWindow.mWelcomeTab.mHomeApp.StopGif();
					}
					if (!KMManager.sPackageName.Equals(this.PackageName))
					{
						KMManager.CloseWindows();
					}
					AppUsageTimer.StartTimer(this.ParentWindow.mVmName, this.TabKey);
					if (this.IsLaunchOnSelection)
					{
						this.LaunchApp();
					}
					else
					{
						this.IsLaunchOnSelection = true;
					}
					if (Constants.ImapShootingModeAppsList.Contains(this.PackageName))
					{
						this.ParentWindow.ToggleShootingModeTooltipVisibility(true);
					}
					else
					{
						this.ParentWindow.ToggleShootingModeTooltipVisibility(false);
					}
					BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "SelectedTabBackgroundColor");
					BlueStacksUIBinding.BindColor(this.mTabLabel, Control.ForegroundProperty, "SelectedTabForegroundColor");
					BlueStacksUIBinding.BindColor(this.mBorder, Border.BorderBrushProperty, "SelectedTabBorderColor");
					if (!FeatureManager.Instance.IsCustomUIForDMM)
					{
						if (this.mTabType == TabType.AppTab)
						{
							this.ParentWindow.mTopBar.mAppTabButtons.KillWebTabs();
							if (KMManager.CheckGamepadCompatible(this.PackageName))
							{
								this.ParentWindow.mCommonHandler.OnGamepadButtonVisibilityChanged(true);
							}
							else
							{
								this.ParentWindow.mCommonHandler.OnGamepadButtonVisibilityChanged(false);
							}
							if (this.mTabType == TabType.AppTab && !this.mIsKeyMappingTipDisplayed && !this.ParentWindow.SendClientActions && !receivedFromImap && KMManager.KeyMappingFilesAvailable(this.PackageName))
							{
								this.mIsKeyMappingTipDisplayed = true;
								this.ParentWindow.mSidebar.ShowKeyMapPopup(true);
							}
							if (RegistryManager.Instance.ShowKeyControlsOverlay && !KMManager.CheckIfKeymappingWindowVisible())
							{
								KMManager.ShowOverlayWindow(this.ParentWindow, true, true);
							}
							this.ParentWindow.mCommonHandler.ToggleMacroAndSyncVisibility();
							this.ParentWindow.mCommonHandler.SetCustomCursorForApp(this.PackageName);
						}
						else
						{
							KMManager.ShowOverlayWindow(this.ParentWindow, false, false);
							if (this.ParentWindow.mCommonHandler != null)
							{
								this.ParentWindow.mCommonHandler.ClipMouseCursorHandler(true, true, "", "");
							}
						}
						if (this.mTabType == TabType.HomeTab)
						{
							this.ParentWindow.mCommonHandler.ToggleMacroAndSyncVisibility();
						}
						else
						{
							this.ParentWindow.mWelcomeTab.mHomeApp.CloseAppSuggestionPopup();
						}
						List<GenericNotificationItem> list = new List<GenericNotificationItem>();
						foreach (GenericNotificationItem genericNotificationItem in from _ in PromotionManager.sPassedDeferredNotificationsList
						where string.Compare(_.DeferredApp, this.PackageName, true) == 0
						select _)
						{
							BlueStacksUIUtils.DictWindows[Strings.CurrentDefaultVmName].HandleGenericNotificationPopup(genericNotificationItem);
							GenericNotificationManager.Instance.AddNewNotification(genericNotificationItem, false);
							BlueStacksUIUtils.DictWindows[Strings.CurrentDefaultVmName].mTopBar.RefreshNotificationCentreButton();
							list.Add(genericNotificationItem);
						}
						foreach (GenericNotificationItem item in list)
						{
							PromotionManager.sPassedDeferredNotificationsList.Remove(item);
						}
						if (this.ParentWindow.SendClientActions && !receivedFromImap)
						{
							Dictionary<string, string> dictionary = new Dictionary<string, string>();
							Dictionary<string, string> dictionary2 = new Dictionary<string, string>();
							dictionary2.Add("EventAction", "TabSelected");
							dictionary2.Add("tabKey", this.TabKey);
							JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
							serializerSettings.Formatting = Formatting.None;
							dictionary.Add("operationData", JsonConvert.SerializeObject(dictionary2, serializerSettings));
							this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("handleClientOperation", dictionary);
						}
					}
					EventHandler<EventArgs> eventOnTabChanged = this.ParentWindow.mTopBar.mAppTabButtons.EventOnTabChanged;
					if (eventOnTabChanged != null)
					{
						eventOnTabChanged(null, null);
					}
					if (this.mRestartPubgTab)
					{
						base.Dispatcher.Invoke(new Action(delegate()
						{
							CustomMessageWindow customMessageWindow = new CustomMessageWindow();
							string path = string.Format(LocaleStrings.GetLocalizedString("STRING_RESTART_OBJECT", false), "PUBG Mobile");
							BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, path, "");
							string path2 = string.Format(LocaleStrings.GetLocalizedString("STRING_SETTING_CHANGED_RESTART_APP_MESSAGE", false), "PUBG Mobile");
							BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, path2, "");
							customMessageWindow.AddButton(ButtonColors.Blue, "STRING_RESTART_BLUESTACKS", new EventHandler(this.RestartConfirmationAcceptedHandler), null, false, null);
							customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
							this.ParentWindow.ShowDimOverlay(null);
							customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
							customMessageWindow.ShowDialog();
							this.ParentWindow.HideDimOverlay();
						}), new object[0]);
						this.mRestartPubgTab = false;
					}
					if (this.mRestartCODTab)
					{
						base.Dispatcher.Invoke(new Action(delegate()
						{
							CustomMessageWindow customMessageWindow = new CustomMessageWindow();
							string path = string.Format(LocaleStrings.GetLocalizedString("STRING_RESTART_OBJECT", false), "Call of Duty: Mobile");
							BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, path, "");
							string path2 = string.Format(LocaleStrings.GetLocalizedString("STRING_SETTING_CHANGED_RESTART_APP_MESSAGE", false), "Call of Duty: Mobile");
							BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, path2, "");
							customMessageWindow.AddButton(ButtonColors.Blue, "STRING_RESTART_BLUESTACKS", new EventHandler(this.RestartConfirmationAcceptedHandler), null, false, null);
							customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
							this.ParentWindow.ShowDimOverlay(null);
							customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
							customMessageWindow.ShowDialog();
							this.ParentWindow.HideDimOverlay();
						}), new object[0]);
						this.mRestartCODTab = false;
					}
					if (this.ParentWindow.mTopBar.mAppTabButtons.mMoreTabButton.Visibility == Visibility.Visible)
					{
						this.MoreTabsButtonHandling();
						return;
					}
				}
				else
				{
					BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundColor");
					BlueStacksUIBinding.BindColor(this.mTabLabel, Control.ForegroundProperty, "TabForegroundColor");
					BlueStacksUIBinding.BindColor(this.mBorder, Border.BorderBrushProperty, "AppTabBorderBrush");
				}
			}
		}

		// Token: 0x06000253 RID: 595 RVA: 0x000039A7 File Offset: 0x00001BA7
		private void RestartConfirmationAcceptedHandler(object sender, EventArgs e)
		{
			Logger.Info("Restarting Pubg/COD Tab.");
			new Thread(delegate()
			{
				this.ParentWindow.mTopBar.mAppTabButtons.RestartTab(this.PackageName);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x170000EA RID: 234
		// (get) Token: 0x06000254 RID: 596 RVA: 0x000039D0 File Offset: 0x00001BD0
		// (set) Token: 0x06000255 RID: 597 RVA: 0x000039D8 File Offset: 0x00001BD8
		public string PackageName
		{
			get
			{
				return this.mPackageName;
			}
			set
			{
				this.mPackageName = value;
			}
		}

		// Token: 0x170000EB RID: 235
		// (get) Token: 0x06000256 RID: 598 RVA: 0x000039E1 File Offset: 0x00001BE1
		// (set) Token: 0x06000257 RID: 599 RVA: 0x000039E9 File Offset: 0x00001BE9
		public string TabKey
		{
			get
			{
				return this.mTabKey;
			}
			set
			{
				this.mTabKey = value;
			}
		}

		// Token: 0x170000EC RID: 236
		// (get) Token: 0x06000258 RID: 600 RVA: 0x000039F2 File Offset: 0x00001BF2
		// (set) Token: 0x06000259 RID: 601 RVA: 0x000039FA File Offset: 0x00001BFA
		public string AppName
		{
			get
			{
				return this.mAppName;
			}
			set
			{
				this.mAppName = value;
			}
		}

		// Token: 0x170000ED RID: 237
		// (get) Token: 0x0600025A RID: 602 RVA: 0x00003A03 File Offset: 0x00001C03
		// (set) Token: 0x0600025B RID: 603 RVA: 0x00003A0B File Offset: 0x00001C0B
		public bool IsDMMKeymapEnabled
		{
			get
			{
				return this.mIsDMMKeyMapEnabled;
			}
			set
			{
				this.mIsDMMKeyMapEnabled = value;
				this.IsDMMKeymapUIVisible = value;
				this.ParentWindow.mCommonHandler.SetDMMKeymapButtonsAndTransparency();
			}
		}

		// Token: 0x170000EE RID: 238
		// (get) Token: 0x0600025C RID: 604 RVA: 0x00003A2B File Offset: 0x00001C2B
		// (set) Token: 0x0600025D RID: 605 RVA: 0x00003A33 File Offset: 0x00001C33
		public bool IsDMMKeymapUIVisible
		{
			get
			{
				return this.mIsDMMKeymapUIVisible;
			}
			set
			{
				this.mIsDMMKeymapUIVisible = value;
			}
		}

		// Token: 0x170000EF RID: 239
		// (get) Token: 0x0600025E RID: 606 RVA: 0x00003A3C File Offset: 0x00001C3C
		public string AppLabel
		{
			get
			{
				return this.mTabLabel.Content.ToString();
			}
		}

		// Token: 0x0600025F RID: 607 RVA: 0x00003A4E File Offset: 0x00001C4E
		public AppTabButton()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000260 RID: 608 RVA: 0x00014104 File Offset: 0x00012304
		internal void Init(string appName, string packageName, string activityName, string imageName, Grid controlGrid, string tabKey)
		{
			bool flag = false;
			if (!string.IsNullOrEmpty(tabKey))
			{
				flag = true;
			}
			this.Init(appName, packageName, imageName, controlGrid, flag ? tabKey : packageName);
			this.mActivityName = activityName;
			this.mTabType = TabType.AppTab;
			if (packageName.Equals("Home") || packageName.Equals("Setup"))
			{
				this.mTabType = TabType.HomeTab;
				BlueStacksUIBinding.BindCornerRadius(this, FrameworkElement.MarginProperty, "TabMarginLandScape");
			}
		}

		// Token: 0x06000261 RID: 609 RVA: 0x00014174 File Offset: 0x00012374
		internal void Init(string title, string url, string imageName, Grid controlGrid, string tabKey)
		{
			BlueStacksUIBinding.Bind(this, title, FrameworkElement.ToolTipProperty);
			BlueStacksUIBinding.Bind(this.mTabLabel, title);
			this.AppName = title;
			this.PackageName = url;
			this.TabKey = tabKey;
			this.mTabType = TabType.WebTab;
			this.mControlGrid = controlGrid;
			if (!this.IsSelected)
			{
				this.mControlGrid.Visibility = Visibility.Hidden;
			}
			if (string.IsNullOrEmpty(imageName))
			{
				this.mImageColumn.Width = new GridLength(0.0);
				return;
			}
			this.mAppTabIcon.ImageName = imageName;
		}

		// Token: 0x06000262 RID: 610 RVA: 0x00014200 File Offset: 0x00012400
		internal void ResizeButton(double tabWidth)
		{
			if (this.ParentWindow.IsUIInPortraitMode)
			{
				this.MakeTabParallelogram(false);
			}
			else
			{
				this.MakeTabParallelogram(true);
			}
			if (tabWidth != base.ActualWidth)
			{
				DoubleAnimation doubleAnimation = new DoubleAnimation();
				doubleAnimation.From = new double?(base.ActualWidth);
				doubleAnimation.To = new double?(tabWidth);
				doubleAnimation.Duration = new Duration(TimeSpan.FromMilliseconds(200.0));
				base.BeginAnimation(FrameworkElement.WidthProperty, doubleAnimation);
			}
		}

		// Token: 0x06000263 RID: 611 RVA: 0x0001427C File Offset: 0x0001247C
		internal void MakeTabParallelogram(bool isSkewTab)
		{
			if (isSkewTab)
			{
				BlueStacksUIBinding.BindCornerRadius(this, FrameworkElement.MarginProperty, "TabMarginLandScape");
			}
			else
			{
				BlueStacksUIBinding.BindCornerRadius(this, FrameworkElement.MarginProperty, "TabMarginPortrait");
			}
			if (isSkewTab != this.mIsTabsSkewed)
			{
				if (isSkewTab)
				{
					this.mIsTabsSkewed = true;
					this.CloseTabButtonPortrait.Visibility = Visibility.Hidden;
					this.ParallelogramGrid.RenderTransform = new SkewTransform(BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleX, BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleY);
					DoubleAnimation animation = new DoubleAnimation(BlueStacksUIColorManager.AppliedTheme.TabTransformPortrait.AngleX, BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleX, TimeSpan.FromMilliseconds(200.0));
					DoubleAnimation doubleAnimation = new DoubleAnimation(BlueStacksUIColorManager.AppliedTheme.TabTransformPortrait.AngleY, BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleY, TimeSpan.FromMilliseconds(200.0));
					doubleAnimation.Completed += this.SkewY_Completed;
					this.ParallelogramGrid.RenderTransform.BeginAnimation(SkewTransform.AngleXProperty, animation);
					this.ParallelogramGrid.RenderTransform.BeginAnimation(SkewTransform.AngleYProperty, doubleAnimation);
					BlueStacksUIBinding.BindCornerRadius(this, FrameworkElement.MarginProperty, "TabMarginLandScape");
				}
				else
				{
					this.mIsTabsSkewed = false;
					this.CloseTabButtonLandScape.Visibility = Visibility.Hidden;
					this.ParallelogramGrid.RenderTransform = new SkewTransform(BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleX, BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleY);
					DoubleAnimation animation2 = new DoubleAnimation(BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleX, BlueStacksUIColorManager.AppliedTheme.TabTransformPortrait.AngleX, TimeSpan.FromMilliseconds(200.0));
					DoubleAnimation doubleAnimation2 = new DoubleAnimation(BlueStacksUIColorManager.AppliedTheme.TabTransformPortrait.AngleY, BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleY, TimeSpan.FromMilliseconds(200.0));
					this.ParallelogramGrid.RenderTransform.BeginAnimation(SkewTransform.AngleXProperty, animation2);
					this.ParallelogramGrid.RenderTransform.BeginAnimation(SkewTransform.AngleYProperty, doubleAnimation2);
					doubleAnimation2.Completed += this.SkewY_Completed;
					BlueStacksUIBinding.BindCornerRadius(this, FrameworkElement.MarginProperty, "TabMarginPortrait");
				}
				if (this.mIsMoreTabsButton)
				{
					this.mBorder.Visibility = Visibility.Visible;
					BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundColor");
				}
			}
		}

		// Token: 0x06000264 RID: 612 RVA: 0x00003A8B File Offset: 0x00001C8B
		private void SkewY_Completed(object sender, EventArgs e)
		{
			if (this.mIsTabsSkewed)
			{
				BlueStacksUIBinding.BindTransform(this.ParallelogramGrid, UIElement.RenderTransformProperty, "TabTransform");
				return;
			}
			BlueStacksUIBinding.BindTransform(this.ParallelogramGrid, UIElement.RenderTransformProperty, "TabTransformPortrait");
		}

		// Token: 0x06000265 RID: 613 RVA: 0x000144E8 File Offset: 0x000126E8
		private void Button_Click(object sender, RoutedEventArgs e)
		{
			if (!this.IsMoreTabsButton)
			{
				if (this.CloseTabButtonLandScape.IsMouseOver || this.CloseTabButtonPortrait.IsMouseOver || this.CloseTabButtonDropDown.IsMouseOver)
				{
					this.ParentWindow.mTopBar.mAppTabButtons.CloseTab(this.TabKey, true, false, false, false, "");
					return;
				}
				this.Select(true, false);
				this.Button_PreviewMouseUp(null, null);
				if (this.EventOnTabChanged != null)
				{
					this.EventOnTabChanged(this, new TabChangeEventArgs(this.AppName, this.PackageName, this.mTabType));
				}
			}
		}

		// Token: 0x06000266 RID: 614 RVA: 0x00014588 File Offset: 0x00012788
		internal void UpdateUIForDropDown(bool isInDropDown)
		{
			if (isInDropDown)
			{
				this.mIsButtonInDropDown = true;
				this.MakeTabParallelogram(false);
				base.MinWidth = 150.0;
				this.mLabelViewBox.Margin = new Thickness(3.0, 1.0, 3.0, 1.0);
				if (!this.mIsSelected)
				{
					this.mBorder.Background = Brushes.Transparent;
				}
				this.mBorder.BorderThickness = new Thickness(0.0);
				return;
			}
			this.mIsButtonInDropDown = false;
			this.mBorder.BorderThickness = new Thickness(1.0);
			base.MinWidth = 0.0;
			this.mLabelViewBox.Margin = new Thickness(3.0, 1.0, 24.0, 1.0);
			if (this.IsSelected)
			{
				BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "SelectedTabBackgroundColor");
				BlueStacksUIBinding.BindColor(this.mBorder, Border.BorderBrushProperty, "SelectedTabBorderColor");
				return;
			}
			BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundColor");
			BlueStacksUIBinding.BindColor(this.mBorder, Border.BorderBrushProperty, "AppTabBorderBrush");
		}

		// Token: 0x06000267 RID: 615 RVA: 0x000146E0 File Offset: 0x000128E0
		internal void LaunchApp()
		{
			if (!string.IsNullOrEmpty(this.PackageName) && this.mTabType == TabType.AppTab)
			{
				this.ParentWindow.mAppHandler.SendRunAppRequestAsync(this.PackageName, this.mActivityName, false);
				return;
			}
			if ((this.mTabType == TabType.HomeTab || this.mTabType == TabType.WebTab) && RegistryManager.Instance.SwitchToAndroidHome)
			{
				this.ParentWindow.mAppHandler.GoHome();
			}
		}

		// Token: 0x06000268 RID: 616 RVA: 0x00014750 File Offset: 0x00012950
		private void Button_MouseEnter(object sender, MouseEventArgs e)
		{
			if (!this.IsSelected)
			{
				BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundHoverColor");
			}
			if (this.mIsButtonInDropDown)
			{
				if (this.mTabType != TabType.HomeTab)
				{
					this.CloseTabButtonDropDown.Visibility = Visibility.Visible;
				}
			}
			else if (this.mTabType != TabType.HomeTab && !this.mIsMoreTabsButton)
			{
				this.CloseTabButtonLandScape.Visibility = Visibility.Visible;
				if (!this.mIsTabsSkewed)
				{
					this.CloseTabButtonPortrait.Visibility = Visibility.Visible;
				}
			}
			if (this.IsMoreTabsButton)
			{
				this.mAppTabIcon.SetHoverImage();
				BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundHoverColor");
			}
		}

		// Token: 0x06000269 RID: 617 RVA: 0x000147F4 File Offset: 0x000129F4
		private void Button_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.IsSelected)
			{
				BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundColor");
			}
			if (this.IsMoreTabsButton)
			{
				this.mAppTabIcon.SetDefaultImage();
				BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundColor");
			}
			this.CloseTabButtonLandScape.Visibility = Visibility.Hidden;
			this.CloseTabButtonPortrait.Visibility = Visibility.Hidden;
			this.CloseTabButtonDropDown.Visibility = Visibility.Hidden;
		}

		// Token: 0x0600026A RID: 618 RVA: 0x0001486C File Offset: 0x00012A6C
		private void Button_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!this.mIsButtonInDropDown)
			{
				if (this.IsMoreTabsButton)
				{
					this.mAppTabIcon.SetClickedImage();
					BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "SelectedTabBackgroundColor");
					return;
				}
				if (!this.IsSelected)
				{
					BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundColor");
					BlueStacksUIBinding.BindColor(this.mBorder, Border.BorderBrushProperty, "AppTabBorderBrush");
				}
			}
		}

		// Token: 0x0600026B RID: 619 RVA: 0x000148DC File Offset: 0x00012ADC
		private void Button_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			if (!this.mIsButtonInDropDown)
			{
				if (!this.IsSelected)
				{
					BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundColor");
				}
				if (this.mIsMoreTabsButton)
				{
					if (base.IsMouseOver)
					{
						this.mAppTabIcon.SetHoverImage();
						BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundHoverColor");
						return;
					}
					this.mAppTabIcon.SetDefaultImage();
					BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundColor");
				}
			}
		}

		// Token: 0x0600026C RID: 620 RVA: 0x00003AC0 File Offset: 0x00001CC0
		private void Button_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (base.IsEnabled)
			{
				base.Opacity = 1.0;
				return;
			}
			base.Opacity = 0.3;
		}

		// Token: 0x0600026D RID: 621 RVA: 0x00014960 File Offset: 0x00012B60
		internal BrowserControl GetBrowserControl()
		{
			BrowserControl result;
			try
			{
				result = (this.mControlGrid.Children[0] as BrowserControl);
			}
			catch (Exception ex)
			{
				Logger.Warning("No BrowserControl associated with tabkey: " + this.TabKey + " Error: " + ex.ToString());
				result = null;
			}
			return result;
		}

		// Token: 0x0600026E RID: 622 RVA: 0x00003AE9 File Offset: 0x00001CE9
		internal void EnableKeymapForDMM(bool enable)
		{
			this.mIsDMMKeyMapEnabled = enable;
		}

		// Token: 0x0600026F RID: 623 RVA: 0x000149BC File Offset: 0x00012BBC
		internal void MoreTabsButtonHandling()
		{
			AppTabButton mMoreTabButton = this.ParentWindow.mTopBar.mAppTabButtons.mMoreTabButton;
			mMoreTabButton.mLabelViewBox.Visibility = Visibility.Collapsed;
			mMoreTabButton.mDownArrowGrid.Visibility = Visibility.Visible;
			if (this.ParentWindow.mTopBar.mAppTabButtons.mHiddenButtons.Children.Contains(this.ParentWindow.StaticComponents.mSelectedTabButton))
			{
				mMoreTabButton.mAppTabIcon.ImageName = this.ParentWindow.StaticComponents.mSelectedTabButton.mAppTabIcon.ImageName;
				return;
			}
			mMoreTabButton.mAppTabIcon.ImageName = (this.ParentWindow.mTopBar.mAppTabButtons.mHiddenButtons.Children[0] as AppTabButton).mAppTabIcon.ImageName;
		}

		// Token: 0x04000140 RID: 320
		private MainWindow mMainWindow;

		// Token: 0x04000141 RID: 321
		internal const int IconModeMinWidth = 38;

		// Token: 0x04000142 RID: 322
		internal const int ParallelogramModeMinWidth = 48;

		// Token: 0x04000143 RID: 323
		private bool mIsPortraitModeTab;

		// Token: 0x04000144 RID: 324
		internal TabType mTabType;

		// Token: 0x04000145 RID: 325
		public EventHandler<TabChangeEventArgs> EventOnTabChanged;

		// Token: 0x04000146 RID: 326
		internal bool mRestartPubgTab;

		// Token: 0x04000147 RID: 327
		internal bool mRestartCODTab;

		// Token: 0x04000148 RID: 328
		internal bool mIsKeyMappingTipDisplayed;

		// Token: 0x04000149 RID: 329
		internal bool mIsOverlayTooltipDisplayed;

		// Token: 0x0400014B RID: 331
		private IMConfig mSelectedConfig;

		// Token: 0x0400014C RID: 332
		private bool mIsMoreTabsButton;

		// Token: 0x0400014D RID: 333
		private bool mIsButtonInDropDown;

		// Token: 0x0400014E RID: 334
		private bool mIsSelected;

		// Token: 0x0400014F RID: 335
		private bool mIsShootingModeTooltipEnabled = true;

		// Token: 0x04000150 RID: 336
		private string mPackageName = string.Empty;

		// Token: 0x04000151 RID: 337
		private string mTabKey;

		// Token: 0x04000152 RID: 338
		private string mAppName = string.Empty;

		// Token: 0x04000153 RID: 339
		private bool mIsDMMKeyMapEnabled;

		// Token: 0x04000154 RID: 340
		private bool mIsDMMKeymapUIVisible;

		// Token: 0x04000155 RID: 341
		public bool IsLaunchOnSelection;

		// Token: 0x04000156 RID: 342
		private string mActivityName = string.Empty;

		// Token: 0x04000157 RID: 343
		private bool mIsTabsSkewed = true;

		// Token: 0x04000158 RID: 344
		public Grid mControlGrid;
	}
}
