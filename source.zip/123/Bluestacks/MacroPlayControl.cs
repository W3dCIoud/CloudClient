﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000061 RID: 97
	public class MacroPlayControl : UserControl, IComponentConnector
	{
		// Token: 0x14000002 RID: 2
		// (add) Token: 0x0600040C RID: 1036 RVA: 0x0001BAB4 File Offset: 0x00019CB4
		// (remove) Token: 0x0600040D RID: 1037 RVA: 0x0001BAEC File Offset: 0x00019CEC
		internal event MacroPlayControl.ScriptPlayDelegate ScriptPlayEvent;

		// Token: 0x14000003 RID: 3
		// (add) Token: 0x0600040E RID: 1038 RVA: 0x0001BB24 File Offset: 0x00019D24
		// (remove) Token: 0x0600040F RID: 1039 RVA: 0x0001BB5C File Offset: 0x00019D5C
		internal event MacroPlayControl.ScriptStopDelegate ScriptStopEvent;

		// Token: 0x06000410 RID: 1040 RVA: 0x00004B39 File Offset: 0x00002D39
		public MacroPlayControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000411 RID: 1041 RVA: 0x00004B4E File Offset: 0x00002D4E
		internal void OnScriptPlayEvent(string tag)
		{
			MacroPlayControl.ScriptPlayDelegate scriptPlayEvent = this.ScriptPlayEvent;
			if (scriptPlayEvent == null)
			{
				return;
			}
			scriptPlayEvent(tag);
		}

		// Token: 0x06000412 RID: 1042 RVA: 0x00004B61 File Offset: 0x00002D61
		private void BlinkPlayingIcon_Tick(object sender, EventArgs e)
		{
			this.ToggleRecordingIcon();
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x00004B69 File Offset: 0x00002D69
		internal void StopTimer()
		{
			this.mBlinkPlayingIconTimer.Stop();
		}

		// Token: 0x06000414 RID: 1044 RVA: 0x00004B76 File Offset: 0x00002D76
		internal void StartTimer()
		{
			this.mBlinkPlayingIconTimer.Start();
		}

		// Token: 0x06000415 RID: 1045 RVA: 0x00004B83 File Offset: 0x00002D83
		private void ToggleRecordingIcon()
		{
			if (this.mShowPlayingIcon)
			{
				this.RecordingImage.ImageName = "recording_macro_title_play";
				this.mShowPlayingIcon = false;
				return;
			}
			this.RecordingImage.ImageName = "recording_macro";
			this.mShowPlayingIcon = true;
		}

		// Token: 0x06000416 RID: 1046 RVA: 0x00004BBC File Offset: 0x00002DBC
		internal void OnScriptStopEvent(string tag)
		{
			MacroPlayControl.ScriptStopDelegate scriptStopEvent = this.ScriptStopEvent;
			if (scriptStopEvent == null)
			{
				return;
			}
			scriptStopEvent(tag);
		}

		// Token: 0x06000417 RID: 1047 RVA: 0x0001BB94 File Offset: 0x00019D94
		internal void Init(MainWindow parentWindow, OperationsRecord record)
		{
			this.ParentWindow = parentWindow;
			this.mOperationsRecord = record;
			this.mRunningScript.Text = this.mOperationsRecord.Name;
			this.mRunningIterations.Visibility = Visibility.Visible;
			this.mRunningScript.ToolTip = string.Format("{0} {1}", LocaleStrings.GetLocalizedString("STRING_PLAYING", false), this.mRunningScript.Text);
			if (this.mBlinkPlayingIconTimer == null)
			{
				this.mBlinkPlayingIconTimer = new DispatcherTimer(new TimeSpan(0, 0, 0, 0, 500), DispatcherPriority.Render, new EventHandler(this.BlinkPlayingIcon_Tick), Dispatcher.CurrentDispatcher);
				this.mTimer = new DispatcherTimer(new TimeSpan(0, 0, 0, 0, 50), DispatcherPriority.Render, new EventHandler(this.T_Tick), Dispatcher.CurrentDispatcher);
				this.StartTimer();
			}
		}

		// Token: 0x06000418 RID: 1048 RVA: 0x0001BC60 File Offset: 0x00019E60
		private void T_Tick(object sender, EventArgs e)
		{
			TimeSpan timeSpan = DateTime.Now - this.mStartTime;
			string text = string.Format("{0:00}:{1:00}:{2:00}", timeSpan.Minutes, timeSpan.Seconds, timeSpan.Milliseconds / 10);
			this.mTimerDisplay.Text = text;
		}

		// Token: 0x06000419 RID: 1049 RVA: 0x00004BCF File Offset: 0x00002DCF
		internal void IncreaseIteration(int iteration)
		{
			this.mRunningIterations.Text = string.Format(LocaleStrings.GetLocalizedString("STRING_RUNNING_X_TIME", false), Strings.AddOrdinal(iteration));
		}

		// Token: 0x0600041A RID: 1050 RVA: 0x00004BF2 File Offset: 0x00002DF2
		private void PauseMacro_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
		}

		// Token: 0x0600041B RID: 1051 RVA: 0x00004BF4 File Offset: 0x00002DF4
		private void PlayMacro_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.OnScriptPlayEvent(this.mOperationsRecord.Name);
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x0001BCBC File Offset: 0x00019EBC
		private void StopMacro_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.StopTimer();
			this.mBlinkPlayingIconTimer = null;
			this.ParentWindow.mCommonHandler.StopMacroScriptHandling();
			MacroPlayControl.ScriptStopDelegate scriptStopEvent = this.ScriptStopEvent;
			if (scriptStopEvent != null)
			{
				scriptStopEvent(this.mOperationsRecord.Name);
			}
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_stop", null, null, null, null, null);
		}

		// Token: 0x0600041D RID: 1053 RVA: 0x0001BD2C File Offset: 0x00019F2C
		internal void UpdateUiForIterationTillTime()
		{
			this.mRunningIterations.Visibility = Visibility.Collapsed;
			this.mTimerDisplay.Visibility = Visibility.Visible;
			this.mRunningScript.ToolTip = string.Format("{0}-{1}sec", this.mOperationsRecord.Name, this.mOperationsRecord.LoopTime);
		}

		// Token: 0x0600041E RID: 1054 RVA: 0x0001BD84 File Offset: 0x00019F84
		internal void UpdateUiMacroPlaybackForInfiniteTime(int iteration)
		{
			this.mTimerDisplay.Visibility = Visibility.Collapsed;
			this.mRunningIterations.Visibility = Visibility.Visible;
			this.mRunningIterations.Text = string.Format(LocaleStrings.GetLocalizedString("STRING_RUNNING_X_TIME", false), Strings.AddOrdinal(iteration));
			this.mRunningScript.ToolTip = string.Format("{0}", this.mOperationsRecord.Name);
		}

		// Token: 0x0600041F RID: 1055 RVA: 0x0001BDEC File Offset: 0x00019FEC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/macroplaycontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000420 RID: 1056 RVA: 0x0001BE1C File Offset: 0x0001A01C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				this.RecordingImage = (CustomPictureBox)target;
				return;
			case 3:
				this.mDescriptionPanel = (StackPanel)target;
				return;
			case 4:
				this.mRunningScript = (TextBlock)target;
				return;
			case 5:
				this.mRunningIterations = (TextBlock)target;
				return;
			case 6:
				this.mTimerDisplay = (TextBlock)target;
				return;
			case 7:
				this.StopMacroImg = (CustomPictureBox)target;
				this.StopMacroImg.PreviewMouseLeftButtonUp += this.StopMacro_PreviewMouseLeftButtonUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000258 RID: 600
		private MainWindow ParentWindow;

		// Token: 0x04000259 RID: 601
		internal OperationsRecord mOperationsRecord;

		// Token: 0x0400025A RID: 602
		private DispatcherTimer mBlinkPlayingIconTimer;

		// Token: 0x0400025B RID: 603
		private DispatcherTimer mTimer;

		// Token: 0x0400025C RID: 604
		public DateTime mStartTime;

		// Token: 0x0400025D RID: 605
		private bool mShowPlayingIcon = true;

		// Token: 0x04000260 RID: 608
		internal Border mMaskBorder;

		// Token: 0x04000261 RID: 609
		internal CustomPictureBox RecordingImage;

		// Token: 0x04000262 RID: 610
		internal StackPanel mDescriptionPanel;

		// Token: 0x04000263 RID: 611
		internal TextBlock mRunningScript;

		// Token: 0x04000264 RID: 612
		internal TextBlock mRunningIterations;

		// Token: 0x04000265 RID: 613
		internal TextBlock mTimerDisplay;

		// Token: 0x04000266 RID: 614
		internal CustomPictureBox StopMacroImg;

		// Token: 0x04000267 RID: 615
		private bool _contentLoaded;

		// Token: 0x02000062 RID: 98
		// (Invoke) Token: 0x06000422 RID: 1058
		internal delegate void ScriptPlayDelegate(string tag);

		// Token: 0x02000063 RID: 99
		// (Invoke) Token: 0x06000426 RID: 1062
		internal delegate void ScriptStopDelegate(string tag);
	}
}
