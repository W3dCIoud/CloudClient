﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000A4 RID: 164
	public class RecommendedApps : UserControl, IComponentConnector
	{
		// Token: 0x0600070A RID: 1802 RVA: 0x00006959 File Offset: 0x00004B59
		public RecommendedApps()
		{
			this.InitializeComponent();
		}

		// Token: 0x17000157 RID: 343
		// (get) Token: 0x0600070B RID: 1803 RVA: 0x00006967 File Offset: 0x00004B67
		// (set) Token: 0x0600070C RID: 1804 RVA: 0x0000696F File Offset: 0x00004B6F
		internal AppRecommendation AppRecomendation { get; set; }

		// Token: 0x17000158 RID: 344
		// (get) Token: 0x0600070D RID: 1805 RVA: 0x00006978 File Offset: 0x00004B78
		// (set) Token: 0x0600070E RID: 1806 RVA: 0x00006980 File Offset: 0x00004B80
		internal int RecommendedAppPosition { get; set; }

		// Token: 0x17000159 RID: 345
		// (get) Token: 0x0600070F RID: 1807 RVA: 0x00006989 File Offset: 0x00004B89
		// (set) Token: 0x06000710 RID: 1808 RVA: 0x00006991 File Offset: 0x00004B91
		internal int RecommendedAppRank { get; set; }

		// Token: 0x1700015A RID: 346
		// (get) Token: 0x06000711 RID: 1809 RVA: 0x0000699A File Offset: 0x00004B9A
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x06000712 RID: 1810 RVA: 0x0002BD04 File Offset: 0x00029F04
		internal void Populate(MainWindow window, AppRecommendation recom, int appPosition, int appRank)
		{
			this.AppRecomendation = recom;
			this.recomIcon.IsFullImagePath = true;
			this.recomIcon.ImageName = recom.ImagePath;
			this.appNameTextBlock.Text = recom.ExtraPayload["click_action_title"];
			this.appGenreTextBlock.Text = recom.GameGenre;
			this.RecommendedAppPosition = appPosition;
			this.RecommendedAppRank = appRank;
		}

		// Token: 0x06000713 RID: 1811 RVA: 0x0002BD70 File Offset: 0x00029F70
		private void Recommendation_Click(object sender, MouseButtonEventArgs e)
		{
			try
			{
				JArray jarray = new JArray();
				jarray.Add(new JObject
				{
					{
						"app_loc",
						(this.AppRecomendation.ExtraPayload["click_generic_action"] == "InstallCDN") ? "cdn" : "gplay"
					},
					{
						"app_pkg",
						this.AppRecomendation.ExtraPayload["click_action_packagename"]
					},
					{
						"is_installed",
						this.ParentWindow.mAppHandler.IsAppInstalled(this.AppRecomendation.ExtraPayload["click_action_packagename"]) ? "true" : "false"
					},
					{
						"app_position",
						this.RecommendedAppPosition.ToString()
					},
					{
						"app_rank",
						this.RecommendedAppRank.ToString()
					}
				});
				ClientStats.SendFrontendClickStats("apps_recommendation", "click", null, this.AppRecomendation.ExtraPayload["click_action_packagename"], null, null, null, jarray.ToString(Formatting.None, new JsonConverter[0]));
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while sending stats to cloud for apps_recommendation_click " + ex.ToString());
			}
			this.ParentWindow.Utils.HandleGenericActionFromDictionary(this.AppRecomendation.ExtraPayload, "search_suggestion", "");
		}

		// Token: 0x06000714 RID: 1812 RVA: 0x000069BB File Offset: 0x00004BBB
		private void UserControl_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(this.mMainGrid, Control.BackgroundProperty, "SearchGridBackgroundHoverColor");
		}

		// Token: 0x06000715 RID: 1813 RVA: 0x000069D2 File Offset: 0x00004BD2
		private void UserControl_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mMainGrid.Background = Brushes.Transparent;
		}

		// Token: 0x06000716 RID: 1814 RVA: 0x0002BF04 File Offset: 0x0002A104
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/recommendedapps.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000717 RID: 1815 RVA: 0x0002BF34 File Offset: 0x0002A134
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMainGrid = (Grid)target;
				this.mMainGrid.MouseEnter += this.UserControl_MouseEnter;
				this.mMainGrid.MouseLeave += this.UserControl_MouseLeave;
				this.mMainGrid.PreviewMouseLeftButtonUp += this.Recommendation_Click;
				return;
			case 2:
				this.recomIcon = (CustomPictureBox)target;
				return;
			case 3:
				this.appNameTextBlock = (TextBlock)target;
				return;
			case 4:
				this.appGenreTextBlock = (TextBlock)target;
				return;
			case 5:
				this.installButton = (CustomButton)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040004C5 RID: 1221
		private MainWindow mMainWindow;

		// Token: 0x040004C6 RID: 1222
		internal Grid mMainGrid;

		// Token: 0x040004C7 RID: 1223
		internal CustomPictureBox recomIcon;

		// Token: 0x040004C8 RID: 1224
		internal TextBlock appNameTextBlock;

		// Token: 0x040004C9 RID: 1225
		internal TextBlock appGenreTextBlock;

		// Token: 0x040004CA RID: 1226
		internal CustomButton installButton;

		// Token: 0x040004CB RID: 1227
		private bool _contentLoaded;
	}
}
