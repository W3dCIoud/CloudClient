﻿using System;
using System.ComponentModel;

// Token: 0x02000014 RID: 20
[Description("Independent")]
[Serializable]
public class TapRepeat : IMAction
{
	// Token: 0x17000090 RID: 144
	// (get) Token: 0x06000133 RID: 307 RVA: 0x00002D22 File Offset: 0x00000F22
	// (set) Token: 0x06000134 RID: 308 RVA: 0x00002D2A File Offset: 0x00000F2A
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X
	{
		get
		{
			return this.mX;
		}
		set
		{
			this.mX = value;
		}
	}

	// Token: 0x17000091 RID: 145
	// (get) Token: 0x06000135 RID: 309 RVA: 0x00002D33 File Offset: 0x00000F33
	// (set) Token: 0x06000136 RID: 310 RVA: 0x00002D3B File Offset: 0x00000F3B
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y
	{
		get
		{
			return this.mY;
		}
		set
		{
			this.mY = value;
		}
	}

	// Token: 0x17000092 RID: 146
	// (get) Token: 0x06000137 RID: 311 RVA: 0x00002D44 File Offset: 0x00000F44
	// (set) Token: 0x06000138 RID: 312 RVA: 0x00002D4C File Offset: 0x00000F4C
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key
	{
		get
		{
			return this.mKey;
		}
		set
		{
			this.mKey = value;
		}
	}

	// Token: 0x17000093 RID: 147
	// (get) Token: 0x06000139 RID: 313 RVA: 0x00002D55 File Offset: 0x00000F55
	// (set) Token: 0x0600013A RID: 314 RVA: 0x00002D5D File Offset: 0x00000F5D
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key_alt1
	{
		get
		{
			return this.mKey_alt1;
		}
		set
		{
			this.mKey_alt1 = value;
		}
	}

	// Token: 0x17000094 RID: 148
	// (get) Token: 0x0600013B RID: 315 RVA: 0x00002D66 File Offset: 0x00000F66
	// (set) Token: 0x0600013C RID: 316 RVA: 0x00002D6E File Offset: 0x00000F6E
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int Count
	{
		get
		{
			return this.mCount;
		}
		set
		{
			this.mCount = value;
		}
	}

	// Token: 0x17000095 RID: 149
	// (get) Token: 0x0600013D RID: 317 RVA: 0x00002D77 File Offset: 0x00000F77
	// (set) Token: 0x0600013E RID: 318 RVA: 0x00002D7F File Offset: 0x00000F7F
	public int Delay
	{
		get
		{
			return this.mDelay;
		}
		set
		{
			this.mDelay = 1000 / (2 * this.Count);
		}
	}

	// Token: 0x17000096 RID: 150
	// (get) Token: 0x0600013F RID: 319 RVA: 0x00002D95 File Offset: 0x00000F95
	// (set) Token: 0x06000140 RID: 320 RVA: 0x00002D9D File Offset: 0x00000F9D
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool ShowOnOverlay
	{
		get
		{
			return this.mShowOnOverlay;
		}
		set
		{
			this.mShowOnOverlay = value;
		}
	}

	// Token: 0x17000097 RID: 151
	// (get) Token: 0x06000141 RID: 321 RVA: 0x00002DA6 File Offset: 0x00000FA6
	// (set) Token: 0x06000142 RID: 322 RVA: 0x00002DAE File Offset: 0x00000FAE
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool RepeatUntilKeyUp
	{
		get
		{
			return this.mRepeatUntilKeyUp;
		}
		set
		{
			this.mRepeatUntilKeyUp = value;
		}
	}

	// Token: 0x0400008D RID: 141
	private double mX = -1.0;

	// Token: 0x0400008E RID: 142
	private double mY = -1.0;

	// Token: 0x0400008F RID: 143
	private string mKey;

	// Token: 0x04000090 RID: 144
	private string mKey_alt1;

	// Token: 0x04000091 RID: 145
	private int mCount = 5;

	// Token: 0x04000092 RID: 146
	private int mDelay = 100;

	// Token: 0x04000093 RID: 147
	internal bool mShowOnOverlay = true;

	// Token: 0x04000094 RID: 148
	private bool mRepeatUntilKeyUp = true;
}
