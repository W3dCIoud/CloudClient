﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Timers;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000046 RID: 70
	internal class SecurityMetrics
	{
		// Token: 0x1700011F RID: 287
		// (get) Token: 0x06000346 RID: 838 RVA: 0x0000434B File Offset: 0x0000254B
		public static SerializableDictionary<string, SecurityMetrics> SecurityMetricsInstanceList { get; } = new SerializableDictionary<string, SecurityMetrics>();

		// Token: 0x06000347 RID: 839 RVA: 0x000185C4 File Offset: 0x000167C4
		public SecurityMetrics(string vmName)
		{
			this.mVmName = vmName;
			this.mTimer = new System.Timers.Timer();
			this.mTimer.Interval = 86400000.0;
			this.mTimer.Elapsed += this.OnTimedEvent;
			this.mTimer.AutoReset = true;
			this.mTimer.Enabled = true;
			new Thread(delegate()
			{
				this.CheckMd5HashOfRootVdi();
				this.CheckAppPlayerRootInfoFromAndroidBstk();
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000348 RID: 840 RVA: 0x00004352 File Offset: 0x00002552
		private void OnTimedEvent(object sender, ElapsedEventArgs e)
		{
			this.SendSecurityBreachesStatsToCloud(false);
		}

		// Token: 0x06000349 RID: 841 RVA: 0x0000435B File Offset: 0x0000255B
		internal static void Init(string vmName)
		{
			if (!SecurityMetrics.SecurityMetricsInstanceList.ContainsKey(vmName))
			{
				SecurityMetrics.SecurityMetricsInstanceList.Add(vmName, new SecurityMetrics(vmName));
			}
		}

		// Token: 0x0600034A RID: 842 RVA: 0x0000437B File Offset: 0x0000257B
		internal void SendSecurityBreachesStatsToCloud(bool isOnClose = false)
		{
			new Thread(delegate()
			{
				try
				{
					this.AddBlacklistedRunningApplicationsToSecurityBreaches();
					if (this.mSecurityBreachesList.Count > 0)
					{
						string urlWithParams = WebHelper.GetUrlWithParams(string.Format("{0}/{1}", RegistryManager.Instance.Host, "/bs4/security_metrics"));
						Dictionary<string, string> data = new Dictionary<string, string>
						{
							{
								"security_metric_data",
								this.GetSecurityMetricsData()
							}
						};
						BstHttpClient.Post(urlWithParams, data, null, false, this.mVmName, 10000, 1, 0, false);
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception while sending security stats to cloud : {0}", new object[]
					{
						ex.ToString()
					});
				}
				if (isOnClose)
				{
					SecurityMetrics.SecurityMetricsInstanceList.Remove(this.mVmName);
				}
			}).Start();
		}

		// Token: 0x0600034B RID: 843 RVA: 0x00018654 File Offset: 0x00016854
		private string GetSecurityMetricsData()
		{
			string text = string.Empty;
			StringBuilder stringBuilder = new StringBuilder();
			using (StringWriter stringWriter = new StringWriter(stringBuilder))
			{
				using (JsonWriter jsonWriter = new JsonTextWriter(stringWriter))
				{
					jsonWriter.Formatting = Formatting.Indented;
					jsonWriter.WriteStartObject();
					foreach (SecurityBreach securityBreach in this.mSecurityBreachesList.Keys)
					{
						if (securityBreach != SecurityBreach.SCRIPT_TOOLS)
						{
							if (securityBreach - SecurityBreach.DEVICE_PROBED <= 3)
							{
								jsonWriter.WritePropertyName(securityBreach.ToString().ToLower());
								jsonWriter.WriteValue(this.mSecurityBreachesList[securityBreach]);
							}
						}
						else
						{
							jsonWriter.WritePropertyName(securityBreach.ToString().ToLower());
							jsonWriter.WriteStartObject();
							jsonWriter.WritePropertyName("running_blacklist_programs");
							jsonWriter.WriteValue(this.mSecurityBreachesList[securityBreach]);
							jsonWriter.WriteEndObject();
						}
					}
					jsonWriter.WriteEndObject();
					text = stringBuilder.ToString();
					Logger.Debug("security data " + text);
				}
			}
			return text;
		}

		// Token: 0x0600034C RID: 844 RVA: 0x0001879C File Offset: 0x0001699C
		private void AddBlacklistedRunningApplicationsToSecurityBreaches()
		{
			List<string> blackListedApplicationsList = PromotionObject.Instance.BlackListedApplicationsList;
			List<string> list = new List<string>();
			foreach (string text in blackListedApplicationsList)
			{
				if (ProcessUtils.FindProcessByName(text))
				{
					list.Add(text);
				}
			}
			if (list.Count > 0)
			{
				string data = JsonConvert.SerializeObject(list);
				this.AddSecurityBreach(SecurityBreach.SCRIPT_TOOLS, data);
			}
		}

		// Token: 0x0600034D RID: 845 RVA: 0x0001881C File Offset: 0x00016A1C
		internal void AddSecurityBreach(SecurityBreach breach, string data)
		{
			try
			{
				if (!this.mSecurityBreachesList.ContainsKey(breach))
				{
					this.mSecurityBreachesList.Add(breach, data);
					Logger.Info("Security breach added for: {0}", new object[]
					{
						breach
					});
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in adding security breach: {0}", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x0600034E RID: 846 RVA: 0x0001888C File Offset: 0x00016A8C
		internal void CheckMd5HashOfRootVdi()
		{
			try
			{
				string blockDevice0Path = RegistryManager.Instance.Guest["Android"].BlockDevice0Path;
				string rootVdiMd5Hash = RegistryManager.Instance.RootVdiMd5Hash;
				if (string.IsNullOrEmpty(rootVdiMd5Hash))
				{
					Utils.CreateMD5HashOfRootVdi();
				}
				else
				{
					string md5HashFromFile = Utils.GetMD5HashFromFile(blockDevice0Path);
					if (!string.IsNullOrEmpty(md5HashFromFile) && !string.Equals(md5HashFromFile, rootVdiMd5Hash, StringComparison.OrdinalIgnoreCase))
					{
						this.AddSecurityBreach(SecurityBreach.DEVICE_ROOTED, string.Empty);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in checking md5 hash of root vdi: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x0600034F RID: 847 RVA: 0x0001891C File Offset: 0x00016B1C
		private void CheckAppPlayerRootInfoFromAndroidBstk()
		{
			try
			{
				JArray jarray = JArray.Parse(HTTPUtils.SendRequestToEngine("isAppPlayerRooted", null, this.mVmName, 0, null, false, 1, 0, ""));
				if ((bool)jarray[0]["success"] && (bool)jarray[0]["isRooted"])
				{
					this.AddSecurityBreach(SecurityBreach.DEVICE_ROOTED, string.Empty);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in checking root info from engine: {0}", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x040001D3 RID: 467
		private Dictionary<SecurityBreach, string> mSecurityBreachesList = new Dictionary<SecurityBreach, string>();

		// Token: 0x040001D4 RID: 468
		private string mVmName;

		// Token: 0x040001D5 RID: 469
		private System.Timers.Timer mTimer;
	}
}
