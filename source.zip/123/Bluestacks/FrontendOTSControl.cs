﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001DE RID: 478
	public class FrontendOTSControl : UserControl, IComponentConnector
	{
		// Token: 0x170001F9 RID: 505
		// (get) Token: 0x06001087 RID: 4231 RVA: 0x0000BC4C File Offset: 0x00009E4C
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x06001088 RID: 4232 RVA: 0x0000BC6D File Offset: 0x00009E6D
		public FrontendOTSControl()
		{
			this.InitializeComponent();
			this.OneTimeSetupCompletedEventHandle = (EventHandler<EventArgs>)Delegate.Combine(this.OneTimeSetupCompletedEventHandle, new EventHandler<EventArgs>(this.OneTimeSetup_Completed));
		}

		// Token: 0x06001089 RID: 4233 RVA: 0x00067938 File Offset: 0x00065B38
		private void UserControl_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (base.Visibility == Visibility.Visible)
			{
				BlueStacksUIBinding.Bind(this.mBaseControl.mTitleLabel, "STRING_GOOGLE_LOGIN_MESSAGE");
				this.mBaseControl.Init(this, this.ParentWindow.mFrontendGrid, true, true);
				this.mBaseControl.ShowContent();
				this.ParentWindow.mAppHandler.EventOnOneTimeSetupCompleted = this.OneTimeSetupCompletedEventHandle;
			}
		}

		// Token: 0x0600108A RID: 4234 RVA: 0x0000BC9D File Offset: 0x00009E9D
		private void OneTimeSetup_Completed(object sender, EventArgs e)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mBaseControl.HideWindow();
			}), new object[0]);
		}

		// Token: 0x0600108B RID: 4235 RVA: 0x0006799C File Offset: 0x00065B9C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/frontendotscontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600108C RID: 4236 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600108D RID: 4237 RVA: 0x0000BCBD File Offset: 0x00009EBD
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				((FrontendOTSControl)target).IsVisibleChanged += this.UserControl_IsVisibleChanged;
				return;
			}
			if (connectionId != 2)
			{
				this._contentLoaded = true;
				return;
			}
			this.mBaseControl = (DimControlWithProgresBar)target;
		}

		// Token: 0x04000B3F RID: 2879
		private MainWindow mMainWindow;

		// Token: 0x04000B40 RID: 2880
		private EventHandler<EventArgs> OneTimeSetupCompletedEventHandle;

		// Token: 0x04000B41 RID: 2881
		internal DimControlWithProgresBar mBaseControl;

		// Token: 0x04000B42 RID: 2882
		private bool _contentLoaded;
	}
}
