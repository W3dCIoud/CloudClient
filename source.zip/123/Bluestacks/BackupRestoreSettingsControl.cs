﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200012F RID: 303
	public class BackupRestoreSettingsControl : UserControl, IComponentConnector
	{
		// Token: 0x06000BEA RID: 3050 RVA: 0x00051580 File Offset: 0x0004F780
		public BackupRestoreSettingsControl(MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			if (!this.ParentWindow.IsDefaultVM)
			{
				this.mBackupRestoreGrid.Visibility = Visibility.Collapsed;
				this.mLineSeperator.Visibility = Visibility.Collapsed;
			}
			base.Visibility = Visibility.Hidden;
		}

		// Token: 0x06000BEB RID: 3051 RVA: 0x000515CC File Offset: 0x0004F7CC
		private void RestoreBtn_Click(object sender, RoutedEventArgs e)
		{
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.ImageName = "backup_restore_popup_window";
			BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_RESTORE_BACKUP", "");
			BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_MAKE_SURE_LATEST_WARNING", "");
			customMessageWindow.AddButton(ButtonColors.Blue, "STRING_RESTORE_BUTTON", delegate(object sender1, EventArgs e1)
			{
				this.LaunchDataManager(sender, null, "restore");
			}, null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
			customMessageWindow.Owner = this.ParentWindow;
			customMessageWindow.ShowDialog();
		}

		// Token: 0x06000BEC RID: 3052 RVA: 0x00051664 File Offset: 0x0004F864
		private void BackupBtn_Click(object sender, RoutedEventArgs e)
		{
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.ImageName = "backup_restore_popup_window";
			BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_BACKUP_WARNING", "");
			BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_BLUESTACKS_BACKUP_PROMPT", "");
			customMessageWindow.AddButton(ButtonColors.Blue, "STRING_YES", delegate(object sender1, EventArgs e1)
			{
				this.LaunchDataManager(sender, null, "backup");
			}, null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_NO", null, null, false, null);
			customMessageWindow.Owner = this.ParentWindow;
			customMessageWindow.ShowDialog();
		}

		// Token: 0x06000BED RID: 3053 RVA: 0x000516FC File Offset: 0x0004F8FC
		private void DiskCleanupBtn_Click(object sender, RoutedEventArgs e)
		{
			EventHandler <>9__1;
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (ProcessUtils.IsAlreadyRunning("Global\\BlueStacks_DiskCompactor_Lock"))
				{
					CustomMessageWindow customMessageWindow = new CustomMessageWindow();
					customMessageWindow.ImageName = "disk_cleanup_popup_window";
					customMessageWindow.TitleTextBlock.Text = string.Format("{0}", LocaleStrings.GetLocalizedString("STRING_DISK_CLEANUP_MULTIPLE_RUN_HEADING", false));
					customMessageWindow.BodyTextBlock.Text = string.Format("{0}", LocaleStrings.GetLocalizedString("STRING_DISK_CLEANUP_MULTIPLE_RUN_MESSAGE", false));
					customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
					customMessageWindow.CloseButtonHandle(null, null);
					customMessageWindow.Owner = this.ParentWindow;
					customMessageWindow.ShowDialog();
					return;
				}
				CustomMessageWindow customMessageWindow2 = new CustomMessageWindow();
				customMessageWindow2.ImageName = "disk_cleanup_popup_window";
				customMessageWindow2.TitleTextBlock.Text = string.Format("{0}", LocaleStrings.GetLocalizedString("STRING_DISK_CLEANUP", false));
				customMessageWindow2.BodyTextBlockTitle.Text = string.Format("{0}", LocaleStrings.GetLocalizedString("STRING_DISK_CLEANUP_MESSAGE", false));
				customMessageWindow2.BodyTextBlockTitle.Visibility = Visibility.Visible;
				customMessageWindow2.BodyTextBlockTitle.FontWeight = FontWeights.Regular;
				customMessageWindow2.BodyTextBlock.Text = string.Format("{0}", LocaleStrings.GetLocalizedString("STRING_CONTINUE_CONFIRMATION", false));
				ButtonColors color = ButtonColors.Blue;
				string text = "STRING_CONTINUE";
				EventHandler handle;
				if ((handle = <>9__1) == null)
				{
					handle = (<>9__1 = delegate(object sender1, EventArgs e1)
					{
						this.LaunchDiskCompaction(sender, null);
					});
				}
				customMessageWindow2.AddButton(color, text, handle, null, false, null);
				customMessageWindow2.AddButton(ButtonColors.White, "STRING_CLOSE", null, null, false, null);
				customMessageWindow2.CloseButtonHandle(null, null);
				customMessageWindow2.Owner = this.ParentWindow;
				customMessageWindow2.ShowDialog();
			}), new object[0]);
		}

		// Token: 0x06000BEE RID: 3054 RVA: 0x00051740 File Offset: 0x0004F940
		private void LaunchDataManager(object sender, MouseButtonEventArgs e, string argument)
		{
			foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
			{
				if (argument == "backup")
				{
					keyValuePair.Value.CloseAllWindowAndPerform(new EventHandler(this.Closing_WindowHandlerForBackup));
				}
				else if (argument == "restore")
				{
					keyValuePair.Value.CloseAllWindowAndPerform(new EventHandler(this.Closing_WindowHandlerForRestore));
				}
			}
		}

		// Token: 0x06000BEF RID: 3055 RVA: 0x000517D8 File Offset: 0x0004F9D8
		private void LaunchDiskCompaction(object sender, MouseButtonEventArgs e)
		{
			try
			{
				BlueStacksUIUtils.HideUnhideBlueStacks(true);
				new Process
				{
					StartInfo = 
					{
						FileName = System.IO.Path.Combine(RegistryStrings.InstallDir, "DiskCompactionTool.exe"),
						Arguments = string.Format("-vmname:{0} -relaunch", this.ParentWindow.mVmName)
					}
				}.Start();
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in starting disk compaction" + ex.ToString());
			}
		}

		// Token: 0x06000BF0 RID: 3056 RVA: 0x0005185C File Offset: 0x0004FA5C
		internal void Closing_WindowHandlerForBackup(object sender, EventArgs e)
		{
			try
			{
				Dictionary<string, string> data = new Dictionary<string, string>
				{
					{
						"relaunch",
						"true"
					},
					{
						"sendResponseImmediately",
						"true"
					}
				};
				HTTPUtils.SendRequestToAgent("backup", data, this.ParentWindow.mVmName, 0, null, false, 1, 0);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in closing window handler for backup" + ex.ToString());
			}
		}

		// Token: 0x06000BF1 RID: 3057 RVA: 0x000518D8 File Offset: 0x0004FAD8
		internal void Closing_WindowHandlerForRestore(object sender, EventArgs e)
		{
			try
			{
				Dictionary<string, string> data = new Dictionary<string, string>
				{
					{
						"relaunch",
						"true"
					},
					{
						"sendResponseImmediately",
						"true"
					}
				};
				HTTPUtils.SendRequestToAgent("restore", data, this.ParentWindow.mVmName, 0, null, false, 1, 0);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in closing window handler for restore" + ex.ToString());
			}
		}

		// Token: 0x06000BF2 RID: 3058 RVA: 0x00051954 File Offset: 0x0004FB54
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/backuprestoresettingscontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000BF3 RID: 3059 RVA: 0x00051984 File Offset: 0x0004FB84
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mDiskCleanupGrid = (Grid)target;
				return;
			case 2:
				this.mDiskCleanupBtn = (CustomButton)target;
				this.mDiskCleanupBtn.Click += this.DiskCleanupBtn_Click;
				return;
			case 3:
				this.mLineSeperator = (Line)target;
				return;
			case 4:
				this.mBackupRestoreGrid = (Grid)target;
				return;
			case 5:
				this.mRestoreBtn = (CustomButton)target;
				this.mRestoreBtn.Click += this.RestoreBtn_Click;
				return;
			case 6:
				this.mBackupBtn = (CustomButton)target;
				this.mBackupBtn.Click += this.BackupBtn_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040008B1 RID: 2225
		private MainWindow ParentWindow;

		// Token: 0x040008B2 RID: 2226
		internal Grid mDiskCleanupGrid;

		// Token: 0x040008B3 RID: 2227
		internal CustomButton mDiskCleanupBtn;

		// Token: 0x040008B4 RID: 2228
		internal Line mLineSeperator;

		// Token: 0x040008B5 RID: 2229
		internal Grid mBackupRestoreGrid;

		// Token: 0x040008B6 RID: 2230
		internal CustomButton mRestoreBtn;

		// Token: 0x040008B7 RID: 2231
		internal CustomButton mBackupBtn;

		// Token: 0x040008B8 RID: 2232
		private bool _contentLoaded;
	}
}
