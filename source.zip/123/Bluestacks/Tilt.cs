﻿using System;
using System.ComponentModel;
using System.Windows.Input;

// Token: 0x02000017 RID: 23
[Description("Independent")]
[Serializable]
public class Tilt : IMAction
{
	// Token: 0x170000A6 RID: 166
	// (get) Token: 0x06000163 RID: 355 RVA: 0x00002ECE File Offset: 0x000010CE
	// (set) Token: 0x06000164 RID: 356 RVA: 0x00002ED6 File Offset: 0x000010D6
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X
	{
		get
		{
			return this.mX;
		}
		set
		{
			this.mX = value;
		}
	}

	// Token: 0x170000A7 RID: 167
	// (get) Token: 0x06000165 RID: 357 RVA: 0x00002EDF File Offset: 0x000010DF
	// (set) Token: 0x06000166 RID: 358 RVA: 0x00002EE7 File Offset: 0x000010E7
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y
	{
		get
		{
			return this.mY;
		}
		set
		{
			this.mY = value;
		}
	}

	// Token: 0x170000A8 RID: 168
	// (get) Token: 0x06000167 RID: 359 RVA: 0x00002EF0 File Offset: 0x000010F0
	[Description("IMAP_CanvasElementRadius")]
	internal double XRadius
	{
		get
		{
			return 10.0;
		}
	}

	// Token: 0x170000A9 RID: 169
	// (get) Token: 0x06000168 RID: 360 RVA: 0x00002EFB File Offset: 0x000010FB
	// (set) Token: 0x06000169 RID: 361 RVA: 0x00002F03 File Offset: 0x00001103
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyUp
	{
		get
		{
			return this.mKeyUp;
		}
		set
		{
			this.mKeyUp = value;
		}
	}

	// Token: 0x170000AA RID: 170
	// (get) Token: 0x0600016A RID: 362 RVA: 0x00002F0C File Offset: 0x0000110C
	// (set) Token: 0x0600016B RID: 363 RVA: 0x00002F14 File Offset: 0x00001114
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyUp_alt1
	{
		get
		{
			return this.mKeyUp_1;
		}
		set
		{
			this.mKeyUp_1 = value;
		}
	}

	// Token: 0x170000AB RID: 171
	// (get) Token: 0x0600016C RID: 364 RVA: 0x00002F1D File Offset: 0x0000111D
	// (set) Token: 0x0600016D RID: 365 RVA: 0x00002F25 File Offset: 0x00001125
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyDown
	{
		get
		{
			return this.mKeyDown;
		}
		set
		{
			this.mKeyDown = value;
		}
	}

	// Token: 0x170000AC RID: 172
	// (get) Token: 0x0600016E RID: 366 RVA: 0x00002F2E File Offset: 0x0000112E
	// (set) Token: 0x0600016F RID: 367 RVA: 0x00002F36 File Offset: 0x00001136
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyDown_alt1
	{
		get
		{
			return this.mKeyDown_1;
		}
		set
		{
			this.mKeyDown_1 = value;
		}
	}

	// Token: 0x170000AD RID: 173
	// (get) Token: 0x06000170 RID: 368 RVA: 0x00002F3F File Offset: 0x0000113F
	// (set) Token: 0x06000171 RID: 369 RVA: 0x00002F47 File Offset: 0x00001147
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyLeft
	{
		get
		{
			return this.mKeyLeft;
		}
		set
		{
			this.mKeyLeft = value;
		}
	}

	// Token: 0x170000AE RID: 174
	// (get) Token: 0x06000172 RID: 370 RVA: 0x00002F50 File Offset: 0x00001150
	// (set) Token: 0x06000173 RID: 371 RVA: 0x00002F58 File Offset: 0x00001158
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyLeft_alt1
	{
		get
		{
			return this.mKeyLeft_1;
		}
		set
		{
			this.mKeyLeft_1 = value;
		}
	}

	// Token: 0x170000AF RID: 175
	// (get) Token: 0x06000174 RID: 372 RVA: 0x00002F61 File Offset: 0x00001161
	// (set) Token: 0x06000175 RID: 373 RVA: 0x00002F69 File Offset: 0x00001169
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyRight
	{
		get
		{
			return this.mKeyRight;
		}
		set
		{
			this.mKeyRight = value;
		}
	}

	// Token: 0x170000B0 RID: 176
	// (get) Token: 0x06000176 RID: 374 RVA: 0x00002F72 File Offset: 0x00001172
	// (set) Token: 0x06000177 RID: 375 RVA: 0x00002F7A File Offset: 0x0000117A
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyRight_alt1
	{
		get
		{
			return this.mKeyRight_1;
		}
		set
		{
			this.mKeyRight_1 = value;
		}
	}

	// Token: 0x170000B1 RID: 177
	// (get) Token: 0x06000178 RID: 376 RVA: 0x00002F83 File Offset: 0x00001183
	// (set) Token: 0x06000179 RID: 377 RVA: 0x00002F8B File Offset: 0x0000118B
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double MaxAngle
	{
		get
		{
			return this.mMaxAngle;
		}
		set
		{
			this.mMaxAngle = value;
		}
	}

	// Token: 0x170000B2 RID: 178
	// (get) Token: 0x0600017A RID: 378 RVA: 0x00002F94 File Offset: 0x00001194
	// (set) Token: 0x0600017B RID: 379 RVA: 0x00002F9C File Offset: 0x0000119C
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Speed
	{
		get
		{
			return this.mSpeed;
		}
		set
		{
			this.mSpeed = value;
		}
	}

	// Token: 0x170000B3 RID: 179
	// (get) Token: 0x0600017C RID: 380 RVA: 0x00002FA5 File Offset: 0x000011A5
	// (set) Token: 0x0600017D RID: 381 RVA: 0x00002FAD File Offset: 0x000011AD
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool AutoReset
	{
		get
		{
			return this.mAutoReset;
		}
		set
		{
			this.mAutoReset = value;
		}
	}

	// Token: 0x040000A3 RID: 163
	private double mX = -1.0;

	// Token: 0x040000A4 RID: 164
	private double mY = -1.0;

	// Token: 0x040000A5 RID: 165
	private string mKeyUp = IMAPKeys.GetStringForFile(Key.Up);

	// Token: 0x040000A6 RID: 166
	private string mKeyUp_1 = string.Empty;

	// Token: 0x040000A7 RID: 167
	private string mKeyDown = IMAPKeys.GetStringForFile(Key.Down);

	// Token: 0x040000A8 RID: 168
	private string mKeyDown_1 = string.Empty;

	// Token: 0x040000A9 RID: 169
	private string mKeyLeft = IMAPKeys.GetStringForFile(Key.Left);

	// Token: 0x040000AA RID: 170
	private string mKeyLeft_1 = string.Empty;

	// Token: 0x040000AB RID: 171
	private string mKeyRight = IMAPKeys.GetStringForFile(Key.Right);

	// Token: 0x040000AC RID: 172
	private string mKeyRight_1 = string.Empty;

	// Token: 0x040000AD RID: 173
	private double mMaxAngle = 20.0;

	// Token: 0x040000AE RID: 174
	private double mSpeed = 90.0;

	// Token: 0x040000AF RID: 175
	private bool mAutoReset = true;
}
