﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000DE RID: 222
	public class ComboBoxSchemeControl : UserControl, IComponentConnector
	{
		// Token: 0x0600097A RID: 2426 RVA: 0x00007E3F File Offset: 0x0000603F
		public ComboBoxSchemeControl(KeymapCanvasWindow window, MainWindow mainWindow)
		{
			this.CanvasWindow = window;
			this.ParentWindow = mainWindow;
			this.InitializeComponent();
		}

		// Token: 0x0600097B RID: 2427 RVA: 0x00042218 File Offset: 0x00040418
		private void Bookmark_img_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!this.mSchemeName.IsReadOnly)
			{
				this.HandleNameEdit(this);
			}
			if (AdvancedGameControlWindow.sBookmarkedSchemes.Contains(this))
			{
				AdvancedGameControlWindow.sBookmarkedSchemes.Remove(this);
				this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeName.Text].IsBookMarked = false;
				this.mBookmarkImg.ImageName = "bookmark";
			}
			else if (AdvancedGameControlWindow.sBookmarkedSchemes.Count < 5)
			{
				AdvancedGameControlWindow.sBookmarkedSchemes.Add(this);
				this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeName.Text].IsBookMarked = true;
				this.mBookmarkImg.ImageName = "bookmarked";
			}
			else
			{
				this.CanvasWindow.SidebarWindow.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_BOOKMARK_SCHEMES_WARNING", false));
			}
			this.CanvasWindow.SidebarWindow.FillProfileCombo();
			KeymapCanvasWindow.sIsDirty = true;
			e.Handled = true;
		}

		// Token: 0x0600097C RID: 2428 RVA: 0x00042314 File Offset: 0x00040514
		private void EditImg_MouseDown(object sender, MouseButtonEventArgs e)
		{
			this.mEditImg.Visibility = Visibility.Collapsed;
			this.mSaveImg.Visibility = Visibility.Visible;
			this.mOldSchemeName = this.mSchemeName.Text;
			this.mSchemeName.Focusable = true;
			this.mSchemeName.IsReadOnly = false;
			this.mSchemeName.CaretIndex = this.mSchemeName.Text.Length;
			this.mSchemeName.Focus();
			e.Handled = true;
		}

		// Token: 0x0600097D RID: 2429 RVA: 0x00007E5B File Offset: 0x0000605B
		private void SaveImg_MouseDown(object sender, MouseButtonEventArgs e)
		{
			this.HandleNameEdit(this);
			e.Handled = true;
		}

		// Token: 0x0600097E RID: 2430 RVA: 0x00042390 File Offset: 0x00040590
		private bool EditedNameIsAllowed(string text, ComboBoxSchemeControl toBeRenamedControl)
		{
			if (string.IsNullOrEmpty(text.Trim()))
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this.CanvasWindow.SidebarWindow, LocaleStrings.GetLocalizedString("STRING_INVALID_NAME", false), 1.3, false);
				return false;
			}
			foreach (object obj in this.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children)
			{
				ComboBoxSchemeControl comboBoxSchemeControl = (ComboBoxSchemeControl)obj;
				if (comboBoxSchemeControl.mSchemeName.Text.ToLower().Trim() == text.ToLower().Trim() && comboBoxSchemeControl != toBeRenamedControl)
				{
					this.ParentWindow.mCommonHandler.AddToastPopup(this.CanvasWindow.SidebarWindow, LocaleStrings.GetLocalizedString("STRING_INVALID_NAME", false), 1.3, false);
					return false;
				}
				if (comboBoxSchemeControl.mSchemeName.Text.Trim().IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
				{
					string message = string.Format("{0} {1} {2}", LocaleStrings.GetLocalizedString("STRING_SCHEME_INVALID_CHARACTERS", false), Environment.NewLine, "\\ / : * ? \" < > |");
					this.ParentWindow.mCommonHandler.AddToastPopup(this.CanvasWindow.SidebarWindow, message, 3.0, false);
					return false;
				}
			}
			return true;
		}

		// Token: 0x0600097F RID: 2431 RVA: 0x0004250C File Offset: 0x0004070C
		private void CopyImg_MouseDown(object sender, MouseButtonEventArgs e)
		{
			bool flag = false;
			foreach (object obj in this.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children)
			{
				ComboBoxSchemeControl comboBoxSchemeControl = (ComboBoxSchemeControl)obj;
				if (!comboBoxSchemeControl.mSchemeName.IsReadOnly)
				{
					this.HandleNameEdit(comboBoxSchemeControl);
					flag = true;
					e.Handled = true;
					break;
				}
			}
			if (!flag)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeName.Text]);
			}
			e.Handled = true;
		}

		// Token: 0x06000980 RID: 2432 RVA: 0x000425C4 File Offset: 0x000407C4
		private void DeleteImg_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!this.mSchemeName.IsReadOnly)
			{
				this.HandleNameEdit(this);
			}
			if (!this.ParentWindow.EngineInstanceRegistry.ShowSchemeDeletePopup)
			{
				this.DeleteControlScheme();
				e.Handled = true;
				return;
			}
			this.mDeleteScriptMessageWindow = new CustomMessageWindow();
			this.mDeleteScriptMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_BLUESTACKS", false);
			this.mDeleteScriptMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_DELETE_SCHEME_CONFIRMATION", false);
			this.mDeleteScriptMessageWindow.CheckBox.Content = LocaleStrings.GetLocalizedString("STRING_DOWNLOAD_GOOGLE_APP_POPUP_STRING_04", false);
			this.mDeleteScriptMessageWindow.CheckBox.Visibility = Visibility.Visible;
			this.mDeleteScriptMessageWindow.CheckBox.IsChecked = new bool?(false);
			this.mDeleteScriptMessageWindow.AddButton(ButtonColors.Blue, LocaleStrings.GetLocalizedString("STRING_DELETE", false), new EventHandler(this.UpdateSettingsAndDeleteScheme), null, false, null);
			this.mDeleteScriptMessageWindow.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_CANCEL", false), delegate(object o, EventArgs evt)
			{
				KeymapCanvasWindow.sIsDirty = false;
				GameControlWindow.sIsDirty = false;
			}, null, false, null);
			this.mDeleteScriptMessageWindow.CloseButtonHandle(delegate(object o, EventArgs evt)
			{
			}, null);
			this.mDeleteScriptMessageWindow.Owner = this.CanvasWindow;
			this.mDeleteScriptMessageWindow.ShowDialog();
			e.Handled = true;
		}

		// Token: 0x06000981 RID: 2433 RVA: 0x00042738 File Offset: 0x00040938
		private void UpdateSettingsAndDeleteScheme(object sender, EventArgs e)
		{
			this.ParentWindow.EngineInstanceRegistry.ShowSchemeDeletePopup = !this.mDeleteScriptMessageWindow.CheckBox.IsChecked.Value;
			this.mDeleteScriptMessageWindow = null;
			this.DeleteControlScheme();
		}

		// Token: 0x06000982 RID: 2434 RVA: 0x00042780 File Offset: 0x00040980
		private void DeleteControlScheme()
		{
			if (this.ParentWindow.SelectedConfig.ControlSchemesDict.ContainsKey(this.mSchemeName.Text) && !this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeName.Text].BuiltIn)
			{
				if (this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeName.Text].Selected)
				{
					this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeName.Text].Selected = false;
					if (this.ParentWindow.SelectedConfig.ControlSchemes.Count > 1)
					{
						if (this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem == (this.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children[0] as ComboBoxSchemeControl).mSchemeName.Text.ToString())
						{
							this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem = (this.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children[1] as ComboBoxSchemeControl).mSchemeName.Text.ToString();
						}
						else
						{
							this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem = (this.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children[0] as ComboBoxSchemeControl).mSchemeName.Text.ToString();
						}
						this.ParentWindow.SelectedConfig.ControlSchemesDict[this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem].Selected = true;
						this.CanvasWindow.SidebarWindow.mSchemeComboBox.mName.Text = this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem;
						this.ParentWindow.SelectedConfig.SelectedControlScheme = this.ParentWindow.SelectedConfig.ControlSchemesDict[this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem];
						this.CanvasWindow.SidebarWindow.ProfileChanged();
					}
					else
					{
						this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem = null;
						BlueStacksUIBinding.Bind(this.CanvasWindow.SidebarWindow.mSchemeComboBox.mName, "Custom", "");
					}
				}
				this.ParentWindow.SelectedConfig.ControlSchemes.Remove(this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeName.Text]);
				this.ParentWindow.SelectedConfig.ControlSchemesDict.Remove(this.mSchemeName.Text);
				ComboBoxSchemeControl comboBoxSchemeControlFromName = KMManager.GetComboBoxSchemeControlFromName(this.mSchemeName.Text);
				if (comboBoxSchemeControlFromName != null)
				{
					this.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children.Remove(comboBoxSchemeControlFromName);
				}
				KeymapCanvasWindow.sIsDirty = true;
				KMManager.Init(this.ParentWindow);
				this.CanvasWindow.SidebarWindow.FillProfileCombo();
				if (this.ParentWindow.SelectedConfig.ControlSchemes.Count == 0)
				{
					this.CanvasWindow.ClearWindow();
				}
			}
		}

		// Token: 0x06000983 RID: 2435 RVA: 0x00042AE0 File Offset: 0x00040CE0
		private void ComboBoxItem_MouseDown(object sender, MouseButtonEventArgs e)
		{
			bool flag = false;
			foreach (object obj in this.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children)
			{
				ComboBoxSchemeControl comboBoxSchemeControl = (ComboBoxSchemeControl)obj;
				if (!comboBoxSchemeControl.mSchemeName.IsReadOnly)
				{
					this.HandleNameEdit(comboBoxSchemeControl);
					flag = true;
					e.Handled = true;
					break;
				}
			}
			if (!flag)
			{
				if (this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem == this.mSchemeName.Text)
				{
					return;
				}
				if (this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem != null)
				{
					this.ParentWindow.SelectedConfig.ControlSchemesDict[this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem].Selected = false;
				}
				this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeName.Text].Selected = true;
				this.ParentWindow.SelectedConfig.ControlSchemesDict[this.ParentWindow.SelectedConfig.SelectedControlScheme.Name].Selected = false;
				this.ParentWindow.SelectedConfig.SelectedControlScheme = this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeName.Text];
				this.CanvasWindow.SidebarWindow.FillProfileCombo();
				this.CanvasWindow.SidebarWindow.ProfileChanged();
				KeymapCanvasWindow.sIsDirty = true;
			}
		}

		// Token: 0x06000984 RID: 2436 RVA: 0x00004B27 File Offset: 0x00002D27
		private void ComboBoxItem_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x06000985 RID: 2437 RVA: 0x00007E6B File Offset: 0x0000606B
		private void ComboBoxItem_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.mSchemeName.Text != this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem)
			{
				BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "ComboBoxBackgroundColor");
			}
		}

		// Token: 0x06000986 RID: 2438 RVA: 0x00007EA4 File Offset: 0x000060A4
		private void ComboBoxItem_LostFocus(object sender, RoutedEventArgs e)
		{
			if (this.mSchemeName.Focusable)
			{
				this.HandleNameEdit(this);
			}
			e.Handled = true;
		}

		// Token: 0x06000987 RID: 2439 RVA: 0x00042C88 File Offset: 0x00040E88
		private void HandleNameEdit(ComboBoxSchemeControl control)
		{
			control.mEditImg.Visibility = Visibility.Visible;
			control.mSaveImg.Visibility = Visibility.Collapsed;
			if (this.EditedNameIsAllowed(control.mSchemeName.Text, control))
			{
				if (this.ParentWindow.SelectedConfig.ControlSchemesDict.ContainsKey(control.mOldSchemeName))
				{
					this.ParentWindow.SelectedConfig.ControlSchemesDict[control.mOldSchemeName].Name = control.mSchemeName.Text.Trim();
					this.CanvasWindow.SidebarWindow.FillProfileCombo();
					KeymapCanvasWindow.sIsDirty = true;
				}
			}
			else
			{
				control.mSchemeName.Text = control.mOldSchemeName;
			}
			control.mSchemeName.Focusable = false;
			control.mSchemeName.IsReadOnly = true;
		}

		// Token: 0x06000988 RID: 2440 RVA: 0x00007EC1 File Offset: 0x000060C1
		private void MSchemeName_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Return)
			{
				this.HandleNameEdit(this);
			}
		}

		// Token: 0x06000989 RID: 2441 RVA: 0x00042D50 File Offset: 0x00040F50
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/comboboxschemecontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600098A RID: 2442 RVA: 0x00042D80 File Offset: 0x00040F80
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((ComboBoxSchemeControl)target).MouseDown += this.ComboBoxItem_MouseDown;
				((ComboBoxSchemeControl)target).MouseEnter += this.ComboBoxItem_MouseEnter;
				((ComboBoxSchemeControl)target).MouseLeave += this.ComboBoxItem_MouseLeave;
				((ComboBoxSchemeControl)target).LostFocus += this.ComboBoxItem_LostFocus;
				return;
			case 2:
				this.mSchemeControl = (Grid)target;
				return;
			case 3:
				this.mBookmarkImg = (CustomPictureBox)target;
				this.mBookmarkImg.MouseDown += this.Bookmark_img_MouseDown;
				return;
			case 4:
				this.mSchemeName = (CustomTextBox)target;
				this.mSchemeName.KeyUp += this.MSchemeName_KeyUp;
				return;
			case 5:
				this.mEditImg = (CustomPictureBox)target;
				this.mEditImg.MouseDown += this.EditImg_MouseDown;
				return;
			case 6:
				this.mSaveImg = (CustomPictureBox)target;
				this.mSaveImg.MouseDown += this.SaveImg_MouseDown;
				return;
			case 7:
				this.mCopyImg = (CustomPictureBox)target;
				this.mCopyImg.MouseDown += this.CopyImg_MouseDown;
				return;
			case 8:
				this.mDeleteImg = (CustomPictureBox)target;
				this.mDeleteImg.MouseDown += this.DeleteImg_MouseDown;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040006DC RID: 1756
		private KeymapCanvasWindow CanvasWindow;

		// Token: 0x040006DD RID: 1757
		private MainWindow ParentWindow;

		// Token: 0x040006DE RID: 1758
		private CustomMessageWindow mDeleteScriptMessageWindow;

		// Token: 0x040006DF RID: 1759
		internal string mOldSchemeName;

		// Token: 0x040006E0 RID: 1760
		internal Grid mSchemeControl;

		// Token: 0x040006E1 RID: 1761
		internal CustomPictureBox mBookmarkImg;

		// Token: 0x040006E2 RID: 1762
		internal CustomTextBox mSchemeName;

		// Token: 0x040006E3 RID: 1763
		internal CustomPictureBox mEditImg;

		// Token: 0x040006E4 RID: 1764
		internal CustomPictureBox mSaveImg;

		// Token: 0x040006E5 RID: 1765
		internal CustomPictureBox mCopyImg;

		// Token: 0x040006E6 RID: 1766
		internal CustomPictureBox mDeleteImg;

		// Token: 0x040006E7 RID: 1767
		private bool _contentLoaded;
	}
}
