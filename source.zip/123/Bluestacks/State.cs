﻿using System;
using System.ComponentModel;

// Token: 0x02000010 RID: 16
[Description("Independent")]
[Serializable]
public class State : IMAction
{
	// Token: 0x17000080 RID: 128
	// (get) Token: 0x06000110 RID: 272 RVA: 0x00002B1B File Offset: 0x00000D1B
	// (set) Token: 0x06000111 RID: 273 RVA: 0x00002B23 File Offset: 0x00000D23
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X
	{
		get
		{
			return this.mX;
		}
		set
		{
			this.mX = value;
		}
	}

	// Token: 0x17000081 RID: 129
	// (get) Token: 0x06000112 RID: 274 RVA: 0x00002B2C File Offset: 0x00000D2C
	// (set) Token: 0x06000113 RID: 275 RVA: 0x00002B34 File Offset: 0x00000D34
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y
	{
		get
		{
			return this.mY;
		}
		set
		{
			this.mY = value;
		}
	}

	// Token: 0x17000082 RID: 130
	// (get) Token: 0x06000114 RID: 276 RVA: 0x00002B3D File Offset: 0x00000D3D
	// (set) Token: 0x06000115 RID: 277 RVA: 0x00002B45 File Offset: 0x00000D45
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Name
	{
		get
		{
			return this.mName;
		}
		set
		{
			this.mName = value;
		}
	}

	// Token: 0x17000083 RID: 131
	// (get) Token: 0x06000116 RID: 278 RVA: 0x00002B4E File Offset: 0x00000D4E
	// (set) Token: 0x06000117 RID: 279 RVA: 0x00002B56 File Offset: 0x00000D56
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key
	{
		get
		{
			return this.mKey;
		}
		set
		{
			this.mKey = value;
		}
	}

	// Token: 0x17000084 RID: 132
	// (get) Token: 0x06000118 RID: 280 RVA: 0x00002B5F File Offset: 0x00000D5F
	// (set) Token: 0x06000119 RID: 281 RVA: 0x00002B67 File Offset: 0x00000D67
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key_alt1
	{
		get
		{
			return this.mKey_alt1;
		}
		set
		{
			this.mKey_alt1 = value;
		}
	}

	// Token: 0x17000085 RID: 133
	// (get) Token: 0x0600011A RID: 282 RVA: 0x00002B70 File Offset: 0x00000D70
	// (set) Token: 0x0600011B RID: 283 RVA: 0x00002B78 File Offset: 0x00000D78
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Model
	{
		get
		{
			return this.mModel;
		}
		set
		{
			this.mModel = value;
		}
	}

	// Token: 0x17000086 RID: 134
	// (get) Token: 0x0600011C RID: 284 RVA: 0x00002B81 File Offset: 0x00000D81
	// (set) Token: 0x0600011D RID: 285 RVA: 0x00002B89 File Offset: 0x00000D89
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int Delay
	{
		get
		{
			return this.mDelay;
		}
		set
		{
			this.mDelay = value;
		}
	}

	// Token: 0x04000083 RID: 131
	private double mX = -1.0;

	// Token: 0x04000084 RID: 132
	private double mY = -1.0;

	// Token: 0x04000085 RID: 133
	private string mName = string.Empty;

	// Token: 0x04000086 RID: 134
	private string mKey;

	// Token: 0x04000087 RID: 135
	private string mKey_alt1;

	// Token: 0x04000088 RID: 136
	private string mModel = string.Empty;

	// Token: 0x04000089 RID: 137
	private int mDelay;
}
