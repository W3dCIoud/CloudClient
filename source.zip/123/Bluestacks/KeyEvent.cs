﻿using System;

// Token: 0x02000009 RID: 9
[Serializable]
public class KeyEvent : IMAction
{
	// Token: 0x17000057 RID: 87
	// (get) Token: 0x060000B8 RID: 184 RVA: 0x000027DF File Offset: 0x000009DF
	// (set) Token: 0x060000B9 RID: 185 RVA: 0x000027E7 File Offset: 0x000009E7
	public string Key
	{
		get
		{
			return this.mKey;
		}
		set
		{
			this.mKey = value;
		}
	}

	// Token: 0x17000058 RID: 88
	// (get) Token: 0x060000BA RID: 186 RVA: 0x000027F0 File Offset: 0x000009F0
	// (set) Token: 0x060000BB RID: 187 RVA: 0x000027F8 File Offset: 0x000009F8
	public int HoldTime
	{
		get
		{
			return this.mHoldTime;
		}
		set
		{
			this.mHoldTime = value;
		}
	}

	// Token: 0x17000059 RID: 89
	// (get) Token: 0x060000BC RID: 188 RVA: 0x00002801 File Offset: 0x00000A01
	// (set) Token: 0x060000BD RID: 189 RVA: 0x00002809 File Offset: 0x00000A09
	public object KeyDownEvents
	{
		get
		{
			return this.mKeyDownEvents;
		}
		set
		{
			this.mKeyDownEvents = value;
		}
	}

	// Token: 0x1700005A RID: 90
	// (get) Token: 0x060000BE RID: 190 RVA: 0x00002812 File Offset: 0x00000A12
	// (set) Token: 0x060000BF RID: 191 RVA: 0x0000281A File Offset: 0x00000A1A
	public object KeyUpEvents
	{
		get
		{
			return this.mKeyUpEvents;
		}
		set
		{
			this.mKeyUpEvents = value;
		}
	}

	// Token: 0x0400005A RID: 90
	private string mKey;

	// Token: 0x0400005B RID: 91
	private int mHoldTime;

	// Token: 0x0400005C RID: 92
	private object mKeyDownEvents;

	// Token: 0x0400005D RID: 93
	private object mKeyUpEvents;
}
