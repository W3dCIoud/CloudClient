﻿using System;
using System.ComponentModel;

// Token: 0x0200000F RID: 15
[Description("Independent")]
[Serializable]
public class Script : IMAction
{
	// Token: 0x1700007A RID: 122
	// (get) Token: 0x06000103 RID: 259 RVA: 0x00002AB5 File Offset: 0x00000CB5
	// (set) Token: 0x06000104 RID: 260 RVA: 0x00002ABD File Offset: 0x00000CBD
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X
	{
		get
		{
			return this.mX;
		}
		set
		{
			this.mX = value;
		}
	}

	// Token: 0x1700007B RID: 123
	// (get) Token: 0x06000105 RID: 261 RVA: 0x00002AC6 File Offset: 0x00000CC6
	// (set) Token: 0x06000106 RID: 262 RVA: 0x00002ACE File Offset: 0x00000CCE
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y
	{
		get
		{
			return this.mY;
		}
		set
		{
			this.mY = value;
		}
	}

	// Token: 0x1700007C RID: 124
	// (get) Token: 0x06000107 RID: 263 RVA: 0x00002AD7 File Offset: 0x00000CD7
	// (set) Token: 0x06000108 RID: 264 RVA: 0x00002ADF File Offset: 0x00000CDF
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key
	{
		get
		{
			return this.mKey;
		}
		set
		{
			this.mKey = value;
		}
	}

	// Token: 0x1700007D RID: 125
	// (get) Token: 0x06000109 RID: 265 RVA: 0x00002AE8 File Offset: 0x00000CE8
	// (set) Token: 0x0600010A RID: 266 RVA: 0x00002AF0 File Offset: 0x00000CF0
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key_alt1
	{
		get
		{
			return this.mKey_1;
		}
		set
		{
			this.mKey_1 = value;
		}
	}

	// Token: 0x1700007E RID: 126
	// (get) Token: 0x0600010B RID: 267 RVA: 0x00002AF9 File Offset: 0x00000CF9
	// (set) Token: 0x0600010C RID: 268 RVA: 0x00002B01 File Offset: 0x00000D01
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool ShowOnOverlay
	{
		get
		{
			return this.mShowOnOverlay;
		}
		set
		{
			this.mShowOnOverlay = value;
		}
	}

	// Token: 0x1700007F RID: 127
	// (get) Token: 0x0600010D RID: 269 RVA: 0x00002B0A File Offset: 0x00000D0A
	// (set) Token: 0x0600010E RID: 270 RVA: 0x00002B12 File Offset: 0x00000D12
	public string[] Commands
	{
		get
		{
			return this.mCommands;
		}
		set
		{
			this.mCommands = value;
		}
	}

	// Token: 0x0400007D RID: 125
	private double mX = -1.0;

	// Token: 0x0400007E RID: 126
	private double mY = -1.0;

	// Token: 0x0400007F RID: 127
	private string mKey;

	// Token: 0x04000080 RID: 128
	private string mKey_1 = string.Empty;

	// Token: 0x04000081 RID: 129
	internal bool mShowOnOverlay = true;

	// Token: 0x04000082 RID: 130
	internal string[] mCommands = new string[]
	{
		""
	};
}
