﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001DF RID: 479
	public class FrontendPopupControl : UserControl, IComponentConnector
	{
		// Token: 0x170001FA RID: 506
		// (get) Token: 0x0600108F RID: 4239 RVA: 0x0000BD02 File Offset: 0x00009F02
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x06001090 RID: 4240 RVA: 0x0000BD23 File Offset: 0x00009F23
		public FrontendPopupControl()
		{
			this.InitializeComponent();
			this.RequestedAppDisplayed = (EventHandler<EventArgs>)Delegate.Combine(this.RequestedAppDisplayed, new EventHandler<EventArgs>(this.RequestedApp_Displayed));
		}

		// Token: 0x06001091 RID: 4241 RVA: 0x000679CC File Offset: 0x00065BCC
		private void ProcessArgs(string googlePlayStoreArg, bool isWindowForcedTillLoaded)
		{
			this.mGooglePlayStoreArg = googlePlayStoreArg;
			this.mIsWindowForcedTillLoaded = isWindowForcedTillLoaded;
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mBaseControl.Init(this, this.ParentWindow.mFrontendGrid, false, isWindowForcedTillLoaded);
				this.mBaseControl.DimBackground();
				this.ParentWindow.mCommonHandler.SetCustomCursorForApp("com.android.vending");
				if (this.mAction == PlayStoreAction.OpenApp)
				{
					if (this.ParentWindow.mAppHandler.IsAppInstalled(googlePlayStoreArg))
					{
						this.ParentWindow.mAppHandler.SendRunAppRequestAsync(googlePlayStoreArg, "", false);
					}
					else
					{
						AppHandler.EventOnAppDisplayed = this.RequestedAppDisplayed;
						this.ParentWindow.mAppHandler.LaunchPlayRequestAsync(googlePlayStoreArg);
					}
					this.ParentWindow.mAppHandler.SwitchWhenPackageNameRecieved = "com.android.vending";
					return;
				}
				if (this.mAction == PlayStoreAction.SearchApp)
				{
					AppHandler.EventOnAppDisplayed = this.RequestedAppDisplayed;
					this.ParentWindow.mAppHandler.SendSearchPlayRequestAsync(googlePlayStoreArg);
					this.ParentWindow.mAppHandler.SwitchWhenPackageNameRecieved = "com.android.vending";
					return;
				}
				if (this.mAction == PlayStoreAction.CustomActivity)
				{
					AppHandler.EventOnAppDisplayed = this.RequestedAppDisplayed;
					this.ParentWindow.mAppHandler.SwitchWhenPackageNameRecieved = "com.android.vending";
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					dictionary.Add("action", googlePlayStoreArg);
					this.ParentWindow.mAppHandler.StartCustomActivity(dictionary);
				}
			}), new object[0]);
		}

		// Token: 0x06001092 RID: 4242 RVA: 0x0000BD53 File Offset: 0x00009F53
		internal void Reload()
		{
			if (base.Visibility == Visibility.Visible && !string.IsNullOrEmpty(this.mGooglePlayStoreArg))
			{
				this.ProcessArgs(this.mGooglePlayStoreArg, this.mIsWindowForcedTillLoaded);
			}
		}

		// Token: 0x06001093 RID: 4243 RVA: 0x0000BD7C File Offset: 0x00009F7C
		internal void RequestedApp_Displayed(object sender, EventArgs e)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mBaseControl.ShowContent();
			}), new object[0]);
		}

		// Token: 0x06001094 RID: 4244 RVA: 0x00067A2C File Offset: 0x00065C2C
		internal void Init(string args, string appName, PlayStoreAction action, bool isWindowForcedTillLoaded = false)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (!this.ParentWindow.mGuestBootCompleted)
				{
					CustomMessageWindow customMessageWindow = new CustomMessageWindow();
					customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
					BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_GUEST_NOT_BOOTED", "");
					customMessageWindow.Owner = this.ParentWindow;
					customMessageWindow.ShowDialog();
					return;
				}
				if (action == PlayStoreAction.OpenApp && this.ParentWindow.mAppHandler.IsAppInstalled(args) && !"com.android.vending".Equals(args, StringComparison.InvariantCultureIgnoreCase))
				{
					AppIcon appIcon = this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon(args);
					if (appIcon != null)
					{
						if (appIcon.IsAppIncompat)
						{
							appIcon.HandleCompatibility();
							return;
						}
						this.ParentWindow.mTopBar.mAppTabButtons.AddAppTab(appIcon.AppName, appIcon.PackageName, appIcon.ActivityName, appIcon.ImageName, true, true, appIcon.PackageName, false);
						return;
					}
				}
				else if (!string.IsNullOrEmpty(args))
				{
					if (!this.ParentWindow.WelcomeTabParentGrid.IsVisible)
					{
						this.ParentWindow.mCommonHandler.HomeButtonHandler(false, false);
					}
					this.mBaseControl.mTitleLabel.Content = appName;
					this.mAction = action;
					this.Visibility = Visibility.Visible;
					this.ParentWindow.ChangeOrientationFromClient(false, false);
					this.ProcessArgs(args, isWindowForcedTillLoaded);
				}
			}), new object[0]);
		}

		// Token: 0x06001095 RID: 4245 RVA: 0x0000BD9C File Offset: 0x00009F9C
		internal void HideWindow()
		{
			this.mBaseControl.HideWindow();
		}

		// Token: 0x06001096 RID: 4246 RVA: 0x00067A84 File Offset: 0x00065C84
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/frontendpopupcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06001097 RID: 4247 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06001098 RID: 4248 RVA: 0x0000BDA9 File Offset: 0x00009FA9
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mBaseControl = (DimControlWithProgresBar)target;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x04000B43 RID: 2883
		private MainWindow mMainWindow;

		// Token: 0x04000B44 RID: 2884
		public PlayStoreAction mAction;

		// Token: 0x04000B45 RID: 2885
		private EventHandler<EventArgs> RequestedAppDisplayed;

		// Token: 0x04000B46 RID: 2886
		private string mGooglePlayStoreArg;

		// Token: 0x04000B47 RID: 2887
		private bool mIsWindowForcedTillLoaded;

		// Token: 0x04000B48 RID: 2888
		internal DimControlWithProgresBar mBaseControl;

		// Token: 0x04000B49 RID: 2889
		private bool _contentLoaded;
	}
}
