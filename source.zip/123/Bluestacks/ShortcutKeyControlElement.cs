﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000069 RID: 105
	public class ShortcutKeyControlElement : UserControl, IComponentConnector
	{
		// Token: 0x17000137 RID: 311
		// (get) Token: 0x0600048A RID: 1162 RVA: 0x000050B9 File Offset: 0x000032B9
		// (set) Token: 0x0600048B RID: 1163 RVA: 0x000050C1 File Offset: 0x000032C1
		internal List<ShortcutKeys> mUserDefinedConfigList { get; set; }

		// Token: 0x0600048C RID: 1164 RVA: 0x0001E1A0 File Offset: 0x0001C3A0
		public ShortcutKeyControlElement(MainWindow window, SettingsWindow settingsWindow)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			this.ParentSettingsWindow = settingsWindow;
			InputMethod.SetIsInputMethodEnabled(this.mShortcutKeyTextBox, false);
			foreach (string value in this.ParentWindow.mCommonHandler.mShortcutsConfigInstance.DefaultModifier.Split(new char[]
			{
				','
			}, StringSplitOptions.RemoveEmptyEntries))
			{
				Key key = (Key)Enum.Parse(typeof(Key), value);
				this.mDefaultModifierForUI = this.mDefaultModifierForUI + IMAPKeys.GetStringForUI(key) + " + ";
				this.mDefaultModifierForFile = this.mDefaultModifierForFile + IMAPKeys.GetStringForFile(key) + " + ";
			}
		}

		// Token: 0x0600048D RID: 1165 RVA: 0x00004BF2 File Offset: 0x00002DF2
		private void mShortcutKeyTextBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
		}

		// Token: 0x0600048E RID: 1166 RVA: 0x000050CA File Offset: 0x000032CA
		private bool IsValid(Key key)
		{
			return key != Key.LeftAlt && key != Key.RightAlt && key != Key.LeftShift && key != Key.RightShift && key != Key.LeftCtrl && key != Key.RightCtrl && key != Key.None && key != Key.System;
		}

		// Token: 0x0600048F RID: 1167 RVA: 0x000050F8 File Offset: 0x000032F8
		private void ShortcutKeyTextBoxKeyUp(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Snapshot || e.SystemKey == Key.Snapshot)
			{
				this.HandleShortcutKeyDown(e);
			}
		}

		// Token: 0x06000490 RID: 1168 RVA: 0x00005115 File Offset: 0x00003315
		private void ShortcutKeyTextBoxKeyDown(object sender, KeyEventArgs e)
		{
			this.HandleShortcutKeyDown(e);
		}

		// Token: 0x06000491 RID: 1169 RVA: 0x0001E270 File Offset: 0x0001C470
		private void HandleShortcutKeyDown(KeyEventArgs e)
		{
			Logger.Debug("SHORTCUT: PrintKey............" + e.Key);
			Logger.Debug("SHORTCUT: PrintSystemKey............" + e.SystemKey);
			if (((IMAPKeys.mDictKeys.ContainsKey(e.Key) || IMAPKeys.mDictKeys.ContainsKey(e.SystemKey)) && (this.IsValid(e.Key) || this.IsValid(e.SystemKey))) || e.Key == Key.Back || e.Key == Key.Delete)
			{
				string text = string.Empty;
				string text2 = string.Empty;
				string str = string.Empty;
				this.mShortcutKeyTextBox.Tag = string.Empty;
				if (e.KeyboardDevice.Modifiers != ModifierKeys.None)
				{
					if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
					{
						text = IMAPKeys.GetStringForUI(Key.LeftCtrl) + " + ";
						this.mShortcutKeyTextBox.Tag = IMAPKeys.GetStringForFile(Key.LeftCtrl) + " + ";
					}
					if (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt))
					{
						text2 = IMAPKeys.GetStringForUI(Key.LeftAlt) + " + ";
						CustomTextBox customTextBox = this.mShortcutKeyTextBox;
						customTextBox.Tag = customTextBox.Tag + IMAPKeys.GetStringForFile(Key.LeftAlt) + " + ";
					}
					if (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift))
					{
						str = IMAPKeys.GetStringForUI(Key.LeftShift) + " + ";
						CustomTextBox customTextBox2 = this.mShortcutKeyTextBox;
						customTextBox2.Tag = customTextBox2.Tag + IMAPKeys.GetStringForFile(Key.LeftShift) + " + ";
					}
					if ((string.IsNullOrEmpty(text) && !string.IsNullOrEmpty(text2)) || e.SystemKey == Key.F10)
					{
						this.mShortcutKeyTextBox.Text = text + text2 + str + IMAPKeys.GetStringForUI(e.SystemKey);
						CustomTextBox customTextBox3 = this.mShortcutKeyTextBox;
						customTextBox3.Tag += IMAPKeys.GetStringForFile(e.SystemKey);
					}
					else
					{
						this.mShortcutKeyTextBox.Text = text + text2 + str + IMAPKeys.GetStringForUI(e.Key);
						CustomTextBox customTextBox4 = this.mShortcutKeyTextBox;
						customTextBox4.Tag += IMAPKeys.GetStringForFile(e.Key);
					}
				}
				else if (e.Key == Key.Back || e.Key == Key.Delete)
				{
					this.mShortcutKeyTextBox.Text = string.Empty;
					this.mShortcutKeyTextBox.Tag = string.Empty;
					if (this.ParentSettingsWindow.mDuplicateShortcutsList.Contains(this.mShortcutNameTextBlock.Text))
					{
						this.ParentSettingsWindow.mDuplicateShortcutsList.Remove(this.mShortcutNameTextBlock.Text);
					}
					this.SetSaveButtonState(this.mErrorMessageShown, this.ParentSettingsWindow.mIsShortcutEdited);
				}
				else if (e.Key == Key.Escape)
				{
					if (this.mDefaultModifierForFile.Equals("Shift + "))
					{
						this.mShortcutKeyTextBox.Text = this.mDefaultModifierForUI + IMAPKeys.GetStringForUI(e.Key);
						this.mShortcutKeyTextBox.Tag = this.mDefaultModifierForFile + IMAPKeys.GetStringForFile(e.Key);
					}
				}
				else if ((e.Key == Key.D0 || e.SystemKey == Key.D0) && this.mDefaultModifierForUI.Equals("Ctrl + Shift + "))
				{
					this.mShortcutKeyTextBox.Text = string.Empty;
					this.mShortcutKeyTextBox.Tag = string.Empty;
					this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_WINDOW_ACTION_ERROR", false));
				}
				else if (e.Key == Key.System)
				{
					this.mShortcutKeyTextBox.Text = this.mDefaultModifierForUI + IMAPKeys.GetStringForUI(e.SystemKey);
					this.mShortcutKeyTextBox.Tag = this.mDefaultModifierForFile + IMAPKeys.GetStringForFile(e.SystemKey);
				}
				else
				{
					this.mShortcutKeyTextBox.Text = this.mDefaultModifierForUI + IMAPKeys.GetStringForUI(e.Key);
					this.mShortcutKeyTextBox.Tag = this.mDefaultModifierForFile + IMAPKeys.GetStringForFile(e.Key);
				}
				e.Handled = true;
				this.mShortcutKeyTextBox.CaretIndex = this.mShortcutKeyTextBox.Text.Length;
				this.mIsShortcutSameAsMacroShortcut = false;
				if ((MainWindow.sMacroMapping.ContainsKey(IMAPKeys.GetStringForUI(e.Key)) || MainWindow.sMacroMapping.ContainsKey(IMAPKeys.GetStringForUI(e.SystemKey))) && (this.mShortcutKeyTextBox.Text.Equals(text + text2 + e.Key) || this.mShortcutKeyTextBox.Text.Equals(text + text2 + e.SystemKey)))
				{
					this.mIsShortcutSameAsMacroShortcut = true;
				}
				if (this.mShortcutKeyTextBox.Text.Equals("Alt + F4"))
				{
					this.mShortcutKeyTextBox.Text = string.Empty;
					this.mShortcutKeyTextBox.Tag = string.Empty;
					this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_WINDOW_ACTION_ERROR", false));
				}
				foreach (ShortcutKeys shortcutKeys in this.mUserDefinedConfigList)
				{
					this.mShortcutKeyTextBox.InputTextValidity = TextValidityOptions.Success;
					this.mKeyInfoPopup.IsOpen = false;
					this.ParentSettingsWindow.mIsShortcutEdited = true;
					this.CheckIfShortcutAlreadyUsed();
					if (LocaleStrings.GetLocalizedString(shortcutKeys.ShortcutName, false).ToString().Equals(this.mShortcutNameTextBlock.Text) && !shortcutKeys.ShortcutKey.Equals(this.mShortcutKeyTextBox.Text))
					{
						shortcutKeys.ShortcutKey = this.mShortcutKeyTextBox.Tag.ToString();
						Stats.SendMiscellaneousStatsAsync("KeyboardShortcuts", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "shortcut_edit", this.mShortcutNameTextBlock.Text, null, null, null, null, "Android", 0);
					}
				}
			}
		}

		// Token: 0x06000492 RID: 1170 RVA: 0x0001E870 File Offset: 0x0001CA70
		private void AddToastPopup(string message)
		{
			try
			{
				if (this.mToastPopup == null)
				{
					this.mToastPopup = new CustomToastPopupControl(this.ParentSettingsWindow);
				}
				this.mToastPopup.Init(this.ParentSettingsWindow, message, null, null, HorizontalAlignment.Center, VerticalAlignment.Top, null, 12, null, null);
				this.mToastPopup.Margin = new Thickness(20.0, 30.0, 0.0, 0.0);
				this.mToastPopup.ShowPopup(1.3);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in showing toast popup: " + ex.ToString());
			}
		}

		// Token: 0x06000493 RID: 1171 RVA: 0x0001E934 File Offset: 0x0001CB34
		private void CheckIfShortcutAlreadyUsed()
		{
			this.mErrorMessageShown = false;
			foreach (ShortcutKeys shortcutKeys in this.ParentWindow.mCommonHandler.mShortcutsConfigInstance.Shortcut)
			{
				if ((!string.IsNullOrEmpty(shortcutKeys.ShortcutKey) && shortcutKeys.ShortcutKey.Equals(this.mShortcutKeyTextBox.Tag.ToString()) && !LocaleStrings.GetLocalizedString(shortcutKeys.ShortcutName, false).ToString().Equals(this.mShortcutNameTextBlock.Text)) || this.mIsShortcutSameAsMacroShortcut)
				{
					this.mKeyInfoPopup.PlacementTarget = this.mShortcutKeyTextBox;
					this.mShortcutKeyTextBox.InputTextValidity = TextValidityOptions.Error;
					this.mKeyInfoPopup.IsOpen = true;
					this.mErrorMessageShown = true;
					if (!this.ParentSettingsWindow.mDuplicateShortcutsList.Contains(this.mShortcutNameTextBlock.Text))
					{
						this.ParentSettingsWindow.mDuplicateShortcutsList.Add(this.mShortcutNameTextBlock.Text);
					}
				}
			}
			if (!this.mErrorMessageShown && this.ParentSettingsWindow.mDuplicateShortcutsList.Contains(this.mShortcutNameTextBlock.Text))
			{
				this.ParentSettingsWindow.mDuplicateShortcutsList.Remove(this.mShortcutNameTextBlock.Text);
			}
			this.SetSaveButtonState(this.mErrorMessageShown, this.ParentSettingsWindow.mIsShortcutEdited);
		}

		// Token: 0x06000494 RID: 1172 RVA: 0x0001EAB4 File Offset: 0x0001CCB4
		private void SetSaveButtonState(bool isErrorMessageShown, bool isEdited)
		{
			if (this.ParentSettingsWindow.mDuplicateShortcutsList.Count<string>() == 0 && isEdited)
			{
				this.ParentWindow.mCommonHandler.OnShortcutKeysChanged(true);
				this.ParentSettingsWindow.mIsShortcutSaveBtnEnabled = true;
				return;
			}
			this.ParentWindow.mCommonHandler.OnShortcutKeysChanged(false);
			this.ParentSettingsWindow.mIsShortcutSaveBtnEnabled = false;
		}

		// Token: 0x06000495 RID: 1173 RVA: 0x0001EB14 File Offset: 0x0001CD14
		private void ShortcutKeyTextBoxMouseEnter(object sender, MouseEventArgs e)
		{
			if (this.mShortcutKeyTextBox.InputTextValidity == TextValidityOptions.Error)
			{
				this.mKeyInfoPopup.PlacementTarget = this.mShortcutKeyTextBox;
				this.mKeyInfoPopup.IsOpen = true;
				this.mKeyInfoPopup.StaysOpen = true;
				return;
			}
			this.mKeyInfoPopup.IsOpen = false;
		}

		// Token: 0x06000496 RID: 1174 RVA: 0x0000511E File Offset: 0x0000331E
		private void ShortcutKeyTextBoxMouseLeave(object sender, MouseEventArgs e)
		{
			this.mKeyInfoPopup.IsOpen = false;
		}

		// Token: 0x06000497 RID: 1175 RVA: 0x0001EB68 File Offset: 0x0001CD68
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/shortcutkeycontrolelement.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000498 RID: 1176 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000499 RID: 1177 RVA: 0x0001EB98 File Offset: 0x0001CD98
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mShortcutNameTextBlock = (TextBlock)target;
				return;
			case 2:
				this.mShortcutKeyTextBox = (CustomTextBox)target;
				this.mShortcutKeyTextBox.PreviewKeyDown += this.ShortcutKeyTextBoxKeyDown;
				this.mShortcutKeyTextBox.PreviewMouseDown += this.mShortcutKeyTextBox_MouseDown;
				this.mShortcutKeyTextBox.MouseEnter += this.ShortcutKeyTextBoxMouseEnter;
				this.mShortcutKeyTextBox.MouseLeave += this.ShortcutKeyTextBoxMouseLeave;
				this.mShortcutKeyTextBox.PreviewKeyUp += this.ShortcutKeyTextBoxKeyUp;
				return;
			case 3:
				this.mKeyInfoPopup = (CustomPopUp)target;
				return;
			case 4:
				this.mMaskBorder = (Border)target;
				return;
			case 5:
				this.mKeyInfoText = (TextBlock)target;
				return;
			case 6:
				this.mDownArrow = (Path)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040002B8 RID: 696
		internal MainWindow ParentWindow;

		// Token: 0x040002B9 RID: 697
		internal SettingsWindow ParentSettingsWindow;

		// Token: 0x040002BA RID: 698
		internal string mDefaultModifierForUI = string.Empty;

		// Token: 0x040002BB RID: 699
		internal string mDefaultModifierForFile = string.Empty;

		// Token: 0x040002BC RID: 700
		private bool mErrorMessageShown;

		// Token: 0x040002BD RID: 701
		private bool mIsShortcutSameAsMacroShortcut;

		// Token: 0x040002BE RID: 702
		private CustomToastPopupControl mToastPopup;

		// Token: 0x040002BF RID: 703
		internal TextBlock mShortcutNameTextBlock;

		// Token: 0x040002C0 RID: 704
		internal CustomTextBox mShortcutKeyTextBox;

		// Token: 0x040002C1 RID: 705
		internal CustomPopUp mKeyInfoPopup;

		// Token: 0x040002C2 RID: 706
		internal Border mMaskBorder;

		// Token: 0x040002C3 RID: 707
		internal TextBlock mKeyInfoText;

		// Token: 0x040002C4 RID: 708
		internal Path mDownArrow;

		// Token: 0x040002C5 RID: 709
		private bool _contentLoaded;
	}
}
