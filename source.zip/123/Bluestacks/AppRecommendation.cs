﻿using System;
using System.IO;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200003E RID: 62
	public class AppRecommendation
	{
		// Token: 0x17000112 RID: 274
		// (get) Token: 0x06000325 RID: 805 RVA: 0x00004217 File Offset: 0x00002417
		// (set) Token: 0x06000326 RID: 806 RVA: 0x0000421F File Offset: 0x0000241F
		[JsonProperty(PropertyName = "extra_payload")]
		public SerializableDictionary<string, string> ExtraPayload { get; set; } = new SerializableDictionary<string, string>();

		// Token: 0x17000113 RID: 275
		// (get) Token: 0x06000327 RID: 807 RVA: 0x00004228 File Offset: 0x00002428
		// (set) Token: 0x06000328 RID: 808 RVA: 0x00004230 File Offset: 0x00002430
		[JsonProperty(PropertyName = "app_icon_id")]
		public string IconId { get; set; }

		// Token: 0x17000114 RID: 276
		// (get) Token: 0x06000329 RID: 809 RVA: 0x00004239 File Offset: 0x00002439
		// (set) Token: 0x0600032A RID: 810 RVA: 0x00004241 File Offset: 0x00002441
		[JsonProperty(PropertyName = "app_icon")]
		public string Icon { get; set; }

		// Token: 0x17000115 RID: 277
		// (get) Token: 0x0600032B RID: 811 RVA: 0x0000424A File Offset: 0x0000244A
		// (set) Token: 0x0600032C RID: 812 RVA: 0x00004252 File Offset: 0x00002452
		[JsonProperty(PropertyName = "game_genre")]
		public string GameGenre { get; set; }

		// Token: 0x17000116 RID: 278
		// (get) Token: 0x0600032D RID: 813 RVA: 0x0000425B File Offset: 0x0000245B
		// (set) Token: 0x0600032E RID: 814 RVA: 0x00004263 File Offset: 0x00002463
		[JsonProperty(PropertyName = "app_pkg")]
		public string AppPackage { get; set; }

		// Token: 0x17000117 RID: 279
		// (get) Token: 0x0600032F RID: 815 RVA: 0x0000426C File Offset: 0x0000246C
		// (set) Token: 0x06000330 RID: 816 RVA: 0x00004274 File Offset: 0x00002474
		public string ImagePath
		{
			get
			{
				return this.sImagePath;
			}
			set
			{
				this.sImagePath = value;
			}
		}

		// Token: 0x06000331 RID: 817 RVA: 0x00018228 File Offset: 0x00016428
		internal void DeleteFile()
		{
			try
			{
				File.Delete(this.ImagePath);
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't delete AppRecommendation file: " + this.ImagePath);
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x040001B2 RID: 434
		private string sImagePath = string.Empty;
	}
}
