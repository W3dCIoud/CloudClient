﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200007B RID: 123
	public class DMMFullScreenTopBar : UserControl, IComponentConnector
	{
		// Token: 0x06000592 RID: 1426 RVA: 0x000059A0 File Offset: 0x00003BA0
		public DMMFullScreenTopBar()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000593 RID: 1427 RVA: 0x000059AE File Offset: 0x00003BAE
		internal void Init(MainWindow window)
		{
			this.ParentWindow = window;
			if (!DesignerProperties.GetIsInDesignMode(this) && !RegistryManager.Instance.UseEscapeToExitFullScreen)
			{
				this.mEscCheckbox.ImageName = "checkbox_new";
			}
			this.mVolumeBtn.ImageName = "volume_small";
		}

		// Token: 0x06000594 RID: 1428 RVA: 0x0002425C File Offset: 0x0002245C
		private void mEscCheckbox_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (RegistryManager.Instance.UseEscapeToExitFullScreen)
			{
				this.mEscCheckbox.ImageName = "checkbox_new";
				RegistryManager.Instance.UseEscapeToExitFullScreen = false;
				return;
			}
			this.mEscCheckbox.ImageName = "checkbox_new_checked";
			RegistryManager.Instance.UseEscapeToExitFullScreen = true;
		}

		// Token: 0x06000595 RID: 1429 RVA: 0x000059EB File Offset: 0x00003BEB
		private void ScreenshotBtn_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mTopBarPopup.IsOpen = false;
			this.ParentWindow.mCommonHandler.ScreenShotButtonHandler();
		}

		// Token: 0x06000596 RID: 1430 RVA: 0x00005A0E File Offset: 0x00003C0E
		private void VolumeBtn_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.mVolumePopup.IsOpen = !this.mVolumePopup.IsOpen;
		}

		// Token: 0x06000597 RID: 1431 RVA: 0x00005A29 File Offset: 0x00003C29
		private void WindowedBtn_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.FullScreenButtonHandler("fullscreentopbarDmm", "MouseClick");
		}

		// Token: 0x06000598 RID: 1432 RVA: 0x00005A45 File Offset: 0x00003C45
		private void SettingsBtn_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.LaunchSettingsWindow();
		}

		// Token: 0x06000599 RID: 1433 RVA: 0x00005A57 File Offset: 0x00003C57
		internal void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			if (this.ParentWindow != null)
			{
				this.ParentWindow.mDmmBottomBar.VolumeSlider_ValueChanged(sender, e);
			}
		}

		// Token: 0x0600059A RID: 1434 RVA: 0x00005A73 File Offset: 0x00003C73
		private void VolumeSliderImage_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow != null)
			{
				this.ParentWindow.mDmmBottomBar.VolumeSliderImage_PreviewMouseLeftButtonUp(sender, e);
			}
		}

		// Token: 0x0600059B RID: 1435 RVA: 0x00005A8F File Offset: 0x00003C8F
		private void SwitchKeyMapButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.DMMSwitchKeyMapButtonHandler();
		}

		// Token: 0x0600059C RID: 1436 RVA: 0x000242AC File Offset: 0x000224AC
		private void KeyMapButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mTopBarPopup.IsOpen = false;
			if (this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab != null && this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName != null)
			{
				this.ParentWindow.mCommonHandler.KeyMapButtonHandler("MouseClick", "fullscreentopbar");
			}
		}

		// Token: 0x0600059D RID: 1437 RVA: 0x00005AA1 File Offset: 0x00003CA1
		private void TranslucentControlsButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.transSlider.Value = RegistryManager.Instance.TranslucentControlsTransparency;
			this.mChangeTransparencyPopup.PlacementTarget = this.mTranslucentControlsButton;
			this.mChangeTransparencyPopup.IsOpen = true;
		}

		// Token: 0x0600059E RID: 1438 RVA: 0x00005AD5 File Offset: 0x00003CD5
		internal void mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mDmmBottomBar.mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp(sender, e);
		}

		// Token: 0x0600059F RID: 1439 RVA: 0x00005AE9 File Offset: 0x00003CE9
		internal void TransparencySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			this.ParentWindow.mDmmBottomBar.TransparencySlider_ValueChanged(sender, e);
		}

		// Token: 0x060005A0 RID: 1440 RVA: 0x00024318 File Offset: 0x00022518
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/dmmfullscreentopbar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060005A1 RID: 1441 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060005A2 RID: 1442 RVA: 0x00024348 File Offset: 0x00022548
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mEscCheckbox = (CustomPictureBox)target;
				this.mEscCheckbox.MouseLeftButtonUp += this.mEscCheckbox_MouseLeftButtonUp;
				return;
			case 2:
				this.mKeyMapSwitch = (CustomPictureBox)target;
				this.mKeyMapSwitch.PreviewMouseLeftButtonUp += this.SwitchKeyMapButton_PreviewMouseLeftButtonUp;
				return;
			case 3:
				this.mKeyMapButton = (CustomPictureBox)target;
				this.mKeyMapButton.PreviewMouseLeftButtonUp += this.KeyMapButton_PreviewMouseLeftButtonUp;
				return;
			case 4:
				this.mTranslucentControlsButton = (CustomPictureBox)target;
				this.mTranslucentControlsButton.PreviewMouseLeftButtonUp += this.TranslucentControlsButton_PreviewMouseLeftButtonUp;
				return;
			case 5:
				this.mScreenshotBtn = (CustomPictureBox)target;
				this.mScreenshotBtn.PreviewMouseLeftButtonUp += this.ScreenshotBtn_MouseUp;
				return;
			case 6:
				this.mVolumeBtn = (CustomPictureBox)target;
				this.mVolumeBtn.PreviewMouseLeftButtonUp += this.VolumeBtn_MouseUp;
				return;
			case 7:
				this.mWindowedBtn = (CustomPictureBox)target;
				this.mWindowedBtn.PreviewMouseLeftButtonUp += this.WindowedBtn_MouseUp;
				return;
			case 8:
				this.mSettingsBtn = (CustomPictureBox)target;
				this.mSettingsBtn.PreviewMouseLeftButtonUp += this.SettingsBtn_MouseUp;
				return;
			case 9:
				this.mVolumePopup = (CustomPopUp)target;
				return;
			case 10:
				this.volumeSliderImage = (CustomPictureBox)target;
				this.volumeSliderImage.PreviewMouseLeftButtonUp += this.VolumeSliderImage_PreviewMouseLeftButtonUp;
				return;
			case 11:
				this.mVolumeSlider = (Slider)target;
				this.mVolumeSlider.ValueChanged += this.VolumeSlider_ValueChanged;
				return;
			case 12:
				this.mChangeTransparencyPopup = (CustomPopUp)target;
				return;
			case 13:
				this.mTranslucentControlsSliderButton = (CustomPictureBox)target;
				this.mTranslucentControlsSliderButton.PreviewMouseLeftButtonUp += this.mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp;
				return;
			case 14:
				this.transSlider = (Slider)target;
				this.transSlider.ValueChanged += this.TransparencySlider_ValueChanged;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400036B RID: 875
		private MainWindow ParentWindow;

		// Token: 0x0400036C RID: 876
		internal CustomPictureBox mEscCheckbox;

		// Token: 0x0400036D RID: 877
		internal CustomPictureBox mKeyMapSwitch;

		// Token: 0x0400036E RID: 878
		internal CustomPictureBox mKeyMapButton;

		// Token: 0x0400036F RID: 879
		internal CustomPictureBox mTranslucentControlsButton;

		// Token: 0x04000370 RID: 880
		internal CustomPictureBox mScreenshotBtn;

		// Token: 0x04000371 RID: 881
		internal CustomPictureBox mVolumeBtn;

		// Token: 0x04000372 RID: 882
		internal CustomPictureBox mWindowedBtn;

		// Token: 0x04000373 RID: 883
		internal CustomPictureBox mSettingsBtn;

		// Token: 0x04000374 RID: 884
		internal CustomPopUp mVolumePopup;

		// Token: 0x04000375 RID: 885
		internal CustomPictureBox volumeSliderImage;

		// Token: 0x04000376 RID: 886
		internal Slider mVolumeSlider;

		// Token: 0x04000377 RID: 887
		internal CustomPopUp mChangeTransparencyPopup;

		// Token: 0x04000378 RID: 888
		internal CustomPictureBox mTranslucentControlsSliderButton;

		// Token: 0x04000379 RID: 889
		internal Slider transSlider;

		// Token: 0x0400037A RID: 890
		private bool _contentLoaded;
	}
}
