﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Effects;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001A5 RID: 421
	public partial class ContainerWindow : CustomWindow
	{
		// Token: 0x06000F9F RID: 3999 RVA: 0x00061D84 File Offset: 0x0005FF84
		public ContainerWindow(MainWindow window, UserControl control, double width, double height, bool autoHeight = false, bool isShow = true)
		{
			this.InitializeComponent();
			this.SetShadowBorder();
			this.SetOuterBorder();
			this.SetMaskGrid();
			if (autoHeight)
			{
				base.Width = 700.0;
				base.SizeToContent = SizeToContent.Height;
			}
			else
			{
				base.Width = width + 60.0;
				base.Height = height + 60.0;
			}
			base.Owner = window;
			if (window.mDMMRecommendedWindow != null && window.mDMMRecommendedWindow.Visibility == Visibility.Visible && window.IsUIInPortraitMode)
			{
				double num = (window.Width + window.mDMMRecommendedWindow.Width - base.Width) / 2.0 + window.Left;
				double num2 = (window.Height - base.Height) / 2.0 + window.Top;
				double num3 = num + base.Width;
				double num4 = num2 + base.Height;
				if (num > 0.0 && num3 < SystemParameters.PrimaryScreenWidth && num2 > 0.0 && num4 < SystemParameters.PrimaryScreenHeight)
				{
					base.Left = num;
					base.Top = num2;
				}
				else
				{
					base.WindowStartupLocation = WindowStartupLocation.CenterOwner;
				}
			}
			else if (window.WindowState == WindowState.Minimized)
			{
				base.WindowStartupLocation = WindowStartupLocation.CenterScreen;
			}
			else
			{
				base.WindowStartupLocation = WindowStartupLocation.CenterOwner;
			}
			this.ContentGrid.Children.Add(control);
			if (isShow)
			{
				if (window != null)
				{
					window.ShowDimOverlay(null);
					base.Owner = window.mDimOverlay;
				}
				base.ShowDialog();
				if (window != null)
				{
					window.HideDimOverlay();
				}
			}
		}

		// Token: 0x06000FA0 RID: 4000 RVA: 0x00061F10 File Offset: 0x00060110
		private void SetShadowBorder()
		{
			this.mShadowBorder.SnapsToDevicePixels = true;
			this.mShadowBorder.SetValue(RenderOptions.EdgeModeProperty, EdgeMode.Aliased);
			BlueStacksUIBinding.BindCornerRadius(this.mShadowBorder, Border.CornerRadiusProperty, "SettingsWindowRadius");
			DropShadowEffect dropShadowEffect = new DropShadowEffect();
			BlueStacksUIBinding.BindColor(dropShadowEffect, DropShadowEffect.ColorProperty, "PopupShadowColor");
			dropShadowEffect.Direction = 270.0;
			dropShadowEffect.ShadowDepth = 0.0;
			dropShadowEffect.BlurRadius = 15.0;
			dropShadowEffect.Opacity = 0.7;
			this.mShadowBorder.Effect = dropShadowEffect;
		}

		// Token: 0x06000FA1 RID: 4001 RVA: 0x00061FB4 File Offset: 0x000601B4
		private void SetOuterBorder()
		{
			BlueStacksUIBinding.BindColor(this.mOuterBorder, Control.BackgroundProperty, "ContextMenuItemBackgroundColor");
			BlueStacksUIBinding.BindColor(this.mOuterBorder, Control.BorderBrushProperty, "PopupBorderBrush");
			BlueStacksUIBinding.BindCornerRadius(this.mOuterBorder, Border.CornerRadiusProperty, "SettingsWindowRadius");
		}

		// Token: 0x06000FA2 RID: 4002 RVA: 0x00062000 File Offset: 0x00060200
		private void SetMaskGrid()
		{
			this.mMaskBorder.SnapsToDevicePixels = true;
			this.mMaskBorder.SetValue(RenderOptions.EdgeModeProperty, EdgeMode.Aliased);
			BlueStacksUIBinding.BindColor(this.mMaskBorder, Control.BackgroundProperty, "ContextMenuItemBackgroundColor");
			BlueStacksUIBinding.BindCornerRadius(this.mMaskBorder, Border.CornerRadiusProperty, "SettingsWindowRadius");
			VisualBrush visualBrush = new VisualBrush(this.mMaskBorder);
			visualBrush.Stretch = Stretch.None;
			this.mMainGrid.OpacityMask = visualBrush;
		}
	}
}
