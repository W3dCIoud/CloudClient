﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using BlueStacks.BlueStacksUI.BTv;
using BlueStacks.Common;
using Microsoft.VisualBasic.Devices;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000212 RID: 530
	public partial class TopBar : UserControl, ITopBar
	{
		// Token: 0x1700020E RID: 526
		// (get) Token: 0x0600120A RID: 4618 RVA: 0x0000CC10 File Offset: 0x0000AE10
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x14000025 RID: 37
		// (add) Token: 0x0600120B RID: 4619 RVA: 0x0006FF38 File Offset: 0x0006E138
		// (remove) Token: 0x0600120C RID: 4620 RVA: 0x0006FF70 File Offset: 0x0006E170
		public event Action<int> ChangePercent;

		// Token: 0x0600120D RID: 4621
		[DllImport("user32.dll")]
		[return: MarshalAs(UnmanagedType.Bool)]
		internal static extern bool GetCursorPos(ref TopBar.Win32Point pt);

		// Token: 0x1700020F RID: 527
		// (get) Token: 0x0600120E RID: 4622 RVA: 0x0000CC31 File Offset: 0x0000AE31
		// (set) Token: 0x0600120F RID: 4623 RVA: 0x00004BF2 File Offset: 0x00002DF2
		string ITopBar.AppName
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		// Token: 0x17000210 RID: 528
		// (get) Token: 0x06001210 RID: 4624 RVA: 0x0000CC31 File Offset: 0x0000AE31
		// (set) Token: 0x06001211 RID: 4625 RVA: 0x00004BF2 File Offset: 0x00002DF2
		string ITopBar.CharacterName
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		// Token: 0x06001212 RID: 4626 RVA: 0x0006FFA8 File Offset: 0x0006E1A8
		public static Point GetMousePosition()
		{
			TopBar.Win32Point win32Point = default(TopBar.Win32Point);
			TopBar.GetCursorPos(ref win32Point);
			return new Point((double)win32Point.X, (double)win32Point.Y);
		}

		// Token: 0x06001213 RID: 4627 RVA: 0x0006FFD8 File Offset: 0x0006E1D8
		public TopBar()
		{
			this.InitializeComponent();
			if (FeatureManager.Instance.IsCustomUIForDMMSandbox)
			{
				this.TopBarOptionsPanelElementVisibility(this.mUserAccountBtn, false);
				this.TopBarOptionsPanelElementVisibility(this.mWarningButton, false);
			}
			else
			{
				if (!FeatureManager.Instance.IsUserAccountBtnEnabled)
				{
					this.TopBarOptionsPanelElementVisibility(this.mUserAccountBtn, false);
				}
				if (!FeatureManager.Instance.IsWarningBtnEnabled)
				{
					this.TopBarOptionsPanelElementVisibility(this.mWarningButton, false);
				}
			}
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				this.mConfigButton.Visibility = Visibility.Collapsed;
				this.TopBarOptionsPanelElementVisibility(this.mNotificationCentreButton, false);
				this.WindowHeaderGrid.Visibility = Visibility.Collapsed;
				this.TopBarOptionsPanelElementVisibility(this.mUserAccountBtn, false);
				this.mWarningButton.ToolTip = null;
			}
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				this.TopBarOptionsPanelElementVisibility(this.mUserAccountBtn, false);
				this.TopBarOptionsPanelElementVisibility(this.mNotificationCentreButton, false);
			}
			if (!this.mTitleIcon.ImageName.Equals(Strings.TitleBarIconImageName))
			{
				this.mTitleIcon.ImageName = Strings.TitleBarIconImageName;
			}
			this.mVersionText.Text = RegistryManager.Instance.ClientVersion;
		}

		// Token: 0x06001214 RID: 4628 RVA: 0x00070120 File Offset: 0x0006E320
		private void ParentWindow_GuestBootCompletedEvent()
		{
			if (this.ParentWindow.EngineInstanceRegistry.IsSidebarVisible && base.Visibility == Visibility.Visible && this.ParentWindow.mSidebar.Visibility != Visibility.Visible)
			{
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					this.ParentWindow.mCommonHandler.FlipSidebarVisibility(this.mSidebarButton, null);
				}), new object[0]);
			}
		}

		// Token: 0x06001215 RID: 4629 RVA: 0x0000CC34 File Offset: 0x0000AE34
		internal void ChangeDownloadPercent(int percent)
		{
			if (this.ChangePercent != null)
			{
				this.ChangePercent(percent);
			}
		}

		// Token: 0x06001216 RID: 4630 RVA: 0x0007017C File Offset: 0x0006E37C
		internal void InitializeSnailButton()
		{
			if (FeatureManager.Instance.IsCustomUIForDMMSandbox || !FeatureManager.Instance.IsWarningBtnEnabled)
			{
				return;
			}
			string deviceCaps = RegistryManager.Instance.DeviceCaps;
			if (string.IsNullOrEmpty(deviceCaps))
			{
				this.mSnailMode = PerformanceState.VtxEnabled;
				this.TopBarOptionsPanelElementVisibility(this.mWarningButton, false);
				return;
			}
			JObject deviceCapsData = JObject.Parse(deviceCaps);
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (deviceCapsData["cpu_hvm"].ToString().Equals("True", StringComparison.OrdinalIgnoreCase) && deviceCapsData["bios_hvm"].ToString().Equals("False", StringComparison.OrdinalIgnoreCase))
				{
					if (deviceCapsData["engine_enabled"].ToString().Equals(EngineState.raw.ToString(), StringComparison.OrdinalIgnoreCase))
					{
						this.mSnailMode = PerformanceState.VtxDisabled;
						this.TopBarOptionsPanelElementVisibility(this.mWarningButton, true);
					}
				}
				else if (deviceCapsData["cpu_hvm"].ToString().Equals("False", StringComparison.OrdinalIgnoreCase))
				{
					this.mSnailMode = PerformanceState.NoVtxSupport;
					this.TopBarOptionsPanelElementVisibility(this.mWarningButton, true);
				}
				else if (deviceCapsData["cpu_hvm"].ToString().Equals("True", StringComparison.OrdinalIgnoreCase) && deviceCapsData["bios_hvm"].ToString().Equals("True", StringComparison.OrdinalIgnoreCase))
				{
					this.mSnailMode = PerformanceState.VtxEnabled;
					this.TopBarOptionsPanelElementVisibility(this.mWarningButton, false);
				}
				this.RefreshWarningButton();
			}), new object[0]);
		}

		// Token: 0x06001217 RID: 4631 RVA: 0x00070204 File Offset: 0x0006E404
		internal void RefreshWarningButton()
		{
			if (FeatureManager.Instance.IsCustomUIForDMMSandbox || !FeatureManager.Instance.IsWarningBtnEnabled)
			{
				return;
			}
			if (this.mSnailMode != PerformanceState.VtxEnabled)
			{
				this.TopBarOptionsPanelElementVisibility(this.mWarningButton, true);
				this.AddVtxNotification();
				return;
			}
			this.TopBarOptionsPanelElementVisibility(this.mWarningButton, false);
		}

		// Token: 0x06001218 RID: 4632 RVA: 0x0000CC4A File Offset: 0x0000AE4A
		internal void AddVtxNotification()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				bool dontOverwrite = true;
				GenericNotificationItem genericNotificationItem = new GenericNotificationItem();
				genericNotificationItem.CreationTime = DateTime.Now;
				genericNotificationItem.IsDeferred = false;
				genericNotificationItem.Priority = NotificationPriority.Important;
				genericNotificationItem.ShowRibbon = false;
				genericNotificationItem.Id = "VtxNotification";
				genericNotificationItem.NotificationMenuImageName = "SlowPerformance.png";
				genericNotificationItem.Title = LocaleStrings.GetLocalizedString("STRING_DISABLED_VT_TITLE", false);
				genericNotificationItem.Message = LocaleStrings.GetLocalizedString("STRING_DISABLED_VT", false);
				genericNotificationItem.ExtraPayload = new SerializableDictionary<string, string>
				{
					{
						"click_generic_action",
						"UserBrowser"
					},
					{
						"click_action_value",
						WebHelper.GetUrlWithParams(string.Format("{0}/{1}", WebHelper.GetServerHost(), "help_articles")) + "&article=enable_virtualization"
					}
				};
				GenericNotificationManager.Instance.AddNewNotification(genericNotificationItem, dontOverwrite);
				this.RefreshNotificationCentreButton();
			}), new object[0]);
		}

		// Token: 0x06001219 RID: 4633 RVA: 0x0000CC6A File Offset: 0x0000AE6A
		internal void AddRamNotification()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				bool dontOverwrite = true;
				GenericNotificationItem genericNotificationItem = new GenericNotificationItem();
				genericNotificationItem.IsDeferred = false;
				genericNotificationItem.Priority = NotificationPriority.Important;
				genericNotificationItem.ShowRibbon = false;
				genericNotificationItem.Id = "ramNotification";
				genericNotificationItem.NotificationMenuImageName = "SlowPerformance.png";
				genericNotificationItem.Title = LocaleStrings.GetLocalizedString("STRING_RAM_NOTIF_TITLE", false);
				genericNotificationItem.Message = LocaleStrings.GetLocalizedString("STRING_RAM_NOTIF", false);
				genericNotificationItem.ExtraPayload = new SerializableDictionary<string, string>
				{
					{
						"click_generic_action",
						"UserBrowser"
					},
					{
						"click_action_value",
						WebHelper.GetUrlWithParams(string.Format("{0}/{1}", WebHelper.GetServerHost(), "help_articles")) + "&article=bs3_nougat_min_requirements"
					}
				};
				GenericNotificationManager.Instance.AddNewNotification(genericNotificationItem, dontOverwrite);
				this.RefreshNotificationCentreButton();
			}), new object[0]);
		}

		// Token: 0x0600121A RID: 4634 RVA: 0x00070254 File Offset: 0x0006E454
		private void UserAccountButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked account button");
			if (this.ParentWindow.mGuestBootCompleted && this.ParentWindow.mAppHandler.IsOneTimeSetupCompleted)
			{
				if (FeatureManager.Instance.IsOpenActivityFromAccountIcon)
				{
					this.mAppTabButtons.AddAppTab("STRING_ACCOUNT", BlueStacksUIUtils.sUserAccountPackageName, BlueStacksUIUtils.sUserAccountActivityName, "account_tab", true, true, "account_tab", false);
					return;
				}
				string text = WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/bluestacks_account");
				text += "&email=";
				text += RegistryManager.Instance.RegisteredEmail;
				text += "&token=";
				text += RegistryManager.Instance.Token;
				this.mAppTabButtons.AddWebTab(text, "STRING_ACCOUNT", "account_tab", true, "account_tab", false);
			}
		}

		// Token: 0x0600121B RID: 4635 RVA: 0x0000CC8A File Offset: 0x0000AE8A
		private void ConfigButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mPreferenceDropDownControl.LateInit();
			this.mSettingsMenuPopup.IsOpen = true;
			this.mConfigButton.ImageName = "cfgmenu_hover";
		}

		// Token: 0x0600121C RID: 4636 RVA: 0x0000CCB3 File Offset: 0x0000AEB3
		private void MinimizeButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked minimize button");
			this.ParentWindow.MinimizeWindow();
		}

		// Token: 0x0600121D RID: 4637 RVA: 0x0000CCCA File Offset: 0x0000AECA
		internal void MaxmizeButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked Maximize\\Restore button");
			if (this.ParentWindow.WindowState == WindowState.Normal && !this.ParentWindow.mIsDmmMaximised)
			{
				this.ParentWindow.MaximizeWindow();
				return;
			}
			this.ParentWindow.RestoreWindows();
		}

		// Token: 0x0600121E RID: 4638 RVA: 0x0000CD07 File Offset: 0x0000AF07
		private void CloseButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked close Bluestacks button");
			this.ParentWindow.CloseWindow();
		}

		// Token: 0x0600121F RID: 4639 RVA: 0x0000CD1E File Offset: 0x0000AF1E
		private void NotificationPopup_Opened(object sender, EventArgs e)
		{
			this.mConfigButton.IsEnabled = false;
		}

		// Token: 0x06001220 RID: 4640 RVA: 0x0000CD2C File Offset: 0x0000AF2C
		private void NotificationPopup_Closed(object sender, EventArgs e)
		{
			this.mConfigButton.IsEnabled = true;
			this.mConfigButton.ImageName = "cfgmenu";
		}

		// Token: 0x06001221 RID: 4641 RVA: 0x0000CD4A File Offset: 0x0000AF4A
		internal void ChangeUserPremiumButton(bool isPremium)
		{
			if (isPremium)
			{
				this.mUserAccountBtn.ImageName = BlueStacksUIUtils.sPremiumUserImageName;
				return;
			}
			this.mUserAccountBtn.ImageName = BlueStacksUIUtils.sLoggedInImageName;
		}

		// Token: 0x06001222 RID: 4642 RVA: 0x0000553B File Offset: 0x0000373B
		private void PreferenceDropDownControl_MouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x06001223 RID: 4643 RVA: 0x00070330 File Offset: 0x0006E530
		private void mWarningButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked warning button for speed up Bluestacks ");
			this.mWarningButton.ImageName = "warning";
			SpeedUpBlueStacks speedUpBlueStacks = new SpeedUpBlueStacks();
			if (this.mSnailMode == PerformanceState.NoVtxSupport)
			{
				speedUpBlueStacks.mUpgradeComputer.Visibility = Visibility.Visible;
			}
			else if (this.mSnailMode == PerformanceState.VtxDisabled)
			{
				speedUpBlueStacks.mEnableVt.Visibility = Visibility.Visible;
			}
			new ContainerWindow(this.ParentWindow, speedUpBlueStacks, 640.0, 200.0, false, true);
		}

		// Token: 0x06001224 RID: 4644 RVA: 0x0000CD70 File Offset: 0x0000AF70
		private void mBtvButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked btv button");
			BTVManager.Instance.StartBlueStacksTV();
		}

		// Token: 0x06001225 RID: 4645 RVA: 0x000703AC File Offset: 0x0006E5AC
		private void TopBar_Loaded(object sender, RoutedEventArgs e)
		{
			if (FeatureManager.Instance.IsBTVEnabled && Strings.CurrentDefaultVmName.Equals(this.ParentWindow.mVmName))
			{
				this.TopBarOptionsPanelElementVisibility(this.mBtvButton, true);
			}
			this.RefreshNotificationCentreButton();
			if (!this.ParentWindow.mGuestBootCompleted)
			{
				this.ParentWindow.mCommonHandler.SetSidebarImageProperties(false, this.mSidebarButton, null);
				this.ParentWindow.GuestBootCompletedEvent += this.ParentWindow_GuestBootCompletedEvent;
			}
			this.ParentWindow.mCommonHandler.ScreenRecordingStateChangedEvent += this.TopBar_ScreenRecordingStateChangedEvent;
			VideoRecordingStatus videoRecordingStatus = this.mVideoRecordStatusControl;
			videoRecordingStatus.RecordingStoppedEvent = (Action)Delegate.Combine(videoRecordingStatus.RecordingStoppedEvent, new Action(this.TopBar_RecordingStoppedEvent));
		}

		// Token: 0x06001226 RID: 4646 RVA: 0x0000CD86 File Offset: 0x0000AF86
		private void TopBar_RecordingStoppedEvent()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.mVideoRecordStatusControl.Visibility = Visibility.Collapsed;
			}), new object[0]);
		}

		// Token: 0x06001227 RID: 4647 RVA: 0x00070470 File Offset: 0x0006E670
		private void TopBar_ScreenRecordingStateChangedEvent(bool isRecording)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (isRecording)
				{
					if (this.mVideoRecordStatusControl.Visibility != Visibility.Visible && CommonHandlers.sIsRecordingVideo)
					{
						this.mVideoRecordStatusControl.Init(this.ParentWindow);
						this.mVideoRecordStatusControl.Visibility = Visibility.Visible;
						return;
					}
				}
				else
				{
					this.mVideoRecordStatusControl.ResetTimer();
					this.mVideoRecordStatusControl.Visibility = Visibility.Collapsed;
				}
			}), new object[0]);
		}

		// Token: 0x06001228 RID: 4648 RVA: 0x000704B4 File Offset: 0x0006E6B4
		private void mNotificationCentreButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked notification_centre button");
			this.mNotificationDrawerControl.ParentWindow = this.ParentWindow;
			this.mNotificationDrawerControl.Width = 370.0;
			this.mNotificationDrawerControl.Populate(GenericNotificationManager.Instance.GetNotificationItems((GenericNotificationItem x) => !x.IsDeleted));
			ClientStats.SendMiscellaneousStatsAsync("NotificationBellIconClicked", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, null, null, null, null, null, null);
			this.mNotificationCentrePopup.IsOpen = true;
		}

		// Token: 0x06001229 RID: 4649 RVA: 0x00070554 File Offset: 0x0006E754
		internal bool CheckForRam()
		{
			int num = 0;
			try
			{
				num = (int)(ulong.Parse(new ComputerInfo().TotalPhysicalMemory.ToString()) / this.MB_MULTIPLIER);
			}
			catch (Exception ex)
			{
				Logger.Error(ex.ToString());
			}
			return num < 4096;
		}

		// Token: 0x0600122A RID: 4650 RVA: 0x000705AC File Offset: 0x0006E7AC
		internal void RefreshNotificationCentreButton()
		{
			if (!this.ParentWindow.EngineInstanceRegistry.IsGoogleSigninDone || !this.ParentWindow.IsDefaultVM || !FeatureManager.Instance.IsShowNotificationCentre || RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				this.TopBarOptionsPanelElementVisibility(this.mNotificationCentreButton, false);
				return;
			}
			this.TopBarOptionsPanelElementVisibility(this.mNotificationCentreButton, true);
			if (GenericNotificationManager.Instance.GetNotificationItems((GenericNotificationItem x) => !x.IsRead && !x.IsDeleted && x.Priority == NotificationPriority.Important).Count > 0)
			{
				this.mNotificationCentreButton.ImageName = "notification_crucial";
				return;
			}
			if (GenericNotificationManager.Instance.GetNotificationItems((GenericNotificationItem x) => !x.IsRead && !x.IsDeleted).Count > 0)
			{
				this.mNotificationCentreButton.ImageName = "notification_dot";
				return;
			}
			this.mNotificationCentreButton.ImageName = "notification";
		}

		// Token: 0x0600122B RID: 4651 RVA: 0x000706AC File Offset: 0x0006E8AC
		private void mNotificationCentreDropDownBorder_LayoutUpdated(object sender, EventArgs e)
		{
			RectangleGeometry rectangleGeometry = new RectangleGeometry();
			Rect rect = default(Rect);
			rect.Height = this.mNotificationCentreDropDownBorder.ActualHeight;
			rect.Width = this.mNotificationCentreDropDownBorder.ActualWidth;
			BlueStacksUIBinding.BindCornerRadiusToDouble(rectangleGeometry, RectangleGeometry.RadiusXProperty, "PreferenceDropDownRadius");
			BlueStacksUIBinding.BindCornerRadiusToDouble(rectangleGeometry, RectangleGeometry.RadiusYProperty, "PreferenceDropDownRadius");
			rectangleGeometry.Rect = rect;
			this.mNotificationCentreDropDownBorder.Clip = rectangleGeometry;
		}

		// Token: 0x0600122C RID: 4652 RVA: 0x00070720 File Offset: 0x0006E920
		internal void ShowRecordingIcons()
		{
			this.mMacroRecordControl.Init(this.ParentWindow);
			this.mMacroRecordControl.Visibility = Visibility.Visible;
			this.mMacroRecordControl.StartTimer();
			this.ParentWindow.mTopBar.mMacroRecorderToolTipPopup.IsOpen = true;
			this.ParentWindow.mTopBar.mMacroRecorderToolTipPopup.StaysOpen = true;
			this.mMacroRecordingPopupTimer = new DispatcherTimer();
			this.mMacroRecordingPopupTimer.Interval = new TimeSpan(0, 0, 0, 5, 0);
			this.mMacroRecordingPopupTimer.Tick += this.MacroRecordingPopupTimer_Tick;
			this.mMacroRecordingPopupTimer.Start();
		}

		// Token: 0x0600122D RID: 4653 RVA: 0x0000CDAB File Offset: 0x0000AFAB
		private void MacroRecordingPopupTimer_Tick(object sender, EventArgs e)
		{
			this.ParentWindow.mTopBar.mMacroRecorderToolTipPopup.IsOpen = false;
			(sender as DispatcherTimer).Stop();
		}

		// Token: 0x0600122E RID: 4654 RVA: 0x000707C4 File Offset: 0x0006E9C4
		internal void HideRecordingIcons()
		{
			this.mConfigButton.Visibility = Visibility.Visible;
			if (this.ParentWindow.EngineInstanceRegistry.IsGoogleSigninDone)
			{
				this.TopBarOptionsPanelElementVisibility(this.mNotificationCentreButton, true);
				this.TopBarOptionsPanelElementVisibility(this.mUserAccountBtn, true);
			}
			this.mMacroRecordControl.Visibility = Visibility.Collapsed;
			this.mMacroRecorderToolTipPopup.IsOpen = false;
		}

		// Token: 0x0600122F RID: 4655 RVA: 0x00070824 File Offset: 0x0006EA24
		internal void ShowMacroPlaybackOnTopBar(OperationsRecord record)
		{
			this.mMacroPlayControl.Init(this.ParentWindow, record);
			this.mMacroPlayControl.Visibility = Visibility.Visible;
			this.ParentWindow.mTopBar.mMacroRunningToolTipPopup.IsOpen = true;
			this.ParentWindow.mTopBar.mMacroRunningToolTipPopup.StaysOpen = true;
			this.mMacroRunningPopupTimer = new DispatcherTimer();
			this.mMacroRunningPopupTimer.Interval = new TimeSpan(0, 0, 0, 5, 0);
			this.mMacroRunningPopupTimer.Tick += this.MacroRunningPopupTimer_Tick;
			this.mMacroRunningPopupTimer.Start();
		}

		// Token: 0x06001230 RID: 4656 RVA: 0x0000CDCE File Offset: 0x0000AFCE
		private void MacroRunningPopupTimer_Tick(object sender, EventArgs e)
		{
			this.ParentWindow.mTopBar.mMacroRunningToolTipPopup.IsOpen = false;
			(sender as DispatcherTimer).Stop();
		}

		// Token: 0x06001231 RID: 4657 RVA: 0x000708C0 File Offset: 0x0006EAC0
		internal void HideMacroPlaybackFromTopBar()
		{
			this.mConfigButton.Visibility = Visibility.Visible;
			if (this.ParentWindow.EngineInstanceRegistry.IsGoogleSigninDone)
			{
				this.TopBarOptionsPanelElementVisibility(this.mNotificationCentreButton, true);
				this.TopBarOptionsPanelElementVisibility(this.mUserAccountBtn, true);
			}
			this.mMacroPlayControl.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06001232 RID: 4658 RVA: 0x00070914 File Offset: 0x0006EB14
		internal void UpdateMacroRecordingProgress()
		{
			if (this.ParentWindow.mIsMacroPlaying || this.ParentWindow.mIsOperationRecorderActive)
			{
				this.mConfigButton.Visibility = Visibility.Visible;
				if (this.ParentWindow.EngineInstanceRegistry.IsGoogleSigninDone)
				{
					this.TopBarOptionsPanelElementVisibility(this.mNotificationCentreButton, true);
					this.TopBarOptionsPanelElementVisibility(this.mUserAccountBtn, true);
				}
			}
		}

		// Token: 0x06001233 RID: 4659 RVA: 0x0000CDF1 File Offset: 0x0000AFF1
		internal void ShowSyncIcon()
		{
			this.TopBarOptionsPanelElementVisibility(this.mOperationsSyncGrid, true);
		}

		// Token: 0x06001234 RID: 4660 RVA: 0x0000CE00 File Offset: 0x0000B000
		internal void HideSyncIcon()
		{
			this.TopBarOptionsPanelElementVisibility(this.mOperationsSyncGrid, false);
		}

		// Token: 0x06001235 RID: 4661 RVA: 0x0000CE0F File Offset: 0x0000B00F
		private void MSidebarButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			MainWindow parentWindow = this.ParentWindow;
			if (parentWindow == null)
			{
				return;
			}
			CommonHandlers mCommonHandler = parentWindow.mCommonHandler;
			if (mCommonHandler == null)
			{
				return;
			}
			mCommonHandler.FlipSidebarVisibility(sender as CustomPictureBox, null);
		}

		// Token: 0x06001236 RID: 4662 RVA: 0x0000CE32 File Offset: 0x0000B032
		private void TopBar_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (!DesignerProperties.GetIsInDesignMode(this))
			{
				this.TopBarButtonsHandling();
			}
		}

		// Token: 0x06001237 RID: 4663 RVA: 0x00070974 File Offset: 0x0006EB74
		private void TopBarButtonsHandling()
		{
			double num = base.ActualWidth - 180.0 - (double)(this.mAppTabButtons.mDictTabs.Count * 48);
			double num2 = this.mOptionsDockPanel.ActualWidth;
			if (num2 > num)
			{
				using (IEnumerator<KeyValuePair<FrameworkElement, double>> enumerator = this.mOptionsPriorityPanel.Values.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						KeyValuePair<FrameworkElement, double> keyValuePair = enumerator.Current;
						if (keyValuePair.Key.Visibility == Visibility.Visible)
						{
							keyValuePair.Key.Visibility = Visibility.Collapsed;
							num2 -= keyValuePair.Value;
						}
						if (num2 < num)
						{
							break;
						}
					}
					return;
				}
			}
			for (int i = this.mOptionsPriorityPanel.Count - 1; i >= 0; i--)
			{
				KeyValuePair<FrameworkElement, double> value = this.mOptionsPriorityPanel.ElementAt(i).Value;
				if (value.Key.Visibility == Visibility.Collapsed)
				{
					if (num2 + value.Value >= num)
					{
						break;
					}
					value.Key.Visibility = Visibility.Visible;
					num2 += value.Value;
				}
			}
		}

		// Token: 0x06001238 RID: 4664 RVA: 0x00070A88 File Offset: 0x0006EC88
		private bool ContainsKey(FrameworkElement element)
		{
			foreach (KeyValuePair<FrameworkElement, double> keyValuePair in this.mOptionsPriorityPanel.Values)
			{
				if (keyValuePair.Key == element)
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x06001239 RID: 4665 RVA: 0x00070AE4 File Offset: 0x0006ECE4
		private void RemoveKey(FrameworkElement element)
		{
			foreach (KeyValuePair<int, KeyValuePair<FrameworkElement, double>> keyValuePair in this.mOptionsPriorityPanel)
			{
				if (keyValuePair.Value.Key == element)
				{
					this.mOptionsPriorityPanel.Remove(keyValuePair.Key);
					break;
				}
			}
		}

		// Token: 0x0600123A RID: 4666 RVA: 0x00070B54 File Offset: 0x0006ED54
		internal void TopBarOptionsPanelElementVisibility(FrameworkElement element, bool isVisible)
		{
			if (isVisible)
			{
				double num = base.ActualWidth - 180.0 - (double)(this.mAppTabButtons.mDictTabs.Count * 48);
				if (this.mOptionsDockPanel.ActualWidth + element.Width < num)
				{
					element.Visibility = Visibility.Visible;
				}
				else
				{
					element.Visibility = Visibility.Collapsed;
				}
				if (!this.ContainsKey(element))
				{
					this.mOptionsPriorityPanel.Add(int.Parse(element.Tag.ToString()), new KeyValuePair<FrameworkElement, double>(element, element.Width));
					return;
				}
			}
			else
			{
				element.Visibility = Visibility.Collapsed;
				if (this.ContainsKey(element))
				{
					this.RemoveKey(element);
				}
			}
		}

		// Token: 0x0600123B RID: 4667 RVA: 0x0000CE42 File Offset: 0x0000B042
		void ITopBar.ShowSyncPanel(bool isSource)
		{
			this.mOperationsSyncGrid.Visibility = Visibility.Visible;
			if (isSource)
			{
				this.mPlayPauseSyncButton.ImageName = "pause_title_bar";
				this.mPlayPauseSyncButton.Visibility = Visibility.Visible;
				this.mStopSyncButton.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x0600123C RID: 4668 RVA: 0x0000CE7B File Offset: 0x0000B07B
		void ITopBar.HideSyncPanel()
		{
			this.mOperationsSyncGrid.Visibility = Visibility.Collapsed;
			this.mPlayPauseSyncButton.Visibility = Visibility.Collapsed;
			this.mStopSyncButton.Visibility = Visibility.Collapsed;
			this.mSyncInstancesToolTipPopup.IsOpen = false;
		}

		// Token: 0x0600123D RID: 4669 RVA: 0x00070BF8 File Offset: 0x0006EDF8
		private void PlayPauseSyncButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if ((sender as CustomPictureBox).ImageName.Equals("pause_title_bar", StringComparison.InvariantCultureIgnoreCase))
			{
				(sender as CustomPictureBox).ImageName = "play_title_bar";
				this.ParentWindow.mSynchronizerWindow.PauseAllSyncOperations();
				return;
			}
			(sender as CustomPictureBox).ImageName = "pause_title_bar";
			this.ParentWindow.mSynchronizerWindow.PlayAllSyncOperations();
		}

		// Token: 0x0600123E RID: 4670 RVA: 0x0000CEAD File Offset: 0x0000B0AD
		private void StopSyncButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			((ITopBar)this).HideSyncPanel();
			this.ParentWindow.mSynchronizerWindow.StopAllSyncOperations();
		}

		// Token: 0x0600123F RID: 4671 RVA: 0x0000CEC5 File Offset: 0x0000B0C5
		private void OperationsSyncGrid_MouseEnter(object sender, MouseEventArgs e)
		{
			if (this.ParentWindow.mIsSynchronisationActive)
			{
				this.mSyncInstancesToolTipPopup.IsOpen = true;
			}
		}

		// Token: 0x06001240 RID: 4672 RVA: 0x0000CEE0 File Offset: 0x0000B0E0
		private void OperationsSyncGrid_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.ParentWindow.mIsSynchronisationActive && !this.mOperationsSyncGrid.IsMouseOver && !this.mSyncInstancesToolTipPopup.IsMouseOver)
			{
				this.mSyncInstancesToolTipPopup.IsOpen = false;
			}
		}

		// Token: 0x06001241 RID: 4673 RVA: 0x0000CF15 File Offset: 0x0000B115
		private void SyncInstancesToolTip_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.mOperationsSyncGrid.IsMouseOver && !this.mSyncInstancesToolTipPopup.IsMouseOver)
			{
				this.mSyncInstancesToolTipPopup.IsOpen = false;
			}
		}

		// Token: 0x04000CAB RID: 3243
		private MainWindow mMainWindow;

		// Token: 0x04000CAD RID: 3245
		private SortedList<int, KeyValuePair<FrameworkElement, double>> mOptionsPriorityPanel = new SortedList<int, KeyValuePair<FrameworkElement, double>>();

		// Token: 0x04000CAE RID: 3246
		internal double mMinimumExpectedTopBarWidth = 320.0;

		// Token: 0x04000CAF RID: 3247
		internal PerformanceState mSnailMode;

		// Token: 0x04000CB0 RID: 3248
		private DispatcherTimer mMacroRunningPopupTimer;

		// Token: 0x04000CB1 RID: 3249
		private DispatcherTimer mMacroRecordingPopupTimer;

		// Token: 0x04000CB2 RID: 3250
		private ulong MB_MULTIPLIER = 1048576UL;

		// Token: 0x02000213 RID: 531
		internal struct Win32Point
		{
			// Token: 0x04000CE5 RID: 3301
			public int X;

			// Token: 0x04000CE6 RID: 3302
			public int Y;
		}
	}
}
