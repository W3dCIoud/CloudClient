﻿using System;
using System.ComponentModel;

// Token: 0x02000012 RID: 18
[Description("SubElementDependent")]
[Serializable]
internal class MOBASkillCancel : IMAction
{
	// Token: 0x1700008A RID: 138
	// (get) Token: 0x06000126 RID: 294 RVA: 0x00002C44 File Offset: 0x00000E44
	// (set) Token: 0x06000127 RID: 295 RVA: 0x00002C51 File Offset: 0x00000E51
	public string Key
	{
		get
		{
			return this.mMOBASkill.KeyCancel;
		}
		set
		{
			this.mMOBASkill.KeyCancel = value;
		}
	}

	// Token: 0x1700008B RID: 139
	// (get) Token: 0x06000128 RID: 296 RVA: 0x00002C5F File Offset: 0x00000E5F
	// (set) Token: 0x06000129 RID: 297 RVA: 0x00002C6C File Offset: 0x00000E6C
	[Description("IMAP_CanvasElementY")]
	public double X
	{
		get
		{
			return this.mMOBASkill.CancelX;
		}
		set
		{
			this.mMOBASkill.CancelX = value;
		}
	}

	// Token: 0x1700008C RID: 140
	// (get) Token: 0x0600012A RID: 298 RVA: 0x00002C7A File Offset: 0x00000E7A
	// (set) Token: 0x0600012B RID: 299 RVA: 0x00002C87 File Offset: 0x00000E87
	[Description("IMAP_CanvasElementX")]
	public double Y
	{
		get
		{
			return this.mMOBASkill.CancelY;
		}
		set
		{
			this.mMOBASkill.CancelY = value;
		}
	}

	// Token: 0x0600012C RID: 300 RVA: 0x00002C95 File Offset: 0x00000E95
	internal MOBASkillCancel(MOBASkill action)
	{
		this.IsChildAction = true;
		base.Type = KeyActionType.MOBASkillCancel;
		this.mMOBASkill = action;
		this.ParentAction = action;
	}

	// Token: 0x0400008B RID: 139
	internal MOBASkill mMOBASkill;
}
