﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000CA RID: 202
	internal interface IControlFordimOverLay
	{
		// Token: 0x06000814 RID: 2068
		bool Close();

		// Token: 0x17000165 RID: 357
		// (get) Token: 0x06000815 RID: 2069
		// (set) Token: 0x06000816 RID: 2070
		bool IsCloseOnOverLayClick { get; set; }

		// Token: 0x06000817 RID: 2071
		bool Show();
	}
}
