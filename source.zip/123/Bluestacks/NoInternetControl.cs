﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000126 RID: 294
	public class NoInternetControl : UserControl, IComponentConnector
	{
		// Token: 0x06000BB8 RID: 3000 RVA: 0x000091CC File Offset: 0x000073CC
		public NoInternetControl(BrowserControl browserControl)
		{
			this.InitializeComponent();
			this.AssociatedControl = browserControl;
			BlueStacksUIBinding.Bind(this.mFailureTextBox, "STRING_NAVIGATE_FAILED", "");
			BlueStacksUIBinding.Bind(this.mBlueButton, "STRING_RETRY_CONNECTION_ISSUE_TEXT1");
		}

		// Token: 0x06000BB9 RID: 3001 RVA: 0x00009206 File Offset: 0x00007406
		private void mBlueButton_Click(object sender, RoutedEventArgs e)
		{
			this.AssociatedControl.NavigateTo(this.AssociatedControl.mFailedUrl);
		}

		// Token: 0x06000BBA RID: 3002 RVA: 0x0004FF5C File Offset: 0x0004E15C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/nointernetcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000BBB RID: 3003 RVA: 0x0004FF8C File Offset: 0x0004E18C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mFailureTextBox = (TextBlock)target;
				return;
			case 2:
				this.mErrorLine1 = (TextBlock)target;
				return;
			case 3:
				this.mErrorLine2 = (TextBlock)target;
				return;
			case 4:
				this.mBlueButton = (CustomButton)target;
				this.mBlueButton.Click += this.mBlueButton_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400086F RID: 2159
		private BrowserControl AssociatedControl;

		// Token: 0x04000870 RID: 2160
		internal TextBlock mFailureTextBox;

		// Token: 0x04000871 RID: 2161
		internal TextBlock mErrorLine1;

		// Token: 0x04000872 RID: 2162
		internal TextBlock mErrorLine2;

		// Token: 0x04000873 RID: 2163
		internal CustomButton mBlueButton;

		// Token: 0x04000874 RID: 2164
		private bool _contentLoaded;
	}
}
