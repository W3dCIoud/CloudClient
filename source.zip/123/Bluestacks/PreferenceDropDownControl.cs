﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using BlueStacks.BlueStacksUI.Controls;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200020F RID: 527
	public class PreferenceDropDownControl : UserControl, IComponentConnector, IStyleConnector
	{
		// Token: 0x14000023 RID: 35
		// (add) Token: 0x060011CD RID: 4557 RVA: 0x0006E1E4 File Offset: 0x0006C3E4
		// (remove) Token: 0x060011CE RID: 4558 RVA: 0x0006E21C File Offset: 0x0006C41C
		private event EventHandler LogoutConfirmationResetAccountAcceptedHandler;

		// Token: 0x14000024 RID: 36
		// (add) Token: 0x060011CF RID: 4559 RVA: 0x0006E254 File Offset: 0x0006C454
		// (remove) Token: 0x060011D0 RID: 4560 RVA: 0x0006E28C File Offset: 0x0006C48C
		private event EventHandler RestoreDefaultConfirmationClicked;

		// Token: 0x060011D1 RID: 4561 RVA: 0x0006E2C4 File Offset: 0x0006C4C4
		public PreferenceDropDownControl()
		{
			this.InitializeComponent();
			this.LogoutConfirmationResetAccountAcceptedHandler += this.PreferenceDropDownControl_CloseWindowConfirmationResetAccountAcceptedHandler;
			this.RestoreDefaultConfirmationClicked += this.PreferenceDropDownControl_RestoreDefaultConfirmationClicked;
			if (FeatureManager.Instance.IsCustomUIForDMMSandbox || !FeatureManager.Instance.ShowBeginnersGuidePreference)
			{
				this.BeginnerGuideGrid.Visibility = Visibility.Collapsed;
			}
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				this.mSpeedUpBstGrid.Visibility = Visibility.Collapsed;
				this.BeginnerGuideGrid.Visibility = Visibility.Collapsed;
				this.mUpgradeToFullBlueStacks.Visibility = Visibility.Visible;
			}
			if (!FeatureManager.Instance.IsShowSpeedUpTips)
			{
				this.mSpeedUpBstGrid.Visibility = Visibility.Collapsed;
			}
			if (!FeatureManager.Instance.IsShowHelpCenter)
			{
				this.mHelpCenterGrid.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x060011D2 RID: 4562 RVA: 0x0006E388 File Offset: 0x0006C588
		private void PreferenceDropDownControl_RestoreDefaultConfirmationClicked(object sender, EventArgs e)
		{
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "RestoreDefaultWallpaper", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, "Premium", null);
			this.mChooseWallpaperPopup.IsOpen = false;
			this.ParentWindow.mWelcomeTab.mHomeApp.RestoreWallpaperImage();
		}

		// Token: 0x060011D3 RID: 4563 RVA: 0x0006E3F8 File Offset: 0x0006C5F8
		internal void Init(MainWindow parentWindow)
		{
			this.ParentWindow = parentWindow;
			if (Oem.Instance.IsRemoveAccountOnExit)
			{
				this.mLogoutButtonGrid.Visibility = Visibility.Visible;
			}
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				this.mUpgradeToFullTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_UPGRADE_TO_STANDARD_BST", false).Replace(GameConfig.Instance.AppName, "BlueStacks");
			}
		}

		// Token: 0x060011D4 RID: 4564 RVA: 0x0006E45C File Offset: 0x0006C65C
		internal void LateInit()
		{
			if (FeatureManager.Instance.ShowClientOnTopPreference)
			{
				if (this.ParentWindow.EngineInstanceRegistry.IsClientOnTop)
				{
					this.mPinToTopToggleButton.ImageName = this.mPinToTopToggleButton.ImageName.Replace("_off", "_on");
				}
				else
				{
					this.mPinToTopToggleButton.ImageName = this.mPinToTopToggleButton.ImageName.Replace("_on", "_off");
				}
			}
			else
			{
				this.mPinToTopGrid.Visibility = Visibility.Collapsed;
			}
			if (FeatureManager.Instance.IsThemeEnabled && RegistryManager.Instance.InstallationType != InstallationTypes.GamingEdition)
			{
				this.mChangeSkinGrid.Visibility = Visibility.Visible;
			}
			if (this.ParentWindow != null && this.ParentWindow.EngineInstanceRegistry.IsGoogleSigninDone && !FeatureManager.Instance.IsWallpaperChangeDisabled && RegistryManager.Instance.InstallationType != InstallationTypes.GamingEdition)
			{
				this.mChangeWallpaperGrid.Visibility = Visibility.Visible;
			}
			this.mAutoAlignGrid.MouseLeftButtonUp += this.AutoAlign_MouseLeftButtonUp;
			this.mAutoAlignGrid.Opacity = 1.0;
			if (!FeatureManager.Instance.IsOperationsSyncEnabled)
			{
				this.mSyncGrid.Visibility = Visibility.Collapsed;
			}
			else if (BlueStacksUIUtils.sSyncInvolvedInstances.Contains(this.ParentWindow.mVmName) && !this.ParentWindow.mIsSyncMaster)
			{
				this.mSyncGrid.PreviewMouseLeftButtonUp -= this.SyncGrid_MouseLeftButtonUp;
				this.mSyncGrid.MouseEnter -= this.Grid_MouseEnter;
				this.mSyncGrid.Opacity = 0.5;
			}
			else
			{
				this.mSyncGrid.PreviewMouseLeftButtonUp -= this.SyncGrid_MouseLeftButtonUp;
				this.mSyncGrid.PreviewMouseLeftButtonUp += this.SyncGrid_MouseLeftButtonUp;
				this.mSyncGrid.MouseEnter -= this.Grid_MouseEnter;
				this.mSyncGrid.MouseEnter += this.Grid_MouseEnter;
				this.mSyncGrid.Opacity = 1.0;
			}
			this.SectionsTagVisibilityToggling();
		}

		// Token: 0x060011D5 RID: 4565 RVA: 0x0000C9CA File Offset: 0x0000ABCA
		internal void SectionsTagVisibilityToggling()
		{
			this.mCustomiseSectionTag.Visibility = (this.CheckSectionTagVisibility(this.mCustomiseSection) ? Visibility.Visible : Visibility.Collapsed);
			this.mHelpandsupportSectionTag.Visibility = (this.CheckSectionTagVisibility(this.mHelpandsupportSection) ? Visibility.Visible : Visibility.Collapsed);
		}

		// Token: 0x060011D6 RID: 4566 RVA: 0x0006E66C File Offset: 0x0006C86C
		private bool CheckSectionTagVisibility(Grid sectionGrid)
		{
			using (IEnumerator enumerator = sectionGrid.Children.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if ((((UIElement)enumerator.Current) as Grid).Visibility == Visibility.Visible)
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x060011D7 RID: 4567 RVA: 0x00005628 File Offset: 0x00003828
		private void Grid_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x060011D8 RID: 4568 RVA: 0x000046FF File Offset: 0x000028FF
		private void Grid_MouseLeave(object sender, MouseEventArgs e)
		{
			(sender as Grid).Background = Brushes.Transparent;
		}

		// Token: 0x060011D9 RID: 4569 RVA: 0x0006E6D0 File Offset: 0x0006C8D0
		private void EngineSettingGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked settings button");
			this.ParentWindow.mTopBar.mSettingsMenuPopup.IsOpen = false;
			this.ParentWindow.mCommonHandler.LaunchSettingsWindow();
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "Settings", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x060011DA RID: 4570 RVA: 0x0006E74C File Offset: 0x0006C94C
		private void BeginnerGuideGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked beginners guide button");
			this.ParentWindow.mTopBar.mSettingsMenuPopup.IsOpen = false;
			BeginnersGuide beginnersGuide = new BeginnersGuide();
			beginnersGuide.Height = this.ParentWindow.ActualHeight * 0.8;
			beginnersGuide.Width = beginnersGuide.Height * 16.0 / 9.0;
			new ContainerWindow(this.ParentWindow, beginnersGuide, (double)((int)beginnersGuide.Width + 60), (double)((int)beginnersGuide.Height + 60), false, true);
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "BeginnersGuide", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x060011DB RID: 4571 RVA: 0x0006E820 File Offset: 0x0006CA20
		private void ReportProblemGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked report problem button");
			new Process
			{
				StartInfo = 
				{
					Arguments = "-vmname:" + this.ParentWindow.mVmName,
					FileName = System.IO.Path.Combine(RegistryStrings.InstallDir, "HD-LogCollector.exe")
				}
			}.Start();
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "ReportProblem", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x060011DC RID: 4572 RVA: 0x0006E8BC File Offset: 0x0006CABC
		private void LogoutButtonGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked logout button");
			if (this.ParentWindow.mGuestBootCompleted)
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.AddButton(ButtonColors.Red, "STRING_YES", this.LogoutConfirmationResetAccountAcceptedHandler, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, "STRING_NO", null, null, false, null);
				BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_LOGOUT_BLUESTACKS3", "");
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_REMOVE_GOOGLE_ACCOUNT", "");
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
				ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "Logout", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
			}
		}

		// Token: 0x060011DD RID: 4573 RVA: 0x0000CA06 File Offset: 0x0000AC06
		private void PreferenceDropDownControl_CloseWindowConfirmationResetAccountAcceptedHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mAppHandler.SendRequestToRemoveAccountAndCloseWindowASync(false);
		}

		// Token: 0x060011DE RID: 4574 RVA: 0x0006E9A4 File Offset: 0x0006CBA4
		private void SpeedUpBstGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked SpeedUp BlueStacks button");
			SpeedUpBlueStacks speedUpBlueStacks = new SpeedUpBlueStacks();
			if (this.ParentWindow.mTopBar.mSnailMode == PerformanceState.VtxDisabled)
			{
				speedUpBlueStacks.mEnableVt.Visibility = Visibility.Visible;
			}
			speedUpBlueStacks.mUpgradeComputer.Visibility = Visibility.Visible;
			speedUpBlueStacks.mPowerPlan.Visibility = Visibility.Visible;
			speedUpBlueStacks.mConfigureAntivirus.Visibility = Visibility.Visible;
			speedUpBlueStacks.mDiasbleHyperV.Visibility = Visibility.Visible;
			new ContainerWindow(this.ParentWindow, speedUpBlueStacks, 640.0, 570.0, false, true);
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "SpeedUpBlueStacks", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x060011DF RID: 4575 RVA: 0x0006EA70 File Offset: 0x0006CC70
		private void mHelpCenterGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			string helpCenterUrl = this.ParentWindow.Utils.GetHelpCenterUrl();
			this.ParentWindow.mTopBar.mSettingsMenuPopup.IsOpen = false;
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "HelpCentre", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				Process.Start(helpCenterUrl);
				return;
			}
			this.ParentWindow.mTopBar.mAppTabButtons.AddWebTab(helpCenterUrl, "STRING_FEEDBACK", "help_center", true, "FEEDBACK_TEXT", false);
		}

		// Token: 0x060011E0 RID: 4576 RVA: 0x0006EB20 File Offset: 0x0006CD20
		private void mChangeSkinGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			ChangeThemeWindow control = new ChangeThemeWindow(this.ParentWindow);
			int num = 504;
			int num2 = 652;
			new ContainerWindow(this.ParentWindow, control, (double)num2, (double)num, false, true);
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "ChangeSkin", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x060011E1 RID: 4577 RVA: 0x0000CA19 File Offset: 0x0000AC19
		private void NotificationPopup_Opened(object sender, EventArgs e)
		{
			this.dummyGridForSize2.Visibility = Visibility.Visible;
		}

		// Token: 0x060011E2 RID: 4578 RVA: 0x0000CA27 File Offset: 0x0000AC27
		private void NotificationPopup_Closed(object sender, EventArgs e)
		{
			this.mChangeWallpaperGrid.Background = Brushes.Transparent;
		}

		// Token: 0x060011E3 RID: 4579 RVA: 0x0006EB98 File Offset: 0x0006CD98
		private void ChooseNewGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mTopBar.mSettingsMenuPopup.IsOpen = false;
			if (RegistryManager.Instance.IsPremium)
			{
				ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "ChangeWallPaperButton", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, "Premium", null);
				this.ParentWindow.mWelcomeTab.mHomeApp.ChooseWallpaper();
				return;
			}
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "ChangeWallPaperButton", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, "NonPremium", null);
			string str = "/bluestacks_account?extra=section:plans";
			string text = WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + str);
			text += "&email=";
			text += RegistryManager.Instance.RegisteredEmail;
			text += "&token=";
			text += RegistryManager.Instance.Token;
			this.ParentWindow.mTopBar.mAppTabButtons.AddWebTab(text, "STRING_ACCOUNT", "account_tab", true, "account_tab", false);
		}

		// Token: 0x060011E4 RID: 4580 RVA: 0x0006ECDC File Offset: 0x0006CEDC
		private void SetDefaultGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (File.Exists(this.ParentWindow.mWelcomeTab.mHomeApp.BackgroundImagePath))
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_YES", this.RestoreDefaultConfirmationClicked, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, "STRING_NO", null, null, false, null);
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_RESTORE_DEFAULT_WALLPAPER", "");
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
			}
		}

		// Token: 0x060011E5 RID: 4581 RVA: 0x0006ED74 File Offset: 0x0006CF74
		private void mChangeWallpaperGrid_MouseEnter(object sender, MouseEventArgs e)
		{
			if (File.Exists(this.ParentWindow.mWelcomeTab.mHomeApp.BackgroundImagePath))
			{
				this.mChangeWallpaperGrid.MouseLeftButtonUp -= this.ChooseNewGrid_MouseLeftButtonUp;
				this.mWallpaperPopup.PlacementTarget = this.mChooseNewGrid;
				this.mChooseWallpaperPopup.IsOpen = false;
				this.mChooseWallpaperPopup.IsOpen = true;
			}
			else
			{
				if (!RegistryManager.Instance.IsPremium)
				{
					this.mWallpaperPopup.PlacementTarget = this.mChangeWallpaperGrid;
					this.mWallpaperPopup.IsOpen = false;
					this.mWallpaperPopup.IsOpen = true;
				}
				this.mChangeWallpaperGrid.MouseLeftButtonUp -= this.ChooseNewGrid_MouseLeftButtonUp;
				this.mChangeWallpaperGrid.MouseLeftButtonUp += this.ChooseNewGrid_MouseLeftButtonUp;
			}
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x060011E6 RID: 4582 RVA: 0x0006EE58 File Offset: 0x0006D058
		private void mChangeWallpaperGrid_MouseLeave(object sender, MouseEventArgs e)
		{
			(sender as Grid).Background = Brushes.Transparent;
			if (!this.mChangeWallpaperGrid.IsMouseOver && !this.mChooseWallpaperPopupGrid.IsMouseOver && !this.mWallpaperPopupGrid.IsMouseOver)
			{
				this.mChooseWallpaperPopup.IsOpen = false;
				this.mWallpaperPopup.IsOpen = false;
			}
		}

		// Token: 0x060011E7 RID: 4583 RVA: 0x0000CA39 File Offset: 0x0000AC39
		private void ChooseNewGrid_MouseEnter(object sender, MouseEventArgs e)
		{
			if (!RegistryManager.Instance.IsPremium)
			{
				this.mWallpaperPopup.IsOpen = true;
			}
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x060011E8 RID: 4584 RVA: 0x0000CA68 File Offset: 0x0000AC68
		private void ChooseNewGrid_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.mChooseNewGrid.IsMouseOver && !this.mWallpaperPopupGrid.IsMouseOver)
			{
				this.mWallpaperPopup.IsOpen = false;
			}
			(sender as Grid).Background = Brushes.Transparent;
		}

		// Token: 0x060011E9 RID: 4585 RVA: 0x0000CAA0 File Offset: 0x0000ACA0
		private void SetDefaultGrid_MouseLeave(object sender, MouseEventArgs e)
		{
			if (File.Exists(this.ParentWindow.mWelcomeTab.mHomeApp.BackgroundImagePath))
			{
				(sender as Grid).Background = Brushes.Transparent;
			}
		}

		// Token: 0x060011EA RID: 4586 RVA: 0x0000CACE File Offset: 0x0000ACCE
		private void SetDefaultGrid_MouseEnter(object sender, MouseEventArgs e)
		{
			if (File.Exists(this.ParentWindow.mWelcomeTab.mHomeApp.BackgroundImagePath))
			{
				BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
			}
		}

		// Token: 0x060011EB RID: 4587 RVA: 0x0000CB01 File Offset: 0x0000AD01
		private void mWallpaperPopup_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.mChooseNewGrid.IsMouseOver)
			{
				this.mWallpaperPopup.IsOpen = false;
			}
		}

		// Token: 0x060011EC RID: 4588 RVA: 0x0006EEB4 File Offset: 0x0006D0B4
		private void mChooseWallpaperPopup_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.mChangeWallpaperGrid.IsMouseOver && !this.mChooseWallpaperPopupGrid.IsMouseOver && !this.mWallpaperPopupGrid.IsMouseOver)
			{
				this.mChooseWallpaperPopup.IsOpen = false;
				this.mWallpaperPopup.IsOpen = false;
			}
		}

		// Token: 0x060011ED RID: 4589 RVA: 0x0006EF00 File Offset: 0x0006D100
		private void mUpgradeToFullBlueStacks_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			string text = LocaleStrings.GetLocalizedString("STRING_UPGRADE_TO_STANDARD_BST", false);
			string text2 = string.Format("{0} {1}", LocaleStrings.GetLocalizedString("STRING_CONTINUING_WILL_UPGRADE_TO_STD_BST", false), LocaleStrings.GetLocalizedString("STRING_LAUNCH_BLUESTACKS_FROM_DESK_SHORTCUT", false));
			text = text.Replace(GameConfig.Instance.AppName, "BlueStacks");
			text2 = text2.Replace(GameConfig.Instance.AppName, "BlueStacks");
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.AddButton(ButtonColors.Blue, "STRING_YES", new EventHandler(this.UpgradeToFullBstHandler), null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_NO", null, null, false, null);
			BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, text, "");
			BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, text2, "");
			this.ParentWindow.ShowDimOverlay(null);
			customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
			customMessageWindow.ShowDialog();
			this.ParentWindow.HideDimOverlay();
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "UpgradeBlueStacks", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x060011EE RID: 4590 RVA: 0x0006F024 File Offset: 0x0006D224
		private void UpgradeToFullBstHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mWelcomeTab.mBackground.Visibility = Visibility.Visible;
			this.ParentWindow.ShowDimOverlayForUpgrade();
			BackgroundWorker backgroundWorker = new BackgroundWorker();
			backgroundWorker.DoWork += this.MBWUpdateToFullVersion_DoWork;
			backgroundWorker.RunWorkerCompleted += this.MBWUpdateToFullVersion_RunWorkerCompleted;
			backgroundWorker.RunWorkerAsync();
		}

		// Token: 0x060011EF RID: 4591 RVA: 0x0000CB1C File Offset: 0x0000AD1C
		private void MBWUpdateToFullVersion_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			this.ParentWindow.MainWindow_CloseWindowConfirmationAcceptedHandler(null, null);
		}

		// Token: 0x060011F0 RID: 4592 RVA: 0x0000CB2B File Offset: 0x0000AD2B
		private void MBWUpdateToFullVersion_DoWork(object sender, DoWorkEventArgs e)
		{
			Utils.UpgradeToFullVersionAndCreateBstShortcut(true);
		}

		// Token: 0x060011F1 RID: 4593 RVA: 0x0006F080 File Offset: 0x0006D280
		private void SyncGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mTopBar.mSettingsMenuPopup.IsOpen = false;
			this.ParentWindow.ShowSynchronizerWindow();
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "OperationSync", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x060011F2 RID: 4594 RVA: 0x0006F0EC File Offset: 0x0006D2EC
		private void mUpgradeBluestacksStatus_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mUpgradeBluestacksStatusTextBlock.Text.ToString().Equals(LocaleStrings.GetLocalizedString("STRING_DOWNLOAD_UPDATE", false)))
			{
				ClientStats.SendBluestacksUpdaterUIStatsAsync(ClientStatsEvent.SettingsGearDwnld, "");
				UpdatePrompt updatePrompt = new UpdatePrompt(BlueStacksUpdater.sBstUpdateData);
				updatePrompt.Height = 215.0;
				updatePrompt.Width = 400.0;
				new ContainerWindow(this.ParentWindow, updatePrompt, (double)((int)updatePrompt.Width), (double)((int)updatePrompt.Height), false, true);
				return;
			}
			if (this.mUpgradeBluestacksStatusTextBlock.Text.ToString().Equals(LocaleStrings.GetLocalizedString("STRING_DOWNLOADING_UPDATE", false)))
			{
				this.ParentWindow.mTopBar.mSettingsMenuPopup.IsOpen = false;
				BlueStacksUpdater.ShowDownloadProgress();
				return;
			}
			if (this.mUpgradeBluestacksStatusTextBlock.Text.ToString().Equals(LocaleStrings.GetLocalizedString("STRING_INSTALL_UPDATE", false)))
			{
				this.ParentWindow.ShowInstallPopup();
			}
		}

		// Token: 0x060011F3 RID: 4595 RVA: 0x0006F1E0 File Offset: 0x0006D3E0
		internal void ToggleStreamingMode(bool enable)
		{
			if (enable)
			{
				this.mStreaminModeToggleButton.ImageName = this.mStreaminModeToggleButton.ImageName.Replace("_off", "_on");
				return;
			}
			this.mStreaminModeToggleButton.ImageName = this.mStreaminModeToggleButton.ImageName.Replace("_on", "_off");
		}

		// Token: 0x060011F4 RID: 4596 RVA: 0x0006F23C File Offset: 0x0006D43C
		private void AutoAlign_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mTopBar.mSettingsMenuPopup.IsOpen = false;
			this.ParentWindow.mCommonHandler.ArrangeWindow();
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "AutoAlign", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x060011F5 RID: 4597 RVA: 0x0006F2B0 File Offset: 0x0006D4B0
		private void PinToTop_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			CustomPictureBox customPictureBox = sender as CustomPictureBox;
			if (customPictureBox.ImageName.Contains("_off"))
			{
				customPictureBox.ImageName = "toggle_on";
				this.ParentWindow.EngineInstanceRegistry.IsClientOnTop = true;
				this.ParentWindow.Topmost = true;
				ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "PinToTopOn", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
				return;
			}
			customPictureBox.ImageName = "toggle_off";
			this.ParentWindow.EngineInstanceRegistry.IsClientOnTop = false;
			this.ParentWindow.Topmost = false;
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "PinToTopOff", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x060011F6 RID: 4598 RVA: 0x0006F3A4 File Offset: 0x0006D5A4
		private void Streaming_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			CustomPictureBox customPictureBox = sender as CustomPictureBox;
			if (customPictureBox.ImageName.Contains("_off"))
			{
				customPictureBox.ImageName = "toggle_on";
				this.ParentWindow.mFrontendHandler.ToggleStreamingMode(true);
				ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "StreamingModeStart", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
			}
			else
			{
				customPictureBox.ImageName = "toggle_off";
				this.ParentWindow.mFrontendHandler.ToggleStreamingMode(false);
				ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "StreamingModeStop", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
			}
			this.ParentWindow.mTopBar.mSettingsMenuPopup.IsOpen = false;
		}

		// Token: 0x060011F7 RID: 4599 RVA: 0x0000CB33 File Offset: 0x0000AD33
		private void TextBlock_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (sender != null)
			{
				(sender as TextBlock).SetTextblockTooltip(null);
			}
		}

		// Token: 0x060011F8 RID: 4600 RVA: 0x0006F498 File Offset: 0x0006D698
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/preferencedropdowncontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060011F9 RID: 4601 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060011FA RID: 4602 RVA: 0x0006F4C8 File Offset: 0x0006D6C8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 2:
				this.EngineSettingGrid = (Grid)target;
				this.EngineSettingGrid.MouseEnter += this.Grid_MouseEnter;
				this.EngineSettingGrid.MouseLeave += this.Grid_MouseLeave;
				this.EngineSettingGrid.PreviewMouseLeftButtonUp += this.EngineSettingGrid_MouseLeftButtonUp;
				return;
			case 3:
				this.mEngineSettingsButtonImage = (CustomPictureBox)target;
				return;
			case 4:
				this.mSettingsBtnNotification = (Ellipse)target;
				return;
			case 5:
				this.mPinToTopGrid = (Grid)target;
				this.mPinToTopGrid.MouseEnter += this.Grid_MouseEnter;
				this.mPinToTopGrid.MouseLeave += this.Grid_MouseLeave;
				return;
			case 6:
				this.mPinToTopImage = (CustomPictureBox)target;
				return;
			case 7:
				this.mPinToTopToggleButton = (CustomPictureBox)target;
				this.mPinToTopToggleButton.PreviewMouseLeftButtonUp += this.PinToTop_MouseLeftButtonUp;
				return;
			case 8:
				this.mStreamingMode = (Grid)target;
				this.mStreamingMode.MouseEnter += this.Grid_MouseEnter;
				this.mStreamingMode.MouseLeave += this.Grid_MouseLeave;
				return;
			case 9:
				this.mStreamingModeImage = (CustomPictureBox)target;
				return;
			case 10:
				this.mStreaminModeToggleButton = (CustomPictureBox)target;
				this.mStreaminModeToggleButton.PreviewMouseLeftButtonUp += this.Streaming_MouseLeftButtonUp;
				return;
			case 11:
				this.mMultiInstanceSectionTag = (Grid)target;
				return;
			case 12:
				this.mMultiInstanceSectionBorderLine = (Separator)target;
				return;
			case 13:
				this.mMultiInstanceSection = (Grid)target;
				return;
			case 14:
				this.mSyncGrid = (Grid)target;
				this.mSyncGrid.MouseEnter += this.Grid_MouseEnter;
				this.mSyncGrid.MouseLeave += this.Grid_MouseLeave;
				this.mSyncGrid.PreviewMouseLeftButtonUp += this.SyncGrid_MouseLeftButtonUp;
				return;
			case 15:
				this.mSyncOperationsImage = (CustomPictureBox)target;
				return;
			case 16:
				this.mAutoAlignGrid = (Grid)target;
				this.mAutoAlignGrid.MouseEnter += this.Grid_MouseEnter;
				this.mAutoAlignGrid.MouseLeave += this.Grid_MouseLeave;
				this.mAutoAlignGrid.PreviewMouseLeftButtonUp += this.AutoAlign_MouseLeftButtonUp;
				return;
			case 17:
				this.mAutoAlignImage = (CustomPictureBox)target;
				return;
			case 18:
				this.mUpgradeBluestacksStatus = (Grid)target;
				this.mUpgradeBluestacksStatus.MouseEnter += this.Grid_MouseEnter;
				this.mUpgradeBluestacksStatus.MouseLeave += this.Grid_MouseLeave;
				this.mUpgradeBluestacksStatus.MouseLeftButtonUp += this.mUpgradeBluestacksStatus_MouseLeftButtonUp;
				return;
			case 19:
				this.mUpgradeBluestacksStatusTextBlock = (TextBlock)target;
				return;
			case 20:
				this.mUpdateDownloadProgressPercentage = (Label)target;
				return;
			case 21:
				this.mUpgradeToFullBlueStacks = (Grid)target;
				this.mUpgradeToFullBlueStacks.MouseEnter += this.Grid_MouseEnter;
				this.mUpgradeToFullBlueStacks.MouseLeave += this.Grid_MouseLeave;
				this.mUpgradeToFullBlueStacks.MouseLeftButtonUp += this.mUpgradeToFullBlueStacks_MouseLeftButtonUp;
				return;
			case 22:
				this.mUpgradeToFullTextBlock = (TextBlock)target;
				return;
			case 23:
				this.BeginnerGuideGrid = (Grid)target;
				this.BeginnerGuideGrid.MouseEnter += this.Grid_MouseEnter;
				this.BeginnerGuideGrid.MouseLeave += this.Grid_MouseLeave;
				this.BeginnerGuideGrid.MouseLeftButtonUp += this.BeginnerGuideGrid_MouseLeftButtonUp;
				return;
			case 24:
				this.mLogoutButtonGrid = (Grid)target;
				this.mLogoutButtonGrid.MouseEnter += this.Grid_MouseEnter;
				this.mLogoutButtonGrid.MouseLeave += this.Grid_MouseLeave;
				this.mLogoutButtonGrid.MouseLeftButtonUp += this.LogoutButtonGrid_MouseLeftButtonUp;
				return;
			case 25:
				this.mCustomiseSectionTag = (Grid)target;
				return;
			case 26:
				this.mCustomiseSectionBorderLine = (Separator)target;
				return;
			case 27:
				this.mCustomiseSection = (Grid)target;
				return;
			case 28:
				this.mChangeSkinGrid = (Grid)target;
				this.mChangeSkinGrid.MouseEnter += this.Grid_MouseEnter;
				this.mChangeSkinGrid.MouseLeave += this.Grid_MouseLeave;
				this.mChangeSkinGrid.PreviewMouseLeftButtonUp += this.mChangeSkinGrid_MouseLeftButtonUp;
				return;
			case 29:
				this.mChangeSkinImage = (CustomPictureBox)target;
				return;
			case 30:
				this.mChangeWallpaperGrid = (Grid)target;
				this.mChangeWallpaperGrid.MouseEnter += this.mChangeWallpaperGrid_MouseEnter;
				this.mChangeWallpaperGrid.MouseLeave += this.mChangeWallpaperGrid_MouseLeave;
				return;
			case 31:
				this.mChangeWallpaperImage = (CustomPictureBox)target;
				return;
			case 32:
				this.mHelpandsupportSectionTag = (Grid)target;
				return;
			case 33:
				this.mHelpAndSupportSectionBorderLine = (Separator)target;
				return;
			case 34:
				this.mHelpandsupportSection = (Grid)target;
				return;
			case 35:
				this.ReportProblemGrid = (Grid)target;
				this.ReportProblemGrid.MouseEnter += this.Grid_MouseEnter;
				this.ReportProblemGrid.MouseLeave += this.Grid_MouseLeave;
				this.ReportProblemGrid.MouseLeftButtonUp += this.ReportProblemGrid_MouseLeftButtonUp;
				return;
			case 36:
				this.mHelpCenterGrid = (Grid)target;
				this.mHelpCenterGrid.MouseEnter += this.Grid_MouseEnter;
				this.mHelpCenterGrid.MouseLeave += this.Grid_MouseLeave;
				this.mHelpCenterGrid.PreviewMouseLeftButtonUp += this.mHelpCenterGrid_MouseLeftButtonUp;
				return;
			case 37:
				this.mHelpCenterImage = (CustomPictureBox)target;
				return;
			case 38:
				this.mSpeedUpBstGrid = (Grid)target;
				this.mSpeedUpBstGrid.MouseEnter += this.Grid_MouseEnter;
				this.mSpeedUpBstGrid.MouseLeave += this.Grid_MouseLeave;
				this.mSpeedUpBstGrid.PreviewMouseLeftButtonUp += this.SpeedUpBstGrid_MouseLeftButtonUp;
				return;
			case 39:
				this.mSpeedUpBstImage = (CustomPictureBox)target;
				return;
			case 40:
				this.mWallpaperPopup = (CustomPopUp)target;
				return;
			case 41:
				this.mWallpaperPopupGrid = (Grid)target;
				return;
			case 42:
				this.dummyGridForSize = (Grid)target;
				return;
			case 43:
				this.mWallpaperPopupBorder = (Border)target;
				return;
			case 44:
				this.mMaskBorder = (Border)target;
				return;
			case 45:
				this.mTitleText = (TextBlock)target;
				return;
			case 46:
				this.mBodyText = (TextBlock)target;
				return;
			case 47:
				this.RightArrow = (System.Windows.Shapes.Path)target;
				return;
			case 48:
				this.mChooseWallpaperPopup = (CustomPopUp)target;
				return;
			case 49:
				this.mChooseWallpaperPopupGrid = (Grid)target;
				return;
			case 50:
				this.dummyGridForSize2 = (Grid)target;
				return;
			case 51:
				this.mPopupGridBorder = (Border)target;
				return;
			case 52:
				this.mMaskBorder2 = (Border)target;
				return;
			case 53:
				this.mChooseNewGrid = (Grid)target;
				this.mChooseNewGrid.MouseEnter += this.ChooseNewGrid_MouseEnter;
				this.mChooseNewGrid.MouseLeave += this.ChooseNewGrid_MouseLeave;
				this.mChooseNewGrid.MouseLeftButtonUp += this.ChooseNewGrid_MouseLeftButtonUp;
				return;
			case 54:
				this.mSetDefaultGrid = (Grid)target;
				this.mSetDefaultGrid.MouseEnter += this.SetDefaultGrid_MouseEnter;
				this.mSetDefaultGrid.MouseLeave += this.SetDefaultGrid_MouseLeave;
				this.mSetDefaultGrid.MouseLeftButtonUp += this.SetDefaultGrid_MouseLeftButtonUp;
				return;
			case 55:
				this.mRestoreDefaultText = (TextBlock)target;
				return;
			case 56:
				this.mRightArrow = (System.Windows.Shapes.Path)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x060011FB RID: 4603 RVA: 0x0006FCCC File Offset: 0x0006DECC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				EventSetter eventSetter = new EventSetter();
				eventSetter.Event = FrameworkElement.SizeChangedEvent;
				eventSetter.Handler = new SizeChangedEventHandler(this.TextBlock_SizeChanged);
				((Style)target).Setters.Add(eventSetter);
			}
		}

		// Token: 0x04000C65 RID: 3173
		public MainWindow ParentWindow;

		// Token: 0x04000C68 RID: 3176
		internal Grid EngineSettingGrid;

		// Token: 0x04000C69 RID: 3177
		internal CustomPictureBox mEngineSettingsButtonImage;

		// Token: 0x04000C6A RID: 3178
		internal Ellipse mSettingsBtnNotification;

		// Token: 0x04000C6B RID: 3179
		internal Grid mPinToTopGrid;

		// Token: 0x04000C6C RID: 3180
		internal CustomPictureBox mPinToTopImage;

		// Token: 0x04000C6D RID: 3181
		internal CustomPictureBox mPinToTopToggleButton;

		// Token: 0x04000C6E RID: 3182
		internal Grid mStreamingMode;

		// Token: 0x04000C6F RID: 3183
		internal CustomPictureBox mStreamingModeImage;

		// Token: 0x04000C70 RID: 3184
		internal CustomPictureBox mStreaminModeToggleButton;

		// Token: 0x04000C71 RID: 3185
		internal Grid mMultiInstanceSectionTag;

		// Token: 0x04000C72 RID: 3186
		internal Separator mMultiInstanceSectionBorderLine;

		// Token: 0x04000C73 RID: 3187
		internal Grid mMultiInstanceSection;

		// Token: 0x04000C74 RID: 3188
		internal Grid mSyncGrid;

		// Token: 0x04000C75 RID: 3189
		internal CustomPictureBox mSyncOperationsImage;

		// Token: 0x04000C76 RID: 3190
		internal Grid mAutoAlignGrid;

		// Token: 0x04000C77 RID: 3191
		internal CustomPictureBox mAutoAlignImage;

		// Token: 0x04000C78 RID: 3192
		internal Grid mUpgradeBluestacksStatus;

		// Token: 0x04000C79 RID: 3193
		internal TextBlock mUpgradeBluestacksStatusTextBlock;

		// Token: 0x04000C7A RID: 3194
		internal Label mUpdateDownloadProgressPercentage;

		// Token: 0x04000C7B RID: 3195
		internal Grid mUpgradeToFullBlueStacks;

		// Token: 0x04000C7C RID: 3196
		internal TextBlock mUpgradeToFullTextBlock;

		// Token: 0x04000C7D RID: 3197
		internal Grid BeginnerGuideGrid;

		// Token: 0x04000C7E RID: 3198
		internal Grid mLogoutButtonGrid;

		// Token: 0x04000C7F RID: 3199
		internal Grid mCustomiseSectionTag;

		// Token: 0x04000C80 RID: 3200
		internal Separator mCustomiseSectionBorderLine;

		// Token: 0x04000C81 RID: 3201
		internal Grid mCustomiseSection;

		// Token: 0x04000C82 RID: 3202
		internal Grid mChangeSkinGrid;

		// Token: 0x04000C83 RID: 3203
		internal CustomPictureBox mChangeSkinImage;

		// Token: 0x04000C84 RID: 3204
		internal Grid mChangeWallpaperGrid;

		// Token: 0x04000C85 RID: 3205
		internal CustomPictureBox mChangeWallpaperImage;

		// Token: 0x04000C86 RID: 3206
		internal Grid mHelpandsupportSectionTag;

		// Token: 0x04000C87 RID: 3207
		internal Separator mHelpAndSupportSectionBorderLine;

		// Token: 0x04000C88 RID: 3208
		internal Grid mHelpandsupportSection;

		// Token: 0x04000C89 RID: 3209
		internal Grid ReportProblemGrid;

		// Token: 0x04000C8A RID: 3210
		internal Grid mHelpCenterGrid;

		// Token: 0x04000C8B RID: 3211
		internal CustomPictureBox mHelpCenterImage;

		// Token: 0x04000C8C RID: 3212
		internal Grid mSpeedUpBstGrid;

		// Token: 0x04000C8D RID: 3213
		internal CustomPictureBox mSpeedUpBstImage;

		// Token: 0x04000C8E RID: 3214
		internal CustomPopUp mWallpaperPopup;

		// Token: 0x04000C8F RID: 3215
		internal Grid mWallpaperPopupGrid;

		// Token: 0x04000C90 RID: 3216
		internal Grid dummyGridForSize;

		// Token: 0x04000C91 RID: 3217
		internal Border mWallpaperPopupBorder;

		// Token: 0x04000C92 RID: 3218
		internal Border mMaskBorder;

		// Token: 0x04000C93 RID: 3219
		internal TextBlock mTitleText;

		// Token: 0x04000C94 RID: 3220
		internal TextBlock mBodyText;

		// Token: 0x04000C95 RID: 3221
		internal System.Windows.Shapes.Path RightArrow;

		// Token: 0x04000C96 RID: 3222
		internal CustomPopUp mChooseWallpaperPopup;

		// Token: 0x04000C97 RID: 3223
		internal Grid mChooseWallpaperPopupGrid;

		// Token: 0x04000C98 RID: 3224
		internal Grid dummyGridForSize2;

		// Token: 0x04000C99 RID: 3225
		internal Border mPopupGridBorder;

		// Token: 0x04000C9A RID: 3226
		internal Border mMaskBorder2;

		// Token: 0x04000C9B RID: 3227
		internal Grid mChooseNewGrid;

		// Token: 0x04000C9C RID: 3228
		internal Grid mSetDefaultGrid;

		// Token: 0x04000C9D RID: 3229
		internal TextBlock mRestoreDefaultText;

		// Token: 0x04000C9E RID: 3230
		internal System.Windows.Shapes.Path mRightArrow;

		// Token: 0x04000C9F RID: 3231
		private bool _contentLoaded;
	}
}
