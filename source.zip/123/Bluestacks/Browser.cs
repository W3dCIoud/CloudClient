﻿using System;
using System.Threading;
using System.Windows;
using System.Windows.Media;
using BlueStacks.Common;
using Xilium.CefGlue.WPF;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200004A RID: 74
	public class Browser : WpfCefBrowser
	{
		// Token: 0x17000122 RID: 290
		// (get) Token: 0x06000360 RID: 864 RVA: 0x00004449 File Offset: 0x00002649
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x06000361 RID: 865 RVA: 0x00018BF8 File Offset: 0x00016DF8
		public Browser(float zoomLevel = 0f)
		{
			base.Loaded += this.Browser_Loaded;
			base.OnBeforePopup += this.Browser_OnBeforePopup;
			base.LoadingStateChange += new LoadingStateChangeEventHandler(this.Browser_LoadingStateChange);
			this.mCustomZoomLevel = zoomLevel;
			if (RegistryManager.Instance.CefDevEnv == 1)
			{
				base.mAllowDevTool = true;
				base.mDevToolHeader = base.StartUrl;
			}
		}

		// Token: 0x06000362 RID: 866 RVA: 0x0000446A File Offset: 0x0000266A
		private bool Browser_OnBeforePopup(string url)
		{
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				BlueStacksUIUtils.OpenUrl(url);
				return true;
			}
			return false;
		}

		// Token: 0x06000363 RID: 867 RVA: 0x00004481 File Offset: 0x00002681
		public Browser(string url)
		{
			this.url = url;
		}

		// Token: 0x06000364 RID: 868 RVA: 0x00018C68 File Offset: 0x00016E68
		private void Browser_Loaded(object sender, RoutedEventArgs e)
		{
			try
			{
				this.isLoaded = true;
				Matrix transformToDevice = PresentationSource.FromVisual((Visual)sender).CompositionTarget.TransformToDevice;
				ScaleTransform scaleTransform = new ScaleTransform(1.0 / transformToDevice.M11, 1.0 / transformToDevice.M22);
				if (scaleTransform.CanFreeze)
				{
					scaleTransform.Freeze();
				}
				base.LayoutTransform = scaleTransform;
				this.zoomLevel = Math.Log(transformToDevice.M11) / Math.Log(1.2);
				if (this.mCustomZoomLevel != 0f)
				{
					double num = Math.Log10((double)this.mCustomZoomLevel) / Math.Log10(1.2);
					this.zoomLevel += num;
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Failed to get zoom factor of browser with url {0} and error :{1}", new object[]
				{
					this.url,
					ex.ToString()
				});
			}
		}

		// Token: 0x06000365 RID: 869 RVA: 0x00018D60 File Offset: 0x00016F60
		private void Browser_LoadingStateChange(object sender, LoadingStateChangeEventArgs e)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					string text = base.getURL();
					if (!string.IsNullOrEmpty(text))
					{
						string packageName = text.Substring(text.LastIndexOf("=") + 1);
						if (text.Contains("play.google.com"))
						{
							this.ParentWindow.mAppHandler.LaunchPlayRequestAsync(packageName);
						}
					}
				}
				catch (Exception)
				{
				}
			}), new object[0]);
			if (!e.IsLoading)
			{
				try
				{
					base.SetZoomLevel(this.zoomLevel);
				}
				catch (Exception ex)
				{
					Logger.Error("Error while setting zoom in browser with url {0} and error :{1}", new object[]
					{
						this.url,
						ex.ToString()
					});
				}
			}
		}

		// Token: 0x06000366 RID: 870 RVA: 0x00018DD8 File Offset: 0x00016FD8
		public void CallJs(string methodName, object[] args)
		{
			if (this.isLoaded)
			{
				new Thread(delegate()
				{
					try
					{
						if (args.Length == 1)
						{
							string text = args[0].ToString();
							text = text.Replace("%27", "&#39;").Replace("'", "&#39;");
							string text2 = string.Format("javascript:{0}('{1}')", methodName, text);
							Logger.Info("calling " + methodName);
							this.ExecuteJavaScript(text2, this.getURL(), 0);
						}
						else if (args.Length == 0)
						{
							string text3 = string.Format("javascript:{0}()", methodName);
							Logger.Info("calling " + methodName);
							this.ExecuteJavaScript(text3, this.getURL(), 0);
						}
						else
						{
							Logger.Error("Error: function supported for one length array object to be changed later");
						}
					}
					catch (Exception ex)
					{
						Logger.Error(ex.ToString());
					}
				})
				{
					IsBackground = true
				}.Start();
			}
		}

		// Token: 0x040001DF RID: 479
		private bool isLoaded;

		// Token: 0x040001E0 RID: 480
		private string url;

		// Token: 0x040001E1 RID: 481
		private double zoomLevel;

		// Token: 0x040001E2 RID: 482
		private float mCustomZoomLevel;

		// Token: 0x040001E3 RID: 483
		private MainWindow mMainWindow;
	}
}
