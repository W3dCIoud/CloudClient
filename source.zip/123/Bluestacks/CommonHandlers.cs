﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Threading;
using System.Timers;
using System.Web;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Windows.Threading;
using BlueStacks.BlueStacksUI.BTv;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200015D RID: 349
	internal class CommonHandlers
	{
		// Token: 0x14000012 RID: 18
		// (add) Token: 0x06000D61 RID: 3425 RVA: 0x000575F0 File Offset: 0x000557F0
		// (remove) Token: 0x06000D62 RID: 3426 RVA: 0x00057628 File Offset: 0x00055828
		public event CommonHandlers.MacroBookmarkChanged MacroBookmarkChangedEvent;

		// Token: 0x14000013 RID: 19
		// (add) Token: 0x06000D63 RID: 3427 RVA: 0x00057660 File Offset: 0x00055860
		// (remove) Token: 0x06000D64 RID: 3428 RVA: 0x00057698 File Offset: 0x00055898
		public event CommonHandlers.MacroSettingsChanged MacroSettingChangedEvent;

		// Token: 0x14000014 RID: 20
		// (add) Token: 0x06000D65 RID: 3429 RVA: 0x000576D0 File Offset: 0x000558D0
		// (remove) Token: 0x06000D66 RID: 3430 RVA: 0x00057708 File Offset: 0x00055908
		public event CommonHandlers.ShortcutKeysChanged ShortcutKeysChangedEvent;

		// Token: 0x14000015 RID: 21
		// (add) Token: 0x06000D67 RID: 3431 RVA: 0x00057740 File Offset: 0x00055940
		// (remove) Token: 0x06000D68 RID: 3432 RVA: 0x00057778 File Offset: 0x00055978
		public event CommonHandlers.MacroDeleted MacroDeletedEvent;

		// Token: 0x14000016 RID: 22
		// (add) Token: 0x06000D69 RID: 3433 RVA: 0x000577B0 File Offset: 0x000559B0
		// (remove) Token: 0x06000D6A RID: 3434 RVA: 0x000577E8 File Offset: 0x000559E8
		public event CommonHandlers.OverlayStateChanged OverlayStateChangedEvent;

		// Token: 0x14000017 RID: 23
		// (add) Token: 0x06000D6B RID: 3435 RVA: 0x00057820 File Offset: 0x00055A20
		// (remove) Token: 0x06000D6C RID: 3436 RVA: 0x00057858 File Offset: 0x00055A58
		public event CommonHandlers.MacroButtonVisibilityChanged MacroButtonVisibilityChangedEvent;

		// Token: 0x14000018 RID: 24
		// (add) Token: 0x06000D6D RID: 3437 RVA: 0x00057890 File Offset: 0x00055A90
		// (remove) Token: 0x06000D6E RID: 3438 RVA: 0x000578C8 File Offset: 0x00055AC8
		public event CommonHandlers.OperationSyncButtonVisibilityChanged OperationSyncButtonVisibilityChangedEvent;

		// Token: 0x14000019 RID: 25
		// (add) Token: 0x06000D6F RID: 3439 RVA: 0x00057900 File Offset: 0x00055B00
		// (remove) Token: 0x06000D70 RID: 3440 RVA: 0x00057938 File Offset: 0x00055B38
		public event CommonHandlers.OBSResponseTimeout OBSResponseTimeoutEvent;

		// Token: 0x1400001A RID: 26
		// (add) Token: 0x06000D71 RID: 3441 RVA: 0x00057970 File Offset: 0x00055B70
		// (remove) Token: 0x06000D72 RID: 3442 RVA: 0x000579A8 File Offset: 0x00055BA8
		public event CommonHandlers.ScreenRecorderStateTransitioning ScreenRecorderStateTransitioningEvent;

		// Token: 0x1400001B RID: 27
		// (add) Token: 0x06000D73 RID: 3443 RVA: 0x000579E0 File Offset: 0x00055BE0
		// (remove) Token: 0x06000D74 RID: 3444 RVA: 0x00057A18 File Offset: 0x00055C18
		public event CommonHandlers.BTvDownloaderMinimized BTvDownloaderMinimizedEvent;

		// Token: 0x1400001C RID: 28
		// (add) Token: 0x06000D75 RID: 3445 RVA: 0x00057A50 File Offset: 0x00055C50
		// (remove) Token: 0x06000D76 RID: 3446 RVA: 0x00057A88 File Offset: 0x00055C88
		public event CommonHandlers.GamepadButtonVisibilityChanged GamepadButtonVisibilityChangedEvent;

		// Token: 0x1400001D RID: 29
		// (add) Token: 0x06000D77 RID: 3447 RVA: 0x00057AC0 File Offset: 0x00055CC0
		// (remove) Token: 0x06000D78 RID: 3448 RVA: 0x00057AF8 File Offset: 0x00055CF8
		public event CommonHandlers.ScreenRecordingStateChanged ScreenRecordingStateChangedEvent;

		// Token: 0x1400001E RID: 30
		// (add) Token: 0x06000D79 RID: 3449 RVA: 0x00057B30 File Offset: 0x00055D30
		// (remove) Token: 0x06000D7A RID: 3450 RVA: 0x00057B68 File Offset: 0x00055D68
		public event CommonHandlers.VolumeChanged VolumeChangedEvent;

		// Token: 0x1400001F RID: 31
		// (add) Token: 0x06000D7B RID: 3451 RVA: 0x00057BA0 File Offset: 0x00055DA0
		// (remove) Token: 0x06000D7C RID: 3452 RVA: 0x00057BD8 File Offset: 0x00055DD8
		public event CommonHandlers.VolumeMuted VolumeMutedEvent;

		// Token: 0x06000D7D RID: 3453 RVA: 0x0000A3D6 File Offset: 0x000085D6
		internal void OnVolumeMuted(bool muted)
		{
			CommonHandlers.VolumeMuted volumeMutedEvent = this.VolumeMutedEvent;
			if (volumeMutedEvent == null)
			{
				return;
			}
			volumeMutedEvent(muted);
		}

		// Token: 0x06000D7E RID: 3454 RVA: 0x0000A3E9 File Offset: 0x000085E9
		internal void OnVolumeChanged(int volumeLevel)
		{
			CommonHandlers.VolumeChanged volumeChangedEvent = this.VolumeChangedEvent;
			if (volumeChangedEvent == null)
			{
				return;
			}
			volumeChangedEvent(volumeLevel);
		}

		// Token: 0x06000D7F RID: 3455 RVA: 0x0000A3FC File Offset: 0x000085FC
		internal void OnScreenRecordingStateChanged(bool isRecording)
		{
			CommonHandlers.ScreenRecordingStateChanged screenRecordingStateChangedEvent = this.ScreenRecordingStateChangedEvent;
			if (screenRecordingStateChangedEvent == null)
			{
				return;
			}
			screenRecordingStateChangedEvent(isRecording);
		}

		// Token: 0x06000D80 RID: 3456 RVA: 0x0000A40F File Offset: 0x0000860F
		internal void OnGamepadButtonVisibilityChanged(bool visiblity)
		{
			CommonHandlers.GamepadButtonVisibilityChanged gamepadButtonVisibilityChangedEvent = this.GamepadButtonVisibilityChangedEvent;
			if (gamepadButtonVisibilityChangedEvent == null)
			{
				return;
			}
			gamepadButtonVisibilityChangedEvent(visiblity);
		}

		// Token: 0x06000D81 RID: 3457 RVA: 0x0000A422 File Offset: 0x00008622
		private void OnOBSResponseTimeout()
		{
			CommonHandlers.OBSResponseTimeout obsresponseTimeoutEvent = this.OBSResponseTimeoutEvent;
			if (obsresponseTimeoutEvent == null)
			{
				return;
			}
			obsresponseTimeoutEvent();
		}

		// Token: 0x06000D82 RID: 3458 RVA: 0x0000A434 File Offset: 0x00008634
		private void OnBTvDownloaderMinimized()
		{
			CommonHandlers.BTvDownloaderMinimized btvDownloaderMinimizedEvent = this.BTvDownloaderMinimizedEvent;
			if (btvDownloaderMinimizedEvent == null)
			{
				return;
			}
			btvDownloaderMinimizedEvent();
		}

		// Token: 0x06000D83 RID: 3459 RVA: 0x0000A446 File Offset: 0x00008646
		internal void OnScreenRecorderStateTransitioning()
		{
			CommonHandlers.ScreenRecorderStateTransitioning screenRecorderStateTransitioningEvent = this.ScreenRecorderStateTransitioningEvent;
			if (screenRecorderStateTransitioningEvent == null)
			{
				return;
			}
			screenRecorderStateTransitioningEvent();
		}

		// Token: 0x06000D84 RID: 3460 RVA: 0x0000A458 File Offset: 0x00008658
		internal void OnMacroButtonVisibilityChanged(bool isVisible)
		{
			CommonHandlers.MacroButtonVisibilityChanged macroButtonVisibilityChangedEvent = this.MacroButtonVisibilityChangedEvent;
			if (macroButtonVisibilityChangedEvent == null)
			{
				return;
			}
			macroButtonVisibilityChangedEvent(isVisible);
		}

		// Token: 0x06000D85 RID: 3461 RVA: 0x0000A46B File Offset: 0x0000866B
		internal void OnOperationSyncButtonVisibilityChanged(bool isVisible)
		{
			CommonHandlers.OperationSyncButtonVisibilityChanged operationSyncButtonVisibilityChangedEvent = this.OperationSyncButtonVisibilityChangedEvent;
			if (operationSyncButtonVisibilityChangedEvent == null)
			{
				return;
			}
			operationSyncButtonVisibilityChangedEvent(isVisible);
		}

		// Token: 0x06000D86 RID: 3462 RVA: 0x00057C10 File Offset: 0x00055E10
		internal void OnMacroBookmarkChanged(string fileName, bool wasBookmarked)
		{
			foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
			{
				CommonHandlers mCommonHandler = keyValuePair.Value.mCommonHandler;
				if (mCommonHandler != null)
				{
					CommonHandlers.MacroBookmarkChanged macroBookmarkChangedEvent = mCommonHandler.MacroBookmarkChangedEvent;
					if (macroBookmarkChangedEvent != null)
					{
						macroBookmarkChangedEvent(fileName, wasBookmarked);
					}
				}
			}
		}

		// Token: 0x06000D87 RID: 3463 RVA: 0x00057C80 File Offset: 0x00055E80
		internal void OnMacroSettingChanged(OperationsRecord record)
		{
			foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
			{
				CommonHandlers mCommonHandler = keyValuePair.Value.mCommonHandler;
				if (mCommonHandler != null)
				{
					CommonHandlers.MacroSettingsChanged macroSettingChangedEvent = mCommonHandler.MacroSettingChangedEvent;
					if (macroSettingChangedEvent != null)
					{
						macroSettingChangedEvent(record);
					}
				}
			}
		}

		// Token: 0x06000D88 RID: 3464 RVA: 0x00057CF0 File Offset: 0x00055EF0
		internal void OnMacroDeleted(string fileName)
		{
			foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
			{
				CommonHandlers mCommonHandler = keyValuePair.Value.mCommonHandler;
				if (mCommonHandler != null)
				{
					CommonHandlers.MacroDeleted macroDeletedEvent = mCommonHandler.MacroDeletedEvent;
					if (macroDeletedEvent != null)
					{
						macroDeletedEvent(fileName);
					}
				}
			}
		}

		// Token: 0x06000D89 RID: 3465 RVA: 0x0000A47E File Offset: 0x0000867E
		internal void OnShortcutKeysChanged(bool isEnabled)
		{
			CommonHandlers.ShortcutKeysChanged shortcutKeysChangedEvent = this.ShortcutKeysChangedEvent;
			if (shortcutKeysChangedEvent == null)
			{
				return;
			}
			shortcutKeysChangedEvent(isEnabled);
		}

		// Token: 0x06000D8A RID: 3466 RVA: 0x0000A491 File Offset: 0x00008691
		internal void OnOverlayStateChanged(bool isEnabled)
		{
			CommonHandlers.OverlayStateChanged overlayStateChangedEvent = this.OverlayStateChangedEvent;
			if (overlayStateChangedEvent == null)
			{
				return;
			}
			overlayStateChangedEvent(isEnabled);
		}

		// Token: 0x06000D8B RID: 3467 RVA: 0x0000A4A4 File Offset: 0x000086A4
		internal CommonHandlers(MainWindow window)
		{
			this.ParentWindow = window;
		}

		// Token: 0x06000D8C RID: 3468 RVA: 0x00057D60 File Offset: 0x00055F60
		public void LocationButtonHandler()
		{
			this.ParentWindow.mTopBar.mAppTabButtons.AddAppTab("STRING_MAP", "com.location.provider", "com.location.provider.MapsActivity", "ico_fakegps", true, true, "com.location.provider", false);
		}

		// Token: 0x06000D8D RID: 3469 RVA: 0x00057DA0 File Offset: 0x00055FA0
		public void ImageTranslationHandler()
		{
			Logger.Info("Saving screenshot automatically for image translater");
			if (ImageTranslateControl.Instance == null)
			{
				Bitmap bitmap = this.CaptureSreenShot();
				ImageTranslateControl imageTranslateControl = new ImageTranslateControl(this.ParentWindow);
				imageTranslateControl.GetTranslateImage(bitmap);
				imageTranslateControl.Visibility = Visibility.Visible;
				this.ParentWindow.ShowDimOverlay(imageTranslateControl);
			}
		}

		// Token: 0x06000D8E RID: 3470 RVA: 0x0000A4B3 File Offset: 0x000086B3
		internal static void ToggleFarmMode()
		{
			RegistryManager.Instance.CurrentFarmModeStatus = !RegistryManager.Instance.CurrentFarmModeStatus;
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
				{
					try
					{
						keyValuePair.Value.mFrontendHandler.SendFrontendRequestAsync("farmModeHandler", new Dictionary<string, string>
						{
							{
								"enable",
								RegistryManager.Instance.CurrentFarmModeStatus.ToString()
							}
						});
					}
					catch
					{
					}
				}
			});
		}

		// Token: 0x06000D8F RID: 3471 RVA: 0x00057DEC File Offset: 0x00055FEC
		internal void SearchAppCenter(string searchString)
		{
			AppTabButton tab = this.ParentWindow.mTopBar.mAppTabButtons.GetTab("appcenter");
			bool flag;
			if (tab == null)
			{
				flag = (null != null);
			}
			else
			{
				BrowserControl browserControl = tab.GetBrowserControl();
				flag = (((browserControl != null) ? browserControl.mBrowser : null) != null);
			}
			if (flag)
			{
				tab.GetBrowserControl().mBrowser.ExecuteJavaScript(string.Format("openSearch(\"{0}\")", HttpUtility.UrlEncode(searchString)), tab.GetBrowserControl().mBrowser.StartUrl, 0);
				this.ParentWindow.mTopBar.mAppTabButtons.GoToTab("appcenter", true, false);
				return;
			}
			this.ParentWindow.Utils.HandleApplicationBrowserClick(this.ParentWindow.Utils.GetAppCenterUrl(null) + "&query=" + HttpUtility.UrlEncode(searchString), LocaleStrings.GetLocalizedString("STRING_APP_CENTER", false), "appcenter", false, "");
		}

		// Token: 0x06000D90 RID: 3472 RVA: 0x0000A4F1 File Offset: 0x000086F1
		internal void OpenOperationRecorderWindow()
		{
			this.ParentWindow.OperationRecorderWindow.Show();
		}

		// Token: 0x06000D91 RID: 3473 RVA: 0x0000A503 File Offset: 0x00008703
		internal void HideOperationRecorderWindow()
		{
			this.ParentWindow.OperationRecorderWindow.Hide();
			this.ParentWindow.OperationRecorderWindow.ShowWithParentWindow = false;
		}

		// Token: 0x06000D92 RID: 3474 RVA: 0x0000A526 File Offset: 0x00008726
		internal void RefreshOperationRecorderWindow()
		{
			this.ParentWindow.OperationRecorderWindow.mScriptsStackPanel.Children.Clear();
			this.ParentWindow.OperationRecorderWindow.Init();
		}

		// Token: 0x06000D93 RID: 3475 RVA: 0x00057EC4 File Offset: 0x000560C4
		internal static void RefreshAllOperationRecorderWindow()
		{
			try
			{
				foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
				{
					if (keyValuePair.Value.OperationRecorderWindow != null)
					{
						keyValuePair.Value.OperationRecorderWindow.mScriptsStackPanel.Children.Clear();
						keyValuePair.Value.OperationRecorderWindow.Init();
					}
				}
			}
			catch (Exception arg)
			{
				Logger.Debug("Error in refreshing operation recorder window" + arg);
			}
		}

		// Token: 0x06000D94 RID: 3476 RVA: 0x00057F6C File Offset: 0x0005616C
		internal static void RefreshAllOperationRecorderWindowWithScroll()
		{
			try
			{
				foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
				{
					if (keyValuePair.Value.OperationRecorderWindow != null)
					{
						keyValuePair.Value.OperationRecorderWindow.mScriptsStackPanel.Children.Clear();
						keyValuePair.Value.OperationRecorderWindow.Init();
						keyValuePair.Value.OperationRecorderWindow.mScriptsListScrollbar.ScrollToEnd();
					}
				}
			}
			catch (Exception arg)
			{
				Logger.Debug("Error in refreshing operation recorder window" + arg);
			}
		}

		// Token: 0x06000D95 RID: 3477 RVA: 0x0000A552 File Offset: 0x00008752
		internal void ShowOperationRecorderWindow()
		{
			this.ParentWindow.OperationRecorderWindow.ShowWithParentWindow = true;
			this.ParentWindow.OperationRecorderWindow.Show();
		}

		// Token: 0x06000D96 RID: 3478 RVA: 0x00058028 File Offset: 0x00056228
		private Bitmap CaptureSreenShot()
		{
			System.Windows.Point point = this.ParentWindow.mContentGrid.PointToScreen(new System.Windows.Point(0.0, 0.0));
			System.Windows.Point point2 = new System.Windows.Point((double)Convert.ToInt32(point.X), (double)Convert.ToInt32(point.Y));
			System.Windows.Point point3 = this.ParentWindow.mContentGrid.PointToScreen(new System.Windows.Point((double)((int)this.ParentWindow.mContentGrid.ActualWidth), (double)((int)this.ParentWindow.mContentGrid.ActualHeight - 40)));
			System.Drawing.Size blockRegionSize = new System.Drawing.Size(Convert.ToInt32(point3.X - point2.X), Convert.ToInt32(point3.Y - point2.Y));
			Bitmap bitmap = new Bitmap(blockRegionSize.Width, blockRegionSize.Height);
			System.Drawing.Point upperLeftSource = new System.Drawing.Point((int)point2.X, (int)point2.Y);
			using (Graphics graphics = Graphics.FromImage(bitmap))
			{
				graphics.CopyFromScreen(upperLeftSource, System.Drawing.Point.Empty, blockRegionSize);
			}
			return bitmap;
		}

		// Token: 0x06000D97 RID: 3479 RVA: 0x00058150 File Offset: 0x00056350
		public void ScreenShotButtonHandler()
		{
			try
			{
				string str = DateTime.Now.ToString("yyyy.MM.dd_HH.mm.ss");
				string str2 = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.AppName;
				if (FeatureManager.Instance.IsCustomUIForNCSoft && !string.IsNullOrEmpty(this.ParentWindow.mNCTopBar.mAppName.Text))
				{
					str2 = this.ParentWindow.mNCTopBar.mAppName.Text;
				}
				string path = str2 + "_Screenshot_" + str + ".jpg";
				string filePath = Path.Combine(Path.GetTempPath(), path);
				this.ParentWindow.mFrontendHandler.GetScreenShot(filePath);
				try
				{
					if (FeatureManager.Instance.IsCustomUIForDMM)
					{
						new SoundPlayer(Path.Combine(Path.Combine(RegistryManager.Instance.ClientInstallDir, "Assets"), "camera_shutter_click.wav")).Play();
					}
				}
				catch
				{
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in screenshot button handler: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x06000D98 RID: 3480 RVA: 0x0005826C File Offset: 0x0005646C
		internal void PostScreenShotWork(string screenshotFileFullPath)
		{
			try
			{
				Logger.Debug("screen shot path..." + screenshotFileFullPath);
				if (RegistryManager.Instance.IsScreenshotsLocationPopupEnabled)
				{
					this.ShowScreenShotFolderUpdatePopup();
				}
				string text = RegistryManager.Instance.ScreenShotsPath;
				if (!StringExtensions.IsValidPath(text))
				{
					string screenshotDefaultPath = RegistryStrings.ScreenshotDefaultPath;
					if (!Directory.Exists(screenshotDefaultPath))
					{
						Directory.CreateDirectory(screenshotDefaultPath);
					}
					RegistryManager.Instance.ScreenShotsPath = screenshotDefaultPath;
					text = screenshotDefaultPath;
				}
				string fileName = Path.GetFileName(screenshotFileFullPath);
				string text2 = Path.Combine(text, fileName);
				Logger.Debug("Screen shot filename.." + text2);
				if (File.Exists(text2))
				{
					File.Delete(text2);
				}
				File.Move(screenshotFileFullPath, text2);
				ClientStats.SendMiscellaneousStatsAsync("MediaFileSaveSuccess", RegistryManager.Instance.UserGuid, "ScreenShot", RegistryManager.Instance.ScreenShotsPath, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
				if (RegistryManager.Instance.IsShowToastNotification)
				{
					this.ParentWindow.ShowGeneralToast(LocaleStrings.GetLocalizedString("STRING_SCREENSHOT_SAVED", false));
				}
				if (this.ParentWindow.EngineInstanceRegistry.IsSidebarVisible)
				{
					this.ParentWindow.mSidebar.ShowScreenshotSavedPopup(text2);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in post screenshot work: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x06000D99 RID: 3481 RVA: 0x000583C4 File Offset: 0x000565C4
		private void ShowScreenShotFolderUpdatePopup()
		{
			RegistryManager.Instance.IsScreenshotsLocationPopupEnabled = false;
			string screenShotsPath = RegistryManager.Instance.ScreenShotsPath;
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_OPEN_MEDIA_FOLDER", "");
			customMessageWindow.AddButton(ButtonColors.Blue, "STRING_CHOOSE_CUSTOM", new EventHandler(this.ChooseCustomFolder), null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_USE_CURRENT", null, null, false, null);
			BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_CHOOSE_FOLDER_TEXT", "");
			customMessageWindow.BodyWarningTextBlock.Visibility = Visibility.Visible;
			customMessageWindow.BodyWarningTextBlock.Text = screenShotsPath;
			BlueStacksUIBinding.BindColor(customMessageWindow.BodyWarningTextBlock, TextBlock.ForegroundProperty, "HyperLinkForegroundColor");
			this.ParentWindow.ShowDimOverlay(null);
			customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
			customMessageWindow.ShowDialog();
			this.ParentWindow.HideDimOverlay();
			ClientStats.SendMiscellaneousStatsAsync("MediaFilesPathSet", RegistryManager.Instance.UserGuid, "PathChangeFromPopUp", screenShotsPath, RegistryManager.Instance.ScreenShotsPath, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null);
		}

		// Token: 0x06000D9A RID: 3482 RVA: 0x000584E0 File Offset: 0x000566E0
		private void SaveScreenShotsInUserDefinedPath()
		{
			Random random = new Random();
			string text = Path.Combine(Path.GetTempPath(), string.Format("bst_screenshot_{0}.jpg", random.Next(1, 1000000)));
			this.ParentWindow.mFrontendHandler.GetScreenShot(text);
			SaveFileDialog saveFileDialog = new SaveFileDialog();
			saveFileDialog.Filter = "Jpeg Image (*.jpg)|*.jpg";
			saveFileDialog.FilterIndex = 1;
			saveFileDialog.RestoreDirectory = true;
			saveFileDialog.FileName = "BlueStacks_ScreenShot.jpg";
			if (saveFileDialog.ShowDialog() == DialogResult.OK)
			{
				string fullPath = Path.GetFullPath(saveFileDialog.FileName);
				string extension = Path.GetExtension(saveFileDialog.FileName);
				if (extension == ".jpg" || extension == ".jpeg")
				{
					if (File.Exists(fullPath))
					{
						File.Delete(fullPath);
					}
					File.Move(text, fullPath);
					return;
				}
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_INVALID_PATH", "");
				customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_INVALID_PATH", false);
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
			}
		}

		// Token: 0x06000D9B RID: 3483 RVA: 0x0000A575 File Offset: 0x00008775
		internal void AddCoordinatesToScriptText(double x, double y)
		{
			if (KMManager.sIsInScriptEditingMode && KMManager.CanvasWindow != null)
			{
				AdvancedGameControlWindow sidebarWindow = KMManager.CanvasWindow.SidebarWindow;
				if (sidebarWindow == null)
				{
					return;
				}
				sidebarWindow.InsertXYInScript(x, y);
			}
		}

		// Token: 0x06000D9C RID: 3484 RVA: 0x0005861C File Offset: 0x0005681C
		private void ChooseCustomFolder(object sender, EventArgs e)
		{
			string screenShotsPath = RegistryManager.Instance.ScreenShotsPath;
			if (!Directory.Exists(screenShotsPath))
			{
				Directory.CreateDirectory(screenShotsPath);
			}
			this.ShowFolderBrowserDialog(screenShotsPath);
		}

		// Token: 0x06000D9D RID: 3485 RVA: 0x0005864C File Offset: 0x0005684C
		internal void ShowFolderBrowserDialog(string screenshotPath)
		{
			FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
			folderBrowserDialog.SelectedPath = screenshotPath;
			folderBrowserDialog.ShowNewFolderButton = true;
			if (folderBrowserDialog.ShowDialog() != DialogResult.OK)
			{
				RegistryManager.Instance.ScreenShotsPath = screenshotPath;
				return;
			}
			string selectedPath = folderBrowserDialog.SelectedPath;
			Logger.Info("dialoge selected path.." + folderBrowserDialog.SelectedPath);
			bool flag = Utils.CheckWritePermissionForFolder(selectedPath);
			Logger.Info("Permission.." + flag.ToString() + "..path.." + selectedPath);
			if (!flag)
			{
				this.ShowInvalidPathPopUp();
				return;
			}
			RegistryManager.Instance.ScreenShotsPath = selectedPath;
		}

		// Token: 0x06000D9E RID: 3486 RVA: 0x000586D8 File Offset: 0x000568D8
		private void ShowInvalidPathPopUp()
		{
			string defaultPicturePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "Bluestacks");
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_OPEN_MEDIA_FOLDER", "");
			customMessageWindow.AddButton(ButtonColors.Blue, "STRING_CHOOSE_ANOTHER", new EventHandler(this.ChooseCustomFolder), null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_USE_DEFAULT", delegate(object o, EventArgs e)
			{
				RegistryManager.Instance.ScreenShotsPath = defaultPicturePath;
			}, null, false, null);
			customMessageWindow.BodyTextBlockTitle.Visibility = Visibility.Visible;
			customMessageWindow.BodyTextBlockTitle.Text = LocaleStrings.GetLocalizedString("STRING_SCREENSHOT_INVALID_PATH", false);
			BlueStacksUIBinding.BindColor(customMessageWindow.BodyTextBlockTitle, TextBlock.ForegroundProperty, "DeleteComboTextForeground");
			customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_SCREENSHOT_USE_DEFAULT", false);
			customMessageWindow.BodyWarningTextBlock.Visibility = Visibility.Visible;
			customMessageWindow.BodyWarningTextBlock.Text = defaultPicturePath;
			BlueStacksUIBinding.BindColor(customMessageWindow.BodyWarningTextBlock, TextBlock.ForegroundProperty, "HyperLinkForegroundColor");
			customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
			customMessageWindow.ShowDialog();
			customMessageWindow.Close();
		}

		// Token: 0x06000D9F RID: 3487 RVA: 0x0000A59B File Offset: 0x0000879B
		public void ShakeButtonHandler()
		{
			this.ParentWindow.Utils.ShakeWindow();
			this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("shake", null);
		}

		// Token: 0x06000DA0 RID: 3488 RVA: 0x000587F0 File Offset: 0x000569F0
		public void BackButtonHandler(bool receivedFromImap = false)
		{
			if (this.ParentWindow.mGuestBootCompleted)
			{
				new Thread(delegate()
				{
					VmCmdHandler.RunCommand("back", this.ParentWindow.mVmName);
				})
				{
					IsBackground = true
				}.Start();
				if (this.ParentWindow.SendClientActions && !receivedFromImap)
				{
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					Dictionary<string, string> dictionary2 = new Dictionary<string, string>();
					dictionary2.Add("EventAction", "BackButton");
					JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
					serializerSettings.Formatting = Formatting.None;
					dictionary.Add("operationData", JsonConvert.SerializeObject(dictionary2, serializerSettings));
					this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("handleClientOperation", dictionary);
				}
			}
		}

		// Token: 0x06000DA1 RID: 3489 RVA: 0x00058888 File Offset: 0x00056A88
		public void OpenBrowserInPopup(Dictionary<string, string> payload)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					string localizedString = LocaleStrings.GetLocalizedString(payload["click_action_title"], false);
					string url = payload["click_action_value"].Trim();
					string urlWithParams = WebHelper.GetUrlWithParams(url);
					ClientStats.SendPopupBrowserStatsInMiscASync("request", url);
					PopupBrowserControl popupBrowserControl = new PopupBrowserControl();
					popupBrowserControl.Init(urlWithParams, localizedString, this.ParentWindow);
					ClientStats.SendPopupBrowserStatsInMiscASync("impression", url);
					this.ParentWindow.ShowDimOverlay(popupBrowserControl);
				}
				catch (Exception ex)
				{
					Logger.Error("Couldn't open popup. An exception occured. {0}", new object[]
					{
						ex
					});
				}
			}), new object[0]);
		}

		// Token: 0x06000DA2 RID: 3490 RVA: 0x000588CC File Offset: 0x00056ACC
		public void HomeButtonHandler(bool isLaunch = true, bool receivedFromImap = false)
		{
			this.ParentWindow.mTopBar.mAppTabButtons.GoToTab("Home", isLaunch, false);
			if (this.ParentWindow.SendClientActions && !receivedFromImap)
			{
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				Dictionary<string, string> dictionary2 = new Dictionary<string, string>();
				dictionary2.Add("EventAction", "HomeButton");
				dictionary2.Add("IsLaunch", isLaunch.ToString());
				JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
				serializerSettings.Formatting = Formatting.None;
				dictionary.Add("operationData", JsonConvert.SerializeObject(dictionary2, serializerSettings));
				this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("handleClientOperation", dictionary);
			}
		}

		// Token: 0x06000DA3 RID: 3491 RVA: 0x0005896C File Offset: 0x00056B6C
		public void FullScreenButtonHandler(string source, string actionPerformed)
		{
			if (!this.ParentWindow.mResizeHandler.IsMinMaxEnabled)
			{
				return;
			}
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (FeatureManager.Instance.IsCustomUIForDMM || this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.mTabType == TabType.AppTab)
				{
					if (this.ParentWindow.mIsFullScreen)
					{
						this.ParentWindow.RestoreWindows();
						ClientStats.SendMiscellaneousStatsAsync(source, RegistryManager.Instance.UserGuid, "RestoreFullscreen", actionPerformed, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
						return;
					}
					this.ParentWindow.FullScreenWindow();
					ClientStats.SendMiscellaneousStatsAsync(source, RegistryManager.Instance.UserGuid, "Fullscreen", actionPerformed, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
				}
			}), new object[0]);
		}

		// Token: 0x06000DA4 RID: 3492 RVA: 0x000589CC File Offset: 0x00056BCC
		internal void AddToastPopup(Window window, string message, double duration = 1.3, bool isShowCloseImage = false)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					CustomToastPopupControl customToastPopupControl = new CustomToastPopupControl(window);
					if (isShowCloseImage)
					{
						customToastPopupControl.Init(window, message, System.Windows.Media.Brushes.Black, null, System.Windows.HorizontalAlignment.Center, VerticalAlignment.Top, null, 12, null, null, isShowCloseImage);
						customToastPopupControl.Margin = new Thickness(0.0, 40.0, 0.0, 0.0);
					}
					else
					{
						customToastPopupControl.Init(window, message, System.Windows.Media.Brushes.Black, null, System.Windows.HorizontalAlignment.Center, VerticalAlignment.Center, null, 12, null, null, false);
					}
					customToastPopupControl.ShowPopup(duration);
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in showing toast popup: " + ex.ToString());
				}
			}), new object[0]);
		}

		// Token: 0x06000DA5 RID: 3493 RVA: 0x00058A20 File Offset: 0x00056C20
		internal void HandleClientOperation(string operationString)
		{
			try
			{
				JObject jobject = JObject.Parse(operationString);
				string a = (string)jobject["EventAction"];
				if (!(a == "RunApp"))
				{
					if (!(a == "BackButton"))
					{
						if (!(a == "HomeButton"))
						{
							if (!(a == "TabSelected"))
							{
								if (a == "TabClosed")
								{
									string tabKey = jobject["tabKey"].ToObject<string>();
									bool sendStopAppToAndroid = jobject["sendStopAppToAndroid"].ToObject<bool>();
									bool forceClose = jobject["forceClose"].ToObject<bool>();
									if (!string.IsNullOrEmpty(tabKey))
									{
										this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
										{
											this.ParentWindow.mTopBar.mAppTabButtons.CloseTab(tabKey, sendStopAppToAndroid, forceClose, true, true, "");
										}), new object[0]);
									}
								}
							}
							else
							{
								string tabKey = jobject["tabKey"].ToObject<string>();
								if (!string.IsNullOrEmpty(tabKey))
								{
									this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
									{
										this.ParentWindow.mTopBar.mAppTabButtons.GoToTab(tabKey, true, true);
									}), new object[0]);
								}
							}
						}
						else
						{
							bool isLaunch = jobject["IsLaunch"].ToObject<bool>();
							this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
							{
								this.HomeButtonHandler(isLaunch, true);
							}), new object[0]);
						}
					}
					else
					{
						this.BackButtonHandler(true);
					}
				}
				else
				{
					this.ParentWindow.mAppHandler.SendRunAppRequestAsync((string)jobject["Package"], (string)jobject["Activity"], true);
				}
			}
			catch (Exception ex)
			{
				Logger.Error(string.Concat(new object[]
				{
					"Exception in HandleClientOperation. OperationString: ",
					operationString,
					" Error:",
					ex
				}));
			}
		}

		// Token: 0x06000DA6 RID: 3494 RVA: 0x0000A5C3 File Offset: 0x000087C3
		private bool CheckForMacroVisibility()
		{
			return !this.ParentWindow.mAppHandler.IsOneTimeSetupCompleted || this.ShowMacroForSelectedApp(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.TabKey);
		}

		// Token: 0x06000DA7 RID: 3495 RVA: 0x00058C4C File Offset: 0x00056E4C
		private bool ShowMacroForSelectedApp(string appPackage)
		{
			if (PromotionObject.Instance.AppSpecificRulesList != null)
			{
				foreach (string text in PromotionObject.Instance.AppSpecificRulesList)
				{
					string text2 = text;
					if (text.EndsWith("*"))
					{
						text2 = text.Substring(0, text.Length - 2);
					}
					if (text2.StartsWith("~"))
					{
						if (appPackage.StartsWith(text2.Substring(1)))
						{
							return false;
						}
					}
					else if (appPackage.StartsWith(text2))
					{
						return true;
					}
				}
				return false;
			}
			return false;
		}

		// Token: 0x06000DA8 RID: 3496 RVA: 0x00058CF8 File Offset: 0x00056EF8
		private bool IsCustomCursorEnableForApp(string appPackage)
		{
			bool result;
			try
			{
				if (!RegistryManager.Instance.CustomCursorEnabled || !FeatureManager.Instance.IsCustomCursorEnabled)
				{
					result = false;
				}
				else
				{
					string text = string.Empty;
					if (PromotionObject.Instance.CustomCursorExcludedAppsList != null)
					{
						foreach (string text2 in PromotionObject.Instance.CustomCursorExcludedAppsList)
						{
							text = text2;
							if (text2.EndsWith("*"))
							{
								text = text2.Substring(0, text2.Length - 1);
							}
							if (text.StartsWith("~"))
							{
								if (appPackage.StartsWith(text.Substring(1)))
								{
									return true;
								}
							}
							else if (appPackage.StartsWith(text))
							{
								return false;
							}
						}
					}
					result = true;
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000DA9 RID: 3497 RVA: 0x0000A5FE File Offset: 0x000087FE
		internal void SetCustomCursorForApp(string appPackage)
		{
			this.ToggleCursorStyle(this.IsCustomCursorEnableForApp(appPackage));
		}

		// Token: 0x06000DAA RID: 3498 RVA: 0x00058DDC File Offset: 0x00056FDC
		internal void ClipMouseCursorHandler(bool forceDisable = false, bool switchState = true, string statAction = "", string sourceLocation = "")
		{
			try
			{
				if (!FeatureManager.Instance.IsCustomUIForDMM)
				{
					if (forceDisable)
					{
						this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsCursorClipped = false;
					}
					else if (switchState)
					{
						this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsCursorClipped = !this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsCursorClipped;
					}
					if (!this.ParentWindow.mIsFullScreen && this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab != null && this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.mTabType == TabType.AppTab && this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsCursorClipped)
					{
						InteropWindow.RECT rect = default(InteropWindow.RECT);
						if (this.ParentWindow.StaticComponents.mLastMappableWindowHandle == IntPtr.Zero)
						{
							this.ParentWindow.StaticComponents.mLastMappableWindowHandle = this.ParentWindow.mFrontendHandler.mFrontendHandle;
						}
						InteropWindow.GetWindowRect(this.ParentWindow.StaticComponents.mLastMappableWindowHandle, ref rect);
						System.Drawing.Point location = new System.Drawing.Point(rect.left, rect.top);
						System.Drawing.Size size = new System.Drawing.Size(rect.right - rect.left, rect.bottom - rect.top);
						System.Windows.Forms.Cursor.Clip = new Rectangle(location, size);
						this.ParentWindow.OnCursorLockChanged(true);
						if (!string.IsNullOrEmpty(statAction))
						{
							ClientStats.SendMiscellaneousStatsAsync(sourceLocation, RegistryManager.Instance.UserGuid, "LockMouseCursor", statAction, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName, null);
							if (RegistryManager.Instance.IsShowToastNotification)
							{
								this.ParentWindow.ShowGeneralToast(string.Format(LocaleStrings.GetLocalizedString("STRING_UNLOCK_CURSOR", false), this.GetShortcutKeyFromName("STRING_TOGGLE_LOCK_CURSOR", false)));
							}
						}
					}
					else
					{
						System.Windows.Forms.Cursor.Clip = Rectangle.Empty;
						this.ParentWindow.OnCursorLockChanged(false);
						if (!string.IsNullOrEmpty(statAction))
						{
							ClientStats.SendMiscellaneousStatsAsync(sourceLocation, RegistryManager.Instance.UserGuid, "UnlockMouseCursor", statAction, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName, null);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ClipMouseCursorHandler. Exception: " + ex.ToString());
			}
		}

		// Token: 0x06000DAB RID: 3499 RVA: 0x00059098 File Offset: 0x00057298
		internal string GetShortcutKeyFromName(string shortcutName, bool isBossKey = false)
		{
			try
			{
				if (this.mShortcutsConfigInstance != null)
				{
					using (List<ShortcutKeys>.Enumerator enumerator = this.mShortcutsConfigInstance.Shortcut.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							ShortcutKeys shortcutKeys = enumerator.Current;
							if (shortcutKeys.ShortcutName.Equals(shortcutName))
							{
								if (isBossKey)
								{
									return shortcutKeys.ShortcutKey;
								}
								string[] array = shortcutKeys.ShortcutKey.Split(new char[]
								{
									'+',
									' '
								}, StringSplitOptions.RemoveEmptyEntries);
								string text = string.Empty;
								foreach (string key in array)
								{
									text = text + LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(key), false) + " + ";
								}
								if (!string.IsNullOrEmpty(text))
								{
									return text.Substring(0, text.Length - 3);
								}
							}
						}
						goto IL_12C;
					}
					goto IL_E3;
					IL_12C:
					goto IL_148;
				}
				IL_E3:
				if (shortcutName == "STRING_TOGGLE_LOCK_CURSOR")
				{
					return "Ctrl + Shift + F8";
				}
				if (shortcutName == "STRING_TOGGLE_KEYMAP_WINDOW")
				{
					return "Ctrl + Shift + H";
				}
				if (!(shortcutName == "STRING_TOGGLE_OVERLAY"))
				{
					return "";
				}
				return "Ctrl + Shift + F6";
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GetShortcutKeyFromName: " + ex.ToString());
			}
			IL_148:
			return "";
		}

		// Token: 0x06000DAC RID: 3500 RVA: 0x00059228 File Offset: 0x00057428
		internal void SerializeJsonOperationRecord(OperationsRecord record, string destFileName)
		{
			try
			{
				JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
				serializerSettings.Formatting = Formatting.Indented;
				string contents = JsonConvert.SerializeObject(record, serializerSettings);
				if (!Directory.Exists(RegistryStrings.OperationsScriptFolder))
				{
					Directory.CreateDirectory(RegistryStrings.OperationsScriptFolder);
				}
				File.WriteAllText(Path.Combine(RegistryStrings.OperationsScriptFolder, Path.GetFileName(destFileName.ToLower().Trim())), contents);
			}
			catch (Exception ex)
			{
				Logger.Error("Could not serialize the Operation Record Object." + ex.ToString());
			}
		}

		// Token: 0x06000DAD RID: 3501 RVA: 0x000592AC File Offset: 0x000574AC
		internal void ToggleMacroAndSyncVisibility()
		{
			try
			{
				if (FeatureManager.Instance.ForceEnableMacroAndSync)
				{
					this.OnMacroButtonVisibilityChanged(true);
					this.OnOperationSyncButtonVisibilityChanged(true);
				}
				else if (FeatureManager.Instance.IsMacroRecorderEnabled || FeatureManager.Instance.IsOperationsSyncEnabled)
				{
					bool isVisible = this.CheckForMacroVisibility();
					if (FeatureManager.Instance.IsMacroRecorderEnabled)
					{
						this.OnMacroButtonVisibilityChanged(isVisible);
					}
					if (FeatureManager.Instance.IsOperationsSyncEnabled)
					{
						this.OnOperationSyncButtonVisibilityChanged(isVisible);
					}
				}
				else
				{
					this.OnMacroButtonVisibilityChanged(false);
					this.OnOperationSyncButtonVisibilityChanged(false);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ToggleMacroAndSyncVisibility: " + ex.ToString());
			}
		}

		// Token: 0x06000DAE RID: 3502 RVA: 0x00059354 File Offset: 0x00057554
		private void ToggleCursorStyle(bool enable)
		{
			try
			{
				Dictionary<string, string> data = new Dictionary<string, string>();
				if (enable)
				{
					data.Add("path", RegistryStrings.CursorPath);
					data.Add("scalingFactor", MainWindow.sScalingFactor.ToString());
				}
				else
				{
					data.Add("path", string.Empty);
					data.Add("scalingFactor", MainWindow.sScalingFactor.ToString());
				}
				ThreadPool.QueueUserWorkItem(delegate(object obj1)
				{
					try
					{
						HTTPUtils.SendRequestToEngine("setCursorStyle", data, this.ParentWindow.mVmName, 3000, null, false, 1, 0, "");
						this.SetDefaultCursorForClient();
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to send Show event to engine... err : " + ex.ToString());
						this.SetDefaultCursorForClient();
					}
				});
			}
			catch (Exception)
			{
				this.SetDefaultCursorForClient();
			}
		}

		// Token: 0x06000DAF RID: 3503 RVA: 0x0000A60D File Offset: 0x0000880D
		private void SetDefaultCursorForClient()
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj1)
			{
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					try
					{
						Mouse.OverrideCursor = null;
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to set default cursor for client... err : " + ex.ToString());
					}
				}), new object[0]);
			});
		}

		// Token: 0x06000DB0 RID: 3504 RVA: 0x0005940C File Offset: 0x0005760C
		public void LaunchSettingsWindow()
		{
			SettingsWindow control = new SettingsWindow(this.ParentWindow, "");
			int num = 510;
			int num2 = 750;
			new ContainerWindow(this.ParentWindow, control, (double)num2, (double)num, false, true);
		}

		// Token: 0x06000DB1 RID: 3505 RVA: 0x0000A621 File Offset: 0x00008821
		public void DMMSwitchKeyMapButtonHandler()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (this.ParentWindow.mDmmBottomBar.mKeyMapSwitch.ImageName.EndsWith("_off"))
				{
					this.ParentWindow.mDmmBottomBar.mKeyMapSwitch.ImageName = this.ParentWindow.mDmmBottomBar.mKeyMapSwitch.ImageName.Replace("_off", string.Empty);
					BlueStacksUIBinding.Bind(this.ParentWindow.mDmmBottomBar.mKeyMapSwitch, "STRING_KEYMAPPING_ENABLED");
					BlueStacksUIBinding.Bind(this.ParentWindow.mDMMFST.mKeyMapSwitch, "STRING_KEYMAPPING_ENABLED");
					this.ParentWindow.mFrontendHandler.EnableKeyMapping(true);
					this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.EnableKeymapForDMM(true);
				}
				else
				{
					this.ParentWindow.mDmmBottomBar.mKeyMapSwitch.ImageName = this.ParentWindow.mDmmBottomBar.mKeyMapSwitch.ImageName + "_off";
					BlueStacksUIBinding.Bind(this.ParentWindow.mDmmBottomBar.mKeyMapSwitch, "STRING_KEYMAPPING_DISABLED");
					BlueStacksUIBinding.Bind(this.ParentWindow.mDMMFST.mKeyMapSwitch, "STRING_KEYMAPPING_DISABLED");
					this.ParentWindow.mFrontendHandler.EnableKeyMapping(false);
					this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.EnableKeymapForDMM(false);
				}
				this.ParentWindow.mDMMFST.mKeyMapSwitch.ImageName = this.ParentWindow.mDmmBottomBar.mKeyMapSwitch.ImageName;
			}), new object[0]);
		}

		// Token: 0x06000DB2 RID: 3506 RVA: 0x0005944C File Offset: 0x0005764C
		public void SetDMMKeymapButtonsAndTransparency()
		{
			if (this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsDMMKeymapUIVisible)
			{
				this.ParentWindow.mCommonHandler.EnableKeymapButtonsForDmm(Visibility.Visible);
				this.ParentWindow.mDmmBottomBar.ShowKeyMapPopup(true);
				KMManager.ShowOverlayWindow(this.ParentWindow, true, true);
				BlueStacksUIBinding.Bind(this.ParentWindow.mDmmBottomBar.mKeyMapSwitch, "STRING_KEYMAPPING_ENABLED");
				if (this.ParentWindow.mDmmBottomBar.CurrentTransparency > 0.0)
				{
					this.SetTranslucentControlsBtnImageForDMM("eye");
				}
				else
				{
					this.SetTranslucentControlsBtnImageForDMM("eye_off");
				}
			}
			else
			{
				this.ParentWindow.mCommonHandler.EnableKeymapButtonsForDmm(Visibility.Collapsed);
				this.ParentWindow.mDmmBottomBar.ShowKeyMapPopup(false);
				KMManager.ShowOverlayWindow(this.ParentWindow, false, false);
			}
			if (this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsDMMKeymapEnabled)
			{
				this.ParentWindow.mDmmBottomBar.mKeyMapSwitch.ImageName = "keymapswitch";
				this.ParentWindow.mDMMFST.mKeyMapSwitch.ImageName = "keymapswitch";
				this.ParentWindow.mFrontendHandler.EnableKeyMapping(true);
				return;
			}
			this.ParentWindow.mDmmBottomBar.mKeyMapSwitch.ImageName = "keymapswitch_off";
			this.ParentWindow.mDMMFST.mKeyMapSwitch.ImageName = "keymapswitch_off";
			this.ParentWindow.mFrontendHandler.EnableKeyMapping(false);
		}

		// Token: 0x06000DB3 RID: 3507 RVA: 0x000595CC File Offset: 0x000577CC
		public void EnableKeymapButtonsForDmm(Visibility isVisible)
		{
			this.ParentWindow.mDmmBottomBar.mKeyMapButton.Visibility = isVisible;
			this.ParentWindow.mDmmBottomBar.mKeyMapSwitch.Visibility = isVisible;
			this.ParentWindow.mDmmBottomBar.mTranslucentControlsButton.Visibility = isVisible;
			this.ParentWindow.mDMMFST.mKeyMapButton.Visibility = isVisible;
			this.ParentWindow.mDMMFST.mKeyMapSwitch.Visibility = isVisible;
			this.ParentWindow.mDMMFST.mTranslucentControlsButton.Visibility = isVisible;
		}

		// Token: 0x06000DB4 RID: 3508 RVA: 0x00059660 File Offset: 0x00057860
		internal void SetTranslucentControlsBtnImageForDMM(string imageName)
		{
			this.ParentWindow.mDmmBottomBar.mTranslucentControlsButton.ImageName = imageName;
			this.ParentWindow.mDmmBottomBar.mTranslucentControlsSliderButton.ImageName = this.ParentWindow.mDmmBottomBar.mTranslucentControlsButton.ImageName;
			this.ParentWindow.mDMMFST.mTranslucentControlsButton.ImageName = this.ParentWindow.mDmmBottomBar.mTranslucentControlsButton.ImageName;
			this.ParentWindow.mDMMFST.mTranslucentControlsSliderButton.ImageName = this.ParentWindow.mDmmBottomBar.mTranslucentControlsButton.ImageName;
		}

		// Token: 0x06000DB5 RID: 3509 RVA: 0x00059704 File Offset: 0x00057904
		internal void KeyMapButtonHandler(string action, string location)
		{
			KMManager.HandleInputMapperWindow(this.ParentWindow, true, "default");
			ClientStats.SendMiscellaneousStatsAsync(location, RegistryManager.Instance.UserGuid, "KeyMap", action, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06000DB6 RID: 3510 RVA: 0x00059758 File Offset: 0x00057958
		public void DMMScreenshotHandler()
		{
			FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog
			{
				ShowNewFolderButton = true,
				Description = LocaleStrings.GetLocalizedString("STRING_CHOOSE_SCREENSHOT_FOLDER_TEXT", false)
			};
			if (folderBrowserDialog.ShowDialog(Utils.GetIWin32Window(this.ParentWindow.Handle)) == DialogResult.OK && !string.IsNullOrEmpty(folderBrowserDialog.SelectedPath))
			{
				string screenShotsPath = Directory.Exists(folderBrowserDialog.SelectedPath) ? folderBrowserDialog.SelectedPath : RegistryStrings.ScreenshotDefaultPath;
				RegistryManager.Instance.ScreenShotsPath = screenShotsPath;
			}
		}

		// Token: 0x06000DB7 RID: 3511 RVA: 0x000597D0 File Offset: 0x000579D0
		public void RecordVideoOfApp()
		{
			Logger.Debug("OBS start or stop status: {0}", new object[]
			{
				CommonHandlers.sIsOBSStartingStopping
			});
			if (!CommonHandlers.sIsOBSStartingStopping)
			{
				CommonHandlers.sIsOBSStartingStopping = true;
				if (RegistryManager.Instance.IsScreenshotsLocationPopupEnabled)
				{
					this.ShowScreenShotFolderUpdatePopup();
				}
				string text = RegistryManager.Instance.ScreenShotsPath;
				if (!StringExtensions.IsValidPath(text))
				{
					if (!Directory.Exists(RegistryStrings.ScreenshotDefaultPath))
					{
						Directory.CreateDirectory(RegistryStrings.ScreenshotDefaultPath);
					}
					RegistryManager.Instance.ScreenShotsPath = RegistryStrings.ScreenshotDefaultPath;
					text = RegistryStrings.ScreenshotDefaultPath;
				}
				string arg = DateTime.Now.ToString("yyyy.MM.dd_HH.mm.ss.ff");
				string path = string.Format(Strings.ProductTopBarDisplayName + "_Recording_{0}.mp4", arg);
				string filePath = Path.Combine(text, path);
				if (text == RegistryStrings.ScreenshotDefaultPath && !Directory.Exists(RegistryStrings.ScreenshotDefaultPath))
				{
					Directory.CreateDirectory(RegistryStrings.ScreenshotDefaultPath);
				}
				ClientStats.SendMiscellaneousStatsAsync("VideoRecording", RegistryManager.Instance.UserGuid, "VideoRecordingStarting", RegistryManager.Instance.ScreenShotsPath, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
				Action <>9__1;
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					try
					{
						CommonHandlers.sRecordingInstance = this.ParentWindow.mVmName;
						if (StreamManager.Instance == null)
						{
							StreamManager.Instance = new StreamManager(this.ParentWindow);
						}
						string text2 = this.ParentWindow.mFrontendHandler.mFrontendHandle.ToString();
						Dispatcher dispatcher = this.ParentWindow.Dispatcher;
						Action method;
						if ((method = <>9__1) == null)
						{
							method = (<>9__1 = delegate()
							{
								this.ParentWindow.RestrictWindowResize(true);
								this.OnScreenRecorderStateTransitioning();
								this.StartLoadingTimeoutTimer();
							});
						}
						dispatcher.Invoke(method, new object[0]);
						Process currentProcess = Process.GetCurrentProcess();
						StreamManager.Instance.Init(text2, currentProcess.Id.ToString());
						StreamManager.sStopInitOBSQueue = false;
						try
						{
							StreamManager.Instance.StartObs();
						}
						catch (Exception ex)
						{
							Logger.Error("Exception in StartObs: {0}", new object[]
							{
								ex
							});
							this.ShowErrorRecordingVideoPopup();
							return;
						}
						StreamManager.Instance.SetMicVolume("0");
						StreamManager.Instance.SetHwnd(text2);
						StreamManager.Instance.SetSavePath(filePath);
						CommonHandlers.mSavedVideoRecordingFilePath = filePath;
						StreamManager.Instance.EnableVideoRecording(true);
						StreamManager.Instance.StartRecordForVideo();
						CommonHandlers.sIsRecordingVideo = true;
					}
					catch (Exception ex2)
					{
						Logger.Error("Error in RecordVideoOfApp: {0}", new object[]
						{
							ex2
						});
					}
				});
				return;
			}
		}

		// Token: 0x06000DB8 RID: 3512 RVA: 0x00059918 File Offset: 0x00057B18
		private void StartLoadingTimeoutTimer()
		{
			if (this.mObsResponseTimeoutTimer == null)
			{
				this.mObsResponseTimeoutTimer = new System.Timers.Timer(20000.0);
				this.mObsResponseTimeoutTimer.Elapsed += this.ObsResponseTimeoutTimer_Elapsed;
				this.mObsResponseTimeoutTimer.AutoReset = false;
			}
			if (!this.mObsResponseTimeoutTimer.Enabled)
			{
				this.mObsResponseTimeoutTimer.Start();
			}
		}

		// Token: 0x06000DB9 RID: 3513 RVA: 0x0005997C File Offset: 0x00057B7C
		private void ObsResponseTimeoutTimer_Elapsed(object sender, ElapsedEventArgs e)
		{
			this.OnOBSResponseTimeout();
			CommonHandlers.sIsRecordingVideo = false;
			CommonHandlers.sIsOBSStartingStopping = false;
			CommonHandlers.sRecordingInstance = "";
			this.ParentWindow.RestrictWindowResize(false);
			if (StreamManager.Instance != null)
			{
				StreamManager.Instance.ShutDownForcefully();
			}
			this.ShowErrorRecordingVideoPopup();
		}

		// Token: 0x06000DBA RID: 3514 RVA: 0x000599C8 File Offset: 0x00057BC8
		internal void StopRecordVideo()
		{
			try
			{
				this.OnScreenRecorderStateTransitioning();
				this.StartLoadingTimeoutTimer();
				StreamManager.Instance.StopRecord();
			}
			catch (Exception ex)
			{
				Logger.Error("error in stop record video : {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x06000DBB RID: 3515 RVA: 0x00059A14 File Offset: 0x00057C14
		internal void RecordingStopped()
		{
			System.Timers.Timer timer = this.mObsResponseTimeoutTimer;
			if (timer != null)
			{
				timer.Stop();
			}
			this.ParentWindow.RestrictWindowResize(false);
			this.OnScreenRecordingStateChanged(false);
			ClientStats.SendMiscellaneousStatsAsync("VideoRecording", RegistryManager.Instance.UserGuid, "VideoRecordingDone", RegistryManager.Instance.ScreenShotsPath, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06000DBC RID: 3516 RVA: 0x00059A88 File Offset: 0x00057C88
		internal void DownloadAndLaunchRecording(string location, string action)
		{
			Logger.Debug("value of sRecordingInstance: {0} and sIsRecordingVideo: {1}", new object[]
			{
				CommonHandlers.sRecordingInstance,
				CommonHandlers.sIsRecordingVideo
			});
			if (!CommonHandlers.sIsRecordingVideo)
			{
				if (Directory.Exists(RegistryStrings.ObsDir) && File.Exists(RegistryStrings.ObsBinaryPath))
				{
					if (!RegistryManager.Instance.IsBTVCheckedAfterUpdate && !this.IsBtvLatestVersionDownloaded())
					{
						this.DownloadObsPopup();
						ClientStats.SendMiscellaneousStatsAsync(location, RegistryManager.Instance.UserGuid, "VideoRecordingDownload", action, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
					}
					else
					{
						this.RecordVideoOfApp();
						ClientStats.SendMiscellaneousStatsAsync(location, RegistryManager.Instance.UserGuid, "VideoRecordingStart", action, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
					}
				}
				else
				{
					this.DownloadObsPopup();
					ClientStats.SendMiscellaneousStatsAsync(location, RegistryManager.Instance.UserGuid, "VideoRecordingDownload", action, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
				}
				RegistryManager.Instance.IsBTVCheckedAfterUpdate = true;
				return;
			}
			if (CommonHandlers.sRecordingInstance.Equals(this.ParentWindow.mVmName))
			{
				this.StopRecordVideo();
				ClientStats.SendMiscellaneousStatsAsync(location, RegistryManager.Instance.UserGuid, "VideoRecordingStop", action, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
				return;
			}
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
			BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_NOT_START_RECORDER", "");
			BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_RECORDER_ALREADY_RUNNING", "");
			customMessageWindow.Owner = this.ParentWindow;
			this.ParentWindow.ShowDimOverlay(null);
			customMessageWindow.ShowDialog();
			this.ParentWindow.HideDimOverlay();
		}

		// Token: 0x06000DBD RID: 3517 RVA: 0x00059C78 File Offset: 0x00057E78
		private bool IsBtvLatestVersionDownloaded()
		{
			string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(new Uri(this.GetBtvUrl()).LocalPath);
			return string.Compare(RegistryManager.Instance.CurrentBtvVersionInstalled, fileNameWithoutExtension) >= 0;
		}

		// Token: 0x06000DBE RID: 3518 RVA: 0x00059CB4 File Offset: 0x00057EB4
		private string GetBtvUrl()
		{
			string url = WebHelper.GetUrlWithParams(RegistryManager.Instance.Host + "/bs4/btv/GetBTVFile");
			if (!RegistryManager.Instance.BtvDevServer.Equals(""))
			{
				url = RegistryManager.Instance.BtvDevServer;
			}
			return BTVManager.GetRedirectedUrl(url);
		}

		// Token: 0x06000DBF RID: 3519 RVA: 0x00059D04 File Offset: 0x00057F04
		private void DownloadObsPopup()
		{
			if (CommonHandlers.sDownloading && CommonHandlers.sWindow != null && !CommonHandlers.sWindow.IsClosed)
			{
				this.DownloadObs(null, null);
				return;
			}
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_RECORDER_REQUIRED", false);
				customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_VIDEO_RECORDER_DOWNLOAD_BODY", false);
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_DOWNLOAD_NOW", new EventHandler(this.DownloadObs), null, false, null);
				customMessageWindow.Owner = this.ParentWindow;
				customMessageWindow.ContentMaxWidth = 450.0;
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
			}), new object[0]);
		}

		// Token: 0x06000DC0 RID: 3520 RVA: 0x00059D58 File Offset: 0x00057F58
		private void DownloadObs(object sender, EventArgs e)
		{
			if (CommonHandlers.sDownloading && CommonHandlers.sWindow != null && !CommonHandlers.sWindow.IsClosed)
			{
				BTVManager.BringToFront(CommonHandlers.sWindow);
				return;
			}
			if (!BTVManager.IsDirectXComponentsInstalled())
			{
				CustomMessageWindow downloadReqWindow = new CustomMessageWindow();
				downloadReqWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_ERROR", false);
				downloadReqWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_SOME_WINDOW_FILES_MISSING", false);
				string text = "http://www.microsoft.com/en-us/download/details.aspx?id=35";
				downloadReqWindow.AddHyperLinkInUI(text, new Uri(text), delegate(object o, RequestNavigateEventArgs arg)
				{
					BlueStacksUIUtils.OpenUrl(arg.Uri.ToString());
					downloadReqWindow.CloseWindow();
				});
				downloadReqWindow.Owner = this.ParentWindow;
				downloadReqWindow.ContentMaxWidth = 450.0;
				this.ParentWindow.ShowDimOverlay(null);
				downloadReqWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
				return;
			}
			CommonHandlers.sDownloading = true;
			CommonHandlers.sWindow = new CustomMessageWindow();
			BlueStacksUIBinding.Bind(CommonHandlers.sWindow.TitleTextBlock, "STRING_DOWNLOAD_ADDITIONAL", "");
			BlueStacksUIBinding.Bind(CommonHandlers.sWindow.BodyWarningTextBlock, "STRING_NOT_CLOSE_DOWNLOAD_COMPLETE", "");
			CommonHandlers.sWindow.BodyWarningTextBlock.Visibility = Visibility.Visible;
			CommonHandlers.sWindow.BodyTextBlock.Visibility = Visibility.Collapsed;
			CommonHandlers.sWindow.CloseButtonHandle(new Predicate<object>(this.RecorderDownloadCancelledHandler), null);
			CustomMessageWindow customMessageWindow = CommonHandlers.sWindow;
			customMessageWindow.MinimizeEventHandler = (EventHandler)Delegate.Combine(customMessageWindow.MinimizeEventHandler, new EventHandler(this.BtvDownloadWindowMinimizedHandler));
			CommonHandlers.sWindow.ProgressBarEnabled = true;
			CommonHandlers.sWindow.IsWindowMinizable = true;
			CommonHandlers.sWindow.IsWindowClosable = true;
			CommonHandlers.sWindow.ShowInTaskbar = false;
			CommonHandlers.sWindow.IsWithoutButtons = true;
			CommonHandlers.sWindow.ContentMaxWidth = 450.0;
			CommonHandlers.sWindow.IsDraggable = true;
			CommonHandlers.sWindow.Owner = this.ParentWindow;
			CommonHandlers.sWindow.Show();
			new Thread(delegate()
			{
				string btvUrl = this.GetBtvUrl();
				if (btvUrl == null)
				{
					Logger.Error("The download url was null");
					this.ShowErrorDownloadingRecorder();
					return;
				}
				string fileName = Path.GetFileName(new Uri(btvUrl).LocalPath);
				string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(new Uri(btvUrl).LocalPath);
				string downloadPath = Path.Combine(Path.GetTempPath(), fileName);
				this.mDownloader = new LegacyDownloader(3, btvUrl, downloadPath);
				this.mDownloader.Download(delegate(int percent)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						if (CommonHandlers.sWindow == null)
						{
							return;
						}
						CommonHandlers.sWindow.CustomProgressBar.Value = (double)percent;
					}), new object[0]);
				}, delegate(string filePath)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						if (CommonHandlers.sWindow == null)
						{
							return;
						}
						CommonHandlers.sWindow.CustomProgressBar.Value = 100.0;
					}), new object[0]);
					Logger.Info("Successfully downloaded BlueStacks TV");
					RegistryManager.Instance.CurrentBtvVersionInstalled = fileNameWithoutExtension;
					if (BTVManager.ExtractBTv(downloadPath))
					{
						Utils.DeleteFile(downloadPath);
						this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
						{
							CustomMessageWindow customMessageWindow2 = CommonHandlers.sWindow;
							if (customMessageWindow2 != null)
							{
								customMessageWindow2.Close();
							}
							CommonHandlers.sWindow = null;
							if (this.ParentWindow.mClosed)
							{
								return;
							}
							CustomMessageWindow customMessageWindow3 = new CustomMessageWindow();
							customMessageWindow3.AddButton(ButtonColors.Blue, "STRING_CLOSE", null, null, false, null);
							BlueStacksUIBinding.Bind(customMessageWindow3.TitleTextBlock, "STRING_RECORDER_DOWNLOADED", "");
							BlueStacksUIBinding.Bind(customMessageWindow3.BodyTextBlock, "STRING_RECORDER_READY_BODY", "");
							customMessageWindow3.Owner = this.ParentWindow;
							customMessageWindow3.ContentMaxWidth = 450.0;
							this.ParentWindow.ShowDimOverlay(null);
							customMessageWindow3.ShowDialog();
							this.ParentWindow.HideDimOverlay();
						}), new object[0]);
						return;
					}
					Utils.DeleteFile(downloadPath);
					this.ShowErrorDownloadingRecorder();
				}, delegate(Exception ex)
				{
					Logger.Error("Failed to download file: {0}. err: {1}", new object[]
					{
						downloadPath,
						ex.Message
					});
					if (ex.InnerException is OperationCanceledException)
					{
						return;
					}
					this.ShowErrorDownloadingRecorder();
				}, null, delegate(long size)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						if (CommonHandlers.sWindow == null)
						{
							return;
						}
						CommonHandlers.sWindow.ProgressStatusTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_DOWNLOADING", false);
						CommonHandlers.sWindow.ProgressPercentageTextBlock.Content = ((float)size / 1048576f).ToString("F") + " MB / " + this.mRecorderSizeMb.ToString("F") + " MB ";
						this.mDownloadedSize = size;
					}), new object[0]);
				}, delegate(LegacyDownloader.PayloadInfo info)
				{
					this.mRecorderSizeMb = (float)info.Size / 1048576f;
				});
				CommonHandlers.sDownloading = false;
			})
			{
				IsBackground = true
			}.Start();
			this.mDownloadStatusTimer = new DispatcherTimer
			{
				Interval = new TimeSpan(0, 0, 5)
			};
			this.mDownloadStatusTimer.Tick += this.DownloadStatusTimerTick;
			this.mDownloadStatusTimer.Start();
		}

		// Token: 0x06000DC1 RID: 3521 RVA: 0x0000A646 File Offset: 0x00008846
		private void BtvDownloadWindowMinimizedHandler(object sender, EventArgs e)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.OnBTvDownloaderMinimized();
				this.ParentWindow.Focus();
				this.ParentWindow.mFrontendHandler.ShowGLWindow();
			}), new object[0]);
		}

		// Token: 0x06000DC2 RID: 3522 RVA: 0x00059FB0 File Offset: 0x000581B0
		private void DownloadStatusTimerTick(object sender, EventArgs e)
		{
			if ((!CommonHandlers.sDownloading && CommonHandlers.sWindow != null) || CommonHandlers.sWindow == null)
			{
				this.mDownloadStatusTimer.Stop();
				return;
			}
			try
			{
				if (this.mLastSizeChecked != this.mDownloadedSize)
				{
					this.mLastSizeChecked = this.mDownloadedSize;
					CommonHandlers.sWindow.ProgressStatusTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_DOWNLOADING", false);
				}
				else
				{
					CommonHandlers.sWindow.ProgressStatusTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_WAITING_FOR_INTERNET", false);
				}
			}
			catch (Exception arg)
			{
				Logger.Error("Exception in DownloadStatusTimerTick. Exception: " + arg);
			}
		}

		// Token: 0x06000DC3 RID: 3523 RVA: 0x0000A66B File Offset: 0x0000886B
		private void ShowErrorDownloadingRecorder()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
				BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_DOWNLOAD_FAILED", "");
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_ERROR_RECORDER_DOWNLOAD", "");
				customMessageWindow.Owner = this.ParentWindow;
				customMessageWindow.ContentMaxWidth = 450.0;
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
				CustomMessageWindow customMessageWindow2 = CommonHandlers.sWindow;
				if (customMessageWindow2 != null)
				{
					customMessageWindow2.Close();
				}
				CommonHandlers.sWindow = null;
			}), new object[0]);
		}

		// Token: 0x06000DC4 RID: 3524 RVA: 0x0000A690 File Offset: 0x00008890
		internal void ShowErrorRecordingVideoPopup()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
				BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_RECORDING_ERROR", "");
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_RECORDING_ERROR_BODY", "");
				customMessageWindow.Owner = this.ParentWindow;
				customMessageWindow.ContentMaxWidth = 450.0;
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
			}), new object[0]);
		}

		// Token: 0x06000DC5 RID: 3525 RVA: 0x0005A054 File Offset: 0x00058254
		private bool RecorderDownloadCancelledHandler(object sender)
		{
			CustomMessageWindow cancelDownloadConfirmation = new CustomMessageWindow();
			cancelDownloadConfirmation.AddButton(ButtonColors.Red, "STRING_YES", delegate(object o, EventArgs args)
			{
				CustomMessageWindow customMessageWindow = CommonHandlers.sWindow;
				if (customMessageWindow != null)
				{
					customMessageWindow.Close();
				}
				CommonHandlers.sWindow = null;
				LegacyDownloader legacyDownloader = this.mDownloader;
				if (legacyDownloader == null)
				{
					return;
				}
				legacyDownloader.AbortDownload();
			}, null, false, null);
			cancelDownloadConfirmation.AddButton(ButtonColors.White, "STRING_NO", delegate(object o, EventArgs args)
			{
				cancelDownloadConfirmation.DialogResult = new bool?(true);
			}, null, false, null);
			BlueStacksUIBinding.Bind(cancelDownloadConfirmation.BodyTextBlock, "STRING_DOWNLOAD_NOT_COMPLETE", "");
			cancelDownloadConfirmation.Owner = this.ParentWindow;
			this.ParentWindow.ShowDimOverlay(null);
			bool? flag = cancelDownloadConfirmation.ShowDialog();
			this.ParentWindow.HideDimOverlay();
			bool? flag2 = flag;
			bool flag3 = true;
			return flag2.GetValueOrDefault() == flag3 & flag2 != null;
		}

		// Token: 0x06000DC6 RID: 3526 RVA: 0x0005A11C File Offset: 0x0005831C
		public void RecordingStarted()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				CommonHandlers.sIsOBSStartingStopping = false;
				System.Timers.Timer timer = this.mObsResponseTimeoutTimer;
				if (timer != null)
				{
					timer.Stop();
				}
				this.OnScreenRecordingStateChanged(true);
				this.ParentWindow.ShowGeneralToast(LocaleStrings.GetLocalizedString("STRING_RECORDING_STARTED", false));
			}), new object[0]);
			ClientStats.SendMiscellaneousStatsAsync("VideoRecording", RegistryManager.Instance.UserGuid, "VideoRecordingStarted", RegistryManager.Instance.ScreenShotsPath, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06000DC7 RID: 3527 RVA: 0x0005A190 File Offset: 0x00058390
		public void StopMacroRecording()
		{
			this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("stopRecordingCombo", null);
			foreach (object obj in this.ParentWindow.OperationRecorderWindow.mScriptsStackPanel.Children)
			{
				OperationRecorderScriptControl mScriptControl = (OperationRecorderScriptControl)obj;
				this.EnableScriptControl(mScriptControl);
			}
			this.ParentWindow.OperationRecorderWindow.mStartMacroRecordingBtn.Visibility = Visibility.Visible;
			this.ParentWindow.OperationRecorderWindow.mStopMacroRecordingBtn.Visibility = Visibility.Collapsed;
			this.ParentWindow.OperationRecorderWindow.mScriptsStackPanel.Visibility = Visibility.Visible;
			this.ParentWindow.mTopBar.mMacroRecorderToolTipPopup.IsOpen = false;
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.ParentWindow.mNCTopBar.mMacroRecordGrid.Visibility = Visibility.Collapsed;
				this.ParentWindow.mNCTopBar.mMacroRecordControl.StopTimer();
				return;
			}
			this.ParentWindow.mTopBar.mMacroRecordControl.Visibility = Visibility.Collapsed;
			this.ParentWindow.mTopBar.mMacroRecordControl.StopTimer();
		}

		// Token: 0x06000DC8 RID: 3528 RVA: 0x0005A2CC File Offset: 0x000584CC
		public void StartMacroRecording()
		{
			this.ParentWindow.mIsOperationRecorderActive = true;
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.ParentWindow.mNCTopBar.ShowRecordingIcons();
			}
			else
			{
				this.ParentWindow.mTopBar.ShowRecordingIcons();
			}
			this.ParentWindow.OperationRecorderWindow.mStartMacroRecordingBtn.Visibility = Visibility.Collapsed;
			this.ParentWindow.OperationRecorderWindow.mStopMacroRecordingBtn.Visibility = Visibility.Visible;
			foreach (object obj in this.ParentWindow.OperationRecorderWindow.mScriptsStackPanel.Children)
			{
				OperationRecorderScriptControl mScriptControl = (OperationRecorderScriptControl)obj;
				this.DisableScriptControl(mScriptControl);
			}
			this.ParentWindow.Focus();
			this.ParentWindow.mCommonHandler.HideOperationRecorderWindow();
			this.ParentWindow.mFrontendHandler.ShowGLWindow();
			this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("startRecordingCombo", null);
		}

		// Token: 0x06000DC9 RID: 3529 RVA: 0x0005A3DC File Offset: 0x000585DC
		internal void InitUiOnMacroPlayback(OperationsRecord operationRecord)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.ParentWindow.Focus();
				this.ParentWindow.mFrontendHandler.ShowGLWindow();
				this.ParentWindow.OperationRecorderWindow.mStartMacroRecordingBtn.IsEnabled = false;
				this.ParentWindow.OperationRecorderWindow.mStartMacroRecordingBtn.Opacity = 0.6;
				if (FeatureManager.Instance.IsCustomUIForNCSoft)
				{
					this.ParentWindow.mNCTopBar.ShowMacroPlaybackOnTopBar(operationRecord);
					this.ParentWindow.mNCTopBar.mMacroPlayControl.mStartTime = DateTime.Now;
				}
				else
				{
					this.ParentWindow.mTopBar.ShowMacroPlaybackOnTopBar(operationRecord);
					this.ParentWindow.mTopBar.mMacroPlayControl.mStartTime = DateTime.Now;
				}
				this.ParentWindow.mMacroPlaying = operationRecord.Name;
				if (operationRecord.RestartPlayer)
				{
					this.ParentWindow.StartTimerForAppPlayerRestart(operationRecord.RestartPlayerAfterMinutes);
				}
			}), new object[0]);
		}

		// Token: 0x06000DCA RID: 3530 RVA: 0x0005A420 File Offset: 0x00058620
		internal void PlayMacroScript(OperationsRecord record)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.ParentWindow.OperationRecorderWindow.mStartMacroRecordingBtn.Visibility = Visibility.Visible;
				this.ParentWindow.OperationRecorderWindow.mStartMacroRecordingBtn.IsEnabled = false;
				this.ParentWindow.OperationRecorderWindow.mStartMacroRecordingBtn.Opacity = 0.6;
				foreach (object obj in this.ParentWindow.OperationRecorderWindow.mScriptsStackPanel.Children)
				{
					OperationRecorderScriptControl operationRecorderScriptControl = (OperationRecorderScriptControl)obj;
					if (operationRecorderScriptControl.mOperationRecord.Name != record.Name)
					{
						this.DisableScriptControl(operationRecorderScriptControl);
					}
					else
					{
						operationRecorderScriptControl.mEditNameImg.IsEnabled = false;
					}
				}
				this.ParentWindow.OperationRecorderWindow.RunMacroOperation(record);
			}), new object[0]);
		}

		// Token: 0x06000DCB RID: 3531 RVA: 0x0005A464 File Offset: 0x00058664
		internal void FullMacroScriptPlayHandler(OperationsRecord record)
		{
			string name = record.Name;
			this.ParentWindow.mCommonHandler.PlayMacroScript(record);
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.ParentWindow.mNCTopBar.mMacroPlayControl.OnScriptPlayEvent(name);
				return;
			}
			this.ParentWindow.mTopBar.mMacroPlayControl.OnScriptPlayEvent(name);
		}

		// Token: 0x06000DCC RID: 3532 RVA: 0x0000A6B5 File Offset: 0x000088B5
		internal void StopMacroScriptHandling()
		{
			this.ParentWindow.OperationRecorderWindow.mBGMacroPlaybackWorker.CancelAsync();
			this.StopMacroPlaybackOperation();
			this.ParentWindow.SetMacroPlayBackEventHandle();
		}

		// Token: 0x06000DCD RID: 3533 RVA: 0x0005A4C4 File Offset: 0x000586C4
		internal void StopMacroPlaybackOperation()
		{
			Logger.Info("In StopMacroPlaybackOperation");
			this.ParentWindow.mIsMacroPlaying = false;
			foreach (object obj in this.ParentWindow.OperationRecorderWindow.mScriptsStackPanel.Children)
			{
				OperationRecorderScriptControl mScriptControl = (OperationRecorderScriptControl)obj;
				this.EnableScriptControl(mScriptControl);
			}
			this.ParentWindow.OperationRecorderWindow.mStartMacroRecordingBtn.Visibility = Visibility.Visible;
			this.ParentWindow.OperationRecorderWindow.mStartMacroRecordingBtn.IsEnabled = true;
			this.ParentWindow.OperationRecorderWindow.mStartMacroRecordingBtn.Opacity = 1.0;
			this.ParentWindow.OperationRecorderWindow.mScriptsStackPanel.Visibility = Visibility.Visible;
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.ParentWindow.mNCTopBar.HideMacroPlaybackFromTopBar();
			}
			else
			{
				this.ParentWindow.mTopBar.HideMacroPlaybackFromTopBar();
			}
			this.ParentWindow.mMacroPlaying = string.Empty;
			if (this.ParentWindow.mMacroTimer != null && this.ParentWindow.mMacroTimer.Enabled)
			{
				this.ParentWindow.mMacroTimer.Enabled = false;
				this.ParentWindow.mMacroTimer.AutoReset = false;
				this.ParentWindow.mMacroTimer.Dispose();
			}
			this.ParentWindow.mTopBar.mMacroRunningToolTipPopup.IsOpen = false;
			this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("stopMacroPlayback", null);
		}

		// Token: 0x06000DCE RID: 3534 RVA: 0x0005A660 File Offset: 0x00058860
		public void EnableScriptControl(OperationRecorderScriptControl mScriptControl)
		{
			mScriptControl.Opacity = 1.0;
			mScriptControl.mBookmarkImg.IsEnabled = true;
			mScriptControl.mEditNameImg.IsEnabled = true;
			mScriptControl.mPlayScriptImg.IsEnabled = true;
			mScriptControl.mScriptSettingsImg.IsEnabled = true;
			mScriptControl.mDeleteScriptImg.IsEnabled = true;
		}

		// Token: 0x06000DCF RID: 3535 RVA: 0x0005A6B8 File Offset: 0x000588B8
		public void DisableScriptControl(OperationRecorderScriptControl mScriptControl)
		{
			mScriptControl.Opacity = 0.4;
			mScriptControl.mBookmarkImg.IsEnabled = false;
			mScriptControl.mEditNameImg.IsEnabled = false;
			mScriptControl.mPlayScriptImg.IsEnabled = false;
			mScriptControl.mScriptSettingsImg.IsEnabled = false;
			mScriptControl.mDeleteScriptImg.IsEnabled = false;
		}

		// Token: 0x06000DD0 RID: 3536 RVA: 0x0005A710 File Offset: 0x00058910
		internal void CheckForMacroScriptOnRestart()
		{
			if (Directory.Exists(RegistryStrings.OperationsScriptFolder))
			{
				foreach (string text in Directory.GetFiles(RegistryStrings.OperationsScriptFolder))
				{
					try
					{
						OperationsRecord operationsRecord = JsonConvert.DeserializeObject<OperationsRecord>(File.ReadAllText(text), Utils.GetSerializerSettings());
						if (operationsRecord.PlayOnStart)
						{
							operationsRecord.Name = Path.GetFileNameWithoutExtension(text);
							this.InitUiAndPlayMacroScript(operationsRecord);
						}
					}
					catch (Exception ex)
					{
						Logger.Error("Exception in executing script {0}, err: {1}", new object[]
						{
							text,
							ex.ToString()
						});
					}
				}
			}
		}

		// Token: 0x06000DD1 RID: 3537 RVA: 0x0005A7A8 File Offset: 0x000589A8
		private void InitUiAndPlayMacroScript(OperationsRecord record)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.RefreshOperationRecorderWindow();
				this.ParentWindow.mTopBar.mMacroPlayControl.OnScriptPlayEvent(record.Name);
				this.PlayMacroScript(record);
			}), new object[0]);
		}

		// Token: 0x06000DD2 RID: 3538 RVA: 0x0000A6DD File Offset: 0x000088DD
		public static void OpenMediaFolder()
		{
			if (Directory.Exists(RegistryManager.Instance.ScreenShotsPath))
			{
				new Process
				{
					StartInfo = 
					{
						UseShellExecute = true,
						FileName = RegistryManager.Instance.ScreenShotsPath
					}
				}.Start();
			}
		}

		// Token: 0x06000DD3 RID: 3539 RVA: 0x0005A7EC File Offset: 0x000589EC
		public static void OpenMediaFolderWithFileSelected(string selectedFile)
		{
			if (Directory.Exists(RegistryManager.Instance.ScreenShotsPath))
			{
				new Process
				{
					StartInfo = 
					{
						UseShellExecute = true,
						FileName = "explorer.exe",
						Arguments = string.Format("/select,\"{0}\"", selectedFile)
					}
				}.Start();
			}
		}

		// Token: 0x06000DD4 RID: 3540 RVA: 0x0005A848 File Offset: 0x00058A48
		internal void SetSidebarImageProperties(bool isVisible, CustomPictureBox cpb, TextBlock tb)
		{
			if (isVisible)
			{
				if (cpb != null)
				{
					cpb.ImageName = "sidebar_hide";
					BlueStacksUIBinding.Bind(cpb, "STRING_CLOSE_SIDEBAR");
				}
				if (tb != null)
				{
					BlueStacksUIBinding.Bind(tb, "STRING_CLOSE_SIDEBAR", "");
					return;
				}
			}
			else
			{
				if (cpb != null)
				{
					cpb.ImageName = "sidebar_show";
					BlueStacksUIBinding.Bind(cpb, "STRING_OPEN_SIDEBAR");
				}
				if (tb != null)
				{
					BlueStacksUIBinding.Bind(tb, "STRING_OPEN_SIDEBAR", "");
				}
			}
		}

		// Token: 0x06000DD5 RID: 3541 RVA: 0x0005A8B4 File Offset: 0x00058AB4
		internal void FlipSidebarVisibility(CustomPictureBox cpb, TextBlock tb)
		{
			if (cpb.ImageName == "sidebar_hide")
			{
				this.ParentWindow.mSidebar.Visibility = Visibility.Collapsed;
				cpb.ImageName = "sidebar_show";
				BlueStacksUIBinding.Bind(cpb, "STRING_OPEN_SIDEBAR");
				if (tb != null)
				{
					BlueStacksUIBinding.Bind(tb, "STRING_OPEN_SIDEBAR", "");
				}
				this.ParentWindow.EngineInstanceRegistry.IsSidebarVisible = false;
				return;
			}
			this.ParentWindow.mSidebar.Visibility = Visibility.Visible;
			cpb.ImageName = "sidebar_hide";
			BlueStacksUIBinding.Bind(cpb, "STRING_CLOSE_SIDEBAR");
			if (tb != null)
			{
				BlueStacksUIBinding.Bind(tb, "STRING_CLOSE_SIDEBAR", "");
			}
			this.ParentWindow.EngineInstanceRegistry.IsSidebarVisible = true;
		}

		// Token: 0x06000DD6 RID: 3542 RVA: 0x0005A96C File Offset: 0x00058B6C
		internal void InitShortcuts()
		{
			this.mShortcutsConfigInstance = ShortcutConfig.LoadShortcutsConfig();
			if (this.mShortcutsConfigInstance == null)
			{
				return;
			}
			List<ShortcutKeys> list = new List<ShortcutKeys>();
			foreach (ShortcutKeys shortcutKeys in this.mShortcutsConfigInstance.Shortcut)
			{
				if (shortcutKeys.ShortcutName.Equals("STRING_MACRO_RECORDER"))
				{
					if (!FeatureManager.Instance.IsMacroRecorderEnabled && !FeatureManager.Instance.IsCustomUIForNCSoft)
					{
						list.Add(shortcutKeys);
					}
				}
				else if (shortcutKeys.ShortcutName.Equals("STRING_SYNCHRONISER"))
				{
					if (!FeatureManager.Instance.IsOperationsSyncEnabled)
					{
						list.Add(shortcutKeys);
					}
				}
				else if (shortcutKeys.ShortcutName.Equals("STRING_TOGGLE_FARM_MODE") && FeatureManager.Instance.IsFarmingModeDisabled)
				{
					list.Add(shortcutKeys);
				}
			}
			foreach (ShortcutKeys item in list)
			{
				this.mShortcutsConfigInstance.Shortcut.Remove(item);
			}
		}

		// Token: 0x06000DD7 RID: 3543 RVA: 0x0005AAA4 File Offset: 0x00058CA4
		internal void SaveAndReloadShortcuts()
		{
			try
			{
				this.mShortcutsConfigInstance.SaveUserDefinedShortcuts();
				this.ReloadShortcutsForAllInstances();
				Stats.SendMiscellaneousStatsAsync("KeyboardShortcuts", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "shortcut_save", null, null, null, null, null, "Android", 0);
			}
			catch (Exception ex)
			{
				Logger.Error("Error saving shortcut registry" + ex.ToString());
			}
		}

		// Token: 0x06000DD8 RID: 3544 RVA: 0x0005AB1C File Offset: 0x00058D1C
		internal void ReloadShortcutsForAllInstances()
		{
			foreach (string text in Utils.GetRunningInstancesList())
			{
				if (BlueStacksUIUtils.DictWindows.ContainsKey(text))
				{
					BlueStacksUIUtils.DictWindows[text].mCommonHandler.InitShortcuts();
					BlueStacksUIUtils.DictWindows[text].mCommonHandler.ReloadBossKey();
					BlueStacksUIUtils.DictWindows[text].mCommonHandler.ReloadTooltips();
				}
				HTTPUtils.SendRequestToEngineAsync("reloadShortcutsConfig", null, text, 0, null, false, 1, 0);
			}
		}

		// Token: 0x06000DD9 RID: 3545 RVA: 0x0005ABC4 File Offset: 0x00058DC4
		internal void ReloadTooltips()
		{
			foreach (SidebarElement sidebarElement in this.ParentWindow.mSidebar.mListSidebarElements)
			{
				this.ParentWindow.mSidebar.SetSidebarElementTooltip(sidebarElement, sidebarElement.mSidebarElementTooltipKey);
			}
		}

		// Token: 0x06000DDA RID: 3546 RVA: 0x0000A71C File Offset: 0x0000891C
		private void ReloadBossKey()
		{
			RegistryManager.Instance.BossKey = this.GetShortcutKeyFromName("STRING_BOSSKEY_SETTING", true);
			if (string.IsNullOrEmpty(RegistryManager.Instance.BossKey))
			{
				GlobalKeyBoardMouseHooks.UnsetKey();
				return;
			}
			GlobalKeyBoardMouseHooks.SetKey(RegistryManager.Instance.BossKey);
		}

		// Token: 0x06000DDB RID: 3547 RVA: 0x0005AC34 File Offset: 0x00058E34
		internal static void ArrangeWindowInTiles()
		{
			int tileWindowColumnCount = RegistryManager.Instance.TileWindowColumnCount;
			double y2 = (double)Screen.PrimaryScreen.WorkingArea.Top;
			double x2 = (double)Screen.PrimaryScreen.WorkingArea.Left;
			double num = (double)Screen.PrimaryScreen.WorkingArea.Width;
			double num2 = (double)Screen.PrimaryScreen.WorkingArea.Height;
			double windowWidth = (double)((int)(num / (double)tileWindowColumnCount));
			double windowHeight = (double)((int)(num2 / (double)tileWindowColumnCount));
			double y = y2;
			double x = x2;
			int num3 = 0;
			using (Dictionary<string, MainWindow>.Enumerator enumerator = BlueStacksUIUtils.DictWindows.GetEnumerator())
			{
				double portraitWidth;
				double portraitHeight;
				while (enumerator.MoveNext())
				{
					KeyValuePair<string, MainWindow> item = enumerator.Current;
					item.Value.Dispatcher.Invoke(new Action(delegate()
					{
						if (item.Value.WindowState == WindowState.Minimized)
						{
							item.Value.RestoreWindows();
						}
						if (new Fraction((long)item.Value.ActualWidth, (long)item.Value.ActualHeight) == new Fraction(16L, 9L))
						{
							windowHeight = item.Value.GetHeightFromWidth(windowWidth, true);
							item.Value.ChangeHeightWidthTopLeft(windowWidth, windowHeight, y, x);
							return;
						}
						portraitWidth = item.Value.Width * MainWindow.sScalingFactor;
						if (portraitWidth > windowWidth)
						{
							portraitWidth = windowWidth;
						}
						portraitHeight = item.Value.GetHeightFromWidth(portraitWidth, true);
						item.Value.ChangeHeightWidthTopLeft(portraitWidth, portraitHeight, y, x);
					}), new object[0]);
					x += windowWidth;
					num3++;
					if (num3 % tileWindowColumnCount == 0)
					{
						y += windowHeight;
						x = 0.0;
					}
				}
			}
		}

		// Token: 0x06000DDC RID: 3548 RVA: 0x0005ADC4 File Offset: 0x00058FC4
		internal static void ArrangeWindowInCascade()
		{
			double num = (double)Screen.PrimaryScreen.WorkingArea.Top;
			double num2 = (double)Screen.PrimaryScreen.WorkingArea.Bottom;
			double num3 = (double)Screen.PrimaryScreen.WorkingArea.Left;
			double num4 = (double)Screen.PrimaryScreen.WorkingArea.Right;
			double num5 = (double)Screen.PrimaryScreen.WorkingArea.Width;
			double num6 = (double)Screen.PrimaryScreen.WorkingArea.Height;
			double windowWidth = (double)((int)(num5 / 3.0));
			double windowHeight = (double)((int)(num6 / 3.0));
			double y = num;
			double x = num3;
			using (Dictionary<string, MainWindow>.Enumerator enumerator = BlueStacksUIUtils.DictWindows.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					KeyValuePair<string, MainWindow> item = enumerator.Current;
					IntPtr handle = item.Value.Handle;
					item.Value.Dispatcher.Invoke(new Action(delegate()
					{
						if (item.Value.WindowState == WindowState.Minimized)
						{
							item.Value.RestoreWindows();
						}
						windowHeight = item.Value.GetHeightFromWidth(windowWidth, false);
						item.Value.ChangeHeightWidthTopLeft(windowWidth, windowHeight, y, x);
						item.Value.Focus();
					}), new object[0]);
					x += 40.0;
					y += 40.0;
					if (y >= num2 || x >= num4)
					{
						y = num + 40.0;
						x = num3 + 40.0;
					}
				}
			}
		}

		// Token: 0x06000DDD RID: 3549 RVA: 0x0005AFB8 File Offset: 0x000591B8
		public void SetNcSoftStreamingStatus(string status)
		{
			if (status.Equals("on", StringComparison.InvariantCultureIgnoreCase))
			{
				SidebarElement elementFromTag = this.ParentWindow.mSidebar.GetElementFromTag("sidebar_stream_video");
				this.ParentWindow.mSidebar.UpdateImage("sidebar_stream_video", "sidebar_stream_video_active");
				elementFromTag.Image.Width = 44.0;
				elementFromTag.Image.Height = 44.0;
				this.ParentWindow.mNCTopBar.ChangeTopBarColor("StreamingTopBarColor");
				this.ParentWindow.mNCTopBar.mStreamingTopbarGrid.Visibility = Visibility.Visible;
				this.ParentWindow.mIsStreaming = true;
				return;
			}
			SidebarElement elementFromTag2 = this.ParentWindow.mSidebar.GetElementFromTag("sidebar_stream_video");
			this.ParentWindow.mSidebar.UpdateImage("sidebar_stream_video", "sidebar_stream_video");
			elementFromTag2.Image.Width = 24.0;
			elementFromTag2.Image.Height = 24.0;
			this.ParentWindow.mNCTopBar.ChangeTopBarColor("TopBarColor");
			this.ParentWindow.mNCTopBar.mStreamingTopbarGrid.Visibility = Visibility.Collapsed;
			this.ParentWindow.mIsStreaming = false;
		}

		// Token: 0x06000DDE RID: 3550 RVA: 0x0000A75A File Offset: 0x0000895A
		internal void ArrangeWindow()
		{
			if (RegistryManager.Instance.ArrangeWindowMode == 0)
			{
				CommonHandlers.ArrangeWindowInTiles();
				return;
			}
			CommonHandlers.ArrangeWindowInCascade();
		}

		// Token: 0x06000DDF RID: 3551 RVA: 0x0000A773 File Offset: 0x00008973
		internal void MuteUnmuteButtonHanlder()
		{
			if (this.ParentWindow.EngineInstanceRegistry.IsMuted)
			{
				this.ParentWindow.Utils.UnmuteApplication(false);
				return;
			}
			this.ParentWindow.Utils.MuteApplication(false);
		}

		// Token: 0x06000DE0 RID: 3552 RVA: 0x0005B0F4 File Offset: 0x000592F4
		internal string GetMacroName(string baseSchemeName = "Script")
		{
			int length = baseSchemeName.Length;
			int num = 1;
			if (Directory.Exists(RegistryStrings.OperationsScriptFolder))
			{
				HashSet<string> hashSet = new HashSet<string>(from _ in Directory.GetFiles(RegistryStrings.OperationsScriptFolder)
				select Path.GetFileNameWithoutExtension(_).ToLower());
				while (hashSet.Contains(string.Format("{0} ({1})", baseSchemeName.ToLower(), num).Trim()))
				{
					num++;
				}
			}
			return string.Format("{0} ({1})", baseSchemeName, num);
		}

		// Token: 0x06000DE1 RID: 3553 RVA: 0x0000A7AA File Offset: 0x000089AA
		internal void MouseMoveOverFrontend()
		{
			if (KMManager.sIsInScriptEditingMode && !this.ParentWindow.mIsWindowInFocus)
			{
				Logger.Info("Script focused");
				this.ParentWindow.mFrontendHandler.FocusFrontend(false);
			}
		}

		// Token: 0x06000DE2 RID: 3554 RVA: 0x0005B184 File Offset: 0x00059384
		internal void ReloadMacroShortcutsForAllInstances()
		{
			foreach (string text in Utils.GetRunningInstancesList())
			{
				if (BlueStacksUIUtils.DictWindows.ContainsKey(text))
				{
					HTTPUtils.SendRequestToEngineAsync("updateMacroShortcutsDict", MainWindow.sMacroMapping, text, 0, null, false, 1, 0);
				}
			}
		}

		// Token: 0x0400099C RID: 2460
		private MainWindow ParentWindow;

		// Token: 0x0400099D RID: 2461
		internal static bool sIsRecordingVideo = false;

		// Token: 0x0400099E RID: 2462
		internal static string sRecordingInstance = "";

		// Token: 0x0400099F RID: 2463
		private static bool sIsOBSStartingStopping = false;

		// Token: 0x040009A0 RID: 2464
		private static bool sDownloading;

		// Token: 0x040009A1 RID: 2465
		private LegacyDownloader mDownloader;

		// Token: 0x040009A2 RID: 2466
		private static CustomMessageWindow sWindow;

		// Token: 0x040009A3 RID: 2467
		internal ShortcutConfig mShortcutsConfigInstance;

		// Token: 0x040009A4 RID: 2468
		internal static string mSavedVideoRecordingFilePath = null;

		// Token: 0x040009B3 RID: 2483
		private System.Timers.Timer mObsResponseTimeoutTimer;

		// Token: 0x040009B4 RID: 2484
		private long mDownloadedSize;

		// Token: 0x040009B5 RID: 2485
		private long mLastSizeChecked;

		// Token: 0x040009B6 RID: 2486
		private DispatcherTimer mDownloadStatusTimer;

		// Token: 0x040009B7 RID: 2487
		private float mRecorderSizeMb;

		// Token: 0x0200015E RID: 350
		// (Invoke) Token: 0x06000DF2 RID: 3570
		public delegate void MacroBookmarkChanged(string fileName, bool wasBookmarked);

		// Token: 0x0200015F RID: 351
		// (Invoke) Token: 0x06000DF6 RID: 3574
		public delegate void MacroSettingsChanged(OperationsRecord record);

		// Token: 0x02000160 RID: 352
		// (Invoke) Token: 0x06000DFA RID: 3578
		public delegate void ShortcutKeysChanged(bool isEnabled);

		// Token: 0x02000161 RID: 353
		// (Invoke) Token: 0x06000DFE RID: 3582
		public delegate void MacroDeleted(string fileName);

		// Token: 0x02000162 RID: 354
		// (Invoke) Token: 0x06000E02 RID: 3586
		public delegate void OverlayStateChanged(bool isEnabled);

		// Token: 0x02000163 RID: 355
		// (Invoke) Token: 0x06000E06 RID: 3590
		public delegate void MacroButtonVisibilityChanged(bool isVisible);

		// Token: 0x02000164 RID: 356
		// (Invoke) Token: 0x06000E0A RID: 3594
		public delegate void OperationSyncButtonVisibilityChanged(bool isVisible);

		// Token: 0x02000165 RID: 357
		// (Invoke) Token: 0x06000E0E RID: 3598
		public delegate void OBSResponseTimeout();

		// Token: 0x02000166 RID: 358
		// (Invoke) Token: 0x06000E12 RID: 3602
		public delegate void ScreenRecorderStateTransitioning();

		// Token: 0x02000167 RID: 359
		// (Invoke) Token: 0x06000E16 RID: 3606
		public delegate void BTvDownloaderMinimized();

		// Token: 0x02000168 RID: 360
		// (Invoke) Token: 0x06000E1A RID: 3610
		public delegate void GamepadButtonVisibilityChanged(bool visibility);

		// Token: 0x02000169 RID: 361
		// (Invoke) Token: 0x06000E1E RID: 3614
		public delegate void ScreenRecordingStateChanged(bool isRecording);

		// Token: 0x0200016A RID: 362
		// (Invoke) Token: 0x06000E22 RID: 3618
		public delegate void VolumeChanged(int volumeLevel);

		// Token: 0x0200016B RID: 363
		// (Invoke) Token: 0x06000E26 RID: 3622
		public delegate void VolumeMuted(bool muted);
	}
}
