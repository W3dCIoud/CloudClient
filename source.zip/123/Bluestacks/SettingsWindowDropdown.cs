﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200006D RID: 109
	public class SettingsWindowDropdown : UserControl, IComponentConnector
	{
		// Token: 0x060004B3 RID: 1203 RVA: 0x000051A4 File Offset: 0x000033A4
		public SettingsWindowDropdown()
		{
			this.InitializeComponent();
		}

		// Token: 0x060004B4 RID: 1204 RVA: 0x000051B2 File Offset: 0x000033B2
		internal void Init(MainWindow window)
		{
			this.ParentWindow = window;
		}

		// Token: 0x060004B5 RID: 1205 RVA: 0x0001F50C File Offset: 0x0001D70C
		private void Grid_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
			foreach (object obj in (sender as Grid).Children)
			{
				UIElement uielement = (UIElement)obj;
				if (uielement is CustomPictureBox)
				{
					(uielement as CustomPictureBox).ImageName = (uielement as CustomPictureBox).ImageName + "_hover";
				}
				if (uielement is TextBlock)
				{
					BlueStacksUIBinding.BindColor(uielement as TextBlock, Control.ForegroundProperty, "SettingsWindowTabMenuItemSelectedForeground");
				}
			}
		}

		// Token: 0x060004B6 RID: 1206 RVA: 0x0001F5C0 File Offset: 0x0001D7C0
		private void Grid_MouseLeave(object sender, MouseEventArgs e)
		{
			(sender as Grid).Background = Brushes.Transparent;
			foreach (object obj in (sender as Grid).Children)
			{
				UIElement uielement = (UIElement)obj;
				if (uielement is CustomPictureBox)
				{
					(uielement as CustomPictureBox).ImageName = (uielement as CustomPictureBox).ImageName.Replace("_hover", "");
				}
				if (uielement is TextBlock)
				{
					BlueStacksUIBinding.BindColor(uielement as TextBlock, Control.ForegroundProperty, "SettingsWindowTabMenuItemForeground");
				}
			}
		}

		// Token: 0x060004B7 RID: 1207 RVA: 0x000051BB File Offset: 0x000033BB
		private void SettingsButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mNCTopBar.mSettingsDropdownPopup.IsOpen = false;
			this.ParentWindow.mCommonHandler.LaunchSettingsWindow();
		}

		// Token: 0x060004B8 RID: 1208 RVA: 0x0001F674 File Offset: 0x0001D874
		private void FullscreenButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mNCTopBar.mSettingsDropdownPopup.IsOpen = false;
			if (!this.ParentWindow.mResizeHandler.IsMinMaxEnabled)
			{
				return;
			}
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (FeatureManager.Instance.IsCustomUIForDMM || this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.mTabType == TabType.AppTab)
				{
					if (this.ParentWindow.mIsFullScreen)
					{
						this.ParentWindow.RestoreWindows();
						return;
					}
					this.ParentWindow.FullScreenWindow();
				}
			}), new object[0]);
		}

		// Token: 0x060004B9 RID: 1209 RVA: 0x000051E3 File Offset: 0x000033E3
		private void SortingButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mNCTopBar.mSettingsDropdownPopup.IsOpen = false;
			this.ParentWindow.mCommonHandler.ArrangeWindow();
		}

		// Token: 0x060004BA RID: 1210 RVA: 0x0001F6D0 File Offset: 0x0001D8D0
		private void AccountButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mNCTopBar.mSettingsDropdownPopup.IsOpen = false;
			if (this.ParentWindow.mGuestBootCompleted)
			{
				this.ParentWindow.mTopBar.mAppTabButtons.AddAppTab("STRING_ACCOUNT", BlueStacksUIUtils.sAndroidSettingsPackageName, BlueStacksUIUtils.sAndroidAccountSettingsActivityName, "account_tab", true, true, "account_tab", false);
			}
		}

		// Token: 0x060004BB RID: 1211 RVA: 0x0001F734 File Offset: 0x0001D934
		private void PinOnTop_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			CustomPictureBox customPictureBox = sender as CustomPictureBox;
			if (customPictureBox.ImageName.Contains("_off"))
			{
				customPictureBox.ImageName = "toggle_on";
				this.ParentWindow.EngineInstanceRegistry.IsClientOnTop = true;
				this.ParentWindow.Topmost = true;
				return;
			}
			customPictureBox.ImageName = "toggle_off";
			this.ParentWindow.EngineInstanceRegistry.IsClientOnTop = false;
			this.ParentWindow.Topmost = false;
		}

		// Token: 0x060004BC RID: 1212 RVA: 0x0001F7AC File Offset: 0x0001D9AC
		internal void LateInit()
		{
			if (BlueStacksUIUtils.DictWindows.Keys.Count == 1)
			{
				this.mSyncOperationsButtonGrid.PreviewMouseLeftButtonUp -= this.SyncOperationsButton_PreviewMouseLeftButtonUp;
				this.mSyncOperationsButtonGrid.MouseEnter -= this.Grid_MouseEnter;
				this.mSyncOperationsButtonGrid.Opacity = 0.5;
				this.mSortingGrid.PreviewMouseLeftButtonUp -= this.SortingButton_MouseLeftButtonUp;
				this.mSortingGrid.MouseEnter -= this.Grid_MouseEnter;
				this.mSortingGrid.Opacity = 0.5;
			}
			else
			{
				this.mSortingGrid.PreviewMouseLeftButtonUp -= this.SortingButton_MouseLeftButtonUp;
				this.mSortingGrid.PreviewMouseLeftButtonUp += this.SortingButton_MouseLeftButtonUp;
				this.mSortingGrid.MouseEnter -= this.Grid_MouseEnter;
				this.mSortingGrid.MouseEnter += this.Grid_MouseEnter;
				this.mSortingGrid.Opacity = 1.0;
				if ((BlueStacksUIUtils.sSyncInvolvedInstances.Contains(this.ParentWindow.mVmName) && this.ParentWindow.mIsSyncMaster) || (!BlueStacksUIUtils.sSyncInvolvedInstances.Contains(this.ParentWindow.mVmName) && BlueStacksUIUtils.DictWindows.Keys.Count - BlueStacksUIUtils.sSyncInvolvedInstances.Count > 1))
				{
					this.mSyncOperationsButtonGrid.PreviewMouseLeftButtonUp -= this.SyncOperationsButton_PreviewMouseLeftButtonUp;
					this.mSyncOperationsButtonGrid.PreviewMouseLeftButtonUp += this.SyncOperationsButton_PreviewMouseLeftButtonUp;
					this.mSyncOperationsButtonGrid.MouseEnter -= this.Grid_MouseEnter;
					this.mSyncOperationsButtonGrid.MouseEnter += this.Grid_MouseEnter;
					this.mSyncOperationsButtonGrid.Opacity = 1.0;
				}
				else
				{
					this.mSyncOperationsButtonGrid.PreviewMouseLeftButtonUp -= this.SyncOperationsButton_PreviewMouseLeftButtonUp;
					this.mSyncOperationsButtonGrid.MouseEnter -= this.Grid_MouseEnter;
					this.mSyncOperationsButtonGrid.Opacity = 0.5;
				}
			}
			if (this.ParentWindow.EngineInstanceRegistry.IsClientOnTop)
			{
				this.mPinOnTopToggleButton.ImageName = "toggle_on";
				return;
			}
			this.mPinOnTopToggleButton.ImageName = "toggle_off";
		}

		// Token: 0x060004BD RID: 1213 RVA: 0x0000520B File Offset: 0x0000340B
		private void SyncOperationsButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mNCTopBar.mSettingsDropdownPopup.IsOpen = false;
			this.ParentWindow.ShowSynchronizerWindow();
		}

		// Token: 0x060004BE RID: 1214 RVA: 0x0001FA0C File Offset: 0x0001DC0C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/ncsettingsdropdown.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060004BF RID: 1215 RVA: 0x0001FA3C File Offset: 0x0001DC3C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mPinOnTopButtonGrid = (Grid)target;
				this.mPinOnTopButtonGrid.MouseEnter += this.Grid_MouseEnter;
				this.mPinOnTopButtonGrid.MouseLeave += this.Grid_MouseLeave;
				return;
			case 2:
				this.mPinOnTopButtonImage = (CustomPictureBox)target;
				return;
			case 3:
				this.mPinOnTopButtonText = (TextBlock)target;
				return;
			case 4:
				this.mPinOnTopToggleButton = (CustomPictureBox)target;
				this.mPinOnTopToggleButton.PreviewMouseLeftButtonUp += this.PinOnTop_MouseLeftButtonUp;
				return;
			case 5:
				this.mFullScreenButtonGrid = (Grid)target;
				this.mFullScreenButtonGrid.MouseEnter += this.Grid_MouseEnter;
				this.mFullScreenButtonGrid.MouseLeave += this.Grid_MouseLeave;
				this.mFullScreenButtonGrid.PreviewMouseLeftButtonUp += this.FullscreenButton_MouseLeftButtonUp;
				return;
			case 6:
				this.mFullScreenImage = (CustomPictureBox)target;
				return;
			case 7:
				this.mFullScreenButtonText = (TextBlock)target;
				return;
			case 8:
				this.mSyncOperationsButtonGrid = (Grid)target;
				this.mSyncOperationsButtonGrid.MouseLeave += this.Grid_MouseLeave;
				this.mSyncOperationsButtonGrid.MouseEnter += this.Grid_MouseEnter;
				this.mSyncOperationsButtonGrid.PreviewMouseLeftButtonUp += this.SyncOperationsButton_PreviewMouseLeftButtonUp;
				return;
			case 9:
				this.mSyncOperationsButtonImage = (CustomPictureBox)target;
				return;
			case 10:
				this.mSyncOperationsButtonText = (TextBlock)target;
				return;
			case 11:
				this.mSortingGrid = (Grid)target;
				this.mSortingGrid.MouseEnter += this.Grid_MouseEnter;
				this.mSortingGrid.MouseLeave += this.Grid_MouseLeave;
				this.mSortingGrid.PreviewMouseLeftButtonUp += this.SortingButton_MouseLeftButtonUp;
				return;
			case 12:
				this.mSortingButtonImage = (CustomPictureBox)target;
				return;
			case 13:
				this.mSortingButtonText = (TextBlock)target;
				return;
			case 14:
				this.mAccountGrid = (Grid)target;
				this.mAccountGrid.MouseEnter += this.Grid_MouseEnter;
				this.mAccountGrid.MouseLeave += this.Grid_MouseLeave;
				this.mAccountGrid.PreviewMouseLeftButtonUp += this.AccountButton_MouseLeftButtonUp;
				return;
			case 15:
				this.mAccountButtonImage = (CustomPictureBox)target;
				return;
			case 16:
				this.mAccountButtonText = (TextBlock)target;
				return;
			case 17:
				this.mSettingsButtonGrid = (Grid)target;
				this.mSettingsButtonGrid.MouseEnter += this.Grid_MouseEnter;
				this.mSettingsButtonGrid.MouseLeave += this.Grid_MouseLeave;
				this.mSettingsButtonGrid.PreviewMouseLeftButtonUp += this.SettingsButton_MouseLeftButtonUp;
				return;
			case 18:
				this.mSettingsButtonImage = (CustomPictureBox)target;
				return;
			case 19:
				this.mSettingsButtonText = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040002D5 RID: 725
		private MainWindow ParentWindow;

		// Token: 0x040002D6 RID: 726
		internal Grid mPinOnTopButtonGrid;

		// Token: 0x040002D7 RID: 727
		internal CustomPictureBox mPinOnTopButtonImage;

		// Token: 0x040002D8 RID: 728
		internal TextBlock mPinOnTopButtonText;

		// Token: 0x040002D9 RID: 729
		internal CustomPictureBox mPinOnTopToggleButton;

		// Token: 0x040002DA RID: 730
		internal Grid mFullScreenButtonGrid;

		// Token: 0x040002DB RID: 731
		internal CustomPictureBox mFullScreenImage;

		// Token: 0x040002DC RID: 732
		internal TextBlock mFullScreenButtonText;

		// Token: 0x040002DD RID: 733
		internal Grid mSyncOperationsButtonGrid;

		// Token: 0x040002DE RID: 734
		internal CustomPictureBox mSyncOperationsButtonImage;

		// Token: 0x040002DF RID: 735
		internal TextBlock mSyncOperationsButtonText;

		// Token: 0x040002E0 RID: 736
		internal Grid mSortingGrid;

		// Token: 0x040002E1 RID: 737
		internal CustomPictureBox mSortingButtonImage;

		// Token: 0x040002E2 RID: 738
		internal TextBlock mSortingButtonText;

		// Token: 0x040002E3 RID: 739
		internal Grid mAccountGrid;

		// Token: 0x040002E4 RID: 740
		internal CustomPictureBox mAccountButtonImage;

		// Token: 0x040002E5 RID: 741
		internal TextBlock mAccountButtonText;

		// Token: 0x040002E6 RID: 742
		internal Grid mSettingsButtonGrid;

		// Token: 0x040002E7 RID: 743
		internal CustomPictureBox mSettingsButtonImage;

		// Token: 0x040002E8 RID: 744
		internal TextBlock mSettingsButtonText;

		// Token: 0x040002E9 RID: 745
		private bool _contentLoaded;
	}
}
