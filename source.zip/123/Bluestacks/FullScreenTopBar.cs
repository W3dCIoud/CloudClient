﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001E6 RID: 486
	public class FullScreenTopBar : UserControl, IComponentConnector
	{
		// Token: 0x060010C3 RID: 4291 RVA: 0x0000BF48 File Offset: 0x0000A148
		public FullScreenTopBar()
		{
			this.InitializeComponent();
		}

		// Token: 0x060010C4 RID: 4292 RVA: 0x00068FA0 File Offset: 0x000671A0
		internal void Init(MainWindow window)
		{
			this.ParentWindow = window;
			if (!DesignerProperties.GetIsInDesignMode(this) && !RegistryManager.Instance.UseEscapeToExitFullScreen)
			{
				this.mEscCheckbox.ImageName = "checkbox_new";
			}
			this.transSlider.Value = RegistryManager.Instance.TranslucentControlsTransparency;
			if (FeatureManager.Instance.IsCustomUIForDMMSandbox)
			{
				this.mKeyMapSwitchFullScreen.Visibility = Visibility.Collapsed;
				this.mKeyMapButtonFullScreen.Visibility = Visibility.Collapsed;
				this.mLocationButtonFullScreen.Visibility = Visibility.Collapsed;
				this.mShakeButtonFullScreen.Visibility = Visibility.Collapsed;
				this.mGamePadButtonFullScreen.Visibility = Visibility.Collapsed;
				this.mTranslucentControlsButtonFullScreen.Visibility = Visibility.Collapsed;
			}
			this.mMacroRecorderFullScreen.Visibility = Visibility.Collapsed;
		}

		// Token: 0x060010C5 RID: 4293 RVA: 0x0000BF56 File Offset: 0x0000A156
		private void BackButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.BackButtonHandler(false);
		}

		// Token: 0x060010C6 RID: 4294 RVA: 0x0000BF69 File Offset: 0x0000A169
		private void HomeButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.HomeButtonHandler(true, false);
		}

		// Token: 0x060010C7 RID: 4295 RVA: 0x00069050 File Offset: 0x00067250
		private void SwitchKeyMapButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mBottomBar.KeyMapSwitchButtonHandler();
			ClientStats.SendMiscellaneousStatsAsync("SwitchKeyMapClicked", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "fullscreentopbar", null, null, null, null, null);
		}

		// Token: 0x060010C8 RID: 4296 RVA: 0x0000BF7D File Offset: 0x0000A17D
		private void KeyMapButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mTopBarPopup.IsOpen = false;
			this.ParentWindow.mCommonHandler.KeyMapButtonHandler("MouseClick", "fullscreentopbar");
		}

		// Token: 0x060010C9 RID: 4297 RVA: 0x0000BFAA File Offset: 0x0000A1AA
		private void FullScreenButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.FullScreenButtonHandler("fullScreenTopbar", "MouseClick");
		}

		// Token: 0x060010CA RID: 4298 RVA: 0x0000BFC6 File Offset: 0x0000A1C6
		private void LocationButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.LocationButtonHandler();
		}

		// Token: 0x060010CB RID: 4299 RVA: 0x0000BFD8 File Offset: 0x0000A1D8
		private void ScreenShotButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mTopBarPopup.IsOpen = false;
			this.ParentWindow.mCommonHandler.ScreenShotButtonHandler();
		}

		// Token: 0x060010CC RID: 4300 RVA: 0x0000BFFB File Offset: 0x0000A1FB
		private void ShakeButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.ShakeButtonHandler();
		}

		// Token: 0x060010CD RID: 4301 RVA: 0x00069098 File Offset: 0x00067298
		private void mEscCheckbox_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (RegistryManager.Instance.UseEscapeToExitFullScreen)
			{
				this.mEscCheckbox.ImageName = "checkbox_new";
				RegistryManager.Instance.UseEscapeToExitFullScreen = false;
				return;
			}
			this.mEscCheckbox.ImageName = "checkbox_new_checked";
			RegistryManager.Instance.UseEscapeToExitFullScreen = true;
		}

		// Token: 0x060010CE RID: 4302 RVA: 0x0000C00D File Offset: 0x0000A20D
		private void mMacroRecorderLandscape_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.OpenOperationRecorderWindow();
		}

		// Token: 0x060010CF RID: 4303 RVA: 0x0000C01F File Offset: 0x0000A21F
		private void GamePadButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mTopBarPopup.IsOpen = false;
			this.ParentWindow.mBottomBar.GamePadButtonHandler();
		}

		// Token: 0x060010D0 RID: 4304 RVA: 0x000690E8 File Offset: 0x000672E8
		private void TranslucentControlsButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			RegistryManager.Instance.ShowKeyControlsOverlay = true;
			RegistryManager.Instance.OverlayAvailablePromptEnabled = false;
			KMManager.ShowOverlayWindow(this.ParentWindow, true, true);
			this.mChangeTransparencyPopup.PlacementTarget = this.mTranslucentControlsButtonFullScreen;
			this.mChangeTransparencyPopup.IsOpen = true;
		}

		// Token: 0x060010D1 RID: 4305 RVA: 0x00069138 File Offset: 0x00067338
		private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			KMManager.ChangeTransparency(this.ParentWindow, this.transSlider.Value);
			if (this.transSlider.Value == 0.0)
			{
				if (!RegistryManager.Instance.ShowKeyControlsOverlay)
				{
					KMManager.ShowOverlayWindow(this.ParentWindow, false, false);
				}
				this.ParentWindow.mCommonHandler.OnOverlayStateChanged(false);
			}
			else
			{
				KMManager.ShowOverlayWindow(this.ParentWindow, true, false);
				this.ParentWindow.mCommonHandler.OnOverlayStateChanged(true);
			}
			this.lastSliderValue = this.transSlider.Value;
		}

		// Token: 0x060010D2 RID: 4306 RVA: 0x000691CC File Offset: 0x000673CC
		private void mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.transSlider.Value == 0.0)
			{
				this.transSlider.Value = this.lastSliderValue;
				return;
			}
			double value = this.transSlider.Value;
			this.transSlider.Value = 0.0;
			this.lastSliderValue = value;
		}

		// Token: 0x060010D3 RID: 4307 RVA: 0x0000C042 File Offset: 0x0000A242
		private void mChangeTransparencyPopup_Closed(object sender, EventArgs e)
		{
			if (!this.ParentWindow.mFullScreenTopBar.IsMouseOver)
			{
				this.ParentWindow.mTopBarPopup.IsOpen = false;
			}
		}

		// Token: 0x060010D4 RID: 4308 RVA: 0x00069228 File Offset: 0x00067428
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/fullscreentopbar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060010D5 RID: 4309 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060010D6 RID: 4310 RVA: 0x00069258 File Offset: 0x00067458
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((CustomPictureBox)target).PreviewMouseLeftButtonUp += this.BackButton_PreviewMouseLeftButtonUp;
				return;
			case 2:
				((CustomPictureBox)target).PreviewMouseLeftButtonUp += this.HomeButton_PreviewMouseLeftButtonUp;
				return;
			case 3:
				this.mEscCheckbox = (CustomPictureBox)target;
				this.mEscCheckbox.MouseLeftButtonUp += this.mEscCheckbox_MouseLeftButtonUp;
				return;
			case 4:
				this.mGamePadButtonFullScreen = (CustomPictureBox)target;
				this.mGamePadButtonFullScreen.PreviewMouseLeftButtonUp += this.GamePadButton_PreviewMouseLeftButtonUp;
				return;
			case 5:
				this.mMacroRecorderFullScreen = (CustomPictureBox)target;
				this.mMacroRecorderFullScreen.PreviewMouseLeftButtonUp += this.mMacroRecorderLandscape_PreviewMouseLeftButtonUp;
				return;
			case 6:
				this.mKeyMapSwitchFullScreen = (CustomPictureBox)target;
				this.mKeyMapSwitchFullScreen.PreviewMouseLeftButtonUp += this.SwitchKeyMapButton_PreviewMouseLeftButtonUp;
				return;
			case 7:
				this.mKeyMapButtonFullScreen = (CustomPictureBox)target;
				this.mKeyMapButtonFullScreen.PreviewMouseLeftButtonUp += this.KeyMapButton_PreviewMouseLeftButtonUp;
				return;
			case 8:
				this.mTranslucentControlsButtonFullScreen = (CustomPictureBox)target;
				this.mTranslucentControlsButtonFullScreen.PreviewMouseLeftButtonUp += this.TranslucentControlsButton_PreviewMouseLeftButtonUp;
				return;
			case 9:
				this.mFullScreenButton = (CustomPictureBox)target;
				this.mFullScreenButton.PreviewMouseLeftButtonUp += this.FullScreenButton_PreviewMouseLeftButtonUp;
				return;
			case 10:
				this.mLocationButtonFullScreen = (CustomPictureBox)target;
				this.mLocationButtonFullScreen.PreviewMouseLeftButtonUp += this.LocationButton_PreviewMouseLeftButtonUp;
				return;
			case 11:
				((CustomPictureBox)target).PreviewMouseLeftButtonUp += this.ScreenShotButton_PreviewMouseLeftButtonUp;
				return;
			case 12:
				this.mShakeButtonFullScreen = (CustomPictureBox)target;
				this.mShakeButtonFullScreen.PreviewMouseLeftButtonUp += this.ShakeButton_PreviewMouseLeftButtonUp;
				return;
			case 13:
				this.mChangeTransparencyPopup = (CustomPopUp)target;
				return;
			case 14:
				this.borderSlider = (Border)target;
				return;
			case 15:
				this.mTranslucentControlsSliderButton = (CustomPictureBox)target;
				this.mTranslucentControlsSliderButton.PreviewMouseLeftButtonUp += this.mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp;
				return;
			case 16:
				this.transSlider = (Slider)target;
				this.transSlider.ValueChanged += this.Slider_ValueChanged;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000B77 RID: 2935
		private MainWindow ParentWindow;

		// Token: 0x04000B78 RID: 2936
		private double lastSliderValue;

		// Token: 0x04000B79 RID: 2937
		internal CustomPictureBox mEscCheckbox;

		// Token: 0x04000B7A RID: 2938
		internal CustomPictureBox mGamePadButtonFullScreen;

		// Token: 0x04000B7B RID: 2939
		internal CustomPictureBox mMacroRecorderFullScreen;

		// Token: 0x04000B7C RID: 2940
		internal CustomPictureBox mKeyMapSwitchFullScreen;

		// Token: 0x04000B7D RID: 2941
		internal CustomPictureBox mKeyMapButtonFullScreen;

		// Token: 0x04000B7E RID: 2942
		internal CustomPictureBox mTranslucentControlsButtonFullScreen;

		// Token: 0x04000B7F RID: 2943
		internal CustomPictureBox mFullScreenButton;

		// Token: 0x04000B80 RID: 2944
		internal CustomPictureBox mLocationButtonFullScreen;

		// Token: 0x04000B81 RID: 2945
		internal CustomPictureBox mShakeButtonFullScreen;

		// Token: 0x04000B82 RID: 2946
		internal CustomPopUp mChangeTransparencyPopup;

		// Token: 0x04000B83 RID: 2947
		internal Border borderSlider;

		// Token: 0x04000B84 RID: 2948
		internal CustomPictureBox mTranslucentControlsSliderButton;

		// Token: 0x04000B85 RID: 2949
		internal Slider transSlider;

		// Token: 0x04000B86 RID: 2950
		private bool _contentLoaded;
	}
}
