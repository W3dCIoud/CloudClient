﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000A1 RID: 161
	public class QuitPopupBrowserControl : UserControl, IDimOverlayControl, IComponentConnector
	{
		// Token: 0x060006DE RID: 1758 RVA: 0x000067C3 File Offset: 0x000049C3
		public QuitPopupBrowserControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x1700014C RID: 332
		// (get) Token: 0x060006DF RID: 1759 RVA: 0x00004D85 File Offset: 0x00002F85
		// (set) Token: 0x060006E0 RID: 1760 RVA: 0x00004BF2 File Offset: 0x00002DF2
		bool IDimOverlayControl.IsCloseOnOverLayClick
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		// Token: 0x1700014D RID: 333
		// (get) Token: 0x060006E1 RID: 1761 RVA: 0x000067EE File Offset: 0x000049EE
		// (set) Token: 0x060006E2 RID: 1762 RVA: 0x000067F6 File Offset: 0x000049F6
		public bool ShowControlInSeparateWindow
		{
			get
			{
				return this.mShowControlInSeparateWindow;
			}
			set
			{
				this.mShowControlInSeparateWindow = value;
			}
		}

		// Token: 0x060006E3 RID: 1763 RVA: 0x0002B5DC File Offset: 0x000297DC
		public void CloseControl()
		{
			ClientStats.SendMiscellaneousStatsAsync("quitpopupclosed", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, WebHelper.GetUrlWithParams(this.mUrl), this.mPackage, null, null, null, null);
			this.mGrid.Children.Remove(this.ParentWindow.mFirebaseBrowserControlGrid);
			this.ParentWindow.mContentGrid.Children.Add(this.ParentWindow.mFirebaseBrowserControlGrid);
			this.ParentWindow.mFirebaseBrowserControlGrid.Visibility = Visibility.Hidden;
			BrowserControl browserControl = this.ParentWindow.mFirebaseBrowserControlGrid.Children[0] as BrowserControl;
			object[] args = new object[]
			{
				false
			};
			browserControl.mBrowser.CallJs("onBrowserVisibilityChange", args);
			if (!this.mCloseClicked)
			{
				this.ParentWindow.mTopBar.mAppTabButtons.mLastPackageForQuitPopupDisplayed = "";
			}
			base.Visibility = Visibility.Hidden;
		}

		// Token: 0x060006E4 RID: 1764 RVA: 0x0002B6D0 File Offset: 0x000298D0
		bool IDimOverlayControl.Close()
		{
			try
			{
				base.Visibility = Visibility.Hidden;
				this.CloseControl();
				return true;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while trying to close quitpopup from dimoverlay " + ex.ToString());
			}
			return false;
		}

		// Token: 0x060006E5 RID: 1765 RVA: 0x000067FF File Offset: 0x000049FF
		public void SetQuitPopParams(string url, string package, bool isForceReload)
		{
			this.mUrl = url;
			this.mForceReload = isForceReload;
			this.mPackage = package;
		}

		// Token: 0x060006E6 RID: 1766 RVA: 0x0002B71C File Offset: 0x0002991C
		public void Init(MainWindow window, string appPackage)
		{
			this.mPackage = appPackage;
			window.mContentGrid.Children.Remove(window.mFirebaseBrowserControlGrid);
			this.mGrid.Children.Add(window.mFirebaseBrowserControlGrid);
			window.mFirebaseBrowserControlGrid.Visibility = Visibility.Visible;
			BrowserControl browserControl = window.mFirebaseBrowserControlGrid.Children[0] as BrowserControl;
			object[] args = new object[]
			{
				true
			};
			browserControl.mBrowser.CallJs("onBrowserVisibilityChange", args);
			this.ParentWindow = window;
			if (string.IsNullOrEmpty(appPackage))
			{
				this.mCloseButton.Content = LocaleStrings.GetLocalizedString("STRING_CLOSE_BLUESTACKS", false);
			}
			else
			{
				this.mCloseButton.Content = LocaleStrings.GetLocalizedString("STRING_CLOSE_GAME", false);
			}
			this.mCloseClicked = false;
		}

		// Token: 0x060006E7 RID: 1767 RVA: 0x00004DA3 File Offset: 0x00002FA3
		bool IDimOverlayControl.Show()
		{
			base.Visibility = Visibility.Visible;
			return true;
		}

		// Token: 0x060006E8 RID: 1768 RVA: 0x00006816 File Offset: 0x00004A16
		private void CloseButton_Click(object sender, RoutedEventArgs e)
		{
			this.Close();
		}

		// Token: 0x060006E9 RID: 1769 RVA: 0x0002B7E8 File Offset: 0x000299E8
		public void Close()
		{
			try
			{
				this.mCloseClicked = true;
				this.ParentWindow.HideDimOverlay();
				if (string.IsNullOrEmpty(this.mPackage))
				{
					this.ParentWindow.ForceCloseWindow();
				}
				else
				{
					this.ParentWindow.mTopBar.mAppTabButtons.CloseTab(this.mPackage, true, false, false, false, "");
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception when trying to close quit popup. " + ex.ToString());
			}
		}

		// Token: 0x060006EA RID: 1770 RVA: 0x0002B870 File Offset: 0x00029A70
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/quitpopupbrowsercontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060006EB RID: 1771 RVA: 0x0002B8A0 File Offset: 0x00029AA0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mGrid = (Grid)target;
				return;
			}
			if (connectionId != 2)
			{
				this._contentLoaded = true;
				return;
			}
			this.mCloseButton = (CustomButton)target;
			this.mCloseButton.Click += this.CloseButton_Click;
		}

		// Token: 0x040004A6 RID: 1190
		private MainWindow ParentWindow;

		// Token: 0x040004A7 RID: 1191
		public string mPackage = "";

		// Token: 0x040004A8 RID: 1192
		private bool mCloseClicked;

		// Token: 0x040004A9 RID: 1193
		public string mUrl = string.Empty;

		// Token: 0x040004AA RID: 1194
		public bool mForceReload;

		// Token: 0x040004AB RID: 1195
		private bool mShowControlInSeparateWindow = true;

		// Token: 0x040004AC RID: 1196
		internal Grid mGrid;

		// Token: 0x040004AD RID: 1197
		internal CustomButton mCloseButton;

		// Token: 0x040004AE RID: 1198
		private bool _contentLoaded;
	}
}
