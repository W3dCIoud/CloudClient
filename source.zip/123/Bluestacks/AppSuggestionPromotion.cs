﻿using System;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000125 RID: 293
	[JsonObject(MemberSerialization.OptIn)]
	public class AppSuggestionPromotion
	{
		// Token: 0x170001AE RID: 430
		// (get) Token: 0x06000B8D RID: 2957 RVA: 0x0000903E File Offset: 0x0000723E
		// (set) Token: 0x06000B8E RID: 2958 RVA: 0x00009046 File Offset: 0x00007246
		[JsonProperty("app_pkg", NullValueHandling = NullValueHandling.Ignore)]
		public string AppPackage
		{
			get
			{
				return this.mAppPackage;
			}
			set
			{
				this.mAppPackage = value;
			}
		}

		// Token: 0x170001AF RID: 431
		// (get) Token: 0x06000B8F RID: 2959 RVA: 0x0000904F File Offset: 0x0000724F
		// (set) Token: 0x06000B90 RID: 2960 RVA: 0x00009057 File Offset: 0x00007257
		[JsonProperty("app_activity", NullValueHandling = NullValueHandling.Ignore)]
		public string AppActivity { get; set; }

		// Token: 0x170001B0 RID: 432
		// (get) Token: 0x06000B91 RID: 2961 RVA: 0x00009060 File Offset: 0x00007260
		// (set) Token: 0x06000B92 RID: 2962 RVA: 0x00009068 File Offset: 0x00007268
		[JsonProperty("show_red_dot", NullValueHandling = NullValueHandling.Ignore)]
		public bool IsShowRedDot
		{
			get
			{
				return this.mIsShowRedDot;
			}
			set
			{
				this.mIsShowRedDot = value;
			}
		}

		// Token: 0x170001B1 RID: 433
		// (get) Token: 0x06000B93 RID: 2963 RVA: 0x00009071 File Offset: 0x00007271
		// (set) Token: 0x06000B94 RID: 2964 RVA: 0x00009079 File Offset: 0x00007279
		[JsonProperty("app_name", NullValueHandling = NullValueHandling.Ignore)]
		public string AppName
		{
			get
			{
				return this.mAppName;
			}
			set
			{
				this.mAppName = value;
			}
		}

		// Token: 0x170001B2 RID: 434
		// (get) Token: 0x06000B95 RID: 2965 RVA: 0x00009082 File Offset: 0x00007282
		// (set) Token: 0x06000B96 RID: 2966 RVA: 0x0000908A File Offset: 0x0000728A
		[JsonProperty("app_icon", NullValueHandling = NullValueHandling.Ignore)]
		public string AppIcon
		{
			get
			{
				return this.mAppIcon;
			}
			set
			{
				this.mAppIcon = value;
			}
		}

		// Token: 0x170001B3 RID: 435
		// (get) Token: 0x06000B97 RID: 2967 RVA: 0x00009093 File Offset: 0x00007293
		// (set) Token: 0x06000B98 RID: 2968 RVA: 0x0000909B File Offset: 0x0000729B
		[JsonProperty("app_icon_id", NullValueHandling = NullValueHandling.Ignore)]
		public string AppIconId
		{
			get
			{
				return this.mAppIconId;
			}
			set
			{
				this.mAppIconId = value;
			}
		}

		// Token: 0x170001B4 RID: 436
		// (get) Token: 0x06000B99 RID: 2969 RVA: 0x000090A4 File Offset: 0x000072A4
		// (set) Token: 0x06000B9A RID: 2970 RVA: 0x000090AC File Offset: 0x000072AC
		[JsonProperty("tooltip", NullValueHandling = NullValueHandling.Ignore)]
		public string ToolTip
		{
			get
			{
				return this.mToolTip;
			}
			set
			{
				this.mToolTip = value;
			}
		}

		// Token: 0x170001B5 RID: 437
		// (get) Token: 0x06000B9B RID: 2971 RVA: 0x000090B5 File Offset: 0x000072B5
		// (set) Token: 0x06000B9C RID: 2972 RVA: 0x000090BD File Offset: 0x000072BD
		[JsonProperty("cross_promotion_pkg", NullValueHandling = NullValueHandling.Ignore)]
		public string CrossPromotionPackage
		{
			get
			{
				return this.mCrossPromotionPackage;
			}
			set
			{
				this.mCrossPromotionPackage = value;
			}
		}

		// Token: 0x170001B6 RID: 438
		// (get) Token: 0x06000B9D RID: 2973 RVA: 0x000090C6 File Offset: 0x000072C6
		// (set) Token: 0x06000B9E RID: 2974 RVA: 0x000090CE File Offset: 0x000072CE
		[JsonProperty("location", NullValueHandling = NullValueHandling.Ignore)]
		public string AppLocation
		{
			get
			{
				return this.mAppLocation;
			}
			set
			{
				this.mAppLocation = value;
			}
		}

		// Token: 0x170001B7 RID: 439
		// (get) Token: 0x06000B9F RID: 2975 RVA: 0x000090D7 File Offset: 0x000072D7
		// (set) Token: 0x06000BA0 RID: 2976 RVA: 0x000090DF File Offset: 0x000072DF
		[JsonProperty("is_email_required", NullValueHandling = NullValueHandling.Ignore)]
		public bool IsEmailRequired
		{
			get
			{
				return this.mIsEmailRequired;
			}
			set
			{
				this.mIsEmailRequired = value;
			}
		}

		// Token: 0x170001B8 RID: 440
		// (get) Token: 0x06000BA1 RID: 2977 RVA: 0x000090E8 File Offset: 0x000072E8
		// (set) Token: 0x06000BA2 RID: 2978 RVA: 0x000090F0 File Offset: 0x000072F0
		public SerializableDictionary<string, string> ExtraPayload
		{
			get
			{
				return this.mExtraPayload;
			}
			set
			{
				this.mExtraPayload = value;
			}
		}

		// Token: 0x170001B9 RID: 441
		// (get) Token: 0x06000BA3 RID: 2979 RVA: 0x000090F9 File Offset: 0x000072F9
		// (set) Token: 0x06000BA4 RID: 2980 RVA: 0x00009101 File Offset: 0x00007301
		[JsonProperty("is_animation", NullValueHandling = NullValueHandling.Ignore)]
		public bool IsAnimation
		{
			get
			{
				return this.mIsAnimation;
			}
			set
			{
				this.mIsAnimation = value;
			}
		}

		// Token: 0x170001BA RID: 442
		// (get) Token: 0x06000BA5 RID: 2981 RVA: 0x0000910A File Offset: 0x0000730A
		// (set) Token: 0x06000BA6 RID: 2982 RVA: 0x00009112 File Offset: 0x00007312
		[JsonProperty("animation_time", NullValueHandling = NullValueHandling.Ignore)]
		public int AnimationTime
		{
			get
			{
				return this.mAnimationTime;
			}
			set
			{
				this.mAnimationTime = value;
			}
		}

		// Token: 0x170001BB RID: 443
		// (get) Token: 0x06000BA7 RID: 2983 RVA: 0x0000911B File Offset: 0x0000731B
		// (set) Token: 0x06000BA8 RID: 2984 RVA: 0x00009123 File Offset: 0x00007323
		[JsonProperty("is_icon_border", NullValueHandling = NullValueHandling.Ignore)]
		public bool IsIconBorder
		{
			get
			{
				return this.mIsIconBorder;
			}
			set
			{
				this.mIsIconBorder = value;
			}
		}

		// Token: 0x170001BC RID: 444
		// (get) Token: 0x06000BA9 RID: 2985 RVA: 0x0000912C File Offset: 0x0000732C
		// (set) Token: 0x06000BAA RID: 2986 RVA: 0x00009134 File Offset: 0x00007334
		[JsonProperty("icon_border_url", NullValueHandling = NullValueHandling.Ignore)]
		public string IconBorderUrl
		{
			get
			{
				return this.mIconBorderUrl;
			}
			set
			{
				this.mIconBorderUrl = value;
			}
		}

		// Token: 0x170001BD RID: 445
		// (get) Token: 0x06000BAB RID: 2987 RVA: 0x0000913D File Offset: 0x0000733D
		// (set) Token: 0x06000BAC RID: 2988 RVA: 0x00009145 File Offset: 0x00007345
		[JsonProperty("icon_border_click_url", NullValueHandling = NullValueHandling.Ignore)]
		public string IconBorderClickUrl
		{
			get
			{
				return this.mIconBorderClickUrl;
			}
			set
			{
				this.mIconBorderClickUrl = value;
			}
		}

		// Token: 0x170001BE RID: 446
		// (get) Token: 0x06000BAD RID: 2989 RVA: 0x0000914E File Offset: 0x0000734E
		// (set) Token: 0x06000BAE RID: 2990 RVA: 0x00009156 File Offset: 0x00007356
		[JsonProperty("icon_border_id", NullValueHandling = NullValueHandling.Ignore)]
		public string IconBorderId
		{
			get
			{
				return this.mIconBorderId;
			}
			set
			{
				this.mIconBorderId = value;
			}
		}

		// Token: 0x170001BF RID: 447
		// (get) Token: 0x06000BAF RID: 2991 RVA: 0x0000915F File Offset: 0x0000735F
		// (set) Token: 0x06000BB0 RID: 2992 RVA: 0x00009167 File Offset: 0x00007367
		[JsonProperty("icon_border_hover_url", NullValueHandling = NullValueHandling.Ignore)]
		public string IconBorderHoverUrl
		{
			get
			{
				return this.mIconBorderHoverUrl;
			}
			set
			{
				this.mIconBorderHoverUrl = value;
			}
		}

		// Token: 0x170001C0 RID: 448
		// (get) Token: 0x06000BB1 RID: 2993 RVA: 0x00009170 File Offset: 0x00007370
		// (set) Token: 0x06000BB2 RID: 2994 RVA: 0x00009178 File Offset: 0x00007378
		public string AppIconPath
		{
			get
			{
				return this.mAppIconPath;
			}
			set
			{
				this.mAppIconPath = value;
			}
		}

		// Token: 0x170001C1 RID: 449
		// (get) Token: 0x06000BB3 RID: 2995 RVA: 0x00009181 File Offset: 0x00007381
		// (set) Token: 0x06000BB4 RID: 2996 RVA: 0x00009189 File Offset: 0x00007389
		[JsonProperty("app_icon_width", NullValueHandling = NullValueHandling.Ignore)]
		public double IconWidth
		{
			get
			{
				return this.mIconWidth;
			}
			set
			{
				this.mIconWidth = value;
			}
		}

		// Token: 0x170001C2 RID: 450
		// (get) Token: 0x06000BB5 RID: 2997 RVA: 0x00009192 File Offset: 0x00007392
		// (set) Token: 0x06000BB6 RID: 2998 RVA: 0x0000919A File Offset: 0x0000739A
		[JsonProperty("app_icon_height", NullValueHandling = NullValueHandling.Ignore)]
		public double IconHeight
		{
			get
			{
				return this.mIconHeight;
			}
			set
			{
				this.mIconHeight = value;
			}
		}

		// Token: 0x0400085A RID: 2138
		private string mAppPackage = string.Empty;

		// Token: 0x0400085C RID: 2140
		private bool mIsShowRedDot;

		// Token: 0x0400085D RID: 2141
		private string mAppName;

		// Token: 0x0400085E RID: 2142
		private string mAppIcon;

		// Token: 0x0400085F RID: 2143
		private string mAppIconId;

		// Token: 0x04000860 RID: 2144
		private string mToolTip;

		// Token: 0x04000861 RID: 2145
		private string mCrossPromotionPackage;

		// Token: 0x04000862 RID: 2146
		private string mAppLocation = string.Empty;

		// Token: 0x04000863 RID: 2147
		private bool mIsEmailRequired;

		// Token: 0x04000864 RID: 2148
		private SerializableDictionary<string, string> mExtraPayload = new SerializableDictionary<string, string>();

		// Token: 0x04000865 RID: 2149
		private bool mIsAnimation;

		// Token: 0x04000866 RID: 2150
		private int mAnimationTime;

		// Token: 0x04000867 RID: 2151
		private bool mIsIconBorder;

		// Token: 0x04000868 RID: 2152
		private string mIconBorderUrl;

		// Token: 0x04000869 RID: 2153
		private string mIconBorderClickUrl;

		// Token: 0x0400086A RID: 2154
		private string mIconBorderId;

		// Token: 0x0400086B RID: 2155
		private string mIconBorderHoverUrl;

		// Token: 0x0400086C RID: 2156
		private string mAppIconPath;

		// Token: 0x0400086D RID: 2157
		private double mIconWidth;

		// Token: 0x0400086E RID: 2158
		private double mIconHeight;
	}
}
