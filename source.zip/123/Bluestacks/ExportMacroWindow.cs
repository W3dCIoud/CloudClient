﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000057 RID: 87
	public class ExportMacroWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x060003D0 RID: 976 RVA: 0x00004923 File Offset: 0x00002B23
		public ExportMacroWindow(OperationRecorderWindow window, MainWindow mainWindow)
		{
			this.InitializeComponent();
			this.mOperationWindow = window;
			this.ParentWindow = mainWindow;
			this.mScriptsStackPanel = (this.mScriptsListScrollbar.Content as StackPanel);
		}

		// Token: 0x060003D1 RID: 977 RVA: 0x00004960 File Offset: 0x00002B60
		private void Close_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.CloseWindow();
		}

		// Token: 0x060003D2 RID: 978 RVA: 0x00004968 File Offset: 0x00002B68
		private void CloseWindow()
		{
			base.Close();
			this.mOperationWindow.mExportMacroWindow = null;
			this.mOperationWindow.mOverlayGrid.Visibility = Visibility.Hidden;
			this.mOperationWindow.Focus();
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x0001A420 File Offset: 0x00018620
		internal void Init()
		{
			try
			{
				if (Directory.Exists(RegistryStrings.OperationsScriptFolder))
				{
					foreach (FileInfo fileInfo in (from p in new DirectoryInfo(RegistryStrings.OperationsScriptFolder).GetFiles()
					orderby p.CreationTime
					select p).ToArray<FileInfo>())
					{
						this.ParentWindow.mIsScriptsPresent = true;
						OperationsRecord operationsRecord = JsonConvert.DeserializeObject<OperationsRecord>(File.ReadAllText(fileInfo.FullName), Utils.GetSerializerSettings());
						if (operationsRecord != null)
						{
							operationsRecord.Name = Path.GetFileName(fileInfo.Name);
							if (!this.dict.ContainsKey(operationsRecord.Name))
							{
								this.dict.Add(operationsRecord.Name, operationsRecord);
								CustomCheckbox customCheckbox = new CustomCheckbox();
								customCheckbox.Content = operationsRecord.Name;
								customCheckbox.TextFontSize = 12.0;
								customCheckbox.Margin = new Thickness(0.0, 6.0, 0.0, 6.0);
								customCheckbox.Checked += this.Box_Checked;
								customCheckbox.Unchecked += this.Box_Unchecked;
								customCheckbox.ImageMargin = new Thickness(2.0);
								customCheckbox.MaxHeight = 20.0;
								this.mScriptsStackPanel.Children.Add(customCheckbox);
							}
						}
					}
					this.mNumberOfFilesSelectedForExport = 0;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in export window init err: " + ex.ToString());
			}
		}

		// Token: 0x060003D4 RID: 980 RVA: 0x0001A5E0 File Offset: 0x000187E0
		private void Box_Unchecked(object sender, RoutedEventArgs e)
		{
			this.mNumberOfFilesSelectedForExport--;
			if (this.mNumberOfFilesSelectedForExport == 0)
			{
				this.mExportBtn.IsEnabled = false;
			}
			if (this.mNumberOfFilesSelectedForExport == this.mScriptsStackPanel.Children.Count - 1)
			{
				this.mSelectAllBtn.IsChecked = new bool?(false);
			}
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x0001A63C File Offset: 0x0001883C
		private void Box_Checked(object sender, RoutedEventArgs e)
		{
			this.mNumberOfFilesSelectedForExport++;
			if (this.mNumberOfFilesSelectedForExport == 1)
			{
				this.mExportBtn.IsEnabled = true;
			}
			if (this.mNumberOfFilesSelectedForExport == this.mScriptsStackPanel.Children.Count)
			{
				this.mSelectAllBtn.IsChecked = new bool?(true);
			}
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x0001A698 File Offset: 0x00018898
		private void ExportBtn_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				int num = 0;
				List<OperationsRecord> list = new List<OperationsRecord>();
				foreach (object obj in this.mScriptsStackPanel.Children)
				{
					bool? isChecked = (obj as CustomCheckbox).IsChecked;
					bool flag = true;
					if (isChecked.GetValueOrDefault() == flag & isChecked != null)
					{
						list.Add(this.dict.ElementAt(num).Value);
					}
					num++;
				}
				if (list.Count != 0)
				{
					using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog())
					{
						if (folderBrowserDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
						{
							BackgroundWorker backgroundWorker = new BackgroundWorker();
							backgroundWorker.DoWork += this.BgExport_DoWork;
							backgroundWorker.RunWorkerCompleted += this.BgExport_RunWorkerCompleted;
							this.ShowLoadingGrid(true);
							backgroundWorker.RunWorkerAsync(new List<object>
							{
								folderBrowserDialog.SelectedPath,
								list
							});
						}
						else
						{
							this.ToggleCheckBoxForExport(false);
						}
						goto IL_125;
					}
				}
				this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_MACRO_SELECTED", false), 4.0, true);
				IL_125:;
			}
			catch (Exception)
			{
				Logger.Error("Error while exporting script. err:" + e.ToString());
			}
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x00004999 File Offset: 0x00002B99
		private void BgExport_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			this.ShowLoadingGrid(false);
			this.ToggleCheckBoxForExport(false);
			this.CloseWindow();
		}

		// Token: 0x060003D8 RID: 984 RVA: 0x0001A830 File Offset: 0x00018A30
		private void ToggleCheckBoxForExport(bool isShow)
		{
			foreach (object obj in this.mScriptsStackPanel.Children)
			{
				(obj as CustomCheckbox).IsChecked = new bool?(false);
			}
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x0001A894 File Offset: 0x00018A94
		private void BgExport_DoWork(object sender, DoWorkEventArgs e)
		{
			List<object> list = e.Argument as List<object>;
			string path = list[0] as string;
			foreach (OperationsRecord operationsRecord in (list[1] as List<OperationsRecord>))
			{
				string name = operationsRecord.Name;
				string sourceFileName = Path.Combine(RegistryStrings.OperationsScriptFolder, name.ToLower().Trim());
				string destFileName = Path.Combine(path, operationsRecord.Name.ToLower().Trim());
				File.Copy(sourceFileName, destFileName, true);
			}
		}

		// Token: 0x060003DA RID: 986 RVA: 0x0001A93C File Offset: 0x00018B3C
		private void ShowLoadingGrid(bool isShow)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (isShow)
				{
					this.mLoadingGrid.Visibility = Visibility.Visible;
					return;
				}
				this.mLoadingGrid.Visibility = Visibility.Hidden;
			}), new object[0]);
		}

		// Token: 0x060003DB RID: 987 RVA: 0x0001A97C File Offset: 0x00018B7C
		private void SelectAllBtn_Click(object sender, RoutedEventArgs e)
		{
			if (this.mSelectAllBtn.IsChecked.Value)
			{
				using (IEnumerator enumerator = this.mScriptsStackPanel.Children.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						object obj = enumerator.Current;
						(obj as CustomCheckbox).IsChecked = new bool?(true);
					}
					return;
				}
			}
			foreach (object obj2 in this.mScriptsStackPanel.Children)
			{
				(obj2 as CustomCheckbox).IsChecked = new bool?(false);
			}
		}

		// Token: 0x060003DC RID: 988 RVA: 0x0001AA44 File Offset: 0x00018C44
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/exportmacrowindow.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060003DD RID: 989 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060003DE RID: 990 RVA: 0x0001AA74 File Offset: 0x00018C74
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				((CustomPictureBox)target).MouseLeftButtonUp += this.Close_MouseLeftButtonUp;
				return;
			case 3:
				this.mScriptsListScrollbar = (ScrollViewer)target;
				return;
			case 4:
				this.mSelectAllBtn = (CustomCheckbox)target;
				this.mSelectAllBtn.Click += this.SelectAllBtn_Click;
				return;
			case 5:
				this.mExportBtn = (CustomButton)target;
				this.mExportBtn.Click += this.ExportBtn_Click;
				return;
			case 6:
				this.mLoadingGrid = (BlueStacks.BlueStacksUI.ProgressBar)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000228 RID: 552
		private OperationRecorderWindow mOperationWindow;

		// Token: 0x04000229 RID: 553
		private MainWindow ParentWindow;

		// Token: 0x0400022A RID: 554
		internal StackPanel mScriptsStackPanel;

		// Token: 0x0400022B RID: 555
		internal int mNumberOfFilesSelectedForExport;

		// Token: 0x0400022C RID: 556
		private Dictionary<string, OperationsRecord> dict = new Dictionary<string, OperationsRecord>();

		// Token: 0x0400022D RID: 557
		internal Border mMaskBorder;

		// Token: 0x0400022E RID: 558
		internal ScrollViewer mScriptsListScrollbar;

		// Token: 0x0400022F RID: 559
		internal CustomCheckbox mSelectAllBtn;

		// Token: 0x04000230 RID: 560
		internal CustomButton mExportBtn;

		// Token: 0x04000231 RID: 561
		internal BlueStacks.BlueStacksUI.ProgressBar mLoadingGrid;

		// Token: 0x04000232 RID: 562
		private bool _contentLoaded;
	}
}
