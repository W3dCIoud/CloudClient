﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000E5 RID: 229
	public class GuidenceVideoWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x060009CC RID: 2508 RVA: 0x000456B8 File Offset: 0x000438B8
		internal void Init(MainWindow window)
		{
			this.mMainBrowserGrid.Height = window.ActualHeight * 0.8;
			this.mMainBrowserGrid.Width = window.ActualWidth * 0.7;
			if (this.mMainBrowserGrid.Width < 700.0)
			{
				this.mMainBrowserGrid.Width = 700.0;
			}
		}

		// Token: 0x060009CD RID: 2509 RVA: 0x00008153 File Offset: 0x00006353
		public GuidenceVideoWindow()
		{
			this.InitializeComponent();
		}

		// Token: 0x060009CE RID: 2510 RVA: 0x00045728 File Offset: 0x00043928
		private void GuidenceVideoWindow_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (base.IsVisible)
			{
				ClientStats.SendKeyMappingUIStatsAsync("video_clicked", KMManager.sPackageName, KMManager.sVideoMode);
				this.mBrowser = new BrowserControl();
				this.mBrowser.InitBaseControl(BlueStacksUIUtils.GetVideoTutorialUrl(KMManager.sPackageName, KMManager.sVideoMode), 0f);
				this.mBrowser.Visibility = Visibility.Visible;
				this.mBrowserGrid.Children.Add(this.mBrowser);
			}
		}

		// Token: 0x060009CF RID: 2511 RVA: 0x00008161 File Offset: 0x00006361
		internal void CloseWindow()
		{
			if (this.mBrowser != null)
			{
				this.mBrowser.DisposeBrowser();
				this.mBrowserGrid.Children.Remove(this.mBrowser);
				this.mBrowser = null;
			}
		}

		// Token: 0x060009D0 RID: 2512 RVA: 0x00008193 File Offset: 0x00006393
		private void CloseButton_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			base.Close();
		}

		// Token: 0x060009D1 RID: 2513 RVA: 0x0000819B File Offset: 0x0000639B
		private void mWindow_Closing(object sender, CancelEventArgs e)
		{
			this.CloseWindow();
		}

		// Token: 0x060009D2 RID: 2514 RVA: 0x000457A0 File Offset: 0x000439A0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/guidencevideowindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060009D3 RID: 2515 RVA: 0x000457D0 File Offset: 0x000439D0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mWindow = (GuidenceVideoWindow)target;
				this.mWindow.IsVisibleChanged += this.GuidenceVideoWindow_IsVisibleChanged;
				this.mWindow.Closing += this.mWindow_Closing;
				return;
			case 2:
				this.mMainBrowserGrid = (Grid)target;
				return;
			case 3:
				this.mMaskBorder = (Border)target;
				return;
			case 4:
				this.mBrowserGrid = (Grid)target;
				return;
			case 5:
				((CustomPictureBox)target).PreviewMouseUp += this.CloseButton_PreviewMouseUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000717 RID: 1815
		private BrowserControl mBrowser;

		// Token: 0x04000718 RID: 1816
		internal GuidenceVideoWindow mWindow;

		// Token: 0x04000719 RID: 1817
		internal Grid mMainBrowserGrid;

		// Token: 0x0400071A RID: 1818
		internal Border mMaskBorder;

		// Token: 0x0400071B RID: 1819
		internal Grid mBrowserGrid;

		// Token: 0x0400071C RID: 1820
		private bool _contentLoaded;
	}
}
