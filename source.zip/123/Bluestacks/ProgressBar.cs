﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001DB RID: 475
	public class ProgressBar : UserControl, IDimOverlayControl, IComponentConnector
	{
		// Token: 0x170001F3 RID: 499
		// (get) Token: 0x06001069 RID: 4201 RVA: 0x0000BACE File Offset: 0x00009CCE
		// (set) Token: 0x0600106A RID: 4202 RVA: 0x0000BADB File Offset: 0x00009CDB
		public string ProgressText
		{
			get
			{
				return this.mLabel.Text;
			}
			set
			{
				BlueStacksUIBinding.Bind(this.mLabel, value, "");
				if (string.IsNullOrEmpty(this.mLabel.Text))
				{
					this.mLabel.Visibility = Visibility.Collapsed;
				}
			}
		}

		// Token: 0x170001F4 RID: 500
		// (get) Token: 0x0600106B RID: 4203 RVA: 0x00004D85 File Offset: 0x00002F85
		// (set) Token: 0x0600106C RID: 4204 RVA: 0x00004BF2 File Offset: 0x00002DF2
		public bool IsCloseOnOverLayClick
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		// Token: 0x170001F5 RID: 501
		// (get) Token: 0x0600106D RID: 4205 RVA: 0x00004D85 File Offset: 0x00002F85
		// (set) Token: 0x0600106E RID: 4206 RVA: 0x00004BF2 File Offset: 0x00002DF2
		public bool ShowControlInSeparateWindow
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		// Token: 0x0600106F RID: 4207 RVA: 0x0000BB0C File Offset: 0x00009D0C
		public ProgressBar()
		{
			this.InitializeComponent();
		}

		// Token: 0x06001070 RID: 4208 RVA: 0x0000516D File Offset: 0x0000336D
		public bool Close()
		{
			base.Visibility = Visibility.Hidden;
			return true;
		}

		// Token: 0x06001071 RID: 4209 RVA: 0x00004DA3 File Offset: 0x00002FA3
		public bool Show()
		{
			base.Visibility = Visibility.Visible;
			return true;
		}

		// Token: 0x06001072 RID: 4210 RVA: 0x000674F8 File Offset: 0x000656F8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/progressbar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06001073 RID: 4211 RVA: 0x00067528 File Offset: 0x00065728
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mProgressBar = (ProgressBar)target;
				return;
			case 2:
				this.mLoadingImage = (CustomPictureBox)target;
				return;
			case 3:
				this.mLabel = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000B31 RID: 2865
		internal ProgressBar mProgressBar;

		// Token: 0x04000B32 RID: 2866
		internal CustomPictureBox mLoadingImage;

		// Token: 0x04000B33 RID: 2867
		internal TextBlock mLabel;

		// Token: 0x04000B34 RID: 2868
		private bool _contentLoaded;
	}
}
