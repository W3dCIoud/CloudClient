﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000E0 RID: 224
	public class DualTextBlockControl : UserControl, IComponentConnector
	{
		// Token: 0x17000175 RID: 373
		// (get) Token: 0x0600098F RID: 2447 RVA: 0x00007EED File Offset: 0x000060ED
		internal List<IMAction> LstActionItem
		{
			get
			{
				return this.lstActionItem;
			}
		}

		// Token: 0x17000176 RID: 374
		// (get) Token: 0x06000990 RID: 2448 RVA: 0x00007EF5 File Offset: 0x000060F5
		// (set) Token: 0x06000991 RID: 2449 RVA: 0x00042F04 File Offset: 0x00041104
		internal string ActionItemProperty
		{
			get
			{
				return this.mActionItemProperty;
			}
			set
			{
				this.mActionItemProperty = value;
				if (value == "Tags" || value == "EnableCondition")
				{
					this.mValueColumn.Width = new GridLength(1.0, GridUnitType.Star);
					this.mKeyTextBox.HorizontalContentAlignment = HorizontalAlignment.Left;
					this.mKeyPropertyName.Visibility = Visibility.Collapsed;
					this.mKeyTextBox.MaxWidth = double.PositiveInfinity;
					this.mKeyPropertyNameTextBox.Visibility = Visibility.Collapsed;
				}
			}
		}

		// Token: 0x06000992 RID: 2450 RVA: 0x00007EFD File Offset: 0x000060FD
		public DualTextBlockControl(MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			InputMethod.SetIsInputMethodEnabled(this.mKeyTextBox, false);
		}

		// Token: 0x06000993 RID: 2451 RVA: 0x00007F34 File Offset: 0x00006134
		private void KeyPropertyNameTextBox_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
			}
			KeymapCanvasWindow.sIsDirty = true;
		}

		// Token: 0x06000994 RID: 2452 RVA: 0x00042F84 File Offset: 0x00041184
		private void KeyTextBox_KeyDown(object sender, KeyEventArgs e)
		{
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
			}
			KeymapCanvasWindow.sIsDirty = true;
			if (e.Key == Key.Escape)
			{
				return;
			}
			if (this.ActionItemProperty.StartsWith("Key"))
			{
				if (this.lstActionItem[0].Type == KeyActionType.Tap || this.lstActionItem[0].Type == KeyActionType.TapRepeat || this.lstActionItem[0].Type == KeyActionType.Script)
				{
					if (e.Key == Key.Back || e.SystemKey == Key.Back)
					{
						this.mKeyTextBox.Tag = string.Empty;
						BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + this.mKeyTextBox.Tag);
					}
					else if (IMAPKeys.mDictKeys.ContainsKey(e.SystemKey) || IMAPKeys.mDictKeys.ContainsKey(e.Key))
					{
						if (e.SystemKey == Key.LeftAlt || e.SystemKey == Key.RightAlt || e.SystemKey == Key.F10)
						{
							this.mKeyList.AddIfNotContain(e.SystemKey);
						}
						else if (e.KeyboardDevice.Modifiers != ModifierKeys.None)
						{
							if (e.KeyboardDevice.Modifiers == ModifierKeys.Alt)
							{
								this.mKeyList.AddIfNotContain(e.SystemKey);
							}
							else if (e.KeyboardDevice.Modifiers == (ModifierKeys.Alt | ModifierKeys.Shift))
							{
								this.mKeyList.AddIfNotContain(e.SystemKey);
							}
							else
							{
								this.mKeyList.AddIfNotContain(e.Key);
							}
						}
						else
						{
							this.mKeyList.AddIfNotContain(e.Key);
						}
					}
				}
				else
				{
					if (e.Key == Key.System && IMAPKeys.mDictKeys.ContainsKey(e.SystemKey))
					{
						this.mKeyTextBox.Tag = IMAPKeys.GetStringForFile(e.SystemKey);
						BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(e.SystemKey));
					}
					else if (IMAPKeys.mDictKeys.ContainsKey(e.Key))
					{
						this.mKeyTextBox.Tag = IMAPKeys.GetStringForFile(e.Key);
						BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(e.Key));
					}
					else if (e.Key == Key.Back)
					{
						this.mKeyTextBox.Tag = string.Empty;
						BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + string.Empty);
					}
					e.Handled = true;
				}
			}
			if (this.PropertyType.Equals(typeof(bool)))
			{
				this.mKeyTextBox.Tag = !Convert.ToBoolean(this.lstActionItem.First<IMAction>()[this.ActionItemProperty]);
				BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + this.mKeyTextBox.Tag);
				if (this.lstActionItem.First<IMAction>().Type == KeyActionType.TapRepeat && KMManager.CanvasWindow.mCanvasElement != null)
				{
					KMManager.CanvasWindow.mCanvasElement.SetToggleModeValues(this.lstActionItem.First<IMAction>());
				}
				e.Handled = true;
			}
			if (this.PropertyType.Equals(typeof(int)) && this.lstActionItem.First<IMAction>().Type == KeyActionType.FreeLook && KMManager.CanvasWindow.mCanvasElement != null)
			{
				KMManager.CanvasWindow.mCanvasElement.SetToggleModeValues(this.lstActionItem.First<IMAction>());
			}
		}

		// Token: 0x06000995 RID: 2453 RVA: 0x0004331C File Offset: 0x0004151C
		private void KeyTextBox_KeyUp(object sender, KeyEventArgs e)
		{
			if (this.lstActionItem[0].Type == KeyActionType.Tap || this.lstActionItem[0].Type == KeyActionType.TapRepeat || this.lstActionItem[0].Type == KeyActionType.Script)
			{
				string text = string.Empty;
				string tag = string.Empty;
				if (this.mKeyList.Count >= 2)
				{
					text = IMAPKeys.GetStringForUI(this.mKeyList.ElementAt(this.mKeyList.Count - 2)) + " + " + IMAPKeys.GetStringForUI(this.mKeyList.ElementAt(this.mKeyList.Count - 1));
					tag = IMAPKeys.GetStringForFile(this.mKeyList.ElementAt(this.mKeyList.Count - 2)) + " + " + IMAPKeys.GetStringForFile(this.mKeyList.ElementAt(this.mKeyList.Count - 1));
					this.mKeyTextBox.Text = text;
					this.mKeyTextBox.Tag = tag;
					this.SetValueHandling();
				}
				else if (this.mKeyList.Count == 1)
				{
					text = IMAPKeys.GetStringForUI(this.mKeyList.ElementAt(0));
					tag = IMAPKeys.GetStringForFile(this.mKeyList.ElementAt(0));
					this.mKeyTextBox.Text = text;
					this.mKeyTextBox.Tag = tag;
					this.SetValueHandling();
				}
				this.mKeyTextBox.CaretIndex = this.mKeyTextBox.Text.Length;
				this.mKeyList.Clear();
			}
		}

		// Token: 0x06000996 RID: 2454 RVA: 0x000434A8 File Offset: 0x000416A8
		private void KeyTextBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.ActionItemProperty.StartsWith("Key"))
			{
				if (e.MiddleButton == MouseButtonState.Pressed)
				{
					e.Handled = true;
					this.mKeyTextBox.Tag = "MouseMButton";
					BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + "MouseMButton");
				}
				else if (e.RightButton == MouseButtonState.Pressed)
				{
					e.Handled = true;
					this.mKeyTextBox.Tag = "MouseRButton";
					BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + "MouseRButton");
				}
				else if (e.XButton1 == MouseButtonState.Pressed)
				{
					e.Handled = true;
					this.mKeyTextBox.Tag = "MouseXButton1";
					BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + "MouseXButton1");
				}
				else if (e.XButton2 == MouseButtonState.Pressed)
				{
					e.Handled = true;
					this.mKeyTextBox.Tag = "MouseXButton2";
					BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + "MouseXButton2");
				}
			}
			if (this.PropertyType.Equals(typeof(bool)))
			{
				this.mKeyTextBox.Tag = !Convert.ToBoolean(this.lstActionItem.First<IMAction>()[this.ActionItemProperty]);
				BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + this.mKeyTextBox.Tag);
			}
		}

		// Token: 0x06000997 RID: 2455 RVA: 0x00043620 File Offset: 0x00041820
		internal bool AddActionItem(IMAction action)
		{
			this.PropertyType = IMAction.DictPropertyInfo[action.Type][this.ActionItemProperty].PropertyType;
			string text;
			if ((!this.PropertyType.Equals(typeof(string)) && !this.ActionItemProperty.Equals("Sensitivity") && !this.ActionItemProperty.Equals("MouseAcceleration")) || (action.Type == KeyActionType.State && (this.ActionItemProperty.Equals("Name") || this.ActionItemProperty.Equals("Model"))))
			{
				this.mKeyPropertyNameTextBox.IsEnabled = false;
			}
			else
			{
				this.mKeyPropertyNameTextBox.IsEnabled = true;
				int num = this.mActionItemProperty.IndexOf("_alt1");
				text = this.mActionItemProperty;
				if (num > 0)
				{
					text = this.mActionItemProperty.Substring(0, num);
				}
				if (action.Guidance.ContainsKey(text) && !string.IsNullOrEmpty(action.Guidance[text]))
				{
					this.mKeyPropertyNameTextBox.Text = this.ParentWindow.SelectedConfig.GetUIString(action.Guidance[text]);
				}
				else if (action.Guidance.ContainsKey(this.mActionItemProperty) && !string.IsNullOrEmpty(action.Guidance[this.mActionItemProperty]))
				{
					this.mKeyPropertyNameTextBox.Text = this.ParentWindow.SelectedConfig.GetUIString(action.Guidance[this.mActionItemProperty]);
					if (!action.Guidance.ContainsKey(text))
					{
						action.Guidance.Add(text, this.mKeyPropertyNameTextBox.Text.ToString());
					}
				}
				else
				{
					BlueStacksUIBinding.Bind(this.mKeyPropertyNameTextBox, "STRING_ENTER_GUIDANCE_TEXT");
					this.mKeyPropertyNameTextBox.FontStyle = FontStyles.Italic;
					this.mKeyPropertyNameTextBox.FontWeight = FontWeights.ExtraLight;
					BlueStacksUIBinding.BindColor(this.mKeyPropertyNameTextBox, Control.ForegroundProperty, "DualTextBlockLightForegroundColor");
				}
			}
			this.lstActionItem.Add(action);
			text = this.mActionItemProperty;
			if (this.mActionItemProperty.EndsWith("_alt1"))
			{
				int num2 = this.mActionItemProperty.IndexOf("_alt1");
				if (num2 > 0)
				{
					text = this.mActionItemProperty.Substring(0, num2);
				}
			}
			if (this.IsAddDirectionAttribute)
			{
				BlueStacksUIBinding.Bind(this.mKeyPropertyName, string.Concat(new object[]
				{
					Constants.ImapLocaleStringsConstant,
					action.Type,
					"_",
					text,
					action.Direction
				}));
			}
			else
			{
				BlueStacksUIBinding.Bind(this.mKeyPropertyName, string.Concat(new object[]
				{
					Constants.ImapLocaleStringsConstant,
					action.Type,
					"_",
					text
				}));
			}
			this.mKeyTextBox.Tag = action[this.ActionItemProperty];
			BlueStacksUIBinding.Bind(this.mKeyTextBox, KMManager.GetStringsToShowInUI(action[this.ActionItemProperty].ToString()));
			if (action[this.ActionItemProperty].ToString().Contains("Gamepad"))
			{
				this.mKeyTextBox.ToolTip = this.mKeyTextBox.Text;
				return true;
			}
			return false;
		}

		// Token: 0x06000998 RID: 2456 RVA: 0x00007F68 File Offset: 0x00006168
		private void KeyTextBox_TextChanged(object sender, TextChangedEventArgs e)
		{
			this.SetValueHandling();
		}

		// Token: 0x06000999 RID: 2457 RVA: 0x00043958 File Offset: 0x00041B58
		private void SetValueHandling()
		{
			string text = this.lstActionItem[0][this.ActionItemProperty].ToString();
			if (this.PropertyType.Equals(typeof(double)))
			{
				double num;
				if (double.TryParse(this.mKeyTextBox.Text, out num))
				{
					text = this.mKeyTextBox.Text;
				}
				else if (!string.IsNullOrEmpty(this.mKeyTextBox.Text))
				{
					this.mKeyTextBox.Text = text;
				}
			}
			else if (this.PropertyType.Equals(typeof(int)))
			{
				int num2;
				if (int.TryParse(this.mKeyTextBox.Text, out num2))
				{
					text = this.mKeyTextBox.Text;
				}
				else if (!string.IsNullOrEmpty(this.mKeyTextBox.Text))
				{
					this.mKeyTextBox.Text = text;
				}
			}
			else if (this.PropertyType.Equals(typeof(bool)))
			{
				text = this.mKeyTextBox.Tag.ToString();
			}
			else if (this.ActionItemProperty.StartsWith("Key") || this.ActionItemProperty.StartsWith("Gamepad"))
			{
				text = this.mKeyTextBox.Tag.ToString();
			}
			else
			{
				text = this.mKeyTextBox.Text;
			}
			this.Setvalue(text);
		}

		// Token: 0x0600099A RID: 2458 RVA: 0x00043AB4 File Offset: 0x00041CB4
		internal void Setvalue(string value)
		{
			foreach (IMAction imaction in this.lstActionItem)
			{
				if (imaction[this.ActionItemProperty].ToString().Contains("Gamepad"))
				{
					this.mKeyTextBox.ToolTip = this.mKeyTextBox.Text.ToUpper();
				}
				if (!imaction[this.ActionItemProperty].ToString().Equals(value))
				{
					imaction[this.ActionItemProperty] = value;
					KeymapCanvasWindow.sIsDirty = true;
				}
			}
			if (this.ActionItemProperty.StartsWith("Key"))
			{
				this.mKeyTextBox.Text = this.mKeyTextBox.Text.ToUpper();
			}
			if (this.ActionItemProperty.Contains("Gamepad"))
			{
				this.mKeyTextBox.Text = this.mKeyTextBox.Text.ToUpper();
				this.mKeyTextBox.ToolTip = this.mKeyTextBox.Text.ToUpper();
			}
		}

		// Token: 0x0600099B RID: 2459 RVA: 0x00043BDC File Offset: 0x00041DDC
		private void KeyPropertyNameTextBox_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (!this.mKeyPropertyNameTextBox.IsVisible)
			{
				string key = this.ActionItemProperty;
				if (this.ActionItemProperty.EndsWith("_alt1"))
				{
					int num = this.ActionItemProperty.IndexOf("_alt1");
					if (num > 0)
					{
						key = this.ActionItemProperty.Substring(0, num);
					}
				}
				if (LocaleStrings.GetLocalizedString("STRING_ENTER_GUIDANCE_TEXT", false).Equals(this.mKeyPropertyNameTextBox.Text) || string.IsNullOrEmpty(this.mKeyPropertyNameTextBox.Text))
				{
					using (List<IMAction>.Enumerator enumerator = this.lstActionItem.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							IMAction imaction = enumerator.Current;
							imaction.Guidance.Remove(key);
						}
						return;
					}
				}
				KeymapCanvasWindow.sIsDirty = true;
				foreach (IMAction imaction2 in this.lstActionItem)
				{
					imaction2.Guidance[key] = this.mKeyPropertyNameTextBox.Text;
				}
				this.ParentWindow.SelectedConfig.AddString(this.mKeyPropertyNameTextBox.Text);
			}
		}

		// Token: 0x0600099C RID: 2460 RVA: 0x00043D20 File Offset: 0x00041F20
		private void KeyTextBox_LostFocus(object sender, RoutedEventArgs e)
		{
			double num;
			if (this.PropertyType.Equals(typeof(double)) && !double.TryParse(this.mKeyTextBox.Text, out num))
			{
				this.Setvalue("0");
				this.mKeyTextBox.Text = "0";
			}
			int num2;
			if (this.PropertyType.Equals(typeof(int)) && !int.TryParse(this.mKeyTextBox.Text, out num2))
			{
				this.Setvalue("0");
				this.mKeyTextBox.Text = "0";
			}
		}

		// Token: 0x0600099D RID: 2461 RVA: 0x00043DBC File Offset: 0x00041FBC
		private void KeyPropertyNameTextBox_GotFocus(object sender, RoutedEventArgs e)
		{
			if (LocaleStrings.GetLocalizedString("STRING_ENTER_GUIDANCE_TEXT", false).Equals(this.mKeyPropertyNameTextBox.Text))
			{
				this.mKeyPropertyNameTextBox.Text = "";
				this.mKeyPropertyNameTextBox.FontStyle = FontStyles.Normal;
				this.mKeyPropertyNameTextBox.FontWeight = FontWeights.Normal;
				BlueStacksUIBinding.BindColor(this.mKeyPropertyNameTextBox, Control.ForegroundProperty, "DualTextBlockForeground");
			}
		}

		// Token: 0x0600099E RID: 2462 RVA: 0x00043E2C File Offset: 0x0004202C
		private void KeyPropertyNameTextBox_LostFocus(object sender, RoutedEventArgs e)
		{
			if (string.IsNullOrEmpty(this.mKeyPropertyNameTextBox.Text))
			{
				this.mKeyPropertyNameTextBox.Text = LocaleStrings.GetLocalizedString("STRING_ENTER_GUIDANCE_TEXT", false);
				this.mKeyPropertyNameTextBox.FontStyle = FontStyles.Italic;
				this.mKeyPropertyNameTextBox.FontWeight = FontWeights.ExtraLight;
				BlueStacksUIBinding.BindColor(this.mKeyPropertyNameTextBox, Control.ForegroundProperty, "DualTextBlockLightForegroundColor");
			}
		}

		// Token: 0x0600099F RID: 2463 RVA: 0x00004BF2 File Offset: 0x00002DF2
		private void mKeyTextBox_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
		}

		// Token: 0x060009A0 RID: 2464 RVA: 0x00007F70 File Offset: 0x00006170
		private void KeyTextBox_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			bool isVisible = this.mKeyTextBox.IsVisible;
		}

		// Token: 0x060009A1 RID: 2465 RVA: 0x00007F7E File Offset: 0x0000617E
		private void mKeyTextBox_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			if (base.IsLoaded)
			{
				KMManager.sGamepadDualTextbox = this;
				KMManager.pressedGamepadKeyList.Clear();
				KMManager.CallGamepadHandler("true");
			}
		}

		// Token: 0x060009A2 RID: 2466 RVA: 0x00043E98 File Offset: 0x00042098
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/dualtextblockcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060009A3 RID: 2467 RVA: 0x00043EC8 File Offset: 0x000420C8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mValueColumn = (ColumnDefinition)target;
				return;
			case 2:
				this.mKeyPropertyName = (TextBox)target;
				this.mKeyPropertyName.TextChanged += this.KeyPropertyNameTextBox_TextChanged;
				this.mKeyPropertyName.IsVisibleChanged += this.KeyPropertyNameTextBox_IsVisibleChanged;
				return;
			case 3:
				this.mKeyTextBox = (TextBox)target;
				this.mKeyTextBox.PreviewMouseDown += this.KeyTextBox_MouseDown;
				this.mKeyTextBox.PreviewMouseLeftButtonDown += this.mKeyTextBox_PreviewMouseLeftButtonDown;
				this.mKeyTextBox.TextChanged += this.KeyTextBox_TextChanged;
				this.mKeyTextBox.PreviewKeyDown += this.KeyTextBox_KeyDown;
				this.mKeyTextBox.KeyUp += this.KeyTextBox_KeyUp;
				this.mKeyTextBox.LostFocus += this.KeyTextBox_LostFocus;
				this.mKeyTextBox.IsVisibleChanged += this.KeyTextBox_IsVisibleChanged;
				return;
			case 4:
				this.mKeyPropertyNameTextBox = (TextBox)target;
				this.mKeyPropertyNameTextBox.GotFocus += this.KeyPropertyNameTextBox_GotFocus;
				this.mKeyPropertyNameTextBox.LostFocus += this.KeyPropertyNameTextBox_LostFocus;
				this.mKeyPropertyNameTextBox.TextChanged += this.KeyPropertyNameTextBox_TextChanged;
				this.mKeyPropertyNameTextBox.IsVisibleChanged += this.KeyPropertyNameTextBox_IsVisibleChanged;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040006EB RID: 1771
		private List<IMAction> lstActionItem = new List<IMAction>();

		// Token: 0x040006EC RID: 1772
		private MainWindow ParentWindow;

		// Token: 0x040006ED RID: 1773
		private List<Key> mKeyList = new List<Key>();

		// Token: 0x040006EE RID: 1774
		private string mActionItemProperty;

		// Token: 0x040006EF RID: 1775
		private Type PropertyType;

		// Token: 0x040006F0 RID: 1776
		internal bool IsAddDirectionAttribute;

		// Token: 0x040006F1 RID: 1777
		internal ColumnDefinition mValueColumn;

		// Token: 0x040006F2 RID: 1778
		internal TextBox mKeyPropertyName;

		// Token: 0x040006F3 RID: 1779
		internal TextBox mKeyTextBox;

		// Token: 0x040006F4 RID: 1780
		internal TextBox mKeyPropertyNameTextBox;

		// Token: 0x040006F5 RID: 1781
		private bool _contentLoaded;
	}
}
