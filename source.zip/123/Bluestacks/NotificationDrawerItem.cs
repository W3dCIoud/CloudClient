﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000084 RID: 132
	public class NotificationDrawerItem : UserControl, IComponentConnector
	{
		// Token: 0x060005DC RID: 1500 RVA: 0x00005CA8 File Offset: 0x00003EA8
		public NotificationDrawerItem()
		{
			this.InitializeComponent();
		}

		// Token: 0x060005DD RID: 1501 RVA: 0x00025238 File Offset: 0x00023438
		internal void InitFromGenricNotificationItem(GenericNotificationItem item, MainWindow parentWin)
		{
			this.ParentWindow = parentWin;
			this.Id = item.Id;
			this.titleText.Text = item.Title;
			this.messageText.Text = item.Message;
			if (!item.IsRead)
			{
				this.ChangeToUnreadBackground();
			}
			else
			{
				this.ChangeToReadBackground();
			}
			if (!string.IsNullOrEmpty(item.NotificationMenuImageName) && !string.IsNullOrEmpty(item.NotificationMenuImageUrl) && !File.Exists(Path.Combine(RegistryStrings.PromotionDirectory, item.NotificationMenuImageName)))
			{
				item.NotificationMenuImageName = Utils.TinyDownloader(item.NotificationMenuImageUrl, item.NotificationMenuImageName, RegistryStrings.PromotionDirectory, false);
			}
			this.icon.ImageName = item.NotificationMenuImageName;
			this.dateText.Text = DateTimeHelper.GetReadableDateTimeString(item.CreationTime);
		}

		// Token: 0x060005DE RID: 1502 RVA: 0x00025308 File Offset: 0x00023508
		private void UserControl_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mCloseBtn.IsMouseOver)
			{
				this.ParentWindow.mTopBar.mNotificationCentrePopup.IsOpen = false;
				NotificationDrawer mNotificationDrawerControl = this.ParentWindow.mTopBar.mNotificationDrawerControl;
				GenericNotificationManager instance = GenericNotificationManager.Instance;
				List<string> list = new List<string>();
				list.Add(this.Id);
				mNotificationDrawerControl.Populate(instance.MarkNotification(list, delegate(GenericNotificationItem x)
				{
					x.IsDeleted = true;
				}));
				this.ParentWindow.mTopBar.mNotificationCentrePopup.IsOpen = true;
				this.ParentWindow.mTopBar.RefreshNotificationCentreButton();
				return;
			}
			if (this.ParentWindow != null && this.ParentWindow.mGuestBootCompleted)
			{
				GenericNotificationItem notificationItem = GenericNotificationManager.Instance.GetNotificationItem(this.Id);
				if (notificationItem != null)
				{
					this.ParentWindow.Utils.HandleGenericActionFromDictionary(notificationItem.ExtraPayload, "notification_drawer", notificationItem.NotificationMenuImageName);
					ClientStats.SendMiscellaneousStatsAsync("NotificationDrawerItemClicked", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, notificationItem.Id, notificationItem.Title, JsonConvert.SerializeObject(notificationItem.ExtraPayload), null, null, null);
					GenericNotificationManager instance2 = GenericNotificationManager.Instance;
					List<string> list2 = new List<string>();
					list2.Add(notificationItem.Id);
					instance2.MarkNotification(list2, delegate(GenericNotificationItem x)
					{
						x.IsRead = true;
					});
					this.ChangeToReadBackground();
					this.ParentWindow.mTopBar.RefreshNotificationCentreButton();
				}
			}
		}

		// Token: 0x060005DF RID: 1503 RVA: 0x00005CB6 File Offset: 0x00003EB6
		internal void ChangeToUnreadBackground()
		{
			base.Background = Brushes.Transparent;
		}

		// Token: 0x060005E0 RID: 1504 RVA: 0x00005CC3 File Offset: 0x00003EC3
		internal void ChangeToReadBackground()
		{
			base.Opacity = 0.5;
			base.Background = Brushes.Transparent;
		}

		// Token: 0x060005E1 RID: 1505 RVA: 0x00005CDF File Offset: 0x00003EDF
		private void UserControl_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mCloseBtn.Visibility = Visibility.Visible;
			BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x060005E2 RID: 1506 RVA: 0x00005CFD File Offset: 0x00003EFD
		private void UserControl_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mCloseBtn.Visibility = Visibility.Hidden;
			if (!GenericNotificationManager.Instance.GetNotificationItem(this.Id).IsRead)
			{
				this.ChangeToUnreadBackground();
				return;
			}
			this.ChangeToReadBackground();
		}

		// Token: 0x060005E3 RID: 1507 RVA: 0x00025490 File Offset: 0x00023690
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/genericnotification/notificationdraweritem.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060005E4 RID: 1508 RVA: 0x000254C0 File Offset: 0x000236C0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((NotificationDrawerItem)target).MouseLeftButtonUp += this.UserControl_MouseLeftButtonUp;
				((NotificationDrawerItem)target).MouseEnter += this.UserControl_MouseEnter;
				((NotificationDrawerItem)target).MouseLeave += this.UserControl_MouseLeave;
				return;
			case 2:
				this.icon = (CustomPictureBox)target;
				return;
			case 3:
				this.titleText = (TextBlock)target;
				return;
			case 4:
				this.dateText = (TextBlock)target;
				return;
			case 5:
				this.messageText = (TextBlock)target;
				return;
			case 6:
				this.mCloseBtn = (CustomPictureBox)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040003AB RID: 939
		internal string Id;

		// Token: 0x040003AC RID: 940
		private MainWindow ParentWindow;

		// Token: 0x040003AD RID: 941
		internal CustomPictureBox icon;

		// Token: 0x040003AE RID: 942
		internal TextBlock titleText;

		// Token: 0x040003AF RID: 943
		internal TextBlock dateText;

		// Token: 0x040003B0 RID: 944
		internal TextBlock messageText;

		// Token: 0x040003B1 RID: 945
		internal CustomPictureBox mCloseBtn;

		// Token: 0x040003B2 RID: 946
		private bool _contentLoaded;
	}
}
