﻿using System;
using System.Collections.Generic;

// Token: 0x02000022 RID: 34
public class ShowImagesOnOverlay
{
	// Token: 0x040000F7 RID: 247
	public static List<string> mListShowImagesForKeys = new List<string>
	{
		"MouseLButton",
		"MouseRButton",
		"MouseMButton",
		"Space",
		"Left",
		"Up",
		"Right",
		"Down"
	};
}
