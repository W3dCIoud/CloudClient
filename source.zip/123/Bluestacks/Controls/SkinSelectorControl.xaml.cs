﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI.Controls
{
	// Token: 0x02000240 RID: 576
	public partial class SkinSelectorControl : UserControl
	{
		// Token: 0x060013EA RID: 5098 RVA: 0x0000E148 File Offset: 0x0000C348
		public SkinSelectorControl()
		{
			this.InitializeComponent();
		}
	}
}
