﻿using System;
using System.ComponentModel;
using System.Windows.Input;

// Token: 0x02000003 RID: 3
[Description("Independent")]
[Serializable]
public class FreeLook : IMAction
{
	// Token: 0x1700000C RID: 12
	// (get) Token: 0x0600001B RID: 27 RVA: 0x000021B5 File Offset: 0x000003B5
	// (set) Token: 0x0600001C RID: 28 RVA: 0x000021BD File Offset: 0x000003BD
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X
	{
		get
		{
			return this.mX;
		}
		set
		{
			this.mX = value;
		}
	}

	// Token: 0x1700000D RID: 13
	// (get) Token: 0x0600001D RID: 29 RVA: 0x000021C6 File Offset: 0x000003C6
	// (set) Token: 0x0600001E RID: 30 RVA: 0x000021CE File Offset: 0x000003CE
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y
	{
		get
		{
			return this.mY;
		}
		set
		{
			this.mY = value;
		}
	}

	// Token: 0x1700000E RID: 14
	// (get) Token: 0x0600001F RID: 31 RVA: 0x000021D7 File Offset: 0x000003D7
	// (set) Token: 0x06000020 RID: 32 RVA: 0x000021DF File Offset: 0x000003DF
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key
	{
		get
		{
			return this.mKey;
		}
		set
		{
			this.mKey = value;
		}
	}

	// Token: 0x1700000F RID: 15
	// (get) Token: 0x06000021 RID: 33 RVA: 0x000021E8 File Offset: 0x000003E8
	// (set) Token: 0x06000022 RID: 34 RVA: 0x000021F0 File Offset: 0x000003F0
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key_alt1
	{
		get
		{
			return this.mKey_alt1;
		}
		set
		{
			this.mKey_alt1 = value;
		}
	}

	// Token: 0x17000010 RID: 16
	// (get) Token: 0x06000023 RID: 35 RVA: 0x000021F9 File Offset: 0x000003F9
	// (set) Token: 0x06000024 RID: 36 RVA: 0x00002201 File Offset: 0x00000401
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyLeft
	{
		get
		{
			return this.mKeyLeft;
		}
		set
		{
			this.mKeyLeft = value;
		}
	}

	// Token: 0x17000011 RID: 17
	// (get) Token: 0x06000025 RID: 37 RVA: 0x0000220A File Offset: 0x0000040A
	// (set) Token: 0x06000026 RID: 38 RVA: 0x00002212 File Offset: 0x00000412
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyLeft_alt1
	{
		get
		{
			return this.mKeyLeft_alt1;
		}
		set
		{
			this.mKeyLeft_alt1 = value;
		}
	}

	// Token: 0x17000012 RID: 18
	// (get) Token: 0x06000027 RID: 39 RVA: 0x0000221B File Offset: 0x0000041B
	// (set) Token: 0x06000028 RID: 40 RVA: 0x00002223 File Offset: 0x00000423
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyRight
	{
		get
		{
			return this.mKeyRight;
		}
		set
		{
			this.mKeyRight = value;
		}
	}

	// Token: 0x17000013 RID: 19
	// (get) Token: 0x06000029 RID: 41 RVA: 0x0000222C File Offset: 0x0000042C
	// (set) Token: 0x0600002A RID: 42 RVA: 0x00002234 File Offset: 0x00000434
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyRight_alt1
	{
		get
		{
			return this.mKeyRight_alt1;
		}
		set
		{
			this.mKeyRight_alt1 = value;
		}
	}

	// Token: 0x17000014 RID: 20
	// (get) Token: 0x0600002B RID: 43 RVA: 0x0000223D File Offset: 0x0000043D
	// (set) Token: 0x0600002C RID: 44 RVA: 0x00002245 File Offset: 0x00000445
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyUp
	{
		get
		{
			return this.mKeyUp;
		}
		set
		{
			this.mKeyUp = value;
		}
	}

	// Token: 0x17000015 RID: 21
	// (get) Token: 0x0600002D RID: 45 RVA: 0x0000224E File Offset: 0x0000044E
	// (set) Token: 0x0600002E RID: 46 RVA: 0x00002256 File Offset: 0x00000456
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyUp_alt1
	{
		get
		{
			return this.mKeyUp_alt1;
		}
		set
		{
			this.mKeyUp_alt1 = value;
		}
	}

	// Token: 0x17000016 RID: 22
	// (get) Token: 0x0600002F RID: 47 RVA: 0x0000225F File Offset: 0x0000045F
	// (set) Token: 0x06000030 RID: 48 RVA: 0x00002267 File Offset: 0x00000467
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyDown
	{
		get
		{
			return this.mKeyDown;
		}
		set
		{
			this.mKeyDown = value;
		}
	}

	// Token: 0x17000017 RID: 23
	// (get) Token: 0x06000031 RID: 49 RVA: 0x00002270 File Offset: 0x00000470
	// (set) Token: 0x06000032 RID: 50 RVA: 0x00002278 File Offset: 0x00000478
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyDown_alt1
	{
		get
		{
			return this.mKeyDown_alt1;
		}
		set
		{
			this.mKeyDown_alt1 = value;
		}
	}

	// Token: 0x17000018 RID: 24
	// (get) Token: 0x06000033 RID: 51 RVA: 0x00002281 File Offset: 0x00000481
	// (set) Token: 0x06000034 RID: 52 RVA: 0x00002289 File Offset: 0x00000489
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int DeviceType
	{
		get
		{
			return this.mDeviceType;
		}
		set
		{
			this.mDeviceType = value;
		}
	}

	// Token: 0x17000019 RID: 25
	// (get) Token: 0x06000035 RID: 53 RVA: 0x00002292 File Offset: 0x00000492
	// (set) Token: 0x06000036 RID: 54 RVA: 0x0000229A File Offset: 0x0000049A
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool ShowOnOverlay
	{
		get
		{
			return this.mShowOnOverlay;
		}
		set
		{
			this.mShowOnOverlay = value;
		}
	}

	// Token: 0x1700001A RID: 26
	// (get) Token: 0x06000037 RID: 55 RVA: 0x000022A3 File Offset: 0x000004A3
	// (set) Token: 0x06000038 RID: 56 RVA: 0x000022AB File Offset: 0x000004AB
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Sensitivity
	{
		get
		{
			return this.mSensitivity;
		}
		set
		{
			this.mSensitivity = value;
		}
	}

	// Token: 0x1700001B RID: 27
	// (get) Token: 0x06000039 RID: 57 RVA: 0x000022B4 File Offset: 0x000004B4
	// (set) Token: 0x0600003A RID: 58 RVA: 0x000022BC File Offset: 0x000004BC
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Speed
	{
		get
		{
			return this.mSpeed;
		}
		set
		{
			this.mSpeed = value;
		}
	}

	// Token: 0x1700001C RID: 28
	// (get) Token: 0x0600003B RID: 59 RVA: 0x000022C5 File Offset: 0x000004C5
	// (set) Token: 0x0600003C RID: 60 RVA: 0x000022CD File Offset: 0x000004CD
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool MouseAcceleration
	{
		get
		{
			return this.mMouseAcceleration;
		}
		set
		{
			this.mMouseAcceleration = value;
		}
	}

	// Token: 0x1700001D RID: 29
	// (get) Token: 0x0600003D RID: 61 RVA: 0x000022D6 File Offset: 0x000004D6
	// (set) Token: 0x0600003E RID: 62 RVA: 0x000022DE File Offset: 0x000004DE
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int Delay
	{
		get
		{
			return this.mDelay;
		}
		set
		{
			this.mDelay = value;
		}
	}

	// Token: 0x04000011 RID: 17
	private double mX = -1.0;

	// Token: 0x04000012 RID: 18
	private double mY = -1.0;

	// Token: 0x04000013 RID: 19
	private string mKey = IMAPKeys.GetStringForFile(System.Windows.Input.Key.V);

	// Token: 0x04000014 RID: 20
	private string mKey_alt1 = string.Empty;

	// Token: 0x04000015 RID: 21
	private string mKeyLeft = IMAPKeys.GetStringForFile(System.Windows.Input.Key.Left);

	// Token: 0x04000016 RID: 22
	private string mKeyLeft_alt1 = string.Empty;

	// Token: 0x04000017 RID: 23
	private string mKeyRight = IMAPKeys.GetStringForFile(System.Windows.Input.Key.Right);

	// Token: 0x04000018 RID: 24
	private string mKeyRight_alt1 = string.Empty;

	// Token: 0x04000019 RID: 25
	private string mKeyUp = IMAPKeys.GetStringForFile(System.Windows.Input.Key.Up);

	// Token: 0x0400001A RID: 26
	private string mKeyUp_alt1 = string.Empty;

	// Token: 0x0400001B RID: 27
	private string mKeyDown = IMAPKeys.GetStringForFile(System.Windows.Input.Key.Down);

	// Token: 0x0400001C RID: 28
	private string mKeyDown_alt1 = string.Empty;

	// Token: 0x0400001D RID: 29
	private int mDeviceType;

	// Token: 0x0400001E RID: 30
	internal bool mShowOnOverlay = true;

	// Token: 0x0400001F RID: 31
	private double mSensitivity = 1.0;

	// Token: 0x04000020 RID: 32
	private double mSpeed = 20.0;

	// Token: 0x04000021 RID: 33
	private bool mMouseAcceleration;

	// Token: 0x04000022 RID: 34
	private int mDelay = 50;
}
