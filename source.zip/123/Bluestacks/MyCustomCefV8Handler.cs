﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using BlueStacks.BlueStacksUI.BTv;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Xilium.CefGlue;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001A4 RID: 420
	internal class MyCustomCefV8Handler : CefV8Handler
	{
		// Token: 0x06000F3D RID: 3901 RVA: 0x0000B502 File Offset: 0x00009702
		protected override bool Execute(string name, CefV8Value obj, CefV8Value[] arguments, out CefV8Value returnValue, out string exception)
		{
			returnValue = CefV8Value.CreateString("");
			this.ReceiveJsFunctionCall(arguments, ref returnValue);
			exception = null;
			return true;
		}

		// Token: 0x06000F3E RID: 3902 RVA: 0x00060BA0 File Offset: 0x0005EDA0
		private void ReceiveJsFunctionCall(CefV8Value[] arguments, ref CefV8Value returnValue)
		{
			JObject jobject = JObject.Parse(arguments[0].GetStringValue());
			string text = jobject["data"].ToString();
			if (string.IsNullOrEmpty(text) || text.Equals("null", StringComparison.InvariantCultureIgnoreCase))
			{
				text = "[]";
			}
			JArray jarray = JArray.Parse(text);
			object[] array = null;
			if (!jarray.IsNullOrEmpty())
			{
				array = new object[jarray.Count];
				for (int i = 0; i < jarray.Count; i++)
				{
					array[i] = jarray[i].ToString();
				}
			}
			try
			{
				try
				{
					if (jobject.ContainsKey("callbackFunction"))
					{
						this.mCallBackFunction = jobject["callbackFunction"].ToString();
					}
				}
				catch
				{
					Logger.Info("Error in callback function name.");
				}
				if (jobject["calledFunction"].ToString().IndexOf("LogInfo") == -1)
				{
					Logger.Debug("Calling function from GM API.." + jobject["calledFunction"].ToString());
				}
				jobject["calledFunction"].ToString();
				object obj;
				try
				{
					Type[] typeArray = Type.GetTypeArray(array);
					obj = base.GetType().GetMethod(jobject["calledFunction"].ToString(), typeArray).Invoke(this, array);
				}
				catch (Exception)
				{
					obj = base.GetType().GetMethod(jobject["calledFunction"].ToString()).Invoke(this, array);
				}
				if (obj != null)
				{
					returnValue = CefV8Value.CreateString((string)obj);
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Error in ReceiveJSFunctionCall: " + ex.ToString());
			}
		}

		// Token: 0x06000F3F RID: 3903 RVA: 0x00060D58 File Offset: 0x0005EF58
		public string isBTVInstalled()
		{
			if (!BTVManager.IsBTVInstalled())
			{
				CefProcessMessage cefProcessMessage = CefProcessMessage.Create("DownloadBTV");
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
				return "false";
			}
			if (!BTVManager.IsDirectXComponentsInstalled())
			{
				CefProcessMessage cefProcessMessage2 = CefProcessMessage.Create("DownloadDirectX");
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage2);
				return "false";
			}
			return "true";
		}

		// Token: 0x06000F40 RID: 3904 RVA: 0x00060DC0 File Offset: 0x0005EFC0
		public void sendFirebaseNotification(string data)
		{
			Logger.Debug("Got call for sendFirebaseNotification");
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("sendFirebaseNotification");
			cefProcessMessage.Arguments.SetString(0, data);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F41 RID: 3905 RVA: 0x00060E04 File Offset: 0x0005F004
		public void subscribeModule(string tag)
		{
			Logger.Info("Subscribe html module");
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("subscribeModule");
			cefProcessMessage.Arguments.SetString(0, tag);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F42 RID: 3906 RVA: 0x00060E48 File Offset: 0x0005F048
		public void UnsubscribeModule(string tag)
		{
			Logger.Info("Unsubscribe html module");
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("unsubscribeModule");
			cefProcessMessage.Arguments.SetString(0, tag);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F43 RID: 3907 RVA: 0x00060E8C File Offset: 0x0005F08C
		public void HandleClick(string json)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("HandleClick");
			cefProcessMessage.Arguments.SetString(0, json);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F44 RID: 3908 RVA: 0x00060EC4 File Offset: 0x0005F0C4
		public void UpdateQuestRules(string json)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("UpdateQuestRules");
			cefProcessMessage.Arguments.SetString(0, json);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F45 RID: 3909 RVA: 0x00060EFC File Offset: 0x0005F0FC
		public void pikaworldprofileadded(string profileId)
		{
			Logger.Debug("Got call for PikaWorldProfileAdded");
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("PikaWorldProfileAdded");
			cefProcessMessage.Arguments.SetString(0, profileId);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F46 RID: 3910 RVA: 0x0000B51F File Offset: 0x0000971F
		public string getPikaWorldUserId()
		{
			return RegistryManager.Instance.PikaWorldId;
		}

		// Token: 0x06000F47 RID: 3911 RVA: 0x00060F40 File Offset: 0x0005F140
		public void getGamepadConnectionStatus()
		{
			Logger.Debug("Got call for getGamepadConnectionStatus");
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("GetGamepadConnectionStatus");
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F48 RID: 3912 RVA: 0x00060F74 File Offset: 0x0005F174
		public string IsAnyAppRunning()
		{
			string text = "isAnyAppRunning";
			string result;
			try
			{
				result = HTTPUtils.SendRequestToClient(text, null, "Android", 0, null, false, 1, 0).ToLower();
			}
			catch (Exception ex)
			{
				Logger.Error("An unexpected error occured in {0}. Err: {1}", new object[]
				{
					text,
					ex.ToString()
				});
				result = null;
			}
			return result;
		}

		// Token: 0x06000F49 RID: 3913 RVA: 0x00060FD4 File Offset: 0x0005F1D4
		public void goToMapsTab()
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("GoToMapsTab");
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F4A RID: 3914 RVA: 0x00061000 File Offset: 0x0005F200
		public void clearmapsnotification()
		{
			Logger.Info("Got call from browser for maps clear notification");
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("ClearMapsNotification");
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F4B RID: 3915 RVA: 0x00061034 File Offset: 0x0005F234
		public void installapp(string appIcon, string appName, string apkUrl, string packageName)
		{
			Logger.Info("Get Call from browser of Install App :" + appName);
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("InstallApp");
			CefListValue arguments = cefProcessMessage.Arguments;
			arguments.SetString(0, appIcon);
			arguments.SetString(1, appName);
			arguments.SetString(2, apkUrl);
			arguments.SetString(3, packageName);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F4C RID: 3916 RVA: 0x00061098 File Offset: 0x0005F298
		public string installapp(string appIcon, string appName, string apkUrl, string packageName, string timestamp)
		{
			Logger.Info("Get Call from browser of Install App with version :" + appName);
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("InstallAppVersion");
			CefListValue arguments = cefProcessMessage.Arguments;
			arguments.SetString(0, appIcon);
			arguments.SetString(1, appName);
			arguments.SetString(2, apkUrl);
			arguments.SetString(3, packageName);
			arguments.SetString(4, timestamp);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
			return "true";
		}

		// Token: 0x06000F4D RID: 3917 RVA: 0x0006110C File Offset: 0x0005F30C
		public void installapp_google(string appIcon, string appName, string apkUrl, string packageName)
		{
			Logger.Info("Get Call from browser of Install App from googleplay :" + appName);
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("InstallAppGooglePlay");
			CefListValue arguments = cefProcessMessage.Arguments;
			arguments.SetString(0, appIcon);
			arguments.SetString(1, appName);
			arguments.SetString(2, apkUrl);
			arguments.SetString(3, packageName);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F4E RID: 3918 RVA: 0x00061170 File Offset: 0x0005F370
		public void checkifpremium(string isPremium)
		{
			Logger.Info("Got call from blocker ad browser of premium subscription");
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("CheckIfPremium");
			cefProcessMessage.Arguments.SetString(0, isPremium);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F4F RID: 3919 RVA: 0x000611B4 File Offset: 0x0005F3B4
		public void applyTheme(string themeName)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("ApplyThemeName");
			cefProcessMessage.Arguments.SetString(0, themeName);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F50 RID: 3920 RVA: 0x0000B52B File Offset: 0x0000972B
		public List<string> getsupportedactiontypes()
		{
			return Enum.GetNames(typeof(GenericAction)).ToList<string>();
		}

		// Token: 0x06000F51 RID: 3921 RVA: 0x000611EC File Offset: 0x0005F3EC
		public void getimpressionid(string impressionId)
		{
			Logger.Info("Get call from browser of impression_id :" + impressionId);
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("GetImpressionId");
			cefProcessMessage.Arguments.SetString(0, impressionId);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
			cefProcessMessage.Dispose();
		}

		// Token: 0x06000F52 RID: 3922 RVA: 0x0006123C File Offset: 0x0005F43C
		public string installedapps()
		{
			List<AppInfo> list = new JsonParser("Android").GetAppList().ToList<AppInfo>();
			new List<string>();
			string text = string.Empty;
			foreach (AppInfo appInfo in list)
			{
				text = text + appInfo.package + ",";
			}
			return text;
		}

		// Token: 0x06000F53 RID: 3923 RVA: 0x000612B8 File Offset: 0x0005F4B8
		public void openapp(string appIcon, string appName, string apkUrl, string packageName)
		{
			Logger.Info("Get Call from browser of open App :" + appName);
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("InstallApp");
			CefListValue arguments = cefProcessMessage.Arguments;
			arguments.SetString(0, appIcon);
			arguments.SetString(1, appName);
			arguments.SetString(2, apkUrl);
			arguments.SetString(3, packageName);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F54 RID: 3924 RVA: 0x0006131C File Offset: 0x0005F51C
		public void showdetails(string url)
		{
			CefBrowser browser = CefV8Context.GetCurrentContext().GetBrowser();
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create(url);
			browser.SendProcessMessage(0, cefProcessMessage);
			cefProcessMessage.Dispose();
		}

		// Token: 0x06000F55 RID: 3925 RVA: 0x00061348 File Offset: 0x0005F548
		public void searchappcenter(string searchString)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("SearchAppcenter");
			cefProcessMessage.Arguments.SetString(0, searchString);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F56 RID: 3926 RVA: 0x00004BF2 File Offset: 0x00002DF2
		public void browser2Client()
		{
		}

		// Token: 0x06000F57 RID: 3927 RVA: 0x0000B541 File Offset: 0x00009741
		public string getguid()
		{
			return RegistryManager.Instance.UserGuid;
		}

		// Token: 0x06000F58 RID: 3928 RVA: 0x0000B541 File Offset: 0x00009741
		public string GetUserGUID()
		{
			return RegistryManager.Instance.UserGuid;
		}

		// Token: 0x06000F59 RID: 3929 RVA: 0x00061380 File Offset: 0x0005F580
		public void feedback(string email, string appName, string description, string downloadURl)
		{
			string clientVersion = RegistryManager.Instance.ClientVersion;
			description = description.Replace("&", " ");
			description += "\n From Client VER=";
			description += clientVersion;
			string text = string.Concat(new string[]
			{
				"-startwithparam \"",
				email,
				"&Others&",
				appName,
				"&",
				description,
				"&",
				downloadURl,
				"\""
			});
			Process process = new Process();
			process.StartInfo.FileName = Path.Combine(RegistryStrings.InstallDir, "HD-LogCollector.exe");
			Logger.Info("The arguments being passed to log collector is :{0}", new object[]
			{
				text
			});
			process.StartInfo.Arguments = text;
			process.Start();
		}

		// Token: 0x06000F5A RID: 3930 RVA: 0x00061450 File Offset: 0x0005F650
		public void openLogCollector()
		{
			string installDir = RegistryStrings.InstallDir;
			Process process = new Process();
			process.StartInfo.FileName = Path.Combine(installDir, "HD-LogCollector.exe");
			Logger.Info("Open log collector through gmApi from dir: " + installDir);
			process.Start();
		}

		// Token: 0x06000F5B RID: 3931 RVA: 0x00061494 File Offset: 0x0005F694
		public void closesearch()
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("CloseSearch");
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F5C RID: 3932 RVA: 0x000614C0 File Offset: 0x0005F6C0
		public void refresh_search()
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("RefreshSearch");
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F5D RID: 3933 RVA: 0x000614EC File Offset: 0x0005F6EC
		public void refresh_search(string searchString)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("RefreshSearch");
			cefProcessMessage.Arguments.SetString(0, searchString);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F5E RID: 3934 RVA: 0x00061524 File Offset: 0x0005F724
		public void google_search(string searchString)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("GoogleSearch");
			cefProcessMessage.Arguments.SetString(0, searchString);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F5F RID: 3935 RVA: 0x0006155C File Offset: 0x0005F75C
		public string getusertoken()
		{
			return new JObject
			{
				{
					"email",
					RegistryManager.Instance.RegisteredEmail
				},
				{
					"token",
					RegistryManager.Instance.Token
				}
			}.ToString(Formatting.None, new JsonConverter[0]);
		}

		// Token: 0x06000F60 RID: 3936 RVA: 0x00004BF2 File Offset: 0x00002DF2
		public void preinstallapp()
		{
		}

		// Token: 0x06000F61 RID: 3937 RVA: 0x0000B54D File Offset: 0x0000974D
		public void openurl(string url)
		{
			Process.Start(url);
		}

		// Token: 0x06000F62 RID: 3938 RVA: 0x0000B556 File Offset: 0x00009756
		public string prod_ver()
		{
			return RegistryManager.Instance.Version;
		}

		// Token: 0x06000F63 RID: 3939 RVA: 0x0000B556 File Offset: 0x00009756
		public string getengineguid()
		{
			return RegistryManager.Instance.Version;
		}

		// Token: 0x06000F64 RID: 3940 RVA: 0x0000B556 File Offset: 0x00009756
		public string EngineVersion()
		{
			return RegistryManager.Instance.Version;
		}

		// Token: 0x06000F65 RID: 3941 RVA: 0x0000B562 File Offset: 0x00009762
		public string ClientVersion()
		{
			return RegistryManager.Instance.ClientVersion;
		}

		// Token: 0x06000F66 RID: 3942 RVA: 0x000615B0 File Offset: 0x0005F7B0
		public string CampaignName()
		{
			string result;
			try
			{
				JObject jobject = JObject.Parse(RegistryManager.Instance.CampaignJson);
				if (jobject.Property("campaign_name") != null)
				{
					result = jobject["campaign_name"].ToString();
				}
				else
				{
					result = "";
				}
			}
			catch
			{
				Logger.Error("error while sending campaign name in gm api");
				result = "";
			}
			return result;
		}

		// Token: 0x06000F67 RID: 3943 RVA: 0x0000B56E File Offset: 0x0000976E
		public string get_oem()
		{
			return RegistryManager.Instance.Oem;
		}

		// Token: 0x06000F68 RID: 3944 RVA: 0x0000B541 File Offset: 0x00009741
		public string bgp_uuid()
		{
			return RegistryManager.Instance.UserGuid;
		}

		// Token: 0x06000F69 RID: 3945 RVA: 0x0000B57A File Offset: 0x0000977A
		public string BGPDevUrl()
		{
			return RegistryManager.Instance.BGPDevUrl;
		}

		// Token: 0x06000F6A RID: 3946 RVA: 0x0000B586 File Offset: 0x00009786
		public string DevCloudUrl()
		{
			return RegistryManager.Instance.Host;
		}

		// Token: 0x06000F6B RID: 3947 RVA: 0x0000B592 File Offset: 0x00009792
		public string GetMachineId()
		{
			return GuidUtils.GetBlueStacksMachineId();
		}

		// Token: 0x06000F6C RID: 3948 RVA: 0x0000B599 File Offset: 0x00009799
		public string GetVersionId()
		{
			return GuidUtils.GetBlueStacksVersionId();
		}

		// Token: 0x06000F6D RID: 3949 RVA: 0x0006161C File Offset: 0x0005F81C
		public string SetFirebaseHost(string hostName)
		{
			object obj = MyCustomCefV8Handler.sLock;
			string result;
			lock (obj)
			{
				if (!string.IsNullOrEmpty(RegistryManager.Instance.CurrentFirebaseHost))
				{
					result = "false";
				}
				else
				{
					RegistryManager.Instance.CurrentFirebaseHost = hostName;
					result = "true";
				}
			}
			return result;
		}

		// Token: 0x06000F6E RID: 3950 RVA: 0x0006167C File Offset: 0x0005F87C
		public void closeAnyPopup()
		{
			Logger.Info("Got call from browser of closeAnyPopup");
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("CloseAnyPopup");
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F6F RID: 3951 RVA: 0x000616B0 File Offset: 0x0005F8B0
		public void closeself()
		{
			Logger.Info("Got call from browser of closeself");
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("CloseSelf");
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F70 RID: 3952 RVA: 0x000616E4 File Offset: 0x0005F8E4
		public void closequitpopup()
		{
			Logger.Info("Got call from browser of closequitpopup");
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("CloseBrowserQuitPopup");
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F71 RID: 3953 RVA: 0x0000B5A0 File Offset: 0x000097A0
		public void LogInfo(string info)
		{
			Logger.Info("HtmlLog: " + info);
		}

		// Token: 0x06000F72 RID: 3954 RVA: 0x0000B5B2 File Offset: 0x000097B2
		public string GetSystemRAM()
		{
			return Profile.RAM;
		}

		// Token: 0x06000F73 RID: 3955 RVA: 0x0000B5B9 File Offset: 0x000097B9
		public string GetLocale()
		{
			return RegistryManager.Instance.UserSelectedLocale;
		}

		// Token: 0x06000F74 RID: 3956 RVA: 0x0000B5C5 File Offset: 0x000097C5
		public string GetSystemCPU()
		{
			return Profile.CPU;
		}

		// Token: 0x06000F75 RID: 3957 RVA: 0x0000B5CC File Offset: 0x000097CC
		public string GetSystemGPU()
		{
			return Profile.GPU;
		}

		// Token: 0x06000F76 RID: 3958 RVA: 0x0000B5D3 File Offset: 0x000097D3
		public string GetSystemOS()
		{
			return Profile.OS;
		}

		// Token: 0x06000F77 RID: 3959 RVA: 0x0000B5DA File Offset: 0x000097DA
		public string GetCurrentSessionId()
		{
			Logger.Info("In GetCurrentSessionId");
			return Stats.GetSessionId();
		}

		// Token: 0x06000F78 RID: 3960 RVA: 0x00061718 File Offset: 0x0005F918
		public void showWebPage(string title, string webUrl)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("ShowWebPage");
			CefListValue arguments = cefProcessMessage.Arguments;
			arguments.SetString(0, title);
			arguments.SetString(1, webUrl);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F79 RID: 3961 RVA: 0x0006175C File Offset: 0x0005F95C
		public void HidePreview()
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("HidePreview");
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F7A RID: 3962 RVA: 0x00061788 File Offset: 0x0005F988
		public void ShowPreview()
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("ShowPreview");
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F7B RID: 3963 RVA: 0x000617B4 File Offset: 0x0005F9B4
		public void StartObs(string callbackFunction)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("StartObs");
			cefProcessMessage.Arguments.SetString(0, callbackFunction);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F7C RID: 3964 RVA: 0x000617EC File Offset: 0x0005F9EC
		public void StartStreamViewStatsRecorder(string label, string jsonString)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("StartStreamViewStatsRecorder");
			CefListValue arguments = cefProcessMessage.Arguments;
			arguments.SetString(0, label);
			arguments.SetString(1, jsonString);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F7D RID: 3965 RVA: 0x0000B5EB File Offset: 0x000097EB
		public string GetStreamConfig()
		{
			Logger.Info("In GetStreamConfig");
			return StreamManager.GetStreamConfig();
		}

		// Token: 0x06000F7E RID: 3966 RVA: 0x00061830 File Offset: 0x0005FA30
		public void LaunchDialog(string jsonString)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("LaunchDialog");
			cefProcessMessage.Arguments.SetString(0, jsonString);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F7F RID: 3967 RVA: 0x00061868 File Offset: 0x0005FA68
		public void StartStreamV2(string jsonString, string callbackStreamStatus, string callbackTabChanged)
		{
			Logger.Info("Got StartStreamV2");
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("StartStreamV2");
			CefListValue arguments = cefProcessMessage.Arguments;
			arguments.SetString(0, jsonString);
			arguments.SetString(1, callbackStreamStatus);
			arguments.SetString(2, callbackTabChanged);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F80 RID: 3968 RVA: 0x000618BC File Offset: 0x0005FABC
		public void StopStream()
		{
			Logger.Info("Got StopStream");
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("StopStream");
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F81 RID: 3969 RVA: 0x0000B5FC File Offset: 0x000097FC
		public void StartRecord()
		{
			this.StartRecordV2("{}");
		}

		// Token: 0x06000F82 RID: 3970 RVA: 0x000618F0 File Offset: 0x0005FAF0
		public void StartRecordV2(string jsonString)
		{
			Logger.Info("Got StartRecordV2");
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("StartRecordV2");
			cefProcessMessage.Arguments.SetString(0, jsonString);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F83 RID: 3971 RVA: 0x00061934 File Offset: 0x0005FB34
		public void StopRecord()
		{
			Logger.Info("Got StopStream");
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("StopRecord");
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F84 RID: 3972 RVA: 0x00004BF2 File Offset: 0x00002DF2
		public void UpdateStreamInfo(string updateStreamJsonString)
		{
		}

		// Token: 0x06000F85 RID: 3973 RVA: 0x00061968 File Offset: 0x0005FB68
		public void SetSystemVolume(string level)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("SetSystemVolume");
			cefProcessMessage.Arguments.SetString(0, level);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F86 RID: 3974 RVA: 0x000619A0 File Offset: 0x0005FBA0
		public void SetMicVolume(string level)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("SetMicVolume");
			cefProcessMessage.Arguments.SetString(0, level);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F87 RID: 3975 RVA: 0x000619D8 File Offset: 0x0005FBD8
		public void EnableWebcam(string width, string height, string position)
		{
			Logger.Info("Got EnableWebcam");
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("EnableWebcam");
			CefListValue arguments = cefProcessMessage.Arguments;
			arguments.SetString(0, width);
			arguments.SetString(1, height);
			arguments.SetString(2, position);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F88 RID: 3976 RVA: 0x00061A2C File Offset: 0x0005FC2C
		public void DisableWebcamV2(string jsonString)
		{
			Logger.Info("Got DisableWebcamV2");
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("DisableWebcamV2");
			cefProcessMessage.Arguments.SetString(0, jsonString);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F89 RID: 3977 RVA: 0x00061A70 File Offset: 0x0005FC70
		public void MoveWebcam(string horizontal, string vertical)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("MoveWebcam");
			CefListValue arguments = cefProcessMessage.Arguments;
			arguments.SetString(0, horizontal);
			arguments.SetString(1, vertical);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F8A RID: 3978 RVA: 0x0000B609 File Offset: 0x00009809
		public void SetStreamName(string name)
		{
			Logger.Info("Got SetStreamName: " + name);
			RegistryManager.Instance.StreamName = name;
		}

		// Token: 0x06000F8B RID: 3979 RVA: 0x0000B626 File Offset: 0x00009826
		public void SetServerLocation(string location)
		{
			Logger.Info("Got SetServerLocation: " + location);
			RegistryManager.Instance.ServerLocation = location;
		}

		// Token: 0x06000F8C RID: 3980 RVA: 0x0000B643 File Offset: 0x00009843
		public void SetChannelName(string channelName)
		{
			RegistryManager.Instance.ChannelName = channelName;
		}

		// Token: 0x06000F8D RID: 3981 RVA: 0x00061AB4 File Offset: 0x0005FCB4
		public string GetRealtimeAppUsage()
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("GetRealtimeAppUsage");
			cefProcessMessage.Arguments.SetString(0, this.mCallBackFunction);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
			return "";
		}

		// Token: 0x06000F8E RID: 3982 RVA: 0x00061AF8 File Offset: 0x0005FCF8
		public string GetInstalledAppsJsonforJS()
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("GetInstalledAppsJsonforJS");
			cefProcessMessage.Arguments.SetString(0, this.mCallBackFunction);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
			return "";
		}

		// Token: 0x06000F8F RID: 3983 RVA: 0x00061B3C File Offset: 0x0005FD3C
		public string GetCurrentAppInfo()
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("GetCurrentAppInfo");
			cefProcessMessage.Arguments.SetString(0, this.mCallBackFunction);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
			return "";
		}

		// Token: 0x06000F90 RID: 3984 RVA: 0x0000B650 File Offset: 0x00009850
		public void SetClientId(string clientId)
		{
			FilterUtility.ClientId = clientId;
		}

		// Token: 0x06000F91 RID: 3985 RVA: 0x00061B80 File Offset: 0x0005FD80
		public string GetGMPort()
		{
			Logger.Info("In GetGMPort");
			return RegistryManager.Instance.PartnerServerPort.ToString();
		}

		// Token: 0x06000F92 RID: 3986 RVA: 0x0000B658 File Offset: 0x00009858
		public string ResetSessionId()
		{
			Logger.Info("In ResetSessionId");
			return Stats.ResetSessionId();
		}

		// Token: 0x06000F93 RID: 3987 RVA: 0x00061BAC File Offset: 0x0005FDAC
		public void makeWebCall(string url, string scriptToInvoke)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("makeWebCall");
			CefListValue arguments = cefProcessMessage.Arguments;
			arguments.SetString(0, url);
			arguments.SetString(1, scriptToInvoke);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F94 RID: 3988 RVA: 0x0000B669 File Offset: 0x00009869
		public void ShowWebPageInBrowser(string url)
		{
			Logger.Info("Showing " + url + " in default browser");
			BlueStacksUIUtils.OpenUrl(url);
		}

		// Token: 0x06000F95 RID: 3989 RVA: 0x00061BF0 File Offset: 0x0005FDF0
		public void DialogClickHandler(string jsonString)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("DialogClickHandler");
			cefProcessMessage.Arguments.SetString(0, jsonString);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F96 RID: 3990 RVA: 0x00061C28 File Offset: 0x0005FE28
		public void CloseDialog(string jsonString)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("CloseDialog");
			cefProcessMessage.Arguments.SetString(0, jsonString);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F97 RID: 3991 RVA: 0x00061C60 File Offset: 0x0005FE60
		public void ShowAdvancedSettings()
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("ShowAdvancedSettings");
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F98 RID: 3992 RVA: 0x00061C8C File Offset: 0x0005FE8C
		public void LaunchFilterWindow(string channel, string sessionId)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("LaunchFilterWindow");
			CefListValue arguments = cefProcessMessage.Arguments;
			arguments.SetString(0, channel);
			arguments.SetString(1, sessionId);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F99 RID: 3993 RVA: 0x00061CD0 File Offset: 0x0005FED0
		public void ChangeFilterTheme(string theme)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("ChangeFilterTheme");
			cefProcessMessage.Arguments.SetString(0, theme);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F9A RID: 3994 RVA: 0x00061D08 File Offset: 0x0005FF08
		public void UpdateThemeSettings(string currentTheme, string settingsJson)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("UpdateThemeSettings");
			CefListValue arguments = cefProcessMessage.Arguments;
			arguments.SetString(0, currentTheme);
			arguments.SetString(1, settingsJson);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F9B RID: 3995 RVA: 0x00061D4C File Offset: 0x0005FF4C
		public void CloseFilterWindow(string jsonArray)
		{
			CefProcessMessage cefProcessMessage = CefProcessMessage.Create("CloseFilterWindow");
			cefProcessMessage.Arguments.SetString(0, jsonArray);
			CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(0, cefProcessMessage);
		}

		// Token: 0x06000F9C RID: 3996 RVA: 0x0000B686 File Offset: 0x00009886
		public string IsFacebook()
		{
			if (RegistryManager.Instance.BtvNetwork.Equals("facebook"))
			{
				return "true";
			}
			return "false";
		}

		// Token: 0x04000AAB RID: 2731
		private static object sLock = new object();

		// Token: 0x04000AAC RID: 2732
		private string mCallBackFunction;
	}
}
