﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000086 RID: 134
	public class NCSoftTopBar : UserControl, ITopBar, IComponentConnector
	{
		// Token: 0x17000146 RID: 326
		// (get) Token: 0x060005E9 RID: 1513 RVA: 0x00005D44 File Offset: 0x00003F44
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x17000147 RID: 327
		// (get) Token: 0x060005EA RID: 1514 RVA: 0x00005D65 File Offset: 0x00003F65
		// (set) Token: 0x060005EB RID: 1515 RVA: 0x00005D72 File Offset: 0x00003F72
		string ITopBar.AppName
		{
			get
			{
				return this.mAppName.Text;
			}
			set
			{
				this.mAppName.Text = value;
			}
		}

		// Token: 0x17000148 RID: 328
		// (get) Token: 0x060005EC RID: 1516 RVA: 0x00005D80 File Offset: 0x00003F80
		// (set) Token: 0x060005ED RID: 1517 RVA: 0x00005D8D File Offset: 0x00003F8D
		string ITopBar.CharacterName
		{
			get
			{
				return this.mCharacterName.Text;
			}
			set
			{
				this.mCharacterName.Text = value;
			}
		}

		// Token: 0x060005EE RID: 1518 RVA: 0x00005D9B File Offset: 0x00003F9B
		public NCSoftTopBar()
		{
			this.InitializeComponent();
		}

		// Token: 0x060005EF RID: 1519 RVA: 0x00005DD5 File Offset: 0x00003FD5
		public void ChangeTopBarColor(string color)
		{
			BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, color);
		}

		// Token: 0x060005F0 RID: 1520 RVA: 0x00025580 File Offset: 0x00023780
		private void ParentWindow_GuestBootCompletedEvent()
		{
			if (this.ParentWindow.EngineInstanceRegistry.IsSidebarVisible && base.Visibility == Visibility.Visible && this.ParentWindow.mSidebar.Visibility != Visibility.Visible)
			{
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					this.ParentWindow.mCommonHandler.FlipSidebarVisibility(this.mSidebarButtonImage, this.mSidebarButtonText);
				}), new object[0]);
			}
		}

		// Token: 0x060005F1 RID: 1521 RVA: 0x000255DC File Offset: 0x000237DC
		private void NCSoftTopBar_Loaded(object sender, RoutedEventArgs e)
		{
			if (!this.ParentWindow.mGuestBootCompleted)
			{
				this.ParentWindow.mCommonHandler.SetSidebarImageProperties(false, this.mSidebarButtonImage, this.mSidebarButtonText);
				this.ParentWindow.GuestBootCompletedEvent += this.ParentWindow_GuestBootCompletedEvent;
			}
			this.ParentWindow.mCommonHandler.ScreenRecordingStateChangedEvent += this.NCTopBar_ScreenRecordingStateChangedEvent;
			VideoRecordingStatus videoRecordingStatus = this.mVideoRecordStatusControl;
			videoRecordingStatus.RecordingStoppedEvent = (Action)Delegate.Combine(videoRecordingStatus.RecordingStoppedEvent, new Action(this.NCTopBar_RecordingStoppedEvent));
		}

		// Token: 0x060005F2 RID: 1522 RVA: 0x00025670 File Offset: 0x00023870
		private void NCTopBar_ScreenRecordingStateChangedEvent(bool isRecording)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (isRecording)
				{
					if (this.mVideoRecordingStatusGrid.Visibility != Visibility.Visible && CommonHandlers.sIsRecordingVideo)
					{
						this.mVideoRecordStatusControl.Init(this.ParentWindow);
						this.mVideoRecordingStatusGrid.Visibility = Visibility.Visible;
						return;
					}
				}
				else
				{
					this.mVideoRecordStatusControl.ResetTimer();
					this.mVideoRecordingStatusGrid.Visibility = Visibility.Collapsed;
				}
			}), new object[0]);
		}

		// Token: 0x060005F3 RID: 1523 RVA: 0x00005DE3 File Offset: 0x00003FE3
		private void NCTopBar_RecordingStoppedEvent()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.mVideoRecordingStatusGrid.Visibility = Visibility.Collapsed;
			}), new object[0]);
		}

		// Token: 0x060005F4 RID: 1524 RVA: 0x00005E08 File Offset: 0x00004008
		private void MinimizeButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked minimize button");
			this.ParentWindow.MinimizeWindow();
		}

		// Token: 0x060005F5 RID: 1525 RVA: 0x00005E1F File Offset: 0x0000401F
		internal void MaxmizeButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked Maximize\\Restore button");
			if (this.ParentWindow.WindowState == WindowState.Normal)
			{
				this.ParentWindow.MaximizeWindow();
				return;
			}
			this.ParentWindow.RestoreWindows();
		}

		// Token: 0x060005F6 RID: 1526 RVA: 0x00005E4F File Offset: 0x0000404F
		private void CloseButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked close Bluestacks button");
			this.ParentWindow.CloseWindow();
		}

		// Token: 0x060005F7 RID: 1527 RVA: 0x000256B4 File Offset: 0x000238B4
		private void SettingsButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if ((sender as Grid).Children[0].Visibility == Visibility.Visible)
			{
				this.mSettingsDropDownControl.LateInit();
				this.mSettingsDropdownPopup.IsOpen = true;
				this.mSettingsButtonImage.ImageName = "cfgmenu_selected";
				return;
			}
			this.ParentWindow.mCommonHandler.LaunchSettingsWindow();
		}

		// Token: 0x060005F8 RID: 1528 RVA: 0x00025714 File Offset: 0x00023914
		private void PinOnTop_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (!this.ParentWindow.EngineInstanceRegistry.IsClientOnTop)
			{
				this.ParentWindow.EngineInstanceRegistry.IsClientOnTop = true;
				this.ParentWindow.Topmost = true;
				return;
			}
			this.ParentWindow.EngineInstanceRegistry.IsClientOnTop = false;
			this.ParentWindow.Topmost = false;
		}

		// Token: 0x060005F9 RID: 1529 RVA: 0x00005E66 File Offset: 0x00004066
		private void MSidebarButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.FlipSidebarVisibility(this.mSidebarButtonImage, this.mSidebarButtonText);
		}

		// Token: 0x060005FA RID: 1530 RVA: 0x00005E84 File Offset: 0x00004084
		internal void ShowMacroPlaybackOnTopBar(OperationsRecord record)
		{
			if (this.ParentWindow.IsUIInPortraitMode)
			{
				this.mSettingsButton.Visibility = Visibility.Collapsed;
			}
			this.mMacroPlayControl.Init(this.ParentWindow, record);
			this.mMacroPlayGrid.Visibility = Visibility.Visible;
		}

		// Token: 0x060005FB RID: 1531 RVA: 0x00005EBD File Offset: 0x000040BD
		internal void HideMacroPlaybackFromTopBar()
		{
			this.mSettingsButton.Visibility = Visibility.Visible;
			this.mMacroPlayGrid.Visibility = Visibility.Collapsed;
		}

		// Token: 0x060005FC RID: 1532 RVA: 0x00025770 File Offset: 0x00023970
		internal void ShowRecordingIcons()
		{
			if (this.ParentWindow.IsUIInPortraitMode)
			{
				this.mSettingsButton.Visibility = Visibility.Collapsed;
			}
			this.mMacroRecordControl.Init(this.ParentWindow);
			this.mMacroRecordGrid.Visibility = Visibility.Visible;
			this.mMacroRecordControl.StartTimer();
		}

		// Token: 0x060005FD RID: 1533 RVA: 0x00005ED7 File Offset: 0x000040D7
		internal void HideRecordingIcons()
		{
			this.mSettingsButton.Visibility = Visibility.Visible;
			this.mMacroRecordGrid.Visibility = Visibility.Collapsed;
			this.mMacroRecorderToolTipPopup.IsOpen = false;
		}

		// Token: 0x060005FE RID: 1534 RVA: 0x00005EFD File Offset: 0x000040FD
		private void NCSoftTopBar_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			DesignerProperties.GetIsInDesignMode(this);
		}

		// Token: 0x060005FF RID: 1535 RVA: 0x0000553B File Offset: 0x0000373B
		private void SettingsDropDownControl_MouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x06000600 RID: 1536 RVA: 0x00005F06 File Offset: 0x00004106
		private void SettingsPopup_Opened(object sender, EventArgs e)
		{
			this.mSettingsDropdownPopup.IsEnabled = false;
			this.mSettingsButtonImage.ImageName = "cfgmenu";
		}

		// Token: 0x06000601 RID: 1537 RVA: 0x00005F24 File Offset: 0x00004124
		private void SettingsPopup_Closed(object sender, EventArgs e)
		{
			this.mSettingsDropdownPopup.IsEnabled = true;
			this.mSettingsButtonImage.ImageName = "cfgmenu";
		}

		// Token: 0x06000602 RID: 1538 RVA: 0x00005F42 File Offset: 0x00004142
		void ITopBar.ShowSyncPanel(bool isSource)
		{
			this.mOperationsSyncGrid.Visibility = Visibility.Visible;
			if (isSource)
			{
				this.mStopSyncButton.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x06000603 RID: 1539 RVA: 0x00005F5F File Offset: 0x0000415F
		void ITopBar.HideSyncPanel()
		{
			this.mOperationsSyncGrid.Visibility = Visibility.Collapsed;
			this.mStopSyncButton.Visibility = Visibility.Collapsed;
			this.mSyncInstancesToolTipPopup.IsOpen = false;
		}

		// Token: 0x06000604 RID: 1540 RVA: 0x000257C0 File Offset: 0x000239C0
		private void PlayPauseSyncButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if ((sender as CustomPictureBox).ImageName.Equals("pause_title_bar", StringComparison.InvariantCultureIgnoreCase))
			{
				(sender as CustomPictureBox).ImageName = "play_title_bar";
				this.ParentWindow.mSynchronizerWindow.PauseAllSyncOperations();
				return;
			}
			(sender as CustomPictureBox).ImageName = "pause_title_bar";
			this.ParentWindow.mSynchronizerWindow.PlayAllSyncOperations();
		}

		// Token: 0x06000605 RID: 1541 RVA: 0x00005F85 File Offset: 0x00004185
		private void StopSyncButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			((ITopBar)this).HideSyncPanel();
			this.ParentWindow.mSynchronizerWindow.StopAllSyncOperations();
		}

		// Token: 0x06000606 RID: 1542 RVA: 0x00005F9D File Offset: 0x0000419D
		private void OperationsSyncGrid_MouseEnter(object sender, MouseEventArgs e)
		{
			if (this.ParentWindow.mIsSynchronisationActive)
			{
				this.mSyncInstancesToolTipPopup.IsOpen = true;
			}
		}

		// Token: 0x06000607 RID: 1543 RVA: 0x00005FB8 File Offset: 0x000041B8
		private void OperationsSyncGrid_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.ParentWindow.mIsSynchronisationActive && !this.mOperationsSyncGrid.IsMouseOver && !this.mSyncInstancesToolTipPopup.IsMouseOver)
			{
				this.mSyncInstancesToolTipPopup.IsOpen = false;
			}
		}

		// Token: 0x06000608 RID: 1544 RVA: 0x00005FED File Offset: 0x000041ED
		private void SyncInstancesToolTip_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.mOperationsSyncGrid.IsMouseOver && !this.mSyncInstancesToolTipPopup.IsMouseOver)
			{
				this.mSyncInstancesToolTipPopup.IsOpen = false;
			}
		}

		// Token: 0x06000609 RID: 1545 RVA: 0x00025828 File Offset: 0x00023A28
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/ncsofttopbar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600060A RID: 1546 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600060B RID: 1547 RVA: 0x00025858 File Offset: 0x00023A58
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((NCSoftTopBar)target).Loaded += this.NCSoftTopBar_Loaded;
				((NCSoftTopBar)target).SizeChanged += this.NCSoftTopBar_SizeChanged;
				return;
			case 2:
				this.mMainGrid = (Grid)target;
				return;
			case 3:
				this.mTitleIcon = (CustomPictureBox)target;
				return;
			case 4:
				this.mWindowHeaderGrid = (StackPanel)target;
				return;
			case 5:
				this.mAppName = (TextBlock)target;
				return;
			case 6:
				this.mGamenameSeparator = (Line)target;
				return;
			case 7:
				this.mCharacterName = (TextBlock)target;
				return;
			case 8:
				this.mStreamingTopbarGrid = (Grid)target;
				return;
			case 9:
				this.mBorder = (Border)target;
				return;
			case 10:
				this.mNcTopBarControlGrid = (Grid)target;
				return;
			case 11:
				this.mMacroRecordGrid = (Grid)target;
				return;
			case 12:
				this.mMacroRecordControl = (MacroRecordControl)target;
				return;
			case 13:
				this.mMacroPlayGrid = (Grid)target;
				return;
			case 14:
				this.mMacroPlayControl = (MacroPlayControl)target;
				return;
			case 15:
				this.mVideoRecordingStatusGrid = (Grid)target;
				return;
			case 16:
				this.mVideoRecordStatusControl = (VideoRecordingStatus)target;
				return;
			case 17:
				this.mOperationsSyncGrid = (Grid)target;
				this.mOperationsSyncGrid.MouseEnter += this.OperationsSyncGrid_MouseEnter;
				this.mOperationsSyncGrid.MouseLeave += this.OperationsSyncGrid_MouseLeave;
				return;
			case 18:
				this.mSyncMaskBorder = (Border)target;
				return;
			case 19:
				this.mStopSyncButton = (CustomPictureBox)target;
				this.mStopSyncButton.PreviewMouseLeftButtonUp += this.StopSyncButton_PreviewMouseLeftButtonUp;
				return;
			case 20:
				this.mControlBtnPanel = (StackPanel)target;
				return;
			case 21:
				this.mSettingsButton = (Grid)target;
				this.mSettingsButton.PreviewMouseLeftButtonUp += this.SettingsButton_MouseLeftButtonUp;
				return;
			case 22:
				this.mSettingsButtonImage = (CustomPictureBox)target;
				return;
			case 23:
				this.mSettingsButtonText = (TextBlock)target;
				return;
			case 24:
				this.mMinimizeButton = (Grid)target;
				this.mMinimizeButton.PreviewMouseLeftButtonUp += this.MinimizeButton_MouseLeftButtonUp;
				return;
			case 25:
				this.mMinimizeButtonImage = (CustomPictureBox)target;
				return;
			case 26:
				this.mMinimizeButtonText = (TextBlock)target;
				return;
			case 27:
				this.mMaximizeButton = (Grid)target;
				this.mMaximizeButton.PreviewMouseLeftButtonUp += this.MaxmizeButton_MouseLeftButtonUp;
				return;
			case 28:
				this.mMaximizeButtonImage = (CustomPictureBox)target;
				return;
			case 29:
				this.mMaximizeButtonText = (TextBlock)target;
				return;
			case 30:
				this.mCloseButton = (Grid)target;
				this.mCloseButton.PreviewMouseLeftButtonUp += this.CloseButton_MouseLeftButtonUp;
				return;
			case 31:
				this.mCloseButtonImage = (CustomPictureBox)target;
				return;
			case 32:
				this.mCloseButtonText = (TextBlock)target;
				return;
			case 33:
				this.mSidebarButton = (Grid)target;
				this.mSidebarButton.PreviewMouseLeftButtonUp += this.MSidebarButton_MouseLeftButtonUp;
				return;
			case 34:
				this.mSidebarButtonImage = (CustomPictureBox)target;
				return;
			case 35:
				this.mSidebarButtonText = (TextBlock)target;
				return;
			case 36:
				this.mMacroRecorderToolTipPopup = (CustomPopUp)target;
				return;
			case 37:
				this.dummyGrid = (Grid)target;
				return;
			case 38:
				this.mMacroRecordingTooltip = (TextBlock)target;
				return;
			case 39:
				this.mUpArrow = (Path)target;
				return;
			case 40:
				this.mMacroRunningToolTipPopup = (CustomPopUp)target;
				return;
			case 41:
				this.grid = (Grid)target;
				return;
			case 42:
				this.mMacroRunningTooltip = (TextBlock)target;
				return;
			case 43:
				this.mSettingsDropdownPopup = (CustomPopUp)target;
				this.mSettingsDropdownPopup.Opened += this.SettingsPopup_Opened;
				this.mSettingsDropdownPopup.Closed += this.SettingsPopup_Closed;
				return;
			case 44:
				this.mSettingsDropdownBorder = (Border)target;
				return;
			case 45:
				this.mGrid = (Grid)target;
				return;
			case 46:
				this.mMaskBorder = (Border)target;
				return;
			case 47:
				this.mSettingsDropDownControl = (SettingsWindowDropdown)target;
				return;
			case 48:
				this.mSyncInstancesToolTipPopup = (CustomPopUp)target;
				return;
			case 49:
				this.mDummyGrid = (Grid)target;
				return;
			case 50:
				this.mUpwardArrow = (Path)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040003B6 RID: 950
		private MainWindow mMainWindow;

		// Token: 0x040003B7 RID: 951
		private List<string> mSkippableGrid = new List<string>
		{
			"mCloseButton"
		};

		// Token: 0x040003B8 RID: 952
		private List<string> mGridNeededBeforeSkippableGrid = new List<string>
		{
			"mSidebarButton"
		};

		// Token: 0x040003B9 RID: 953
		internal Grid mMainGrid;

		// Token: 0x040003BA RID: 954
		internal CustomPictureBox mTitleIcon;

		// Token: 0x040003BB RID: 955
		internal StackPanel mWindowHeaderGrid;

		// Token: 0x040003BC RID: 956
		internal TextBlock mAppName;

		// Token: 0x040003BD RID: 957
		internal Line mGamenameSeparator;

		// Token: 0x040003BE RID: 958
		internal TextBlock mCharacterName;

		// Token: 0x040003BF RID: 959
		internal Grid mStreamingTopbarGrid;

		// Token: 0x040003C0 RID: 960
		internal Border mBorder;

		// Token: 0x040003C1 RID: 961
		internal Grid mNcTopBarControlGrid;

		// Token: 0x040003C2 RID: 962
		internal Grid mMacroRecordGrid;

		// Token: 0x040003C3 RID: 963
		internal MacroRecordControl mMacroRecordControl;

		// Token: 0x040003C4 RID: 964
		internal Grid mMacroPlayGrid;

		// Token: 0x040003C5 RID: 965
		internal MacroPlayControl mMacroPlayControl;

		// Token: 0x040003C6 RID: 966
		internal Grid mVideoRecordingStatusGrid;

		// Token: 0x040003C7 RID: 967
		internal VideoRecordingStatus mVideoRecordStatusControl;

		// Token: 0x040003C8 RID: 968
		internal Grid mOperationsSyncGrid;

		// Token: 0x040003C9 RID: 969
		internal Border mSyncMaskBorder;

		// Token: 0x040003CA RID: 970
		internal CustomPictureBox mStopSyncButton;

		// Token: 0x040003CB RID: 971
		internal StackPanel mControlBtnPanel;

		// Token: 0x040003CC RID: 972
		internal Grid mSettingsButton;

		// Token: 0x040003CD RID: 973
		internal CustomPictureBox mSettingsButtonImage;

		// Token: 0x040003CE RID: 974
		internal TextBlock mSettingsButtonText;

		// Token: 0x040003CF RID: 975
		internal Grid mMinimizeButton;

		// Token: 0x040003D0 RID: 976
		internal CustomPictureBox mMinimizeButtonImage;

		// Token: 0x040003D1 RID: 977
		internal TextBlock mMinimizeButtonText;

		// Token: 0x040003D2 RID: 978
		internal Grid mMaximizeButton;

		// Token: 0x040003D3 RID: 979
		internal CustomPictureBox mMaximizeButtonImage;

		// Token: 0x040003D4 RID: 980
		internal TextBlock mMaximizeButtonText;

		// Token: 0x040003D5 RID: 981
		internal Grid mCloseButton;

		// Token: 0x040003D6 RID: 982
		internal CustomPictureBox mCloseButtonImage;

		// Token: 0x040003D7 RID: 983
		internal TextBlock mCloseButtonText;

		// Token: 0x040003D8 RID: 984
		internal Grid mSidebarButton;

		// Token: 0x040003D9 RID: 985
		internal CustomPictureBox mSidebarButtonImage;

		// Token: 0x040003DA RID: 986
		internal TextBlock mSidebarButtonText;

		// Token: 0x040003DB RID: 987
		internal CustomPopUp mMacroRecorderToolTipPopup;

		// Token: 0x040003DC RID: 988
		internal Grid dummyGrid;

		// Token: 0x040003DD RID: 989
		internal TextBlock mMacroRecordingTooltip;

		// Token: 0x040003DE RID: 990
		internal Path mUpArrow;

		// Token: 0x040003DF RID: 991
		internal CustomPopUp mMacroRunningToolTipPopup;

		// Token: 0x040003E0 RID: 992
		internal Grid grid;

		// Token: 0x040003E1 RID: 993
		internal TextBlock mMacroRunningTooltip;

		// Token: 0x040003E2 RID: 994
		internal CustomPopUp mSettingsDropdownPopup;

		// Token: 0x040003E3 RID: 995
		internal Border mSettingsDropdownBorder;

		// Token: 0x040003E4 RID: 996
		internal Grid mGrid;

		// Token: 0x040003E5 RID: 997
		internal Border mMaskBorder;

		// Token: 0x040003E6 RID: 998
		internal SettingsWindowDropdown mSettingsDropDownControl;

		// Token: 0x040003E7 RID: 999
		internal CustomPopUp mSyncInstancesToolTipPopup;

		// Token: 0x040003E8 RID: 1000
		internal Grid mDummyGrid;

		// Token: 0x040003E9 RID: 1001
		internal Path mUpwardArrow;

		// Token: 0x040003EA RID: 1002
		private bool _contentLoaded;
	}
}
