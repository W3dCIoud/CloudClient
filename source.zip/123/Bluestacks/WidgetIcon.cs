﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media.Animation;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001DC RID: 476
	public class WidgetIcon : Button, IComponentConnector, IStyleConnector
	{
		// Token: 0x170001F6 RID: 502
		// (get) Token: 0x06001074 RID: 4212 RVA: 0x0000BB1A File Offset: 0x00009D1A
		// (set) Token: 0x06001075 RID: 4213 RVA: 0x0006757C File Offset: 0x0006577C
		public string ImageName
		{
			get
			{
				return this.mImageName;
			}
			set
			{
				this.mImageName = value;
				if (this.mImage != null)
				{
					this.mImage.ImageName = this.mImageName;
				}
				if (this.mBusyImage != null)
				{
					this.mBusyImage.ImageName = this.mImageName + this.mBusyImageNamePostFix;
				}
			}
		}

		// Token: 0x170001F7 RID: 503
		// (get) Token: 0x06001076 RID: 4214 RVA: 0x0000BB22 File Offset: 0x00009D22
		// (set) Token: 0x06001077 RID: 4215 RVA: 0x0000BB34 File Offset: 0x00009D34
		public string FooterText
		{
			get
			{
				return base.GetValue(WidgetIcon.MyFooterTextProperty) as string;
			}
			set
			{
				base.SetValue(WidgetIcon.MyFooterTextProperty, value);
			}
		}

		// Token: 0x06001078 RID: 4216 RVA: 0x0000BB42 File Offset: 0x00009D42
		public WidgetIcon()
		{
			this.InitializeComponent();
		}

		// Token: 0x06001079 RID: 4217 RVA: 0x0000BB5B File Offset: 0x00009D5B
		internal void ShowBusyIcon(Visibility visibility)
		{
			this.mBusyImage.Visibility = visibility;
		}

		// Token: 0x0600107A RID: 4218 RVA: 0x0000BB69 File Offset: 0x00009D69
		private void Image_Initialized(object sender, EventArgs e)
		{
			if (this.mImage == null)
			{
				this.mImage = (sender as CustomPictureBox);
			}
			if (!string.IsNullOrEmpty(this.mImageName))
			{
				this.mImage.ImageName = this.mImageName;
			}
		}

		// Token: 0x0600107B RID: 4219 RVA: 0x0000BB9D File Offset: 0x00009D9D
		private void BusyImage_Initialized(object sender, EventArgs e)
		{
			if (this.mBusyImage == null)
			{
				this.mBusyImage = (sender as CustomPictureBox);
			}
			if (!string.IsNullOrEmpty(this.mImageName))
			{
				this.mBusyImage.ImageName = this.mImageName + this.mBusyImageNamePostFix;
			}
		}

		// Token: 0x0600107C RID: 4220 RVA: 0x000675D0 File Offset: 0x000657D0
		private void CustomPictureBox_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (this.mBusyImage.IsVisible)
			{
				if (this.mBusyIconStoryBoard == null)
				{
					this.mBusyIconStoryBoard = new Storyboard();
					DoubleAnimation doubleAnimation = new DoubleAnimation();
					doubleAnimation.From = new double?(0.0);
					doubleAnimation.To = new double?((double)360);
					doubleAnimation.RepeatBehavior = RepeatBehavior.Forever;
					doubleAnimation.Duration = new Duration(new TimeSpan(0, 0, 1));
					Storyboard.SetTarget(doubleAnimation, this.mBusyImage);
					Storyboard.SetTargetProperty(doubleAnimation, new PropertyPath("(UIElement.RenderTransform).(RotateTransform.Angle)", new object[0]));
					this.mBusyIconStoryBoard.Children.Add(doubleAnimation);
				}
				this.mBusyIconStoryBoard.Begin();
				return;
			}
			this.mBusyIconStoryBoard.Pause();
		}

		// Token: 0x0600107D RID: 4221 RVA: 0x00067698 File Offset: 0x00065898
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/widgeticon.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600107E RID: 4222 RVA: 0x0000BBDC File Offset: 0x00009DDC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mWidgetIcon = (WidgetIcon)target;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x0600107F RID: 4223 RVA: 0x000676C8 File Offset: 0x000658C8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 2)
			{
				((CustomPictureBox)target).Initialized += this.Image_Initialized;
				return;
			}
			if (connectionId != 3)
			{
				return;
			}
			((CustomPictureBox)target).Initialized += this.BusyImage_Initialized;
			((CustomPictureBox)target).IsVisibleChanged += this.CustomPictureBox_IsVisibleChanged;
		}

		// Token: 0x04000B35 RID: 2869
		private CustomPictureBox mImage;

		// Token: 0x04000B36 RID: 2870
		private CustomPictureBox mBusyImage;

		// Token: 0x04000B37 RID: 2871
		private string mBusyImageNamePostFix = "_busy";

		// Token: 0x04000B38 RID: 2872
		private Storyboard mBusyIconStoryBoard;

		// Token: 0x04000B39 RID: 2873
		private string mImageName;

		// Token: 0x04000B3A RID: 2874
		public static readonly DependencyProperty MyFooterTextProperty = DependencyProperty.Register("FooterText", typeof(string), typeof(WidgetIcon));

		// Token: 0x04000B3B RID: 2875
		internal WidgetIcon mWidgetIcon;

		// Token: 0x04000B3C RID: 2876
		private bool _contentLoaded;
	}
}
