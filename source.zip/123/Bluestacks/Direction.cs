﻿using System;

// Token: 0x0200001F RID: 31
public enum Direction
{
	// Token: 0x040000EA RID: 234
	Up,
	// Token: 0x040000EB RID: 235
	Down,
	// Token: 0x040000EC RID: 236
	Left,
	// Token: 0x040000ED RID: 237
	Right
}
