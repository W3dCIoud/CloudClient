﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001E5 RID: 485
	public class DimControlWithProgresBar : UserControl, IComponentConnector
	{
		// Token: 0x170001FB RID: 507
		// (get) Token: 0x060010B7 RID: 4279 RVA: 0x0000BE88 File Offset: 0x0000A088
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x060010B8 RID: 4280 RVA: 0x0000BEA9 File Offset: 0x0000A0A9
		public DimControlWithProgresBar()
		{
			this.InitializeComponent();
		}

		// Token: 0x060010B9 RID: 4281 RVA: 0x00068CE0 File Offset: 0x00066EE0
		internal void Init(Control parentControl, Panel childControl, bool isWindowForced, bool isWindowForcedTillLoaded)
		{
			this.ParentControl = parentControl;
			this.ChildControl = childControl;
			this.FixUpUILayout();
			if (isWindowForced)
			{
				this.mIsWindowForced = isWindowForced;
				this.mBackButton.Visibility = Visibility.Hidden;
				this.mCloseButton.Visibility = Visibility.Hidden;
			}
			this.mIsWindowForcedTillLoaded = isWindowForcedTillLoaded;
			this.ParentWindow.SizeChanged += this.MainWindow_SizeChanged;
		}

		// Token: 0x060010BA RID: 4282 RVA: 0x0000BEB7 File Offset: 0x0000A0B7
		private void MainWindow_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			this.FixUpUILayout();
		}

		// Token: 0x060010BB RID: 4283 RVA: 0x00068D44 File Offset: 0x00066F44
		private void FixUpUILayout()
		{
			this.mControlGrid.Height = (double)((long)((int)(this.ParentWindow.mWelcomeTab.ActualHeight * 0.8 / (double)this.ParentWindow.mAspectRatio.Denominator)) * this.ParentWindow.mAspectRatio.Denominator);
			if (this.ParentWindow.mWelcomeTab.ActualHeight * 0.9 - this.mControlGrid.Height > 10.0)
			{
				this.mControlGrid.Height = this.ParentWindow.mWelcomeTab.ActualHeight * 0.8;
			}
			this.mControlGrid.Height = this.mControlGrid.Height + 50.0;
			this.mControlGrid.Width = (this.mControlGrid.Height - 50.0) * this.ParentWindow.mAspectRatio.DoubleValue + 10.0;
		}

		// Token: 0x060010BC RID: 4284 RVA: 0x00068E50 File Offset: 0x00067050
		internal void ShowContent()
		{
			this.DimBackground();
			if (this.ChildControl != null)
			{
				if (this.ChildControl.Parent != null)
				{
					(this.ChildControl.Parent as Panel).Children.Remove(this.ChildControl);
				}
				this.mControlParentGrid.Children.Add(this.ChildControl);
			}
			this.mControlGrid.Visibility = Visibility.Visible;
		}

		// Token: 0x060010BD RID: 4285 RVA: 0x0000BEBF File Offset: 0x0000A0BF
		private void CloseButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Cicked DimControl close button");
			this.HideWindow();
		}

		// Token: 0x060010BE RID: 4286 RVA: 0x0000BED1 File Offset: 0x0000A0D1
		internal void DimBackground()
		{
			Logger.Info("Diming popup window");
			if (this.ParentControl != null)
			{
				this.ParentControl.Visibility = Visibility.Visible;
			}
			base.Visibility = Visibility.Visible;
		}

		// Token: 0x060010BF RID: 4287 RVA: 0x0000BEF8 File Offset: 0x0000A0F8
		private void BackButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked Back Button");
			this.ParentWindow.mCommonHandler.BackButtonHandler(false);
		}

		// Token: 0x060010C0 RID: 4288 RVA: 0x0000BF15 File Offset: 0x0000A115
		internal void HideWindow()
		{
			Logger.Debug("Hiding popup window");
			base.Visibility = Visibility.Hidden;
			this.mControlGrid.Visibility = Visibility.Hidden;
			if (this.ParentControl != null)
			{
				this.ParentControl.Visibility = Visibility.Hidden;
			}
		}

		// Token: 0x060010C1 RID: 4289 RVA: 0x00068EBC File Offset: 0x000670BC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/dimcontrolwithprogresbar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060010C2 RID: 4290 RVA: 0x00068EEC File Offset: 0x000670EC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mControlGrid = (Grid)target;
				return;
			case 2:
				this.mTopBar = (Grid)target;
				return;
			case 3:
				this.mBackButton = (CustomPictureBox)target;
				this.mBackButton.PreviewMouseLeftButtonUp += this.BackButton_PreviewMouseLeftButtonUp;
				return;
			case 4:
				this.mTitleLabel = (Label)target;
				return;
			case 5:
				this.mCloseButton = (CustomPictureBox)target;
				this.mCloseButton.PreviewMouseLeftButtonUp += this.CloseButton_PreviewMouseLeftButtonUp;
				return;
			case 6:
				this.mControlParentGrid = (Grid)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000B6B RID: 2923
		private MainWindow mMainWindow;

		// Token: 0x04000B6C RID: 2924
		public Control ParentControl;

		// Token: 0x04000B6D RID: 2925
		public Panel ChildControl;

		// Token: 0x04000B6E RID: 2926
		private bool mIsWindowForced;

		// Token: 0x04000B6F RID: 2927
		private bool mIsWindowForcedTillLoaded;

		// Token: 0x04000B70 RID: 2928
		internal Grid mControlGrid;

		// Token: 0x04000B71 RID: 2929
		internal Grid mTopBar;

		// Token: 0x04000B72 RID: 2930
		internal CustomPictureBox mBackButton;

		// Token: 0x04000B73 RID: 2931
		internal Label mTitleLabel;

		// Token: 0x04000B74 RID: 2932
		internal CustomPictureBox mCloseButton;

		// Token: 0x04000B75 RID: 2933
		internal Grid mControlParentGrid;

		// Token: 0x04000B76 RID: 2934
		private bool _contentLoaded;
	}
}
