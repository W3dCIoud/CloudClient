﻿using System;
using BlueStacks.BlueStacksUI;

// Token: 0x0200001D RID: 29
[Serializable]
public class MetaData
{
	// Token: 0x170000D1 RID: 209
	// (get) Token: 0x060001C9 RID: 457 RVA: 0x000032F9 File Offset: 0x000014F9
	public string ParserVersion
	{
		get
		{
			return KMManager.ParserVersion;
		}
	}

	// Token: 0x170000D2 RID: 210
	// (get) Token: 0x060001CA RID: 458 RVA: 0x00003300 File Offset: 0x00001500
	// (set) Token: 0x060001CB RID: 459 RVA: 0x00003308 File Offset: 0x00001508
	public string Comment { get; set; }
}
