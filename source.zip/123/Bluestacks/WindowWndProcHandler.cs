﻿using System;
using System.Drawing;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000203 RID: 515
	internal class WindowWndProcHandler
	{
		// Token: 0x060011B4 RID: 4532
		[DllImport("user32.dll")]
		[return: MarshalAs(UnmanagedType.Bool)]
		private static extern bool GetCursorPos(ref WindowWndProcHandler.Win32Point pt);

		// Token: 0x060011B5 RID: 4533
		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		private static extern IntPtr SendMessage(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

		// Token: 0x060011B6 RID: 4534 RVA: 0x0006D620 File Offset: 0x0006B820
		internal WindowWndProcHandler(MainWindow window)
		{
			this.mWindowInstance = window;
			MainWindow mainWindow = this.mWindowInstance;
			mainWindow.ResizeBegin = (EventHandler)Delegate.Combine(mainWindow.ResizeBegin, new EventHandler(this.mWindowInstance.MainWindow_ResizeBegin));
			MainWindow mainWindow2 = this.mWindowInstance;
			mainWindow2.ResizeEnd = (EventHandler)Delegate.Combine(mainWindow2.ResizeEnd, new EventHandler(this.mWindowInstance.MainWindow_ResizeEnd));
			this.mWindowInstance.SourceInitialized += this.Instance_SourceInitialized;
			WindowWndProcHandler.SetMenuDropDownAlignment();
		}

		// Token: 0x060011B7 RID: 4535 RVA: 0x0000C911 File Offset: 0x0000AB11
		private void Instance_SourceInitialized(object sender, EventArgs e)
		{
			this._hwndSource = (HwndSource)PresentationSource.FromVisual(this.mWindowInstance);
			this._hwndSource.AddHook(new HwndSourceHook(this.WndProc));
		}

		// Token: 0x060011B8 RID: 4536 RVA: 0x0006D6BC File Offset: 0x0006B8BC
		internal void AddRawInputHandler()
		{
			try
			{
				if (PromotionObject.Instance != null && PromotionObject.Instance.IsSecurityMetricsEnable)
				{
					WindowInteropHelper windowInteropHelper = new WindowInteropHelper(this.mWindowInstance);
					this.mRawInput = new RawInputClass(windowInteropHelper.Handle);
					Logger.Info("Adding raw input handle");
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error while adding raw input handle: {0}", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x060011B9 RID: 4537 RVA: 0x0006D734 File Offset: 0x0006B934
		internal void ResizeRectangle_MouseMove(object sender, MouseEventArgs e)
		{
			if (this.IsResizingEnabled)
			{
				string name = (sender as System.Windows.Shapes.Rectangle).Name;
				uint num = <PrivateImplementationDetails>.ComputeStringHash(name);
				if (num <= 1319594794U)
				{
					if (num <= 591972422U)
					{
						if (num != 306900080U)
						{
							if (num != 591972422U)
							{
								return;
							}
							if (!(name == "topRight"))
							{
								return;
							}
							this.mWindowInstance.Cursor = Cursors.SizeNESW;
							return;
						}
						else
						{
							if (!(name == "left"))
							{
								return;
							}
							this.mWindowInstance.Cursor = Cursors.SizeWE;
							return;
						}
					}
					else if (num != 873742264U)
					{
						if (num != 1319594794U)
						{
							return;
						}
						if (!(name == "bottom"))
						{
							return;
						}
						this.mWindowInstance.Cursor = Cursors.SizeNS;
						return;
					}
					else
					{
						if (!(name == "bottomRight"))
						{
							return;
						}
						this.mWindowInstance.Cursor = Cursors.SizeNWSE;
					}
				}
				else if (num <= 2059707271U)
				{
					if (num != 2028154341U)
					{
						if (num != 2059707271U)
						{
							return;
						}
						if (!(name == "bottomLeft"))
						{
							return;
						}
						this.mWindowInstance.Cursor = Cursors.SizeNESW;
						return;
					}
					else
					{
						if (!(name == "right"))
						{
							return;
						}
						this.mWindowInstance.Cursor = Cursors.SizeWE;
						return;
					}
				}
				else if (num != 2387400333U)
				{
					if (num == 2802900028U)
					{
						if (!(name == "top"))
						{
							return;
						}
						this.mWindowInstance.Cursor = Cursors.SizeNS;
						return;
					}
				}
				else
				{
					if (!(name == "topLeft"))
					{
						return;
					}
					this.mWindowInstance.Cursor = Cursors.SizeNWSE;
					return;
				}
			}
		}

		// Token: 0x060011BA RID: 4538 RVA: 0x0006D8BC File Offset: 0x0006BABC
		internal void ResizeRectangle_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.IsResizingEnabled)
			{
				e.Handled = true;
				string name = (sender as System.Windows.Shapes.Rectangle).Name;
				uint num = <PrivateImplementationDetails>.ComputeStringHash(name);
				if (num <= 1319594794U)
				{
					if (num <= 591972422U)
					{
						if (num != 306900080U)
						{
							if (num == 591972422U)
							{
								if (name == "topRight")
								{
									this.mWindowInstance.Cursor = Cursors.SizeNESW;
									this.ResizeWindow(WindowWndProcHandler.ResizeDirection.TopRight);
									return;
								}
							}
						}
						else if (name == "left")
						{
							this.mWindowInstance.Cursor = Cursors.SizeWE;
							this.mAdjustingWidth = true;
							this.ResizeWindow(WindowWndProcHandler.ResizeDirection.Left);
							return;
						}
					}
					else if (num != 873742264U)
					{
						if (num == 1319594794U)
						{
							if (name == "bottom")
							{
								this.mWindowInstance.Cursor = Cursors.SizeNS;
								this.mAdjustingWidth = false;
								this.ResizeWindow(WindowWndProcHandler.ResizeDirection.Bottom);
								return;
							}
						}
					}
					else if (name == "bottomRight")
					{
						this.mWindowInstance.Cursor = Cursors.SizeNWSE;
						this.ResizeWindow(WindowWndProcHandler.ResizeDirection.BottomRight);
						return;
					}
				}
				else if (num <= 2059707271U)
				{
					if (num != 2028154341U)
					{
						if (num == 2059707271U)
						{
							if (name == "bottomLeft")
							{
								this.mWindowInstance.Cursor = Cursors.SizeNESW;
								this.ResizeWindow(WindowWndProcHandler.ResizeDirection.BottomLeft);
								return;
							}
						}
					}
					else if (name == "right")
					{
						this.mWindowInstance.Cursor = Cursors.SizeWE;
						this.mAdjustingWidth = true;
						this.ResizeWindow(WindowWndProcHandler.ResizeDirection.Right);
						return;
					}
				}
				else if (num != 2387400333U)
				{
					if (num == 2802900028U)
					{
						if (name == "top")
						{
							this.mWindowInstance.Cursor = Cursors.SizeNS;
							this.mAdjustingWidth = false;
							this.ResizeWindow(WindowWndProcHandler.ResizeDirection.Top);
							return;
						}
					}
				}
				else if (name == "topLeft")
				{
					this.mWindowInstance.Cursor = Cursors.SizeNWSE;
					this.ResizeWindow(WindowWndProcHandler.ResizeDirection.TopLeft);
					return;
				}
				e.Handled = false;
			}
		}

		// Token: 0x060011BB RID: 4539 RVA: 0x0006DAF0 File Offset: 0x0006BCF0
		internal void ResizeWindow(WindowWndProcHandler.ResizeDirection direction)
		{
			this.mWindowInstance.ResizeBegin(this.mWindowInstance, new EventArgs());
			WindowWndProcHandler.SendMessage(this._hwndSource.Handle, 274U, (IntPtr)((int)(61440 + direction)), IntPtr.Zero);
			this.mWindowInstance.ResizeEnd(this.mWindowInstance, new EventArgs());
		}

		// Token: 0x060011BC RID: 4540 RVA: 0x0006DB5C File Offset: 0x0006BD5C
		internal System.Drawing.Point GetMousePosition()
		{
			WindowWndProcHandler.Win32Point win32Point = default(WindowWndProcHandler.Win32Point);
			WindowWndProcHandler.GetCursorPos(ref win32Point);
			return new System.Drawing.Point(win32Point.X, win32Point.Y);
		}

		// Token: 0x060011BD RID: 4541 RVA: 0x0006DB8C File Offset: 0x0006BD8C
		internal IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
		{
			if (WindowWndProcHandler.isLogWndProc)
			{
				Logger.Info(string.Concat(new object[]
				{
					"WndProcMessage: ",
					msg,
					"~~",
					wParam.ToString(),
					"~~",
					lParam.ToString(),
					"~~"
				}));
			}
			if (msg <= 126)
			{
				if (msg <= 26)
				{
					if (msg != 21 && msg != 26)
					{
						goto IL_2CC;
					}
				}
				else
				{
					if (msg == 36)
					{
						this.WmGetMinMaxInfo(hwnd, lParam);
						handled = true;
						goto IL_2CC;
					}
					if (msg != 70)
					{
						if (msg != 126)
						{
							goto IL_2CC;
						}
					}
					else
					{
						WindowWndProcHandler.WINDOWPOS windowpos = (WindowWndProcHandler.WINDOWPOS)Marshal.PtrToStructure(lParam, typeof(WindowWndProcHandler.WINDOWPOS));
						if ((windowpos.flags & 2) != 0)
						{
							return IntPtr.Zero;
						}
						if ((Window)HwndSource.FromHwnd(hwnd).RootVisual == null)
						{
							return IntPtr.Zero;
						}
						if (this.mWindowInstance.WindowState != WindowState.Normal)
						{
							return IntPtr.Zero;
						}
						bool flag = true;
						if (this.mWindowInstance.MinWidthScaled > windowpos.cx)
						{
							windowpos.cx = this.mWindowInstance.MinWidthScaled;
							windowpos.cy = (int)this.mWindowInstance.GetHeightFromWidth((double)windowpos.cx, true);
							flag = false;
						}
						else if (this.mWindowInstance.MinHeightScaled > windowpos.cy)
						{
							windowpos.cy = this.mWindowInstance.MinHeightScaled;
							windowpos.cx = (int)this.mWindowInstance.GetWidthFromHeight((double)windowpos.cy, true);
							flag = false;
						}
						if (flag)
						{
							if (this.mAdjustingWidth)
							{
								windowpos.cy = (int)this.mWindowInstance.GetHeightFromWidth((double)windowpos.cx, true);
							}
							else
							{
								windowpos.cx = (int)this.mWindowInstance.GetWidthFromHeight((double)windowpos.cy, true);
							}
						}
						Marshal.StructureToPtr(windowpos, lParam, true);
						handled = true;
						goto IL_2CC;
					}
				}
			}
			else if (msg <= 274)
			{
				if (msg != 255)
				{
					if (msg != 274)
					{
						goto IL_2CC;
					}
					if (wParam == (IntPtr)61696)
					{
						handled = true;
						goto IL_2CC;
					}
					goto IL_2CC;
				}
				else
				{
					int num = -1;
					if (this.mRawInput != null)
					{
						num = this.mRawInput.GetDeviceID(lParam);
					}
					if (num == 0 && SecurityMetrics.SecurityMetricsInstanceList.ContainsKey(this.mWindowInstance.mVmName))
					{
						SecurityMetrics.SecurityMetricsInstanceList[this.mWindowInstance.mVmName].AddSecurityBreach(SecurityBreach.SYNTHETIC_INPUT, string.Empty);
						goto IL_2CC;
					}
					goto IL_2CC;
				}
			}
			else
			{
				if (msg == 529)
				{
					handled = true;
					goto IL_2CC;
				}
				if (msg != 537 && msg != 794)
				{
					goto IL_2CC;
				}
			}
			Timer timer = null;
			timer = new Timer(delegate(object x)
			{
				WindowWndProcHandler.SetMenuDropDownAlignment();
				timer.Dispose();
			}, null, TimeSpan.FromMilliseconds(2.0), TimeSpan.FromMilliseconds(-1.0));
			IL_2CC:
			return IntPtr.Zero;
		}

		// Token: 0x060011BE RID: 4542 RVA: 0x0006DE6C File Offset: 0x0006C06C
		private static void SetMenuDropDownAlignment()
		{
			try
			{
				if (SystemParameters.MenuDropAlignment)
				{
					typeof(SystemParameters).GetField("_menuDropAlignment", BindingFlags.Static | BindingFlags.NonPublic).SetValue(null, false);
					bool menuDropAlignment = SystemParameters.MenuDropAlignment;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("error setting _menuDropAlignment" + ex.ToString());
			}
		}

		// Token: 0x060011BF RID: 4543
		[DllImport("user32.dll")]
		public static extern IntPtr MonitorFromWindow(IntPtr handle, int flags);

		// Token: 0x060011C0 RID: 4544
		[DllImport("User32.dll", CharSet = CharSet.Auto)]
		public static extern bool GetMonitorInfo(IntPtr hmonitor, [In] [Out] WindowWndProcHandler.MONITORINFOEX info);

		// Token: 0x060011C1 RID: 4545 RVA: 0x0006DED4 File Offset: 0x0006C0D4
		private void WmGetMinMaxInfo(IntPtr hwnd, IntPtr lParam)
		{
			WindowWndProcHandler.MINMAXINFO minmaxinfo = (WindowWndProcHandler.MINMAXINFO)Marshal.PtrToStructure(lParam, typeof(WindowWndProcHandler.MINMAXINFO));
			IntPtr intPtr = WindowWndProcHandler.MonitorFromWindow(hwnd, 1);
			if (intPtr != IntPtr.Zero)
			{
				WindowWndProcHandler.MONITORINFOEX monitorinfoex = new WindowWndProcHandler.MONITORINFOEX();
				monitorinfoex.cbSize = Marshal.SizeOf(typeof(MONITORINFO));
				WindowWndProcHandler.GetMonitorInfo(intPtr, monitorinfoex);
				IntereopRect rcWork = monitorinfoex.rcWork;
				IntereopRect rcMonitor = monitorinfoex.rcMonitor;
				WindowWndProcHandler.TaskbarLocation taskbarPosition = WindowWndProcHandler.GetTaskbarPosition();
				if (!this.mWindowInstance.mIsFullScreen)
				{
					minmaxinfo.ptMaxPosition.X = Math.Abs(rcWork.Left - rcMonitor.Left);
					minmaxinfo.ptMaxPosition.Y = Math.Abs(rcWork.Top - rcMonitor.Top);
					minmaxinfo.ptMaxSize.X = Math.Abs(rcWork.Width);
					minmaxinfo.ptMaxSize.Y = Math.Abs(rcWork.Height);
					if (rcWork == rcMonitor)
					{
						switch (taskbarPosition)
						{
						case WindowWndProcHandler.TaskbarLocation.Left:
							minmaxinfo.ptMaxPosition.X = minmaxinfo.ptMaxPosition.X + 2;
							break;
						case WindowWndProcHandler.TaskbarLocation.Top:
							minmaxinfo.ptMaxPosition.Y = minmaxinfo.ptMaxPosition.Y + 2;
							break;
						case WindowWndProcHandler.TaskbarLocation.Right:
							minmaxinfo.ptMaxSize.X = minmaxinfo.ptMaxSize.X - 2;
							break;
						case WindowWndProcHandler.TaskbarLocation.Bottom:
							minmaxinfo.ptMaxSize.Y = minmaxinfo.ptMaxSize.Y - 2;
							break;
						}
					}
				}
				else
				{
					minmaxinfo.ptMaxPosition.X = 0;
					minmaxinfo.ptMaxPosition.Y = 0;
					minmaxinfo.ptMaxSize.X = Math.Abs(rcMonitor.Width);
					minmaxinfo.ptMaxSize.Y = Math.Abs(rcMonitor.Height);
				}
				minmaxinfo.ptMaxTrackSize.X = minmaxinfo.ptMaxSize.X;
				minmaxinfo.ptMaxTrackSize.Y = minmaxinfo.ptMaxSize.Y;
			}
			Marshal.StructureToPtr(minmaxinfo, lParam, true);
		}

		// Token: 0x060011C2 RID: 4546 RVA: 0x0006E0C8 File Offset: 0x0006C2C8
		internal static IntereopRect GetFullscreenMonitorSize(IntPtr hwnd, bool isWorkAreaRequired = false)
		{
			IntPtr intPtr = WindowWndProcHandler.MonitorFromWindow(hwnd, 1);
			new System.Windows.Size(SystemParameters.MaximizedPrimaryScreenWidth, SystemParameters.MaximizedPrimaryScreenHeight);
			if (!(intPtr != IntPtr.Zero))
			{
				return default(IntereopRect);
			}
			WindowWndProcHandler.MONITORINFOEX monitorinfoex = new WindowWndProcHandler.MONITORINFOEX();
			WindowWndProcHandler.GetMonitorInfo(intPtr, monitorinfoex);
			if (isWorkAreaRequired)
			{
				return monitorinfoex.rcWork;
			}
			return monitorinfoex.rcMonitor;
		}

		// Token: 0x060011C3 RID: 4547
		[DllImport("shell32.dll")]
		private static extern IntPtr SHAppBarMessage(int msg, ref WindowWndProcHandler.APPBARDATA data);

		// Token: 0x060011C4 RID: 4548 RVA: 0x0006E124 File Offset: 0x0006C324
		private static WindowWndProcHandler.TaskbarLocation GetTaskbarPosition()
		{
			WindowWndProcHandler.TaskbarLocation result = WindowWndProcHandler.TaskbarLocation.None;
			WindowWndProcHandler.APPBARDATA appbardata = default(WindowWndProcHandler.APPBARDATA);
			appbardata.cbSize = Marshal.SizeOf(appbardata);
			if (WindowWndProcHandler.SHAppBarMessage(5, ref appbardata) == IntPtr.Zero)
			{
				return result;
			}
			if (appbardata.rc.Left == appbardata.rc.Top)
			{
				if (appbardata.rc.Right < appbardata.rc.Bottom)
				{
					result = WindowWndProcHandler.TaskbarLocation.Left;
				}
				if (appbardata.rc.Right > appbardata.rc.Bottom)
				{
					result = WindowWndProcHandler.TaskbarLocation.Top;
				}
			}
			if (appbardata.rc.Left > appbardata.rc.Top)
			{
				result = WindowWndProcHandler.TaskbarLocation.Right;
			}
			if (appbardata.rc.Left < appbardata.rc.Top)
			{
				result = WindowWndProcHandler.TaskbarLocation.Bottom;
			}
			return result;
		}

		// Token: 0x04000C22 RID: 3106
		private const int ABM_GETTASKBARPOS = 5;

		// Token: 0x04000C23 RID: 3107
		internal bool IsResizingEnabled = true;

		// Token: 0x04000C24 RID: 3108
		internal bool IsMinMaxEnabled = true;

		// Token: 0x04000C25 RID: 3109
		internal bool mAdjustingWidth;

		// Token: 0x04000C26 RID: 3110
		private MainWindow mWindowInstance;

		// Token: 0x04000C27 RID: 3111
		private RawInputClass mRawInput;

		// Token: 0x04000C28 RID: 3112
		private HwndSource _hwndSource;

		// Token: 0x04000C29 RID: 3113
		internal static bool isLogWndProc;

		// Token: 0x04000C2A RID: 3114
		private const int MONITOR_DEFAULTTOPRIMARY = 1;

		// Token: 0x02000204 RID: 516
		internal enum ResizeDirection
		{
			// Token: 0x04000C2C RID: 3116
			Left = 1,
			// Token: 0x04000C2D RID: 3117
			Right,
			// Token: 0x04000C2E RID: 3118
			Top,
			// Token: 0x04000C2F RID: 3119
			TopLeft,
			// Token: 0x04000C30 RID: 3120
			TopRight,
			// Token: 0x04000C31 RID: 3121
			Bottom,
			// Token: 0x04000C32 RID: 3122
			BottomLeft,
			// Token: 0x04000C33 RID: 3123
			BottomRight
		}

		// Token: 0x02000205 RID: 517
		private struct WINDOWPOS
		{
			// Token: 0x04000C34 RID: 3124
			public IntPtr hwnd;

			// Token: 0x04000C35 RID: 3125
			public IntPtr hwndInsertAfter;

			// Token: 0x04000C36 RID: 3126
			public int x;

			// Token: 0x04000C37 RID: 3127
			public int y;

			// Token: 0x04000C38 RID: 3128
			public int cx;

			// Token: 0x04000C39 RID: 3129
			public int cy;

			// Token: 0x04000C3A RID: 3130
			public int flags;
		}

		// Token: 0x02000206 RID: 518
		private enum SWP
		{
			// Token: 0x04000C3C RID: 3132
			NOMOVE = 2
		}

		// Token: 0x02000207 RID: 519
		private enum WM
		{
			// Token: 0x04000C3E RID: 3134
			SYSCOMMAND = 274,
			// Token: 0x04000C3F RID: 3135
			ENTERMENULOOP = 529,
			// Token: 0x04000C40 RID: 3136
			WINDOWPOSCHANGING = 70,
			// Token: 0x04000C41 RID: 3137
			NCCALCSIZE = 131,
			// Token: 0x04000C42 RID: 3138
			EXITSIZEMOVE = 562,
			// Token: 0x04000C43 RID: 3139
			GETMINMAXINFO = 36,
			// Token: 0x04000C44 RID: 3140
			WININICHANGE = 26,
			// Token: 0x04000C45 RID: 3141
			DEVICECHANGE = 537,
			// Token: 0x04000C46 RID: 3142
			DISPLAYCHANGE = 126,
			// Token: 0x04000C47 RID: 3143
			THEMECHANGED = 794,
			// Token: 0x04000C48 RID: 3144
			SYSCOLORCHANGE = 21,
			// Token: 0x04000C49 RID: 3145
			INPUT = 255
		}

		// Token: 0x02000208 RID: 520
		private struct Win32Point
		{
			// Token: 0x04000C4A RID: 3146
			public int X;

			// Token: 0x04000C4B RID: 3147
			public int Y;
		}

		// Token: 0x02000209 RID: 521
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto, Pack = 4)]
		public class MONITORINFOEX
		{
			// Token: 0x04000C4C RID: 3148
			public int cbSize = Marshal.SizeOf(typeof(WindowWndProcHandler.MONITORINFOEX));

			// Token: 0x04000C4D RID: 3149
			public IntereopRect rcMonitor;

			// Token: 0x04000C4E RID: 3150
			public IntereopRect rcWork;

			// Token: 0x04000C4F RID: 3151
			public int dwFlags;

			// Token: 0x04000C50 RID: 3152
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
			public char[] szDevice = new char[32];
		}

		// Token: 0x0200020A RID: 522
		internal struct MINMAXINFO
		{
			// Token: 0x04000C51 RID: 3153
			public WindowWndProcHandler.POINT ptReserved;

			// Token: 0x04000C52 RID: 3154
			public WindowWndProcHandler.POINT ptMaxSize;

			// Token: 0x04000C53 RID: 3155
			public WindowWndProcHandler.POINT ptMaxPosition;

			// Token: 0x04000C54 RID: 3156
			public WindowWndProcHandler.POINT ptMinTrackSize;

			// Token: 0x04000C55 RID: 3157
			public WindowWndProcHandler.POINT ptMaxTrackSize;
		}

		// Token: 0x0200020B RID: 523
		public struct POINT
		{
			// Token: 0x060011C7 RID: 4551 RVA: 0x0000C96A File Offset: 0x0000AB6A
			public POINT(int x, int y)
			{
				this.X = x;
				this.Y = y;
			}

			// Token: 0x060011C8 RID: 4552 RVA: 0x0000C97A File Offset: 0x0000AB7A
			public POINT(System.Drawing.Point pt)
			{
				this = new WindowWndProcHandler.POINT(pt.X, pt.Y);
			}

			// Token: 0x060011C9 RID: 4553 RVA: 0x0000C990 File Offset: 0x0000AB90
			public static implicit operator System.Drawing.Point(WindowWndProcHandler.POINT p)
			{
				return new System.Drawing.Point(p.X, p.Y);
			}

			// Token: 0x060011CA RID: 4554 RVA: 0x0000C9A3 File Offset: 0x0000ABA3
			public static implicit operator WindowWndProcHandler.POINT(System.Drawing.Point p)
			{
				return new WindowWndProcHandler.POINT(p.X, p.Y);
			}

			// Token: 0x04000C56 RID: 3158
			public int X;

			// Token: 0x04000C57 RID: 3159
			public int Y;
		}

		// Token: 0x0200020C RID: 524
		private struct APPBARDATA
		{
			// Token: 0x04000C58 RID: 3160
			public int cbSize;

			// Token: 0x04000C59 RID: 3161
			public IntPtr hWnd;

			// Token: 0x04000C5A RID: 3162
			public int uCallbackMessage;

			// Token: 0x04000C5B RID: 3163
			public int uEdge;

			// Token: 0x04000C5C RID: 3164
			public RECT rc;

			// Token: 0x04000C5D RID: 3165
			public IntPtr lParam;
		}

		// Token: 0x0200020D RID: 525
		private enum TaskbarLocation
		{
			// Token: 0x04000C5F RID: 3167
			None,
			// Token: 0x04000C60 RID: 3168
			Left,
			// Token: 0x04000C61 RID: 3169
			Top,
			// Token: 0x04000C62 RID: 3170
			Right,
			// Token: 0x04000C63 RID: 3171
			Bottom
		}
	}
}
