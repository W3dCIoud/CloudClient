﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Effects;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000DC RID: 220
	public class AdvancedSettingsItemPanel : UserControl, IComponentConnector
	{
		// Token: 0x1700016F RID: 367
		// (get) Token: 0x06000927 RID: 2343 RVA: 0x00007ADC File Offset: 0x00005CDC
		// (set) Token: 0x06000928 RID: 2344 RVA: 0x00007AE4 File Offset: 0x00005CE4
		public EventHandler Tap
		{
			get
			{
				return this.mTap;
			}
			set
			{
				this.mTap = value;
			}
		}

		// Token: 0x17000170 RID: 368
		// (get) Token: 0x06000929 RID: 2345 RVA: 0x00007AED File Offset: 0x00005CED
		// (set) Token: 0x0600092A RID: 2346 RVA: 0x00007AF5 File Offset: 0x00005CF5
		public EventHandler MouseDragStart
		{
			get
			{
				return this.mMouseDragStart;
			}
			set
			{
				this.mMouseDragStart = value;
			}
		}

		// Token: 0x17000171 RID: 369
		// (get) Token: 0x0600092B RID: 2347 RVA: 0x00007AFE File Offset: 0x00005CFE
		// (set) Token: 0x0600092C RID: 2348 RVA: 0x0003DC80 File Offset: 0x0003BE80
		public KeyActionType ActionType
		{
			get
			{
				return this.mActionType;
			}
			set
			{
				this.mActionType = value;
				this.mImage.ImageName = this.mActionType.ToString() + "_sidebar";
				BlueStacksUIBinding.Bind(this.mActionHeader, Constants.ImapLocaleStringsConstant + this.mActionType.ToString() + "_Header_Edit_UI", "");
			}
		}

		// Token: 0x0600092D RID: 2349 RVA: 0x00007B06 File Offset: 0x00005D06
		public AdvancedSettingsItemPanel()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600092E RID: 2350 RVA: 0x0003DCEC File Offset: 0x0003BEEC
		private void Image_MouseEnter(object sender, MouseEventArgs e)
		{
			base.Cursor = Cursors.Hand;
			this.mDragImage.Visibility = Visibility.Visible;
			BlueStacksUIBinding.BindColor(this.mBorder, Control.BorderBrushProperty, "AdvancedGameControlHeaderBackgroundColor");
			this.mBorder.Effect = new DropShadowEffect
			{
				Direction = 270.0,
				ShadowDepth = 3.0,
				BlurRadius = 12.0,
				Opacity = 0.75,
				Color = ((SolidColorBrush)this.mBorder.Background).Color
			};
		}

		// Token: 0x0600092F RID: 2351 RVA: 0x0003DD8C File Offset: 0x0003BF8C
		private void Image_MouseLeave(object sender, MouseEventArgs e)
		{
			if (KMManager.sDragCanvasElement == null)
			{
				base.Cursor = Cursors.Arrow;
			}
			this.mDragImage.Visibility = Visibility.Hidden;
			BlueStacksUIBinding.BindColor(this.mBorder, Control.BorderBrushProperty, "AdvancedSettingsItemPanelBorder");
			this.mBorder.Effect = null;
		}

		// Token: 0x06000930 RID: 2352 RVA: 0x00007B14 File Offset: 0x00005D14
		private void Image_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			this.mousePressedPosition = new Point?(e.GetPosition(this));
		}

		// Token: 0x06000931 RID: 2353 RVA: 0x0003DDD8 File Offset: 0x0003BFD8
		private void Image_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			this.mouseReleasedPosition = new Point?(e.GetPosition(this));
			if (this.mousePressedPosition.Equals(this.mouseReleasedPosition))
			{
				EventHandler tap = this.Tap;
				if (tap != null)
				{
					tap(this, null);
				}
			}
			else
			{
				KMManager.ClearElement();
			}
			this.ReatchedMouseMove();
		}

		// Token: 0x06000932 RID: 2354 RVA: 0x00007B28 File Offset: 0x00005D28
		private void OnTimedElapsed(object sender, ElapsedEventArgs e)
		{
			if (!this.mousePressedPosition.Equals(this.mouseReleasedPosition))
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					EventHandler mouseDragStart = this.MouseDragStart;
					if (mouseDragStart == null)
					{
						return;
					}
					mouseDragStart(this, null);
				}), new object[0]);
			}
		}

		// Token: 0x06000933 RID: 2355 RVA: 0x0003DE38 File Offset: 0x0003C038
		private void Image_MouseMove(object sender, MouseEventArgs e)
		{
			if (this.mousePressedPosition != null && !this.mousePressedPosition.Equals(this.mouseReleasedPosition))
			{
				base.MouseMove -= this.Image_MouseMove;
				EventHandler mouseDragStart = this.MouseDragStart;
				if (mouseDragStart == null)
				{
					return;
				}
				mouseDragStart(this, null);
			}
		}

		// Token: 0x06000934 RID: 2356 RVA: 0x00007B66 File Offset: 0x00005D66
		public void ReatchedMouseMove()
		{
			this.mousePressedPosition = null;
			base.MouseMove -= this.Image_MouseMove;
			base.MouseMove += this.Image_MouseMove;
		}

		// Token: 0x06000935 RID: 2357 RVA: 0x0003DE94 File Offset: 0x0003C094
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/advancedsettingsitempanel.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000936 RID: 2358 RVA: 0x0003DEC4 File Offset: 0x0003C0C4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((AdvancedSettingsItemPanel)target).MouseEnter += this.Image_MouseEnter;
				((AdvancedSettingsItemPanel)target).MouseLeave += this.Image_MouseLeave;
				((AdvancedSettingsItemPanel)target).PreviewMouseDown += this.Image_PreviewMouseDown;
				((AdvancedSettingsItemPanel)target).MouseMove += this.Image_MouseMove;
				((AdvancedSettingsItemPanel)target).PreviewMouseUp += this.Image_PreviewMouseUp;
				return;
			case 2:
				this.mBorder = (Border)target;
				return;
			case 3:
				this.mDragImage = (CustomPictureBox)target;
				return;
			case 4:
				this.mImage = (CustomPictureBox)target;
				return;
			case 5:
				this.mActionHeader = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400069B RID: 1691
		private EventHandler mTap;

		// Token: 0x0400069C RID: 1692
		private EventHandler mMouseDragStart;

		// Token: 0x0400069D RID: 1693
		private KeyActionType mActionType;

		// Token: 0x0400069E RID: 1694
		private Point? mousePressedPosition;

		// Token: 0x0400069F RID: 1695
		private Point? mouseReleasedPosition;

		// Token: 0x040006A0 RID: 1696
		internal Border mBorder;

		// Token: 0x040006A1 RID: 1697
		internal CustomPictureBox mDragImage;

		// Token: 0x040006A2 RID: 1698
		internal CustomPictureBox mImage;

		// Token: 0x040006A3 RID: 1699
		internal TextBlock mActionHeader;

		// Token: 0x040006A4 RID: 1700
		private bool _contentLoaded;
	}
}
