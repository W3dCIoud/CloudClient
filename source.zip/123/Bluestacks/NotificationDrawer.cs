﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000082 RID: 130
	public class NotificationDrawer : UserControl, IComponentConnector
	{
		// Token: 0x060005D0 RID: 1488 RVA: 0x00005C6C File Offset: 0x00003E6C
		public NotificationDrawer()
		{
			this.InitializeComponent();
		}

		// Token: 0x060005D1 RID: 1489 RVA: 0x00024E08 File Offset: 0x00023008
		internal void Populate(SerializableDictionary<string, GenericNotificationItem> items)
		{
			new List<NotificationDrawerItem>();
			new List<NotificationDrawerItem>();
			new List<string>();
			new List<string>();
			StackPanel stackPanel = this.mNotificationScroll.Content as StackPanel;
			Panel panel = this.mImportantNotificationScroll.Content as StackPanel;
			Grid grid = null;
			if (stackPanel.Children.OfType<Grid>().Count<Grid>() > 0)
			{
				grid = stackPanel.Children.OfType<Grid>().First<Grid>();
			}
			stackPanel.Children.Clear();
			panel.Children.Clear();
			if (grid != null)
			{
				stackPanel.Children.Add(grid);
			}
			foreach (KeyValuePair<string, GenericNotificationItem> keyValuePair in from _ in items
			where !_.Value.IsDeleted
			select _)
			{
				this.AddNotificationItem(keyValuePair.Value);
			}
			this.HideUnhideNoNotification();
		}

		// Token: 0x060005D2 RID: 1490 RVA: 0x00024F04 File Offset: 0x00023104
		private void HideUnhideNoNotification()
		{
			StackPanel stackPanel = this.mNotificationScroll.Content as StackPanel;
			StackPanel stackPanel2 = this.mImportantNotificationScroll.Content as StackPanel;
			if (stackPanel2.Children.OfType<NotificationDrawerItem>().Count<NotificationDrawerItem>() == 0 && stackPanel.Children.OfType<NotificationDrawerItem>().Count<NotificationDrawerItem>() == 0)
			{
				this.grdImportantUpdates.Visibility = Visibility.Collapsed;
				if (stackPanel.Children.OfType<Grid>().Count<Grid>() > 0)
				{
					this.grdNormalUpdates.Visibility = Visibility.Visible;
					stackPanel.Children.OfType<Grid>().First<Grid>().Visibility = Visibility.Visible;
					this.noNotification = true;
					return;
				}
			}
			else
			{
				if (stackPanel2.Children.OfType<NotificationDrawerItem>().Count<NotificationDrawerItem>() == 0)
				{
					this.grdImportantUpdates.Visibility = Visibility.Collapsed;
				}
				if (stackPanel.Children.OfType<NotificationDrawerItem>().Count<NotificationDrawerItem>() == 0)
				{
					this.grdNormalUpdates.Visibility = Visibility.Collapsed;
				}
				if (this.noNotification && stackPanel.Children.OfType<Grid>().Count<Grid>() > 0)
				{
					stackPanel.Children.OfType<Grid>().First<Grid>().Visibility = Visibility.Collapsed;
				}
			}
		}

		// Token: 0x060005D3 RID: 1491 RVA: 0x00025010 File Offset: 0x00023210
		private void AddNotificationItem(GenericNotificationItem notifItem)
		{
			try
			{
				NotificationDrawerItem notificationDrawerItem = new NotificationDrawerItem();
				notificationDrawerItem.InitFromGenricNotificationItem(notifItem, this.ParentWindow);
				if (notifItem.Priority == NotificationPriority.Important)
				{
					(this.mImportantNotificationScroll.Content as StackPanel).Children.Insert(0, notificationDrawerItem);
					this.grdImportantUpdates.Visibility = Visibility.Visible;
				}
				else
				{
					(this.mNotificationScroll.Content as StackPanel).Children.Insert(0, notificationDrawerItem);
					this.grdNormalUpdates.Visibility = Visibility.Visible;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Could not add notificationdraweritem. Id " + notifItem.Id + "Error:" + ex.ToString());
			}
		}

		// Token: 0x060005D4 RID: 1492 RVA: 0x000250C0 File Offset: 0x000232C0
		private void ClearButton_Click(object sender, RoutedEventArgs e)
		{
			this.ParentWindow.mTopBar.mNotificationCentrePopup.IsOpen = false;
			StackPanel stackPanel = this.mNotificationScroll.Content as StackPanel;
			this.ParentWindow.mTopBar.mNotificationDrawerControl.Populate(GenericNotificationManager.Instance.MarkNotification(from _ in stackPanel.Children.OfType<NotificationDrawerItem>()
			select _.Id, delegate(GenericNotificationItem _)
			{
				_.IsDeleted = true;
			}));
			this.ParentWindow.mTopBar.RefreshNotificationCentreButton();
			this.ParentWindow.mTopBar.mNotificationCentrePopup.IsOpen = true;
		}

		// Token: 0x060005D5 RID: 1493 RVA: 0x00025188 File Offset: 0x00023388
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/genericnotification/notificationdrawer.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060005D6 RID: 1494 RVA: 0x000251B8 File Offset: 0x000233B8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.grdImportantUpdates = (Grid)target;
				return;
			case 2:
				this.mImportantNotificationScroll = (ScrollViewer)target;
				return;
			case 3:
				this.grdNormalUpdates = (Grid)target;
				return;
			case 4:
				((CustomButton)target).Click += this.ClearButton_Click;
				return;
			case 5:
				this.mNotificationScroll = (ScrollViewer)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040003A0 RID: 928
		internal MainWindow ParentWindow;

		// Token: 0x040003A1 RID: 929
		private bool noNotification;

		// Token: 0x040003A2 RID: 930
		internal Grid grdImportantUpdates;

		// Token: 0x040003A3 RID: 931
		internal ScrollViewer mImportantNotificationScroll;

		// Token: 0x040003A4 RID: 932
		internal Grid grdNormalUpdates;

		// Token: 0x040003A5 RID: 933
		internal ScrollViewer mNotificationScroll;

		// Token: 0x040003A6 RID: 934
		private bool _contentLoaded;
	}
}
