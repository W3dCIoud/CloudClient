﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200007D RID: 125
	public class Gl3CustomWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x060005A6 RID: 1446 RVA: 0x00005B17 File Offset: 0x00003D17
		public Gl3CustomWindow(MainWindow parentWindow)
		{
			this.mParentWindow = parentWindow;
			this.InitializeComponent();
		}

		// Token: 0x060005A7 RID: 1447 RVA: 0x00024640 File Offset: 0x00022840
		private void mGetButton_Click(object sender, RoutedEventArgs e)
		{
			Logger.Info("Clicked Restart to opengl button");
			if (RegistryManager.Instance.GLES3 && this.mParentWindow.EngineInstanceRegistry.GlRenderMode != 1)
			{
				this.mParentWindow.EngineInstanceRegistry.GlRenderMode = 1;
				BlueStacksUIUtils.RestartInstance(this.mParentWindow.mVmName);
				return;
			}
			base.Close();
		}

		// Token: 0x060005A8 RID: 1448 RVA: 0x00005B2C File Offset: 0x00003D2C
		private void Close_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked Gl3 custom window close button");
			base.Close();
		}

		// Token: 0x060005A9 RID: 1449 RVA: 0x000246A0 File Offset: 0x000228A0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/gl3customwindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060005AA RID: 1450 RVA: 0x000246D0 File Offset: 0x000228D0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				this.mParentGrid = (Grid)target;
				return;
			case 3:
				this.mTextBlockGrid = (Grid)target;
				return;
			case 4:
				this.mCustomMessageBoxCloseButton = (CustomPictureBox)target;
				this.mCustomMessageBoxCloseButton.PreviewMouseLeftButtonUp += this.Close_PreviewMouseLeftButtonUp;
				return;
			case 5:
				this.mTitleText = (TextBlock)target;
				return;
			case 6:
				this.mTitleIcon = (CustomPictureBox)target;
				return;
			case 7:
				this.mBodyTextBlock = (TextBlock)target;
				return;
			case 8:
				this.mHintGrid = (Grid)target;
				return;
			case 9:
				this.mHintTextBlock = (TextBlock)target;
				return;
			case 10:
				this.mHintGrid1 = (Grid)target;
				return;
			case 11:
				this.mHintTextBlock1 = (TextBlock)target;
				return;
			case 12:
				this.mButton = (CustomButton)target;
				this.mButton.Click += this.mGetButton_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000380 RID: 896
		private MainWindow mParentWindow;

		// Token: 0x04000381 RID: 897
		internal Border mMaskBorder;

		// Token: 0x04000382 RID: 898
		internal Grid mParentGrid;

		// Token: 0x04000383 RID: 899
		internal Grid mTextBlockGrid;

		// Token: 0x04000384 RID: 900
		internal CustomPictureBox mCustomMessageBoxCloseButton;

		// Token: 0x04000385 RID: 901
		internal TextBlock mTitleText;

		// Token: 0x04000386 RID: 902
		internal CustomPictureBox mTitleIcon;

		// Token: 0x04000387 RID: 903
		internal TextBlock mBodyTextBlock;

		// Token: 0x04000388 RID: 904
		internal Grid mHintGrid;

		// Token: 0x04000389 RID: 905
		internal TextBlock mHintTextBlock;

		// Token: 0x0400038A RID: 906
		internal Grid mHintGrid1;

		// Token: 0x0400038B RID: 907
		internal TextBlock mHintTextBlock1;

		// Token: 0x0400038C RID: 908
		internal CustomButton mButton;

		// Token: 0x0400038D RID: 909
		private bool _contentLoaded;
	}
}
