﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Navigation;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000138 RID: 312
	public class UpdatePrompt : UserControl, IComponentConnector
	{
		// Token: 0x06000C30 RID: 3120 RVA: 0x000533D4 File Offset: 0x000515D4
		internal UpdatePrompt(BlueStacksUpdateData bstUpdateData)
		{
			this.InitializeComponent();
			this.mBstUpdateData = bstUpdateData;
			if (string.IsNullOrEmpty(bstUpdateData.EngineVersion))
			{
				this.mLabelVersion.Content = "";
				this.mLabelVersion.Visibility = Visibility.Collapsed;
			}
			else
			{
				this.mLabelVersion.Content = "v" + bstUpdateData.EngineVersion;
			}
			BlueStacksUIBinding.Bind(this.titleLabel, "STRING_BLUESTACKS_UPDATE_AVAILABLE");
			BlueStacksUIBinding.Bind(this.bodyLabel, "STRING_UPDATE_AVAILABLE");
			BlueStacksUIBinding.Bind(this.mDownloadNewButton, "STRING_DOWNLOAD_UPDATE");
			this.mCloseBtn.Visibility = Visibility.Visible;
			this.mDetailedChangeLogs.NavigateUri = new Uri(bstUpdateData.DetailedChangeLogsUrl);
			this.mDetailedChangeLogs.Inlines.Clear();
			this.mDetailedChangeLogs.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_DETAILED_CHANGELOG", false));
		}

		// Token: 0x06000C31 RID: 3121 RVA: 0x00009701 File Offset: 0x00007901
		private void CloseBtn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked UpdateNow Menu Close button");
			RegistryManager.Instance.LastUpdateSkippedVersion = this.mBstUpdateData.EngineVersion;
			ClientStats.SendBluestacksUpdaterUIStatsAsync(ClientStatsEvent.UpgradePopupCross, "");
			BlueStacksUIUtils.CloseContainerWindow(this);
		}

		// Token: 0x06000C32 RID: 3122 RVA: 0x00009737 File Offset: 0x00007937
		private void DownloadNowButton_Click(object sender, RoutedEventArgs e)
		{
			Logger.Info("Clicked Download_Now button");
			ClientStats.SendBluestacksUpdaterUIStatsAsync(ClientStatsEvent.UpgradePopupDwnld, "");
			BlueStacksUpdater.DownloadNow(this.mBstUpdateData, false);
			BlueStacksUIUtils.CloseContainerWindow(this);
		}

		// Token: 0x06000C33 RID: 3123 RVA: 0x00009399 File Offset: 0x00007599
		private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
		{
			BlueStacksUIUtils.OpenUrl(e.Uri.OriginalString);
			e.Handled = true;
		}

		// Token: 0x06000C34 RID: 3124 RVA: 0x000534B8 File Offset: 0x000516B8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/updateprompt.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000C35 RID: 3125 RVA: 0x000534E8 File Offset: 0x000516E8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.titleLabel = (Label)target;
				return;
			case 2:
				this.mCloseBtn = (CustomPictureBox)target;
				this.mCloseBtn.MouseLeftButtonUp += this.CloseBtn_MouseLeftButtonUp;
				return;
			case 3:
				this.bodyLabel = (Label)target;
				return;
			case 4:
				this.mLabelVersion = (Label)target;
				return;
			case 5:
				this.mDetailedChangeLogs = (Hyperlink)target;
				this.mDetailedChangeLogs.RequestNavigate += this.Hyperlink_RequestNavigate;
				return;
			case 6:
				this.mDownloadNewButton = (CustomButton)target;
				this.mDownloadNewButton.Click += this.DownloadNowButton_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040008F6 RID: 2294
		private BlueStacksUpdateData mBstUpdateData;

		// Token: 0x040008F7 RID: 2295
		internal Label titleLabel;

		// Token: 0x040008F8 RID: 2296
		internal CustomPictureBox mCloseBtn;

		// Token: 0x040008F9 RID: 2297
		internal Label bodyLabel;

		// Token: 0x040008FA RID: 2298
		internal Label mLabelVersion;

		// Token: 0x040008FB RID: 2299
		internal Hyperlink mDetailedChangeLogs;

		// Token: 0x040008FC RID: 2300
		internal CustomButton mDownloadNewButton;

		// Token: 0x040008FD RID: 2301
		private bool _contentLoaded;
	}
}
