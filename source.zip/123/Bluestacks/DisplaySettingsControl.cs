﻿using System;
using System.Windows;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000B4 RID: 180
	public class DisplaySettingsControl : DisplaySettingsBase
	{
		// Token: 0x06000758 RID: 1880 RVA: 0x0002E03C File Offset: 0x0002C23C
		public DisplaySettingsControl(MainWindow window)
		{
			this.ParentWindow = window;
			this.mVmName = window.mVmName;
			base.Init();
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				base.RestartNowBtn.Content = LocaleStrings.GetLocalizedString("STRING_QUIT_TEXT", false);
			}
		}

		// Token: 0x06000759 RID: 1881 RVA: 0x0002E08C File Offset: 0x0002C28C
		protected override void RestartNowBtn_Click(object sender, RoutedEventArgs e)
		{
			Logger.Info("Restart now button pressed");
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				BlueStacksUIUtils.CloseContainerWindow(this);
				this.ParentWindow.Close();
				return;
			}
			BlueStacksUIBinding.Bind(base.RestartNowBtn, "STRING_RESTARTING");
			BlueStacksUIUtils.CloseContainerWindow(this);
			BlueStacksUIUtils.RestartInstance(this.mVmName);
		}

		// Token: 0x04000508 RID: 1288
		private MainWindow ParentWindow;
	}
}
