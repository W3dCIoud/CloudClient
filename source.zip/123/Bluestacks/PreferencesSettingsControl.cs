﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000135 RID: 309
	public class PreferencesSettingsControl : UserControl, IComponentConnector
	{
		// Token: 0x06000C1E RID: 3102 RVA: 0x000522D0 File Offset: 0x000504D0
		public PreferencesSettingsControl(MainWindow window)
		{
			this.InitializeComponent();
			this.mChangePrefGrid.Visibility = Visibility.Visible;
			this.mChangeLocaleGrid.Visibility = Visibility.Collapsed;
			this.ParentWindow = window;
			base.Visibility = Visibility.Hidden;
			this.InitSettings();
			this.AddLanguages();
			this.AddQuitOptions();
			if (!FeatureManager.Instance.IsShowLanguagePreference)
			{
				this.mLanguageSettingsGrid.Visibility = Visibility.Collapsed;
				this.mLanguagePreferencePaddingGrid.Visibility = Visibility.Collapsed;
			}
			if (!FeatureManager.Instance.IsShowDesktopShortcutPreference)
			{
				this.mAddDesktopShortcuts.Visibility = Visibility.Collapsed;
			}
			if (!FeatureManager.Instance.IsShowGamingSummaryPreference)
			{
				this.mShowGamingSummary.Visibility = Visibility.Collapsed;
			}
			if (!FeatureManager.Instance.IsShowPerformancePreference)
			{
				this.mPerformancePreference.Visibility = Visibility.Collapsed;
				this.mPerformancePreferencePaddingGrid.Visibility = Visibility.Collapsed;
			}
			if (!FeatureManager.Instance.IsShowDiscordPreference)
			{
				this.mDiscordCheckBox.Visibility = Visibility.Collapsed;
			}
			if (!FeatureManager.Instance.IsCustomCursorEnabled)
			{
				this.mCustomCursorCheckbox.Visibility = Visibility.Collapsed;
			}
			if (!FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.mQuitOptionsGrid.Visibility = Visibility.Collapsed;
			}
			this.mScrollBar.ScrollChanged += BluestacksUIColor.ScrollBarScrollChanged;
		}

		// Token: 0x06000C1F RID: 3103 RVA: 0x00052404 File Offset: 0x00050604
		private void AddQuitOptions()
		{
			ComboBoxItem comboBoxItem = null;
			foreach (string text in LocaleStringsConstants.ExitOptions)
			{
				ComboBoxItem comboBoxItem2 = new ComboBoxItem();
				comboBoxItem2.Content = LocaleStrings.GetLocalizedString(text, false);
				comboBoxItem2.Tag = text;
				this.mQuitOptionsComboBox.Items.Add(comboBoxItem2);
				if (text == RegistryManager.Instance.QuitDefaultOption)
				{
					comboBoxItem = comboBoxItem2;
				}
			}
			foreach (string text2 in LocaleStringsConstants.RestartOptions)
			{
				ComboBoxItem comboBoxItem3 = new ComboBoxItem();
				comboBoxItem3.Content = LocaleStrings.GetLocalizedString(text2, false);
				this.mQuitOptionsComboBox.Items.Add(comboBoxItem3);
				comboBoxItem3.Tag = text2;
				if (text2 == RegistryManager.Instance.QuitDefaultOption)
				{
					comboBoxItem = comboBoxItem3;
				}
			}
			if (comboBoxItem == null)
			{
				this.mQuitOptionsComboBox.SelectedIndex = 0;
				return;
			}
			this.mQuitOptionsComboBox.SelectedItem = comboBoxItem;
		}

		// Token: 0x06000C20 RID: 3104 RVA: 0x000524F0 File Offset: 0x000506F0
		private void AddLanguages()
		{
			foreach (string key in LocaleStrings.sSupportedLocales.Keys)
			{
				ComboBoxItem comboBoxItem = new ComboBoxItem();
				comboBoxItem.Content = LocaleStrings.sSupportedLocales[key].ToString();
				this.dictComboBoxItems.Add(comboBoxItem.Content.ToString(), comboBoxItem);
				this.mLanguageCombobox.Items.Add(comboBoxItem);
			}
			this.SelectDefaultValue();
		}

		// Token: 0x06000C21 RID: 3105 RVA: 0x0005258C File Offset: 0x0005078C
		private void SelectDefaultValue()
		{
			this.mLanguageCombobox.SelectionChanged -= this.mLanguageCombobox_SelectionChanged;
			string text = RegistryManager.Instance.UserSelectedLocale;
			if (string.IsNullOrEmpty(text))
			{
				text = LocaleStrings.GetLocaleName("Android", false);
				RegistryManager.Instance.UserSelectedLocale = text;
			}
			else if (!LocaleStrings.sSupportedLocales.ContainsKey(text))
			{
				string locale = text;
				text = "en-US";
				string text2 = LocaleStrings.sSupportedLocales.Keys.FirstOrDefault((string x) => x.StartsWith(locale.Substring(0, 2)));
				if (!string.IsNullOrEmpty(text2))
				{
					text = text2;
				}
			}
			this.mLanguageCombobox.SelectedItem = this.dictComboBoxItems[LocaleStrings.sSupportedLocales[text].ToString()];
			this.mLanguageCombobox.SelectionChanged += this.mLanguageCombobox_SelectionChanged;
		}

		// Token: 0x06000C22 RID: 3106 RVA: 0x00052660 File Offset: 0x00050860
		private void InitSettings()
		{
			if (!this.ParentWindow.IsDefaultVM)
			{
				this.mAddDesktopShortcuts.Visibility = Visibility.Collapsed;
			}
			if (RegistryManager.Instance.AddDesktopShortcuts)
			{
				this.mAddDesktopShortcuts.IsChecked = new bool?(true);
			}
			if (RegistryManager.Instance.SwitchToAndroidHome)
			{
				this.mSwitchToHome.IsChecked = new bool?(true);
			}
			else
			{
				this.mSwitchToHome.IsChecked = new bool?(false);
			}
			if (RegistryManager.Instance.SwitchKillWebTab)
			{
				this.mSwitchKillWebTab.IsChecked = new bool?(true);
			}
			else
			{
				this.mSwitchKillWebTab.IsChecked = new bool?(false);
			}
			if (RegistryManager.Instance.ShowGamingSummary)
			{
				this.mShowGamingSummary.IsChecked = new bool?(true);
			}
			else
			{
				this.mShowGamingSummary.IsChecked = new bool?(false);
			}
			if (FeatureManager.Instance.IsMacroRecorderEnabled)
			{
				this.mShowMacroDeleteWarning.IsChecked = new bool?(this.ParentWindow.EngineInstanceRegistry.ShowMacroDeletePopup);
			}
			else
			{
				this.mShowMacroDeleteWarning.Visibility = Visibility.Collapsed;
			}
			this.mShowSchemeDeleteWarning.IsChecked = new bool?(this.ParentWindow.EngineInstanceRegistry.ShowSchemeDeletePopup);
			if (PromotionObject.Instance != null && !string.IsNullOrEmpty(PromotionObject.Instance.DiscordClientID) && this.ParentWindow.IsDefaultVM)
			{
				this.mDiscordCheckBox.Visibility = Visibility.Visible;
				if (RegistryManager.Instance.DiscordEnabled)
				{
					this.mDiscordCheckBox.IsChecked = new bool?(true);
				}
				else
				{
					this.mDiscordCheckBox.IsChecked = new bool?(false);
				}
			}
			else
			{
				this.mDiscordCheckBox.Visibility = Visibility.Collapsed;
			}
			this.mEnableGamePadCheckbox.IsChecked = new bool?(RegistryManager.Instance.GamepadDetectionEnabled);
			if (FeatureManager.Instance.AllowADBSettingToggle)
			{
				try
				{
					if (this.ParentWindow.mGuestBootCompleted)
					{
						JObject jobject = JsonConvert.DeserializeObject(HTTPUtils.SendRequestToGuest("checkADBStatus", null, this.ParentWindow.mVmName, 0, null, false, 1, 0), Utils.GetSerializerSettings()) as JObject;
						if (string.Compare("ok", jobject["result"].Value<string>(), true) == 0)
						{
							this.mEnableAdbCheckBox.IsChecked = new bool?(true);
						}
						else
						{
							this.mEnableAdbCheckBox.IsChecked = new bool?(false);
						}
						this.mEnableAdbCheckBox.Visibility = Visibility.Visible;
						this.mEnableAdbWarning.Visibility = Visibility.Visible;
					}
					else
					{
						this.mEnableAdbCheckBox.Visibility = Visibility.Collapsed;
						this.mEnableAdbWarning.Visibility = Visibility.Collapsed;
					}
					goto IL_2B0;
				}
				catch (Exception ex)
				{
					Logger.Error("Exception when initialising adb checkbox " + ex.ToString());
					this.mEnableAdbCheckBox.Visibility = Visibility.Collapsed;
					this.mEnableAdbWarning.Visibility = Visibility.Collapsed;
					goto IL_2B0;
				}
			}
			this.mEnableAdbCheckBox.Visibility = Visibility.Collapsed;
			this.mEnableAdbWarning.Visibility = Visibility.Collapsed;
			IL_2B0:
			if (StringExtensions.IsValidPath(RegistryManager.Instance.ScreenShotsPath))
			{
				this.mScreenShotPathLable.Text = RegistryManager.Instance.ScreenShotsPath;
			}
			else
			{
				string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), Strings.ProductTopBarDisplayName);
				if (!Directory.Exists(text))
				{
					Directory.CreateDirectory(text);
				}
				RegistryManager.Instance.ScreenShotsPath = text;
				this.mScreenShotPathLable.Text = text;
			}
			if (!RegistryManager.Instance.Guest[this.ParentWindow.mVmName].IsGoogleSigninDone)
			{
				this.mLanguageSettingsGrid.Visibility = Visibility.Collapsed;
				this.mLanguagePreferencePaddingGrid.Visibility = Visibility.Collapsed;
			}
			if (!this.ParentWindow.mGuestBootCompleted)
			{
				this.mCustomCursorCheckbox.Visibility = Visibility.Collapsed;
			}
			else
			{
				this.mCustomCursorCheckbox.Visibility = Visibility.Visible;
				this.mCustomCursorCheckbox.IsChecked = new bool?(RegistryManager.Instance.CustomCursorEnabled);
			}
			this.mShowOnExitCheckbox.IsChecked = new bool?(!RegistryManager.Instance.IsQuitOptionSaved);
		}

		// Token: 0x06000C23 RID: 3107 RVA: 0x00052A24 File Offset: 0x00050C24
		private void CheckBox_Click(object sender, RoutedEventArgs e)
		{
			this.mChangeLocaleGrid.Visibility = Visibility.Collapsed;
			this.mChangePrefGrid.Visibility = Visibility.Visible;
			CustomCheckbox customCheckbox = sender as CustomCheckbox;
			if (customCheckbox == this.mAddDesktopShortcuts)
			{
				bool flag = true;
				bool? isChecked = this.mAddDesktopShortcuts.IsChecked;
				if (flag == isChecked.GetValueOrDefault() & isChecked != null)
				{
					RegistryManager.Instance.AddDesktopShortcuts = true;
					return;
				}
				RegistryManager.Instance.AddDesktopShortcuts = false;
				return;
			}
			else
			{
				bool? isChecked;
				bool flag2;
				if (customCheckbox != this.mShowGamingSummary)
				{
					if (customCheckbox == this.mDiscordCheckBox)
					{
						isChecked = this.mDiscordCheckBox.IsChecked;
						flag2 = true;
						if (!(isChecked.GetValueOrDefault() == flag2 & isChecked != null))
						{
							RegistryManager.Instance.DiscordEnabled = false;
							if (this.ParentWindow.mDiscordhandler != null)
							{
								this.ParentWindow.mDiscordhandler.ToggleDiscordState(false);
							}
							this.ParentWindow.mDiscordhandler = null;
							return;
						}
						RegistryManager.Instance.DiscordEnabled = true;
						if (this.ParentWindow.mAppHandler.IsOneTimeSetupCompleted && this.ParentWindow.mGuestBootCompleted)
						{
							if (this.ParentWindow.mDiscordhandler == null)
							{
								this.ParentWindow.InitDiscord();
								return;
							}
							this.ParentWindow.mDiscordhandler.ToggleDiscordState(true);
							return;
						}
					}
					else if (customCheckbox == this.mEnableAdbCheckBox)
					{
						isChecked = this.mEnableAdbCheckBox.IsChecked;
						flag2 = true;
						HTTPUtils.SendRequestToGuestAsync((isChecked.GetValueOrDefault() == flag2 & isChecked != null) ? "connectHost?d=permanent" : "disconnectHost?d=permanent", null, this.ParentWindow.mVmName, 0, null, false, 1, 0);
						isChecked = this.mEnableAdbCheckBox.IsChecked;
						flag2 = true;
						if ((isChecked.GetValueOrDefault() == flag2 & isChecked != null) && SecurityMetrics.SecurityMetricsInstanceList.ContainsKey(this.ParentWindow.mVmName))
						{
							SecurityMetrics.SecurityMetricsInstanceList[this.ParentWindow.mVmName].AddSecurityBreach(SecurityBreach.DEVICE_PROBED, "");
							return;
						}
					}
					else
					{
						if (customCheckbox == this.mCustomCursorCheckbox)
						{
							try
							{
								isChecked = this.mCustomCursorCheckbox.IsChecked;
								flag2 = true;
								if (isChecked.GetValueOrDefault() == flag2 & isChecked != null)
								{
									RegistryManager.Instance.CustomCursorEnabled = true;
								}
								else
								{
									RegistryManager.Instance.CustomCursorEnabled = false;
								}
								foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values)
								{
									mainWindow.mCommonHandler.SetCustomCursorForApp(mainWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName);
								}
								return;
							}
							catch (Exception ex)
							{
								Logger.Error("Exception in custom cursor setting change: {0}", new object[]
								{
									ex
								});
								return;
							}
						}
						if (customCheckbox == this.mShowMacroDeleteWarning)
						{
							this.ParentWindow.EngineInstanceRegistry.ShowMacroDeletePopup = this.mShowMacroDeleteWarning.IsChecked.Value;
							return;
						}
						if (customCheckbox == this.mShowSchemeDeleteWarning)
						{
							this.ParentWindow.EngineInstanceRegistry.ShowSchemeDeletePopup = this.mShowSchemeDeleteWarning.IsChecked.Value;
							return;
						}
						if (customCheckbox == this.mEnableGamePadCheckbox)
						{
							isChecked = this.mEnableGamePadCheckbox.IsChecked;
							flag2 = true;
							if (isChecked.GetValueOrDefault() == flag2 & isChecked != null)
							{
								RegistryManager.Instance.GamepadDetectionEnabled = true;
							}
							else
							{
								RegistryManager.Instance.GamepadDetectionEnabled = false;
							}
							Dictionary<string, string> data = new Dictionary<string, string>
							{
								{
									"enable",
									RegistryManager.Instance.GamepadDetectionEnabled.ToString()
								}
							};
							this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("enableGamepad", data);
						}
					}
					return;
				}
				ClientStats.SendMiscellaneousStatsAsync("gamingSummaryCheckboxClicked", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "checked" + this.mShowGamingSummary.IsChecked, null, null, null, null, null);
				isChecked = this.mShowGamingSummary.IsChecked;
				flag2 = true;
				if (isChecked.GetValueOrDefault() == flag2 & isChecked != null)
				{
					RegistryManager.Instance.ShowGamingSummary = true;
					return;
				}
				RegistryManager.Instance.ShowGamingSummary = false;
				return;
			}
		}

		// Token: 0x06000C24 RID: 3108 RVA: 0x00052E34 File Offset: 0x00051034
		private void mLanguageCombobox_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			try
			{
				string selectedLocale = (this.mLanguageCombobox.SelectedItem as ComboBoxItem).Content.ToString();
				if (selectedLocale != null)
				{
					this.mChangePrefGrid.Visibility = Visibility.Visible;
					string key = LocaleStrings.sSupportedLocales.FirstOrDefault((KeyValuePair<string, string> x) => x.Value == selectedLocale).Key;
					if (RegistryManager.Instance.UserSelectedLocale != key.ToString())
					{
						RegistryManager.Instance.UserSelectedLocale = key.ToString();
						BlueStacksUIUtils.UpdateLocale(key.ToString(), "");
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in set locale" + ex.ToString());
			}
		}

		// Token: 0x06000C25 RID: 3109 RVA: 0x00052EFC File Offset: 0x000510FC
		private void mSwitchToHome_Click(object sender, RoutedEventArgs e)
		{
			bool? isChecked = this.mSwitchToHome.IsChecked;
			bool flag = true;
			if (isChecked.GetValueOrDefault() == flag & isChecked != null)
			{
				RegistryManager.Instance.SwitchToAndroidHome = true;
				return;
			}
			RegistryManager.Instance.SwitchToAndroidHome = false;
		}

		// Token: 0x06000C26 RID: 3110 RVA: 0x00052F44 File Offset: 0x00051144
		private void SwitchKillWebTab_Click(object sender, RoutedEventArgs e)
		{
			bool? isChecked = this.mSwitchKillWebTab.IsChecked;
			bool flag = true;
			if (isChecked.GetValueOrDefault() == flag & isChecked != null)
			{
				RegistryManager.Instance.SwitchKillWebTab = true;
				return;
			}
			RegistryManager.Instance.SwitchKillWebTab = false;
		}

		// Token: 0x06000C27 RID: 3111 RVA: 0x00052F8C File Offset: 0x0005118C
		private void mChangePathBtn_Click(object sender, RoutedEventArgs e)
		{
			string text = this.mScreenShotPathLable.Text;
			this.ParentWindow.mCommonHandler.ShowFolderBrowserDialog(text);
			this.mScreenShotPathLable.Text = RegistryManager.Instance.ScreenShotsPath;
			ClientStats.SendMiscellaneousStatsAsync("MediaFilesPathSet", RegistryManager.Instance.UserGuid, "PathChangeFromPreferences", text, RegistryManager.Instance.ScreenShotsPath, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null);
		}

		// Token: 0x06000C28 RID: 3112 RVA: 0x000096B2 File Offset: 0x000078B2
		private void MQuitOptionsComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			RegistryManager.Instance.QuitDefaultOption = (this.mQuitOptionsComboBox.SelectedItem as ComboBoxItem).Tag.ToString();
		}

		// Token: 0x06000C29 RID: 3113 RVA: 0x00053010 File Offset: 0x00051210
		private void MShowOnExitCheckbox_Click(object sender, RoutedEventArgs e)
		{
			CustomCheckbox customCheckbox = sender as CustomCheckbox;
			RegistryManager.Instance.IsQuitOptionSaved = !customCheckbox.IsChecked.Value;
		}

		// Token: 0x06000C2A RID: 3114 RVA: 0x00053040 File Offset: 0x00051240
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/preferencessettingscontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000C2B RID: 3115 RVA: 0x00053070 File Offset: 0x00051270
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mScrollBar = (ScrollViewer)target;
				return;
			case 2:
				this.mMainGrid = (Grid)target;
				return;
			case 3:
				this.mLanguageSettingsGrid = (Grid)target;
				return;
			case 4:
				this.mLanguageCombobox = (CustomComboBox)target;
				this.mLanguageCombobox.SelectionChanged += this.mLanguageCombobox_SelectionChanged;
				return;
			case 5:
				this.mLanguagePreferencePaddingGrid = (Grid)target;
				return;
			case 6:
				this.mPerformancePreference = (Grid)target;
				return;
			case 7:
				this.mPerformanceSettingsLabel = (Label)target;
				return;
			case 8:
				this.mSwitchToHome = (CustomCheckbox)target;
				this.mSwitchToHome.Click += this.mSwitchToHome_Click;
				return;
			case 9:
				this.mSwitchKillWebTab = (CustomCheckbox)target;
				this.mSwitchKillWebTab.Click += this.SwitchKillWebTab_Click;
				return;
			case 10:
				this.mPerformancePreferencePaddingGrid = (Grid)target;
				return;
			case 11:
				this.mPlatformStackPanel = (StackPanel)target;
				return;
			case 12:
				this.mAddDesktopShortcuts = (CustomCheckbox)target;
				this.mAddDesktopShortcuts.Click += this.CheckBox_Click;
				return;
			case 13:
				this.mShowGamingSummary = (CustomCheckbox)target;
				this.mShowGamingSummary.Click += this.CheckBox_Click;
				return;
			case 14:
				this.mShowMacroDeleteWarning = (CustomCheckbox)target;
				this.mShowMacroDeleteWarning.Click += this.CheckBox_Click;
				return;
			case 15:
				this.mShowSchemeDeleteWarning = (CustomCheckbox)target;
				this.mShowSchemeDeleteWarning.Click += this.CheckBox_Click;
				return;
			case 16:
				this.mDiscordCheckBox = (CustomCheckbox)target;
				this.mDiscordCheckBox.Click += this.CheckBox_Click;
				return;
			case 17:
				this.mCustomCursorCheckbox = (CustomCheckbox)target;
				this.mCustomCursorCheckbox.Click += this.CheckBox_Click;
				return;
			case 18:
				this.mEnableGamePadCheckbox = (CustomCheckbox)target;
				this.mEnableGamePadCheckbox.Click += this.CheckBox_Click;
				return;
			case 19:
				this.mEnableAdbCheckBox = (CustomCheckbox)target;
				this.mEnableAdbCheckBox.Click += this.CheckBox_Click;
				return;
			case 20:
				this.mEnableAdbWarning = (TextBlock)target;
				return;
			case 21:
				this.mQuitOptionsGrid = (Grid)target;
				return;
			case 22:
				this.mQuitOptionsComboBox = (CustomComboBox)target;
				this.mQuitOptionsComboBox.SelectionChanged += this.MQuitOptionsComboBox_SelectionChanged;
				return;
			case 23:
				this.mShowOnExitCheckbox = (CustomCheckbox)target;
				this.mShowOnExitCheckbox.Click += this.MShowOnExitCheckbox_Click;
				return;
			case 24:
				this.mScreenshotGrid = (Grid)target;
				return;
			case 25:
				this.mScreenShotPathLable = (TextBlock)target;
				return;
			case 26:
				this.mChangePathBtn = (CustomButton)target;
				this.mChangePathBtn.Click += this.mChangePathBtn_Click;
				return;
			case 27:
				this.mChangeLocaleGrid = (Grid)target;
				return;
			case 28:
				this.mInfoIconLocale = (CustomPictureBox)target;
				return;
			case 29:
				this.mChangePrefGrid = (Grid)target;
				return;
			case 30:
				this.mInfoIcon = (CustomPictureBox)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040008D3 RID: 2259
		private Dictionary<string, ComboBoxItem> dictComboBoxItems = new Dictionary<string, ComboBoxItem>();

		// Token: 0x040008D4 RID: 2260
		private MainWindow ParentWindow;

		// Token: 0x040008D5 RID: 2261
		internal ScrollViewer mScrollBar;

		// Token: 0x040008D6 RID: 2262
		internal Grid mMainGrid;

		// Token: 0x040008D7 RID: 2263
		internal Grid mLanguageSettingsGrid;

		// Token: 0x040008D8 RID: 2264
		internal CustomComboBox mLanguageCombobox;

		// Token: 0x040008D9 RID: 2265
		internal Grid mLanguagePreferencePaddingGrid;

		// Token: 0x040008DA RID: 2266
		internal Grid mPerformancePreference;

		// Token: 0x040008DB RID: 2267
		internal Label mPerformanceSettingsLabel;

		// Token: 0x040008DC RID: 2268
		internal CustomCheckbox mSwitchToHome;

		// Token: 0x040008DD RID: 2269
		internal CustomCheckbox mSwitchKillWebTab;

		// Token: 0x040008DE RID: 2270
		internal Grid mPerformancePreferencePaddingGrid;

		// Token: 0x040008DF RID: 2271
		internal StackPanel mPlatformStackPanel;

		// Token: 0x040008E0 RID: 2272
		internal CustomCheckbox mAddDesktopShortcuts;

		// Token: 0x040008E1 RID: 2273
		internal CustomCheckbox mShowGamingSummary;

		// Token: 0x040008E2 RID: 2274
		internal CustomCheckbox mShowMacroDeleteWarning;

		// Token: 0x040008E3 RID: 2275
		internal CustomCheckbox mShowSchemeDeleteWarning;

		// Token: 0x040008E4 RID: 2276
		internal CustomCheckbox mDiscordCheckBox;

		// Token: 0x040008E5 RID: 2277
		internal CustomCheckbox mCustomCursorCheckbox;

		// Token: 0x040008E6 RID: 2278
		internal CustomCheckbox mEnableGamePadCheckbox;

		// Token: 0x040008E7 RID: 2279
		internal CustomCheckbox mEnableAdbCheckBox;

		// Token: 0x040008E8 RID: 2280
		internal TextBlock mEnableAdbWarning;

		// Token: 0x040008E9 RID: 2281
		internal Grid mQuitOptionsGrid;

		// Token: 0x040008EA RID: 2282
		internal CustomComboBox mQuitOptionsComboBox;

		// Token: 0x040008EB RID: 2283
		internal CustomCheckbox mShowOnExitCheckbox;

		// Token: 0x040008EC RID: 2284
		internal Grid mScreenshotGrid;

		// Token: 0x040008ED RID: 2285
		internal TextBlock mScreenShotPathLable;

		// Token: 0x040008EE RID: 2286
		internal CustomButton mChangePathBtn;

		// Token: 0x040008EF RID: 2287
		internal Grid mChangeLocaleGrid;

		// Token: 0x040008F0 RID: 2288
		internal CustomPictureBox mInfoIconLocale;

		// Token: 0x040008F1 RID: 2289
		internal Grid mChangePrefGrid;

		// Token: 0x040008F2 RID: 2290
		internal CustomPictureBox mInfoIcon;

		// Token: 0x040008F3 RID: 2291
		private bool _contentLoaded;
	}
}
