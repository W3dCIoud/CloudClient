﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Navigation;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000BE RID: 190
	public class SpeedUpBluestacksUserControl : UserControl, IComponentConnector
	{
		// Token: 0x060007A2 RID: 1954 RVA: 0x00006EFA File Offset: 0x000050FA
		public SpeedUpBluestacksUserControl()
		{
			this.InitializeComponent();
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				this.mHyperLink.Foreground = (SolidColorBrush)new BrushConverter().ConvertFrom("#FF328CF2");
			}
		}

		// Token: 0x060007A3 RID: 1955 RVA: 0x0002EF80 File Offset: 0x0002D180
		private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
		{
			try
			{
				Logger.Info("Opening url: " + e.Uri.AbsoluteUri);
				BlueStacksUIUtils.OpenUrl(e.Uri.AbsoluteUri);
				e.Handled = true;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in opening url" + ex.ToString());
			}
		}

		// Token: 0x060007A4 RID: 1956 RVA: 0x000300BC File Offset: 0x0002E2BC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/speedupbluestacksusercontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060007A5 RID: 1957 RVA: 0x000300EC File Offset: 0x0002E2EC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mTitleText = (TextBlock)target;
				return;
			case 2:
				this.mBodyText = (TextBlock)target;
				return;
			case 3:
				this.mImage = (CustomPictureBox)target;
				return;
			case 4:
				this.mHyperLink = (Hyperlink)target;
				this.mHyperLink.RequestNavigate += this.Hyperlink_RequestNavigate;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400057B RID: 1403
		internal TextBlock mTitleText;

		// Token: 0x0400057C RID: 1404
		internal TextBlock mBodyText;

		// Token: 0x0400057D RID: 1405
		internal CustomPictureBox mImage;

		// Token: 0x0400057E RID: 1406
		internal Hyperlink mHyperLink;

		// Token: 0x0400057F RID: 1407
		private bool _contentLoaded;
	}
}
