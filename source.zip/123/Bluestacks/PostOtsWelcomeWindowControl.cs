﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200009D RID: 157
	public class PostOtsWelcomeWindowControl : UserControl, IComponentConnector
	{
		// Token: 0x060006BE RID: 1726 RVA: 0x00006687 File Offset: 0x00004887
		public PostOtsWelcomeWindowControl(MainWindow ParentWindow)
		{
			this.InitializeComponent();
			this.ParentWindow = ParentWindow;
		}

		// Token: 0x060006BF RID: 1727 RVA: 0x0002AB9C File Offset: 0x00028D9C
		private void PostOtsWelcome_Loaded(object sender, RoutedEventArgs e)
		{
			Logger.Info("PostOtsWelcome window loaded");
			this.loginSyncTimer = new Timer(10000.0);
			this.loginSyncTimer.Elapsed += this.OnLoginSyncTimeout;
			this.loginSyncTimer.AutoReset = false;
			if (!string.IsNullOrEmpty(RegistryManager.Instance.Token))
			{
				this.ChangeBasedonTokenReceived("true");
				return;
			}
			this.StartingTimer();
		}

		// Token: 0x060006C0 RID: 1728 RVA: 0x0002AC10 File Offset: 0x00028E10
		public void ChangeBasedonTokenReceived(string status)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					Logger.Info("In ChangeBasedonTokenReceived");
					this.mLoadingImage.Visibility = Visibility.Collapsed;
					if (status.Equals("true", StringComparison.InvariantCultureIgnoreCase))
					{
						this.mPostOtsImage.ImageName = "success_ots_icon";
						this.mPostOtsWarning.Visibility = Visibility.Collapsed;
						this.mCloseButton.Visibility = Visibility.Collapsed;
						BlueStacksUIBinding.Bind(this.mPostOtsLabel, "STRING_POST_OTS_SUCCESS_MESSAGE");
						BlueStacksUIBinding.Bind(this.mPostOtsButton, "STRING_POST_OTS_SUCCESS_BUTTON_MESSAGE");
						this.mSuccess = new bool?(true);
					}
					else
					{
						this.mPostOtsImage.ImageName = "failure_ots_icon";
						this.mPostOtsWarning.Visibility = Visibility.Visible;
						this.mCloseButton.Visibility = Visibility.Visible;
						BlueStacksUIBinding.Bind(this.mPostOtsLabel, "STRING_POST_OTS_FAILED_MESSAGE");
						BlueStacksUIBinding.Bind(this.mPostOtsButton, "STRING_POST_OTS_FAILED_BUTTON_MESSAGE");
						this.mSuccess = new bool?(false);
					}
					if (this.loginSyncTimer != null)
					{
						this.loginSyncTimer.Stop();
					}
					this.mPostOtsButton.IsEnabled = true;
				}
				catch (Exception ex)
				{
					Logger.Error(string.Concat(new string[]
					{
						" Exception in ChangeBasedOnTokenReceived Status: ",
						status,
						Environment.NewLine,
						"Error: ",
						ex.ToString()
					}));
				}
			}), new object[0]);
		}

		// Token: 0x060006C1 RID: 1729 RVA: 0x0000669C File Offset: 0x0000489C
		private void StartingTimer()
		{
			Logger.Info("Starting Timer");
			this.loginSyncTimer.Stop();
			this.loginSyncTimer.Start();
			this.loginSyncTimer.Enabled = true;
		}

		// Token: 0x060006C2 RID: 1730 RVA: 0x0002AC50 File Offset: 0x00028E50
		private void OnLoginSyncTimeout(object source, ElapsedEventArgs e)
		{
			try
			{
				Logger.Error("Login Sync timed out.");
				if (this.mSuccess == null)
				{
					this.ChangeBasedonTokenReceived("false");
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in login sync timer timeout " + ex.ToString());
			}
		}

		// Token: 0x060006C3 RID: 1731 RVA: 0x0002ACAC File Offset: 0x00028EAC
		private void mPostOtsButton_Click(object sender, RoutedEventArgs e)
		{
			Logger.Info("mPostOtsButton clicked");
			if (this.mSuccess != null)
			{
				if (this.mSuccess.Value)
				{
					this.loginSyncTimer.Dispose();
					BlueStacksUIUtils.CloseContainerWindow(this);
					return;
				}
				base.Dispatcher.Invoke(new Action(delegate()
				{
					this.mPostOtsImage.ImageName = "syncing_ots_icon";
					this.mLoadingImage.Visibility = Visibility.Visible;
					this.mPostOtsWarning.Visibility = Visibility.Collapsed;
					this.mCloseButton.Visibility = Visibility.Collapsed;
					BlueStacksUIBinding.Bind(this.mPostOtsLabel, "STRING_POST_OTS_SYNCING_MESSAGE");
					BlueStacksUIBinding.Bind(this.mPostOtsButton, "STRING_POST_OTS_SYNCING_BUTTON_MESSAGE");
					this.mPostOtsButton.IsEnabled = false;
				}), new object[0]);
				this.SendRetryBluestacksLoginRequest(this.ParentWindow.mVmName);
			}
		}

		// Token: 0x060006C4 RID: 1732 RVA: 0x0002AD20 File Offset: 0x00028F20
		private void CloseButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			try
			{
				Logger.Info("Clicked postotswelcome window close button");
				this.ParentWindow.CloseWindow();
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in closing bluestacks from postotswelcome window, " + ex.ToString());
			}
		}

		// Token: 0x060006C5 RID: 1733 RVA: 0x0002AD6C File Offset: 0x00028F6C
		private void SendRetryBluestacksLoginRequest(string vmName)
		{
			try
			{
				Logger.Info("Sending retry call for token to android, since token is not received successfully");
				this.mSuccess = null;
				this.StartingTimer();
				this.ParentWindow.Utils.SendBluestacksLoginRequest(vmName);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in SendRetryBluestacksLoginRequest: " + ex.ToString());
			}
		}

		// Token: 0x060006C6 RID: 1734 RVA: 0x0002ADD4 File Offset: 0x00028FD4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/postotswelcomewindowcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060006C7 RID: 1735 RVA: 0x0002AE04 File Offset: 0x00029004
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((PostOtsWelcomeWindowControl)target).Loaded += this.PostOtsWelcome_Loaded;
				return;
			case 2:
				this.mCloseButton = (CustomPictureBox)target;
				this.mCloseButton.MouseLeftButtonUp += this.CloseButton_MouseLeftButtonUp;
				return;
			case 3:
				this.mPostOtsImage = (CustomPictureBox)target;
				return;
			case 4:
				this.mLoadingImage = (CustomPictureBox)target;
				return;
			case 5:
				this.mPostOtsLabel = (Label)target;
				return;
			case 6:
				this.mPostOtsWarning = (TextBlock)target;
				return;
			case 7:
				this.mPostOtsButton = (CustomButton)target;
				this.mPostOtsButton.Click += this.mPostOtsButton_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000489 RID: 1161
		private bool? mSuccess;

		// Token: 0x0400048A RID: 1162
		private Timer loginSyncTimer;

		// Token: 0x0400048B RID: 1163
		private MainWindow ParentWindow;

		// Token: 0x0400048C RID: 1164
		internal CustomPictureBox mCloseButton;

		// Token: 0x0400048D RID: 1165
		internal CustomPictureBox mPostOtsImage;

		// Token: 0x0400048E RID: 1166
		internal CustomPictureBox mLoadingImage;

		// Token: 0x0400048F RID: 1167
		internal Label mPostOtsLabel;

		// Token: 0x04000490 RID: 1168
		internal TextBlock mPostOtsWarning;

		// Token: 0x04000491 RID: 1169
		internal CustomButton mPostOtsButton;

		// Token: 0x04000492 RID: 1170
		private bool _contentLoaded;
	}
}
