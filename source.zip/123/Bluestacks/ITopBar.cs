﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000CC RID: 204
	internal interface ITopBar
	{
		// Token: 0x1700016A RID: 362
		// (get) Token: 0x06000822 RID: 2082
		// (set) Token: 0x06000823 RID: 2083
		string AppName { get; set; }

		// Token: 0x1700016B RID: 363
		// (get) Token: 0x06000824 RID: 2084
		// (set) Token: 0x06000825 RID: 2085
		string CharacterName { get; set; }

		// Token: 0x06000826 RID: 2086
		void ShowSyncPanel(bool show = false);

		// Token: 0x06000827 RID: 2087
		void HideSyncPanel();
	}
}
