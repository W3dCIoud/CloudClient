﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000056 RID: 86
	public class DimOverlayControl : CustomWindow, IComponentConnector
	{
		// Token: 0x1700012C RID: 300
		// (get) Token: 0x060003BC RID: 956 RVA: 0x0000488A File Offset: 0x00002A8A
		// (set) Token: 0x060003BD RID: 957 RVA: 0x00019FDC File Offset: 0x000181DC
		public new MainWindow Owner
		{
			get
			{
				return (MainWindow)base.Owner;
			}
			set
			{
				if (value != null)
				{
					if (value != base.Owner)
					{
						value.LocationChanged += this.ParentWindow_LocationChanged;
						value.SizeChanged += this.ParentWindow_SizeChanged;
					}
				}
				else if (base.Owner != null)
				{
					base.Owner.LocationChanged -= this.ParentWindow_LocationChanged;
					base.Owner.SizeChanged -= this.ParentWindow_SizeChanged;
				}
				base.Owner = value;
			}
		}

		// Token: 0x1700012D RID: 301
		// (get) Token: 0x060003BE RID: 958 RVA: 0x00004897 File Offset: 0x00002A97
		// (set) Token: 0x060003BF RID: 959 RVA: 0x0000489F File Offset: 0x00002A9F
		internal IDimOverlayControl Control
		{
			get
			{
				return this.mControl;
			}
			set
			{
				if (value != null)
				{
					this.AddControl(value);
				}
				this.mControl = value;
			}
		}

		// Token: 0x1700012E RID: 302
		// (get) Token: 0x060003C0 RID: 960 RVA: 0x000048B2 File Offset: 0x00002AB2
		// (set) Token: 0x060003C1 RID: 961 RVA: 0x000048BA File Offset: 0x00002ABA
		public bool IsWindowVisible
		{
			get
			{
				return this.mIsWindowVisible;
			}
			set
			{
				this.mIsWindowVisible = value;
				base.IsShowGLWindow = !value;
			}
		}

		// Token: 0x060003C2 RID: 962 RVA: 0x000048CD File Offset: 0x00002ACD
		private void ParentWindow_LocationChanged(object sender, EventArgs e)
		{
			this.UpadteSizeLocation();
		}

		// Token: 0x060003C3 RID: 963 RVA: 0x000048CD File Offset: 0x00002ACD
		private void ParentWindow_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			this.UpadteSizeLocation();
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x000048D5 File Offset: 0x00002AD5
		public DimOverlayControl(MainWindow owner)
		{
			this.Owner = owner;
			this.InitializeComponent();
		}

		// Token: 0x060003C5 RID: 965 RVA: 0x0001A058 File Offset: 0x00018258
		internal void AddControl(IDimOverlayControl el)
		{
			if (!el.ShowControlInSeparateWindow)
			{
				if (!this.mGrid.Children.Contains(el as UIElement))
				{
					this.mGrid.Children.Add(el as UIElement);
					return;
				}
				(el as UIElement).Visibility = Visibility.Visible;
			}
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x0001A0AC File Offset: 0x000182AC
		internal void RemoveControl()
		{
			if (!this.Control.ShowControlInSeparateWindow)
			{
				if (this.mGrid.Children.Contains(this.Control as UIElement))
				{
					this.mGrid.Children.Remove(this.Control as UIElement);
					this.Control.Close();
					return;
				}
			}
			else
			{
				if (this.Control != null)
				{
					BlueStacksUIUtils.RemoveChildFromParent((UIElement)this.Control);
					this.Control.Close();
				}
				if (this.cw != null)
				{
					this.cw.Close();
				}
			}
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x0001A144 File Offset: 0x00018344
		internal void UpadteSizeLocation()
		{
			if (this.Owner != null && PresentationSource.FromVisual(this.Owner) != null)
			{
				Point point = this.Owner.PointToScreen(new Point(0.0, 0.0));
				Point point2 = PresentationSource.FromVisual(this.Owner).CompositionTarget.TransformFromDevice.Transform(point);
				base.Left = point2.X;
				base.Top = point2.Y;
				base.Width = this.Owner.ActualWidth;
				base.Height = this.Owner.ActualHeight;
			}
		}

		// Token: 0x060003C8 RID: 968 RVA: 0x0001A1E8 File Offset: 0x000183E8
		internal void ShowWindow()
		{
			if (!this.IsWindowVisible)
			{
				this.IsWindowVisible = true;
				base.Show();
				if (this.Control != null)
				{
					if (!this.Control.ShowControlInSeparateWindow)
					{
						this.Control.Show();
						return;
					}
					this.Control.Show();
					this.cw = new ContainerWindow(this.Owner, (UserControl)this.Control, this.Control.Width, this.Control.Height, false, false);
					this.cw.Show();
				}
			}
		}

		// Token: 0x060003C9 RID: 969 RVA: 0x0001A278 File Offset: 0x00018478
		internal void HideWindow(bool isFromOverlayClick)
		{
			if (this.IsWindowVisible)
			{
				if (this.Control != null)
				{
					if (!isFromOverlayClick)
					{
						this.IsWindowVisible = false;
						this.RemoveControl();
						this.Hide();
						return;
					}
					if (this.Control.IsCloseOnOverLayClick)
					{
						this.IsWindowVisible = false;
						this.RemoveControl();
						this.Hide();
						return;
					}
					if (this.cw != null)
					{
						this.cw.Focus();
						return;
					}
				}
				else
				{
					this.IsWindowVisible = false;
					this.Hide();
				}
			}
		}

		// Token: 0x060003CA RID: 970 RVA: 0x000048EA File Offset: 0x00002AEA
		private void mGrid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			this.HideWindow(true);
		}

		// Token: 0x060003CB RID: 971 RVA: 0x000048F3 File Offset: 0x00002AF3
		public new void Hide()
		{
			if (!this.IsWindowVisible)
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					base.Hide();
				}), new object[0]);
			}
		}

		// Token: 0x060003CC RID: 972 RVA: 0x0001A2F0 File Offset: 0x000184F0
		private void DimWindow_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.System && e.SystemKey == Key.F4 && this.Control != null && FeatureManager.Instance.IsCustomUIForNCSoft && this.Control.GetType() == BlueStacksUIUtils.DictWindows[Strings.CurrentDefaultVmName].ScreenLockInstance.GetType() && BlueStacksUIUtils.DictWindows[Strings.CurrentDefaultVmName].ScreenLockInstance.IsVisible)
			{
				e.Handled = true;
			}
		}

		// Token: 0x060003CD RID: 973 RVA: 0x0001A370 File Offset: 0x00018570
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/dimoverlaycontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060003CE RID: 974 RVA: 0x0001A3A0 File Offset: 0x000185A0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((DimOverlayControl)target).KeyDown += this.DimWindow_KeyDown;
				return;
			case 2:
				this.mGrid = (Grid)target;
				return;
			case 3:
				((Grid)target).MouseDown += this.mGrid_MouseLeftButtonDown;
				((Grid)target).MouseLeftButtonDown += this.mGrid_MouseLeftButtonDown;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000223 RID: 547
		private IDimOverlayControl mControl;

		// Token: 0x04000224 RID: 548
		private bool mIsWindowVisible;

		// Token: 0x04000225 RID: 549
		private ContainerWindow cw;

		// Token: 0x04000226 RID: 550
		internal Grid mGrid;

		// Token: 0x04000227 RID: 551
		private bool _contentLoaded;
	}
}
