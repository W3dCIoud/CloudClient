﻿using System;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200003A RID: 58
	public class GenericNotificationItem
	{
		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x060002E1 RID: 737 RVA: 0x00003FAC File Offset: 0x000021AC
		// (set) Token: 0x060002E2 RID: 738 RVA: 0x00003FB4 File Offset: 0x000021B4
		public string Id
		{
			get
			{
				return this.mId;
			}
			set
			{
				this.mId = value;
			}
		}

		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x060002E3 RID: 739 RVA: 0x00003FBD File Offset: 0x000021BD
		// (set) Token: 0x060002E4 RID: 740 RVA: 0x00003FC5 File Offset: 0x000021C5
		public string Title
		{
			get
			{
				return this.mTitle;
			}
			set
			{
				this.mTitle = value;
			}
		}

		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x060002E5 RID: 741 RVA: 0x00003FCE File Offset: 0x000021CE
		// (set) Token: 0x060002E6 RID: 742 RVA: 0x00003FD6 File Offset: 0x000021D6
		public string Message
		{
			get
			{
				return this.mMessage;
			}
			set
			{
				this.mMessage = value;
			}
		}

		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x060002E7 RID: 743 RVA: 0x00003FDF File Offset: 0x000021DF
		// (set) Token: 0x060002E8 RID: 744 RVA: 0x00003FE7 File Offset: 0x000021E7
		public NotificationPriority Priority
		{
			get
			{
				return this.mPriority;
			}
			set
			{
				this.mPriority = value;
			}
		}

		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x060002E9 RID: 745 RVA: 0x00003FF0 File Offset: 0x000021F0
		// (set) Token: 0x060002EA RID: 746 RVA: 0x00003FF8 File Offset: 0x000021F8
		public bool ShowRibbon
		{
			get
			{
				return this.mShowRibbon;
			}
			set
			{
				this.mShowRibbon = value;
			}
		}

		// Token: 0x170000FA RID: 250
		// (get) Token: 0x060002EB RID: 747 RVA: 0x00004001 File Offset: 0x00002201
		// (set) Token: 0x060002EC RID: 748 RVA: 0x00004009 File Offset: 0x00002209
		public DateTime CreationTime
		{
			get
			{
				return this.mCreationTime;
			}
			set
			{
				this.mCreationTime = value;
			}
		}

		// Token: 0x170000FB RID: 251
		// (get) Token: 0x060002ED RID: 749 RVA: 0x00004012 File Offset: 0x00002212
		// (set) Token: 0x060002EE RID: 750 RVA: 0x0000401A File Offset: 0x0000221A
		public string NotificationMenuImageUrl
		{
			get
			{
				return this.mNotificationMenuImageUrl;
			}
			set
			{
				this.mNotificationMenuImageUrl = value;
			}
		}

		// Token: 0x170000FC RID: 252
		// (get) Token: 0x060002EF RID: 751 RVA: 0x00004023 File Offset: 0x00002223
		// (set) Token: 0x060002F0 RID: 752 RVA: 0x0000402B File Offset: 0x0000222B
		public string NotificationMenuImageName
		{
			get
			{
				return this.mNotificationMenuImageName;
			}
			set
			{
				this.mNotificationMenuImageName = value;
			}
		}

		// Token: 0x170000FD RID: 253
		// (get) Token: 0x060002F1 RID: 753 RVA: 0x00004034 File Offset: 0x00002234
		// (set) Token: 0x060002F2 RID: 754 RVA: 0x0000403C File Offset: 0x0000223C
		public bool IsRead
		{
			get
			{
				return this.mIsRead;
			}
			set
			{
				this.mIsRead = value;
			}
		}

		// Token: 0x170000FE RID: 254
		// (get) Token: 0x060002F3 RID: 755 RVA: 0x00004045 File Offset: 0x00002245
		// (set) Token: 0x060002F4 RID: 756 RVA: 0x0000404D File Offset: 0x0000224D
		public NotificationPayloadType PayloadType
		{
			get
			{
				return this.mPayloadType;
			}
			set
			{
				this.mPayloadType = value;
			}
		}

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x060002F5 RID: 757 RVA: 0x00004056 File Offset: 0x00002256
		// (set) Token: 0x060002F6 RID: 758 RVA: 0x0000405E File Offset: 0x0000225E
		public bool IsDeleted
		{
			get
			{
				return this.mIsDeleted;
			}
			set
			{
				this.mIsDeleted = value;
			}
		}

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x060002F7 RID: 759 RVA: 0x00004067 File Offset: 0x00002267
		// (set) Token: 0x060002F8 RID: 760 RVA: 0x0000406F File Offset: 0x0000226F
		public bool IsDeferred
		{
			get
			{
				return this.mIsDeferred;
			}
			set
			{
				this.mIsDeferred = value;
			}
		}

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x060002F9 RID: 761 RVA: 0x00004078 File Offset: 0x00002278
		// (set) Token: 0x060002FA RID: 762 RVA: 0x00004080 File Offset: 0x00002280
		public string DeferredApp
		{
			get
			{
				return this.mDeferredApp;
			}
			set
			{
				this.mDeferredApp = value;
			}
		}

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x060002FB RID: 763 RVA: 0x00004089 File Offset: 0x00002289
		// (set) Token: 0x060002FC RID: 764 RVA: 0x00004091 File Offset: 0x00002291
		public long DeferredAppUsage
		{
			get
			{
				return this.mDeferredAppUsage;
			}
			set
			{
				this.mDeferredAppUsage = value;
			}
		}

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x060002FD RID: 765 RVA: 0x0000409A File Offset: 0x0000229A
		// (set) Token: 0x060002FE RID: 766 RVA: 0x000040A2 File Offset: 0x000022A2
		public GenericNotificationDesignItem NotificationDesignItem
		{
			get
			{
				return this.mNotificationDesignItem;
			}
			set
			{
				this.mNotificationDesignItem = value;
			}
		}

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x060002FF RID: 767 RVA: 0x000040AB File Offset: 0x000022AB
		// (set) Token: 0x06000300 RID: 768 RVA: 0x000040B3 File Offset: 0x000022B3
		public SerializableDictionary<string, string> ExtraPayload
		{
			get
			{
				return this.mExtraPayload;
			}
			set
			{
				this.mExtraPayload = value;
			}
		}

		// Token: 0x0400018E RID: 398
		private string mId;

		// Token: 0x0400018F RID: 399
		private string mTitle;

		// Token: 0x04000190 RID: 400
		private string mMessage;

		// Token: 0x04000191 RID: 401
		private NotificationPriority mPriority = NotificationPriority.Normal;

		// Token: 0x04000192 RID: 402
		private bool mShowRibbon;

		// Token: 0x04000193 RID: 403
		private bool mIsDeferred;

		// Token: 0x04000194 RID: 404
		private string mDeferredApp = string.Empty;

		// Token: 0x04000195 RID: 405
		private long mDeferredAppUsage;

		// Token: 0x04000196 RID: 406
		private string mNotificationMenuImageName;

		// Token: 0x04000197 RID: 407
		private string mNotificationMenuImageUrl;

		// Token: 0x04000198 RID: 408
		private NotificationPayloadType mPayloadType;

		// Token: 0x04000199 RID: 409
		private SerializableDictionary<string, string> mExtraPayload = new SerializableDictionary<string, string>();

		// Token: 0x0400019A RID: 410
		private DateTime mCreationTime = DateTime.Now;

		// Token: 0x0400019B RID: 411
		private bool mIsRead;

		// Token: 0x0400019C RID: 412
		private bool mIsDeleted;

		// Token: 0x0400019D RID: 413
		private GenericNotificationDesignItem mNotificationDesignItem;
	}
}
