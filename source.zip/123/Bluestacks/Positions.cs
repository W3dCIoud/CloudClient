﻿using System;

// Token: 0x02000020 RID: 32
public enum Positions
{
	// Token: 0x040000EF RID: 239
	Up,
	// Token: 0x040000F0 RID: 240
	Down,
	// Token: 0x040000F1 RID: 241
	Left,
	// Token: 0x040000F2 RID: 242
	Right,
	// Token: 0x040000F3 RID: 243
	Center
}
