﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000034 RID: 52
	internal class GrmManager
	{
		// Token: 0x060002B2 RID: 690 RVA: 0x00003DA4 File Offset: 0x00001FA4
		internal static void UpdateGrmAsync(IEnumerable<string> listOfPackages = null)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				if (AppRequirementsParser.Instance.Requirements == null)
				{
					AppRequirementsParser.Instance.PopulateRequirementsFromFile();
				}
				GrmManager.GetGrmFromCloud(listOfPackages);
			});
		}

		// Token: 0x060002B3 RID: 691 RVA: 0x00016D8C File Offset: 0x00014F8C
		private static void GetGrmFromCloud(IEnumerable<string> listOfPackages = null)
		{
			try
			{
				if (listOfPackages != null && listOfPackages.Count<string>() > 0)
				{
					List<string> list = new List<string>();
					foreach (string vmName in RegistryManager.Instance.VmList)
					{
						list = list.Union(JsonParser.GetInstalledAppsList(vmName)).ToList<string>();
					}
					if (listOfPackages.Intersect(list).Count<string>() == 0)
					{
						return;
					}
				}
				string urlWithParams = WebHelper.GetUrlWithParams(string.Format("{0}/{1}", RegistryManager.Instance.Host, "grm/files"));
				Logger.Debug("Grm Url: " + urlWithParams);
				JObject jobject = JObject.Parse(HTTPUtils.SendRequestToCloud("grm/files", null, "Android", 0, null, false, 1, 0, false));
				if ((int)jobject["code"] == 200 && jobject["data"].Value<bool>("success"))
				{
					string url = jobject["data"]["files"].Value<string>("translations_file");
					string fullJson = BstHttpClient.Get(jobject["data"]["files"].Value<string>("config_file"), null, false, Strings.CurrentDefaultVmName, 0, 1, 0, false);
					string translationJson = BstHttpClient.Get(url, null, false, Strings.CurrentDefaultVmName, 0, 1, 0, false);
					AppRequirementsParser.Instance.UpdateOverwriteRequirements(fullJson, translationJson);
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Error Getting Grm json " + ex.ToString());
			}
		}
	}
}
