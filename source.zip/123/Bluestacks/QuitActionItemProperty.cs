﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000043 RID: 67
	public enum QuitActionItemProperty
	{
		// Token: 0x040001C4 RID: 452
		ImageName,
		// Token: 0x040001C5 RID: 453
		BodyText,
		// Token: 0x040001C6 RID: 454
		CallToAction,
		// Token: 0x040001C7 RID: 455
		ActionText,
		// Token: 0x040001C8 RID: 456
		ActionValue,
		// Token: 0x040001C9 RID: 457
		StatEventName
	}
}
