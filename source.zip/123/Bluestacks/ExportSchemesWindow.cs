﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000E1 RID: 225
	public class ExportSchemesWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x060009A4 RID: 2468 RVA: 0x00007FA2 File Offset: 0x000061A2
		public ExportSchemesWindow(KeymapCanvasWindow window, MainWindow mainWindow)
		{
			this.InitializeComponent();
			this.CanvasWindow = window;
			this.ParentWindow = mainWindow;
			this.mSchemesStackPanel = (this.mSchemesListScrollbar.Content as StackPanel);
		}

		// Token: 0x060009A5 RID: 2469 RVA: 0x00007FDF File Offset: 0x000061DF
		private void Close_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.CloseWindow();
		}

		// Token: 0x060009A6 RID: 2470 RVA: 0x00007FE7 File Offset: 0x000061E7
		private void CloseWindow()
		{
			base.Close();
			this.CanvasWindow.SidebarWindow.mExportSchemesWindow = null;
			this.CanvasWindow.SidebarWindow.mOverlayGrid.Visibility = Visibility.Hidden;
			this.CanvasWindow.SidebarWindow.Focus();
		}

		// Token: 0x060009A7 RID: 2471 RVA: 0x00044058 File Offset: 0x00042258
		internal void Init()
		{
			try
			{
				foreach (IMControlScheme imcontrolScheme in this.ParentWindow.OriginalLoadedConfig.ControlSchemes)
				{
					this.dict.Add(imcontrolScheme.Name, imcontrolScheme);
					CustomCheckbox customCheckbox = new CustomCheckbox();
					customCheckbox.Content = imcontrolScheme.Name;
					customCheckbox.TextFontSize = 14.0;
					customCheckbox.ImageMargin = new Thickness(2.0);
					customCheckbox.Margin = new Thickness(0.0, 1.0, 0.0, 1.0);
					customCheckbox.MaxHeight = 20.0;
					customCheckbox.Checked += this.Box_Checked;
					customCheckbox.Unchecked += this.Box_Unchecked;
					this.mSchemesStackPanel.Children.Add(customCheckbox);
				}
				this.mNumberOfSchemesSelectedForExport = 0;
			}
			catch (Exception ex)
			{
				Logger.Error("Error in export window init err: " + ex.ToString());
			}
		}

		// Token: 0x060009A8 RID: 2472 RVA: 0x000441B4 File Offset: 0x000423B4
		private void Box_Unchecked(object sender, RoutedEventArgs e)
		{
			this.mNumberOfSchemesSelectedForExport--;
			if (this.mNumberOfSchemesSelectedForExport == this.mSchemesStackPanel.Children.Count - 1)
			{
				this.mSelectAllBtn.IsChecked = new bool?(false);
			}
			if (this.mNumberOfSchemesSelectedForExport == 0)
			{
				this.mExportBtn.IsEnabled = false;
			}
		}

		// Token: 0x060009A9 RID: 2473 RVA: 0x00044210 File Offset: 0x00042410
		private void Box_Checked(object sender, RoutedEventArgs e)
		{
			this.mNumberOfSchemesSelectedForExport++;
			if (this.mNumberOfSchemesSelectedForExport == this.mSchemesStackPanel.Children.Count)
			{
				this.mSelectAllBtn.IsChecked = new bool?(true);
			}
			if (this.mNumberOfSchemesSelectedForExport == 1)
			{
				this.mExportBtn.IsEnabled = true;
			}
		}

		// Token: 0x060009AA RID: 2474 RVA: 0x0004426C File Offset: 0x0004246C
		private void ExportBtn_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				int num = 0;
				List<IMControlScheme> list = new List<IMControlScheme>();
				foreach (object obj in this.mSchemesStackPanel.Children)
				{
					bool? isChecked = (obj as CustomCheckbox).IsChecked;
					bool flag = true;
					if (isChecked.GetValueOrDefault() == flag & isChecked != null)
					{
						list.Add(this.dict.ElementAt(num).Value);
					}
					num++;
				}
				if (list.Count != 0)
				{
					using (SaveFileDialog saveFileDialog = new SaveFileDialog())
					{
						saveFileDialog.AddExtension = true;
						saveFileDialog.DefaultExt = ".cfg";
						saveFileDialog.Filter = "Cfg files(*.cfg) | *.cfg";
						saveFileDialog.FileName = this.ParentWindow.StaticComponents.mSelectedTabButton.AppName;
						if (saveFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
						{
							BackgroundWorker backgroundWorker = new BackgroundWorker();
							backgroundWorker.DoWork += this.BgExport_DoWork;
							backgroundWorker.RunWorkerCompleted += this.BgExport_RunWorkerCompleted;
							this.ShowLoadingGrid(true);
							backgroundWorker.RunWorkerAsync(new List<object>
							{
								saveFileDialog.FileName,
								list
							});
						}
						else
						{
							this.ToggleCheckBoxForExport(false);
						}
						goto IL_164;
					}
				}
				this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_SCHEME_SELECTED", false), 1.3, false);
				IL_164:;
			}
			catch (Exception)
			{
				Logger.Error("Error while exporting script. err:" + e.ToString());
			}
		}

		// Token: 0x060009AB RID: 2475 RVA: 0x00008027 File Offset: 0x00006227
		private void BgExport_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			this.ShowLoadingGrid(false);
			this.ToggleCheckBoxForExport(false);
			this.CloseWindow();
		}

		// Token: 0x060009AC RID: 2476 RVA: 0x00044444 File Offset: 0x00042644
		private void ToggleCheckBoxForExport(bool isShow)
		{
			foreach (object obj in this.mSchemesStackPanel.Children)
			{
				(obj as CustomCheckbox).IsChecked = new bool?(false);
			}
		}

		// Token: 0x060009AD RID: 2477 RVA: 0x000444A8 File Offset: 0x000426A8
		private void BgExport_DoWork(object sender, DoWorkEventArgs e)
		{
			try
			{
				List<object> list = e.Argument as List<object>;
				string path = list[0] as string;
				List<IMControlScheme> controlSchemes = list[1] as List<IMControlScheme>;
				IMConfig imconfig = new IMConfig();
				imconfig.Strings = this.ParentWindow.OriginalLoadedConfig.Strings.DeepCopy<Dictionary<string, Dictionary<string, string>>>();
				imconfig.ControlSchemes = controlSchemes;
				JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
				serializerSettings.Formatting = Formatting.Indented;
				string contents = JsonConvert.SerializeObject(imconfig, serializerSettings);
				File.WriteAllText(path, contents);
				this.ParentWindow.mCommonHandler.AddToastPopup(this.CanvasWindow.SidebarWindow, LocaleStrings.GetLocalizedString("STRING_CONTROLS_EXPORTED", false), 1.3, false);
			}
			catch (Exception)
			{
				Logger.Error("Error in creating exported file " + e.ToString());
			}
		}

		// Token: 0x060009AE RID: 2478 RVA: 0x00044578 File Offset: 0x00042778
		private void ShowLoadingGrid(bool isShow)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (isShow)
				{
					this.mLoadingGrid.Visibility = Visibility.Visible;
					return;
				}
				this.mLoadingGrid.Visibility = Visibility.Hidden;
			}), new object[0]);
		}

		// Token: 0x060009AF RID: 2479 RVA: 0x000445B8 File Offset: 0x000427B8
		private void SelectAllBtn_Click(object sender, RoutedEventArgs e)
		{
			if (this.mSelectAllBtn.IsChecked.Value)
			{
				using (IEnumerator enumerator = this.mSchemesStackPanel.Children.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						object obj = enumerator.Current;
						(obj as CustomCheckbox).IsChecked = new bool?(true);
					}
					return;
				}
			}
			foreach (object obj2 in this.mSchemesStackPanel.Children)
			{
				(obj2 as CustomCheckbox).IsChecked = new bool?(false);
			}
		}

		// Token: 0x060009B0 RID: 2480 RVA: 0x00044680 File Offset: 0x00042880
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/exportschemeswindow.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060009B1 RID: 2481 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060009B2 RID: 2482 RVA: 0x000446B0 File Offset: 0x000428B0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				((CustomPictureBox)target).MouseLeftButtonUp += this.Close_MouseLeftButtonUp;
				return;
			case 3:
				this.mSchemesListScrollbar = (ScrollViewer)target;
				return;
			case 4:
				this.mSelectAllBtn = (CustomCheckbox)target;
				this.mSelectAllBtn.Click += this.SelectAllBtn_Click;
				return;
			case 5:
				this.mExportBtn = (CustomButton)target;
				this.mExportBtn.Click += this.ExportBtn_Click;
				return;
			case 6:
				this.mLoadingGrid = (BlueStacks.BlueStacksUI.ProgressBar)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040006F6 RID: 1782
		private KeymapCanvasWindow CanvasWindow;

		// Token: 0x040006F7 RID: 1783
		private MainWindow ParentWindow;

		// Token: 0x040006F8 RID: 1784
		internal StackPanel mSchemesStackPanel;

		// Token: 0x040006F9 RID: 1785
		internal int mNumberOfSchemesSelectedForExport;

		// Token: 0x040006FA RID: 1786
		private Dictionary<string, IMControlScheme> dict = new Dictionary<string, IMControlScheme>();

		// Token: 0x040006FB RID: 1787
		internal Border mMaskBorder;

		// Token: 0x040006FC RID: 1788
		internal ScrollViewer mSchemesListScrollbar;

		// Token: 0x040006FD RID: 1789
		internal CustomCheckbox mSelectAllBtn;

		// Token: 0x040006FE RID: 1790
		internal CustomButton mExportBtn;

		// Token: 0x040006FF RID: 1791
		internal BlueStacks.BlueStacksUI.ProgressBar mLoadingGrid;

		// Token: 0x04000700 RID: 1792
		private bool _contentLoaded;
	}
}
