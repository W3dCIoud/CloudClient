﻿using System;

// Token: 0x0200000C RID: 12
[Serializable]
public class KeyInput : IMAction
{
	// Token: 0x17000075 RID: 117
	// (get) Token: 0x060000F6 RID: 246 RVA: 0x00002A60 File Offset: 0x00000C60
	// (set) Token: 0x060000F7 RID: 247 RVA: 0x00002A68 File Offset: 0x00000C68
	public string KeyIn
	{
		get
		{
			return this.mKeyIn;
		}
		set
		{
			this.mKeyIn = value;
		}
	}

	// Token: 0x17000076 RID: 118
	// (get) Token: 0x060000F8 RID: 248 RVA: 0x00002A71 File Offset: 0x00000C71
	// (set) Token: 0x060000F9 RID: 249 RVA: 0x00002A79 File Offset: 0x00000C79
	public string KeyOut
	{
		get
		{
			return this.mKeyOut;
		}
		set
		{
			this.mKeyOut = value;
		}
	}

	// Token: 0x04000078 RID: 120
	private string mKeyIn;

	// Token: 0x04000079 RID: 121
	private string mKeyOut;
}
