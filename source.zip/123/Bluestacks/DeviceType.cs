﻿using System;

// Token: 0x02000021 RID: 33
public enum DeviceType
{
	// Token: 0x040000F5 RID: 245
	Keyboard,
	// Token: 0x040000F6 RID: 246
	Mouse
}
