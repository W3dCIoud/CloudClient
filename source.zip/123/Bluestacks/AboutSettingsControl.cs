﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Markup;
using System.Windows.Navigation;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200012D RID: 301
	public class AboutSettingsControl : UserControl, IComponentConnector
	{
		// Token: 0x06000BD8 RID: 3032 RVA: 0x00050C00 File Offset: 0x0004EE00
		public AboutSettingsControl(MainWindow window, SettingsWindow settingswindow)
		{
			this.ParentWindow = window;
			this.ParentSettingsWindow = settingswindow;
			this.InitializeComponent();
			base.Visibility = Visibility.Hidden;
			base.Loaded += this.AboutSettingsControl_Loaded;
			this.mVersionLabel.Content = "v" + RegistryManager.Instance.Version;
			BlueStacksUIBinding.Bind(this.mSupportLabel, "STRING_SUPPORT");
			this.mSupportLabel.ContentStringFormat = "{0} - ";
			BlueStacksUIBinding.Bind(this.mWebsiteLabel, "STRING_WEBSITE");
			this.mWebsiteLabel.ContentStringFormat = "{0} - ";
			BlueStacksUIBinding.Bind(this.mSupportMailLabel, "STRING_SUPPORT_EMAIL");
			this.mSupportMailLabel.ContentStringFormat = "{0} - ";
			if (Oem.Instance.IsProductBeta)
			{
				Label label = this.mVersionLabel;
				label.Content += LocaleStrings.GetLocalizedString("STRING_BETA", false);
			}
			string str = WebHelper.GetUrlWithParams(string.Format("{0}/{1}", WebHelper.GetServerHost(), "help_articles")) + "&article=";
			this.mTermsOfUseLink.NavigateUri = new Uri(str + "terms_of_use");
			this.mDetailedChangeLogs.Inlines.Clear();
			this.mDetailedChangeLogs.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_DETAILED_CHANGELOG", false));
		}

		// Token: 0x06000BD9 RID: 3033 RVA: 0x00050D58 File Offset: 0x0004EF58
		private void AboutSettingsControl_Loaded(object sender, RoutedEventArgs e)
		{
			if (FeatureManager.Instance.IsCustomUIForDMMSandbox)
			{
				this.ContactInfoGrid.Visibility = Visibility.Hidden;
			}
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				this.mPoweredByBSGrid.Visibility = Visibility.Visible;
				this.mBSIconAndNameGrid.Visibility = Visibility.Hidden;
			}
			if (Oem.Instance.IsProductBeta)
			{
				string text = "beta-support@bluestacks.com";
				this.mSupportEMailHyperlink.Inlines.Clear();
				this.mSupportEMailHyperlink.Inlines.Add(text);
				this.mSupportEMailHyperlink.NavigateUri = new Uri("mailto:" + text);
			}
			this.HandleUpdateStateGridVisibility(BlueStacksUpdater.SUpdateState);
			BlueStacksUpdater.StateChanged -= this.BlueStacksUpdater_StateChanged;
			BlueStacksUpdater.StateChanged += this.BlueStacksUpdater_StateChanged;
		}

		// Token: 0x06000BDA RID: 3034 RVA: 0x0000932C File Offset: 0x0000752C
		private void BlueStacksUpdater_StateChanged()
		{
			this.HandleUpdateStateGridVisibility(BlueStacksUpdater.SUpdateState);
		}

		// Token: 0x06000BDB RID: 3035 RVA: 0x00050E20 File Offset: 0x0004F020
		private void HandleUpdateStateGridVisibility(BlueStacksUpdater.UpdateState state)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				switch (state)
				{
				case BlueStacksUpdater.UpdateState.NO_UPDATE:
					this.mUpdateInfoGrid.Visibility = Visibility.Collapsed;
					this.mCheckUpdateBtn.HorizontalAlignment = HorizontalAlignment.Left;
					this.mCheckUpdateBtn.Visibility = Visibility.Visible;
					BlueStacksUIBinding.Bind(this.mCheckUpdateBtn, "STRING_CHECK_UPDATES");
					this.mStatusLabel.Visibility = Visibility.Collapsed;
					this.mCheckingGrid.Visibility = Visibility.Collapsed;
					return;
				case BlueStacksUpdater.UpdateState.UPDATE_AVAILABLE:
					this.mUpdateInfoGrid.Visibility = Visibility.Visible;
					BlueStacksUIBinding.Bind(this.bodyLabel, "STRING_UPDATE_AVAILABLE");
					this.mDetailedChangeLogs.NavigateUri = new Uri(BlueStacksUpdater.sBstUpdateData.DetailedChangeLogsUrl);
					this.mLabelVersion.Content = "v" + BlueStacksUpdater.sBstUpdateData.EngineVersion;
					this.mCheckUpdateBtn.HorizontalAlignment = HorizontalAlignment.Right;
					this.mCheckUpdateBtn.Visibility = Visibility.Visible;
					BlueStacksUIBinding.Bind(this.mCheckUpdateBtn, "STRING_DOWNLOAD_UPDATE");
					this.mStatusLabel.Visibility = Visibility.Collapsed;
					this.mCheckingGrid.Visibility = Visibility.Collapsed;
					return;
				case BlueStacksUpdater.UpdateState.DOWNLOADING:
					this.mUpdateInfoGrid.Visibility = Visibility.Visible;
					BlueStacksUIBinding.Bind(this.bodyLabel, "STRING_DOWNLOADING_UPDATE");
					this.mDetailedChangeLogs.NavigateUri = new Uri(BlueStacksUpdater.sBstUpdateData.DetailedChangeLogsUrl);
					this.mLabelVersion.Content = "v" + BlueStacksUpdater.sBstUpdateData.EngineVersion;
					this.mCheckUpdateBtn.Visibility = Visibility.Collapsed;
					this.mStatusLabel.Visibility = Visibility.Collapsed;
					this.mCheckingGrid.Visibility = Visibility.Collapsed;
					return;
				case BlueStacksUpdater.UpdateState.DOWNLOADED:
					this.mUpdateInfoGrid.Visibility = Visibility.Visible;
					BlueStacksUIBinding.Bind(this.bodyLabel, "STRING_UPDATES_READY_TO_INSTALL");
					this.mDetailedChangeLogs.NavigateUri = new Uri(BlueStacksUpdater.sBstUpdateData.DetailedChangeLogsUrl);
					this.mLabelVersion.Content = "v" + BlueStacksUpdater.sBstUpdateData.EngineVersion;
					this.mCheckUpdateBtn.HorizontalAlignment = HorizontalAlignment.Right;
					this.mCheckUpdateBtn.Visibility = Visibility.Visible;
					BlueStacksUIBinding.Bind(this.mCheckUpdateBtn, "STRING_INSTALL_UPDATE");
					this.mStatusLabel.Visibility = Visibility.Collapsed;
					this.mCheckingGrid.Visibility = Visibility.Collapsed;
					return;
				default:
					return;
				}
			}), new object[0]);
		}

		// Token: 0x06000BDC RID: 3036 RVA: 0x00009339 File Offset: 0x00007539
		private void ShowCheckingForUpdateGrid()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mUpdateInfoGrid.Visibility = Visibility.Collapsed;
				this.mCheckUpdateBtn.Visibility = Visibility.Collapsed;
				this.mStatusLabel.Visibility = Visibility.Collapsed;
				this.mCheckingGrid.Visibility = Visibility.Visible;
			}), new object[0]);
		}

		// Token: 0x06000BDD RID: 3037 RVA: 0x00009359 File Offset: 0x00007559
		private void ShowLatestVersionGrid()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mUpdateInfoGrid.Visibility = Visibility.Collapsed;
				this.mCheckUpdateBtn.Visibility = Visibility.Collapsed;
				this.mStatusLabel.Visibility = Visibility.Visible;
				BlueStacksUIBinding.Bind(this.mStatusLabel, "STRING_LATEST_VERSION", "");
				this.mCheckingGrid.Visibility = Visibility.Collapsed;
			}), new object[0]);
		}

		// Token: 0x06000BDE RID: 3038 RVA: 0x00009379 File Offset: 0x00007579
		private void ShowInternetConnectionErrorGrid()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mUpdateInfoGrid.Visibility = Visibility.Collapsed;
				this.mCheckUpdateBtn.HorizontalAlignment = HorizontalAlignment.Right;
				this.mCheckUpdateBtn.Visibility = Visibility.Visible;
				BlueStacksUIBinding.Bind(this.mCheckUpdateBtn, "STRING_RETRY_CONNECTION_ISSUE_TEXT1");
				this.mStatusLabel.Visibility = Visibility.Visible;
				BlueStacksUIBinding.Bind(this.mStatusLabel, "STRING_POST_OTS_FAILED_WARNING_MESSAGE", "");
				this.mCheckingGrid.Visibility = Visibility.Collapsed;
			}), new object[0]);
		}

		// Token: 0x06000BDF RID: 3039 RVA: 0x00050E60 File Offset: 0x0004F060
		private void mCheckUpdateBtn_Click(object sender, RoutedEventArgs e)
		{
			if (this.mCheckUpdateBtn.Content.ToString().Equals(LocaleStrings.GetLocalizedString("STRING_DOWNLOAD_UPDATE", false)))
			{
				BlueStacksUpdater.DownloadNow(BlueStacksUpdater.sBstUpdateData, false);
				ClientStats.SendBluestacksUpdaterUIStatsAsync(ClientStatsEvent.SettingDownloadUpdate, "");
				return;
			}
			if (this.mCheckUpdateBtn.Content.ToString().Equals(LocaleStrings.GetLocalizedString("STRING_INSTALL_UPDATE", false)))
			{
				this.ParentWindow.ShowInstallPopup();
				ClientStats.SendBluestacksUpdaterUIStatsAsync(ClientStatsEvent.SettingInstallUpdate, "");
				return;
			}
			if (this.mCheckUpdateBtn.Content.ToString().Equals(LocaleStrings.GetLocalizedString("STRING_CHECK_UPDATES", false)) || this.mCheckUpdateBtn.Content.ToString().Equals(LocaleStrings.GetLocalizedString("STRING_RETRY_CONNECTION_ISSUE_TEXT1", false)))
			{
				this.ShowCheckingForUpdateGrid();
				BlueStacksUpdater.sCheckUpdateBackgroundWorker.RunWorkerCompleted -= this.HandleCheckForUpdateResult;
				BlueStacksUpdater.sCheckUpdateBackgroundWorker.RunWorkerCompleted += this.HandleCheckForUpdateResult;
				BlueStacksUpdater.SetupBlueStacksUpdater(this.ParentWindow, false);
				ClientStats.SendBluestacksUpdaterUIStatsAsync(ClientStatsEvent.SettingCheckUpdate, "");
			}
		}

		// Token: 0x06000BE0 RID: 3040 RVA: 0x00050F78 File Offset: 0x0004F178
		private void HandleCheckForUpdateResult(object sender, RunWorkerCompletedEventArgs e)
		{
			if (BlueStacksUpdater.sBstUpdateData.IsUpdateAvailble)
			{
				this.HandleUpdateStateGridVisibility(BlueStacksUpdater.SUpdateState);
				ClientStats.SendBluestacksUpdaterUIStatsAsync(ClientStatsEvent.SettingUpdateAvailable, "");
				return;
			}
			if (BlueStacksUpdater.sBstUpdateData.IsTryAgain)
			{
				this.ShowInternetConnectionErrorGrid();
				return;
			}
			this.ShowLatestVersionGrid();
			ClientStats.SendBluestacksUpdaterUIStatsAsync(ClientStatsEvent.SettingUpdateNotAvailable, "");
		}

		// Token: 0x06000BE1 RID: 3041 RVA: 0x00009399 File Offset: 0x00007599
		private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
		{
			BlueStacksUIUtils.OpenUrl(e.Uri.OriginalString);
			e.Handled = true;
		}

		// Token: 0x06000BE2 RID: 3042 RVA: 0x000093B2 File Offset: 0x000075B2
		private void mTermsOfUseLink_Loaded(object sender, RoutedEventArgs e)
		{
			this.mTermsOfUseLink.Inlines.Clear();
			this.mTermsOfUseLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_TERMS_OF_USE_LINK", false));
		}

		// Token: 0x06000BE3 RID: 3043 RVA: 0x00050FD4 File Offset: 0x0004F1D4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/aboutsettingscontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000BE4 RID: 3044 RVA: 0x00051004 File Offset: 0x0004F204
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mPoweredByBSGrid = (Grid)target;
				return;
			case 2:
				this.mBSIconAndNameGrid = (Grid)target;
				return;
			case 3:
				this.mProductTextGrid = (Grid)target;
				return;
			case 4:
				this.mVersionLabel = (Label)target;
				return;
			case 5:
				this.mUpdateInfoGrid = (Grid)target;
				return;
			case 6:
				this.bodyLabel = (Label)target;
				return;
			case 7:
				this.mLabelVersion = (Label)target;
				return;
			case 8:
				this.mDetailedChangeLogs = (Hyperlink)target;
				this.mDetailedChangeLogs.RequestNavigate += this.Hyperlink_RequestNavigate;
				return;
			case 9:
				this.mCheckUpdateBtn = (CustomButton)target;
				this.mCheckUpdateBtn.Click += this.mCheckUpdateBtn_Click;
				return;
			case 10:
				this.mStatusLabel = (TextBlock)target;
				return;
			case 11:
				this.mCheckingGrid = (Grid)target;
				return;
			case 12:
				this.ContactInfoGrid = (Grid)target;
				return;
			case 13:
				this.mWebsiteLabel = (Label)target;
				return;
			case 14:
				((Hyperlink)target).RequestNavigate += this.Hyperlink_RequestNavigate;
				return;
			case 15:
				this.mSupportLabel = (Label)target;
				return;
			case 16:
				((Hyperlink)target).RequestNavigate += this.Hyperlink_RequestNavigate;
				return;
			case 17:
				this.mSupportMailLabel = (Label)target;
				return;
			case 18:
				this.mSupportEMailHyperlink = (Hyperlink)target;
				this.mSupportEMailHyperlink.RequestNavigate += this.Hyperlink_RequestNavigate;
				return;
			case 19:
				this.mTermsOfUse = (TextBlock)target;
				return;
			case 20:
				this.mTermsOfUseLink = (Hyperlink)target;
				this.mTermsOfUseLink.RequestNavigate += this.Hyperlink_RequestNavigate;
				this.mTermsOfUseLink.Loaded += this.mTermsOfUseLink_Loaded;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400089A RID: 2202
		private MainWindow ParentWindow;

		// Token: 0x0400089B RID: 2203
		private SettingsWindow ParentSettingsWindow;

		// Token: 0x0400089C RID: 2204
		internal Grid mPoweredByBSGrid;

		// Token: 0x0400089D RID: 2205
		internal Grid mBSIconAndNameGrid;

		// Token: 0x0400089E RID: 2206
		internal Grid mProductTextGrid;

		// Token: 0x0400089F RID: 2207
		internal Label mVersionLabel;

		// Token: 0x040008A0 RID: 2208
		internal Grid mUpdateInfoGrid;

		// Token: 0x040008A1 RID: 2209
		internal Label bodyLabel;

		// Token: 0x040008A2 RID: 2210
		internal Label mLabelVersion;

		// Token: 0x040008A3 RID: 2211
		internal Hyperlink mDetailedChangeLogs;

		// Token: 0x040008A4 RID: 2212
		internal CustomButton mCheckUpdateBtn;

		// Token: 0x040008A5 RID: 2213
		internal TextBlock mStatusLabel;

		// Token: 0x040008A6 RID: 2214
		internal Grid mCheckingGrid;

		// Token: 0x040008A7 RID: 2215
		internal Grid ContactInfoGrid;

		// Token: 0x040008A8 RID: 2216
		internal Label mWebsiteLabel;

		// Token: 0x040008A9 RID: 2217
		internal Label mSupportLabel;

		// Token: 0x040008AA RID: 2218
		internal Label mSupportMailLabel;

		// Token: 0x040008AB RID: 2219
		internal Hyperlink mSupportEMailHyperlink;

		// Token: 0x040008AC RID: 2220
		internal TextBlock mTermsOfUse;

		// Token: 0x040008AD RID: 2221
		internal Hyperlink mTermsOfUseLink;

		// Token: 0x040008AE RID: 2222
		private bool _contentLoaded;
	}
}
