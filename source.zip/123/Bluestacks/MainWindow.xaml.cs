﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using BlueStacks.BlueStacksUI.BTv;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200021A RID: 538
	public partial class MainWindow : CustomWindow, IStyleConnector
	{
		// Token: 0x17000212 RID: 530
		// (get) Token: 0x0600126D RID: 4717 RVA: 0x0000D09E File Offset: 0x0000B29E
		// (set) Token: 0x0600126E RID: 4718 RVA: 0x0000D0A6 File Offset: 0x0000B2A6
		internal int ParentWindowHeightDiff
		{
			get
			{
				return this.mHeightDiff;
			}
			set
			{
				this.mHeightDiff = value;
			}
		}

		// Token: 0x17000213 RID: 531
		// (get) Token: 0x0600126F RID: 4719 RVA: 0x0000D0AF File Offset: 0x0000B2AF
		// (set) Token: 0x06001270 RID: 4720 RVA: 0x0000D0B7 File Offset: 0x0000B2B7
		internal int ParentWindowWidthDiff
		{
			get
			{
				return this.mWidthDiff;
			}
			set
			{
				this.mWidthDiff = value;
			}
		}

		// Token: 0x17000214 RID: 532
		// (get) Token: 0x06001271 RID: 4721 RVA: 0x0000D0C0 File Offset: 0x0000B2C0
		public System.Windows.Controls.UserControl TopBar
		{
			get
			{
				if (FeatureManager.Instance.IsCustomUIForNCSoft)
				{
					return this.mNCTopBar;
				}
				return this.mTopBar;
			}
		}

		// Token: 0x17000215 RID: 533
		// (get) Token: 0x06001272 RID: 4722 RVA: 0x0000D0C0 File Offset: 0x0000B2C0
		internal ITopBar _TopBar
		{
			get
			{
				if (FeatureManager.Instance.IsCustomUIForNCSoft)
				{
					return this.mNCTopBar;
				}
				return this.mTopBar;
			}
		}

		// Token: 0x17000216 RID: 534
		// (get) Token: 0x06001273 RID: 4723 RVA: 0x0000D0DB File Offset: 0x0000B2DB
		// (set) Token: 0x06001274 RID: 4724 RVA: 0x0000D0F6 File Offset: 0x0000B2F6
		internal IMConfig SelectedConfig
		{
			get
			{
				if (this.mSelectedConfig == null)
				{
					this.mSelectedConfig = new IMConfig();
				}
				return this.mSelectedConfig;
			}
			set
			{
				this.mSelectedConfig = value;
			}
		}

		// Token: 0x17000217 RID: 535
		// (get) Token: 0x06001275 RID: 4725 RVA: 0x0000D0FF File Offset: 0x0000B2FF
		// (set) Token: 0x06001276 RID: 4726 RVA: 0x0000D11A File Offset: 0x0000B31A
		internal IMConfig OriginalLoadedConfig
		{
			get
			{
				if (this.mOriginalLoadedConfig == null)
				{
					this.mOriginalLoadedConfig = new IMConfig();
				}
				return this.mOriginalLoadedConfig;
			}
			set
			{
				this.mOriginalLoadedConfig = value;
			}
		}

		// Token: 0x17000218 RID: 536
		// (get) Token: 0x06001277 RID: 4727 RVA: 0x0000D123 File Offset: 0x0000B323
		// (set) Token: 0x06001278 RID: 4728 RVA: 0x0000D12B File Offset: 0x0000B32B
		internal bool SkipNextGamepadStatus
		{
			get
			{
				return this.mSkipNextGamepadStatus;
			}
			set
			{
				this.mSkipNextGamepadStatus = value;
				if (this.mSkipNextGamepadStatus)
				{
					this.WasGamepadStatusSkipped = value;
				}
			}
		}

		// Token: 0x17000219 RID: 537
		// (get) Token: 0x06001279 RID: 4729 RVA: 0x0000D143 File Offset: 0x0000B343
		// (set) Token: 0x0600127A RID: 4730 RVA: 0x0000D14B File Offset: 0x0000B34B
		internal bool WasGamepadStatusSkipped { get; set; }

		// Token: 0x1700021A RID: 538
		// (get) Token: 0x0600127B RID: 4731 RVA: 0x0000D154 File Offset: 0x0000B354
		// (set) Token: 0x0600127C RID: 4732 RVA: 0x00071F64 File Offset: 0x00070164
		internal bool IsGamepadConnected
		{
			get
			{
				return this.mIsGamepadConnected;
			}
			set
			{
				this.mIsGamepadConnected = value;
				if (RegistryManager.Instance.IsShowToastNotification && !this.SkipNextGamepadStatus)
				{
					this.ShowGamepadToast(value);
				}
				this.SkipNextGamepadStatus = false;
				this.SendGamepadStatusToBrowsers(value);
				this.mWelcomeTab.mHomeApp.UpdateGamepadIcons();
			}
		}

		// Token: 0x0600127D RID: 4733 RVA: 0x00071FB4 File Offset: 0x000701B4
		private void ShowGamepadToast(bool state)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					if (this.mIsWindowInFocus)
					{
						if (this.toastPopup.IsOpen)
						{
							this.toastTimer.Stop();
							this.toastPopup.IsOpen = false;
						}
						if (state)
						{
							this.toastControl.Init(this, LocaleStrings.GetLocalizedString("STRING_GAMEPAD_CONNECTED", false), null, new SolidColorBrush(System.Windows.Media.Color.FromArgb(85, byte.MaxValue, byte.MaxValue, byte.MaxValue)), System.Windows.HorizontalAlignment.Right, VerticalAlignment.Bottom, new Thickness?(new Thickness(0.0, 0.0, 20.0, 20.0)), 5, null, null, false);
							this.toastControl.AddImage("gamepad_connected", 16.0, 24.0, new Thickness?(new Thickness(0.0, 5.0, 10.0, 5.0)));
						}
						else
						{
							this.toastControl.Init(this, LocaleStrings.GetLocalizedString("STRING_GAMEPAD_DISCONNECTED", false), null, new SolidColorBrush(System.Windows.Media.Color.FromArgb(85, byte.MaxValue, byte.MaxValue, byte.MaxValue)), System.Windows.HorizontalAlignment.Right, VerticalAlignment.Bottom, new Thickness?(new Thickness(0.0, 0.0, 20.0, 20.0)), 5, null, null, false);
							this.toastControl.AddImage("gamepad_disconnected", 19.0, 24.0, new Thickness?(new Thickness(0.0, 5.0, 10.0, 5.0)));
						}
						this.dummyToast.HorizontalAlignment = System.Windows.HorizontalAlignment.Right;
						this.dummyToast.VerticalAlignment = VerticalAlignment.Bottom;
						this.toastControl.Visibility = Visibility.Visible;
						this.toastPopup.IsOpen = true;
						this.toastCanvas.Width = this.toastControl.ActualWidth;
						this.toastCanvas.Height = this.toastControl.ActualHeight;
						this.toastPopup.VerticalOffset = -1.0 * this.toastControl.ActualHeight - 50.0;
						this.toastPopup.HorizontalOffset = -20.0;
						this.toastTimer.Start();
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in showing toast popup for gamepad : " + ex.ToString());
				}
			}), new object[0]);
		}

		// Token: 0x0600127E RID: 4734 RVA: 0x00071FF4 File Offset: 0x000701F4
		internal void ShowGeneralToast(string message)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					if (this.mIsWindowInFocus)
					{
						if (this.mGeneraltoast.IsOpen)
						{
							this.toastTimer.Stop();
							this.mGeneraltoast.IsOpen = false;
						}
						this.mGeneraltoastControl.Init(this, message, System.Windows.Media.Brushes.Black, new SolidColorBrush(System.Windows.Media.Color.FromArgb(85, byte.MaxValue, byte.MaxValue, byte.MaxValue)), System.Windows.HorizontalAlignment.Center, VerticalAlignment.Bottom, null, 5, null, null, false);
						this.dummyToast.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
						this.dummyToast.VerticalAlignment = VerticalAlignment.Bottom;
						this.mGeneraltoastControl.Visibility = Visibility.Visible;
						this.mGeneraltoast.IsOpen = true;
						this.mGeneraltoastCanvas.Height = this.mGeneraltoastControl.ActualHeight;
						this.mGeneraltoast.VerticalOffset = -1.0 * this.mGeneraltoastControl.ActualHeight - 50.0;
						this.mGeneraltoast.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
						this.toastTimer.Start();
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in showing general toast popup : " + ex.ToString());
				}
			}), new object[0]);
		}

		// Token: 0x0600127F RID: 4735 RVA: 0x0000D15C File Offset: 0x0000B35C
		private void ToastTimer_Tick(object sender, EventArgs e)
		{
			this.toastTimer.Stop();
			this.toastPopup.IsOpen = false;
			this.mGeneraltoast.IsOpen = false;
		}

		// Token: 0x06001280 RID: 4736 RVA: 0x0000D181 File Offset: 0x0000B381
		internal void CloseFullScreenToastAndStopTimer()
		{
			this.mFullScreenToastTimer.Stop();
			this.mFullScreenToastPopup.IsOpen = false;
		}

		// Token: 0x06001281 RID: 4737 RVA: 0x0000D19A File Offset: 0x0000B39A
		private void FullScreenToastTimer_Tick(object sender, EventArgs e)
		{
			this.CloseFullScreenToastAndStopTimer();
		}

		// Token: 0x06001282 RID: 4738 RVA: 0x00072034 File Offset: 0x00070234
		internal void SendGamepadStatusToBrowsers(bool status)
		{
			try
			{
				object[] array = new object[]
				{
					""
				};
				array[0] = status.ToString();
				foreach (BrowserControl browserControl in BrowserControl.sAllBrowserControls)
				{
					try
					{
						if (browserControl != null && browserControl.mBrowser != null)
						{
							browserControl.mBrowser.CallJs("toggleGamePadSupport", array);
						}
					}
					catch (Exception ex)
					{
						Logger.Error("Exception in sending gamepad status to browser:" + browserControl.mUrl + Environment.NewLine + ex.ToString());
					}
				}
			}
			catch (Exception ex2)
			{
				Logger.Error("Exception in sending gamepad status to browser:" + ex2.ToString());
			}
		}

		// Token: 0x14000026 RID: 38
		// (add) Token: 0x06001283 RID: 4739 RVA: 0x00072110 File Offset: 0x00070310
		// (remove) Token: 0x06001284 RID: 4740 RVA: 0x00072148 File Offset: 0x00070348
		private event EventHandler CloseWindowConfirmationAcceptedHandler;

		// Token: 0x14000027 RID: 39
		// (add) Token: 0x06001285 RID: 4741 RVA: 0x00072180 File Offset: 0x00070380
		// (remove) Token: 0x06001286 RID: 4742 RVA: 0x000721B8 File Offset: 0x000703B8
		private event EventHandler CloseWindowConfirmationResetAccountAcceptedHandler;

		// Token: 0x14000028 RID: 40
		// (add) Token: 0x06001287 RID: 4743 RVA: 0x000721F0 File Offset: 0x000703F0
		// (remove) Token: 0x06001288 RID: 4744 RVA: 0x00072228 File Offset: 0x00070428
		public event MainWindow.GuestBootCompleted GuestBootCompletedEvent;

		// Token: 0x14000029 RID: 41
		// (add) Token: 0x06001289 RID: 4745 RVA: 0x00072260 File Offset: 0x00070460
		// (remove) Token: 0x0600128A RID: 4746 RVA: 0x00072298 File Offset: 0x00070498
		public event MainWindow.CursorLockChanged CursorLockChangedEvent;

		// Token: 0x1400002A RID: 42
		// (add) Token: 0x0600128B RID: 4747 RVA: 0x000722D0 File Offset: 0x000704D0
		// (remove) Token: 0x0600128C RID: 4748 RVA: 0x00072308 File Offset: 0x00070508
		public event MainWindow.FullScreenChanged FullScreenChangedEvent;

		// Token: 0x1400002B RID: 43
		// (add) Token: 0x0600128D RID: 4749 RVA: 0x00072340 File Offset: 0x00070540
		// (remove) Token: 0x0600128E RID: 4750 RVA: 0x00072378 File Offset: 0x00070578
		public event MainWindow.FrontendGridVisibleChanged FrontendGridVisibleChangedEvent;

		// Token: 0x1400002C RID: 44
		// (add) Token: 0x0600128F RID: 4751 RVA: 0x000723B0 File Offset: 0x000705B0
		// (remove) Token: 0x06001290 RID: 4752 RVA: 0x000723E8 File Offset: 0x000705E8
		private event EventHandler mEventOnAllWindowClosed;

		// Token: 0x1400002D RID: 45
		// (add) Token: 0x06001291 RID: 4753 RVA: 0x00072420 File Offset: 0x00070620
		// (remove) Token: 0x06001292 RID: 4754 RVA: 0x00072458 File Offset: 0x00070658
		private event EventHandler mEventOnInstanceClosed;

		// Token: 0x1400002E RID: 46
		// (add) Token: 0x06001293 RID: 4755 RVA: 0x00072490 File Offset: 0x00070690
		// (remove) Token: 0x06001294 RID: 4756 RVA: 0x000724C8 File Offset: 0x000706C8
		internal event EventHandler RestartEngineConfirmationAcceptedHandler;

		// Token: 0x1400002F RID: 47
		// (add) Token: 0x06001295 RID: 4757 RVA: 0x00072500 File Offset: 0x00070700
		// (remove) Token: 0x06001296 RID: 4758 RVA: 0x00072538 File Offset: 0x00070738
		internal event EventHandler RestartPcConfirmationAcceptedHandler;

		// Token: 0x1700021B RID: 539
		// (get) Token: 0x06001297 RID: 4759 RVA: 0x0000D1A2 File Offset: 0x0000B3A2
		internal ScreenLockControl ScreenLockInstance
		{
			get
			{
				if (this.mScreenLock == null)
				{
					this.mScreenLock = new ScreenLockControl();
				}
				return this.mScreenLock;
			}
		}

		// Token: 0x06001298 RID: 4760 RVA: 0x00072570 File Offset: 0x00070770
		private void GetMacroShortcutKeyMappingsWithRestrictedKeysandNames()
		{
			if (Directory.Exists(RegistryStrings.OperationsScriptFolder))
			{
				foreach (string path in Directory.GetFiles(RegistryStrings.OperationsScriptFolder))
				{
					string path2 = System.IO.Path.Combine(RegistryStrings.OperationsScriptFolder, path);
					if (File.Exists(path2))
					{
						try
						{
							OperationsRecord operationsRecord = JsonConvert.DeserializeObject<OperationsRecord>(File.ReadAllText(path2), BlueStacks.Common.Utils.GetSerializerSettings());
							operationsRecord.Name = System.IO.Path.GetFileNameWithoutExtension(path2);
							MainWindow.sMacroScriptNames.Add(operationsRecord.Name.ToLower().Trim());
							if (operationsRecord.ShortCut.Length == 1)
							{
								MainWindow.sMacroMapping.Add(operationsRecord.ShortCut, operationsRecord.Name);
							}
							if (operationsRecord.PlayOnStart)
							{
								if (this.mAutoRunMacro == null)
								{
									this.mAutoRunMacro = operationsRecord;
								}
								else
								{
									operationsRecord.PlayOnStart = false;
									this.mCommonHandler.SerializeJsonOperationRecord(operationsRecord, operationsRecord.Name + ".json");
								}
							}
						}
						catch
						{
							Logger.Error("Unable to deserialize userscript.");
						}
					}
				}
				HTTPUtils.SendRequestToEngineAsync("updateMacroShortcutsDict", MainWindow.sMacroMapping, this.mVmName, 0, null, false, 1, 0);
			}
		}

		// Token: 0x06001299 RID: 4761 RVA: 0x00004BF2 File Offset: 0x00002DF2
		private static void GenerateRestrictedKeysList()
		{
		}

		// Token: 0x1700021C RID: 540
		// (get) Token: 0x0600129A RID: 4762 RVA: 0x0000D1BD File Offset: 0x0000B3BD
		internal MacroOverlay MacroOverlayControl
		{
			get
			{
				if (this.mMacroOverlay == null)
				{
					this.mMacroOverlay = new MacroOverlay(this);
				}
				return this.mMacroOverlay;
			}
		}

		// Token: 0x1700021D RID: 541
		// (get) Token: 0x0600129B RID: 4763 RVA: 0x0000D1D9 File Offset: 0x0000B3D9
		internal InstanceRegistry EngineInstanceRegistry
		{
			get
			{
				return RegistryManager.Instance.Guest[this.mVmName];
			}
		}

		// Token: 0x1700021E RID: 542
		// (get) Token: 0x0600129C RID: 4764 RVA: 0x0000D1F0 File Offset: 0x0000B3F0
		internal OperationRecorderWindow OperationRecorderWindow
		{
			get
			{
				if (this.mOperationRecorderWindow == null)
				{
					this.mOperationRecorderWindow = new OperationRecorderWindow(this);
					this.mOperationRecorderWindow.Owner = this;
				}
				return this.mOperationRecorderWindow;
			}
		}

		// Token: 0x1700021F RID: 543
		// (get) Token: 0x0600129D RID: 4765 RVA: 0x0000D218 File Offset: 0x0000B418
		internal BlueStacksUIUtils Utils
		{
			get
			{
				if (this.mUtils == null)
				{
					this.mUtils = new BlueStacksUIUtils(this);
				}
				return this.mUtils;
			}
		}

		// Token: 0x17000220 RID: 544
		// (get) Token: 0x0600129E RID: 4766 RVA: 0x0000D234 File Offset: 0x0000B434
		internal MainWindowsStaticComponents StaticComponents
		{
			get
			{
				if (this.mStaticComponents == null)
				{
					this.mStaticComponents = new MainWindowsStaticComponents();
				}
				return this.mStaticComponents;
			}
		}

		// Token: 0x17000221 RID: 545
		// (get) Token: 0x0600129F RID: 4767 RVA: 0x0000D24F File Offset: 0x0000B44F
		internal bool IsDefaultVM
		{
			get
			{
				return this.mVmName.Equals(Strings.CurrentDefaultVmName);
			}
		}

		// Token: 0x17000222 RID: 546
		// (get) Token: 0x060012A0 RID: 4768 RVA: 0x0000D266 File Offset: 0x0000B466
		internal Storyboard StoryBoard
		{
			get
			{
				if (this.mStoryBoard == null)
				{
					this.mStoryBoard = (base.FindResource("mStoryBoard") as Storyboard);
				}
				return this.mStoryBoard;
			}
		}

		// Token: 0x17000223 RID: 547
		// (get) Token: 0x060012A1 RID: 4769 RVA: 0x0000D28C File Offset: 0x0000B48C
		internal bool SendClientActions
		{
			get
			{
				return this.mIsOperationRecorderActive || this.mIsSynchronisationActive;
			}
		}

		// Token: 0x060012A2 RID: 4770 RVA: 0x000726A4 File Offset: 0x000708A4
		public MainWindow(string vmName)
		{
			this.mVmName = vmName;
			this.GetLockOfCurrentInstance();
			this.SetMultiInstanceEventWaitHandle();
			this.mFrontendHandler = new FrontendHandler(this);
			this.InitializeComponent();
			if (!FeatureManager.Instance.IsCustomUIForDMM)
			{
				this.mWelcomeTab.Init();
				this.mFrontendGrid.Visibility = Visibility.Visible;
			}
			else
			{
				this.WelcomeTabParentGrid.Visibility = Visibility.Hidden;
				this.mWelcomeTab.Init();
				this.mWelcomeTab.Visibility = Visibility.Hidden;
				this.mWelcomeTab.mPromotionGrid.Visibility = Visibility.Hidden;
				this.mWelcomeTab.mPromotionControl.IsEnabled = false;
				this.FrontendParentGrid.Visibility = Visibility.Visible;
				this.mDmmProgressControl.Visibility = Visibility.Visible;
				this.mFrontendGrid.Visibility = Visibility.Hidden;
				this.mBottomBar.IsEnabled = false;
				this.mDmmBottomBar.Visibility = Visibility.Visible;
				this.mDMMFST = new DMMFullScreenTopBar();
				this.mDmmBottomBar.Init(this);
				this.mTopBarPopup.Child = this.mDMMFST;
				this.mDMMFST.Init(this);
				this.mDMMFST.MouseLeave += this.TopBarPopup_MouseLeave;
			}
			base.SizeChanged += this.MainWindow_SizeChanged;
			base.LocationChanged += this.MainWindow_LocationChanged;
			this.SetupInitialSize();
			this.SetWindowTitle(vmName);
			this.mResizeHandler = new WindowWndProcHandler(this);
			this.mExitProgressGrid.ProgressText = "STRING_CLOSING_BLUESTACKS";
			this.mAppHandler = new AppHandler(this);
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.mTopBar.Visibility = Visibility.Collapsed;
				this.mNCTopBar.Visibility = Visibility.Visible;
			}
			if (this.EngineInstanceRegistry.IsClientOnTop)
			{
				base.Topmost = true;
			}
			this.mCommonHandler = new CommonHandlers(this);
			this.mCommonHandler.InitShortcuts();
			this.mSidebar.InitElements();
			if (!string.IsNullOrEmpty(RegistryManager.Instance.Token))
			{
				this.mIsTokenAvailable = true;
			}
			if (this.IsDefaultVM && this.mAppHandler.IsOneTimeSetupCompleted)
			{
				PromotionObject.PromotionHandler = (EventHandler)Delegate.Combine(PromotionObject.PromotionHandler, new EventHandler(this.MainWindow_PromotionHandler));
			}
			AppRequirementsParser.Instance.RequirementConfigUpdated += this.MainWindow_RequirementConfigUpdated;
			base.PreviewKeyDown += this.MainWindow_PreviewKeyDown;
			base.PreviewKeyUp += this.MainWindow_PreviewKeyUp;
			RegistryManager.Instance.BossKey = this.mCommonHandler.GetShortcutKeyFromName("STRING_BOSSKEY_SETTING", true);
			this.mIsWindowLoadedOnce = true;
		}

		// Token: 0x060012A3 RID: 4771 RVA: 0x00072A1C File Offset: 0x00070C1C
		private void GetLockOfCurrentInstance()
		{
			Logger.Debug("Getting lock of instance.." + this.mVmName);
			ProcessUtils.IsAlreadyRunning(Strings.GetClientInstanceLockName(this.mVmName), out this.mBlueStacksClientInstanceLock);
			if (this.mBlueStacksClientInstanceLock == null)
			{
				Logger.Error("Client lock is not created for vmName: {0}", new object[]
				{
					this.mVmName
				});
			}
		}

		// Token: 0x060012A4 RID: 4772 RVA: 0x00072A78 File Offset: 0x00070C78
		private void SetMultiInstanceEventWaitHandle()
		{
			try
			{
				EventWaitHandle.OpenExisting(BlueStacks.Common.Utils.GetMultiInstanceEventName(this.mVmName)).Set();
			}
			catch (Exception ex)
			{
				Logger.Error("Error while setting event wait handle for vmName: {0} ex: {1}", new object[]
				{
					this.mVmName,
					ex
				});
			}
		}

		// Token: 0x060012A5 RID: 4773 RVA: 0x0000D29E File Offset: 0x0000B49E
		private void MainWindow_RequirementConfigUpdated()
		{
			this.mWelcomeTab.mHomeApp.RequirementConfigUpdated();
		}

		// Token: 0x060012A6 RID: 4774 RVA: 0x0000D2B0 File Offset: 0x0000B4B0
		private void MainWindow_PromotionHandler(object sender, EventArgs e)
		{
			if (this.IsDefaultVM && this.mAppHandler.IsOneTimeSetupCompleted && !this.mGuestBootCompleted)
			{
				this.HandleFLEorAppPopupBeforeBoot();
			}
		}

		// Token: 0x060012A7 RID: 4775 RVA: 0x0000D2D5 File Offset: 0x0000B4D5
		private void SetTaskbarProperties()
		{
			base.Icon = new BitmapImage(new Uri(System.IO.Path.Combine(RegistryStrings.InstallDir, "app_icon.ico")));
			base.Title = GameConfig.Instance.AppName;
		}

		// Token: 0x060012A8 RID: 4776 RVA: 0x0000D306 File Offset: 0x0000B506
		internal void RestartFrontend()
		{
			this.mFrontendHandler.mEventOnFrontendClosed -= this.FrontendHandler_StartFrontend;
			this.mFrontendHandler.mEventOnFrontendClosed += this.FrontendHandler_StartFrontend;
			this.CloseFrontend();
		}

		// Token: 0x060012A9 RID: 4777 RVA: 0x0000D33C File Offset: 0x0000B53C
		private void FrontendHandler_StartFrontend(object sender, EventArgs e)
		{
			this.mFrontendHandler.StartFrontendAfterRAMCheck();
			if (!this.mFrontendHandler.mIsSufficientRAMAvailable)
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					this.mFrontendHandler.FrontendHandler_ShowLowRAMMessage();
				}), new object[0]);
			}
		}

		// Token: 0x060012AA RID: 4778 RVA: 0x0000D374 File Offset: 0x0000B574
		internal void CloseFrontend()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.ShowLoadingGrid(true);
				this.mTopBar.mAppTabButtons.GoToTab("Home", true, false);
				if (this.mWelcomeTab != null)
				{
					this.mWelcomeTab.mFrontendPopupControl.HideWindow();
				}
				this.mGuestBootCompleted = false;
				if (this.mAppHandler != null)
				{
					this.mAppHandler.IsGuestReady = false;
					this.mAppHandler.mGuestReadyCheckStarted = false;
				}
				this.mFrontendHandler.mFrontendHandle = IntPtr.Zero;
			}), new object[0]);
			this.mFrontendHandler.KillFrontend();
		}

		// Token: 0x060012AB RID: 4779 RVA: 0x00072AD0 File Offset: 0x00070CD0
		internal void SwitchToPortraitMode(bool isSwitchForPortraitMode)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					if (this.mPreviousWidth == null)
					{
						this.mPreviousWidth = new double?(this.Width);
					}
					bool flag = false;
					if (isSwitchForPortraitMode && this.WindowState != WindowState.Maximized)
					{
						if (isSwitchForPortraitMode != this.IsUIInPortraitMode)
						{
							flag = true;
							this.IsUIInPortraitMode = true;
							this.mTopBar.RefreshNotificationCentreButton();
							this.mTopBar.UpdateMacroRecordingProgress();
						}
					}
					else
					{
						if (isSwitchForPortraitMode && FeatureManager.Instance.IsCustomUIForDMM)
						{
							this.IsUIInPortraitMode = true;
							this.WindowState = WindowState.Normal;
							this.SetSizeForDMMPortraitMaximisedWindow();
							this.mTopBar.RefreshNotificationCentreButton();
							this.mTopBar.RefreshWarningButton();
							return;
						}
						if (isSwitchForPortraitMode != this.IsUIInPortraitMode)
						{
							flag = true;
							this.IsUIInPortraitMode = false;
							if (this.mIsDmmMaximised)
							{
								this.WindowState = WindowState.Maximized;
							}
							this.mTopBar.UpdateMacroRecordingProgress();
							this.mTopBar.RefreshNotificationCentreButton();
						}
					}
					if (this.WindowState == WindowState.Normal)
					{
						if (FeatureManager.Instance.IsCustomUIForDMM && this.mIsDmmMaximised && this.DmmRestoreWindowRectangle.Height != 0.0)
						{
							this.SetDMMSizeOnRestoreWindow();
						}
						else
						{
							this.ChangeHeightWidthAndPosition(this.GetWidthFromHeight((double)((int)this.Height), false), (double)((int)this.Height), flag || (this.IsUIInPortraitMode ^ this.IsUIInPortraitModeWhenMaximized));
						}
					}
					this.mTopBar.RefreshWarningButton();
					this.UIChangesOnMainWindowSizeChanged();
					if (this.mStreamingModeEnabled)
					{
						this.mFrontendHandler.ChangeFrontendToPortraitMode();
					}
					if (StreamManager.Instance != null)
					{
						StreamManager.Instance.OrientationChangeHandler();
					}
				}
				catch (Exception ex)
				{
					this.SetupInitialSize();
					Logger.Info("Error occured setting size." + ex.ToString());
				}
			}), new object[0]);
		}

		// Token: 0x060012AC RID: 4780 RVA: 0x00072B10 File Offset: 0x00070D10
		private void SetDMMSizeOnRestoreWindow()
		{
			this.ChangeHeightWidthAndPosition(this.GetWidthFromHeight((double)((int)this.DmmRestoreWindowRectangle.Height), false), (double)((int)this.DmmRestoreWindowRectangle.Height), false);
			if (this.mIsDMMMaximizedFromPortrait != this.IsUIInPortraitMode)
			{
				if (this.IsUIInPortraitMode)
				{
					base.Left = this.DmmRestoreWindowRectangle.Left + (this.DmmRestoreWindowRectangle.Width - base.Width) / 2.0;
				}
				else
				{
					base.Left = this.DmmRestoreWindowRectangle.Left - (base.Width - this.DmmRestoreWindowRectangle.Width) / 2.0;
				}
			}
			else
			{
				base.Left = this.DmmRestoreWindowRectangle.Left;
			}
			base.Top = this.DmmRestoreWindowRectangle.Top;
		}

		// Token: 0x060012AD RID: 4781 RVA: 0x00072BE0 File Offset: 0x00070DE0
		private void UIChangesOnMainWindowSizeChanged()
		{
			this.pikaPop.HorizontalOffset += 1.0;
			this.pikaPop.HorizontalOffset -= 1.0;
			this.toastPopup.HorizontalOffset += 1.0;
			this.toastPopup.HorizontalOffset -= 1.0;
			this.mShootingModePopup.HorizontalOffset += 1.0;
			this.mShootingModePopup.HorizontalOffset -= 1.0;
			this.mCommonHandler.ClipMouseCursorHandler(false, false, "", "");
		}

		// Token: 0x060012AE RID: 4782 RVA: 0x00072CA8 File Offset: 0x00070EA8
		private void ChangeHeightWidthAndPosition(double width, double height, bool changePosition)
		{
			try
			{
				base.Height = height;
				base.Width = width;
				if (FeatureManager.Instance.IsCustomUIForDMM && !this.mIsWindowResizedOnce)
				{
					double num = (base.Height - (double)this.mHeightDiff) * 9.0 / 16.0 + (double)this.mWidthDiff;
					base.Left = (SystemParameters.MaximizedPrimaryScreenWidth - base.Width - num) / 2.0;
					base.Top = (SystemParameters.MaximizedPrimaryScreenHeight - base.Height) / 2.0;
					this.mIsWindowResizedOnce = true;
				}
				else if (changePosition)
				{
					if (this.IsUIInPortraitMode)
					{
						base.Left += (this.mPreviousWidth.Value - base.Width) / 2.0;
					}
					else
					{
						base.Left -= (base.Width - this.mPreviousWidth.Value) / 2.0;
					}
				}
				this.mPreviousWidth = null;
			}
			catch (Exception ex)
			{
				Logger.Info("Error occured setting size." + ex.ToString());
			}
		}

		// Token: 0x060012AF RID: 4783 RVA: 0x00072DDC File Offset: 0x00070FDC
		internal void ChangeHeightWidthTopLeft(double width, double height, double top, double left)
		{
			try
			{
				if (base.WindowState == WindowState.Maximized)
				{
					this.RestoreWindows();
				}
				base.Height = height / MainWindow.sScalingFactor;
				base.Width = width / MainWindow.sScalingFactor;
				base.Top = top / MainWindow.sScalingFactor;
				base.Left = left / MainWindow.sScalingFactor;
				Sidebar sidebar = this.mSidebar;
				if (sidebar != null)
				{
					sidebar.ArrangeAllSidebarElements();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error occured setting size of the window. err:" + ex.ToString());
			}
		}

		// Token: 0x060012B0 RID: 4784 RVA: 0x00072E68 File Offset: 0x00071068
		private void SetWindowTitle(string vmName)
		{
			base.Title = BlueStacks.Common.Utils.GetDisplayName(vmName);
			this.mTopBar.mTitleText.Text = base.Title;
			bool isCustomUIForNCSoft = FeatureManager.Instance.IsCustomUIForNCSoft;
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				this.mTopBar.mTitleText.Text = GameConfig.Instance.AppName;
				this.mTopBar.mTitleIcon.ImageName = System.IO.Path.Combine(RegistryStrings.InstallDir, "app_icon.ico");
				this.SetTaskbarProperties();
			}
		}

		// Token: 0x060012B1 RID: 4785 RVA: 0x0000D39F File Offset: 0x0000B59F
		internal void ShowRerollOverlay()
		{
			this.ShowDimOverlay(this.MacroOverlayControl);
		}

		// Token: 0x060012B2 RID: 4786 RVA: 0x00072EF0 File Offset: 0x000710F0
		internal void HandleGenericNotificationPopup(GenericNotificationItem notifItem)
		{
			GenericNotificationDesignItem designItem = notifItem.NotificationDesignItem;
			if (!RegistryManager.Instance.IsShowRibbonNotification || RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				return;
			}
			Action <>9__1;
			this.pikaNotificationWorkQueue.Enqueue(delegate
			{
				while (!this.mIsWindowInFocus || this.isPikaPopOpen)
				{
					Thread.Sleep(2000);
				}
				Dispatcher dispatcher = this.Dispatcher;
				Action method;
				if ((method = <>9__1) == null)
				{
					method = (<>9__1 = delegate()
					{
						this.isPikaPopOpen = true;
						this.pikaPopControl.Init(notifItem);
						Canvas.SetLeft(this.pikaPopControl, 0.0);
						this.pikaPop.IsOpen = true;
						new Storyboard();
						this.pikaCanvas.Width = this.pikaPopControl.ActualWidth;
						this.pikaPop.HorizontalOffset = this.pikaPopControl.ActualWidth * -0.5;
						PennerDoubleAnimation.Equations type = PennerDoubleAnimation.Equations.QuadEaseInOut;
						double actualWidth = this.pikaPopControl.ActualWidth;
						double to = 0.0;
						int durationMS = 700;
						Animator.AnimatePenner(this.pikaPopControl, Canvas.LeftProperty, type, new double?(actualWidth), to, durationMS, null);
						string arg = "Home";
						if (this.mTopBar.mAppTabButtons.SelectedTab != null)
						{
							arg = this.mTopBar.mAppTabButtons.SelectedTab.AppLabel;
						}
						ClientStats.SendMiscellaneousStatsAsync("RibbonShown", RegistryManager.Instance.UserGuid, JsonConvert.SerializeObject(notifItem.ExtraPayload), arg, RegistryManager.Instance.ClientVersion, Oem.Instance.OEM, notifItem.Id, notifItem.Title, null);
					});
				}
				dispatcher.Invoke(method, new object[0]);
				this.pikaNotificationTimer.Interval = TimeSpan.FromMilliseconds(designItem.AutoHideTime);
				this.pikaNotificationTimer.Start();
			});
		}

		// Token: 0x060012B3 RID: 4787 RVA: 0x0000D3AD File Offset: 0x0000B5AD
		private void PikaNotificationTimer_Tick(object sender, EventArgs e)
		{
			this.pikaNotificationTimer.Stop();
			if (this.isPikaPopOpen)
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					PennerDoubleAnimation.Equations type = PennerDoubleAnimation.Equations.QuadEaseInOut;
					double value = 0.0;
					double actualWidth = this.pikaPopControl.ActualWidth;
					int durationMS = 400;
					Animator.AnimatePenner(this.pikaPopControl, Canvas.LeftProperty, type, new double?(value), actualWidth, durationMS, delegate(object s, EventArgs ev)
					{
						this.pikaPop.IsOpen = false;
						this.isPikaPopOpen = false;
					});
				}), new object[0]);
			}
		}

		// Token: 0x060012B4 RID: 4788 RVA: 0x00072F54 File Offset: 0x00071154
		internal void ShowDimOverlay(IDimOverlayControl el = null)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					Logger.Debug("showing dim overlay");
					if (this.mDimOverlay == null)
					{
						this.mDimOverlay = new DimOverlayControl(this);
					}
					if (PresentationSource.FromVisual(this) != null)
					{
						this.mDimOverlay.Owner = this;
						this.mDimOverlay.Control = el;
						this.mDimOverlay.UpadteSizeLocation();
						this.mDimOverlay.ShowWindow();
						this.Focus();
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception while showing dimoverlay control. " + ex.ToString());
				}
			}), new object[0]);
		}

		// Token: 0x060012B5 RID: 4789 RVA: 0x0000D3E0 File Offset: 0x0000B5E0
		internal void HideDimOverlay()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					Logger.Debug("Hide dim overlay");
					if (this.mDimOverlay != null)
					{
						if (this.mIsLockScreenActionPending)
						{
							this.ShowDimOverlay(this.ScreenLockInstance);
						}
						else
						{
							this.mDimOverlay.HideWindow(false);
							this.mDimOverlay.Control = null;
						}
					}
				}
				catch (Exception)
				{
				}
				base.Focus();
			}), new object[0]);
		}

		// Token: 0x060012B6 RID: 4790 RVA: 0x00072F94 File Offset: 0x00071194
		private void MainWindow_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			foreach (object obj in base.OwnedWindows)
			{
				Window window = (Window)obj;
				if (window != null)
				{
					try
					{
						CustomWindow customWindow = (CustomWindow)window;
						if (customWindow == null || customWindow.ShowWithParentWindow)
						{
							window.Visibility = base.Visibility;
						}
					}
					catch (Exception ex)
					{
						Logger.Error("Exception in showing child windows: {0}", new object[]
						{
							ex.ToString()
						});
					}
				}
			}
		}

		// Token: 0x060012B7 RID: 4791 RVA: 0x00073038 File Offset: 0x00071238
		private void MainWindow_StateChanged(object sender, EventArgs e)
		{
			if (base.WindowState != WindowState.Minimized)
			{
				if (this.mFrontendGrid.IsVisible)
				{
					this.mFrontendHandler.FocusFrontend(false);
				}
				else
				{
					this.ToggleShootingModeTooltipVisibility(false);
					this.mFrontendHandler.DeactivateFrontend();
				}
				if (this.mTopBar.mAppTabButtons.SelectedTab != null && Constants.ImapShootingModeAppsList.Contains(this.mTopBar.mAppTabButtons.SelectedTab.PackageName))
				{
					this.ToggleShootingModeTooltipVisibility(true);
				}
				else
				{
					this.ToggleShootingModeTooltipVisibility(false);
				}
				this.SendTempGamepadState(true);
			}
			else
			{
				Logger.Debug("KMP MainWindow_StateChanged " + this.mVmName);
				if (BlueStacksUIUtils.ActivatedWindow == this)
				{
					BlueStacksUIUtils.ActivatedWindow = null;
				}
				AppUsageTimer.StopTimer();
				this.ToggleShootingModeTooltipVisibility(false);
				this.mFrontendHandler.DeactivateFrontend();
				this.mCommonHandler.ClipMouseCursorHandler(true, true, "", "");
				this.mIsWindowInFocus = false;
			}
			BlueStacksUIUtils.LastActivatedWindow.mFrontendHandler.UpdateOverlaySizeStatus();
			this.OnResizeMainWindow();
		}

		// Token: 0x060012B8 RID: 4792 RVA: 0x00073138 File Offset: 0x00071338
		internal void SendTempGamepadState(bool enable)
		{
			if (RegistryManager.Instance.GamepadDetectionEnabled)
			{
				if (enable)
				{
					if (!this.IsGamepadConnected)
					{
						if (this.WasGamepadStatusSkipped)
						{
							this.SkipNextGamepadStatus = true;
							this.WasGamepadStatusSkipped = false;
						}
						this.mFrontendHandler.SendFrontendRequestAsync("enableGamepad", new Dictionary<string, string>
						{
							{
								"enable",
								"true"
							}
						});
						return;
					}
				}
				else
				{
					this.SkipNextGamepadStatus = true;
					this.mFrontendHandler.SendFrontendRequestAsync("enableGamepad", new Dictionary<string, string>
					{
						{
							"enable",
							"false"
						}
					});
				}
			}
		}

		// Token: 0x060012B9 RID: 4793 RVA: 0x000731C4 File Offset: 0x000713C4
		private void MainWindow_Deactivated(object sender, EventArgs e)
		{
			Logger.Debug("KMP MainWindow_Deactivated " + this.mVmName);
			if (BlueStacksUIUtils.ActivatedWindow == this)
			{
				BlueStacksUIUtils.ActivatedWindow = null;
			}
			this.ClosePopUps();
			this.mFrontendHandler.DeactivateFrontend();
			this.mCommonHandler.ClipMouseCursorHandler(true, true, "", "");
			this.mIsWindowInFocus = false;
		}

		// Token: 0x060012BA RID: 4794 RVA: 0x00073228 File Offset: 0x00071428
		private void MainWindow_Activated(object sender, EventArgs e)
		{
			BlueStacksUIUtils.LastActivatedWindow = this;
			BlueStacksUIUtils.ActivatedWindow = this;
			App.IsApplicationActive = true;
			this.mIsWindowInFocus = true;
			this.mFrontendHandler.ShowGLWindow();
			if (!string.IsNullOrEmpty(this.mVmName) && this.mTopBar != null && this.mTopBar.mAppTabButtons != null && this.mTopBar.mAppTabButtons.SelectedTab != null && !string.IsNullOrEmpty(this.mTopBar.mAppTabButtons.SelectedTab.TabKey))
			{
				AppUsageTimer.StartTimer(this.mVmName, this.mTopBar.mAppTabButtons.SelectedTab.TabKey);
			}
			if (this.mFrontendGrid.IsVisible)
			{
				Logger.Debug("KMP MainWindow_Activated focusfrontend " + this.mVmName);
				this.mFrontendHandler.FocusFrontend(false);
				if (base.WindowState != WindowState.Minimized && this.mTopBar.mAppTabButtons.SelectedTab != null && Constants.ImapShootingModeAppsList.Contains(this.mTopBar.mAppTabButtons.SelectedTab.PackageName))
				{
					this.ToggleShootingModeTooltipVisibility(true);
				}
				else
				{
					this.ToggleShootingModeTooltipVisibility(false);
				}
			}
			else
			{
				Logger.Debug("KMP MainWindow_Activated DeactivateFrontend " + this.mVmName);
				this.mFrontendHandler.DeactivateFrontend();
			}
			this.SendTempGamepadState(true);
		}

		// Token: 0x060012BB RID: 4795 RVA: 0x0000D400 File Offset: 0x0000B600
		private void MainWindow_SourceInitialized(object sender, EventArgs e)
		{
			this.Handle = ((HwndSource)PresentationSource.FromVisual(this)).Handle;
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				App.FocusMonitor.Init();
			}
		}

		// Token: 0x060012BC RID: 4796 RVA: 0x0000D429 File Offset: 0x0000B629
		internal void MainWindow_ResizeBegin(object sender, EventArgs e)
		{
			this.mIsResizing = true;
		}

		// Token: 0x060012BD RID: 4797 RVA: 0x0000D432 File Offset: 0x0000B632
		private void OnResizeMainWindow()
		{
			Sidebar sidebar = this.mSidebar;
			if (sidebar != null)
			{
				sidebar.SetHeight();
			}
			Action<bool> appRecommendationHandler = PromotionObject.AppRecommendationHandler;
			if (appRecommendationHandler == null)
			{
				return;
			}
			appRecommendationHandler(false);
		}

		// Token: 0x060012BE RID: 4798 RVA: 0x00073370 File Offset: 0x00071570
		internal void MainWindow_ResizeEnd(object sender, EventArgs e)
		{
			this.mIsResizing = false;
			if (base.WindowState == WindowState.Normal)
			{
				try
				{
					this.EngineInstanceRegistry.WindowPlacement = this.GetPlacement();
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in MainWindow_ResizeEnd. Exception: " + ex.ToString());
				}
			}
			this.UIChangesOnMainWindowSizeChanged();
		}

		// Token: 0x060012BF RID: 4799 RVA: 0x0000D455 File Offset: 0x0000B655
		internal void ChangeWindowOrientaion(object sender, ChangeOrientationArgs e)
		{
			this.SwitchToPortraitMode(e.IsPotrait);
		}

		// Token: 0x060012C0 RID: 4800 RVA: 0x000733D0 File Offset: 0x000715D0
		private void SetupInitialSize()
		{
			this.mAspectRatio = new Fraction((long)this.EngineInstanceRegistry.GuestWidth, (long)this.EngineInstanceRegistry.GuestHeight);
			this.mPreviousWidth = new double?(base.Width);
			this.ChangeHeightWidthAndPosition(this.GetWidthFromHeight(this.GetDefaultHeight(), false), this.GetDefaultHeight(), true);
		}

		// Token: 0x060012C1 RID: 4801 RVA: 0x0000D463 File Offset: 0x0000B663
		internal void ChangeOrientationFromClient(bool isPortrait, bool stopFurtherOrientation = true)
		{
			new Thread(delegate()
			{
				if (BlueStacks.Common.Utils.IsGuestBooted(this.mVmName))
				{
					this.SwitchOrientationFromClient(isPortrait, stopFurtherOrientation);
					this.SendOrientationChangeToAndroid(isPortrait);
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060012C2 RID: 4802 RVA: 0x0007342C File Offset: 0x0007162C
		private void SendOrientationChangeToAndroid(bool isPortrait)
		{
			try
			{
				HTTPUtils.SendRequestToGuest("guestorientation", new Dictionary<string, string>
				{
					{
						"d",
						isPortrait ? "1" : "0"
					}
				}, this.mVmName, 0, null, false, 1, 0);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in sending GuestOrientation to android: " + ex.ToString());
			}
		}

		// Token: 0x060012C3 RID: 4803 RVA: 0x0007349C File Offset: 0x0007169C
		private void SwitchOrientationFromClient(bool orientation, bool stopFurtherOrientation)
		{
			try
			{
				string text = orientation ? "1" : "0";
				string text2 = stopFurtherOrientation ? "1" : "0";
				string arg = string.Concat(new string[]
				{
					"orientation=",
					text,
					"&package=",
					this.mTopBar.mAppTabButtons.SelectedTab.PackageName,
					"&stopFurtherOrientationChange=",
					text2
				});
				string arg2 = string.Format("{0}?{1}", "switchOrientation", arg);
				BstHttpClient.Get(string.Format("{0}/{1}", string.Format("{0}:{1}", "http://127.0.0.1", RegistryManager.Instance.Guest[this.mVmName].FrontendServerPort), arg2), null, false, this.mVmName, 0, 1, 0, false);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in sending switch orientation from client: " + ex.ToString());
			}
		}

		// Token: 0x060012C4 RID: 4804 RVA: 0x0000D49B File Offset: 0x0000B69B
		private double GetDefaultHeight()
		{
			return SystemParameters.MaximizedPrimaryScreenHeight * 0.75 + 94.0;
		}

		// Token: 0x060012C5 RID: 4805 RVA: 0x00073598 File Offset: 0x00071798
		internal void HandleDisplaySettingsChanged()
		{
			try
			{
				if (PresentationSource.FromVisual(this) != null)
				{
					MainWindow.sScalingFactor = PresentationSource.FromVisual(this).CompositionTarget.TransformToDevice.M11;
				}
				this.MinWidthScaled = (int)(base.MinWidth * MainWindow.sScalingFactor);
				this.MinHeightScaled = (int)(base.MinHeight * MainWindow.sScalingFactor);
				this.heightDiffScaled = (int)((double)this.mHeightDiff * MainWindow.sScalingFactor);
				this.widthDiffScaled = (int)((double)this.mWidthDiff * MainWindow.sScalingFactor);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in HandleDisplaySettingsChanged. Exception: " + ex.ToString());
			}
		}

		// Token: 0x060012C6 RID: 4806 RVA: 0x00073644 File Offset: 0x00071844
		internal void ShowWindow(bool updateBootStartTime = false)
		{
			if (this.mIsWindowLoadedOnce)
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					if (FeatureManager.Instance.IsCustomUIForDMM)
					{
						KMManager.ShowOverlayWindow(this, false, false);
					}
					if (this.WindowState == WindowState.Minimized)
					{
						InteropWindow.ShowWindow(this.Handle, 9);
					}
					this.Visibility = Visibility.Visible;
					this.Show();
					this.BringIntoView();
					if (FeatureManager.Instance.IsCustomUIForDMM && this.mDMMRecommendedWindow == null)
					{
						this.mDMMRecommendedWindow = new DMMRecommendedWindow(this);
						this.mDMMRecommendedWindow.Init(RegistryManager.Instance.DMMRecommendedWindowUrl);
						this.mDMMRecommendedWindow.Visibility = Visibility.Visible;
					}
					if (!this.Topmost)
					{
						this.Topmost = true;
						this.Topmost = false;
					}
					if (updateBootStartTime)
					{
						this.mBootStartTime = DateTime.Now;
					}
				}), new object[0]);
			}
		}

		// Token: 0x060012C7 RID: 4807 RVA: 0x0007368C File Offset: 0x0007188C
		internal double GetWidthFromHeight(double height, bool isScaled = false)
		{
			if (this.IsUIInPortraitMode)
			{
				if (isScaled)
				{
					try
					{
						return Math.Max((height - (double)this.heightDiffScaled) / this.mAspectRatio.DoubleValue + (double)this.widthDiffScaled, base.MinWidth * MainWindow.sScalingFactor);
					}
					catch
					{
					}
				}
				return Math.Max((height - (double)this.mHeightDiff) / this.mAspectRatio.DoubleValue + (double)this.mWidthDiff, base.MinWidth);
			}
			if (isScaled)
			{
				try
				{
					return Math.Max((height - (double)this.heightDiffScaled) * this.mAspectRatio.DoubleValue + (double)this.widthDiffScaled, base.MinWidth * MainWindow.sScalingFactor);
				}
				catch
				{
				}
			}
			return Math.Max((height - (double)this.mHeightDiff) * this.mAspectRatio.DoubleValue + (double)this.mWidthDiff, base.MinWidth);
		}

		// Token: 0x060012C8 RID: 4808 RVA: 0x00073784 File Offset: 0x00071984
		internal double GetHeightFromWidth(double width, bool isScaled = false)
		{
			if (this.IsUIInPortraitMode)
			{
				if (isScaled)
				{
					try
					{
						return Math.Max((width - (double)this.widthDiffScaled) * this.mAspectRatio.DoubleValue + (double)this.heightDiffScaled, base.MinHeight * MainWindow.sScalingFactor);
					}
					catch
					{
					}
				}
				return Math.Max((width - (double)this.mWidthDiff) * this.mAspectRatio.DoubleValue + (double)this.mHeightDiff, base.MinHeight);
			}
			if (isScaled)
			{
				try
				{
					return Math.Max((width - (double)this.widthDiffScaled) / this.mAspectRatio.DoubleValue + (double)this.heightDiffScaled, base.MinHeight * MainWindow.sScalingFactor);
				}
				catch
				{
				}
			}
			return Math.Max((width - (double)this.mWidthDiff) / this.mAspectRatio.DoubleValue + (double)this.mHeightDiff, base.MinHeight);
		}

		// Token: 0x060012C9 RID: 4809 RVA: 0x0000D4B6 File Offset: 0x0000B6B6
		private void MainWindow_PreviewMouseMove(object sender, System.Windows.Input.MouseEventArgs e)
		{
			if (!this.mIsResizing)
			{
				base.Cursor = System.Windows.Input.Cursors.Arrow;
			}
		}

		// Token: 0x060012CA RID: 4810 RVA: 0x0000D4CB File Offset: 0x0000B6CB
		private void MainWindow_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			DMMRecommendedWindow dmmrecommendedWindow = this.mDMMRecommendedWindow;
			if (dmmrecommendedWindow != null)
			{
				dmmrecommendedWindow.UpdateSize();
			}
			this.OnResizeMainWindow();
		}

		// Token: 0x060012CB RID: 4811 RVA: 0x0000D4E4 File Offset: 0x0000B6E4
		private void MainWindow_LocationChanged(object sender, EventArgs e)
		{
			DMMRecommendedWindow dmmrecommendedWindow = this.mDMMRecommendedWindow;
			if (dmmrecommendedWindow != null)
			{
				dmmrecommendedWindow.UpdateLocation();
			}
			this.OnResizeMainWindow();
		}

		// Token: 0x060012CC RID: 4812 RVA: 0x0007387C File Offset: 0x00071A7C
		internal void RestartInstanceAndPerform(EventHandler action = null)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (action != null)
				{
					this.mFrontendHandler.mEventOnFrontendClosed -= action;
					this.mFrontendHandler.mEventOnFrontendClosed += action;
				}
				this.mFrontendHandler.mEventOnFrontendClosed -= this.FrontendHandler_RunInstance;
				this.mFrontendHandler.mEventOnFrontendClosed += this.FrontendHandler_RunInstance;
				this.CloseCurrentInstanceForRestart();
			}), new object[0]);
		}

		// Token: 0x060012CD RID: 4813 RVA: 0x000738BC File Offset: 0x00071ABC
		internal void CloseInstanceAndPerform(EventHandler action = null)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (action != null)
				{
					this.mEventOnInstanceClosed -= action;
					this.mEventOnInstanceClosed += action;
				}
				this.ForceCloseWindow();
			}), new object[0]);
		}

		// Token: 0x060012CE RID: 4814 RVA: 0x000738FC File Offset: 0x00071AFC
		internal void CloseAllWindowAndPerform(EventHandler action = null)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (action != null)
				{
					this.mEventOnAllWindowClosed -= action;
					this.mEventOnAllWindowClosed += action;
				}
				this.ForceCloseWindow();
			}), new object[0]);
		}

		// Token: 0x060012CF RID: 4815 RVA: 0x0000D4FD File Offset: 0x0000B6FD
		internal void FrontendHandler_RunInstance(object sender, EventArgs e)
		{
			this.CloseMainWindow();
			BlueStacksUIUtils.RunInstance(this.mVmName, false);
		}

		// Token: 0x060012D0 RID: 4816 RVA: 0x0007393C File Offset: 0x00071B3C
		internal void CloseMainWindow()
		{
			try
			{
				HTTPUtils.SendRequestToAgent("instanceStopped", null, this.mVmName, 0, null, false, 1, 0);
			}
			catch
			{
			}
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mClosing = true;
				base.Close();
			}), new object[0]);
		}

		// Token: 0x060012D1 RID: 4817 RVA: 0x0000D511 File Offset: 0x0000B711
		internal void CloseCurrentInstanceForRestart()
		{
			this.mIsRestart = true;
			Opt.Instance.Json = "";
			this.ForceCloseWindow();
		}

		// Token: 0x060012D2 RID: 4818 RVA: 0x00073994 File Offset: 0x00071B94
		internal void ForceCloseWindow()
		{
			try
			{
				this.CloseWindowHandler();
			}
			catch (Exception ex)
			{
				Logger.Error("Error occured in ForceClose" + ex.ToString());
			}
		}

		// Token: 0x060012D3 RID: 4819 RVA: 0x000739D4 File Offset: 0x00071BD4
		internal void CloseWindow()
		{
			if (this.mClosed)
			{
				return;
			}
			if (Oem.Instance.IsRemoveAccountOnExit)
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.AddButton(ButtonColors.Red, "STRING_YES", this.CloseWindowConfirmationResetAccountAcceptedHandler, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, "STRING_NO", this.CloseWindowConfirmationAcceptedHandler, null, false, null);
				BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_EXIT_BLUESTACKS3", "");
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_REMOVE_ACCOUNT_ON_EXIT", "");
				this.ShowDimOverlay(null);
				customMessageWindow.Owner = this.mDimOverlay;
				customMessageWindow.ShowDialog();
				this.HideDimOverlay();
				return;
			}
			BlueStacks.BlueStacksUI.ProgressBar el = new BlueStacks.BlueStacksUI.ProgressBar
			{
				ProgressText = "STRING_LOADING_MESSAGE",
				Visibility = Visibility.Hidden
			};
			this.ShowDimOverlay(el);
			new Thread(delegate()
			{
				if (FeatureManager.Instance.IsCheckForQuitPopup)
				{
					if (this.Utils.CheckQuitPopupFromCloud("app_tab_closed", ""))
					{
						return;
					}
					if (this.Utils.CheckQuitPopupLocal())
					{
						return;
					}
				}
				base.Dispatcher.Invoke(new Action(delegate()
				{
					this.HideDimOverlay();
					if (!FeatureManager.Instance.IsCustomUIForNCSoft)
					{
						CustomMessageWindow customMessageWindow2 = new CustomMessageWindow();
						customMessageWindow2.AddButton(ButtonColors.Red, "STRING_YES", this.CloseWindowConfirmationAcceptedHandler, null, false, null);
						customMessageWindow2.AddButton(ButtonColors.White, "STRING_NO", new EventHandler(this.CloseWindowConfirmationDeniedHandler), null, false, null);
						if ((from _ in BlueStacksUIUtils.DictWindows
						where !_.Value.mClosed
						select _).Count<KeyValuePair<string, MainWindow>>() == 1)
						{
							BlueStacksUIBinding.Bind(customMessageWindow2.BodyTextBlock, "STRING_EXIT_BLUESTACKS", "");
							BlueStacksUIBinding.Bind(customMessageWindow2.TitleTextBlock, "STRING_CLOSE_BLUESTACKS", "");
							if (FeatureManager.Instance.IsCustomUIForDMM)
							{
								customMessageWindow2.ContentMaxWidth = 400.0;
							}
						}
						else
						{
							BlueStacksUIBinding.Bind(customMessageWindow2.BodyTextBlock, "STRING_EXIT_INSTANCE", "");
							BlueStacksUIBinding.Bind(customMessageWindow2.TitleTextBlock, "STRING_INSTANCE_CLOSE_TITLE", "");
							if (FeatureManager.Instance.IsCustomUIForDMM)
							{
								customMessageWindow2.ContentMaxWidth = 400.0;
							}
						}
						this.ShowDimOverlay(null);
						customMessageWindow2.Owner = this.mDimOverlay;
						customMessageWindow2.ShowDialog();
						if (this.mDimOverlay != null && this.mDimOverlay.OwnedWindows.OfType<ContainerWindow>().Count<ContainerWindow>() == 0)
						{
							this.HideDimOverlay();
						}
						return;
					}
					if (RegistryManager.Instance.IsQuitOptionSaved)
					{
						this.BlueStacksAdvancedExitAcceptedHandler(null, null);
						return;
					}
					BlueStacksAdvancedExit blueStacksAdvancedExit = new BlueStacksAdvancedExit(this);
					blueStacksAdvancedExit.YesButton.PreviewMouseLeftButtonUp += this.BlueStacksAdvancedExitAcceptedHandler;
					blueStacksAdvancedExit.NoButton.PreviewMouseLeftButtonUp += this.BlueStacksAdvancedExitDeclinedHandler;
					blueStacksAdvancedExit.CrossButton.PreviewMouseLeftButtonUp += this.BlueStacksAdvancedExitDeclinedHandler;
					new ContainerWindow(this, blueStacksAdvancedExit, 440.0, 400.0, false, true);
				}), new object[0]);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060012D4 RID: 4820 RVA: 0x00073AAC File Offset: 0x00071CAC
		private void BlueStacksAdvancedExitAcceptedHandler(object sender, MouseButtonEventArgs e)
		{
			string quitDefaultOption = RegistryManager.Instance.QuitDefaultOption;
			if (!(quitDefaultOption == "STRING_CLOSE_CURRENT_INSTANCE"))
			{
				if (quitDefaultOption == "STRING_CLOSE_ALL_RUNNING_INSTANCES")
				{
					BlueStacks.Common.Utils.StopClientInstanceAsync("");
					return;
				}
				if (quitDefaultOption == "STRING_RESTART_CURRENT_INSTANCE")
				{
					BlueStacksUIUtils.RestartInstance(this.mVmName);
					return;
				}
			}
			this.CloseWindowHandler();
		}

		// Token: 0x060012D5 RID: 4821 RVA: 0x0000D52F File Offset: 0x0000B72F
		private void BlueStacksAdvancedExitDeclinedHandler(object sender, MouseButtonEventArgs e)
		{
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition && this.mGuestBootCompleted)
			{
				this.mTopBar.mAppTabButtons.AddHiddenAppTabAndLaunch(GameConfig.Instance.PkgName, GameConfig.Instance.ActivityName);
			}
		}

		// Token: 0x060012D6 RID: 4822 RVA: 0x0000D52F File Offset: 0x0000B72F
		private void CloseWindowConfirmationDeniedHandler(object sender, EventArgs e)
		{
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition && this.mGuestBootCompleted)
			{
				this.mTopBar.mAppTabButtons.AddHiddenAppTabAndLaunch(GameConfig.Instance.PkgName, GameConfig.Instance.ActivityName);
			}
		}

		// Token: 0x060012D7 RID: 4823 RVA: 0x0000D56A File Offset: 0x0000B76A
		internal void MainWindow_CloseWindowConfirmationAcceptedHandler(object sender, EventArgs e)
		{
			this.CloseWindowHandler();
		}

		// Token: 0x060012D8 RID: 4824 RVA: 0x00073B08 File Offset: 0x00071D08
		private void MainWindow_CloseWindowConfirmationResetAccountAcceptedHandler(object sender, EventArgs e)
		{
			if (base.Visibility == Visibility.Visible)
			{
				this.mFrontendGrid.Visibility = Visibility.Hidden;
				if (this.mIsRestart)
				{
					this.mExitProgressGrid.ProgressText = "STRING_RESTARTING";
				}
				else
				{
					this.mExitProgressGrid.ProgressText = "STRING_CLOSING_BLUESTACKS";
				}
				this.mExitProgressGrid.Visibility = Visibility.Visible;
			}
			this.mAppHandler.SendRequestToRemoveAccountAndCloseWindowASync(true);
		}

		// Token: 0x060012D9 RID: 4825 RVA: 0x0000D572 File Offset: 0x0000B772
		internal void ShowDimOverlayForUpgrade()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.CloseChildOwnedWindows();
				this.GotoHomeTab();
				this.mWelcomeTab.mFrontendPopupControl.HideWindow();
				this.mExitProgressGrid.ProgressText = "STRING_UPGRADING_TEXT";
				this.mExitProgressGrid.Visibility = Visibility.Visible;
				this.HideDimOverlay();
			}), new object[0]);
		}

		// Token: 0x060012DA RID: 4826 RVA: 0x00073B6C File Offset: 0x00071D6C
		private void CloseChildOwnedWindows()
		{
			foreach (object obj in base.OwnedWindows)
			{
				Window window = (Window)obj;
				if (window != null)
				{
					foreach (object obj2 in window.OwnedWindows)
					{
						Window window2 = (Window)obj2;
						if (window2 != null)
						{
							window2.Close();
						}
					}
					window.Close();
				}
			}
			if (StreamWindow.Instance != null && Strings.CurrentDefaultVmName.Equals(this.mVmName))
			{
				StreamWindow.Instance.Close();
			}
		}

		// Token: 0x060012DB RID: 4827 RVA: 0x00073C3C File Offset: 0x00071E3C
		private void GotoHomeTab()
		{
			if (!FeatureManager.Instance.IsCustomUIForDMM && !this.mTopBar.mAppTabButtons.GoToTab("Home", true, false))
			{
				this.mTopBar.mAppTabButtons.AddHomeTab();
				this.mTopBar.mAppTabButtons.CloseTab("Setup", false, true, false, false, "");
			}
		}

		// Token: 0x060012DC RID: 4828 RVA: 0x0000D592 File Offset: 0x0000B792
		private void CloseWindowHandler()
		{
			if (this.mClosed)
			{
				return;
			}
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					if (!this.mClosed)
					{
						this.CloseChildOwnedWindows();
						if (CommonHandlers.sIsRecordingVideo && CommonHandlers.sRecordingInstance.Equals(this.mVmName))
						{
							this.mCommonHandler.StopRecordVideo();
						}
						this.GotoHomeTab();
						if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
						{
							this.mWelcomeTab.mBackground.Visibility = Visibility.Visible;
						}
						this.mWelcomeTab.mFrontendPopupControl.HideWindow();
						if (this.mIsRestart)
						{
							this.mExitProgressGrid.ProgressText = "STRING_RESTARTING";
						}
						else
						{
							this.mExitProgressGrid.ProgressText = "STRING_CLOSING_BLUESTACKS";
						}
						this.mExitProgressGrid.Visibility = Visibility.Visible;
						this.HideDimOverlay();
						this.mClosed = true;
						if (!this.mIsRestart)
						{
							this.mFrontendHandler.mEventOnFrontendClosed -= this.FrontendHandler_CloseMainWindow;
							this.mFrontendHandler.mEventOnFrontendClosed += this.FrontendHandler_CloseMainWindow;
						}
						this.mFrontendHandler.KillFrontendAsync();
						if (this.mDiscordhandler != null)
						{
							this.mDiscordhandler.Dispose();
							this.mDiscordhandler = null;
						}
						if (SecurityMetrics.SecurityMetricsInstanceList.ContainsKey(this.mVmName))
						{
							SecurityMetrics.SecurityMetricsInstanceList[this.mVmName].SendSecurityBreachesStatsToCloud(true);
						}
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Error occured in CloseWindowHandler " + ex.ToString());
				}
			}), new object[0]);
		}

		// Token: 0x060012DD RID: 4829 RVA: 0x0000D5BB File Offset: 0x0000B7BB
		private void FrontendHandler_CloseMainWindow(object sender, EventArgs e)
		{
			this.CloseMainWindow();
		}

		// Token: 0x060012DE RID: 4830 RVA: 0x00073C9C File Offset: 0x00071E9C
		private void UpdateSynchronizerInstancesList()
		{
			try
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
					{
						if (keyValuePair.Value.mSynchronizerWindow != null && keyValuePair.Value.mSynchronizerWindow.IsVisible)
						{
							keyValuePair.Value.mSynchronizerWindow.Init();
						}
					}
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in updating instances for sync operation: " + ex.ToString());
			}
		}

		// Token: 0x060012DF RID: 4831 RVA: 0x00073D04 File Offset: 0x00071F04
		private void MainWindow_Closing(object sender, CancelEventArgs e)
		{
			if (this.mClosing)
			{
				this.mClosing = false;
				if (base.WindowState == WindowState.Normal)
				{
					try
					{
						this.EngineInstanceRegistry.WindowPlacement = this.GetPlacement();
					}
					catch (Exception arg)
					{
						Logger.Error("Exception in MainWindow_Closing. Exception: " + arg);
					}
				}
				BrowserControl sideHtmlBrowser = BlueStacksUIUtils.DictWindows[this.mVmName].mWelcomeTab.mHomeApp.SideHtmlBrowser;
				if (sideHtmlBrowser != null)
				{
					sideHtmlBrowser.DisposeBrowser();
				}
				BlueStacksUIUtils.DictWindows.Remove(this.mVmName);
				this.UpdateSynchronizationState();
				this.UpdateSynchronizerInstancesList();
				if (this.mVmName == "Android")
				{
					BlueStacksUpdater.DownloadCompleted -= this.BlueStacksUpdater_DownloadCompleted;
				}
				EventHandler eventHandler = this.mEventOnInstanceClosed;
				if (eventHandler != null)
				{
					eventHandler(this.mVmName, null);
				}
				this.ReleaseClientGlobalLock();
				if (BlueStacksUIUtils.DictWindows.Count == 0 && !this.mIsRestart)
				{
					AppUsageTimer.SaveData();
					GlobalKeyBoardMouseHooks.UnHookGlobalHooks();
					App.UnwindEvents();
					App.ReleaseLock();
					EventHandler eventHandler2 = this.mEventOnAllWindowClosed;
					if (eventHandler2 != null)
					{
						eventHandler2(this.mVmName, null);
					}
					if (HttpHandlerSetup.Server != null)
					{
						HttpHandlerSetup.Server.Stop();
					}
					BlueStacksUIUtils.sStopStatSendingThread = true;
					BlueStacks.Common.Utils.RunHDQuit(false, true);
					System.Windows.Application.Current.Shutdown();
				}
				this.mIsRestart = false;
				return;
			}
			e.Cancel = true;
			this.CloseWindow();
		}

		// Token: 0x060012E0 RID: 4832 RVA: 0x00073E68 File Offset: 0x00072068
		private void MainWindow_Loaded(object sender, RoutedEventArgs e)
		{
			this.HandleDisplaySettingsChanged();
			if (this.EngineInstanceRegistry.WindowPlacement == "")
			{
				base.Left = (SystemParameters.MaximizedPrimaryScreenWidth - base.Width) / 2.0;
				base.Top = (SystemParameters.MaximizedPrimaryScreenHeight - base.Height) / 2.0;
			}
			else
			{
				this.SetPlacement(this.EngineInstanceRegistry.WindowPlacement);
			}
			bool flag = false;
			IntereopRect fullscreenMonitorSize = WindowWndProcHandler.GetFullscreenMonitorSize(this.Handle, true);
			if (base.Left + (base.Width + 62.0) * MainWindow.sScalingFactor > (double)fullscreenMonitorSize.Width)
			{
				base.Left = (double)(fullscreenMonitorSize.X + fullscreenMonitorSize.Width) - (base.Width + 62.0) * MainWindow.sScalingFactor;
				if (base.Left < 0.0)
				{
					base.Left = 0.0;
				}
				flag = true;
			}
			if (base.Top + base.Height * MainWindow.sScalingFactor > (double)fullscreenMonitorSize.Height)
			{
				base.Top = (double)(fullscreenMonitorSize.Y + fullscreenMonitorSize.Height) - base.Height * MainWindow.sScalingFactor;
				if (base.Top < 0.0)
				{
					base.Top = 0.0;
				}
				flag = true;
			}
			if (flag)
			{
				this.ChangeHeightWidthTopLeft(base.Width * MainWindow.sScalingFactor, base.Height * MainWindow.sScalingFactor, base.Top, base.Left);
			}
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				double num = FeatureManager.Instance.IsCustomUIForDMM ? ((base.Height - (double)this.mHeightDiff) * 9.0 / 16.0 + (double)this.mWidthDiff) : 0.0;
				base.Left = (SystemParameters.MaximizedPrimaryScreenWidth - base.Width - num) / 2.0;
			}
			this.mTopBar.mPreferenceDropDownControl.Init(this);
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.mNCTopBar.mSettingsDropDownControl.Init(this);
			}
			this.mFullScreenTopBar.Init(this);
			this.CloseWindowConfirmationAcceptedHandler += this.MainWindow_CloseWindowConfirmationAcceptedHandler;
			this.CloseWindowConfirmationResetAccountAcceptedHandler += this.MainWindow_CloseWindowConfirmationResetAccountAcceptedHandler;
			this.RestartEngineConfirmationAcceptedHandler += this.MainWindow_RestartEngineConfirmationAcceptedHandler;
			this.RestartPcConfirmationAcceptedHandler += this.MainWindow_RestartPcConfirmationHandler;
			GlobalKeyBoardMouseHooks.SetBossKeyHook();
			this.mTopBar.ChangeUserPremiumButton(RegistryManager.Instance.IsPremium);
			if (this.IsDefaultVM)
			{
				this.pikaNotificationTimer.Interval = TimeSpan.FromMilliseconds(3500.0);
				this.pikaNotificationTimer.Tick += this.PikaNotificationTimer_Tick;
				this.pikaPopControl.ParentWindow = this;
				this.pikaNotificationWorkQueue.Start();
			}
			this.ClientLaunchedStats();
			this.toastTimer.Interval = TimeSpan.FromMilliseconds(3000.0);
			this.toastTimer.Tick += this.ToastTimer_Tick;
			this.mFullScreenToastTimer.Interval = TimeSpan.FromMilliseconds(5000.0);
			this.mFullScreenToastTimer.Tick += this.FullScreenToastTimer_Tick;
			if (!this.mFrontendHandler.mIsSufficientRAMAvailable)
			{
				this.mFrontendHandler.FrontendHandler_ShowLowRAMMessage();
			}
			this.FullScreenChangedEvent += this.ToastVisibility_FullScreenChangedEvent;
		}

		// Token: 0x060012E1 RID: 4833 RVA: 0x000741D8 File Offset: 0x000723D8
		private void ToastVisibility_FullScreenChangedEvent(bool isFullScreen)
		{
			if (isFullScreen)
			{
				string text = string.Format(LocaleStrings.GetLocalizedString("STRING_FULLSCREEN_EXIT_POPUP_TEXT", false), this.mCommonHandler.GetShortcutKeyFromName("STRING_UPDATED_FULLSCREEN_BUTTON_TOOLTIP", false));
				this.ShowToast(text);
				return;
			}
			this.CloseFullScreenToastAndStopTimer();
		}

		// Token: 0x060012E2 RID: 4834 RVA: 0x00074218 File Offset: 0x00072418
		private void ClientLaunchedStats()
		{
			if (RegistryManager.Instance.IsClientUpgraded && RegistryManager.Instance.IsClientFirstLaunch == 1)
			{
				ClientStats.SendClientStatsAsync("update_init", "success", "emulator_activity", "", "", this.mVmName);
				return;
			}
			if (RegistryManager.Instance.IsClientFirstLaunch == 1)
			{
				ClientStats.SendClientStatsAsync("first_init", "success", "emulator_activity", "", "", this.mVmName);
				return;
			}
			ClientStats.SendClientStatsAsync("init", "success", "emulator_activity", "", "", this.mVmName);
		}

		// Token: 0x060012E3 RID: 4835 RVA: 0x000742BC File Offset: 0x000724BC
		internal void CreateFirebaseBrowserControl()
		{
			string urlWithParams = WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/page/notification");
			this.mFirebaseBrowserControlGrid = this.AddBrowser(urlWithParams);
			(this.mFirebaseBrowserControlGrid.Children[0] as BrowserControl).CreateNewBrowser();
		}

		// Token: 0x060012E4 RID: 4836 RVA: 0x00074308 File Offset: 0x00072508
		private void MainWindow_ContentRendered(object sender, EventArgs e)
		{
			if (!this.isSetupDone)
			{
				this.isSetupDone = true;
				if (!FeatureManager.Instance.IsCustomUIForDMM && this.mVmName == Strings.CurrentDefaultVmName)
				{
					BlueStacksUpdater.DownloadCompleted += this.BlueStacksUpdater_DownloadCompleted;
					BlueStacksUpdater.SetupBlueStacksUpdater(this, true);
				}
				base.ContentRendered -= this.MainWindow_ContentRendered;
			}
		}

		// Token: 0x060012E5 RID: 4837 RVA: 0x0000D5C3 File Offset: 0x0000B7C3
		private void BlueStacksUpdater_DownloadCompleted(Tuple<BlueStacksUpdateData, bool> result)
		{
			if (result.Item1.IsUpdateAvailble && result.Item1.IsFullInstaller)
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					this.ShowInstallPopup();
				}), new object[0]);
			}
		}

		// Token: 0x060012E6 RID: 4838 RVA: 0x0007436C File Offset: 0x0007256C
		public void ShowInstallPopup()
		{
			this.ShowDimOverlay(null);
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.AddButton(ButtonColors.Blue, "STRING_INSTALL_NOW", delegate(object s, EventArgs ev)
			{
				ClientStats.SendBluestacksUpdaterUIStatsAsync(ClientStatsEvent.InstallPopupNow, "");
				BlueStacksUpdater.CheckDownloadedUpdateFileAndUpdate();
			}, null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_INSTALL_NEXT_BOOT", delegate(object s, EventArgs ev)
			{
				ClientStats.SendBluestacksUpdaterUIStatsAsync(ClientStatsEvent.InstallPopupLater, "");
			}, null, false, null);
			BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_BLUESTACKS_UPDATE_AVAILABLE", "");
			customMessageWindow.ImageName = "update_icon";
			BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_NEW_UPDATE_READY", "");
			customMessageWindow.BodyWarningTextBlock.Visibility = Visibility.Visible;
			BlueStacksUIBinding.Bind(customMessageWindow.BodyWarningTextBlock, "STRING_NEW_UPDATE_READY_WARNING", "");
			customMessageWindow.BodyWarningTextBlock.Foreground = new SolidColorBrush((System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#F09200"));
			customMessageWindow.CloseButtonHandle(delegate(object s, EventArgs ev)
			{
				ClientStats.SendBluestacksUpdaterUIStatsAsync(ClientStatsEvent.InstallPopupCross, "");
			}, null);
			customMessageWindow.Owner = this.mDimOverlay;
			customMessageWindow.ShowDialog();
			this.HideDimOverlay();
		}

		// Token: 0x060012E7 RID: 4839 RVA: 0x0000D5FD File Offset: 0x0000B7FD
		private void MainWindow_PreviewKeyUp(object sender, System.Windows.Input.KeyEventArgs e)
		{
			if (e.Key == Key.Snapshot)
			{
				this.HandleKeyDown(e.Key);
			}
			if (e.SystemKey == Key.Snapshot)
			{
				this.HandleKeyDown(e.SystemKey);
			}
		}

		// Token: 0x060012E8 RID: 4840 RVA: 0x0000D62B File Offset: 0x0000B82B
		private void MainWindow_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			if (e.Key == Key.System)
			{
				this.HandleKeyDown(e.SystemKey);
				return;
			}
			this.HandleKeyDown(e.Key);
		}

		// Token: 0x060012E9 RID: 4841 RVA: 0x00074494 File Offset: 0x00072694
		internal void HandleKeyDown(Key key)
		{
			string text = string.Empty;
			if (key != Key.None)
			{
				if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
				{
					text = IMAPKeys.GetStringForFile(Key.LeftCtrl) + " + ";
				}
				if (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt))
				{
					text = text + IMAPKeys.GetStringForFile(Key.LeftAlt) + " + ";
				}
				if (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift))
				{
					text = text + IMAPKeys.GetStringForFile(Key.LeftShift) + " + ";
				}
				text += IMAPKeys.GetStringForFile(key);
			}
			Logger.Debug("SHORTCUT: KeyPressed.." + text);
			if (this.mCommonHandler.mShortcutsConfigInstance != null)
			{
				foreach (ShortcutKeys shortcutKeys in this.mCommonHandler.mShortcutsConfigInstance.Shortcut)
				{
					if (shortcutKeys.ShortcutKey.Equals(text))
					{
						ClientHotKeys clienthotKey = (ClientHotKeys)Enum.Parse(typeof(ClientHotKeys), shortcutKeys.ShortcutName);
						this.HandleClientHotKey(clienthotKey);
						Logger.Debug("SHORTCUT: Shortcut Name.." + shortcutKeys.ShortcutName);
					}
				}
			}
		}

		// Token: 0x060012EA RID: 4842 RVA: 0x000745D0 File Offset: 0x000727D0
		internal void HandleClientHotKey(ClientHotKeys clienthotKey)
		{
			try
			{
				switch (clienthotKey)
				{
				case ClientHotKeys.STRING_TOGGLE_KEYMAP_WINDOW:
					ThreadPool.QueueUserWorkItem(delegate(object obj)
					{
						try
						{
							base.Dispatcher.Invoke(new Action(delegate()
							{
								if (this.mTopBar.mAppTabButtons.SelectedTab.mTabType == TabType.AppTab)
								{
									this.mCommonHandler.KeyMapButtonHandler("shortcut", "sidebar");
								}
							}), new object[0]);
						}
						catch
						{
						}
					});
					goto IL_BEF;
				case ClientHotKeys.STRING_TOGGLE_FARM_MODE:
					if (!FeatureManager.Instance.IsFarmingModeDisabled)
					{
						CommonHandlers.ToggleFarmMode();
						ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "FarmMode", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
						goto IL_BEF;
					}
					goto IL_BEF;
				case ClientHotKeys.AddWebTab:
					if (!FeatureManager.Instance.IsCustomUIForDMM)
					{
						ThreadPool.QueueUserWorkItem(delegate(object obj)
						{
							try
							{
								base.Dispatcher.Invoke(new Action(delegate()
								{
									this.mTopBar.mAppTabButtons.AddWebTab("https://www.google.com/", "Google", string.Empty, true, DateTime.Now.ToString(), true);
								}), new object[0]);
							}
							catch (Exception ex3)
							{
								Logger.Error("Exception while ading web tab using key shortcut:{0}", new object[]
								{
									ex3
								});
							}
						});
						goto IL_BEF;
					}
					goto IL_BEF;
				case ClientHotKeys.STRING_TOGGLE_OVERLAY:
					ThreadPool.QueueUserWorkItem(delegate(object obj)
					{
						base.Dispatcher.Invoke(new Action(delegate()
						{
							if (FeatureManager.Instance.IsCustomUIForDMM)
							{
								this.mDmmBottomBar.mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp(null, null);
								return;
							}
							if (KMManager.dictOverlayWindow.ContainsKey(this))
							{
								ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "Overlay", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, "toggleOff", null);
								KMManager.ShowOverlayWindow(this, false, false);
								this.mCommonHandler.OnOverlayStateChanged(false);
								return;
							}
							if (!KMManager.CheckIfKeymappingWindowVisible() && this.mTopBar.mAppTabButtons.SelectedTab.mTabType == TabType.AppTab)
							{
								ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "Overlay", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, "toggleOn", null);
								this.mCommonHandler.OnOverlayStateChanged(true);
								KMManager.ShowOverlayWindow(this, true, false);
							}
						}), new object[0]);
					});
					goto IL_BEF;
				case ClientHotKeys.STRING_UPDATED_FULLSCREEN_BUTTON_TOOLTIP:
					ThreadPool.QueueUserWorkItem(delegate(object obj)
					{
						base.Dispatcher.Invoke(new Action(delegate()
						{
							if (this.mCommonHandler != null && !this.mStreamingModeEnabled)
							{
								this.mCommonHandler.FullScreenButtonHandler("sidebar", "shortcut");
							}
						}), new object[0]);
					});
					goto IL_BEF;
				case ClientHotKeys.STRING_TOGGLE_LOCK_CURSOR:
					if (!FeatureManager.Instance.IsCustomUIForDMM)
					{
						ThreadPool.QueueUserWorkItem(delegate(object obj)
						{
							base.Dispatcher.Invoke(new Action(delegate()
							{
								if (this.mCommonHandler != null && !this.mIsFullScreen)
								{
									this.mCommonHandler.ClipMouseCursorHandler(false, true, "shortcut", "sidebar");
								}
							}), new object[0]);
						});
						goto IL_BEF;
					}
					goto IL_BEF;
				case ClientHotKeys.RestoreWindow:
					if (this.mIsFullScreen && RegistryManager.Instance.UseEscapeToExitFullScreen)
					{
						ThreadPool.QueueUserWorkItem(delegate(object obj)
						{
							base.Dispatcher.Invoke(new Action(delegate()
							{
								this.RestoreWindows();
							}), new object[0]);
						});
						goto IL_BEF;
					}
					goto IL_BEF;
				case ClientHotKeys.STRING_TOGGLE_KEYMAPPING_STATE:
					if (this.mTopBar.mAppTabButtons.SelectedTab != null && this.mTopBar.mAppTabButtons.SelectedTab.mTabType == TabType.AppTab)
					{
						ThreadPool.QueueUserWorkItem(delegate(object obj)
						{
							base.Dispatcher.Invoke(new Action(delegate()
							{
								if (FeatureManager.Instance.IsCustomUIForDMM)
								{
									this.mCommonHandler.DMMSwitchKeyMapButtonHandler();
									return;
								}
								this.mSidebar.KeyMapSwitchButtonHandler(null);
							}), new object[0]);
						});
						goto IL_BEF;
					}
					goto IL_BEF;
				case ClientHotKeys.STRING_TRANSLATOR_TOOL:
					if (!FeatureManager.Instance.IsCustomUIForDMM)
					{
						ThreadPool.QueueUserWorkItem(delegate(object obj)
						{
							base.Dispatcher.Invoke(new Action(delegate()
							{
								try
								{
									this.mCommonHandler.ImageTranslationHandler();
									ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "translatorTool", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
								}
								catch (Exception ex3)
								{
									Logger.Error("error while calling image translation function.." + ex3.ToString());
								}
							}), new object[0]);
						});
						goto IL_BEF;
					}
					goto IL_BEF;
				case ClientHotKeys.STRING_ALWAYS_ON_TOP:
					this.EngineInstanceRegistry.IsClientOnTop = !this.EngineInstanceRegistry.IsClientOnTop;
					base.Topmost = this.EngineInstanceRegistry.IsClientOnTop;
					ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, this.EngineInstanceRegistry.IsClientOnTop ? "PinToTopOn" : "PinToTopOff", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
					goto IL_BEF;
				case ClientHotKeys.STRING_INCREASE_VOLUME:
					if (this.mSidebar != null && this.mSidebar.GetElementFromTag("sidebar_volume") != null && this.mSidebar.GetElementFromTag("sidebar_volume").Visibility == Visibility.Visible && this.mSidebar.GetElementFromTag("sidebar_volume").IsEnabled)
					{
						if (this.mSidebar.mVolumeSliderPopupTimer == null)
						{
							this.mSidebar.mVolumeSliderPopupTimer = new DispatcherTimer();
							this.mSidebar.mVolumeSliderPopupTimer.Interval = new TimeSpan(0, 0, 2);
							this.mSidebar.mVolumeSliderPopupTimer.Tick += this.mSidebar.VolumeSliderPopupTimer_Tick;
						}
						else
						{
							this.mSidebar.mVolumeSliderPopupTimer.Stop();
						}
						this.mSidebar.mVolumeSliderPopupTimer.Start();
						this.mSidebar.mVolumeSliderPopup.IsOpen = true;
						this.Utils.VolumeUpHandler();
						ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "VolumeUp", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
						goto IL_BEF;
					}
					goto IL_BEF;
				case ClientHotKeys.STRING_DECREASE_VOLUME:
					if (this.mSidebar != null && this.mSidebar.GetElementFromTag("sidebar_volume") != null && this.mSidebar.GetElementFromTag("sidebar_volume").Visibility == Visibility.Visible && this.mSidebar.GetElementFromTag("sidebar_volume").IsEnabled)
					{
						if (this.mSidebar.mVolumeSliderPopupTimer == null)
						{
							this.mSidebar.mVolumeSliderPopupTimer = new DispatcherTimer();
							this.mSidebar.mVolumeSliderPopupTimer.Interval = new TimeSpan(0, 0, 2);
							this.mSidebar.mVolumeSliderPopupTimer.Tick += this.mSidebar.VolumeSliderPopupTimer_Tick;
						}
						else
						{
							this.mSidebar.mVolumeSliderPopupTimer.Stop();
						}
						this.mSidebar.mVolumeSliderPopupTimer.Start();
						this.mSidebar.mVolumeSliderPopup.IsOpen = true;
						this.Utils.VolumeDownHandler();
						ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "VolumeDown", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
						goto IL_BEF;
					}
					goto IL_BEF;
				case ClientHotKeys.STRING_TOGGLE_MUTE_STATE:
					if (this.mSidebar != null)
					{
						this.mCommonHandler.MuteUnmuteButtonHanlder();
						ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, this.EngineInstanceRegistry.IsMuted ? "VolumeMute" : "VolumeUnmute", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
						goto IL_BEF;
					}
					goto IL_BEF;
				case ClientHotKeys.STRING_TOOLBAR_CAMERA:
					if (this.mSidebar != null && this.mSidebar.GetElementFromTag("sidebar_screenshot") != null && this.mSidebar.GetElementFromTag("sidebar_screenshot").Visibility == Visibility.Visible && this.mSidebar.GetElementFromTag("sidebar_screenshot").IsEnabled)
					{
						this.mCommonHandler.ScreenShotButtonHandler();
						ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "Screenshot", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
						goto IL_BEF;
					}
					goto IL_BEF;
				case ClientHotKeys.STRING_MACRO_RECORDER:
					if (this.mSidebar != null && this.mSidebar.GetElementFromTag("sidebar_macro") != null && this.mSidebar.GetElementFromTag("sidebar_macro").Visibility == Visibility.Visible && this.mSidebar.GetElementFromTag("sidebar_macro").IsEnabled && (FeatureManager.Instance.IsMacroRecorderEnabled || FeatureManager.Instance.IsCustomUIForNCSoft))
					{
						if (this.mIsOperationRecorderActive)
						{
							this.ShowToast(LocaleStrings.GetLocalizedString("STRING_STOP_RECORDING_FIRST", false));
						}
						else
						{
							this.mCommonHandler.OpenOperationRecorderWindow();
						}
						ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "MacroRecorder", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
						goto IL_BEF;
					}
					goto IL_BEF;
				case ClientHotKeys.STRING_SYNCHRONISER:
					if (FeatureManager.Instance.IsOperationsSyncEnabled)
					{
						if (!BlueStacksUIUtils.sSyncInvolvedInstances.Contains(this.mVmName) || this.mIsSyncMaster)
						{
							this.ShowSynchronizerWindow();
						}
						ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "OperationSync", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
						goto IL_BEF;
					}
					goto IL_BEF;
				case ClientHotKeys.STRING_TOGGLE_VIDEO_RECORDER:
				case ClientHotKeys.STRING_BOSSKEY_SETTING:
					goto IL_BEF;
				case ClientHotKeys.STRING_RECORD_SCREEN:
					if (this.mSidebar != null && this.mSidebar.GetElementFromTag("sidebar_video_capture") != null && this.mSidebar.GetElementFromTag("sidebar_video_capture").Visibility == Visibility.Visible && this.mSidebar.GetElementFromTag("sidebar_video_capture").IsEnabled)
					{
						this.mCommonHandler.DownloadAndLaunchRecording("sidebar", "shortcut");
						goto IL_BEF;
					}
					goto IL_BEF;
				case ClientHotKeys.STRING_HOME:
					this.mCommonHandler.HomeButtonHandler(true, false);
					ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "Home", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
					goto IL_BEF;
				case ClientHotKeys.STRING_BACK:
					this.mCommonHandler.BackButtonHandler(false);
					ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "Back", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
					goto IL_BEF;
				case ClientHotKeys.STRING_SHAKE:
					this.mCommonHandler.ShakeButtonHandler();
					ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "SetLocation", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
					goto IL_BEF;
				case ClientHotKeys.STRING_ROTATE:
					if (this.mSidebar != null)
					{
						this.mSidebar.RotateButtonHandler("shortcut");
						goto IL_BEF;
					}
					goto IL_BEF;
				case ClientHotKeys.STRING_OPEN_MEDIA_FOLDER:
					CommonHandlers.OpenMediaFolder();
					ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "MediaFolder", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
					goto IL_BEF;
				case ClientHotKeys.STRING_TOGGLE_MULTIINSTANCE_WINDOW:
					try
					{
						if (!FeatureManager.Instance.IsCustomUIForNCSoft)
						{
							Process.Start(System.IO.Path.Combine(RegistryStrings.InstallDir, "HD-MultiInstanceManager.exe"));
							ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "MultiInstance", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
						}
						goto IL_BEF;
					}
					catch (Exception ex)
					{
						Logger.Error("Couldn't launch MI Manager. Ex: {0}", new object[]
						{
							ex.Message
						});
						goto IL_BEF;
					}
					break;
				case ClientHotKeys.STRING_SET_LOCATION:
					break;
				case ClientHotKeys.STRING_GAMEPAD_CONTROLS:
					if (this.mTopBar.mAppTabButtons.SelectedTab != null && this.mTopBar.mAppTabButtons.SelectedTab.mTabType == TabType.AppTab && KMManager.CheckGamepadCompatible(this.mTopBar.mAppTabButtons.SelectedTab.PackageName))
					{
						KMManager.HandleInputMapperWindow(this, true, "gamepad");
						string tag = "sidebar";
						string userGuid = RegistryManager.Instance.UserGuid;
						string arg = "GamePad";
						string arg2 = "shortcut";
						string clientVersion = RegistryManager.Instance.ClientVersion;
						string version = RegistryManager.Instance.Version;
						string oem = RegistryManager.Instance.Oem;
						AppTabButton selectedTab = this.mTopBar.mAppTabButtons.SelectedTab;
						ClientStats.SendMiscellaneousStatsAsync(tag, userGuid, arg, arg2, clientVersion, version, oem, (selectedTab != null) ? selectedTab.PackageName : null, null);
						goto IL_BEF;
					}
					goto IL_BEF;
				case ClientHotKeys.STRING_MINIMIZE_TOOLTIP:
					this.MinimizeWindow();
					ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "Minimize", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
					goto IL_BEF;
				case ClientHotKeys.STRING_AUTOMATIC_SORTING:
					this.mCommonHandler.ArrangeWindow();
					ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "ArrangeWindow", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
					goto IL_BEF;
				case ClientHotKeys.STRING_START_STREAMING:
				{
					bool flag = this.mIsStreaming;
					NCSoftUtils.Instance.SendStreamingEvent(this.mVmName, this.mIsStreaming ? "off" : "on");
					ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, flag ? "StreamVideoOff" : "StreamVideoOn", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
					goto IL_BEF;
				}
				case ClientHotKeys.STRING_SETTINGS:
					this.mTopBar.mSettingsMenuPopup.IsOpen = false;
					this.mCommonHandler.LaunchSettingsWindow();
					ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "Setting", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
					goto IL_BEF;
				default:
					goto IL_BEF;
				}
				this.mCommonHandler.LocationButtonHandler();
				ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "SetLocation", "shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
				IL_BEF:;
			}
			catch (Exception ex2)
			{
				Logger.Error("Exception in executing shortcut: " + ex2.ToString());
			}
		}

		// Token: 0x060012EB RID: 4843 RVA: 0x0000D653 File Offset: 0x0000B853
		internal void ResizeMainWindowForKeyMapSidebar()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				bool flag = false;
				IntereopRect fullscreenMonitorSize = WindowWndProcHandler.GetFullscreenMonitorSize(this.Handle, false);
				double num = (double)fullscreenMonitorSize.Width;
				if (base.WindowState == WindowState.Maximized || this.mIsFullScreen)
				{
					this.RestoreWindows();
					flag = true;
				}
				if (flag || base.ActualWidth * MainWindow.sScalingFactor > num - MainWindow.sScalingFactor * 241.0)
				{
					double num2 = num - 241.0 * MainWindow.sScalingFactor;
					double heightFromWidth = this.GetHeightFromWidth(num2, true);
					int y = Convert.ToInt32(Math.Floor(((double)fullscreenMonitorSize.Height - heightFromWidth) / 2.0));
					InteropWindow.SetWindowPos(this.Handle, (IntPtr)0, 0, y, Convert.ToInt32(Math.Floor(num2)), Convert.ToInt32(Math.Floor(heightFromWidth)), 80U);
					return;
				}
				if (base.ActualWidth * MainWindow.sScalingFactor + base.Left * MainWindow.sScalingFactor > num - MainWindow.sScalingFactor * 241.0)
				{
					InteropWindow.SetWindowPos(this.Handle, (IntPtr)0, Convert.ToInt32(Math.Floor(num - MainWindow.sScalingFactor * 241.0 - base.ActualWidth * MainWindow.sScalingFactor)), Convert.ToInt32(Math.Floor(base.Top * MainWindow.sScalingFactor)), Convert.ToInt32(Math.Floor(base.ActualWidth * MainWindow.sScalingFactor)), Convert.ToInt32(Math.Floor(base.ActualHeight * MainWindow.sScalingFactor)), 80U);
				}
			}), new object[0]);
		}

		// Token: 0x060012EC RID: 4844 RVA: 0x0007521C File Offset: 0x0007341C
		internal Grid AddBrowser(string url)
		{
			Grid grid = new Grid();
			BrowserControl element = new BrowserControl(url)
			{
				Visibility = Visibility.Visible
			};
			CustomPictureBox element2 = new CustomPictureBox
			{
				HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
				VerticalAlignment = VerticalAlignment.Center,
				Height = 30.0,
				Width = 30.0,
				ImageName = "loader",
				IsImageToBeRotated = true
			};
			grid.Children.Add(element);
			grid.Children.Add(element2);
			grid.Visibility = Visibility.Hidden;
			this.mContentGrid.Children.Add(grid);
			return grid;
		}

		// Token: 0x060012ED RID: 4845 RVA: 0x000752B8 File Offset: 0x000734B8
		internal void Frontend_OrientationChanged(string packagename, bool isPortrait)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (!string.IsNullOrEmpty(packagename))
				{
					AppTabButton tab = this.mTopBar.mAppTabButtons.GetTab(packagename);
					if (tab != null)
					{
						tab.IsPortraitModeTab = isPortrait;
						if (FeatureManager.Instance.IsCustomUIForDMM && tab.IsDMMKeymapUIVisible && KMManager.GuidanceWindow != null)
						{
							KMManager.GuidanceWindow.RepositionWindowForDMM();
						}
					}
					if (this.AppForcedOrientationDict.ContainsKey(packagename))
					{
						this.AppForcedOrientationDict[packagename] = isPortrait;
					}
				}
				this.mCommonHandler.ClipMouseCursorHandler(false, false, "", "");
			}), new object[0]);
		}

		// Token: 0x060012EE RID: 4846 RVA: 0x00075300 File Offset: 0x00073500
		internal void GuestBoot_Completed()
		{
			Logger.Info("BOOT_STAGE: In Guestboot_completed ");
			this.ShowLoadingGrid(false);
			if (!this.mGuestBootCompleted)
			{
				this.mGuestBootCompleted = true;
				this.OnGuestBootCompleted();
				if (FeatureManager.Instance.IsCustomUIForDMM)
				{
					base.Dispatcher.Invoke(new Action(delegate()
					{
						this.FrontendParentGrid.Visibility = Visibility.Visible;
					}), new object[0]);
				}
				this.HideQuitPopupIfShown();
				this.mWelcomeTab.mHomeApp.InitAppPromotionEvents();
				if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
				{
					base.Dispatcher.Invoke(new Action(delegate()
					{
						this.mWelcomeTab.mBackground.Visibility = Visibility.Hidden;
					}), new object[0]);
				}
				AppUsageTimer.StartTimer(this.mVmName, "Home");
				KMManager.Init(this);
				this.Utils.GetCurrentVolumeAtBootAsyncAndSetMuteInstancesState();
				BlueStacksUIUtils.InvokeMIManagerEvents(this.mVmName);
				this.EngineInstanceRegistry.LastBootDate = DateTime.Now.Date.ToShortDateString();
				this.Utils.sBootCheckTimer.Enabled = false;
				this.mTopBar.InitializeSnailButton();
				this.CheckIfVtxDisabledOrUnavailableAndShowPopup();
				this.mFrontendHandler.UpdateBootTimeInregistry(this.mBootStartTime);
				if (!FeatureManager.Instance.IsPromotionDisabled)
				{
					this.mWelcomeTab.RemovePromotionGrid();
				}
				if (!FeatureManager.Instance.IsCustomUIForDMM)
				{
					if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
					{
						if (this.mTopBar.CheckForRam())
						{
							this.mTopBar.AddRamNotification();
						}
						bool flag = false;
						if (!string.IsNullOrEmpty(Opt.Instance.Json))
						{
							JObject jobject = JObject.Parse(Opt.Instance.Json);
							if (jobject.Property("app_pkg") != null && !string.IsNullOrEmpty(jobject["app_pkg"].ToString().Trim().Trim()))
							{
								this.mAppHandler.PerformGamingAction(jobject["app_pkg"].ToString().Trim(), "");
								flag = true;
							}
						}
						if (!flag)
						{
							this.mAppHandler.PerformGamingAction("", "");
						}
					}
					else
					{
						this.PerformPendingRegistryActionIfAny();
						if (this.EngineInstanceRegistry.IsGoogleSigninDone)
						{
							this.PostGoogleSigninCompleteTask();
						}
						else
						{
							if (this.mTopBar.CheckForRam())
							{
								this.mTopBar.AddRamNotification();
							}
							this.HandleSslConnectionError();
							this.mWelcomeTab.mHomeApp.AppSuggestionPromotion();
						}
						this.PostBootCompleteTask();
					}
				}
				this.BootCompletedStats();
			}
		}

		// Token: 0x060012EF RID: 4847 RVA: 0x0000D673 File Offset: 0x0000B873
		private void OnFullScreenChanged(bool isFullScreen)
		{
			MainWindow.FullScreenChanged fullScreenChangedEvent = this.FullScreenChangedEvent;
			if (fullScreenChangedEvent == null)
			{
				return;
			}
			fullScreenChangedEvent(isFullScreen);
		}

		// Token: 0x060012F0 RID: 4848 RVA: 0x0000D686 File Offset: 0x0000B886
		private void OnGuestBootCompleted()
		{
			MainWindow.GuestBootCompleted guestBootCompletedEvent = this.GuestBootCompletedEvent;
			if (guestBootCompletedEvent == null)
			{
				return;
			}
			guestBootCompletedEvent();
		}

		// Token: 0x060012F1 RID: 4849 RVA: 0x0000D698 File Offset: 0x0000B898
		internal void OnCursorLockChanged(bool locked)
		{
			MainWindow.CursorLockChanged cursorLockChangedEvent = this.CursorLockChangedEvent;
			if (cursorLockChangedEvent == null)
			{
				return;
			}
			cursorLockChangedEvent(locked);
		}

		// Token: 0x060012F2 RID: 4850 RVA: 0x0000D6AB File Offset: 0x0000B8AB
		private QuitPopupControl GetQuitPopupFromDimOverlay()
		{
			if (this.mDimOverlay != null)
			{
				return this.mDimOverlay.Control as QuitPopupControl;
			}
			return null;
		}

		// Token: 0x060012F3 RID: 4851 RVA: 0x0000D6C7 File Offset: 0x0000B8C7
		private void HideQuitPopupIfShown()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					QuitPopupControl quitPopupFromDimOverlay = this.GetQuitPopupFromDimOverlay();
					if (quitPopupFromDimOverlay != null)
					{
						quitPopupFromDimOverlay.Close();
						ClientStats.SendLocalQuitPopupStatsAsync(quitPopupFromDimOverlay.CurrentPopupTag, "popup_auto_hidden");
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Couldn't notify QuitPopup for boot complete. Ex: {0}", new object[]
					{
						ex
					});
				}
			}), new object[0]);
		}

		// Token: 0x060012F4 RID: 4852 RVA: 0x00075558 File Offset: 0x00073758
		internal void InitDiscord()
		{
			try
			{
				if (RegistryManager.Instance.DiscordEnabled && this.IsDefaultVM)
				{
					if (this.mDiscordhandler == null)
					{
						this.mDiscordhandler = new Discord(this);
					}
					this.mDiscordhandler.Init();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in init discord: {0}", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x060012F5 RID: 4853 RVA: 0x000755C8 File Offset: 0x000737C8
		private void HandleSslConnectionError()
		{
			try
			{
				string text = HTTPUtils.SendRequestToGuest("checkSSLConnection", null, this.mVmName, 10000, null, false, 1, 0);
				JObject jobject = JObject.Parse(text);
				if (jobject["result"].ToString().Equals("error") && jobject["reason"].ToString().Contains("SSLHandshakeException"))
				{
					base.Dispatcher.Invoke(new Action(delegate()
					{
						CustomMessageWindow customMessageWindow = new CustomMessageWindow();
						customMessageWindow.ImageName = "security_icon";
						BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_ANTIVIRUS_ISSUE", "");
						BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlockTitle, "STRING_ANTIVIRUS_ISSUE_HEADER", "");
						customMessageWindow.BodyTextBlockTitle.Visibility = Visibility.Visible;
						customMessageWindow.BodyTextBlockTitle.FontWeight = FontWeights.Regular;
						customMessageWindow.BodyTextBlock.Inlines.Clear();
						customMessageWindow.BodyTextBlock.Inlines.Add(new TextBlock
						{
							Text = LocaleStrings.GetLocalizedString("STRING_TECHNICAL_TIP", false),
							FontWeight = FontWeights.Bold
						});
						customMessageWindow.BodyTextBlock.Inlines.Add(" ");
						customMessageWindow.BodyTextBlock.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_ANTIVIRUS_ISSUE_FIX", false));
						customMessageWindow.AddButton(ButtonColors.Blue, "STRING_SEE_HOW_TO_FIX", delegate(object sender1, EventArgs e1)
						{
							BlueStacksUIUtils.OpenUrl(WebHelper.GetUrlWithParams(string.Format("{0}/{1}", WebHelper.GetServerHost(), "help_articles")) + "&article=failed_ssl_connection");
						}, "external_link", true, null);
						this.ShowDimOverlay(null);
						customMessageWindow.Owner = this;
						customMessageWindow.ShowDialog();
						if (this.mDimOverlay != null && this.mDimOverlay.OwnedWindows.OfType<ContainerWindow>().Count<ContainerWindow>() == 0)
						{
							this.HideDimOverlay();
						}
					}), new object[0]);
				}
				ClientStats.SendMiscellaneousStatsAsync("SslConnectionResponse", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.UserSelectedLocale, text, null, null, null, null);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception when testing whether facing any problem in reaching google. " + ex.ToString());
			}
		}

		// Token: 0x060012F6 RID: 4854 RVA: 0x000756A4 File Offset: 0x000738A4
		private void PerformPendingRegistryActionIfAny()
		{
			string pendingAction = RegistryManager.Instance.PendingLaunchAction;
			if (string.IsNullOrEmpty(pendingAction))
			{
				return;
			}
			GenericAction action = (GenericAction)Enum.Parse(typeof(GenericAction), pendingAction.Split(new char[]
			{
				','
			})[0].Trim(), true);
			string actionValue = pendingAction.Split(new char[]
			{
				','
			})[1].Trim();
			if (action != GenericAction.None)
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					Logger.Info("Performing pending registry action: {0}", new object[]
					{
						pendingAction
					});
					if (this.mAppHandler.IsAppInstalled(actionValue))
					{
						this.mAppHandler.SendRunAppRequestAsync(actionValue, "", false);
						return;
					}
					GenericAction action = action;
					if (action == GenericAction.InstallPlay)
					{
						this.mAppHandler.LaunchPlayRequestAsync(actionValue);
					}
				}), new object[0]);
			}
			RegistryManager.Instance.PendingLaunchAction = string.Format("{0},{1}", GenericAction.None, string.Empty);
		}

		// Token: 0x060012F7 RID: 4855 RVA: 0x0000D6E7 File Offset: 0x0000B8E7
		private void CheckIfVtxDisabledOrUnavailableAndShowPopup()
		{
			if (!FeatureManager.Instance.IsCustomUIForDMM)
			{
				Logger.Info("In CheckIfVtxDisabledOrUnavailableAndShowPopup");
				base.Dispatcher.Invoke(new Action(delegate()
				{
					string deviceCaps = RegistryManager.Instance.DeviceCaps;
					if (string.IsNullOrEmpty(deviceCaps))
					{
						return;
					}
					JObject jobject = JObject.Parse(deviceCaps);
					if (jobject["cpu_hvm"].ToString().Equals("True", StringComparison.OrdinalIgnoreCase) && jobject["bios_hvm"].ToString().Equals("False", StringComparison.OrdinalIgnoreCase))
					{
						string text = WebHelper.GetUrlWithParams(string.Format("{0}/{1}", WebHelper.GetServerHost(), "help_articles"));
						text = string.Format("{0}&article={1}", text, "enable_virtualization");
						this.ShowImprovePerformanceWarningPopup(text, "STRING_VTX_DISABLED_WARNING_MESSAGE");
						return;
					}
					if (jobject["cpu_hvm"].ToString().Equals("False", StringComparison.OrdinalIgnoreCase))
					{
						string text = WebHelper.GetUrlWithParams(string.Format("{0}/{1}", WebHelper.GetServerHost(), "help_articles"));
						text = string.Format("{0}&article={1}", text, "vtx_unavailable");
						this.ShowImprovePerformanceWarningPopup(text, "STRING_VTX_UNAVAILABLE_WARNING_MESSAGE");
						return;
					}
					if (jobject["cpu_hvm"].ToString().Equals("True", StringComparison.OrdinalIgnoreCase) && jobject["bios_hvm"].ToString().Equals("True", StringComparison.OrdinalIgnoreCase) && jobject["engine_enabled"].ToString().Equals(EngineState.raw.ToString(), StringComparison.InvariantCultureIgnoreCase))
					{
						string text = WebHelper.GetUrlWithParams(string.Format("{0}/{1}", WebHelper.GetServerHost(), "help_articles"));
						text = string.Format("{0}&article={1}", text, "disable_antivirus");
						this.ShowImprovePerformanceWarningPopup(text, "STRING_VTX_DISABLED_WARNING_MESSAGE");
					}
				}), new object[0]);
			}
		}

		// Token: 0x060012F8 RID: 4856 RVA: 0x00075788 File Offset: 0x00073988
		private void ShowImprovePerformanceWarningPopup(string url, string bodyTextKeyValue)
		{
			CustomMessageWindow window = new CustomMessageWindow();
			BlueStacksUIBinding.Bind(window.TitleTextBlock, "STRING_IMPROVE_PERFORMANCE", "");
			window.AddWarning(LocaleStrings.GetLocalizedString("STRING_IMPROVE_PERFORMANCE_WARNING", false), "message_error");
			window.Owner = this;
			BlueStacksUIBinding.Bind(window.BodyTextBlock, bodyTextKeyValue, "");
			window.AddButton(ButtonColors.Blue, "STRING_CHECK_FAQ", delegate(object sender1, EventArgs e1)
			{
				BlueStacksUIUtils.OpenUrl(url);
			}, null, false, null);
			window.AddButton(ButtonColors.White, "STRING_CONTINUE_ANYWAY", delegate(object sender1, EventArgs e1)
			{
				window.Close();
			}, null, false, null);
			window.Show();
		}

		// Token: 0x060012F9 RID: 4857 RVA: 0x0000D71D File Offset: 0x0000B91D
		internal void CloseBrowserQuitPopup()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (this.mQuitPopupBrowserControl != null)
				{
					this.mQuitPopupBrowserControl.Close();
				}
			}), new object[0]);
		}

		// Token: 0x060012FA RID: 4858 RVA: 0x00075850 File Offset: 0x00073A50
		internal void ShowBrowserQuitPopUp(string url, string appPackage)
		{
			if (this.mIsFullScreen || base.WindowState == WindowState.Maximized)
			{
				this.mQuitPopupBrowserControl.Width = 740.0;
				this.mQuitPopupBrowserControl.Height = 490.0;
			}
			else
			{
				this.mQuitPopupBrowserControl.Width = 640.0;
				this.mQuitPopupBrowserControl.Height = 440.0;
			}
			ClientStats.SendMiscellaneousStatsAsync("quitpopupdisplayed", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, url, appPackage, null, null, null, null);
			this.mQuitPopupBrowserControl.Init(this, appPackage);
			this.ShowDimOverlay(this.mQuitPopupBrowserControl);
		}

		// Token: 0x060012FB RID: 4859 RVA: 0x00075900 File Offset: 0x00073B00
		private void BootCompletedStats()
		{
			if (RegistryManager.Instance.IsClientFirstLaunch == 1)
			{
				if (RegistryManager.Instance.IsEngineUpgraded == 1)
				{
					ClientStats.SendClientStatsAsync("update_init", "success", "engine_activity", "", "", "");
				}
				else
				{
					ClientStats.SendClientStatsAsync("first_init", "success", "engine_activity", "", "", "");
				}
				RegistryManager.Instance.IsClientFirstLaunch = 0;
				BlueStacksUIUtils.waveOutSetVolume(IntPtr.Zero, uint.MaxValue);
				HTTPUtils.SendRequestToAgentAsync("downloadInstalledAppsCfg", null, this.mVmName, 0, null, false, 1, 0);
				return;
			}
			ClientStats.SendClientStatsAsync("init", "success", "engine_activity", "", "", "");
		}

		// Token: 0x060012FC RID: 4860 RVA: 0x000759C4 File Offset: 0x00073BC4
		private void PostBootCompleteTask()
		{
			this.GetMacroShortcutKeyMappingsWithRestrictedKeysandNames();
			Action<bool> appRecommendationHandler = PromotionObject.AppRecommendationHandler;
			if (appRecommendationHandler != null)
			{
				appRecommendationHandler(false);
			}
			this.CheckUserPremiumAsync();
			if (RegistryManager.Instance.RequirementConfigUpdateRequired)
			{
				HTTPUtils.SendRequestToGuest("getConfigList", null, this.mVmName, 1000, null, false, 1, 0);
				RegistryManager.Instance.RequirementConfigUpdateRequired = false;
			}
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mTopBar.ChangeUserPremiumButton(RegistryManager.Instance.IsPremium);
			}), new object[0]);
			PromotionObject.QuestHandler = (Action)Delegate.Remove(PromotionObject.QuestHandler, new Action(this.HandleQuestForFrontend));
			PromotionObject.QuestHandler = (Action)Delegate.Combine(PromotionObject.QuestHandler, new Action(this.HandleQuestForFrontend));
			this.HandleQuestForFrontend();
			this.mAppHandler.UpdateDefaultLauncher();
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mAppInstaller = new DownloadInstallApk(this);
				if (Oem.Instance.IsDragDropEnabled)
				{
					FileImporter.Init(this);
				}
				this.mWelcomeTab.mPromotionControl.HandlePromotionEventAfterBoot();
			}), new object[0]);
			try
			{
				DownloadInstallApk.SerialWorkQueueInstaller(this.mVmName).Start();
			}
			catch (ThreadStateException ex)
			{
				Logger.Info("Thread Already Started" + ex.ToString());
			}
			if (this.mStartupTabLaunched)
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					this.mTopBar.mAppTabButtons.GoToTab(1);
				}), new object[0]);
			}
			this.HandleFLEorAppPopupPostBoot();
			this.mCommonHandler.CheckForMacroScriptOnRestart();
			this.UpdateSynchronizerInstancesList();
			this.InitDiscord();
			BlueStacks.Common.Utils.SetGoogleAdIdAndAndroidIdFromAndroid(this.mVmName);
			if (PromotionObject.Instance != null && PromotionObject.Instance.IsSecurityMetricsEnable)
			{
				SecurityMetrics.Init(this.mVmName);
				base.Dispatcher.Invoke(new Action(delegate()
				{
					this.mResizeHandler.AddRawInputHandler();
				}), new object[0]);
			}
			if (!RegistryManager.Instance.Guest[this.mVmName].IsGoogleSigninPopupShown && !RegistryManager.Instance.Guest[this.mVmName].IsGoogleSigninDone)
			{
				ClientStats.SendMiscellaneousStatsAsync("GoogleSigninShown", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, null, null, RegistryManager.Instance.InstallID, null, null, null);
				base.Dispatcher.Invoke(new Action(delegate()
				{
					if (base.WindowState != WindowState.Minimized)
					{
						new ContainerWindow(this, new PromptGoogleSigninControl(this), 620.0, 380.0, false, true);
					}
				}), new object[0]);
			}
			RegistryManager.Instance.Guest[this.mVmName].IsGoogleSigninPopupShown = true;
			if (new DriveInfo(System.IO.Path.GetPathRoot(RegistryManager.Instance.UserDefinedDir)).AvailableFreeSpace < 1073741824L)
			{
				this.ShowLowDiskSpaceWarning();
			}
			if (RegistryManager.Instance.IsEngineUpgraded == 1 && RegistryManager.Instance.IsClientFirstLaunch == 1 && this.VersionCheckForSmartControl())
			{
				this.mWelcomeTab.mHomeApp.ShowAppPopupAfterUpgrade("com.dts.freefireth");
			}
		}

		// Token: 0x060012FD RID: 4861 RVA: 0x00075C70 File Offset: 0x00073E70
		private bool VersionCheckForSmartControl()
		{
			if (RegistryManager.Instance.UpgradeVersionList.Length != 0)
			{
				System.Version v = new System.Version("4.140.00.0000");
				return new System.Version(RegistryManager.Instance.UpgradeVersionList.Last<string>()) < v;
			}
			return false;
		}

		// Token: 0x060012FE RID: 4862 RVA: 0x0000D73D File Offset: 0x0000B93D
		private void ShowLowDiskSpaceWarning()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_LOW_DISK_SPACE", false);
				customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_LOW_DISK_SPACE_MESSAGE", false);
				customMessageWindow.AddWarning(LocaleStrings.GetLocalizedString("STRING_LOW_DISK_SPACE_WARNING", false), "");
				customMessageWindow.BodyWarningTextBlock.Visibility = Visibility.Visible;
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
				this.ShowDimOverlay(null);
				customMessageWindow.Owner = this.mDimOverlay;
				customMessageWindow.ShowDialog();
				this.HideDimOverlay();
			}), new object[0]);
		}

		// Token: 0x060012FF RID: 4863 RVA: 0x00075CB4 File Offset: 0x00073EB4
		internal void PostGoogleSigninCompleteTask()
		{
			if (!this.mIsTokenAvailable && RegistryManager.Instance.InstallationType != InstallationTypes.GamingEdition)
			{
				this.Utils.SendBluestacksLoginRequest(this.mVmName);
			}
			if (!FeatureManager.Instance.IsCustomUIForDMM)
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					this.mTopBar.TopBarOptionsPanelElementVisibility(this.mTopBar.mUserAccountBtn, true);
					this.mTopBar.TopBarOptionsPanelElementVisibility(this.mTopBar.mNotificationCentreButton, true);
				}), new object[0]);
				this.mWelcomeTab.mHomeApp.AppSuggestionPromotion();
			}
		}

		// Token: 0x06001300 RID: 4864 RVA: 0x0000D75D File Offset: 0x0000B95D
		internal void CheckUserPremiumAsync()
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					PromotionManager.CheckIsUserPremium();
				}
				catch (Exception ex)
				{
					Logger.Error("PostOTSBootComplete: call for premium failed" + ex.ToString());
				}
			});
		}

		// Token: 0x06001301 RID: 4865 RVA: 0x00075D24 File Offset: 0x00073F24
		private void HandleQuestForFrontend()
		{
			if (PromotionObject.Instance.QuestHdPlayerRules.Count > 0)
			{
				Dictionary<string, string> data = new Dictionary<string, string>
				{
					{
						"data",
						JsonConvert.SerializeObject(PromotionObject.Instance.QuestHdPlayerRules, Formatting.None)
					}
				};
				this.mFrontendHandler.SendFrontendRequest("setPackagesForInteraction", data);
				PromotionManager.StartQuestRulesProcessor();
			}
		}

		// Token: 0x06001302 RID: 4866 RVA: 0x00075D7C File Offset: 0x00073F7C
		private void HandleFLEorAppPopupPostBoot()
		{
			this.GetFleCampaignJson();
			if (!RegistryManager.Instance.Guest[this.mVmName].IsGoogleSigninPopupShown && !RegistryManager.Instance.Guest[this.mVmName].IsGoogleSigninDone)
			{
				return;
			}
			if (!string.IsNullOrEmpty(Opt.Instance.Json) && "Android".Equals(this.mVmName))
			{
				JObject jobject = JObject.Parse(Opt.Instance.Json);
				if (jobject.Property("app_pkg") != null && !string.IsNullOrEmpty(jobject["app_pkg"].ToString().Trim().Trim()))
				{
					new DownloadInstallApk(this).DownloadAndInstallAppFromJson(Opt.Instance.Json, "parameter_json");
					return;
				}
			}
			if (!this.mStartupTabLaunched && PromotionObject.Instance.StartupTab != null)
			{
				if (PromotionObject.Instance.StartupTab.ContainsKey("click_generic_action") && EnumHelper.Parse<GenericAction>(PromotionObject.Instance.StartupTab["click_generic_action"], GenericAction.None) != GenericAction.None && (string.IsNullOrEmpty(RegistryManager.Instance.RegisteredEmail.Trim()) || string.IsNullOrEmpty(RegistryManager.Instance.Token.Trim())))
				{
					this.mLaunchStartupTabWhenTokenReceived = true;
				}
				if (!this.mLaunchStartupTabWhenTokenReceived)
				{
					base.Dispatcher.Invoke(new Action(delegate()
					{
						this.mStartupTabLaunched = true;
						this.Utils.HandleGenericActionFromDictionary(PromotionObject.Instance.StartupTab, "startup_tab", "");
					}), new object[0]);
				}
			}
		}

		// Token: 0x06001303 RID: 4867 RVA: 0x00075EF4 File Offset: 0x000740F4
		private void GetFleCampaignJson()
		{
			string flecampaignMD = RegistryManager.Instance.FLECampaignMD5;
			if (!string.IsNullOrEmpty(flecampaignMD))
			{
				try
				{
					string campaignJson = BstHttpClient.Get(string.Format("{0}/bs3/getcampaigninfo?md5_hash={1}", RegistryManager.Instance.Host, flecampaignMD), null, false, this.mVmName, 0, 1, 0, false);
					RegistryManager.Instance.DeleteFLECampaignMD5();
					RegistryManager.Instance.CampaignJson = campaignJson;
				}
				catch
				{
					Logger.Info("Error fetching campaign json");
				}
			}
		}

		// Token: 0x06001304 RID: 4868 RVA: 0x00075F70 File Offset: 0x00074170
		private void HandleFLEorAppPopupBeforeBoot()
		{
			this.GetFleCampaignJson();
			if (!RegistryManager.Instance.Guest[this.mVmName].IsGoogleSigninPopupShown && !RegistryManager.Instance.Guest[this.mVmName].IsGoogleSigninDone)
			{
				return;
			}
			if (!string.IsNullOrEmpty(Opt.Instance.Json) && "Android".Equals(this.mVmName))
			{
				JObject jobject = JObject.Parse(Opt.Instance.Json);
				if (jobject.Property("app_pkg") != null && !string.IsNullOrEmpty(jobject["app_pkg"].ToString().Trim().Trim()))
				{
					return;
				}
			}
			if (PromotionObject.Instance.StartupTab != null)
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					if (PromotionObject.Instance.StartupTab.ContainsKey("click_generic_action") && (EnumHelper.Parse<GenericAction>(PromotionObject.Instance.StartupTab["click_generic_action"], GenericAction.None) & (GenericAction)36) != (GenericAction)0)
					{
						this.mStartupTabLaunched = true;
						this.Utils.HandleGenericActionFromDictionary(PromotionObject.Instance.StartupTab, "startup_tab", "");
					}
				}), new object[0]);
			}
		}

		// Token: 0x06001305 RID: 4869 RVA: 0x00076048 File Offset: 0x00074248
		internal void ShowLoadingGrid(bool isShow)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					if (isShow)
					{
						this.mTopBar.mAppTabButtons.EnableAppTabs(false);
						if (!FeatureManager.Instance.IsCustomUIForDMM)
						{
							this.mWelcomeTab.mHomeApp.mLoadingGrid.Visibility = Visibility.Visible;
						}
					}
					else
					{
						this.mTopBar.mAppTabButtons.EnableAppTabs(true);
						if (!FeatureManager.Instance.IsCustomUIForDMM)
						{
							this.mWelcomeTab.mHomeApp.mLoadingGrid.Visibility = Visibility.Hidden;
						}
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in ShowLoadingGrid. " + ex.ToString());
				}
				Logger.Info("BOOT_STAGE: Removing progress bar");
			}), new object[0]);
		}

		// Token: 0x06001306 RID: 4870 RVA: 0x0000D784 File Offset: 0x0000B984
		internal void ShowControlGrid(Grid controlGrid)
		{
			if (this.mLastVisibleGrid != null && controlGrid != this.mLastVisibleGrid)
			{
				this.mLastVisibleGrid.Visibility = Visibility.Hidden;
			}
			this.mLastVisibleGrid = controlGrid;
			controlGrid.Visibility = Visibility.Visible;
		}

		// Token: 0x06001307 RID: 4871 RVA: 0x00076088 File Offset: 0x00074288
		private void TopBar_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!e.OriginalSource.GetType().Equals(typeof(CustomPictureBox)) || this.mTopBar.WindowHeaderGrid.IsMouseOver)
			{
				try
				{
					base.DragMove();
				}
				catch
				{
				}
				this.UIChangesOnMainWindowSizeChanged();
			}
		}

		// Token: 0x06001308 RID: 4872 RVA: 0x0000D7B1 File Offset: 0x0000B9B1
		private void TopBar_MouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
			if (!e.OriginalSource.GetType().Equals(typeof(CustomPictureBox)))
			{
				if (base.WindowState == WindowState.Maximized)
				{
					this.RestoreWindows();
					return;
				}
				this.MaximizeWindow();
			}
		}

		// Token: 0x06001309 RID: 4873 RVA: 0x000760E8 File Offset: 0x000742E8
		internal void RestoreWindows()
		{
			if (this.mResizeHandler.IsMinMaxEnabled)
			{
				if (FeatureManager.Instance.IsCustomUIForDMM)
				{
					this.mTopBarPopup.IsOpen = false;
				}
				if (this.mGeneraltoast.IsOpen)
				{
					this.toastTimer.Stop();
					this.mGeneraltoast.IsOpen = false;
				}
				this.TopBar.Visibility = Visibility.Visible;
				this.OuterBorder.BorderThickness = new Thickness(1.0);
				if (FeatureManager.Instance.IsCustomUIForDMM)
				{
					this.mDmmBottomBar.Visibility = Visibility.Visible;
				}
				if (this.mIsFullScreenFromMaximized && this.mIsFullScreen)
				{
					IntereopRect fullscreenMonitorSize = WindowWndProcHandler.GetFullscreenMonitorSize(this.Handle, true);
					InteropWindow.SetWindowPos(this.Handle, (IntPtr)0, fullscreenMonitorSize.Left, fullscreenMonitorSize.Top, fullscreenMonitorSize.Width, fullscreenMonitorSize.Height, 80U);
					this.UIChangesOnMainWindowSizeChanged();
				}
				else
				{
					this.mIsFullScreenFromMaximized = false;
					if (FeatureManager.Instance.IsCustomUIForDMM && this.mDMMRecommendedWindow != null && this.mIsDMMRecommendedWindowOpen)
					{
						this.mDMMRecommendedWindow.Visibility = Visibility.Visible;
					}
					this.mResizeHandler.mAdjustingWidth = false;
					if (this.mTopBar.mAppTabButtons.SelectedTab != null)
					{
						this.IsUIInPortraitMode = this.mTopBar.mAppTabButtons.SelectedTab.IsPortraitModeTab;
					}
					this.mResizeGrid.Visibility = Visibility.Visible;
					this.FrontendParentGrid.Margin = new Thickness(1.0);
					base.WindowState = WindowState.Normal;
					this.SwitchToPortraitMode(this.IsUIInPortraitMode);
					this.mIsDmmMaximised = false;
					if (FeatureManager.Instance.IsCustomUIForDMM)
					{
						this.DmmRestoreWindowRectangle = new Rect(0.0, 0.0, 0.0, 0.0);
					}
					else if (this.IsUIInPortraitMode)
					{
						this.mTopBar.RefreshNotificationCentreButton();
					}
					if (this.mTopBar.mAppTabButtons.SelectedTab != null && Constants.ImapShootingModeAppsList.Contains(this.mTopBar.mAppTabButtons.SelectedTab.PackageName))
					{
						this.ToggleShootingModeTooltipVisibility(true);
					}
					else
					{
						this.ToggleShootingModeTooltipVisibility(false);
					}
					this.mResizeHandler.IsResizingEnabled = true;
					this.mTopBar.mMaximizeButton.ImageName = "maximize";
					BlueStacksUIBinding.Bind(this.mTopBar.mMaximizeButton, "STRING_MAXIMIZE_TOOLTIP");
					this.mNCTopBar.mMaximizeButtonImage.ImageName = "maximize";
					BlueStacksUIBinding.Bind(this.mNCTopBar.mMaximizeButtonImage, "STRING_MAXIMIZE_TOOLTIP");
					this.mCommonHandler.ClipMouseCursorHandler(false, false, "", "");
				}
				this.mTopBar.UpdateMacroRecordingProgress();
				this.mIsFullScreen = false;
				this.mFrontendHandler.ShowGLWindow();
				HTTPUtils.SendRequestToEngineAsync("setIsFullscreen", new Dictionary<string, string>
				{
					{
						"isFullscreen",
						"false"
					}
				}, this.mVmName, 0, null, false, 1, 0);
				this.OnFullScreenChanged(false);
				this.mCommonHandler.ClipMouseCursorHandler(false, false, "", "");
			}
		}

		// Token: 0x0600130A RID: 4874 RVA: 0x0000D7E5 File Offset: 0x0000B9E5
		internal void MinimizeWindow()
		{
			base.WindowState = WindowState.Minimized;
		}

		// Token: 0x0600130B RID: 4875 RVA: 0x000763EC File Offset: 0x000745EC
		internal void MaximizeWindow()
		{
			if (this.mResizeHandler.IsMinMaxEnabled)
			{
				this.mIsDMMMaximizedFromPortrait = this.IsUIInPortraitMode;
				if (FeatureManager.Instance.IsCustomUIForDMM && this.mDMMRecommendedWindow != null)
				{
					this.mDMMRecommendedWindow.Visibility = Visibility.Hidden;
				}
				if (this.mPreviousWidth == null)
				{
					this.mPreviousWidth = new double?(base.Width);
				}
				this.mIsDmmMaximised = true;
				if (FeatureManager.Instance.IsCustomUIForDMM && this.IsUIInPortraitMode && !this.mIsFullScreen)
				{
					this.SetDMMRestoreWindowSizeAndPosition();
					this.SetSizeForDMMPortraitMaximisedWindow();
				}
				else
				{
					if (FeatureManager.Instance.IsCustomUIForDMM && !this.mIsFullScreen)
					{
						this.SetDMMRestoreWindowSizeAndPosition();
					}
					this.IsUIInPortraitModeWhenMaximized = this.IsUIInPortraitMode;
					this.IsUIInPortraitMode = false;
					base.WindowState = WindowState.Maximized;
				}
				this.mResizeHandler.IsResizingEnabled = false;
				this.mTopBar.mMaximizeButton.ImageName = "restore";
				this.mTopBar.RefreshNotificationCentreButton();
				this.mTopBar.UpdateMacroRecordingProgress();
				BlueStacksUIBinding.Bind(this.mTopBar.mMaximizeButton, "STRING_RESTORE_BUTTON");
				this.mNCTopBar.mMaximizeButtonImage.ImageName = "restore";
				BlueStacksUIBinding.Bind(this.mNCTopBar.mMaximizeButtonImage, "STRING_RESTORE_BUTTON");
				this.mTopBar.RefreshWarningButton();
				this.UIChangesOnMainWindowSizeChanged();
			}
		}

		// Token: 0x0600130C RID: 4876 RVA: 0x00076540 File Offset: 0x00074740
		internal void RestrictWindowResize(bool enable)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mResizeHandler.IsMinMaxEnabled = !enable;
				this.mResizeHandler.IsResizingEnabled = !enable;
				this.mTopBar.mMaximizeButton.IsEnabled = !enable;
				this.mNCTopBar.mMaximizeButtonImage.IsEnabled = !enable;
				if (enable)
				{
					this.mTopBar.mMaximizeButton.SetDisabledState();
					this.mNCTopBar.mMaximizeButtonImage.SetDisabledState();
					return;
				}
				this.mTopBar.mMaximizeButton.SetNormalState();
				this.mNCTopBar.mMaximizeButtonImage.SetNormalState();
			}), new object[0]);
		}

		// Token: 0x0600130D RID: 4877 RVA: 0x00076580 File Offset: 0x00074780
		internal void FullScreenWindow()
		{
			if (FeatureManager.Instance.IsCustomUIForDMM || this.mTopBar.mAppTabButtons.SelectedTab.mTabType == TabType.AppTab)
			{
				if (this.mPreviousWidth == null)
				{
					this.mPreviousWidth = new double?(base.Width);
				}
				this.mIsFullScreen = true;
				this.OuterBorder.BorderThickness = new Thickness(0.0);
				if (FeatureManager.Instance.IsCustomUIForDMM)
				{
					this.mDmmBottomBar.Visibility = Visibility.Collapsed;
					this.mDmmBottomBar.ShowKeyMapPopup(false);
				}
				else
				{
					this.mBottomBar.ShowKeyMapPopup(false);
					this.mBottomBar.ShowOverlayTooltip(false, false);
				}
				this.TopBar.Visibility = Visibility.Collapsed;
				this.mResizeGrid.Visibility = Visibility.Collapsed;
				this.FrontendParentGrid.Margin = new Thickness(0.0);
				if (base.WindowState == WindowState.Maximized)
				{
					this.mIsFullScreenFromMaximized = true;
					IntereopRect fullscreenMonitorSize = WindowWndProcHandler.GetFullscreenMonitorSize(this.Handle, false);
					InteropWindow.SetWindowPos(this.Handle, (IntPtr)0, fullscreenMonitorSize.Left, fullscreenMonitorSize.Top, fullscreenMonitorSize.Width, fullscreenMonitorSize.Height, 80U);
				}
				else
				{
					if (FeatureManager.Instance.IsCustomUIForDMM && base.WindowState != WindowState.Maximized && !this.mIsDmmMaximised)
					{
						this.SetDMMRestoreWindowSizeAndPosition();
					}
					this.MaximizeWindow();
				}
				System.Windows.Forms.Cursor.Clip = System.Drawing.Rectangle.Empty;
				if (FeatureManager.Instance.IsCustomUIForDMM)
				{
					this.mTopBarPopup.IsOpen = true;
				}
				HTTPUtils.SendRequestToEngineAsync("setIsFullscreen", new Dictionary<string, string>
				{
					{
						"isFullscreen",
						"true"
					}
				}, this.mVmName, 0, null, false, 1, 0);
				new Thread(delegate()
				{
					Thread.Sleep(1000);
					base.Dispatcher.Invoke(new Action(delegate()
					{
						if (FeatureManager.Instance.IsCustomUIForDMM && !this.mDMMFST.IsMouseOver && !this.mDMMFST.mVolumePopup.IsOpen && !this.mDMMFST.mChangeTransparencyPopup.IsOpen)
						{
							this.mTopBarPopup.IsOpen = false;
						}
					}), new object[0]);
				})
				{
					IsBackground = true
				}.Start();
				this.OnFullScreenChanged(true);
				this.UIChangesOnMainWindowSizeChanged();
			}
		}

		// Token: 0x0600130E RID: 4878 RVA: 0x00076750 File Offset: 0x00074950
		internal void ShowToast(string text)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					if (this.mIsWindowInFocus)
					{
						if (this.mFullScreenToastPopup.IsOpen)
						{
							this.mFullScreenToastTimer.Stop();
							this.mFullScreenToastPopup.IsOpen = false;
						}
						this.mFullScreenToastControl.Init(this, text);
						this.dummyToast.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
						this.dummyToast.VerticalAlignment = VerticalAlignment.Top;
						this.mFullScreenToastControl.Visibility = Visibility.Visible;
						this.mFullScreenToastPopup.IsOpen = true;
						this.mFullScreenToastCanvas.Height = this.mFullScreenToastControl.ActualHeight;
						this.mFullScreenToastPopup.VerticalOffset = this.mFullScreenToastControl.ActualHeight + 20.0;
						this.mFullScreenToastPopup.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
						this.mFullScreenToastTimer.Start();
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in showing fullscreen toast : " + ex.ToString());
				}
			}), new object[0]);
		}

		// Token: 0x0600130F RID: 4879 RVA: 0x0000D7EE File Offset: 0x0000B9EE
		private void SetDMMRestoreWindowSizeAndPosition()
		{
			this.DmmRestoreWindowRectangle = new Rect(base.Left, base.Top, base.Width, base.Height);
		}

		// Token: 0x06001310 RID: 4880 RVA: 0x00076790 File Offset: 0x00074990
		private void SetSizeForDMMPortraitMaximisedWindow()
		{
			double num = SystemParameters.WorkArea.Height;
			double num2 = this.GetWidthFromHeight(num, false);
			if (num2 > SystemParameters.WorkArea.Width / MainWindow.sScalingFactor)
			{
				num2 = SystemParameters.WorkArea.Width / MainWindow.sScalingFactor;
				num = this.GetHeightFromWidth(num2, false);
			}
			if (num2 < base.MinWidth || num < base.MinHeight)
			{
				num2 = base.MinWidth;
				num = base.MinHeight;
			}
			base.Height = num;
			base.Width = num2;
			base.Left = (SystemParameters.WorkArea.Width - base.Width) / 2.0;
			base.Top = 0.0;
		}

		// Token: 0x06001311 RID: 4881 RVA: 0x0001CBFC File Offset: 0x0001ADFC
		private void BottomBar_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!e.OriginalSource.GetType().Equals(typeof(CustomPictureBox)))
			{
				try
				{
					base.DragMove();
				}
				catch
				{
				}
			}
		}

		// Token: 0x06001312 RID: 4882 RVA: 0x0000D813 File Offset: 0x0000BA13
		private void ResizeGrid_Loaded(object sender, RoutedEventArgs e)
		{
			if (this.mResizeGrid == null)
			{
				this.mResizeGrid = (sender as Grid);
				this.WireSizingEvents();
			}
		}

		// Token: 0x06001313 RID: 4883 RVA: 0x00076848 File Offset: 0x00074A48
		private void WireSizingEvents()
		{
			using (IEnumerator enumerator = this.mResizeGrid.Children.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					System.Windows.Shapes.Rectangle rectangle;
					if ((rectangle = (((UIElement)enumerator.Current) as System.Windows.Shapes.Rectangle)) != null)
					{
						rectangle.PreviewMouseLeftButtonDown += this.mResizeHandler.ResizeRectangle_PreviewMouseDown;
						rectangle.MouseMove += this.mResizeHandler.ResizeRectangle_MouseMove;
					}
				}
			}
		}

		// Token: 0x06001314 RID: 4884 RVA: 0x000768D8 File Offset: 0x00074AD8
		private void FrontendGrid_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			this.mFrontendHandler.FrontendVisibleChanged((bool)e.NewValue);
			Logger.Debug("KMP FrontendGrid_IsVisibleChanged " + e.NewValue + this.mVmName);
			if ((bool)e.NewValue)
			{
				this.OnFrontendGridVisible();
			}
			else
			{
				this.OnFrontendGridHidden();
			}
			this.mFrontendHandler.ShowGLWindow();
		}

		// Token: 0x06001315 RID: 4885 RVA: 0x0000D82F File Offset: 0x0000BA2F
		private void OnFrontendGridHidden()
		{
			this.mFrontendHandler.DeactivateFrontend();
			MainWindow.FrontendGridVisibleChanged frontendGridVisibleChangedEvent = this.FrontendGridVisibleChangedEvent;
			if (frontendGridVisibleChangedEvent == null)
			{
				return;
			}
			frontendGridVisibleChangedEvent(false);
		}

		// Token: 0x06001316 RID: 4886 RVA: 0x0000D84D File Offset: 0x0000BA4D
		private void OnFrontendGridVisible()
		{
			MainWindow.FrontendGridVisibleChanged frontendGridVisibleChangedEvent = this.FrontendGridVisibleChangedEvent;
			if (frontendGridVisibleChangedEvent == null)
			{
				return;
			}
			frontendGridVisibleChangedEvent(true);
		}

		// Token: 0x06001317 RID: 4887 RVA: 0x0000D860 File Offset: 0x0000BA60
		private void FrontendGrid_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			this.mFrontendHandler.ShowGLWindow();
		}

		// Token: 0x06001318 RID: 4888 RVA: 0x00076940 File Offset: 0x00074B40
		private void FrontendParentGrid_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (this.FrontendParentGrid.Visibility == Visibility.Visible)
			{
				if (!this.FrontendParentGrid.Children.Contains(this.mFrontendGrid))
				{
					if (this.mFrontendGrid.Parent != null)
					{
						(this.mFrontendGrid.Parent as Grid).Children.Remove(this.mFrontendGrid);
					}
					this.FrontendParentGrid.Children.Add(this.mFrontendGrid);
				}
				if (this.mGuestBootCompleted && FeatureManager.Instance.IsCustomUIForDMM)
				{
					this.mDmmProgressControl.Visibility = Visibility.Hidden;
					this.mFrontendGrid.Visibility = Visibility.Visible;
				}
			}
		}

		// Token: 0x06001319 RID: 4889 RVA: 0x0000D86D File Offset: 0x0000BA6D
		internal void HandleRestartPopup()
		{
			Logger.Info("Showing restart option to the user");
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					CustomMessageWindow customMessageWindow = new CustomMessageWindow();
					customMessageWindow.AddButton(ButtonColors.Blue, "STRING_RESTART_ENGINE", this.RestartEngineConfirmationAcceptedHandler, null, false, null);
					customMessageWindow.AddButton(ButtonColors.White, "STRING_RESTART_PC", this.RestartPcConfirmationAcceptedHandler, null, false, null);
					BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_ENGINE_FAIL_HEADER", "");
					BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_ENGINE_RESTART", "");
					this.ShowDimOverlay(null);
					customMessageWindow.Owner = this.mDimOverlay;
					customMessageWindow.ShowDialog();
					this.HideDimOverlay();
				}
				catch (Exception ex)
				{
					Logger.Error("Error window probably closed");
					Logger.Error(ex.ToString());
				}
			}), new object[0]);
		}

		// Token: 0x0600131A RID: 4890 RVA: 0x0000D897 File Offset: 0x0000BA97
		internal void MainWindow_RestartEngineConfirmationAcceptedHandler(object sender, EventArgs e)
		{
			BlueStacksUIUtils.RestartInstance(this.mVmName);
		}

		// Token: 0x0600131B RID: 4891 RVA: 0x0000D8A4 File Offset: 0x0000BAA4
		private void MainWindow_RestartPcConfirmationHandler(object sender, EventArgs e)
		{
			Process.Start("shutdown.exe", "-r -t 0");
		}

		// Token: 0x0600131C RID: 4892 RVA: 0x0000D8B6 File Offset: 0x0000BAB6
		private void WelcomeTabParentGrid_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			this.mWelcomeTab.Visibility = this.WelcomeTabParentGrid.Visibility;
		}

		// Token: 0x0600131D RID: 4893 RVA: 0x0000D8CE File Offset: 0x0000BACE
		private void PikaPopControl_CloseClicked(object sender, EventArgs e)
		{
			this.pikaPop.IsOpen = false;
			this.isPikaPopOpen = false;
		}

		// Token: 0x0600131E RID: 4894 RVA: 0x000769E8 File Offset: 0x00074BE8
		internal void ClosePopUps()
		{
			this.PikaPopControl_CloseClicked(this, null);
			this.mWelcomeTab.mHomeApp.mSuggestedAppPopUp.IsOpen = false;
			this.mWelcomeTab.mHomeApp.mMoreAppsDockPopup.IsOpen = false;
			this.toastPopup.IsOpen = false;
			this.mShootingModePopup.IsOpen = false;
			if (this.mSidebar.mListPopups != null)
			{
				foreach (CustomPopUp customPopUp in this.mSidebar.mListPopups)
				{
					customPopUp.IsOpen = false;
				}
			}
		}

		// Token: 0x0600131F RID: 4895 RVA: 0x0000D8E3 File Offset: 0x0000BAE3
		private void BackButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked back button setup bottombar ");
			this.mCommonHandler.BackButtonHandler(false);
		}

		// Token: 0x06001320 RID: 4896 RVA: 0x00076A98 File Offset: 0x00074C98
		private void TopBarPopup_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				if (!this.mDMMFST.IsMouseOver && !this.mDMMFST.mVolumePopup.IsOpen && !this.mDMMFST.mChangeTransparencyPopup.IsOpen)
				{
					this.mTopBarPopup.IsOpen = false;
					return;
				}
			}
			else if (!this.mFullScreenTopBar.mChangeTransparencyPopup.IsOpen)
			{
				this.mTopBarPopup.IsOpen = false;
			}
		}

		// Token: 0x06001321 RID: 4897 RVA: 0x00076B10 File Offset: 0x00074D10
		internal void SetMacroPlayBackEventHandle()
		{
			try
			{
				EventWaitHandle.OpenExisting(BlueStacksUIUtils.GetMacroPlaybackEventName(this.mVmName)).Set();
			}
			catch (Exception ex)
			{
				Logger.Warning("Unable to set macro playback event err:" + ex.ToString());
			}
		}

		// Token: 0x06001322 RID: 4898 RVA: 0x00076B60 File Offset: 0x00074D60
		internal void StartTimerForAppPlayerRestart(int interval)
		{
			this.mMacroTimer = new System.Timers.Timer((double)(interval * 60 * 1000));
			this.mMacroTimer.Elapsed -= this.MacroTimer_Elapsed;
			this.mMacroTimer.Elapsed += this.MacroTimer_Elapsed;
			this.mMacroTimer.Start();
		}

		// Token: 0x06001323 RID: 4899 RVA: 0x00076BBC File Offset: 0x00074DBC
		private void Fullscreentopbar_opened(object sender, EventArgs e)
		{
			if (this.mTopBarPopup.IsOpen)
			{
				base.MouseMove -= this.MainWindow_MouseMove;
				base.MouseMove += this.MainWindow_MouseMove;
				return;
			}
			base.MouseMove -= this.MainWindow_MouseMove;
		}

		// Token: 0x06001324 RID: 4900 RVA: 0x00076C10 File Offset: 0x00074E10
		private void MacroTimer_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (this.mMacroTimer.Enabled)
			{
				this.mMacroTimer.Enabled = false;
				this.mMacroTimer.AutoReset = false;
				this.mMacroTimer.Dispose();
				base.Dispatcher.Invoke(new Action(delegate()
				{
					this.mTopBar.HideMacroPlaybackFromTopBar();
					if (FeatureManager.Instance.IsCustomUIForNCSoft)
					{
						this.mNCTopBar.HideMacroPlaybackFromTopBar();
					}
					this.mIsMacroPlaying = false;
					this.mMacroPlaying = string.Empty;
					BlueStacksUIUtils.RestartInstance(this.mVmName);
				}), new object[0]);
			}
		}

		// Token: 0x06001325 RID: 4901 RVA: 0x00076C6C File Offset: 0x00074E6C
		internal void ShowSynchronizerWindow()
		{
			this.mTopBar.mSettingsMenuPopup.IsOpen = false;
			if (this.mSynchronizerWindow == null)
			{
				this.mSynchronizerWindow = new SynchronizerWindow(this);
			}
			this.mSynchronizerWindow.Init();
			this.mSynchronizerWindow.Show();
			this.mSynchronizerWindow.ShowWithParentWindow = true;
		}

		// Token: 0x06001326 RID: 4902 RVA: 0x00076CC0 File Offset: 0x00074EC0
		internal void ToggleShootingModeTooltipVisibility(bool isVisible = false)
		{
			if (isVisible)
			{
				string text;
				if (RegistryManager.Instance.Guest[this.mVmName].GlMode == 1 && RegistryManager.Instance.Guest[this.mVmName].GlRenderMode == 1 && RegistryManager.Instance.Guest[this.mVmName].SmartControlsEnabledApps.Contains("com.dts.freefireth") && this.EngineInstanceRegistry.SmartControlsEnabledApps.Any((string x) => string.Equals(x, this.mTopBar.mAppTabButtons.SelectedTab.PackageName, StringComparison.InvariantCultureIgnoreCase)) && this.SelectedConfig.SelectedControlScheme.Images.Count > 0)
				{
					text = string.Format(LocaleStrings.GetLocalizedString("STRING_SHOOTING_MODE_TOOLTIP_SMART_CONTROL", false), KMManager.sShootingModeKey);
				}
				else
				{
					text = string.Format(LocaleStrings.GetLocalizedString("STRING_PRESS_TO_AIM_AND_SHOOT", false), KMManager.sShootingModeKey);
				}
				if (!this.mIsWindowInFocus)
				{
					return;
				}
				if (this.mToastControl.Init(this, text))
				{
					this.mToastControl.Visibility = Visibility.Visible;
					this.dummyTooltip.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
					this.dummyTooltip.VerticalAlignment = VerticalAlignment.Bottom;
					this.mShootingModePopup.IsOpen = true;
					this.mShootingModePopup.StaysOpen = true;
					this.mShootingModePopup.VerticalAlignment = VerticalAlignment.Bottom;
					this.mShootingModePopup.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
					this.mShootingModePopup.VerticalOffset = -1.0 * this.mToastControl.ActualHeight - 14.0;
					this.mShootingModePopup.HorizontalOffset = 130.0;
					this.mShootingModePopupCanvas.Width = this.mToastControl.ActualWidth;
					this.mShootingModePopupCanvas.Height = this.mToastControl.ActualHeight;
					return;
				}
			}
			else
			{
				this.mShootingModePopup.IsOpen = false;
				this.mShootingModePopup.StaysOpen = false;
				this.mToastControl.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x06001327 RID: 4903 RVA: 0x00076E9C File Offset: 0x0007509C
		private void ReleaseClientGlobalLock()
		{
			try
			{
				if (this.mBlueStacksClientInstanceLock != null)
				{
					this.mBlueStacksClientInstanceLock.ReleaseMutex();
					this.mBlueStacksClientInstanceLock.Close();
					this.mBlueStacksClientInstanceLock = null;
				}
			}
			catch (Exception arg)
			{
				Logger.Error("Exception in releasing client global lock.." + arg);
			}
		}

		// Token: 0x06001328 RID: 4904 RVA: 0x00004BF2 File Offset: 0x00002DF2
		private void FullscreenSidebarPopup_Opened(object sender, EventArgs e)
		{
		}

		// Token: 0x06001329 RID: 4905 RVA: 0x00004BF2 File Offset: 0x00002DF2
		private void FullscreenSidebarPopup_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
		}

		// Token: 0x0600132A RID: 4906 RVA: 0x00076EF4 File Offset: 0x000750F4
		private void MainWindow_SidebarMouseMove(object sender, System.Windows.Input.MouseEventArgs e)
		{
			try
			{
				if (this.mIsFullScreen && this.mFullscreenSidebarPopup.IsOpen && e.GetPosition(this).X < base.Width - 40.0)
				{
					this.mFullscreenSidebarPopup.IsOpen = false;
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600132B RID: 4907 RVA: 0x00076F58 File Offset: 0x00075158
		private void MainWindow_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
		{
			try
			{
				if (this.mIsFullScreen && this.mTopBarPopup.IsOpen && e.GetPosition(this.mDMMFST).Y > 80.0 && !this.mDMMFST.mChangeTransparencyPopup.IsOpen)
				{
					this.mTopBarPopup.IsOpen = false;
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600132C RID: 4908 RVA: 0x00076FCC File Offset: 0x000751CC
		internal void ShowLockScreen()
		{
			if (this.mIsLockScreenActionPending)
			{
				return;
			}
			if (this.EngineInstanceRegistry.IsClientOnTop)
			{
				base.Topmost = false;
				this.EngineInstanceRegistry.IsClientOnTop = false;
			}
			if (this.mDimOverlay != null && this.mDimOverlay.OwnedWindows.Count > 0)
			{
				using (IEnumerator enumerator = this.mDimOverlay.OwnedWindows.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						object obj = enumerator.Current;
						((Window)obj).Close();
					}
					goto IL_D4;
				}
			}
			if (KMManager.CanvasWindow != null && KMManager.CanvasWindow.SidebarWindow != null && KMManager.CanvasWindow.SidebarWindow.Visibility == Visibility.Visible)
			{
				KMManager.CanvasWindow.SidebarWindow.Close();
			}
			else if (KMManager.GuidanceWindow != null && KMManager.GuidanceWindow.Visibility == Visibility.Visible)
			{
				KMManager.GuidanceWindow.Close();
			}
			IL_D4:
			KMManager.ShowOverlayWindow(this, false, false);
			if (this.mOperationRecorderWindow != null)
			{
				this.mCommonHandler.HideOperationRecorderWindow();
			}
			this.mIsLockScreenActionPending = true;
			this.ShowDimOverlay(this.ScreenLockInstance);
		}

		// Token: 0x0600132D RID: 4909 RVA: 0x000770EC File Offset: 0x000752EC
		internal void HideLockScreen()
		{
			if (this.mDimOverlay == null || this.ScreenLockInstance.Visibility != Visibility.Visible)
			{
				return;
			}
			this.mIsLockScreenActionPending = false;
			this.HideDimOverlay();
			this.ShowWindow(false);
			base.Activate();
			if (RegistryManager.Instance.ShowKeyControlsOverlay && !KMManager.CheckIfKeymappingWindowVisible())
			{
				KMManager.ShowOverlayWindow(this, true, false);
			}
		}

		// Token: 0x0600132E RID: 4910 RVA: 0x00077148 File Offset: 0x00075348
		private void UpdateSynchronizationState()
		{
			this._TopBar.HideSyncPanel();
			if (this.mIsSyncMaster)
			{
				this.mSynchronizerWindow.StopAllSyncOperations();
				return;
			}
			if (BlueStacksUIUtils.sSyncInvolvedInstances.Contains(this.mVmName))
			{
				HTTPUtils.SendRequestToEngineAsync("stopSyncConsumer", null, this.mVmName, 0, null, false, 1, 0);
				BlueStacksUIUtils.sSyncInvolvedInstances.Remove(this.mVmName);
			}
			foreach (string text in BlueStacksUIUtils.DictWindows.Keys)
			{
				if (text != this.mVmName && BlueStacksUIUtils.DictWindows[text].mSelectedInstancesForSync.Contains(this.mVmName))
				{
					MainWindow mainWindow = BlueStacksUIUtils.DictWindows[text];
					mainWindow.mSelectedInstancesForSync.Remove(this.mVmName);
					if (mainWindow.mSelectedInstancesForSync.Count == 0)
					{
						mainWindow.mIsSynchronisationActive = false;
						mainWindow.mIsSyncMaster = false;
						if (BlueStacksUIUtils.sSyncInvolvedInstances.Contains(mainWindow.mVmName))
						{
							BlueStacksUIUtils.sSyncInvolvedInstances.Remove(mainWindow.mVmName);
						}
						mainWindow._TopBar.HideSyncPanel();
						mainWindow.mFrontendHandler.SendFrontendRequestAsync("stopOperationsSync", new Dictionary<string, string>());
					}
				}
			}
		}

		// Token: 0x06001332 RID: 4914 RVA: 0x0000D8FB File Offset: 0x0000BAFB
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 2)
			{
				((Grid)target).Loaded += this.ResizeGrid_Loaded;
			}
		}

		// Token: 0x04000CF6 RID: 3318
		private int mHeightDiff = 42;

		// Token: 0x04000CF7 RID: 3319
		private int mWidthDiff = 2;

		// Token: 0x04000CF8 RID: 3320
		private Mutex mBlueStacksClientInstanceLock;

		// Token: 0x04000CF9 RID: 3321
		private int heightDiffScaled = 42;

		// Token: 0x04000CFA RID: 3322
		private int widthDiffScaled = 2;

		// Token: 0x04000CFB RID: 3323
		internal Fraction mAspectRatio = new Fraction(16L, 9L);

		// Token: 0x04000CFC RID: 3324
		private const long OneGB = 1073741824L;

		// Token: 0x04000CFD RID: 3325
		internal int MinWidthScaled = 320;

		// Token: 0x04000CFE RID: 3326
		internal int MinHeightScaled = 190;

		// Token: 0x04000CFF RID: 3327
		internal bool mIsDmmMaximised;

		// Token: 0x04000D00 RID: 3328
		internal bool mIsDMMMaximizedFromPortrait;

		// Token: 0x04000D01 RID: 3329
		internal bool mIsDMMRecommendedWindowOpen = true;

		// Token: 0x04000D02 RID: 3330
		internal Rect DmmRestoreWindowRectangle = new Rect(0.0, 0.0, 0.0, 0.0);

		// Token: 0x04000D03 RID: 3331
		internal DMMFullScreenTopBar mDMMFST;

		// Token: 0x04000D04 RID: 3332
		internal DMMRecommendedWindow mDMMRecommendedWindow;

		// Token: 0x04000D05 RID: 3333
		private bool mIsWindowResizedOnce;

		// Token: 0x04000D06 RID: 3334
		internal bool mIsFullScreenFromMaximized;

		// Token: 0x04000D07 RID: 3335
		internal bool mIsStreaming;

		// Token: 0x04000D08 RID: 3336
		private bool isSetupDone;

		// Token: 0x04000D09 RID: 3337
		private double? mPreviousWidth;

		// Token: 0x04000D0A RID: 3338
		internal bool IsUIInPortraitMode;

		// Token: 0x04000D0B RID: 3339
		internal bool IsUIInPortraitModeWhenMaximized;

		// Token: 0x04000D0C RID: 3340
		private Grid mLastVisibleGrid;

		// Token: 0x04000D0D RID: 3341
		internal bool mIsFullScreen;

		// Token: 0x04000D0E RID: 3342
		internal static double sScalingFactor = 1.0;

		// Token: 0x04000D0F RID: 3343
		private static object syncRoot = new object();

		// Token: 0x04000D10 RID: 3344
		private IMConfig mSelectedConfig;

		// Token: 0x04000D11 RID: 3345
		private IMConfig mOriginalLoadedConfig;

		// Token: 0x04000D12 RID: 3346
		internal bool mClosed;

		// Token: 0x04000D13 RID: 3347
		private bool mIsGamepadConnected;

		// Token: 0x04000D14 RID: 3348
		internal Dictionary<string, bool> AppForcedOrientationDict = new Dictionary<string, bool>();

		// Token: 0x04000D15 RID: 3349
		private bool mSkipNextGamepadStatus;

		// Token: 0x04000D17 RID: 3351
		private Grid mResizeGrid;

		// Token: 0x04000D18 RID: 3352
		internal bool mIsResizing;

		// Token: 0x04000D19 RID: 3353
		internal EventHandler ResizeBegin;

		// Token: 0x04000D1A RID: 3354
		internal EventHandler ResizeEnd;

		// Token: 0x04000D1B RID: 3355
		private bool mClosing;

		// Token: 0x04000D1C RID: 3356
		internal bool mGuestBootCompleted;

		// Token: 0x04000D1D RID: 3357
		internal bool mEnableLaunchPlayForNCSoft;

		// Token: 0x04000D1E RID: 3358
		internal volatile bool mIsWindowInFocus;

		// Token: 0x04000D29 RID: 3369
		internal DateTime mBootStartTime = DateTime.Now;

		// Token: 0x04000D2A RID: 3370
		internal bool IsQuitPopupNotficationReceived;

		// Token: 0x04000D2B RID: 3371
		internal Grid mFirebaseBrowserControlGrid;

		// Token: 0x04000D2C RID: 3372
		internal static Dictionary<string, string> sMacroMapping = new Dictionary<string, string>();

		// Token: 0x04000D2D RID: 3373
		internal OperationsRecord mAutoRunMacro;

		// Token: 0x04000D2E RID: 3374
		private ScreenLockControl mScreenLock;

		// Token: 0x04000D2F RID: 3375
		internal static List<string> sMacroScriptNames = new List<string>();

		// Token: 0x04000D30 RID: 3376
		private MacroOverlay mMacroOverlay;

		// Token: 0x04000D31 RID: 3377
		internal CommonHandlers mCommonHandler;

		// Token: 0x04000D32 RID: 3378
		internal FrontendHandler mFrontendHandler;

		// Token: 0x04000D33 RID: 3379
		internal DownloadInstallApk mAppInstaller;

		// Token: 0x04000D34 RID: 3380
		internal AppHandler mAppHandler;

		// Token: 0x04000D35 RID: 3381
		internal bool mStreamingModeEnabled;

		// Token: 0x04000D36 RID: 3382
		internal PostOtsWelcomeWindowControl mPostOtsWelcomeWindow;

		// Token: 0x04000D37 RID: 3383
		private OperationRecorderWindow mOperationRecorderWindow;

		// Token: 0x04000D38 RID: 3384
		internal SynchronizerWindow mSynchronizerWindow;

		// Token: 0x04000D39 RID: 3385
		internal List<string> mSelectedInstancesForSync = new List<string>();

		// Token: 0x04000D3A RID: 3386
		internal bool mIsMacroPlaying;

		// Token: 0x04000D3B RID: 3387
		internal string mMacroPlaying = string.Empty;

		// Token: 0x04000D3C RID: 3388
		internal bool mIsScriptsPresent;

		// Token: 0x04000D3D RID: 3389
		internal System.Timers.Timer mMacroTimer;

		// Token: 0x04000D3E RID: 3390
		internal bool mIsSyncMaster;

		// Token: 0x04000D3F RID: 3391
		private BlueStacksUIUtils mUtils;

		// Token: 0x04000D40 RID: 3392
		internal WindowWndProcHandler mResizeHandler;

		// Token: 0x04000D41 RID: 3393
		private MainWindowsStaticComponents mStaticComponents;

		// Token: 0x04000D42 RID: 3394
		internal string mVmName = Strings.CurrentDefaultVmName;

		// Token: 0x04000D43 RID: 3395
		private bool mIsTokenAvailable;

		// Token: 0x04000D44 RID: 3396
		private readonly bool mIsWindowLoadedOnce;

		// Token: 0x04000D45 RID: 3397
		internal DimOverlayControl mDimOverlay;

		// Token: 0x04000D46 RID: 3398
		internal IntPtr Handle;

		// Token: 0x04000D47 RID: 3399
		internal bool mIsRestart;

		// Token: 0x04000D48 RID: 3400
		private Storyboard mStoryBoard;

		// Token: 0x04000D49 RID: 3401
		internal bool mIsOperationRecorderActive;

		// Token: 0x04000D4A RID: 3402
		public Discord mDiscordhandler;

		// Token: 0x04000D4B RID: 3403
		internal bool mIsSynchronisationActive;

		// Token: 0x04000D4C RID: 3404
		internal bool mStartupTabLaunched;

		// Token: 0x04000D4D RID: 3405
		internal bool mLaunchStartupTabWhenTokenReceived;

		// Token: 0x04000D4E RID: 3406
		private readonly SerialWorkQueue pikaNotificationWorkQueue = new SerialWorkQueue("pikaNotificationWorkQueue");

		// Token: 0x04000D4F RID: 3407
		private bool isPikaPopOpen;

		// Token: 0x04000D50 RID: 3408
		private readonly DispatcherTimer pikaNotificationTimer = new DispatcherTimer();

		// Token: 0x04000D51 RID: 3409
		private readonly DispatcherTimer toastTimer = new DispatcherTimer();

		// Token: 0x04000D52 RID: 3410
		private readonly DispatcherTimer mFullScreenToastTimer = new DispatcherTimer();

		// Token: 0x04000D53 RID: 3411
		internal QuitPopupBrowserControl mQuitPopupBrowserControl = new QuitPopupBrowserControl();

		// Token: 0x04000D54 RID: 3412
		private bool mIsLockScreenActionPending;

		// Token: 0x0200021B RID: 539
		// (Invoke) Token: 0x06001365 RID: 4965
		public delegate void GuestBootCompleted();

		// Token: 0x0200021C RID: 540
		// (Invoke) Token: 0x06001369 RID: 4969
		public delegate void CursorLockChanged(bool locked);

		// Token: 0x0200021D RID: 541
		// (Invoke) Token: 0x0600136D RID: 4973
		public delegate void FullScreenChanged(bool isFullScreen);

		// Token: 0x0200021E RID: 542
		// (Invoke) Token: 0x06001371 RID: 4977
		public delegate void FrontendGridVisibleChanged(bool isFullScreen);
	}
}
