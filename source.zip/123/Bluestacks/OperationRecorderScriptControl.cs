﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000088 RID: 136
	public class OperationRecorderScriptControl : UserControl, IComponentConnector
	{
		// Token: 0x17000149 RID: 329
		// (get) Token: 0x06000610 RID: 1552 RVA: 0x00006023 File Offset: 0x00004223
		// (set) Token: 0x06000611 RID: 1553 RVA: 0x0000602B File Offset: 0x0000422B
		public bool IsBookmarked
		{
			get
			{
				return this.mIsBookmarked;
			}
			set
			{
				this.mIsBookmarked = value;
				this.ToggleBookmarkIcon(value);
			}
		}

		// Token: 0x06000612 RID: 1554 RVA: 0x0000603B File Offset: 0x0000423B
		private void ToggleBookmarkIcon(bool isBookmarked)
		{
			if (isBookmarked)
			{
				this.mBookmarkImg.ImageName = "bookmarked";
				return;
			}
			this.mBookmarkImg.ImageName = "bookmark";
		}

		// Token: 0x06000613 RID: 1555 RVA: 0x00025D50 File Offset: 0x00023F50
		internal OperationRecorderScriptControl(MainWindow parentWindow, OperationsRecord record, OperationRecorderWindow operationRecorderWindow)
		{
			this.InitializeComponent();
			this.ParentWindow = parentWindow;
			this.mOperationRecorderWindow = operationRecorderWindow;
			this.mOperationRecord = record;
			InputMethod.SetIsInputMethodEnabled(this.mMacroShortcutTextBox, false);
			this.mTimestamp.Content = DateTime.ParseExact(this.mOperationRecord.TimeCreated, "yyyyMMddTHHmmss", CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal).ToString("yyyy.MM.dd HH.mm.ss");
			this.mScriptName.Text = this.mOperationRecord.Name;
			this.mMacroShortcutTextBox.Text = IMAPKeys.GetStringForUI(this.mOperationRecord.ShortCut);
			this.mScriptName.ToolTip = this.mScriptName.Text;
			if (!string.IsNullOrEmpty(this.mOperationRecord.ShortCut))
			{
				Key key = IMAPKeys.mDictKeys.FirstOrDefault((KeyValuePair<Key, string> x) => x.Value == this.mOperationRecord.ShortCut).Key;
				this.mMacroShortcutTextBox.Tag = IMAPKeys.GetStringForFile(key);
				MainWindow.sMacroMapping[this.mMacroShortcutTextBox.Tag.ToString()] = this.mScriptName.Text;
			}
			else
			{
				this.mMacroShortcutTextBox.Tag = "";
			}
			this.IsBookmarked = BlueStacksUIUtils.CheckIfMacroScriptBookmarked(this.mOperationRecord.Name);
			if (record.PlayOnStart)
			{
				this.mAutorunImage.Visibility = Visibility.Visible;
			}
			if (this.ParentWindow.mIsMacroPlaying && this.mOperationRecord.Name.Equals(this.ParentWindow.mMacroPlaying))
			{
				this.ToggleScriptPlayPauseUi(true);
				return;
			}
			this.ToggleScriptPlayPauseUi(false);
		}

		// Token: 0x06000614 RID: 1556 RVA: 0x00025EE4 File Offset: 0x000240E4
		public bool DeleteScriptNameFromBookmarkedScriptListIfPresent(string fileName)
		{
			if (RegistryManager.Instance.BookmarkedScriptList.Contains(fileName))
			{
				List<string> list = new List<string>(RegistryManager.Instance.BookmarkedScriptList);
				list.Remove(fileName);
				RegistryManager.Instance.BookmarkedScriptList = list.ToArray();
				return true;
			}
			return false;
		}

		// Token: 0x06000615 RID: 1557 RVA: 0x00025F30 File Offset: 0x00024130
		public bool AddScriptNameToBookmarkedScriptListIfNotPresent(string fileName)
		{
			if (!RegistryManager.Instance.BookmarkedScriptList.Contains(this.mOperationRecord.Name))
			{
				List<string> list = new List<string>(RegistryManager.Instance.BookmarkedScriptList);
				list.Add(fileName);
				RegistryManager.Instance.BookmarkedScriptList = list.ToArray();
				return true;
			}
			return false;
		}

		// Token: 0x06000616 RID: 1558 RVA: 0x00025F84 File Offset: 0x00024184
		private void UpdateMacroDeleteWindowSettings()
		{
			this.ParentWindow.EngineInstanceRegistry.ShowMacroDeletePopup = !this.mDeleteScriptMessageWindow.CheckBox.IsChecked.Value;
			this.mDeleteScriptMessageWindow = null;
		}

		// Token: 0x06000617 RID: 1559 RVA: 0x00025FC4 File Offset: 0x000241C4
		private void DeleteMacroScript()
		{
			string path = Path.Combine(RegistryStrings.OperationsScriptFolder, this.mOperationRecord.Name + ".json");
			if (File.Exists(path))
			{
				File.Delete(path);
				this.ParentWindow.mCommonHandler.RefreshOperationRecorderWindow();
			}
			if (this.mOperationRecord.ShortCut != null && MainWindow.sMacroMapping.ContainsKey(this.mOperationRecord.ShortCut))
			{
				MainWindow.sMacroMapping.Remove(this.mOperationRecord.ShortCut);
			}
			this.DeleteScriptNameFromBookmarkedScriptListIfPresent(this.mOperationRecord.Name);
			CommonHandlers.RefreshAllOperationRecorderWindow();
			MainWindow.sMacroScriptNames.Remove(this.mOperationRecord.Name.ToLower().Trim());
			if (this.ParentWindow.mAutoRunMacro != null && this.ParentWindow.mAutoRunMacro.Name.ToLower().Trim() == this.mOperationRecord.Name.ToLower().Trim())
			{
				this.ParentWindow.mAutoRunMacro = null;
			}
			this.ParentWindow.mCommonHandler.OnMacroDeleted(this.mOperationRecord.Name);
		}

		// Token: 0x06000618 RID: 1560 RVA: 0x00006061 File Offset: 0x00004261
		private void OperationRecorderScriptControl_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(this.mGrid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
			this.mEditNameImg.Visibility = Visibility.Visible;
		}

		// Token: 0x06000619 RID: 1561 RVA: 0x00006084 File Offset: 0x00004284
		private void OperationRecorderScriptControl_MouseLeave(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(this.mGrid, Panel.BackgroundProperty, "SettingsWindowBackground");
			this.mEditNameImg.Visibility = Visibility.Hidden;
		}

		// Token: 0x0600061A RID: 1562 RVA: 0x00004BF2 File Offset: 0x00002DF2
		private void PauseScriptImg_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
		}

		// Token: 0x0600061B RID: 1563 RVA: 0x000260EC File Offset: 0x000242EC
		private void StopScriptImg_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ToggleScriptPlayPauseUi(false);
			this.ParentWindow.mCommonHandler.StopMacroScriptHandling();
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_stop", null, null, null, null, null);
		}

		// Token: 0x0600061C RID: 1564 RVA: 0x000060A7 File Offset: 0x000042A7
		internal void ToggleScriptPlayPauseUi(bool isScriptRunning)
		{
			if (isScriptRunning)
			{
				this.mScriptPlayPanel.Visibility = Visibility.Collapsed;
				this.mScriptRunningPanel.Visibility = Visibility.Visible;
				return;
			}
			this.mScriptPlayPanel.Visibility = Visibility.Visible;
			this.mScriptRunningPanel.Visibility = Visibility.Collapsed;
		}

		// Token: 0x0600061D RID: 1565 RVA: 0x00026138 File Offset: 0x00024338
		private void ScriptSettingsImg_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mOperationRecorderWindow.mOverlayGrid.Visibility = Visibility.Visible;
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_window_settings", null, null, null, null, null);
			if (this.mMacroSettingsWindow == null)
			{
				this.mMacroSettingsWindow = new MacroSettingsWindow(this.ParentWindow, this.mOperationRecord, this);
			}
			this.mMacroSettingsWindow.Show();
		}

		// Token: 0x0600061E RID: 1566 RVA: 0x000261AC File Offset: 0x000243AC
		private void BookMarkScriptImg_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.IsBookmarked)
			{
				this.IsBookmarked = false;
				this.DeleteScriptNameFromBookmarkedScriptListIfPresent(this.mOperationRecord.Name);
				this.ParentWindow.mCommonHandler.OnMacroBookmarkChanged(this.mOperationRecord.Name, false);
			}
			else if (RegistryManager.Instance.BookmarkedScriptList.Length < 5)
			{
				this.IsBookmarked = true;
				this.AddScriptNameToBookmarkedScriptListIfNotPresent(this.mOperationRecord.Name);
				this.ParentWindow.mCommonHandler.OnMacroBookmarkChanged(this.mOperationRecord.Name, true);
			}
			else
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this.mOperationRecorderWindow, LocaleStrings.GetLocalizedString("STRING_BOOKMARK_MACRO_WARNING", false), 4.0, true);
			}
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_window_bookmark", null, null, null, null, null);
		}

		// Token: 0x0600061F RID: 1567 RVA: 0x00026294 File Offset: 0x00024494
		private void DeleteScriptImg_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (!this.ParentWindow.EngineInstanceRegistry.ShowMacroDeletePopup)
			{
				this.DeleteMacroScript();
				return;
			}
			this.mDeleteScriptMessageWindow = new CustomMessageWindow();
			this.mDeleteScriptMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_BLUESTACKS", false);
			this.mDeleteScriptMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_DELETE_SCRIPT", false);
			this.mDeleteScriptMessageWindow.CheckBox.Content = LocaleStrings.GetLocalizedString("STRING_DOWNLOAD_GOOGLE_APP_POPUP_STRING_04", false);
			this.mDeleteScriptMessageWindow.CheckBox.Visibility = Visibility.Visible;
			this.mDeleteScriptMessageWindow.CheckBox.IsChecked = new bool?(false);
			this.mDeleteScriptMessageWindow.AddButton(ButtonColors.Red, LocaleStrings.GetLocalizedString("STRING_YES", false), new EventHandler(this.UpdateSettingsAndDeleteMacro), null, false, null);
			this.mDeleteScriptMessageWindow.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_NO", false), delegate(object o, EventArgs evt)
			{
			}, null, false, null);
			this.mDeleteScriptMessageWindow.CloseButtonHandle(delegate(object o, EventArgs evt)
			{
			}, null);
			this.mDeleteScriptMessageWindow.Owner = this.ParentWindow;
			this.mDeleteScriptMessageWindow.ShowDialog();
		}

		// Token: 0x06000620 RID: 1568 RVA: 0x000060DD File Offset: 0x000042DD
		private void UpdateSettingsAndDeleteMacro(object sender, EventArgs e)
		{
			this.UpdateMacroDeleteWindowSettings();
			this.DeleteMacroScript();
		}

		// Token: 0x06000621 RID: 1569 RVA: 0x000263E4 File Offset: 0x000245E4
		private void PlayScriptImg_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (!this.ParentWindow.mIsMacroPlaying)
			{
				this.ToggleScriptPlayPauseUi(true);
				this.ParentWindow.mCommonHandler.PlayMacroScript(this.mOperationRecord);
				ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_play", "macro_popup", null, null, null, null);
				this.ParentWindow.mCommonHandler.HideOperationRecorderWindow();
				return;
			}
			this.ParentWindow.mCommonHandler.AddToastPopup(this.mOperationRecorderWindow, LocaleStrings.GetLocalizedString("STRING_STOP_THE_SCRIPT", false), 4.0, true);
		}

		// Token: 0x06000622 RID: 1570 RVA: 0x00026484 File Offset: 0x00024684
		private void EditMacroName_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.mEditNameImg.ImageName.Equals("edit_icon"))
			{
				e.Handled = true;
				this.mScriptName.IsEnabled = true;
				this.mEditNameImg.ImageName = "macro_name_save";
				this.mScriptName.Width = this.mScriptNameGrid.ActualWidth - this.mEditNameImg.ActualWidth - this.mTimestamp.ActualWidth - this.mPrefix.ActualWidth - 30.0;
				this.mLastScriptName = this.mScriptName.Text;
				this.mScriptName.Focusable = true;
				this.mScriptName.IsReadOnly = false;
				this.mScriptName.Focus();
				BlueStacksUIBinding.Bind(this.mEditNameImg, "STRING_SAVE");
				this.mScriptName.CaretIndex = this.mScriptName.Text.Length;
				return;
			}
			this.PerformSaveMacroNameOperations();
		}

		// Token: 0x06000623 RID: 1571 RVA: 0x0002657C File Offset: 0x0002477C
		private void PerformSaveMacroNameOperations()
		{
			this.mScriptName.IsEnabled = false;
			this.mScriptName.Focusable = false;
			this.mScriptName.IsReadOnly = true;
			this.mScriptName.BorderThickness = new Thickness(0.0);
			this.mEditNameImg.ImageName = "edit_icon";
			BlueStacksUIBinding.Bind(this.mEditNameImg, "STRING_RENAME");
			this.SaveMacroName();
		}

		// Token: 0x06000624 RID: 1572 RVA: 0x000265EC File Offset: 0x000247EC
		private void SaveMacroName()
		{
			if (string.IsNullOrEmpty(this.mScriptName.Text.Trim()))
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this.ParentWindow.OperationRecorderWindow, LocaleStrings.GetLocalizedString("STRING_MACRO_NAME_NULL_MESSAGE", false), 4.0, true);
				this.mScriptName.Text = this.mLastScriptName;
				return;
			}
			if (MainWindow.sMacroScriptNames.Contains(this.mScriptName.Text.ToLower().Trim()) && !(this.mScriptName.Text.ToLower().Trim() == this.mOperationRecord.Name.ToLower().Trim()))
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this.ParentWindow.OperationRecorderWindow, LocaleStrings.GetLocalizedString("STRING_MACRO_NOT_SAVED_MESSAGE", false), 4.0, true);
				this.mScriptName.Text = this.mLastScriptName;
				return;
			}
			if (this.mScriptName.Text.Trim().IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
			{
				string message = string.Format("{0} {1} {2}", LocaleStrings.GetLocalizedString("STRING_MACRO_NAME_ERROR", false), Environment.NewLine, "\\ / : * ? \" < > |");
				this.ParentWindow.mCommonHandler.AddToastPopup(this.ParentWindow.OperationRecorderWindow, message, 4.0, true);
				this.mScriptName.Text = this.mLastScriptName;
				return;
			}
			this.SaveScriptSettings();
		}

		// Token: 0x06000625 RID: 1573 RVA: 0x00026764 File Offset: 0x00024964
		private void SaveScriptSettings()
		{
			try
			{
				if (!(this.mOperationRecord.ShortCut == this.mMacroShortcutTextBox.Tag.ToString()) || !(this.mOperationRecord.Name.ToLower().Trim() == this.mScriptName.Text.ToLower().Trim()))
				{
					JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
					serializerSettings.Formatting = Formatting.Indented;
					string text = Path.Combine(RegistryStrings.OperationsScriptFolder, this.mOperationRecord.Name + ".json");
					if (this.mOperationRecord.ShortCut != this.mMacroShortcutTextBox.Tag.ToString())
					{
						if (!string.IsNullOrEmpty(this.mOperationRecord.ShortCut) && MainWindow.sMacroMapping.ContainsKey(this.mOperationRecord.ShortCut))
						{
							MainWindow.sMacroMapping.Remove(this.mOperationRecord.ShortCut);
						}
						if (this.mMacroShortcutTextBox.Tag != null && !string.IsNullOrEmpty(this.mMacroShortcutTextBox.Tag.ToString()))
						{
							MainWindow.sMacroMapping[this.mMacroShortcutTextBox.Tag.ToString()] = this.mScriptName.Text;
						}
						if (this.mOperationRecord.ShortCut != null && this.mMacroShortcutTextBox.Tag != null && !this.mOperationRecord.ShortCut.Equals(this.mMacroShortcutTextBox.Tag.ToString()))
						{
							ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_window_shortcutkey", null, null, null, null, null);
						}
						if (this.mMacroShortcutTextBox.Tag != null)
						{
							this.mOperationRecord.ShortCut = this.mMacroShortcutTextBox.Tag.ToString();
						}
						if (this.mOperationRecord.PlayOnStart)
						{
							this.ParentWindow.mAutoRunMacro = this.mOperationRecord;
						}
						string contents = JsonConvert.SerializeObject(this.mOperationRecord, serializerSettings);
						File.WriteAllText(text, contents);
					}
					if (this.mOperationRecord.Name.ToLower().Trim() != this.mScriptName.Text.ToLower().Trim())
					{
						string name = this.mOperationRecord.Name;
						MainWindow.sMacroScriptNames.Remove(this.mOperationRecord.Name.ToLower().Trim());
						MainWindow.sMacroScriptNames.Add(this.mScriptName.Text.ToLower().Trim());
						this.mOperationRecord.Name = this.mScriptName.Text.Trim();
						if (this.mOperationRecord.PlayOnStart)
						{
							this.ParentWindow.mAutoRunMacro = this.mOperationRecord;
						}
						string contents2 = JsonConvert.SerializeObject(this.mOperationRecord, serializerSettings);
						File.WriteAllText(text, contents2);
						string destFileName = Path.Combine(RegistryStrings.OperationsScriptFolder, this.mScriptName.Text.Trim() + ".json");
						File.Move(text, destFileName);
						if (this.IsBookmarked)
						{
							this.DeleteScriptNameFromBookmarkedScriptListIfPresent(name);
							this.AddScriptNameToBookmarkedScriptListIfNotPresent(this.mOperationRecord.Name);
						}
					}
					this.ParentWindow.mCommonHandler.OnMacroSettingChanged(this.mOperationRecord);
					CommonHandlers.RefreshAllOperationRecorderWindow();
					this.ParentWindow.mCommonHandler.ReloadMacroShortcutsForAllInstances();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in saving macro settings: " + ex.ToString());
			}
		}

		// Token: 0x06000626 RID: 1574 RVA: 0x000060EB File Offset: 0x000042EB
		private void NoSelection_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.mScriptName.SelectionLength = 0;
		}

		// Token: 0x06000627 RID: 1575 RVA: 0x00026AE4 File Offset: 0x00024CE4
		private bool Valid(Key key)
		{
			if (key == Key.Escape || key == Key.LeftAlt || key == Key.RightAlt || key == Key.LeftCtrl || key == Key.RightCtrl || key == Key.RightShift || key == Key.LeftShift || key == Key.Capital || key == Key.Return || key == Key.Space)
			{
				return false;
			}
			if (this.ParentWindow.mCommonHandler.mShortcutsConfigInstance != null)
			{
				string value = string.Format("{0} + {1} + {2}", IMAPKeys.GetStringForFile(Key.LeftCtrl), IMAPKeys.GetStringForFile(Key.LeftAlt), IMAPKeys.GetStringForFile(key));
				using (List<ShortcutKeys>.Enumerator enumerator = this.ParentWindow.mCommonHandler.mShortcutsConfigInstance.Shortcut.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						if (enumerator.Current.ShortcutKey.Equals(value))
						{
							this.ParentWindow.mCommonHandler.AddToastPopup(this.ParentWindow.OperationRecorderWindow, LocaleStrings.GetLocalizedString("STRING_ALREADY_IN_USE_MESSAGE", false), 4.0, true);
							return false;
						}
					}
				}
			}
			if (!MainWindow.sMacroMapping.ContainsKey(IMAPKeys.GetStringForFile(key)))
			{
				return true;
			}
			if (MainWindow.sMacroMapping[IMAPKeys.GetStringForFile(key)] != this.mOperationRecord.Name)
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this.ParentWindow.OperationRecorderWindow, LocaleStrings.GetLocalizedString("STRING_ALREADY_IN_USE_MESSAGE", false), 4.0, true);
				return false;
			}
			return true;
		}

		// Token: 0x06000628 RID: 1576 RVA: 0x00026C54 File Offset: 0x00024E54
		private void MacroShortcutPreviewKeyDown(object sender, KeyEventArgs e)
		{
			this.mMacroShortcutTextBox.Text = "";
			this.mMacroShortcutTextBox.Tag = "";
			Key key = (e.Key == Key.System) ? e.SystemKey : e.Key;
			if (IMAPKeys.mDictKeys.ContainsKey(key) && this.Valid(key))
			{
				this.mMacroShortcutTextBox.Text = IMAPKeys.GetStringForUI(key);
				this.mMacroShortcutTextBox.Tag = IMAPKeys.GetStringForFile(key);
			}
			else
			{
				this.mMacroShortcutTextBox.Text = "";
				this.mMacroShortcutTextBox.Tag = "";
			}
			e.Handled = true;
			this.SaveScriptSettings();
		}

		// Token: 0x06000629 RID: 1577 RVA: 0x000060F9 File Offset: 0x000042F9
		private void ScriptName_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Return)
			{
				this.PerformSaveMacroNameOperations();
			}
		}

		// Token: 0x0600062A RID: 1578 RVA: 0x0000610A File Offset: 0x0000430A
		private void ScriptName_LostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
		{
			this.PerformSaveMacroNameOperations();
		}

		// Token: 0x0600062B RID: 1579 RVA: 0x0000610A File Offset: 0x0000430A
		private void ScriptName_LostFocus(object sender, RoutedEventArgs e)
		{
			this.PerformSaveMacroNameOperations();
		}

		// Token: 0x0600062C RID: 1580 RVA: 0x00026D04 File Offset: 0x00024F04
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/operationrecorderscriptcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600062D RID: 1581 RVA: 0x00026D34 File Offset: 0x00024F34
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((OperationRecorderScriptControl)target).MouseEnter += this.OperationRecorderScriptControl_MouseEnter;
				((OperationRecorderScriptControl)target).MouseLeave += this.OperationRecorderScriptControl_MouseLeave;
				return;
			case 2:
				this.mGrid = (Grid)target;
				return;
			case 3:
				this.mBookmarkImg = (CustomPictureBox)target;
				this.mBookmarkImg.PreviewMouseLeftButtonUp += this.BookMarkScriptImg_PreviewMouseLeftButtonUp;
				return;
			case 4:
				this.mScriptNameGrid = (Grid)target;
				return;
			case 5:
				this.mScriptName = (CustomTextBox)target;
				this.mScriptName.PreviewLostKeyboardFocus += this.ScriptName_LostKeyboardFocus;
				this.mScriptName.LostFocus += this.ScriptName_LostFocus;
				this.mScriptName.MouseLeftButtonUp += this.NoSelection_MouseUp;
				this.mScriptName.KeyDown += this.ScriptName_KeyDown;
				return;
			case 6:
				this.mEditNameImg = (CustomPictureBox)target;
				this.mEditNameImg.MouseLeftButtonDown += this.EditMacroName_MouseDown;
				return;
			case 7:
				this.mTimestamp = (Label)target;
				return;
			case 8:
				this.mPrefix = (TextBlock)target;
				return;
			case 9:
				this.mMacroShortcutTextBox = (CustomTextBox)target;
				this.mMacroShortcutTextBox.PreviewKeyDown += this.MacroShortcutPreviewKeyDown;
				return;
			case 10:
				this.mScriptPlayPanel = (StackPanel)target;
				return;
			case 11:
				this.mAutorunImage = (CustomPictureBox)target;
				this.mAutorunImage.PreviewMouseLeftButtonUp += this.BookMarkScriptImg_PreviewMouseLeftButtonUp;
				return;
			case 12:
				this.mPlayScriptImg = (CustomPictureBox)target;
				this.mPlayScriptImg.PreviewMouseLeftButtonUp += this.PlayScriptImg_PreviewMouseLeftButtonUp;
				return;
			case 13:
				this.mScriptSettingsImg = (CustomPictureBox)target;
				this.mScriptSettingsImg.PreviewMouseLeftButtonUp += this.ScriptSettingsImg_PreviewMouseLeftButtonUp;
				return;
			case 14:
				this.mDeleteScriptImg = (CustomPictureBox)target;
				this.mDeleteScriptImg.PreviewMouseLeftButtonUp += this.DeleteScriptImg_PreviewMouseLeftButtonUp;
				return;
			case 15:
				this.mScriptRunningPanel = (StackPanel)target;
				return;
			case 16:
				this.mStopScriptImg = (CustomPictureBox)target;
				this.mStopScriptImg.PreviewMouseLeftButtonUp += this.StopScriptImg_PreviewMouseLeftButtonUp;
				return;
			case 17:
				this.mRunning = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040003ED RID: 1005
		private MainWindow ParentWindow;

		// Token: 0x040003EE RID: 1006
		internal OperationRecorderWindow mOperationRecorderWindow;

		// Token: 0x040003EF RID: 1007
		internal OperationsRecord mOperationRecord;

		// Token: 0x040003F0 RID: 1008
		internal MacroSettingsWindow mMacroSettingsWindow;

		// Token: 0x040003F1 RID: 1009
		private CustomMessageWindow mDeleteScriptMessageWindow;

		// Token: 0x040003F2 RID: 1010
		private bool mIsBookmarked;

		// Token: 0x040003F3 RID: 1011
		private string mLastScriptName;

		// Token: 0x040003F4 RID: 1012
		internal Grid mGrid;

		// Token: 0x040003F5 RID: 1013
		internal CustomPictureBox mBookmarkImg;

		// Token: 0x040003F6 RID: 1014
		internal Grid mScriptNameGrid;

		// Token: 0x040003F7 RID: 1015
		internal CustomTextBox mScriptName;

		// Token: 0x040003F8 RID: 1016
		internal CustomPictureBox mEditNameImg;

		// Token: 0x040003F9 RID: 1017
		internal Label mTimestamp;

		// Token: 0x040003FA RID: 1018
		internal TextBlock mPrefix;

		// Token: 0x040003FB RID: 1019
		internal CustomTextBox mMacroShortcutTextBox;

		// Token: 0x040003FC RID: 1020
		internal StackPanel mScriptPlayPanel;

		// Token: 0x040003FD RID: 1021
		internal CustomPictureBox mAutorunImage;

		// Token: 0x040003FE RID: 1022
		internal CustomPictureBox mPlayScriptImg;

		// Token: 0x040003FF RID: 1023
		internal CustomPictureBox mScriptSettingsImg;

		// Token: 0x04000400 RID: 1024
		internal CustomPictureBox mDeleteScriptImg;

		// Token: 0x04000401 RID: 1025
		internal StackPanel mScriptRunningPanel;

		// Token: 0x04000402 RID: 1026
		internal CustomPictureBox mStopScriptImg;

		// Token: 0x04000403 RID: 1027
		internal TextBlock mRunning;

		// Token: 0x04000404 RID: 1028
		private bool _contentLoaded;
	}
}
