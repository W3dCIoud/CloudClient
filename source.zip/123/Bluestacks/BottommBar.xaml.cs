﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000189 RID: 393
	public partial class BottommBar : UserControl
	{
		// Token: 0x170001F0 RID: 496
		// (get) Token: 0x06000E7F RID: 3711 RVA: 0x0000ABC7 File Offset: 0x00008DC7
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x06000E80 RID: 3712 RVA: 0x0005D248 File Offset: 0x0005B448
		public BottommBar()
		{
			this.InitializeComponent();
			string sLocale = LocaleStrings.sLocale;
			BlueStacksUIBinding.Bind(this.mKeyMappingPopUp1, "STRING_DEFAULT_KEYBOARD_MAPPING_SETTING_01", "");
			BlueStacksUIBinding.Bind(this.mKeyMappingPopUp3, "STRING_DEFAULT_KEYBOARD_MAPPING_SETTING_02", "");
			BlueStacksUIBinding.Bind(this.mKeyMappingDontShowPopUp, "STRING_DOWNLOAD_GOOGLE_APP_POPUP_STRING_04", "");
			base.Loaded += this.BottommBar_Loaded;
		}

		// Token: 0x06000E81 RID: 3713 RVA: 0x0005D2B8 File Offset: 0x0005B4B8
		private void BottommBar_Loaded(object sender, RoutedEventArgs e)
		{
			if (FeatureManager.Instance.IsCustomUIForDMMSandbox)
			{
				this.mGamePadButton.Visibility = Visibility.Collapsed;
				this.mKeyMapSwitchButton.Visibility = Visibility.Collapsed;
				this.mKeyMapButton.Visibility = Visibility.Collapsed;
				this.mTranslucentControlsButton.Visibility = Visibility.Collapsed;
				this.mRotateScreenButton.Visibility = Visibility.Collapsed;
				this.mLocationButton.Visibility = Visibility.Collapsed;
				this.mShakeButton.Visibility = Visibility.Collapsed;
				this.mKeyMapPopup.IsOpen = false;
				this.mScreenshotButton.Visibility = Visibility.Visible;
				this.mMoreButton.Visibility = Visibility.Collapsed;
			}
			this.mScreenRecorderButton.Visibility = (FeatureManager.Instance.IsAllowGameRecording ? Visibility.Visible : Visibility.Collapsed);
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				this.mHomeButton.Visibility = Visibility.Collapsed;
			}
			if (FeatureManager.Instance.IsRotateScreenDisabled)
			{
				this.mRotateScreenButton.Visibility = Visibility.Collapsed;
			}
			this.mMacroRecorderButton.Visibility = Visibility.Collapsed;
			this.transSlider.Value = RegistryManager.Instance.TranslucentControlsTransparency;
		}

		// Token: 0x06000E82 RID: 3714 RVA: 0x0000ABE8 File Offset: 0x00008DE8
		private void UserControl_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (!DesignerProperties.GetIsInDesignMode(this))
			{
				this.UpdateLayoutAndBounds();
				this.BottomBarButtonHandling();
			}
		}

		// Token: 0x06000E83 RID: 3715 RVA: 0x0000ABFE File Offset: 0x00008DFE
		private void BackButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked back button bottombar ");
			this.ParentWindow.mCommonHandler.BackButtonHandler(false);
		}

		// Token: 0x06000E84 RID: 3716 RVA: 0x0000AC1B File Offset: 0x00008E1B
		private void HomeButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked home button ");
			this.ParentWindow.mCommonHandler.HomeButtonHandler(true, false);
		}

		// Token: 0x06000E85 RID: 3717 RVA: 0x0000AC39 File Offset: 0x00008E39
		private void GamePadButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked GamePad control UI button ");
			this.GamePadButtonHandler();
		}

		// Token: 0x06000E86 RID: 3718 RVA: 0x0005D3B8 File Offset: 0x0005B5B8
		internal void GamePadButtonHandler()
		{
			KMManager.HandleInputMapperWindow(this.ParentWindow, true, "gamepad");
			ClientStats.SendMiscellaneousStatsAsync("GamePadButtonClicked", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "bottombar", null, null, null, null, null);
		}

		// Token: 0x06000E87 RID: 3719 RVA: 0x0000AC4B File Offset: 0x00008E4B
		private void GamePadButton_LayoutUpdated(object sender, EventArgs e)
		{
			if (this.mKeyMapPopup.IsOpen)
			{
				this.ActualKeymapPopup();
			}
		}

		// Token: 0x06000E88 RID: 3720 RVA: 0x0000AC60 File Offset: 0x00008E60
		private void MacroRecorder_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.OpenOperationRecorderWindow();
		}

		// Token: 0x06000E89 RID: 3721 RVA: 0x0005D400 File Offset: 0x0005B600
		private void KeyMapSwitchButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked keymap toggle button ");
			this.KeyMapSwitchButtonHandler();
			ClientStats.SendMiscellaneousStatsAsync("SwitchKeyMapClicked", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "bottombar", null, null, null, null, null);
		}

		// Token: 0x06000E8A RID: 3722 RVA: 0x0000AC72 File Offset: 0x00008E72
		internal void KeyMapSwitchButtonHandler()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (!KMManager.sIsComboRecordingOn)
				{
					if (this.mKeyMapSwitchButtonImage.ImageName.EndsWith("_off"))
					{
						this.mKeyMapSwitchButtonImage.ImageName = this.mKeyMapSwitchButtonImage.ImageName.Replace("_off", string.Empty);
						BlueStacksUIBinding.Bind(this.mKeyMapSwitchButtonImage, "STRING_KEY_MAPPING_ENABLED");
						this.ParentWindow.mFrontendHandler.EnableKeyMapping(true);
					}
					else
					{
						this.mKeyMapSwitchButtonImage.ImageName = this.mKeyMapSwitchButtonImage.ImageName + "_off";
						BlueStacksUIBinding.Bind(this.mKeyMapSwitchButtonImage, "STRING_KEY_MAPPING_DISABLED");
						this.ParentWindow.mFrontendHandler.EnableKeyMapping(false);
					}
					this.ParentWindow.mFullScreenTopBar.mKeyMapSwitchFullScreen.ImageName = this.mKeyMapSwitchButtonImage.ImageName;
					this.ParentWindow.mFullScreenTopBar.mKeyMapSwitchFullScreen.ToolTip = this.mKeyMapSwitchButtonImage.ToolTip;
				}
			}), new object[0]);
		}

		// Token: 0x06000E8B RID: 3723 RVA: 0x0000AC97 File Offset: 0x00008E97
		private void KeyMapButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked keymap control UI button ");
			this.ParentWindow.mCommonHandler.KeyMapButtonHandler("MouseClick", "bottombar");
		}

		// Token: 0x06000E8C RID: 3724 RVA: 0x0000AC4B File Offset: 0x00008E4B
		private void KeyMapButton_LayoutUpdated(object sender, EventArgs e)
		{
			if (this.mKeyMapPopup.IsOpen)
			{
				this.ActualKeymapPopup();
			}
		}

		// Token: 0x06000E8D RID: 3725 RVA: 0x0005D448 File Offset: 0x0005B648
		private void KeyMapButton_PreviewMouseRightButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info(" Right Click on keymap control UI button ");
			try
			{
				if ((Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl)) && (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt)))
				{
					KMManager.sIsDeveloperModeOn = true;
				}
				else
				{
					KMManager.sIsDeveloperModeOn = false;
				}
				KMManager.CloseWindows();
				KMManager.LoadIMActions(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName);
				KMManager.ShowAdvancedSettings(this.ParentWindow);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception on right click on keymap button: " + ex.ToString());
			}
		}

		// Token: 0x06000E8E RID: 3726 RVA: 0x0005D4EC File Offset: 0x0005B6EC
		private void TranslucentControlsButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			RegistryManager.Instance.ShowKeyControlsOverlay = true;
			RegistryManager.Instance.OverlayAvailablePromptEnabled = false;
			KMManager.ShowOverlayWindow(this.ParentWindow, true, true);
			this.mChangeTransparencyPopup.PlacementTarget = this.mTranslucentControlsButton;
			this.mChangeTransparencyPopup.IsOpen = true;
		}

		// Token: 0x06000E8F RID: 3727 RVA: 0x0000ACBD File Offset: 0x00008EBD
		private void TranslucentControlsButton_LayoutUpdated(object sender, EventArgs e)
		{
			if (this.mOverlayTooltip.IsOpen)
			{
				this.ActualOverlayTooltip(false);
			}
		}

		// Token: 0x06000E90 RID: 3728 RVA: 0x0005D53C File Offset: 0x0005B73C
		private void RotateScreenButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mIsUIInPortraitModeBeforeChange = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsPortraitModeTab;
			this.ParentWindow.AppForcedOrientationDict[this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName] = !this.mIsUIInPortraitModeBeforeChange;
			this.ParentWindow.ChangeOrientationFromClient(!this.mIsUIInPortraitModeBeforeChange, true);
			string arg = this.mIsUIInPortraitModeBeforeChange ? "landscape" : "portrait";
			ClientStats.SendMiscellaneousStatsAsync("RotateScreenButtonClicked", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "bottombar", arg, this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName, null, null, null);
		}

		// Token: 0x06000E91 RID: 3729 RVA: 0x0000ACD3 File Offset: 0x00008ED3
		private void FullScreenButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked fullscreen button ");
			this.ParentWindow.mCommonHandler.FullScreenButtonHandler("bottombar", "MouseClick");
		}

		// Token: 0x06000E92 RID: 3730 RVA: 0x0005D610 File Offset: 0x0005B810
		private void LocationButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked location button ");
			this.ParentWindow.mCommonHandler.LocationButtonHandler();
			ClientStats.SendMiscellaneousStatsAsync("bottombar", RegistryManager.Instance.UserGuid, "SetLocation", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06000E93 RID: 3731 RVA: 0x0000ACF9 File Offset: 0x00008EF9
		private void ScreenShotButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked screenshot button ");
			this.ParentWindow.mCommonHandler.ScreenShotButtonHandler();
		}

		// Token: 0x06000E94 RID: 3732 RVA: 0x0005D678 File Offset: 0x0005B878
		private void ShakeButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked shake button ");
			this.ParentWindow.mCommonHandler.ShakeButtonHandler();
			ClientStats.SendMiscellaneousStatsAsync("bottombar", RegistryManager.Instance.UserGuid, "SetLocation", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06000E95 RID: 3733 RVA: 0x0000AD15 File Offset: 0x00008F15
		private void MoreButton_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked more button options");
			this.mMoreButtonPopup.IsOpen = true;
		}

		// Token: 0x06000E96 RID: 3734 RVA: 0x0005D6E0 File Offset: 0x0005B8E0
		internal void BottomBarButtonHandling()
		{
			while (this.mHiddenButtonsPanel.Children.Count > 0)
			{
				Grid grid = this.mHiddenButtonsPanel.Children[0] as Grid;
				this.mHiddenButtonsPanel.Children.Remove(grid);
				this.AddToVisibleButtonPanel(grid);
			}
			double num = this.mBottomBarControls.ActualWidth - 140.0;
			double num2 = 40.0;
			int num3 = (int)(num / num2);
			int num4 = 0;
			bool flag = false;
			for (int i = 0; i < this.mVisibleButtonsPanel.Children.Count; i++)
			{
				Grid grid2 = this.mVisibleButtonsPanel.Children[i] as Grid;
				if (flag || num3 == 0)
				{
					this.mVisibleButtonsPanel.Children.Remove(grid2);
					this.AddToHiddenButtonPanel(grid2);
					i--;
				}
				else if (grid2.Visibility == Visibility.Visible)
				{
					num4++;
					if (num4 == num3)
					{
						flag = true;
					}
				}
			}
			if (this.mHiddenButtonsPanel.Children.Count > 0)
			{
				this.mMoreButton.Visibility = Visibility.Visible;
				return;
			}
			this.mMoreButton.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000E97 RID: 3735 RVA: 0x0005D7FC File Offset: 0x0005B9FC
		private void AddToVisibleButtonPanel(Grid grid)
		{
			grid.MouseEnter -= this.Grid_MouseEnter;
			grid.MouseLeave -= this.Grid_MouseLeave;
			grid.Children[1].Visibility = Visibility.Collapsed;
			this.mVisibleButtonsPanel.Children.Add(grid);
			if (grid == this.mTranslucentControlsButton)
			{
				this.mChangeTransparencyPopup.Placement = PlacementMode.Top;
				this.mChangeTransparencyPopup.VerticalOffset = -10.0;
				this.mChangeTransparencyPopup.HorizontalOffset = 0.0;
			}
			if (grid == this.mKeyMapSwitchButton)
			{
				grid.Margin = new Thickness(5.0, 0.0, -8.0, 0.0);
			}
		}

		// Token: 0x06000E98 RID: 3736 RVA: 0x0005D8C8 File Offset: 0x0005BAC8
		private void AddToHiddenButtonPanel(Grid grid)
		{
			grid.MouseEnter += this.Grid_MouseEnter;
			grid.MouseLeave += this.Grid_MouseLeave;
			grid.Children[1].Visibility = Visibility.Visible;
			this.mHiddenButtonsPanel.Children.Add(grid);
			if (grid == this.mTranslucentControlsButton)
			{
				this.mChangeTransparencyPopup.Placement = PlacementMode.Right;
				this.mChangeTransparencyPopup.VerticalOffset = -100.0;
				this.mChangeTransparencyPopup.HorizontalOffset = 7.0;
			}
			if (grid == this.mKeyMapSwitchButton)
			{
				grid.Margin = new Thickness(5.0, 0.0, 5.0, 0.0);
			}
		}

		// Token: 0x06000E99 RID: 3737 RVA: 0x0005D994 File Offset: 0x0005BB94
		internal void UpdateLayoutAndBounds()
		{
			if (this.mKeyMapPopup.IsOpen)
			{
				this.ShowKeyMapPopup(true);
			}
			if (this.mOverlayTooltip.IsOpen)
			{
				this.ShowOverlayTooltip(true, false);
			}
			if (KMManager.CanvasWindow != null && KMManager.CanvasWindow.IsVisible)
			{
				KMManager.CloseWindows();
				ThreadPool.QueueUserWorkItem(delegate(object stateInfo)
				{
					Thread.Sleep(500);
					base.Dispatcher.Invoke(new Action(delegate()
					{
						KMManager.ShowAdvancedSettings(this.ParentWindow);
					}), new object[0]);
				});
			}
		}

		// Token: 0x06000E9A RID: 3738 RVA: 0x0005D9F4 File Offset: 0x0005BBF4
		internal void ShowOverlayTooltip(bool isShow, bool force = false)
		{
			if (FeatureManager.Instance.IsCustomUIForDMMSandbox || FeatureManager.Instance.IsCustomUIForDMM || !RegistryManager.Instance.OverlayAvailablePromptEnabled)
			{
				return;
			}
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (isShow)
				{
					this.mIsPendingShowOverlayTooltip = true;
					this.ActualOverlayTooltip(force);
					return;
				}
				this.mKeyMapPopup.IsOpen = false;
				this.mOverlayTooltip.IsOpen = false;
			}), new object[0]);
		}

		// Token: 0x06000E9B RID: 3739 RVA: 0x0005DA60 File Offset: 0x0005BC60
		internal void ShowKeyMapPopup(bool isShow)
		{
			if (FeatureManager.Instance.IsCustomUIForDMMSandbox)
			{
				return;
			}
			if (!isShow)
			{
				this.mIsPendingKeyMapTooltip = false;
				this.mKeyMapPopup.IsOpen = false;
				return;
			}
			if (RegistryManager.Instance.IsAutoShowGuidance)
			{
				KMManager.HandleInputMapperWindow(this.ParentWindow, false, "default");
				return;
			}
			this.mIsPendingKeyMapTooltip = true;
			this.ActualKeymapPopup();
		}

		// Token: 0x06000E9C RID: 3740 RVA: 0x0000AD2D File Offset: 0x00008F2D
		private void NotificaitonPopup_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (!this.mTranslucentControlsButton.IsMouseOver)
			{
				this.mMoreButtonPopup.IsOpen = false;
			}
		}

		// Token: 0x06000E9D RID: 3741 RVA: 0x00005628 File Offset: 0x00003828
		private void Grid_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x06000E9E RID: 3742 RVA: 0x000046FF File Offset: 0x000028FF
		private void Grid_MouseLeave(object sender, MouseEventArgs e)
		{
			(sender as Grid).Background = Brushes.Transparent;
		}

		// Token: 0x06000E9F RID: 3743 RVA: 0x0000AD48 File Offset: 0x00008F48
		private void KeyMapPopup_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.KeyMapButtonHandler("MouseClick", "bottombarpopup");
		}

		// Token: 0x06000EA0 RID: 3744 RVA: 0x0000AD64 File Offset: 0x00008F64
		private void ClosePopup_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mKeyMapPopup.IsOpen = false;
			e.Handled = true;
		}

		// Token: 0x06000EA1 RID: 3745 RVA: 0x0005DABC File Offset: 0x0005BCBC
		private void DoNotPromptManageGP_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mDoNotPromptChkBx.ImageName.Equals("bgpcheckbox"))
			{
				this.mDoNotPromptChkBx.ImageName = "bgpcheckbox_checked";
				RegistryManager.Instance.KeyMappingAvailablePromptEnabled = false;
			}
			else
			{
				this.mDoNotPromptChkBx.ImageName = "bgpcheckbox";
				RegistryManager.Instance.KeyMappingAvailablePromptEnabled = true;
			}
			e.Handled = true;
		}

		// Token: 0x06000EA2 RID: 3746 RVA: 0x0005DB20 File Offset: 0x0005BD20
		private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			KMManager.ChangeTransparency(this.ParentWindow, this.transSlider.Value);
			if (this.transSlider.Value == 0.0)
			{
				if (!RegistryManager.Instance.ShowKeyControlsOverlay)
				{
					KMManager.ShowOverlayWindow(this.ParentWindow, false, false);
				}
			}
			else
			{
				KMManager.ShowOverlayWindow(this.ParentWindow, true, false);
			}
			this.mLastSliderValue = this.transSlider.Value;
		}

		// Token: 0x06000EA3 RID: 3747 RVA: 0x0005DB94 File Offset: 0x0005BD94
		private void mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.transSlider.Value == 0.0)
			{
				this.transSlider.Value = this.mLastSliderValue;
				return;
			}
			double value = this.transSlider.Value;
			this.transSlider.Value = 0.0;
			this.mLastSliderValue = value;
		}

		// Token: 0x06000EA4 RID: 3748 RVA: 0x0000AD79 File Offset: 0x00008F79
		private void CustomPictureBox_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mOverlayTooltip.IsOpen = false;
			this.mIsOverlayTooltipClosed = true;
			e.Handled = true;
		}

		// Token: 0x06000EA5 RID: 3749 RVA: 0x0005DBF0 File Offset: 0x0005BDF0
		private void mDoNotShowChkBx_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mDoNotShowChkBx.ImageName.Equals("bgpcheckbox"))
			{
				this.mDoNotShowChkBx.ImageName = "bgpcheckbox_checked";
				RegistryManager.Instance.OverlayAvailablePromptEnabled = false;
			}
			else
			{
				this.mDoNotShowChkBx.ImageName = "bgpcheckbox";
				RegistryManager.Instance.OverlayAvailablePromptEnabled = true;
			}
			e.Handled = true;
		}

		// Token: 0x06000EA6 RID: 3750 RVA: 0x0000AD95 File Offset: 0x00008F95
		private void ActualKeymapPopup()
		{
			if (RegistryManager.Instance.KeyMappingAvailablePromptEnabled)
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					if (this.mKeyMapPopup.PlacementTarget != this.mKeyMapButton)
					{
						this.mKeyMapPopup.PlacementTarget = this.mKeyMapButton;
					}
					this.mKeyMapPopup.VerticalOffset += 1.0;
					this.mKeyMapPopup.VerticalOffset -= 1.0;
					if ((!RegistryManager.Instance.OverlayAvailablePromptEnabled || this.mIsOverlayTooltipClosed) && this.mIsPendingKeyMapTooltip)
					{
						this.mKeyMapPopup.IsOpen = true;
					}
				}), new object[0]);
			}
		}

		// Token: 0x06000EA7 RID: 3751 RVA: 0x0005DC54 File Offset: 0x0005BE54
		private void ActualOverlayTooltip(bool force = false)
		{
			if (this.mOverlayTooltip.PlacementTarget != this.mTranslucentControlsButton)
			{
				this.mOverlayTooltip.PlacementTarget = this.mTranslucentControlsButton;
			}
			this.mOverlayTooltip.VerticalOffset += 1.0;
			this.mOverlayTooltip.VerticalOffset -= 1.0;
			if (RegistryManager.Instance.OverlayAvailablePromptEnabled && !this.mIsOverlayTooltipClosed && this.mIsPendingShowOverlayTooltip && (!RegistryManager.Instance.IsAutoShowGuidance || force) && !this.ParentWindow.mIsFullScreen)
			{
				this.mIsPendingShowOverlayTooltip = false;
				this.mOverlayTooltip.IsOpen = true;
			}
		}

		// Token: 0x06000EA8 RID: 3752 RVA: 0x0000ADC1 File Offset: 0x00008FC1
		private void LockCursorButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.ClipMouseCursorHandler(false, true, "MouseClick", "bottombar");
		}

		// Token: 0x06000EA9 RID: 3753 RVA: 0x0005DD08 File Offset: 0x0005BF08
		private void LockCursorButton_MouseEnter(object sender, MouseEventArgs e)
		{
			if (!this.mLockCursorPopup.IsOpen)
			{
				if (this.mLockCursorPopup.PlacementTarget != this.mLockCursorButton)
				{
					this.mLockCursorPopup.PlacementTarget = this.mLockCursorButton;
				}
				this.mLockCursorPopup.VerticalOffset += 1.0;
				this.mLockCursorPopup.VerticalOffset -= 1.0;
				this.mLockCursorPopup.IsOpen = true;
			}
		}

		// Token: 0x06000EAA RID: 3754 RVA: 0x0000ADDF File Offset: 0x00008FDF
		private void LockCursorButton_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mLockCursorPopup.IsOpen = false;
		}

		// Token: 0x06000EAB RID: 3755 RVA: 0x0005DD88 File Offset: 0x0005BF88
		private void SyncButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.ShowSynchronizerWindow();
			ClientStats.SendMiscellaneousStatsAsync("bottombar", RegistryManager.Instance.UserGuid, "OperationSync", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06000EAC RID: 3756 RVA: 0x0005DDE0 File Offset: 0x0005BFE0
		private void ScreenRecorderButton_MouseEnter(object sender, MouseEventArgs e)
		{
			Logger.Info("ScreenRecorderButton_MouseEnter");
			if (!this.mRecordScreenPopup.IsOpen)
			{
				if (this.mRecordScreenPopup.PlacementTarget != this.mScreenRecorderButton)
				{
					this.mRecordScreenPopup.PlacementTarget = this.mScreenRecorderButton;
				}
				this.mRecordScreenPopup.VerticalOffset += 1.0;
				this.mRecordScreenPopup.VerticalOffset -= 1.0;
				this.mRecordScreenPopup.IsOpen = true;
			}
		}

		// Token: 0x06000EAD RID: 3757 RVA: 0x0000ADED File Offset: 0x00008FED
		private void ScreenRecorderButton_MouseLeave(object sender, MouseEventArgs e)
		{
			Logger.Info("ScreenRecorderButton_MouseLeave");
			if (this.ParentWindow.mBottomBar.RecordScreenPopupBody.Text != LocaleStrings.GetLocalizedString("STRING_CLICK_TO_SEE_VIDEO", false))
			{
				this.mRecordScreenPopup.IsOpen = false;
			}
		}

		// Token: 0x06000EAE RID: 3758 RVA: 0x0000AE2C File Offset: 0x0000902C
		private void ScreenRecorderButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.DownloadAndLaunchRecording("bottombar", "MouseClick");
		}

		// Token: 0x06000EAF RID: 3759 RVA: 0x0000AE48 File Offset: 0x00009048
		private void RecordScreenPopupClose_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mRecordScreenPopup.IsOpen = false;
		}

		// Token: 0x06000EB0 RID: 3760 RVA: 0x0005DE6C File Offset: 0x0005C06C
		private void RecordScreenPopup_Closed(object sender, EventArgs e)
		{
			if (CommonHandlers.sIsRecordingVideo && CommonHandlers.sRecordingInstance == this.ParentWindow.mVmName)
			{
				BlueStacksUIBinding.Bind(this.RecordScreenPopupHeader, "STRING_STOP_RECORDING", "");
				this.RecordScreenPopupHeader.Visibility = Visibility.Visible;
				this.RecordScreenPopupBody.Visibility = Visibility.Collapsed;
				this.RecordScreenPopupHyperlink.Visibility = Visibility.Collapsed;
				this.mRecordScreenClose.Visibility = Visibility.Collapsed;
			}
			else
			{
				BlueStacksUIBinding.Bind(this.RecordScreenPopupHeader, "STRING_RECORD_SCREEN", "");
				BlueStacksUIBinding.Bind(this.RecordScreenPopupBody, "STRING_RECORD_SCREEN_PLAYING", "");
				this.RecordScreenPopupHeader.Visibility = Visibility.Visible;
				this.RecordScreenPopupBody.Visibility = Visibility.Visible;
				this.mRecordScreenClose.Visibility = Visibility.Collapsed;
				this.RecordScreenPopupHyperlink.Visibility = Visibility.Collapsed;
			}
			this.mRecordScreenPopup.StaysOpen = true;
			this.RecordScreenPopupHyperlink.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000EB1 RID: 3761 RVA: 0x0005DF50 File Offset: 0x0005C150
		private void RecordScreenPopupHyperlink_Click(object sender, RoutedEventArgs e)
		{
			if (Directory.Exists(RegistryManager.Instance.ScreenShotsPath))
			{
				new Process
				{
					StartInfo = 
					{
						UseShellExecute = true,
						FileName = RegistryManager.Instance.ScreenShotsPath
					}
				}.Start();
			}
			this.mRecordScreenPopup.IsOpen = false;
		}

		// Token: 0x06000EB2 RID: 3762 RVA: 0x0005DFA8 File Offset: 0x0005C1A8
		private void RecordScreenClose_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if ((bool)e.NewValue)
			{
				this.RecordScreenPopupHeader.Margin = new Thickness(0.0, 0.0, 20.0, 0.0);
				return;
			}
			this.RecordScreenPopupHeader.Margin = new Thickness(0.0);
		}

		// Token: 0x04000A19 RID: 2585
		internal bool mIsUIInPortraitModeBeforeChange;

		// Token: 0x04000A1A RID: 2586
		internal bool mIsOverlayTooltipClosed;

		// Token: 0x04000A1B RID: 2587
		private bool mIsPendingShowOverlayTooltip;

		// Token: 0x04000A1C RID: 2588
		private bool mIsPendingKeyMapTooltip;

		// Token: 0x04000A1D RID: 2589
		internal double mLastSliderValue;

		// Token: 0x04000A1E RID: 2590
		private MainWindow mMainWindow;
	}
}
