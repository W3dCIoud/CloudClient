﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000EC RID: 236
	[Flags]
	public enum RawMouseFlags : ushort
	{
		// Token: 0x04000748 RID: 1864
		MoveRelative = 0,
		// Token: 0x04000749 RID: 1865
		MoveAbsolute = 1,
		// Token: 0x0400074A RID: 1866
		VirtualDesktop = 2,
		// Token: 0x0400074B RID: 1867
		AttributesChanged = 4
	}
}
