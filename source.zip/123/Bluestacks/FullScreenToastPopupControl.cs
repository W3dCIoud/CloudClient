﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media.Animation;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200005A RID: 90
	public class FullScreenToastPopupControl : UserControl, IComponentConnector
	{
		// Token: 0x060003E4 RID: 996 RVA: 0x000049F0 File Offset: 0x00002BF0
		public FullScreenToastPopupControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x060003E5 RID: 997 RVA: 0x0001AB34 File Offset: 0x00018D34
		public FullScreenToastPopupControl(MainWindow window)
		{
			this.InitializeComponent();
			if (window != null)
			{
				this.ParentWindow = window;
				Grid grid = new Grid();
				object content = window.Content;
				window.Content = grid;
				grid.Children.Add(content as UIElement);
				grid.Children.Add(this);
			}
		}

		// Token: 0x060003E6 RID: 998 RVA: 0x0001AB8C File Offset: 0x00018D8C
		public void Init(MainWindow window, string text)
		{
			if (window != null)
			{
				this.ParentWindow = window;
			}
			this.mToastTextblock.Text = text;
			this.mToastTextblock.TextWrapping = TextWrapping.WrapWithOverflow;
			this.mToastTextblock.MaxWidth = this.ParentWindow.ActualWidth - 15.0;
			this.mToastTextblock.TextAlignment = TextAlignment.Center;
		}

		// Token: 0x060003E7 RID: 999 RVA: 0x0001ABE8 File Offset: 0x00018DE8
		public void ShowPopup(double seconds = 4.0)
		{
			base.Visibility = Visibility.Visible;
			base.Opacity = 0.0;
			DoubleAnimation doubleAnimation = new DoubleAnimation
			{
				From = new double?(0.0),
				To = new double?(seconds),
				Duration = new Duration(TimeSpan.FromSeconds(0.3))
			};
			Storyboard storyboard = new Storyboard();
			storyboard.Children.Add(doubleAnimation);
			Storyboard.SetTarget(doubleAnimation, this);
			Storyboard.SetTargetProperty(doubleAnimation, new PropertyPath(UIElement.OpacityProperty));
			storyboard.Completed += delegate(object <p0>, EventArgs <p1>)
			{
				this.Visibility = Visibility.Visible;
				DoubleAnimation doubleAnimation2 = new DoubleAnimation
				{
					From = new double?(seconds),
					To = new double?(0.0),
					FillBehavior = FillBehavior.Stop,
					BeginTime = new TimeSpan?(TimeSpan.FromSeconds(seconds)),
					Duration = new Duration(TimeSpan.FromSeconds(seconds / 2.0))
				};
				Storyboard storyboard2 = new Storyboard();
				storyboard2.Children.Add(doubleAnimation2);
				Storyboard.SetTarget(doubleAnimation2, this);
				Storyboard.SetTargetProperty(doubleAnimation2, new PropertyPath(UIElement.OpacityProperty));
				storyboard2.Completed += delegate(object <p0>, EventArgs <p1>)
				{
					this.Visibility = Visibility.Collapsed;
				};
				storyboard2.Begin();
			};
			storyboard.Begin();
		}

		// Token: 0x060003E8 RID: 1000 RVA: 0x000049FE File Offset: 0x00002BFE
		private void ToastIcon_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.CloseFullScreenToastAndStopTimer();
		}

		// Token: 0x060003E9 RID: 1001 RVA: 0x0001ACA4 File Offset: 0x00018EA4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/fullscreentoastpopupcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060003EA RID: 1002 RVA: 0x0001ACD4 File Offset: 0x00018ED4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mToastPopupBorder = (Border)target;
				return;
			case 2:
				this.mMaskBorder = (Border)target;
				return;
			case 3:
				this.mToastTextblock = (TextBlock)target;
				return;
			case 4:
				this.mToastIcon = (CustomPictureBox)target;
				this.mToastIcon.MouseLeftButtonUp += this.ToastIcon_MouseLeftButtonUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000237 RID: 567
		private MainWindow ParentWindow;

		// Token: 0x04000238 RID: 568
		internal Border mToastPopupBorder;

		// Token: 0x04000239 RID: 569
		internal Border mMaskBorder;

		// Token: 0x0400023A RID: 570
		internal TextBlock mToastTextblock;

		// Token: 0x0400023B RID: 571
		internal CustomPictureBox mToastIcon;

		// Token: 0x0400023C RID: 572
		private bool _contentLoaded;
	}
}
