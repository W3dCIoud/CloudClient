﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000158 RID: 344
	public class ClientStatsEvent
	{
		// Token: 0x170001D9 RID: 473
		// (get) Token: 0x06000D2E RID: 3374 RVA: 0x0000A2B2 File Offset: 0x000084B2
		public static string UpgradePopup
		{
			get
			{
				return "upgrade_popup";
			}
		}

		// Token: 0x170001DA RID: 474
		// (get) Token: 0x06000D2F RID: 3375 RVA: 0x0000A2B9 File Offset: 0x000084B9
		public static string UpgradePopupCross
		{
			get
			{
				return "upgrade_popup_cross";
			}
		}

		// Token: 0x170001DB RID: 475
		// (get) Token: 0x06000D30 RID: 3376 RVA: 0x0000A2C0 File Offset: 0x000084C0
		public static string UpgradePopupDwnld
		{
			get
			{
				return "upgrade_popup_dwnld";
			}
		}

		// Token: 0x170001DC RID: 476
		// (get) Token: 0x06000D31 RID: 3377 RVA: 0x0000A2C7 File Offset: 0x000084C7
		public static string SettingsGearDwnld
		{
			get
			{
				return "settingsgear_dwnld";
			}
		}

		// Token: 0x170001DD RID: 477
		// (get) Token: 0x06000D32 RID: 3378 RVA: 0x0000A2CE File Offset: 0x000084CE
		public static string InstallPopupNow
		{
			get
			{
				return "install_popup_now";
			}
		}

		// Token: 0x170001DE RID: 478
		// (get) Token: 0x06000D33 RID: 3379 RVA: 0x0000A2D5 File Offset: 0x000084D5
		public static string InstallPopupLater
		{
			get
			{
				return "install_popup_later";
			}
		}

		// Token: 0x170001DF RID: 479
		// (get) Token: 0x06000D34 RID: 3380 RVA: 0x0000A2DC File Offset: 0x000084DC
		public static string InstallPopupCross
		{
			get
			{
				return "install_popup_cross";
			}
		}

		// Token: 0x170001E0 RID: 480
		// (get) Token: 0x06000D35 RID: 3381 RVA: 0x0000A2E3 File Offset: 0x000084E3
		public static string SettingCheckUpdate
		{
			get
			{
				return "setting_check_update";
			}
		}

		// Token: 0x170001E1 RID: 481
		// (get) Token: 0x06000D36 RID: 3382 RVA: 0x0000A2EA File Offset: 0x000084EA
		public static string SettingUpdateAvailable
		{
			get
			{
				return "setting_update_available";
			}
		}

		// Token: 0x170001E2 RID: 482
		// (get) Token: 0x06000D37 RID: 3383 RVA: 0x0000A2F1 File Offset: 0x000084F1
		public static string SettingUpdateNotAvailable
		{
			get
			{
				return "setting_update_not_available";
			}
		}

		// Token: 0x170001E3 RID: 483
		// (get) Token: 0x06000D38 RID: 3384 RVA: 0x0000A2F8 File Offset: 0x000084F8
		public static string SettingDownloadUpdate
		{
			get
			{
				return "setting_download_update";
			}
		}

		// Token: 0x170001E4 RID: 484
		// (get) Token: 0x06000D39 RID: 3385 RVA: 0x0000A2FF File Offset: 0x000084FF
		public static string SettingInstallUpdate
		{
			get
			{
				return "setting_install_update";
			}
		}
	}
}
