﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;
using BlueStacks.Common;
using Microsoft.VisualBasic.FileIO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000142 RID: 322
	public class FileImporter
	{
		// Token: 0x06000C70 RID: 3184
		[DllImport("urlmon.dll", CharSet = CharSet.Auto)]
		private static extern uint FindMimeFromData(uint pBC, [MarshalAs(UnmanagedType.LPStr)] string pwzUrl, [MarshalAs(UnmanagedType.LPArray)] byte[] pBuffer, uint cbSize, [MarshalAs(UnmanagedType.LPStr)] string pwzMimeProposed, uint dwMimeFlags, out uint ppwzMimeOut, uint dwReserverd);

		// Token: 0x06000C71 RID: 3185 RVA: 0x00009992 File Offset: 0x00007B92
		internal static void Init(MainWindow window)
		{
			window.AllowDrop = true;
			window.DragEnter += FileImporter.HandleDragEnter;
			window.Drop += FileImporter.HandleDragDrop;
		}

		// Token: 0x06000C72 RID: 3186 RVA: 0x000099BF File Offset: 0x00007BBF
		private static void HandleDragDrop(object sender, DragEventArgs e)
		{
			new Thread(delegate()
			{
				FileImporter.HandleDragDropAsync(e, sender as MainWindow);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000C73 RID: 3187 RVA: 0x000099F0 File Offset: 0x00007BF0
		private static bool IsSharedFolderEnabled(int fileSystem)
		{
			if (fileSystem == 0)
			{
				Logger.Info("Shared folders disabled");
				return false;
			}
			return true;
		}

		// Token: 0x06000C74 RID: 3188 RVA: 0x000546AC File Offset: 0x000528AC
		private static void HandleDragDropAsync(DragEventArgs evt, MainWindow window)
		{
			string mVmName = window.mVmName;
			if (FileImporter.IsSharedFolderEnabled(window.EngineInstanceRegistry.FileSystem))
			{
				try
				{
					Array array = (Array)evt.Data.GetData(DataFormats.FileDrop);
					List<string> list = new List<string>();
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					for (int i = 0; i < array.Length; i++)
					{
						string text = array.GetValue(i).ToString();
						string fileName = Path.GetFileName(text);
						if (string.Equals(Path.GetExtension(text), ".apk", StringComparison.InvariantCultureIgnoreCase) || string.Equals(Path.GetExtension(text), ".xapk", StringComparison.InvariantCultureIgnoreCase))
						{
							list.Add(text);
						}
						else
						{
							dictionary.Add(fileName, text);
						}
					}
					string text2 = RegistryStrings.SharedFolderDir;
					if (dictionary.Count > 0)
					{
						string text3 = Utils.CreateRandomBstSharedFolder(text2);
						text2 = Path.Combine(RegistryStrings.SharedFolderDir, text3);
						Logger.Info("Shared Folder path : " + text2);
						foreach (KeyValuePair<string, string> keyValuePair in dictionary)
						{
							Logger.Info("DragDrop File: {0}", new object[]
							{
								keyValuePair.Key
							});
							string text4 = Path.Combine(text2, keyValuePair.Key);
							try
							{
								FileSystem.CopyFile(keyValuePair.Value, text4, UIOption.AllDialogs);
								File.SetAttributes(text4, FileAttributes.Normal);
							}
							catch (Exception ex)
							{
								Logger.Error("Failed to copy file : " + keyValuePair.Value + "...Err : " + ex.ToString());
							}
						}
						JArray jarray = new JArray
						{
							new JObject
							{
								new JProperty("foldername", text3)
							}
						};
						Dictionary<string, string> dictionary2 = new Dictionary<string, string>();
						dictionary2.Add("data", jarray.ToString(Formatting.None, new JsonConverter[0]));
						Logger.Info("Sending drag drop request: " + jarray.ToString());
						try
						{
							HTTPUtils.SendRequestToGuest("fileDrop", dictionary2, mVmName, 0, null, false, 1, 0);
						}
						catch (Exception ex2)
						{
							Logger.Error("Failed to send FileDrop request. err: " + ex2.ToString());
						}
					}
					if (list.Count > 0)
					{
						foreach (string value in list)
						{
							try
							{
								HTTPUtils.SendRequestToClient("dragDropInstall", new Dictionary<string, string>
								{
									{
										"filePath",
										value
									}
								}, mVmName, 0, null, false, 1, 0);
							}
							catch (Exception ex3)
							{
								Logger.Warning("Failed to send drag drop install. Err: " + ex3.Message);
							}
						}
					}
				}
				catch (Exception ex4)
				{
					Logger.Error("Error in DragDrop function: " + ex4.Message);
				}
			}
		}

		// Token: 0x06000C75 RID: 3189 RVA: 0x000549E8 File Offset: 0x00052BE8
		public static void HandleDragEnter(object obj, DragEventArgs evt)
		{
			if (evt.Data.GetDataPresent(DataFormats.FileDrop))
			{
				evt.Effects = DragDropEffects.Copy;
				return;
			}
			Logger.Debug("FileDrop DataFormat not supported");
			string[] formats = evt.Data.GetFormats();
			Logger.Debug("Supported formats:");
			string[] array = formats;
			for (int i = 0; i < array.Length; i++)
			{
				Logger.Debug(array[i]);
			}
			evt.Effects = DragDropEffects.None;
		}

		// Token: 0x06000C76 RID: 3190 RVA: 0x00054A4C File Offset: 0x00052C4C
		public static string GetMimeFromFile(string filename)
		{
			string result = "";
			if (!File.Exists(filename))
			{
				return result;
			}
			byte[] array = new byte[256];
			using (FileStream fileStream = new FileStream(filename, FileMode.Open))
			{
				if (fileStream.Length >= 256L)
				{
					fileStream.Read(array, 0, 256);
				}
				else
				{
					fileStream.Read(array, 0, (int)fileStream.Length);
				}
			}
			try
			{
				uint num;
				FileImporter.FindMimeFromData(0U, null, array, 256U, null, 0U, out num, 0U);
				IntPtr ptr = new IntPtr((long)((ulong)num));
				result = Marshal.PtrToStringUni(ptr);
				Marshal.FreeCoTaskMem(ptr);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to get mime type. err: " + ex.Message);
			}
			return result;
		}
	}
}
