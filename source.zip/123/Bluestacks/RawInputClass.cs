﻿using System;
using System.Runtime.InteropServices;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000EE RID: 238
	internal class RawInputClass
	{
		// Token: 0x060009FE RID: 2558
		[DllImport("user32.dll", SetLastError = true)]
		private static extern uint GetRawInputDeviceInfo(IntPtr hDevice, uint uiCommand, IntPtr pData, ref uint pcbSize);

		// Token: 0x060009FF RID: 2559
		[DllImport("User32.dll")]
		private static extern uint GetRawInputData(IntPtr hRawInput, uint uiCommand, IntPtr pData, ref uint pcbSize, uint cbSizeHeader);

		// Token: 0x06000A00 RID: 2560
		[DllImport("User32.dll")]
		private static extern bool RegisterRawInputDevices(RawInputClass.RAWINPUTDEVICE[] pRawInputDevice, uint uiNumDevices, uint cbSize);

		// Token: 0x06000A01 RID: 2561 RVA: 0x00046908 File Offset: 0x00044B08
		internal int GetDeviceID(IntPtr lParam)
		{
			try
			{
				uint cb = 0U;
				RawInputClass.GetRawInputData(lParam, 268435459U, IntPtr.Zero, ref cb, (uint)Marshal.SizeOf(typeof(RawInputClass.RawInputHeader)));
				IntPtr intPtr = Marshal.AllocHGlobal((int)cb);
				RawInputClass.GetRawInputData(lParam, 268435459U, intPtr, ref cb, (uint)Marshal.SizeOf(typeof(RawInputClass.RawInputHeader)));
				RawInputClass.RawInput rawInput = (RawInputClass.RawInput)Marshal.PtrToStructure(intPtr, typeof(RawInputClass.RawInput));
				Marshal.FreeHGlobal(intPtr);
				if (rawInput.Data.Mouse.ButtonFlags == RawMouseButtons.LeftDown || rawInput.Data.Mouse.ButtonFlags == RawMouseButtons.RightDown)
				{
					return (int)rawInput.Header.Device;
				}
				return -1;
			}
			catch (Exception ex)
			{
				Logger.Info("Exception in raw input constructor : {0}", new object[]
				{
					ex.ToString()
				});
			}
			return -1;
		}

		// Token: 0x06000A02 RID: 2562 RVA: 0x000469E8 File Offset: 0x00044BE8
		public RawInputClass(IntPtr hwnd)
		{
			try
			{
				RawInputClass.RAWINPUTDEVICE[] array = new RawInputClass.RAWINPUTDEVICE[3];
				array[0].usUsagePage = 1;
				array[0].usUsage = 2;
				array[0].dwFlags = 256;
				array[0].hwndTarget = hwnd;
				array[1].usUsagePage = 1;
				array[1].usUsage = 5;
				array[1].dwFlags = 256;
				array[1].hwndTarget = hwnd;
				array[2].usUsagePage = 1;
				array[2].usUsage = 4;
				array[2].dwFlags = 256;
				array[2].hwndTarget = hwnd;
				if (!RawInputClass.RegisterRawInputDevices(array, (uint)array.Length, (uint)Marshal.SizeOf(array[0])))
				{
					Logger.Info("Failed to register raw input device(s).");
				}
				else
				{
					Logger.Info("Successfully registered raw input device(s).");
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Exception in raw input constructor : {0}", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x04000759 RID: 1881
		private const int RID_INPUT = 268435459;

		// Token: 0x0400075A RID: 1882
		private const int RIDEV_INPUTSINK = 256;

		// Token: 0x020000EF RID: 239
		internal struct RAWINPUTDEVICE
		{
			// Token: 0x0400075B RID: 1883
			[MarshalAs(UnmanagedType.U2)]
			public ushort usUsagePage;

			// Token: 0x0400075C RID: 1884
			[MarshalAs(UnmanagedType.U2)]
			public ushort usUsage;

			// Token: 0x0400075D RID: 1885
			[MarshalAs(UnmanagedType.U4)]
			public int dwFlags;

			// Token: 0x0400075E RID: 1886
			public IntPtr hwndTarget;
		}

		// Token: 0x020000F0 RID: 240
		internal struct RAWHID
		{
			// Token: 0x0400075F RID: 1887
			[MarshalAs(UnmanagedType.U4)]
			public int dwSizHid;

			// Token: 0x04000760 RID: 1888
			[MarshalAs(UnmanagedType.U4)]
			public int dwCount;
		}

		// Token: 0x020000F1 RID: 241
		[StructLayout(LayoutKind.Explicit)]
		public struct RawMouse
		{
			// Token: 0x04000761 RID: 1889
			[FieldOffset(0)]
			public RawMouseFlags Flags;

			// Token: 0x04000762 RID: 1890
			[FieldOffset(4)]
			public RawMouseButtons ButtonFlags;

			// Token: 0x04000763 RID: 1891
			[FieldOffset(6)]
			public ushort ButtonData;

			// Token: 0x04000764 RID: 1892
			[FieldOffset(8)]
			public uint RawButtons;

			// Token: 0x04000765 RID: 1893
			[FieldOffset(12)]
			public int LastX;

			// Token: 0x04000766 RID: 1894
			[FieldOffset(16)]
			public int LastY;

			// Token: 0x04000767 RID: 1895
			[FieldOffset(20)]
			public uint ExtraInformation;
		}

		// Token: 0x020000F2 RID: 242
		internal struct RAWKEYBOARD
		{
			// Token: 0x04000768 RID: 1896
			[MarshalAs(UnmanagedType.U2)]
			public ushort MakeCode;

			// Token: 0x04000769 RID: 1897
			[MarshalAs(UnmanagedType.U2)]
			public ushort Flags;

			// Token: 0x0400076A RID: 1898
			[MarshalAs(UnmanagedType.U2)]
			public ushort Reserved;

			// Token: 0x0400076B RID: 1899
			[MarshalAs(UnmanagedType.U2)]
			public ushort VKey;

			// Token: 0x0400076C RID: 1900
			[MarshalAs(UnmanagedType.U4)]
			public uint Message;

			// Token: 0x0400076D RID: 1901
			[MarshalAs(UnmanagedType.U4)]
			public uint ExtraInformation;
		}

		// Token: 0x020000F3 RID: 243
		public enum RawInputType
		{
			// Token: 0x0400076F RID: 1903
			Mouse,
			// Token: 0x04000770 RID: 1904
			Keyboard,
			// Token: 0x04000771 RID: 1905
			HID
		}

		// Token: 0x020000F4 RID: 244
		public struct RawInput
		{
			// Token: 0x04000772 RID: 1906
			public RawInputClass.RawInputHeader Header;

			// Token: 0x04000773 RID: 1907
			public RawInputClass.RawInput.Union Data;

			// Token: 0x020000F5 RID: 245
			[StructLayout(LayoutKind.Explicit)]
			public struct Union
			{
				// Token: 0x04000774 RID: 1908
				[FieldOffset(0)]
				public RawInputClass.RawMouse Mouse;

				// Token: 0x04000775 RID: 1909
				[FieldOffset(0)]
				public RawInputClass.RAWKEYBOARD Keyboard;

				// Token: 0x04000776 RID: 1910
				[FieldOffset(0)]
				public RawInputClass.RAWHID HID;
			}
		}

		// Token: 0x020000F6 RID: 246
		internal struct RawInputHeader
		{
			// Token: 0x04000777 RID: 1911
			public RawInputClass.RawInputType Type;

			// Token: 0x04000778 RID: 1912
			public int Size;

			// Token: 0x04000779 RID: 1913
			public IntPtr Device;

			// Token: 0x0400077A RID: 1914
			public IntPtr wParam;
		}
	}
}
