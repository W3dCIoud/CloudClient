﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media.Imaging;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000133 RID: 307
	public class CustomToggleButton : UserControl, IComponentConnector
	{
		// Token: 0x170001C4 RID: 452
		// (set) Token: 0x06000BFB RID: 3067 RVA: 0x00009457 File Offset: 0x00007657
		public bool HideIcon
		{
			set
			{
				if (value)
				{
					this.mIconColDef.Width = new GridLength(0.0);
				}
			}
		}

		// Token: 0x170001C5 RID: 453
		// (get) Token: 0x06000BFC RID: 3068 RVA: 0x00009475 File Offset: 0x00007675
		// (set) Token: 0x06000BFD RID: 3069 RVA: 0x00009482 File Offset: 0x00007682
		public string AppLabel
		{
			get
			{
				return this.mAppLabel.Text;
			}
			set
			{
				BlueStacksUIBinding.Bind(this.mAppLabel, value, "");
			}
		}

		// Token: 0x170001C6 RID: 454
		// (set) Token: 0x06000BFE RID: 3070 RVA: 0x00009495 File Offset: 0x00007695
		public Orientation CheckBoxOrientation
		{
			set
			{
				this.mMuteCheckBox.Orientation = value;
				this.mAutoHideCheckBox.Orientation = value;
				Grid.SetRow(this.mAppLabel, 1);
				Grid.SetRowSpan(this.mAppLabel, 1);
			}
		}

		// Token: 0x170001C7 RID: 455
		// (set) Token: 0x06000BFF RID: 3071 RVA: 0x000094C7 File Offset: 0x000076C7
		public bool IsThreeStateCheckBox
		{
			set
			{
				this.mMuteCheckBox.IsThreeState = value;
				this.mAutoHideCheckBox.IsThreeState = value;
			}
		}

		// Token: 0x170001C8 RID: 456
		// (set) Token: 0x06000C00 RID: 3072 RVA: 0x000094E1 File Offset: 0x000076E1
		public Visibility CheckBoxLabelVisibility
		{
			set
			{
				this.mMuteCheckBox.LabelVisibility = value;
				this.mAutoHideCheckBox.LabelVisibility = value;
			}
		}

		// Token: 0x170001C9 RID: 457
		// (set) Token: 0x06000C01 RID: 3073 RVA: 0x000094FB File Offset: 0x000076FB
		public BitmapImage Image
		{
			set
			{
				this.mAppImage.Source = value;
				if (value != null)
				{
					this.mAppImage.ImageName = string.Empty;
				}
			}
		}

		// Token: 0x170001CA RID: 458
		// (get) Token: 0x06000C02 RID: 3074 RVA: 0x0000951C File Offset: 0x0000771C
		public bool? IsMuted
		{
			get
			{
				return this.mMuteCheckBox.IsChecked;
			}
		}

		// Token: 0x170001CB RID: 459
		// (get) Token: 0x06000C03 RID: 3075 RVA: 0x00009529 File Offset: 0x00007729
		public bool? IsAutoHide
		{
			get
			{
				return this.mAutoHideCheckBox.IsChecked;
			}
		}

		// Token: 0x06000C04 RID: 3076 RVA: 0x00009536 File Offset: 0x00007736
		public void HideAppLable()
		{
			this.mAppLableColDef.Width = new GridLength(0.0);
			this.mIconColDef.Width = new GridLength(0.0);
		}

		// Token: 0x06000C05 RID: 3077 RVA: 0x0000956A File Offset: 0x0000776A
		public void HideShowButton()
		{
			this.mShowColDef.Width = new GridLength(0.0);
			this.mIconColDef.Width = new GridLength(0.0);
		}

		// Token: 0x06000C06 RID: 3078 RVA: 0x0000959E File Offset: 0x0000779E
		public CustomToggleButton()
		{
			this.InitializeComponent();
			this.SetProperties();
		}

		// Token: 0x06000C07 RID: 3079 RVA: 0x000095B2 File Offset: 0x000077B2
		private void SetProperties()
		{
			BlueStacksUIBinding.Bind(this.mMuteCheckBox, "STRING_SHOW");
			BlueStacksUIBinding.Bind(this.mAutoHideCheckBox, "STRING_AUTO_HIDE");
		}

		// Token: 0x06000C08 RID: 3080 RVA: 0x00051BD8 File Offset: 0x0004FDD8
		private void MuteButton_Checked(object sender, RoutedEventArgs e)
		{
			if (this.mAutoHideCheckBox.IsChecked != null && !this.mAutoHideCheckBox.IsChecked.Value && base.IsLoaded)
			{
				NotificationManager.Instance.UpdateMuteState(MuteState.NotMuted, this.AppLabel);
			}
		}

		// Token: 0x06000C09 RID: 3081 RVA: 0x000095D4 File Offset: 0x000077D4
		private void MuteButton_Unchecked(object sender, RoutedEventArgs e)
		{
			this.mAutoHideCheckBox.IsChecked = new bool?(false);
			if (base.IsLoaded)
			{
				NotificationManager.Instance.UpdateMuteState(MuteState.MutedForever, this.AppLabel);
			}
		}

		// Token: 0x06000C0A RID: 3082 RVA: 0x00009600 File Offset: 0x00007800
		private void MuteCheckBox_Indeterminate(object sender, RoutedEventArgs e)
		{
			if (base.IsLoaded)
			{
				NotificationManager.Instance.UpdateMuteState(MuteState.MutedForever, this.AppLabel);
			}
		}

		// Token: 0x06000C0B RID: 3083 RVA: 0x0000961B File Offset: 0x0000781B
		private void AutoHideButton_Checked(object sender, RoutedEventArgs e)
		{
			this.mMuteCheckBox.IsChecked = new bool?(true);
			if (base.IsLoaded)
			{
				NotificationManager.Instance.UpdateMuteState(MuteState.AutoHide, this.AppLabel);
			}
		}

		// Token: 0x06000C0C RID: 3084 RVA: 0x00009647 File Offset: 0x00007847
		private void AutoHideButton_Unchecked(object sender, RoutedEventArgs e)
		{
			if (base.IsLoaded)
			{
				NotificationManager.Instance.UpdateMuteState(MuteState.NotMuted, this.AppLabel);
			}
		}

		// Token: 0x06000C0D RID: 3085 RVA: 0x00009600 File Offset: 0x00007800
		private void AutoHideCheckBox_Indeterminate(object sender, RoutedEventArgs e)
		{
			if (base.IsLoaded)
			{
				NotificationManager.Instance.UpdateMuteState(MuteState.MutedForever, this.AppLabel);
			}
		}

		// Token: 0x06000C0E RID: 3086 RVA: 0x00051C28 File Offset: 0x0004FE28
		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			if (NotificationManager.Instance.IsNotificationMutedForKey(this.AppLabel) == MuteState.AutoHide)
			{
				this.mAutoHideCheckBox.IsChecked = new bool?(true);
				return;
			}
			if (NotificationManager.Instance.IsNotificationMutedForKey(this.AppLabel) == MuteState.NotMuted)
			{
				this.mMuteCheckBox.IsChecked = new bool?(true);
				return;
			}
			this.mMuteCheckBox.IsChecked = new bool?(false);
			this.mAutoHideCheckBox.IsChecked = new bool?(false);
		}

		// Token: 0x06000C0F RID: 3087 RVA: 0x00051CA0 File Offset: 0x0004FEA0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/customtogglebutton.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000C10 RID: 3088 RVA: 0x00051CD0 File Offset: 0x0004FED0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((CustomToggleButton)target).Loaded += this.UserControl_Loaded;
				return;
			case 2:
				this.mIconColDef = (ColumnDefinition)target;
				return;
			case 3:
				this.mAppLableColDef = (ColumnDefinition)target;
				return;
			case 4:
				this.mShowColDef = (ColumnDefinition)target;
				return;
			case 5:
				this.mAppImage = (CustomPictureBox)target;
				return;
			case 6:
				this.mAppLabel = (TextBlock)target;
				return;
			case 7:
				this.mMuteCheckBox = (CustomCheckbox)target;
				this.mMuteCheckBox.Checked += this.MuteButton_Checked;
				this.mMuteCheckBox.Unchecked += this.MuteButton_Unchecked;
				this.mMuteCheckBox.Indeterminate += this.MuteCheckBox_Indeterminate;
				return;
			case 8:
				this.mAutoHideCheckBox = (CustomCheckbox)target;
				this.mAutoHideCheckBox.Checked += this.AutoHideButton_Checked;
				this.mAutoHideCheckBox.Unchecked += this.AutoHideButton_Unchecked;
				this.mAutoHideCheckBox.Indeterminate += this.AutoHideCheckBox_Indeterminate;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040008C0 RID: 2240
		internal ColumnDefinition mIconColDef;

		// Token: 0x040008C1 RID: 2241
		internal ColumnDefinition mAppLableColDef;

		// Token: 0x040008C2 RID: 2242
		internal ColumnDefinition mShowColDef;

		// Token: 0x040008C3 RID: 2243
		internal CustomPictureBox mAppImage;

		// Token: 0x040008C4 RID: 2244
		internal TextBlock mAppLabel;

		// Token: 0x040008C5 RID: 2245
		internal CustomCheckbox mMuteCheckBox;

		// Token: 0x040008C6 RID: 2246
		internal CustomCheckbox mAutoHideCheckBox;

		// Token: 0x040008C7 RID: 2247
		private bool _contentLoaded;
	}
}
