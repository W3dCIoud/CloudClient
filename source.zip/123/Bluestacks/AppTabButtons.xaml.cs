﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200002C RID: 44
	public partial class AppTabButtons : UserControl
	{
		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x06000277 RID: 631 RVA: 0x00003B35 File Offset: 0x00001D35
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x06000278 RID: 632 RVA: 0x00003B56 File Offset: 0x00001D56
		// (set) Token: 0x06000279 RID: 633 RVA: 0x00003B5E File Offset: 0x00001D5E
		public List<string> ListTabHistory
		{
			get
			{
				return this.mListTabHistory;
			}
			set
			{
				this.mListTabHistory = value;
			}
		}

		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x0600027A RID: 634 RVA: 0x00014D84 File Offset: 0x00012F84
		public int AreaForTABS
		{
			get
			{
				int num = (int)(base.ActualWidth - 20.0);
				if (num < 0)
				{
					num = 0;
				}
				return num;
			}
		}

		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x0600027B RID: 635 RVA: 0x00003B67 File Offset: 0x00001D67
		internal AppTabButton SelectedTab
		{
			get
			{
				return this.ParentWindow.StaticComponents.mSelectedTabButton;
			}
		}

		// Token: 0x0600027C RID: 636 RVA: 0x00014DAC File Offset: 0x00012FAC
		public AppTabButtons()
		{
			this.InitializeComponent();
			if (!DesignerProperties.GetIsInDesignMode(this))
			{
				base.SizeChanged += this.Window_SizeChanged;
				base.Loaded += this.AppTabButtons_Loaded;
			}
		}

		// Token: 0x0600027D RID: 637 RVA: 0x00003B79 File Offset: 0x00001D79
		private void AppTabButtons_Loaded(object sender, RoutedEventArgs e)
		{
			base.Loaded -= this.AppTabButtons_Loaded;
			if (!FeatureManager.Instance.IsCustomUIForDMM && RegistryManager.Instance.InstallationType == InstallationTypes.FullEdition)
			{
				this.AddHomeTab();
			}
		}

		// Token: 0x0600027E RID: 638 RVA: 0x00014E38 File Offset: 0x00013038
		internal void AddHomeTab()
		{
			AppTabButton appTabButton = new AppTabButton();
			this.mHomeAppTabButton = appTabButton;
			this.mPanel.Children.Insert(0, appTabButton);
			appTabButton.Init("STRING_HOME", "Home", string.Empty, "home", this.ParentWindow.WelcomeTabParentGrid, "Home");
			BlueStacksUIBinding.Bind(appTabButton.mTabLabel, "STRING_HOME");
			appTabButton.MouseUp += this.AppTabButton_MouseUp;
			this.mDictTabs[appTabButton.PackageName] = appTabButton;
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				appTabButton.Visibility = Visibility.Collapsed;
			}
			appTabButton.IsPortraitModeTab = !(this.ParentWindow.mAspectRatio > 1L);
			this.ResizeTabs();
			this.GoToTab("Home", false, false);
		}

		// Token: 0x0600027F RID: 639 RVA: 0x00014F10 File Offset: 0x00013110
		internal void AddHiddenAppTabAndLaunch(string packageName, string activityName)
		{
			this.AddAppTab("", packageName, activityName, "", true, true, "", false);
			this.ParentWindow.StaticComponents.mSelectedTabButton.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000280 RID: 640 RVA: 0x00014F50 File Offset: 0x00013150
		internal void AddAppTab(string appName, string packageName, string activityName, string imageName, bool isSwitch, bool isLaunch, string tabKey, bool receivedFromImap = false)
		{
			if (this.mDictTabs.ContainsKey(packageName))
			{
				this.GoToTab(packageName, isLaunch, receivedFromImap);
				return;
			}
			AppTabButton mSelectedTabButton = this.ParentWindow.StaticComponents.mSelectedTabButton;
			AppTabButton appTabButton = new AppTabButton();
			appTabButton.Init(appName, packageName, activityName, imageName, this.ParentWindow.FrontendParentGrid, packageName);
			appTabButton.MouseUp += this.AppTabButton_MouseUp;
			if (this.ParentWindow.mDiscordhandler != null)
			{
				this.ParentWindow.mDiscordhandler.AssignTabChangeEvent(appTabButton);
			}
			if (FeatureManager.Instance.IsCustomUIForDMM && this.ParentWindow.mDmmBottomBar != null)
			{
				AppTabButton appTabButton2 = appTabButton;
				appTabButton2.EventOnTabChanged = (EventHandler<TabChangeEventArgs>)Delegate.Combine(appTabButton2.EventOnTabChanged, new EventHandler<TabChangeEventArgs>(this.ParentWindow.mDmmBottomBar.Tab_Changed));
			}
			this.mDictTabs.Add(packageName, appTabButton);
			this.mPanel.Children.Add(appTabButton);
			if (Oem.Instance.SendAppClickStatsFromClient)
			{
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					AppInfo appInfoFromPackageName = new JsonParser(this.ParentWindow.mVmName).GetAppInfoFromPackageName(packageName);
					string appVersion = string.Empty;
					string appVersionName = string.Empty;
					if (appInfoFromPackageName != null)
					{
						if (!string.IsNullOrEmpty(appInfoFromPackageName.version))
						{
							appVersion = appInfoFromPackageName.version;
						}
						if (!string.IsNullOrEmpty(appInfoFromPackageName.versionName))
						{
							appVersionName = appInfoFromPackageName.versionName;
						}
					}
					Stats.SendAppStats(appName, packageName, appVersion, "HomeVersionNotKnown", Stats.AppType.app, this.ParentWindow.mVmName, appVersionName);
				});
			}
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				appTabButton.Visibility = Visibility.Collapsed;
			}
			else if (mSelectedTabButton != null && mSelectedTabButton.IsPortraitModeTab && mSelectedTabButton.mTabType == TabType.AppTab)
			{
				appTabButton.IsPortraitModeTab = true;
			}
			this.ResizeTabs();
			if (isSwitch)
			{
				this.GoToTab(packageName, isLaunch, receivedFromImap);
			}
			if (PackageActivityNames.ThirdParty.AllPUBGPackageNames.Contains(packageName))
			{
				this.DoPUBGLaunchCountHandling();
			}
		}

		// Token: 0x06000281 RID: 641 RVA: 0x000150F4 File Offset: 0x000132F4
		private void DoPUBGLaunchCountHandling()
		{
			this.ParentWindow.EngineInstanceRegistry.PUBGLaunchedCount++;
			if (this.ParentWindow.EngineInstanceRegistry.PUBGLaunchedCount == 2147483647)
			{
				this.ParentWindow.EngineInstanceRegistry.PUBGLaunchedCount = 3;
			}
			if (this.ParentWindow.EngineInstanceRegistry.PUBGLaunchedCount == 2)
			{
				Logger.Info("Launch count for PUBG is 2, showing red dot for settings which will trigger GameSettings");
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					this.ParentWindow.mTopBar.mSettingsBtnNotification.Visibility = Visibility.Visible;
					this.ParentWindow.mTopBar.mPreferenceDropDownControl.mSettingsBtnNotification.Visibility = Visibility.Visible;
				}), new object[0]);
			}
		}

		// Token: 0x06000282 RID: 642 RVA: 0x00015184 File Offset: 0x00013384
		internal void AddWebTab(string url, string tabName, string imageName, bool isSwitch, string tabKey = "", bool forceRefresh = false)
		{
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				return;
			}
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				Process.Start(url);
				return;
			}
			bool flag = false;
			if (!string.IsNullOrEmpty(tabKey))
			{
				flag = true;
			}
			if (this.mDictTabs.ContainsKey(flag ? tabKey : url))
			{
				if (this.mDictTabs[flag ? tabKey : url].GetBrowserControl() == null)
				{
					this.mDictTabs[tabKey].mControlGrid = this.ParentWindow.AddBrowser(url);
					this.mDictTabs[tabKey].Init(tabName, url, imageName, this.mDictTabs[tabKey].mControlGrid, tabKey);
				}
				if (flag && string.Compare(url, this.mDictTabs[tabKey].PackageName, true) != 0)
				{
					BrowserControl browserControl = this.mDictTabs[tabKey].GetBrowserControl();
					this.mDictTabs[tabKey].Init(tabName, url, imageName, this.mDictTabs[tabKey].mControlGrid, tabKey);
					if (browserControl != null)
					{
						browserControl.UpdateUrlAndRefresh(url);
					}
				}
				else if (forceRefresh)
				{
					BrowserControl browserControl = this.mDictTabs[flag ? tabKey : url].GetBrowserControl();
					browserControl.UpdateUrlAndRefresh(browserControl.mUrl);
				}
				this.GoToTab(flag ? tabKey : url, true, false);
				return;
			}
			AppTabButton appTabButton = new AppTabButton();
			Grid grid = this.ParentWindow.AddBrowser(url);
			grid.Visibility = Visibility.Visible;
			appTabButton.Init(tabName, url, imageName, grid, flag ? tabKey : url);
			appTabButton.MouseUp += this.AppTabButton_MouseUp;
			if (this.ParentWindow.mDiscordhandler != null)
			{
				this.ParentWindow.mDiscordhandler.AssignTabChangeEvent(appTabButton);
			}
			this.mDictTabs.Add(flag ? tabKey : url, appTabButton);
			this.mPanel.Children.Add(appTabButton);
			this.ResizeTabs();
			if (isSwitch)
			{
				this.GoToTab(flag ? tabKey : url, true, false);
			}
			ClientStats.SendMiscellaneousStatsAsync("WebTabLaunched", RegistryManager.Instance.UserGuid, url, appTabButton.AppLabel, RegistryManager.Instance.Version, Oem.Instance.OEM, null, null, null);
		}

		// Token: 0x06000283 RID: 643 RVA: 0x000153AC File Offset: 0x000135AC
		internal void KillWebTabs()
		{
			if (RegistryManager.Instance.SwitchKillWebTab)
			{
				foreach (KeyValuePair<string, AppTabButton> keyValuePair in this.mDictTabs)
				{
					if (keyValuePair.Value.mTabType == TabType.WebTab)
					{
						foreach (object obj in keyValuePair.Value.mControlGrid.Children)
						{
							BrowserControl browserControl = obj as BrowserControl;
							if (browserControl != null && browserControl.mBrowser != null)
							{
								browserControl.mBrowser.Dispose();
								browserControl.mBrowser = null;
							}
						}
					}
				}
			}
		}

		// Token: 0x06000284 RID: 644 RVA: 0x00015488 File Offset: 0x00013688
		private void AppTabButton_MouseUp(object sender, MouseButtonEventArgs e)
		{
			if (e.ChangedButton == MouseButton.Middle)
			{
				string tabKey = (sender as AppTabButton).TabKey;
				if (!string.IsNullOrEmpty(tabKey))
				{
					this.CloseTab(tabKey, true, false, false, false, "");
				}
			}
		}

		// Token: 0x06000285 RID: 645 RVA: 0x00003BAC File Offset: 0x00001DAC
		private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (!this.ParentWindow.mIsFullScreen)
			{
				this.RefreshUI();
			}
		}

		// Token: 0x06000286 RID: 646 RVA: 0x000154C4 File Offset: 0x000136C4
		private void RefreshUI()
		{
			if ((DateTime.Now - this.mLastTimeOfSizeChangeEventRecieved).TotalSeconds > 2.0)
			{
				this.mLastTimeOfSizeChangeEventRecieved = DateTime.Now;
				this.mSizeChangedEventCountInLast2Seconds = 1;
			}
			else
			{
				this.mSizeChangedEventCountInLast2Seconds++;
			}
			if (this.mSizeChangedEventCountInLast2Seconds > 500)
			{
				return;
			}
			if (this.ParentWindow.IsUIInPortraitMode)
			{
				this.SwitchToIconMode(true);
			}
			else
			{
				this.SwitchToIconMode(false);
			}
			this.ResizeTabs();
		}

		// Token: 0x06000287 RID: 647 RVA: 0x00015548 File Offset: 0x00013748
		private void SwitchToIconMode(bool isSwitchToIconMode)
		{
			if (isSwitchToIconMode)
			{
				this.mTabMinWidth = 38;
				this.mTabMode = AppTabButtons.TabMode.IconMode;
				if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
				{
					this.mMoreTabButton.Visibility = Visibility.Hidden;
					this.ParentWindow.mTopBar.mTitleText.Visibility = Visibility.Collapsed;
				}
				else if (!FeatureManager.Instance.IsCustomUIForDMM)
				{
					this.ParentWindow.mTopBar.mTitleTextGrid.Visibility = Visibility.Collapsed;
				}
				this.mMoreTabButton.MakeTabParallelogram(false);
			}
			else
			{
				if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
				{
					this.ParentWindow.mTopBar.mTitleText.Visibility = Visibility.Visible;
				}
				this.mTabMinWidth = 48;
				this.mTabMode = AppTabButtons.TabMode.ParallelogramMode;
				this.mMoreTabButton.MakeTabParallelogram(true);
			}
			this.ParentWindow.mTopBar.RefreshWarningButton();
		}

		// Token: 0x06000288 RID: 648 RVA: 0x00015618 File Offset: 0x00013818
		internal void ResizeTabs()
		{
			double num = this.MacroGridHandling();
			num += this.VideoRecordingGridHandling();
			if (this.ParentWindow.mTopBar.ActualWidth > this.ParentWindow.mTopBar.mMinimumExpectedTopBarWidth + num + 40.0)
			{
				this.ParentWindow.mTopBar.mTitleIcon.Visibility = Visibility.Visible;
			}
			else
			{
				this.ParentWindow.mTopBar.mTitleIcon.Visibility = Visibility.Collapsed;
			}
			if (this.ParentWindow.mTopBar.ActualWidth > this.ParentWindow.mTopBar.mMinimumExpectedTopBarWidth + 140.0 + num + (double)(this.mDictTabs.Count * 48))
			{
				this.ParentWindow.mTopBar.mTitleTextGrid.Visibility = Visibility.Visible;
			}
			else
			{
				this.ParentWindow.mTopBar.mTitleTextGrid.Visibility = Visibility.Collapsed;
			}
			int num2 = this.mPanel.Children.Count + this.mHiddenButtons.Children.Count;
			if (num2 > 0)
			{
				double num3 = (double)this.mTabMinWidth;
				if (this.AreaForTABS >= num2 * this.mTabMinWidth)
				{
					num3 = (double)(this.AreaForTABS / num2);
				}
				for (int i = 0; i < this.mPanel.Children.Count; i++)
				{
					(this.mPanel.Children[i] as AppTabButton).ResizeButton(num3);
				}
				if ((double)this.AreaForTABS >= num3 * (double)num2)
				{
					if (this.mHiddenButtons.Children.Count > 0)
					{
						this.ShowXTabs(this.mHiddenButtons.Children.Count, num3);
					}
				}
				else
				{
					int num4 = this.AreaForTABS / this.mTabMinWidth - 1;
					if (FeatureManager.Instance.IsCustomUIForDMM)
					{
						int num5 = (int)Math.Floor(BlueStacksUIBinding.Instance.CornerRadiusModel["TabMarginPortrait"].TopLeft);
						int num6 = (int)Math.Floor(this.mMoreTabButton.ActualWidth) + num5;
						num4 = (this.AreaForTABS - num6) / (this.mTabMinWidth + num5);
					}
					if (num4 > num2)
					{
						num4 = num2;
					}
					if (num4 > this.mPanel.Children.Count || num2 == 1)
					{
						this.ShowXTabs(num4 - this.mPanel.Children.Count, num3);
					}
					else if (num4 < this.mPanel.Children.Count)
					{
						this.HideXTabs(this.mPanel.Children.Count - num4);
					}
				}
			}
			if (this.mHiddenButtons.Children.Count > 0)
			{
				this.mMoreTabButton.Visibility = Visibility.Visible;
				this.mMoreTabButton.MoreTabsButtonHandling();
				return;
			}
			this.mMoreTabButton.Visibility = Visibility.Hidden;
		}

		// Token: 0x06000289 RID: 649 RVA: 0x000158CC File Offset: 0x00013ACC
		private double MacroGridHandling()
		{
			double num = 0.0;
			if (this.ParentWindow.mTopBar.mMacroRecordControl.Visibility == Visibility.Visible)
			{
				num = this.ParentWindow.mTopBar.mMacroRecordControl.MaxWidth;
			}
			else if (this.ParentWindow.mTopBar.mMacroPlayControl.Visibility == Visibility.Visible)
			{
				num = this.ParentWindow.mTopBar.mMacroPlayControl.MaxWidth;
			}
			if (num > 0.0)
			{
				if (this.ParentWindow.mTopBar.ActualWidth > this.ParentWindow.mTopBar.mMinimumExpectedTopBarWidth + num)
				{
					this.ParentWindow.mTopBar.mMacroRecordControl.TimerDisplay.Visibility = Visibility.Visible;
					this.ParentWindow.mTopBar.mMacroPlayControl.mDescriptionPanel.Visibility = Visibility.Visible;
				}
				else
				{
					this.ParentWindow.mTopBar.mMacroRecordControl.TimerDisplay.Visibility = Visibility.Collapsed;
					this.ParentWindow.mTopBar.mMacroPlayControl.mDescriptionPanel.Visibility = Visibility.Collapsed;
				}
			}
			return num;
		}

		// Token: 0x0600028A RID: 650 RVA: 0x000159E4 File Offset: 0x00013BE4
		private double VideoRecordingGridHandling()
		{
			double num = 0.0;
			if (this.ParentWindow.mTopBar.mVideoRecordStatusControl.Visibility == Visibility.Visible)
			{
				num = this.ParentWindow.mTopBar.mVideoRecordStatusControl.MaxWidth;
			}
			if (num > 0.0)
			{
				if (this.ParentWindow.mTopBar.ActualWidth > this.ParentWindow.mTopBar.mMinimumExpectedTopBarWidth + num)
				{
					this.ParentWindow.mTopBar.mVideoRecordStatusControl.mDescriptionPanel.Visibility = Visibility.Visible;
				}
				else
				{
					this.ParentWindow.mTopBar.mVideoRecordStatusControl.mDescriptionPanel.Visibility = Visibility.Collapsed;
				}
			}
			return num;
		}

		// Token: 0x0600028B RID: 651 RVA: 0x00015A94 File Offset: 0x00013C94
		private void ShowXTabs(int x, double tabWidth)
		{
			for (int i = 0; i < x; i++)
			{
				AppTabButton appTabButton = this.mDictTabs.Values.First<AppTabButton>();
				foreach (AppTabButton appTabButton2 in this.mDictTabs.Values)
				{
					if (this.mHiddenButtons.Children.Contains(appTabButton2))
					{
						appTabButton = appTabButton2;
						break;
					}
				}
				appTabButton.ResizeButton(tabWidth);
				appTabButton.UpdateUIForDropDown(false);
				if (!this.mPanel.Children.Contains(appTabButton))
				{
					this.mHiddenButtons.Children.Remove(appTabButton);
					if (appTabButton.mTabType == TabType.HomeTab)
					{
						this.mPanel.Children.Insert(0, appTabButton);
					}
					else
					{
						this.mPanel.Children.Add(appTabButton);
					}
				}
			}
		}

		// Token: 0x0600028C RID: 652 RVA: 0x00015B80 File Offset: 0x00013D80
		private void HideXTabs(int x)
		{
			for (int i = 0; i < x; i++)
			{
				AppTabButton appTabButton = this.mDictTabs.Values.Last<AppTabButton>();
				for (int j = this.mDictTabs.Count - 1; j >= 0; j--)
				{
					AppTabButton value = this.mDictTabs.ElementAt(j).Value;
					if (this.mPanel.Children.Contains(value))
					{
						appTabButton = value;
						break;
					}
				}
				appTabButton.UpdateUIForDropDown(true);
				if (!this.mHiddenButtons.Children.Contains(appTabButton))
				{
					this.mPanel.Children.Remove(appTabButton);
					this.mHiddenButtons.Children.Add(appTabButton);
				}
			}
		}

		// Token: 0x0600028D RID: 653 RVA: 0x00015C34 File Offset: 0x00013E34
		internal void CloseTab(string tabKey, bool sendStopAppToAndroid = false, bool forceClose = false, bool dontCheckQuitPopup = false, bool receivedFromImap = false, string topActivityPackageName = "")
		{
			if (this.mDictTabs.ContainsKey(tabKey))
			{
				if (this.ParentWindow.SendClientActions && !receivedFromImap)
				{
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					Dictionary<string, string> dictionary2 = new Dictionary<string, string>();
					dictionary2.Add("EventAction", "TabClosed");
					dictionary2.Add("tabKey", tabKey);
					dictionary2.Add("sendStopAppToAndroid", sendStopAppToAndroid.ToString());
					dictionary2.Add("forceClose", forceClose.ToString());
					JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
					serializerSettings.Formatting = Formatting.None;
					dictionary.Add("operationData", JsonConvert.SerializeObject(dictionary2, serializerSettings));
					this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("handleClientOperation", dictionary);
				}
				AppTabButton appTabButton = this.mDictTabs[tabKey];
				if (appTabButton.mTabType == TabType.WebTab)
				{
					BrowserControl browserControl = null;
					foreach (object obj in appTabButton.mControlGrid.Children)
					{
						browserControl = (obj as BrowserControl);
						if (browserControl != null)
						{
							break;
						}
					}
					string arg = string.Empty;
					if (browserControl != null)
					{
						arg = browserControl.mUrl;
						appTabButton.mControlGrid.Children.Remove(browserControl);
						if (browserControl.mBrowser != null)
						{
							browserControl.mBrowser.Dispose();
						}
					}
					ClientStats.SendMiscellaneousStatsAsync("WebTabClosed", RegistryManager.Instance.UserGuid, arg, appTabButton.AppLabel, RegistryManager.Instance.Version, Oem.Instance.OEM, null, null, null);
				}
				if (FeatureManager.Instance.IsCheckForQuitPopup && !RegistryManager.Instance.Guest[this.ParentWindow.mVmName].IsGoogleSigninDone && appTabButton.mTabType == TabType.AppTab && appTabButton.PackageName == "com.android.vending")
				{
					QuitPopupControl quitPopupControl = new QuitPopupControl(this.ParentWindow);
					string text = "exit_popup_ots";
					quitPopupControl.CurrentPopupTag = text;
					BlueStacksUIBinding.Bind(quitPopupControl.TitleTextBlock, "STRING_YOU_ARE_ONE_STEP_AWAY", "");
					BlueStacksUIBinding.Bind(quitPopupControl.mCloseBlueStacksButton, "STRING_CLOSE_TAB");
					quitPopupControl.AddQuitActionItem(QuitActionItem.WhyGoogleAccount);
					quitPopupControl.AddQuitActionItem(QuitActionItem.TroubleSigningIn);
					quitPopupControl.AddQuitActionItem(QuitActionItem.SomethingElseWrong);
					quitPopupControl.CloseBlueStacksButton.PreviewMouseUp += delegate(object sender, MouseButtonEventArgs e)
					{
						this.CloseTabAfterQuitPopup(tabKey, sendStopAppToAndroid, forceClose);
					};
					quitPopupControl.CrossButtonPictureBox.PreviewMouseUp += delegate(object sender, MouseButtonEventArgs e)
					{
						if (topActivityPackageName.Equals("com.bluestacks.appmart"))
						{
							this.CloseTabAfterQuitPopup(tabKey, sendStopAppToAndroid, forceClose);
						}
					};
					new ContainerWindow(this.ParentWindow, quitPopupControl, quitPopupControl.Width, quitPopupControl.Height, false, true);
					ClientStats.SendLocalQuitPopupStatsAsync(text, "popup_shown");
					return;
				}
				if (!FeatureManager.Instance.IsCustomUIForDMM && !dontCheckQuitPopup && appTabButton.mTabType == TabType.AppTab && tabKey != this.mLastPackageForQuitPopupDisplayed && !this.ParentWindow.SendClientActions && !receivedFromImap)
				{
					if (this.ParentWindow.mWelcomeTab.mHomeApp.CheckDictAppIconFor(tabKey, (AppIcon _) => _.IsInstalledApp))
					{
						if (this.ParentWindow.mWelcomeTab.mHomeApp.CheckDictAppIconFor(tabKey, (AppIcon _) => !_.IsAppSuggestionActive))
						{
							ProgressBar progressBar = new ProgressBar();
							progressBar.ProgressText = "STRING_LOADING_MESSAGE";
							progressBar.Visibility = Visibility.Hidden;
							this.ParentWindow.ShowDimOverlay(progressBar);
							this.mLastPackageForQuitPopupDisplayed = tabKey;
							new Thread(delegate()
							{
								if (this.ParentWindow.Utils.CheckQuitPopupFromCloud("app_tab_closed", tabKey))
								{
									return;
								}
								this.Dispatcher.Invoke(new Action(delegate()
								{
									this.CloseTabAfterQuitPopup(tabKey, sendStopAppToAndroid, forceClose);
								}), new object[0]);
							})
							{
								IsBackground = true
							}.Start();
							return;
						}
					}
				}
				this.CloseTabAfterQuitPopup(tabKey, sendStopAppToAndroid, forceClose);
			}
		}

		// Token: 0x0600028E RID: 654 RVA: 0x00016050 File Offset: 0x00014250
		private void CloseTabAfterQuitPopup(string tabKey, bool sendStopAppToAndroid, bool forceClose)
		{
			if (this.mDictTabs.ContainsKey(tabKey))
			{
				AppTabButton appTabButton = this.mDictTabs[tabKey];
				if (appTabButton.mTabType != TabType.HomeTab && this.ParentWindow.mDimOverlay != null && this.ParentWindow.mDimOverlay.Control != null && ((FeatureManager.Instance.IsCustomUIForNCSoft && this.ParentWindow.mDimOverlay.Control.GetType() == this.ParentWindow.ScreenLockInstance.GetType()) || !FeatureManager.Instance.IsCustomUIForNCSoft))
				{
					this.ParentWindow.HideDimOverlay();
					this.mPopup.IsOpen = false;
				}
				this.mLastPackageForQuitPopupDisplayed = "";
				if (appTabButton.mTabType != TabType.HomeTab || forceClose)
				{
					(appTabButton.Parent as Panel).Children.Remove(appTabButton);
					this.mDictTabs.Remove(tabKey);
					if (appTabButton.mTabType == TabType.AppTab || appTabButton.mTabType == TabType.HomeTab)
					{
						this.ParentWindow.mCommonHandler.ToggleMacroAndSyncVisibility();
					}
					if (sendStopAppToAndroid && appTabButton.mTabType == TabType.AppTab)
					{
						this.ParentWindow.mAppHandler.StopAppRequest(appTabButton.PackageName);
					}
					this.mListTabHistory.RemoveAll((string n) => n.Equals(tabKey, StringComparison.OrdinalIgnoreCase));
					if (this.ParentWindow.mDiscordhandler != null)
					{
						this.ParentWindow.mDiscordhandler.RemoveAppFromTimestampList(tabKey);
					}
					if (FeatureManager.Instance.IsCustomUIForDMM && this.mListTabHistory.Count == 0)
					{
						this.ParentWindow.Hide();
						this.ParentWindow.RestoreWindows();
						if (this.ParentWindow.mDMMRecommendedWindow != null)
						{
							this.ParentWindow.mDMMRecommendedWindow.Visibility = Visibility.Hidden;
						}
						this.ParentWindow.StaticComponents.mSelectedTabButton.IsPortraitModeTab = false;
					}
					else if (appTabButton.IsSelected)
					{
						if (this.mListTabHistory.Count != 0)
						{
							this.GoToTab(this.mListTabHistory[this.mListTabHistory.Count - 1], true, false);
						}
						else
						{
							Logger.Fatal("No tab to go back to! Ignoring");
						}
					}
					this.ResizeTabs();
				}
			}
		}

		// Token: 0x0600028F RID: 655 RVA: 0x00016280 File Offset: 0x00014480
		internal bool GoToTab(string key, bool isLaunch = true, bool receivedFromImap = false)
		{
			bool result = false;
			if (this.mDictTabs.ContainsKey(key))
			{
				if (FeatureManager.Instance.IsCustomUIForDMM && this.ParentWindow.mFrontendGrid.Visibility != Visibility.Visible)
				{
					this.ParentWindow.mFrontendGrid.Visibility = Visibility.Visible;
					this.ParentWindow.mDmmProgressControl.Visibility = Visibility.Hidden;
				}
				AppTabButton appTabButton = this.mDictTabs[key];
				if (!appTabButton.IsSelected)
				{
					appTabButton.IsLaunchOnSelection = isLaunch;
					appTabButton.Select(true, receivedFromImap);
					result = true;
					if (appTabButton.EventOnTabChanged != null)
					{
						appTabButton.EventOnTabChanged(null, new TabChangeEventArgs(appTabButton.AppName, appTabButton.PackageName, appTabButton.mTabType));
					}
				}
				else
				{
					result = true;
				}
			}
			return result;
		}

		// Token: 0x06000290 RID: 656 RVA: 0x00003BC1 File Offset: 0x00001DC1
		internal bool GoToTab(int index)
		{
			return this.mDictTabs.Count > index && this.GoToTab(this.mPanel.Children.OfType<AppTabButton>().Last<AppTabButton>().TabKey, true, false);
		}

		// Token: 0x06000291 RID: 657 RVA: 0x00003BF5 File Offset: 0x00001DF5
		internal AppTabButton GetTab(string packageName)
		{
			if (this.mDictTabs.ContainsKey(packageName))
			{
				return this.mDictTabs[packageName];
			}
			return null;
		}

		// Token: 0x06000292 RID: 658 RVA: 0x00003C13 File Offset: 0x00001E13
		private void MoreTabButton_Click(object sender, RoutedEventArgs e)
		{
			this.mPopup.IsOpen = true;
		}

		// Token: 0x06000293 RID: 659 RVA: 0x00003C21 File Offset: 0x00001E21
		private void NotificationPopup_Opened(object sender, EventArgs e)
		{
			this.mMoreTabButton.IsEnabled = false;
		}

		// Token: 0x06000294 RID: 660 RVA: 0x00003C2F File Offset: 0x00001E2F
		private void NotificationPopup_Closed(object sender, EventArgs e)
		{
			this.mMoreTabButton.IsEnabled = true;
		}

		// Token: 0x06000295 RID: 661 RVA: 0x00003C3D File Offset: 0x00001E3D
		private void NotificaitonPopup_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			new Thread(delegate()
			{
				Thread.Sleep(100);
				base.Dispatcher.Invoke(new Action(delegate()
				{
					this.mPopup.IsOpen = false;
				}), new object[0]);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000296 RID: 662 RVA: 0x00016338 File Offset: 0x00014538
		internal void EnableAppTabs(bool isEnableTab)
		{
			foreach (KeyValuePair<string, AppTabButton> keyValuePair in this.mDictTabs)
			{
				if (keyValuePair.Value.mTabType == TabType.AppTab)
				{
					keyValuePair.Value.IsEnabled = isEnableTab;
				}
			}
		}

		// Token: 0x06000297 RID: 663 RVA: 0x000163A0 File Offset: 0x000145A0
		internal bool IsAppRunning()
		{
			foreach (KeyValuePair<string, AppTabButton> keyValuePair in this.mDictTabs)
			{
				if (keyValuePair.Value.mTabType == TabType.AppTab)
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x06000298 RID: 664 RVA: 0x00016404 File Offset: 0x00014604
		internal void RestartTab(string package)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.CloseTab(package, true, true, true, false, "");
			}), new object[0]);
			Thread.Sleep(1000);
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon(package).OpenApp();
			}), new object[0]);
		}

		// Token: 0x04000165 RID: 357
		private MainWindow mMainWindow;

		// Token: 0x04000166 RID: 358
		internal AppTabButton mHomeAppTabButton;

		// Token: 0x04000167 RID: 359
		private int mTabMinWidth = 48;

		// Token: 0x04000168 RID: 360
		private AppTabButtons.TabMode mTabMode;

		// Token: 0x04000169 RID: 361
		private DateTime mLastTimeOfSizeChangeEventRecieved = DateTime.Now;

		// Token: 0x0400016A RID: 362
		private int mSizeChangedEventCountInLast2Seconds = 1;

		// Token: 0x0400016B RID: 363
		private bool mIsWindowsHeaderVisible = true;

		// Token: 0x0400016C RID: 364
		internal Dictionary<string, AppTabButton> mDictTabs = new Dictionary<string, AppTabButton>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x0400016D RID: 365
		private List<string> mListTabHistory = new List<string>();

		// Token: 0x0400016E RID: 366
		public EventHandler<EventArgs> EventOnTabChanged;

		// Token: 0x0400016F RID: 367
		internal string mLastPackageForQuitPopupDisplayed = "";

		// Token: 0x0200002D RID: 45
		private enum TabMode
		{
			// Token: 0x04000177 RID: 375
			ParallelogramMode,
			// Token: 0x04000178 RID: 376
			IconMode
		}
	}
}
