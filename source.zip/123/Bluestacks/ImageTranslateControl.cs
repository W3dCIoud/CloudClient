﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media.Imaging;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200007E RID: 126
	public class ImageTranslateControl : UserControl, IDimOverlayControl, IComponentConnector
	{
		// Token: 0x17000140 RID: 320
		// (get) Token: 0x060005AB RID: 1451 RVA: 0x00005B3E File Offset: 0x00003D3E
		public static ImageTranslateControl Instance
		{
			get
			{
				return ImageTranslateControl.mInstance;
			}
		}

		// Token: 0x060005AC RID: 1452 RVA: 0x000247EC File Offset: 0x000229EC
		public ImageTranslateControl(MainWindow parentWindow)
		{
			this.InitializeComponent();
			ImageTranslateControl.mInstance = this;
			this.ParentWindow = parentWindow;
			this.mGrid.Width = parentWindow.FrontendParentGrid.ActualWidth;
			this.mGrid.Height = parentWindow.FrontendParentGrid.ActualHeight + 40.0;
			this.mLoadingImage.Visibility = Visibility.Visible;
			this.mFrontEndImage.Visibility = Visibility.Collapsed;
			this.mBootText.Visibility = Visibility.Visible;
			this.mBootText.Text = "Loading..";
		}

		// Token: 0x060005AD RID: 1453 RVA: 0x0002487C File Offset: 0x00022A7C
		public void GetTranslateImage(Bitmap bitmap)
		{
			MemoryStream fs = new MemoryStream();
			bitmap.Save(fs, ImageFormat.Jpeg);
			fs.Position = 0L;
			this.httpBackGroundThread = new Thread(delegate()
			{
				Dictionary<string, object> dictionary = new Dictionary<string, object>();
				string text = RegistryManager.Instance.UserSelectedLocale;
				text = text.Substring(0, 2);
				if (text.Equals("zh-CN") || text.Equals("zh-TW"))
				{
					text = RegistryManager.Instance.UserSelectedLocale;
				}
				if (!string.IsNullOrEmpty(RegistryManager.Instance.TargetLocale))
				{
					text = RegistryManager.Instance.TargetLocale;
				}
				dictionary.Add("locale", text);
				dictionary.Add("inputImage", new FormFile
				{
					Name = "image.jpg",
					ContentType = "image/jpeg",
					Stream = fs
				});
				dictionary.Add("oem", RegistryManager.Instance.Oem);
				dictionary.Add("guid", RegistryManager.Instance.UserGuid);
				dictionary.Add("prod_ver", RegistryManager.Instance.ClientVersion);
				string text2 = Convert.ToBase64String(fs.ToArray());
				text2 = text2 + RegistryManager.Instance.UserGuid + "BstTranslate";
				dictionary.Add("token", new _MD5
				{
					Value = text2
				}.FingerPrint);
				string url = string.Format("{0}/{1}", RegistryManager.Instance.Host, "/translate/postimage");
				if (!string.IsNullOrEmpty(RegistryManager.Instance.TargetLocaleUrl))
				{
					url = RegistryManager.Instance.TargetLocaleUrl;
				}
				string text3 = string.Empty;
				byte[] dataArray = null;
				try
				{
					text3 = BstHttpClient.PostMultipart(url, dictionary, out dataArray);
				}
				catch (Exception ex)
				{
					Logger.Error("error while downloading translated image.." + ex.ToString());
					text3 = "error";
				}
				if (text3.Contains("error"))
				{
					this.Dispatcher.Invoke(new Action(delegate()
					{
						this.mLoadingImage.Visibility = Visibility.Collapsed;
						this.mBootText.Text = "Error while translating";
					}), new object[0]);
					return;
				}
				this.Dispatcher.Invoke(new Action(delegate()
				{
					BitmapImage source = this.byteArrayToImage(dataArray);
					this.mFrontEndImage.Source = source;
					this.mFrontEndImage.ReloadImages();
					this.mFrontEndImage.Visibility = Visibility.Visible;
					this.mLoadingImage.Visibility = Visibility.Collapsed;
					this.mBootText.Visibility = Visibility.Collapsed;
				}), new object[0]);
			});
			this.httpBackGroundThread.IsBackground = true;
			this.httpBackGroundThread.Start();
		}

		// Token: 0x060005AE RID: 1454 RVA: 0x000248F0 File Offset: 0x00022AF0
		public BitmapImage byteArrayToImage(byte[] dataArray)
		{
			BitmapImage result;
			using (MemoryStream memoryStream = new MemoryStream(dataArray))
			{
				BitmapImage bitmapImage = new BitmapImage();
				bitmapImage.BeginInit();
				bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
				bitmapImage.StreamSource = memoryStream;
				bitmapImage.EndInit();
				result = bitmapImage;
			}
			return result;
		}

		// Token: 0x060005AF RID: 1455 RVA: 0x00024944 File Offset: 0x00022B44
		public byte[] imageToByteArray(string filePath)
		{
			System.Drawing.Image image = System.Drawing.Image.FromFile(filePath);
			MemoryStream memoryStream = new MemoryStream();
			image.Save(memoryStream, ImageFormat.Png);
			return memoryStream.ToArray();
		}

		// Token: 0x060005B0 RID: 1456 RVA: 0x00024970 File Offset: 0x00022B70
		private static string GetHexString(byte[] bt)
		{
			string text = string.Empty;
			foreach (byte b in bt)
			{
				int num = (int)(b & 15);
				int num2 = b >> 4 & 15;
				if (num2 > 9)
				{
					text += ((char)(num2 - 10 + 65)).ToString();
				}
				else
				{
					text += num2.ToString();
				}
				if (num > 9)
				{
					text += ((char)(num - 10 + 65)).ToString();
				}
				else
				{
					text += num.ToString();
				}
			}
			return text;
		}

		// Token: 0x17000141 RID: 321
		// (get) Token: 0x060005B1 RID: 1457 RVA: 0x00005B45 File Offset: 0x00003D45
		// (set) Token: 0x060005B2 RID: 1458 RVA: 0x00004BF2 File Offset: 0x00002DF2
		public bool IsCloseOnOverLayClick
		{
			get
			{
				return true;
			}
			set
			{
			}
		}

		// Token: 0x17000142 RID: 322
		// (get) Token: 0x060005B3 RID: 1459 RVA: 0x00004D85 File Offset: 0x00002F85
		// (set) Token: 0x060005B4 RID: 1460 RVA: 0x00004BF2 File Offset: 0x00002DF2
		public bool ShowControlInSeparateWindow
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		// Token: 0x060005B5 RID: 1461 RVA: 0x00005B48 File Offset: 0x00003D48
		public bool Close()
		{
			if (this.httpBackGroundThread != null)
			{
				this.httpBackGroundThread.Abort();
			}
			if (this.ParentWindow != null)
			{
				this.ParentWindow.HideDimOverlay();
			}
			base.Visibility = Visibility.Hidden;
			ImageTranslateControl.mInstance = null;
			return true;
		}

		// Token: 0x060005B6 RID: 1462 RVA: 0x00004DA3 File Offset: 0x00002FA3
		public bool Show()
		{
			base.Visibility = Visibility.Visible;
			return true;
		}

		// Token: 0x060005B7 RID: 1463 RVA: 0x00005B7E File Offset: 0x00003D7E
		public bool Hide()
		{
			if (this.ParentWindow != null)
			{
				this.ParentWindow.HideDimOverlay();
			}
			base.Visibility = Visibility.Hidden;
			return true;
		}

		// Token: 0x060005B8 RID: 1464 RVA: 0x00005B9B File Offset: 0x00003D9B
		private void mCloseButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.Close();
		}

		// Token: 0x060005B9 RID: 1465 RVA: 0x000249FC File Offset: 0x00022BFC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/imagetranslatecontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060005BA RID: 1466 RVA: 0x00024A2C File Offset: 0x00022C2C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mGrid = (Grid)target;
				return;
			case 2:
				this.mCloseButton = (CustomPictureBox)target;
				this.mCloseButton.MouseLeftButtonUp += this.mCloseButton_MouseLeftButtonUp;
				return;
			case 3:
				this.mFrontEndImage = (CustomPictureBox)target;
				return;
			case 4:
				this.mLoadingImage = (CustomPictureBox)target;
				return;
			case 5:
				this.mBootText = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400038E RID: 910
		private MainWindow ParentWindow;

		// Token: 0x0400038F RID: 911
		private Thread httpBackGroundThread;

		// Token: 0x04000390 RID: 912
		private static ImageTranslateControl mInstance;

		// Token: 0x04000391 RID: 913
		internal Grid mGrid;

		// Token: 0x04000392 RID: 914
		internal CustomPictureBox mCloseButton;

		// Token: 0x04000393 RID: 915
		internal CustomPictureBox mFrontEndImage;

		// Token: 0x04000394 RID: 916
		internal CustomPictureBox mLoadingImage;

		// Token: 0x04000395 RID: 917
		internal TextBlock mBootText;

		// Token: 0x04000396 RID: 918
		private bool _contentLoaded;
	}
}
