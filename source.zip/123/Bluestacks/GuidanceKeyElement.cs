﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000E3 RID: 227
	public class GuidanceKeyElement : UserControl, IComponentConnector
	{
		// Token: 0x17000177 RID: 375
		// (get) Token: 0x060009B5 RID: 2485 RVA: 0x0000806A File Offset: 0x0000626A
		internal List<IMAction> LstActionItem
		{
			get
			{
				return this.mActionItem;
			}
		}

		// Token: 0x17000178 RID: 376
		// (get) Token: 0x060009B6 RID: 2486 RVA: 0x0000806A File Offset: 0x0000626A
		// (set) Token: 0x060009B7 RID: 2487 RVA: 0x00008072 File Offset: 0x00006272
		internal List<IMAction> lstActionItem
		{
			get
			{
				return this.mActionItem;
			}
			set
			{
				this.mActionItem = value;
				this.PropertyType = IMAction.DictPropertyInfo[this.mActionItem[0].Type][this.ActionItemProperty].PropertyType;
			}
		}

		// Token: 0x060009B8 RID: 2488 RVA: 0x000080AC File Offset: 0x000062AC
		public GuidanceKeyElement(MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			InputMethod.SetIsInputMethodEnabled(this.mKeyTextBox, false);
		}

		// Token: 0x060009B9 RID: 2489 RVA: 0x00044770 File Offset: 0x00042970
		private void mGuidenceKey_KeyDown(object sender, KeyEventArgs e)
		{
			if (KMManager.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(KMManager.ParentWindow.SelectedConfig.SelectedControlScheme);
				if (KMManager.GuidanceWindow != null)
				{
					KMManager.GuidanceWindow.FillProfileComboBox();
				}
			}
			if (e.Key == Key.Escape)
			{
				return;
			}
			if (this.ActionItemProperty.StartsWith("Key"))
			{
				if (this.lstActionItem[0].Type == KeyActionType.Tap || this.lstActionItem[0].Type == KeyActionType.TapRepeat || this.lstActionItem[0].Type == KeyActionType.Script)
				{
					if (e.Key == Key.Back || e.SystemKey == Key.Back)
					{
						this.mKeyTextBox.Tag = string.Empty;
						BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + this.mKeyTextBox.Tag);
					}
					else if (IMAPKeys.mDictKeys.ContainsKey(e.SystemKey) || IMAPKeys.mDictKeys.ContainsKey(e.Key))
					{
						if (e.SystemKey == Key.LeftAlt || e.SystemKey == Key.RightAlt || e.SystemKey == Key.F10)
						{
							this.mKeyList.AddIfNotContain(e.SystemKey);
						}
						else if (e.KeyboardDevice.Modifiers != ModifierKeys.None)
						{
							if (e.KeyboardDevice.Modifiers == ModifierKeys.Alt)
							{
								this.mKeyList.AddIfNotContain(e.SystemKey);
							}
							else if (e.KeyboardDevice.Modifiers == (ModifierKeys.Alt | ModifierKeys.Shift))
							{
								this.mKeyList.AddIfNotContain(e.SystemKey);
							}
							else
							{
								this.mKeyList.AddIfNotContain(e.Key);
							}
						}
						else
						{
							this.mKeyList.AddIfNotContain(e.Key);
						}
					}
				}
				else
				{
					if (e.Key == Key.System && IMAPKeys.mDictKeys.ContainsKey(e.SystemKey))
					{
						this.mKeyTextBox.Tag = IMAPKeys.GetStringForFile(e.SystemKey);
						BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(e.SystemKey));
					}
					else if (IMAPKeys.mDictKeys.ContainsKey(e.Key))
					{
						this.mKeyTextBox.Tag = IMAPKeys.GetStringForFile(e.Key);
						BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(e.Key));
					}
					else if (e.Key == Key.Back)
					{
						this.mKeyTextBox.Tag = string.Empty;
						BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + string.Empty);
					}
					e.Handled = true;
				}
			}
			if (this.ActionItemProperty.Equals("GamepadStick"))
			{
				if (e.Key == Key.Back || e.Key == Key.Delete)
				{
					this.mKeyTextBox.Tag = string.Empty;
					BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + string.Empty);
				}
				e.Handled = true;
			}
			if (this.PropertyType.Equals(typeof(bool)))
			{
				this.mKeyTextBox.Tag = !Convert.ToBoolean(this.lstActionItem.First<IMAction>()[this.ActionItemProperty]);
				BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + this.mKeyTextBox.Tag);
				e.Handled = true;
			}
			this.mKeyTextBox.Focus();
			if (this.PropertyType.Equals(typeof(string)))
			{
				this.mKeyTextBox.SelectAll();
			}
		}

		// Token: 0x060009BA RID: 2490 RVA: 0x00044B08 File Offset: 0x00042D08
		private void KeyTextBox_KeyUp(object sender, KeyEventArgs e)
		{
			if (this.lstActionItem[0].Type == KeyActionType.Tap || this.lstActionItem[0].Type == KeyActionType.TapRepeat || this.lstActionItem[0].Type == KeyActionType.Script)
			{
				string text = string.Empty;
				string tag = string.Empty;
				if (this.mKeyList.Count >= 2)
				{
					text = IMAPKeys.GetStringForUI(this.mKeyList.ElementAt(this.mKeyList.Count - 2)) + " + " + IMAPKeys.GetStringForUI(this.mKeyList.ElementAt(this.mKeyList.Count - 1));
					tag = IMAPKeys.GetStringForFile(this.mKeyList.ElementAt(this.mKeyList.Count - 2)) + " + " + IMAPKeys.GetStringForFile(this.mKeyList.ElementAt(this.mKeyList.Count - 1));
					this.mKeyTextBox.Text = text;
					this.mKeyTextBox.Tag = tag;
					this.SetValueHandling();
				}
				else if (this.mKeyList.Count == 1)
				{
					text = IMAPKeys.GetStringForUI(this.mKeyList.ElementAt(0));
					tag = IMAPKeys.GetStringForFile(this.mKeyList.ElementAt(0));
					this.mKeyTextBox.Text = text;
					this.mKeyTextBox.Tag = tag;
					this.SetValueHandling();
				}
				this.mKeyTextBox.CaretIndex = this.mKeyTextBox.Text.Length;
				this.mKeyList.Clear();
			}
		}

		// Token: 0x060009BB RID: 2491 RVA: 0x00044C94 File Offset: 0x00042E94
		private void CheckIfKeyAlreadyUsed()
		{
			int num = 0;
			this.mKeyInfoPopup.IsOpen = false;
			this.mIsDuplicateString = false;
			foreach (IMAction imaction in this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls)
			{
				if (imaction.Type != KeyActionType.Alias)
				{
					foreach (KeyValuePair<string, PropertyInfo> keyValuePair in IMAction.DictPropertyInfo[imaction.Type])
					{
						if (keyValuePair.Key.ToString().StartsWith("Key") && this.mKeyTextBox.Tag.Equals(imaction[keyValuePair.Key].ToString()))
						{
							num++;
							if (num == 2)
							{
								this.mKeyTextBox.Style = (Style)base.FindResource("ErrorTextBoxStyle");
								this.mKeyTextBox.BorderBrush = Brushes.Red;
								this.mIsDuplicateString = true;
								this.mKeyInfoPopup.PlacementTarget = this.mKeyTextBox;
								this.mKeyInfoPopup.IsOpen = true;
								this.mKeyInfoPopup.StaysOpen = true;
								break;
							}
						}
					}
				}
			}
		}

		// Token: 0x060009BC RID: 2492 RVA: 0x00044E20 File Offset: 0x00043020
		private void mGuidenceKey_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.ActionItemProperty.StartsWith("Key"))
			{
				if (e.MiddleButton == MouseButtonState.Pressed)
				{
					e.Handled = true;
					this.mKeyTextBox.Tag = "MouseMButton";
					BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + "MouseMButton");
				}
				else if (e.RightButton == MouseButtonState.Pressed)
				{
					e.Handled = true;
					this.mKeyTextBox.Tag = "MouseRButton";
					BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + "MouseRButton");
				}
				else if (e.XButton1 == MouseButtonState.Pressed)
				{
					e.Handled = true;
					this.mKeyTextBox.Tag = "MouseXButton1";
					BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + "MouseXButton1");
				}
				else if (e.XButton2 == MouseButtonState.Pressed)
				{
					e.Handled = true;
					this.mKeyTextBox.Tag = "MouseXButton2";
					BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + "MouseXButton2");
				}
			}
			if (this.PropertyType.Equals(typeof(bool)))
			{
				this.mKeyTextBox.Tag = !Convert.ToBoolean(this.lstActionItem.First<IMAction>()[this.ActionItemProperty]);
				BlueStacksUIBinding.Bind(this.mKeyTextBox, Constants.ImapLocaleStringsConstant + this.mKeyTextBox.Tag);
			}
			if (e.LeftButton == MouseButtonState.Pressed && this.mKeyTextBox.IsKeyboardFocusWithin)
			{
				e.Handled = true;
			}
			this.mKeyTextBox.Focus();
			if (this.PropertyType.Equals(typeof(string)))
			{
				this.mKeyTextBox.SelectAll();
			}
		}

		// Token: 0x060009BD RID: 2493 RVA: 0x000080E8 File Offset: 0x000062E8
		private void mGuidenceKey_TextChanged(object sender, TextChangedEventArgs e)
		{
			this.SetValueHandling();
		}

		// Token: 0x060009BE RID: 2494 RVA: 0x00044FE4 File Offset: 0x000431E4
		private void SetValueHandling()
		{
			this.mKeyInfoPopup.IsOpen = false;
			this.mKeyTextBox.Style = (Style)this.mKeyTextBox.FindResource("TextBoxStyle1");
			string text = this.lstActionItem[0][this.ActionItemProperty].ToString();
			if (base.IsLoaded)
			{
				KMManager.CallGamepadHandler("true");
			}
			if (this.PropertyType.Equals(typeof(double)))
			{
				double num;
				if (double.TryParse(this.mKeyTextBox.Text, out num))
				{
					text = this.mKeyTextBox.Text;
				}
				else if (!string.IsNullOrEmpty(this.mKeyTextBox.Text))
				{
					this.mKeyTextBox.Text = text;
				}
			}
			else if (this.PropertyType.Equals(typeof(int)))
			{
				int num2;
				if (int.TryParse(this.mKeyTextBox.Text, out num2))
				{
					text = this.mKeyTextBox.Text;
				}
				else if (!string.IsNullOrEmpty(this.mKeyTextBox.Text))
				{
					this.mKeyTextBox.Text = text;
				}
			}
			else if (this.PropertyType.Equals(typeof(bool)))
			{
				text = this.mKeyTextBox.Tag.ToString();
			}
			else
			{
				text = this.mKeyTextBox.Tag.ToString();
			}
			this.Setvalue(text);
		}

		// Token: 0x060009BF RID: 2495 RVA: 0x0004514C File Offset: 0x0004334C
		internal void Setvalue(string value)
		{
			this.mKeyTextBox.Style = (Style)this.mKeyTextBox.FindResource("TextBoxStyle1");
			this.mKeyInfoPopup.IsOpen = false;
			foreach (IMAction imaction in this.lstActionItem)
			{
				if (imaction[this.ActionItemProperty].ToString().Contains("Gamepad"))
				{
					this.mGuidanceKeyGrid.ToolTip = this.mKeyTextBox.Text.ToUpper();
				}
				if (!imaction[this.ActionItemProperty].ToString().Equals(value))
				{
					imaction[this.ActionItemProperty] = value;
					GameControlWindow.sIsDirty = true;
				}
			}
			if (this.ActionItemProperty.StartsWith("Key"))
			{
				this.mKeyTextBox.Text = this.mKeyTextBox.Text.ToUpper();
				KMManager.sGamepadKeyElement = this;
				if (base.IsLoaded)
				{
					this.CheckIfKeyAlreadyUsed();
				}
			}
			if (this.ActionItemProperty.Contains("Gamepad"))
			{
				this.mKeyTextBox.Text = this.mKeyTextBox.Text.ToUpper();
				this.mGuidanceKeyGrid.ToolTip = this.mKeyTextBox.Text.ToUpper();
			}
			this.mKeyTextBox1.ItemsSource = this.mKeyTextBox.Text;
		}

		// Token: 0x060009C0 RID: 2496 RVA: 0x000452C8 File Offset: 0x000434C8
		private void SelectAddress(object sender, RoutedEventArgs e)
		{
			TextBox textBox = sender as TextBox;
			if (textBox != null && this.PropertyType.Equals(typeof(string)))
			{
				textBox.SelectAll();
			}
		}

		// Token: 0x060009C1 RID: 2497 RVA: 0x000452FC File Offset: 0x000434FC
		private void SelectivelyIgnoreMouseButton(object sender, MouseButtonEventArgs e)
		{
			if (this.PropertyType.Equals(typeof(string)))
			{
				TextBox textBox = sender as TextBox;
				if (textBox != null && !textBox.IsKeyboardFocusWithin)
				{
					e.Handled = true;
					textBox.Focus();
				}
			}
			if (base.IsLoaded)
			{
				KMManager.sGamepadKeyElement = this;
				KMManager.pressedGamepadKeyList.Clear();
				KMManager.CallGamepadHandler("true");
			}
		}

		// Token: 0x060009C2 RID: 2498 RVA: 0x00045364 File Offset: 0x00043564
		private void KeyTextBox_LostFocus(object sender, RoutedEventArgs e)
		{
			double num;
			if (this.PropertyType.Equals(typeof(double)) && !double.TryParse(this.mKeyTextBox.Text, out num))
			{
				this.Setvalue("0");
				this.mKeyTextBox.Text = "0";
			}
			int num2;
			if (this.PropertyType.Equals(typeof(int)) && !int.TryParse(this.mKeyTextBox.Text, out num2))
			{
				this.Setvalue("0");
				this.mKeyTextBox.Text = "0";
			}
			KMManager.CallGamepadHandler("false");
			KMManager.sGamepadKeyElement = null;
		}

		// Token: 0x060009C3 RID: 2499 RVA: 0x000080F0 File Offset: 0x000062F0
		private void KeyTextBox_MouseEnter(object sender, MouseEventArgs e)
		{
			if (this.mIsDuplicateString)
			{
				this.mKeyInfoPopup.PlacementTarget = this.mKeyTextBox;
				this.mKeyInfoPopup.IsOpen = true;
				this.mKeyInfoPopup.StaysOpen = true;
				return;
			}
			this.mKeyInfoPopup.IsOpen = false;
		}

		// Token: 0x060009C4 RID: 2500 RVA: 0x00008130 File Offset: 0x00006330
		private void KeyTextBox_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mKeyInfoPopup.IsOpen = false;
		}

		// Token: 0x060009C5 RID: 2501 RVA: 0x00045410 File Offset: 0x00043610
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/guidancekeyelement.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060009C6 RID: 2502 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060009C7 RID: 2503 RVA: 0x00045440 File Offset: 0x00043640
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mGuidenceTextBlock = (TextBlock)target;
				return;
			case 2:
				this.mGuidanceKeyGrid = (Grid)target;
				return;
			case 3:
				this.mKeyTextBox1 = (ItemsControl)target;
				return;
			case 4:
				this.mKeyTextBox = (TextBox)target;
				this.mKeyTextBox.PreviewKeyDown += this.mGuidenceKey_KeyDown;
				this.mKeyTextBox.PreviewMouseDown += this.mGuidenceKey_MouseDown;
				this.mKeyTextBox.TextChanged += this.mGuidenceKey_TextChanged;
				this.mKeyTextBox.PreviewMouseLeftButtonDown += this.SelectivelyIgnoreMouseButton;
				this.mKeyTextBox.LostFocus += this.KeyTextBox_LostFocus;
				this.mKeyTextBox.KeyUp += this.KeyTextBox_KeyUp;
				this.mKeyTextBox.MouseEnter += this.KeyTextBox_MouseEnter;
				this.mKeyTextBox.MouseLeave += this.KeyTextBox_MouseLeave;
				return;
			case 5:
				this.mKeyInfoPopup = (CustomPopUp)target;
				return;
			case 6:
				this.mMaskBorder = (Border)target;
				return;
			case 7:
				this.mKeyInfoText = (TextBlock)target;
				return;
			case 8:
				this.mDownArrow = (Path)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000703 RID: 1795
		private List<IMAction> mActionItem;

		// Token: 0x04000704 RID: 1796
		internal string ActionItemProperty;

		// Token: 0x04000705 RID: 1797
		private Type PropertyType = typeof(string);

		// Token: 0x04000706 RID: 1798
		private MainWindow ParentWindow;

		// Token: 0x04000707 RID: 1799
		private bool mIsDuplicateString;

		// Token: 0x04000708 RID: 1800
		private List<Key> mKeyList = new List<Key>();

		// Token: 0x04000709 RID: 1801
		internal TextBlock mGuidenceTextBlock;

		// Token: 0x0400070A RID: 1802
		internal Grid mGuidanceKeyGrid;

		// Token: 0x0400070B RID: 1803
		internal ItemsControl mKeyTextBox1;

		// Token: 0x0400070C RID: 1804
		internal TextBox mKeyTextBox;

		// Token: 0x0400070D RID: 1805
		internal CustomPopUp mKeyInfoPopup;

		// Token: 0x0400070E RID: 1806
		internal Border mMaskBorder;

		// Token: 0x0400070F RID: 1807
		internal TextBlock mKeyInfoText;

		// Token: 0x04000710 RID: 1808
		internal Path mDownArrow;

		// Token: 0x04000711 RID: 1809
		private bool _contentLoaded;
	}
}
