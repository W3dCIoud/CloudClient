﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Interop;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000054 RID: 84
	public class CustomPopUp : Popup
	{
		// Token: 0x060003AD RID: 941 RVA: 0x00004761 File Offset: 0x00002961
		private void CustomPopUp_Initialized(object sender, EventArgs e)
		{
			RenderHelper.ChangeRenderModeToSoftware(sender);
		}

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x060003AE RID: 942 RVA: 0x00004769 File Offset: 0x00002969
		// (set) Token: 0x060003AF RID: 943 RVA: 0x0000477B File Offset: 0x0000297B
		public bool IsTopmost
		{
			get
			{
				return (bool)base.GetValue(CustomPopUp.IsTopmostProperty);
			}
			set
			{
				base.SetValue(CustomPopUp.IsTopmostProperty, value);
			}
		}

		// Token: 0x060003B0 RID: 944 RVA: 0x0000478E File Offset: 0x0000298E
		public CustomPopUp()
		{
			base.Loaded += this.OnPopupLoaded;
			base.Unloaded += this.OnPopupUnloaded;
			base.Opened += this.CustomPopUp_Initialized;
		}

		// Token: 0x060003B1 RID: 945 RVA: 0x00019D50 File Offset: 0x00017F50
		private void OnPopupLoaded(object sender, RoutedEventArgs e)
		{
			if (this.mAlreadyLoaded)
			{
				return;
			}
			this.mAlreadyLoaded = true;
			UIElement child = base.Child;
			if (child != null)
			{
				child.AddHandler(UIElement.PreviewMouseLeftButtonDownEvent, new MouseButtonEventHandler(this.OnChildPreviewMouseLeftButtonDown), true);
			}
			this.mParentWindow = Window.GetWindow(this);
			if (this.mParentWindow == null)
			{
				return;
			}
			this.mParentWindow.Activated += this.OnParentWindowActivated;
			this.mParentWindow.Deactivated += this.OnParentWindowDeactivated;
		}

		// Token: 0x060003B2 RID: 946 RVA: 0x000047CC File Offset: 0x000029CC
		private void OnPopupUnloaded(object sender, RoutedEventArgs e)
		{
			if (this.mParentWindow == null)
			{
				return;
			}
			this.mParentWindow.Activated -= this.OnParentWindowActivated;
			this.mParentWindow.Deactivated -= this.OnParentWindowDeactivated;
		}

		// Token: 0x060003B3 RID: 947 RVA: 0x00004805 File Offset: 0x00002A05
		private void OnParentWindowActivated(object sender, EventArgs e)
		{
			this.SetTopmostState(true);
		}

		// Token: 0x060003B4 RID: 948 RVA: 0x0000480E File Offset: 0x00002A0E
		private void OnParentWindowDeactivated(object sender, EventArgs e)
		{
			if (!this.IsTopmost)
			{
				this.SetTopmostState(this.IsTopmost);
			}
		}

		// Token: 0x060003B5 RID: 949 RVA: 0x00004824 File Offset: 0x00002A24
		private void OnChildPreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			this.SetTopmostState(true);
			if (this.mParentWindow != null && !this.mParentWindow.IsActive && !this.IsTopmost)
			{
				this.mParentWindow.Activate();
			}
		}

		// Token: 0x060003B6 RID: 950 RVA: 0x00004856 File Offset: 0x00002A56
		private static void OnIsTopmostChanged(DependencyObject obj, DependencyPropertyChangedEventArgs e)
		{
			CustomPopUp customPopUp = (CustomPopUp)obj;
			customPopUp.SetTopmostState(customPopUp.IsTopmost);
		}

		// Token: 0x060003B7 RID: 951 RVA: 0x00004869 File Offset: 0x00002A69
		protected override void OnOpened(EventArgs e)
		{
			this.mParentWindow = Window.GetWindow(this);
			this.SetTopmostState(this.IsTopmost);
			base.OnOpened(e);
		}

		// Token: 0x060003B8 RID: 952 RVA: 0x00019DD4 File Offset: 0x00017FD4
		private void SetTopmostState(bool isTop)
		{
			try
			{
				if (this.mParentWindow != null && !isTop && InteropWindow.GetTopmostOwnerWindow(this.mParentWindow).Topmost)
				{
					isTop = true;
				}
				if (this.mAppliedTopMost != null)
				{
					bool? flag = this.mAppliedTopMost;
					bool flag2 = isTop;
					if (flag.GetValueOrDefault() == flag2 & flag != null)
					{
						return;
					}
				}
				if (base.Child != null)
				{
					HwndSource hwndSource;
					if ((hwndSource = (PresentationSource.FromVisual(base.Child) as HwndSource)) != null)
					{
						IntPtr handle = hwndSource.Handle;
						CustomPopUp.RECT rect;
						if (CustomPopUp.GetWindowRect(handle, out rect))
						{
							if (isTop)
							{
								CustomPopUp.SetWindowPos(handle, CustomPopUp.HWND_TOPMOST, rect.Left, rect.Top, (int)base.Width, (int)base.Height, 1563U);
							}
							else
							{
								CustomPopUp.SetWindowPos(handle, CustomPopUp.HWND_BOTTOM, rect.Left, rect.Top, (int)base.Width, (int)base.Height, 1563U);
								CustomPopUp.SetWindowPos(handle, CustomPopUp.HWND_TOP, rect.Left, rect.Top, (int)base.Width, (int)base.Height, 1563U);
								CustomPopUp.SetWindowPos(handle, CustomPopUp.HWND_NOTOPMOST, rect.Left, rect.Top, (int)base.Width, (int)base.Height, 1563U);
							}
							this.mAppliedTopMost = new bool?(isTop);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in set topmost state in custom popup: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x060003B9 RID: 953
		[DllImport("user32.dll")]
		[return: MarshalAs(UnmanagedType.Bool)]
		private static extern bool GetWindowRect(IntPtr hWnd, out CustomPopUp.RECT lpRect);

		// Token: 0x060003BA RID: 954
		[DllImport("user32.dll")]
		private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);

		// Token: 0x0400020B RID: 523
		public static readonly DependencyProperty IsTopmostProperty = DependencyProperty.Register("IsTopmost", typeof(bool), typeof(CustomPopUp), new FrameworkPropertyMetadata(false, new PropertyChangedCallback(CustomPopUp.OnIsTopmostChanged)));

		// Token: 0x0400020C RID: 524
		private bool? mAppliedTopMost;

		// Token: 0x0400020D RID: 525
		private bool mAlreadyLoaded;

		// Token: 0x0400020E RID: 526
		private Window mParentWindow;

		// Token: 0x0400020F RID: 527
		private static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);

		// Token: 0x04000210 RID: 528
		private static readonly IntPtr HWND_NOTOPMOST = new IntPtr(-2);

		// Token: 0x04000211 RID: 529
		private static readonly IntPtr HWND_TOP = new IntPtr(0);

		// Token: 0x04000212 RID: 530
		private static readonly IntPtr HWND_BOTTOM = new IntPtr(1);

		// Token: 0x04000213 RID: 531
		private const uint SWP_NOSIZE = 1U;

		// Token: 0x04000214 RID: 532
		private const uint SWP_NOMOVE = 2U;

		// Token: 0x04000215 RID: 533
		private const uint SWP_NOZORDER = 4U;

		// Token: 0x04000216 RID: 534
		private const uint SWP_NOREDRAW = 8U;

		// Token: 0x04000217 RID: 535
		private const uint SWP_NOACTIVATE = 16U;

		// Token: 0x04000218 RID: 536
		private const uint SWP_FRAMECHANGED = 32U;

		// Token: 0x04000219 RID: 537
		private const uint SWP_SHOWWINDOW = 64U;

		// Token: 0x0400021A RID: 538
		private const uint SWP_HIDEWINDOW = 128U;

		// Token: 0x0400021B RID: 539
		private const uint SWP_NOCOPYBITS = 256U;

		// Token: 0x0400021C RID: 540
		private const uint SWP_NOOWNERZORDER = 512U;

		// Token: 0x0400021D RID: 541
		private const uint SWP_NOSENDCHANGING = 1024U;

		// Token: 0x0400021E RID: 542
		private const uint TOPMOST_FLAGS = 1563U;

		// Token: 0x02000055 RID: 85
		public struct RECT
		{
			// Token: 0x0400021F RID: 543
			public int Left;

			// Token: 0x04000220 RID: 544
			public int Top;

			// Token: 0x04000221 RID: 545
			public int Right;

			// Token: 0x04000222 RID: 546
			public int Bottom;
		}
	}
}
