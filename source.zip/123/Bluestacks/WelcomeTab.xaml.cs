﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000210 RID: 528
	public partial class WelcomeTab : UserControl
	{
		// Token: 0x1700020C RID: 524
		// (get) Token: 0x060011FC RID: 4604 RVA: 0x0000CB45 File Offset: 0x0000AD45
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x1700020D RID: 525
		// (get) Token: 0x060011FD RID: 4605 RVA: 0x0000CB66 File Offset: 0x0000AD66
		internal bool IsPromotionVisible
		{
			get
			{
				return this.mPromotionGrid.Visibility == Visibility.Visible;
			}
		}

		// Token: 0x060011FE RID: 4606 RVA: 0x0000CB76 File Offset: 0x0000AD76
		public WelcomeTab()
		{
			this.InitializeComponent();
			if (this.ParentWindow != null)
			{
				this.ParentWindow.mCommonHandler.MacroButtonVisibilityChangedEvent += this.ParentWindow_MacroButtonVisibilityChangedEvent;
			}
		}

		// Token: 0x060011FF RID: 4607 RVA: 0x0006FD14 File Offset: 0x0006DF14
		private void ParentWindow_MacroButtonVisibilityChangedEvent(bool isVisible)
		{
			if (isVisible)
			{
				HomeApp homeApp = this.mHomeApp;
				IEnumerable<AppIcon> enumerable;
				if (homeApp == null)
				{
					enumerable = null;
				}
				else
				{
					enumerable = from x in homeApp.mMoreAppsDockPanel.Children.OfType<AppIcon>()
					where x.PackageName.Equals("macro_recorder")
					select x;
				}
				IEnumerable<AppIcon> source = enumerable;
				if (source.Count<AppIcon>() > 0)
				{
					source.FirstOrDefault<AppIcon>().Visibility = Visibility.Visible;
					return;
				}
			}
			else
			{
				HomeApp homeApp2 = this.mHomeApp;
				IEnumerable<AppIcon> enumerable2;
				if (homeApp2 == null)
				{
					enumerable2 = null;
				}
				else
				{
					enumerable2 = from x in homeApp2.mMoreAppsDockPanel.Children.OfType<AppIcon>()
					where x.PackageName.Equals("macro_recorder")
					select x;
				}
				IEnumerable<AppIcon> source2 = enumerable2;
				if (source2.Count<AppIcon>() > 0)
				{
					source2.FirstOrDefault<AppIcon>().Visibility = Visibility.Collapsed;
				}
			}
		}

		// Token: 0x06001200 RID: 4608 RVA: 0x0006FDD4 File Offset: 0x0006DFD4
		internal void Init()
		{
			this.mHomeApp = new HomeApp(this.ParentWindow);
			if (!this.mContentGrid.Children.Contains(this.mHomeApp))
			{
				this.mContentGrid.Children.Add(this.mHomeApp);
			}
			this.mHomeApp.Init();
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				this.mHomeApp.Visibility = Visibility.Hidden;
				this.mBackground.ImageName = Path.Combine(RegistryManager.Instance.ClientInstallDir, "Promo\\boot_promo_0.png");
				this.mBackground.Visibility = Visibility.Visible;
			}
			if (FeatureManager.Instance.IsPromotionDisabled)
			{
				this.RemovePromotionGrid();
				this.mHomeApp.mLoadingGrid.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x06001201 RID: 4609 RVA: 0x0000CBA8 File Offset: 0x0000ADA8
		internal void RemovePromotionGrid()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mPromotionGrid.Visibility = Visibility.Hidden;
				this.mPromotionControl.Stop();
				this.mHomeApp.mSearchTextBox.IsEnabled = true;
			}), new object[0]);
		}

		// Token: 0x04000CA0 RID: 3232
		internal HomeApp mHomeApp;

		// Token: 0x04000CA1 RID: 3233
		private MainWindow mMainWindow;
	}
}
