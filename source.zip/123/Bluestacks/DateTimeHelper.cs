﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000FC RID: 252
	internal class DateTimeHelper
	{
		// Token: 0x06000A37 RID: 2615 RVA: 0x00048698 File Offset: 0x00046898
		internal static string GetReadableDateTimeString(DateTime yourDate)
		{
			TimeSpan timeSpan = new TimeSpan(DateTime.Now.Ticks - yourDate.ToLocalTime().Ticks);
			Math.Abs(timeSpan.TotalSeconds);
			if (yourDate.ToLocalTime().Date == DateTime.Now.Date)
			{
				return "Today at " + yourDate.ToLocalTime().ToString("HH:mm");
			}
			if (yourDate.ToLocalTime().Date.Year == DateTime.Now.Date.Year)
			{
				return yourDate.ToLocalTime().ToString("%d MMM',' HH:mm");
			}
			return yourDate.ToLocalTime().ToString("%d MMM yyyy',' HH:mm");
		}
	}
}
