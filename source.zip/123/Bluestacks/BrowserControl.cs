﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using BlueStacks.BlueStacksUI.BTv;
using BlueStacks.Common;
using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Windows7.Multitouch;
using Windows7.Multitouch.Manipulation;
using Windows7.Multitouch.WPF;
using Xilium.CefGlue;
using Xilium.CefGlue.WPF;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200018B RID: 395
	public class BrowserControl : UserControl
	{
		// Token: 0x170001F1 RID: 497
		// (get) Token: 0x06000EBC RID: 3772 RVA: 0x0000AE8D File Offset: 0x0000908D
		// (set) Token: 0x06000EBD RID: 3773 RVA: 0x0000AEAE File Offset: 0x000090AE
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
			set
			{
				this.mMainWindow = value;
			}
		}

		// Token: 0x170001F2 RID: 498
		// (get) Token: 0x06000EBE RID: 3774 RVA: 0x0000AEB7 File Offset: 0x000090B7
		// (set) Token: 0x06000EBF RID: 3775 RVA: 0x0000AED3 File Offset: 0x000090D3
		public NoInternetControl NoInternetControl
		{
			get
			{
				if (this.mNoInternetControl == null)
				{
					this.mNoInternetControl = new NoInternetControl(this);
				}
				return this.mNoInternetControl;
			}
			set
			{
				this.mNoInternetControl = value;
			}
		}

		// Token: 0x14000020 RID: 32
		// (add) Token: 0x06000EC0 RID: 3776 RVA: 0x0005EA48 File Offset: 0x0005CC48
		// (remove) Token: 0x06000EC1 RID: 3777 RVA: 0x0005EA80 File Offset: 0x0005CC80
		public event ProcessMessageEventHandler ProcessMessageRecieved;

		// Token: 0x06000EC2 RID: 3778 RVA: 0x0000AEDC File Offset: 0x000090DC
		public BrowserControl()
		{
		}

		// Token: 0x06000EC3 RID: 3779 RVA: 0x0000AF14 File Offset: 0x00009114
		public void UpdateUrlAndRefresh(string newUrl)
		{
			this.mUrl = newUrl;
			if (this.mBrowser != null)
			{
				this.mBrowser.StartUrl = this.mUrl;
				this.SetVisibilityOfLoader(Visibility.Visible);
				this.mBrowser.NavigateTo(this.mUrl);
			}
		}

		// Token: 0x06000EC4 RID: 3780 RVA: 0x0000AF4E File Offset: 0x0000914E
		internal void NavigateTo(string url)
		{
			if (this.mBrowser != null)
			{
				this.SetVisibilityOfLoader(Visibility.Visible);
				this.mBrowser.NavigateTo(url);
			}
		}

		// Token: 0x06000EC5 RID: 3781 RVA: 0x0000AF6B File Offset: 0x0000916B
		public void RefreshBrowser()
		{
			if (this.mBrowser != null)
			{
				this.mBrowser.Refresh();
			}
		}

		// Token: 0x06000EC6 RID: 3782 RVA: 0x0005EAB8 File Offset: 0x0005CCB8
		public BrowserControl(string url)
		{
			this.InitBaseControl(url, 0f);
		}

		// Token: 0x06000EC7 RID: 3783 RVA: 0x0005EB08 File Offset: 0x0005CD08
		public void CallJsForMaps(string methodName, string appName, string packageName)
		{
			object[] array = new object[]
			{
				""
			};
			if (!string.IsNullOrEmpty(appName) || !string.IsNullOrEmpty(packageName))
			{
				array[0] = new JObject
				{
					{
						"name",
						appName
					},
					{
						"pkg",
						packageName
					}
				}.ToString(Formatting.None, new JsonConverter[0]);
			}
			if (this.mBrowser != null)
			{
				this.mBrowser.CallJs(methodName, array);
			}
		}

		// Token: 0x06000EC8 RID: 3784 RVA: 0x0005EB84 File Offset: 0x0005CD84
		internal void InitBaseControl(string url, float zoomLevel = 0f)
		{
			this.customZoomLevel = zoomLevel;
			this.mUrl = url;
			base.Visibility = Visibility.Hidden;
			base.IsVisibleChanged += this.BrowserControl_IsVisibleChanged;
			this.mGrid = new Grid();
			base.Content = this.mGrid;
			if (FeatureManager.Instance.IsCreateBrowserOnStart)
			{
				this.CreateNewBrowser();
			}
		}

		// Token: 0x06000EC9 RID: 3785 RVA: 0x0005EBE4 File Offset: 0x0005CDE4
		public void DisposeBrowser()
		{
			BrowserControl.sAllBrowserControls.Remove(this);
			if (this.mBrowser != null)
			{
				this.mGrid.Children.Remove(this.mBrowser);
				this.mBrowser.Dispose();
				this.mBrowserHost = null;
				this.mBrowser = null;
			}
		}

		// Token: 0x06000ECA RID: 3786 RVA: 0x0000AF80 File Offset: 0x00009180
		private void BrowserControl_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (base.IsVisible)
			{
				this.CreateNewBrowser();
			}
		}

		// Token: 0x06000ECB RID: 3787 RVA: 0x0000AF90 File Offset: 0x00009190
		internal void WelcomeTab_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (FeatureManager.Instance.IsBrowserKilledOnTabSwitch && ((UIElement)sender).Visibility != Visibility.Visible)
			{
				this.DisposeBrowser();
			}
		}

		// Token: 0x06000ECC RID: 3788 RVA: 0x0005EC34 File Offset: 0x0005CE34
		internal void CreateNewBrowser()
		{
			if (this.mBrowser == null && !string.IsNullOrEmpty(this.mUrl))
			{
				this.mBrowser = new Browser(this.customZoomLevel);
				BrowserControl.sAllBrowserControls.Add(this);
				this.mBrowser.StartUrl = this.mUrl;
				this.mGrid.Children.Add(this.mBrowser);
				this.mBrowser.LoadEnd += new LoadEndEventHandler(this.MBrowser_LoadEnd);
				this.mBrowser.ProcessMessageRecieved += new ProcessMessageEventHandler(this.Browser_ProcessMessageRecieved);
				this.mBrowser.Loaded += this.Browser_Loaded;
				this.mBrowser.LoadError += new LoadErrorEventHandler(this.Browser_LoadError);
				this.mBrowser.LoadingStateChange += new LoadingStateChangeEventHandler(this.Browser_LoadingStateChange);
				this.mBrowser.mWPFCefBrowserExceptionHandler += new ExceptionHandler(this.Browser_WPFCefBrowserExceptionHandler);
				if (RegistryManager.Instance.CefDevEnv == 1)
				{
					this.mBrowser.mAllowDevTool = true;
					this.mBrowser.mDevToolHeader = this.mUrl;
				}
				try
				{
					this.AddTouchHandler();
				}
				catch (Exception ex)
				{
					Logger.Error("exception adding touch handler: {0}", new object[]
					{
						ex
					});
				}
			}
		}

		// Token: 0x06000ECD RID: 3789 RVA: 0x0000AFB1 File Offset: 0x000091B1
		private void MBrowser_LoadEnd(object sender, LoadEndEventArgs e)
		{
			this.SetVisibilityOfLoader(Visibility.Hidden);
		}

		// Token: 0x06000ECE RID: 3790 RVA: 0x0005ED84 File Offset: 0x0005CF84
		private void Browser_LoadError(object sender, LoadErrorEventArgs e)
		{
			if (this.mBrowser != null)
			{
				Logger.Warning("Cef error code: {0}, error text: {1}", new object[]
				{
					e.ErrorCode,
					e.ErrorText
				});
				if (e.ErrorCode == -106 || e.ErrorCode == -111 || e.ErrorCode == -101 || e.ErrorCode == -21 || e.ErrorCode == -130 || (e.ErrorCode == -105 && !Utils.CheckForInternetConnection()))
				{
					this.mFailedUrl = e.FailedUrl;
					base.Dispatcher.Invoke(new Action(delegate()
					{
						if (!this.mGrid.Children.Contains(this.NoInternetControl))
						{
							this.mGrid.Children.Add(this.NoInternetControl);
						}
					}), new object[0]);
				}
			}
		}

		// Token: 0x06000ECF RID: 3791 RVA: 0x0005EE34 File Offset: 0x0005D034
		private void SetVisibilityOfLoader(Visibility visibility)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					Grid grid = this.Parent as Grid;
					if (grid != null)
					{
						IEnumerable<CustomPictureBox> enumerable = grid.Children.OfType<CustomPictureBox>();
						if (enumerable != null && enumerable.Count<CustomPictureBox>() > 0)
						{
							enumerable.First<CustomPictureBox>().Visibility = visibility;
						}
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in set visibility of web page loader : " + ex.ToString());
				}
			}), new object[0]);
		}

		// Token: 0x06000ED0 RID: 3792 RVA: 0x0000AFBA File Offset: 0x000091BA
		private void Browser_WPFCefBrowserExceptionHandler(object sender, Exception e)
		{
			Logger.Error("Handle Error in wpf cef browser.." + e.ToString());
		}

		// Token: 0x06000ED1 RID: 3793 RVA: 0x0005EE74 File Offset: 0x0005D074
		private void Browser_LoadingStateChange(object sender, LoadingStateChangeEventArgs e)
		{
			try
			{
				if (this.customZoomLevel == 0f)
				{
					this.mBrowser.SetZoomLevel(this.zoomLevel);
				}
				if (e.IsLoading)
				{
					base.Dispatcher.Invoke(new Action(delegate()
					{
						if (this.mGrid.Children.Contains(this.NoInternetControl))
						{
							this.mGrid.Children.Remove(this.NoInternetControl);
						}
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error while setting zoom in browser with url {0} and error :{1}", new object[]
				{
					this.mUrl,
					ex.ToString()
				});
			}
		}

		// Token: 0x06000ED2 RID: 3794 RVA: 0x0005EEFC File Offset: 0x0005D0FC
		private void Browser_Loaded(object sender, RoutedEventArgs e)
		{
			try
			{
				if (this.customZoomLevel == 0f)
				{
					Matrix transformToDevice = PresentationSource.FromVisual((Visual)sender).CompositionTarget.TransformToDevice;
					ScaleTransform scaleTransform = new ScaleTransform(1.0 / transformToDevice.M11, 1.0 / transformToDevice.M22);
					if (scaleTransform.CanFreeze)
					{
						scaleTransform.Freeze();
					}
					this.mBrowser.LayoutTransform = scaleTransform;
					this.zoomLevel = Math.Log(transformToDevice.M11) / Math.Log(1.2);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error while getting zoom of browser with url {0} and error :{1}", new object[]
				{
					this.mUrl,
					ex.ToString()
				});
			}
		}

		// Token: 0x06000ED3 RID: 3795 RVA: 0x0005EFCC File Offset: 0x0005D1CC
		private void AddTouchHandler()
		{
			try
			{
				if (Handler.DigitizerCapabilities.IsMultiTouchReady)
				{
					Logger.Info("adding touch handler");
					ManipulationProcessor mManipulationProcessor = new ManipulationProcessor(2);
					this.mBrowserHost = this.mBrowser.GetHost();
					Factory.EnableStylusEvents(this.ParentWindow);
					base.StylusDown += delegate(object s, StylusDownEventArgs e)
					{
						mManipulationProcessor.ProcessDown((uint)e.StylusDevice.Id, PointUtil.ToDrawingPointF(e.GetPosition(this)));
					};
					base.StylusUp += delegate(object s, StylusEventArgs e)
					{
						mManipulationProcessor.ProcessUp((uint)e.StylusDevice.Id, PointUtil.ToDrawingPointF(e.GetPosition(this)));
					};
					base.StylusMove += delegate(object s, StylusEventArgs e)
					{
						mManipulationProcessor.ProcessMove((uint)e.StylusDevice.Id, PointUtil.ToDrawingPointF(e.GetPosition(this)));
					};
					mManipulationProcessor.ManipulationDelta += this.ProcessManipulationDelta;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("exception in adding touch handler: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x06000ED4 RID: 3796 RVA: 0x0005F098 File Offset: 0x0005D298
		private void ProcessManipulationDelta(object sender, ManipulationDeltaEventArgs e)
		{
			Logger.Debug(string.Concat(new object[]
			{
				"ProcessManipulationDelta..",
				e.TranslationDelta.Height,
				"...",
				e.Location
			}));
			if (this.mBrowserHost == null)
			{
				this.mBrowserHost = this.mBrowser.GetHost();
			}
			CefMouseEvent cefMouseEvent = default(CefMouseEvent);
			cefMouseEvent.X = (int)e.Location.X;
			cefMouseEvent.Y = (int)e.Location.Y;
			CefMouseEvent cefMouseEvent2 = cefMouseEvent;
			this.mBrowserHost.SendMouseWheelEvent(cefMouseEvent2, 0, (int)e.TranslationDelta.Height);
			this.mBrowserHost.SendMouseMoveEvent(new CefMouseEvent(0, 0, 0), false);
		}

		// Token: 0x06000ED5 RID: 3797 RVA: 0x0005F168 File Offset: 0x0005D368
		private void Browser_ProcessMessageRecieved(object sender, ProcessMessageEventArgs e)
		{
			Logger.Info("Browser to client web call :" + e.Message);
			if (e.Message.Name.Equals("InstallApp"))
			{
				CefListValue arguments = e.Message.Arguments;
				string @string = arguments.GetString(0);
				string string2 = arguments.GetString(1);
				string string3 = arguments.GetString(2);
				string string4 = arguments.GetString(3);
				this.InstallApp(@string, string2, string3, string4);
				this.ParentWindow.Utils.SendMessageToAndroidForAffiliate(string4, this.SOURCE_APPCENTER);
				return;
			}
			if (e.Message.Name.Equals("InstallAppVersion"))
			{
				CefListValue arguments2 = e.Message.Arguments;
				string string5 = arguments2.GetString(0);
				string string6 = arguments2.GetString(1);
				string string7 = arguments2.GetString(2);
				string string8 = arguments2.GetString(3);
				string string9 = arguments2.GetString(4);
				this.InstallApp(string5, string6, string7, string8, string9);
				this.ParentWindow.Utils.SendMessageToAndroidForAffiliate(string8, this.SOURCE_APPCENTER);
				return;
			}
			if (e.Message.Name.Equals("InstallAppGooglePlay"))
			{
				CefListValue arguments3 = e.Message.Arguments;
				arguments3.GetString(0);
				string string10 = arguments3.GetString(1);
				arguments3.GetString(2);
				string string11 = arguments3.GetString(3);
				this.ShowAppInPlayStore(string11, string10);
				this.ParentWindow.Utils.SendMessageToAndroidForAffiliate(string11, this.SOURCE_APPCENTER);
				return;
			}
			if (e.Message.Name.Equals("GoogleSearch"))
			{
				string string12 = e.Message.Arguments.GetString(0);
				this.SearchAppInPlayStore(string12);
				ClientStats.SendGPlayClickStats(new Dictionary<string, string>
				{
					{
						"query",
						string12
					},
					{
						"source",
						"bs3_appsearch"
					}
				});
				return;
			}
			if (e.Message.Name.Equals("CloseSearch"))
			{
				this.CloseSearch();
				return;
			}
			if (e.Message.Name.Equals("RefreshSearch"))
			{
				CefListValue arguments4 = e.Message.Arguments;
				string searchString = string.Empty;
				if (arguments4.Count > 0)
				{
					searchString = arguments4.GetString(0);
				}
				this.RefreshSearch(searchString);
				return;
			}
			if (e.Message.Name.Equals("ShowWebPage"))
			{
				CefListValue arguments5 = e.Message.Arguments;
				string string13 = arguments5.GetString(0);
				string string14 = arguments5.GetString(1);
				this.ShowWebPage(string13, string14);
				return;
			}
			if (!e.Message.Name.Equals("CloseBlockerAd"))
			{
				if (e.Message.Name.Equals("CheckIfPremium"))
				{
					string string15 = e.Message.Arguments.GetString(0);
					this.CheckIfPremium(string15);
					return;
				}
				if (!e.Message.Name.Equals("GetImpressionId"))
				{
					if (e.Message.Name.Equals("sendFirebaseNotification"))
					{
						string json = e.Message.Arguments.GetString(0);
						base.Dispatcher.Invoke(new Action(delegate()
						{
							CloudNotificationManager.Instance.HandleCloudNotification(json, this.ParentWindow.mVmName);
						}), new object[0]);
						return;
					}
					if (e.Message.Name.Equals("PikaWorldProfileAdded"))
					{
						string string16 = e.Message.Arguments.GetString(0);
						RegistryManager.Instance.PikaWorldId = string16;
						return;
					}
					if (e.Message.Name.Equals("subscribeModule"))
					{
						string string17 = e.Message.Arguments.GetString(0);
						char[] separator = new char[]
						{
							','
						};
						string[] array = string17.Split(separator, StringSplitOptions.None);
						this.PopulateTagsInfo(array, array[0]);
						return;
					}
					if (e.Message.Name.Equals("unsubscribeModule"))
					{
						string string18 = e.Message.Arguments.GetString(0);
						char[] separator2 = new char[]
						{
							','
						};
						string[] tagsList = string18.Split(separator2, StringSplitOptions.None);
						this.RemoveTagsInfo(tagsList);
						return;
					}
					if (e.Message.Name.Equals("ApplyThemeName"))
					{
						string themeName = e.Message.Arguments.GetString(0);
						base.Dispatcher.Invoke(new Action(delegate()
						{
							this.ParentWindow.Utils.ApplyTheme(themeName);
							this.ParentWindow.mWelcomeTab.mHomeApp.RestoreWallpaperImage();
							BlueStacksUIColorManager.ApplyTheme(themeName);
						}), new object[0]);
						return;
					}
					if (e.Message.Name.Equals("GoToMapsTab"))
					{
						base.Dispatcher.Invoke(new Action(delegate()
						{
							this.GoToMapsTab();
						}), new object[0]);
						return;
					}
					if (e.Message.Name.Equals("HandleClick"))
					{
						string text = "";
						try
						{
							text = e.Message.Arguments.GetString(0);
							JToken res = JToken.Parse(text);
							base.Dispatcher.Invoke(new Action(delegate()
							{
								this.ParentWindow.HideDimOverlay();
								this.ParentWindow.Utils.HandleGenericActionFromDictionary(res.ToSerializableDictionary<string>(), "handle_browser_click", "");
							}), new object[0]);
							return;
						}
						catch (Exception ex)
						{
							Logger.Error(string.Concat(new string[]
							{
								"Error when processing click action received from gmapi. JsonString: ",
								text,
								Environment.NewLine,
								"Error: ",
								ex.ToString()
							}));
							return;
						}
					}
					if (e.Message.Name.Equals("UpdateQuestRules"))
					{
						string text2 = "";
						try
						{
							text2 = e.Message.Arguments.GetString(0);
							PromotionManager.ReadQuests(JToken.Parse(text2), true);
							return;
						}
						catch (Exception ex2)
						{
							Logger.Error(string.Concat(new string[]
							{
								"Error when processing UpdateQuestRules. JsonString: ",
								text2,
								Environment.NewLine,
								"Error: ",
								ex2.ToString()
							}));
							return;
						}
					}
					if (e.Message.Name.Equals("GetGamepadConnectionStatus"))
					{
						base.Dispatcher.Invoke(new Action(delegate()
						{
							if (this.ParentWindow != null)
							{
								this.ParentWindow.SendGamepadStatusToBrowsers(this.ParentWindow.IsGamepadConnected);
							}
						}), new object[0]);
						return;
					}
					if (e.Message.Name.Equals("CloseAnyPopup"))
					{
						base.Dispatcher.Invoke(new Action(delegate()
						{
							if (this.ParentWindow != null)
							{
								this.ParentWindow.HideDimOverlay();
							}
						}), new object[0]);
						return;
					}
					if (e.Message.Name.Equals("SearchAppcenter"))
					{
						string searchText = e.Message.Arguments.GetString(0);
						base.Dispatcher.Invoke(new Action(delegate()
						{
							this.ParentWindow.mCommonHandler.SearchAppCenter(searchText);
						}), new object[0]);
						return;
					}
					try
					{
						object[] array2 = null;
						if (e.Message.Arguments.Count > 0)
						{
							array2 = new object[e.Message.Arguments.Count];
							for (int i = 0; i < e.Message.Arguments.Count; i++)
							{
								if (e.Message.Arguments.GetString(i) != null)
								{
									array2[i] = e.Message.Arguments.GetString(i).ToString();
									Logger.Info("web api call.." + e.Message.Name + "..with args.." + e.Message.Arguments.GetString(i).ToString());
								}
								else
								{
									array2[i] = string.Empty;
								}
							}
						}
						base.GetType().GetMethod(e.Message.Name).Invoke(this, array2);
					}
					catch (Exception)
					{
					}
					ProcessMessageEventHandler processMessageRecieved = this.ProcessMessageRecieved;
					if (processMessageRecieved == null)
					{
						return;
					}
					processMessageRecieved.Invoke(sender, e);
				}
			}
		}

		// Token: 0x06000ED6 RID: 3798 RVA: 0x0005F918 File Offset: 0x0005DB18
		internal void RemoveTagsInfo(string[] tagsList)
		{
			foreach (string item in tagsList)
			{
				if (BrowserControl.mFirebaseTagsSubscribed.Contains(item))
				{
					BrowserControl.mFirebaseTagsSubscribed.Remove(item);
				}
			}
		}

		// Token: 0x06000ED7 RID: 3799 RVA: 0x0005F954 File Offset: 0x0005DB54
		public void PopulateTagsInfo(string[] tagsList, string methodName)
		{
			foreach (string text in tagsList)
			{
				if (!text.Equals(methodName))
				{
					BrowserControl.mFirebaseTagsSubscribed.Add(text);
				}
			}
			this.mFirebaseCallbackMethod = methodName;
		}

		// Token: 0x06000ED8 RID: 3800 RVA: 0x0000AFD1 File Offset: 0x000091D1
		public void GoToMapsTab()
		{
			if (this.ParentWindow != null)
			{
				this.ParentWindow.mTopBar.mAppTabButtons.GoToTab("pikaworld", true, false);
			}
		}

		// Token: 0x06000ED9 RID: 3801 RVA: 0x0005F990 File Offset: 0x0005DB90
		private void CheckIfPremium(string isPremium)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (isPremium.Equals("true", StringComparison.InvariantCultureIgnoreCase))
				{
					RegistryManager.Instance.IsPremium = true;
					this.ParentWindow.mTopBar.ChangeUserPremiumButton(true);
				}
				else
				{
					RegistryManager.Instance.IsPremium = false;
					this.ParentWindow.mTopBar.ChangeUserPremiumButton(false);
				}
				Action<bool> appRecommendationHandler = PromotionObject.AppRecommendationHandler;
				if (appRecommendationHandler == null)
				{
					return;
				}
				appRecommendationHandler(true);
			}), new object[0]);
		}

		// Token: 0x06000EDA RID: 3802 RVA: 0x0005F9D0 File Offset: 0x0005DBD0
		private void InstallApp(string iconUrl, string appName, string apkUrl, string package, string timestamp)
		{
			if (!string.IsNullOrEmpty(package))
			{
				Logger.Info("apkUrl: " + apkUrl);
				string empty = string.Empty;
				if (!string.IsNullOrEmpty(apkUrl))
				{
					base.Dispatcher.Invoke(new Action(delegate()
					{
						new DownloadInstallApk(this.ParentWindow).DownloadAndInstallApp(iconUrl, appName, apkUrl, package, false, true, timestamp);
					}), new object[0]);
				}
			}
		}

		// Token: 0x06000EDB RID: 3803 RVA: 0x0005FA64 File Offset: 0x0005DC64
		private void InstallApp(string iconUrl, string appName, string apkUrl, string package)
		{
			if (!string.IsNullOrEmpty(package))
			{
				Logger.Info("apkUrl: " + apkUrl);
				if (!string.IsNullOrEmpty(apkUrl))
				{
					base.Dispatcher.Invoke(new Action(delegate()
					{
						new DownloadInstallApk(this.ParentWindow).DownloadAndInstallApp(iconUrl, appName, apkUrl, package, false, true, "");
					}), new object[0]);
				}
			}
		}

		// Token: 0x06000EDC RID: 3804 RVA: 0x0005FAE8 File Offset: 0x0005DCE8
		private void ShowAppInPlayStore(string packageName, string appName)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.ParentWindow.mWelcomeTab.mFrontendPopupControl.Init(packageName, appName, PlayStoreAction.OpenApp, false);
				this.ParentWindow.mWelcomeTab.mFrontendPopupControl.Visibility = Visibility.Visible;
			}), new object[0]);
		}

		// Token: 0x06000EDD RID: 3805 RVA: 0x0005FB30 File Offset: 0x0005DD30
		private void SearchAppInPlayStore(string searchString)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (searchString != null)
				{
					this.ParentWindow.mWelcomeTab.mFrontendPopupControl.Init(searchString, LocaleStrings.GetLocalizedString("STRING_MORE_GOOGLE_SEARCH_RESULT", false) + " \"" + searchString + "\"", PlayStoreAction.SearchApp, false);
				}
			}), new object[0]);
		}

		// Token: 0x06000EDE RID: 3806 RVA: 0x0000AFF8 File Offset: 0x000091F8
		private void CloseSearch()
		{
			if (this.mBrowser != null)
			{
				this.mBrowser.NavigateTo(this.mUrl);
			}
		}

		// Token: 0x06000EDF RID: 3807 RVA: 0x00004BF2 File Offset: 0x00002DF2
		private void RefreshSearch(string searchString)
		{
		}

		// Token: 0x06000EE0 RID: 3808 RVA: 0x0005FB70 File Offset: 0x0005DD70
		public void ShowWebPage(string title, string webUrl)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (title == null)
				{
					title = "";
				}
				if (this.ParentWindow != null)
				{
					this.ParentWindow.Utils.AppendUrlWithCommonParamsAndOpenTab(webUrl, title, "cef_tab", "");
					return;
				}
				MainWindow activatedWindow = null;
				if (BlueStacksUIUtils.DictWindows.Count > 0)
				{
					activatedWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
				}
				activatedWindow.Dispatcher.Invoke(new Action(delegate()
				{
					activatedWindow.Utils.AppendUrlWithCommonParamsAndOpenTab(webUrl, title, "cef_tab", "");
				}), new object[0]);
			}), new object[0]);
		}

		// Token: 0x06000EE1 RID: 3809 RVA: 0x0000B013 File Offset: 0x00009213
		public void CloseSelf()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				AppTabButton selectedTab = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab;
				if (selectedTab != null)
				{
					this.ParentWindow.mTopBar.mAppTabButtons.CloseTab(selectedTab.TabKey, false, false, false, false, "");
				}
			}), new object[0]);
		}

		// Token: 0x06000EE2 RID: 3810 RVA: 0x0000B038 File Offset: 0x00009238
		public void CloseBrowserQuitPopup()
		{
			this.ParentWindow.CloseBrowserQuitPopup();
		}

		// Token: 0x06000EE3 RID: 3811 RVA: 0x0000B045 File Offset: 0x00009245
		internal void ReInitBrowser(string url)
		{
			this.mBrowser.Dispose();
			this.mBrowser = null;
			this.mUrl = url;
			this.CreateNewBrowser();
		}

		// Token: 0x06000EE4 RID: 3812 RVA: 0x0005FBB8 File Offset: 0x0005DDB8
		public void DownloadBTV()
		{
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				MainWindow window = BlueStacksUIUtils.DictWindows[BlueStacksUIUtils.DictWindows.Keys.ToList<string>()[0]];
				window.Dispatcher.Invoke(new Action(delegate()
				{
					BTVManager.Instance.MaybeDownloadAndLaunchBTv(window);
				}), new object[0]);
			}
		}

		// Token: 0x06000EE5 RID: 3813 RVA: 0x0005FC20 File Offset: 0x0005DE20
		public void DownloadDirectX()
		{
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				MainWindow activatedWindow = BlueStacksUIUtils.DictWindows[BlueStacksUIUtils.DictWindows.Keys.ToList<string>()[0]];
				activatedWindow.Dispatcher.Invoke(new Action(delegate()
				{
					string directXDownloadURL = "http://www.microsoft.com/en-us/download/details.aspx?id=35";
					CustomMessageWindow customMessageWindow = new CustomMessageWindow();
					customMessageWindow.AddButton(ButtonColors.Blue, "STRING_YES", delegate(object sender1, EventArgs e1)
					{
						BlueStacksUIUtils.OpenUrl(directXDownloadURL);
					}, null, false, null);
					customMessageWindow.AddButton(ButtonColors.White, "STRING_NO", null, null, false, null);
					BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_DIRECTX_DOWNLOAD", "");
					customMessageWindow.Owner = activatedWindow;
					customMessageWindow.ShowDialog();
					activatedWindow.BringIntoView();
				}), new object[0]);
			}
		}

		// Token: 0x06000EE6 RID: 3814 RVA: 0x0000B066 File Offset: 0x00009266
		public void SetSystemVolume(string level)
		{
			StreamManager.Instance.SetSystemVolume(level);
		}

		// Token: 0x06000EE7 RID: 3815 RVA: 0x0000B073 File Offset: 0x00009273
		public void SetMicVolume(string level)
		{
			if (level.Trim().Equals("0"))
			{
				StreamManager.mIsMicDisabled = true;
			}
			StreamManager.Instance.SetMicVolume(level);
		}

		// Token: 0x06000EE8 RID: 3816 RVA: 0x0000B098 File Offset: 0x00009298
		public void EnableWebcam(string width, string height, string position)
		{
			StreamManager.Instance.EnableWebcam(width, height, position);
		}

		// Token: 0x06000EE9 RID: 3817 RVA: 0x0000B0A7 File Offset: 0x000092A7
		public void DisableWebcamV2(string jsonString)
		{
			StreamManager.Instance.DisableWebcamV2(jsonString);
		}

		// Token: 0x06000EEA RID: 3818 RVA: 0x0000B0B4 File Offset: 0x000092B4
		public void MoveWebcam(string horizontal, string vertical)
		{
			StreamManager.Instance.MoveWebcam(horizontal, vertical);
		}

		// Token: 0x06000EEB RID: 3819 RVA: 0x0000B0C2 File Offset: 0x000092C2
		public void StopRecord()
		{
			if (StreamManager.Instance != null)
			{
				Logger.Info("Got StopRecord");
				StreamWindowUtility.UnSetOBSParentWindow();
				StreamManager.Instance.StopRecord(true);
			}
		}

		// Token: 0x06000EEC RID: 3820 RVA: 0x0000B0E5 File Offset: 0x000092E5
		public void StopStream()
		{
			StreamManager.Instance.StopStream();
		}

		// Token: 0x06000EED RID: 3821 RVA: 0x0000B0F1 File Offset: 0x000092F1
		public void ShowPreview()
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					StreamWindow.Instance.ShowGrid();
				}
				catch (Exception ex)
				{
					Logger.Error("ShowPreview Error: {0}", new object[]
					{
						ex
					});
				}
			}), new object[0]);
		}

		// Token: 0x06000EEE RID: 3822 RVA: 0x0000B128 File Offset: 0x00009328
		public void HidePreview()
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					StreamWindow.Instance.HideGrid();
				}
				catch (Exception ex)
				{
					Logger.Error("HidePreview Error: {0}", new object[]
					{
						ex
					});
				}
			}), new object[0]);
		}

		// Token: 0x06000EEF RID: 3823 RVA: 0x0000B15F File Offset: 0x0000935F
		public void StartObs(string callbackFunction)
		{
			this.InitStreamManager();
			StreamManager.Instance.StartObs();
			FilterDownloader instance = FilterDownloader.Instance;
			this.mBrowser.ExecuteJavaScript(callbackFunction + "('true');", this.mBrowser.getURL(), 0);
		}

		// Token: 0x06000EF0 RID: 3824 RVA: 0x0000B19A File Offset: 0x0000939A
		public void StartStreamViewStatsRecorder(string label, string jsonString)
		{
			StreamWindowUtility.AddNewStreamViewKey(label, jsonString);
		}

		// Token: 0x06000EF1 RID: 3825 RVA: 0x0005FC88 File Offset: 0x0005DE88
		public void GetRealtimeAppUsage(string callBackFunction)
		{
			try
			{
				Dictionary<string, Dictionary<string, long>> realtimeDictionary = AppUsageTimer.GetRealtimeDictionary();
				if (!string.IsNullOrEmpty(callBackFunction))
				{
					this.CallBackToHtml(callBackFunction, JSONUtils.GetJSONObjectString<long>(realtimeDictionary[this.ParentWindow.mVmName]));
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error while sending realtime dictionary to gmapi" + ex.ToString());
			}
		}

		// Token: 0x06000EF2 RID: 3826 RVA: 0x0005FCEC File Offset: 0x0005DEEC
		public void GetInstalledAppsJsonforJS(string callBackFunction)
		{
			bool flag = false;
			MainWindow mainWindow = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				mainWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			string mVmName = mainWindow.mVmName;
			string path = Path.Combine(RegistryStrings.GadgetDir, "apps_" + mVmName + ".json");
			string text = "[" + Environment.NewLine + "]";
			using (Mutex mutex = new Mutex(false, "BlueStacks_AppJsonUpdate"))
			{
				if (mutex.WaitOne())
				{
					try
					{
						StreamReader streamReader = new StreamReader(path);
						text = streamReader.ReadToEnd();
						streamReader.Close();
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to read apps json file... Err : " + ex.ToString());
					}
					finally
					{
						mutex.ReleaseMutex();
					}
				}
			}
			if (flag)
			{
				text = text.Replace("\"", "\\\"");
			}
			text = text.Replace("\n", "");
			text = text.Replace("\r", "");
			text = Regex.Replace(text, "\\s+", " ", RegexOptions.Multiline);
			if (!string.IsNullOrEmpty(callBackFunction))
			{
				this.CallBackToHtml(callBackFunction, text);
			}
		}

		// Token: 0x06000EF3 RID: 3827 RVA: 0x0005FE38 File Offset: 0x0005E038
		public string GetCurrentAppInfo(string callBackFunction)
		{
			MainWindow mainWindow = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				mainWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			AppTabButton selectedTab = mainWindow.mTopBar.mAppTabButtons.SelectedTab;
			if (selectedTab == null)
			{
				return "{}";
			}
			selectedTab.mTabType.ToString();
			string appName = selectedTab.AppName;
			string packageName = selectedTab.PackageName;
			JObject jobject = new JObject();
			jobject.Add("type", "app");
			jobject.Add("name", appName);
			jobject.Add("data", packageName);
			if (!string.IsNullOrEmpty(callBackFunction))
			{
				this.CallBackToHtml(callBackFunction, jobject.ToString(Formatting.None, new JsonConverter[0]));
			}
			return jobject.ToString(Formatting.None, new JsonConverter[0]);
		}

		// Token: 0x06000EF4 RID: 3828 RVA: 0x0000B1A3 File Offset: 0x000093A3
		public void StartStreamV2(string jsonString, string callbackStreamStatus, string callbackTabChanged)
		{
			Logger.Info("Got StartStreamV2");
			this.InitStreamManager();
			if (StreamManager.Instance.mReplayBufferEnabled)
			{
				StreamManager.Instance.StartReplayBuffer();
			}
			Logger.Info("Got StartStream");
			StreamManager.Instance.StartStream(jsonString, callbackStreamStatus, callbackTabChanged);
		}

		// Token: 0x06000EF5 RID: 3829 RVA: 0x0005FF0C File Offset: 0x0005E10C
		public void StartRecordV2(string jsonString)
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				JObject jobject = JObject.Parse(jsonString);
				string text = StreamManager.DEFAULT_NETWORK;
				bool flag = StreamManager.DEFAULT_ENABLE_FILTER;
				string text2 = StreamManager.DEFAULT_LAYOUT_THEME;
				bool flag2 = StreamManager.DEFAULT_SQUARE_THEME;
				string callbackAppInfo = null;
				if (jobject.Property("network") != null)
				{
					text = jobject["network"].ToString();
				}
				OBSRenderFrameSpecs obsrenderFrameSpecs = new OBSRenderFrameSpecs(jsonString);
				if (jobject.Property("enableFilter") != null)
				{
					flag = Convert.ToBoolean(jobject["enableFilter"].ToString());
				}
				if (jobject.Property("layoutTheme") != null && string.IsNullOrEmpty(jobject["layoutTheme"].ToString()))
				{
					text2 = jobject["layoutTheme"].ToString();
				}
				if (jobject.Property("squareTheme") != null)
				{
					flag2 = Convert.ToBoolean(jobject["squareTheme"].ToString());
				}
				if (jobject.Property("sendAppStatusHandler") != null)
				{
					callbackAppInfo = jobject["sendAppStatusHandler"].ToString();
				}
				if (flag2)
				{
					StreamManager.Instance.mAspectRatio = new Fraction(1L, 1L);
				}
				else
				{
					StreamManager.Instance.mAspectRatio = new Fraction(16L, 9L);
				}
				Logger.Info("network = {0}, position = {1}x{2}, size = {3}x{4}", new object[]
				{
					text,
					obsrenderFrameSpecs.xPosition,
					obsrenderFrameSpecs.yPosition,
					obsrenderFrameSpecs.width,
					obsrenderFrameSpecs.height
				});
				Logger.Info("enableFilter: {0}, layoutTheme: {1}", new object[]
				{
					flag,
					text2
				});
				StreamWindowUtility.sNetwork = text;
				this.InitStreamManager();
				if (StreamManager.Instance.mReplayBufferEnabled)
				{
					StreamManager.Instance.StartReplayBuffer();
				}
				StreamManager.Instance.mObsRenderFrame = obsrenderFrameSpecs;
				Logger.Info("Got StartRecord");
				StreamManager.Instance.StartRecord(text, flag, flag2, text2, callbackAppInfo);
			}), new object[0]);
		}

		// Token: 0x06000EF6 RID: 3830 RVA: 0x0005FF50 File Offset: 0x0005E150
		private StreamManager InitStreamManager()
		{
			if (StreamManager.Instance == null)
			{
				StreamManager.Instance = new StreamManager(this.mBrowser);
			}
			else
			{
				string hwnd;
				string text;
				StreamManager.Instance.GetStreamConfig(out hwnd, out text);
				StreamManager.Instance.SetHwnd(hwnd);
			}
			return StreamManager.Instance;
		}

		// Token: 0x06000EF7 RID: 3831 RVA: 0x0005FF94 File Offset: 0x0005E194
		public void makeWebCall(string url, string scriptToInvoke)
		{
			HttpWebRequest httpWebRequest = WebRequest.Create(url) as HttpWebRequest;
			httpWebRequest.Method = "GET";
			httpWebRequest.AutomaticDecompression = DecompressionMethods.GZip;
			httpWebRequest.Headers.Add(HttpRequestHeader.AcceptEncoding, "gzip");
			string str = "Bluestacks/" + RegistryManager.Instance.ClientVersion;
			httpWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36 " + str;
			new Uri(url);
			try
			{
				Logger.Info("making a webcall at url=" + url);
				string text = null;
				using (HttpWebResponse httpWebResponse = httpWebRequest.GetResponse() as HttpWebResponse)
				{
					using (Stream responseStream = httpWebResponse.GetResponseStream())
					{
						using (StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8))
						{
							text = streamReader.ReadToEnd();
						}
					}
				}
				object[] args = new object[]
				{
					text
				};
				this.mBrowser.CallJs(scriptToInvoke, args);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in MakeWebCall. err : " + ex.ToString());
				string text2 = "";
				object[] args2 = new object[]
				{
					text2
				};
				this.mBrowser.CallJs(scriptToInvoke, args2);
			}
		}

		// Token: 0x06000EF8 RID: 3832 RVA: 0x000600F0 File Offset: 0x0005E2F0
		public void LaunchDialog(string jsonString)
		{
			try
			{
				JObject jobject = JObject.Parse(jsonString);
				string paramsStr = "";
				if (jobject.Property("parameter") != null)
				{
					paramsStr = jobject["parameter"].ToString();
				}
				MainWindow mainWindow = null;
				if (BlueStacksUIUtils.DictWindows.Count > 0)
				{
					mainWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
				}
				mainWindow.Dispatcher.Invoke(new Action(delegate()
				{
					LayoutWindow.LaunchWindow(paramsStr);
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in launchDialog gmApi : " + ex.ToString());
			}
		}

		// Token: 0x06000EF9 RID: 3833 RVA: 0x000601A0 File Offset: 0x0005E3A0
		public void DialogClickHandler(string jsonString)
		{
			JObject obj = JObject.Parse(jsonString);
			bool isAppView = false;
			if (obj.Property("isAppView") != null)
			{
				isAppView = obj["isAppView"].ToObject<bool>();
			}
			MainWindow mainWindow = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				mainWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			mainWindow.Dispatcher.Invoke(new Action(delegate()
			{
				LayoutWindow.Instance.mClosingJsonString = jsonString;
				LayoutWindow.Instance.ChangeLayout(obj["layoutTheme"].ToString(), isAppView);
			}), new object[0]);
		}

		// Token: 0x06000EFA RID: 3834 RVA: 0x0006023C File Offset: 0x0005E43C
		public void CloseDialog(string jsonString)
		{
			MainWindow mainWindow = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				mainWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			try
			{
				mainWindow.Dispatcher.Invoke(new Action(delegate()
				{
					if (!StreamManager.Instance.mIsStreaming)
					{
						StreamWindowUtility.ReParentOBSWindow();
					}
					if (LayoutWindow.Instance != null)
					{
						LayoutWindow.Instance.mClosingJsonString = jsonString;
						LayoutWindow.Instance.Close();
						LayoutWindow.Instance = null;
					}
				}), new object[0]);
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000EFB RID: 3835 RVA: 0x000602AC File Offset: 0x0005E4AC
		public void ShowAdvancedSettings()
		{
			MainWindow mainWindow = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				mainWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			mainWindow.Dispatcher.Invoke(new Action(delegate()
			{
				AdvanceSettingsWindow.ShowWindow();
			}), new object[0]);
		}

		// Token: 0x06000EFC RID: 3836 RVA: 0x0006030C File Offset: 0x0005E50C
		public void LaunchFilterWindow(string channel, string sessionId)
		{
			MainWindow mainWindow = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				mainWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			mainWindow.Dispatcher.Invoke(new Action(delegate()
			{
				FilterWindow.LaunchWindow(channel, sessionId);
			}), new object[0]);
		}

		// Token: 0x06000EFD RID: 3837 RVA: 0x0006036C File Offset: 0x0005E56C
		public void ChangeFilterTheme(string theme)
		{
			string sCurrentAppPkg = FilterWindow.sCurrentAppPkg;
			FilterThemeConfig filterThemeConfig = StreamManager.Instance.ChangeTheme(sCurrentAppPkg, theme);
			if (filterThemeConfig != null)
			{
				object[] args = new object[]
				{
					filterThemeConfig.mFilterThemeSettings.ToJsonString()
				};
				this.mBrowser.CallJs("setSettings", args);
			}
		}

		// Token: 0x06000EFE RID: 3838 RVA: 0x000603B8 File Offset: 0x0005E5B8
		public void UpdateThemeSettings(string currentTheme, string settingsJson)
		{
			string sCurrentAppPkg = FilterWindow.sCurrentAppPkg;
			FilterThemeConfig filterThemeConfig = FilterUtility.GetFilterThemeConfig(sCurrentAppPkg, currentTheme);
			filterThemeConfig.mFilterThemeSettings = new FilterThemeSettings(settingsJson);
			bool flag = JObject.Parse(settingsJson)["webcam"].ToString().ToLower().Equals("true");
			if (flag != filterThemeConfig.mFilterThemeSettings.mIsWebCamOn)
			{
				if (flag)
				{
					StreamManager.Instance.SetAndEnableWebCamPosition(filterThemeConfig);
				}
				else
				{
					StreamManager.Instance.DisableWebcamV2("{}");
				}
				StreamWindow.Instance.ChangeWebCamState();
			}
			string str = RegistryManager.Instance.ClientBaseKeyPath + "\\Filter";
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(str + "\\" + sCurrentAppPkg, true);
			registryKey.SetValue(currentTheme, filterThemeConfig.ToJsonString(), RegistryValueKind.String);
			registryKey.Close();
			FilterUtility.SendRequestToCLRBrowser("updatesettings", new Dictionary<string, string>
			{
				{
					"settings",
					settingsJson
				}
			});
		}

		// Token: 0x06000EFF RID: 3839 RVA: 0x0006049C File Offset: 0x0005E69C
		public void CloseFilterWindow(string jsonArray)
		{
			if (FilterWindow.Instance == null)
			{
				Logger.Error("CloseFilterWindow called without initializing it. Ignoring...");
				return;
			}
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				object[] args = new object[0];
				StreamWindow.Instance.mbrowserControl.mBrowser.CallJs("closeFilter", args);
				if (!StreamManager.Instance.mIsStreaming)
				{
					StreamWindowUtility.ReParentOBSWindow();
				}
				FilterWindow.Instance.CloseFilterWindow(jsonArray);
				FilterWindow.Instance = null;
			}), new object[0]);
		}

		// Token: 0x06000F00 RID: 3840 RVA: 0x000604EC File Offset: 0x0005E6EC
		private void CallBackToHtml(string callBackFunction, string data)
		{
			string text;
			if (data == null)
			{
				text = callBackFunction + "()";
				return;
			}
			text = callBackFunction + "('" + data.Replace("'", "&#39;").Replace("%27", "&#39;") + "')";
			this.mBrowser.ExecuteJavaScript(text, this.mBrowser.getURL(), 0);
		}

		// Token: 0x04000A68 RID: 2664
		private string SOURCE_APPCENTER = "BSAppCenter";

		// Token: 0x04000A69 RID: 2665
		private float customZoomLevel;

		// Token: 0x04000A6A RID: 2666
		private MainWindow mMainWindow;

		// Token: 0x04000A6B RID: 2667
		private NoInternetControl mNoInternetControl;

		// Token: 0x04000A6C RID: 2668
		internal Browser mBrowser;

		// Token: 0x04000A6D RID: 2669
		internal string mUrl;

		// Token: 0x04000A6E RID: 2670
		private double zoomLevel = 1.0;

		// Token: 0x04000A70 RID: 2672
		public Grid mGrid;

		// Token: 0x04000A71 RID: 2673
		internal static List<BrowserControl> sAllBrowserControls = new List<BrowserControl>();

		// Token: 0x04000A72 RID: 2674
		internal static List<string> mFirebaseTagsSubscribed = new List<string>();

		// Token: 0x04000A73 RID: 2675
		internal string mFirebaseCallbackMethod = string.Empty;

		// Token: 0x04000A74 RID: 2676
		internal string mFailedUrl = string.Empty;

		// Token: 0x04000A75 RID: 2677
		private CefBrowserHost mBrowserHost;
	}
}
