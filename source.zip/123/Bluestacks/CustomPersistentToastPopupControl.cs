﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000053 RID: 83
	public class CustomPersistentToastPopupControl : UserControl, IComponentConnector
	{
		// Token: 0x060003A2 RID: 930 RVA: 0x000046C2 File Offset: 0x000028C2
		public CustomPersistentToastPopupControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x060003A3 RID: 931 RVA: 0x00019B20 File Offset: 0x00017D20
		public CustomPersistentToastPopupControl(Window window)
		{
			this.InitializeComponent();
			if (window != null)
			{
				Grid grid = new Grid();
				object content = window.Content;
				window.Content = grid;
				grid.Children.Add(content as UIElement);
				grid.Children.Add(this);
			}
		}

		// Token: 0x060003A4 RID: 932 RVA: 0x00019B70 File Offset: 0x00017D70
		public bool Init(MainWindow window, string text)
		{
			this.ParentWindow = window;
			if (this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsShootingModeTooltipEnabled && RegistryManager.Instance.IsShootingModeTooltipVisible)
			{
				base.Visibility = Visibility.Visible;
				this.mPersistentToastTextblock.Text = text;
				this.mPersistentToastPopupBorder.HorizontalAlignment = HorizontalAlignment.Center;
				this.mPersistentToastPopupBorder.VerticalAlignment = VerticalAlignment.Center;
				return true;
			}
			return false;
		}

		// Token: 0x060003A5 RID: 933 RVA: 0x000046D0 File Offset: 0x000028D0
		private void MCloseIcon_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mCloseSettingsPopup.IsOpen = true;
		}

		// Token: 0x060003A6 RID: 934 RVA: 0x000046DE File Offset: 0x000028DE
		private void Grid_MouseEnter(object sender, MouseEventArgs e)
		{
			(sender as Grid).Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#33FFFFFF"));
		}

		// Token: 0x060003A7 RID: 935 RVA: 0x000046FF File Offset: 0x000028FF
		private void Grid_MouseLeave(object sender, MouseEventArgs e)
		{
			(sender as Grid).Background = Brushes.Transparent;
		}

		// Token: 0x060003A8 RID: 936 RVA: 0x00004711 File Offset: 0x00002911
		private void mNeverShowAgain_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mCloseSettingsPopup.IsOpen = false;
			base.Visibility = Visibility.Collapsed;
			RegistryManager.Instance.IsShootingModeTooltipVisible = false;
		}

		// Token: 0x060003A9 RID: 937 RVA: 0x00004731 File Offset: 0x00002931
		private void Close_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mCloseSettingsPopup.IsOpen = false;
			base.Visibility = Visibility.Collapsed;
			this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsShootingModeTooltipEnabled = false;
		}

		// Token: 0x060003AA RID: 938 RVA: 0x00019BDC File Offset: 0x00017DDC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/custompersistenttoastpopupcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060003AB RID: 939 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060003AC RID: 940 RVA: 0x00019C0C File Offset: 0x00017E0C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mPersistentToastPopupBorder = (Border)target;
				return;
			case 2:
				this.mCloseIcon = (CustomPictureBox)target;
				this.mCloseIcon.MouseLeftButtonUp += this.MCloseIcon_MouseLeftButtonUp;
				return;
			case 3:
				this.mPersistentToastTextblock = (TextBlock)target;
				return;
			case 4:
				this.mCloseSettingsPopup = (CustomPopUp)target;
				return;
			case 5:
				this.dummyGrid = (Grid)target;
				return;
			case 6:
				this.mCloseSettingsPopupBorder = (Border)target;
				return;
			case 7:
				this.mMaskBorder1 = (Border)target;
				return;
			case 8:
				((Grid)target).MouseEnter += this.Grid_MouseEnter;
				((Grid)target).MouseLeave += this.Grid_MouseLeave;
				((Grid)target).MouseLeftButtonUp += this.mNeverShowAgain_MouseLeftButtonUp;
				return;
			case 9:
				((Grid)target).MouseEnter += this.Grid_MouseEnter;
				((Grid)target).MouseLeave += this.Grid_MouseLeave;
				((Grid)target).MouseLeftButtonUp += this.Close_MouseLeftButtonUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000202 RID: 514
		private MainWindow ParentWindow;

		// Token: 0x04000203 RID: 515
		internal Border mPersistentToastPopupBorder;

		// Token: 0x04000204 RID: 516
		internal CustomPictureBox mCloseIcon;

		// Token: 0x04000205 RID: 517
		internal TextBlock mPersistentToastTextblock;

		// Token: 0x04000206 RID: 518
		internal CustomPopUp mCloseSettingsPopup;

		// Token: 0x04000207 RID: 519
		internal Grid dummyGrid;

		// Token: 0x04000208 RID: 520
		internal Border mCloseSettingsPopupBorder;

		// Token: 0x04000209 RID: 521
		internal Border mMaskBorder1;

		// Token: 0x0400020A RID: 522
		private bool _contentLoaded;
	}
}
