﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000081 RID: 129
	public class MacroOverlay : UserControl, IDimOverlayControl, IComponentConnector
	{
		// Token: 0x17000143 RID: 323
		// (get) Token: 0x060005C0 RID: 1472 RVA: 0x00005BCC File Offset: 0x00003DCC
		// (set) Token: 0x060005C1 RID: 1473 RVA: 0x00005BD4 File Offset: 0x00003DD4
		public MainWindow ParentWindow
		{
			get
			{
				return this.mMainWindow;
			}
			set
			{
				this.mMainWindow = value;
			}
		}

		// Token: 0x060005C2 RID: 1474 RVA: 0x00005BDD File Offset: 0x00003DDD
		public MacroOverlay()
		{
			this.InitializeComponent();
		}

		// Token: 0x060005C3 RID: 1475 RVA: 0x00005BEB File Offset: 0x00003DEB
		public MacroOverlay(MainWindow mainWindow)
		{
			this.mainWindow = mainWindow;
		}

		// Token: 0x060005C4 RID: 1476 RVA: 0x00005BFA File Offset: 0x00003DFA
		private void CloseButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.HideOverlay();
			this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("abortReroll", null);
		}

		// Token: 0x060005C5 RID: 1477 RVA: 0x00005C18 File Offset: 0x00003E18
		private void HideOverlay()
		{
			this.mMainWindow.HideDimOverlay();
		}

		// Token: 0x060005C6 RID: 1478 RVA: 0x00024D64 File Offset: 0x00022F64
		internal void ShowPromptAndHideOverlay()
		{
			if (base.Visibility == Visibility.Visible)
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_REROLL_COMPLETED", "");
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
				this.HideOverlay();
			}
		}

		// Token: 0x060005C7 RID: 1479 RVA: 0x0000516D File Offset: 0x0000336D
		bool IDimOverlayControl.Close()
		{
			base.Visibility = Visibility.Hidden;
			return true;
		}

		// Token: 0x17000144 RID: 324
		// (get) Token: 0x060005C8 RID: 1480 RVA: 0x00005C25 File Offset: 0x00003E25
		// (set) Token: 0x060005C9 RID: 1481 RVA: 0x00005C2D File Offset: 0x00003E2D
		bool IDimOverlayControl.IsCloseOnOverLayClick
		{
			get
			{
				return this.mIsCloseOnOverLayClick;
			}
			set
			{
				this.mIsCloseOnOverLayClick = value;
			}
		}

		// Token: 0x17000145 RID: 325
		// (get) Token: 0x060005CA RID: 1482 RVA: 0x00005C36 File Offset: 0x00003E36
		// (set) Token: 0x060005CB RID: 1483 RVA: 0x00005C3E File Offset: 0x00003E3E
		public bool ShowControlInSeparateWindow
		{
			get
			{
				return this.mShowControlInSeparateWindow;
			}
			set
			{
				this.mShowControlInSeparateWindow = value;
			}
		}

		// Token: 0x060005CC RID: 1484 RVA: 0x00004DA3 File Offset: 0x00002FA3
		bool IDimOverlayControl.Show()
		{
			base.Visibility = Visibility.Visible;
			return true;
		}

		// Token: 0x060005CD RID: 1485 RVA: 0x00024DD8 File Offset: 0x00022FD8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/macrooverlay.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060005CE RID: 1486 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060005CF RID: 1487 RVA: 0x00005C47 File Offset: 0x00003E47
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				((CustomPictureBox)target).PreviewMouseLeftButtonUp += this.CloseButton_PreviewMouseLeftButtonUp;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x0400039B RID: 923
		private MainWindow mMainWindow;

		// Token: 0x0400039C RID: 924
		private bool mIsCloseOnOverLayClick;

		// Token: 0x0400039D RID: 925
		private MainWindow mainWindow;

		// Token: 0x0400039E RID: 926
		private bool mShowControlInSeparateWindow;

		// Token: 0x0400039F RID: 927
		private bool _contentLoaded;
	}
}
