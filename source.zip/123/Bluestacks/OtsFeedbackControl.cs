﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000097 RID: 151
	public class OtsFeedbackControl : UserControl, IComponentConnector
	{
		// Token: 0x06000689 RID: 1673 RVA: 0x00006410 File Offset: 0x00004610
		public OtsFeedbackControl(MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
		}

		// Token: 0x0600068A RID: 1674 RVA: 0x00006425 File Offset: 0x00004625
		private void CloseBtn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			BlueStacksUIUtils.CloseContainerWindow(this);
		}

		// Token: 0x0600068B RID: 1675 RVA: 0x00029864 File Offset: 0x00027A64
		private void SubmitButton_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				if (this.TestEmail(this.txtEmail.Text) && this.TestPhone(this.txtPhone.Text))
				{
					ClientStats.SendMiscellaneousStatsAsync("OTSFeedback", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, this.txtDescIssue.Text, this.txtEmail.Text, this.txtPhone.Text, null, null, null);
					new Thread(delegate()
					{
						try
						{
							new Process
							{
								StartInfo = 
								{
									Arguments = "-silent",
									FileName = Path.Combine(RegistryStrings.InstallDir, "HD-LogCollector.exe")
								}
							}.Start();
						}
						catch (Exception ex2)
						{
							Logger.Error("Exception in starting HD-logCollector.exe: " + ex2.ToString());
						}
					})
					{
						IsBackground = true
					}.Start();
					BlueStacksUIUtils.CloseContainerWindow(this);
					CustomMessageWindow customMessageWindow = new CustomMessageWindow();
					customMessageWindow.ImageName = "help";
					customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_THANK_YOU", false);
					customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_APPRECIATE_FEEDBACK", false);
					customMessageWindow.AddButton(ButtonColors.Blue, LocaleStrings.GetLocalizedString("STRING_CLOSE", false), null, null, false, null);
					customMessageWindow.Owner = this.ParentWindow;
					this.ParentWindow.ShowDimOverlay(null);
					customMessageWindow.ShowDialog();
					this.ParentWindow.HideDimOverlay();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Submitting ots feedback " + ex.ToString());
			}
		}

		// Token: 0x0600068C RID: 1676 RVA: 0x0000642D File Offset: 0x0000462D
		private bool TestEmail(string text)
		{
			BlueStacksUIBinding.BindColor(this.txtEmailBorder, Border.BorderBrushProperty, "SettingsWindowTabMenuItemForeground");
			if (!Regex.IsMatch(text, "^(?(\")(\".+?(?<!\\\\)\"@)|(([0-9a-z]((\\.(?!\\.))|[-!#\\$%&'\\*\\+/=\\?\\^`\\{\\}\\|~\\w])*)(?<=[0-9a-z])@))(?(\\[)(\\[(\\d{1,3}\\.){3}\\d{1,3}\\])|(([0-9a-z][-0-9a-z]*[0-9a-z]*\\.)+[a-z0-9][\\-a-z0-9]{0,22}[a-z0-9]))$", RegexOptions.IgnoreCase))
			{
				this.txtEmailBorder.BorderBrush = Brushes.Red;
				return false;
			}
			return true;
		}

		// Token: 0x0600068D RID: 1677 RVA: 0x00006465 File Offset: 0x00004665
		private bool TestPhone(string text)
		{
			BlueStacksUIBinding.BindColor(this.txtPhoneBorder, Border.BorderBrushProperty, "SettingsWindowTabMenuItemForeground");
			if (!Regex.IsMatch(text, OtsFeedbackControl.MakeCombinedPattern(OtsFeedbackControl.m_Phone_Patterns), RegexOptions.IgnoreCase))
			{
				this.txtPhoneBorder.BorderBrush = Brushes.Red;
				return false;
			}
			return true;
		}

		// Token: 0x0600068E RID: 1678 RVA: 0x000064A2 File Offset: 0x000046A2
		private static string MakeCombinedPattern(IEnumerable<string> patterns)
		{
			return string.Join("|", (from item in patterns
			select "(" + item + ")").ToArray<string>());
		}

		// Token: 0x0600068F RID: 1679 RVA: 0x000064D8 File Offset: 0x000046D8
		private void txtEmail_TextChanged(object sender, TextChangedEventArgs e)
		{
			this.TestEmail(this.txtEmail.Text);
		}

		// Token: 0x06000690 RID: 1680 RVA: 0x000064EC File Offset: 0x000046EC
		private void txtPhone_TextChanged(object sender, TextChangedEventArgs e)
		{
			this.TestPhone(this.txtPhone.Text);
		}

		// Token: 0x06000691 RID: 1681 RVA: 0x000299C8 File Offset: 0x00027BC8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/otsfeedbackcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000692 RID: 1682 RVA: 0x000299F8 File Offset: 0x00027BF8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mCloseBtn = (CustomPictureBox)target;
				this.mCloseBtn.MouseLeftButtonUp += this.CloseBtn_MouseLeftButtonUp;
				return;
			case 2:
				this.txtDescIssue = (TextBox)target;
				return;
			case 3:
				this.txtEmailBorder = (Border)target;
				return;
			case 4:
				this.txtEmail = (TextBox)target;
				this.txtEmail.TextChanged += this.txtEmail_TextChanged;
				return;
			case 5:
				this.txtPhoneBorder = (Border)target;
				return;
			case 6:
				this.txtPhone = (TextBox)target;
				this.txtPhone.TextChanged += this.txtPhone_TextChanged;
				return;
			case 7:
				((CustomButton)target).Click += this.SubmitButton_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000456 RID: 1110
		public MainWindow ParentWindow;

		// Token: 0x04000457 RID: 1111
		private static List<string> m_Phone_Patterns = new List<string>
		{
			"^[\\d\\s-\\+]{5,15}$"
		};

		// Token: 0x04000458 RID: 1112
		internal CustomPictureBox mCloseBtn;

		// Token: 0x04000459 RID: 1113
		internal TextBox txtDescIssue;

		// Token: 0x0400045A RID: 1114
		internal Border txtEmailBorder;

		// Token: 0x0400045B RID: 1115
		internal TextBox txtEmail;

		// Token: 0x0400045C RID: 1116
		internal Border txtPhoneBorder;

		// Token: 0x0400045D RID: 1117
		internal TextBox txtPhone;

		// Token: 0x0400045E RID: 1118
		private bool _contentLoaded;
	}
}
