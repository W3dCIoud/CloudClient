﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Forms.Integration;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;
using Xilium.CefGlue.WPF;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000279 RID: 633
	public class StreamWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x14000034 RID: 52
		// (add) Token: 0x060015A5 RID: 5541 RVA: 0x000849E0 File Offset: 0x00082BE0
		// (remove) Token: 0x060015A6 RID: 5542 RVA: 0x00084A18 File Offset: 0x00082C18
		public event ParentWindowEventhandler mWindowEvent;

		// Token: 0x14000035 RID: 53
		// (add) Token: 0x060015A7 RID: 5543 RVA: 0x00084A50 File Offset: 0x00082C50
		// (remove) Token: 0x060015A8 RID: 5544 RVA: 0x00084A88 File Offset: 0x00082C88
		private event EventHandler EndStreamingClickedEvent;

		// Token: 0x060015A9 RID: 5545 RVA: 0x00084AC0 File Offset: 0x00082CC0
		public StreamWindow()
		{
			StreamWindow.Instance = this;
			this.InitializeComponent();
			BtvApp.Init();
			base.Closing += this.HandleCloseEvent;
			this.SetControlProperties();
			this.mUrl = StreamWindowUtility.GetStreamWindowUrl();
			MiscUtils.SetWindowSizeAndLocation(this, "BTV", false);
			if (this.mUrl != null)
			{
				float zoomLevel = (float)(base.Width / 320.0);
				this.mbrowserControl = new BTvBrowserControl("http://bgp-btv.appspot.com/home?logo=null&videos=null&streaming=null", zoomLevel);
				this.mbrowserControl.IsVisibleChanged += this.MbrowserControl_IsVisibleChanged;
				this.BrowserGrid.Children.Add(this.mbrowserControl);
				Grid.SetRow(this.mbrowserControl, 0);
				Grid.SetColumnSpan(this.mbrowserControl, 3);
				Grid.SetRowSpan(this.mbrowserControl, 3);
			}
			this.ShowLoadingGrid();
			base.Activated += this.StreamWindow_Activated;
			this.TopBar.MouseLeftButtonDown += this.StreamWindow_MouseLeftButtonDown;
			this.EndStreamingClickedEvent += this.EndStreamingClicked;
		}

		// Token: 0x060015AA RID: 5546 RVA: 0x00084BD4 File Offset: 0x00082DD4
		private void MbrowserControl_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			this.mbrowserControl.mBrowser._popUpSize = new Size(base.Width * 3.0, base.Height * 1.5);
			this.mbrowserControl.mBrowser.SetIconFile(RegistryStrings.ProductIconCompletePath);
			this.mbrowserControl.mBrowser.LoadingStateChange += new LoadingStateChangeEventHandler(this.MBrowser_LoadingStateChange);
		}

		// Token: 0x060015AB RID: 5547 RVA: 0x0000F054 File Offset: 0x0000D254
		private void MBrowser_LoadingStateChange(object sender, LoadingStateChangeEventArgs e)
		{
			if (!e.IsLoading)
			{
				StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
				{
					if (!this.mIsFirstTimeLoadComplete)
					{
						Logger.Info("browser loading complete");
						this.mIsFirstTimeLoadComplete = true;
						this.mLoadingGrid.Visibility = Visibility.Hidden;
						this.BrowserGrid.Visibility = Visibility.Visible;
					}
				}), new object[0]);
			}
		}

		// Token: 0x060015AC RID: 5548 RVA: 0x0000F080 File Offset: 0x0000D280
		private void MbrowserControl_mWindowEvent(string topic, string data)
		{
			if (this.mWindowEvent != null)
			{
				this.mWindowEvent(topic, data);
			}
		}

		// Token: 0x060015AD RID: 5549 RVA: 0x00004BF2 File Offset: 0x00002DF2
		private void MCefBrowser_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
		}

		// Token: 0x060015AE RID: 5550 RVA: 0x0000F097 File Offset: 0x0000D297
		private void ShowLoadingGrid()
		{
			this.mLoadingGrid.Visibility = Visibility.Visible;
		}

		// Token: 0x060015AF RID: 5551 RVA: 0x0000F0A5 File Offset: 0x0000D2A5
		public static void HideNoWifiGrid()
		{
			StreamWindow.Instance.HideNoWifiGrid(true);
		}

		// Token: 0x060015B0 RID: 5552 RVA: 0x00084C48 File Offset: 0x00082E48
		public void HideNoWifiGrid(bool isHide)
		{
			if (isHide)
			{
				this.NoWifiGrid.Visibility = Visibility.Hidden;
				this.mbrowserControl.mBrowser.NavigateTo(StreamWindow.Instance.mUrl);
				this.mIsFirstTimeLoadComplete = false;
				this.mLoadingGrid.Visibility = Visibility.Visible;
				return;
			}
			this.BrowserGrid.Visibility = Visibility.Hidden;
			this.mLoadingGrid.Visibility = Visibility.Hidden;
			this.NoWifiGrid.Visibility = Visibility.Visible;
		}

		// Token: 0x060015B1 RID: 5553 RVA: 0x0000ED18 File Offset: 0x0000CF18
		public static void CloseButtonClicked()
		{
			StreamWindow.Instance.Close();
		}

		// Token: 0x060015B2 RID: 5554 RVA: 0x0000F0B2 File Offset: 0x0000D2B2
		private void StreamWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			base.DragMove();
		}

		// Token: 0x060015B3 RID: 5555 RVA: 0x0000F0BA File Offset: 0x0000D2BA
		private void StreamWindow_Activated(object sender, EventArgs e)
		{
			Logger.Info("HandleActivatedEvent");
			if (LayoutWindow.Instance != null)
			{
				LayoutWindow.Instance.Activate();
			}
		}

		// Token: 0x060015B4 RID: 5556 RVA: 0x00084CB8 File Offset: 0x00082EB8
		public void HandleCloseEvent(object sender, CancelEventArgs e)
		{
			Logger.Info("StreamWindow: HandleCloseEvent");
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				base.Hide();
			}), new object[0]);
			StreamWindow.KillOBS();
			if (LayoutWindow.Instance != null)
			{
				if (StreamManager.Instance != null)
				{
					LayoutWindow.Instance.UpdateRegistry();
				}
				LayoutWindow.Instance.mClosingJsonString = "{}";
				LayoutWindow.Instance.Close();
			}
			if (StreamManager.Instance != null)
			{
				StreamManager.Instance.Shutdown();
				StreamManager.Instance.mIsStreaming = false;
			}
			StreamWindow.Instance = null;
			StreamManager.Instance = null;
			this.DisposeBrowser();
			BTVManager.Instance.RestrictWindowResize(false);
			Stats.ResetSessionId();
			Logger.Info("Exiting");
		}

		// Token: 0x060015B5 RID: 5557 RVA: 0x00084D70 File Offset: 0x00082F70
		private static void KillOBS()
		{
			try
			{
				new Thread(delegate()
				{
					int num = 0;
					int num2 = 25;
					while (num < num2 && Process.GetProcessesByName("HD-OBS").Length != 0)
					{
						num++;
						if (num < num2)
						{
							Logger.Info("Waiting for HD-OBS to quit gracefully, retry: {0}", new object[]
							{
								num
							});
							Thread.Sleep(200);
						}
					}
					if (num >= num2)
					{
						ProcessUtils.KillProcessByName("HD-OBS");
					}
				})
				{
					IsBackground = true
				}.Start();
			}
			catch (Exception ex)
			{
				Logger.Info("Failed to kill HD-OBS.exe...Err : " + ex.ToString());
			}
		}

		// Token: 0x060015B6 RID: 5558 RVA: 0x0000F0D8 File Offset: 0x0000D2D8
		public void DisposeBrowser()
		{
			this.mbrowserControl.DisposeBrowser();
		}

		// Token: 0x060015B7 RID: 5559 RVA: 0x00084DD8 File Offset: 0x00082FD8
		private void SetControlProperties()
		{
			BlueStacksUIBinding.Bind(this.mCloseButton, "STRING_CLOSE");
			this.mCloseButton.MouseUp += this.CloseButton_MouseUp;
			this.mCloseButton.MouseLeftButtonDown += this.HandleMouseDown;
			BlueStacksUIBinding.Bind(this.mMinimizeButton, "STRING_MINIMIZE_TOOLTIP");
			this.mMinimizeButton.MouseUp += this.MinimizeButton_MouseUp;
			this.mMinimizeButton.MouseLeftButtonDown += this.HandleMouseDown;
		}

		// Token: 0x060015B8 RID: 5560 RVA: 0x0000553B File Offset: 0x0000373B
		private void HandleMouseDown(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x060015B9 RID: 5561 RVA: 0x00084E64 File Offset: 0x00083064
		private void CloseButton_MouseUp(object sender, MouseButtonEventArgs e)
		{
			if (StreamManager.Instance != null && StreamManager.Instance.mIsStreaming)
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.AddButton(ButtonColors.Red, "STRING_YES", this.EndStreamingClickedEvent, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, "STRING_NO", null, null, false, null);
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_CLOSE_MESSAGE_PROMPT", "");
				customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_CLOSE_MESSAGE_PROMPT", false);
				customMessageWindow.Owner = this;
				customMessageWindow.ShowDialog();
				return;
			}
			base.Close();
		}

		// Token: 0x060015BA RID: 5562 RVA: 0x00008193 File Offset: 0x00006393
		private void EndStreamingClicked(object sender, EventArgs e)
		{
			base.Close();
		}

		// Token: 0x060015BB RID: 5563 RVA: 0x0000F0E5 File Offset: 0x0000D2E5
		public void EvaluateJS(string script)
		{
			this.mbrowserControl.mBrowser.ExecuteJavaScript(script, this.mbrowserControl.mBrowser.getURL(), 0);
		}

		// Token: 0x060015BC RID: 5564 RVA: 0x0000F109 File Offset: 0x0000D309
		public void ChangeWebCamState()
		{
			this.mbrowserControl.mBrowser.ExecuteJavaScript("toggle_webcam_via_filter();", this.mbrowserControl.mBrowser.getURL(), 0);
		}

		// Token: 0x060015BD RID: 5565 RVA: 0x0000D7E5 File Offset: 0x0000B9E5
		private void MinimizeButton_MouseUp(object sender, MouseButtonEventArgs e)
		{
			base.WindowState = WindowState.Minimized;
		}

		// Token: 0x060015BE RID: 5566 RVA: 0x00084EF0 File Offset: 0x000830F0
		public void AddPanel(System.Windows.Forms.Panel panel)
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				this.PreviewHost.Child = panel;
				this.PreviewGrid.Visibility = Visibility.Visible;
			}), new object[0]);
		}

		// Token: 0x060015BF RID: 5567 RVA: 0x0000F131 File Offset: 0x0000D331
		public void ShowGrid()
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				this.PreviewGrid.Visibility = Visibility.Visible;
			}), new object[0]);
		}

		// Token: 0x060015C0 RID: 5568 RVA: 0x0000F155 File Offset: 0x0000D355
		public void HideGrid()
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				this.PreviewGrid.Visibility = Visibility.Hidden;
			}), new object[0]);
		}

		// Token: 0x060015C1 RID: 5569 RVA: 0x0000F179 File Offset: 0x0000D379
		public void StreamStarted()
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				BlueStacksUIBinding.Bind(this.mCloseButton, "STRING_CLOSE_WHILE_STREAMING_TOOLTIP");
				this.mCloseButton.ToolTip = LocaleStrings.GetLocalizedString("STRING_CLOSE_WHILE_STREAMING_TOOLTIP", false);
			}), new object[0]);
		}

		// Token: 0x060015C2 RID: 5570 RVA: 0x0000F19D File Offset: 0x0000D39D
		public void StreamEnded()
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				BlueStacksUIBinding.Bind(this.mCloseButton, "STRING_CLOSE");
				this.mCloseButton.ToolTip = LocaleStrings.GetLocalizedString("STRING_CLOSE", false);
			}), new object[0]);
		}

		// Token: 0x060015C3 RID: 5571 RVA: 0x0000F1C1 File Offset: 0x0000D3C1
		private void CustomWindow_Loaded(object sender, RoutedEventArgs e)
		{
			this.mCloseButton.ImageName = Path.Combine(RegistryManager.Instance.ClientInstallDir, "Assets\\closewindow.png");
		}

		// Token: 0x060015C4 RID: 5572 RVA: 0x00084F34 File Offset: 0x00083134
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/btv/wpffiles/streamwindow.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060015C5 RID: 5573 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060015C6 RID: 5574 RVA: 0x00084F64 File Offset: 0x00083164
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((StreamWindow)target).Loaded += this.CustomWindow_Loaded;
				return;
			case 2:
				this.TopBar = (Grid)target;
				return;
			case 3:
				this.mMinimizeButton = (CustomPictureBox)target;
				return;
			case 4:
				this.mCloseButton = (CustomPictureBox)target;
				return;
			case 5:
				this.WindowHeaderGrid = (Grid)target;
				return;
			case 6:
				this.TitleBarViewBox = (TextBlock)target;
				return;
			case 7:
				this.BrowserGrid = (Grid)target;
				return;
			case 8:
				this.BrowserHost = (WindowsFormsHost)target;
				return;
			case 9:
				this.PreviewGrid = (Grid)target;
				return;
			case 10:
				this.PreviewHost = (WindowsFormsHost)target;
				return;
			case 11:
				this.NoWifiGrid = (Grid)target;
				return;
			case 12:
				this.mLoadingGrid = (BlueStacks.BlueStacksUI.ProgressBar)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000F25 RID: 3877
		public static StreamWindow Instance;

		// Token: 0x04000F26 RID: 3878
		private string mUrl;

		// Token: 0x04000F27 RID: 3879
		private bool mIsFirstTimeLoadComplete;

		// Token: 0x04000F28 RID: 3880
		public BTvBrowserControl mbrowserControl;

		// Token: 0x04000F2B RID: 3883
		internal Grid TopBar;

		// Token: 0x04000F2C RID: 3884
		internal CustomPictureBox mMinimizeButton;

		// Token: 0x04000F2D RID: 3885
		internal CustomPictureBox mCloseButton;

		// Token: 0x04000F2E RID: 3886
		internal Grid WindowHeaderGrid;

		// Token: 0x04000F2F RID: 3887
		internal TextBlock TitleBarViewBox;

		// Token: 0x04000F30 RID: 3888
		internal Grid BrowserGrid;

		// Token: 0x04000F31 RID: 3889
		internal WindowsFormsHost BrowserHost;

		// Token: 0x04000F32 RID: 3890
		internal Grid PreviewGrid;

		// Token: 0x04000F33 RID: 3891
		internal WindowsFormsHost PreviewHost;

		// Token: 0x04000F34 RID: 3892
		internal Grid NoWifiGrid;

		// Token: 0x04000F35 RID: 3893
		internal BlueStacks.BlueStacksUI.ProgressBar mLoadingGrid;

		// Token: 0x04000F36 RID: 3894
		private bool _contentLoaded;
	}
}
