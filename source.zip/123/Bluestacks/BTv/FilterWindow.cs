﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Forms.Integration;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000273 RID: 627
	public class FilterWindow : Window, IComponentConnector
	{
		// Token: 0x0600157E RID: 5502 RVA: 0x00083B14 File Offset: 0x00081D14
		public static void LaunchWindow(string channel, string sessionId)
		{
			try
			{
				object obj = FilterWindow.mFilterWindowLock;
				lock (obj)
				{
					if (FilterWindow.Instance == null)
					{
						bool showFilterScreen = false;
						string currentAppPkg = FilterUtility.GetCurrentAppPkg();
						if (currentAppPkg != null)
						{
							FilterWindow.sCurrentAppPkg = currentAppPkg;
							if (FilterUtility.IsFilterApplicableApp(currentAppPkg))
							{
								string currentTheme = FilterUtility.GetCurrentTheme(currentAppPkg);
								if (!StreamManager.Instance.mCLRBrowserRunning)
								{
									StreamManager.Instance.InitCLRBrowser(currentAppPkg, currentTheme, true);
								}
								showFilterScreen = true;
							}
						}
						StreamWindowUtility.UnSetOBSParentWindow();
						FilterWindow.Instance = new FilterWindow();
						FilterWindow.Instance.Setup(channel, sessionId, showFilterScreen);
						FilterWindow.Instance.Show();
					}
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x0600157F RID: 5503 RVA: 0x0000EFB9 File Offset: 0x0000D1B9
		public FilterWindow()
		{
			this.InitializeComponent();
		}

		// Token: 0x06001580 RID: 5504 RVA: 0x00083BC4 File Offset: 0x00081DC4
		public void Setup(string channel, string sessionId, bool showFilterScreen)
		{
			FilterWindow.Instance = this;
			string text = BtvApp.sApplicationBaseUrl + this.FILTER_HOME_URL;
			if (!showFilterScreen)
			{
				text = BtvApp.sApplicationBaseUrl + this.FILTER_NA_URL;
			}
			text = Utils.GetString(RegistryManager.Instance.FilterUrl, text);
			text = text + "?channel=" + channel;
			if (showFilterScreen)
			{
				string currentAppPkg = FilterUtility.GetCurrentAppPkg();
				text = string.Concat(new string[]
				{
					text,
					"&session_id=",
					sessionId,
					"&guid=",
					RegistryManager.Instance.UserGuid
				});
				text = text + "&" + FilterUtility.GetQueryStringForTheme(currentAppPkg, FilterUtility.GetCurrentTheme(currentAppPkg));
			}
			double num = base.Width / 865.0;
			this.mbrowserControl = new BTvBrowserControl(text, 0f);
			this.BrowserGrid.Children.Add(this.mbrowserControl);
			this.mbrowserControl.Visibility = Visibility.Visible;
			Grid.SetRow(this.mbrowserControl, 0);
			Grid.SetColumn(this.mbrowserControl, 0);
			Grid.SetColumnSpan(this.mbrowserControl, 3);
			Grid.SetRowSpan(this.mbrowserControl, 3);
			if (showFilterScreen)
			{
				this.mOBSRenderFrame = new System.Windows.Forms.Panel();
				this.mOBSRenderFrame.Dock = DockStyle.Fill;
				this.mOBSRenderFrame.BackColor = Color.Black;
				this.mFilterAvailable = true;
			}
			if (showFilterScreen)
			{
				this.ObsHost.Child = this.mOBSRenderFrame;
				this.mOBSRenderFrame.BringToFront();
			}
			RegistryManager.Instance.ChannelName = channel;
		}

		// Token: 0x06001581 RID: 5505 RVA: 0x00083D3C File Offset: 0x00081F3C
		public void CloseFilterWindow(string jsonArray)
		{
			this.ReportToCloud(jsonArray);
			base.Hide();
			if (this.mOBSHandle != IntPtr.Zero)
			{
				InteropWindow.ShowWindow(this.mOBSHandle, 0);
				InteropWindow.SetParent(this.mOBSHandle, IntPtr.Zero);
			}
			FilterWindow.sCurrentAppPkg = null;
			if (this.mbrowserControl.mBrowser != null)
			{
				this.mbrowserControl.mBrowser.Dispose();
			}
			if (this.mFilterAvailable && StreamWindow.Instance != null)
			{
				StreamWindow.Instance.EvaluateJS("filter_added();");
			}
			base.Close();
		}

		// Token: 0x06001582 RID: 5506 RVA: 0x00083DD0 File Offset: 0x00081FD0
		public void ReParentOBSWindow()
		{
			this.mOBSHandle = InteropWindow.FindWindow("OBSWindowClass", null);
			IntPtr handle = this.mOBSRenderFrame.Handle;
			if (this.mOBSHandle != IntPtr.Zero)
			{
				Logger.Info("OBS Handle: {0}", new object[]
				{
					this.mOBSHandle.ToString()
				});
				if (StreamWindowUtility.sOBSDevEnv)
				{
					InteropWindow.SetWindowLong(this.mOBSHandle, -16, InteropWindow.GetWindowLong(this.mOBSHandle, -16) | Convert.ToInt32(1073741824U));
				}
				else
				{
					InteropWindow.SetWindowLong(this.mOBSHandle, -16, Convert.ToInt32(1073741824U));
				}
				InteropWindow.SetParent(this.mOBSHandle, handle);
				InteropWindow.SetWindowPos(this.mOBSHandle, (IntPtr)0, 0, 0, this.mOBSRenderFrame.Width, this.mOBSRenderFrame.Height, 80U);
				InteropWindow.ShowWindow(this.mOBSHandle, 5);
			}
		}

		// Token: 0x06001583 RID: 5507 RVA: 0x00083EBC File Offset: 0x000820BC
		public void ReportToCloud(string jsonArray)
		{
			JArray jarray = JArray.Parse(jsonArray);
			for (int i = 0; i < jarray.Count; i++)
			{
				JObject jobject = JObject.Parse(jarray[i].ToString());
				Dictionary<string, string> data = new Dictionary<string, string>();
				foreach (string text in (from p in jobject.Properties()
				select p.Name).ToList<string>())
				{
					if (jobject.Property(text) != null)
					{
						if (jobject[text].ToString().ToLower().Equals("true") || jobject[text].ToString().ToLower().Equals("false"))
						{
							data.Add(text, jobject[text].ToString().ToLower());
						}
						else
						{
							data.Add(text, jobject[text].ToString());
						}
					}
				}
				new Thread(delegate()
				{
					string text2 = RegistryManager.Instance.Host + "/stats/btvfunnelstats";
					try
					{
						string text3 = BstHttpClient.Post(text2, data, null, false, BtvApp.sVmName, 0, 1, 0, false);
						Logger.Debug("FilterWindow ReportToCloud response: {0}", new object[]
						{
							text3
						});
					}
					catch (Exception ex)
					{
						Logger.Error("Exception in ReportToCloud. url = {0}, data = {1} err : {2}", new object[]
						{
							text2,
							data,
							ex.ToString()
						});
					}
				})
				{
					IsBackground = true
				}.Start();
			}
		}

		// Token: 0x06001584 RID: 5508 RVA: 0x0000EFF3 File Offset: 0x0000D1F3
		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			this.ReParentOBSWindow();
		}

		// Token: 0x06001585 RID: 5509 RVA: 0x00084018 File Offset: 0x00082218
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/btv/wpffiles/filterwindow.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06001586 RID: 5510 RVA: 0x00084048 File Offset: 0x00082248
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((FilterWindow)target).Loaded += this.Window_Loaded;
				return;
			case 2:
				this.BrowserGrid = (Grid)target;
				return;
			case 3:
				this.ObsGrid = (Grid)target;
				return;
			case 4:
				this.ObsHost = (WindowsFormsHost)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000F00 RID: 3840
		internal static FilterWindow Instance = null;

		// Token: 0x04000F01 RID: 3841
		private string FILTER_HOME_URL = "filters/home/index.html";

		// Token: 0x04000F02 RID: 3842
		private string FILTER_NA_URL = "filters/home/NotAvailable.html";

		// Token: 0x04000F03 RID: 3843
		private System.Windows.Forms.Panel mOBSRenderFrame = new System.Windows.Forms.Panel();

		// Token: 0x04000F04 RID: 3844
		private bool mFilterAvailable;

		// Token: 0x04000F05 RID: 3845
		public static string sCurrentAppPkg;

		// Token: 0x04000F06 RID: 3846
		public IntPtr mOBSHandle = IntPtr.Zero;

		// Token: 0x04000F07 RID: 3847
		public BTvBrowserControl mbrowserControl;

		// Token: 0x04000F08 RID: 3848
		private static object mFilterWindowLock = new object();

		// Token: 0x04000F09 RID: 3849
		internal Grid BrowserGrid;

		// Token: 0x04000F0A RID: 3850
		internal Grid ObsGrid;

		// Token: 0x04000F0B RID: 3851
		internal WindowsFormsHost ObsHost;

		// Token: 0x04000F0C RID: 3852
		private bool _contentLoaded;
	}
}
