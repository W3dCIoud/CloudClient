﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Markup;
using BlueStacks.Common;
using Xilium.CefGlue.WPF;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000250 RID: 592
	public partial class BtvWebUserControl : BrowserControl
	{
		// Token: 0x0600143D RID: 5181 RVA: 0x0000E530 File Offset: 0x0000C730
		public BtvWebUserControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600143E RID: 5182 RVA: 0x0000E53E File Offset: 0x0000C73E
		public BtvWebUserControl(string url) : base(url)
		{
			this.InitializeComponent();
			base.ProcessMessageRecieved += new ProcessMessageEventHandler(this.Browser_ProcessMessageRecieved);
		}

		// Token: 0x0600143F RID: 5183 RVA: 0x0000E55F File Offset: 0x0000C75F
		private void Browser_ProcessMessageRecieved(object sender, ProcessMessageEventArgs e)
		{
			Logger.Info("Browser to client web call in feedback tab :" + e.Message);
		}
	}
}
