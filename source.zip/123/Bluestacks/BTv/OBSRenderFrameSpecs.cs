﻿using System;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x0200025F RID: 607
	public class OBSRenderFrameSpecs
	{
		// Token: 0x0600149D RID: 5277 RVA: 0x0007ECC4 File Offset: 0x0007CEC4
		public OBSRenderFrameSpecs(string jsonString)
		{
			JObject jobject = JObject.Parse(jsonString);
			if (jobject.Property("xPosition") != null)
			{
				this.xPosition = Convert.ToInt32(jobject["xPosition"].ToString());
			}
			if (jobject.Property("yPosition") != null)
			{
				this.yPosition = Convert.ToInt32(jobject["yPosition"].ToString());
			}
			if (jobject.Property("width") != null)
			{
				this.width = Convert.ToInt32(jobject["width"].ToString());
			}
			if (jobject.Property("height") != null)
			{
				this.height = Convert.ToInt32(jobject["height"].ToString());
			}
			string text = "twitch";
			if (jobject.Property("network") != null)
			{
				text = jobject["network"].ToString();
			}
			if (text.Equals("facebook"))
			{
				this.widthRatio = 1;
				this.heightRatio = 1;
			}
			else
			{
				this.widthRatio = 16;
				this.heightRatio = 9;
			}
			if (jobject.Property("widthRatio") != null)
			{
				this.widthRatio = Convert.ToInt32(jobject["widthRatio"].ToString());
			}
			if (jobject.Property("heightRatio") != null)
			{
				this.heightRatio = Convert.ToInt32(jobject["heightRatio"].ToString());
			}
			if (jobject.Property("preserveAspectRatio") != null)
			{
				this.preserveAspectRatio = jobject["preserveAspectRatio"].ToObject<bool>();
			}
		}

		// Token: 0x04000E5C RID: 3676
		public int xPosition = -1;

		// Token: 0x04000E5D RID: 3677
		public int yPosition = 73;

		// Token: 0x04000E5E RID: 3678
		public int width = 280;

		// Token: 0x04000E5F RID: 3679
		public int height = 158;

		// Token: 0x04000E60 RID: 3680
		public int widthRatio;

		// Token: 0x04000E61 RID: 3681
		public int heightRatio;

		// Token: 0x04000E62 RID: 3682
		public bool preserveAspectRatio = true;
	}
}
