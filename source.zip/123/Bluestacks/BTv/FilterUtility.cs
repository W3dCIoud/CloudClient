﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using BlueStacks.Common;
using Microsoft.Win32;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000259 RID: 601
	public class FilterUtility
	{
		// Token: 0x1700022C RID: 556
		// (get) Token: 0x0600147C RID: 5244 RVA: 0x0000E7BA File Offset: 0x0000C9BA
		// (set) Token: 0x0600147D RID: 5245 RVA: 0x0000E7C1 File Offset: 0x0000C9C1
		public static string ClientId
		{
			get
			{
				return FilterUtility.sClientId;
			}
			set
			{
				FilterUtility.sClientId = value;
			}
		}

		// Token: 0x0600147E RID: 5246 RVA: 0x0007E124 File Offset: 0x0007C324
		public static string GetCurrentAppPkg()
		{
			string result;
			try
			{
				MainWindow mainWindow = null;
				if (BlueStacksUIUtils.DictWindows.Count > 0)
				{
					mainWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
				}
				if (mainWindow != null)
				{
					AppTabButton selectedTab = mainWindow.mTopBar.mAppTabButtons.SelectedTab;
					if (selectedTab == null)
					{
						result = "";
					}
					else
					{
						result = selectedTab.PackageName;
					}
				}
				else
				{
					result = "xyz";
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to find current app package... Err : " + ex.ToString());
				result = null;
			}
			return result;
		}

		// Token: 0x0600147F RID: 5247 RVA: 0x0000E7C9 File Offset: 0x0000C9C9
		public static void CheckNewFiltersAvailable()
		{
			new Thread(delegate()
			{
				object obj = FilterUtility.sFilterDownloaderLock;
				lock (obj)
				{
					if (FilterDownloader.Instance != null)
					{
						FilterUtility.sRunFilterDownloaderAgain = true;
						return;
					}
				}
				FilterDownloader.Instance = new FilterDownloader();
				FilterDownloader.Instance.IsFilterUpdateAvailable();
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06001480 RID: 5248 RVA: 0x0000E7FB File Offset: 0x0000C9FB
		public static void UpdateLayout(string keyStr, string valueStr, bool lastCameraLayoutTheame)
		{
			if (lastCameraLayoutTheame)
			{
				RegistryManager.Instance.LastCameraLayoutTheme = valueStr;
				return;
			}
			RegistryManager.Instance.LayoutTheme = valueStr;
		}

		// Token: 0x06001481 RID: 5249 RVA: 0x0007E1AC File Offset: 0x0007C3AC
		public static void UpdateAppViewLayoutRegistry(bool valueStr)
		{
			int appViewLayout = 0;
			if (valueStr)
			{
				appViewLayout = 1;
			}
			RegistryManager.Instance.AppViewLayout = appViewLayout;
		}

		// Token: 0x06001482 RID: 5250 RVA: 0x0007E1CC File Offset: 0x0007C3CC
		public static FilterThemeConfig GetInitialConfigForTheme(string appPkg, string theme)
		{
			string text = FilterUtility.GetDefaultConfig(FilterUtility.GetFilterDir() + "\\filterthemes.js");
			if (text == null)
			{
				new FilterThemeConfig("{}");
			}
			JObject jobject = JObject.Parse(text);
			Logger.Info("GetInitialConfig {0} {1}", new object[]
			{
				appPkg,
				theme
			});
			JObject jobject2 = JObject.Parse(jobject["themes"][appPkg][theme].ToString());
			if (theme.Equals(jobject2["dir_name"].ToString()))
			{
				if (jobject2.Property("initial_config") != null)
				{
					text = jobject2["initial_config"].ToString();
				}
				else
				{
					text = "{}";
				}
				return new FilterThemeConfig(text);
			}
			return new FilterThemeConfig("{}");
		}

		// Token: 0x06001483 RID: 5251 RVA: 0x0007E28C File Offset: 0x0007C48C
		public static string GetQueryStringForTheme(string appPkg, string theme)
		{
			Logger.Info("In GetQueryStringForTheme");
			string text = "theme=" + theme;
			text = text + "&appPkg=" + appPkg;
			FilterThemeConfig filterThemeConfig = FilterUtility.GetFilterThemeConfig(appPkg, theme);
			if (filterThemeConfig != null)
			{
				foreach (string text2 in filterThemeConfig.mFilterThemeSettings.mOtherFields.Keys)
				{
					text = string.Concat(new string[]
					{
						text,
						"&",
						text2,
						"=",
						filterThemeConfig.mFilterThemeSettings.mOtherFields[text2]
					});
				}
			}
			return text;
		}

		// Token: 0x06001484 RID: 5252 RVA: 0x0007E34C File Offset: 0x0007C54C
		public static FilterThemeConfig GetFilterThemeConfig(string appPkg, string theme)
		{
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(FilterUtility.sFilterKeyPath + "\\" + appPkg, true);
			if (registryKey != null)
			{
				registryKey.SetValue("CurrentTheme", theme.ToLower(), RegistryValueKind.String);
				string text = (string)registryKey.GetValue(theme, null);
				FilterThemeConfig result;
				if (text == null)
				{
					Logger.Info("Setting Initial Config for {0}", new object[]
					{
						theme
					});
					result = FilterUtility.GetInitialConfigForTheme(appPkg, theme);
				}
				else
				{
					Logger.Info("Config theme for {0}: {1}", new object[]
					{
						theme,
						text
					});
					result = new FilterThemeConfig(text);
				}
				return result;
			}
			return null;
		}

		// Token: 0x06001485 RID: 5253 RVA: 0x0000E817 File Offset: 0x0000CA17
		public static string GetQueryStringForTheme(string theme)
		{
			if (FilterUtility.GetCurrentAppPkg() == null)
			{
				return string.Empty;
			}
			return FilterUtility.GetQueryStringForTheme(FilterUtility.GetCurrentAppPkg(), theme);
		}

		// Token: 0x06001486 RID: 5254 RVA: 0x0007E3DC File Offset: 0x0007C5DC
		public static string GetCurrentTheme(string appPkg)
		{
			if (appPkg == null)
			{
				return null;
			}
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(FilterUtility.sFilterKeyPath, true);
			RegistryKey registryKey2 = registryKey.OpenSubKey(appPkg, true);
			if (registryKey2 == null)
			{
				registryKey.CreateSubKey(appPkg);
				registryKey.Close();
				return FilterUtility.sDefaultTheme;
			}
			string text = (string)registryKey2.GetValue("CurrentTheme", FilterUtility.sDefaultTheme);
			Logger.Info("Current theme for appPkg: {0} value {1}", new object[]
			{
				appPkg,
				text
			});
			registryKey2.Close();
			return text;
		}

		// Token: 0x06001487 RID: 5255 RVA: 0x0000E831 File Offset: 0x0000CA31
		public static string GetFilterDir()
		{
			return Path.Combine(RegistryStrings.BtvDir, "filters");
		}

		// Token: 0x06001488 RID: 5256 RVA: 0x0000E842 File Offset: 0x0000CA42
		public static bool IsFilterApplicableApp()
		{
			return FilterUtility.IsFilterApplicableApp(FilterUtility.GetCurrentAppPkg());
		}

		// Token: 0x06001489 RID: 5257 RVA: 0x0007E454 File Offset: 0x0007C654
		public static string GetDefaultConfig(string filePath)
		{
			string text = null;
			try
			{
				text = File.ReadAllText(filePath);
				int num = text.IndexOf("{");
				text = text.Substring(num, text.Length - num).Trim();
				if (text.EndsWith(";"))
				{
					text = text.Substring(0, text.Length - 1);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to read filterApps.json. Error: {0}", new object[]
				{
					ex.ToString()
				});
			}
			return text;
		}

		// Token: 0x0600148A RID: 5258 RVA: 0x0007E4D8 File Offset: 0x0007C6D8
		public static void UpdateSupportedPackages()
		{
			object obj = FilterUtility.sSupportedPackageLock;
			lock (obj)
			{
				string defaultConfig = FilterUtility.GetDefaultConfig(FilterUtility.GetFilterDir() + "\\filterthemes.js");
				if (defaultConfig != null)
				{
					JArray jarray = JArray.Parse(JObject.Parse(defaultConfig)["supported_packages"].ToString());
					FilterUtility.sSupportedPackages = new string[jarray.Count];
					Logger.Info("{0} supported apps are:", new object[]
					{
						jarray.Count
					});
					for (int i = 0; i < jarray.Count; i++)
					{
						FilterUtility.sSupportedPackages[i] = jarray[i].ToString();
						Logger.Info(FilterUtility.sSupportedPackages[i]);
					}
				}
			}
		}

		// Token: 0x0600148B RID: 5259 RVA: 0x0007E5A0 File Offset: 0x0007C7A0
		public static bool IsFilterApplicableApp(string appPkg)
		{
			return false;
		}

		// Token: 0x0600148C RID: 5260 RVA: 0x0007E5B0 File Offset: 0x0007C7B0
		public static bool IsFilterAvailableForThisApp(string appPkg)
		{
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(FilterUtility.sFilterKeyPath);
			string json = (string)registryKey.GetValue("FilterAvailableForApps", "[]");
			registryKey.Close();
			JArray jarray = JArray.Parse(json);
			for (int i = 0; i < jarray.Count; i++)
			{
				if (appPkg.Equals(jarray[i].ToString()))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x0600148D RID: 5261 RVA: 0x0007E618 File Offset: 0x0007C818
		public static void SendRequestToCLRBrowser(string path, Dictionary<string, string> data)
		{
			string url = string.Format("http://127.0.0.1:{0}/{1}", RegistryManager.Instance.CLRBrowserServerPort, path);
			try
			{
				if (data == null)
				{
					BstHttpClient.Get(url, null, false, BtvApp.sVmName, 0, 1, 0, false);
				}
				else
				{
					BstHttpClient.Post(url, data, null, false, BtvApp.sVmName, 0, 1, 0, false);
				}
			}
			catch (Exception ex)
			{
				Logger.Info("error while sending request to CLR browser" + ex.ToString());
			}
		}

		// Token: 0x0600148E RID: 5262 RVA: 0x0007E694 File Offset: 0x0007C894
		public static void SetCurrentTheme(string appPkg, string theme)
		{
			if (appPkg == null)
			{
				return;
			}
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(FilterUtility.sFilterKeyPath + "\\" + appPkg, true);
			if (registryKey != null)
			{
				registryKey.SetValue("CurrentTheme", theme, RegistryValueKind.String);
				registryKey.Close();
			}
		}

		// Token: 0x04000E46 RID: 3654
		public static string[] sSupportedPackages;

		// Token: 0x04000E47 RID: 3655
		private static object sSupportedPackageLock = new object();

		// Token: 0x04000E48 RID: 3656
		private static string sFilterKeyPath = RegistryManager.Instance.ClientBaseKeyPath + "\\Filter";

		// Token: 0x04000E49 RID: 3657
		private static string sClientId = "";

		// Token: 0x04000E4A RID: 3658
		public static string sDefaultTheme = "basic";

		// Token: 0x04000E4B RID: 3659
		public static bool sRunFilterDownloaderAgain = false;

		// Token: 0x04000E4C RID: 3660
		public static object sFilterDownloaderLock = new object();

		// Token: 0x04000E4D RID: 3661
		public static FilterDownloader mFilterDownloader;
	}
}
