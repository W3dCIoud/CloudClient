﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x0200026F RID: 623
	public class BtvApp : Application, IComponentConnector
	{
		// Token: 0x0600155F RID: 5471 RVA: 0x0008374C File Offset: 0x0008194C
		public static void Init()
		{
			Logger.Info("BlueStacksTV: CLR version {0}", new object[]
			{
				Environment.Version
			});
			Logger.Info("IsAdministrator: {0}", new object[]
			{
				SystemUtils.IsAdministrator()
			});
			int @int = Utils.GetInt(RegistryManager.Instance.PartnerServerPort, 2871);
			BtvApp.sServerRootDir = RegistryStrings.BtvDir;
			BtvApp.sApplicationBaseUrl = "http://localhost:" + @int.ToString() + "/static/";
			FilterUtility.CheckNewFiltersAvailable();
		}

		// Token: 0x06001560 RID: 5472 RVA: 0x000837D0 File Offset: 0x000819D0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			base.StartupUri = new Uri("StreamWindow.xaml", UriKind.Relative);
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/btv/wpffiles/btvapp.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06001561 RID: 5473 RVA: 0x0000EDC7 File Offset: 0x0000CFC7
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			this._contentLoaded = true;
		}

		// Token: 0x04000EE9 RID: 3817
		public static int sBlueStacksTVPort = 2885;

		// Token: 0x04000EEA RID: 3818
		public static string sApplicationBaseUrl = "http://localhost:2881/static/";

		// Token: 0x04000EEB RID: 3819
		public static string sServerRootDir = null;

		// Token: 0x04000EEC RID: 3820
		public static string sVmName = "Android";

		// Token: 0x04000EED RID: 3821
		private bool _contentLoaded;
	}
}
