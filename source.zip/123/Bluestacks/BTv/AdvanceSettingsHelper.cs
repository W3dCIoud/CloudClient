﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000241 RID: 577
	public static class AdvanceSettingsHelper
	{
		// Token: 0x17000228 RID: 552
		// (get) Token: 0x060013ED RID: 5101 RVA: 0x0000E156 File Offset: 0x0000C356
		internal static Dictionary<string, string> ServersDict
		{
			get
			{
				if (AdvanceSettingsHelper.dictServers == null)
				{
					AdvanceSettingsHelper.LoadServers();
				}
				return AdvanceSettingsHelper.dictServers;
			}
		}

		// Token: 0x060013EE RID: 5102 RVA: 0x0007B084 File Offset: 0x00079284
		private static void LoadServers()
		{
			AdvanceSettingsHelper.dictServers = new Dictionary<string, string>();
			JToken[] array = JArray.Parse(AdvanceSettingsHelper.GetServersList()).ToArray<JToken>();
			for (int i = 0; i < array.Length; i++)
			{
				foreach (JObject jobject in ((JArray)array[i]).ToArray<JToken>())
				{
					try
					{
						if (AdvanceSettingsHelper.dictServers.Count == 0)
						{
							AdvanceSettingsHelper.dictServers.Add(jobject["name"].ToString(), jobject["url_template"].ToString());
						}
						else
						{
							AdvanceSettingsHelper.dictServers.Add(jobject["name"].ToString(), jobject["url_template"].ToString());
						}
					}
					catch
					{
					}
				}
			}
		}

		// Token: 0x060013EF RID: 5103 RVA: 0x0007B160 File Offset: 0x00079360
		private static string GetServersList()
		{
			string result = string.Empty;
			HttpWebRequest httpWebRequest = WebRequest.Create("https://cloud.bluestacks.com/btv/GetTwitchServers") as HttpWebRequest;
			httpWebRequest.Method = "GET";
			try
			{
				using (HttpWebResponse httpWebResponse = httpWebRequest.GetResponse() as HttpWebResponse)
				{
					using (Stream responseStream = httpWebResponse.GetResponseStream())
					{
						using (StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8))
						{
							result = streamReader.ReadToEnd();
						}
					}
				}
			}
			catch
			{
			}
			return result;
		}

		// Token: 0x060013F0 RID: 5104 RVA: 0x0007B218 File Offset: 0x00079418
		public static string GetServerPath()
		{
			string text = string.Empty;
			if (AdvanceSettingsHelper.ServersDict.ContainsKey(RegistryManager.Instance.TwitchServerPath))
			{
				text = AdvanceSettingsHelper.ServersDict[RegistryManager.Instance.TwitchServerPath];
			}
			if (string.IsNullOrEmpty(text))
			{
				text = AdvanceSettingsHelper.ServersDict[AdvanceSettingsHelper.ServersDict.Keys.ToList<string>()[0]];
			}
			return text;
		}

		// Token: 0x04000DE9 RID: 3561
		private static Dictionary<string, string> dictServers;
	}
}
