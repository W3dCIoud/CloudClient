﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;
using System.Windows.Forms;
using BlueStacks.Common;
using Microsoft.Win32;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000268 RID: 616
	public static class StreamWindowUtility
	{
		// Token: 0x0600152C RID: 5420
		[DllImport("user32.dll")]
		private static extern int GetSystemMetrics(int which);

		// Token: 0x1700022D RID: 557
		// (get) Token: 0x0600152D RID: 5421 RVA: 0x0000EB93 File Offset: 0x0000CD93
		public static System.Drawing.Size ScreenSize
		{
			get
			{
				if (StreamWindowUtility.sSize == null)
				{
					StreamWindowUtility.sSize = new System.Drawing.Size?(new System.Drawing.Size(StreamWindowUtility.GetSystemMetrics(0), StreamWindowUtility.GetSystemMetrics(1)));
				}
				return StreamWindowUtility.sSize.Value;
			}
		}

		// Token: 0x1700022E RID: 558
		// (get) Token: 0x0600152E RID: 5422 RVA: 0x0000EBC6 File Offset: 0x0000CDC6
		// (set) Token: 0x0600152F RID: 5423 RVA: 0x0000EBE5 File Offset: 0x0000CDE5
		public static string ProgramData
		{
			get
			{
				if (string.IsNullOrEmpty(StreamWindowUtility.sProgramData))
				{
					StreamWindowUtility.sProgramData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
				}
				return StreamWindowUtility.sProgramData;
			}
			set
			{
				StreamWindowUtility.sProgramData = value;
			}
		}

		// Token: 0x1700022F RID: 559
		// (get) Token: 0x06001530 RID: 5424 RVA: 0x0000EBED File Offset: 0x0000CDED
		// (set) Token: 0x06001531 RID: 5425 RVA: 0x0000EC0F File Offset: 0x0000CE0F
		public static string SetupDir
		{
			get
			{
				if (string.IsNullOrEmpty(StreamWindowUtility.sSetupDir))
				{
					StreamWindowUtility.sSetupDir = RegistryManager.Instance.SetupFolder;
				}
				return StreamWindowUtility.sSetupDir;
			}
			set
			{
				StreamWindowUtility.sSetupDir = value;
			}
		}

		// Token: 0x17000230 RID: 560
		// (get) Token: 0x06001532 RID: 5426 RVA: 0x0000EC17 File Offset: 0x0000CE17
		// (set) Token: 0x06001533 RID: 5427 RVA: 0x0000EC28 File Offset: 0x0000CE28
		public static string InstallDir
		{
			get
			{
				StreamWindowUtility.sInstallDir = RegistryStrings.BtvDir;
				return StreamWindowUtility.sInstallDir;
			}
			set
			{
				StreamWindowUtility.sInstallDir = value;
			}
		}

		// Token: 0x06001534 RID: 5428 RVA: 0x0000EC30 File Offset: 0x0000CE30
		public static void UnSetOBSParentWindow()
		{
			if (StreamWindowUtility.mOBSHandle != IntPtr.Zero)
			{
				InteropWindow.ShowWindow(StreamWindowUtility.mOBSHandle, 0);
				InteropWindow.SetParent(StreamWindowUtility.mOBSHandle, IntPtr.Zero);
			}
			StreamWindowUtility.sIsOBSReParented = false;
			StreamWindow.Instance.HideGrid();
		}

		// Token: 0x06001535 RID: 5429 RVA: 0x0000EC6F File Offset: 0x0000CE6F
		public static void ReParentOBSWindow()
		{
			if (StreamWindowUtility.sOBSRenderFrameSpecs != null)
			{
				StreamWindowUtility.ReParentOBSWindow(StreamWindowUtility.sOBSRenderFrameSpecs);
			}
		}

		// Token: 0x06001536 RID: 5430 RVA: 0x00082B60 File Offset: 0x00080D60
		public static void ChangeHeightOFOBSWindow(int height)
		{
			int actualY = (int)StreamWindow.Instance.BrowserGrid.RenderSize.Height * height / 100;
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				StreamWindow.Instance.BrowserGrid.RowDefinitions[0].Height = new GridLength((double)actualY, GridUnitType.Pixel);
			}), new object[0]);
		}

		// Token: 0x06001537 RID: 5431 RVA: 0x00082BB8 File Offset: 0x00080DB8
		public static void ReParentOBSWindow(OBSRenderFrameSpecs obsRenderFrameSpecs)
		{
			try
			{
				if (StreamWindowUtility.sIsOBSReParented)
				{
					Logger.Info("skipping reparenting as already reparented");
				}
				else
				{
					StreamWindowUtility.sOBSRenderFrameSpecs = obsRenderFrameSpecs;
					int actualWidth = (int)StreamWindow.Instance.BrowserGrid.RenderSize.Width * StreamWindowUtility.sOBSRenderFrameSpecs.width / 100;
					int y = (int)StreamWindow.Instance.BrowserGrid.RenderSize.Height * StreamWindowUtility.sOBSRenderFrameSpecs.height / 100;
					int actualY = (int)StreamWindow.Instance.BrowserGrid.RenderSize.Height * StreamWindowUtility.sOBSRenderFrameSpecs.yPosition / 100;
					int actualX = StreamWindowUtility.sOBSRenderFrameSpecs.xPosition;
					if (StreamWindowUtility.sOBSRenderFrameSpecs.xPosition != -1)
					{
						actualX = (int)StreamWindow.Instance.BrowserGrid.RenderSize.Width * StreamWindowUtility.sOBSRenderFrameSpecs.xPosition / 100;
					}
					System.Drawing.Point point = new System.Drawing.Point(actualWidth, y);
					Logger.Info("GridSizeForRenderFrame {0} x {1}", new object[]
					{
						point.X,
						point.Y
					});
					System.Drawing.Size renderFrameSize = new System.Drawing.Size(point.X * StreamWindowUtility.sDpi / 96, point.Y * StreamWindowUtility.sDpi / 96);
					if (StreamWindowUtility.mOBSRenderFrame == null)
					{
						StreamWindowUtility.mOBSRenderFrame = new Panel();
						StreamWindowUtility.mOBSRenderFrame.BackColor = Color.Black;
					}
					StreamWindowUtility.mOBSRenderFrame.Size = renderFrameSize;
					StreamWindow.Instance.AddPanel(StreamWindowUtility.mOBSRenderFrame);
					if (!StreamWindowUtility.sIsOBSReParented)
					{
						StreamWindow.Instance.HideGrid();
					}
					IntPtr panelHandle = StreamWindowUtility.mOBSRenderFrame.Handle;
					StreamWindowUtility.mOBSRenderFrame.BringToFront();
					new Thread(delegate()
					{
						StreamWindowUtility.mOBSHandle = InteropWindow.FindWindow("OBSWindowClass", null);
						int requiredHeight = renderFrameSize.Height;
						try
						{
							if (obsRenderFrameSpecs.preserveAspectRatio)
							{
								requiredHeight = obsRenderFrameSpecs.heightRatio * renderFrameSize.Width / obsRenderFrameSpecs.widthRatio;
								Logger.Info("RenderFrame {0} x {1}", new object[]
								{
									renderFrameSize.Width,
									renderFrameSize.Height
								});
							}
							goto IL_DE;
						}
						catch (Exception ex2)
						{
							Logger.Error("ReParentOBSWindow Error : {0}", new object[]
							{
								ex2.ToString()
							});
							goto IL_DE;
						}
						IL_C7:
						Thread.Sleep(100);
						StreamWindowUtility.mOBSHandle = InteropWindow.FindWindow("OBSWindowClass", null);
						IL_DE:
						if (!(StreamWindowUtility.mOBSHandle == IntPtr.Zero))
						{
							StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
							{
								StreamWindowUtility.mOBSRenderFrame.Size = new System.Drawing.Size(renderFrameSize.Width, requiredHeight);
								StreamWindow.Instance.BrowserGrid.RowDefinitions[0].Height = new GridLength((double)actualY, GridUnitType.Pixel);
								StreamWindow.Instance.BrowserGrid.RowDefinitions[1].Height = new GridLength((double)(requiredHeight * 96 / StreamWindowUtility.sDpi), GridUnitType.Pixel);
								StreamWindow.Instance.BrowserGrid.ColumnDefinitions[1].Width = new GridLength((double)(renderFrameSize.Width * 96 / StreamWindowUtility.sDpi), GridUnitType.Pixel);
								if (actualX == -1)
								{
									int num = ((int)StreamWindow.Instance.BrowserGrid.RenderSize.Width - actualWidth) / 2;
								}
								StreamWindow.Instance.ShowGrid();
								Logger.Info("OBS Handle: {0}", new object[]
								{
									StreamWindowUtility.mOBSHandle.ToString()
								});
								Logger.Info("mOBSRenderFrame {0} x {1}", new object[]
								{
									renderFrameSize.Width,
									requiredHeight
								});
								if (StreamWindowUtility.sOBSDevEnv)
								{
									InteropWindow.SetWindowLong(StreamWindowUtility.mOBSHandle, -16, InteropWindow.GetWindowLong(StreamWindowUtility.mOBSHandle, -16) | Convert.ToInt32(1073741824U));
								}
								else
								{
									InteropWindow.SetWindowLong(StreamWindowUtility.mOBSHandle, -16, Convert.ToInt32(1073741824U));
								}
								InteropWindow.SetParent(StreamWindowUtility.mOBSHandle, panelHandle);
								InteropWindow.SetWindowPos(StreamWindowUtility.mOBSHandle, (IntPtr)0, -1, -1, renderFrameSize.Width + 2, requiredHeight + 4, 80U);
								InteropWindow.ShowWindow(StreamWindowUtility.mOBSHandle, 5);
								StreamWindowUtility.sIsOBSReParented = true;
							}), new object[0]);
							return;
						}
						goto IL_C7;
					})
					{
						IsBackground = true
					}.Start();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("error while reparenting :" + ex.ToString());
			}
		}

		// Token: 0x06001538 RID: 5432 RVA: 0x00082DF8 File Offset: 0x00080FF8
		public static void CheckIfGMIsRunning()
		{
			Logger.Info("In check if gm is running");
			Thread thread = new Thread(delegate()
			{
				try
				{
					Logger.Info("GameManager not running...");
					StreamWindowUtility.CloseBTV();
				}
				catch (Exception ex)
				{
					Logger.Error("GameManager not running... Err : " + ex.ToString());
					StreamWindowUtility.CloseBTV();
				}
			});
			if (!StreamWindowUtility.isCheckThreadAlreadyRunning)
			{
				Logger.Info("starting gm check thread");
				StreamWindowUtility.isCheckThreadAlreadyRunning = true;
				thread.IsBackground = true;
				thread.Start();
			}
		}

		// Token: 0x06001539 RID: 5433 RVA: 0x0000EC82 File Offset: 0x0000CE82
		public static void GetCurrentAppInfo(out string type, out string name, out string data)
		{
			type = string.Empty;
			name = string.Empty;
			data = string.Empty;
		}

		// Token: 0x0600153A RID: 5434 RVA: 0x00082E58 File Offset: 0x00081058
		public static void CloseBTV()
		{
			try
			{
				Logger.Info("Exiting OBS and closing btv exe");
				if (StreamWindow.Instance != null)
				{
					StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
					{
						StreamWindow.Instance.Close();
					}), new object[0]);
				}
				else
				{
					ProcessUtils.KillProcessByName("HD-OBS");
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Failed to kill HD-OBS.exe...Err : " + ex.ToString());
			}
		}

		// Token: 0x0600153B RID: 5435 RVA: 0x00082EE4 File Offset: 0x000810E4
		public static bool IsGMFullScreen()
		{
			try
			{
				return true;
			}
			catch (Exception ex)
			{
				Logger.Info("Failed in getting GM window state... Err : " + ex.ToString());
			}
			return false;
		}

		// Token: 0x0600153C RID: 5436 RVA: 0x00004BF2 File Offset: 0x00002DF2
		public static void AddNewStreamViewKey(string label, string jsonString)
		{
		}

		// Token: 0x0600153D RID: 5437 RVA: 0x00004BF2 File Offset: 0x00002DF2
		public static void ReLaunchStreamWindow()
		{
		}

		// Token: 0x0600153E RID: 5438 RVA: 0x0000EC99 File Offset: 0x0000CE99
		internal static void ShowStreamWindow()
		{
			if (StreamWindow.Instance != null)
			{
				StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
				{
					if (StreamWindow.Instance.WindowState == WindowState.Minimized)
					{
						StreamWindow.Instance.WindowState = WindowState.Normal;
					}
					StreamWindow.Instance.Activate();
					StreamWindow.Instance.ShowInTaskbar = true;
					StreamWindow.Instance.Visibility = Visibility.Visible;
					StreamWindow.Instance.Topmost = true;
					StreamWindow.Instance.Topmost = false;
					StreamWindow.Instance.Focus();
				}), new object[0]);
			}
		}

		// Token: 0x0600153F RID: 5439 RVA: 0x00082F20 File Offset: 0x00081120
		internal static string GetStreamWindowUrl()
		{
			string text = StreamWindowUtility.sStreamWindowHtml;
			string text2 = "null";
			string text3 = "null";
			string text4 = "null";
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(RegistryManager.Instance.BTVKeyPath);
			text2 = (string)registryKey.GetValue("ShowLogo", text2);
			text3 = (string)registryKey.GetValue("NumRecVideos", text3);
			text4 = (string)registryKey.GetValue("GoLiveEnabled", text4);
			text = string.Format("{0}?logo={1}&videos={2}&streaming={3}", new object[]
			{
				text,
				text2,
				text3,
				text4
			});
			if (registryKey.GetValue("StreamWindowUrl", null) != null)
			{
				text = (string)registryKey.GetValue("StreamWindowUrl");
			}
			return text;
		}

		// Token: 0x06001540 RID: 5440 RVA: 0x0000ECD7 File Offset: 0x0000CED7
		public static string GetChannelName()
		{
			return RegistryManager.Instance.ChannelName;
		}

		// Token: 0x06001541 RID: 5441 RVA: 0x00082FD8 File Offset: 0x000811D8
		public static void SendStreamInfoToGM(string time, string followers, string likes, string watching, string chat)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			if (string.Compare(time, "0:0:0") > 0 && !StreamWindowUtility.isStartEventSent)
			{
				StreamWindowUtility.isStartEventSent = true;
				dictionary.Add("isstarted", "True");
			}
			else
			{
				dictionary.Add("isstarted", "False");
			}
			dictionary.Add("network", StreamWindowUtility.sNetwork);
			int num;
			int num2;
			if (int.TryParse(followers, out num))
			{
				dictionary.Add("likes", followers);
			}
			else if (int.TryParse(likes, out num2))
			{
				dictionary.Add("likes", likes);
			}
			else
			{
				dictionary.Add("likes", "0");
			}
			dictionary.Add("views", watching);
			dictionary.Add("comments", chat);
		}

		// Token: 0x04000EBE RID: 3774
		public const int STREAM_WINDOW_WIDTH = 320;

		// Token: 0x04000EBF RID: 3775
		public static int sDpi = SystemUtils.GetDPI();

		// Token: 0x04000EC0 RID: 3776
		private const int mGrip = 5;

		// Token: 0x04000EC1 RID: 3777
		public static Panel mOBSRenderFrame;

		// Token: 0x04000EC2 RID: 3778
		public static IntPtr mOBSHandle = IntPtr.Zero;

		// Token: 0x04000EC3 RID: 3779
		public static bool sOBSDevEnv = false;

		// Token: 0x04000EC4 RID: 3780
		public static bool isCheckThreadAlreadyRunning = false;

		// Token: 0x04000EC5 RID: 3781
		public static bool sIsOBSReParented = false;

		// Token: 0x04000EC6 RID: 3782
		public static bool isStartEventSent = false;

		// Token: 0x04000EC7 RID: 3783
		public static string sStreamWindowHtml = "http://bluestacks-tv2-prod.appspot.com/home";

		// Token: 0x04000EC8 RID: 3784
		public static OBSRenderFrameSpecs sOBSRenderFrameSpecs;

		// Token: 0x04000EC9 RID: 3785
		public static string sNetwork = null;

		// Token: 0x04000ECA RID: 3786
		private const int SM_CXSCREEN = 0;

		// Token: 0x04000ECB RID: 3787
		private const int SM_CYSCREEN = 1;

		// Token: 0x04000ECC RID: 3788
		private static System.Drawing.Size? sSize = null;

		// Token: 0x04000ECD RID: 3789
		private static string sProgramData = string.Empty;

		// Token: 0x04000ECE RID: 3790
		private static string sSetupDir = string.Empty;

		// Token: 0x04000ECF RID: 3791
		private static string sInstallDir = string.Empty;

		// Token: 0x04000ED0 RID: 3792
		public static bool isAddStreamindow = false;
	}
}
