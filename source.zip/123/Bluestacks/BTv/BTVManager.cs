﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Threading;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000243 RID: 579
	internal sealed class BTVManager
	{
		// Token: 0x060013F3 RID: 5107 RVA: 0x0000E196 File Offset: 0x0000C396
		private BTVManager()
		{
		}

		// Token: 0x17000229 RID: 553
		// (get) Token: 0x060013F4 RID: 5108 RVA: 0x0007B280 File Offset: 0x00079480
		public static BTVManager Instance
		{
			get
			{
				if (BTVManager.instance == null)
				{
					object obj = BTVManager.syncRoot;
					lock (obj)
					{
						if (BTVManager.instance == null)
						{
							BTVManager.instance = new BTVManager();
						}
					}
				}
				return BTVManager.instance;
			}
		}

		// Token: 0x1700022A RID: 554
		// (set) Token: 0x060013F5 RID: 5109 RVA: 0x0000E1A9 File Offset: 0x0000C3A9
		public bool sWritingToFile
		{
			set
			{
				HTTPServer.sFileWriteComplete = !value;
			}
		}

		// Token: 0x060013F6 RID: 5110 RVA: 0x0007B2D8 File Offset: 0x000794D8
		public void StartBlueStacksTV()
		{
			if (!this.IsBtvLaunched || this.streamWindow == null)
			{
				this.streamWindow = new StreamWindow();
				this.streamWindow.mWindowEvent += BtvEventHandler.WindowEvent;
				this.streamWindow.Closing += this.BtvWindow_Closing;
				this.IsBtvLaunched = true;
				this.streamWindow.Show();
				return;
			}
			if (this.streamWindow != null)
			{
				BTVManager.BringToFront(this.streamWindow);
			}
		}

		// Token: 0x060013F7 RID: 5111 RVA: 0x0000E1B4 File Offset: 0x0000C3B4
		private void BtvWindow_Closing(object sender, CancelEventArgs e)
		{
			this.IsBtvLaunched = false;
		}

		// Token: 0x060013F8 RID: 5112 RVA: 0x0007B354 File Offset: 0x00079554
		internal static void BringToFront(CustomWindow win)
		{
			try
			{
				win.Dispatcher.Invoke(new Action(delegate()
				{
					if (win.WindowState == WindowState.Minimized)
					{
						win.WindowState = WindowState.Normal;
					}
					win.Visibility = Visibility.Visible;
					win.Show();
					win.BringIntoView();
					if (!win.Topmost)
					{
						win.Topmost = true;
						win.Topmost = false;
					}
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Error("An error was triggered in bringing BTv downloader to front", new object[]
				{
					ex.Message
				});
			}
		}

		// Token: 0x060013F9 RID: 5113 RVA: 0x0007B3C0 File Offset: 0x000795C0
		public static void ReportObsErrorHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			Logger.Info("Got ReportObsErrorHandler");
			HTTPUtils.ParseRequest(req);
			try
			{
				StreamManager.Instance.ReportObsError("obs_error");
				StreamManager.Instance = null;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ReportObsHandler");
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x060013FA RID: 5114 RVA: 0x0000E1BD File Offset: 0x0000C3BD
		private void CancelBTvDownload(object sender, EventArgs e)
		{
			Logger.Info("User cancelled BTV download");
			this.sDownloading = false;
			if (this.sDownloader != null)
			{
				this.sDownloader.AbortDownload();
				if (BTVManager.IsBTVInstalled())
				{
					Directory.Delete(RegistryStrings.ObsDir, true);
				}
			}
		}

		// Token: 0x060013FB RID: 5115 RVA: 0x0007B41C File Offset: 0x0007961C
		private void CancelDownloadConfirmation(object sender, EventArgs e)
		{
			MainWindow owner = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				owner = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.AddButton(ButtonColors.Red, "STRING_YES", new EventHandler(this.CancelBTvDownload), null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_NO", null, null, false, null);
			BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_BTV_DOWNLOAD_CANCEL", "");
			customMessageWindow.Owner = owner;
			customMessageWindow.ShowDialog();
		}

		// Token: 0x060013FC RID: 5116 RVA: 0x0000E1F5 File Offset: 0x0000C3F5
		internal static bool IsBTVInstalled()
		{
			return Directory.Exists(RegistryStrings.BtvDir) && Directory.Exists(RegistryStrings.ObsDir);
		}

		// Token: 0x060013FD RID: 5117 RVA: 0x0007B49C File Offset: 0x0007969C
		internal static bool IsDirectXComponentsInstalled()
		{
			string systemDirectory = Environment.SystemDirectory;
			foreach (string path in new string[]
			{
				"D3DX10_43.DLL",
				"D3D10_1.DLL",
				"DXGI.DLL",
				"D3DCompiler_43.dll"
			})
			{
				if (!File.Exists(Path.Combine(systemDirectory, path)))
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x060013FE RID: 5118 RVA: 0x0007B4FC File Offset: 0x000796FC
		public void MaybeDownloadAndLaunchBTv(MainWindow parentWindow)
		{
			BTVManager.<>c__DisplayClass28_0 CS$<>8__locals1 = new BTVManager.<>c__DisplayClass28_0();
			CS$<>8__locals1.<>4__this = this;
			CS$<>8__locals1.parentWindow = parentWindow;
			if (BTVManager.IsBTVInstalled())
			{
				this.StartBlueStacksTV();
				return;
			}
			if (this.sDownloading && this.sWindow != null)
			{
				BTVManager.BringToFront(this.sWindow);
				return;
			}
			ExtensionPopupControl btvExtPopup = new ExtensionPopupControl();
			btvExtPopup.LoadExtensionPopupFromFolder("BTVExtensionPopup");
			btvExtPopup.DownloadClicked += delegate(object o, EventArgs e)
			{
				BlueStacksUIUtils.CloseContainerWindow(btvExtPopup);
				CS$<>8__locals1.<>4__this.sDownloading = true;
				CS$<>8__locals1.<>4__this.sWindow = new CustomMessageWindow();
				CS$<>8__locals1.<>4__this.sWindow.AddButton(ButtonColors.Blue, "STRING_CANCEL", new EventHandler(CS$<>8__locals1.<>4__this.CancelDownloadConfirmation), null, false, null);
				BlueStacksUIBinding.Bind(CS$<>8__locals1.<>4__this.sWindow.TitleTextBlock, "STRING_BTV_DOWNLOAD", "");
				BlueStacksUIBinding.Bind(CS$<>8__locals1.<>4__this.sWindow.BodyTextBlock, "STRING_BTV_INSTALL_WAIT", "");
				BlueStacksUIBinding.Bind(CS$<>8__locals1.<>4__this.sWindow.BodyWarningTextBlock, "STRING_BTV_WARNING", "");
				CS$<>8__locals1.<>4__this.sWindow.BodyWarningTextBlock.Visibility = Visibility.Visible;
				CS$<>8__locals1.<>4__this.sWindow.ProgressBarEnabled = true;
				CS$<>8__locals1.<>4__this.sWindow.IsWindowMinizable = true;
				CS$<>8__locals1.<>4__this.sWindow.IsWindowClosable = false;
				CS$<>8__locals1.<>4__this.sWindow.ImageName = "BTVTopBar";
				CS$<>8__locals1.<>4__this.sWindow.ShowInTaskbar = true;
				CS$<>8__locals1.<>4__this.sWindow.Owner = CS$<>8__locals1.parentWindow;
				CS$<>8__locals1.<>4__this.sWindow.Show();
				ThreadStart start;
				if ((start = CS$<>8__locals1.<>9__1) == null)
				{
					start = (CS$<>8__locals1.<>9__1 = delegate()
					{
						if (!RegistryManager.Instance.BtvDevServer.Equals(""))
						{
							BTVManager.sBTvUrl = RegistryManager.Instance.BtvDevServer;
						}
						string redirectedUrl = BTVManager.GetRedirectedUrl(BTVManager.sBTvUrl);
						if (redirectedUrl == null)
						{
							Logger.Error("The download url was null");
							return;
						}
						string fileName = Path.GetFileName(new Uri(redirectedUrl).LocalPath);
						string downloadPath = Path.Combine(Path.GetTempPath(), fileName);
						CS$<>8__locals1.<>4__this.sDownloader = new LegacyDownloader(3, redirectedUrl, downloadPath);
						LegacyDownloader legacyDownloader = CS$<>8__locals1.<>4__this.sDownloader;
						LegacyDownloader.UpdateProgressCallback updateProgressCb;
						if ((updateProgressCb = CS$<>8__locals1.<>9__2) == null)
						{
							updateProgressCb = (CS$<>8__locals1.<>9__2 = delegate(int percent)
							{
								CS$<>8__locals1.<>4__this.sWindow.Dispatcher.Invoke(new Action(delegate()
								{
									CS$<>8__locals1.<>4__this.sWindow.CustomProgressBar.Value = (double)percent;
								}), new object[0]);
							});
						}
						legacyDownloader.Download(updateProgressCb, delegate(string filePath)
						{
							Dispatcher dispatcher = CS$<>8__locals1.<>4__this.sWindow.Dispatcher;
							Action method;
							if ((method = CS$<>8__locals1.<>9__6) == null)
							{
								method = (CS$<>8__locals1.<>9__6 = delegate()
								{
									CS$<>8__locals1.<>4__this.sWindow.CustomProgressBar.Value = 100.0;
									CS$<>8__locals1.<>4__this.sWindow.Close();
								});
							}
							dispatcher.Invoke(method, new object[0]);
							Logger.Info("Successfully downloaded BlueStacks TV");
							CS$<>8__locals1.<>4__this.sDownloading = false;
							BTVManager.ExtractBTv(downloadPath);
							Dispatcher dispatcher2 = CS$<>8__locals1.parentWindow.Dispatcher;
							Action method2;
							if ((method2 = CS$<>8__locals1.<>9__7) == null)
							{
								method2 = (CS$<>8__locals1.<>9__7 = delegate()
								{
									CS$<>8__locals1.parentWindow.mTopBar.mBtvButton.ImageName = "btv";
								});
							}
							dispatcher2.Invoke(method2, new object[0]);
						}, delegate(Exception ex)
						{
							Logger.Error("Failed to download file: {0}. err: {1}", new object[]
							{
								downloadPath,
								ex.Message
							});
						}, null, null, null);
					});
				}
				new Thread(start)
				{
					IsBackground = true
				}.Start();
			};
			btvExtPopup.Height = CS$<>8__locals1.parentWindow.ActualHeight * 0.8;
			btvExtPopup.Width = btvExtPopup.Height * 16.0 / 9.0;
			new ContainerWindow(CS$<>8__locals1.parentWindow, btvExtPopup, (double)((int)btvExtPopup.Width), (double)((int)btvExtPopup.Height), false, true);
		}

		// Token: 0x060013FF RID: 5119 RVA: 0x0007B60C File Offset: 0x0007980C
		internal static void ReportOpenGLCaptureError(HttpListenerRequest req, HttpListenerResponse res)
		{
			Logger.Info("Got open gl CaptureError");
			try
			{
				StreamManager.Instance.ReportObsError("opengl_capture_error");
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ReportObsHandler");
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x06001400 RID: 5120 RVA: 0x0000E212 File Offset: 0x0000C412
		private static void ShowOpenGLWindowError()
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				BstHttpClient.Post("https://cloud.bluestacks.com/stats/btvfunnelstats", new Dictionary<string, string>
				{
					{
						"event_type",
						"opengl_capture_error"
					},
					{
						"error_code",
						"opengl_capture_error"
					},
					{
						"guid",
						RegistryManager.Instance.UserGuid
					},
					{
						"streaming_platform",
						"facebook"
					},
					{
						"session_id",
						Stats.GetSessionId()
					},
					{
						"prod_ver",
						"4.140.12.1002"
					},
					{
						"created_at",
						DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss")
					}
				}, null, false, BtvApp.sVmName, 0, 1, 0, false);
				MainWindow mainWindow = null;
				if (BlueStacksUIUtils.DictWindows.Count > 0)
				{
					mainWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
				}
				BTVManager.Instance.CloseBTV();
				string btvCaptureIssueURL = WebHelper.GetUrlWithParams(string.Format("{0}/{1}", WebHelper.GetServerHost(), "help_articles")) + "&article=change_graphics_mode";
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_SHOW_GUIDE", delegate(object sender1, EventArgs e1)
				{
					BlueStacksUIUtils.OpenUrl(btvCaptureIssueURL);
				}, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, "STRING_NO", delegate(object sender1, EventArgs e1)
				{
					StreamManager.sStopInitOBSQueue = false;
				}, null, false, null);
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_CAPTURE_ERROR", "");
				customMessageWindow.Owner = mainWindow;
				customMessageWindow.ShowDialog();
				mainWindow.BringIntoView();
			}), new object[0]);
		}

		// Token: 0x06001401 RID: 5121 RVA: 0x0007B65C File Offset: 0x0007985C
		internal static void ReportCaptureError(HttpListenerRequest req, HttpListenerResponse res)
		{
			Logger.Info("Got ReportCaptureError");
			HTTPUtils.ParseRequest(req);
			try
			{
				StreamManager.Instance.ReportObsError("capture_error");
				StreamManager.Instance = null;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ReportObsHandler");
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x06001402 RID: 5122 RVA: 0x0007B6B8 File Offset: 0x000798B8
		internal static void ObsStatusHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			Logger.Info("Got ObsStatus {0} request from {1}", new object[]
			{
				req.HttpMethod,
				req.RemoteEndPoint.ToString()
			});
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (requestData.data.Count > 0 && requestData.data.AllKeys[0] == "Error")
				{
					if (!StreamManager.sStopInitOBSQueue)
					{
						if (requestData.data[0].Equals("OBSAlreadyRunning"))
						{
							StreamManager.sStopInitOBSQueue = true;
						}
						if (StreamManager.Instance != null)
						{
							new Thread(delegate()
							{
								StreamManager.Instance.ReportObsError(requestData.data[0]);
							})
							{
								IsBackground = true
							}.Start();
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ObsStatus");
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x06001403 RID: 5123 RVA: 0x0007B7A8 File Offset: 0x000799A8
		internal static string GetRedirectedUrl(string url)
		{
			HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
			httpWebRequest.Method = "GET";
			httpWebRequest.AllowAutoRedirect = true;
			string str = "Bluestacks/" + RegistryManager.Instance.ClientVersion;
			httpWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36 " + str;
			httpWebRequest.Headers.Add("x_oem", RegistryManager.Instance.Oem);
			httpWebRequest.Headers.Set("x_email", RegistryManager.Instance.RegisteredEmail);
			httpWebRequest.Headers.Add("x_guid", RegistryManager.Instance.UserGuid);
			httpWebRequest.Headers.Add("x_prod_ver", RegistryManager.Instance.Version);
			httpWebRequest.Headers.Add("x_home_app_ver", RegistryManager.Instance.ClientVersion);
			string result;
			try
			{
				using (HttpWebResponse httpWebResponse = httpWebRequest.GetResponse() as HttpWebResponse)
				{
					using (Stream responseStream = httpWebResponse.GetResponseStream())
					{
						using (StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8))
						{
							JObject jobject = JObject.Parse(streamReader.ReadToEnd());
							if (jobject["success"].ToObject<bool>())
							{
								result = jobject["file_url"].ToString();
							}
							else
							{
								result = null;
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in getting redirected url for BTV " + ex.ToString());
				result = null;
			}
			return result;
		}

		// Token: 0x06001404 RID: 5124 RVA: 0x0007B94C File Offset: 0x00079B4C
		internal static bool ExtractBTv(string downloadPath)
		{
			try
			{
				if (File.Exists(downloadPath))
				{
					if (MiscUtils.Extract7Zip(downloadPath, RegistryManager.Instance.UserDefinedDir) == 0)
					{
						return true;
					}
					Logger.Error("Could not extract BTv zip file.");
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Could not extract BTv zip file. Error: " + ex.ToString());
			}
			return false;
		}

		// Token: 0x06001405 RID: 5125 RVA: 0x0007B9B0 File Offset: 0x00079BB0
		public void StartPingBTVThread()
		{
			object obj = this.sPingBTVLock;
			lock (obj)
			{
				Logger.Info("Starting btv ping thread");
				for (;;)
				{
					this.PingBTV();
					if (this.sStopPingBTVThread)
					{
						break;
					}
					Thread.Sleep(5000);
				}
			}
		}

		// Token: 0x06001406 RID: 5126 RVA: 0x0000E249 File Offset: 0x0000C449
		public void ShowStreamWindow()
		{
			if (!ProcessUtils.FindProcessByName("BlueStacksTV"))
			{
				this.StartBlueStacksTV();
				return;
			}
			this.SendBTVAsyncRequest("showstreamwindow", null);
		}

		// Token: 0x06001407 RID: 5127 RVA: 0x0000E26A File Offset: 0x0000C46A
		public void HideStreamWindow()
		{
			if (ProcessUtils.FindProcessByName("BlueStacksTV"))
			{
				this.SendBTVAsyncRequest("hidestreamwindow", null);
			}
		}

		// Token: 0x06001408 RID: 5128 RVA: 0x0000E284 File Offset: 0x0000C484
		public void HideStreamWindowFromTaskbar()
		{
			this.SendBTVAsyncRequest("hidestreamwindowfromtaskbar", null);
		}

		// Token: 0x06001409 RID: 5129 RVA: 0x0007BA08 File Offset: 0x00079C08
		public void GetStreamDimensionInfo(out int startX, out int startY, out int width, out int height)
		{
			Point p = default(Point);
			MainWindow activatedWindow = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				activatedWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			activatedWindow.Dispatcher.Invoke(new Action(delegate()
			{
				p = activatedWindow.mFrontendGrid.TranslatePoint(new Point(0.0, 0.0), activatedWindow.mFrontendGrid);
			}), new object[0]);
			startX = Convert.ToInt32(p.X) * SystemUtils.GetDPI() / 96;
			startY = Convert.ToInt32(p.Y) * SystemUtils.GetDPI() / 96;
			width = (int)activatedWindow.mFrontendGrid.ActualWidth * SystemUtils.GetDPI() / 96;
			height = (int)activatedWindow.mFrontendGrid.ActualHeight * SystemUtils.GetDPI() / 96;
		}

		// Token: 0x0600140A RID: 5130 RVA: 0x0007BAE4 File Offset: 0x00079CE4
		public void PingBTV()
		{
			bool flag = false;
			bool flag2 = false;
			try
			{
				string text = this.SendBTVRequest("ping", null);
				JArray.Parse(text);
				JObject jobject = JObject.Parse(text[0].ToString());
				if (jobject["success"].ToObject<bool>())
				{
					flag = jobject["recording"].ToObject<bool>();
					flag2 = jobject["streaming"].ToObject<bool>();
				}
				Logger.Info("Ping BTV response recording: {0}, streaming: {1}", new object[]
				{
					flag,
					flag2
				});
				this.sStopPingBTVThread = false;
			}
			catch (Exception ex)
			{
				this.sStopPingBTVThread = true;
				Logger.Error("PingBTV : {0}", new object[]
				{
					ex.Message
				});
			}
			this.sRecording = flag;
			this.sStreaming = flag2;
		}

		// Token: 0x0600140B RID: 5131 RVA: 0x0007BBC0 File Offset: 0x00079DC0
		public void SetFrontendPosition(int width, int height, bool isPortrait)
		{
			if (ProcessUtils.FindProcessByName("BlueStacksTV"))
			{
				this.SendBTVRequest("setfrontendposition", new Dictionary<string, string>
				{
					{
						"width",
						width.ToString()
					},
					{
						"height",
						height.ToString()
					},
					{
						"isPortrait",
						isPortrait.ToString()
					}
				});
			}
		}

		// Token: 0x0600140C RID: 5132 RVA: 0x0007BC24 File Offset: 0x00079E24
		public void WindowResized()
		{
			if (ProcessUtils.FindProcessByName("BlueStacksTV"))
			{
				try
				{
					this.SendBTVRequest("windowresized", null);
				}
				catch (Exception ex)
				{
					Logger.Error("{0}", new object[]
					{
						ex
					});
				}
			}
		}

		// Token: 0x0600140D RID: 5133 RVA: 0x0000E292 File Offset: 0x0000C492
		public void StreamStarted()
		{
			this.sWritingToFile = true;
			this.sRecording = true;
			this.sStreaming = true;
		}

		// Token: 0x0600140E RID: 5134 RVA: 0x0000E2A9 File Offset: 0x0000C4A9
		public void StreamStopped()
		{
			this.sWritingToFile = false;
			this.sStreaming = false;
			this.sRecording = false;
			this.RestrictWindowResize(false);
		}

		// Token: 0x0600140F RID: 5135 RVA: 0x0000E2C7 File Offset: 0x0000C4C7
		public void RecordStarted()
		{
			this.sWritingToFile = true;
			this.sRecording = true;
			this.sWasRecording = true;
		}

		// Token: 0x06001410 RID: 5136 RVA: 0x0007BC74 File Offset: 0x00079E74
		public void SetConfig()
		{
			int num;
			int num2;
			int num3;
			int num4;
			this.GetStreamDimensionInfo(out num, out num2, out num3, out num4);
			this.SendBTVRequest("setconfig", new Dictionary<string, string>
			{
				{
					"startX",
					num.ToString()
				},
				{
					"startY",
					num2.ToString()
				},
				{
					"width",
					num3.ToString()
				},
				{
					"height",
					num4.ToString()
				}
			});
		}

		// Token: 0x06001411 RID: 5137 RVA: 0x0000E2DE File Offset: 0x0000C4DE
		public void RecordStopped()
		{
			this.sWritingToFile = false;
			this.sRecording = false;
			this.RestrictWindowResize(false);
		}

		// Token: 0x06001412 RID: 5138 RVA: 0x0000E2F5 File Offset: 0x0000C4F5
		public void SendTabChangeData(string[] tabChangedData)
		{
			new Thread(delegate()
			{
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary.Add("type", tabChangedData[0]);
				dictionary.Add("name", tabChangedData[1]);
				dictionary.Add("data", tabChangedData[2]);
				this.SendBTVRequest("tabchangeddata", dictionary);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06001413 RID: 5139 RVA: 0x0007BCF0 File Offset: 0x00079EF0
		public void ReplayBufferSaved()
		{
			MainWindow mainWindow = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				mainWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			mainWindow.Dispatcher.Invoke(new Action(delegate()
			{
				SaveFileDialog saveFileDialog = new SaveFileDialog();
				saveFileDialog.Filter = "Flash Video (*.flv)|*.flv";
				saveFileDialog.FilterIndex = 1;
				saveFileDialog.RestoreDirectory = true;
				saveFileDialog.FileName = "Replay";
				if (saveFileDialog.ShowDialog() == DialogResult.OK)
				{
					string fileName = saveFileDialog.FileName;
					string path = "replay.flv";
					File.Copy(Path.Combine(RegistryManager.Instance.ClientInstallDir, path), fileName);
				}
			}), new object[0]);
		}

		// Token: 0x06001414 RID: 5140 RVA: 0x0000E326 File Offset: 0x0000C526
		public void Stop()
		{
			if (this.sStreaming || this.sRecording)
			{
				this.SendBTVRequest("sessionswitch", null);
				this.sWasRecording = false;
			}
		}

		// Token: 0x06001415 RID: 5141 RVA: 0x0000E34C File Offset: 0x0000C54C
		public void CloseBTV()
		{
			if (StreamWindow.Instance != null)
			{
				StreamWindow.Instance.Close();
			}
			else
			{
				StreamWindowUtility.CloseBTV();
			}
			this.sWasRecording = false;
		}

		// Token: 0x06001416 RID: 5142 RVA: 0x0000E36D File Offset: 0x0000C56D
		public void CheckNewFiltersAvailable()
		{
			this.SendBTVRequest("checknewfilters", null);
		}

		// Token: 0x06001417 RID: 5143 RVA: 0x0000E37C File Offset: 0x0000C57C
		public void SendBTVAsyncRequest(string request, Dictionary<string, string> data)
		{
			new Thread(delegate()
			{
				Logger.Info("Sending btv async request");
				this.SendBTVRequest(request, data);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06001418 RID: 5144 RVA: 0x0000E3B4 File Offset: 0x0000C5B4
		public string SendBTVRequest(string request, Dictionary<string, string> data)
		{
			return "";
		}

		// Token: 0x06001419 RID: 5145 RVA: 0x0007BD50 File Offset: 0x00079F50
		public void RestrictWindowResize(bool enable)
		{
			MainWindow activatedWindow = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				activatedWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			activatedWindow.Dispatcher.Invoke(new Action(delegate()
			{
				activatedWindow.RestrictWindowResize(enable);
			}), new object[0]);
		}

		// Token: 0x0600141A RID: 5146 RVA: 0x0007BDB8 File Offset: 0x00079FB8
		public void RecordVideoOfApp()
		{
			if (StreamManager.Instance == null)
			{
				StreamManager.Instance = new StreamManager(BlueStacksUIUtils.DictWindows.Values.First<MainWindow>());
			}
			string text;
			string pid;
			StreamManager.Instance.GetStreamConfig(out text, out pid);
			StreamManager.Instance.Init(text, pid);
			StreamManager.Instance.SetHwnd(text);
			StreamManager.Instance.EnableVideoRecording(true);
			StreamManager.Instance.StartObs();
			StreamManager.Instance.StartRecordForVideo();
			this.mIsRecordingVideo = true;
		}

		// Token: 0x0600141B RID: 5147 RVA: 0x0000E3BB File Offset: 0x0000C5BB
		private void StopRecordVideo()
		{
			this.mIsRecordingVideo = false;
			StreamManager.Instance.StopRecord();
		}

		// Token: 0x0600141C RID: 5148 RVA: 0x00004BF2 File Offset: 0x00002DF2
		internal void RecordStartedVideo()
		{
		}

		// Token: 0x04000DEC RID: 3564
		private static volatile BTVManager instance;

		// Token: 0x04000DED RID: 3565
		private static object syncRoot = new object();

		// Token: 0x04000DEE RID: 3566
		public bool sStreaming;

		// Token: 0x04000DEF RID: 3567
		public static string sNetwork = "twitch";

		// Token: 0x04000DF0 RID: 3568
		public bool sRecording;

		// Token: 0x04000DF1 RID: 3569
		public bool sWasRecording;

		// Token: 0x04000DF2 RID: 3570
		public bool sStopPingBTVThread;

		// Token: 0x04000DF3 RID: 3571
		public object sPingBTVLock = new object();

		// Token: 0x04000DF4 RID: 3572
		private CustomMessageWindow sWindow;

		// Token: 0x04000DF5 RID: 3573
		private bool sDownloading;

		// Token: 0x04000DF6 RID: 3574
		private LegacyDownloader sDownloader;

		// Token: 0x04000DF7 RID: 3575
		private bool IsBtvLaunched;

		// Token: 0x04000DF8 RID: 3576
		private StreamWindow streamWindow;

		// Token: 0x04000DF9 RID: 3577
		private bool mIsRecordingVideo;

		// Token: 0x04000DFA RID: 3578
		private static string sBTvUrl = "https://cloud.bluestacks.com/bs4/btv/GetBTVFile";
	}
}
