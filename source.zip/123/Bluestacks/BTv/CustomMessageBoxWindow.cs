﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000270 RID: 624
	public class CustomMessageBoxWindow : Window, IComponentConnector
	{
		// Token: 0x06001564 RID: 5476 RVA: 0x0000EDF6 File Offset: 0x0000CFF6
		public CustomMessageBoxWindow()
		{
			this.InitializeComponent();
			base.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		}

		// Token: 0x17000231 RID: 561
		// (get) Token: 0x06001565 RID: 5477 RVA: 0x0000EE0B File Offset: 0x0000D00B
		// (set) Token: 0x06001566 RID: 5478 RVA: 0x0000EE13 File Offset: 0x0000D013
		public MessageBoxResult messageBoxResult { get; set; }

		// Token: 0x06001567 RID: 5479 RVA: 0x0000EE1C File Offset: 0x0000D01C
		private void Image_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.messageBoxResult = MessageBoxResult.Yes;
			base.Close();
		}

		// Token: 0x06001568 RID: 5480 RVA: 0x0000EE2B File Offset: 0x0000D02B
		public void CustomMessage(string contentBox, string leftBtnLabel, string rightBtnLabel)
		{
			this.ContentBox.Text = contentBox;
			this.LeftBtnLabel.Text = leftBtnLabel;
			this.RightBtnLabel.Text = rightBtnLabel;
		}

		// Token: 0x06001569 RID: 5481 RVA: 0x0000553B File Offset: 0x0000373B
		private void Image_MouseDown(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x0600156A RID: 5482 RVA: 0x0000EE51 File Offset: 0x0000D051
		private void Image_MouseLeftButtonUpKeepData(object sender, MouseButtonEventArgs e)
		{
			this.messageBoxResult = MessageBoxResult.Cancel;
			base.Close();
		}

		// Token: 0x0600156B RID: 5483 RVA: 0x0000EE60 File Offset: 0x0000D060
		private void Window_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!this.mHoverImage.IsMouseOver && !this.mImageleftBtn.IsMouseOver && !this.mImageRightBtn.IsMouseOver)
			{
				base.DragMove();
			}
		}

		// Token: 0x0600156C RID: 5484 RVA: 0x0000EE8F File Offset: 0x0000D08F
		public static MessageBoxResult Show(string contentBox, string leftBtnLabel, string rightBtnLabel)
		{
			CustomMessageBoxWindow customMessageBoxWindow = new CustomMessageBoxWindow();
			customMessageBoxWindow.CustomMessage(contentBox, leftBtnLabel, rightBtnLabel);
			customMessageBoxWindow.ShowDialog();
			return customMessageBoxWindow.messageBoxResult;
		}

		// Token: 0x0600156D RID: 5485 RVA: 0x00083814 File Offset: 0x00081A14
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/btv/wpffiles/custommessageboxwindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600156E RID: 5486 RVA: 0x00083844 File Offset: 0x00081A44
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((CustomMessageBoxWindow)target).MouseDown += this.Window_MouseDown;
				return;
			case 2:
				this.mHoverImage = (CustomPictureBox)target;
				this.mHoverImage.MouseLeftButtonUp += this.Image_MouseLeftButtonUpKeepData;
				return;
			case 3:
				this.ContentBox = (TextBlock)target;
				return;
			case 4:
				((Image)target).MouseLeftButtonUp += this.Image_MouseLeftButtonUp;
				return;
			case 5:
				this.LeftBtnLabel = (TextBlock)target;
				this.LeftBtnLabel.MouseLeftButtonUp += this.Image_MouseLeftButtonUp;
				return;
			case 6:
				this.mImageleftBtn = (CustomPictureBox)target;
				this.mImageleftBtn.MouseLeftButtonUp += this.Image_MouseLeftButtonUp;
				return;
			case 7:
				((Image)target).MouseLeftButtonUp += this.Image_MouseLeftButtonUpKeepData;
				return;
			case 8:
				this.RightBtnLabel = (TextBlock)target;
				this.RightBtnLabel.MouseLeftButtonUp += this.Image_MouseLeftButtonUpKeepData;
				return;
			case 9:
				this.mImageRightBtn = (CustomPictureBox)target;
				this.mImageRightBtn.MouseLeftButtonUp += this.Image_MouseLeftButtonUpKeepData;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000EEF RID: 3823
		internal CustomPictureBox mHoverImage;

		// Token: 0x04000EF0 RID: 3824
		internal TextBlock ContentBox;

		// Token: 0x04000EF1 RID: 3825
		internal TextBlock LeftBtnLabel;

		// Token: 0x04000EF2 RID: 3826
		internal CustomPictureBox mImageleftBtn;

		// Token: 0x04000EF3 RID: 3827
		internal TextBlock RightBtnLabel;

		// Token: 0x04000EF4 RID: 3828
		internal CustomPictureBox mImageRightBtn;

		// Token: 0x04000EF5 RID: 3829
		private bool _contentLoaded;
	}
}
