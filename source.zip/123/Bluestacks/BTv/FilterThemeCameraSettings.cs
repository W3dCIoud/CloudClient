﻿using System;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x0200025C RID: 604
	public class FilterThemeCameraSettings
	{
		// Token: 0x06001496 RID: 5270 RVA: 0x0007E890 File Offset: 0x0007CA90
		public FilterThemeCameraSettings(string cameraSettings)
		{
			Logger.Info("In FilterThemeCameraSettings Constructor");
			JObject jobject = JObject.Parse(cameraSettings);
			if (jobject.Property("width") != null)
			{
				Logger.Info("Camera width is {0}", new object[]
				{
					jobject["width"].ToObject<int>()
				});
				this.width = jobject["width"].ToObject<int>();
			}
			if (jobject.Property("height") != null)
			{
				Logger.Info("Camera height is {0}", new object[]
				{
					jobject["height"].ToObject<int>()
				});
				this.height = jobject["height"].ToObject<int>();
			}
			if (jobject.Property("x") != null)
			{
				Logger.Info("Camera x is {0}", new object[]
				{
					jobject["x"].ToObject<int>()
				});
				this.x = jobject["x"].ToObject<int>();
			}
			if (jobject.Property("y") != null)
			{
				Logger.Info("Camera y is {0}", new object[]
				{
					jobject["y"].ToObject<int>()
				});
				this.y = jobject["y"].ToObject<int>();
			}
		}

		// Token: 0x06001497 RID: 5271 RVA: 0x0007E9E0 File Offset: 0x0007CBE0
		public string ToJsonString()
		{
			return new JObject
			{
				{
					"width",
					this.width
				},
				{
					"height",
					this.height
				},
				{
					"x",
					this.x
				},
				{
					"y",
					this.y
				}
			}.ToString(Formatting.None, new JsonConverter[0]);
		}

		// Token: 0x04000E52 RID: 3666
		public int width;

		// Token: 0x04000E53 RID: 3667
		public int height;

		// Token: 0x04000E54 RID: 3668
		public int x;

		// Token: 0x04000E55 RID: 3669
		public int y;
	}
}
