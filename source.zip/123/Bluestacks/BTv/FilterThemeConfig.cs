﻿using System;
using System.IO;
using System.Text;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x0200025B RID: 603
	public class FilterThemeConfig
	{
		// Token: 0x06001494 RID: 5268 RVA: 0x0007E784 File Offset: 0x0007C984
		public FilterThemeConfig(string themeConfig)
		{
			Logger.Info("In FilterThemeConfig Constructor");
			JObject jobject = JObject.Parse(themeConfig);
			string settings = "{}";
			if (jobject.Property("settings") != null)
			{
				settings = jobject["settings"].ToString();
			}
			this.mFilterThemeSettings = new FilterThemeSettings(settings);
			string cameraSettings = "{}";
			if (jobject.Property("camera") != null)
			{
				cameraSettings = jobject["camera"].ToString();
			}
			this.mFilterThemeCameraSettings = new FilterThemeCameraSettings(cameraSettings);
		}

		// Token: 0x06001495 RID: 5269 RVA: 0x0007E808 File Offset: 0x0007CA08
		public string ToJsonString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			using (JsonWriter jsonWriter = new JsonTextWriter(new StringWriter(stringBuilder)))
			{
				jsonWriter.WriteStartObject();
				jsonWriter.WritePropertyName("settings");
				jsonWriter.WriteValue(this.mFilterThemeSettings.ToJsonString());
				jsonWriter.WritePropertyName("camera");
				jsonWriter.WriteValue(this.mFilterThemeCameraSettings.ToJsonString());
				jsonWriter.WriteEndObject();
			}
			return stringBuilder.ToString();
		}

		// Token: 0x04000E50 RID: 3664
		public FilterThemeSettings mFilterThemeSettings;

		// Token: 0x04000E51 RID: 3665
		public FilterThemeCameraSettings mFilterThemeCameraSettings;
	}
}
