﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000285 RID: 645
	public class OtherControl : UserControl, IComponentConnector
	{
		// Token: 0x06001616 RID: 5654 RVA: 0x0000F601 File Offset: 0x0000D801
		public OtherControl()
		{
			this.InitializeComponent();
			this.LocalizeString();
		}

		// Token: 0x06001617 RID: 5655 RVA: 0x00085DB0 File Offset: 0x00083FB0
		private void LocalizeString()
		{
			BlueStacksUIBinding.Bind(this.mlblServerLocation, "STRING_SERVER_LOCATION", "");
			BlueStacksUIBinding.Bind(this.mCloseButton, "STRING_CLOSE");
			this.LocalizedRecommendedString = " (" + LocaleStrings.GetLocalizedString("STRING_RECOMMENDED", false) + ")";
		}

		// Token: 0x06001618 RID: 5656 RVA: 0x0000F2D5 File Offset: 0x0000D4D5
		private void CloseButton_Click(object sender, RoutedEventArgs e)
		{
			AdvanceSettingsWindow.Instance.HideWindow();
		}

		// Token: 0x06001619 RID: 5657 RVA: 0x00085E04 File Offset: 0x00084004
		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			this.dictServers = AdvanceSettingsHelper.ServersDict;
			foreach (KeyValuePair<string, string> keyValuePair in this.dictServers)
			{
				ComboBoxItem comboBoxItem = new ComboBoxItem();
				comboBoxItem.Content = keyValuePair.Key;
				if (this.mServerCombo.Items.Count == 0)
				{
					comboBoxItem.Content = keyValuePair.Key + this.LocalizedRecommendedString;
				}
				this.mServerCombo.Items.Add(comboBoxItem);
			}
			if (string.IsNullOrEmpty(RegistryManager.Instance.TwitchServerPath))
			{
				this.mServerCombo.Text = this.dictServers.Keys.ToList<string>()[0] + this.LocalizedRecommendedString;
				return;
			}
			this.mServerCombo.Text = RegistryManager.Instance.TwitchServerPath;
			if (this.mServerCombo.SelectedItem == null)
			{
				this.mServerCombo.Text = this.dictServers.Keys.ToList<string>()[0] + this.LocalizedRecommendedString;
			}
		}

		// Token: 0x0600161A RID: 5658 RVA: 0x00085F38 File Offset: 0x00084138
		private void ServerCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count > 0)
			{
				string text = ((ComboBoxItem)e.AddedItems[0]).Content.ToString();
				if (text.Contains(this.LocalizedRecommendedString))
				{
					text = text.Replace(this.LocalizedRecommendedString, string.Empty);
				}
				RegistryManager.Instance.TwitchServerPath = text;
			}
		}

		// Token: 0x0600161B RID: 5659 RVA: 0x00085F9C File Offset: 0x0008419C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/btv/wpffiles/usercontrol/othercontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600161C RID: 5660 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600161D RID: 5661 RVA: 0x00085FCC File Offset: 0x000841CC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((OtherControl)target).Loaded += this.UserControl_Loaded;
				return;
			case 2:
				this.mlblServerLocation = (TextBlock)target;
				return;
			case 3:
				this.mServerCombo = (CustomComboBox)target;
				return;
			case 4:
				this.mCloseButton = (Button)target;
				this.mCloseButton.Click += this.CloseButton_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000F67 RID: 3943
		private Dictionary<string, string> dictServers = new Dictionary<string, string>();

		// Token: 0x04000F68 RID: 3944
		private string LocalizedRecommendedString = "(Recommended)";

		// Token: 0x04000F69 RID: 3945
		internal TextBlock mlblServerLocation;

		// Token: 0x04000F6A RID: 3946
		internal CustomComboBox mServerCombo;

		// Token: 0x04000F6B RID: 3947
		internal Button mCloseButton;

		// Token: 0x04000F6C RID: 3948
		private bool _contentLoaded;
	}
}
