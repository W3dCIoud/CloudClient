﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000282 RID: 642
	public class CustomToggleButton : ToggleButton, IComponentConnector, IStyleConnector
	{
		// Token: 0x17000232 RID: 562
		// (set) Token: 0x060015F7 RID: 5623 RVA: 0x0000F441 File Offset: 0x0000D641
		public string ImageName
		{
			set
			{
				this.mImageName = value;
			}
		}

		// Token: 0x060015F8 RID: 5624 RVA: 0x0000F44A File Offset: 0x0000D64A
		public CustomToggleButton()
		{
			this.InitializeComponent();
		}

		// Token: 0x060015F9 RID: 5625 RVA: 0x00085804 File Offset: 0x00083A04
		private void ToggleButton_Checked(object sender, RoutedEventArgs e)
		{
			if (CustomToggleButton.mCurrentButtonChecked != this)
			{
				CustomToggleButton.mCurrentButtonChecked = this;
				if (CustomToggleButton.mLastButtonChecked != null)
				{
					ToggleButton toggleButton = CustomToggleButton.mLastButtonChecked;
					CustomToggleButton.mLastButtonChecked = this;
					toggleButton.IsChecked = new bool?(false);
				}
				else
				{
					CustomToggleButton.mLastButtonChecked = this;
				}
				if (this.mImage != null)
				{
					this.mImage.SetSelectedImage();
				}
			}
		}

		// Token: 0x060015FA RID: 5626 RVA: 0x00085858 File Offset: 0x00083A58
		private void ToggleButton_Loaded(object sender, RoutedEventArgs e)
		{
			if (this.mImage != null)
			{
				if (!base.IsEnabled)
				{
					this.mImage.SetDisabledImage();
					return;
				}
				if (base.IsChecked != null && base.IsChecked.Value)
				{
					this.mImage.SetSelectedImage();
					return;
				}
				this.mImage.SetDefaultImage();
			}
		}

		// Token: 0x060015FB RID: 5627 RVA: 0x0000F463 File Offset: 0x0000D663
		private void ToggleButton_Unchecked(object sender, RoutedEventArgs e)
		{
			if (CustomToggleButton.mCurrentButtonChecked == this)
			{
				base.IsChecked = new bool?(true);
				return;
			}
			if (this.mImage != null)
			{
				this.mImage.SetDefaultImage();
			}
		}

		// Token: 0x060015FC RID: 5628 RVA: 0x0000F48D File Offset: 0x0000D68D
		private void ToggleButton_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (this.mImage != null)
			{
				this.mImage.SetDisabledImage();
			}
		}

		// Token: 0x060015FD RID: 5629 RVA: 0x0000F4A2 File Offset: 0x0000D6A2
		private void Image_Initialized(object sender, EventArgs e)
		{
			this.mImage = (sender as CustomPictureBox);
			this.mImage.ImageName = this.mImageName;
		}

		// Token: 0x060015FE RID: 5630 RVA: 0x000858B8 File Offset: 0x00083AB8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/btv/wpffiles/usercontrol/customtogglebutton.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060015FF RID: 5631 RVA: 0x000858E8 File Offset: 0x00083AE8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				((CustomToggleButton)target).Checked += this.ToggleButton_Checked;
				((CustomToggleButton)target).Unchecked += this.ToggleButton_Unchecked;
				((CustomToggleButton)target).IsEnabledChanged += this.ToggleButton_IsEnabledChanged;
				((CustomToggleButton)target).Loaded += this.ToggleButton_Loaded;
				return;
			}
			if (connectionId != 3)
			{
				this._contentLoaded = true;
				return;
			}
			this.mToolTip = (ToolTip)target;
		}

		// Token: 0x06001600 RID: 5632 RVA: 0x0000F4C1 File Offset: 0x0000D6C1
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 2)
			{
				((CustomPictureBox)target).Initialized += this.Image_Initialized;
			}
		}

		// Token: 0x04000F52 RID: 3922
		private string mImageName = string.Empty;

		// Token: 0x04000F53 RID: 3923
		private static CustomToggleButton mLastButtonChecked;

		// Token: 0x04000F54 RID: 3924
		private static CustomToggleButton mCurrentButtonChecked;

		// Token: 0x04000F55 RID: 3925
		private CustomPictureBox mImage;

		// Token: 0x04000F56 RID: 3926
		internal ToolTip mToolTip;

		// Token: 0x04000F57 RID: 3927
		private bool _contentLoaded;
	}
}
