﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000251 RID: 593
	public partial class BtvWindow : CustomWindow
	{
		// Token: 0x1700022B RID: 555
		// (get) Token: 0x06001443 RID: 5187 RVA: 0x0007C4E8 File Offset: 0x0007A6E8
		// (set) Token: 0x06001444 RID: 5188 RVA: 0x0000E57F File Offset: 0x0000C77F
		public static BtvWindow Instance
		{
			get
			{
				if (BtvWindow.sInstance == null)
				{
					object obj = BtvWindow.syncRoot;
					lock (obj)
					{
						if (BtvWindow.sInstance == null)
						{
							BtvWindow.sInstance = new BtvWindow();
						}
					}
				}
				return BtvWindow.sInstance;
			}
			set
			{
				BtvWindow.sInstance = value;
			}
		}

		// Token: 0x06001445 RID: 5189 RVA: 0x0007C538 File Offset: 0x0007A738
		public BtvWindow()
		{
			this.InitializeComponent();
			this.mBtvUserControl = new BtvWebUserControl("google.com");
			new RowDefinition().Height = new GridLength(1.0, GridUnitType.Star);
			this.mGrid.Children.Add(this.mBtvUserControl);
			Grid.SetRow(this.mBtvUserControl, 1);
			this.mBtvUserControl.Visibility = Visibility.Visible;
			base.Width = 320.0;
			base.Height = 540.0;
			this.mIsWindowLoadedOnce = true;
		}

		// Token: 0x06001446 RID: 5190 RVA: 0x0000E587 File Offset: 0x0000C787
		public void ShowWindow()
		{
			if (this.mIsWindowLoadedOnce)
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					if (base.WindowState == WindowState.Minimized)
					{
						this.RestoreWindows();
					}
					base.Visibility = Visibility.Visible;
					base.Show();
					base.BringIntoView();
					if (!base.Topmost)
					{
						base.Topmost = true;
						base.Topmost = false;
					}
				}), new object[0]);
			}
		}

		// Token: 0x06001447 RID: 5191 RVA: 0x0000E5AF File Offset: 0x0000C7AF
		private void RestoreWindows()
		{
			base.WindowState = WindowState.Normal;
		}

		// Token: 0x06001448 RID: 5192 RVA: 0x0000E5B8 File Offset: 0x0000C7B8
		private void BtvWindow_Closed(object sender, EventArgs e)
		{
			this.mIsWindowLoadedOnce = false;
			BtvWindow.sInstance = null;
		}

		// Token: 0x06001449 RID: 5193 RVA: 0x0000E5C7 File Offset: 0x0000C7C7
		private void addressTextBox_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Return)
			{
				this.mBtvUserControl.mBrowser.NavigateTo(this.addressTextBox.Text);
			}
		}

		// Token: 0x04000E18 RID: 3608
		private static BtvWindow sInstance;

		// Token: 0x04000E19 RID: 3609
		private static object syncRoot = new object();

		// Token: 0x04000E1A RID: 3610
		private bool mIsWindowLoadedOnce;

		// Token: 0x04000E1B RID: 3611
		private BtvWebUserControl mBtvUserControl;
	}
}
