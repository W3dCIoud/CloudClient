﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x0200026E RID: 622
	public class AdvanceSettingsWindow : Window, IComponentConnector
	{
		// Token: 0x0600154F RID: 5455 RVA: 0x0000ED24 File Offset: 0x0000CF24
		public AdvanceSettingsWindow()
		{
			this.InitializeComponent();
			if (!DesignerProperties.GetIsInDesignMode(this))
			{
				this.Intialize();
				this.LocalizeString();
			}
		}

		// Token: 0x06001550 RID: 5456 RVA: 0x000834E8 File Offset: 0x000816E8
		private void LocalizeString()
		{
			this.mLblAdvancedStreamSettings.Content = LocaleStrings.GetLocalizedString("STRING_LBL_ADVANCED_STREAM_SETTINGS", false);
			BlueStacksUIBinding.Bind(this.mAudioButton, "STRING_AUDIO_BUTTON");
			this.mAudioButton.Content = LocaleStrings.GetLocalizedString("STRING_AUDIO_BUTTON", false);
			this.mVideoButton.Content = LocaleStrings.GetLocalizedString("STRING_VIDEO_BUTTON", false);
			this.mVideoButton.Tag = LocaleStrings.GetLocalizedString("STRING_VIDEO_BUTTON_TOOLTIP", false);
			this.mOtherButton.Content = LocaleStrings.GetLocalizedString("STRING_OTHER_BUTTON", false);
			this.mOtherButton.Tag = LocaleStrings.GetLocalizedString("STRING_OTHER_BUTTON_TOOLTIP", false);
		}

		// Token: 0x06001551 RID: 5457 RVA: 0x0000ED46 File Offset: 0x0000CF46
		private void Intialize()
		{
			this.mAudioControl.Intialize();
			this.mVideoControl.Intialize();
		}

		// Token: 0x06001552 RID: 5458 RVA: 0x000338D0 File Offset: 0x00031AD0
		private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
		{
			try
			{
				base.DragMove();
			}
			catch
			{
			}
		}

		// Token: 0x06001553 RID: 5459 RVA: 0x0000553B File Offset: 0x0000373B
		private void CloseButton_MouseDown(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x06001554 RID: 5460 RVA: 0x0000ED5E File Offset: 0x0000CF5E
		private void CloseButton_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.HideWindow();
		}

		// Token: 0x06001555 RID: 5461 RVA: 0x0000ED66 File Offset: 0x0000CF66
		private void BringInFront(UserControl control)
		{
			if (this.mControlOnTop != null)
			{
				this.mControlOnTop.Visibility = Visibility.Hidden;
			}
			control.Visibility = Visibility.Visible;
			this.mControlOnTop = control;
		}

		// Token: 0x06001556 RID: 5462 RVA: 0x0000ED8A File Offset: 0x0000CF8A
		private void AudioButton_Checked(object sender, RoutedEventArgs e)
		{
			this.BringInFront(this.mAudioControl);
		}

		// Token: 0x06001557 RID: 5463 RVA: 0x0000ED98 File Offset: 0x0000CF98
		private void VideoButton_Checked(object sender, RoutedEventArgs e)
		{
			this.BringInFront(this.mVideoControl);
		}

		// Token: 0x06001558 RID: 5464 RVA: 0x0000EDA6 File Offset: 0x0000CFA6
		private void OtherButton_Checked(object sender, RoutedEventArgs e)
		{
			this.BringInFront(this.mOtherControl);
		}

		// Token: 0x06001559 RID: 5465 RVA: 0x0000EDB4 File Offset: 0x0000CFB4
		internal void HideWindow()
		{
			base.Hide();
			this.mVideoControl.UnParentOBS();
		}

		// Token: 0x0600155A RID: 5466 RVA: 0x0008358C File Offset: 0x0008178C
		internal static void ShowWindow()
		{
			if (AdvanceSettingsWindow.Instance == null)
			{
				AdvanceSettingsWindow.Instance = new AdvanceSettingsWindow();
			}
			AdvanceSettingsWindow.Instance.mAudioButton.IsChecked = new bool?(true);
			AdvanceSettingsWindow.Instance.mVideoControl.ReparentOBS();
			if (StreamManager.Instance.mIsStreaming)
			{
				AdvanceSettingsWindow.Instance.mVideoButton.IsEnabled = false;
				AdvanceSettingsWindow.Instance.mOtherButton.IsEnabled = false;
			}
			else
			{
				AdvanceSettingsWindow.Instance.mVideoButton.IsEnabled = true;
				AdvanceSettingsWindow.Instance.mOtherButton.IsEnabled = true;
			}
			StreamManager.Instance.GetParametersFromOBS();
			AdvanceSettingsWindow.Instance.ShowDialog();
		}

		// Token: 0x0600155B RID: 5467 RVA: 0x00083634 File Offset: 0x00081834
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/btv/wpffiles/advancesettingswindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600155C RID: 5468 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600155D RID: 5469 RVA: 0x00083664 File Offset: 0x00081864
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((Grid)target).MouseDown += this.Grid_MouseDown;
				return;
			case 2:
				this.mLblAdvancedStreamSettings = (Label)target;
				return;
			case 3:
				((CustomPictureBox)target).MouseDown += this.CloseButton_MouseDown;
				((CustomPictureBox)target).MouseUp += this.CloseButton_MouseUp;
				return;
			case 4:
				this.mAudioControl = (AudioControl)target;
				return;
			case 5:
				this.mVideoControl = (VideoControl)target;
				return;
			case 6:
				this.mOtherControl = (OtherControl)target;
				return;
			case 7:
				this.mAudioButton = (CustomToggleButton)target;
				return;
			case 8:
				this.mVideoButton = (CustomToggleButton)target;
				return;
			case 9:
				this.mOtherButton = (CustomToggleButton)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000EDF RID: 3807
		public static AdvanceSettingsWindow Instance;

		// Token: 0x04000EE0 RID: 3808
		private UserControl mControlOnTop;

		// Token: 0x04000EE1 RID: 3809
		internal Label mLblAdvancedStreamSettings;

		// Token: 0x04000EE2 RID: 3810
		internal AudioControl mAudioControl;

		// Token: 0x04000EE3 RID: 3811
		internal VideoControl mVideoControl;

		// Token: 0x04000EE4 RID: 3812
		internal OtherControl mOtherControl;

		// Token: 0x04000EE5 RID: 3813
		internal CustomToggleButton mAudioButton;

		// Token: 0x04000EE6 RID: 3814
		internal CustomToggleButton mVideoButton;

		// Token: 0x04000EE7 RID: 3815
		internal CustomToggleButton mOtherButton;

		// Token: 0x04000EE8 RID: 3816
		private bool _contentLoaded;
	}
}
