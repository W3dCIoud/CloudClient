﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000271 RID: 625
	public class FilterDownloadProgress : Window, IComponentConnector
	{
		// Token: 0x0600156F RID: 5487 RVA: 0x00083994 File Offset: 0x00081B94
		public FilterDownloadProgress()
		{
			FilterDownloadProgress.Instance = this;
			this.InitializeComponent();
			BlueStacksUIBinding.Bind(this.mLabelText, "STRING_INITIALIZING_DOWNLOADER");
			BlueStacksUIBinding.Bind(this.mApplyButton, "STRING_APPLY");
			BlueStacksUIBinding.Bind(this.mLaterButton, "STRING_LATER_BUTTON");
			base.Closing += this.HandleCloseEvent;
			this.SetControlProperties();
		}

		// Token: 0x06001570 RID: 5488 RVA: 0x0000EEAB File Offset: 0x0000D0AB
		private void HandleCloseEvent(object sender, CancelEventArgs e)
		{
			if (FilterDownloader.Instance != null)
			{
				FilterDownloader.Instance.ExecuteCallBack(this.mCallBackStatus);
			}
		}

		// Token: 0x06001571 RID: 5489 RVA: 0x000839FC File Offset: 0x00081BFC
		public void UpdateProgress(string text)
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				this.mLabelText.Content = text;
			}), new object[0]);
		}

		// Token: 0x06001572 RID: 5490 RVA: 0x0000EEC4 File Offset: 0x0000D0C4
		private void SetControlProperties()
		{
			BlueStacksUIBinding.Bind(this.mCloseButton, "STRING_CLOSE");
			this.mCloseButton.MouseUp += this.CloseButton_MouseUp;
			this.mCloseButton.MouseLeftButtonDown += this.HandleMouseDown;
		}

		// Token: 0x06001573 RID: 5491 RVA: 0x00008193 File Offset: 0x00006393
		private void CloseButton_MouseUp(object sender, MouseButtonEventArgs e)
		{
			base.Close();
		}

		// Token: 0x06001574 RID: 5492 RVA: 0x0000553B File Offset: 0x0000373B
		private void HandleMouseDown(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x06001575 RID: 5493 RVA: 0x0000EF04 File Offset: 0x0000D104
		private void LaterButtonClick(object sender, RoutedEventArgs e)
		{
			FilterDownloader.sUpdateLater = true;
			FilterDownloader.sStopBackgroundWorker = false;
			this.mCallBackStatus = true;
			base.Close();
			FilterDownloader.Instance = null;
		}

		// Token: 0x06001576 RID: 5494 RVA: 0x0000EF25 File Offset: 0x0000D125
		private void ApplyButtonClick(object sender, RoutedEventArgs e)
		{
			this.mApplyButton.IsEnabled = false;
			this.mLaterButton.IsEnabled = false;
			this.mProgressBar.Visibility = Visibility.Visible;
			FilterDownloader.sUpdateLater = false;
			FilterDownloader.sStopBackgroundWorker = false;
		}

		// Token: 0x06001577 RID: 5495 RVA: 0x0000EF57 File Offset: 0x0000D157
		public void EnableButtons()
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				this.mLaterButton.IsEnabled = true;
				this.mApplyButton.IsEnabled = true;
				this.mProgressBar.Visibility = Visibility.Hidden;
			}), new object[0]);
		}

		// Token: 0x06001578 RID: 5496 RVA: 0x00083A40 File Offset: 0x00081C40
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/btv/wpffiles/filterdownloadprogress.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06001579 RID: 5497 RVA: 0x00083A70 File Offset: 0x00081C70
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mCloseButton = (CustomPictureBox)target;
				return;
			case 2:
				this.mLabelText = (Label)target;
				return;
			case 3:
				this.mProgressBar = (ProgressBar)target;
				return;
			case 4:
				this.mApplyButton = (Button)target;
				this.mApplyButton.Click += this.ApplyButtonClick;
				return;
			case 5:
				this.mLaterButton = (Button)target;
				this.mLaterButton.Click += this.LaterButtonClick;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000EF6 RID: 3830
		public static FilterDownloadProgress Instance;

		// Token: 0x04000EF7 RID: 3831
		private bool mCallBackStatus;

		// Token: 0x04000EF8 RID: 3832
		internal CustomPictureBox mCloseButton;

		// Token: 0x04000EF9 RID: 3833
		internal Label mLabelText;

		// Token: 0x04000EFA RID: 3834
		internal ProgressBar mProgressBar;

		// Token: 0x04000EFB RID: 3835
		internal Button mApplyButton;

		// Token: 0x04000EFC RID: 3836
		internal Button mLaterButton;

		// Token: 0x04000EFD RID: 3837
		private bool _contentLoaded;
	}
}
