﻿using System;
using System.Windows;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000242 RID: 578
	public class BTvBrowserControl : BrowserControl
	{
		// Token: 0x060013F2 RID: 5106 RVA: 0x0000E169 File Offset: 0x0000C369
		public BTvBrowserControl(string url, float zoomLevel = 0f)
		{
			this.mCustomZoomLevel = zoomLevel;
			base.InitBaseControl(url, zoomLevel);
			base.Visibility = Visibility.Visible;
		}

		// Token: 0x04000DEA RID: 3562
		public double zoomLevel = 1.0;

		// Token: 0x04000DEB RID: 3563
		private float mCustomZoomLevel;
	}
}
