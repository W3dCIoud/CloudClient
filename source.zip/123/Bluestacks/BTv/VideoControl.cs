﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Forms.Integration;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000286 RID: 646
	public class VideoControl : System.Windows.Controls.UserControl, IComponentConnector
	{
		// Token: 0x0600161E RID: 5662 RVA: 0x0000F62B File Offset: 0x0000D82B
		public VideoControl()
		{
			this.InitializeComponent();
			this.LocalizeStrings();
		}

		// Token: 0x0600161F RID: 5663 RVA: 0x00086050 File Offset: 0x00084250
		private void LocalizeStrings()
		{
			this.mLocalizedTextAuto = "(" + LocaleStrings.GetLocalizedString("STRING_AUTO", false) + ")";
			this.mLocalizedTextNone = LocaleStrings.GetLocalizedString("None", false);
			BlueStacksUIBinding.Bind(this.mLblWebcamSource, "STRING_WEBCAM_SOURCE_STRING", "");
			BlueStacksUIBinding.Bind(this.mStreamQualityText, "STRING_STREAM_QUALITY");
			BlueStacksUIBinding.Bind(this.mCloseButton, "STRING_CLOSE");
			this.mStreamQualityDetailsText.Text = "*" + LocaleStrings.GetLocalizedString("STRING_STREAM_QUALITY_DETAILS", false);
		}

		// Token: 0x06001620 RID: 5664 RVA: 0x0000F2D5 File Offset: 0x0000D4D5
		private void CloseButton_Click(object sender, RoutedEventArgs e)
		{
			AdvanceSettingsWindow.Instance.HideWindow();
		}

		// Token: 0x06001621 RID: 5665 RVA: 0x0000F660 File Offset: 0x0000D860
		internal void Intialize()
		{
			StreamManager.Instance.EventGetCameraDetails += this.StreamManager_EventGetCamera;
			this.SetResolutionCombo();
		}

		// Token: 0x06001622 RID: 5666 RVA: 0x000860E4 File Offset: 0x000842E4
		private void SetResolutionCombo()
		{
			List<string> list = new List<string>();
			list.Add(this.mLocalizedTextAuto + " " + StreamManager.Instance.mStreamHeight.ToString() + "p");
			if (!list.Contains("540p"))
			{
				list.Add("540p");
			}
			if (!list.Contains("720p"))
			{
				list.Add("720p");
			}
			if (!list.Contains("1080p"))
			{
				list.Add("1080p");
			}
			foreach (string content in list)
			{
				ComboBoxItem comboBoxItem = new ComboBoxItem();
				comboBoxItem.Content = content;
				this.mResolutionCombo.Items.Add(comboBoxItem);
			}
			if (RegistryManager.Instance.StreamingResolution == 0)
			{
				this.mResolutionCombo.Text = list[0];
				return;
			}
			this.mResolutionCombo.Text = RegistryManager.Instance.StreamingResolution.ToString() + "p";
			if (this.mResolutionCombo.SelectedItem == null)
			{
				this.mResolutionCombo.Text = list[0];
			}
		}

		// Token: 0x06001623 RID: 5667 RVA: 0x00086228 File Offset: 0x00084428
		private void ResolutionCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count > 0)
			{
				string text = ((ComboBoxItem)e.AddedItems[0]).Content.ToString();
				if (text.Contains(this.mLocalizedTextAuto))
				{
					RegistryManager.Instance.StreamingResolution = 0;
					return;
				}
				RegistryManager.Instance.StreamingResolution = Convert.ToInt32(text.Replace('p', ' ').Trim());
			}
		}

		// Token: 0x06001624 RID: 5668 RVA: 0x00086298 File Offset: 0x00084498
		private void StreamManager_EventGetCamera(object sender, CustomVolumeEventArgs e)
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				this.mWebCamSource.Items.Clear();
				ComboBoxItem comboBoxItem = new ComboBoxItem();
				comboBoxItem.Content = this.mLocalizedTextNone;
				this.mWebCamSource.Items.Add(comboBoxItem);
				foreach (string content in e.dictData.Keys)
				{
					comboBoxItem = new ComboBoxItem();
					comboBoxItem.Content = content;
					this.mWebCamSource.Items.Add(comboBoxItem);
				}
				if (StreamManager.mIsWebcamDisabled)
				{
					this.mWebCamSource.Text = this.mLocalizedTextNone;
					return;
				}
				this.mWebCamSource.Text = e.mSelected;
			}), new object[0]);
		}

		// Token: 0x06001625 RID: 5669 RVA: 0x000862DC File Offset: 0x000844DC
		private void WebCamSource_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count > 0)
			{
				string text = ((ComboBoxItem)e.AddedItems[0]).Content.ToString();
				if (text.Equals(this.mLocalizedTextNone))
				{
					StreamManager.mIsWebcamDisabled = true;
					StreamManager.Instance.DisableWebcam();
					return;
				}
				StreamManager.mIsWebcamDisabled = false;
				StreamManager.Instance.UpdateCameraPosition(text);
				RegistryManager.Instance.SelectedCam = text;
			}
		}

		// Token: 0x06001626 RID: 5670 RVA: 0x00086350 File Offset: 0x00084550
		internal void ReparentOBS()
		{
			if (this.mOBSGrid.ActualWidth != 0.0)
			{
				StreamManager.Instance.UpdateCameraPosition(string.Empty);
				StreamWindowUtility.UnSetOBSParentWindow();
				VideoControl.mOBSHandle = InteropWindow.FindWindow("OBSWindowClass", null);
				IntPtr handle = this.mPanel.Handle;
				if (VideoControl.mOBSHandle != IntPtr.Zero)
				{
					Logger.Info("OBS Handle: {0}", new object[]
					{
						VideoControl.mOBSHandle.ToString()
					});
					if (StreamWindowUtility.sOBSDevEnv)
					{
						InteropWindow.SetWindowLong(VideoControl.mOBSHandle, -16, InteropWindow.GetWindowLong(VideoControl.mOBSHandle, -16) | Convert.ToInt32(1073741824U));
					}
					else
					{
						InteropWindow.SetWindowLong(VideoControl.mOBSHandle, -16, Convert.ToInt32(1073741824U));
					}
					InteropWindow.SetParent(VideoControl.mOBSHandle, handle);
					InteropWindow.SetWindowPos(VideoControl.mOBSHandle, (IntPtr)0, 0, 0, this.mPanel.Width, this.mPanel.Height, 80U);
					InteropWindow.ShowWindow(VideoControl.mOBSHandle, 5);
				}
			}
		}

		// Token: 0x06001627 RID: 5671 RVA: 0x0000F67E File Offset: 0x0000D87E
		internal void UnParentOBS()
		{
			if (VideoControl.mOBSHandle != IntPtr.Zero)
			{
				InteropWindow.ShowWindow(VideoControl.mOBSHandle, 0);
				InteropWindow.SetParent(VideoControl.mOBSHandle, IntPtr.Zero);
			}
			StreamManager.Instance.ChangeCamera();
			StreamWindowUtility.ReParentOBSWindow();
		}

		// Token: 0x06001628 RID: 5672 RVA: 0x00086460 File Offset: 0x00084660
		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			if (!DesignerProperties.GetIsInDesignMode(this))
			{
				double num = (double)Screen.PrimaryScreen.WorkingArea.Height / SystemParameters.WorkArea.Height;
				this.mPanel.Width = (int)(this.mOBSGrid.ActualWidth * num);
				this.mPanel.Height = (int)(this.mOBSGrid.ActualHeight * num);
				this.mPanel.BackColor = Color.Black;
				this.mPanel.Dock = DockStyle.Fill;
				this.PreviewHost.Child = this.mPanel;
				VideoControl.mOBSHandle = this.mPanel.Handle;
				IntPtr handle = this.mPanel.Handle;
				this.ReparentOBS();
			}
		}

		// Token: 0x06001629 RID: 5673 RVA: 0x0008651C File Offset: 0x0008471C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/btv/wpffiles/usercontrol/videocontrol.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600162A RID: 5674 RVA: 0x0008654C File Offset: 0x0008474C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((VideoControl)target).Loaded += this.UserControl_Loaded;
				return;
			case 2:
				this.mOBSGrid = (Grid)target;
				return;
			case 3:
				this.PreviewHost = (WindowsFormsHost)target;
				return;
			case 4:
				this.mStreamQualityText = (Run)target;
				return;
			case 5:
				this.mStreamQualityDetailsText = (Run)target;
				return;
			case 6:
				this.mResolutionCombo = (CustomComboBox)target;
				this.mResolutionCombo.SelectionChanged += this.ResolutionCombo_SelectionChanged;
				return;
			case 7:
				this.mLblWebcamSource = (TextBlock)target;
				return;
			case 8:
				this.mWebCamSource = (CustomComboBox)target;
				this.mWebCamSource.SelectionChanged += this.WebCamSource_SelectionChanged;
				return;
			case 9:
				this.mCloseButton = (System.Windows.Controls.Button)target;
				this.mCloseButton.Click += this.CloseButton_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000F6D RID: 3949
		public static IntPtr mOBSHandle = IntPtr.Zero;

		// Token: 0x04000F6E RID: 3950
		private System.Windows.Forms.Panel mPanel = new System.Windows.Forms.Panel();

		// Token: 0x04000F6F RID: 3951
		private string mLocalizedTextAuto = "(Auto)";

		// Token: 0x04000F70 RID: 3952
		private string mLocalizedTextNone = "None";

		// Token: 0x04000F71 RID: 3953
		internal Grid mOBSGrid;

		// Token: 0x04000F72 RID: 3954
		internal WindowsFormsHost PreviewHost;

		// Token: 0x04000F73 RID: 3955
		internal Run mStreamQualityText;

		// Token: 0x04000F74 RID: 3956
		internal Run mStreamQualityDetailsText;

		// Token: 0x04000F75 RID: 3957
		internal CustomComboBox mResolutionCombo;

		// Token: 0x04000F76 RID: 3958
		internal TextBlock mLblWebcamSource;

		// Token: 0x04000F77 RID: 3959
		internal CustomComboBox mWebCamSource;

		// Token: 0x04000F78 RID: 3960
		internal System.Windows.Controls.Button mCloseButton;

		// Token: 0x04000F79 RID: 3961
		private bool _contentLoaded;
	}
}
