﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000283 RID: 643
	public class EndStreamPopup : Window, IComponentConnector
	{
		// Token: 0x06001602 RID: 5634 RVA: 0x0000F4DE File Offset: 0x0000D6DE
		public EndStreamPopup()
		{
			this.InitializeComponent();
			this.CloseBtn.MouseDown += this.CloseBtn_MouseDown;
		}

		// Token: 0x06001603 RID: 5635 RVA: 0x0000F50A File Offset: 0x0000D70A
		private void PopulateCustomPopupInfo(string message, string leftButton, string rightButton, string title)
		{
			this.EndStreamText.Text = message;
			this.LeftButtonText.Text = leftButton;
			this.RightButtonText.Text = rightButton;
			this.EndstreamTitleText.Text = title;
		}

		// Token: 0x06001604 RID: 5636 RVA: 0x0000F53D File Offset: 0x0000D73D
		private void CloseBtn_MouseDown(object sender, MouseButtonEventArgs e)
		{
			this.messageBoxResult = MessageBoxResult.No;
			base.Close();
		}

		// Token: 0x06001605 RID: 5637 RVA: 0x0000F54C File Offset: 0x0000D74C
		private void LeftButton_MouseButtonDown(object sender, MouseButtonEventArgs e)
		{
			this.messageBoxResult = MessageBoxResult.Yes;
			base.Close();
		}

		// Token: 0x06001606 RID: 5638 RVA: 0x0000F53D File Offset: 0x0000D73D
		private void RightButton_MouseButtonDown(object sender, MouseButtonEventArgs e)
		{
			this.messageBoxResult = MessageBoxResult.No;
			base.Close();
		}

		// Token: 0x06001607 RID: 5639 RVA: 0x0000F55B File Offset: 0x0000D75B
		public static MessageBoxResult ShowPopup(string message, string leftButton, string rightButton, string title)
		{
			EndStreamPopup endStreamPopup = new EndStreamPopup();
			endStreamPopup.PopulateCustomPopupInfo(message, leftButton, rightButton, title);
			endStreamPopup.ShowDialog();
			return endStreamPopup.messageBoxResult;
		}

		// Token: 0x06001608 RID: 5640 RVA: 0x00085970 File Offset: 0x00083B70
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/btv/wpffiles/usercontrol/endstreampopup.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06001609 RID: 5641 RVA: 0x000859A0 File Offset: 0x00083BA0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.EndstreamTitleText = (TextBlock)target;
				return;
			case 2:
				this.CloseBtn = (CustomPictureBox)target;
				return;
			case 3:
				this.EndStreamText = (TextBlock)target;
				return;
			case 4:
				this.LeftGrid = (Grid)target;
				this.LeftGrid.MouseDown += this.LeftButton_MouseButtonDown;
				return;
			case 5:
				((Viewbox)target).MouseDown += this.LeftButton_MouseButtonDown;
				return;
			case 6:
				this.LeftButtonText = (TextBlock)target;
				return;
			case 7:
				this.RightButtonGrid = (Grid)target;
				this.RightButtonGrid.MouseDown += this.RightButton_MouseButtonDown;
				return;
			case 8:
				((Viewbox)target).MouseDown += this.RightButton_MouseButtonDown;
				return;
			case 9:
				this.RightButtonText = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000F58 RID: 3928
		private MessageBoxResult messageBoxResult = MessageBoxResult.No;

		// Token: 0x04000F59 RID: 3929
		internal TextBlock EndstreamTitleText;

		// Token: 0x04000F5A RID: 3930
		internal CustomPictureBox CloseBtn;

		// Token: 0x04000F5B RID: 3931
		internal TextBlock EndStreamText;

		// Token: 0x04000F5C RID: 3932
		internal Grid LeftGrid;

		// Token: 0x04000F5D RID: 3933
		internal TextBlock LeftButtonText;

		// Token: 0x04000F5E RID: 3934
		internal Grid RightButtonGrid;

		// Token: 0x04000F5F RID: 3935
		internal TextBlock RightButtonText;

		// Token: 0x04000F60 RID: 3936
		private bool _contentLoaded;
	}
}
