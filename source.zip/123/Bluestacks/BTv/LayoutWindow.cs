﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Forms.Integration;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000276 RID: 630
	public class LayoutWindow : Window, IComponentConnector
	{
		// Token: 0x0600158D RID: 5517 RVA: 0x00084144 File Offset: 0x00082344
		public LayoutWindow()
		{
			this.InitializeComponent();
			this.SetControlProperties();
			base.Closing += this.HandleCloseEvent;
		}

		// Token: 0x0600158E RID: 5518 RVA: 0x000841A4 File Offset: 0x000823A4
		public static string GetLayoutName(string layoutTheme)
		{
			string[] array = JObject.Parse(layoutTheme)["name"].ToString().Split(new string[]
			{
				"_"
			}, StringSplitOptions.RemoveEmptyEntries);
			if (StreamManager.Instance.IsPortraitApp())
			{
				return "portrait_" + array[1];
			}
			return "landscape_" + array[1];
		}

		// Token: 0x0600158F RID: 5519 RVA: 0x00084204 File Offset: 0x00082404
		public void ChangeLayout(string layoutTheme, bool isAppView)
		{
			object obj = this.mChangeLayoutLock;
			lock (obj)
			{
				if (isAppView)
				{
					if (string.Compare(StreamManager.mCamStatus, "true", true) == 0)
					{
						StreamWindow.Instance.ChangeWebCamState();
					}
				}
				else if (string.Compare(StreamManager.mCamStatus, "true", true) != 0)
				{
					StreamWindow.Instance.ChangeWebCamState();
				}
				StreamManager.Instance.mLayoutTheme = layoutTheme;
				FilterUtility.UpdateLayout("LayoutTheme", layoutTheme, false);
				StreamManager.Instance.RestartRecord();
				StreamManager.Instance.mAppViewLayout = isAppView;
				FilterUtility.UpdateAppViewLayoutRegistry(isAppView);
			}
		}

		// Token: 0x06001590 RID: 5520 RVA: 0x000842A8 File Offset: 0x000824A8
		private void SetControlProperties()
		{
			this.mCloseButton.ToolTip = LocaleStrings.GetLocalizedString("STRING_CLOSE", false);
			this.mCloseButton.MouseUp += this.CloseButton_MouseUp;
			this.mCloseButton.MouseLeftButtonDown += this.HandleMouseDown;
		}

		// Token: 0x06001591 RID: 5521 RVA: 0x00004BF2 File Offset: 0x00002DF2
		private void HandleMouseDown(object sender, MouseButtonEventArgs e)
		{
		}

		// Token: 0x06001592 RID: 5522 RVA: 0x000842FC File Offset: 0x000824FC
		private void CloseButton_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.mbrowserControl.mBrowser.getURL();
			StreamWindow.Instance.EvaluateJS("closeWindow();");
			this.mbrowserControl.mBrowser.ExecuteJavaScript("closeWindow();", this.mbrowserControl.mBrowser.getURL(), 0);
			base.Close();
		}

		// Token: 0x06001593 RID: 5523 RVA: 0x0000F019 File Offset: 0x0000D219
		private void Titlebar_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!this.mCloseButton.IsMouseOver)
			{
				base.DragMove();
			}
		}

		// Token: 0x06001594 RID: 5524 RVA: 0x00084358 File Offset: 0x00082558
		public void Setup(string layoutTheme, string paramsStr)
		{
			LayoutWindow.Instance = this;
			string text = RegistryManager.Instance.LayoutUrl;
			if (string.IsNullOrEmpty(text))
			{
				text = BtvApp.sApplicationBaseUrl + this.LAYOUT_HOME_URL;
			}
			this.mCurrentLayout = layoutTheme;
			this.mIsCurrentAppViewLayout = StreamManager.Instance.mAppViewLayout;
			this.mCurrentLastCameraLayout = StreamManager.Instance.mLastCameraLayoutTheme;
			text = text + "?activeMode=" + LayoutWindow.GetLayoutName(layoutTheme);
			if (StreamManager.Instance.mIsStreaming)
			{
				text += "&live=true";
			}
			text += paramsStr;
			float zoomLevel = (float)((base.Width - 573.0) / 573.0);
			this.mbrowserControl = new BTvBrowserControl(text, zoomLevel);
			this.BrowserGrid.Children.Add(this.mbrowserControl);
			this.mbrowserControl.Visibility = Visibility.Visible;
			Grid.SetRow(this.mbrowserControl, 0);
			Grid.SetColumn(this.mbrowserControl, 0);
			Grid.SetColumnSpan(this.mbrowserControl, 3);
			Grid.SetRowSpan(this.mbrowserControl, 3);
			this.mOBSRenderFrame = new System.Windows.Forms.Panel();
			this.mOBSRenderFrame.Dock = DockStyle.Fill;
			this.mOBSRenderFrame.BackColor = Color.Black;
			this.ObsHost.Child = this.mOBSRenderFrame;
			this.mOBSRenderFrame.BringToFront();
		}

		// Token: 0x06001595 RID: 5525 RVA: 0x000844A8 File Offset: 0x000826A8
		public static void LaunchWindow(string paramsStr)
		{
			try
			{
				object obj = LayoutWindow.mLayoutWindowLock;
				lock (obj)
				{
					if (LayoutWindow.Instance == null)
					{
						StreamWindowUtility.UnSetOBSParentWindow();
						LayoutWindow.Instance = new LayoutWindow();
						LayoutWindow.Instance.Setup(StreamManager.Instance.mLayoutTheme, paramsStr);
						LayoutWindow.Instance.Show();
					}
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06001596 RID: 5526 RVA: 0x00084524 File Offset: 0x00082724
		public void UpdateRegistry()
		{
			if (this.mCurrentLastCameraLayout != null)
			{
				FilterUtility.UpdateLayout("LastCameraLayoutTheme", this.mCurrentLastCameraLayout, true);
				StreamManager.Instance.mLastCameraLayoutTheme = this.mCurrentLastCameraLayout;
			}
			else
			{
				FilterUtility.UpdateLayout("LastCameraLayoutTheme", this.mCurrentLayout, true);
				StreamManager.Instance.mLastCameraLayoutTheme = this.mCurrentLayout;
			}
			FilterUtility.UpdateLayout("LayoutTheme", this.mCurrentLayout, false);
			FilterUtility.UpdateAppViewLayoutRegistry(this.mIsCurrentAppViewLayout);
		}

		// Token: 0x06001597 RID: 5527 RVA: 0x0008459C File Offset: 0x0008279C
		public void HandleCloseEvent(object sender, CancelEventArgs e)
		{
			Logger.Info("LayoutWindow: HandleCloseEvent");
			if (this.mClosingJsonString != null)
			{
				JObject jobject = JObject.Parse(this.mClosingJsonString);
				try
				{
					if (jobject.Property("stats") != null)
					{
						this.ReportToCloud(jobject["stats"].ToString());
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in HandleCloseEvent err : {0}", new object[]
					{
						ex.ToString()
					});
				}
				if (jobject.Property("type") != null && jobject["type"].ToString().Equals("close") && !StreamManager.Instance.mIsStreaming)
				{
					this.UpdateRegistry();
					this.ChangeLayout(this.mCurrentLayout, this.mIsCurrentAppViewLayout);
				}
			}
			else
			{
				Thread.Sleep(100);
			}
			base.Hide();
			if (this.mOBSHandle != IntPtr.Zero)
			{
				InteropWindow.ShowWindow(this.mOBSHandle, 0);
				InteropWindow.SetParent(this.mOBSHandle, IntPtr.Zero);
			}
			if (this.mbrowserControl.mBrowser != null)
			{
				this.mbrowserControl.mBrowser.Dispose();
			}
			if (StreamWindow.Instance != null)
			{
				StreamWindow.Instance.EvaluateJS("layoutWindowClosed();");
			}
			LayoutWindow.Instance = null;
		}

		// Token: 0x06001598 RID: 5528 RVA: 0x000846E0 File Offset: 0x000828E0
		public void ReParentOBSWindow()
		{
			this.mOBSHandle = InteropWindow.FindWindow("OBSWindowClass", null);
			IntPtr handle = this.mOBSRenderFrame.Handle;
			if (this.mOBSHandle != IntPtr.Zero)
			{
				Logger.Info("OBS Handle: {0}", new object[]
				{
					this.mOBSHandle.ToString()
				});
				if (StreamWindowUtility.sOBSDevEnv)
				{
					InteropWindow.SetWindowLong(this.mOBSHandle, -16, InteropWindow.GetWindowLong(this.mOBSHandle, -16) | Convert.ToInt32(1073741824U));
				}
				else
				{
					InteropWindow.SetWindowLong(this.mOBSHandle, -16, Convert.ToInt32(1073741824U));
				}
				InteropWindow.SetParent(this.mOBSHandle, handle);
				InteropWindow.SetWindowPos(this.mOBSHandle, (IntPtr)0, 0, 0, this.mOBSRenderFrame.Width, this.mOBSRenderFrame.Height, 80U);
				InteropWindow.ShowWindow(this.mOBSHandle, 5);
			}
		}

		// Token: 0x06001599 RID: 5529 RVA: 0x000847CC File Offset: 0x000829CC
		public void ReportToCloud(string jsonArray)
		{
			JArray jarray = JArray.Parse(jsonArray);
			for (int i = 0; i < jarray.Count; i++)
			{
				JObject jobject = JObject.Parse(jarray[i].ToString());
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				foreach (string text in (from p in jobject.Properties()
				select p.Name).ToList<string>())
				{
					if (jobject.Property(text) != null)
					{
						if (jobject[text].ToString().ToLower().Equals("true") || jobject[text].ToString().ToLower().Equals("false"))
						{
							dictionary.Add(text, jobject[text].ToString().ToLower());
						}
						else
						{
							dictionary.Add(text, jobject[text].ToString());
						}
					}
				}
			}
		}

		// Token: 0x0600159A RID: 5530 RVA: 0x0000F02E File Offset: 0x0000D22E
		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			this.ReParentOBSWindow();
		}

		// Token: 0x0600159B RID: 5531 RVA: 0x000848F8 File Offset: 0x00082AF8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/btv/wpffiles/layoutwindow.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600159C RID: 5532 RVA: 0x00084928 File Offset: 0x00082B28
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((LayoutWindow)target).Loaded += this.Window_Loaded;
				return;
			case 2:
				this.TopBar = (Grid)target;
				this.TopBar.MouseDown += this.Titlebar_MouseDown;
				return;
			case 3:
				this.mCloseButton = (CustomPictureBox)target;
				return;
			case 4:
				this.BrowserGrid = (Grid)target;
				return;
			case 5:
				this.BrowserHost = (WindowsFormsHost)target;
				return;
			case 6:
				this.ObsGrid = (Grid)target;
				return;
			case 7:
				this.ObsHost = (WindowsFormsHost)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000F10 RID: 3856
		internal static LayoutWindow Instance = null;

		// Token: 0x04000F11 RID: 3857
		public static object mLayoutWindowLock = new object();

		// Token: 0x04000F12 RID: 3858
		private string LAYOUT_HOME_URL = "filters/home/layout/index.html";

		// Token: 0x04000F13 RID: 3859
		private System.Windows.Forms.Panel mOBSRenderFrame = new System.Windows.Forms.Panel();

		// Token: 0x04000F14 RID: 3860
		private string mCurrentLayout;

		// Token: 0x04000F15 RID: 3861
		private bool mIsCurrentAppViewLayout;

		// Token: 0x04000F16 RID: 3862
		private string mCurrentLastCameraLayout;

		// Token: 0x04000F17 RID: 3863
		public object mChangeLayoutLock = new object();

		// Token: 0x04000F18 RID: 3864
		public string mClosingJsonString;

		// Token: 0x04000F19 RID: 3865
		public IntPtr mOBSHandle = IntPtr.Zero;

		// Token: 0x04000F1A RID: 3866
		public BTvBrowserControl mbrowserControl;

		// Token: 0x04000F1B RID: 3867
		public Browser mBrowser;

		// Token: 0x04000F1C RID: 3868
		internal Grid TopBar;

		// Token: 0x04000F1D RID: 3869
		internal CustomPictureBox mCloseButton;

		// Token: 0x04000F1E RID: 3870
		internal Grid BrowserGrid;

		// Token: 0x04000F1F RID: 3871
		internal WindowsFormsHost BrowserHost;

		// Token: 0x04000F20 RID: 3872
		internal Grid ObsGrid;

		// Token: 0x04000F21 RID: 3873
		internal WindowsFormsHost ObsHost;

		// Token: 0x04000F22 RID: 3874
		private bool _contentLoaded;
	}
}
