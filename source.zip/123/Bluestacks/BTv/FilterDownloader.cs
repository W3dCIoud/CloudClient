﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using BlueStacks.Common;
using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000253 RID: 595
	public class FilterDownloader
	{
		// Token: 0x0600144F RID: 5199 RVA: 0x0000E633 File Offset: 0x0000C833
		public FilterDownloader()
		{
			FilterDownloader.Instance = this;
		}

		// Token: 0x06001450 RID: 5200 RVA: 0x0007C674 File Offset: 0x0007A874
		public void IsFilterUpdateAvailable()
		{
			Logger.Info("FilterUpdateUtility: in IsFilterUpdateAvailable");
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(FilterDownloader.sFilterRegPath, true);
			if (registryKey == null)
			{
				RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey(RegistryManager.Instance.ClientBaseKeyPath, true);
				registryKey2.CreateSubKey("Filter");
				registryKey2.Close();
				registryKey = Registry.LocalMachine.OpenSubKey(FilterDownloader.sFilterRegPath, true);
			}
			if (registryKey.GetValue("FilterAvailableForApps", null) == null)
			{
				registryKey.SetValue("FilterAvailableForApps", "[\"com.supercell.clashroyale\", \"com.nianticlabs.pokemongo\"]", RegistryValueKind.String);
			}
			string text = (string)registryKey.GetValue("FilterThemeUrl", null);
			registryKey.Close();
			FilterUtility.sRunFilterDownloaderAgain = false;
			FilterDownloader.FreeMemory();
		}

		// Token: 0x06001451 RID: 5201 RVA: 0x0007C718 File Offset: 0x0007A918
		private void RemoveUninstalledAppsFilterIfThere()
		{
			try
			{
				List<string> installedAppsList = this.GetInstalledAppsList();
				RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(FilterDownloader.sFilterRegPath);
				string json = (string)registryKey.GetValue("FilterAvailableForApps", "[]");
				registryKey.Close();
				JArray jarray = JArray.Parse(json);
				for (int i = 0; i < jarray.Count; i++)
				{
					string text = jarray[i].ToString();
					if (!installedAppsList.Contains(text))
					{
						Logger.Info("FilterUpdateUtility: RemoveFilterAvailableForApp {0}", new object[]
						{
							text
						});
						try
						{
							FilterDownloader.RemoveFilterAvailableForApp(text);
						}
						catch (Exception ex)
						{
							Logger.Error("FilterUpdateUtility: RemoveFilterAvailableForApp {0}", new object[]
							{
								ex.ToString()
							});
						}
					}
				}
			}
			catch (Exception ex2)
			{
				Logger.Error("FilterUpdateUtility: RemoveUninstalledAppsFilterIfThere {0}", new object[]
				{
					ex2.ToString()
				});
			}
		}

		// Token: 0x06001452 RID: 5202 RVA: 0x0007C800 File Offset: 0x0007AA00
		private bool CheckStatus(string status)
		{
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(FilterDownloader.sFilterRegPath, true);
			string text = (string)registryKey.GetValue("UpdateStatus", null);
			registryKey.Close();
			if (text != null)
			{
				Logger.Info("FilterUpdateUtility: CheckStatus value {0}", new object[]
				{
					text
				});
				if (text.Equals(status))
				{
					return true;
				}
			}
			else
			{
				Logger.Info("FilterUpdateUtility: CheckStatus value null");
			}
			return false;
		}

		// Token: 0x06001453 RID: 5203 RVA: 0x0007C864 File Offset: 0x0007AA64
		private static void FreeMemory()
		{
			object sFilterDownloaderLock = FilterUtility.sFilterDownloaderLock;
			lock (sFilterDownloaderLock)
			{
				if (FilterUtility.sRunFilterDownloaderAgain)
				{
					FilterUtility.sRunFilterDownloaderAgain = false;
					FilterDownloader.Instance = null;
					FilterUtility.CheckNewFiltersAvailable();
				}
				else
				{
					FilterDownloader.Instance = null;
				}
			}
		}

		// Token: 0x06001454 RID: 5204 RVA: 0x0007C8B8 File Offset: 0x0007AAB8
		private void StartUpdating(string status)
		{
			Logger.Info("FilterUpdateUtility: in StartUpdating with arg {0}", new object[]
			{
				status
			});
			string defaultConfig = FilterUtility.GetDefaultConfig(this.mFilterThemesCloudPath);
			if (defaultConfig == null)
			{
				FilterDownloader.FreeMemory();
				return;
			}
			try
			{
				this.mCloudJSONData = JToken.Parse(defaultConfig);
			}
			catch (Exception ex)
			{
				Logger.Error("FilterUpdateUtility: {0}", new object[]
				{
					ex.ToString()
				});
				FilterDownloader.FreeMemory();
				return;
			}
			if (status.Equals("Downloading"))
			{
				try
				{
					if (File.Exists(this.mFilterThemesLocalPath))
					{
						string defaultConfig2 = FilterUtility.GetDefaultConfig(this.mFilterThemesLocalPath);
						this.mLocalJSONData = JToken.Parse(defaultConfig2);
						int num = int.Parse(this.mLocalJSONData["version"].ToString());
						int num2 = int.Parse(this.mCloudJSONData["version"].ToString());
						Logger.Info("FilterUpdateUtility: currentFilterVersion: {0}, nextFilterVersion: {1}", new object[]
						{
							num,
							num2
						});
						this.mIsDownloading = true;
					}
					else
					{
						Logger.Info("FilterUpdateUtility: No local filterthemes.js exist");
						this.mIsDownloading = true;
						this.mIsFirstTimeDownload = true;
						this.mIsDownloaded = false;
					}
					goto IL_19A;
				}
				catch (Exception ex2)
				{
					Logger.Error("FilterUpdateUtility: Error in update filtertheme. Error: {0}", new object[]
					{
						ex2.ToString()
					});
					this.SetUpdateStatus("Error");
					FilterDownloader.FreeMemory();
					return;
				}
			}
			if (!status.Equals("Downloaded"))
			{
				FilterDownloader.FreeMemory();
				return;
			}
			if (this.CheckStatus("Extracting"))
			{
				this.mSkipFolderNotAvailable = true;
				this.SetUpdateStatus("Extracting");
			}
			else
			{
				this.SetUpdateStatus("Downloaded");
			}
			this.mIsDownloading = false;
			this.mIsDownloaded = true;
			IL_19A:
			this.mBackgroundWorker = new BackgroundWorker();
			this.mBackgroundWorker.WorkerSupportsCancellation = true;
			this.mBackgroundWorker.WorkerReportsProgress = true;
			this.mBackgroundWorker.DoWork += this.DoWork;
			this.mBackgroundWorker.RunWorkerAsync();
		}

		// Token: 0x06001455 RID: 5205 RVA: 0x0007CAC0 File Offset: 0x0007ACC0
		private void DoWork(object sender, DoWorkEventArgs e)
		{
			BackgroundWorker backgroundWorker = (BackgroundWorker)sender;
			if (!this.mIsDownloading)
			{
				if (this.mIsDownloaded)
				{
					this.CheckAndExtractAllFiles();
				}
				return;
			}
			if (!this.PopulateUpdateCount())
			{
				this.SetUpdateStatus("Error");
				return;
			}
			if (this.mFilterZipInfo.Count == 0)
			{
				Logger.Info("FilterUpdateUtility: Nothing is available for update");
				if (this.mFilterDownloadProgress != null)
				{
					this.SuccessfullyCloseUI();
					return;
				}
				FilterDownloader.FreeMemory();
				return;
			}
			else
			{
				this.SetUpdateStatus("Downloading");
				if (this.DownloadAllUpdates() == 0)
				{
					this.mIsDownloaded = true;
					this.SavePopulateUpdateCount();
					this.SetUpdateStatus("Downloaded");
					this.CheckAndExtractAllFiles();
					return;
				}
				this.SetUpdateStatus("Error");
				return;
			}
		}

		// Token: 0x06001456 RID: 5206 RVA: 0x0007CB68 File Offset: 0x0007AD68
		public void SetUpdateStatus(string status)
		{
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(FilterDownloader.sFilterRegPath, true);
			if (status.Equals("Error") && this.mFilterDownloadProgress != null)
			{
				StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
				{
					MessageBox.Show(LocaleStrings.GetLocalizedString("STRING_DOWNLOAD_ERROR", false));
					this.SuccessfullyCloseUI();
				}), new object[0]);
			}
			string text = (string)registryKey.GetValue("UpdateStatus", null);
			if (status.Equals("PopulateZipError"))
			{
				registryKey.SetValue("UpdateStatus", "Error", RegistryValueKind.String);
			}
			else if (status.Equals("Completed"))
			{
				registryKey.SetValue("UpdateStatus", status, RegistryValueKind.String);
			}
			else if (text == null || (!text.Equals("Downloaded") && !text.Equals("Extracting")))
			{
				registryKey.SetValue("UpdateStatus", status, RegistryValueKind.String);
			}
			registryKey.Close();
			if (status.Equals("Error"))
			{
				FilterDownloader.FreeMemory();
			}
		}

		// Token: 0x06001457 RID: 5207 RVA: 0x0007CC50 File Offset: 0x0007AE50
		public void ExecuteCallBack(bool callBackStatus)
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				if (this.mCallBackFunction != null)
				{
					StreamWindow.Instance.EvaluateJS(this.mCallBackFunction + "('" + callBackStatus.ToString().ToLower() + "');");
				}
				if (this.mReParentOBS)
				{
					StreamWindowUtility.ReParentOBSWindow();
				}
				this.mFilterDownloadProgress = null;
				if (this.mFreeMemoryOnClose)
				{
					FilterDownloader.FreeMemory();
				}
			}), new object[0]);
		}

		// Token: 0x06001458 RID: 5208 RVA: 0x0007CC94 File Offset: 0x0007AE94
		public void CheckAndExtractAllFiles()
		{
			if (StreamManager.Instance != null && StreamManager.Instance.mIsObsRunning)
			{
				if (this.mFilterDownloadProgress == null)
				{
					FilterDownloader.FreeMemory();
					return;
				}
				this.UpdateUI("Downloaded");
				FilterDownloader.sStopBackgroundWorker = true;
				while (FilterDownloader.sStopBackgroundWorker)
				{
					Thread.Sleep(100);
				}
				if (!FilterDownloader.sUpdateLater)
				{
					this.KillOBSAndExtractUpdates();
					return;
				}
			}
			else
			{
				if (this.ExtractAllUpdates() == 0)
				{
					this.FinishUpdate();
					return;
				}
				this.SetUpdateStatus("Error");
			}
		}

		// Token: 0x06001459 RID: 5209 RVA: 0x0007CD0C File Offset: 0x0007AF0C
		public void SavePopulateUpdateCount()
		{
			StringBuilder stringBuilder = new StringBuilder();
			using (JsonWriter jsonWriter = new JsonTextWriter(new StringWriter(stringBuilder)))
			{
				jsonWriter.WriteStartArray();
				foreach (FilterZipInfo filterZipInfo in this.mFilterZipInfo)
				{
					jsonWriter.WriteStartObject();
					jsonWriter.WritePropertyName("version");
					jsonWriter.WriteValue(filterZipInfo.version);
					jsonWriter.WritePropertyName("downloadPath");
					jsonWriter.WriteValue(filterZipInfo.downloadPath);
					jsonWriter.WritePropertyName("url");
					jsonWriter.WriteValue(filterZipInfo.url);
					jsonWriter.WritePropertyName("deleteDir");
					jsonWriter.WriteValue(filterZipInfo.deleteDir);
					jsonWriter.WritePropertyName("deleteDirPath");
					jsonWriter.WriteValue(filterZipInfo.deleteDirPath);
					jsonWriter.WritePropertyName("appPkg");
					jsonWriter.WriteValue(filterZipInfo.appPkg);
					jsonWriter.WriteEndObject();
				}
				jsonWriter.WriteEndArray();
			}
			if (this.mFilterZipInfo.Count > 0)
			{
				RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(FilterDownloader.sFilterRegPath, true);
				registryKey.SetValue("FilterZipList", stringBuilder.ToString(), RegistryValueKind.String);
				registryKey.Close();
			}
		}

		// Token: 0x0600145A RID: 5210 RVA: 0x0007CE60 File Offset: 0x0007B060
		private bool PopulateZipInfoList()
		{
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(FilterDownloader.sFilterRegPath);
			string text = (string)registryKey.GetValue("FilterZipList", null);
			this.mAppsForFilterDownload = new List<string>();
			this.mFilterZipInfo = new List<FilterZipInfo>();
			if (text != null)
			{
				JArray jarray = JArray.Parse(text);
				List<string> installedAppsList = this.GetInstalledAppsList();
				int i = 0;
				while (i < jarray.Count)
				{
					FilterZipInfo filterZipInfo = new FilterZipInfo();
					JObject jobject = JObject.Parse(jarray[i].ToString());
					if (jobject.Property("appPkg") == null)
					{
						goto IL_CD;
					}
					filterZipInfo.appPkg = jobject["appPkg"].ToString();
					if (installedAppsList.Contains(filterZipInfo.appPkg))
					{
						if (!this.mAppsForFilterDownload.Contains(filterZipInfo.appPkg))
						{
							this.mAppsForFilterDownload.Add(filterZipInfo.appPkg);
							goto IL_CD;
						}
						goto IL_CD;
					}
					IL_1D4:
					i++;
					continue;
					IL_CD:
					if (jobject.Property("version") != null)
					{
						filterZipInfo.version = jobject[i]["version"].ToObject<int>();
					}
					if (jobject.Property("downloadPath") != null)
					{
						filterZipInfo.downloadPath = jobject[i]["downloadPath"].ToString();
					}
					if (jobject.Property("url") != null)
					{
						filterZipInfo.url = jobject[i]["url"].ToString();
					}
					if (jobject.Property("deleteDir") != null)
					{
						filterZipInfo.deleteDir = jobject[i]["deleteDir"].ToObject<bool>();
					}
					if (jobject.Property("deleteDirPath") != null)
					{
						filterZipInfo.deleteDirPath = jobject[i]["deleteDirPath"].ToString();
					}
					this.mFilterZipInfo.Add(filterZipInfo);
					goto IL_1D4;
				}
				return true;
			}
			registryKey.Close();
			return false;
		}

		// Token: 0x0600145B RID: 5211 RVA: 0x0007D060 File Offset: 0x0007B260
		private void KillOBSAndExtractUpdates()
		{
			if (StreamManager.Instance != null && StreamManager.Instance.mIsStreaming)
			{
				StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
				{
					if (MessageBox.Show(LocaleStrings.GetLocalizedString("STRING_STOP_STREAMING_REQUIRED", false), LocaleStrings.GetLocalizedString("STRING_FILTER_UPDATE_TITLE", false), MessageBoxButtons.YesNo) == DialogResult.Yes)
					{
						StreamManager.StopOBS();
						this.mCallBackFunction = null;
						this.mReParentOBS = false;
						if (this.ExtractAllUpdates() == 0)
						{
							this.FinishUpdate();
						}
						else
						{
							this.SetUpdateStatus("Error");
						}
						StreamWindowUtility.ReLaunchStreamWindow();
						return;
					}
					this.SuccessfullyCloseUI();
				}), new object[0]);
				return;
			}
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				StreamManager.StopOBS();
				this.mCallBackFunction = null;
				this.mReParentOBS = false;
				if (this.ExtractAllUpdates() == 0)
				{
					this.FinishUpdate();
				}
				else
				{
					this.SetUpdateStatus("Error");
				}
				StreamWindowUtility.ReLaunchStreamWindow();
			}), new object[0]);
		}

		// Token: 0x0600145C RID: 5212 RVA: 0x0007D0C8 File Offset: 0x0007B2C8
		private void FinishUpdate()
		{
			try
			{
				File.Copy(this.mFilterThemesCloudPath, this.mFilterThemesLocalPath, true);
				this.UpdateFilterRegistry();
				this.UpdateAppList();
				this.SetUpdateStatus("Completed");
				FilterUtility.UpdateSupportedPackages();
				foreach (FilterZipInfo filterZipInfo in this.mFilterZipInfo)
				{
					try
					{
						if (filterZipInfo.downloadPath != null)
						{
							File.Delete(filterZipInfo.downloadPath);
						}
					}
					catch (Exception ex)
					{
						Logger.Error("FilterUpdateUtility: Error {0}", new object[]
						{
							ex
						});
					}
				}
			}
			catch (Exception ex2)
			{
				this.SetUpdateStatus("Error");
				Logger.Error("FilterUpdateUtility: Error {0}", new object[]
				{
					ex2.ToString()
				});
				return;
			}
			if (this.mFilterDownloadProgress != null)
			{
				this.SuccessfullyCloseUI();
				return;
			}
			FilterDownloader.FreeMemory();
		}

		// Token: 0x0600145D RID: 5213 RVA: 0x0000E641 File Offset: 0x0000C841
		private void SuccessfullyCloseUI()
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				if (this.mCallBackFunction != null)
				{
					StreamWindow.Instance.EvaluateJS(this.mCallBackFunction + "('true');");
				}
				this.mCallBackFunction = null;
				this.mFreeMemoryOnClose = true;
				this.mFilterDownloadProgress.Close();
			}), new object[0]);
		}

		// Token: 0x0600145E RID: 5214 RVA: 0x0007D1C4 File Offset: 0x0007B3C4
		private void UpdateAppList()
		{
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(FilterDownloader.sFilterRegPath, true);
			List<string> list = new List<string>();
			JArray jarray = JArray.Parse((string)registryKey.GetValue("FilterAvailableForApps", "[]"));
			for (int i = 0; i < jarray.Count; i++)
			{
				if (!list.Contains(jarray[i].ToString()))
				{
					list.Add(jarray[i].ToString());
				}
			}
			foreach (string item in this.mAppsForFilterDownload)
			{
				if (!list.Contains(item))
				{
					list.Add(item);
				}
			}
			if (!list.Contains("com.supercell.clashroyale"))
			{
				list.Add("com.supercell.clashroyale");
			}
			if (!list.Contains("com.nianticlabs.pokemongo"))
			{
				list.Add("com.nianticlabs.pokemongo");
			}
			jarray = this.mCloudJSONData["supported_packages"].ToObject<JArray>();
			registryKey.SetValue("FilterAvailableForApps", jarray.ToString(), RegistryValueKind.String);
			registryKey.Close();
		}

		// Token: 0x0600145F RID: 5215 RVA: 0x0007D2EC File Offset: 0x0007B4EC
		public static void RemoveFilterAvailableForApp(string appPkg)
		{
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(FilterDownloader.sFilterRegPath, true);
			string text = (string)registryKey.GetValue("FilterAvailableForApps", null);
			if (text == null || appPkg.Equals("com.supercell.clashroyale") || appPkg.Equals("com.nianticlabs.pokemongo"))
			{
				return;
			}
			JArray jarray = new JArray();
			bool flag = false;
			if (text.Equals(appPkg))
			{
				jarray.Add(text);
			}
			else
			{
				flag = true;
			}
			registryKey.SetValue("FilterAvailableForApps", jarray.ToString(Formatting.None, new JsonConverter[0]), RegistryValueKind.String);
			if (flag)
			{
				try
				{
					Directory.Delete(FilterUtility.GetFilterDir() + "\\theme\\" + appPkg, true);
				}
				catch (Exception ex)
				{
					Logger.Error("FilterUpdateUtility: {0}", new object[]
					{
						ex.ToString()
					});
				}
				try
				{
					if (Array.IndexOf<string>(registryKey.GetSubKeyNames(), appPkg) > -1)
					{
						registryKey.DeleteSubKey(appPkg);
					}
				}
				catch (Exception ex2)
				{
					Logger.Error("FilterUpdateUtility: {0}", new object[]
					{
						ex2.ToString()
					});
				}
			}
			registryKey.Close();
		}

		// Token: 0x06001460 RID: 5216 RVA: 0x0007D408 File Offset: 0x0007B608
		private List<string> GetInstalledAppsList()
		{
			List<string> list = new List<string>();
			AppInfo[] appList = new JsonParser(Strings.CurrentDefaultVmName).GetAppList();
			for (int i = 0; i < appList.Length; i++)
			{
				if (appList[i] != null && appList[i].package != null)
				{
					list.Add(appList[i].package);
				}
			}
			if (!list.Contains("com.supercell.clashroyale"))
			{
				list.Add("com.supercell.clashroyale");
			}
			if (!list.Contains("com.nianticlabs.pokemongo"))
			{
				list.Add("com.nianticlabs.pokemongo");
			}
			return list;
		}

		// Token: 0x06001461 RID: 5217 RVA: 0x0007D488 File Offset: 0x0007B688
		public void ShowMessageBox(string data)
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				MessageBox.Show(data);
			}), new object[0]);
		}

		// Token: 0x06001462 RID: 5218 RVA: 0x0007D4C4 File Offset: 0x0007B6C4
		private bool PopulateUpdateCount()
		{
			try
			{
				this.mAppsForFilterDownload = new List<string>();
				this.mFilterZipInfo = new List<FilterZipInfo>();
				JObject jobject = JObject.Parse(this.mCloudJSONData["themes"].ToString());
				JObject jobject2 = null;
				if (this.mLocalJSONData != null)
				{
					jobject2 = JObject.Parse(this.mLocalJSONData["themes"].ToString());
				}
				bool flag = false;
				if (this.mIsFirstTimeDownload)
				{
					flag = true;
				}
				else
				{
					int num = this.mCloudJSONData["home"]["version"].ToObject<int>();
					int num2 = this.mLocalJSONData["home"]["version"].ToObject<int>();
					if (num > num2)
					{
						flag = true;
					}
				}
				if (flag)
				{
					FilterZipInfo filterZipInfo = new FilterZipInfo();
					filterZipInfo.version = this.mCloudJSONData["home"]["version"].ToObject<int>();
					filterZipInfo.url = this.mCloudJSONData["home"]["zip_url"].ToString();
					filterZipInfo.downloadPath = string.Concat(new object[]
					{
						FilterUtility.GetFilterDir(),
						"\\",
						this.mCloudJSONData["home"]["dir_name"],
						"_V",
						filterZipInfo.version.ToString(),
						".zip"
					});
					this.mFilterZipInfo.Add(filterZipInfo);
				}
				foreach (string text in this.GetInstalledAppsList())
				{
					Logger.Info("FilterUpdateUtility: installed package {0}", new object[]
					{
						text
					});
					if (jobject.Property(text) != null)
					{
						string path = FilterUtility.GetFilterDir() + "\\theme\\" + text;
						if (!Directory.Exists(path))
						{
							Directory.CreateDirectory(path);
						}
						foreach (JToken value in JArray.Parse(jobject[text].ToString()))
						{
							string text2 = (string)value;
							Logger.Info("FilterUpdateUtility: {0} : {1}", new object[]
							{
								text,
								text2
							});
							flag = false;
							if (this.mIsFirstTimeDownload)
							{
								flag = true;
							}
							else if (jobject2.Property(text) != null && FilterUtility.IsFilterAvailableForThisApp(text))
							{
								int num3 = jobject[text][text2]["version"].ToObject<int>();
								if (jobject2[text][text2] != null)
								{
									int num4 = jobject2[text][text2]["version"].ToObject<int>();
									if (num3 > num4)
									{
										flag = true;
									}
								}
								else
								{
									flag = true;
								}
							}
							else
							{
								flag = true;
							}
							if (flag)
							{
								FilterZipInfo filterZipInfo2 = new FilterZipInfo();
								filterZipInfo2.version = jobject[text][text2]["version"].ToObject<int>();
								filterZipInfo2.appPkg = text;
								string text3 = FilterUtility.GetFilterDir() + "\\theme\\" + text + "\\";
								if (jobject[text][text2]["delete"] != null)
								{
									filterZipInfo2.deleteDir = true;
									filterZipInfo2.deleteDirPath = text3 + jobject[text][text2]["dir_name"];
								}
								else
								{
									filterZipInfo2.url = jobject[text][text2]["zip_url"].ToString();
									filterZipInfo2.downloadPath = string.Concat(new object[]
									{
										text3,
										jobject[text][text2]["dir_name"],
										"_V",
										filterZipInfo2.version.ToString(),
										".zip"
									});
								}
								this.mFilterZipInfo.Add(filterZipInfo2);
								if (!this.mAppsForFilterDownload.Contains(filterZipInfo2.appPkg))
								{
									this.mAppsForFilterDownload.Add(filterZipInfo2.appPkg);
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error(ex.ToString());
				return false;
			}
			return true;
		}

		// Token: 0x06001463 RID: 5219 RVA: 0x0007D948 File Offset: 0x0007BB48
		public void LaunchUI(string callBackFunction)
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				this.mCallBackFunction = callBackFunction;
				if (this.mFilterDownloadProgress != null)
				{
					return;
				}
				this.mFilterDownloadProgress = new FilterDownloadProgress();
				if (this.mIsDownloaded)
				{
					this.UpdateUI("Downloaded");
				}
				this.mFilterDownloadProgress.ShowDialog();
			}), new object[0]);
		}

		// Token: 0x06001464 RID: 5220 RVA: 0x0007D98C File Offset: 0x0007BB8C
		private void UpdateUI(string status)
		{
			if (this.mFilterDownloadProgress != null)
			{
				string text;
				if (status.Equals("Downloading"))
				{
					if (this.mDownloadCount > this.mFilterZipInfo.Count)
					{
						text = LocaleStrings.GetLocalizedString("STRING_DOWNLOADED", false);
					}
					else
					{
						text = string.Format(LocaleStrings.GetLocalizedString("STRING_DOWNLOADING_0_of_1", false), this.mDownloadCount, this.mFilterZipInfo.Count);
					}
				}
				else if (status.Equals("Downloaded"))
				{
					text = LocaleStrings.GetLocalizedString("STRING_DOWNLOADED", false);
					this.mFilterDownloadProgress.EnableButtons();
				}
				else
				{
					text = LocaleStrings.GetLocalizedString("STRING_APPLYING", false);
				}
				this.mFilterDownloadProgress.UpdateProgress(text);
			}
		}

		// Token: 0x06001465 RID: 5221 RVA: 0x0007DA40 File Offset: 0x0007BC40
		private int DownloadAllUpdates()
		{
			int exitCode = 0;
			this.mDownloadCount = 1;
			LegacyDownloader.UpdateProgressCallback <>9__0;
			LegacyDownloader.DownloadCompletedCallback <>9__1;
			LegacyDownloader.ExceptionCallback <>9__2;
			foreach (FilterZipInfo filterZipInfo in this.mFilterZipInfo)
			{
				if (filterZipInfo.deleteDir)
				{
					this.mDownloadCount++;
					this.UpdateUI("Downloading");
				}
				else if (File.Exists(filterZipInfo.downloadPath))
				{
					this.mDownloadCount++;
					this.UpdateUI("Downloading");
				}
				else
				{
					LegacyDownloader legacyDownloader = new LegacyDownloader(1, filterZipInfo.url, filterZipInfo.downloadPath);
					LegacyDownloader.UpdateProgressCallback updateProgressCb;
					if ((updateProgressCb = <>9__0) == null)
					{
						updateProgressCb = (<>9__0 = delegate(int percent)
						{
							this.UpdateUI("Downloading");
							Logger.Info("FilterUpdateUtility: percent: " + percent);
						});
					}
					LegacyDownloader.DownloadCompletedCallback downloadedCb;
					if ((downloadedCb = <>9__1) == null)
					{
						downloadedCb = (<>9__1 = delegate(string file)
						{
							Logger.Info("FilterUpdateUtility: file downloaded to: " + file);
							this.mDownloadCount++;
							this.UpdateUI("Downloading");
						});
					}
					LegacyDownloader.ExceptionCallback exceptionCb;
					if ((exceptionCb = <>9__2) == null)
					{
						exceptionCb = (<>9__2 = delegate(Exception ex)
						{
							Logger.Error("FilterUpdateUtility: {0}", new object[]
							{
								ex.ToString()
							});
							exitCode = -1;
						});
					}
					legacyDownloader.Download(updateProgressCb, downloadedCb, exceptionCb, null, null, null);
				}
			}
			return exitCode;
		}

		// Token: 0x06001466 RID: 5222 RVA: 0x0007DB7C File Offset: 0x0007BD7C
		private int ExtractAllUpdates()
		{
			this.UpdateUI("Extracting");
			this.SetUpdateStatus("Extracting");
			int num = 0;
			if (StreamManager.Instance != null && StreamManager.Instance.mIsObsRunning)
			{
				num = -1;
				Logger.Info("FilterUpdateUtility: Unable to update obs already running");
			}
			else
			{
				foreach (FilterZipInfo filterZipInfo in this.mFilterZipInfo)
				{
					if (filterZipInfo.deleteDir)
					{
						try
						{
							if (Directory.Exists(filterZipInfo.deleteDirPath))
							{
								Directory.Delete(filterZipInfo.deleteDirPath, true);
							}
							continue;
						}
						catch (Exception ex)
						{
							Logger.Error("FilterUpdateUtility: {0}", new object[]
							{
								ex.ToString()
							});
							continue;
						}
					}
					if (!this.mSkipFolderNotAvailable || File.Exists(filterZipInfo.downloadPath))
					{
						string directoryName = Path.GetDirectoryName(filterZipInfo.downloadPath);
						num = MiscUtils.Extract7Zip(filterZipInfo.downloadPath, directoryName);
						if (num != 0)
						{
							break;
						}
					}
				}
			}
			return num;
		}

		// Token: 0x06001467 RID: 5223 RVA: 0x0007DC88 File Offset: 0x0007BE88
		private bool DownloadFilterThemeJson(string cloudThemeURL, string cloudThemeFilePath)
		{
			Logger.Info("FilterUpdateUtility: Downloading file at location {0}", new object[]
			{
				cloudThemeFilePath
			});
			WebClient webClient = new WebClient();
			try
			{
				webClient.DownloadFile(cloudThemeURL, cloudThemeFilePath);
				return true;
			}
			catch (Exception ex)
			{
				Logger.Error("FilterUpdateUtility: Failed to Download file on url. Error: {0}", new object[]
				{
					ex.ToString()
				});
			}
			return false;
		}

		// Token: 0x06001468 RID: 5224 RVA: 0x0007DCEC File Offset: 0x0007BEEC
		public void UpdateFilterRegistry()
		{
			JObject jobject = JObject.Parse(this.mCloudJSONData["themes"].ToString());
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(FilterDownloader.sFilterRegPath, true);
			if (registryKey == null)
			{
				return;
			}
			foreach (string text in registryKey.GetSubKeyNames())
			{
				bool flag = false;
				using (List<string>.Enumerator enumerator = (from p in jobject.Properties()
				select p.Name).ToList<string>().GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						if (enumerator.Current.Equals(text))
						{
							flag = true;
						}
					}
				}
				if (flag)
				{
					Logger.Info("FilterUpdateUtility: updating reg for appPkg {0}", new object[]
					{
						text
					});
					RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey(FilterDownloader.sFilterRegPath + "\\" + text, true);
					if (registryKey2 != null)
					{
						string text2 = (string)registryKey2.GetValue("CurrentTheme", null);
						foreach (string text3 in registryKey2.GetValueNames())
						{
							if (jobject[text][text3] != null)
							{
								foreach (string text4 in (from p in JObject.Parse(jobject[text].ToString()).Properties()
								select p.Name).ToList<string>())
								{
									if (text4.ToLower().Equals(text3.ToLower()))
									{
										FilterThemeConfig filterThemeConfig = new FilterThemeConfig((string)registryKey2.GetValue(text4));
										registryKey2.SetValue(text4, new FilterThemeConfig(jobject[text][text4]["initial_config"].ToString())
										{
											mFilterThemeSettings = 
											{
												mIsWebCamOn = filterThemeConfig.mFilterThemeSettings.mIsWebCamOn,
												mIsChatOn = filterThemeConfig.mFilterThemeSettings.mIsChatOn,
												mIsAnimate = filterThemeConfig.mFilterThemeSettings.mIsAnimate
											}
										}.ToJsonString(), RegistryValueKind.String);
									}
								}
							}
						}
						if (text2 != null && (jobject[text][text2] == null || jobject[text][text2]["delete"] != null))
						{
							registryKey2.DeleteValue("CurrentTheme");
						}
						registryKey2.Close();
					}
				}
				else
				{
					registryKey.DeleteSubKey(text);
				}
			}
			registryKey.Close();
		}

		// Token: 0x04000E25 RID: 3621
		private bool mIsDownloading;

		// Token: 0x04000E26 RID: 3622
		private bool mIsDownloaded;

		// Token: 0x04000E27 RID: 3623
		private bool mFreeMemoryOnClose;

		// Token: 0x04000E28 RID: 3624
		private string mCallBackFunction;

		// Token: 0x04000E29 RID: 3625
		private bool mIsFirstTimeDownload;

		// Token: 0x04000E2A RID: 3626
		private bool mSkipFolderNotAvailable;

		// Token: 0x04000E2B RID: 3627
		public bool mReParentOBS;

		// Token: 0x04000E2C RID: 3628
		private BackgroundWorker mBackgroundWorker;

		// Token: 0x04000E2D RID: 3629
		private JToken mCloudJSONData;

		// Token: 0x04000E2E RID: 3630
		private JToken mLocalJSONData;

		// Token: 0x04000E2F RID: 3631
		private List<FilterZipInfo> mFilterZipInfo;

		// Token: 0x04000E30 RID: 3632
		private List<string> mAppsForFilterDownload;

		// Token: 0x04000E31 RID: 3633
		private int mDownloadCount;

		// Token: 0x04000E32 RID: 3634
		private string mFilterThemesLocalPath;

		// Token: 0x04000E33 RID: 3635
		private string mFilterThemesCloudPath;

		// Token: 0x04000E34 RID: 3636
		private FilterDownloadProgress mFilterDownloadProgress;

		// Token: 0x04000E35 RID: 3637
		public static bool sUpdateLater = false;

		// Token: 0x04000E36 RID: 3638
		public static bool sStopBackgroundWorker = false;

		// Token: 0x04000E37 RID: 3639
		public static FilterDownloader Instance = null;

		// Token: 0x04000E38 RID: 3640
		private static string sFilterRegPath = RegistryManager.Instance.ClientBaseKeyPath + "\\Filter";
	}
}
