﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000281 RID: 641
	public class CustomSlider : Slider, IComponentConnector, IStyleConnector
	{
		// Token: 0x060015EF RID: 5615 RVA: 0x0000F397 File Offset: 0x0000D597
		public CustomSlider()
		{
			this.InitializeComponent();
		}

		// Token: 0x060015F0 RID: 5616 RVA: 0x000856CC File Offset: 0x000838CC
		private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			int num = 96;
			int num2 = 176;
			int num3 = 255;
			Slider slider = (Slider)sender;
			double num5;
			double num6;
			double num7;
			if (base.Value > 50.0)
			{
				double num4 = base.Value - 50.0;
				num5 = (double)num + num4 * 1.1;
				num6 = (double)num2 - num4 * 1.28;
				num7 = (double)num3 - num4 * 0.22;
			}
			else
			{
				double num8 = 50.0 - base.Value;
				num5 = (double)num + num8 * 1.94;
				num6 = (double)num2 + num8 * 0.9;
				num7 = (double)num3 - num8 * 0.12;
			}
			if (this.mBorder != null)
			{
				this.mBorder.BorderBrush = new SolidColorBrush(Color.FromRgb((byte)num5, (byte)num6, (byte)num7));
			}
			if (this.mEllipse != null)
			{
				this.mEllipse.Fill = new SolidColorBrush(Color.FromRgb((byte)num5, (byte)num6, (byte)num7));
			}
		}

		// Token: 0x060015F1 RID: 5617 RVA: 0x0000F3A5 File Offset: 0x0000D5A5
		private void SliderBorder_Initialized(object sender, EventArgs e)
		{
			this.mBorder = (Border)sender;
		}

		// Token: 0x060015F2 RID: 5618 RVA: 0x0000F3B3 File Offset: 0x0000D5B3
		private void Ellipse_Initialized(object sender, EventArgs e)
		{
			this.mEllipse = (Ellipse)sender;
		}

		// Token: 0x060015F3 RID: 5619 RVA: 0x0000F3C1 File Offset: 0x0000D5C1
		private void Slider_Loaded(object sender, RoutedEventArgs e)
		{
			this.Slider_ValueChanged(null, null);
		}

		// Token: 0x060015F4 RID: 5620 RVA: 0x000857D4 File Offset: 0x000839D4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/btv/wpffiles/usercontrol/customslider.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060015F5 RID: 5621 RVA: 0x0000F3CB File Offset: 0x0000D5CB
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				((CustomSlider)target).ValueChanged += this.Slider_ValueChanged;
				((CustomSlider)target).Loaded += this.Slider_Loaded;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x060015F6 RID: 5622 RVA: 0x0000F407 File Offset: 0x0000D607
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 2)
			{
				((Border)target).Initialized += this.SliderBorder_Initialized;
				return;
			}
			if (connectionId != 3)
			{
				return;
			}
			((Ellipse)target).Initialized += this.Ellipse_Initialized;
		}

		// Token: 0x04000F4F RID: 3919
		private Border mBorder;

		// Token: 0x04000F50 RID: 3920
		private Ellipse mEllipse;

		// Token: 0x04000F51 RID: 3921
		private bool _contentLoaded;
	}
}
