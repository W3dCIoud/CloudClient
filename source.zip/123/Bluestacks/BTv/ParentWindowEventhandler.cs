﻿using System;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000278 RID: 632
	// (Invoke) Token: 0x060015A2 RID: 5538
	public delegate void ParentWindowEventhandler(string topic, string data);
}
