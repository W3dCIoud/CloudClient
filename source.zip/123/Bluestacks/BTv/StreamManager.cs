﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000260 RID: 608
	public class StreamManager
	{
		// Token: 0x14000030 RID: 48
		// (add) Token: 0x0600149E RID: 5278 RVA: 0x0007EE70 File Offset: 0x0007D070
		// (remove) Token: 0x0600149F RID: 5279 RVA: 0x0007EEA8 File Offset: 0x0007D0A8
		public event EventHandler<CustomVolumeEventArgs> EventGetSystemVolume;

		// Token: 0x14000031 RID: 49
		// (add) Token: 0x060014A0 RID: 5280 RVA: 0x0007EEE0 File Offset: 0x0007D0E0
		// (remove) Token: 0x060014A1 RID: 5281 RVA: 0x0007EF18 File Offset: 0x0007D118
		public event EventHandler<CustomVolumeEventArgs> EventGetMicVolume;

		// Token: 0x14000032 RID: 50
		// (add) Token: 0x060014A2 RID: 5282 RVA: 0x0007EF50 File Offset: 0x0007D150
		// (remove) Token: 0x060014A3 RID: 5283 RVA: 0x0007EF88 File Offset: 0x0007D188
		public event EventHandler<CustomVolumeEventArgs> EventGetCameraDetails;

		// Token: 0x14000033 RID: 51
		// (add) Token: 0x060014A4 RID: 5284 RVA: 0x0007EFC0 File Offset: 0x0007D1C0
		// (remove) Token: 0x060014A5 RID: 5285 RVA: 0x0007EFF8 File Offset: 0x0007D1F8
		public event EventHandler<CustomVolumeEventArgs> EventGetMicDetails;

		// Token: 0x060014A6 RID: 5286 RVA: 0x0007F030 File Offset: 0x0007D230
		public StreamManager(Browser browser)
		{
			StreamManager.Instance = this;
			this.mBrowser = browser;
			this.mReplayBufferEnabled = (RegistryManager.Instance.ReplayBufferEnabled == 1);
			if (RegistryManager.Instance.CamStatus == 1)
			{
				StreamManager.mCamStatus = "true";
			}
			else
			{
				StreamManager.mCamStatus = "false";
			}
			StreamManager.mSelectedCamera = RegistryManager.Instance.SelectedCam;
			this.mObsCommandEventHandle = new EventWaitHandle(false, EventResetMode.AutoReset);
			MainWindow mainWindow = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				mainWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			this.mWindow = mainWindow;
			this.CopySceneConfigFile(this.mWindow, false);
		}

		// Token: 0x060014A7 RID: 5287 RVA: 0x0007F17C File Offset: 0x0007D37C
		public StreamManager(MainWindow window)
		{
			StreamManager.Instance = this;
			this.mReplayBufferEnabled = true;
			if (RegistryManager.Instance.CamStatus == 1)
			{
				StreamManager.mCamStatus = "true";
			}
			else
			{
				StreamManager.mCamStatus = "false";
			}
			StreamManager.mSelectedCamera = RegistryManager.Instance.SelectedCam;
			this.mObsCommandEventHandle = new EventWaitHandle(false, EventResetMode.AutoReset);
			this.mWindow = window;
			this.CopySceneConfigFile(this.mWindow, !RegistryManager.Instance.IsGameCaptureSupportedInMachine);
		}

		// Token: 0x060014A8 RID: 5288 RVA: 0x0007F2A0 File Offset: 0x0007D4A0
		public void CopySceneConfigFile(MainWindow activatedWindow, bool forceWindowCaptureMode = false)
		{
			Logger.Debug("In Scene config file copy method with glmode: {0}", new object[]
			{
				activatedWindow.EngineInstanceRegistry.GlRenderMode
			});
			string path = Path.Combine(RegistryStrings.ObsDir, "sceneCollection");
			try
			{
				if (!Directory.Exists(path))
				{
					Directory.CreateDirectory(path);
				}
				if (activatedWindow.EngineInstanceRegistry.GlRenderMode != 1 || forceWindowCaptureMode)
				{
					string sourceFileName = Path.Combine(RegistryStrings.ObsDir, "SceneConfigFiles\\scenes_window.xconfig");
					string destFileName = Path.Combine(RegistryStrings.ObsDir, "scenes.xconfig");
					string destFileName2 = Path.Combine(RegistryStrings.ObsDir, "sceneCollection\\scenes.xconfig");
					File.Copy(sourceFileName, destFileName, true);
					File.Copy(sourceFileName, destFileName2, true);
					this.isWindowCaptureActive = true;
				}
				else
				{
					string sourceFileName2 = Path.Combine(RegistryStrings.ObsDir, "SceneConfigFiles\\scenes_graphics.xconfig");
					string destFileName3 = Path.Combine(RegistryStrings.ObsDir, "scenes.xconfig");
					string destFileName4 = Path.Combine(RegistryStrings.ObsDir, "sceneCollection\\scenes.xconfig");
					File.Copy(sourceFileName2, destFileName3, true);
					File.Copy(sourceFileName2, destFileName4, true);
					this.isWindowCaptureActive = false;
				}
				Logger.Debug("Is window capture active..: {0}", new object[]
				{
					this.isWindowCaptureActive
				});
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in obs scene config file : {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x060014A9 RID: 5289 RVA: 0x0007F3DC File Offset: 0x0007D5DC
		internal void OrientationChangeHandler()
		{
			try
			{
				if (this.isWindowCaptureActive)
				{
					this.SetCaptureSize();
				}
				this.RefreshCapture();
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in OrientationChangeHandler : " + ex.ToString());
			}
		}

		// Token: 0x060014AA RID: 5290 RVA: 0x0000E866 File Offset: 0x0000CA66
		private void RefreshCapture()
		{
			this.SendObsRequest("refreshCapture", null, null, null, 0, false);
		}

		// Token: 0x060014AB RID: 5291 RVA: 0x0007F428 File Offset: 0x0007D628
		private void Tab_Changed(object sender, EventArgs e)
		{
			try
			{
				string currentAppPkg = FilterUtility.GetCurrentAppPkg();
				if (currentAppPkg != null && this.mEnableFilter && FilterUtility.IsFilterApplicableApp(currentAppPkg))
				{
					string currentTheme = FilterUtility.GetCurrentTheme(currentAppPkg);
					this.InitCLRBrowser(currentAppPkg, currentTheme, this.isWindowCaptureActive);
				}
				else
				{
					this.ResetCLRBrowser(this.isWindowCaptureActive);
				}
				if (this.mLayoutTheme != null)
				{
					this.SetSceneConfiguration(this.mLayoutTheme);
				}
				this.SendCurrentAppInfoAtTabChange();
				if (this.isWindowCaptureActive)
				{
					this.SetCaptureSize();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in btv tab changed event : " + ex.ToString());
			}
		}

		// Token: 0x060014AC RID: 5292 RVA: 0x0007F4C4 File Offset: 0x0007D6C4
		public void SendCurrentAppInfoAtTabChange()
		{
			try
			{
				if (this.mBrowser != null)
				{
					if (!string.IsNullOrEmpty(this.mBrowser.getURL()))
					{
						AppTabButton selectedTab = this.mWindow.mTopBar.mAppTabButtons.SelectedTab;
						if (selectedTab != null)
						{
							selectedTab.mTabType.ToString();
							string appName = selectedTab.AppName;
							string packageName = selectedTab.PackageName;
							string text = new JObject
							{
								{
									"type",
									"app"
								},
								{
									"name",
									appName
								},
								{
									"data",
									packageName
								}
							}.ToString(Formatting.None, new JsonConverter[0]);
							string text2 = "getCurrentAppInfo('" + text.Replace("'", "&#39;").Replace("%27", "&#39;") + "')";
							this.mBrowser.ExecuteJavaScript(text2, this.mBrowser.getURL(), 0);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in send current app status on tab changed " + ex.ToString());
			}
		}

		// Token: 0x060014AD RID: 5293 RVA: 0x0000E878 File Offset: 0x0000CA78
		public void StartObs()
		{
			if (!this.mIsInitCalled)
			{
				this.InitObs();
			}
		}

		// Token: 0x060014AE RID: 5294 RVA: 0x0007F5F4 File Offset: 0x0007D7F4
		private void InitObs()
		{
			this.mIsInitCalled = true;
			ProcessUtils.KillProcessByName("HD-OBS");
			if (!ProcessUtils.FindProcessByName("HD-OBS") && !StreamManager.sStopInitOBSQueue)
			{
				this.StartOBS();
			}
			if (StreamManager.sStopInitOBSQueue)
			{
				return;
			}
			try
			{
				string text = this.SendObsRequestInternal("ping", null);
				Logger.Info("response for ping is {0}", new object[]
				{
					text
				});
				this.mIsObsRunning = true;
			}
			catch (Exception ex)
			{
				if (StreamManager.sStopInitOBSQueue || StreamManager.Instance == null)
				{
					return;
				}
				Logger.Error("Exception in InitObs. err: " + ex.ToString());
				Thread.Sleep(100);
				if (this.mObsRetryCount <= 0)
				{
					this.ShutDownForcefully();
					throw new Exception("Could not start OBS.");
				}
				this.mObsRetryCount--;
				this.InitObs();
			}
			this.mObsRetryCount = 2;
			new Thread(delegate()
			{
				this.ProcessObsCommandQueue();
			})
			{
				IsBackground = true
			}.Start();
			if (this.mReplayBufferEnabled)
			{
				this.SetReplayBufferSavePath();
			}
			this.GetParametersFromOBS();
			this.EnableSource("BlueStacks");
		}

		// Token: 0x060014AF RID: 5295 RVA: 0x0007F714 File Offset: 0x0007D914
		private void SetBackGroundImagePath()
		{
			this.EnableSource("BackGroundImage");
			string value = Path.Combine(RegistryStrings.ObsDir, "backgrounds\\Background3.jpg");
			this.SendObsRequest("setBackground", new Dictionary<string, string>
			{
				{
					"path",
					value
				}
			}, null, null, 0);
		}

		// Token: 0x060014B0 RID: 5296 RVA: 0x0007F760 File Offset: 0x0007D960
		public void SetSceneConfiguration(string layoutTheme)
		{
			this.mAppViewLayout = false;
			this.mLayoutTheme = layoutTheme;
			if (layoutTheme == null)
			{
				this.SendObsRequest("resettooriginalscene", null, null, null, 0, false);
				return;
			}
			FilterUtility.UpdateLayout("LayoutTheme", layoutTheme, false);
			FilterUtility.UpdateAppViewLayoutRegistry(this.mAppViewLayout);
			this.SetCaptureSize();
			this.DisableSource("CLR Browser");
			try
			{
				JObject jobject = JObject.Parse(layoutTheme);
				Logger.Info(layoutTheme);
				bool flag = this.IsPortraitApp();
				if (jobject.Property("isPortrait") != null)
				{
					flag = jobject["isPortrait"].ToObject<bool>();
				}
				JObject jobject2;
				if (flag)
				{
					jobject2 = JObject.Parse(jobject["portrait"].ToString());
				}
				else
				{
					jobject2 = JObject.Parse(jobject["landscape"].ToString());
				}
				if (jobject2.Property("BlueStacksWebcam") != null)
				{
					bool flag2 = Convert.ToBoolean(jobject2["BlueStacksWebcam"]["enableWebCam"].ToString());
					if (flag2)
					{
						this.SetCameraPosition(Convert.ToInt32(jobject2["BlueStacksWebcam"]["x"].ToString()), Convert.ToInt32(jobject2["BlueStacksWebcam"]["y"].ToString()), Convert.ToInt32(jobject2["BlueStacksWebcam"]["width"].ToString()), Convert.ToInt32(jobject2["BlueStacksWebcam"]["height"].ToString()), flag2 ? 1 : 0);
					}
					else
					{
						this.DisableWebcamAndClearDictionary();
					}
				}
				if (jobject2.Property("BlueStacks") != null)
				{
					string value = jobject2["BlueStacks"]["width"].ToString();
					string text = jobject2["BlueStacks"]["height"].ToString();
					string value2 = jobject2["BlueStacks"]["x"].ToString();
					string value3 = jobject2["BlueStacks"]["y"].ToString();
					if (!this.isWindowCaptureActive)
					{
						value = text;
						if (jobject.Property("name") != null)
						{
							string text2 = jobject["name"].ToString();
							if (text2.Equals("layout_2") || text2.Equals("layout_3"))
							{
								value2 = "22";
								if (flag && text2.Equals("layout_3"))
								{
									value2 = "0";
								}
							}
							else if (text2.Equals("layout_1"))
							{
								value2 = "47";
							}
						}
					}
					this.SetFrontendPosition(0, 0, Convert.ToInt32(value), Convert.ToInt32(text));
					this.SetPosition(Convert.ToInt32(value2), Convert.ToInt32(value3));
					this.EnableSource("BlueStacks");
				}
				else
				{
					this.DisableSource("BlueStacks");
				}
				string text3 = jobject["order"].ToString();
				string value4 = jobject["logo"].ToString();
				text3 += ",BackGroundImage";
				string value5 = "watermarkFB,watermark,watermarkGif";
				if (jobject.Property("allLogo") != null)
				{
					value5 = jobject["allLogo"].ToString();
				}
				this.SendObsRequest("setorderandlogo", new Dictionary<string, string>
				{
					{
						"order",
						text3
					},
					{
						"logo",
						value4
					},
					{
						"allLogo",
						value5
					}
				}, null, null, 0, false);
			}
			catch (Exception ex)
			{
				Logger.Error("SetSceneConfiguration: Error {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x060014B1 RID: 5297 RVA: 0x0007FAF4 File Offset: 0x0007DCF4
		public bool IsPortraitApp()
		{
			int frontendWidth = RegistryManager.Instance.FrontendWidth;
			int frontendHeight = RegistryManager.Instance.FrontendHeight;
			return frontendWidth <= frontendHeight;
		}

		// Token: 0x060014B2 RID: 5298 RVA: 0x0007FB1C File Offset: 0x0007DD1C
		private void StartOBS()
		{
			Logger.Info("starting obs");
			string obsBinaryPath = RegistryStrings.ObsBinaryPath;
			string text = "-port " + RegistryManager.Instance.PartnerServerPort;
			if (SystemUtils.IsOs64Bit())
			{
				text += " -64bit";
			}
			if (!string.IsNullOrEmpty(Strings.OEMTag))
			{
				text = text + " -oem " + Strings.OEMTag;
			}
			ProcessUtils.GetProcessObject(obsBinaryPath, text, false).Start();
			Logger.Info("OBS started");
			StreamManager.sObsServerPort = RegistryManager.Instance.OBSServerPort;
		}

		// Token: 0x060014B3 RID: 5299 RVA: 0x0007FBA8 File Offset: 0x0007DDA8
		public void SetHwnd(string handle)
		{
			this.SendObsRequest("sethwnd", new Dictionary<string, string>
			{
				{
					"hwnd",
					handle
				}
			}, null, null, 0, false);
		}

		// Token: 0x060014B4 RID: 5300 RVA: 0x0007FBD8 File Offset: 0x0007DDD8
		public void SetSavePath(string path = null)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			string value = path ?? Path.Combine(RegistryStrings.BtvDir, "stream.flv");
			this.mLastVideoFilePath = value;
			dictionary.Add("savepath", value);
			this.SendObsRequest("setsavepath", dictionary, null, "SetSaveFailed", 0, false);
		}

		// Token: 0x060014B5 RID: 5301 RVA: 0x0000E888 File Offset: 0x0000CA88
		private void SetSaveFailed()
		{
			Logger.Error("Exception in SetSaveFailed");
		}

		// Token: 0x060014B6 RID: 5302 RVA: 0x0007FC28 File Offset: 0x0007DE28
		private void SetReplayBufferSavePath()
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			string value = Path.Combine(RegistryStrings.BtvDir, "replay.flv");
			dictionary.Add("savepath", value);
			this.SendObsRequest("setreplaybuffersavepath", dictionary, null, null, 0, false);
		}

		// Token: 0x060014B7 RID: 5303 RVA: 0x0007FC68 File Offset: 0x0007DE68
		public void SetStreamDimension(out int startX, out int startY, out int width, out int height)
		{
			try
			{
				BTVManager.Instance.GetStreamDimensionInfo(out startX, out startY, out width, out height);
			}
			catch (Exception ex)
			{
				Logger.Error("Got Exception in getting stream dimension... Err : " + ex.ToString());
				startX = (startY = (width = (height = 0)));
			}
		}

		// Token: 0x060014B8 RID: 5304 RVA: 0x0007FCC4 File Offset: 0x0007DEC4
		public void SetFrontendPosition()
		{
			int startX;
			int startY;
			int width;
			int num;
			this.SetStreamDimension(out startX, out startY, out width, out num);
			int @int = Utils.GetInt(RegistryManager.Instance.FrontendHeight, num);
			int frontendWidth;
			if (this.isWindowCaptureActive)
			{
				frontendWidth = RegistryManager.Instance.FrontendWidth;
			}
			else
			{
				frontendWidth = (int)this.GetWidthFromHeight((double)@int);
			}
			this.SetFrontendPosition(frontendWidth, @int, startX, startY, width, num);
		}

		// Token: 0x060014B9 RID: 5305 RVA: 0x0007FD24 File Offset: 0x0007DF24
		public void SetFrontendPosition(int frontendWidth, int frontendHeight)
		{
			int startX;
			int startY;
			int width;
			int height;
			this.SetStreamDimension(out startX, out startY, out width, out height);
			this.SetFrontendPosition(frontendWidth, frontendHeight, startX, startY, width, height);
		}

		// Token: 0x060014BA RID: 5306 RVA: 0x0007FD4C File Offset: 0x0007DF4C
		public void SetFrontendPosition(int frontendWidth, int frontendHeight, int startX, int startY, int width, int height)
		{
			startY += (height - frontendHeight) / 2;
			startX += (width - frontendWidth) / 2;
			if (this.mEnableFilter && FilterUtility.IsFilterApplicableApp())
			{
				int num = frontendWidth * 100 / (frontendHeight * 16 / 9);
				int startX2 = (100 - num) / 2;
				this.SetFrontendPosition(startX2, 0, num, 100);
				this.SetPosition(startX2, 0);
			}
			else
			{
				this.SetFrontendPosition(0, 0, 100, 100);
				if (!this.mSquareTheme)
				{
					this.SetPosition(0, 0);
				}
			}
			this.SetCaptureSize(startX, startY, frontendWidth, frontendHeight);
		}

		// Token: 0x060014BB RID: 5307 RVA: 0x0007FDD0 File Offset: 0x0007DFD0
		public void SetFrontendPosition(int startX, int startY, int width, int height)
		{
			this.SendObsRequest("setsourceposition", new Dictionary<string, string>
			{
				{
					"width",
					width.ToString()
				},
				{
					"height",
					height.ToString()
				},
				{
					"y",
					startY.ToString()
				},
				{
					"x",
					startX.ToString()
				},
				{
					"source",
					"BlueStacks"
				}
			}, null, null, 0, false);
		}

		// Token: 0x060014BC RID: 5308 RVA: 0x0007FE4C File Offset: 0x0007E04C
		public void SetPosition(int startX, int startY)
		{
			this.SendObsRequest("setposition", new Dictionary<string, string>
			{
				{
					"y",
					startY.ToString()
				},
				{
					"x",
					startX.ToString()
				},
				{
					"source",
					"BlueStacks"
				}
			}, null, null, 0, false);
		}

		// Token: 0x060014BD RID: 5309 RVA: 0x0007FEA4 File Offset: 0x0007E0A4
		public void SetFrontEndCaptureSize(int width, int height)
		{
			this.SendObsRequest("SetFrontendCaptureSize", new Dictionary<string, string>
			{
				{
					"width",
					width.ToString()
				},
				{
					"height",
					height.ToString()
				},
				{
					"source",
					"BlueStacks"
				}
			}, null, null, 0, false);
		}

		// Token: 0x060014BE RID: 5310 RVA: 0x0007FEFC File Offset: 0x0007E0FC
		public void SetCaptureSize()
		{
			int num;
			int num2;
			int num3;
			int num4;
			this.SetStreamDimension(out num, out num2, out num3, out num4);
			int @int = Utils.GetInt(RegistryManager.Instance.FrontendHeight, num4);
			num2 += (num4 - @int) / 2;
			int num5;
			if (this.isWindowCaptureActive)
			{
				num5 = RegistryManager.Instance.FrontendWidth;
			}
			else
			{
				num5 = (int)this.GetWidthFromHeight((double)@int);
			}
			num += (num3 - num5) / 2;
			Logger.Info("frontendWidth for set capture size : " + num5);
			Logger.Info("frontendHeight for set capture size : " + @int);
			this.SetCaptureSize(num, num2, num5, @int);
		}

		// Token: 0x060014BF RID: 5311 RVA: 0x0007FF98 File Offset: 0x0007E198
		private void SetCaptureSize(int startX, int startY, int width, int height)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			Logger.Info("width for set capture size : " + width);
			Logger.Info("height for set capture size : " + height);
			dictionary.Add("width", width.ToString());
			dictionary.Add("height", height.ToString());
			dictionary.Add("x", startX.ToString());
			dictionary.Add("y", startY.ToString());
			dictionary.Add("source", "BlueStacks");
			this.SendObsRequest("setcapturesize", dictionary, null, null, 0);
			if (this.isWindowCaptureActive)
			{
				this.SetFrontEndCaptureSize(RegistryManager.Instance.FrontendWidth, RegistryManager.Instance.FrontendHeight);
				if (this.IsPortraitApp())
				{
					this.SetPosition(35, 0);
					return;
				}
				this.SetPosition(0, 0);
			}
		}

		// Token: 0x060014C0 RID: 5312 RVA: 0x0008007C File Offset: 0x0007E27C
		public void ResetCLRBrowser(bool isSetFrontEndPosition = true)
		{
			this.DisableSource("CLR Browser");
			if (isSetFrontEndPosition)
			{
				this.SetFrontendPosition();
			}
			if (string.Compare(StreamManager.mCamStatus, "true", true) == 0)
			{
				this.EnableWebcamInternal("320", "240", "3");
			}
			else
			{
				this.DisableWebcamAndClearDictionary();
			}
			this.mCLRBrowserRunning = false;
			this.mCurrentFilterAppPkg = null;
		}

		// Token: 0x060014C1 RID: 5313 RVA: 0x000800DC File Offset: 0x0007E2DC
		public void InitCLRBrowser(string appPkg, string currentTheme, bool isSetFrontEndPosition = true)
		{
			this.mCurrentFilterAppPkg = appPkg;
			string channelName = RegistryManager.Instance.ChannelName;
			string text = "channel=" + channelName + "&client_id=" + FilterUtility.ClientId;
			this.mCLRBrowserRunning = true;
			FilterUtility.SetCurrentTheme(appPkg, currentTheme);
			text = text + "&" + FilterUtility.GetQueryStringForTheme(appPkg, currentTheme);
			string text2 = string.Concat(new string[]
			{
				BtvApp.sApplicationBaseUrl,
				"filters/theme/",
				appPkg,
				"/",
				currentTheme,
				"/index.html?",
				text
			});
			if (BTVManager.sNetwork.Equals("facebook"))
			{
				text2 += "&isFacebook=true";
			}
			FilterThemeConfig filterThemeConfig = FilterUtility.GetFilterThemeConfig(appPkg, currentTheme);
			if (string.Compare(StreamManager.mCamStatus, "true", true) == 0)
			{
				this.SetAndEnableWebCamPosition(filterThemeConfig);
			}
			else
			{
				filterThemeConfig.mFilterThemeSettings.mIsWebCamOn = false;
				this.DisableWebcamAndClearDictionary();
			}
			this.SendObsRequest("setclrbrowserconfig", new Dictionary<string, string>
			{
				{
					"width",
					this.mStreamWidth.ToString()
				},
				{
					"height",
					this.mStreamHeight.ToString()
				},
				{
					"url",
					text2
				}
			}, null, null, 0, false);
			Thread.Sleep(200);
			this.EnableSource("CLR Browser");
			if (isSetFrontEndPosition)
			{
				this.SetFrontendPosition();
			}
		}

		// Token: 0x060014C2 RID: 5314 RVA: 0x00080230 File Offset: 0x0007E430
		internal void EnableVideoRecording(bool enable)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			if (enable)
			{
				dictionary.Add("Enable", "1");
			}
			else
			{
				dictionary.Add("Enable", "0");
			}
			this.SendObsRequest("EnableVideoRecording", dictionary, null, null, 0);
		}

		// Token: 0x060014C3 RID: 5315 RVA: 0x00080278 File Offset: 0x0007E478
		public FilterThemeConfig ChangeTheme(string appPkg, string theme)
		{
			if (!this.mCLRBrowserRunning)
			{
				return null;
			}
			this.mCurrentFilterAppPkg = appPkg;
			string channelName = RegistryManager.Instance.ChannelName;
			string text = string.Concat(new string[]
			{
				"channel=",
				channelName,
				"&client_id=",
				FilterUtility.ClientId,
				"&"
			});
			text += FilterUtility.GetQueryStringForTheme(appPkg, theme);
			FilterUtility.SetCurrentTheme(appPkg, theme);
			FilterThemeConfig filterThemeConfig = FilterUtility.GetFilterThemeConfig(appPkg, theme);
			if (filterThemeConfig.mFilterThemeSettings.mIsWebCamOn)
			{
				this.SetAndEnableWebCamPosition(filterThemeConfig);
			}
			else
			{
				this.DisableWebcamV2("{}");
			}
			FilterUtility.SendRequestToCLRBrowser("changetheme", new Dictionary<string, string>
			{
				{
					"queryParam",
					text
				},
				{
					"theme",
					theme
				},
				{
					"appPkg",
					appPkg
				}
			});
			return filterThemeConfig;
		}

		// Token: 0x060014C4 RID: 5316 RVA: 0x00080348 File Offset: 0x0007E548
		public void SetAndEnableWebCamPosition(FilterThemeConfig filterThemeConfig)
		{
			int width = 32000 / this.mStreamWidth;
			int num = 24000 / this.mStreamHeight;
			int x = 0;
			int y = 100 - num;
			filterThemeConfig.mFilterThemeSettings.mIsWebCamOn = true;
			if (filterThemeConfig.mFilterThemeCameraSettings.width != 0 && filterThemeConfig.mFilterThemeCameraSettings.height != 0)
			{
				width = filterThemeConfig.mFilterThemeCameraSettings.width;
				num = filterThemeConfig.mFilterThemeCameraSettings.height;
				x = filterThemeConfig.mFilterThemeCameraSettings.x;
				y = filterThemeConfig.mFilterThemeCameraSettings.y;
			}
			this.SetCameraPosition(x, y, width, num, 1);
		}

		// Token: 0x060014C5 RID: 5317 RVA: 0x000803D8 File Offset: 0x0007E5D8
		private void SetCameraPosition(int x, int y, int width, int height, int render)
		{
			Logger.Info(string.Concat(new object[]
			{
				"camera position width is : ",
				width,
				" and height is :",
				height
			}));
			StreamManager.mIsWebcamDisabled = false;
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary.Add("source", "BlueStacksWebcam");
			dictionary.Add("width", width.ToString());
			dictionary.Add("height", height.ToString());
			dictionary.Add("x", x.ToString());
			dictionary.Add("y", y.ToString());
			dictionary.Add("render", render.ToString());
			if (StreamManager.mDictCameraDetails.ContainsKey(StreamManager.mSelectedCamera))
			{
				dictionary.Add("camera", StreamManager.mDictCameraDetails[StreamManager.mSelectedCamera]);
			}
			else
			{
				dictionary["camera"] = string.Empty;
			}
			StreamManager.mDictLastCameraPosition = dictionary;
			this.SendObsRequest("setcameraposition", dictionary, "WebcamConfigured", null, 0, false);
		}

		// Token: 0x060014C6 RID: 5318 RVA: 0x000804E8 File Offset: 0x0007E6E8
		internal void UpdateCameraPosition(string camName)
		{
			this.DisableWebcam();
			if (!string.IsNullOrEmpty(camName))
			{
				StreamManager.mSelectedCamera = camName;
			}
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["source"] = "BlueStacksWebcam";
			dictionary["width"] = "100";
			dictionary["height"] = "100";
			dictionary["x"] = "0";
			dictionary["y"] = "0";
			dictionary["render"] = "1";
			if (StreamManager.mDictCameraDetails.ContainsKey(StreamManager.mSelectedCamera))
			{
				dictionary["camera"] = StreamManager.mDictCameraDetails[StreamManager.mSelectedCamera];
			}
			else
			{
				dictionary["camera"] = string.Empty;
			}
			this.SendObsRequest("setcameraposition", dictionary, "WebcamConfigured", null, 0, false);
		}

		// Token: 0x060014C7 RID: 5319 RVA: 0x000805C0 File Offset: 0x0007E7C0
		internal void ChangeCamera()
		{
			this.DisableWebcam();
			if (!StreamManager.mIsWebcamDisabled)
			{
				if (StreamManager.mDictLastCameraPosition.Count == 0)
				{
					StreamManager.mDictLastCameraPosition["source"] = "BlueStacksWebcam";
					StreamManager.mDictLastCameraPosition["width"] = "17";
					StreamManager.mDictLastCameraPosition["height"] = "23";
					StreamManager.mDictLastCameraPosition["x"] = "0";
					StreamManager.mDictLastCameraPosition["y"] = "77";
					StreamManager.mDictLastCameraPosition["render"] = "1";
				}
				if (StreamManager.mDictCameraDetails.ContainsKey(StreamManager.mSelectedCamera))
				{
					StreamManager.mDictLastCameraPosition["camera"] = StreamManager.mDictCameraDetails[StreamManager.mSelectedCamera];
				}
				else
				{
					StreamManager.mDictLastCameraPosition["camera"] = string.Empty;
				}
				this.SendObsRequest("setcameraposition", StreamManager.mDictLastCameraPosition, "WebcamConfigured", null, 0, false);
			}
		}

		// Token: 0x060014C8 RID: 5320 RVA: 0x000806C0 File Offset: 0x0007E8C0
		public void SetClrBrowserConfig(string width, string height, string url)
		{
			this.SendObsRequest("setclrbrowserconfig", new Dictionary<string, string>
			{
				{
					"width",
					width
				},
				{
					"height",
					height
				},
				{
					"url",
					url
				}
			}, null, null, 0);
		}

		// Token: 0x060014C9 RID: 5321 RVA: 0x0000E894 File Offset: 0x0000CA94
		public void ObsErrorStatus(string erroReason)
		{
			this.mIsStreaming = false;
			this.mFailureReason = "Error starting stream : " + erroReason;
			this.SendStreamStatus(false, false);
		}

		// Token: 0x060014CA RID: 5322 RVA: 0x00080708 File Offset: 0x0007E908
		public void ReportObsError(string errorReason)
		{
			try
			{
				Logger.Info("error reason in obs :" + errorReason);
				string text = "stream_interrupted_error";
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				if (errorReason.Equals("ConnectionSuccessfull"))
				{
					if (!this.mIsStreamStarted)
					{
						this.mIsStreamStarted = true;
						text = "obs_connected";
					}
					else
					{
						text = "stream_resumed";
					}
				}
				else if (!this.mIsStreamStarted)
				{
					text = "went_live_error";
				}
				if (errorReason.Equals("OBSAlreadyRunning"))
				{
					text = "obs_already_running";
					this.ReportStreamStatsToCloud(text, errorReason);
					dictionary.Add("reason", text);
					StreamManager.ReportObsErrorHandler(text);
				}
				else if (errorReason.Equals("capture_error"))
				{
					text = "capture_error";
					this.ReportStreamStatsToCloud(text, errorReason);
					StreamManager.sStopInitOBSQueue = true;
					dictionary.Add("reason", text);
					StreamManager.ReportObsErrorHandler(text);
				}
				else if (errorReason.Equals("opengl_capture_error"))
				{
					text = "opengl_capture_error";
					this.ReportStreamStatsToCloud(text, errorReason);
					StreamManager.sStopInitOBSQueue = true;
					dictionary.Add("reason", text);
					StreamManager.ReportObsErrorHandler(text);
				}
				else if (errorReason.StartsWith("AccessDenied") || errorReason.StartsWith("ConnectServerError") || errorReason.Equals("obs_error"))
				{
					errorReason = "Error starting stream : " + errorReason;
					this.ReportStreamStatsToCloud(text, errorReason);
					dictionary.Add("reason", "obs_error");
					StreamManager.ReportObsErrorHandler("obs_error");
				}
				else if (errorReason.Equals("ConnectionSuccessfull"))
				{
					this.ReportStreamStatsToCloud(text, errorReason);
				}
				else
				{
					errorReason = "Error starting stream : " + errorReason;
					this.ReportStreamStatsToCloud(text, errorReason);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to report obs error.. Err : " + ex.ToString());
			}
		}

		// Token: 0x060014CB RID: 5323 RVA: 0x000808C8 File Offset: 0x0007EAC8
		public void RestartOBSInWindowCaptureMode()
		{
			try
			{
				this.ShutDownForcefully();
				this.CopySceneConfigFile(this.mWindow, true);
				Logger.Info("restarting obs in window capture mode");
				if (File.Exists(this.mLastVideoFilePath))
				{
					File.Delete(this.mLastVideoFilePath);
				}
				this.mWindow.mCommonHandler.RecordVideoOfApp();
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in restart obs in window capture mode: {0}", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x060014CC RID: 5324 RVA: 0x00080948 File Offset: 0x0007EB48
		private static void ReportObsErrorHandler(string reason)
		{
			Logger.Error("Obs reported an error. " + reason);
			if (string.Equals(reason, "opengl_capture_error", StringComparison.OrdinalIgnoreCase))
			{
				RegistryManager.Instance.IsGameCaptureSupportedInMachine = false;
				StreamManager.Instance.RestartOBSInWindowCaptureMode();
				return;
			}
			StreamManager instance = StreamManager.Instance;
			if (instance == null)
			{
				return;
			}
			instance.mWindow.Dispatcher.Invoke(new Action(delegate()
			{
				StreamManager.Instance.mWindow.mCommonHandler.ShowErrorRecordingVideoPopup();
			}), new object[0]);
		}

		// Token: 0x060014CD RID: 5325 RVA: 0x000809C8 File Offset: 0x0007EBC8
		private void ReportStreamStatsToCloud(string eventType, string reason)
		{
			Logger.Info("StreamStats eventType: {0}, reason: {1}", new object[]
			{
				eventType,
				reason
			});
			string str = BstHttpClient.Post("https://cloud.bluestacks.com/stats/btvfunnelstats", new Dictionary<string, string>
			{
				{
					"event_type",
					eventType
				},
				{
					"error_code",
					reason
				},
				{
					"guid",
					RegistryManager.Instance.UserGuid
				},
				{
					"streaming_platform",
					this.mNetwork
				},
				{
					"session_id",
					Stats.GetSessionId()
				},
				{
					"prod_ver",
					"4.140.12.1002"
				},
				{
					"created_at",
					DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss")
				}
			}, null, false, BtvApp.sVmName, 0, 1, 0, false);
			Logger.Info("Response for btvfunnelstats : " + str);
		}

		// Token: 0x060014CE RID: 5326 RVA: 0x0000E8B6 File Offset: 0x0000CAB6
		internal void GetParametersFromOBS()
		{
			this.SendObsRequest("getmicvolume", null, "SetMicVolumeLocal", null, 0, false);
			this.SendObsRequest("getsystemvolume", null, "SetSystemVolumeLocal", null, 0, false);
		}

		// Token: 0x060014CF RID: 5327 RVA: 0x00080A98 File Offset: 0x0007EC98
		private void SetMicLocal(string response)
		{
			try
			{
				List<string> list = response.Split(new string[]
				{
					"@@"
				}, StringSplitOptions.RemoveEmptyEntries)[0].Split(new char[]
				{
					','
				}, StringSplitOptions.RemoveEmptyEntries).ToList<string>();
				List<string> list2 = response.Split(new string[]
				{
					"@@"
				}, StringSplitOptions.RemoveEmptyEntries)[1].Split(new char[]
				{
					','
				}, StringSplitOptions.RemoveEmptyEntries).ToList<string>();
				StreamManager.mSelectedMic = response.Split(new string[]
				{
					"@@"
				}, StringSplitOptions.RemoveEmptyEntries)[2];
				StreamManager.mDictMicDetails.Clear();
				StreamManager.mSelectedMic = Regex.Replace(StreamManager.mSelectedMic, "[^\\u0000-\\u007F]+", string.Empty);
				if (list2.Count == 0)
				{
					StreamManager.mSelectedMic = string.Empty;
					StreamManager.mIsMicDisabled = true;
				}
				else
				{
					for (int i = 0; i < list2.Count; i++)
					{
						if (!list2[i].Equals("Default") && !list2[i].Equals("Disable"))
						{
							StreamManager.mDictMicDetails.Add(Regex.Replace(list[i], "[^\\u0000-\\u007F]+", string.Empty), list2[i]);
						}
					}
					if (StreamManager.mDictMicDetails.Count == 0)
					{
						StreamManager.mSelectedMic = string.Empty;
						StreamManager.mIsMicDisabled = true;
					}
					else if (!StreamManager.mDictMicDetails.ContainsKey(StreamManager.mSelectedMic))
					{
						StreamManager.mSelectedMic = StreamManager.mDictMicDetails.Keys.ToList<string>()[0];
					}
				}
				if (this.EventGetMicDetails != null)
				{
					this.EventGetMicDetails(this, new CustomVolumeEventArgs(StreamManager.mDictMicDetails, StreamManager.mSelectedMic));
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in SetMicLocal. response: " + response);
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x060014D0 RID: 5328 RVA: 0x00080C64 File Offset: 0x0007EE64
		private void SetMicVolumeLocal(string volumeResponse)
		{
			try
			{
				StreamManager.mMicVolume = JObject.Parse(volumeResponse)["volume"].ToObject<int>();
				if (this.EventGetMicVolume != null)
				{
					this.EventGetMicVolume(this, new CustomVolumeEventArgs(StreamManager.mMicVolume));
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in SetMicVolumeLocal. response: " + volumeResponse);
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x060014D1 RID: 5329 RVA: 0x00080CD8 File Offset: 0x0007EED8
		private void SetCameraLocal(string cameraResponse)
		{
			try
			{
				List<string> list = cameraResponse.Split(new string[]
				{
					"@@"
				}, StringSplitOptions.RemoveEmptyEntries)[0].Split(new char[]
				{
					','
				}, StringSplitOptions.RemoveEmptyEntries).ToList<string>();
				List<string> list2 = cameraResponse.Split(new string[]
				{
					"@@"
				}, StringSplitOptions.RemoveEmptyEntries)[1].Split(new char[]
				{
					','
				}, StringSplitOptions.RemoveEmptyEntries).ToList<string>();
				StreamManager.mDictCameraDetails.Clear();
				if (list2.Count == 0)
				{
					StreamManager.mSelectedCamera = string.Empty;
					StreamManager.mIsWebcamDisabled = true;
				}
				else
				{
					for (int i = 0; i < list2.Count; i++)
					{
						StreamManager.mDictCameraDetails.Add(Regex.Replace(list[i], "[^\\u0000-\\u007F]+", string.Empty).Trim(), list2[i]);
					}
					if (!StreamManager.mDictCameraDetails.ContainsKey(StreamManager.mSelectedCamera))
					{
						StreamManager.mSelectedCamera = Regex.Replace(cameraResponse.Split(new string[]
						{
							"@@"
						}, StringSplitOptions.RemoveEmptyEntries)[2], "[^\\u0000-\\u007F]+", string.Empty);
					}
				}
				if (this.EventGetCameraDetails != null)
				{
					this.EventGetCameraDetails(this, new CustomVolumeEventArgs(StreamManager.mDictCameraDetails, StreamManager.mSelectedCamera));
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in SetCameraLocal. response: " + cameraResponse);
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x060014D2 RID: 5330 RVA: 0x00080E3C File Offset: 0x0007F03C
		private void SetSystemVolumeLocal(string volumeResponse)
		{
			try
			{
				StreamManager.mSystemVolume = JObject.Parse(volumeResponse)["volume"].ToObject<int>();
				if (this.EventGetSystemVolume != null)
				{
					this.EventGetSystemVolume(this, new CustomVolumeEventArgs(StreamManager.mSystemVolume));
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in SetSystemVolumeLocal. response: " + volumeResponse);
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x060014D3 RID: 5331 RVA: 0x00080EB0 File Offset: 0x0007F0B0
		public void EnableWebcam(string width, string height, string position)
		{
			if (this.mCLRBrowserRunning && this.mLayoutTheme == null)
			{
				string currentTheme = FilterUtility.GetCurrentTheme(this.mCurrentFilterAppPkg);
				FilterThemeConfig filterThemeConfig = FilterUtility.GetFilterThemeConfig(this.mCurrentFilterAppPkg, currentTheme);
				this.SetAndEnableWebCamPosition(filterThemeConfig);
				FilterUtility.SendRequestToCLRBrowser("updatesettings", new Dictionary<string, string>
				{
					{
						"settings",
						filterThemeConfig.mFilterThemeSettings.ToJsonString()
					}
				});
				return;
			}
			if (this.mLayoutTheme == null)
			{
				this.EnableWebcamInternal(width, height, position);
				return;
			}
			this.SetSceneConfiguration(this.mLastCameraLayoutTheme);
			StreamWindow.Instance.EvaluateJS("currentActiveLayout('" + LayoutWindow.GetLayoutName(this.mLayoutTheme) + "');");
		}

		// Token: 0x060014D4 RID: 5332 RVA: 0x00080F58 File Offset: 0x0007F158
		public void DisableSource(string source)
		{
			this.SendObsRequest("setrender", new Dictionary<string, string>
			{
				{
					"source",
					source
				},
				{
					"render",
					"0"
				}
			}, null, null, 0, false);
		}

		// Token: 0x060014D5 RID: 5333 RVA: 0x00080F98 File Offset: 0x0007F198
		public void EnableSource(string source)
		{
			this.SendObsRequest("setrender", new Dictionary<string, string>
			{
				{
					"source",
					source
				},
				{
					"render",
					"1"
				}
			}, null, null, 0, false);
		}

		// Token: 0x060014D6 RID: 5334 RVA: 0x00080FD8 File Offset: 0x0007F1D8
		public void EnableWebcamInternal(string widthStr, string heightStr, string position)
		{
			int num = Convert.ToInt32(widthStr);
			int num2 = Convert.ToInt32(heightStr);
			if (this.mStreamHeight == 0 || this.mStreamWidth == 0)
			{
				return;
			}
			num = num * 100 / this.mStreamWidth;
			num2 = num2 * 100 / this.mStreamHeight;
			new Dictionary<string, string>();
			int x = 0;
			int y = 0;
			if (position.Equals("2"))
			{
				x = 100 - num;
			}
			else if (position.Equals("3"))
			{
				y = 100 - num2;
			}
			else if (position.Equals("4"))
			{
				x = 100 - num;
				y = 100 - num;
			}
			this.SetCameraPosition(x, y, num, num2, 1);
		}

		// Token: 0x060014D7 RID: 5335 RVA: 0x00081070 File Offset: 0x0007F270
		public void DisableWebcamV2(string jsonString)
		{
			if (this.mLayoutTheme != null)
			{
				this.mLastCameraLayoutTheme = this.mLayoutTheme;
				FilterUtility.UpdateLayout("LastCameraLayoutTheme", this.mLastCameraLayoutTheme, true);
				this.SetSceneConfiguration(jsonString);
				this.mAppViewLayout = true;
				FilterUtility.UpdateAppViewLayoutRegistry(this.mAppViewLayout);
				StreamWindow.Instance.EvaluateJS("currentActiveLayout('" + LayoutWindow.GetLayoutName(this.mLayoutTheme) + "');");
			}
			else
			{
				this.DisableWebcamAndClearDictionary();
			}
			if (this.mCLRBrowserRunning)
			{
				string currentTheme = FilterUtility.GetCurrentTheme(this.mCurrentFilterAppPkg);
				FilterThemeConfig filterThemeConfig = FilterUtility.GetFilterThemeConfig(this.mCurrentFilterAppPkg, currentTheme);
				filterThemeConfig.mFilterThemeSettings.mIsWebCamOn = false;
				FilterUtility.SendRequestToCLRBrowser("updatesettings", new Dictionary<string, string>
				{
					{
						"settings",
						filterThemeConfig.mFilterThemeSettings.ToJsonString()
					}
				});
			}
		}

		// Token: 0x060014D8 RID: 5336 RVA: 0x0000E8E0 File Offset: 0x0000CAE0
		public void DisableWebcamAndClearDictionary()
		{
			StreamManager.mDictLastCameraPosition.Clear();
			StreamManager.mIsWebcamDisabled = true;
			this.DisableWebcam();
		}

		// Token: 0x060014D9 RID: 5337 RVA: 0x0000E8F8 File Offset: 0x0000CAF8
		internal void DisableWebcam()
		{
			this.DisableSource("BlueStacksWebcam");
		}

		// Token: 0x060014DA RID: 5338 RVA: 0x0008113C File Offset: 0x0007F33C
		private void WebcamConfigured(string response)
		{
			try
			{
				JObject jobject = JObject.Parse(response);
				if (jobject["success"].ToObject<bool>())
				{
					StreamManager.mCamStatus = jobject["webcam"].ToObject<bool>().ToString();
					if (Convert.ToBoolean(StreamManager.mCamStatus))
					{
						RegistryManager.Instance.CamStatus = 1;
					}
					else
					{
						RegistryManager.Instance.CamStatus = 0;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Setting WebCamRegistry. response: {0} err : {1}", new object[]
				{
					response,
					ex.ToString()
				});
			}
		}

		// Token: 0x060014DB RID: 5339 RVA: 0x0000E905 File Offset: 0x0000CB05
		public void ResetFlvStream()
		{
			this.SendObsRequest("resetflvstream", null, null, null, 0);
		}

		// Token: 0x060014DC RID: 5340 RVA: 0x000811D8 File Offset: 0x0007F3D8
		public void SetSquareConfig(int startX, int startY, int width, int height)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			Logger.Info("Window size: ({0}, {1})", new object[]
			{
				width,
				height
			});
			this.widthDiff = 0;
			int num;
			int num2;
			MiscUtils.GetStreamWidthAndHeight(width, height, out num, out num2);
			num = (int)this.GetWidthFromHeight((double)num2);
			Logger.Info("Stream size: ({0}, {1})", new object[]
			{
				num,
				num2
			});
			width = num;
			height = num2;
			height = width;
			string value;
			int num3;
			if (num2 <= 720)
			{
				value = "main";
				num3 = 2500;
			}
			else
			{
				value = "high";
				num3 = 3500;
			}
			float num4 = 1f;
			Logger.Info("x : " + startX);
			Logger.Info("y : " + startY);
			Logger.Info("width : " + width);
			Logger.Info("height : " + height);
			dictionary.Clear();
			dictionary.Add("startX", startX.ToString());
			dictionary.Add("startY", startY.ToString());
			dictionary.Add("width", width.ToString());
			dictionary.Add("height", height.ToString());
			dictionary.Add("x264Profile", value);
			dictionary.Add("maxBitrate", num3.ToString());
			dictionary.Add("downscale", num4.ToString());
			this.mStreamWidth = width;
			this.mStreamHeight = height;
			this.SendObsRequest("setconfig", dictionary, null, null, 0, false);
		}

		// Token: 0x060014DD RID: 5341 RVA: 0x0000E916 File Offset: 0x0000CB16
		public void SetConfig(int startX, int startY, int width, int height)
		{
			if (this.mSquareTheme)
			{
				this.SetSquareConfig(startX, startY, width, height);
				return;
			}
			this.SetDefaultConfig(startX, startY, width, height);
		}

		// Token: 0x060014DE RID: 5342 RVA: 0x0000E937 File Offset: 0x0000CB37
		public void RestartRecord()
		{
			StreamWindowUtility.UnSetOBSParentWindow();
			this.StopRecord(true);
			this.StartRecord();
		}

		// Token: 0x060014DF RID: 5343 RVA: 0x00081374 File Offset: 0x0007F574
		public void SetDefaultConfig(int startX, int startY, int width, int height)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			Logger.Info("Window size: ({0}, {1})", new object[]
			{
				width,
				height
			});
			this.widthDiff = 0;
			int num;
			int num2;
			MiscUtils.GetStreamWidthAndHeight(width, height, out num, out num2);
			num = (int)this.GetWidthFromHeight((double)num2);
			width = num;
			height = num2;
			int num3 = width * 9 / 16;
			Logger.Info("Stream size: ({0}, {1})", new object[]
			{
				num,
				num2
			});
			string value;
			int num4;
			if (num2 == 540)
			{
				value = "main";
				num4 = 1200;
			}
			else if (num2 == 720)
			{
				value = "main";
				num4 = 2500;
			}
			else
			{
				value = "high";
				num4 = 3500;
			}
			float num5 = (float)height / (float)num2;
			Logger.Info("x : " + startX);
			Logger.Info("y : " + startY);
			Logger.Info("width : " + width);
			Logger.Info("height : " + height);
			dictionary.Clear();
			dictionary.Add("startX", startX.ToString());
			dictionary.Add("startY", startY.ToString());
			dictionary.Add("width", width.ToString());
			dictionary.Add("height", height.ToString());
			dictionary.Add("x264Profile", value);
			dictionary.Add("maxBitrate", num4.ToString());
			dictionary.Add("downscale", num5.ToString());
			this.mStreamWidth = width;
			this.mStreamHeight = height;
			this.SendObsRequest("setconfig", dictionary, null, null, 0, false);
		}

		// Token: 0x060014E0 RID: 5344 RVA: 0x0008152C File Offset: 0x0007F72C
		public void StartStream(string key, string location, string callbackStreamStatus, string callbackAppInfo)
		{
			string service = "1";
			this.mCallbackStreamStatus = callbackStreamStatus;
			if (this.mCallbackAppInfo == null)
			{
				this.mCallbackAppInfo = callbackAppInfo;
			}
			this.SetStreamSettings(service, key, location);
			this.SendObsRequest("startstream", null, "StreamStarted", null, 0);
		}

		// Token: 0x060014E1 RID: 5345 RVA: 0x00081574 File Offset: 0x0007F774
		public void StartStream(string jsonString, string callbackStreamStatus, string callbackAppInfo)
		{
			Logger.Info(jsonString);
			JObject jobject = JObject.Parse(jsonString);
			string playPath = jobject["key"].ToString();
			string service = jobject["service"].ToString();
			string url = jobject["streamUrl"].ToString();
			if (jobject["server"].ToString().ToLower() == "twitch")
			{
				StreamWindowUtility.ChangeHeightOFOBSWindow(13);
			}
			else
			{
				StreamWindowUtility.ChangeHeightOFOBSWindow(13);
			}
			this.mCallbackStreamStatus = callbackStreamStatus;
			this.mCallbackAppInfo = callbackAppInfo;
			this.SetStreamSettings(service, playPath, url);
			this.SendObsRequest("startstream", null, "StreamStarted", null, 0);
		}

		// Token: 0x060014E2 RID: 5346 RVA: 0x0000E94B File Offset: 0x0000CB4B
		public void StopStream()
		{
			this.SendObsRequest("stopstream", null, "StreamStopped", null, 0);
		}

		// Token: 0x060014E3 RID: 5347 RVA: 0x0008161C File Offset: 0x0007F81C
		private void SendStatus(string path, Dictionary<string, string> data)
		{
			try
			{
				if (path.Equals("streamstarted"))
				{
					BTVManager.Instance.StreamStarted();
				}
				else if (path.Equals("streamstopped"))
				{
					BTVManager.Instance.StreamStopped();
				}
				else if (path.Equals("recordstarted"))
				{
					BTVManager.Instance.RecordStarted();
					StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
					{
						if (LayoutWindow.Instance != null)
						{
							LayoutWindow.Instance.ReParentOBSWindow();
							return;
						}
						StreamWindowUtility.ReParentOBSWindow(this.mObsRenderFrame);
					}), new object[0]);
				}
				else if (path.Equals("recordstopped"))
				{
					BTVManager.Instance.RecordStopped();
					CommonHandlers.sIsRecordingVideo = false;
					if (BlueStacksUIUtils.DictWindows.ContainsKey(CommonHandlers.sRecordingInstance))
					{
						BlueStacksUIUtils.DictWindows[CommonHandlers.sRecordingInstance].mCommonHandler.RecordingStopped();
					}
					CommonHandlers.sRecordingInstance = "";
					this.ShutDownForcefully();
				}
				else if (path.Equals("streamstatus"))
				{
					if (string.Compare(data["isstreaming"], "true", true) == 0)
					{
						BTVManager.Instance.sStreaming = true;
					}
					else
					{
						BTVManager.Instance.sStreaming = false;
					}
				}
				else if (path.Equals("replaybuffersaved"))
				{
					BTVManager.Instance.ReplayBufferSaved();
				}
				else if (path.Equals("RecordStartedVideo") && BlueStacksUIUtils.DictWindows.ContainsKey(CommonHandlers.sRecordingInstance))
				{
					BlueStacksUIUtils.DictWindows[CommonHandlers.sRecordingInstance].mCommonHandler.RecordingStarted();
				}
				Logger.Info("Successfully sent status for {0}", new object[]
				{
					path
				});
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send post request for {0}... Err : {1}", new object[]
				{
					path,
					ex.ToString()
				});
			}
		}

		// Token: 0x060014E4 RID: 5348 RVA: 0x000817DC File Offset: 0x0007F9DC
		public void StartRecordForVideo()
		{
			if (this.mIsObsRunning)
			{
				int startX;
				int startY;
				int width;
				int height;
				StreamManager.Instance.SetStreamDimension(out startX, out startY, out width, out height);
				this.SetConfig(startX, startY, width, height);
				this.SetSceneConfiguration(this.mLayoutTheme);
				this.ResetCLRBrowser(true);
			}
			this.SendObsRequest("startrecord", null, "RecordStartedVideo", null, 0);
		}

		// Token: 0x060014E5 RID: 5349 RVA: 0x0000E960 File Offset: 0x0000CB60
		public void StartRecord()
		{
			this.StartRecord(this.mNetwork, this.mEnableFilter, this.mSquareTheme, this.mLayoutTheme, this.mCallbackAppInfo);
		}

		// Token: 0x060014E6 RID: 5350 RVA: 0x0000E986 File Offset: 0x0000CB86
		public void StartRecordInit(string network, bool enableFilter, bool squareTheme, string layoutTheme, string callbackAppInfo)
		{
			this.mNetwork = network;
			this.mEnableFilter = enableFilter;
			this.mSquareTheme = squareTheme;
			this.mLayoutTheme = layoutTheme;
			this.mCallbackAppInfo = callbackAppInfo;
		}

		// Token: 0x060014E7 RID: 5351 RVA: 0x00081834 File Offset: 0x0007FA34
		public void StartRecord(string network, bool enableFilter, bool squareTheme, string layoutTheme, string callbackAppInfo)
		{
			object obj = this.stoppingOBSLock;
			lock (obj)
			{
				this.mEnableFilter = enableFilter;
				this.mSquareTheme = squareTheme;
				this.mCallbackAppInfo = callbackAppInfo;
				this.SendNetworkName(network);
				if (layoutTheme != null)
				{
					this.mLayoutTheme = Utils.GetString(RegistryManager.Instance.LayoutTheme, layoutTheme);
					this.mLastCameraLayoutTheme = RegistryManager.Instance.LastCameraLayoutTheme;
					this.mAppViewLayout = (RegistryManager.Instance.AppViewLayout == 1);
					if (string.IsNullOrEmpty(this.mLastCameraLayoutTheme))
					{
						this.mLastCameraLayoutTheme = layoutTheme;
					}
				}
				else
				{
					this.mLayoutTheme = layoutTheme;
				}
				this.mNetwork = network;
				if (this.mIsObsRunning)
				{
					int startX;
					int startY;
					int width;
					int height;
					StreamManager.Instance.SetStreamDimension(out startX, out startY, out width, out height);
					this.SetConfig(startX, startY, width, height);
					this.SetSceneConfiguration(this.mLayoutTheme);
					if (layoutTheme == null)
					{
						string currentAppPkg = FilterUtility.GetCurrentAppPkg();
						if (currentAppPkg != null && this.mEnableFilter && FilterUtility.IsFilterApplicableApp(currentAppPkg))
						{
							string currentTheme = FilterUtility.GetCurrentTheme(currentAppPkg);
							this.InitCLRBrowser(currentAppPkg, currentTheme, true);
						}
						else
						{
							this.ResetCLRBrowser(true);
						}
					}
				}
				this.EnableVideoRecording(false);
				this.SendObsRequest("startrecord", null, "RecordStarted", null, 0);
			}
		}

		// Token: 0x060014E8 RID: 5352 RVA: 0x0000E9AD File Offset: 0x0000CBAD
		public void StopRecord()
		{
			this.StopRecord(false);
		}

		// Token: 0x060014E9 RID: 5353 RVA: 0x0008197C File Offset: 0x0007FB7C
		public void StopRecord(bool immediate)
		{
			this.SendObsRequest("stoprecord", new Dictionary<string, string>
			{
				{
					"immediate",
					immediate ? "1" : "0"
				}
			}, "RecordStopped", null, 0);
		}

		// Token: 0x060014EA RID: 5354 RVA: 0x000819BC File Offset: 0x0007FBBC
		public void SendAppInfo(string type, string name, string data)
		{
			if (this.mCallbackAppInfo == null)
			{
				return;
			}
			object[] args = new object[]
			{
				new JObject
				{
					{
						"type",
						type
					},
					{
						"name",
						name
					},
					{
						"data",
						data
					}
				}.ToString(Formatting.None, new JsonConverter[0])
			};
			this.mBrowser.CallJs(this.mCallbackAppInfo, args);
		}

		// Token: 0x060014EB RID: 5355 RVA: 0x00081A34 File Offset: 0x0007FC34
		public static string GetStreamConfig()
		{
			string streamName = RegistryManager.Instance.StreamName;
			string serverLocation = RegistryManager.Instance.ServerLocation;
			JObject jobject = new JObject();
			jobject.Add("streamName", streamName);
			jobject.Add("camStatus", Convert.ToBoolean(StreamManager.mCamStatus));
			jobject.Add("micVolume", StreamManager.mMicVolume);
			jobject.Add("systemVolume", StreamManager.mSystemVolume);
			jobject.Add("serverLocation", serverLocation);
			Logger.Info("GetStreamConfig: " + jobject.ToString(Formatting.None, new JsonConverter[0]));
			return jobject.ToString();
		}

		// Token: 0x060014EC RID: 5356 RVA: 0x00081AE8 File Offset: 0x0007FCE8
		private void StreamStarted(string response)
		{
			this.SendStatus("streamstarted", null);
			this.mIsStreaming = true;
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				if (StreamWindow.Instance != null)
				{
					StreamWindow.Instance.StreamStarted();
				}
			}), new object[0]);
			string type;
			string name;
			string data;
			StreamWindowUtility.GetCurrentAppInfo(out type, out name, out data);
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				this.SendAppInfo(type, name, data);
			}), new object[0]);
		}

		// Token: 0x060014ED RID: 5357 RVA: 0x00081B84 File Offset: 0x0007FD84
		private void StreamStopped(string response)
		{
			StreamWindowUtility.isStartEventSent = false;
			this.SendStatus("streamstopped", null);
			this.mIsStreaming = false;
			this.mIsStreamStarted = false;
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				if (StreamWindow.Instance != null)
				{
					StreamWindow.Instance.StreamEnded();
				}
			}), new object[0]);
			this.SendObsRequest("close", null, null, null, 0);
			new Thread(delegate()
			{
				this.KillOBS();
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060014EE RID: 5358 RVA: 0x0000E9B6 File Offset: 0x0000CBB6
		public void killOBSForcelly()
		{
			ProcessUtils.KillProcessByName("HD-OBS");
		}

		// Token: 0x060014EF RID: 5359 RVA: 0x00081C14 File Offset: 0x0007FE14
		public void KillOBS()
		{
			if (this.mStoppingOBS)
			{
				return;
			}
			object obj = this.stoppingOBSLock;
			lock (obj)
			{
				this.mStoppingOBS = true;
				try
				{
					int num = 0;
					int num2 = 20;
					while (num < num2 && Process.GetProcessesByName("HD-OBS").Length != 0)
					{
						num++;
						if (num < num2)
						{
							Logger.Info("Waiting for HD-OBS to quit gracefully, retry: {0}", new object[]
							{
								num
							});
							Thread.Sleep(200);
						}
					}
					if (num >= num2)
					{
						ProcessUtils.KillProcessByName("HD-OBS");
					}
					this.StartOBS();
				}
				catch (Exception ex)
				{
					Logger.Info("Failed to kill HD-OBS.exe...Err : " + ex.ToString());
				}
				this.mStoppingOBS = false;
			}
		}

		// Token: 0x060014F0 RID: 5360 RVA: 0x0000E9C2 File Offset: 0x0000CBC2
		private void RecordStarted(string response)
		{
			this.SendStatus("recordstarted", null);
		}

		// Token: 0x060014F1 RID: 5361 RVA: 0x0000E9D0 File Offset: 0x0000CBD0
		private void RecordStopped(string response)
		{
			this.SendStatus("recordstopped", null);
		}

		// Token: 0x060014F2 RID: 5362 RVA: 0x0000E9DE File Offset: 0x0000CBDE
		private void RecordStartedVideo(string response)
		{
			this.SendStatus("RecordStartedVideo", null);
		}

		// Token: 0x060014F3 RID: 5363 RVA: 0x0000E9EC File Offset: 0x0000CBEC
		public void StartReplayBuffer()
		{
			this.SendObsRequest("startreplaybuffer", null, null, null, 0);
		}

		// Token: 0x060014F4 RID: 5364 RVA: 0x0000E9FD File Offset: 0x0000CBFD
		public void StopReplayBuffer()
		{
			this.SendObsRequest("stopreplaybuffer", null, null, null, 2000);
		}

		// Token: 0x060014F5 RID: 5365 RVA: 0x00081CDC File Offset: 0x0007FEDC
		private void SetStreamSettings(string service, string playPath, string url)
		{
			this.SendObsRequest("setstreamsettings", new Dictionary<string, string>
			{
				{
					"service",
					service
				},
				{
					"playPath",
					playPath
				},
				{
					"url",
					url
				}
			}, null, null, 0);
		}

		// Token: 0x060014F6 RID: 5366 RVA: 0x00081D24 File Offset: 0x0007FF24
		public void SetSystemVolume(string level)
		{
			StreamManager.mSystemVolume = Convert.ToInt32(level);
			this.SendObsRequest("setsystemvolume", new Dictionary<string, string>
			{
				{
					"volume",
					level
				}
			}, null, null, 0);
		}

		// Token: 0x060014F7 RID: 5367 RVA: 0x00081D60 File Offset: 0x0007FF60
		internal void SetMic(string micName)
		{
			micName = StreamManager.mDictMicDetails[micName];
			this.SendObsRequest("setmic", new Dictionary<string, string>
			{
				{
					"micId",
					micName
				}
			}, null, null, 0);
		}

		// Token: 0x060014F8 RID: 5368 RVA: 0x00081D9C File Offset: 0x0007FF9C
		public void SetMicVolume(string level)
		{
			StreamManager.mMicVolume = Convert.ToInt32(level);
			if (StreamManager.mMicVolume > 0)
			{
				StreamManager.mIsMicDisabled = false;
			}
			this.SendObsRequest("setmicvolume", new Dictionary<string, string>
			{
				{
					"volume",
					level
				}
			}, null, null, 0);
		}

		// Token: 0x060014F9 RID: 5369 RVA: 0x00081DE4 File Offset: 0x0007FFE4
		private void StartPollingOBS()
		{
			while (this.mIsObsRunning)
			{
				try
				{
					JObject jobject = JObject.Parse(Regex.Replace(this.SendObsRequestInternal("getstatus", null), "\\r\\n?|\\n", ""));
					bool flag = jobject["streaming"].ToObject<bool>();
					bool reconnecting = jobject["reconnecting"].ToObject<bool>();
					if (!flag)
					{
						try
						{
							this.mFailureReason = jobject["reason"].ToString();
						}
						catch
						{
						}
					}
					if (flag != this.mIsStreaming)
					{
						this.SendStreamStatus(flag, reconnecting);
					}
					this.mIsStreaming = flag;
					this.mIsReconnecting = reconnecting;
					this.SendStatus("streamstatus", new Dictionary<string, string>
					{
						{
							"isstreaming",
							Convert.ToString(this.mIsStreaming)
						}
					});
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in StartPollingOBS err : " + ex.ToString());
					if (!ProcessUtils.FindProcessByName("HD-OBS"))
					{
						this.mIsObsRunning = false;
						this.mIsStreaming = false;
						this.mIsReconnecting = false;
						this.mCLRBrowserRunning = false;
						this.mIsStreamStarted = false;
						if (!this.mStoppingOBS)
						{
							this.UpdateFailureReason();
						}
						this.SendStreamStatus(false, false);
						this.InitObs();
						this.mStoppingOBS = false;
						break;
					}
				}
				Thread.Sleep(5000);
			}
		}

		// Token: 0x060014FA RID: 5370 RVA: 0x00081F40 File Offset: 0x00080140
		private void UpdateFailureReason()
		{
			if (string.IsNullOrEmpty(this.mFailureReason))
			{
				string text = "";
				string format = "yyyy-MM-dd-HHmm-ss";
				DateTime t = DateTime.MinValue;
				string[] files = Directory.GetFiles(Path.Combine(RegistryStrings.BtvDir, "OBS\\Logs\\"));
				for (int i = 0; i < files.Length; i++)
				{
					text = Path.GetFileNameWithoutExtension(files[i]);
					DateTime dateTime;
					if (DateTime.TryParseExact(text, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out dateTime) && t < dateTime)
					{
						t = dateTime;
					}
				}
				if (!t.Equals(DateTime.MinValue))
				{
					text = File.ReadAllLines(Path.Combine(RegistryStrings.BtvDir, "OBS\\Logs\\") + t.ToString("yyyy-MM-dd-HHmm-ss") + ".log").Last<string>();
				}
				this.mFailureReason = "OBS crashed: " + text;
			}
		}

		// Token: 0x060014FB RID: 5371 RVA: 0x00082010 File Offset: 0x00080210
		private void SendNetworkName(string network)
		{
			try
			{
				BTVManager.sNetwork = network;
				RegistryManager.Instance.BtvNetwork = network;
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send network name... Err : " + ex.ToString());
			}
		}

		// Token: 0x060014FC RID: 5372 RVA: 0x00082058 File Offset: 0x00080258
		private void SendStreamStatus(bool streaming, bool reconnecting)
		{
			Logger.Info(string.Concat(new string[]
			{
				"Sending stream status with data :: streaming : ",
				streaming.ToString(),
				", reconnecting : ",
				reconnecting.ToString(),
				", obsRunning : ",
				this.mIsObsRunning.ToString(),
				", failureReason : ",
				this.mFailureReason
			}));
			try
			{
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary.Add("obs", this.mIsObsRunning.ToString());
				dictionary.Add("streaming", streaming.ToString());
				dictionary.Add("reconnecting", reconnecting.ToString());
				dictionary.Add("reason", this.mFailureReason.ToString());
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send stream status... Err : " + ex.ToString());
			}
		}

		// Token: 0x060014FD RID: 5373 RVA: 0x00082140 File Offset: 0x00080340
		public void ResizeStream(string width, string height)
		{
			if (StreamManager.mObsCommandQueue != null)
			{
				this.SendObsRequest("windowresized", new Dictionary<string, string>
				{
					{
						"width",
						width
					},
					{
						"height",
						height
					}
				}, null, null, 0);
			}
		}

		// Token: 0x060014FE RID: 5374 RVA: 0x0000EA12 File Offset: 0x0000CC12
		public void ShowObs()
		{
			this.SendObsRequest("show", null, null, null, 0);
		}

		// Token: 0x060014FF RID: 5375 RVA: 0x0000EA23 File Offset: 0x0000CC23
		public void HideObs()
		{
			this.SendObsRequest("hide", null, null, null, 0);
		}

		// Token: 0x06001500 RID: 5376 RVA: 0x00082184 File Offset: 0x00080384
		public void MoveWebcam(string horizontal, string vertical)
		{
			this.SendObsRequest("movewebcam", new Dictionary<string, string>
			{
				{
					"horizontal",
					horizontal
				},
				{
					"vertical",
					vertical
				}
			}, null, null, 0);
		}

		// Token: 0x06001501 RID: 5377 RVA: 0x000821C0 File Offset: 0x000803C0
		public void Shutdown()
		{
			if (this.mIsStreaming)
			{
				this.StopStream();
			}
			StreamWindowUtility.sIsOBSReParented = false;
			if (StreamManager.mObsCommandQueue != null)
			{
				this.mIsObsRunning = false;
				this.mIsStreamStarted = false;
				this.SendObsRequest("close", null, "CloseSuccess", "CloseFailed", 0);
			}
		}

		// Token: 0x06001502 RID: 5378 RVA: 0x0000EA34 File Offset: 0x0000CC34
		public void CloseSuccess(string response)
		{
			StreamManager.Instance = null;
		}

		// Token: 0x06001503 RID: 5379 RVA: 0x0000EA3C File Offset: 0x0000CC3C
		public void CloseFailed()
		{
			ProcessUtils.KillProcessByName("HD-OBS");
			StreamManager.Instance = null;
		}

		// Token: 0x06001504 RID: 5380 RVA: 0x00082210 File Offset: 0x00080410
		public static void StopOBS()
		{
			StreamManager.Instance.mStoppingOBS = true;
			StreamManager.sStopInitOBSQueue = true;
			StreamManager.Instance.Shutdown();
			int num = 0;
			while (Process.GetProcessesByName("HD-OBS").Length != 0 && num < 20)
			{
				Thread.Sleep(500);
				num++;
			}
			if (num == 20)
			{
				Logger.Info("Killing hd-obs as normal close failed");
				StreamManager.Instance.CloseFailed();
			}
		}

		// Token: 0x06001505 RID: 5381 RVA: 0x0000EA4E File Offset: 0x0000CC4E
		public void SaveReplayBuffer()
		{
			this.SendObsRequest("savereplaybuffer", null, null, null, 0);
		}

		// Token: 0x06001506 RID: 5382 RVA: 0x0000EA5F File Offset: 0x0000CC5F
		public void ReplayBufferSaved()
		{
			this.SendStatus("replaybuffersaved", null);
		}

		// Token: 0x06001507 RID: 5383 RVA: 0x0000EA6D File Offset: 0x0000CC6D
		public void SendObsRequest(string request, Dictionary<string, string> data, string responseCallback, string failureCallback, int pauseTime)
		{
			this.SendObsRequest(request, data, responseCallback, failureCallback, pauseTime, true);
		}

		// Token: 0x06001508 RID: 5384 RVA: 0x00082278 File Offset: 0x00080478
		public void SendObsRequest(string request, Dictionary<string, string> data, string responseCallback, string failureCallback, int pauseTime, bool waitForInit)
		{
			Logger.Info("got obs request: " + request);
			if (data != null && !data.ContainsKey("randomVal"))
			{
				data.Add("randomVal", "0");
			}
			new Thread(delegate()
			{
				StreamManager.ObsCommand item = new StreamManager.ObsCommand(request, data, responseCallback, failureCallback, pauseTime);
				object obj = this.mInitOBSLock;
				lock (obj)
				{
					if (!this.mIsInitCalled)
					{
						this.InitObs();
					}
				}
				if (StreamManager.mObsCommandQueue == null)
				{
					StreamManager.mObsCommandQueue = new Queue<StreamManager.ObsCommand>();
				}
				if (waitForInit)
				{
					obj = this.mInitOBSLock;
					lock (obj)
					{
						object obj2 = this.mObsCommandQueueObject;
						lock (obj2)
						{
							StreamManager.mObsCommandQueue.Enqueue(item);
							this.mObsCommandEventHandle.Set();
							return;
						}
					}
				}
				obj = this.mObsCommandQueueObject;
				lock (obj)
				{
					StreamManager.mObsCommandQueue.Enqueue(item);
					this.mObsCommandEventHandle.Set();
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06001509 RID: 5385 RVA: 0x00082320 File Offset: 0x00080520
		private string SendObsRequestInternal(string request, Dictionary<string, string> data)
		{
			Logger.Info("waiting to send request: " + request);
			object obj = this.mObsSendRequestObject;
			string result;
			lock (obj)
			{
				string text = string.Empty;
				if (this.mIsObsRunning)
				{
					text = BstHttpClient.Post(string.Format("{0}:{1}/{2}", StreamManager.sObsServerBaseURL, StreamManager.sObsServerPort, request), data, null, false, BtvApp.sVmName, 0, 1, 0, false);
				}
				result = text;
			}
			return result;
		}

		// Token: 0x0600150A RID: 5386 RVA: 0x000823A0 File Offset: 0x000805A0
		private void ProcessObsCommandQueue()
		{
			while (this.mIsObsRunning)
			{
				this.mObsCommandEventHandle.WaitOne();
				while (StreamManager.mObsCommandQueue.Count != 0)
				{
					object obj = this.mObsCommandQueueObject;
					StreamManager.ObsCommand obsCommand;
					lock (obj)
					{
						if (StreamManager.mObsCommandQueue.Count == 0)
						{
							break;
						}
						obsCommand = StreamManager.mObsCommandQueue.Dequeue();
					}
					try
					{
						string text = this.SendObsRequestInternal(obsCommand.mRequest, obsCommand.mData);
						Logger.Info("Got response {0} for {1}", new object[]
						{
							text,
							obsCommand.mRequest
						});
						if (obsCommand.mResponseCallback != null)
						{
							base.GetType().GetMethod(obsCommand.mResponseCallback, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).Invoke(this, new object[]
							{
								text
							});
						}
					}
					catch (Exception ex)
					{
						Logger.Error("Exception when sending " + obsCommand.mRequest);
						Logger.Error(ex.ToString());
						try
						{
							if (obsCommand.mFailureCallback != null)
							{
								base.GetType().GetMethod(obsCommand.mFailureCallback, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).Invoke(this, new object[0]);
							}
						}
						catch (Exception ex2)
						{
							Logger.Error("Error in failure call back for call {} and error {1}", new object[]
							{
								obsCommand.mFailureCallback,
								ex2
							});
						}
					}
					Thread.Sleep(obsCommand.mPauseTime);
				}
			}
		}

		// Token: 0x0600150B RID: 5387 RVA: 0x00082514 File Offset: 0x00080714
		public void Init(string appHandle, string pid)
		{
			Logger.Info("App Handle : {0} and Process Id : {1}", new object[]
			{
				appHandle,
				pid
			});
			if (this.mAppHandle == "" && this.mAppPid == "")
			{
				this.mAppHandle = appHandle;
				this.mAppPid = pid;
			}
		}

		// Token: 0x0600150C RID: 5388 RVA: 0x0000EA7D File Offset: 0x0000CC7D
		private double GetWidthFromHeight(double height)
		{
			return (height - (double)this.heightDiff) * this.mAspectRatio.DoubleValue + (double)this.widthDiff;
		}

		// Token: 0x0600150D RID: 5389 RVA: 0x0008256C File Offset: 0x0008076C
		public void GetStreamConfig(out string handle, out string pid)
		{
			try
			{
				MainWindow activatedWindow = null;
				if (BlueStacksUIUtils.DictWindows.Count > 0)
				{
					activatedWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
				}
				handle = activatedWindow.mFrontendHandler.mFrontendHandle.ToString();
				activatedWindow.Dispatcher.Invoke(new Action(delegate()
				{
					activatedWindow.RestrictWindowResize(true);
				}), new object[0]);
				Process currentProcess = Process.GetCurrentProcess();
				pid = currentProcess.Id.ToString();
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to get window handle and process id... Err : " + ex.ToString());
				string text;
				pid = (text = null);
				handle = text;
			}
		}

		// Token: 0x0600150E RID: 5390 RVA: 0x0008262C File Offset: 0x0008082C
		public void ShutDownForcefully()
		{
			try
			{
				this.killOBSForcelly();
				this.mIsObsRunning = false;
				StreamManager.Instance.mStoppingOBS = true;
				StreamManager.mObsCommandQueue.Clear();
				StreamManager.Instance = null;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in shutdown obs : {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x04000E63 RID: 3683
		public static string sObsServerBaseURL = "http://localhost";

		// Token: 0x04000E64 RID: 3684
		public static int sObsServerPort = 2851;

		// Token: 0x04000E65 RID: 3685
		public static string DEFAULT_NETWORK = "twitch";

		// Token: 0x04000E66 RID: 3686
		public static bool DEFAULT_ENABLE_FILTER = true;

		// Token: 0x04000E67 RID: 3687
		public static bool DEFAULT_SQUARE_THEME = false;

		// Token: 0x04000E68 RID: 3688
		public static string DEFAULT_LAYOUT_THEME = null;

		// Token: 0x04000E69 RID: 3689
		private static Queue<StreamManager.ObsCommand> mObsCommandQueue;

		// Token: 0x04000E6A RID: 3690
		private object mObsCommandQueueObject = new object();

		// Token: 0x04000E6B RID: 3691
		private object mObsSendRequestObject = new object();

		// Token: 0x04000E6C RID: 3692
		private object mInitOBSLock = new object();

		// Token: 0x04000E6D RID: 3693
		private EventWaitHandle mObsCommandEventHandle;

		// Token: 0x04000E6E RID: 3694
		public static bool sStopInitOBSQueue = false;

		// Token: 0x04000E6F RID: 3695
		public string mCallbackStreamStatus;

		// Token: 0x04000E70 RID: 3696
		public string mCallbackAppInfo;

		// Token: 0x04000E71 RID: 3697
		public bool mIsObsRunning;

		// Token: 0x04000E72 RID: 3698
		public bool mIsInitCalled;

		// Token: 0x04000E73 RID: 3699
		public bool mIsStreaming;

		// Token: 0x04000E74 RID: 3700
		public bool mStoppingOBS;

		// Token: 0x04000E75 RID: 3701
		public bool mIsReconnecting;

		// Token: 0x04000E76 RID: 3702
		private bool mIsStreamStarted;

		// Token: 0x04000E77 RID: 3703
		private string mFailureReason = "";

		// Token: 0x04000E78 RID: 3704
		private static int mMicVolume;

		// Token: 0x04000E79 RID: 3705
		internal static string mSelectedCamera;

		// Token: 0x04000E7A RID: 3706
		internal static string mSelectedMic;

		// Token: 0x04000E7B RID: 3707
		internal static bool mIsWebcamDisabled = true;

		// Token: 0x04000E7C RID: 3708
		internal static bool mIsMicDisabled = true;

		// Token: 0x04000E7D RID: 3709
		internal static Dictionary<string, string> mDictCameraDetails = new Dictionary<string, string>();

		// Token: 0x04000E7E RID: 3710
		internal static Dictionary<string, string> mDictMicDetails = new Dictionary<string, string>();

		// Token: 0x04000E7F RID: 3711
		internal static Dictionary<string, string> mDictLastCameraPosition = new Dictionary<string, string>();

		// Token: 0x04000E80 RID: 3712
		public string mNetwork = StreamManager.DEFAULT_NETWORK;

		// Token: 0x04000E81 RID: 3713
		public bool mSquareTheme = StreamManager.DEFAULT_SQUARE_THEME;

		// Token: 0x04000E82 RID: 3714
		public string mLayoutTheme = StreamManager.DEFAULT_LAYOUT_THEME;

		// Token: 0x04000E83 RID: 3715
		public string mLastCameraLayoutTheme = StreamManager.DEFAULT_LAYOUT_THEME;

		// Token: 0x04000E84 RID: 3716
		public bool mAppViewLayout;

		// Token: 0x04000E85 RID: 3717
		public bool mEnableFilter = StreamManager.DEFAULT_ENABLE_FILTER;

		// Token: 0x04000E86 RID: 3718
		private static int mSystemVolume;

		// Token: 0x04000E87 RID: 3719
		public static string mCamStatus;

		// Token: 0x04000E88 RID: 3720
		public bool mReplayBufferEnabled;

		// Token: 0x04000E89 RID: 3721
		private string mAppHandle = "";

		// Token: 0x04000E8A RID: 3722
		private string mAppPid = "";

		// Token: 0x04000E8B RID: 3723
		internal int mStreamWidth;

		// Token: 0x04000E8C RID: 3724
		internal int mStreamHeight;

		// Token: 0x04000E8D RID: 3725
		public bool mCLRBrowserRunning;

		// Token: 0x04000E8E RID: 3726
		public string mCurrentFilterAppPkg;

		// Token: 0x04000E8F RID: 3727
		private object stoppingOBSLock = new object();

		// Token: 0x04000E90 RID: 3728
		private Browser mBrowser;

		// Token: 0x04000E91 RID: 3729
		public static StreamManager Instance = null;

		// Token: 0x04000E92 RID: 3730
		public OBSRenderFrameSpecs mObsRenderFrame;

		// Token: 0x04000E97 RID: 3735
		private int heightDiff;

		// Token: 0x04000E98 RID: 3736
		private int widthDiff = 14;

		// Token: 0x04000E99 RID: 3737
		internal Fraction mAspectRatio = new Fraction(16L, 9L);

		// Token: 0x04000E9A RID: 3738
		private MainWindow mWindow;

		// Token: 0x04000E9B RID: 3739
		public bool isWindowCaptureActive;

		// Token: 0x04000E9C RID: 3740
		private string mLastVideoFilePath;

		// Token: 0x04000E9D RID: 3741
		private int mObsRetryCount = 2;

		// Token: 0x02000261 RID: 609
		private class ObsCommand
		{
			// Token: 0x06001513 RID: 5395 RVA: 0x0000EACB File Offset: 0x0000CCCB
			public ObsCommand(string request, Dictionary<string, string> data, string responseCallback, string failureCallback, int pauseTime)
			{
				this.mRequest = request;
				this.mData = data;
				this.mResponseCallback = responseCallback;
				this.mFailureCallback = failureCallback;
				this.mPauseTime = pauseTime;
			}

			// Token: 0x04000E9E RID: 3742
			public string mRequest;

			// Token: 0x04000E9F RID: 3743
			public Dictionary<string, string> mData;

			// Token: 0x04000EA0 RID: 3744
			public string mResponseCallback;

			// Token: 0x04000EA1 RID: 3745
			public string mFailureCallback;

			// Token: 0x04000EA2 RID: 3746
			public int mPauseTime;
		}
	}
}
