﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x0200027C RID: 636
	public class AudioControl : UserControl, IComponentConnector
	{
		// Token: 0x060015D3 RID: 5587 RVA: 0x0000F2B6 File Offset: 0x0000D4B6
		public AudioControl()
		{
			this.InitializeComponent();
			this.LocalizeStrings();
		}

		// Token: 0x060015D4 RID: 5588 RVA: 0x000850BC File Offset: 0x000832BC
		private void LocalizeStrings()
		{
			BlueStacksUIBinding.Bind(this.mLableStreamAudioSource, "STRING_LABEL_STREAM_AUDIO_SOURCE");
			BlueStacksUIBinding.Bind(this.mLblMicroPhoneSource, "STRING_LBL_MICROPHONE_SOURCE");
			BlueStacksUIBinding.Bind(this.mLblMicrophoneSound, "STRING_LBL_MICROPHONE_SOUND");
			BlueStacksUIBinding.Bind(this.mLblMicrophoneSound, "STRING_LBL_COMPUTER_SOUND");
			BlueStacksUIBinding.Bind(this.mLblRestoreDefault, "STRING_LBL_RESTORE_DEFAULT", "");
			BlueStacksUIBinding.Bind(this.mCloseButton, "STRING_CLOSE");
			this.mLocalizedTextNone = LocaleStrings.GetLocalizedString("None", false);
			this.mLableStreamAudioSourceDetail.Text = "*" + LocaleStrings.GetLocalizedString("STRING_LABEL_STREAM_AUDIO_SOURCE_DETAIL", false);
		}

		// Token: 0x060015D5 RID: 5589 RVA: 0x00085160 File Offset: 0x00083360
		internal void Intialize()
		{
			StreamManager.Instance.EventGetMicVolume += this.StreamManager_EventGetMicVolume;
			StreamManager.Instance.EventGetSystemVolume += this.StreamManager_EventGetSystemVolume;
			StreamManager.Instance.EventGetMicDetails += this.StreamManager_EventGetMicDetails;
		}

		// Token: 0x060015D6 RID: 5590 RVA: 0x000851B0 File Offset: 0x000833B0
		private void StreamManager_EventGetMicDetails(object sender, CustomVolumeEventArgs e)
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				this.mAudioSources.Items.Clear();
				ComboBoxItem comboBoxItem = new ComboBoxItem();
				comboBoxItem.Content = this.mLocalizedTextNone;
				this.mAudioSources.Items.Add(comboBoxItem);
				foreach (string content in e.dictData.Keys)
				{
					comboBoxItem = new ComboBoxItem();
					comboBoxItem.Content = content;
					this.mAudioSources.Items.Add(comboBoxItem);
				}
				if (StreamManager.mIsMicDisabled)
				{
					this.mAudioSources.Text = this.mLocalizedTextNone;
					return;
				}
				this.mAudioSources.Text = e.mSelected;
			}), new object[0]);
		}

		// Token: 0x060015D7 RID: 5591 RVA: 0x000851F4 File Offset: 0x000833F4
		private void AudioSources_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count > 0)
			{
				if (((ComboBoxItem)e.AddedItems[0]).Content.ToString().Equals(this.mLocalizedTextNone))
				{
					StreamManager.Instance.SetMicVolume("0");
					return;
				}
				StreamManager.Instance.SetMicVolume(this.mSliderMicVolume.Value.ToString());
				StreamManager.Instance.SetMic(((ComboBoxItem)e.AddedItems[0]).Content.ToString());
			}
		}

		// Token: 0x060015D8 RID: 5592 RVA: 0x0008528C File Offset: 0x0008348C
		private void StreamManager_EventGetSystemVolume(object sender, CustomVolumeEventArgs e)
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				this.mSliderSystemVolume.Value = (double)e.Volume;
			}), new object[0]);
		}

		// Token: 0x060015D9 RID: 5593 RVA: 0x000852D0 File Offset: 0x000834D0
		private void StreamManager_EventGetMicVolume(object sender, CustomVolumeEventArgs e)
		{
			StreamWindow.Instance.Dispatcher.Invoke(new Action(delegate()
			{
				this.mSliderMicVolume.Value = (double)e.Volume;
			}), new object[0]);
		}

		// Token: 0x060015DA RID: 5594 RVA: 0x0000F2D5 File Offset: 0x0000D4D5
		private void CloseButton_Click(object sender, RoutedEventArgs e)
		{
			AdvanceSettingsWindow.Instance.HideWindow();
		}

		// Token: 0x060015DB RID: 5595 RVA: 0x00085314 File Offset: 0x00083514
		private void SliderSystemVolume_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			StreamManager.Instance.SetSystemVolume(this.mSliderSystemVolume.Value.ToString());
		}

		// Token: 0x060015DC RID: 5596 RVA: 0x00085340 File Offset: 0x00083540
		private void SliderMicVolume_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			if (!this.mAudioSources.Text.Equals(this.mLocalizedTextNone))
			{
				StreamManager.Instance.SetMicVolume(this.mSliderMicVolume.Value.ToString());
			}
		}

		// Token: 0x060015DD RID: 5597 RVA: 0x00085384 File Offset: 0x00083584
		private void Restore_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			this.mSliderMicVolume.Value = 100.0;
			this.mSliderSystemVolume.Value = 50.0;
			this.mRestore.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#60B0FF"));
		}

		// Token: 0x060015DE RID: 5598 RVA: 0x0000F2E1 File Offset: 0x0000D4E1
		private void Restore_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mRestore.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFFFFF"));
		}

		// Token: 0x060015DF RID: 5599 RVA: 0x0000F302 File Offset: 0x0000D502
		private void Restore_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mRestore.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#60B0FF"));
		}

		// Token: 0x060015E0 RID: 5600 RVA: 0x0000F323 File Offset: 0x0000D523
		private void Restore_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			this.mRestore.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#638CBC"));
		}

		// Token: 0x060015E1 RID: 5601 RVA: 0x000853D8 File Offset: 0x000835D8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/btv/wpffiles/usercontrol/audiocontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060015E2 RID: 5602 RVA: 0x00003762 File Offset: 0x00001962
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060015E3 RID: 5603 RVA: 0x00085408 File Offset: 0x00083608
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mLableStreamAudioSource = (Run)target;
				return;
			case 2:
				this.mLableStreamAudioSourceDetail = (Run)target;
				return;
			case 3:
				this.mLblMicroPhoneSource = (Run)target;
				return;
			case 4:
				this.mAudioSources = (CustomComboBox)target;
				return;
			case 5:
				this.mLblMicrophoneSound = (Run)target;
				return;
			case 6:
				this.mSliderMicVolume = (CustomSlider)target;
				return;
			case 7:
				this.mLblComputerSound = (Run)target;
				return;
			case 8:
				this.mSliderSystemVolume = (CustomSlider)target;
				return;
			case 9:
				this.mRestore = (Hyperlink)target;
				this.mRestore.PreviewMouseDown += this.Restore_PreviewMouseDown;
				this.mRestore.MouseEnter += this.Restore_MouseEnter;
				this.mRestore.MouseLeave += this.Restore_MouseLeave;
				this.mRestore.PreviewMouseUp += this.Restore_PreviewMouseUp;
				return;
			case 10:
				this.mLblRestoreDefault = (TextBlock)target;
				return;
			case 11:
				this.mCloseButton = (Button)target;
				this.mCloseButton.Click += this.CloseButton_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000F3B RID: 3899
		private string mLocalizedTextNone = "None";

		// Token: 0x04000F3C RID: 3900
		internal Run mLableStreamAudioSource;

		// Token: 0x04000F3D RID: 3901
		internal Run mLableStreamAudioSourceDetail;

		// Token: 0x04000F3E RID: 3902
		internal Run mLblMicroPhoneSource;

		// Token: 0x04000F3F RID: 3903
		internal CustomComboBox mAudioSources;

		// Token: 0x04000F40 RID: 3904
		internal Run mLblMicrophoneSound;

		// Token: 0x04000F41 RID: 3905
		internal CustomSlider mSliderMicVolume;

		// Token: 0x04000F42 RID: 3906
		internal Run mLblComputerSound;

		// Token: 0x04000F43 RID: 3907
		internal CustomSlider mSliderSystemVolume;

		// Token: 0x04000F44 RID: 3908
		internal Hyperlink mRestore;

		// Token: 0x04000F45 RID: 3909
		internal TextBlock mLblRestoreDefault;

		// Token: 0x04000F46 RID: 3910
		internal Button mCloseButton;

		// Token: 0x04000F47 RID: 3911
		private bool _contentLoaded;
	}
}
