﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000284 RID: 644
	public class NoWifi : UserControl, IComponentConnector
	{
		// Token: 0x0600160A RID: 5642 RVA: 0x0000F578 File Offset: 0x0000D778
		public NoWifi()
		{
			this.InitializeComponent();
			this.InitText();
			base.MouseLeftButtonDown += this.NoWifi_MouseLeftButtonDown;
		}

		// Token: 0x0600160B RID: 5643 RVA: 0x00085AA0 File Offset: 0x00083CA0
		private void InitText()
		{
			BlueStacksUIBinding.Bind(this.mNoWifiLbl, "STRING_NAVIGATE_FAILED");
			BlueStacksUIBinding.Bind(this.mRetryText, "STRING_RETRY", "");
			this.mCloseBtnLink.Inlines.Clear();
			this.mCloseBtnLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_CLOSE", false));
		}

		// Token: 0x0600160C RID: 5644 RVA: 0x0000553B File Offset: 0x0000373B
		private void NoWifi_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x0600160D RID: 5645 RVA: 0x0000F59E File Offset: 0x0000D79E
		private void RetryBtn_MouseEnter(object sender, MouseEventArgs e)
		{
			((Grid)sender).Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#84DBD1"));
		}

		// Token: 0x0600160E RID: 5646 RVA: 0x0000F5BF File Offset: 0x0000D7BF
		private void RetryBtn_MouseDown(object sender, MouseButtonEventArgs e)
		{
			((Grid)sender).Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#C2EDE8"));
		}

		// Token: 0x0600160F RID: 5647 RVA: 0x0000F5E0 File Offset: 0x0000D7E0
		private void RetryBtn_MouseLeave(object sender, MouseEventArgs e)
		{
			((Grid)sender).Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#84D2E4"));
		}

		// Token: 0x06001610 RID: 5648 RVA: 0x0000F59E File Offset: 0x0000D79E
		private void RetryBtn_MouseUp(object sender, MouseButtonEventArgs e)
		{
			((Grid)sender).Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#84DBD1"));
		}

		// Token: 0x06001611 RID: 5649 RVA: 0x00085B00 File Offset: 0x00083D00
		private void RetryBtn_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			string[] array = this.GetParents((DependencyObject)sender).ToArray();
			for (int i = 0; i < array.Length; i++)
			{
				if (!array[i].StartsWith("System"))
				{
					try
					{
						Type.GetType(array[i] + ", " + Assembly.GetEntryAssembly().FullName).GetMethod("HideNoWifiGrid").Invoke(null, null);
						break;
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to call method hidenowifigrid through reflection...Err : " + ex.ToString());
					}
				}
			}
			e.Handled = true;
		}

		// Token: 0x06001612 RID: 5650 RVA: 0x00085B9C File Offset: 0x00083D9C
		private void CloseHyperlink_Clicked(object sender, RoutedEventArgs e)
		{
			string[] array = this.GetParents((DependencyObject)sender).ToArray();
			for (int i = 0; i < array.Length; i++)
			{
				if (!array[i].StartsWith("System"))
				{
					try
					{
						Type.GetType(array[i] + ", " + Assembly.GetEntryAssembly().FullName).GetMethod("CloseButtonClicked").Invoke(null, null);
						break;
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to call method hidenowifigrid through reflection...Err : " + ex.ToString());
					}
				}
			}
			e.Handled = true;
		}

		// Token: 0x06001613 RID: 5651 RVA: 0x00085C38 File Offset: 0x00083E38
		private List<string> GetParents(DependencyObject initial)
		{
			DependencyObject dependencyObject = initial;
			List<string> list = new List<string>();
			while (dependencyObject != null)
			{
				list.Add(dependencyObject.ToString());
				if (dependencyObject is Visual || dependencyObject is Visual3D)
				{
					dependencyObject = VisualTreeHelper.GetParent(dependencyObject);
				}
				else
				{
					dependencyObject = LogicalTreeHelper.GetParent(dependencyObject);
				}
			}
			return list;
		}

		// Token: 0x06001614 RID: 5652 RVA: 0x00085C80 File Offset: 0x00083E80
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/btv/wpffiles/usercontrol/nowifi.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06001615 RID: 5653 RVA: 0x00085CB0 File Offset: 0x00083EB0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mNoWifiImg = (CustomPictureBox)target;
				return;
			case 2:
				this.mNoWifiLbl = (Label)target;
				return;
			case 3:
				this.mRetryBtn = (Grid)target;
				this.mRetryBtn.PreviewMouseLeftButtonUp += this.RetryBtn_PreviewMouseLeftButtonUp;
				this.mRetryBtn.MouseDown += this.RetryBtn_MouseDown;
				this.mRetryBtn.MouseEnter += this.RetryBtn_MouseEnter;
				this.mRetryBtn.MouseLeave += this.RetryBtn_MouseLeave;
				this.mRetryBtn.MouseUp += this.RetryBtn_MouseUp;
				return;
			case 4:
				this.mRetryText = (TextBlock)target;
				return;
			case 5:
				this.mCloseBtnLink = (Hyperlink)target;
				this.mCloseBtnLink.Click += this.CloseHyperlink_Clicked;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000F61 RID: 3937
		internal CustomPictureBox mNoWifiImg;

		// Token: 0x04000F62 RID: 3938
		internal Label mNoWifiLbl;

		// Token: 0x04000F63 RID: 3939
		internal Grid mRetryBtn;

		// Token: 0x04000F64 RID: 3940
		internal TextBlock mRetryText;

		// Token: 0x04000F65 RID: 3941
		internal Hyperlink mCloseBtnLink;

		// Token: 0x04000F66 RID: 3942
		private bool _contentLoaded;
	}
}
