﻿using System;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000252 RID: 594
	public class FilterZipInfo
	{
		// Token: 0x04000E1F RID: 3615
		public string downloadPath;

		// Token: 0x04000E20 RID: 3616
		public int version;

		// Token: 0x04000E21 RID: 3617
		public string url;

		// Token: 0x04000E22 RID: 3618
		public bool deleteDir;

		// Token: 0x04000E23 RID: 3619
		public string deleteDirPath;

		// Token: 0x04000E24 RID: 3620
		public string appPkg;
	}
}
