﻿using System;
using System.Collections.Generic;
using System.Linq;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x0200025D RID: 605
	public class FilterThemeSettings
	{
		// Token: 0x06001498 RID: 5272 RVA: 0x0007EA58 File Offset: 0x0007CC58
		public FilterThemeSettings(string settings)
		{
			Logger.Info("In FilterThemeSettings Constructor");
			JObject jobject = JObject.Parse(settings);
			Logger.Info("reading sidebar cam status");
			if (jobject.Property("webcam") != null && StreamManager.Instance != null && string.Compare(StreamManager.mCamStatus, "true", true) == 0)
			{
				Logger.Info("WebCam status is true");
				this.mIsWebCamOn = true;
			}
			if (jobject.Property("chat") != null && jobject["chat"].ToObject<bool>())
			{
				Logger.Info("Chat status is true");
				this.mIsChatOn = true;
			}
			if (jobject.Property("animate") != null && !jobject["animate"].ToObject<bool>())
			{
				Logger.Info("animate status is false");
				this.mIsAnimate = false;
			}
			foreach (string text in (from p in jobject.Properties()
			select p.Name).ToList<string>())
			{
				if (text.Equals("webcam"))
				{
					this.mOtherFields.Add(text, this.mIsWebCamOn.ToString().ToLower());
				}
				else
				{
					this.mOtherFields.Add(text, jobject[text].ToString());
				}
			}
		}

		// Token: 0x06001499 RID: 5273 RVA: 0x0007EBDC File Offset: 0x0007CDDC
		public string ToJsonString()
		{
			JObject jobject = new JObject();
			foreach (string text in this.mOtherFields.Keys)
			{
				if (!text.Equals("webcam") && !text.Equals("chat") && !text.Equals("animate"))
				{
					jobject.Add(text, this.mOtherFields[text]);
				}
			}
			jobject.Add("webcam", this.mIsWebCamOn);
			jobject.Add("animate", this.mIsAnimate);
			jobject.Add("chat", this.mIsChatOn);
			return jobject.ToString(Formatting.None, new JsonConverter[0]);
		}

		// Token: 0x04000E56 RID: 3670
		public bool mIsWebCamOn;

		// Token: 0x04000E57 RID: 3671
		public bool mIsChatOn;

		// Token: 0x04000E58 RID: 3672
		public bool mIsAnimate = true;

		// Token: 0x04000E59 RID: 3673
		public Dictionary<string, string> mOtherFields = new Dictionary<string, string>();
	}
}
