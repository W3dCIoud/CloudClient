﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000280 RID: 640
	public class CustomComboBox : ComboBox, IComponentConnector, IStyleConnector
	{
		// Token: 0x060015EA RID: 5610 RVA: 0x0000F380 File Offset: 0x0000D580
		public CustomComboBox()
		{
			this.InitializeComponent();
		}

		// Token: 0x060015EB RID: 5611 RVA: 0x000082DD File Offset: 0x000064DD
		private void OnRequestBringIntoView(object sender, RequestBringIntoViewEventArgs e)
		{
			if (Keyboard.IsKeyDown(Key.Down) || Keyboard.IsKeyDown(Key.Up))
			{
				return;
			}
			e.Handled = true;
		}

		// Token: 0x060015EC RID: 5612 RVA: 0x00085654 File Offset: 0x00083854
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/btv/wpffiles/usercontrol/customcombobox.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060015ED RID: 5613 RVA: 0x0000F38E File Offset: 0x0000D58E
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			this._contentLoaded = true;
		}

		// Token: 0x060015EE RID: 5614 RVA: 0x00085684 File Offset: 0x00083884
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				EventSetter eventSetter = new EventSetter();
				eventSetter.Event = FrameworkElement.RequestBringIntoViewEvent;
				eventSetter.Handler = new RequestBringIntoViewEventHandler(this.OnRequestBringIntoView);
				((Style)target).Setters.Add(eventSetter);
			}
		}

		// Token: 0x04000F4E RID: 3918
		private bool _contentLoaded;
	}
}
