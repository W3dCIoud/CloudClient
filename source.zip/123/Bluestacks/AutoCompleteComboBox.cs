﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000052 RID: 82
	public class AutoCompleteComboBox : UserControl, IComponentConnector
	{
		// Token: 0x06000398 RID: 920 RVA: 0x000198E4 File Offset: 0x00017AE4
		public AutoCompleteComboBox()
		{
			this.InitializeComponent();
			this.mAutoComboBox.IsDropDownOpen = false;
			this.mAutoComboBox.Loaded += delegate(object <p0>, RoutedEventArgs <p1>)
			{
				TextBox textBox = this.mAutoComboBox.Template.FindName("PART_EditableTextBox", this.mAutoComboBox) as TextBox;
				if (textBox != null)
				{
					textBox.TextChanged += this.EditTextBox_TextChanged;
				}
			};
			this.mAutoComboBox.DropDownOpened += this.MAutoComboBox_DropDownOpened;
			EventManager.RegisterClassHandler(typeof(TextBox), UIElement.KeyUpEvent, new RoutedEventHandler(this.DeselectText));
		}

		// Token: 0x06000399 RID: 921 RVA: 0x00019964 File Offset: 0x00017B64
		private void DeselectText(object sender, RoutedEventArgs e)
		{
			TextBox textBox = e.OriginalSource as TextBox;
			if (textBox == null)
			{
				return;
			}
			if (textBox.Text.Length >= 2)
			{
				return;
			}
			textBox.SelectionLength = 0;
			textBox.SelectionStart = 1;
		}

		// Token: 0x0600039A RID: 922 RVA: 0x000199A0 File Offset: 0x00017BA0
		private void EditTextBox_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (Keyboard.IsKeyDown(Key.Down))
			{
				e.Handled = true;
				return;
			}
			TextBox textBox = sender as TextBox;
			this.mAutoComboBox_TextChanged(textBox.Text);
		}

		// Token: 0x0600039B RID: 923 RVA: 0x00004686 File Offset: 0x00002886
		private void MAutoComboBox_DropDownOpened(object sender, EventArgs e)
		{
			this.mAutoComboBox.SelectedItem = null;
		}

		// Token: 0x0600039C RID: 924 RVA: 0x000199D4 File Offset: 0x00017BD4
		public void AddItems(string key)
		{
			ComboBoxItem comboBoxItem = new ComboBoxItem();
			comboBoxItem.Content = key;
			this.mAutoComboBox.Items.Add(comboBoxItem);
		}

		// Token: 0x0600039D RID: 925 RVA: 0x00004694 File Offset: 0x00002894
		public void AddSuggestions(List<string> listOfSuggestions)
		{
			this.mListData.Clear();
			this.mListData = listOfSuggestions;
		}

		// Token: 0x0600039E RID: 926 RVA: 0x00019A00 File Offset: 0x00017C00
		private void mAutoComboBox_TextChanged(string msg)
		{
			bool flag = false;
			if (string.IsNullOrEmpty(msg))
			{
				this.mAutoComboBox.IsDropDownOpen = false;
			}
			this.mAutoComboBox.Items.Clear();
			foreach (string text in this.mListData)
			{
				if (text.ToLower().StartsWith(msg.ToLower()))
				{
					this.AddItems(text);
					flag = true;
				}
			}
			if (flag)
			{
				this.mAutoComboBox.IsDropDownOpen = true;
				return;
			}
			this.mAutoComboBox.IsDropDownOpen = false;
		}

		// Token: 0x0600039F RID: 927 RVA: 0x00019AAC File Offset: 0x00017CAC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/autocompletecombobox.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060003A0 RID: 928 RVA: 0x000046A8 File Offset: 0x000028A8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mAutoComboBox = (CustomComboBox)target;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x040001FF RID: 511
		private List<string> mListData = new List<string>();

		// Token: 0x04000200 RID: 512
		internal CustomComboBox mAutoComboBox;

		// Token: 0x04000201 RID: 513
		private bool _contentLoaded;
	}
}
