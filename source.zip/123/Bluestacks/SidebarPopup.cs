﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000F8 RID: 248
	public class SidebarPopup : UserControl, IComponentConnector
	{
		// Token: 0x1700017A RID: 378
		// (get) Token: 0x06000A0E RID: 2574 RVA: 0x00008401 File Offset: 0x00006601
		private int NumColumns
		{
			get
			{
				return this.mMainStackPanel.Children.Count;
			}
		}

		// Token: 0x06000A0F RID: 2575 RVA: 0x00008413 File Offset: 0x00006613
		public SidebarPopup()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000A10 RID: 2576 RVA: 0x00046DAC File Offset: 0x00044FAC
		public void AddElement(SidebarElement element)
		{
			this.RemoveParentIfExists(element);
			if (this.NumColumns == 0)
			{
				this.AddToNewPanel(element);
				return;
			}
			StackPanel stackPanel = this.mMainStackPanel.Children[this.NumColumns - 1] as StackPanel;
			if (stackPanel.Children.Count == 3)
			{
				this.AddToNewPanel(element);
				return;
			}
			stackPanel.Children.Add(element);
		}

		// Token: 0x06000A11 RID: 2577 RVA: 0x00046E14 File Offset: 0x00045014
		private void RemoveParentIfExists(SidebarElement element)
		{
			if (element.Parent != null)
			{
				StackPanel stackPanel = element.Parent as StackPanel;
				if (stackPanel != null)
				{
					stackPanel.Children.Remove(element);
				}
			}
		}

		// Token: 0x06000A12 RID: 2578 RVA: 0x00008421 File Offset: 0x00006621
		private void AddToNewPanel(SidebarElement element)
		{
			this.CreateStackPanel().Children.Add(element);
		}

		// Token: 0x06000A13 RID: 2579 RVA: 0x00046E44 File Offset: 0x00045044
		public SidebarElement PopElement()
		{
			StackPanel stackPanel = this.mMainStackPanel.Children[this.NumColumns - 1] as StackPanel;
			SidebarElement sidebarElement = stackPanel.Children[stackPanel.Children.Count - 1] as SidebarElement;
			stackPanel.Children.Remove(sidebarElement);
			if (stackPanel.Children.Count == 0)
			{
				this.mMainStackPanel.Children.Remove(stackPanel);
			}
			return sidebarElement;
		}

		// Token: 0x06000A14 RID: 2580 RVA: 0x00046EB8 File Offset: 0x000450B8
		private StackPanel CreateStackPanel()
		{
			StackPanel stackPanel = new StackPanel();
			stackPanel.Margin = new Thickness(2.0, 0.0, 2.0, 0.0);
			stackPanel.Orientation = Orientation.Vertical;
			this.mMainStackPanel.Children.Add(stackPanel);
			return stackPanel;
		}

		// Token: 0x06000A15 RID: 2581 RVA: 0x00004BF2 File Offset: 0x00002DF2
		private void SidebarPopup_Loaded(object sender, RoutedEventArgs e)
		{
		}

		// Token: 0x06000A16 RID: 2582 RVA: 0x00046F14 File Offset: 0x00045114
		internal void InitAllElements(IEnumerable<SidebarElement> listOfHiddenElements)
		{
			foreach (SidebarElement sidebarElement in listOfHiddenElements)
			{
				if (sidebarElement.Visibility == Visibility.Visible)
				{
					sidebarElement.Margin = new Thickness(0.0, 2.0, 0.0, 2.0);
					this.AddElement(sidebarElement);
				}
			}
		}

		// Token: 0x06000A17 RID: 2583 RVA: 0x00046F94 File Offset: 0x00045194
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/sidebarpopup.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000A18 RID: 2584 RVA: 0x00046FC4 File Offset: 0x000451C4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((SidebarPopup)target).Loaded += this.SidebarPopup_Loaded;
				return;
			case 2:
				this.mGrid = (Grid)target;
				return;
			case 3:
				this.mMainStackPanel = (StackPanel)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400077F RID: 1919
		private const int NumElementsPerRow = 3;

		// Token: 0x04000780 RID: 1920
		internal Grid mGrid;

		// Token: 0x04000781 RID: 1921
		internal StackPanel mMainStackPanel;

		// Token: 0x04000782 RID: 1922
		private bool _contentLoaded;
	}
}
