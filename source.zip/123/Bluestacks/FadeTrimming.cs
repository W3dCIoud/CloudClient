﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000C8 RID: 200
	public static class FadeTrimming
	{
		// Token: 0x06000801 RID: 2049 RVA: 0x0000731F File Offset: 0x0000551F
		public static bool GetIsEnabled(DependencyObject obj)
		{
			return (bool)obj.GetValue(FadeTrimming.IsEnabledProperty);
		}

		// Token: 0x06000802 RID: 2050 RVA: 0x00007331 File Offset: 0x00005531
		public static void SetIsEnabled(DependencyObject obj, bool value)
		{
			obj.SetValue(FadeTrimming.IsEnabledProperty, value);
		}

		// Token: 0x06000803 RID: 2051 RVA: 0x00007344 File Offset: 0x00005544
		public static void SetIsVerticalFadingEnabled(DependencyObject obj, bool value)
		{
			obj.SetValue(FadeTrimming.IsVerticalFadingEnabledProperty, value);
		}

		// Token: 0x06000804 RID: 2052 RVA: 0x00007357 File Offset: 0x00005557
		private static FadeTrimming.Fader GetFader(DependencyObject obj)
		{
			return (FadeTrimming.Fader)obj.GetValue(FadeTrimming.FaderProperty);
		}

		// Token: 0x06000805 RID: 2053 RVA: 0x00007369 File Offset: 0x00005569
		private static void SetFader(DependencyObject obj, FadeTrimming.Fader value)
		{
			obj.SetValue(FadeTrimming.FaderProperty, value);
		}

		// Token: 0x06000806 RID: 2054 RVA: 0x00032578 File Offset: 0x00030778
		private static void HandleVerticalFadingEnabled(DependencyObject source, DependencyPropertyChangedEventArgs e)
		{
			TextBlock textBlock = source as TextBlock;
			if (textBlock == null)
			{
				return;
			}
			FadeTrimming.Fader fader = FadeTrimming.GetFader(textBlock);
			if (fader != null)
			{
				fader.ToggleVerticalFading((bool)e.NewValue);
			}
		}

		// Token: 0x06000807 RID: 2055 RVA: 0x000325AC File Offset: 0x000307AC
		private static void HandleIsEnabledChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
		{
			TextBlock textBlock = source as TextBlock;
			if (textBlock == null)
			{
				return;
			}
			if ((bool)e.OldValue)
			{
				FadeTrimming.Fader fader = FadeTrimming.GetFader(textBlock);
				if (fader != null)
				{
					fader.Detach();
					FadeTrimming.SetFader(textBlock, null);
				}
				textBlock.Loaded -= FadeTrimming.HandleTextBlockLoaded;
				textBlock.Unloaded -= FadeTrimming.HandleTextBlockUnloaded;
			}
			if ((bool)e.NewValue)
			{
				textBlock.Loaded += FadeTrimming.HandleTextBlockLoaded;
				textBlock.Unloaded += FadeTrimming.HandleTextBlockUnloaded;
				FadeTrimming.Fader fader2 = new FadeTrimming.Fader(textBlock);
				FadeTrimming.SetFader(textBlock, fader2);
				fader2.Attach();
			}
		}

		// Token: 0x06000808 RID: 2056 RVA: 0x00007377 File Offset: 0x00005577
		private static void HandleTextBlockUnloaded(object sender, RoutedEventArgs e)
		{
			FadeTrimming.GetFader(sender as DependencyObject).Detach();
		}

		// Token: 0x06000809 RID: 2057 RVA: 0x00007389 File Offset: 0x00005589
		private static void HandleTextBlockLoaded(object sender, RoutedEventArgs e)
		{
			FadeTrimming.GetFader(sender as DependencyObject).Attach();
		}

		// Token: 0x0600080A RID: 2058 RVA: 0x00032654 File Offset: 0x00030854
		private static bool HorizontalBrushNeedsUpdating(LinearGradientBrush brush, double visibleWidth)
		{
			return brush.EndPoint.X < visibleWidth - 1E-05 || brush.EndPoint.X > visibleWidth + 1E-05;
		}

		// Token: 0x0600080B RID: 2059 RVA: 0x0003269C File Offset: 0x0003089C
		private static bool VerticalBrushNeedsUpdating(LinearGradientBrush brush, double visibleHeight)
		{
			return brush.EndPoint.Y < visibleHeight - 1E-05 || brush.EndPoint.Y > visibleHeight + 1E-05;
		}

		// Token: 0x040005C1 RID: 1473
		private const double Epsilon = 1E-05;

		// Token: 0x040005C2 RID: 1474
		private const double FadeWidth = 10.0;

		// Token: 0x040005C3 RID: 1475
		private const double FadeHeight = 20.0;

		// Token: 0x040005C4 RID: 1476
		public static readonly DependencyProperty IsEnabledProperty = DependencyProperty.RegisterAttached("IsEnabled", typeof(bool), typeof(FadeTrimming), new PropertyMetadata(false, new PropertyChangedCallback(FadeTrimming.HandleIsEnabledChanged)));

		// Token: 0x040005C5 RID: 1477
		private static readonly DependencyProperty FaderProperty = DependencyProperty.RegisterAttached("Fader", typeof(FadeTrimming.Fader), typeof(FadeTrimming), new PropertyMetadata(null));

		// Token: 0x040005C6 RID: 1478
		public static readonly DependencyProperty IsVerticalFadingEnabledProperty = DependencyProperty.RegisterAttached("IsVerticalFadingEnabledProperty", typeof(bool), typeof(FadeTrimming), new PropertyMetadata(false, new PropertyChangedCallback(FadeTrimming.HandleVerticalFadingEnabled)));

		// Token: 0x020000C9 RID: 201
		private class Fader
		{
			// Token: 0x0600080D RID: 2061 RVA: 0x0000739B File Offset: 0x0000559B
			public Fader(TextBlock textBlock)
			{
				this._textBlock = textBlock;
			}

			// Token: 0x0600080E RID: 2062 RVA: 0x00032790 File Offset: 0x00030990
			public void Attach()
			{
				FrameworkElement frameworkElement = VisualTreeHelper.GetParent(this._textBlock) as FrameworkElement;
				if (frameworkElement == null || this._isAttached)
				{
					return;
				}
				frameworkElement.SizeChanged += new SizeChangedEventHandler(this.UpdateForegroundBrush);
				this._textBlock.SizeChanged += new SizeChangedEventHandler(this.UpdateForegroundBrush);
				this._opacityMask = this._textBlock.OpacityMask;
				if (this._verticalFadingEnabled || this._textBlock.TextWrapping == TextWrapping.NoWrap)
				{
					this._textBlock.TextTrimming = TextTrimming.None;
				}
				this.UpdateForegroundBrush(this._textBlock, EventArgs.Empty);
				this._isAttached = true;
			}

			// Token: 0x0600080F RID: 2063 RVA: 0x00032830 File Offset: 0x00030A30
			public void Detach()
			{
				this._textBlock.SizeChanged -= new SizeChangedEventHandler(this.UpdateForegroundBrush);
				FrameworkElement frameworkElement = VisualTreeHelper.GetParent(this._textBlock) as FrameworkElement;
				if (frameworkElement != null)
				{
					frameworkElement.SizeChanged -= new SizeChangedEventHandler(this.UpdateForegroundBrush);
				}
				this._textBlock.OpacityMask = this._opacityMask;
				this._isAttached = false;
			}

			// Token: 0x06000810 RID: 2064 RVA: 0x000073AA File Offset: 0x000055AA
			public void ToggleVerticalFading(bool newValue)
			{
				this._verticalFadingEnabled = newValue;
				this.UpdateForegroundBrush(this._textBlock, EventArgs.Empty);
			}

			// Token: 0x06000811 RID: 2065 RVA: 0x00032894 File Offset: 0x00030A94
			private void UpdateForegroundBrush(object sender, EventArgs e)
			{
				Geometry layoutClip = LayoutInformation.GetLayoutClip(this._textBlock);
				bool flag = layoutClip != null && ((this._textBlock.TextWrapping == TextWrapping.NoWrap && layoutClip.Bounds.Width > 0.0 && layoutClip.Bounds.Width < this._textBlock.ActualWidth) || (this._verticalFadingEnabled && this._textBlock.TextWrapping == TextWrapping.Wrap && layoutClip.Bounds.Height > 0.0 && layoutClip.Bounds.Height < this._textBlock.ActualHeight));
				if (this._isClipped && !flag)
				{
					this._textBlock.OpacityMask = this._opacityMask;
					this._brush = null;
					this._isClipped = false;
				}
				if (flag)
				{
					double width = layoutClip.Bounds.Width;
					double height = layoutClip.Bounds.Height;
					bool flag2 = this._textBlock.TextWrapping == TextWrapping.Wrap;
					if (this._brush == null)
					{
						this._brush = (flag2 ? this.GetVerticalClipBrush(height) : this.GetHorizontalClipBrush(width));
						this._textBlock.OpacityMask = this._brush;
					}
					else if (flag2 && FadeTrimming.VerticalBrushNeedsUpdating(this._brush, height))
					{
						this._brush.EndPoint = new Point(0.0, height);
						this._brush.GradientStops[1].Offset = (height - 20.0) / height;
					}
					else if (!flag2 && FadeTrimming.HorizontalBrushNeedsUpdating(this._brush, width))
					{
						this._brush.EndPoint = new Point(width, 0.0);
						this._brush.GradientStops[1].Offset = (width - 10.0) / width;
					}
					this._isClipped = true;
				}
			}

			// Token: 0x06000812 RID: 2066 RVA: 0x00032A8C File Offset: 0x00030C8C
			private LinearGradientBrush GetHorizontalClipBrush(double visibleWidth)
			{
				return new LinearGradientBrush
				{
					MappingMode = BrushMappingMode.Absolute,
					StartPoint = new Point(0.0, 0.0),
					EndPoint = new Point(visibleWidth, 0.0),
					GradientStops = 
					{
						new GradientStop
						{
							Color = Colors.Black,
							Offset = 0.0
						},
						new GradientStop
						{
							Color = Colors.Black,
							Offset = (visibleWidth - 10.0) / visibleWidth
						},
						new GradientStop
						{
							Color = Colors.Transparent,
							Offset = 1.0
						}
					}
				};
			}

			// Token: 0x06000813 RID: 2067 RVA: 0x00032B5C File Offset: 0x00030D5C
			private LinearGradientBrush GetVerticalClipBrush(double visibleHeight)
			{
				return new LinearGradientBrush
				{
					MappingMode = BrushMappingMode.Absolute,
					StartPoint = new Point(0.0, 0.0),
					EndPoint = new Point(0.0, visibleHeight),
					GradientStops = 
					{
						new GradientStop
						{
							Color = Colors.Black,
							Offset = 0.0
						},
						new GradientStop
						{
							Color = Colors.Black,
							Offset = (visibleHeight - 20.0) / visibleHeight
						},
						new GradientStop
						{
							Color = Colors.Transparent,
							Offset = 1.0
						}
					}
				};
			}

			// Token: 0x040005C7 RID: 1479
			private readonly TextBlock _textBlock;

			// Token: 0x040005C8 RID: 1480
			private bool _isAttached;

			// Token: 0x040005C9 RID: 1481
			private LinearGradientBrush _brush;

			// Token: 0x040005CA RID: 1482
			private Brush _opacityMask;

			// Token: 0x040005CB RID: 1483
			private bool _isClipped;

			// Token: 0x040005CC RID: 1484
			private bool _verticalFadingEnabled;
		}
	}
}
