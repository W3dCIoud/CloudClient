﻿using System;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Forms;
using BlueStacks.Common;
using Microsoft.Win32;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200014A RID: 330
	public static class MiscUtils
	{
		// Token: 0x170001D5 RID: 469
		// (get) Token: 0x06000CF9 RID: 3321 RVA: 0x0000A10B File Offset: 0x0000830B
		private static SerialWorkQueue FocusWorker
		{
			get
			{
				if (MiscUtils.sFocusWorker == null)
				{
					MiscUtils.sFocusWorker = new SerialWorkQueue();
					MiscUtils.sFocusWorker.Start();
				}
				return MiscUtils.sFocusWorker;
			}
		}

		// Token: 0x06000CFA RID: 3322 RVA: 0x00055C94 File Offset: 0x00053E94
		public static void SetFocusAsync(UIElement control, int delay = 0)
		{
			MiscUtils.FocusWorker.Enqueue(delegate
			{
				try
				{
					int i = 0;
					if (delay > 0)
					{
						Thread.Sleep(delay);
					}
					while (10 > i)
					{
						control.Dispatcher.Invoke(new Action(delegate()
						{
							if (control.Focus())
							{
								i = 11;
							}
						}), new object[0]);
						int j = i;
						i = j + 1;
						Thread.Sleep(10);
					}
				}
				catch (Exception ex)
				{
					Logger.Info("Error setting focus on control" + ex.ToString());
				}
			});
		}

		// Token: 0x06000CFB RID: 3323 RVA: 0x00055CCC File Offset: 0x00053ECC
		public static void GetWindowWidthAndHeight(out int width, out int height)
		{
			int width2 = Screen.PrimaryScreen.Bounds.Width;
			int height2 = Screen.PrimaryScreen.Bounds.Height;
			if (width2 > 2560 && height2 > 1440)
			{
				width = 2560;
				height = 1440;
				return;
			}
			if (width2 > 1920 && height2 > 1080)
			{
				width = 1920;
				height = 1080;
				return;
			}
			if (width2 > 1600 && height2 > 900)
			{
				width = 1600;
				height = 900;
				return;
			}
			if (width2 > 1280 && height2 > 720)
			{
				width = 1280;
				height = 720;
				return;
			}
			width = 960;
			height = 540;
		}

		// Token: 0x06000CFC RID: 3324 RVA: 0x00055D8C File Offset: 0x00053F8C
		private static bool IsParametersValid(Window window)
		{
			try
			{
				if (window.Left < 0.0 || window.Left > SystemParameters.VirtualScreenWidth || window.Top < 0.0 || window.Top > SystemParameters.VirtualScreenHeight)
				{
					return false;
				}
				if (SystemParameters.VirtualScreenWidth - window.Left < window.Width / 10.0 || SystemParameters.VirtualScreenHeight - window.Top < window.Height / 10.0)
				{
					return false;
				}
				double screenWidth = (double)RegistryManager.Instance.ScreenWidth;
				int screenHeight = RegistryManager.Instance.ScreenHeight;
				if (Math.Abs(screenWidth - SystemParameters.VirtualScreenWidth) > 100.0 || Math.Abs((double)screenHeight - SystemParameters.VirtualScreenHeight) > 100.0)
				{
					return false;
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Exception calculating size" + ex.ToString());
				return false;
			}
			return true;
		}

		// Token: 0x06000CFD RID: 3325 RVA: 0x00055E94 File Offset: 0x00054094
		private static void SaveControlSize(double width, double height, string prefix)
		{
			RegistryKey registryKey = Registry.LocalMachine.CreateSubKey(RegistryManager.Instance.ClientBaseKeyPath);
			registryKey.SetValue(prefix + "Width", width, RegistryValueKind.DWord);
			registryKey.SetValue(prefix + "Height", height, RegistryValueKind.DWord);
			registryKey.Close();
		}

		// Token: 0x06000CFE RID: 3326 RVA: 0x00055EEC File Offset: 0x000540EC
		public static void SetWindowSizeAndLocation(Window window, string prefix, bool isGMWindow = false)
		{
			try
			{
				double aspectRatio = 1.7777777777777777;
				bool flag = true;
				RegistryKey registryKey = Registry.LocalMachine.CreateSubKey(RegistryManager.Instance.ClientBaseKeyPath);
				if ((int)registryKey.GetValue(prefix + "Width", -2147483648) != -2147483648)
				{
					try
					{
						window.Width = (double)((int)registryKey.GetValue(prefix + "Width"));
						window.Height = (double)((int)registryKey.GetValue(prefix + "Height"));
						RegistryKey registryKey2 = Registry.LocalMachine.CreateSubKey(RegistryManager.Instance.ClientBaseKeyPath);
						window.Left = (double)((int)registryKey2.GetValue(prefix + "Left"));
						window.Top = (double)((int)registryKey2.GetValue(prefix + "Top"));
						flag = false;
						if (!MiscUtils.IsParametersValid(window))
						{
							flag = true;
						}
					}
					catch (Exception ex)
					{
						Logger.Info("Exception in geting value from reg" + ex.ToString());
						flag = true;
					}
				}
				if (flag)
				{
					double num;
					double num2;
					double num3;
					WpfUtils.GetDefaultSize(out num, out num2, out num3, aspectRatio, isGMWindow);
					double left = num3 + num;
					double top = (double)((int)(SystemParameters.PrimaryScreenHeight - num2) / 2);
					if (isGMWindow)
					{
						window.Left = num3;
						window.Top = top;
						window.Height = num2;
						window.Width = num;
						MiscUtils.SaveControlSize(num, num2, "DefaultGM");
					}
					else
					{
						window.Left = left;
						window.Top = top;
						window.Height = num2;
						window.Width = (window.Height - 33.0) / 27.0 * 16.0;
						if (window.Left + window.Width > SystemParameters.PrimaryScreenWidth)
						{
							window.Left = SystemParameters.PrimaryScreenWidth - window.Width - 20.0;
						}
					}
				}
			}
			catch (Exception ex2)
			{
				Logger.Info("Exception getting size" + ex2.ToString());
			}
		}

		// Token: 0x06000CFF RID: 3327 RVA: 0x00056114 File Offset: 0x00054314
		public static int Extract7Zip(string zipFilePath, string extractDirectory)
		{
			string cmd = Path.Combine(RegistryStrings.InstallDir, "7zr.exe");
			if (!Directory.Exists(extractDirectory))
			{
				Directory.CreateDirectory(extractDirectory);
			}
			string args = string.Format("x \"{0}\" -o\"{1}\" -aoa", zipFilePath, extractDirectory);
			return RunCommand.RunCmd(cmd, args, false, true, false, 0).ExitCode;
		}

		// Token: 0x06000D00 RID: 3328 RVA: 0x0005615C File Offset: 0x0005435C
		public static void GetStreamWidthAndHeight(int sWidth, int sHeight, out int width, out int height)
		{
			if (RegistryManager.Instance.StreamingResolution != 0)
			{
				height = RegistryManager.Instance.StreamingResolution;
				width = height / 9 * 16;
			}
			else if (sWidth >= 1920 && sHeight >= 1080)
			{
				width = 1280;
				height = 720;
			}
			else
			{
				width = 960;
				height = 540;
			}
			height = Utils.GetInt(RegistryManager.Instance.FrontendHeight, height);
			width = Utils.GetInt(RegistryManager.Instance.FrontendWidth, width);
		}

		// Token: 0x0400095C RID: 2396
		private const int TextBoxFoxusAttemts = 10;

		// Token: 0x0400095D RID: 2397
		private static SerialWorkQueue sFocusWorker;
	}
}
