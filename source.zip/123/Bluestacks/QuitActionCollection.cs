﻿using System;
using System.Collections.Generic;
using System.IO;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000044 RID: 68
	public class QuitActionCollection
	{
		// Token: 0x1700011E RID: 286
		// (get) Token: 0x06000342 RID: 834 RVA: 0x000182C0 File Offset: 0x000164C0
		public static Dictionary<QuitActionItem, Dictionary<QuitActionItemProperty, string>> Actions
		{
			get
			{
				if (QuitActionCollection.sQuitActionCollection == null)
				{
					object obj = QuitActionCollection.syncRoot;
					lock (obj)
					{
						if (QuitActionCollection.sQuitActionCollection == null)
						{
							QuitActionCollection.InitDictionary();
						}
					}
				}
				return QuitActionCollection.sQuitActionCollection;
			}
		}

		// Token: 0x06000343 RID: 835 RVA: 0x0001830C File Offset: 0x0001650C
		private static void InitDictionary()
		{
			Dictionary<QuitActionItem, Dictionary<QuitActionItemProperty, string>> dictionary = new Dictionary<QuitActionItem, Dictionary<QuitActionItemProperty, string>>();
			foreach (object obj in Enum.GetValues(typeof(QuitActionItem)))
			{
				QuitActionItem key = (QuitActionItem)obj;
				Dictionary<QuitActionItemProperty, string> dictionary2 = new Dictionary<QuitActionItemProperty, string>();
				switch (key)
				{
				case QuitActionItem.None:
					continue;
				case QuitActionItem.StuckAtBoot:
					dictionary2[QuitActionItemProperty.ImageName] = "clock_icon";
					dictionary2[QuitActionItemProperty.BodyText] = LocaleStrings.GetLocalizedString("STRING_STUCK_AT_BOOT_SCREEN", false);
					dictionary2[QuitActionItemProperty.CallToAction] = QuitActionItemCTA.OpenLinkInBrowser.ToString();
					dictionary2[QuitActionItemProperty.ActionText] = LocaleStrings.GetLocalizedString("STRING_SEE_SOLUTION", false);
					dictionary2[QuitActionItemProperty.ActionValue] = WebHelper.GetUrlWithParams("https://cloud.bluestacks.com/bs3/page/stuck_at_boot");
					dictionary2[QuitActionItemProperty.StatEventName] = "click_action_stuck_at_boot";
					break;
				case QuitActionItem.SomethingElseWrong:
					dictionary2[QuitActionItemProperty.ImageName] = "support_icon";
					dictionary2[QuitActionItemProperty.BodyText] = LocaleStrings.GetLocalizedString("STRING_SOMETHING_ELSE_WENT_WRONG", false);
					dictionary2[QuitActionItemProperty.CallToAction] = QuitActionItemCTA.OpenApplication.ToString();
					dictionary2[QuitActionItemProperty.ActionText] = LocaleStrings.GetLocalizedString("STRING_REPORT_A_PROBLEM", false);
					dictionary2[QuitActionItemProperty.ActionValue] = Path.Combine(RegistryStrings.InstallDir, "HD-LogCollector.exe");
					dictionary2[QuitActionItemProperty.StatEventName] = "click_action_support";
					break;
				case QuitActionItem.SlowPerformance:
					dictionary2[QuitActionItemProperty.ImageName] = "rocket";
					dictionary2[QuitActionItemProperty.BodyText] = LocaleStrings.GetLocalizedString("STRING_SLOW_PERFORMANCE", false);
					dictionary2[QuitActionItemProperty.CallToAction] = QuitActionItemCTA.OpenLinkInBrowser.ToString();
					dictionary2[QuitActionItemProperty.ActionText] = LocaleStrings.GetLocalizedString("STRING_SEE_SOLUTION", false);
					dictionary2[QuitActionItemProperty.ActionValue] = WebHelper.GetUrlWithParams("https://cloud.bluestacks.com/bs3/page/enhance_performance");
					dictionary2[QuitActionItemProperty.StatEventName] = "click_action_enhance_performance";
					break;
				case QuitActionItem.WhyGoogleAccount:
					dictionary2[QuitActionItemProperty.ImageName] = "google_white_icon";
					dictionary2[QuitActionItemProperty.BodyText] = LocaleStrings.GetLocalizedString("STRING_WHY_GOOGLE_ACCOUNT", false);
					dictionary2[QuitActionItemProperty.CallToAction] = QuitActionItemCTA.OpenLinkInBrowser.ToString();
					dictionary2[QuitActionItemProperty.ActionText] = LocaleStrings.GetLocalizedString("STRING_SEE_SOLUTION", false);
					dictionary2[QuitActionItemProperty.ActionValue] = WebHelper.GetUrlWithParams("https://cloud.bluestacks.com/bs3/page/why_google");
					dictionary2[QuitActionItemProperty.StatEventName] = "click_action_why_google";
					break;
				case QuitActionItem.TroubleSigningIn:
					dictionary2[QuitActionItemProperty.ImageName] = "performance_icon";
					dictionary2[QuitActionItemProperty.BodyText] = LocaleStrings.GetLocalizedString("STRING_TROUBLE_SIGNING_IN", false);
					dictionary2[QuitActionItemProperty.CallToAction] = QuitActionItemCTA.OpenLinkInBrowser.ToString();
					dictionary2[QuitActionItemProperty.ActionText] = LocaleStrings.GetLocalizedString("STRING_SEE_SOLUTION", false);
					dictionary2[QuitActionItemProperty.ActionValue] = WebHelper.GetUrlWithParams("https://cloud.bluestacks.com/bs3/page/trouble_signing");
					dictionary2[QuitActionItemProperty.StatEventName] = "click_action_trouble_signing";
					break;
				}
				dictionary[key] = dictionary2;
			}
			QuitActionCollection.sQuitActionCollection = dictionary;
		}

		// Token: 0x040001CA RID: 458
		private static Dictionary<QuitActionItem, Dictionary<QuitActionItemProperty, string>> sQuitActionCollection = null;

		// Token: 0x040001CB RID: 459
		private static readonly object syncRoot = new object();
	}
}
