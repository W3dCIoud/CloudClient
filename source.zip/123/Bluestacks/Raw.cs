﻿using System;

// Token: 0x0200000D RID: 13
[Serializable]
public class Raw : IMAction
{
	// Token: 0x17000077 RID: 119
	// (get) Token: 0x060000FB RID: 251 RVA: 0x00002A82 File Offset: 0x00000C82
	// (set) Token: 0x060000FC RID: 252 RVA: 0x00002A8A File Offset: 0x00000C8A
	public string Key
	{
		get
		{
			return this.mKey;
		}
		set
		{
			this.mKey = value;
		}
	}

	// Token: 0x17000078 RID: 120
	// (get) Token: 0x060000FD RID: 253 RVA: 0x00002A93 File Offset: 0x00000C93
	// (set) Token: 0x060000FE RID: 254 RVA: 0x00002A9B File Offset: 0x00000C9B
	public object Sequence
	{
		get
		{
			return this.mSequence;
		}
		set
		{
			this.mSequence = value;
		}
	}

	// Token: 0x0400007A RID: 122
	private string mKey;

	// Token: 0x0400007B RID: 123
	private object mSequence;
}
