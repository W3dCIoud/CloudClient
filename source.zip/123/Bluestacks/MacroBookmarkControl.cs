﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000060 RID: 96
	public class MacroBookmarkControl : UserControl, IComponentConnector
	{
		// Token: 0x06000406 RID: 1030 RVA: 0x0001B7C4 File Offset: 0x000199C4
		public MacroBookmarkControl(IMControlScheme scheme, MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			this.mSchemeName.Text = scheme.Name;
			if (scheme.Selected)
			{
				this.mCheckbox.ImageName = "radio_selected";
				BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
			}
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x00004B27 File Offset: 0x00002D27
		private void UserControl_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x06000408 RID: 1032 RVA: 0x0001B820 File Offset: 0x00019A20
		private void UserControl_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme != null && this.mSchemeName.Text != this.ParentWindow.SelectedConfig.SelectedControlScheme.Name)
			{
				BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "ComboBoxBackgroundColor");
			}
		}

		// Token: 0x06000409 RID: 1033 RVA: 0x0001B878 File Offset: 0x00019A78
		private void UserControl_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.mCheckbox.ImageName == "radio_unselected")
			{
				foreach (object obj in this.ParentWindow.mSidebar.mBookmarkedSchemesStackPanel.Children)
				{
					MacroBookmarkControl macroBookmarkControl = (MacroBookmarkControl)obj;
					macroBookmarkControl.mCheckbox.ImageName = "radio_unselected";
					BlueStacksUIBinding.BindColor(macroBookmarkControl, Control.BackgroundProperty, "ComboBoxBackgroundColor");
				}
				this.mCheckbox.ImageName = "radio_selected";
				BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
				this.ParentWindow.SelectedConfig.SelectedControlScheme.Selected = false;
				IMControlScheme imcontrolScheme = null;
				foreach (IMControlScheme imcontrolScheme2 in this.ParentWindow.SelectedConfig.ControlSchemes)
				{
					if (imcontrolScheme2.Name == this.mSchemeName.Text)
					{
						imcontrolScheme = imcontrolScheme2;
						break;
					}
				}
				imcontrolScheme.Selected = true;
				this.ParentWindow.SelectedConfig.SelectedControlScheme = imcontrolScheme;
				KeymapCanvasWindow.sIsDirty = true;
				KMManager.SaveIMActions(false, false);
				if (RegistryManager.Instance.ShowKeyControlsOverlay)
				{
					KMManager.ShowOverlayWindow(this.ParentWindow, true, true);
				}
				BlueStacksUIUtils.RefreshKeyMap(KMManager.sPackageName);
			}
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x0001B9F8 File Offset: 0x00019BF8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/macrobookmarkcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x0001BA28 File Offset: 0x00019C28
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((MacroBookmarkControl)target).MouseEnter += this.UserControl_MouseEnter;
				((MacroBookmarkControl)target).MouseLeave += this.UserControl_MouseLeave;
				((MacroBookmarkControl)target).MouseDown += this.UserControl_PreviewMouseDown;
				return;
			case 2:
				this.mCheckbox = (CustomPictureBox)target;
				return;
			case 3:
				this.mSchemeName = (CustomTextBox)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000254 RID: 596
		private MainWindow ParentWindow;

		// Token: 0x04000255 RID: 597
		internal CustomPictureBox mCheckbox;

		// Token: 0x04000256 RID: 598
		internal CustomTextBox mSchemeName;

		// Token: 0x04000257 RID: 599
		private bool _contentLoaded;
	}
}
