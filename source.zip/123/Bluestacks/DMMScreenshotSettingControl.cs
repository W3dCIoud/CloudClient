﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000B5 RID: 181
	public class DMMScreenshotSettingControl : UserControl, IComponentConnector
	{
		// Token: 0x0600075A RID: 1882 RVA: 0x00006BA1 File Offset: 0x00004DA1
		public DMMScreenshotSettingControl(MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			base.Visibility = Visibility.Hidden;
			this.mChooseFolderTextBlock.Text = RegistryManager.Instance.ScreenShotsPath;
		}

		// Token: 0x0600075B RID: 1883 RVA: 0x00006BD2 File Offset: 0x00004DD2
		private void ChooseScreenshotFolder_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.DMMScreenshotHandler();
			this.mChooseFolderTextBlock.Text = RegistryManager.Instance.ScreenShotsPath;
		}

		// Token: 0x0600075C RID: 1884 RVA: 0x0002E0E4 File Offset: 0x0002C2E4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/dmmscreenshotsettingcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600075D RID: 1885 RVA: 0x00006BF9 File Offset: 0x00004DF9
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mChooseFolderTextBlock = (TextBox)target;
				return;
			}
			if (connectionId != 2)
			{
				this._contentLoaded = true;
				return;
			}
			((Grid)target).PreviewMouseLeftButtonUp += this.ChooseScreenshotFolder_MouseLeftButtonUp;
		}

		// Token: 0x04000509 RID: 1289
		private MainWindow ParentWindow;

		// Token: 0x0400050A RID: 1290
		internal TextBox mChooseFolderTextBlock;

		// Token: 0x0400050B RID: 1291
		private bool _contentLoaded;
	}
}
