﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000042 RID: 66
	public enum QuitActionItemCTA
	{
		// Token: 0x040001C1 RID: 449
		OpenLinkInBrowser,
		// Token: 0x040001C2 RID: 450
		OpenApplication
	}
}
