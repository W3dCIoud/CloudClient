﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000045 RID: 69
	public enum SecurityBreach
	{
		// Token: 0x040001CD RID: 461
		SCRIPT_TOOLS,
		// Token: 0x040001CE RID: 462
		DEVICE_PROBED,
		// Token: 0x040001CF RID: 463
		DEVICE_ROOTED,
		// Token: 0x040001D0 RID: 464
		DEVICE_PROFILE_CHANGED,
		// Token: 0x040001D1 RID: 465
		SYNTHETIC_INPUT
	}
}
