﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000182 RID: 386
	internal class DownloadInstallApk
	{
		// Token: 0x06000E5A RID: 3674 RVA: 0x0000AA55 File Offset: 0x00008C55
		public DownloadInstallApk(MainWindow mainWindow)
		{
			this.ParentWindow = mainWindow;
		}

		// Token: 0x06000E5B RID: 3675 RVA: 0x0000AA64 File Offset: 0x00008C64
		public static SerialWorkQueue SerialWorkQueueInstaller(string vmName)
		{
			if (!DownloadInstallApk.mSerialQueue.ContainsKey(vmName))
			{
				DownloadInstallApk.mSerialQueue[vmName] = new SerialWorkQueue();
			}
			return DownloadInstallApk.mSerialQueue[vmName];
		}

		// Token: 0x06000E5C RID: 3676 RVA: 0x0005C2A8 File Offset: 0x0005A4A8
		internal void DownloadAndInstallAppFromJson(string campaignJson, string source)
		{
			try
			{
				JObject resJson = JObject.Parse(campaignJson);
				string iconUrl = "";
				string appName = "";
				string apkUrl = "";
				string package = "";
				resJson.AssignIfContains("app_icon_url", delegate(string x)
				{
					iconUrl = x.Trim();
				});
				resJson.AssignIfContains("app_name", delegate(string x)
				{
					appName = x.Trim();
				});
				resJson.AssignIfContains("app_url", delegate(string x)
				{
					apkUrl = x.Trim();
				});
				resJson.AssignIfContains("app_pkg", delegate(string x)
				{
					package = x.Trim();
				});
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					if (string.IsNullOrEmpty(apkUrl))
					{
						this.ParentWindow.mWelcomeTab.mFrontendPopupControl.Init(package, appName, PlayStoreAction.OpenApp, false);
						return;
					}
					this.DownloadAndInstallApp(iconUrl, appName, apkUrl, package, true, true, "");
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Info("Error in Fle. Json String : " + campaignJson + "Error: " + ex.ToString());
			}
		}

		// Token: 0x06000E5D RID: 3677 RVA: 0x0005C3A8 File Offset: 0x0005A5A8
		internal void DownloadAndInstallApp(string iconUrl, string appName, string apkUrl, string packageName, bool isLaunchAfterInstall, bool isDeleteApk, string timestamp = "")
		{
			if (this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon(packageName) == null || this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon(packageName).IsAppSuggestionActive)
			{
				if (!string.IsNullOrEmpty(apkUrl))
				{
					this.DownloadApk(iconUrl, appName, apkUrl, packageName, isLaunchAfterInstall, isDeleteApk, timestamp);
				}
				return;
			}
			if (!this.ParentWindow.mAppHandler.IsAppInstalled(packageName))
			{
				this.ParentWindow.mTopBar.mAppTabButtons.GoToTab("Home", true, false);
				return;
			}
			if (string.IsNullOrEmpty(timestamp))
			{
				this.ParentWindow.mAppHandler.SendRunAppRequestAsync(packageName, "", false);
				return;
			}
			bool flag = true;
			DateTime t = DateTime.Parse(timestamp);
			DateTime t2 = DateTime.MaxValue;
			if (this.ParentWindow.mAppHandler.mCdnAppdict.ContainsKey(packageName))
			{
				t2 = this.ParentWindow.mAppHandler.mCdnAppdict[packageName];
				if (t <= t2)
				{
					flag = false;
				}
			}
			if (flag)
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_INSTALL_UPDATE", "");
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_APP_UPGRADE", "");
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_YES", delegate(object sender1, EventArgs e1)
				{
					this.DownloadApk(iconUrl, appName, apkUrl, packageName, isLaunchAfterInstall, isDeleteApk, timestamp);
				}, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, "STRING_NO", delegate(object sender1, EventArgs e1)
				{
					this.ParentWindow.mAppHandler.SendRunAppRequestAsync(packageName, "", false);
				}, null, false, null);
				customMessageWindow.Owner = this.ParentWindow;
				customMessageWindow.ShowDialog();
				return;
			}
			this.ParentWindow.mAppHandler.SendRunAppRequestAsync(packageName, "", false);
		}

		// Token: 0x06000E5E RID: 3678 RVA: 0x0005C5D0 File Offset: 0x0005A7D0
		internal void DownloadApk(string iconUrl, string appName, string apkUrl, string packageName, bool isLaunchAfterInstall, bool isDeleteApk, string timestamp)
		{
			Utils.TinyDownloader(iconUrl, packageName + ".png", "", false);
			this.ParentWindow.mWelcomeTab.mHomeApp.AddAppIcon(packageName, appName, apkUrl, this);
			this.DownloadApk(apkUrl, packageName, isLaunchAfterInstall, isDeleteApk, timestamp);
		}

		// Token: 0x06000E5F RID: 3679 RVA: 0x0000AA8E File Offset: 0x00008C8E
		internal static string DownloadIcon(string packageName)
		{
			return Utils.DownloadIcon(packageName, "", false);
		}

		// Token: 0x06000E60 RID: 3680 RVA: 0x0005C620 File Offset: 0x0005A820
		public void DownloadApk(string apkUrl, string packageName, bool isLaunchAfterInstall, bool isDeleteApk, string timestamp = "")
		{
			string apkUrl2 = apkUrl;
			if (apkUrl == null)
			{
				return;
			}
			if (this.IsContainsGoogleAdId(apkUrl2))
			{
				apkUrl = this.AddGoogleAdidWithApk(apkUrl2);
			}
			apkUrl = BlueStacksUIUtils.GetFinalRedirectedUrl(apkUrl);
			if (apkUrl == null)
			{
				return;
			}
			string input = packageName + ".apk";
			string text = Path.Combine(RegistryStrings.DataDir, "DownloadedApk");
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
			string path = Regex.Replace(input, "[\\x22\\\\\\/:*?|<>]", " ");
			string apkFilePath = Path.Combine(text, path);
			Logger.Info("Downloading Apk file to: " + apkFilePath);
			this.ParentWindow.mWelcomeTab.mHomeApp.DownloadStarted(packageName);
			ClientStats.SendClientStatsAsync("download", "unknown", "app_install", packageName, "", "");
			this.mDownloadThread = new Thread(delegate()
			{
				this.mIsDownloading = true;
				this.mDownloader = new LegacyDownloader(3, apkUrl, apkFilePath);
				this.mDownloader.Download(delegate(int percent)
				{
					this.ParentWindow.mWelcomeTab.mHomeApp.UpdateAppDownloadProgress(packageName, percent);
					this.mDownloadPercent = percent;
				}, delegate(string filePath)
				{
					ClientStats.SendClientStatsAsync("download", "success", "app_install", packageName, "", "");
					this.mIsDownloading = false;
					this.ParentWindow.mWelcomeTab.mHomeApp.DownloadCompleted(packageName, filePath);
					this.InstallApk(packageName, filePath, isLaunchAfterInstall, isDeleteApk, timestamp);
					DownloadInstallApk.sDownloadedApkList.Add(packageName);
				}, delegate(Exception ex)
				{
					ClientStats.SendClientStatsAsync("download", "fail", "app_install", packageName, "", "");
					this.ParentWindow.mWelcomeTab.mHomeApp.DownloadFailed(packageName);
					Logger.Error("Failed to download file: {0}. err: {1}", new object[]
					{
						apkFilePath,
						ex.Message
					});
				}, null, null, null);
			});
			this.mDownloadThread.IsBackground = true;
			this.mDownloadThread.Start();
		}

		// Token: 0x06000E61 RID: 3681 RVA: 0x0005C770 File Offset: 0x0005A970
		private string AddGoogleAdidWithApk(string apkUrl)
		{
			Logger.Info("In AddGoogleAdidWithApk");
			string newValue = "google_aid=00000000-0000-0000-0000-000000000000";
			string result = "";
			try
			{
				JObject jobject = JObject.Parse(HTTPUtils.SendRequestToGuest("getGoogleAdID", null, this.ParentWindow.mVmName, 0, null, false, 1, 0));
				if (jobject["result"].ToString() == "ok")
				{
					string arg = jobject["googleadid"].ToString();
					string newValue2 = string.Format("google_aid={0}", arg);
					result = apkUrl.Replace("google_aid={google_aid}", newValue2);
				}
				else
				{
					result = apkUrl.Replace("google_aid={google_aid}", newValue);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in adding google adId" + ex.ToString());
				result = apkUrl.Replace("google_aid={google_aid}", newValue);
			}
			return result;
		}

		// Token: 0x06000E62 RID: 3682 RVA: 0x0000AA9C File Offset: 0x00008C9C
		private bool IsContainsGoogleAdId(string apkUrl)
		{
			return apkUrl.ToLower().Contains("google_aid={google_aid}");
		}

		// Token: 0x06000E63 RID: 3683 RVA: 0x0005C848 File Offset: 0x0005AA48
		internal void AbortApkDownload(string packageName)
		{
			ClientStats.SendClientStatsAsync("download", "cancel", "app_install", packageName, "", "");
			if (this.mDownloader != null)
			{
				this.mDownloader.AbortDownload();
			}
			if (this.mDownloadThread != null)
			{
				this.mDownloadThread.Abort();
			}
		}

		// Token: 0x06000E64 RID: 3684 RVA: 0x0005C89C File Offset: 0x0005AA9C
		internal void ChooseAndInstallApk()
		{
			OpenFileDialog openFileDialog = new OpenFileDialog();
			openFileDialog.Filter = "Android Files (*.apk, *.xapk)|*.apk; *.xapk";
			openFileDialog.Multiselect = true;
			openFileDialog.RestoreDirectory = true;
			if (openFileDialog.ShowDialog() == DialogResult.OK)
			{
				foreach (string text in openFileDialog.FileNames)
				{
					Logger.Info("File Selected : " + text);
					this.InstallApk(text, true);
				}
			}
		}

		// Token: 0x06000E65 RID: 3685 RVA: 0x0005C904 File Offset: 0x0005AB04
		internal void InstallApk(string apkPath, bool addToChooseApkList = false)
		{
			Logger.Info("Console: Installing apk: {0}", new object[]
			{
				apkPath
			});
			string package = string.Empty;
			string appName = string.Empty;
			if (string.Equals(Path.GetExtension(apkPath), ".xapk", StringComparison.InvariantCultureIgnoreCase))
			{
				JToken jtoken = Utils.ExtractInfoFromXapk(apkPath);
				if (jtoken != null)
				{
					package = jtoken.GetValue("package_name");
					appName = jtoken.GetValue("name");
					Logger.Debug("Package name from manifest.json.." + package);
				}
			}
			else
			{
				AppInfoExtractor apkInfo = AppInfoExtractor.GetApkInfo(apkPath);
				package = apkInfo.PackageName;
				appName = apkInfo.AppName;
			}
			if (addToChooseApkList)
			{
				DownloadInstallApk.sApkInstalledFromChooser.Add(package);
			}
			if (!string.IsNullOrEmpty(package))
			{
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					this.ParentWindow.mWelcomeTab.mHomeApp.AddAppIcon(package, appName, string.Empty, this);
				}), new object[0]);
			}
			this.InstallApk(package, apkPath, false, false, "");
		}

		// Token: 0x06000E66 RID: 3686 RVA: 0x0005CA14 File Offset: 0x0005AC14
		internal void InstallApk(string packageName, string apkPath, bool isLaunchAfterInstall, bool isDeleteApk, string timestamp = "")
		{
			this.ParentWindow.mWelcomeTab.mHomeApp.ApkInstallStart(packageName, apkPath);
			DownloadInstallApk.SerialWorkQueueInstaller(this.ParentWindow.mVmName).Enqueue(delegate
			{
				Logger.Info("Installing apk: {0}", new object[]
				{
					apkPath
				});
				int num = BluestacksProcessHelper.RunApkInstaller(apkPath, true, this.ParentWindow.mVmName);
				Logger.Info("Apk installer exit code: {0}", new object[]
				{
					num
				});
				if (num == 0)
				{
					if (DownloadInstallApk.sDownloadedApkList.Contains(packageName))
					{
						ClientStats.SendClientStatsAsync("install_from_download", "success", "app_install", packageName, "", "");
						DownloadInstallApk.sDownloadedApkList.Remove(packageName);
						this.UpdateCdnAppEntry(true, packageName, timestamp);
					}
					else if (DownloadInstallApk.sApkInstalledFromChooser.Contains(packageName))
					{
						ClientStats.SendClientStatsAsync("install", "success", "app_install", packageName, "", "");
						DownloadInstallApk.sApkInstalledFromChooser.Remove(packageName);
					}
					this.ParentWindow.mWelcomeTab.mHomeApp.ApkInstallCompleted(packageName);
					if (isLaunchAfterInstall)
					{
						this.ParentWindow.Utils.RunAppOrCreateTabButton(packageName);
					}
					Logger.Info("Installation successful.");
					if (isDeleteApk)
					{
						File.Delete(apkPath);
					}
					Logger.Info("Install Completed : " + packageName);
					return;
				}
				if (DownloadInstallApk.sDownloadedApkList.Contains(packageName))
				{
					ClientStats.SendClientStatsAsync("install_from_download", "fail", "app_install", packageName, num.ToString(), "");
					DownloadInstallApk.sDownloadedApkList.Remove(packageName);
				}
				else if (DownloadInstallApk.sApkInstalledFromChooser.Contains(packageName))
				{
					ClientStats.SendClientStatsAsync("install", "fail", "app_install", packageName, num.ToString(), "");
					DownloadInstallApk.sApkInstalledFromChooser.Remove(packageName);
				}
				ClientStats.SendGeneralStats("apk_inst_error", new Dictionary<string, string>
				{
					{
						"errcode",
						Convert.ToString(num)
					},
					{
						"precode",
						"0"
					},
					{
						"app_pkg",
						packageName
					}
				});
				this.ParentWindow.mWelcomeTab.mHomeApp.ApkInstallFailed(packageName);
			});
		}

		// Token: 0x06000E67 RID: 3687 RVA: 0x0005CA98 File Offset: 0x0005AC98
		internal int InstallFLEApk(string packageName, string apkPath)
		{
			Logger.Info("Installing apk: {0}", new object[]
			{
				apkPath
			});
			int num = BluestacksProcessHelper.RunApkInstaller(apkPath, true, this.ParentWindow.mVmName);
			Logger.Info("Apk installer exit code: {0}", new object[]
			{
				num
			});
			if (num == 0)
			{
				if (DownloadInstallApk.sDownloadedApkList.Contains(packageName))
				{
					ClientStats.SendClientStatsAsync("install_from_download", "success", "app_install", packageName, "", "");
					DownloadInstallApk.sDownloadedApkList.Remove(packageName);
					this.UpdateCdnAppEntry(true, packageName, "");
				}
				else if (DownloadInstallApk.sApkInstalledFromChooser.Contains(packageName))
				{
					ClientStats.SendClientStatsAsync("install", "success", "app_install", packageName, "", "");
					DownloadInstallApk.sApkInstalledFromChooser.Remove(packageName);
				}
				this.ParentWindow.Utils.RunAppOrCreateTabButton(packageName);
				Logger.Info("Installation successful.");
				File.Delete(apkPath);
			}
			else
			{
				if (DownloadInstallApk.sDownloadedApkList.Contains(packageName))
				{
					ClientStats.SendClientStatsAsync("install_from_download", "fail", "app_install", packageName, num.ToString(), "");
					DownloadInstallApk.sDownloadedApkList.Remove(packageName);
				}
				else if (DownloadInstallApk.sApkInstalledFromChooser.Contains(packageName))
				{
					ClientStats.SendClientStatsAsync("install", "fail", "app_install", packageName, num.ToString(), "");
					DownloadInstallApk.sApkInstalledFromChooser.Remove(packageName);
				}
				ClientStats.SendGeneralStats("apk_inst_error", new Dictionary<string, string>
				{
					{
						"errcode",
						Convert.ToString(num)
					},
					{
						"precode",
						"0"
					},
					{
						"app_pkg",
						packageName
					}
				});
			}
			Logger.Info("Install Completed : " + packageName);
			return num;
		}

		// Token: 0x06000E68 RID: 3688 RVA: 0x0005CC54 File Offset: 0x0005AE54
		internal void UninstallApp(string packageName)
		{
			DownloadInstallApk.SerialWorkQueueInstaller(this.ParentWindow.mVmName).Enqueue(delegate
			{
				Logger.Info("Uninstall started : " + packageName);
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary["package"] = packageName;
				try
				{
					JArray jarray = JArray.Parse(HTTPUtils.SendRequestToAgent("uninstall", dictionary, this.ParentWindow.mVmName, 0, null, false, 1, 0));
					try
					{
						if (!JObject.Parse(jarray[0].ToString())["success"].ToObject<bool>())
						{
							ClientStats.SendClientStatsAsync("uninstall", "fail", "app_install", packageName, "", "");
						}
						else
						{
							this.UpdateCdnAppEntry(false, packageName, "");
						}
					}
					catch
					{
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to uninstall app. Err: " + ex.Message);
				}
				Logger.Info("Uninstall completed for " + packageName);
			});
		}

		// Token: 0x06000E69 RID: 3689 RVA: 0x0005CC98 File Offset: 0x0005AE98
		internal void UpdateCdnAppEntry(bool isAdd, string packageName, string timestamp)
		{
			DateTime timestamp2 = DateTime.MinValue;
			if (!string.IsNullOrEmpty(timestamp))
			{
				timestamp2 = DateTime.Parse(timestamp);
			}
			this.ParentWindow.mAppHandler.WriteXMl(isAdd, packageName, timestamp2);
		}

		// Token: 0x040009F1 RID: 2545
		internal const string mIconUrl = "https://cloud.bluestacks.com/app/icon?pkg={0}&fallback=false";

		// Token: 0x040009F2 RID: 2546
		private Thread mDownloadThread;

		// Token: 0x040009F3 RID: 2547
		public bool mIsDownloading;

		// Token: 0x040009F4 RID: 2548
		private LegacyDownloader mDownloader;

		// Token: 0x040009F5 RID: 2549
		private int mDownloadPercent;

		// Token: 0x040009F6 RID: 2550
		private static Dictionary<string, SerialWorkQueue> mSerialQueue = new Dictionary<string, SerialWorkQueue>();

		// Token: 0x040009F7 RID: 2551
		internal static List<string> sDownloadedApkList = new List<string>();

		// Token: 0x040009F8 RID: 2552
		internal static List<string> sApkInstalledFromChooser = new List<string>();

		// Token: 0x040009F9 RID: 2553
		private MainWindow ParentWindow;
	}
}
