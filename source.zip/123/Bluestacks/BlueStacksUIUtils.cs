﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using BlueStacks.Common;
using Microsoft.VisualBasic.Devices;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000102 RID: 258
	internal class BlueStacksUIUtils
	{
		// Token: 0x06000A4C RID: 2636
		[DllImport("winmm.dll")]
		public static extern int waveOutGetVolume(IntPtr h, out uint dwVolume);

		// Token: 0x06000A4D RID: 2637
		[DllImport("winmm.dll")]
		public static extern int waveOutSetVolume(IntPtr h, uint dwVolume);

		// Token: 0x1700017D RID: 381
		// (get) Token: 0x06000A4E RID: 2638 RVA: 0x0000855C File Offset: 0x0000675C
		// (set) Token: 0x06000A4F RID: 2639 RVA: 0x00048C84 File Offset: 0x00046E84
		public int CurrentVolumeLevel
		{
			get
			{
				return this.mCurrentVolumeLevel;
			}
			private set
			{
				if (value <= 0)
				{
					this.mCurrentVolumeLevel = 0;
				}
				else if (value >= 100)
				{
					this.mCurrentVolumeLevel = 100;
				}
				else
				{
					this.mCurrentVolumeLevel = value;
				}
				this.ParentWindow.EngineInstanceRegistry.Volume = this.mCurrentVolumeLevel;
				this.ParentWindow.mCommonHandler.OnVolumeChanged(this.mCurrentVolumeLevel);
			}
		}

		// Token: 0x06000A50 RID: 2640 RVA: 0x00008564 File Offset: 0x00006764
		internal static bool IsAlphabet(char c)
		{
			return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
		}

		// Token: 0x06000A51 RID: 2641 RVA: 0x00048CE0 File Offset: 0x00046EE0
		internal BlueStacksUIUtils(MainWindow window)
		{
			this.ParentWindow = window;
			this.mCurrentVolumeLevel = this.ParentWindow.EngineInstanceRegistry.Volume;
		}

		// Token: 0x06000A52 RID: 2642 RVA: 0x00048D2C File Offset: 0x00046F2C
		internal static void CloseContainerWindow(UserControl control)
		{
			FrameworkElement frameworkElement = control;
			while (frameworkElement != null && !(frameworkElement is ContainerWindow))
			{
				frameworkElement = (frameworkElement.Parent as FrameworkElement);
			}
			if (frameworkElement != null)
			{
				(frameworkElement as ContainerWindow).Close();
			}
		}

		// Token: 0x06000A53 RID: 2643 RVA: 0x00048D64 File Offset: 0x00046F64
		internal static void RefreshKeyMap(string packageName)
		{
			foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
			{
				try
				{
					if (keyValuePair.Value.mTopBar.mAppTabButtons.SelectedTab.PackageName.Equals(packageName))
					{
						keyValuePair.Value.mFrontendHandler.RefreshKeyMap(packageName);
					}
				}
				catch (Exception ex)
				{
					Logger.Error(string.Concat(new string[]
					{
						ex.ToString(),
						Environment.NewLine,
						"Exception refreshing mapping of package : ",
						packageName,
						" for instance : ",
						keyValuePair.Value.mVmName
					}));
				}
			}
		}

		// Token: 0x06000A54 RID: 2644 RVA: 0x00008581 File Offset: 0x00006781
		public static bool IsModal(Window window)
		{
			return (bool)typeof(Window).GetField("_showingAsDialog", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(window);
		}

		// Token: 0x06000A55 RID: 2645 RVA: 0x00048E40 File Offset: 0x00047040
		private static void CloseWindows(Window win)
		{
			List<Window> list = new List<Window>();
			foreach (object obj in win.OwnedWindows)
			{
				Window window = (Window)obj;
				if (window != null && BlueStacksUIUtils.IsModal(window))
				{
					list.Add(window);
				}
				else
				{
					window.Visibility = Visibility.Hidden;
				}
				BlueStacksUIUtils.CloseWindows(window);
			}
			for (int i = list.Count - 1; i >= 0; i--)
			{
				list[i].Close();
			}
		}

		// Token: 0x06000A56 RID: 2646 RVA: 0x00048EE0 File Offset: 0x000470E0
		internal static void HideUnhideBlueStacks(bool isHide)
		{
			using (Dictionary<string, MainWindow>.ValueCollection.Enumerator enumerator = BlueStacksUIUtils.DictWindows.Values.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					MainWindow item = enumerator.Current;
					if (isHide)
					{
						item.Dispatcher.Invoke(new Action(delegate()
						{
							item.Visibility = Visibility.Hidden;
							if (item.mIsFullScreen)
							{
								item.WindowState = WindowState.Normal;
							}
							BlueStacksUIUtils.CloseWindows(item);
							item.ShowInTaskbar = false;
						}), new object[0]);
						item.mFrontendHandler.DeactivateFrontend();
					}
					else
					{
						item.ShowInTaskbar = true;
						if (item.mIsFullScreen)
						{
							item.WindowState = WindowState.Maximized;
						}
						item.Visibility = Visibility.Visible;
						item.Activate();
						if (!item.Topmost)
						{
							item.Topmost = true;
							Action <>9__2;
							ThreadPool.QueueUserWorkItem(delegate(object obj)
							{
								Dispatcher dispatcher = item.Dispatcher;
								Action method;
								if ((method = <>9__2) == null)
								{
									method = (<>9__2 = delegate()
									{
										item.Topmost = false;
									});
								}
								dispatcher.Invoke(method, new object[0]);
							});
						}
						if (RegistryManager.Instance.ShowKeyControlsOverlay)
						{
							KMManager.ShowOverlayWindow(item, true, false);
						}
						item.mFrontendHandler.FocusFrontend(false);
					}
				}
			}
		}

		// Token: 0x06000A57 RID: 2647 RVA: 0x00049010 File Offset: 0x00047210
		internal void MuteApplication(bool allInstances)
		{
			BlueStacksUIUtils.waveOutSetVolume(IntPtr.Zero, 0U);
			try
			{
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary["allInstances"] = allInstances.ToString();
				HTTPUtils.SendRequestToEngine("mute", dictionary, this.ParentWindow.mVmName, 0, null, false, 1, 0, "");
				this.ParentWindow.mCommonHandler.OnVolumeMuted(true);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send mute to frontend. Ex: " + ex.Message);
			}
		}

		// Token: 0x06000A58 RID: 2648 RVA: 0x000490A0 File Offset: 0x000472A0
		internal void UnmuteApplication(bool allInstances)
		{
			if (allInstances && this.ParentWindow.EngineInstanceRegistry.IsMuted)
			{
				this.ParentWindow.mSidebar.UpdateMuteAllInstancesCheckbox();
				return;
			}
			if (!allInstances && RegistryManager.Instance.AreAllInstancesMuted)
			{
				RegistryManager.Instance.AreAllInstancesMuted = false;
				foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values)
				{
					mainWindow.mSidebar.UpdateMuteAllInstancesCheckbox();
				}
			}
			BlueStacksUIUtils.waveOutSetVolume(IntPtr.Zero, uint.MaxValue);
			try
			{
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary["allInstances"] = allInstances.ToString();
				HTTPUtils.SendRequestToEngine("unmute", dictionary, this.ParentWindow.mVmName, 0, null, false, 1, 0, "");
				this.ParentWindow.mCommonHandler.OnVolumeMuted(false);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send mute to frontend. Ex: " + ex.Message);
			}
		}

		// Token: 0x06000A59 RID: 2649 RVA: 0x000085A4 File Offset: 0x000067A4
		internal void SetCurrentVolumeForDMM(int previousVolume, int newVolume)
		{
			new Thread(delegate()
			{
				try
				{
					this.ParentWindow.Utils.SetVolumeInFrontendAsync(newVolume);
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						this.ParentWindow.mDmmBottomBar.CurrentVolume = previousVolume;
					}), new object[0]);
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to set volume... Err : " + ex.ToString());
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						this.ParentWindow.mDmmBottomBar.CurrentVolume = previousVolume;
					}), new object[0]);
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000A5A RID: 2650 RVA: 0x000085DC File Offset: 0x000067DC
		internal void SetVolumeLevelFromAndroid(int volume)
		{
			this.CurrentVolumeLevel = volume;
		}

		// Token: 0x06000A5B RID: 2651 RVA: 0x000085E5 File Offset: 0x000067E5
		internal void SetVolumeInFrontendAsync(int newVolume)
		{
			int currentVolumeLevel = this.CurrentVolumeLevel;
			new Thread(delegate()
			{
				try
				{
					if (this.ParentWindow.mGuestBootCompleted && Convert.ToBoolean(JArray.Parse(HTTPUtils.SendRequestToEngine("setVolume", new Dictionary<string, string>
					{
						{
							"vol",
							newVolume.ToString()
						}
					}, this.ParentWindow.mVmName, 0, null, false, 1, 0, ""))[0]["success"]))
					{
						this.CurrentVolumeLevel = newVolume;
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to set volume. Ex: " + ex.ToString());
				}
				if (this.CurrentVolumeLevel == 0)
				{
					this.MuteApplication(false);
				}
				if (this.ParentWindow.EngineInstanceRegistry.IsMuted && this.CurrentVolumeLevel != 0)
				{
					this.UnmuteApplication(false);
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000A5C RID: 2652 RVA: 0x0000861D File Offset: 0x0000681D
		internal void GetCurrentVolumeAtBootAsyncAndSetMuteInstancesState()
		{
			new Thread(delegate()
			{
				try
				{
					int millisecondsTimeout = 1000;
					int volume = this.mCurrentVolumeLevel;
					int i = 60;
					while (i > 0)
					{
						i--;
						try
						{
							JObject jobject = JObject.Parse(HTTPUtils.SendRequestToGuest("getVolume", null, this.ParentWindow.mVmName, 0, null, true, 1, 0));
							if (!(jobject["result"].ToString() != "ok"))
							{
								volume = Convert.ToInt32(jobject["volume"].ToString());
								break;
							}
							Thread.Sleep(millisecondsTimeout);
						}
						catch (Exception ex)
						{
							Logger.Warning("Failed to get volume from guest: {0}", new object[]
							{
								ex.Message
							});
							Thread.Sleep(millisecondsTimeout);
						}
					}
					this.CurrentVolumeLevel = volume;
					if (FeatureManager.Instance.IsCustomUIForDMM)
					{
						this.ParentWindow.mDmmBottomBar.Dispatcher.Invoke(new Action(delegate()
						{
							this.ParentWindow.mDmmBottomBar.CurrentVolume = volume;
						}), new object[0]);
					}
					if (RegistryManager.Instance.AreAllInstancesMuted)
					{
						this.MuteApplication(true);
					}
				}
				catch (Exception ex2)
				{
					Logger.Error("Failed to get volume: " + ex2.ToString());
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000A5D RID: 2653 RVA: 0x0000863C File Offset: 0x0000683C
		internal static void RestartInstance(string vmName)
		{
			if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
			{
				BlueStacksUIUtils.DictWindows[vmName].RestartInstanceAndPerform(null);
			}
		}

		// Token: 0x06000A5E RID: 2654 RVA: 0x000491B8 File Offset: 0x000473B8
		internal static void SwitchAndRestartInstanceInAgl(string vmName)
		{
			if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
			{
				BlueStacksUIUtils.DictWindows[vmName].EngineInstanceRegistry.GlRenderMode = 1;
				Utils.UpdateValueInBootParams("GlMode", "2", vmName, true);
				BlueStacksUIUtils.DictWindows[vmName].EngineInstanceRegistry.GlMode = 2;
				BlueStacksUIUtils.RestartInstance(vmName);
			}
		}

		// Token: 0x06000A5F RID: 2655 RVA: 0x00049218 File Offset: 0x00047418
		internal static void SwitchAndRestartInstanceInOglAfterRunningGlCheck(string vmName, Action openApp)
		{
			if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
			{
				if (BlueStacksUIUtils.isOglSupported == null)
				{
					BlueStacksUIUtils.DictWindows[vmName].mExitProgressGrid.ProgressText = "STRING_RUNNING_CHECKS";
					BlueStacksUIUtils.DictWindows[vmName].mExitProgressGrid.Visibility = Visibility.Visible;
					BackgroundWorker backgroundWorker = new BackgroundWorker();
					backgroundWorker.DoWork += BlueStacksUIUtils.Bgw_DoWork;
					backgroundWorker.RunWorkerCompleted += BlueStacksUIUtils.Bgw_RunWorkerCompleted;
					backgroundWorker.RunWorkerAsync(new object[]
					{
						vmName,
						openApp
					});
					return;
				}
				BlueStacksUIUtils.Bgw_RunWorkerCompleted(new object(), new RunWorkerCompletedEventArgs(new object[]
				{
					vmName,
					openApp
				}, null, false));
			}
		}

		// Token: 0x06000A60 RID: 2656 RVA: 0x000492D0 File Offset: 0x000474D0
		private static void Bgw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			if (e.Error != null)
			{
				return;
			}
			string text = ((object[])e.Result)[0].ToString();
			Action openApp = (Action)((object[])e.Result)[1];
			BlueStacksUIUtils.DictWindows[text].mExitProgressGrid.ProgressText = "STRING_CLOSING_BLUESTACKS";
			BlueStacksUIUtils.DictWindows[text].mExitProgressGrid.Visibility = Visibility.Hidden;
			bool? flag = BlueStacksUIUtils.isOglSupported;
			bool flag2 = true;
			if (flag.GetValueOrDefault() == flag2 & flag != null)
			{
				BlueStacksUIUtils.DictWindows[text].EngineInstanceRegistry.GlRenderMode = 1;
				Utils.UpdateValueInBootParams("GlMode", "1", text, true);
				BlueStacksUIUtils.DictWindows[text].EngineInstanceRegistry.GlMode = 1;
				BlueStacksUIUtils.RestartInstance(text);
				return;
			}
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_OPENGL_NOT_SUPPORTED", false);
			customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_OPENGL_NOTSUPPORTED_BODY", false);
			customMessageWindow.AddButton(ButtonColors.Blue, LocaleStrings.GetLocalizedString("STRING_CONTINUE", false), delegate(object o, EventArgs args)
			{
				openApp();
			}, null, false, null);
			customMessageWindow.Owner = BlueStacksUIUtils.DictWindows[text];
			BlueStacksUIUtils.DictWindows[text].ShowDimOverlay(null);
			customMessageWindow.ShowDialog();
			BlueStacksUIUtils.DictWindows[text].HideDimOverlay();
		}

		// Token: 0x06000A61 RID: 2657 RVA: 0x00049434 File Offset: 0x00047634
		private static void Bgw_DoWork(object sender, DoWorkEventArgs e)
		{
			string empty = string.Empty;
			string empty2 = string.Empty;
			string empty3 = string.Empty;
			int num;
			BlueStacksUIUtils.isOglSupported = new bool?(Utils.CheckOpenGlSupport(out num, out empty, out empty3, out empty2, RegistryStrings.InstallDir));
			e.Result = e.Argument;
		}

		// Token: 0x06000A62 RID: 2658 RVA: 0x0004947C File Offset: 0x0004767C
		internal static void SwitchAndRestartInstanceInDx(string vmName)
		{
			if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
			{
				BlueStacksUIUtils.DictWindows[vmName].EngineInstanceRegistry.GlRenderMode = 4;
				Utils.UpdateValueInBootParams("GlMode", "1", vmName, true);
				BlueStacksUIUtils.DictWindows[vmName].EngineInstanceRegistry.GlMode = 1;
				BlueStacksUIUtils.RestartInstance(vmName);
			}
		}

		// Token: 0x06000A63 RID: 2659 RVA: 0x000494DC File Offset: 0x000476DC
		internal static void SwitchAndRestartInstanceInAdx(string vmName)
		{
			if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
			{
				BlueStacksUIUtils.DictWindows[vmName].EngineInstanceRegistry.GlRenderMode = 4;
				Utils.UpdateValueInBootParams("GlMode", "2", vmName, true);
				BlueStacksUIUtils.DictWindows[vmName].EngineInstanceRegistry.GlMode = 2;
				BlueStacksUIUtils.RestartInstance(vmName);
			}
		}

		// Token: 0x06000A64 RID: 2660 RVA: 0x0004953C File Offset: 0x0004773C
		internal void RunAppOrCreateTabButton(string packageName)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (this.ParentWindow.mTopBar.mAppTabButtons.mHomeAppTabButton.IsSelected)
				{
					this.ParentWindow.mAppHandler.SendRunAppRequestAsync(packageName, "", false);
					return;
				}
				AppIcon appIcon = this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon(packageName);
				if (appIcon != null)
				{
					this.ParentWindow.mTopBar.mAppTabButtons.AddAppTab(appIcon.AppName, appIcon.PackageName, appIcon.ActivityName, appIcon.ImageName, false, false, appIcon.PackageName, false);
				}
			}), new object[0]);
		}

		// Token: 0x06000A65 RID: 2661 RVA: 0x00049580 File Offset: 0x00047780
		internal void ResetPendingUIOperations()
		{
			try
			{
				if (this.ParentWindow.mGuestBootCompleted)
				{
					this.ParentWindow.mAppHandler.SwitchWhenPackageNameRecieved = string.Empty;
					AppHandler.EventOnAppDisplayed = null;
					if (FeatureManager.Instance.IsCustomUIForDMM)
					{
						this.ParentWindow.mDmmBottomBar.ShowKeyMapPopup(false);
					}
					else
					{
						this.ParentWindow.mSidebar.ShowKeyMapPopup(false);
						this.ParentWindow.mSidebar.ShowOverlayTooltip(false, false);
					}
					this.ParentWindow.mWelcomeTab.mFrontendPopupControl.HideWindow();
					this.ParentWindow.StaticComponents.ShowUninstallButtons(false);
					this.ParentWindow.ClosePopUps();
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Error in ResetPendingUIOperations " + ex.ToString());
			}
		}

		// Token: 0x06000A66 RID: 2662 RVA: 0x0000865C File Offset: 0x0000685C
		internal static void AddBootEventHandler(string vmName, EventHandler bootedEvennt)
		{
			if (BlueStacksUIUtils.BootEventsForMIManager.ContainsKey(vmName))
			{
				BlueStacksUIUtils.BootEventsForMIManager[vmName].Add(bootedEvennt);
				return;
			}
			BlueStacksUIUtils.BootEventsForMIManager.Add(vmName, new List<EventHandler>
			{
				bootedEvennt
			});
		}

		// Token: 0x06000A67 RID: 2663 RVA: 0x00049658 File Offset: 0x00047858
		internal static void InvokeMIManagerEvents(string VmName)
		{
			if (BlueStacksUIUtils.BootEventsForMIManager.ContainsKey(VmName))
			{
				foreach (EventHandler eventHandler in BlueStacksUIUtils.BootEventsForMIManager[VmName])
				{
					eventHandler(null, null);
				}
			}
		}

		// Token: 0x06000A68 RID: 2664 RVA: 0x000496BC File Offset: 0x000478BC
		internal void ShakeWindow()
		{
			if (this.ParentWindow.WindowState == WindowState.Maximized)
			{
				this.ParentWindow.StoryBoard.Begin();
				return;
			}
			int i = 10;
			int num = 5;
			int num2 = 0;
			int num3 = 0;
			while (i > 0)
			{
				if (num3 == 0)
				{
					num2 = num;
				}
				else if (num3 == 1)
				{
					num2 = num * -1;
				}
				else if (num3 == 2)
				{
					num2 = num * -1;
				}
				else if (num3 == 3)
				{
					num2 = num;
				}
				num3++;
				if (num3 == 4)
				{
					num3 = 0;
					i--;
				}
				this.ParentWindow.Left = this.ParentWindow.Left + (double)num2;
				Thread.Sleep(30);
			}
		}

		// Token: 0x06000A69 RID: 2665 RVA: 0x00049748 File Offset: 0x00047948
		internal static void RunInstance(string vmName, bool hiddenMode = false)
		{
			if (!BlueStacksUIUtils.lstCreatingWindows.Contains(vmName))
			{
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName) && !hiddenMode)
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[vmName].ShowWindow(false);
					}), new object[0]);
					return;
				}
				Application.Current.Dispatcher.Invoke(new Action(delegate()
				{
					BlueStacksUIUtils.lstCreatingWindows.Add(vmName);
					MainWindow mainWindow = new MainWindow(vmName);
					BlueStacksUIUtils.DictWindows[vmName] = mainWindow;
					BlueStacksUIUtils.lstCreatingWindows.Remove(vmName);
					if (!hiddenMode)
					{
						mainWindow.ShowWindow(true);
					}
				}), new object[0]);
			}
		}

		// Token: 0x06000A6A RID: 2666 RVA: 0x00008694 File Offset: 0x00006894
		internal void CheckGuestFailedAsync()
		{
			this.sBootCheckTimer.Elapsed += this.SBootCheckTimer_Elapsed;
			this.sBootCheckTimer.Enabled = true;
		}

		// Token: 0x06000A6B RID: 2667 RVA: 0x000497E8 File Offset: 0x000479E8
		internal static void HideAllBlueStacks()
		{
			foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>())
			{
				BlueStacksUIUtils.CloseWindows(mainWindow);
				mainWindow.ShowInTaskbar = false;
				mainWindow.Hide();
			}
		}

		// Token: 0x06000A6C RID: 2668 RVA: 0x000086B9 File Offset: 0x000068B9
		private void SBootCheckTimer_Elapsed(object sender, ElapsedEventArgs e)
		{
			(sender as System.Timers.Timer).Enabled = false;
			if (!this.ParentWindow.mGuestBootCompleted)
			{
				this.SendGuestBootFailureStats("boot timeout exception");
			}
		}

		// Token: 0x06000A6D RID: 2669 RVA: 0x00049850 File Offset: 0x00047A50
		public static string GetFinalRedirectedUrl(string url)
		{
			HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
			httpWebRequest.Method = "GET";
			httpWebRequest.AllowAutoRedirect = true;
			string str = "Bluestacks/" + RegistryManager.Instance.ClientVersion;
			httpWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36 " + str;
			httpWebRequest.Headers.Add("x_oem", RegistryManager.Instance.Oem);
			httpWebRequest.Headers.Set("x_email", RegistryManager.Instance.RegisteredEmail);
			httpWebRequest.Headers.Add("x_guid", RegistryManager.Instance.UserGuid);
			httpWebRequest.Headers.Add("x_prod_ver", RegistryManager.Instance.Version);
			httpWebRequest.Headers.Add("x_home_app_ver", RegistryManager.Instance.ClientVersion);
			string result;
			try
			{
				result = httpWebRequest.GetResponse().ResponseUri.ToString();
			}
			catch (Exception ex)
			{
				Logger.Error("Error in getting redirected url" + ex.ToString());
				result = null;
			}
			return result;
		}

		// Token: 0x06000A6E RID: 2670 RVA: 0x00049964 File Offset: 0x00047B64
		internal void SendGuestBootFailureStats(string errorString)
		{
			if (RegistryManager.Instance.IsEngineUpgraded == 1 && RegistryManager.Instance.IsClientFirstLaunch == 1)
			{
				ClientStats.SendClientStatsAsync("update_init", "fail", "engine_activity", "", errorString, "");
			}
			else if (RegistryManager.Instance.IsClientFirstLaunch == 1)
			{
				ClientStats.SendClientStatsAsync("first_init", "fail", "engine_activity", "", errorString, "");
			}
			else
			{
				ClientStats.SendClientStatsAsync("init", "fail", "engine_activity", "", errorString, "");
			}
			this.ParentWindow.HandleRestartPopup();
		}

		// Token: 0x06000A6F RID: 2671 RVA: 0x00049A04 File Offset: 0x00047C04
		internal static bool CheckForMacrAvailable(string packageName)
		{
			string path = Path.Combine(Path.Combine(RegistryManager.Instance.EngineDataDir, "UserData\\InputMapper"), packageName + "_macro.cfg");
			string path2 = Path.Combine(Path.Combine(RegistryManager.Instance.EngineDataDir, "UserData\\InputMapper\\UserFiles"), packageName + "_macro.cfg");
			return File.Exists(path) || File.Exists(path2);
		}

		// Token: 0x06000A70 RID: 2672 RVA: 0x00049A6C File Offset: 0x00047C6C
		internal static string GetVideoTutorialUrl(string packageName, string videoMode)
		{
			string text = WebHelper.GetServerHost();
			text = text.Substring(0, text.Length - 4);
			string text2 = WebHelper.GetUrlWithParams(string.Format("{0}/{1}?app_pkg={2}&mode={3}", new object[]
			{
				text,
				"videoTutorial",
				packageName,
				videoMode
			}));
			if (!RegistryManager.Instance.IgnoreAutoPlayPackageList.Contains(packageName))
			{
				text2 = string.Format("{0}&autoplay=1", text2);
				List<string> ignoreAutoPlayPackageList = RegistryManager.Instance.IgnoreAutoPlayPackageList;
				ignoreAutoPlayPackageList.Add(packageName);
				RegistryManager.Instance.IgnoreAutoPlayPackageList = ignoreAutoPlayPackageList;
			}
			else
			{
				text2 = string.Format("{0}&autoplay=0", text2);
			}
			if (!string.IsNullOrEmpty(RegistryManager.Instance.Partner))
			{
				text2 += string.Format("&partner={0}", RegistryManager.Instance.Partner);
			}
			return text2;
		}

		// Token: 0x06000A71 RID: 2673 RVA: 0x00049B30 File Offset: 0x00047D30
		internal void SetKeyMapping(string packageName, string source)
		{
			string path = Path.Combine(RegistryManager.Instance.EngineDataDir, "UserData\\InputMapper\\UserFiles");
			string destFileName = Path.Combine(path, string.Format("{0}.cfg", packageName));
			string sourceFileName = Path.Combine(path, string.Format("{0}_{1}.cfg", packageName, source));
			try
			{
				File.Copy(sourceFileName, destFileName, true);
			}
			catch (Exception ex)
			{
				Logger.Error("Faield to copy cfgs... Err : " + ex.ToString());
				return;
			}
			this.ParentWindow.mFrontendHandler.RefreshKeyMap(packageName);
		}

		// Token: 0x06000A72 RID: 2674 RVA: 0x00049BB8 File Offset: 0x00047DB8
		internal static void OpenUrl(string url)
		{
			try
			{
				Process.Start(url);
			}
			catch (Win32Exception)
			{
				try
				{
					Process.Start("IExplore.exe", url);
				}
				catch (Exception ex)
				{
					Logger.Warning("Not able to launch the url " + url + "Ignoring Exception: " + ex.ToString());
				}
			}
			catch (Exception ex2)
			{
				Logger.Warning("Not able to launch the url " + url + "Ignoring Exception: " + ex2.ToString());
			}
		}

		// Token: 0x06000A73 RID: 2675 RVA: 0x00049C44 File Offset: 0x00047E44
		internal bool IsSufficientRAMAvailable()
		{
			Logger.Info("Checking for physical memory...");
			long num = long.Parse(Profile.GetSysInfo("Select TotalPhysicalMemory from Win32_ComputerSystem"));
			long num2 = 1073741824L;
			return num >= num2;
		}

		// Token: 0x06000A74 RID: 2676 RVA: 0x00049C78 File Offset: 0x00047E78
		public void SendMessageToAndroidForAffiliate(string pkgName, string source)
		{
			try
			{
				Logger.Info("Sending message to Android for affiliate");
				HTTPUtils.SendRequestToGuest("customStartService", new Dictionary<string, string>
				{
					{
						"action",
						"com.bluestacks.home.AFFILIATE_HANDLER_HTML"
					},
					{
						"extras",
						new JObject
						{
							{
								"success",
								true
							},
							{
								"app_pkg",
								pkgName
							},
							{
								"WINDOWS_SOURCE",
								source
							}
						}.ToString(Formatting.None, new JsonConverter[0])
					}
				}, this.ParentWindow.mVmName, 0, null, false, 1, 0);
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't send message to Adnroid: " + ex.ToString());
			}
		}

		// Token: 0x06000A75 RID: 2677 RVA: 0x00049D3C File Offset: 0x00047F3C
		public void AppendUrlWithCommonParamsAndOpenTab(string url, string title, string imagePath, string tabKey = "")
		{
			try
			{
				url = WebHelper.GetUrlWithParams(url);
				if (new Uri(url).Host.Contains("bluestacks", StringComparison.InvariantCultureIgnoreCase))
				{
					string registeredEmail = RegistryManager.Instance.RegisteredEmail;
					string token = RegistryManager.Instance.Token;
					if (string.IsNullOrEmpty(registeredEmail))
					{
						Logger.Warning("User email not found. Not opening webpage.");
					}
					if (string.IsNullOrEmpty(token))
					{
						Logger.Warning("User token not found. Not opening webpage.");
					}
				}
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					this.ParentWindow.mTopBar.mAppTabButtons.AddWebTab(url, title, imagePath, true, tabKey, false);
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception when parsing uri for opening in webtab " + ex.ToString());
			}
		}

		// Token: 0x06000A76 RID: 2678 RVA: 0x00049E28 File Offset: 0x00048028
		public void ApplyTheme(string themeName)
		{
			BlueStacksUIColorManager.ReloadAppliedTheme(themeName);
			this.RefreshAppCenterUrl("");
			this.RefreshHtmlSidePanelUrl();
			this.ParentWindow.mCommonHandler.SetCustomCursorForApp(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName);
			ClientStats.SendMiscellaneousStatsAsync("SkinChangedStats", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.ClientThemeName, null, null, null, null);
		}

		// Token: 0x06000A77 RID: 2679 RVA: 0x00049EAC File Offset: 0x000480AC
		internal string GetAppCenterUrl(string tabId)
		{
			string text = WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/page/appcenter-v2");
			text += "&theme=";
			text += RegistryManager.Instance.ClientThemeName;
			text += "&naked=1";
			if (!string.IsNullOrEmpty(tabId))
			{
				text += "&tabid=";
				text += tabId;
			}
			return text;
		}

		// Token: 0x06000A78 RID: 2680 RVA: 0x000086DF File Offset: 0x000068DF
		internal string GetHtmlSidePanelUrl()
		{
			return WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/page/myapps-sidepanel") + "&theme=" + RegistryManager.Instance.ClientThemeName;
		}

		// Token: 0x06000A79 RID: 2681 RVA: 0x0000870E File Offset: 0x0000690E
		internal string GetGiftTabUrl()
		{
			return WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/gift") + "&theme=" + RegistryManager.Instance.ClientThemeName;
		}

		// Token: 0x06000A7A RID: 2682 RVA: 0x0000873D File Offset: 0x0000693D
		internal string GetPikaWorldUrl()
		{
			return WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/pikaworld") + "&naked=1";
		}

		// Token: 0x06000A7B RID: 2683 RVA: 0x00049F14 File Offset: 0x00048114
		internal void SwitchProfile(string vmName, string pcode)
		{
			try
			{
				Dictionary<string, string> data = new Dictionary<string, string>();
				JObject jobject = new JObject();
				jobject.Add("pcode", pcode);
				jobject.Add("createcustomprofile", "false");
				data.Add("data", jobject.ToString(Formatting.None, new JsonConverter[0]));
				BlueStacksUIUtils.DictWindows[vmName].mExitProgressGrid.ProgressText = "STRING_SWITCHING_PROFILE";
				BlueStacksUIUtils.DictWindows[vmName].mExitProgressGrid.Visibility = Visibility.Visible;
				Action <>9__1;
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					JObject jobject2 = new JObject();
					jobject2["pcode"] = Utils.GetValueInBootParams("pcode", this.ParentWindow.mVmName, "");
					string text = HTTPUtils.SendRequestToGuest("changePCode", data, vmName, 0, null, false, 3, 60000);
					Logger.Info("Response for ChangePCode: " + text);
					JObject jobject3 = JObject.Parse(text);
					Dispatcher dispatcher = this.ParentWindow.Dispatcher;
					Action method;
					if ((method = <>9__1) == null)
					{
						method = (<>9__1 = delegate()
						{
							this.ParentWindow.mExitProgressGrid.ProgressText = "STRING_CLOSING_BLUESTACKS";
							this.ParentWindow.mExitProgressGrid.Visibility = Visibility.Hidden;
						});
					}
					dispatcher.Invoke(method, new object[0]);
					JObject jobject4 = new JObject();
					jobject4["pcode"] = pcode;
					if (jobject3["result"].ToString() == "ok")
					{
						Logger.Info("Successfully updated Device Profile.");
						Utils.UpdateValueInBootParams("pcode", pcode, this.ParentWindow.mVmName, false);
						this.ParentWindow.mCommonHandler.AddToastPopup(this.ParentWindow, LocaleStrings.GetLocalizedString("STRING_SWITCH_PROFILE_UPDATED", false), 1.3, false);
						this.ParentWindow.mWelcomeTab.mHomeApp.RequirementConfigUpdated();
						ClientStats.SendMiscellaneousStatsAsync("DeviceProfileChangeStats", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "success", JsonConvert.SerializeObject(jobject4), JsonConvert.SerializeObject(jobject2), RegistryManager.Instance.Version, "GRM", null);
						return;
					}
					Logger.Warning("DeviceProfile Update failed in android");
					this.ParentWindow.mCommonHandler.AddToastPopup(this.ParentWindow, LocaleStrings.GetLocalizedString("STRING_SWITCH_PROFILE_FAILED", false), 1.3, false);
					ClientStats.SendMiscellaneousStatsAsync("DeviceProfileChangeStats", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "failed", JsonConvert.SerializeObject(jobject4), JsonConvert.SerializeObject(jobject2), RegistryManager.Instance.Version, "GRM", null);
				});
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in SwitchProfileAndRestart: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x06000A7C RID: 2684 RVA: 0x0000875D File Offset: 0x0000695D
		internal string GetHelpCenterUrl()
		{
			return WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/feedback");
		}

		// Token: 0x06000A7D RID: 2685 RVA: 0x0004A028 File Offset: 0x00048228
		internal void RefreshHtmlSidePanelUrl()
		{
			foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values)
			{
				try
				{
					BrowserControl sideHtmlBrowser = mainWindow.mWelcomeTab.mHomeApp.SideHtmlBrowser;
					if (sideHtmlBrowser != null)
					{
						sideHtmlBrowser.ReInitBrowser(this.GetHtmlSidePanelUrl());
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Error while refreshing side html panel for vmname: {0} and exception is: {1}", new object[]
					{
						mainWindow.mVmName,
						ex
					});
				}
			}
		}

		// Token: 0x06000A7E RID: 2686 RVA: 0x0004A0C8 File Offset: 0x000482C8
		internal void RefreshAppCenterUrl(string tabId)
		{
			if (BlueStacksUIUtils.DictWindows.ContainsKey(Strings.CurrentDefaultVmName))
			{
				MainWindow mainWindow = BlueStacksUIUtils.DictWindows[Strings.CurrentDefaultVmName];
				AppTabButton tab = mainWindow.mTopBar.mAppTabButtons.GetTab("appcenter");
				if (tab != null && tab.GetBrowserControl() != null)
				{
					tab.GetBrowserControl().NavigateTo(this.GetAppCenterUrl(""));
				}
				AppTabButton tab2 = mainWindow.mTopBar.mAppTabButtons.GetTab("gift");
				if (tab2 != null && tab2.GetBrowserControl() != null)
				{
					tab2.GetBrowserControl().NavigateTo(this.GetGiftTabUrl());
				}
			}
		}

		// Token: 0x06000A7F RID: 2687 RVA: 0x0004A160 File Offset: 0x00048360
		internal bool IsRequiredFreeRAMAvailable()
		{
			try
			{
				ulong num = 1048576UL;
				ulong availablePhysicalMemory = new ComputerInfo().AvailablePhysicalMemory;
				int num2 = this.ParentWindow.EngineInstanceRegistry.Memory + 100;
				if (num2 > 2148)
				{
					num2 = 2148;
				}
				ulong num3 = (ulong)((long)num2 * (long)num);
				if (availablePhysicalMemory < num3)
				{
					Logger.Warning("Available physical memory is less than required. {0} < {1}", new object[]
					{
						availablePhysicalMemory / num,
						num2
					});
					return false;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("An error occurred while finding free RAM");
				Logger.Error(ex.ToString());
			}
			return true;
		}

		// Token: 0x06000A80 RID: 2688 RVA: 0x0004A200 File Offset: 0x00048400
		internal bool CheckQuitPopupLocal()
		{
			try
			{
				if (!this.ParentWindow.mGuestBootCompleted)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						QuitPopupControl quitPopupControl = new QuitPopupControl(this.ParentWindow);
						string text = "exit_popup_boot";
						quitPopupControl.CurrentPopupTag = text;
						BlueStacksUIBinding.Bind(quitPopupControl.TitleTextBlock, "STRING_TROUBLE_STARTING_BLUESTACKS", "");
						BlueStacksUIBinding.Bind(quitPopupControl.mCloseBlueStacksButton, "STRING_CLOSE_BLUESTACKS");
						quitPopupControl.AddQuitActionItem(QuitActionItem.StuckAtBoot);
						quitPopupControl.AddQuitActionItem(QuitActionItem.SlowPerformance);
						quitPopupControl.AddQuitActionItem(QuitActionItem.SomethingElseWrong);
						quitPopupControl.CloseBlueStacksButton.PreviewMouseUp += new MouseButtonEventHandler(this.ParentWindow.MainWindow_CloseWindowConfirmationAcceptedHandler);
						this.ParentWindow.HideDimOverlay();
						this.ParentWindow.ShowDimOverlay(quitPopupControl);
						ClientStats.SendLocalQuitPopupStatsAsync(text, "popup_shown");
					}), new object[0]);
					return true;
				}
				if (!RegistryManager.Instance.Guest[this.ParentWindow.mVmName].IsGoogleSigninDone && this.ParentWindow.mFrontendGrid.IsVisible)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						QuitPopupControl quitPopupControl = new QuitPopupControl(this.ParentWindow);
						string text = "exit_popup_ots";
						quitPopupControl.CurrentPopupTag = text;
						BlueStacksUIBinding.Bind(quitPopupControl.TitleTextBlock, "STRING_YOU_ARE_ONE_STEP_AWAY", "");
						BlueStacksUIBinding.Bind(quitPopupControl.mCloseBlueStacksButton, "STRING_CLOSE_BLUESTACKS");
						quitPopupControl.AddQuitActionItem(QuitActionItem.WhyGoogleAccount);
						quitPopupControl.AddQuitActionItem(QuitActionItem.TroubleSigningIn);
						quitPopupControl.AddQuitActionItem(QuitActionItem.SomethingElseWrong);
						quitPopupControl.CloseBlueStacksButton.PreviewMouseUp += new MouseButtonEventHandler(this.ParentWindow.MainWindow_CloseWindowConfirmationAcceptedHandler);
						this.ParentWindow.HideDimOverlay();
						this.ParentWindow.ShowDimOverlay(quitPopupControl);
						ClientStats.SendLocalQuitPopupStatsAsync(text, "popup_shown");
					}), new object[0]);
					return true;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while trying to show local quit popup. " + ex.ToString());
			}
			return false;
		}

		// Token: 0x06000A81 RID: 2689 RVA: 0x0004A2C8 File Offset: 0x000484C8
		public void OpenPikaAccountPage()
		{
			if (this.ParentWindow.mAppHandler.IsOneTimeSetupCompleted && !string.IsNullOrEmpty(RegistryManager.Instance.RegisteredEmail))
			{
				string text = WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/bluestacks_account?extra=section:pika");
				text += "&email=";
				text += RegistryManager.Instance.RegisteredEmail;
				text += "&token=";
				text += RegistryManager.Instance.Token;
				this.ParentWindow.mTopBar.mAppTabButtons.AddWebTab(text, "STRING_ACCOUNT", "account_tab", true, "account_tab", true);
			}
		}

		// Token: 0x06000A82 RID: 2690 RVA: 0x0004A374 File Offset: 0x00048574
		internal void HandleApplicationBrowserClick(string clickActionValue, string title, string key, bool paramsOnlyActionValue = false, string customImageName = "")
		{
			title = title.Trim();
			string imagePath = "cef_tab";
			uint num = <PrivateImplementationDetails>.ComputeStringHash(key);
			if (num > 2737665056U)
			{
				if (num <= 3655924613U)
				{
					if (num != 2938085890U)
					{
						if (num != 3655924613U)
						{
							goto IL_211;
						}
						if (!(key == "appcenter"))
						{
							goto IL_211;
						}
						goto IL_132;
					}
					else if (!(key == "pikaworld"))
					{
						goto IL_211;
					}
				}
				else if (num != 3727264231U)
				{
					if (num != 3975455884U)
					{
						goto IL_211;
					}
					if (!(key == "MAPS_TEXT"))
					{
						goto IL_211;
					}
				}
				else
				{
					if (!(key == "GIFT_TEXT"))
					{
						goto IL_211;
					}
					goto IL_16E;
				}
				clickActionValue = HTTPUtils.MergeQueryParams(this.GetPikaWorldUrl(), clickActionValue, paramsOnlyActionValue);
				if (string.IsNullOrEmpty(title))
				{
					title = LocaleStrings.GetLocalizedString("STRING_MAPS", false);
				}
				key = "pikaworld";
				imagePath = "pikaworld";
				goto IL_211;
			}
			if (num <= 2322801903U)
			{
				if (num != 255579182U)
				{
					if (num != 2322801903U)
					{
						goto IL_211;
					}
					if (!(key == "gift"))
					{
						goto IL_211;
					}
					goto IL_16E;
				}
				else if (!(key == "APP_CENTER_TEXT"))
				{
					goto IL_211;
				}
			}
			else if (num != 2333368623U)
			{
				if (num != 2737665056U)
				{
					goto IL_211;
				}
				if (!(key == "FEEDBACK_TEXT"))
				{
					goto IL_211;
				}
				clickActionValue = HTTPUtils.MergeQueryParams(this.GetHelpCenterUrl(), clickActionValue, paramsOnlyActionValue);
				Process.Start(clickActionValue);
				return;
			}
			else
			{
				if (!(key == "preregistration"))
				{
					goto IL_211;
				}
				if (string.IsNullOrEmpty(title))
				{
					title = LocaleStrings.GetLocalizedString("STRING_PREREGISTER", false);
				}
				imagePath = "preregistration";
				goto IL_211;
			}
			IL_132:
			clickActionValue = HTTPUtils.MergeQueryParams(this.GetAppCenterUrl(""), clickActionValue, paramsOnlyActionValue);
			if (string.IsNullOrEmpty(title))
			{
				title = LocaleStrings.GetLocalizedString("STRING_APP_CENTER", false);
			}
			key = "appcenter";
			imagePath = "appcenter";
			goto IL_211;
			IL_16E:
			clickActionValue = HTTPUtils.MergeQueryParams(this.GetGiftTabUrl(), clickActionValue, paramsOnlyActionValue);
			if (string.IsNullOrEmpty(title))
			{
				title = LocaleStrings.GetLocalizedString("STRING_GIFT", false);
			}
			key = "gift";
			imagePath = "gift";
			IL_211:
			if (!string.IsNullOrEmpty(customImageName))
			{
				imagePath = customImageName;
			}
			this.ParentWindow.Utils.AppendUrlWithCommonParamsAndOpenTab(clickActionValue, title, imagePath, key);
		}

		// Token: 0x06000A83 RID: 2691 RVA: 0x00008773 File Offset: 0x00006973
		private string GetImagePath(Dictionary<string, string> payload, string customImageName = "")
		{
			if (!string.IsNullOrEmpty(customImageName))
			{
				return customImageName;
			}
			if (payload.ContainsKey("icon_path"))
			{
				return payload["icon_path"];
			}
			return "";
		}

		// Token: 0x06000A84 RID: 2692 RVA: 0x0004A5B4 File Offset: 0x000487B4
		public void HandleGenericActionFromDictionary(Dictionary<string, string> payload, string source, string customImageName = "")
		{
			try
			{
				if (payload.ContainsKey("click_generic_action"))
				{
					GenericAction genericAction = EnumHelper.Parse<GenericAction>(payload["click_generic_action"], GenericAction.None);
					if (genericAction <= GenericAction.HomeAppTab)
					{
						switch (genericAction)
						{
						case GenericAction.InstallPlay:
							if (!this.ParentWindow.mAppHandler.IsAppInstalled(payload["click_action_packagename"]))
							{
								this.ParentWindow.Utils.SendMessageToAndroidForAffiliate(payload["click_action_packagename"], source);
							}
							this.ParentWindow.mWelcomeTab.mFrontendPopupControl.Init(payload["click_action_packagename"], payload["click_action_title"], PlayStoreAction.OpenApp, true);
							goto IL_477;
						case GenericAction.InstallCDN:
							if (!this.ParentWindow.mAppHandler.IsAppInstalled(payload["click_action_packagename"]))
							{
								this.ParentWindow.Utils.SendMessageToAndroidForAffiliate(payload["click_action_packagename"], source);
							}
							this.ParentWindow.mAppInstaller.DownloadAndInstallApp(string.Empty, payload["click_action_title"], payload["click_action_value"], payload["click_action_packagename"], false, true, "");
							goto IL_477;
						case (GenericAction)3:
							break;
						case GenericAction.ApplicationBrowser:
							this.HandleApplicationBrowserClick(payload["click_action_value"], payload["click_action_title"], payload.ContainsKey("click_action_key") ? payload["click_action_key"] : "", false, this.GetImagePath(payload, customImageName));
							goto IL_477;
						default:
							if (genericAction == GenericAction.UserBrowser)
							{
								BlueStacksUIUtils.OpenUrl(payload["click_action_value"]);
								goto IL_477;
							}
							if (genericAction == GenericAction.HomeAppTab)
							{
								this.ParentWindow.mTopBar.mAppTabButtons.GoToTab("Home", true, false);
								if (string.Compare(payload["click_action_value"], "my_app_text", true) == 0)
								{
									goto IL_477;
								}
								if (payload.ContainsKey("query_params") && !string.IsNullOrEmpty(payload["query_params"].Trim()))
								{
									this.HandleApplicationBrowserClick(payload["query_params"], "", payload["click_action_value"], true, customImageName);
									goto IL_477;
								}
								this.HandleApplicationBrowserClick("", "", payload["click_action_value"], true, customImageName);
								goto IL_477;
							}
							break;
						}
					}
					else if (genericAction <= GenericAction.KeyBasedPopup)
					{
						if (genericAction == GenericAction.SettingsMenu)
						{
							this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
							{
								SettingsWindow control = new SettingsWindow(this.ParentWindow, payload["click_action_value"]);
								int num = 510;
								int num2 = 750;
								new ContainerWindow(this.ParentWindow, control, (double)num2, (double)num, false, true);
							}), new object[0]);
							goto IL_477;
						}
						if (genericAction == GenericAction.KeyBasedPopup)
						{
							string a = payload["click_action_key"].Trim().ToLower();
							if (a == "instance_manager")
							{
								BlueStacksUIUtils.LaunchMultiInstanceManager();
								goto IL_477;
							}
							if (!(a == "macro_recorder"))
							{
								goto IL_477;
							}
							this.ParentWindow.mCommonHandler.OpenOperationRecorderWindow();
							goto IL_477;
						}
					}
					else
					{
						if (genericAction == GenericAction.OpenSystemApp)
						{
							this.ParentWindow.mTopBar.mAppTabButtons.AddAppTab(payload["click_action_title"], payload["click_action_packagename"], payload["click_action_app_activity"], this.GetImagePath(payload, customImageName), false, true, payload["click_action_key"], false);
							this.ParentWindow.mAppHandler.SwitchWhenPackageNameRecieved = payload["click_action_packagename"];
							this.ParentWindow.mAppHandler.SendRunAppRequestAsync(payload["click_action_packagename"], payload["click_action_app_activity"], false);
							goto IL_477;
						}
						if (genericAction == GenericAction.PopupBrowser)
						{
							this.ParentWindow.mCommonHandler.OpenBrowserInPopup(payload);
							goto IL_477;
						}
					}
					Logger.Warning("Unknown case {0}", new object[]
					{
						payload["click_generic_action"]
					});
				}
				IL_477:;
			}
			catch (Exception ex)
			{
				Logger.Error(string.Concat(new string[]
				{
					"Exception on handling click event for payload ",
					payload.ToDebugString<string, string>(),
					Environment.NewLine,
					"Exception: ",
					ex.ToString()
				}));
			}
		}

		// Token: 0x06000A85 RID: 2693 RVA: 0x0004AA98 File Offset: 0x00048C98
		internal bool CheckQuitPopupFromCloud(string eventType, string appPackage = "")
		{
			bool result;
			try
			{
				Logger.Info("IsQuitPopupNotificationReceived status: " + this.ParentWindow.IsQuitPopupNotficationReceived.ToString());
				if (!RegistryManager.Instance.ShowGamingSummary || !this.ParentWindow.IsQuitPopupNotficationReceived || (!string.Equals(this.ParentWindow.mQuitPopupBrowserControl.mPackage, appPackage) && !string.Equals(this.ParentWindow.mQuitPopupBrowserControl.mPackage, "*")))
				{
					result = false;
				}
				else
				{
					this.ParentWindow.IsQuitPopupNotficationReceived = false;
					string url = this.ParentWindow.mQuitPopupBrowserControl.mUrl;
					if (this.ParentWindow.mQuitPopupBrowserControl.mForceReload)
					{
						string str = JsonConvert.SerializeObject(AppUsageTimer.GetRealtimeDictionary()[this.ParentWindow.mVmName], Formatting.None);
						string urlOverideParams = "usage_data=" + str;
						url = HTTPUtils.MergeQueryParams(url, urlOverideParams, true);
						url = WebHelper.GetUrlWithParams(url);
						this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
						{
							BrowserControl browserControl = this.ParentWindow.mFirebaseBrowserControlGrid.Children[0] as BrowserControl;
							object[] args = new object[]
							{
								url
							};
							browserControl.mBrowser.CallJs("setIframeUrl", args);
						}), new object[0]);
					}
					else
					{
						url = WebHelper.GetUrlWithParams(url);
					}
					if (!string.IsNullOrEmpty(url))
					{
						this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
						{
							this.ParentWindow.HideDimOverlay();
							this.ParentWindow.ShowBrowserQuitPopUp(url, appPackage);
						}), new object[0]);
						result = true;
					}
					else
					{
						result = false;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while trying to show quit popup. " + ex.ToString());
				result = false;
			}
			return result;
		}

		// Token: 0x06000A86 RID: 2694 RVA: 0x0000879D File Offset: 0x0000699D
		internal static void LaunchMultiInstanceManager()
		{
			if (!FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				ProcessUtils.GetProcessObject(Path.Combine(RegistryStrings.InstallDir, "HD-MultiInstanceManager.exe"), null, false).Start();
			}
		}

		// Token: 0x06000A87 RID: 2695 RVA: 0x0004AC6C File Offset: 0x00048E6C
		internal static void RemoveChildFromParent(UIElement child)
		{
			DependencyObject parent = VisualTreeHelper.GetParent(child);
			Panel panel = parent as Panel;
			if (panel != null)
			{
				panel.Children.Remove(child);
			}
			ContentControl contentControl = parent as ContentControl;
			if (contentControl != null)
			{
				contentControl.Content = null;
			}
			Decorator decorator = parent as Decorator;
			if (decorator != null)
			{
				decorator.Child = null;
			}
		}

		// Token: 0x06000A88 RID: 2696 RVA: 0x0004ACB8 File Offset: 0x00048EB8
		public static void UpdateLocale(string locale, string vmToIgnore = "")
		{
			new List<string>();
			using (List<string>.Enumerator enumerator = RegistryManager.Instance.VmList.ToList<string>().GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					string itemVMName = enumerator.Current;
					if (RegistryManager.Instance.UserSelectedLocale != RegistryManager.Instance.Guest[itemVMName].Locale)
					{
						RegistryManager.Instance.Guest[itemVMName].Locale = locale;
						Utils.UpdateValueInBootParams("LANG", locale, itemVMName, false);
						if (BlueStacksUIUtils.DictWindows.ContainsKey(itemVMName) && string.Compare(itemVMName, vmToIgnore.Trim(), true) != 0)
						{
							string cmd = string.Format("setlocale {0}", locale);
							new Thread(delegate()
							{
								if (VmCmdHandler.RunCommand(cmd, itemVMName) == null)
								{
									Logger.Error("Set locale did not work for vm " + itemVMName);
								}
							})
							{
								IsBackground = true
							}.Start();
						}
					}
				}
			}
			LocaleStrings.InitLocalization(null);
		}

		// Token: 0x06000A89 RID: 2697 RVA: 0x0004ADE8 File Offset: 0x00048FE8
		internal bool SendBluestacksLoginRequest(string vmName)
		{
			bool result = false;
			try
			{
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary.Add("action", "com.bluestacks.account.RETRY_BLUESTACKS_LOGIN");
				dictionary.Add("extras", new JObject
				{
					{
						"windows",
						"true"
					}
				}.ToString(Formatting.None, new JsonConverter[0]));
				Logger.Info("Sending bluestacks login request");
				HTTPUtils.SendRequestToGuest("customStartService".ToLower(), dictionary, vmName, 500, null, false, 1, 0);
				result = true;
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't send request to guest for login. Ex: {0}", new object[]
				{
					ex.Message
				});
			}
			return result;
		}

		// Token: 0x06000A8A RID: 2698 RVA: 0x000087C7 File Offset: 0x000069C7
		internal static bool CheckIfMacroScriptBookmarked(string fileName)
		{
			return RegistryManager.Instance.BookmarkedScriptList.Contains(fileName);
		}

		// Token: 0x06000A8B RID: 2699 RVA: 0x000087DE File Offset: 0x000069DE
		internal static string GetMacroPlaybackEventName(string vmname)
		{
			return string.Format("{0}-{1}", "MacroPlayBack", vmname);
		}

		// Token: 0x06000A8C RID: 2700 RVA: 0x0004AE98 File Offset: 0x00049098
		internal void HandleLaunchPlay(string package)
		{
			object obj = BlueStacksUIUtils.mLaunchPlaySyncObj;
			lock (obj)
			{
				int i = 180000;
				while (i > 0)
				{
					i--;
					if (this.ParentWindow.mEnableLaunchPlayForNCSoft || (!FeatureManager.Instance.IsCustomUIForNCSoft && this.ParentWindow.mGuestBootCompleted))
					{
						break;
					}
					Thread.Sleep(1000);
				}
				if (i > 0)
				{
					HTTPUtils.SendRequestToGuest(string.Format("launchplay?pkgname={0}", package), null, this.ParentWindow.mVmName, 0, null, false, 1, 0);
				}
			}
		}

		// Token: 0x06000A8D RID: 2701 RVA: 0x0004AF30 File Offset: 0x00049130
		internal void VolumeDownHandler()
		{
			if (this.CurrentVolumeLevel == 0)
			{
				return;
			}
			int num = this.CurrentVolumeLevel - 7;
			if (num <= 0)
			{
				num = 0;
			}
			this.SetVolumeInFrontendAsync(num);
		}

		// Token: 0x06000A8E RID: 2702 RVA: 0x0004AF5C File Offset: 0x0004915C
		internal void VolumeUpHandler()
		{
			if (this.CurrentVolumeLevel >= 100)
			{
				return;
			}
			int num = this.CurrentVolumeLevel + 7;
			if (num >= 100)
			{
				num = 100;
			}
			this.SetVolumeInFrontendAsync(num);
		}

		// Token: 0x06000A8F RID: 2703 RVA: 0x000087F0 File Offset: 0x000069F0
		internal void ToggleTopBarSidebarEnabled(bool isEnabled)
		{
			this.ParentWindow.TopBar.IsEnabled = isEnabled;
			this.ParentWindow.mSidebar.IsEnabled = isEnabled;
		}

		// Token: 0x06000A90 RID: 2704 RVA: 0x0004AF8C File Offset: 0x0004918C
		internal static Dictionary<string, string> GetResolutionData()
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			int guestWidth = RegistryManager.Instance.Guest[Strings.CurrentDefaultVmName].GuestWidth;
			int guestHeight = RegistryManager.Instance.Guest[Strings.CurrentDefaultVmName].GuestHeight;
			string value = Convert.ToString(guestWidth, CultureInfo.InvariantCulture) + "x" + Convert.ToString(guestHeight, CultureInfo.InvariantCulture);
			dictionary.Add("resolution", value);
			double num = (double)guestWidth / (double)guestHeight;
			string value2 = "landscape";
			if (num < 1.0)
			{
				value2 = "portrait";
			}
			dictionary.Add("resolution_type", value2);
			return dictionary;
		}

		// Token: 0x040007BF RID: 1983
		private MainWindow ParentWindow;

		// Token: 0x040007C0 RID: 1984
		private int mCurrentVolumeLevel = 33;

		// Token: 0x040007C1 RID: 1985
		internal static object mLaunchPlaySyncObj = new object();

		// Token: 0x040007C2 RID: 1986
		internal static string sLoggedInImageName = "loggedin";

		// Token: 0x040007C3 RID: 1987
		internal static string sPremiumUserImageName = "premiumuser";

		// Token: 0x040007C4 RID: 1988
		internal static string sUserAccountPackageName = "com.uncube.account";

		// Token: 0x040007C5 RID: 1989
		internal static string sUserAccountActivityName = "com.bluestacks.account.activities.AccountActivity_";

		// Token: 0x040007C6 RID: 1990
		internal static string sAndroidSettingsPackageName = "com.android.settings";

		// Token: 0x040007C7 RID: 1991
		internal static string sAndroidAccountSettingsActivityName = "com.android.settings.BstAccountsSettings";

		// Token: 0x040007C8 RID: 1992
		internal static bool sStopStatSendingThread = false;

		// Token: 0x040007C9 RID: 1993
		internal System.Timers.Timer sBootCheckTimer = new System.Timers.Timer(360000.0);

		// Token: 0x040007CA RID: 1994
		internal static List<string> lstCreatingWindows = new List<string>();

		// Token: 0x040007CB RID: 1995
		internal static Dictionary<string, MainWindow> DictWindows = new Dictionary<string, MainWindow>();

		// Token: 0x040007CC RID: 1996
		internal static bool sIsSynchronizationActive = false;

		// Token: 0x040007CD RID: 1997
		internal static List<string> sSelectedInstancesForSync = new List<string>();

		// Token: 0x040007CE RID: 1998
		public static MainWindow LastActivatedWindow;

		// Token: 0x040007CF RID: 1999
		public static MainWindow ActivatedWindow;

		// Token: 0x040007D0 RID: 2000
		public static Dictionary<string, List<EventHandler>> BootEventsForMIManager = new Dictionary<string, List<EventHandler>>();

		// Token: 0x040007D1 RID: 2001
		public static List<string> sSyncInvolvedInstances = new List<string>();

		// Token: 0x040007D2 RID: 2002
		private static bool? isOglSupported = null;
	}
}
