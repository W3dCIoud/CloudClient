﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000144 RID: 324
	public class Fraction
	{
		// Token: 0x06000C7A RID: 3194 RVA: 0x00009A1A File Offset: 0x00007C1A
		public Fraction()
		{
			this.Initialize(0L, 1L);
		}

		// Token: 0x06000C7B RID: 3195 RVA: 0x00009A2C File Offset: 0x00007C2C
		public Fraction(long iWholeNumber)
		{
			this.Initialize(iWholeNumber, 1L);
		}

		// Token: 0x06000C7C RID: 3196 RVA: 0x00054B18 File Offset: 0x00052D18
		public Fraction(double dDecimalValue)
		{
			Fraction fraction = Fraction.ToFraction(dDecimalValue);
			this.Initialize(fraction.Numerator, fraction.Denominator);
		}

		// Token: 0x06000C7D RID: 3197 RVA: 0x00054B44 File Offset: 0x00052D44
		public Fraction(string strValue)
		{
			Fraction fraction = Fraction.ToFraction(strValue);
			this.Initialize(fraction.Numerator, fraction.Denominator);
		}

		// Token: 0x06000C7E RID: 3198 RVA: 0x00009A3D File Offset: 0x00007C3D
		public Fraction(long iNumerator, long iDenominator)
		{
			this.Initialize(iNumerator, iDenominator);
		}

		// Token: 0x06000C7F RID: 3199 RVA: 0x00009A4D File Offset: 0x00007C4D
		private void Initialize(long iNumerator, long iDenominator)
		{
			this.Numerator = iNumerator;
			this.Denominator = iDenominator;
			Fraction.ReduceFraction(this);
		}

		// Token: 0x170001CE RID: 462
		// (get) Token: 0x06000C80 RID: 3200 RVA: 0x00009A63 File Offset: 0x00007C63
		// (set) Token: 0x06000C81 RID: 3201 RVA: 0x00009A6B File Offset: 0x00007C6B
		public long Denominator
		{
			get
			{
				return this.m_iDenominator;
			}
			set
			{
				if (value != 0L)
				{
					this.m_iDenominator = value;
					this.CalculateDoubleValue();
					return;
				}
				throw new FractionException("Denominator cannot be assigned a ZERO Value");
			}
		}

		// Token: 0x170001CF RID: 463
		// (get) Token: 0x06000C82 RID: 3202 RVA: 0x00009A88 File Offset: 0x00007C88
		// (set) Token: 0x06000C83 RID: 3203 RVA: 0x00009A90 File Offset: 0x00007C90
		public long Numerator
		{
			get
			{
				return this.m_iNumerator;
			}
			set
			{
				this.m_iNumerator = value;
				this.CalculateDoubleValue();
			}
		}

		// Token: 0x170001D0 RID: 464
		// (set) Token: 0x06000C84 RID: 3204 RVA: 0x00009A9F File Offset: 0x00007C9F
		public long Value
		{
			set
			{
				this.m_iNumerator = value;
				this.m_iDenominator = 1L;
			}
		}

		// Token: 0x170001D1 RID: 465
		// (get) Token: 0x06000C85 RID: 3205 RVA: 0x00009AB0 File Offset: 0x00007CB0
		// (set) Token: 0x06000C86 RID: 3206 RVA: 0x00009AB8 File Offset: 0x00007CB8
		public double DoubleValue
		{
			get
			{
				return this.m_iDoubleValue;
			}
			set
			{
				this.m_iDoubleValue = value;
			}
		}

		// Token: 0x06000C87 RID: 3207 RVA: 0x00009AC1 File Offset: 0x00007CC1
		private void CalculateDoubleValue()
		{
			this.m_iDoubleValue = (double)this.m_iNumerator / (double)this.m_iDenominator;
		}

		// Token: 0x06000C88 RID: 3208 RVA: 0x00009AD8 File Offset: 0x00007CD8
		public double ToDouble()
		{
			return (double)this.Numerator / (double)this.Denominator;
		}

		// Token: 0x06000C89 RID: 3209 RVA: 0x00054B70 File Offset: 0x00052D70
		public override string ToString()
		{
			string result;
			if (this.Denominator == 1L)
			{
				result = this.Numerator.ToString();
			}
			else
			{
				result = this.Numerator + "/" + this.Denominator;
			}
			return result;
		}

		// Token: 0x06000C8A RID: 3210 RVA: 0x00054BBC File Offset: 0x00052DBC
		public static Fraction ToFraction(string strValue)
		{
			int num = 0;
			while (num < strValue.Length && strValue[num] != '/')
			{
				num++;
			}
			if (num == strValue.Length)
			{
				return Convert.ToDouble(strValue);
			}
			long iNumerator = Convert.ToInt64(strValue.Substring(0, num));
			long iDenominator = Convert.ToInt64(strValue.Substring(num + 1));
			return new Fraction(iNumerator, iDenominator);
		}

		// Token: 0x06000C8B RID: 3211 RVA: 0x00054C1C File Offset: 0x00052E1C
		public static Fraction ToFraction(double dValue)
		{
			checked
			{
				Fraction result;
				try
				{
					Fraction fraction;
					if (dValue % 1.0 == 0.0)
					{
						fraction = new Fraction((long)dValue);
					}
					else
					{
						double num = dValue;
						long num2 = 1L;
						string text = dValue.ToString();
						while (text.IndexOf("E") > 0)
						{
							unchecked
							{
								num *= 10.0;
							}
							num2 *= 10L;
							text = num.ToString();
						}
						int num3 = 0;
						while (text[num3] != '.')
						{
							num3++;
						}
						for (int i = text.Length - num3 - 1; i > 0; i--)
						{
							unchecked
							{
								num *= 10.0;
							}
							num2 *= 10L;
						}
						fraction = new Fraction(unchecked((long)(checked((int)Math.Round(num)))), num2);
					}
					result = fraction;
				}
				catch (OverflowException)
				{
					throw new FractionException("Conversion not possible due to overflow");
				}
				catch (Exception)
				{
					throw new FractionException("Conversion not possible");
				}
				return result;
			}
		}

		// Token: 0x06000C8C RID: 3212 RVA: 0x00009AE9 File Offset: 0x00007CE9
		public Fraction Duplicate()
		{
			return new Fraction
			{
				Numerator = this.Numerator,
				Denominator = this.Denominator
			};
		}

		// Token: 0x06000C8D RID: 3213 RVA: 0x00054D10 File Offset: 0x00052F10
		public static Fraction Inverse(Fraction frac1)
		{
			if (frac1.Numerator == 0L)
			{
				throw new FractionException("Operation not possible (Denominator cannot be assigned a ZERO Value)");
			}
			long denominator = frac1.Denominator;
			long numerator = frac1.Numerator;
			return new Fraction(denominator, numerator);
		}

		// Token: 0x06000C8E RID: 3214 RVA: 0x00009B08 File Offset: 0x00007D08
		public static Fraction operator -(Fraction frac1)
		{
			return Fraction.Negate(frac1);
		}

		// Token: 0x06000C8F RID: 3215 RVA: 0x00009B10 File Offset: 0x00007D10
		public static Fraction operator +(Fraction frac1, Fraction frac2)
		{
			return Fraction.Add(frac1, frac2);
		}

		// Token: 0x06000C90 RID: 3216 RVA: 0x00009B19 File Offset: 0x00007D19
		public static Fraction operator +(int iNo, Fraction frac1)
		{
			return Fraction.Add(frac1, new Fraction((long)iNo));
		}

		// Token: 0x06000C91 RID: 3217 RVA: 0x00009B28 File Offset: 0x00007D28
		public static Fraction operator +(Fraction frac1, int iNo)
		{
			return Fraction.Add(frac1, new Fraction((long)iNo));
		}

		// Token: 0x06000C92 RID: 3218 RVA: 0x00009B37 File Offset: 0x00007D37
		public static Fraction operator +(double dbl, Fraction frac1)
		{
			return Fraction.Add(frac1, Fraction.ToFraction(dbl));
		}

		// Token: 0x06000C93 RID: 3219 RVA: 0x00009B45 File Offset: 0x00007D45
		public static Fraction operator +(Fraction frac1, double dbl)
		{
			return Fraction.Add(frac1, Fraction.ToFraction(dbl));
		}

		// Token: 0x06000C94 RID: 3220 RVA: 0x00009B53 File Offset: 0x00007D53
		public static Fraction operator -(Fraction frac1, Fraction frac2)
		{
			return Fraction.Add(frac1, -frac2);
		}

		// Token: 0x06000C95 RID: 3221 RVA: 0x00009B61 File Offset: 0x00007D61
		public static Fraction operator -(int iNo, Fraction frac1)
		{
			return Fraction.Add(-frac1, new Fraction((long)iNo));
		}

		// Token: 0x06000C96 RID: 3222 RVA: 0x00009B75 File Offset: 0x00007D75
		public static Fraction operator -(Fraction frac1, int iNo)
		{
			return Fraction.Add(frac1, -new Fraction((long)iNo));
		}

		// Token: 0x06000C97 RID: 3223 RVA: 0x00009B89 File Offset: 0x00007D89
		public static Fraction operator -(double dbl, Fraction frac1)
		{
			return Fraction.Add(-frac1, Fraction.ToFraction(dbl));
		}

		// Token: 0x06000C98 RID: 3224 RVA: 0x00009B9C File Offset: 0x00007D9C
		public static Fraction operator -(Fraction frac1, double dbl)
		{
			return Fraction.Add(frac1, -Fraction.ToFraction(dbl));
		}

		// Token: 0x06000C99 RID: 3225 RVA: 0x00009BAF File Offset: 0x00007DAF
		public static Fraction operator *(Fraction frac1, Fraction frac2)
		{
			return Fraction.Multiply(frac1, frac2);
		}

		// Token: 0x06000C9A RID: 3226 RVA: 0x00009BB8 File Offset: 0x00007DB8
		public static Fraction operator *(int iNo, Fraction frac1)
		{
			return Fraction.Multiply(frac1, new Fraction((long)iNo));
		}

		// Token: 0x06000C9B RID: 3227 RVA: 0x00009BC7 File Offset: 0x00007DC7
		public static Fraction operator *(Fraction frac1, int iNo)
		{
			return Fraction.Multiply(frac1, new Fraction((long)iNo));
		}

		// Token: 0x06000C9C RID: 3228 RVA: 0x00009BD6 File Offset: 0x00007DD6
		public static Fraction operator *(double dbl, Fraction frac1)
		{
			return Fraction.Multiply(frac1, Fraction.ToFraction(dbl));
		}

		// Token: 0x06000C9D RID: 3229 RVA: 0x00009BE4 File Offset: 0x00007DE4
		public static Fraction operator *(Fraction frac1, double dbl)
		{
			return Fraction.Multiply(frac1, Fraction.ToFraction(dbl));
		}

		// Token: 0x06000C9E RID: 3230 RVA: 0x00009BF2 File Offset: 0x00007DF2
		public static Fraction operator /(Fraction frac1, Fraction frac2)
		{
			return Fraction.Multiply(frac1, Fraction.Inverse(frac2));
		}

		// Token: 0x06000C9F RID: 3231 RVA: 0x00009C00 File Offset: 0x00007E00
		public static Fraction operator /(int iNo, Fraction frac1)
		{
			return Fraction.Multiply(Fraction.Inverse(frac1), new Fraction((long)iNo));
		}

		// Token: 0x06000CA0 RID: 3232 RVA: 0x00009C14 File Offset: 0x00007E14
		public static Fraction operator /(Fraction frac1, int iNo)
		{
			return Fraction.Multiply(frac1, Fraction.Inverse(new Fraction((long)iNo)));
		}

		// Token: 0x06000CA1 RID: 3233 RVA: 0x00009C28 File Offset: 0x00007E28
		public static Fraction operator /(double dbl, Fraction frac1)
		{
			return Fraction.Multiply(Fraction.Inverse(frac1), Fraction.ToFraction(dbl));
		}

		// Token: 0x06000CA2 RID: 3234 RVA: 0x00009C3B File Offset: 0x00007E3B
		public static Fraction operator /(Fraction frac1, double dbl)
		{
			return Fraction.Multiply(frac1, Fraction.Inverse(Fraction.ToFraction(dbl)));
		}

		// Token: 0x06000CA3 RID: 3235 RVA: 0x00009C4E File Offset: 0x00007E4E
		public static bool operator ==(Fraction frac1, Fraction frac2)
		{
			return frac1.Equals(frac2);
		}

		// Token: 0x06000CA4 RID: 3236 RVA: 0x00009C57 File Offset: 0x00007E57
		public static bool operator !=(Fraction frac1, Fraction frac2)
		{
			return !frac1.Equals(frac2);
		}

		// Token: 0x06000CA5 RID: 3237 RVA: 0x00009C63 File Offset: 0x00007E63
		public static bool operator ==(Fraction frac1, int iNo)
		{
			return frac1.Equals(new Fraction((long)iNo));
		}

		// Token: 0x06000CA6 RID: 3238 RVA: 0x00009C72 File Offset: 0x00007E72
		public static bool operator !=(Fraction frac1, int iNo)
		{
			return !frac1.Equals(new Fraction((long)iNo));
		}

		// Token: 0x06000CA7 RID: 3239 RVA: 0x00009C84 File Offset: 0x00007E84
		public static bool operator ==(Fraction frac1, double dbl)
		{
			return frac1.Equals(new Fraction(dbl));
		}

		// Token: 0x06000CA8 RID: 3240 RVA: 0x00009C92 File Offset: 0x00007E92
		public static bool operator !=(Fraction frac1, double dbl)
		{
			return !frac1.Equals(new Fraction(dbl));
		}

		// Token: 0x06000CA9 RID: 3241 RVA: 0x00009CA3 File Offset: 0x00007EA3
		public static bool operator <(Fraction frac1, Fraction frac2)
		{
			return frac1.Numerator * frac2.Denominator < frac2.Numerator * frac1.Denominator;
		}

		// Token: 0x06000CAA RID: 3242 RVA: 0x00009CC1 File Offset: 0x00007EC1
		public static bool operator >(Fraction frac1, Fraction frac2)
		{
			return frac1.Numerator * frac2.Denominator > frac2.Numerator * frac1.Denominator;
		}

		// Token: 0x06000CAB RID: 3243 RVA: 0x00009CDF File Offset: 0x00007EDF
		public static bool operator <=(Fraction frac1, Fraction frac2)
		{
			return frac1.Numerator * frac2.Denominator <= frac2.Numerator * frac1.Denominator;
		}

		// Token: 0x06000CAC RID: 3244 RVA: 0x00009D00 File Offset: 0x00007F00
		public static bool operator >=(Fraction frac1, Fraction frac2)
		{
			return frac1.Numerator * frac2.Denominator >= frac2.Numerator * frac1.Denominator;
		}

		// Token: 0x06000CAD RID: 3245 RVA: 0x00009D21 File Offset: 0x00007F21
		public static implicit operator Fraction(long lNo)
		{
			return new Fraction(lNo);
		}

		// Token: 0x06000CAE RID: 3246 RVA: 0x00009D29 File Offset: 0x00007F29
		public static implicit operator Fraction(double dNo)
		{
			return new Fraction(dNo);
		}

		// Token: 0x06000CAF RID: 3247 RVA: 0x00009D31 File Offset: 0x00007F31
		public static implicit operator Fraction(string strNo)
		{
			return new Fraction(strNo);
		}

		// Token: 0x06000CB0 RID: 3248 RVA: 0x00009D39 File Offset: 0x00007F39
		public static explicit operator double(Fraction frac)
		{
			return frac.ToDouble();
		}

		// Token: 0x06000CB1 RID: 3249 RVA: 0x00009D41 File Offset: 0x00007F41
		public static implicit operator string(Fraction frac)
		{
			return frac.ToString();
		}

		// Token: 0x06000CB2 RID: 3250 RVA: 0x00054D44 File Offset: 0x00052F44
		public override bool Equals(object obj)
		{
			Fraction fraction = (Fraction)obj;
			return this.Numerator == fraction.Numerator && this.Denominator == fraction.Denominator;
		}

		// Token: 0x06000CB3 RID: 3251 RVA: 0x00009D49 File Offset: 0x00007F49
		public override int GetHashCode()
		{
			return Convert.ToInt32((this.Numerator ^ this.Denominator) & (long)((ulong)-1));
		}

		// Token: 0x06000CB4 RID: 3252 RVA: 0x00054D78 File Offset: 0x00052F78
		private static Fraction Negate(Fraction frac1)
		{
			long iNumerator = -frac1.Numerator;
			long denominator = frac1.Denominator;
			return new Fraction(iNumerator, denominator);
		}

		// Token: 0x06000CB5 RID: 3253 RVA: 0x00054D9C File Offset: 0x00052F9C
		private static Fraction Add(Fraction frac1, Fraction frac2)
		{
			checked
			{
				Fraction result;
				try
				{
					long iNumerator = frac1.Numerator * frac2.Denominator + frac2.Numerator * frac1.Denominator;
					long iDenominator = frac1.Denominator * frac2.Denominator;
					result = new Fraction(iNumerator, iDenominator);
				}
				catch (OverflowException)
				{
					throw new FractionException("Overflow occurred while performing arithemetic operation");
				}
				catch (Exception)
				{
					throw new FractionException("An error occurred while performing arithemetic operation");
				}
				return result;
			}
		}

		// Token: 0x06000CB6 RID: 3254 RVA: 0x00054E10 File Offset: 0x00053010
		private static Fraction Multiply(Fraction frac1, Fraction frac2)
		{
			checked
			{
				Fraction result;
				try
				{
					long iNumerator = frac1.Numerator * frac2.Numerator;
					long iDenominator = frac1.Denominator * frac2.Denominator;
					result = new Fraction(iNumerator, iDenominator);
				}
				catch (OverflowException)
				{
					throw new FractionException("Overflow occurred while performing arithemetic operation");
				}
				catch (Exception)
				{
					throw new FractionException("An error occurred while performing arithemetic operation");
				}
				return result;
			}
		}

		// Token: 0x06000CB7 RID: 3255 RVA: 0x00009D60 File Offset: 0x00007F60
		private static long GCD(long iNo1, long iNo2)
		{
			if (iNo1 < 0L)
			{
				iNo1 = -iNo1;
			}
			if (iNo2 < 0L)
			{
				iNo2 = -iNo2;
			}
			do
			{
				if (iNo1 < iNo2)
				{
					long num = iNo1;
					iNo1 = iNo2;
					iNo2 = num;
				}
				iNo1 %= iNo2;
			}
			while (iNo1 != 0L);
			return iNo2;
		}

		// Token: 0x06000CB8 RID: 3256 RVA: 0x00054E78 File Offset: 0x00053078
		public static void ReduceFraction(Fraction frac)
		{
			try
			{
				if (frac.Numerator == 0L)
				{
					frac.Denominator = 1L;
				}
				else
				{
					long num = Fraction.GCD(frac.Numerator, frac.Denominator);
					frac.Numerator /= num;
					frac.Denominator /= num;
					if (frac.Denominator < 0L)
					{
						frac.Numerator *= -1L;
						frac.Denominator *= -1L;
					}
				}
			}
			catch (Exception ex)
			{
				throw new FractionException("Cannot reduce Fraction: " + ex.Message);
			}
		}

		// Token: 0x0400092A RID: 2346
		private long m_iNumerator;

		// Token: 0x0400092B RID: 2347
		private long m_iDenominator;

		// Token: 0x0400092C RID: 2348
		private double m_iDoubleValue;
	}
}
