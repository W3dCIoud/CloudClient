﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001F7 RID: 503
	public partial class HomeAppTabButton : Button
	{
		// Token: 0x17000200 RID: 512
		// (get) Token: 0x06001160 RID: 4448 RVA: 0x0000C52C File Offset: 0x0000A72C
		// (set) Token: 0x06001161 RID: 4449 RVA: 0x0000C534 File Offset: 0x0000A734
		public string Key
		{
			get
			{
				return this.mKey;
			}
			set
			{
				this.mKey = value;
			}
		}

		// Token: 0x17000201 RID: 513
		// (get) Token: 0x06001162 RID: 4450 RVA: 0x0000C53D File Offset: 0x0000A73D
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x17000202 RID: 514
		// (get) Token: 0x06001163 RID: 4451 RVA: 0x0000C55E File Offset: 0x0000A75E
		// (set) Token: 0x06001164 RID: 4452 RVA: 0x0000C56B File Offset: 0x0000A76B
		public string Text
		{
			get
			{
				return this.mTabHeader.Text;
			}
			set
			{
				this.Key = value + "-Normal";
				this.ImageBox.ImageName = this.Key;
				BlueStacksUIBinding.Bind(this.mTabHeader, value, "");
			}
		}

		// Token: 0x17000203 RID: 515
		// (get) Token: 0x06001165 RID: 4453 RVA: 0x0000C5A0 File Offset: 0x0000A7A0
		// (set) Token: 0x06001166 RID: 4454 RVA: 0x0000C5A8 File Offset: 0x0000A7A8
		public int Column { get; internal set; }

		// Token: 0x17000204 RID: 516
		// (get) Token: 0x06001167 RID: 4455 RVA: 0x0000C5B1 File Offset: 0x0000A7B1
		// (set) Token: 0x06001168 RID: 4456 RVA: 0x0000C5B9 File Offset: 0x0000A7B9
		public BrowserControl AssociatedUserControl
		{
			get
			{
				return this.mAssociatedUserControl;
			}
			set
			{
				this.mAssociatedUserControl = value;
				if (this.mAssociatedUserControl != null)
				{
					this.mAssociatedUserControl.RenderTransform = this.mTranslateTransform;
				}
			}
		}

		// Token: 0x06001169 RID: 4457 RVA: 0x0006C5BC File Offset: 0x0006A7BC
		private void AssociatedGrid_LayoutUpdated(object sender, EventArgs e)
		{
			try
			{
				if (!this.IsSelected && Math.Abs(Math.Abs(this.mTranslateTransform.X) - this.mAssociatedUserControl.ActualWidth) <= 10.0)
				{
					this.mAssociatedUserControl.Visibility = Visibility.Hidden;
					this.mAssociatedUserControl.LayoutUpdated -= this.AssociatedGrid_LayoutUpdated;
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Error updating " + ex.ToString());
			}
		}

		// Token: 0x17000205 RID: 517
		// (get) Token: 0x0600116A RID: 4458 RVA: 0x0000C5DB File Offset: 0x0000A7DB
		// (set) Token: 0x0600116B RID: 4459 RVA: 0x0006C64C File Offset: 0x0006A84C
		public bool IsSelected
		{
			get
			{
				return this.mIsSelected;
			}
			set
			{
				if (this.ParentWindow.StaticComponents.mSelectedHomeAppTabButton != this || !value)
				{
					this.mIsSelected = value;
					if (this.ParentWindow.StaticComponents.mSelectedHomeAppTabButton != null)
					{
						HomeAppTabButton mSelectedHomeAppTabButton = this.ParentWindow.StaticComponents.mSelectedHomeAppTabButton;
						if (this.Column > mSelectedHomeAppTabButton.Column)
						{
							HomeAppTabButton.mIsSwipeDirectonLeft = true;
						}
						else
						{
							HomeAppTabButton.mIsSwipeDirectonLeft = false;
						}
						this.ParentWindow.StaticComponents.mSelectedHomeAppTabButton = null;
						if (this.mAssociatedUserControl == mSelectedHomeAppTabButton.mAssociatedUserControl)
						{
							mSelectedHomeAppTabButton.IsAnimationIgnored = true;
							this.IsAnimationIgnored = true;
						}
						mSelectedHomeAppTabButton.IsSelected = false;
					}
					if (this.mIsSelected)
					{
						BlueStacksUIBinding.BindColor(this.mTabHeader, TextBlock.ForegroundProperty, "SelectedHomeAppTabForegroundColor");
						BlueStacksUIBinding.BindColor(this.mBottomGrid, Panel.BackgroundProperty, "HomeAppTabBackgroundColor");
						this.ParentWindow.StaticComponents.mSelectedHomeAppTabButton = this;
						this.ParentWindow.Utils.ResetPendingUIOperations();
						this.mGridHighlighterBox.Visibility = Visibility.Visible;
						this.AnimateAssociatedGrid(true);
						this.ImageBox.ImageName = this.Key.Replace("Normal", "Active");
						if (this.mAssociatedUserControl.mBrowser != null)
						{
							MiscUtils.SetFocusAsync(this.ParentWindow.mWelcomeTab.mHomeApp.mSearchTextBox, this.animationTime + 100);
							MiscUtils.SetFocusAsync(this.mAssociatedUserControl.mBrowser, 0);
							return;
						}
					}
					else
					{
						BlueStacksUIBinding.BindColor(this.mTabHeader, TextBlock.ForegroundProperty, "HomeAppTabForegroundColor");
						this.mGridHighlighterBox.Visibility = Visibility.Hidden;
						this.AnimateAssociatedGrid(false);
						this.ImageBox.ImageName = this.Key.Replace("Active", "Normal");
					}
				}
			}
		}

		// Token: 0x0600116C RID: 4460 RVA: 0x0006C800 File Offset: 0x0006AA00
		private void AnimateAssociatedGrid(bool show)
		{
			if (this.IsAnimationIgnored)
			{
				this.IsAnimationIgnored = false;
				return;
			}
			this.mAssociatedUserControl.LayoutUpdated += this.AssociatedGrid_LayoutUpdated;
			DoubleAnimation animation;
			if (show)
			{
				this.mAssociatedUserControl.Visibility = Visibility.Visible;
				if (HomeAppTabButton.mIsSwipeDirectonLeft)
				{
					animation = new DoubleAnimation(this.mAssociatedUserControl.ActualWidth, 0.0, TimeSpan.FromMilliseconds((double)this.animationTime));
				}
				else
				{
					animation = new DoubleAnimation(-1.0 * this.mAssociatedUserControl.ActualWidth, 0.0, TimeSpan.FromMilliseconds((double)this.animationTime));
				}
			}
			else if (HomeAppTabButton.mIsSwipeDirectonLeft)
			{
				animation = new DoubleAnimation(0.0, -1.0 * this.mAssociatedUserControl.ActualWidth, TimeSpan.FromMilliseconds((double)this.animationTime));
			}
			else
			{
				animation = new DoubleAnimation(0.0, this.mAssociatedUserControl.ActualWidth, TimeSpan.FromMilliseconds((double)this.animationTime));
			}
			this.mTranslateTransform.BeginAnimation(TranslateTransform.XProperty, animation);
		}

		// Token: 0x0600116D RID: 4461 RVA: 0x0000C5E3 File Offset: 0x0000A7E3
		public HomeAppTabButton()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600116E RID: 4462 RVA: 0x0000C612 File Offset: 0x0000A812
		private void Button_Click(object sender, RoutedEventArgs e)
		{
			this.IsSelected = true;
		}

		// Token: 0x0600116F RID: 4463 RVA: 0x0000C61B File Offset: 0x0000A81B
		private void Button_MouseEnter(object sender, MouseEventArgs e)
		{
			if (!this.IsSelected)
			{
				BlueStacksUIBinding.BindColor(this.mBottomGrid, Panel.BackgroundProperty, "HomeAppTabBackgroundHoverColor");
				BlueStacksUIBinding.BindColor(this.mTabHeader, TextBlock.ForegroundProperty, "HomeAppTabForegroundHoverColor");
			}
		}

		// Token: 0x06001170 RID: 4464 RVA: 0x0000C64F File Offset: 0x0000A84F
		private void Button_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.IsSelected)
			{
				BlueStacksUIBinding.BindColor(this.mBottomGrid, Panel.BackgroundProperty, "HomeAppTabBackgroundColor");
				BlueStacksUIBinding.BindColor(this.mTabHeader, TextBlock.ForegroundProperty, "HomeAppTabForegroundColor");
			}
		}

		// Token: 0x06001171 RID: 4465 RVA: 0x0000C683 File Offset: 0x0000A883
		private void Button_Loaded(object sender, RoutedEventArgs e)
		{
			this.SetMaxWidth(0.0);
		}

		// Token: 0x06001172 RID: 4466 RVA: 0x0006C92C File Offset: 0x0006AB2C
		internal void SetMaxWidth(double extraWidth = 0.0)
		{
			double num = 0.0;
			Typeface typeface = new Typeface(this.mTabHeader.FontFamily, this.mTabHeader.FontStyle, this.mTabHeader.FontWeight, this.mTabHeader.FontStretch);
			FormattedText formattedText = new FormattedText(this.mTabHeader.Text, Thread.CurrentThread.CurrentCulture, this.mTabHeader.FlowDirection, typeface, this.mTabHeader.FontSize, this.mTabHeader.Foreground);
			num += this.mAppTabNotificationCountBorder.ActualWidth;
			num += formattedText.WidthIncludingTrailingWhitespace;
			num += this.tabGrid.ActualHeight;
			num += 30.0;
			if (extraWidth == 1.7976931348623157E+308)
			{
				if (this.tabGrid.ColumnDefinitions[0].Width.IsStar)
				{
					num += 50.0;
				}
			}
			else
			{
				num += extraWidth;
			}
			int column = Grid.GetColumn(this.mTabHeader);
			if ((extraWidth > 0.0 && extraWidth < 1.7976931348623157E+308) || (this.tabGrid.ColumnDefinitions[0].Width.IsStar && extraWidth == 1.7976931348623157E+308))
			{
				this.tabGrid.ColumnDefinitions[column].Width = new GridLength(1.0, GridUnitType.Auto);
				this.tabGrid.ColumnDefinitions[0].Width = new GridLength(1.0, GridUnitType.Star);
				this.tabGrid.ColumnDefinitions[5].Width = new GridLength(1.0, GridUnitType.Star);
			}
			else
			{
				this.tabGrid.ColumnDefinitions[column].Width = new GridLength(1.0, GridUnitType.Star);
				this.tabGrid.ColumnDefinitions[0].Width = new GridLength(0.0, GridUnitType.Pixel);
				this.tabGrid.ColumnDefinitions[5].Width = new GridLength(0.0, GridUnitType.Pixel);
			}
			column = Grid.GetColumn(this);
			((Grid)base.Parent).ColumnDefinitions[column].MaxWidth = num;
		}

		// Token: 0x06001173 RID: 4467 RVA: 0x0000C683 File Offset: 0x0000A883
		private void mAppTabNotificationCountBorder_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			this.SetMaxWidth(0.0);
		}

		// Token: 0x04000BE6 RID: 3046
		private string mKey = string.Empty;

		// Token: 0x04000BE7 RID: 3047
		private int animationTime = 150;

		// Token: 0x04000BE8 RID: 3048
		private MainWindow mMainWindow;

		// Token: 0x04000BEA RID: 3050
		private static bool mIsSwipeDirectonLeft = true;

		// Token: 0x04000BEB RID: 3051
		private TranslateTransform mTranslateTransform = new TranslateTransform();

		// Token: 0x04000BEC RID: 3052
		private BrowserControl mAssociatedUserControl;

		// Token: 0x04000BED RID: 3053
		private bool mIsSelected;

		// Token: 0x04000BEE RID: 3054
		public bool IsAnimationIgnored;
	}
}
