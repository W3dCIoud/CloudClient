﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000E9 RID: 233
	public class ImportSchemesWindowControl : UserControl, IComponentConnector
	{
		// Token: 0x060009EA RID: 2538 RVA: 0x00008276 File Offset: 0x00006476
		public ImportSchemesWindowControl(ImportSchemesWindow importSchemesWindow, MainWindow window)
		{
			this.InitializeComponent();
			this.mImportSchemesWindow = importSchemesWindow;
			this.ParentWindow = window;
		}

		// Token: 0x060009EB RID: 2539 RVA: 0x00008292 File Offset: 0x00006492
		private void box_Checked(object sender, RoutedEventArgs e)
		{
			this.mImportSchemesWindow.Box_Checked(sender, e);
		}

		// Token: 0x060009EC RID: 2540 RVA: 0x000082A1 File Offset: 0x000064A1
		private void box_Unchecked(object sender, RoutedEventArgs e)
		{
			this.mImportSchemesWindow.Box_Unchecked(sender, e);
		}

		// Token: 0x060009ED RID: 2541 RVA: 0x00046684 File Offset: 0x00044884
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/importschemeswindowcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060009EE RID: 2542 RVA: 0x000466B4 File Offset: 0x000448B4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mContent = (CustomCheckbox)target;
				this.mContent.Checked += this.box_Checked;
				this.mContent.Unchecked += this.box_Unchecked;
				return;
			case 2:
				this.mBlock = (Grid)target;
				return;
			case 3:
				this.mImportName = (CustomTextBox)target;
				return;
			case 4:
				this.mWarningMsg = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400072E RID: 1838
		internal ImportSchemesWindow mImportSchemesWindow;

		// Token: 0x0400072F RID: 1839
		internal MainWindow ParentWindow;

		// Token: 0x04000730 RID: 1840
		internal CustomCheckbox mContent;

		// Token: 0x04000731 RID: 1841
		internal Grid mBlock;

		// Token: 0x04000732 RID: 1842
		internal CustomTextBox mImportName;

		// Token: 0x04000733 RID: 1843
		internal TextBlock mWarningMsg;

		// Token: 0x04000734 RID: 1844
		private bool _contentLoaded;
	}
}
