﻿using System;
using System.ComponentModel;

// Token: 0x02000013 RID: 19
[Description("SubElement")]
[Serializable]
internal class PanShoot : IMAction
{
	// Token: 0x1700008D RID: 141
	// (get) Token: 0x0600012D RID: 301 RVA: 0x00002CBA File Offset: 0x00000EBA
	public string Key
	{
		get
		{
			return this.mPan.KeyAction;
		}
	}

	// Token: 0x1700008E RID: 142
	// (get) Token: 0x0600012E RID: 302 RVA: 0x00002CC7 File Offset: 0x00000EC7
	// (set) Token: 0x0600012F RID: 303 RVA: 0x00002CD4 File Offset: 0x00000ED4
	[Description("IMAP_CanvasElementY")]
	public double X
	{
		get
		{
			return this.mPan.LButtonX;
		}
		set
		{
			this.mPan.LButtonX = value;
		}
	}

	// Token: 0x1700008F RID: 143
	// (get) Token: 0x06000130 RID: 304 RVA: 0x00002CE2 File Offset: 0x00000EE2
	// (set) Token: 0x06000131 RID: 305 RVA: 0x00002CEF File Offset: 0x00000EEF
	[Description("IMAP_CanvasElementX")]
	public double Y
	{
		get
		{
			return this.mPan.LButtonY;
		}
		set
		{
			this.mPan.LButtonY = value;
		}
	}

	// Token: 0x06000132 RID: 306 RVA: 0x00002CFD File Offset: 0x00000EFD
	internal PanShoot(Pan action)
	{
		this.IsChildAction = true;
		base.Type = KeyActionType.PanShoot;
		this.mPan = action;
		this.ParentAction = action;
	}

	// Token: 0x0400008C RID: 140
	private Pan mPan;
}
