﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000064 RID: 100
	public class MacroRecordControl : UserControl, IComponentConnector
	{
		// Token: 0x06000429 RID: 1065 RVA: 0x00004C07 File Offset: 0x00002E07
		public MacroRecordControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600042A RID: 1066 RVA: 0x0001BEC8 File Offset: 0x0001A0C8
		internal void Init(MainWindow window)
		{
			this.ParentWindow = window;
			this.mTimer = new DispatcherTimer(new TimeSpan(0, 0, 0, 0, 50), DispatcherPriority.Render, new EventHandler(this.T_Tick), Dispatcher.CurrentDispatcher);
			this.mPlayMacroImg.Visibility = Visibility.Collapsed;
			this.mPauseMacroImg.Visibility = Visibility.Visible;
			this.mBlinkRecordingIconTimer = new DispatcherTimer(new TimeSpan(0, 0, 0, 0, 500), DispatcherPriority.Render, new EventHandler(this.BlinkRecordingIcon_Tick), Dispatcher.CurrentDispatcher);
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				BlueStacksUIBinding.Bind(this.ParentWindow.mNCTopBar.mMacroRecordingTooltip, "STRING_PAUSE_RECORDING_TOOLTIP", "");
				return;
			}
			BlueStacksUIBinding.Bind(this.ParentWindow.mTopBar.mMacroRecordingTooltip, "STRING_PAUSE_RECORDING_TOOLTIP", "");
		}

		// Token: 0x0600042B RID: 1067 RVA: 0x00004C1C File Offset: 0x00002E1C
		private void BlinkRecordingIcon_Tick(object sender, EventArgs e)
		{
			this.ToggleRecordingIcon();
		}

		// Token: 0x0600042C RID: 1068 RVA: 0x0001BF94 File Offset: 0x0001A194
		private void PauseMacroRecording_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("pauseRecordingCombo", null);
			this.PauseTimer();
			this.mPauseMacroImg.Visibility = Visibility.Collapsed;
			this.mPlayMacroImg.Visibility = Visibility.Visible;
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_record_pause", null, null, null, null, null);
		}

		// Token: 0x0600042D RID: 1069 RVA: 0x00004C24 File Offset: 0x00002E24
		private void ResumeMacroRecording_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("startRecordingCombo", null);
			this.ResumeTimer();
			this.mPlayMacroImg.Visibility = Visibility.Collapsed;
			this.mPauseMacroImg.Visibility = Visibility.Visible;
		}

		// Token: 0x0600042E RID: 1070 RVA: 0x0001C000 File Offset: 0x0001A200
		private void StopMacroRecording_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.StopMacroRecording();
			this.mBlinkRecordingIconTimer.Stop();
			this.mRecordingImage.ImageName = "recording_macro_title_bar";
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_record_stop", null, null, null, null, null);
		}

		// Token: 0x0600042F RID: 1071 RVA: 0x00004C5A File Offset: 0x00002E5A
		internal void StopTimer()
		{
			this.mTimer.Stop();
			this.mBlinkRecordingIconTimer.Stop();
		}

		// Token: 0x06000430 RID: 1072 RVA: 0x00004C72 File Offset: 0x00002E72
		internal void StartTimer()
		{
			this.mTimer.Start();
			this.mStartTime = DateTime.Now;
			this.mBlinkRecordingIconTimer.Start();
		}

		// Token: 0x06000431 RID: 1073 RVA: 0x0001C060 File Offset: 0x0001A260
		private void T_Tick(object sender, EventArgs e)
		{
			TimeSpan timeSpan = DateTime.Now - this.mStartTime;
			string text = string.Format("{0:00}:{1:00}:{2:00}", timeSpan.Minutes, timeSpan.Seconds, timeSpan.Milliseconds / 10);
			this.TimerDisplay.Text = text;
		}

		// Token: 0x06000432 RID: 1074 RVA: 0x00004C95 File Offset: 0x00002E95
		private void ToggleRecordingIcon()
		{
			if (this.mShowRecordingIcon)
			{
				this.mRecordingImage.ImageName = "recording_macro_active";
				this.mShowRecordingIcon = false;
				return;
			}
			this.mRecordingImage.ImageName = "recording_macro";
			this.mShowRecordingIcon = true;
		}

		// Token: 0x06000433 RID: 1075 RVA: 0x00004CCE File Offset: 0x00002ECE
		internal void PauseTimer()
		{
			this.mTimer.IsEnabled = false;
			this.mTimer.Stop();
			this.mPauseTime = DateTime.Now;
			this.mBlinkRecordingIconTimer.Stop();
			this.mShowRecordingIcon = true;
			this.ToggleRecordingIcon();
		}

		// Token: 0x06000434 RID: 1076 RVA: 0x0001C0BC File Offset: 0x0001A2BC
		internal void ResumeTimer()
		{
			TimeSpan t = DateTime.Now - this.mPauseTime;
			this.mStartTime += t;
			this.mTimer.IsEnabled = true;
			this.mTimer.Start();
			this.mBlinkRecordingIconTimer.Start();
			this.mShowRecordingIcon = true;
			this.ToggleRecordingIcon();
		}

		// Token: 0x06000435 RID: 1077 RVA: 0x0001C11C File Offset: 0x0001A31C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/macrorecordcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000436 RID: 1078 RVA: 0x0001C14C File Offset: 0x0001A34C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				this.mRecordingImage = (CustomPictureBox)target;
				return;
			case 3:
				this.TimerDisplay = (TextBlock)target;
				return;
			case 4:
				this.mPauseMacroImg = (CustomPictureBox)target;
				this.mPauseMacroImg.PreviewMouseLeftButtonUp += this.PauseMacroRecording_MouseLeftButtonUp;
				return;
			case 5:
				this.mPlayMacroImg = (CustomPictureBox)target;
				this.mPlayMacroImg.PreviewMouseLeftButtonUp += this.ResumeMacroRecording_MouseLeftButtonUp;
				return;
			case 6:
				this.mStopMacroImg = (CustomPictureBox)target;
				this.mStopMacroImg.PreviewMouseLeftButtonUp += this.StopMacroRecording_PreviewMouseLeftButtonUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000268 RID: 616
		private MainWindow ParentWindow;

		// Token: 0x04000269 RID: 617
		private DispatcherTimer mTimer;

		// Token: 0x0400026A RID: 618
		private DispatcherTimer mBlinkRecordingIconTimer;

		// Token: 0x0400026B RID: 619
		private DateTime mStartTime;

		// Token: 0x0400026C RID: 620
		private DateTime mPauseTime;

		// Token: 0x0400026D RID: 621
		private bool mShowRecordingIcon = true;

		// Token: 0x0400026E RID: 622
		internal Border mMaskBorder;

		// Token: 0x0400026F RID: 623
		internal CustomPictureBox mRecordingImage;

		// Token: 0x04000270 RID: 624
		internal TextBlock TimerDisplay;

		// Token: 0x04000271 RID: 625
		internal CustomPictureBox mPauseMacroImg;

		// Token: 0x04000272 RID: 626
		internal CustomPictureBox mPlayMacroImg;

		// Token: 0x04000273 RID: 627
		internal CustomPictureBox mStopMacroImg;

		// Token: 0x04000274 RID: 628
		private bool _contentLoaded;
	}
}
