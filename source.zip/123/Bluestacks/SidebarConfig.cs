﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000048 RID: 72
	internal class SidebarConfig
	{
		// Token: 0x17000120 RID: 288
		// (get) Token: 0x06000354 RID: 852 RVA: 0x000043BF File Offset: 0x000025BF
		public List<List<string>> GroupElements
		{
			get
			{
				return this.mGroupElements;
			}
		}

		// Token: 0x17000121 RID: 289
		// (get) Token: 0x06000355 RID: 853 RVA: 0x00018A84 File Offset: 0x00016C84
		// (set) Token: 0x06000356 RID: 854 RVA: 0x000043C7 File Offset: 0x000025C7
		public static SidebarConfig Instance
		{
			get
			{
				if (SidebarConfig.sInstance == null)
				{
					object obj = SidebarConfig.syncRoot;
					lock (obj)
					{
						if (SidebarConfig.sInstance == null)
						{
							SidebarConfig.sInstance = new SidebarConfig();
							SidebarConfig.sInstance.Init(SidebarConfig.sFilePath);
						}
					}
				}
				return SidebarConfig.sInstance;
			}
			set
			{
				SidebarConfig.sInstance = value;
			}
		}

		// Token: 0x06000357 RID: 855 RVA: 0x00018AEC File Offset: 0x00016CEC
		private void Init(string filePath)
		{
			SidebarConfig.InitFile(filePath);
			JObject jobject = JObject.Parse(File.ReadAllText(filePath));
			int num = 0;
			foreach (JProperty jproperty in from x in jobject.Properties()
			orderby x.Name
			select x)
			{
				List<string> list = new List<string>();
				foreach (JProperty jproperty2 in jproperty.Value.ToObject<JObject>().Properties().OrderBy((JProperty x) => x.Name))
				{
					list.Add(jproperty2.Value.ToString());
				}
				this.mGroupElements.Add(list);
				num++;
			}
		}

		// Token: 0x06000358 RID: 856 RVA: 0x000043D1 File Offset: 0x000025D1
		private static void InitFile(string filePath)
		{
			if (!File.Exists(filePath))
			{
				SidebarConfig.InitNewFile(filePath);
			}
		}

		// Token: 0x06000359 RID: 857 RVA: 0x000043E1 File Offset: 0x000025E1
		public static void InitNewFile(string filePath)
		{
			File.Copy(Path.Combine(RegistryStrings.GadgetDir, "sidebar_config.json"), filePath);
		}

		// Token: 0x040001D8 RID: 472
		private static volatile SidebarConfig sInstance;

		// Token: 0x040001D9 RID: 473
		private static object syncRoot = new object();

		// Token: 0x040001DA RID: 474
		public static string sFilePath = Path.Combine(RegistryStrings.GadgetDir, string.Format("SidebarConfig_{0}.json", "Android"));

		// Token: 0x040001DB RID: 475
		private List<List<string>> mGroupElements = new List<List<string>>();
	}
}
