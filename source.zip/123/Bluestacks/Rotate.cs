﻿using System;
using System.ComponentModel;

// Token: 0x0200000A RID: 10
[Description("Independent")]
[Serializable]
public class Rotate : IMAction
{
	// Token: 0x1700005B RID: 91
	// (get) Token: 0x060000C1 RID: 193 RVA: 0x00002823 File Offset: 0x00000A23
	// (set) Token: 0x060000C2 RID: 194 RVA: 0x0000282B File Offset: 0x00000A2B
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyClock
	{
		get
		{
			return this.mKeyClock;
		}
		set
		{
			this.mKeyClock = value;
		}
	}

	// Token: 0x1700005C RID: 92
	// (get) Token: 0x060000C3 RID: 195 RVA: 0x00002834 File Offset: 0x00000A34
	// (set) Token: 0x060000C4 RID: 196 RVA: 0x0000283C File Offset: 0x00000A3C
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyAntiClock
	{
		get
		{
			return this.mKeyAntiClock;
		}
		set
		{
			this.mKeyAntiClock = value;
		}
	}

	// Token: 0x1700005D RID: 93
	// (get) Token: 0x060000C5 RID: 197 RVA: 0x00002845 File Offset: 0x00000A45
	// (set) Token: 0x060000C6 RID: 198 RVA: 0x0000284D File Offset: 0x00000A4D
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double OriginX
	{
		get
		{
			return this.mOriginX;
		}
		set
		{
			this.mOriginX = value;
		}
	}

	// Token: 0x1700005E RID: 94
	// (get) Token: 0x060000C7 RID: 199 RVA: 0x00002856 File Offset: 0x00000A56
	// (set) Token: 0x060000C8 RID: 200 RVA: 0x0000285E File Offset: 0x00000A5E
	[Description("IMAP_CanvasElementX")]
	public double OriginY
	{
		get
		{
			return this.mOriginY;
		}
		set
		{
			this.mOriginY = value;
		}
	}

	// Token: 0x1700005F RID: 95
	// (get) Token: 0x060000C9 RID: 201 RVA: 0x00002867 File Offset: 0x00000A67
	// (set) Token: 0x060000CA RID: 202 RVA: 0x0000286F File Offset: 0x00000A6F
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double XRadius
	{
		get
		{
			return this.mXRadius;
		}
		set
		{
			this.mXRadius = value;
		}
	}

	// Token: 0x17000060 RID: 96
	// (get) Token: 0x060000CB RID: 203 RVA: 0x00002878 File Offset: 0x00000A78
	// (set) Token: 0x060000CC RID: 204 RVA: 0x00002880 File Offset: 0x00000A80
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int Speed
	{
		get
		{
			return this.mSpeed;
		}
		set
		{
			this.mSpeed = value;
		}
	}

	// Token: 0x17000061 RID: 97
	// (get) Token: 0x060000CD RID: 205 RVA: 0x00002889 File Offset: 0x00000A89
	// (set) Token: 0x060000CE RID: 206 RVA: 0x00002891 File Offset: 0x00000A91
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int ActivationTime
	{
		get
		{
			return this.mActivationTime;
		}
		set
		{
			this.mActivationTime = value;
		}
	}

	// Token: 0x0400005E RID: 94
	private string mKeyClock = string.Empty;

	// Token: 0x0400005F RID: 95
	private string mKeyAntiClock = string.Empty;

	// Token: 0x04000060 RID: 96
	private double mOriginX = -1.0;

	// Token: 0x04000061 RID: 97
	private double mOriginY = -1.0;

	// Token: 0x04000062 RID: 98
	private double mXRadius = -1.0;

	// Token: 0x04000063 RID: 99
	private int mSpeed = -1;

	// Token: 0x04000064 RID: 100
	private int mActivationTime = -1;
}
