﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200007A RID: 122
	public class MacroBookmarksPopup : UserControl, IComponentConnector
	{
		// Token: 0x1700013F RID: 319
		// (get) Token: 0x06000582 RID: 1410 RVA: 0x00005970 File Offset: 0x00003B70
		// (set) Token: 0x06000583 RID: 1411 RVA: 0x00005978 File Offset: 0x00003B78
		private MainWindow ParentWindow { get; set; }

		// Token: 0x06000584 RID: 1412 RVA: 0x00005981 File Offset: 0x00003B81
		public MacroBookmarksPopup()
		{
			this.InitializeComponent();
			this.InitList();
		}

		// Token: 0x06000585 RID: 1413 RVA: 0x00023CFC File Offset: 0x00021EFC
		public void SetParentWindowAndBindEvents(MainWindow window)
		{
			this.ParentWindow = window;
			window.mCommonHandler.MacroBookmarkChangedEvent += this.ParentWindow_MacroBookmarkChanged;
			window.mCommonHandler.MacroSettingChangedEvent += this.ParentWindow_MacroSettingChangedEvent;
			window.mCommonHandler.MacroDeletedEvent += this.ParentWindow_MacroDeletedEvent;
		}

		// Token: 0x06000586 RID: 1414 RVA: 0x00023D58 File Offset: 0x00021F58
		private void ParentWindow_MacroDeletedEvent(string fileName)
		{
			Grid gridByTag = this.GetGridByTag(fileName);
			if (gridByTag != null)
			{
				this.mMainStackPanel.Children.Remove(gridByTag);
			}
		}

		// Token: 0x06000587 RID: 1415 RVA: 0x00023D84 File Offset: 0x00021F84
		private void ParentWindow_MacroSettingChangedEvent(OperationsRecord record)
		{
			try
			{
				this.mMainStackPanel.Children.Clear();
				this.InitList();
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't update name: {0}", new object[]
				{
					ex.Message
				});
			}
		}

		// Token: 0x06000588 RID: 1416 RVA: 0x00023DD8 File Offset: 0x00021FD8
		private void ParentWindow_MacroBookmarkChanged(string fileName, bool wasBookmarked)
		{
			if (wasBookmarked)
			{
				this.mMainStackPanel.Children.Add(this.CreateGrid(fileName));
				return;
			}
			foreach (object obj in this.mMainStackPanel.Children)
			{
				Grid grid = (Grid)obj;
				if ((string)grid.Tag == fileName)
				{
					this.mMainStackPanel.Children.Remove(grid);
					break;
				}
			}
		}

		// Token: 0x06000589 RID: 1417 RVA: 0x00023E74 File Offset: 0x00022074
		private Grid GetGridByTag(string tag)
		{
			foreach (object obj in this.mMainStackPanel.Children)
			{
				Grid grid = (Grid)obj;
				if ((string)grid.Tag == tag)
				{
					return grid;
				}
			}
			return null;
		}

		// Token: 0x0600058A RID: 1418 RVA: 0x00023EE8 File Offset: 0x000220E8
		private void InitList()
		{
			foreach (string text in RegistryManager.Instance.BookmarkedScriptList)
			{
				if (!string.IsNullOrEmpty(text))
				{
					Grid element = this.CreateGrid(text);
					this.mMainStackPanel.Children.Add(element);
				}
			}
		}

		// Token: 0x0600058B RID: 1419 RVA: 0x00004BF2 File Offset: 0x00002DF2
		private void MMacroBookmarksPopup_Loaded(object sender, RoutedEventArgs e)
		{
		}

		// Token: 0x0600058C RID: 1420 RVA: 0x00023F34 File Offset: 0x00022134
		private Grid CreateGrid(string fileName)
		{
			Grid grid = new Grid();
			grid.MouseEnter += this.GridElement_MouseEnter;
			grid.MouseLeave += this.GridElement_MouseLeave;
			grid.MouseLeftButtonUp += this.GridElement_MouseLeftButtonUp;
			grid.Background = Brushes.Transparent;
			grid.Tag = fileName;
			TextBlock textBlock = new TextBlock();
			textBlock.FontSize = 12.0;
			textBlock.TextTrimming = TextTrimming.CharacterEllipsis;
			textBlock.Margin = new Thickness(10.0, 5.0, 10.0, 5.0);
			BlueStacksUIBinding.BindColor(textBlock, TextBlock.ForegroundProperty, "GuidanceTextColorForeground");
			string path = Path.Combine(RegistryStrings.OperationsScriptFolder, fileName);
			if (File.Exists(path))
			{
				try
				{
					OperationsRecord operationsRecord = JsonConvert.DeserializeObject<OperationsRecord>(File.ReadAllText(path), Utils.GetSerializerSettings());
					textBlock.Text = operationsRecord.Name;
					textBlock.ToolTip = operationsRecord.Name;
					goto IL_F9;
				}
				catch
				{
					goto IL_F9;
				}
			}
			textBlock.Text = fileName;
			textBlock.ToolTip = fileName;
			IL_F9:
			grid.Children.Add(textBlock);
			return grid;
		}

		// Token: 0x0600058D RID: 1421 RVA: 0x00024058 File Offset: 0x00022258
		private void GridElement_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow.mIsOperationRecorderActive)
			{
				return;
			}
			string text = (string)(sender as Grid).Tag;
			string path = Path.Combine(RegistryStrings.OperationsScriptFolder, text + ".json");
			if (!File.Exists(path))
			{
				this.mMainStackPanel.Children.Remove(sender as Grid);
				return;
			}
			try
			{
				if (!this.ParentWindow.mIsMacroPlaying)
				{
					OperationsRecord operationsRecord = JsonConvert.DeserializeObject<OperationsRecord>(File.ReadAllText(path), Utils.GetSerializerSettings());
					operationsRecord.Name = text;
					this.ParentWindow.mCommonHandler.FullMacroScriptPlayHandler(operationsRecord);
					ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_play", "bookmark", null, null, null, null);
				}
				else
				{
					CustomMessageWindow customMessageWindow = new CustomMessageWindow();
					BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_BLUESTACKS", "");
					customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
					BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_STOP_MACRO_SCRIPT", "");
					customMessageWindow.Owner = this.ParentWindow;
					customMessageWindow.ShowDialog();
				}
				if (this.ParentWindow.mSidebar != null)
				{
					this.ParentWindow.mSidebar.mMacroButtonPopup.IsOpen = false;
					this.ParentWindow.mSidebar.ToggleSidebarVisibilityInFullscreen(false);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
		}

		// Token: 0x0600058E RID: 1422 RVA: 0x00005628 File Offset: 0x00003828
		private void GridElement_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x0600058F RID: 1423 RVA: 0x000046FF File Offset: 0x000028FF
		private void GridElement_MouseLeave(object sender, MouseEventArgs e)
		{
			(sender as Grid).Background = Brushes.Transparent;
		}

		// Token: 0x06000590 RID: 1424 RVA: 0x000241C4 File Offset: 0x000223C4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/macrobookmarkspopup.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000591 RID: 1425 RVA: 0x000241F4 File Offset: 0x000223F4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMacroBookmarksPopup = (MacroBookmarksPopup)target;
				this.mMacroBookmarksPopup.Loaded += this.MMacroBookmarksPopup_Loaded;
				return;
			case 2:
				this.mGrid = (Grid)target;
				return;
			case 3:
				this.mMainStackPanel = (StackPanel)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000365 RID: 869
		private Dictionary<Grid, EventHandler> mDictActions = new Dictionary<Grid, EventHandler>();

		// Token: 0x04000367 RID: 871
		internal MacroBookmarksPopup mMacroBookmarksPopup;

		// Token: 0x04000368 RID: 872
		internal Grid mGrid;

		// Token: 0x04000369 RID: 873
		internal StackPanel mMainStackPanel;

		// Token: 0x0400036A RID: 874
		private bool _contentLoaded;
	}
}
