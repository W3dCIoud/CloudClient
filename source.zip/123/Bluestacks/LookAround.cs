﻿using System;
using System.ComponentModel;

// Token: 0x02000011 RID: 17
[Description("SubElement")]
[Serializable]
internal class LookAround : IMAction
{
	// Token: 0x17000087 RID: 135
	// (get) Token: 0x0600011F RID: 287 RVA: 0x00002BCE File Offset: 0x00000DCE
	// (set) Token: 0x06000120 RID: 288 RVA: 0x00002BDB File Offset: 0x00000DDB
	public string Key
	{
		get
		{
			return this.mPan.KeyLookAround;
		}
		set
		{
			this.mPan.KeyLookAround = value;
		}
	}

	// Token: 0x17000088 RID: 136
	// (get) Token: 0x06000121 RID: 289 RVA: 0x00002BE9 File Offset: 0x00000DE9
	// (set) Token: 0x06000122 RID: 290 RVA: 0x00002BF6 File Offset: 0x00000DF6
	[Description("IMAP_CanvasElementY")]
	public double X
	{
		get
		{
			return this.mPan.LookAroundX;
		}
		set
		{
			this.mPan.LookAroundX = value;
		}
	}

	// Token: 0x17000089 RID: 137
	// (get) Token: 0x06000123 RID: 291 RVA: 0x00002C04 File Offset: 0x00000E04
	// (set) Token: 0x06000124 RID: 292 RVA: 0x00002C11 File Offset: 0x00000E11
	[Description("IMAP_CanvasElementX")]
	public double Y
	{
		get
		{
			return this.mPan.LookAroundY;
		}
		set
		{
			this.mPan.LookAroundY = value;
		}
	}

	// Token: 0x06000125 RID: 293 RVA: 0x00002C1F File Offset: 0x00000E1F
	internal LookAround(Pan action)
	{
		this.IsChildAction = true;
		base.Type = KeyActionType.LookAround;
		this.mPan = action;
		this.ParentAction = action;
	}

	// Token: 0x0400008A RID: 138
	private Pan mPan;
}
