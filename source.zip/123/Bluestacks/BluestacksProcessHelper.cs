﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200015C RID: 348
	internal class BluestacksProcessHelper
	{
		// Token: 0x06000D5B RID: 3419 RVA: 0x00057274 File Offset: 0x00055474
		internal static int StartFrontend(string vmName)
		{
			try
			{
				string installDir = RegistryStrings.InstallDir;
				string fileName = Path.Combine(installDir, "HD-Player.exe");
				string str = FeatureManager.Instance.IsUseWpfTextbox ? " -w" : "";
				string str2 = " -h";
				if (RegistryManager.Instance.DevEnv == 1)
				{
					str2 = "";
				}
				Process process = new Process();
				process.StartInfo.UseShellExecute = false;
				process.StartInfo.CreateNoWindow = true;
				process.StartInfo.FileName = fileName;
				process.StartInfo.Arguments = vmName + str2 + str;
				process.StartInfo.WorkingDirectory = installDir;
				Logger.Info("Starting Frontend for vm: {0} with args: {1}", new object[]
				{
					vmName,
					process.StartInfo.Arguments
				});
				process.Start();
				process.WaitForExit();
				return process.ExitCode;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in starting frontend. Err : " + ex.ToString());
			}
			return 0;
		}

		// Token: 0x06000D5C RID: 3420 RVA: 0x00057380 File Offset: 0x00055580
		public static void RunUpdateInstaller(string filePath, string arg, bool isAdmin = false)
		{
			Logger.Info("RunUpdateInstaller start");
			try
			{
				Process process = new Process();
				process.StartInfo.FileName = filePath;
				process.StartInfo.Arguments = arg;
				if (isAdmin)
				{
					process.StartInfo.Verb = "runas";
				}
				process.Start();
			}
			catch (Exception ex)
			{
				Logger.Warning("Exception in running update installer " + ex.ToString());
			}
		}

		// Token: 0x06000D5D RID: 3421 RVA: 0x000573FC File Offset: 0x000555FC
		public static Process StartBluestacks(string vmName)
		{
			string fileName = Path.Combine(RegistryStrings.InstallDir, "HD-RunApp.exe");
			Process process = new Process();
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.CreateNoWindow = true;
			process.StartInfo.FileName = fileName;
			process.StartInfo.Arguments = "-vmname:" + vmName + " -h";
			Logger.Info("Sending RunApp for vm calling {0}", new object[]
			{
				vmName
			});
			Logger.Info("Utils: Starting hidden Frontend");
			process.Start();
			return process;
		}

		// Token: 0x06000D5E RID: 3422 RVA: 0x00057484 File Offset: 0x00055684
		public static int RunApkInstaller(string apkPath, bool isSilentInstall, string vmName)
		{
			Logger.Info("Installing apk :{0} vmname: {1} ", new object[]
			{
				apkPath,
				vmName
			});
			if (vmName == null)
			{
				vmName = "Android";
			}
			int result = -1;
			try
			{
				string installDir = RegistryStrings.InstallDir;
				ProcessStartInfo processStartInfo = new ProcessStartInfo();
				processStartInfo.WorkingDirectory = installDir;
				if (string.Equals(Path.GetExtension(apkPath), ".xapk", StringComparison.InvariantCultureIgnoreCase))
				{
					processStartInfo.FileName = Path.Combine(installDir, "HD-XapkHandler.exe");
					if (isSilentInstall)
					{
						processStartInfo.Arguments = string.Format("-xapk \"{0}\" -s -vmname {1}", apkPath, vmName);
					}
					else
					{
						processStartInfo.Arguments = string.Format("-xapk \"{0}\" -vmname {1}", apkPath, vmName);
					}
				}
				else
				{
					processStartInfo.FileName = Path.Combine(installDir, "HD-ApkHandler.exe");
					if (isSilentInstall)
					{
						processStartInfo.Arguments = string.Format("-apk \"{0}\" -s -vmname {1}", apkPath, vmName);
					}
					else
					{
						processStartInfo.Arguments = string.Format("-apk \"{0}\" -vmname {1}", apkPath, vmName);
					}
				}
				processStartInfo.UseShellExecute = false;
				processStartInfo.CreateNoWindow = true;
				Logger.Info("Console: installer path {0}", new object[]
				{
					processStartInfo.FileName
				});
				Process process = Process.Start(processStartInfo);
				process.WaitForExit();
				result = process.ExitCode;
				Logger.Info("Console: apk installer exit code: {0}", new object[]
				{
					process.ExitCode
				});
			}
			catch (Exception ex)
			{
				Logger.Info("Error Installing Apk : " + ex.ToString());
			}
			return result;
		}

		// Token: 0x06000D5F RID: 3423 RVA: 0x000575D8 File Offset: 0x000557D8
		internal static bool TakeLock(string lockBane)
		{
			Mutex mutex;
			return ProcessUtils.IsAlreadyRunning(lockBane, out mutex);
		}
	}
}
