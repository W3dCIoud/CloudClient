﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media.Animation;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000BA RID: 186
	public class SlideShowControl : System.Windows.Controls.UserControl, IComponentConnector
	{
		// Token: 0x0600077D RID: 1917 RVA: 0x00006D08 File Offset: 0x00004F08
		public SlideShowControl()
		{
			this.InitializeComponent();
			this.image1_MouseEnter(null, null);
		}

		// Token: 0x0600077E RID: 1918 RVA: 0x0002F888 File Offset: 0x0002DA88
		internal void AddOrUpdateSlide(SlideShowControl.SlideShowContext slideContext)
		{
			if (this.mSlideShowDict.ContainsKey(slideContext.Key))
			{
				this.mSlideShowDict[slideContext.Key] = slideContext;
				return;
			}
			this.mSlideShowDict.Add((slideContext.Key == 0) ? this.mSlideShowDict.Count : slideContext.Key, slideContext);
		}

		// Token: 0x1700015B RID: 347
		// (get) Token: 0x0600077F RID: 1919 RVA: 0x00006D29 File Offset: 0x00004F29
		// (set) Token: 0x06000780 RID: 1920 RVA: 0x00006D3B File Offset: 0x00004F3B
		public System.Windows.HorizontalAlignment TextHorizontalAlignment
		{
			get
			{
				return (System.Windows.HorizontalAlignment)base.GetValue(SlideShowControl.TextHorizontalAlignmentProperty);
			}
			set
			{
				base.SetValue(SlideShowControl.TextHorizontalAlignmentProperty, value);
			}
		}

		// Token: 0x1700015C RID: 348
		// (get) Token: 0x06000781 RID: 1921 RVA: 0x00006D4E File Offset: 0x00004F4E
		// (set) Token: 0x06000782 RID: 1922 RVA: 0x00006D60 File Offset: 0x00004F60
		public VerticalAlignment TextVerticalAlignment
		{
			get
			{
				return (VerticalAlignment)base.GetValue(SlideShowControl.TextVerticalAlignmentProperty);
			}
			set
			{
				base.SetValue(SlideShowControl.TextVerticalAlignmentProperty, value);
			}
		}

		// Token: 0x1700015D RID: 349
		// (get) Token: 0x06000783 RID: 1923 RVA: 0x00006D73 File Offset: 0x00004F73
		// (set) Token: 0x06000784 RID: 1924 RVA: 0x00006D85 File Offset: 0x00004F85
		public string ImagesFolderPath
		{
			get
			{
				return (string)base.GetValue(SlideShowControl.ImagesFolderPathProperty);
			}
			set
			{
				base.SetValue(SlideShowControl.ImagesFolderPathProperty, value);
			}
		}

		// Token: 0x1700015E RID: 350
		// (get) Token: 0x06000785 RID: 1925 RVA: 0x00006D93 File Offset: 0x00004F93
		// (set) Token: 0x06000786 RID: 1926 RVA: 0x00006DA5 File Offset: 0x00004FA5
		public bool IsArrowVisible
		{
			get
			{
				return (bool)base.GetValue(SlideShowControl.IsArrowVisibleProperty);
			}
			set
			{
				base.SetValue(SlideShowControl.IsArrowVisibleProperty, value);
			}
		}

		// Token: 0x1700015F RID: 351
		// (get) Token: 0x06000787 RID: 1927 RVA: 0x00006DB8 File Offset: 0x00004FB8
		// (set) Token: 0x06000788 RID: 1928 RVA: 0x00006DCA File Offset: 0x00004FCA
		public bool HideArrowOnLeave
		{
			get
			{
				return (bool)base.GetValue(SlideShowControl.HideArrowOnLeaveProperty);
			}
			set
			{
				base.SetValue(SlideShowControl.HideArrowOnLeaveProperty, value);
			}
		}

		// Token: 0x17000160 RID: 352
		// (get) Token: 0x06000789 RID: 1929 RVA: 0x00006DDD File Offset: 0x00004FDD
		// (set) Token: 0x0600078A RID: 1930 RVA: 0x00006DEF File Offset: 0x00004FEF
		public bool IsAutoPlay
		{
			get
			{
				return (bool)base.GetValue(SlideShowControl.IsAutoPlayProperty);
			}
			set
			{
				base.SetValue(SlideShowControl.IsAutoPlayProperty, value);
			}
		}

		// Token: 0x17000161 RID: 353
		// (get) Token: 0x0600078B RID: 1931 RVA: 0x00006E02 File Offset: 0x00005002
		// (set) Token: 0x0600078C RID: 1932 RVA: 0x00006E14 File Offset: 0x00005014
		public int SlideDelay
		{
			get
			{
				return (int)base.GetValue(SlideShowControl.SlideDelayProperty);
			}
			set
			{
				base.SetValue(SlideShowControl.SlideDelayProperty, value);
			}
		}

		// Token: 0x17000162 RID: 354
		// (get) Token: 0x0600078D RID: 1933 RVA: 0x00006E27 File Offset: 0x00005027
		// (set) Token: 0x0600078E RID: 1934 RVA: 0x00006E39 File Offset: 0x00005039
		public SlideShowControl.SlideAnimationType TransitionType
		{
			get
			{
				return (SlideShowControl.SlideAnimationType)base.GetValue(SlideShowControl.TransitionTypeProperty);
			}
			set
			{
				base.SetValue(SlideShowControl.TransitionTypeProperty, value);
			}
		}

		// Token: 0x0600078F RID: 1935 RVA: 0x00006E4C File Offset: 0x0000504C
		internal void PlaySlideShow()
		{
			this.IsAutoPlay = true;
			this.SlideShowLoop(false);
			this.StartImageTransition(this._slide + 1);
		}

		// Token: 0x06000790 RID: 1936 RVA: 0x00006E6A File Offset: 0x0000506A
		internal void StopSlideShow()
		{
			this.IsAutoPlay = false;
		}

		// Token: 0x06000791 RID: 1937 RVA: 0x0002F8E4 File Offset: 0x0002DAE4
		internal void LoadImagesFromFolder(string folderPath)
		{
			if (!Path.IsPathRooted(folderPath))
			{
				folderPath = Path.Combine(CustomPictureBox.AssetsDir, folderPath);
			}
			if (Directory.Exists(folderPath))
			{
				try
				{
					string path = Path.Combine(folderPath, "slides.json");
					if (File.Exists(path))
					{
						IEnumerable<SlideShowControl.SlideShowContext> enumerable = JObject.Parse(File.ReadAllText(path)).ToObject<IEnumerable<SlideShowControl.SlideShowContext>>();
						if (enumerable != null)
						{
							foreach (SlideShowControl.SlideShowContext slideShowContext in enumerable)
							{
								if (!string.IsNullOrEmpty(slideShowContext.Description))
								{
									slideShowContext.Description = LocaleStrings.GetLocalizedString(slideShowContext.Description, false);
								}
								this.AddOrUpdateSlide(slideShowContext);
							}
						}
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Error while trying to read slides.json from " + folderPath + "." + ex.ToString());
					this.mSlideShowDict.Clear();
				}
				if (this.mSlideShowDict.Count == 0)
				{
					FileInfo[] files = new DirectoryInfo(folderPath).GetFiles();
					int num = 0;
					for (int i = 0; i < files.Length; i++)
					{
						if (SlideShowControl.ValidImageExtensions.Contains(files[i].Extension, StringComparer.InvariantCultureIgnoreCase))
						{
							this.AddOrUpdateSlide(new SlideShowControl.SlideShowContext
							{
								Key = num,
								ImageName = files[i].FullName
							});
							num++;
						}
					}
				}
				this.StartImageTransition(0);
			}
		}

		// Token: 0x06000792 RID: 1938 RVA: 0x0002FA48 File Offset: 0x0002DC48
		private void SlideShowLoop(bool forceStart = false)
		{
			if (forceStart && this.timer != null)
			{
				this.timer.Enabled = false;
			}
			if (this.timer != null && !this.timer.Enabled)
			{
				this.timer.Dispose();
			}
			if (this.IsAutoPlay && this.mSlideShowDict.Count > 1)
			{
				this.timer = new Timer();
				this.timer.Interval = this.SlideDelay * 1000;
				this.timer.Tick += delegate(object o, EventArgs e)
				{
					if (this.timer.Enabled && this.IsAutoPlay && this.mSlideShowDict.Count > 1 && o == this.timer)
					{
						this.StartImageTransition(this._slide + 1);
						return;
					}
					((Timer)o).Enabled = false;
				};
				this.timer.Start();
			}
		}

		// Token: 0x06000793 RID: 1939 RVA: 0x0002FAE8 File Offset: 0x0002DCE8
		private void StartImageTransition(int i)
		{
			if (this.mSlideShowDict.Count > 0)
			{
				if (this._slide == i)
				{
					this.image1.ImageName = this.mSlideShowDict[this._slide].ImageName;
					this.SlideshowName.Text = this.mSlideShowDict[this._slide].Description;
					this.SlideShowLoop(false);
					return;
				}
				if (i >= this.mSlideShowDict.Count)
				{
					this.UnloadImage(0);
					return;
				}
				if (i < 0)
				{
					this.UnloadImage(this.mSlideShowDict.Count - 1);
					return;
				}
				this.UnloadImage(i);
			}
		}

		// Token: 0x06000794 RID: 1940 RVA: 0x0002FB90 File Offset: 0x0002DD90
		private void UnloadImage(int imageToShow)
		{
			Storyboard storyboard = (base.Resources[string.Format("{0}Out", this.TransitionType.ToString())] as Storyboard).Clone();
			storyboard.Completed += delegate(object o, EventArgs e)
			{
				this.image1.ImageName = this.mSlideShowDict[imageToShow].ImageName;
				this.LoadImage(imageToShow);
			};
			Storyboard.SetTarget(storyboard, this.SlideshowGrid);
			storyboard.Begin();
		}

		// Token: 0x06000795 RID: 1941 RVA: 0x0002FC08 File Offset: 0x0002DE08
		private void LoadImage(int imageToShow)
		{
			this._slide = imageToShow;
			this.SlideshowName.Text = this.mSlideShowDict[imageToShow].Description;
			Storyboard storyboard = base.Resources[string.Format("{0}In", this.TransitionType.ToString())] as Storyboard;
			Storyboard.SetTarget(storyboard, this.SlideshowGrid);
			storyboard.Begin();
		}

		// Token: 0x06000796 RID: 1942 RVA: 0x00006E73 File Offset: 0x00005073
		private void mPrevBtn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.SlideShowLoop(true);
			this.StartImageTransition(this._slide - 1);
		}

		// Token: 0x06000797 RID: 1943 RVA: 0x00006E8A File Offset: 0x0000508A
		private void mNextBtn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.SlideShowLoop(true);
			this.StartImageTransition(this._slide + 1);
		}

		// Token: 0x06000798 RID: 1944 RVA: 0x00006EA1 File Offset: 0x000050A1
		private void SlideShowControl_Loaded(object sender, RoutedEventArgs e)
		{
			if (!string.IsNullOrEmpty(this.ImagesFolderPath))
			{
				this.LoadImagesFromFolder(this.ImagesFolderPath);
			}
		}

		// Token: 0x06000799 RID: 1945 RVA: 0x0002FC78 File Offset: 0x0002DE78
		private void image1_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			if (!this.IsArrowVisible || this.mSlideShowDict.Count < 2)
			{
				this.image1_MouseLeave(sender, e);
				return;
			}
			if (!this.HideArrowOnLeave)
			{
				return;
			}
			if (this.image1.IsMouseOver)
			{
				this.mPrevBtn.Visibility = Visibility.Visible;
				this.mNextBtn.Visibility = Visibility.Visible;
				return;
			}
			this.image1_MouseLeave(sender, e);
		}

		// Token: 0x0600079A RID: 1946 RVA: 0x0002FCDC File Offset: 0x0002DEDC
		private void image1_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			if (!this.IsArrowVisible || this.mSlideShowDict.Count < 2)
			{
				this.mPrevBtn.Visibility = Visibility.Hidden;
				this.mNextBtn.Visibility = Visibility.Hidden;
				return;
			}
			if (!this.HideArrowOnLeave)
			{
				return;
			}
			if (!this.mPrevBtn.IsMouseOver && !this.mNextBtn.IsMouseOver && !this.image1.IsMouseOver)
			{
				this.mPrevBtn.Visibility = Visibility.Hidden;
				this.mNextBtn.Visibility = Visibility.Hidden;
			}
		}

		// Token: 0x0600079B RID: 1947 RVA: 0x0002FD60 File Offset: 0x0002DF60
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/slideshowcontrol.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600079C RID: 1948 RVA: 0x0002FD90 File Offset: 0x0002DF90
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.slideControl = (SlideShowControl)target;
				this.slideControl.Loaded += this.SlideShowControl_Loaded;
				return;
			case 2:
				this.SlideshowGrid = (Grid)target;
				return;
			case 3:
				this.image1 = (CustomPictureBox)target;
				this.image1.MouseEnter += this.image1_MouseEnter;
				this.image1.MouseLeave += this.image1_MouseLeave;
				return;
			case 4:
				this.mPrevBtn = (CustomPictureBox)target;
				this.mPrevBtn.MouseLeftButtonUp += this.mPrevBtn_MouseLeftButtonUp;
				this.mPrevBtn.MouseLeave += this.image1_MouseLeave;
				return;
			case 5:
				this.mNextBtn = (CustomPictureBox)target;
				this.mNextBtn.MouseLeftButtonUp += this.mNextBtn_MouseLeftButtonUp;
				this.mNextBtn.MouseLeave += this.image1_MouseLeave;
				return;
			case 6:
				this.SlideshowName = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000560 RID: 1376
		private SortedDictionary<int, SlideShowControl.SlideShowContext> mSlideShowDict = new SortedDictionary<int, SlideShowControl.SlideShowContext>();

		// Token: 0x04000561 RID: 1377
		private static string[] ValidImageExtensions = new string[]
		{
			".png",
			".jpg",
			".jpeg",
			".bmp",
			".gif"
		};

		// Token: 0x04000562 RID: 1378
		public static readonly DependencyProperty TransitionTypeProperty = DependencyProperty.Register("TransitionType", typeof(SlideShowControl.SlideAnimationType), typeof(SlideShowControl), new PropertyMetadata(SlideShowControl.SlideAnimationType.Fade));

		// Token: 0x04000563 RID: 1379
		public static readonly DependencyProperty TextVerticalAlignmentProperty = DependencyProperty.Register("TextVerticalAlignment", typeof(VerticalAlignment), typeof(SlideShowControl), new PropertyMetadata(VerticalAlignment.Bottom));

		// Token: 0x04000564 RID: 1380
		public static readonly DependencyProperty TextHorizontalAlignmentProperty = DependencyProperty.Register("TextHorizontalAlignment", typeof(System.Windows.HorizontalAlignment), typeof(SlideShowControl), new PropertyMetadata(System.Windows.HorizontalAlignment.Center));

		// Token: 0x04000565 RID: 1381
		public static readonly DependencyProperty IsAutoPlayProperty = DependencyProperty.Register("IsAutoPlay", typeof(bool), typeof(SlideShowControl), new PropertyMetadata(false));

		// Token: 0x04000566 RID: 1382
		public static readonly DependencyProperty HideArrowOnLeaveProperty = DependencyProperty.Register("HideArrowOnLeave", typeof(bool), typeof(SlideShowControl), new PropertyMetadata(true));

		// Token: 0x04000567 RID: 1383
		public static readonly DependencyProperty IsArrowVisibleProperty = DependencyProperty.Register("IsArrowVisible", typeof(bool), typeof(SlideShowControl), new PropertyMetadata(true));

		// Token: 0x04000568 RID: 1384
		public static readonly DependencyProperty SlideDelayProperty = DependencyProperty.Register("SlideDelay", typeof(int), typeof(SlideShowControl), new PropertyMetadata(5));

		// Token: 0x04000569 RID: 1385
		public static readonly DependencyProperty ImagesFolderPathProperty = DependencyProperty.Register("ImagesFolderPath", typeof(string), typeof(SlideShowControl), new PropertyMetadata(""));

		// Token: 0x0400056A RID: 1386
		private int _slide;

		// Token: 0x0400056B RID: 1387
		private Timer timer;

		// Token: 0x0400056C RID: 1388
		internal SlideShowControl slideControl;

		// Token: 0x0400056D RID: 1389
		internal Grid SlideshowGrid;

		// Token: 0x0400056E RID: 1390
		internal CustomPictureBox image1;

		// Token: 0x0400056F RID: 1391
		internal CustomPictureBox mPrevBtn;

		// Token: 0x04000570 RID: 1392
		internal CustomPictureBox mNextBtn;

		// Token: 0x04000571 RID: 1393
		internal TextBlock SlideshowName;

		// Token: 0x04000572 RID: 1394
		private bool _contentLoaded;

		// Token: 0x020000BB RID: 187
		[JsonObject(MemberSerialization.OptIn)]
		internal class SlideShowContext
		{
			// Token: 0x04000573 RID: 1395
			[JsonProperty("key")]
			internal int Key;

			// Token: 0x04000574 RID: 1396
			[JsonProperty("imagename")]
			internal string ImageName;

			// Token: 0x04000575 RID: 1397
			[JsonProperty("description")]
			internal string Description;
		}

		// Token: 0x020000BC RID: 188
		public enum SlideAnimationType
		{
			// Token: 0x04000577 RID: 1399
			Fade,
			// Token: 0x04000578 RID: 1400
			Slide
		}
	}
}
