﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using BlueStacks.Common;
using Microsoft.Win32;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200004F RID: 79
	public static class AppUsageTimer
	{
		// Token: 0x06000381 RID: 897 RVA: 0x00004559 File Offset: 0x00002759
		internal static void StartTimer(string vmName, string packageName)
		{
			AppUsageTimer.StopTimer();
			AppUsageTimer.sLastAppPackage = packageName;
			AppUsageTimer.sLastVMName = vmName;
			AppUsageTimer.sStopwatch.Reset();
			AppUsageTimer.sStopwatch.Start();
		}

		// Token: 0x06000382 RID: 898 RVA: 0x00019098 File Offset: 0x00017298
		internal static void StopTimer()
		{
			if (AppUsageTimer.sStopwatch.IsRunning && !string.IsNullOrEmpty(AppUsageTimer.sLastAppPackage))
			{
				AppUsageTimer.sStopwatch.Stop();
				long num = (long)AppUsageTimer.sStopwatch.Elapsed.TotalSeconds;
				if (AppUsageTimer.sDictAppUsageInfo.ContainsKey(AppUsageTimer.sLastVMName))
				{
					Dictionary<string, long> dictionary;
					if (AppUsageTimer.sDictAppUsageInfo[AppUsageTimer.sLastVMName].ContainsKey(AppUsageTimer.sLastAppPackage))
					{
						dictionary = AppUsageTimer.sDictAppUsageInfo[AppUsageTimer.sLastVMName];
						string key = AppUsageTimer.sLastAppPackage;
						dictionary[key] += num;
					}
					else
					{
						AppUsageTimer.sDictAppUsageInfo[AppUsageTimer.sLastVMName].Add(AppUsageTimer.sLastAppPackage, num);
					}
					dictionary = AppUsageTimer.sDictAppUsageInfo[AppUsageTimer.sLastVMName];
					dictionary["TotalUsage"] = dictionary["TotalUsage"] + num;
				}
				else
				{
					AppUsageTimer.sDictAppUsageInfo.Add(AppUsageTimer.sLastVMName, new Dictionary<string, long>
					{
						{
							"TotalUsage",
							num
						}
					});
					AppUsageTimer.sDictAppUsageInfo[AppUsageTimer.sLastVMName].Add(AppUsageTimer.sLastAppPackage, num);
				}
				AppUsageTimer.sLastAppPackage = string.Empty;
			}
		}

		// Token: 0x06000383 RID: 899 RVA: 0x000191C0 File Offset: 0x000173C0
		internal static Dictionary<string, Dictionary<string, long>> GetRealtimeDictionary()
		{
			if (AppUsageTimer.sStopwatch.IsRunning && !string.IsNullOrEmpty(AppUsageTimer.sLastAppPackage))
			{
				Dictionary<string, Dictionary<string, long>> dictionary = new Dictionary<string, Dictionary<string, long>>();
				foreach (KeyValuePair<string, Dictionary<string, long>> keyValuePair in AppUsageTimer.sDictAppUsageInfo)
				{
					dictionary.Add(keyValuePair.Key, keyValuePair.Value.ToDictionary((KeyValuePair<string, long> _) => _.Key, (KeyValuePair<string, long> _) => _.Value));
				}
				long num = (long)AppUsageTimer.sStopwatch.Elapsed.TotalSeconds;
				if (dictionary.ContainsKey(AppUsageTimer.sLastVMName))
				{
					Dictionary<string, long> dictionary2;
					if (dictionary[AppUsageTimer.sLastVMName].ContainsKey(AppUsageTimer.sLastAppPackage))
					{
						dictionary2 = dictionary[AppUsageTimer.sLastVMName];
						string key = AppUsageTimer.sLastAppPackage;
						dictionary2[key] += num;
					}
					else
					{
						dictionary[AppUsageTimer.sLastVMName].Add(AppUsageTimer.sLastAppPackage, num);
					}
					dictionary2 = dictionary[AppUsageTimer.sLastVMName];
					dictionary2["TotalUsage"] = dictionary2["TotalUsage"] + num;
				}
				else
				{
					dictionary.Add(AppUsageTimer.sLastVMName, new Dictionary<string, long>
					{
						{
							"TotalUsage",
							num
						}
					});
					dictionary[AppUsageTimer.sLastVMName].Add(AppUsageTimer.sLastAppPackage, num);
				}
				return dictionary;
			}
			return AppUsageTimer.sDictAppUsageInfo;
		}

		// Token: 0x06000384 RID: 900 RVA: 0x00019364 File Offset: 0x00017564
		internal static long GetTotalTimeForPackageAcrossInstances(string packageName)
		{
			long num = 0L;
			try
			{
				Func<KeyValuePair<string, long>, bool> <>9__0;
				foreach (KeyValuePair<string, Dictionary<string, long>> keyValuePair in AppUsageTimer.sDictAppUsageInfo)
				{
					IEnumerable<KeyValuePair<string, long>> value = keyValuePair.Value;
					Func<KeyValuePair<string, long>, bool> predicate;
					if ((predicate = <>9__0) == null)
					{
						predicate = (<>9__0 = ((KeyValuePair<string, long> _) => string.Compare(_.Key, packageName, true) == 0));
					}
					IEnumerable<KeyValuePair<string, long>> source = value.Where(predicate);
					if (source.Count<KeyValuePair<string, long>>() > 0)
					{
						num += source.First<KeyValuePair<string, long>>().Value;
					}
				}
				if (!string.IsNullOrEmpty(AppUsageTimer.sLastAppPackage) && string.Compare(AppUsageTimer.sLastAppPackage, packageName, true) == 0)
				{
					num += (long)AppUsageTimer.sStopwatch.Elapsed.TotalSeconds;
				}
				Logger.Debug(string.Concat(new object[]
				{
					"Total time for package ",
					packageName,
					" ",
					num
				}));
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GetTotalTimeForPackageAcrossInstances. Err : " + ex.ToString());
			}
			return num;
		}

		// Token: 0x06000385 RID: 901 RVA: 0x0001949C File Offset: 0x0001769C
		internal static long GetTotalTimeForAllPackages()
		{
			long num = 0L;
			try
			{
				foreach (KeyValuePair<string, Dictionary<string, long>> keyValuePair in AppUsageTimer.sDictAppUsageInfo)
				{
					long num2 = 0L;
					IEnumerable<KeyValuePair<string, long>> source = from _ in keyValuePair.Value
					where string.Compare(_.Key, "Home", true) == 0
					select _;
					if (source.Count<KeyValuePair<string, long>>() > 0)
					{
						num2 += source.First<KeyValuePair<string, long>>().Value;
					}
					source = from _ in keyValuePair.Value
					where string.Compare(_.Key, "TotalUsage", true) == 0
					select _;
					if (source.Count<KeyValuePair<string, long>>() > 0)
					{
						num += source.First<KeyValuePair<string, long>>().Value;
						num -= num2;
					}
				}
				if (!string.IsNullOrEmpty(AppUsageTimer.sLastAppPackage) && !AppUsageTimer.sLastAppPackage.Equals("Home"))
				{
					num += (long)AppUsageTimer.sStopwatch.Elapsed.TotalSeconds;
				}
				Logger.Debug("Total time for all packages " + num);
				if (num < 0L)
				{
					return 0L;
				}
				return num;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GetTotalTimeForAllPackages " + ex.ToString());
			}
			return 0L;
		}

		// Token: 0x06000386 RID: 902 RVA: 0x00019628 File Offset: 0x00017828
		internal static long GetTotalTimeForPackageAfterReset(string packageName)
		{
			try
			{
				long totalTimeForPackageAcrossInstances = AppUsageTimer.GetTotalTimeForPackageAcrossInstances(packageName);
				if (totalTimeForPackageAcrossInstances < 0L)
				{
					return 0L;
				}
				return totalTimeForPackageAcrossInstances;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GetTotalTimeForPackageAfterReset. Err : " + ex.ToString());
			}
			return 0L;
		}

		// Token: 0x06000387 RID: 903 RVA: 0x00004580 File Offset: 0x00002780
		internal static void AddPackageForReset(string package, long time)
		{
			AppUsageTimer.sResetQuestDict[package] = time;
		}

		// Token: 0x06000388 RID: 904 RVA: 0x0000458E File Offset: 0x0000278E
		internal static void SessionEventHandler()
		{
			SystemEvents.SessionSwitch += AppUsageTimer.sessionSwitchHandler;
		}

		// Token: 0x06000389 RID: 905 RVA: 0x0000459A File Offset: 0x0000279A
		private static void SystemEvents_SessionSwitch(object sender, SessionSwitchEventArgs e)
		{
			if (e.Reason == SessionSwitchReason.SessionLock)
			{
				AppUsageTimer.StopTimer();
				return;
			}
			if (e.Reason == SessionSwitchReason.SessionUnlock)
			{
				AppUsageTimer.StartTimerAfterResume();
			}
		}

		// Token: 0x0600038A RID: 906 RVA: 0x000045B9 File Offset: 0x000027B9
		internal static void DetachSessionEventHandler()
		{
			SystemEvents.SessionSwitch -= AppUsageTimer.sessionSwitchHandler;
		}

		// Token: 0x0600038B RID: 907 RVA: 0x00019678 File Offset: 0x00017878
		private static void StartTimerAfterResume()
		{
			try
			{
				if (BlueStacksUIUtils.DictWindows.ContainsKey(AppUsageTimer.sLastVMName))
				{
					MainWindow mainWindow = BlueStacksUIUtils.DictWindows[AppUsageTimer.sLastVMName];
					if (mainWindow != null && mainWindow.mTopBar.mAppTabButtons.SelectedTab != null)
					{
						AppUsageTimer.StartTimer(AppUsageTimer.sLastVMName, mainWindow.mTopBar.mAppTabButtons.SelectedTab.TabKey);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in starting timer after sleep. Err : " + ex.ToString());
			}
		}

		// Token: 0x0600038C RID: 908 RVA: 0x000045C5 File Offset: 0x000027C5
		internal static void SaveData()
		{
			AppUsageTimer.StopTimer();
			RegistryManager.Instance.AInfo = AppUsageTimer.EncryptString(JsonConvert.SerializeObject(AppUsageTimer.sDictAppUsageInfo));
		}

		// Token: 0x0600038D RID: 909 RVA: 0x00019704 File Offset: 0x00017904
		internal static string EncryptString(string encryptString)
		{
			string userGuid = RegistryManager.Instance.UserGuid;
			byte[] bytes = Encoding.Unicode.GetBytes(encryptString);
			using (Aes aes = Aes.Create())
			{
				Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(userGuid, new byte[]
				{
					73,
					118,
					97,
					110,
					32,
					77,
					101,
					100,
					118,
					101,
					100,
					101,
					118
				});
				aes.Key = rfc2898DeriveBytes.GetBytes(32);
				aes.IV = rfc2898DeriveBytes.GetBytes(16);
				using (MemoryStream memoryStream = new MemoryStream())
				{
					using (CryptoStream cryptoStream = new CryptoStream(memoryStream, aes.CreateEncryptor(), CryptoStreamMode.Write))
					{
						cryptoStream.Write(bytes, 0, bytes.Length);
						cryptoStream.Close();
					}
					encryptString = Convert.ToBase64String(memoryStream.ToArray());
				}
			}
			return encryptString;
		}

		// Token: 0x0600038E RID: 910 RVA: 0x000197EC File Offset: 0x000179EC
		public static string DecryptString(string decryptString)
		{
			string userGuid = RegistryManager.Instance.UserGuid;
			decryptString = decryptString.Replace(" ", "+");
			byte[] array = Convert.FromBase64String(decryptString);
			using (Aes aes = Aes.Create())
			{
				Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(userGuid, new byte[]
				{
					73,
					118,
					97,
					110,
					32,
					77,
					101,
					100,
					118,
					101,
					100,
					101,
					118
				});
				aes.Key = rfc2898DeriveBytes.GetBytes(32);
				aes.IV = rfc2898DeriveBytes.GetBytes(16);
				using (MemoryStream memoryStream = new MemoryStream())
				{
					using (CryptoStream cryptoStream = new CryptoStream(memoryStream, aes.CreateDecryptor(), CryptoStreamMode.Write))
					{
						cryptoStream.Write(array, 0, array.Length);
						cryptoStream.Close();
					}
					decryptString = Encoding.Unicode.GetString(memoryStream.ToArray());
				}
			}
			return decryptString;
		}

		// Token: 0x040001F2 RID: 498
		internal static Dictionary<string, Dictionary<string, long>> sDictAppUsageInfo = new Dictionary<string, Dictionary<string, long>>();

		// Token: 0x040001F3 RID: 499
		private static Dictionary<string, long> sResetQuestDict = new Dictionary<string, long>();

		// Token: 0x040001F4 RID: 500
		private static Stopwatch sStopwatch = new Stopwatch();

		// Token: 0x040001F5 RID: 501
		private static string sLastAppPackage = null;

		// Token: 0x040001F6 RID: 502
		private static string sLastVMName = null;

		// Token: 0x040001F7 RID: 503
		private static SessionSwitchEventHandler sessionSwitchHandler = new SessionSwitchEventHandler(AppUsageTimer.SystemEvents_SessionSwitch);
	}
}
