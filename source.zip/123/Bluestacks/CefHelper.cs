﻿using System;
using System.IO;
using System.Windows;
using BlueStacks.Common;
using Xilium.CefGlue;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001DD RID: 477
	internal class CefHelper : CefApp
	{
		// Token: 0x06001081 RID: 4225 RVA: 0x0000BC1B File Offset: 0x00009E1B
		public CefHelper()
		{
			if (RegistryManager.Instance.CefDevEnv == 0)
			{
				this.mDevToolEnable = false;
			}
		}

		// Token: 0x06001082 RID: 4226 RVA: 0x0000BC36 File Offset: 0x00009E36
		protected override CefRenderProcessHandler GetRenderProcessHandler()
		{
			return new RenderProcessHandler();
		}

		// Token: 0x06001083 RID: 4227 RVA: 0x00067724 File Offset: 0x00065924
		protected override void OnBeforeCommandLineProcessing(string processType, CefCommandLine commandLine)
		{
			if (string.IsNullOrEmpty(processType))
			{
				commandLine.AppendSwitch("disable-gpu");
				commandLine.AppendSwitch("disable-gpu-compositing");
				commandLine.AppendSwitch("disable-smooth-scrolling");
				commandLine.AppendSwitch("--enable-system-flash");
				commandLine.AppendSwitch("ppapi-flash-path", Path.Combine(RegistryManager.Instance.CefDataPath, "pepflashplayer.dll"));
				commandLine.AppendSwitch("plugin-policy", "allow");
				commandLine.AppendSwitch("enable-media-stream", "1");
				if (this.mDevToolEnable)
				{
					commandLine.AppendSwitch("enable-begin-frame-scheduling");
				}
			}
		}

		// Token: 0x170001F8 RID: 504
		// (get) Token: 0x06001084 RID: 4228 RVA: 0x0000BC3D File Offset: 0x00009E3D
		// (set) Token: 0x06001085 RID: 4229 RVA: 0x0000BC44 File Offset: 0x00009E44
		internal static bool CefInited { get; set; }

		// Token: 0x06001086 RID: 4230 RVA: 0x000677B8 File Offset: 0x000659B8
		internal static bool InitCef(string[] args, string mBSTProcessIdentifier)
		{
			try
			{
				CefRuntime.Load(RegistryManager.Instance.CefDataPath);
			}
			catch (DllNotFoundException ex)
			{
				MessageBox.Show(ex.Message, "Error!", MessageBoxButton.OK, MessageBoxImage.Hand);
				return false;
			}
			catch (CefRuntimeException ex2)
			{
				MessageBox.Show(ex2.Message, "Error!", MessageBoxButton.OK, MessageBoxImage.Hand);
				return false;
			}
			catch (Exception ex3)
			{
				MessageBox.Show(ex3.ToString(), "Error!", MessageBoxButton.OK, MessageBoxImage.Hand);
				return false;
			}
			CefMainArgs cefMainArgs = new CefMainArgs(args);
			CefHelper cefHelper = new CefHelper();
			CefRuntime.EnableHighDpiSupport();
			if (CefRuntime.ExecuteProcess(cefMainArgs, cefHelper, IntPtr.Zero) != -1)
			{
				return false;
			}
			string userAgent = "Mozilla/5.0(Windows NT 6.2; Win64; x64) AppleWebKit/537.36(KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36" + mBSTProcessIdentifier;
			if (!SystemUtils.IsOs64Bit())
			{
				userAgent = "Mozilla/5.0(Windows NT 6.2; WOW64) AppleWebKit/537.36(KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36" + mBSTProcessIdentifier;
			}
			CefSettings cefSettings = new CefSettings
			{
				SingleProcess = false,
				WindowlessRenderingEnabled = true,
				MultiThreadedMessageLoop = true,
				LogSeverity = 1,
				BackgroundColor = new CefColor(byte.MaxValue, 39, 41, 65),
				CachePath = Path.Combine(RegistryManager.Instance.CefDataPath, "Cache"),
				UserAgent = userAgent,
				Locale = RegistryManager.Instance.UserSelectedLocale
			};
			try
			{
				CefRuntime.Initialize(cefMainArgs, cefSettings, cefHelper, IntPtr.Zero);
			}
			catch (CefRuntimeException ex4)
			{
				MessageBox.Show(ex4.ToString(), "Error!", MessageBoxButton.OK, MessageBoxImage.Hand);
				return false;
			}
			CefHelper.CefInited = true;
			return true;
		}

		// Token: 0x04000B3D RID: 2877
		private bool mDevToolEnable;
	}
}
