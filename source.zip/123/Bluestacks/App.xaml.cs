﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Forms;
using System.Windows.Markup;
using BlueStacks.Common;
using Microsoft.Win32;
using Xilium.CefGlue;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000217 RID: 535
	public partial class App : System.Windows.Application
	{
		// Token: 0x17000211 RID: 529
		// (get) Token: 0x06001252 RID: 4690 RVA: 0x0000CFAD File Offset: 0x0000B1AD
		// (set) Token: 0x06001253 RID: 4691 RVA: 0x0000CFB4 File Offset: 0x0000B1B4
		internal static bool IsApplicationActive { get; set; }

		// Token: 0x06001255 RID: 4693 RVA: 0x00071698 File Offset: 0x0006F898
		private static void HandleDisplaySettingsChanged(object sender, EventArgs e)
		{
			try
			{
				foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>())
				{
					if (mainWindow != null && !mainWindow.mClosed)
					{
						mainWindow.HandleDisplaySettingsChanged();
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in HandleDisplaySettingsChanged. Exception: " + ex.ToString());
			}
		}

		// Token: 0x06001256 RID: 4694 RVA: 0x00071724 File Offset: 0x0006F924
		private static void ParseWebMagnetArgs(ref string[] args)
		{
			if (args.Length != 0 && args[0].StartsWith("bluestacksgp:", StringComparison.InvariantCultureIgnoreCase))
			{
				Logger.Info("Handling web uri: " + args[0]);
				string[] array = args[0].Split(new char[]
				{
					':'
				}, 2);
				string[] array2 = new string[args.Length + 1];
				string[] array3 = Uri.UnescapeDataString(array[1]).TrimStart(new char[0]).Split(new char[]
				{
					' '
				}, 2);
				if (array3.Length > 1)
				{
					Array.Copy(array3, 0, array2, 0, 2);
					Array.Copy(args, 1, array2, 2, args.Length - 1);
					args = array2;
					return;
				}
				args[0] = array3[0];
			}
		}

		// Token: 0x06001257 RID: 4695 RVA: 0x0000CFBC File Offset: 0x0000B1BC
		private static void InitExceptionAndLogging()
		{
			Logger.InitLog("BlueStacksUI", "BlueStacksUI", true);
			System.Windows.Forms.Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
			System.Windows.Forms.Application.ThreadException += App.Application_ThreadException;
			AppDomain.CurrentDomain.UnhandledException += App.CurrentDomain_UnhandledException;
		}

		// Token: 0x06001258 RID: 4696 RVA: 0x0000CFFB File Offset: 0x0000B1FB
		private static void Application_Startup(object sender, StartupEventArgs e)
		{
			Logger.Info("In Application_Startup");
			ServicePointManager.ServerCertificateValidationCallback = (RemoteCertificateValidationCallback)Delegate.Combine(ServicePointManager.ServerCertificateValidationCallback, new RemoteCertificateValidationCallback(App.ValidateRemoteCertificate));
			ServicePointManager.DefaultConnectionLimit = 1000;
		}

		// Token: 0x06001259 RID: 4697 RVA: 0x00005B45 File Offset: 0x00003D45
		private static bool ValidateRemoteCertificate(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors policyErrors)
		{
			return true;
		}

		// Token: 0x0600125A RID: 4698 RVA: 0x000717D0 File Offset: 0x0006F9D0
		private static void CheckIfAlreadyRunning()
		{
			if (Utils.CheckMultiInstallBeforeRunQuitMultiInstall())
			{
				int num = Utils.RunQuitMultiInstall();
				if (num != 0)
				{
					Logger.Info("Exiting application as runQuitMultiInstall returned " + num);
					App.ExitApplication();
				}
			}
			try
			{
				if (ProcessUtils.IsAlreadyRunning("Global\\BlueStacks_DiskCompactor_Lock"))
				{
					Logger.Info("Disk compaction is running in background");
					using (List<string>.Enumerator enumerator = GetProcessExecutionPath.GetApplicationPath(Process.GetProcessesByName("DiskCompactionTool")).GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							if (enumerator.Current.Equals(Path.Combine(RegistryStrings.InstallDir, "DiskCompactionTool.exe"), StringComparison.InvariantCultureIgnoreCase))
							{
								CustomMessageWindow customMessageWindow = new CustomMessageWindow();
								customMessageWindow.ImageName = "ProductLogo";
								customMessageWindow.TitleTextBlock.Text = string.Format("{0}", LocaleStrings.GetLocalizedString("STRING_EXIT_BLUESTACKS_DUE_TO_DISK_COMPACTION_HEADING", false));
								customMessageWindow.BodyTextBlock.Text = string.Format("{0}", LocaleStrings.GetLocalizedString("STRING_EXIT_BLUESTACKS_DUE_TO_DISK_COMPACTION_MESSAGE", false));
								customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
								customMessageWindow.CloseButtonHandle(null, null);
								customMessageWindow.ShowDialog();
								Logger.Info("Disk compaction running for this instance. Exiting this instance");
								App.ExitApplication();
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to check if disk compaction is running: " + ex.Message);
			}
			if (ProcessUtils.IsAlreadyRunning("Global\\BlueStacks_BlueStacksUI_Lock", out App.sBlueStacksUILock))
			{
				try
				{
					Logger.Info("Relaunching client for vm : " + Opt.Instance.vmname);
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					dictionary.Add("vmname", Opt.Instance.vmname);
					dictionary.Add("hidden", Opt.Instance.h.ToString());
					if (!string.IsNullOrEmpty(Opt.Instance.Json))
					{
						dictionary.Add("json", Opt.Instance.Json);
						string str = HTTPUtils.SendRequestToClient("openPackage", dictionary, Opt.Instance.vmname, 0, null, false, 1, 0);
						Logger.Debug("OpenPackage result: " + str);
					}
					else
					{
						string str2 = HTTPUtils.SendRequestToClient("showWindow", dictionary, Opt.Instance.vmname, 0, null, false, 1, 0);
						Logger.Debug("ShowWindow result: " + str2);
					}
				}
				catch (Exception ex2)
				{
					Logger.Error(ex2.ToString());
				}
				Logger.Info("BlueStacksUI already running. Exiting this instance");
				App.ExitApplication();
				return;
			}
			try
			{
				Logger.Debug("Checking for existing process not exited");
				List<Process> list = Process.GetProcessesByName(Process.GetCurrentProcess().ProcessName).ToList<Process>();
				if (ProcessUtils.IsLockInUse("Global\\BlueStacks_BlueStacksUI_Closing_Lock"))
				{
					foreach (Process process in list)
					{
						if (process.Id != Process.GetCurrentProcess().Id)
						{
							process.Kill();
						}
					}
				}
			}
			catch (Exception ex3)
			{
				Logger.Warning("Ignoring error closing previous instances" + ex3.ToString());
			}
		}

		// Token: 0x0600125B RID: 4699 RVA: 0x00071AE0 File Offset: 0x0006FCE0
		private static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
		{
			if (App.CheckForIgnoredExceptions(e.Exception.ToString()))
			{
				Logger.Error("Unhandled Thread Exception:");
				Logger.Error(e.Exception.ToString());
				if (!FeatureManager.Instance.IsCustomUIForNCSoft)
				{
					System.Windows.Forms.MessageBox.Show("BlueStacks App Player.\nError: " + e.Exception.ToString());
				}
				App.ExitApplication();
			}
		}

		// Token: 0x0600125C RID: 4700 RVA: 0x00071B48 File Offset: 0x0006FD48
		private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			if (App.CheckForIgnoredExceptions(((Exception)e.ExceptionObject).ToString()))
			{
				App.CheckForIgnoredExceptions(((Exception)e.ExceptionObject).ToString());
				Logger.Error("Unhandled Application Exception.");
				Logger.Error("Err: " + e.ExceptionObject.ToString());
				if (!FeatureManager.Instance.IsCustomUIForNCSoft)
				{
					System.Windows.Forms.MessageBox.Show("BlueStacks App Player.\nError: " + ((Exception)e.ExceptionObject).ToString());
				}
				App.ExitApplication();
			}
		}

		// Token: 0x0600125D RID: 4701 RVA: 0x0000D031 File Offset: 0x0000B231
		private static bool CheckForIgnoredExceptions(string s)
		{
			if (s.Contains("GetFocusedElementFromWinEvent"))
			{
				Logger.Warning("Ignoring Unhandled Application Exception: " + s);
				return false;
			}
			return true;
		}

		// Token: 0x0600125E RID: 4702 RVA: 0x00071BD8 File Offset: 0x0006FDD8
		internal static void ExitApplication()
		{
			foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>())
			{
				if (mainWindow != null && !mainWindow.mClosed)
				{
					mainWindow.ForceCloseWindow();
				}
			}
			App.UnwindEvents();
			App.ReleaseLock();
			Process.GetCurrentProcess().Kill();
		}

		// Token: 0x0600125F RID: 4703 RVA: 0x00071C54 File Offset: 0x0006FE54
		internal static void UnwindEvents()
		{
			try
			{
				SystemEvents.DisplaySettingsChanged -= App.HandleDisplaySettingsChanged;
			}
			catch (Exception arg)
			{
				Logger.Error("Couldn't unwind events properly; " + arg);
			}
		}

		// Token: 0x06001260 RID: 4704 RVA: 0x00071C98 File Offset: 0x0006FE98
		internal static void ReleaseLock()
		{
			try
			{
				BluestacksProcessHelper.TakeLock("Global\\BlueStacks_BlueStacksUI_Closing_Lock");
				if (App.sBlueStacksUILock != null)
				{
					App.sBlueStacksUILock.Close();
					App.sBlueStacksUILock = null;
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Ignoring Exception while releasing lock. Err : " + ex.ToString());
			}
		}

		// Token: 0x06001261 RID: 4705 RVA: 0x00071CF4 File Offset: 0x0006FEF4
		private void Application_Activated(object sender, EventArgs e)
		{
			App.IsApplicationActive = true;
			foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>())
			{
				if (mainWindow.IsGamepadConnected)
				{
					mainWindow.SendTempGamepadState(true);
				}
			}
		}

		// Token: 0x06001262 RID: 4706 RVA: 0x00071D60 File Offset: 0x0006FF60
		private void Application_Deactivated(object sender, EventArgs e)
		{
			App.IsApplicationActive = false;
			foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>())
			{
				if (mainWindow.IsGamepadConnected)
				{
					mainWindow.SendTempGamepadState(false);
				}
			}
		}

		// Token: 0x04000CEF RID: 3311
		public static Mutex sBlueStacksUILock;

		// Token: 0x04000CF1 RID: 3313
		internal static Fraction defaultResolution;

		// Token: 0x02000218 RID: 536
		public class FocusMonitor
		{
			// Token: 0x06001266 RID: 4710 RVA: 0x0000D064 File Offset: 0x0000B264
			public static void Init()
			{
				App.FocusMonitor.sProcessId = Process.GetCurrentProcess().Id;
				Automation.AddAutomationFocusChangedEventHandler(new AutomationFocusChangedEventHandler(App.FocusMonitor.OnFocusChanged));
			}

			// Token: 0x06001267 RID: 4711 RVA: 0x00071E20 File Offset: 0x00070020
			private static void OnFocusChanged(object sender, AutomationFocusChangedEventArgs e)
			{
				try
				{
					AutomationElement automationElement = sender as AutomationElement;
					if (automationElement != null)
					{
						AutomationElement.AutomationElementInformation automationElementInformation = automationElement.Current;
						if (automationElementInformation.ProcessId == App.FocusMonitor.sProcessId && BlueStacksUIUtils.ActivatedWindow != null)
						{
							BlueStacksUIUtils.ActivatedWindow.Dispatcher.Invoke(new Action(delegate()
							{
								try
								{
									bool flag = true;
									foreach (object obj in BlueStacksUIUtils.ActivatedWindow.OwnedWindows)
									{
										Window window = (Window)obj;
										CustomWindow customWindow;
										if ((customWindow = (window as CustomWindow)) != null)
										{
											if (!customWindow.IsShowGLWindow)
											{
												flag = false;
												Logger.Debug("OnFocusChanged window IsShowGLWindow false: " + customWindow.Name);
											}
										}
										else
										{
											Logger.Debug("OnFocusChanged Non Custom window found! " + window.Name);
										}
									}
									if (flag)
									{
										BlueStacksUIUtils.ActivatedWindow.mFrontendHandler.ShowGLWindow();
									}
								}
								catch
								{
								}
							}), new object[0]);
						}
					}
				}
				catch
				{
				}
			}

			// Token: 0x04000CF3 RID: 3315
			private static int sProcessId = int.MinValue;
		}
	}
}
