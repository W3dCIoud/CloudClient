﻿using System;
using System.ComponentModel;
using System.Windows.Input;

// Token: 0x0200000B RID: 11
[Description("ParentElement")]
[Serializable]
public class Pan : IMAction
{
	// Token: 0x17000062 RID: 98
	// (get) Token: 0x060000D0 RID: 208 RVA: 0x0000289A File Offset: 0x00000A9A
	// (set) Token: 0x060000D1 RID: 209 RVA: 0x000028A2 File Offset: 0x00000AA2
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X
	{
		get
		{
			return this.mX;
		}
		set
		{
			this.mX = value;
		}
	}

	// Token: 0x17000063 RID: 99
	// (get) Token: 0x060000D2 RID: 210 RVA: 0x000028AB File Offset: 0x00000AAB
	// (set) Token: 0x060000D3 RID: 211 RVA: 0x000028B3 File Offset: 0x00000AB3
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y
	{
		get
		{
			return this.mY;
		}
		set
		{
			this.mY = value;
		}
	}

	// Token: 0x17000064 RID: 100
	// (get) Token: 0x060000D4 RID: 212 RVA: 0x000028BC File Offset: 0x00000ABC
	// (set) Token: 0x060000D5 RID: 213 RVA: 0x000028C4 File Offset: 0x00000AC4
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyStartStop
	{
		get
		{
			return this.mKeyStartStop;
		}
		set
		{
			this.mKeyStartStop = value;
		}
	}

	// Token: 0x17000065 RID: 101
	// (get) Token: 0x060000D6 RID: 214 RVA: 0x000028CD File Offset: 0x00000ACD
	// (set) Token: 0x060000D7 RID: 215 RVA: 0x000028D5 File Offset: 0x00000AD5
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyStartStop_alt1
	{
		get
		{
			return this.mKeyStartStop_1;
		}
		set
		{
			this.mKeyStartStop_1 = value;
		}
	}

	// Token: 0x17000066 RID: 102
	// (get) Token: 0x060000D8 RID: 216 RVA: 0x000028DE File Offset: 0x00000ADE
	// (set) Token: 0x060000D9 RID: 217 RVA: 0x000028E6 File Offset: 0x00000AE6
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeySuspend
	{
		get
		{
			return this.mKeySuspend;
		}
		set
		{
			this.mKeySuspend = value;
		}
	}

	// Token: 0x17000067 RID: 103
	// (get) Token: 0x060000DA RID: 218 RVA: 0x000028EF File Offset: 0x00000AEF
	// (set) Token: 0x060000DB RID: 219 RVA: 0x000028F7 File Offset: 0x00000AF7
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeySuspend_alt1
	{
		get
		{
			return this.mKeySuspend_1;
		}
		set
		{
			this.mKeySuspend_1 = value;
		}
	}

	// Token: 0x17000068 RID: 104
	// (get) Token: 0x060000DC RID: 220 RVA: 0x00002900 File Offset: 0x00000B00
	// (set) Token: 0x060000DD RID: 221 RVA: 0x00002908 File Offset: 0x00000B08
	public double LookAroundX
	{
		get
		{
			return this.mLookAroundX;
		}
		set
		{
			this.mLookAroundX = value;
			this.CheckLookAround();
		}
	}

	// Token: 0x17000069 RID: 105
	// (get) Token: 0x060000DE RID: 222 RVA: 0x00002917 File Offset: 0x00000B17
	// (set) Token: 0x060000DF RID: 223 RVA: 0x0000291F File Offset: 0x00000B1F
	public double LookAroundY
	{
		get
		{
			return this.mLookAroundY;
		}
		set
		{
			this.mLookAroundY = value;
			this.CheckLookAround();
		}
	}

	// Token: 0x1700006A RID: 106
	// (get) Token: 0x060000E0 RID: 224 RVA: 0x0000292E File Offset: 0x00000B2E
	// (set) Token: 0x060000E1 RID: 225 RVA: 0x00002936 File Offset: 0x00000B36
	public string KeyLookAround
	{
		get
		{
			return this.mKeyLookAround;
		}
		set
		{
			this.mKeyLookAround = value;
		}
	}

	// Token: 0x1700006B RID: 107
	// (get) Token: 0x060000E2 RID: 226 RVA: 0x0000293F File Offset: 0x00000B3F
	// (set) Token: 0x060000E3 RID: 227 RVA: 0x00002947 File Offset: 0x00000B47
	public double LButtonX
	{
		get
		{
			return this.mLButtonX;
		}
		set
		{
			this.mLButtonX = value;
			this.CheckShootOnClick();
		}
	}

	// Token: 0x1700006C RID: 108
	// (get) Token: 0x060000E4 RID: 228 RVA: 0x00002956 File Offset: 0x00000B56
	// (set) Token: 0x060000E5 RID: 229 RVA: 0x0000295E File Offset: 0x00000B5E
	public double LButtonY
	{
		get
		{
			return this.mLButtonY;
		}
		set
		{
			this.mLButtonY = value;
			this.CheckShootOnClick();
		}
	}

	// Token: 0x1700006D RID: 109
	// (get) Token: 0x060000E6 RID: 230 RVA: 0x0000296D File Offset: 0x00000B6D
	internal string KeyAction
	{
		get
		{
			return this.mKeyAction;
		}
	}

	// Token: 0x1700006E RID: 110
	// (get) Token: 0x060000E7 RID: 231 RVA: 0x00002975 File Offset: 0x00000B75
	// (set) Token: 0x060000E8 RID: 232 RVA: 0x0000297D File Offset: 0x00000B7D
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Sensitivity
	{
		get
		{
			return this.mSensitivity;
		}
		set
		{
			this.mSensitivity = value;
		}
	}

	// Token: 0x1700006F RID: 111
	// (get) Token: 0x060000E9 RID: 233 RVA: 0x00002986 File Offset: 0x00000B86
	// (set) Token: 0x060000EA RID: 234 RVA: 0x0000298E File Offset: 0x00000B8E
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int Tweaks
	{
		get
		{
			return this.mTweaks;
		}
		set
		{
			this.mTweaks = value;
		}
	}

	// Token: 0x17000070 RID: 112
	// (get) Token: 0x060000EB RID: 235 RVA: 0x00002997 File Offset: 0x00000B97
	// (set) Token: 0x060000EC RID: 236 RVA: 0x0000299F File Offset: 0x00000B9F
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double SensitivityRatioY
	{
		get
		{
			return this.mSensitivityRatioY;
		}
		set
		{
			this.mSensitivityRatioY = value;
		}
	}

	// Token: 0x17000071 RID: 113
	// (get) Token: 0x060000ED RID: 237 RVA: 0x000029A8 File Offset: 0x00000BA8
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	internal bool IsLookAroundEnabled
	{
		get
		{
			return this.mLookAround != null;
		}
	}

	// Token: 0x17000072 RID: 114
	// (get) Token: 0x060000EE RID: 238 RVA: 0x000029B3 File Offset: 0x00000BB3
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	internal bool IsShootOnClickEnabled
	{
		get
		{
			return this.mPanShoot != null;
		}
	}

	// Token: 0x060000EF RID: 239 RVA: 0x000029BE File Offset: 0x00000BBE
	private void CheckLookAround()
	{
		if (this.mLookAroundX == -1.0 && this.mLookAroundY == -1.0)
		{
			this.mLookAround = null;
			return;
		}
		if (this.mLookAround == null)
		{
			this.mLookAround = new LookAround(this);
		}
	}

	// Token: 0x060000F0 RID: 240 RVA: 0x000029FE File Offset: 0x00000BFE
	private void CheckShootOnClick()
	{
		if (this.mLButtonX == -1.0 && this.mLButtonY == -1.0)
		{
			this.mPanShoot = null;
			return;
		}
		if (this.mPanShoot == null)
		{
			this.mPanShoot = new PanShoot(this);
		}
	}

	// Token: 0x17000073 RID: 115
	// (get) Token: 0x060000F1 RID: 241 RVA: 0x00002A3E File Offset: 0x00000C3E
	// (set) Token: 0x060000F2 RID: 242 RVA: 0x00002A46 File Offset: 0x00000C46
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool ShowOnOverlay
	{
		get
		{
			return this.mShowOnOverlay;
		}
		set
		{
			this.mShowOnOverlay = value;
		}
	}

	// Token: 0x17000074 RID: 116
	// (get) Token: 0x060000F3 RID: 243 RVA: 0x00002A4F File Offset: 0x00000C4F
	// (set) Token: 0x060000F4 RID: 244 RVA: 0x00002A57 File Offset: 0x00000C57
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool MouseAcceleration
	{
		get
		{
			return this.mMouseAcceleration;
		}
		set
		{
			this.mMouseAcceleration = value;
		}
	}

	// Token: 0x04000065 RID: 101
	internal LookAround mLookAround;

	// Token: 0x04000066 RID: 102
	internal PanShoot mPanShoot;

	// Token: 0x04000067 RID: 103
	private double mX = -1.0;

	// Token: 0x04000068 RID: 104
	private double mY = -1.0;

	// Token: 0x04000069 RID: 105
	private string mKeyStartStop = IMAPKeys.GetStringForFile(Key.F1);

	// Token: 0x0400006A RID: 106
	private string mKeyStartStop_1 = string.Empty;

	// Token: 0x0400006B RID: 107
	private string mKeySuspend = IMAPKeys.GetStringForFile(Key.LeftAlt);

	// Token: 0x0400006C RID: 108
	private string mKeySuspend_1 = string.Empty;

	// Token: 0x0400006D RID: 109
	private double mLookAroundX = -1.0;

	// Token: 0x0400006E RID: 110
	private double mLookAroundY = -1.0;

	// Token: 0x0400006F RID: 111
	private string mKeyLookAround = IMAPKeys.GetStringForFile(Key.V);

	// Token: 0x04000070 RID: 112
	private double mLButtonX = -1.0;

	// Token: 0x04000071 RID: 113
	private double mLButtonY = -1.0;

	// Token: 0x04000072 RID: 114
	private string mKeyAction = "MouseLButton";

	// Token: 0x04000073 RID: 115
	private double mSensitivity = 1.0;

	// Token: 0x04000074 RID: 116
	private int mTweaks;

	// Token: 0x04000075 RID: 117
	private double mSensitivityRatioY = 1.0;

	// Token: 0x04000076 RID: 118
	internal bool mShowOnOverlay = true;

	// Token: 0x04000077 RID: 119
	private bool mMouseAcceleration;
}
