﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

// Token: 0x02000006 RID: 6
[Description("Independent")]
[Serializable]
public class MOBADpad : IMAction
{
	// Token: 0x06000074 RID: 116 RVA: 0x0000FD60 File Offset: 0x0000DF60
	public MOBADpad()
	{
		this.IsChildAction = true;
		base.Type = KeyActionType.MOBADpad;
		MOBADpad.sListMOBADpad.Add(this);
	}

	// Token: 0x06000075 RID: 117 RVA: 0x0000FDD8 File Offset: 0x0000DFD8
	public MOBADpad(Dpad action)
	{
		this.IsChildAction = true;
		base.Type = KeyActionType.MOBADpad;
		MOBADpad.sListMOBADpad.Add(this);
		this.mDpad = action;
		this.ParentAction = action;
	}

	// Token: 0x17000037 RID: 55
	// (get) Token: 0x06000076 RID: 118 RVA: 0x000024EE File Offset: 0x000006EE
	// (set) Token: 0x06000077 RID: 119 RVA: 0x000024F6 File Offset: 0x000006F6
	public double X
	{
		get
		{
			return this.mX;
		}
		set
		{
			this.mX = value;
		}
	}

	// Token: 0x17000038 RID: 56
	// (get) Token: 0x06000078 RID: 120 RVA: 0x000024FF File Offset: 0x000006FF
	// (set) Token: 0x06000079 RID: 121 RVA: 0x00002507 File Offset: 0x00000707
	public double Y
	{
		get
		{
			return this.mY;
		}
		set
		{
			this.mY = value;
		}
	}

	// Token: 0x17000039 RID: 57
	// (get) Token: 0x0600007A RID: 122 RVA: 0x00002510 File Offset: 0x00000710
	// (set) Token: 0x0600007B RID: 123 RVA: 0x00002518 File Offset: 0x00000718
	[Description("IMAP_CanvasElementY")]
	public double OriginX
	{
		get
		{
			return this.mOriginX;
		}
		set
		{
			this.mOriginX = value;
		}
	}

	// Token: 0x1700003A RID: 58
	// (get) Token: 0x0600007C RID: 124 RVA: 0x00002521 File Offset: 0x00000721
	// (set) Token: 0x0600007D RID: 125 RVA: 0x00002529 File Offset: 0x00000729
	[Description("IMAP_CanvasElementX")]
	public double OriginY
	{
		get
		{
			return this.mOriginY;
		}
		set
		{
			this.mOriginY = value;
		}
	}

	// Token: 0x1700003B RID: 59
	// (get) Token: 0x0600007E RID: 126 RVA: 0x00002532 File Offset: 0x00000732
	// (set) Token: 0x0600007F RID: 127 RVA: 0x00002551 File Offset: 0x00000751
	public double XRadius
	{
		get
		{
			if (this.mDpad == null)
			{
				return -1.0;
			}
			return this.mDpad.XRadius;
		}
		set
		{
			if (this.mDpad != null)
			{
				this.mDpad.XRadius = value;
			}
		}
	}

	// Token: 0x1700003C RID: 60
	// (get) Token: 0x06000080 RID: 128 RVA: 0x00002567 File Offset: 0x00000767
	// (set) Token: 0x06000081 RID: 129 RVA: 0x00002586 File Offset: 0x00000786
	public double DpadSpeed
	{
		get
		{
			if (this.mDpad == null)
			{
				return -1.0;
			}
			return this.mDpad.Speed;
		}
		set
		{
			if (this.mDpad != null)
			{
				this.mDpad.Speed = value;
			}
		}
	}

	// Token: 0x1700003D RID: 61
	// (get) Token: 0x06000082 RID: 130 RVA: 0x0000259C File Offset: 0x0000079C
	// (set) Token: 0x06000083 RID: 131 RVA: 0x000025A4 File Offset: 0x000007A4
	public double CharSpeed
	{
		get
		{
			return this.mCharSpeed;
		}
		set
		{
			this.mCharSpeed = value;
		}
	}

	// Token: 0x0400003D RID: 61
	internal Dpad mDpad;

	// Token: 0x0400003E RID: 62
	internal static List<MOBADpad> sListMOBADpad = new List<MOBADpad>();

	// Token: 0x0400003F RID: 63
	private double mX = -1.0;

	// Token: 0x04000040 RID: 64
	private double mY = -1.0;

	// Token: 0x04000041 RID: 65
	private double mOriginX = -1.0;

	// Token: 0x04000042 RID: 66
	private double mOriginY = -1.0;

	// Token: 0x04000043 RID: 67
	private double mCharSpeed = 10.0;
}
