﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using BlueStacks.Common;

// Token: 0x02000002 RID: 2
[Serializable]
public abstract class IMAction
{
	// Token: 0x06000001 RID: 1 RVA: 0x0000F6C8 File Offset: 0x0000D8C8
	public IMAction()
	{
		this.GetPropertyInfo("Type");
		if (this.ParentAction == null)
		{
			this.ParentAction = this;
		}
	}

	// Token: 0x17000001 RID: 1
	// (get) Token: 0x06000002 RID: 2 RVA: 0x00002078 File Offset: 0x00000278
	// (set) Token: 0x06000003 RID: 3 RVA: 0x00002080 File Offset: 0x00000280
	public KeyActionType Type
	{
		get
		{
			return this.mType;
		}
		set
		{
			this.mType = value;
		}
	}

	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000004 RID: 4 RVA: 0x00002089 File Offset: 0x00000289
	// (set) Token: 0x06000005 RID: 5 RVA: 0x00002091 File Offset: 0x00000291
	public Dictionary<string, string> Guidance
	{
		get
		{
			return this.mGuidance;
		}
		set
		{
			this.mGuidance = value;
		}
	}

	// Token: 0x17000003 RID: 3
	// (get) Token: 0x06000006 RID: 6 RVA: 0x0000209A File Offset: 0x0000029A
	// (set) Token: 0x06000007 RID: 7 RVA: 0x000020CE File Offset: 0x000002CE
	public string GuidanceCategory
	{
		get
		{
			if (this.IsChildAction)
			{
				return this.ParentAction.GuidanceCategory;
			}
			if (string.IsNullOrEmpty(this.mGuidanceCategory))
			{
				this.mGuidanceCategory = "MISC";
			}
			return this.mGuidanceCategory;
		}
		set
		{
			this.mGuidanceCategory = value;
		}
	}

	// Token: 0x17000004 RID: 4
	// (get) Token: 0x06000008 RID: 8 RVA: 0x000020D7 File Offset: 0x000002D7
	// (set) Token: 0x06000009 RID: 9 RVA: 0x000020DF File Offset: 0x000002DF
	public string EnableCondition
	{
		get
		{
			return this.mEnableCondition;
		}
		set
		{
			this.mEnableCondition = value;
		}
	}

	// Token: 0x17000005 RID: 5
	// (get) Token: 0x0600000A RID: 10 RVA: 0x000020E8 File Offset: 0x000002E8
	// (set) Token: 0x0600000B RID: 11 RVA: 0x000020F0 File Offset: 0x000002F0
	public string StartCondition { get; set; }

	// Token: 0x17000006 RID: 6
	// (get) Token: 0x0600000C RID: 12 RVA: 0x000020F9 File Offset: 0x000002F9
	// (set) Token: 0x0600000D RID: 13 RVA: 0x00002101 File Offset: 0x00000301
	public string Comment { get; set; }

	// Token: 0x17000007 RID: 7
	// (get) Token: 0x0600000E RID: 14 RVA: 0x0000F718 File Offset: 0x0000D918
	// (set) Token: 0x0600000F RID: 15 RVA: 0x0000210A File Offset: 0x0000030A
	internal double PositionX
	{
		get
		{
			double result;
			if (!double.TryParse(this[IMAction.sPositionXPropertyName[this.Type]].ToString(), out result))
			{
				result = -1.0;
			}
			return result;
		}
		set
		{
			this[IMAction.sPositionXPropertyName[this.Type]] = value;
		}
	}

	// Token: 0x17000008 RID: 8
	// (get) Token: 0x06000010 RID: 16 RVA: 0x0000F754 File Offset: 0x0000D954
	// (set) Token: 0x06000011 RID: 17 RVA: 0x00002128 File Offset: 0x00000328
	internal double PositionY
	{
		get
		{
			double result;
			if (!double.TryParse(this[IMAction.sPositionYPropertyName[this.Type]].ToString(), out result))
			{
				result = -1.0;
			}
			return result;
		}
		set
		{
			this[IMAction.sPositionYPropertyName[this.Type]] = value;
		}
	}

	// Token: 0x17000009 RID: 9
	// (get) Token: 0x06000012 RID: 18 RVA: 0x0000F790 File Offset: 0x0000D990
	// (set) Token: 0x06000013 RID: 19 RVA: 0x00002146 File Offset: 0x00000346
	internal double RadiusProperty
	{
		get
		{
			double result;
			if (!double.TryParse(this[IMAction.sRadiusPropertyName[this.Type]].ToString(), out result))
			{
				result = -1.0;
			}
			return result;
		}
		set
		{
			this[IMAction.sRadiusPropertyName[this.Type]] = value;
		}
	}

	// Token: 0x1700000A RID: 10
	// (get) Token: 0x06000014 RID: 20 RVA: 0x0000F7CC File Offset: 0x0000D9CC
	// (set) Token: 0x06000015 RID: 21 RVA: 0x00002164 File Offset: 0x00000364
	public bool IsVisibleInOverlay
	{
		get
		{
			bool result;
			if (!bool.TryParse(this["ShowOnOverlay"].ToString(), out result))
			{
				result = false;
			}
			return result;
		}
		set
		{
			this["ShowOnOverlay"] = value;
		}
	}

	// Token: 0x1700000B RID: 11
	public object this[string propertyName]
	{
		get
		{
			object obj = null;
			if (this.GetPropertyInfo(propertyName) != null)
			{
				obj = this.GetPropertyInfo(propertyName).GetValue(this, null);
			}
			if (obj != null)
			{
				return obj;
			}
			return string.Empty;
		}
		set
		{
			try
			{
				PropertyInfo propertyInfo = this.GetPropertyInfo(propertyName);
				if (propertyInfo != null)
				{
					propertyInfo.SetValue(this, Convert.ChangeType(value, this.GetPropertyInfo(propertyName).PropertyType), null);
				}
			}
			catch (Exception ex)
			{
				Logger.Error(Constants.ImapLocaleStringsConstant + " error parsing variable set " + ex.ToString());
			}
		}
	}

	// Token: 0x06000018 RID: 24 RVA: 0x0000F890 File Offset: 0x0000DA90
	private PropertyInfo GetPropertyInfo(string propertyName)
	{
		PropertyInfo result = null;
		KeyActionType key = EnumHelper.Parse<KeyActionType>(base.GetType().Name, KeyActionType.Alias);
		if (!IMAction.DictPropertyInfo.ContainsKey(key))
		{
			IMAction.DictPropertyInfo[key] = new Dictionary<string, PropertyInfo>();
			IMAction.DictPopUpUIElements[key] = new Dictionary<string, PropertyInfo>();
			IMAction.sDictDevModeUIElements[key] = new Dictionary<string, PropertyInfo>();
			IMAction.sPositionXPropertyName[key] = string.Empty;
			IMAction.sPositionYPropertyName[key] = string.Empty;
			IMAction.sRadiusPropertyName[key] = string.Empty;
			foreach (PropertyInfo propertyInfo in base.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
			{
				IMAction.DictPropertyInfo[key].Add(propertyInfo.Name, propertyInfo);
				object[] customAttributes = propertyInfo.GetCustomAttributes(typeof(DescriptionAttribute), true);
				if (customAttributes.Length != 0)
				{
					DescriptionAttribute descriptionAttribute = customAttributes[0] as DescriptionAttribute;
					if (descriptionAttribute.Description.Contains("IMAP_CanvasElementY"))
					{
						IMAction.sPositionXPropertyName[key] = propertyInfo.Name;
					}
					if (descriptionAttribute.Description.Contains("IMAP_CanvasElementX"))
					{
						IMAction.sPositionYPropertyName[key] = propertyInfo.Name;
					}
					if (descriptionAttribute.Description.Contains("IMAP_CanvasElementRadius"))
					{
						IMAction.sRadiusPropertyName[key] = propertyInfo.Name;
					}
					if (descriptionAttribute.Description.Contains("IMAP_PopupUIElement"))
					{
						IMAction.DictPopUpUIElements[key].Add(propertyInfo.Name, propertyInfo);
					}
					if (descriptionAttribute.Description.Contains("IMAP_DeveloperModeUIElemnt"))
					{
						IMAction.sDictDevModeUIElements[key].Add(propertyInfo.Name, propertyInfo);
					}
				}
			}
		}
		if (!string.IsNullOrEmpty(propertyName) && IMAction.DictPropertyInfo[key].ContainsKey(propertyName))
		{
			result = IMAction.DictPropertyInfo[key][propertyName];
		}
		return result;
	}

	// Token: 0x06000019 RID: 25 RVA: 0x0000FA78 File Offset: 0x0000DC78
	internal List<Tuple<string, IMAction>> GetListGuidanceElements()
	{
		List<string> list = new List<string>();
		List<Tuple<string, IMAction>> list2 = new List<Tuple<string, IMAction>>();
		foreach (KeyValuePair<string, string> keyValuePair in this.Guidance)
		{
			if (keyValuePair.Key.StartsWith("Key"))
			{
				list2.Add(new Tuple<string, IMAction>(keyValuePair.Key, this));
				list.Add(keyValuePair.Key);
			}
		}
		foreach (KeyValuePair<string, PropertyInfo> keyValuePair2 in IMAction.DictPropertyInfo[this.Type])
		{
			if (!list.Contains(keyValuePair2.Key) && (keyValuePair2.Key.StartsWith("Key") || keyValuePair2.Key.StartsWith("Sensitivity") || keyValuePair2.Key.StartsWith("MouseAcceleration")))
			{
				list2.Add(new Tuple<string, IMAction>(keyValuePair2.Key, this));
			}
		}
		return list2;
	}

	// Token: 0x04000001 RID: 1
	private const string UNCATEGORISEDKEYS = "MISC";

	// Token: 0x04000002 RID: 2
	internal static Dictionary<KeyActionType, Dictionary<string, PropertyInfo>> sDictDevModeUIElements = new Dictionary<KeyActionType, Dictionary<string, PropertyInfo>>();

	// Token: 0x04000003 RID: 3
	internal static Dictionary<KeyActionType, Dictionary<string, PropertyInfo>> DictPropertyInfo = new Dictionary<KeyActionType, Dictionary<string, PropertyInfo>>();

	// Token: 0x04000004 RID: 4
	internal static Dictionary<KeyActionType, Dictionary<string, PropertyInfo>> DictPopUpUIElements = new Dictionary<KeyActionType, Dictionary<string, PropertyInfo>>();

	// Token: 0x04000005 RID: 5
	private KeyActionType mType;

	// Token: 0x04000006 RID: 6
	private Dictionary<string, string> mGuidance = new Dictionary<string, string>();

	// Token: 0x04000007 RID: 7
	private string mGuidanceCategory = "MISC";

	// Token: 0x04000008 RID: 8
	private string mEnableCondition = string.Empty;

	// Token: 0x0400000B RID: 11
	internal Direction Direction;

	// Token: 0x0400000C RID: 12
	internal IMAction ParentAction;

	// Token: 0x0400000D RID: 13
	private static Dictionary<KeyActionType, string> sPositionXPropertyName = new Dictionary<KeyActionType, string>();

	// Token: 0x0400000E RID: 14
	private static Dictionary<KeyActionType, string> sPositionYPropertyName = new Dictionary<KeyActionType, string>();

	// Token: 0x0400000F RID: 15
	internal static Dictionary<KeyActionType, string> sRadiusPropertyName = new Dictionary<KeyActionType, string>();

	// Token: 0x04000010 RID: 16
	internal bool IsChildAction;
}
