﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000D3 RID: 211
	public class KeymapCanvasWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x1700016C RID: 364
		// (get) Token: 0x0600089C RID: 2204 RVA: 0x000077B7 File Offset: 0x000059B7
		// (set) Token: 0x0600089D RID: 2205 RVA: 0x00037440 File Offset: 0x00035640
		public static bool sIsDirty
		{
			get
			{
				return KeymapCanvasWindow.IsDirty;
			}
			set
			{
				KeymapCanvasWindow.IsDirty = value;
				if (KMManager.CanvasWindow != null && KMManager.CanvasWindow.SidebarWindow != null)
				{
					KMManager.CanvasWindow.SidebarWindow.mRevertBtn.IsEnabled = KeymapCanvasWindow.IsDirty;
					KMManager.CanvasWindow.SidebarWindow.mSaveBtn.IsEnabled = KeymapCanvasWindow.IsDirty;
				}
			}
		}

		// Token: 0x1700016D RID: 365
		// (get) Token: 0x0600089E RID: 2206 RVA: 0x000077BE File Offset: 0x000059BE
		// (set) Token: 0x0600089F RID: 2207 RVA: 0x000077C6 File Offset: 0x000059C6
		internal bool IsInOverlayMode
		{
			get
			{
				return this.mIsInOverlayMode;
			}
			set
			{
				this.mIsInOverlayMode = value;
				base.IsShowGLWindow = value;
			}
		}

		// Token: 0x060008A0 RID: 2208 RVA: 0x00037498 File Offset: 0x00035698
		internal KeymapCanvasWindow(MainWindow window)
		{
			this.ParentWindow = window;
			this.InitializeComponent();
			this.mParentWindowHeight = this.ParentWindow.ActualHeight * MainWindow.sScalingFactor;
			this.mParentWindowWidth = this.ParentWindow.ActualWidth * MainWindow.sScalingFactor;
			this.mParentWindowTop = this.ParentWindow.Top * MainWindow.sScalingFactor;
			this.mParentWindowLeft = this.ParentWindow.Left * MainWindow.sScalingFactor;
		}

		// Token: 0x060008A1 RID: 2209 RVA: 0x000077D6 File Offset: 0x000059D6
		internal void ClearWindow()
		{
			this.dictCanvasElement.Clear();
			CanvasElement.dictPoints.Clear();
			this.mCanvas.Children.Clear();
		}

		// Token: 0x060008A2 RID: 2210 RVA: 0x000375A0 File Offset: 0x000357A0
		private void Canvas_MouseEnter(object sender, MouseEventArgs e)
		{
			if (KMManager.IsDragging)
			{
				this.isNewElementAdded = true;
				KeymapCanvasWindow.sIsDirty = true;
				List<IMAction> lstAction = KMManager.ClearElement();
				this.AddNewCanvasElement(lstAction, false);
				this.StartMoving(this.mCanvasElement, e.GetPosition(this));
			}
		}

		// Token: 0x060008A3 RID: 2211 RVA: 0x000375E4 File Offset: 0x000357E4
		public void AddNewCanvasElement(List<IMAction> lstAction, bool isTap = false)
		{
			this.mCanvasElement = new CanvasElement(this, this.ParentWindow);
			foreach (IMAction imaction in lstAction)
			{
				if (isTap)
				{
					Canvas canvas = this.mCanvas;
					double num = (base.ActualWidth - this.mCanvasElement.ActualWidth) * 100.0 / (base.ActualWidth * 3.0) + (double)(this.mTapXMargin * this.mCurrentTapElementDisplayCol);
					Canvas.SetLeft(this.mCanvasElement, num);
					double num2 = (base.ActualHeight - this.mCanvasElement.ActualHeight) * 100.0 / (base.ActualHeight * 3.0) + (double)(this.mTapYMargin * this.mCurrentTapElementDisplayRow);
					Canvas.SetTop(this.mCanvasElement, num2);
					imaction.PositionX = Math.Round(num, 2);
					imaction.PositionY = Math.Round(num2, 2);
					this.mCurrentTapElementDisplayCol++;
					if (this.mCurrentTapElementDisplayCol == this.mMaxElementPerRow)
					{
						this.mCurrentTapElementDisplayCol = 0;
						this.mCurrentTapElementDisplayRow++;
					}
				}
				this.mCanvasElement.AddAction(imaction);
				this.dictCanvasElement.Add(imaction, this.mCanvasElement);
				if (isTap)
				{
					this.mCanvasElement.ShowTextBox(this.mCanvasElement.dictTextElemets.First<KeyValuePair<Positions, Tuple<string, TextBox, TextBlock, List<IMAction>>>>().Value.Item3);
				}
				if (!imaction.IsChildAction && imaction.Type != KeyActionType.MOBADpad)
				{
					this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Add(imaction);
				}
			}
			this.mCanvasElement.PreviewMouseLeftButtonDown += this.MoveIcon_PreviewMouseDown;
			this.mCanvasElement.mResizeIcon.PreviewMouseDown += this.ResizeIcon_PreviewMouseDown;
			this.mCanvas.Children.Add(this.mCanvasElement);
		}

		// Token: 0x060008A4 RID: 2212 RVA: 0x000377FC File Offset: 0x000359FC
		private void ResizeIcon_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
			}
			this.mCanvasElement = WpfUtils.FindVisualParent<CanvasElement>(sender as DependencyObject);
			this.mCanvasElement.mResizeIcon.Focus();
			this.startPoint = e.GetPosition(this);
			this.mCanvas.PreviewMouseMove += this.CanvasResizeExistingElement_MouseMove;
			KeymapCanvasWindow.sIsDirty = true;
			e.Handled = true;
			Mouse.Capture(this.mCanvas);
		}

		// Token: 0x060008A5 RID: 2213 RVA: 0x00037894 File Offset: 0x00035A94
		private void CanvasResizeExistingElement_MouseMove(object sender, MouseEventArgs e)
		{
			base.Cursor = Cursors.SizeNWSE;
			Point position = e.GetPosition(this);
			double num = position.X - this.startPoint.X;
			double num2 = position.Y - this.startPoint.Y;
			double num3 = num2;
			if (Math.Abs(num) > Math.Abs(num2))
			{
				num3 = num;
			}
			num3 = Math.Round(num3, 2);
			double num4 = this.mCanvasElement.ActualWidth + num3;
			double actualHeight = this.mCanvasElement.ActualHeight;
			if (num4 < 40.0)
			{
				num4 = 40.0;
				num3 = num4 - this.mCanvasElement.ActualWidth;
			}
			if (num4 < 70.0)
			{
				double top = this.mCanvasElement.ActualHeight - 20.0;
				this.mCanvasElement.mSkillImage.Margin = new Thickness(-50.0, top, 10.0, 0.0);
			}
			if (this.mCanvasElement.mSkillImage.Visibility == Visibility.Visible)
			{
				this.mCanvasElement.mActionIcon.Visibility = Visibility.Visible;
			}
			double num5 = Canvas.GetTop(this.mCanvasElement);
			double num6 = Canvas.GetLeft(this.mCanvasElement);
			if (double.IsNaN(num5))
			{
				num5 = 0.0;
			}
			if (double.IsNaN(num6))
			{
				num6 = 0.0;
			}
			num5 -= num3 / 2.0;
			num6 -= num3 / 2.0;
			this.mCanvasElement.Width = num4;
			this.mCanvasElement.Height = num4;
			Canvas.SetLeft(this.mCanvasElement, num6);
			Canvas.SetTop(this.mCanvasElement, num5);
			this.mCanvasElement.UpdatePosition(num5, num6);
			this.startPoint = position;
		}

		// Token: 0x060008A6 RID: 2214 RVA: 0x00037A60 File Offset: 0x00035C60
		internal void ReloadCanvasWindow()
		{
			this.mCurrentTapElementDisplayRow = 0;
			this.mCurrentTapElementDisplayCol = 0;
			KMManager.LoadIMActions(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName);
			this.mCanvas.Children.Clear();
			this.Init();
		}

		// Token: 0x060008A7 RID: 2215 RVA: 0x00037AB0 File Offset: 0x00035CB0
		private void MoveIcon_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			CanvasElement canvasElement = sender as CanvasElement;
			if (canvasElement.mMOBASkillSettingsPopup != null && canvasElement.mMOBASkillSettingsPopup.IsOpen)
			{
				e.Handled = true;
				return;
			}
			canvasElement.TopOnClick = Canvas.GetTop(canvasElement);
			canvasElement.LeftOnClick = Canvas.GetLeft(canvasElement);
			Point position = e.GetPosition(this);
			if (!canvasElement.mResizeIcon.IsMouseOver && !canvasElement.mCloseIcon.IsMouseOver)
			{
				if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
				{
					IMAction imaction = canvasElement.lstActionItem.First<IMAction>();
					if (!imaction.IsChildAction)
					{
						IMAction imaction2 = imaction.DeepCopy<IMAction>();
						imaction2.PositionX = imaction.PositionX + 1.0;
						List<CanvasElement> source = this.AddCanvasElementsForAction(imaction2, false);
						if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
						{
							KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
						}
						this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Add(imaction2);
						this.StartMoving(source.First<CanvasElement>(), e.GetPosition(this));
					}
				}
				else
				{
					this.StartMoving(canvasElement, position);
				}
				e.Handled = true;
			}
		}

		// Token: 0x060008A8 RID: 2216 RVA: 0x00037BE0 File Offset: 0x00035DE0
		private void CanvasMoveExistingElement_MouseMove(object sender, MouseEventArgs e)
		{
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
			}
			base.Focus();
			this.MoveElement(e.GetPosition(this));
		}

		// Token: 0x060008A9 RID: 2217 RVA: 0x00037C30 File Offset: 0x00035E30
		internal void StartMoving(CanvasElement element, Point p)
		{
			if (this.mCanvasElement == null || this.mCanvasElement == element)
			{
				KeymapCanvasWindow.sIsDirty = true;
				this.mCanvasElement = element;
				this.startPoint = p;
				this.mCanvas.PreviewMouseMove -= this.CanvasMoveExistingElement_MouseMove;
				this.mCanvas.PreviewMouseMove += this.CanvasMoveExistingElement_MouseMove;
			}
		}

		// Token: 0x060008AA RID: 2218 RVA: 0x00037C90 File Offset: 0x00035E90
		internal void MoveElement(Point p1)
		{
			if (this.mCanvasElement.IsLoaded)
			{
				base.Cursor = Cursors.Hand;
				double num = Canvas.GetTop(this.mCanvasElement);
				double num2 = Canvas.GetLeft(this.mCanvasElement);
				if (double.IsNaN(num))
				{
					num = 0.0;
				}
				if (double.IsNaN(num2))
				{
					num2 = 0.0;
				}
				double num3 = num2 + this.mCanvasElement.ActualWidth / 2.0;
				double num4 = num + this.mCanvasElement.ActualHeight / 2.0;
				num3 += p1.X - this.startPoint.X;
				num4 += p1.Y - this.startPoint.Y;
				num3 = ((num3 < 0.0) ? 0.0 : num3);
				num4 = ((num4 < 0.0) ? 0.0 : num4);
				num3 = ((num3 > this.mCanvas.ActualWidth) ? this.mCanvas.ActualWidth : num3);
				num4 = ((num4 > this.mCanvas.ActualHeight) ? this.mCanvas.ActualHeight : num4);
				num2 = num3 - this.mCanvasElement.ActualWidth / 2.0;
				num = num4 - this.mCanvasElement.ActualHeight / 2.0;
				Canvas.SetLeft(this.mCanvasElement, num2);
				Canvas.SetTop(this.mCanvasElement, num);
				this.mCanvasElement.UpdatePosition(num, num2);
				this.startPoint = p1;
			}
		}

		// Token: 0x060008AB RID: 2219 RVA: 0x00037E18 File Offset: 0x00036018
		internal void Init()
		{
			this.ClearWindow();
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls != null)
			{
				foreach (IMAction imaction in this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls)
				{
					if (!this.IsInOverlayMode || imaction.IsVisibleInOverlay)
					{
						this.AddCanvasElementsForAction(imaction, true);
					}
				}
			}
		}

		// Token: 0x060008AC RID: 2220 RVA: 0x00037EAC File Offset: 0x000360AC
		internal void InitLayout()
		{
			MainWindow parentWindow = this.ParentWindow;
			Grid mFrontendGrid = parentWindow.mFrontendGrid;
			Point point = mFrontendGrid.TranslatePoint(default(Point), parentWindow);
			if (this.IsInOverlayMode)
			{
				base.Background = Brushes.Transparent;
				this.mCanvas.Background = Brushes.Transparent;
				this.mCanvas.Margin = default(Thickness);
				if (FeatureManager.Instance.IsCustomUIForDMM)
				{
					base.Opacity = RegistryManager.Instance.TranslucentControlsTransparency;
				}
				else
				{
					this.mCanvas.Opacity = 1.0;
				}
				this.Handle = new WindowInteropHelper(this).EnsureHandle();
				int dwNewLong = 1207959552;
				InteropWindow.SetWindowLong(this.Handle, -16, dwNewLong);
				return;
			}
			IntereopRect fullscreenMonitorSize = WindowWndProcHandler.GetFullscreenMonitorSize(this.ParentWindow.Handle, true);
			double num = (double)fullscreenMonitorSize.Width - (double)this.mSidebarWidth * MainWindow.sScalingFactor;
			if (!this.ParentWindow.EngineInstanceRegistry.IsSidebarVisible)
			{
				num -= this.ParentWindow.mSidebar.Width * MainWindow.sScalingFactor;
			}
			double num2 = this.ParentWindow.GetHeightFromWidth(num, true);
			if (num2 > (double)fullscreenMonitorSize.Height)
			{
				num2 = (double)fullscreenMonitorSize.Height;
				num = this.ParentWindow.GetWidthFromHeight(num2, true);
			}
			double top;
			if (this.ParentWindow.Top + num2 > (double)fullscreenMonitorSize.Height)
			{
				top = (double)fullscreenMonitorSize.Y;
			}
			else
			{
				top = this.ParentWindow.Top;
			}
			double left;
			if (this.ParentWindow.Left + num + (double)this.mSidebarWidth * MainWindow.sScalingFactor > (double)fullscreenMonitorSize.Width)
			{
				left = (double)fullscreenMonitorSize.X;
			}
			else
			{
				left = this.ParentWindow.Left;
			}
			this.ParentWindow.ChangeHeightWidthTopLeft(num, num2, top, left);
			base.Width = this.ParentWindow.ActualWidth;
			base.Height = this.ParentWindow.ActualHeight;
			base.Top = this.ParentWindow.Top;
			base.Left = this.ParentWindow.Left;
			Point point2 = new Point(parentWindow.ActualWidth - (mFrontendGrid.ActualWidth + point.X), parentWindow.ActualHeight - (mFrontendGrid.ActualHeight + point.Y));
			this.mCanvas.Margin = new Thickness(point.X, point.Y, point2.X, point2.Y);
			this.mCanvas.Width = mFrontendGrid.ActualWidth;
			this.mCanvas.Height = mFrontendGrid.ActualHeight;
		}

		// Token: 0x060008AD RID: 2221 RVA: 0x00038144 File Offset: 0x00036344
		private List<CanvasElement> AddCanvasElementsForAction(IMAction item, bool isLoadingFromFile = false)
		{
			List<CanvasElement> canvasElement = CanvasElement.GetCanvasElement(item, this, this.ParentWindow);
			foreach (CanvasElement canvasElement2 in canvasElement)
			{
				canvasElement2.mIsLoadingfromFile = isLoadingFromFile;
				foreach (IMAction key in canvasElement2.lstActionItem)
				{
					this.dictCanvasElement[key] = canvasElement2;
				}
				if (canvasElement2.Parent == null)
				{
					this.mCanvas.Children.Add(canvasElement2);
					canvasElement2.PreviewMouseLeftButtonDown -= this.MoveIcon_PreviewMouseDown;
					canvasElement2.mResizeIcon.PreviewMouseDown -= this.ResizeIcon_PreviewMouseDown;
					canvasElement2.PreviewMouseLeftButtonDown += this.MoveIcon_PreviewMouseDown;
					canvasElement2.mResizeIcon.PreviewMouseDown += this.ResizeIcon_PreviewMouseDown;
				}
			}
			return canvasElement;
		}

		// Token: 0x060008AE RID: 2222 RVA: 0x00038260 File Offset: 0x00036460
		private void Canvas_MouseUp(object sender, MouseButtonEventArgs e)
		{
			base.Cursor = Cursors.Arrow;
			if (this.mCanvasElement != null)
			{
				UIElement element = this.mCanvasElement;
				int num = this.zIndex;
				this.zIndex = num + 1;
				Panel.SetZIndex(element, num);
				this.mCanvasElement.ShowOtherIcons(true);
				if (this.mCanvasElement.IsMouseDirectlyOver)
				{
					e.Handled = true;
				}
				if (this.isNewElementAdded && this.mCanvasElement.dictTextElemets.Count > 0)
				{
					this.isNewElementAdded = false;
					this.mCanvasElement.ShowTextBox(this.mCanvasElement.dictTextElemets.First<KeyValuePair<Positions, Tuple<string, TextBox, TextBlock, List<IMAction>>>>().Value.Item3);
				}
			}
			this.startPoint = new Point(-1.0, -1.0);
			this.mCanvas.PreviewMouseMove -= this.CanvasMoveExistingElement_MouseMove;
			this.mCanvas.PreviewMouseMove -= this.CanvasResizeExistingElement_MouseMove;
			Mouse.Capture(null);
			this.mCanvasElement = null;
		}

		// Token: 0x060008AF RID: 2223 RVA: 0x000077FD File Offset: 0x000059FD
		private void KeymapCanvasWindow_Closing(object sender, CancelEventArgs e)
		{
			if (this.SidebarWindow != null)
			{
				e.Cancel = true;
				ThreadPool.QueueUserWorkItem(delegate(object stateInfo)
				{
					base.Dispatcher.Invoke(new Action(delegate()
					{
						this.SidebarWindow.Close();
					}), new object[0]);
				});
			}
			else
			{
				this.mIsClosing = true;
			}
			this.ParentWindow.Focus();
		}

		// Token: 0x060008B0 RID: 2224 RVA: 0x00007835 File Offset: 0x00005A35
		private void CustomWindow_Closed(object sender, EventArgs e)
		{
			if (KMManager.dictOverlayWindow.ContainsKey(this.ParentWindow) && KMManager.dictOverlayWindow[this.ParentWindow] == this)
			{
				KMManager.dictOverlayWindow.Remove(this.ParentWindow);
			}
		}

		// Token: 0x060008B1 RID: 2225 RVA: 0x00038364 File Offset: 0x00036564
		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			InteropWindow.RemoveWindowFromAltTabUI(new WindowInteropHelper(this).Handle);
			if (!this.IsInOverlayMode)
			{
				this.ShowSideBarWindow();
			}
			else
			{
				base.Topmost = true;
				this.Handle = new WindowInteropHelper(this).Handle;
				int dwNewLong = 1207959552;
				InteropWindow.SetWindowLong(this.Handle, -16, dwNewLong);
				this.ParentWindow.mFrontendHandler.UpdateOverlaySizeStatus();
				this.ParentWindow.LocationChanged += this.ParentWindow_LocationChanged;
				this.ParentWindow.Activated += this.ParentWindow_Activated;
				this.ParentWindow.Deactivated += this.ParentWindow_Deactivated;
				this.UpdateSize();
			}
			this.Init();
		}

		// Token: 0x060008B2 RID: 2226 RVA: 0x0000786D File Offset: 0x00005A6D
		private void ParentWindow_Deactivated(object sender, EventArgs e)
		{
			if (!this.mIsClosing)
			{
				base.Hide();
			}
		}

		// Token: 0x060008B3 RID: 2227 RVA: 0x0000787D File Offset: 0x00005A7D
		private void ParentWindow_Activated(object sender, EventArgs e)
		{
			if (!this.mIsClosing)
			{
				base.Show();
			}
		}

		// Token: 0x060008B4 RID: 2228 RVA: 0x0000788D File Offset: 0x00005A8D
		private void ParentWindow_LocationChanged(object sender, EventArgs e)
		{
			this.UpdateSize();
		}

		// Token: 0x060008B5 RID: 2229 RVA: 0x00038424 File Offset: 0x00036624
		internal void UpdateSize()
		{
			if (this.ParentWindow.StaticComponents.mLastMappableWindowHandle != IntPtr.Zero && !this.mIsClosing)
			{
				if (this.mIsShowWindow)
				{
					this.mIsShowWindow = false;
					Logger.Debug("KMP KeymapCanvasWindow UpdateSize");
					this.ParentWindow.mFrontendHandler.DeactivateFrontend();
					base.Show();
					return;
				}
				InteropWindow.RECT rect = default(InteropWindow.RECT);
				InteropWindow.GetWindowRect(this.ParentWindow.StaticComponents.mLastMappableWindowHandle, ref rect);
				int left = rect.left;
				int top = rect.top;
				int w = rect.right - rect.left;
				int h = rect.bottom - rect.top;
				InteropWindow.SetWindowPos(this.Handle, (IntPtr)0, left, top, w, h, 16448U);
				this.ParentWindow.mFrontendHandler.FocusFrontend(false);
			}
		}

		// Token: 0x060008B6 RID: 2230 RVA: 0x00038504 File Offset: 0x00036704
		private Point GetCorrectCoordinateLocationForAndroid(Point p)
		{
			double x = p.X * 100.0 / this.ParentWindow.Width;
			double y = p.Y * 100.0 / this.ParentWindow.Height;
			return new Point(x, y);
		}

		// Token: 0x060008B7 RID: 2231 RVA: 0x00038554 File Offset: 0x00036754
		private void ShowSideBarWindow()
		{
			if (this.SidebarWindow == null)
			{
				this.SidebarWindow = new AdvancedGameControlWindow(this.ParentWindow);
				this.SidebarWindow.Init(this);
				this.SidebarWindow.Owner = this;
				this.SidebarWindow.Show();
				this.SidebarWindow.Activate();
			}
		}

		// Token: 0x060008B8 RID: 2232 RVA: 0x000385AC File Offset: 0x000367AC
		private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (CanvasElement.sFocusedTextBox != null)
			{
				WpfUtils.FindVisualParent<CanvasElement>(CanvasElement.sFocusedTextBox as DependencyObject).TxtBox_LostFocus(CanvasElement.sFocusedTextBox, new RoutedEventArgs());
				return;
			}
			if (double.IsNaN(this.CanvasWindowLeft) && double.IsNaN(this.CanvasWindowTop))
			{
				this.CanvasWindowLeft = base.Left;
				this.CanvasWindowTop = base.Top;
				this.mMousePointForNewTap = Mouse.GetPosition(this.mCanvas);
			}
			KeymapCanvasWindow.sIsDirty = true;
			try
			{
				base.DragMove();
			}
			catch (Exception)
			{
			}
			if (Math.Abs(this.CanvasWindowLeft - base.Left) < 2.0 && Math.Abs(this.CanvasWindowTop - base.Top) < 2.0)
			{
				if (KMManager.sIsInScriptEditingMode)
				{
					return;
				}
				IMAction item = new Tap
				{
					Type = KeyActionType.Tap
				};
				if (this.ParentWindow.SelectedConfig.ControlSchemes.Count == 0 && CanvasElement.sFocusedTextBox != null)
				{
					WpfUtils.FindVisualParent<CanvasElement>(CanvasElement.sFocusedTextBox as DependencyObject).TxtBox_LostFocus(CanvasElement.sFocusedTextBox, new RoutedEventArgs());
				}
				else
				{
					if (this.ParentWindow.SelectedConfig.ControlSchemes.Count == 0)
					{
						KMManager.AddNewControlSchemeAndSelect(null);
					}
					else if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
					{
						KMManager.AddNewControlSchemeAndSelect(this.ParentWindow.SelectedConfig.SelectedControlScheme);
					}
					this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Add(item);
					List<CanvasElement> source = this.AddCanvasElementsForAction(item, false);
					source.First<CanvasElement>().SetMousePoint(this.mMousePointForNewTap);
					source.First<CanvasElement>().IsRemoveIfEmpty = true;
					source.First<CanvasElement>().ShowTextBox(source.First<CanvasElement>().dictTextElemets.First<KeyValuePair<Positions, Tuple<string, TextBox, TextBlock, List<IMAction>>>>().Value.Item3);
				}
			}
			this.CanvasWindowLeft = double.NaN;
			this.CanvasWindowTop = double.NaN;
		}

		// Token: 0x060008B9 RID: 2233 RVA: 0x000387B4 File Offset: 0x000369B4
		private void CustomWindow_MouseDown(object sender, MouseButtonEventArgs e)
		{
			this.mMousePointForNewTap = Mouse.GetPosition(this.mCanvas);
			this.CanvasWindowLeft = base.Left;
			this.CanvasWindowTop = base.Top;
			try
			{
				base.DragMove();
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x060008BA RID: 2234 RVA: 0x00007895 File Offset: 0x00005A95
		private void CustomWindow_LocationChanged(object sender, EventArgs e)
		{
			if (!this.IsInOverlayMode)
			{
				this.ParentWindow.Top = base.Top;
				this.ParentWindow.Left = base.Left;
			}
		}

		// Token: 0x060008BB RID: 2235 RVA: 0x00038808 File Offset: 0x00036A08
		private void CustomWindow_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			foreach (object obj in this.mCanvas.Children)
			{
				(obj as CanvasElement).SetElementLayout(false);
			}
		}

		// Token: 0x060008BC RID: 2236 RVA: 0x00038864 File Offset: 0x00036A64
		private void MCanvas_PreviewMouseMove(object sender, MouseEventArgs e)
		{
			ToolTip toolTip = new ToolTip();
			if (KMManager.sIsInScriptEditingMode)
			{
				Point correctCoordinateLocationForAndroid = this.GetCorrectCoordinateLocationForAndroid(Mouse.GetPosition(this.mCanvas));
				if (toolTip.IsOpen)
				{
					toolTip.IsOpen = false;
				}
				toolTip.Content = string.Format(" X: {0} Y: {1}", correctCoordinateLocationForAndroid.X, correctCoordinateLocationForAndroid.Y);
				toolTip.StaysOpen = true;
				toolTip.Placement = PlacementMode.Mouse;
				toolTip.IsOpen = true;
			}
		}

		// Token: 0x060008BD RID: 2237 RVA: 0x000388DC File Offset: 0x00036ADC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/keymapcanvaswindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060008BE RID: 2238 RVA: 0x0003890C File Offset: 0x00036B0C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((KeymapCanvasWindow)target).Closing += this.KeymapCanvasWindow_Closing;
				((KeymapCanvasWindow)target).Closed += this.CustomWindow_Closed;
				((KeymapCanvasWindow)target).Loaded += this.Window_Loaded;
				((KeymapCanvasWindow)target).LocationChanged += this.CustomWindow_LocationChanged;
				((KeymapCanvasWindow)target).MouseLeftButtonDown += this.CustomWindow_MouseDown;
				((KeymapCanvasWindow)target).SizeChanged += this.CustomWindow_SizeChanged;
				return;
			case 2:
				((Grid)target).MouseLeftButtonDown += this.Canvas_MouseDown;
				return;
			case 3:
				this.mCanvas = (Canvas)target;
				this.mCanvas.MouseEnter += this.Canvas_MouseEnter;
				this.mCanvas.PreviewMouseUp += this.Canvas_MouseUp;
				this.mCanvas.MouseDown += this.CustomWindow_MouseDown;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000629 RID: 1577
		private int mCurrentTapElementDisplayRow;

		// Token: 0x0400062A RID: 1578
		private int mCurrentTapElementDisplayCol;

		// Token: 0x0400062B RID: 1579
		private int mTapYMargin = 5;

		// Token: 0x0400062C RID: 1580
		private int mTapXMargin = 5;

		// Token: 0x0400062D RID: 1581
		private int mMaxElementPerRow = 10;

		// Token: 0x0400062E RID: 1582
		internal bool mIsShowWindow = true;

		// Token: 0x0400062F RID: 1583
		private bool isNewElementAdded;

		// Token: 0x04000630 RID: 1584
		private int mSidebarWidth = 260;

		// Token: 0x04000631 RID: 1585
		private MainWindow ParentWindow;

		// Token: 0x04000632 RID: 1586
		internal AdvancedGameControlWindow SidebarWindow;

		// Token: 0x04000633 RID: 1587
		private Point startPoint = new Point(-1.0, -1.0);

		// Token: 0x04000634 RID: 1588
		private int zIndex;

		// Token: 0x04000635 RID: 1589
		internal CanvasElement mCanvasElement;

		// Token: 0x04000636 RID: 1590
		internal double mParentWindowHeight;

		// Token: 0x04000637 RID: 1591
		internal double mParentWindowWidth;

		// Token: 0x04000638 RID: 1592
		internal double mParentWindowTop;

		// Token: 0x04000639 RID: 1593
		internal double mParentWindowLeft;

		// Token: 0x0400063A RID: 1594
		internal Dictionary<IMAction, CanvasElement> dictCanvasElement = new Dictionary<IMAction, CanvasElement>();

		// Token: 0x0400063B RID: 1595
		internal static bool IsDirty;

		// Token: 0x0400063C RID: 1596
		internal static bool sWasMaximized;

		// Token: 0x0400063D RID: 1597
		private bool mIsInOverlayMode;

		// Token: 0x0400063E RID: 1598
		internal bool mIsClosing;

		// Token: 0x0400063F RID: 1599
		internal double SidebarWindowLeft = -1.0;

		// Token: 0x04000640 RID: 1600
		internal double SidebarWindowTop = -1.0;

		// Token: 0x04000641 RID: 1601
		internal double CanvasWindowLeft = -1.0;

		// Token: 0x04000642 RID: 1602
		internal double CanvasWindowTop = -1.0;

		// Token: 0x04000643 RID: 1603
		private Point mMousePointForNewTap;

		// Token: 0x04000644 RID: 1604
		private IntPtr Handle;

		// Token: 0x04000645 RID: 1605
		internal Canvas mCanvas;

		// Token: 0x04000646 RID: 1606
		private bool _contentLoaded;
	}
}
