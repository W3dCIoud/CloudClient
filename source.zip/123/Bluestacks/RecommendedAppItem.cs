﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000A3 RID: 163
	public class RecommendedAppItem : UserControl, IComponentConnector
	{
		// Token: 0x06000700 RID: 1792 RVA: 0x00006907 File Offset: 0x00004B07
		public RecommendedAppItem()
		{
			this.InitializeComponent();
		}

		// Token: 0x17000155 RID: 341
		// (get) Token: 0x06000701 RID: 1793 RVA: 0x00006915 File Offset: 0x00004B15
		// (set) Token: 0x06000702 RID: 1794 RVA: 0x0000691D File Offset: 0x00004B1D
		internal SearchRecommendation SearchRecomendation { get; set; }

		// Token: 0x17000156 RID: 342
		// (get) Token: 0x06000703 RID: 1795 RVA: 0x00006926 File Offset: 0x00004B26
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x06000704 RID: 1796 RVA: 0x0002BA94 File Offset: 0x00029C94
		internal void Populate(MainWindow parentWindow, SearchRecommendation recom)
		{
			this.mMainWindow = parentWindow;
			this.recomIcon.IsFullImagePath = true;
			this.recomIcon.ImageName = recom.ImagePath;
			this.installButton.ButtonColor = ButtonColors.Green;
			this.installButton.Content = (this.ParentWindow.mAppHandler.IsAppInstalled(recom.ExtraPayload["click_action_packagename"]) ? LocaleStrings.GetLocalizedString("STRING_PLAY", false) : LocaleStrings.GetLocalizedString("STRING_INSTALL", false));
			this.appNameTextBlock.Text = recom.ExtraPayload["click_action_title"];
			this.SearchRecomendation = recom;
		}

		// Token: 0x06000705 RID: 1797 RVA: 0x0002BB38 File Offset: 0x00029D38
		private void Recommendation_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				ClientStats.SendFrontendClickStats("search_suggestion_click", "", (this.SearchRecomendation.ExtraPayload["click_generic_action"] == "InstallCDN") ? "cdn" : "gplay", this.SearchRecomendation.ExtraPayload["click_action_packagename"], this.ParentWindow.mAppHandler.IsAppInstalled(this.SearchRecomendation.ExtraPayload["click_action_packagename"]) ? "true" : "false", null, null, null);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while sending stats to cloud for search_suggestion_click " + ex.ToString());
			}
			this.ParentWindow.Utils.HandleGenericActionFromDictionary(this.SearchRecomendation.ExtraPayload, "search_suggestion", "");
		}

		// Token: 0x06000706 RID: 1798 RVA: 0x00006947 File Offset: 0x00004B47
		private void UserControl_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "SearchGridBackgroundHoverColor");
		}

		// Token: 0x06000707 RID: 1799 RVA: 0x00005CB6 File Offset: 0x00003EB6
		private void UserControl_MouseLeave(object sender, MouseEventArgs e)
		{
			base.Background = Brushes.Transparent;
		}

		// Token: 0x06000708 RID: 1800 RVA: 0x0002BC1C File Offset: 0x00029E1C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/recommendedappitem.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000709 RID: 1801 RVA: 0x0002BC4C File Offset: 0x00029E4C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((RecommendedAppItem)target).MouseUp += new MouseButtonEventHandler(this.Recommendation_Click);
				((RecommendedAppItem)target).MouseEnter += this.UserControl_MouseEnter;
				((RecommendedAppItem)target).MouseLeave += this.UserControl_MouseLeave;
				return;
			case 2:
				this.recomIcon = (CustomPictureBox)target;
				return;
			case 3:
				this.appNameTextBlock = (TextBlock)target;
				return;
			case 4:
				this.installButton = (CustomButton)target;
				this.installButton.Click += this.Recommendation_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040004BD RID: 1213
		private MainWindow mMainWindow;

		// Token: 0x040004BE RID: 1214
		internal CustomPictureBox recomIcon;

		// Token: 0x040004BF RID: 1215
		internal TextBlock appNameTextBlock;

		// Token: 0x040004C0 RID: 1216
		internal CustomButton installButton;

		// Token: 0x040004C1 RID: 1217
		private bool _contentLoaded;
	}
}
