﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000099 RID: 153
	public class PikaNotificationControl : UserControl, IComponentConnector
	{
		// Token: 0x06000698 RID: 1688 RVA: 0x00006535 File Offset: 0x00004735
		public PikaNotificationControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000699 RID: 1689 RVA: 0x00029B4C File Offset: 0x00027D4C
		private void pikanotificationcontrol_MouseUp(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow != null && this.ParentWindow.mGuestBootCompleted)
			{
				this.ParentWindow.Utils.HandleGenericActionFromDictionary(this.mNotificationItem.ExtraPayload, "notification_ribbon", this.mNotificationItem.NotificationMenuImageName);
				ClientStats.SendMiscellaneousStatsAsync("RibbonClicked", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, this.mNotificationItem.Id, this.mNotificationItem.Title, JsonConvert.SerializeObject(this.mNotificationItem.ExtraPayload), null, null, null);
				GenericNotificationManager instance = GenericNotificationManager.Instance;
				List<string> list = new List<string>();
				list.Add(this.mNotificationItem.Id);
				instance.MarkNotification(list, delegate(GenericNotificationItem x)
				{
					x.IsRead = true;
				});
				IEnumerable<NotificationDrawerItem> source = from _ in (this.ParentWindow.mTopBar.mNotificationDrawerControl.mNotificationScroll.Content as StackPanel).Children.OfType<NotificationDrawerItem>()
				where _.Id == this.mNotificationItem.Id
				select _;
				if (source.Count<NotificationDrawerItem>() > 0)
				{
					source.First<NotificationDrawerItem>().ChangeToReadBackground();
				}
				this.ParentWindow.mTopBar.RefreshNotificationCentreButton();
				this.CloseClicked(sender, e);
			}
		}

		// Token: 0x0600069A RID: 1690 RVA: 0x00029C94 File Offset: 0x00027E94
		private void ApplyHoverColors(bool hover)
		{
			if (hover)
			{
				if (string.IsNullOrEmpty(this.mNotificationItem.NotificationDesignItem.HoverBorderColor))
				{
					this.mNotificationItem.NotificationDesignItem.HoverBorderColor = this.mNotificationItem.NotificationDesignItem.BorderColor;
				}
				this.notificationBorder.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(this.mNotificationItem.NotificationDesignItem.HoverBorderColor));
				if (string.IsNullOrEmpty(this.mNotificationItem.NotificationDesignItem.HoverRibboncolor))
				{
					this.mNotificationItem.NotificationDesignItem.HoverRibboncolor = this.mNotificationItem.NotificationDesignItem.Ribboncolor;
				}
				this.ribbonStroke.Stroke = new SolidColorBrush((Color)ColorConverter.ConvertFromString(this.mNotificationItem.NotificationDesignItem.HoverBorderColor));
				this.ribbonBack.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString(this.mNotificationItem.NotificationDesignItem.HoverRibboncolor));
				if (this.mNotificationItem.NotificationDesignItem.HoverBackGroundGradient.Count == 0)
				{
					this.mNotificationItem.NotificationDesignItem.HoverBackGroundGradient = this.mNotificationItem.NotificationDesignItem.BackgroundGradient;
				}
				this.backgroundPanel.Background = new LinearGradientBrush(new GradientStopCollection(from _ in this.mNotificationItem.NotificationDesignItem.HoverBackGroundGradient
				select new GradientStop((Color)ColorConverter.ConvertFromString(_.Key), _.Value)));
				return;
			}
			this.notificationBorder.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(this.mNotificationItem.NotificationDesignItem.BorderColor));
			this.ribbonStroke.Stroke = new SolidColorBrush((Color)ColorConverter.ConvertFromString(this.mNotificationItem.NotificationDesignItem.BorderColor));
			this.ribbonBack.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString(this.mNotificationItem.NotificationDesignItem.Ribboncolor));
			this.backgroundPanel.Background = new LinearGradientBrush(new GradientStopCollection(from _ in this.mNotificationItem.NotificationDesignItem.BackgroundGradient
			select new GradientStop((Color)ColorConverter.ConvertFromString(_.Key), _.Value)));
		}

		// Token: 0x0600069B RID: 1691 RVA: 0x00029EDC File Offset: 0x000280DC
		internal void Init(GenericNotificationItem notifItem)
		{
			this.mNotificationItem = notifItem;
			this.titleText.Text = notifItem.Title;
			this.titleText.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(notifItem.NotificationDesignItem.TitleForeGroundColor));
			this.messageText.Text = notifItem.Message;
			this.messageText.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(notifItem.NotificationDesignItem.MessageForeGroundColor));
			this.notificationBorder.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(notifItem.NotificationDesignItem.BorderColor));
			this.ribbonStroke.Stroke = new SolidColorBrush((Color)ColorConverter.ConvertFromString(notifItem.NotificationDesignItem.BorderColor));
			if (notifItem.NotificationDesignItem.BackgroundGradient.Count == 0)
			{
				notifItem.NotificationDesignItem.BackgroundGradient.Add(new SerializableKeyValuePair<string, double>("#FFF350", 0.0));
				notifItem.NotificationDesignItem.BackgroundGradient.Add(new SerializableKeyValuePair<string, double>("#FFF8AF", 0.3));
				notifItem.NotificationDesignItem.BackgroundGradient.Add(new SerializableKeyValuePair<string, double>("#FFE940", 0.6));
				notifItem.NotificationDesignItem.BackgroundGradient.Add(new SerializableKeyValuePair<string, double>("#FCE74E", 0.8));
				notifItem.NotificationDesignItem.BackgroundGradient.Add(new SerializableKeyValuePair<string, double>("#FDF09C", 0.9));
				notifItem.NotificationDesignItem.BackgroundGradient.Add(new SerializableKeyValuePair<string, double>("#FFE227", 1.0));
			}
			this.backgroundPanel.Background = new LinearGradientBrush(new GradientStopCollection(from _ in notifItem.NotificationDesignItem.BackgroundGradient
			select new GradientStop((Color)ColorConverter.ConvertFromString(_.Key), _.Value)));
			if (string.IsNullOrEmpty(notifItem.NotificationDesignItem.Ribboncolor))
			{
				this.ribbonBack.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFF350"));
			}
			else
			{
				this.ribbonBack.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString(notifItem.NotificationDesignItem.Ribboncolor));
			}
			if (string.IsNullOrEmpty(notifItem.NotificationDesignItem.LeftGifName))
			{
				this.pikaGif.Visibility = Visibility.Collapsed;
			}
			else
			{
				this.pikaGif.Visibility = Visibility.Visible;
				this.pikaGif.ImageName = notifItem.NotificationDesignItem.LeftGifName;
			}
			Canvas.SetLeft(this, 0.0);
		}

		// Token: 0x0600069C RID: 1692 RVA: 0x00006543 File Offset: 0x00004743
		private void PikaNotificationControl_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mCloseBtn.Visibility = Visibility.Hidden;
			this.ApplyHoverColors(false);
		}

		// Token: 0x0600069D RID: 1693 RVA: 0x00006558 File Offset: 0x00004758
		private void PikaNotificationControl_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mCloseBtn.Visibility = Visibility.Visible;
			this.ApplyHoverColors(true);
		}

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x0600069E RID: 1694 RVA: 0x0002A17C File Offset: 0x0002837C
		// (remove) Token: 0x0600069F RID: 1695 RVA: 0x0002A1B4 File Offset: 0x000283B4
		public event EventHandler CloseClicked;

		// Token: 0x060006A0 RID: 1696 RVA: 0x0000656D File Offset: 0x0000476D
		private void CloseBtn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Pika notification close button clicked");
			this.CloseClicked(sender, e);
			e.Handled = true;
		}

		// Token: 0x060006A1 RID: 1697 RVA: 0x0002A1EC File Offset: 0x000283EC
		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			try
			{
				if (File.Exists(System.IO.Path.Combine(RegistryStrings.PromotionDirectory, this.pikaGif.ImageName)))
				{
					ImageSource value = new BitmapImage(new Uri(System.IO.Path.Combine(RegistryStrings.PromotionDirectory, this.pikaGif.ImageName)));
					ImageBehavior.SetAnimatedSource(this.pikaGif, value);
				}
				else if (File.Exists(System.IO.Path.Combine(CustomPictureBox.AssetsDir, this.pikaGif.ImageName)))
				{
					ImageSource value2 = new BitmapImage(new Uri(System.IO.Path.Combine(CustomPictureBox.AssetsDir, this.pikaGif.ImageName)));
					ImageBehavior.SetAnimatedSource(this.pikaGif, value2);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while loading pika notification. " + ex.ToString());
			}
		}

		// Token: 0x060006A2 RID: 1698 RVA: 0x0002A2B8 File Offset: 0x000284B8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/pikanotificationcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060006A3 RID: 1699 RVA: 0x0002A2E8 File Offset: 0x000284E8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((PikaNotificationControl)target).AddHandler(Mouse.MouseUpEvent, new MouseButtonEventHandler(this.pikanotificationcontrol_MouseUp));
				((PikaNotificationControl)target).MouseEnter += this.PikaNotificationControl_MouseEnter;
				((PikaNotificationControl)target).MouseLeave += this.PikaNotificationControl_MouseLeave;
				((PikaNotificationControl)target).Loaded += this.UserControl_Loaded;
				return;
			case 2:
				this.mNotificationGrid = (Grid)target;
				return;
			case 3:
				this.ribbonBack = (System.Windows.Shapes.Path)target;
				return;
			case 4:
				this.ribbonStroke = (System.Windows.Shapes.Path)target;
				return;
			case 5:
				this.backgroundPanel = (StackPanel)target;
				return;
			case 6:
				this.pikaGif = (CustomPictureBox)target;
				return;
			case 7:
				this.titleText = (TextBlock)target;
				return;
			case 8:
				this.messageText = (TextBlock)target;
				return;
			case 9:
				this.notificationBorder = (Border)target;
				return;
			case 10:
				this.mCloseBtn = (CustomPictureBox)target;
				this.mCloseBtn.MouseLeftButtonUp += this.CloseBtn_MouseLeftButtonUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000462 RID: 1122
		internal MainWindow ParentWindow;

		// Token: 0x04000463 RID: 1123
		private GenericNotificationItem mNotificationItem;

		// Token: 0x04000465 RID: 1125
		internal Grid mNotificationGrid;

		// Token: 0x04000466 RID: 1126
		internal System.Windows.Shapes.Path ribbonBack;

		// Token: 0x04000467 RID: 1127
		internal System.Windows.Shapes.Path ribbonStroke;

		// Token: 0x04000468 RID: 1128
		internal StackPanel backgroundPanel;

		// Token: 0x04000469 RID: 1129
		internal CustomPictureBox pikaGif;

		// Token: 0x0400046A RID: 1130
		internal TextBlock titleText;

		// Token: 0x0400046B RID: 1131
		internal TextBlock messageText;

		// Token: 0x0400046C RID: 1132
		internal Border notificationBorder;

		// Token: 0x0400046D RID: 1133
		internal CustomPictureBox mCloseBtn;

		// Token: 0x0400046E RID: 1134
		private bool _contentLoaded;
	}
}
