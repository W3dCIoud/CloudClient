﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Reflection;
using BlueStacks.Common;

// Token: 0x02000005 RID: 5
[Serializable]
public abstract class IMAction
{
	// Token: 0x06000027 RID: 39 RVA: 0x00010CD8 File Offset: 0x0000EED8
	public IMAction()
	{
		this.GetPropertyInfo("Type");
		if (this.ParentAction == null)
		{
			this.ParentAction = this;
		}
	}

	// Token: 0x17000012 RID: 18
	// (get) Token: 0x06000028 RID: 40 RVA: 0x000021DD File Offset: 0x000003DD
	// (set) Token: 0x06000029 RID: 41 RVA: 0x000021E5 File Offset: 0x000003E5
	public KeyActionType Type { get; set; }

	// Token: 0x17000013 RID: 19
	// (get) Token: 0x0600002A RID: 42 RVA: 0x000021EE File Offset: 0x000003EE
	public Dictionary<string, string> Guidance { get; } = new Dictionary<string, string>();

	// Token: 0x17000014 RID: 20
	// (get) Token: 0x0600002B RID: 43 RVA: 0x000021F6 File Offset: 0x000003F6
	// (set) Token: 0x0600002C RID: 44 RVA: 0x00002222 File Offset: 0x00000422
	public string GuidanceCategory
	{
		get
		{
			if (!this.IsChildAction)
			{
				return this.GetCurrentGuidanceCategory();
			}
			if (this.ParentAction != this)
			{
				return this.ParentAction.GuidanceCategory;
			}
			return this.GetCurrentGuidanceCategory();
		}
		set
		{
			this.mGuidanceCategory = ((value == null || string.IsNullOrEmpty(value.Trim())) ? "MISC" : value.Trim());
		}
	}

	// Token: 0x0600002D RID: 45 RVA: 0x00002247 File Offset: 0x00000447
	private string GetCurrentGuidanceCategory()
	{
		if (string.IsNullOrEmpty(this.mGuidanceCategory))
		{
			this.mGuidanceCategory = "MISC";
		}
		return this.mGuidanceCategory;
	}

	// Token: 0x17000015 RID: 21
	// (get) Token: 0x0600002E RID: 46 RVA: 0x00002267 File Offset: 0x00000467
	// (set) Token: 0x0600002F RID: 47 RVA: 0x0000226F File Offset: 0x0000046F
	public string EnableCondition { get; set; } = string.Empty;

	// Token: 0x17000016 RID: 22
	// (get) Token: 0x06000030 RID: 48 RVA: 0x00002278 File Offset: 0x00000478
	// (set) Token: 0x06000031 RID: 49 RVA: 0x00002280 File Offset: 0x00000480
	public string StartCondition { get; set; }

	// Token: 0x17000017 RID: 23
	// (get) Token: 0x06000032 RID: 50 RVA: 0x00002289 File Offset: 0x00000489
	// (set) Token: 0x06000033 RID: 51 RVA: 0x00002291 File Offset: 0x00000491
	public string Note { get; set; }

	// Token: 0x17000018 RID: 24
	// (get) Token: 0x06000034 RID: 52 RVA: 0x0000229A File Offset: 0x0000049A
	// (set) Token: 0x06000035 RID: 53 RVA: 0x000022A2 File Offset: 0x000004A2
	public string Comment { get; set; }

	// Token: 0x17000019 RID: 25
	// (get) Token: 0x06000036 RID: 54 RVA: 0x00010D28 File Offset: 0x0000EF28
	// (set) Token: 0x06000037 RID: 55 RVA: 0x000022AB File Offset: 0x000004AB
	internal double PositionX
	{
		get
		{
			double result;
			if (!double.TryParse(this[IMAction.sPositionXPropertyName[this.Type]].ToString(), out result))
			{
				result = -1.0;
			}
			return result;
		}
		set
		{
			this[IMAction.sPositionXPropertyName[this.Type]] = value;
		}
	}

	// Token: 0x1700001A RID: 26
	// (get) Token: 0x06000038 RID: 56 RVA: 0x00010D64 File Offset: 0x0000EF64
	// (set) Token: 0x06000039 RID: 57 RVA: 0x000022C9 File Offset: 0x000004C9
	internal double PositionY
	{
		get
		{
			double result;
			if (!double.TryParse(this[IMAction.sPositionYPropertyName[this.Type]].ToString(), out result))
			{
				result = -1.0;
			}
			return result;
		}
		set
		{
			this[IMAction.sPositionYPropertyName[this.Type]] = value;
		}
	}

	// Token: 0x1700001B RID: 27
	// (get) Token: 0x0600003A RID: 58 RVA: 0x00010DA0 File Offset: 0x0000EFA0
	// (set) Token: 0x0600003B RID: 59 RVA: 0x000022E7 File Offset: 0x000004E7
	internal double RadiusProperty
	{
		get
		{
			double result;
			if (!double.TryParse(this[IMAction.sRadiusPropertyName[this.Type]].ToString(), out result))
			{
				result = -1.0;
			}
			return result;
		}
		set
		{
			this[IMAction.sRadiusPropertyName[this.Type]] = value;
		}
	}

	// Token: 0x1700001C RID: 28
	// (get) Token: 0x0600003C RID: 60 RVA: 0x00010DDC File Offset: 0x0000EFDC
	// (set) Token: 0x0600003D RID: 61 RVA: 0x00002305 File Offset: 0x00000505
	public bool IsVisibleInOverlay
	{
		get
		{
			bool result;
			if (!bool.TryParse(this["ShowOnOverlay"].ToString(), out result))
			{
				result = false;
			}
			return result;
		}
		set
		{
			this["ShowOnOverlay"] = value;
		}
	}

	// Token: 0x1700001D RID: 29
	public object this[string propertyName]
	{
		get
		{
			object obj = null;
			if (this.GetPropertyInfo(propertyName) != null)
			{
				obj = this.GetPropertyInfo(propertyName).GetValue(this, null);
			}
			return obj ?? string.Empty;
		}
		set
		{
			try
			{
				PropertyInfo propertyInfo = this.GetPropertyInfo(propertyName);
				if (propertyInfo != null)
				{
					propertyInfo.SetValue(this, Convert.ChangeType(value, this.GetPropertyInfo(propertyName).PropertyType, CultureInfo.InvariantCulture), null);
				}
			}
			catch (Exception ex)
			{
				Logger.Error(Constants.ImapLocaleStringsConstant + " error parsing variable set " + ex.ToString());
			}
		}
	}

	// Token: 0x06000040 RID: 64 RVA: 0x00010EA4 File Offset: 0x0000F0A4
	private PropertyInfo GetPropertyInfo(string propertyName)
	{
		PropertyInfo result = null;
		KeyActionType keyActionType = EnumHelper.Parse<KeyActionType>(base.GetType().Name, KeyActionType.Alias);
		this.Type = keyActionType;
		if (!IMAction.DictPropertyInfo.ContainsKey(keyActionType))
		{
			IMAction.DictPropertyInfo[keyActionType] = new Dictionary<string, PropertyInfo>();
			IMAction.DictPopUpUIElements[keyActionType] = new Dictionary<string, PropertyInfo>();
			IMAction.sDictDevModeUIElements[keyActionType] = new Dictionary<string, PropertyInfo>();
			IMAction.sPositionXPropertyName[keyActionType] = string.Empty;
			IMAction.sPositionYPropertyName[keyActionType] = string.Empty;
			IMAction.sRadiusPropertyName[keyActionType] = string.Empty;
			foreach (PropertyInfo propertyInfo in base.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
			{
				IMAction.DictPropertyInfo[keyActionType].Add(propertyInfo.Name, propertyInfo);
				object[] customAttributes = propertyInfo.GetCustomAttributes(typeof(DescriptionAttribute), true);
				if (customAttributes.Length != 0)
				{
					DescriptionAttribute descriptionAttribute = customAttributes[0] as DescriptionAttribute;
					if (descriptionAttribute.Description.Contains("IMAP_CanvasElementY"))
					{
						IMAction.sPositionXPropertyName[keyActionType] = propertyInfo.Name;
					}
					if (descriptionAttribute.Description.Contains("IMAP_CanvasElementX"))
					{
						IMAction.sPositionYPropertyName[keyActionType] = propertyInfo.Name;
					}
					if (descriptionAttribute.Description.Contains("IMAP_CanvasElementRadius"))
					{
						IMAction.sRadiusPropertyName[keyActionType] = propertyInfo.Name;
					}
					if (descriptionAttribute.Description.Contains("IMAP_PopupUIElement"))
					{
						IMAction.DictPopUpUIElements[keyActionType].Add(propertyInfo.Name, propertyInfo);
					}
					if (descriptionAttribute.Description.Contains("IMAP_DeveloperModeUIElemnt"))
					{
						IMAction.sDictDevModeUIElements[keyActionType].Add(propertyInfo.Name, propertyInfo);
					}
				}
			}
		}
		if (!string.IsNullOrEmpty(propertyName) && IMAction.DictPropertyInfo[keyActionType].ContainsKey(propertyName))
		{
			result = IMAction.DictPropertyInfo[keyActionType][propertyName];
		}
		return result;
	}

	// Token: 0x06000041 RID: 65 RVA: 0x00011090 File Offset: 0x0000F290
	internal List<Tuple<string, IMAction>> GetListGuidanceElements()
	{
		List<string> list = new List<string>();
		List<Tuple<string, IMAction>> list2 = new List<Tuple<string, IMAction>>();
		foreach (KeyValuePair<string, string> keyValuePair in this.Guidance)
		{
			if (keyValuePair.Key.StartsWith("Key", StringComparison.InvariantCulture))
			{
				list2.Add(new Tuple<string, IMAction>(keyValuePair.Key, this));
				list.Add(keyValuePair.Key);
			}
		}
		foreach (KeyValuePair<string, PropertyInfo> keyValuePair2 in IMAction.DictPropertyInfo[this.Type])
		{
			if (!list.Contains(keyValuePair2.Key) && (keyValuePair2.Key.StartsWith("Key", StringComparison.InvariantCulture) || keyValuePair2.Key.StartsWith("Sensitivity", StringComparison.InvariantCulture) || keyValuePair2.Key.StartsWith("MouseAcceleration", StringComparison.InvariantCulture)))
			{
				list2.Add(new Tuple<string, IMAction>(keyValuePair2.Key, this));
			}
		}
		return list2;
	}

	// Token: 0x04000011 RID: 17
	internal static Dictionary<KeyActionType, Dictionary<string, PropertyInfo>> sDictDevModeUIElements = new Dictionary<KeyActionType, Dictionary<string, PropertyInfo>>();

	// Token: 0x04000012 RID: 18
	internal static Dictionary<KeyActionType, Dictionary<string, PropertyInfo>> DictPropertyInfo = new Dictionary<KeyActionType, Dictionary<string, PropertyInfo>>();

	// Token: 0x04000013 RID: 19
	internal static Dictionary<KeyActionType, Dictionary<string, PropertyInfo>> DictPopUpUIElements = new Dictionary<KeyActionType, Dictionary<string, PropertyInfo>>();

	// Token: 0x04000016 RID: 22
	private string mGuidanceCategory = "MISC";

	// Token: 0x0400001B RID: 27
	internal Direction Direction;

	// Token: 0x0400001C RID: 28
	internal IMAction ParentAction;

	// Token: 0x0400001D RID: 29
	private static Dictionary<KeyActionType, string> sPositionXPropertyName = new Dictionary<KeyActionType, string>();

	// Token: 0x0400001E RID: 30
	private static Dictionary<KeyActionType, string> sPositionYPropertyName = new Dictionary<KeyActionType, string>();

	// Token: 0x0400001F RID: 31
	internal static Dictionary<KeyActionType, string> sRadiusPropertyName = new Dictionary<KeyActionType, string>();

	// Token: 0x04000020 RID: 32
	internal bool IsChildAction;
}
