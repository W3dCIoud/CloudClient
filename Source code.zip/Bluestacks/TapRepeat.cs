﻿using System;
using System.ComponentModel;

// Token: 0x02000017 RID: 23
[Description("Independent")]
[Serializable]
public class TapRepeat : IMAction
{
	// Token: 0x170000AC RID: 172
	// (get) Token: 0x0600016C RID: 364 RVA: 0x00002F4C File Offset: 0x0000114C
	// (set) Token: 0x0600016D RID: 365 RVA: 0x00002F54 File Offset: 0x00001154
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X
	{
		get
		{
			return this.mX;
		}
		set
		{
			this.mX = value;
		}
	}

	// Token: 0x170000AD RID: 173
	// (get) Token: 0x0600016E RID: 366 RVA: 0x00002F5D File Offset: 0x0000115D
	// (set) Token: 0x0600016F RID: 367 RVA: 0x00002F65 File Offset: 0x00001165
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y
	{
		get
		{
			return this.mY;
		}
		set
		{
			this.mY = value;
		}
	}

	// Token: 0x170000AE RID: 174
	// (get) Token: 0x06000170 RID: 368 RVA: 0x00002F6E File Offset: 0x0000116E
	// (set) Token: 0x06000171 RID: 369 RVA: 0x00002F76 File Offset: 0x00001176
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key
	{
		get
		{
			return this.mKey;
		}
		set
		{
			this.mKey = value;
		}
	}

	// Token: 0x170000AF RID: 175
	// (get) Token: 0x06000172 RID: 370 RVA: 0x00002F7F File Offset: 0x0000117F
	// (set) Token: 0x06000173 RID: 371 RVA: 0x00002F87 File Offset: 0x00001187
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key_alt1
	{
		get
		{
			return this.mKey_alt1;
		}
		set
		{
			this.mKey_alt1 = value;
		}
	}

	// Token: 0x170000B0 RID: 176
	// (get) Token: 0x06000174 RID: 372 RVA: 0x00002F90 File Offset: 0x00001190
	// (set) Token: 0x06000175 RID: 373 RVA: 0x00002F98 File Offset: 0x00001198
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int Count
	{
		get
		{
			return this.mCount;
		}
		set
		{
			this.mCount = value;
		}
	}

	// Token: 0x170000B1 RID: 177
	// (get) Token: 0x06000176 RID: 374 RVA: 0x00002FA1 File Offset: 0x000011A1
	// (set) Token: 0x06000177 RID: 375 RVA: 0x00002FA9 File Offset: 0x000011A9
	public int Delay
	{
		get
		{
			return this.mDelay;
		}
		set
		{
			this.mDelay = 1000 / (2 * this.Count);
		}
	}

	// Token: 0x170000B2 RID: 178
	// (get) Token: 0x06000178 RID: 376 RVA: 0x00002FBF File Offset: 0x000011BF
	// (set) Token: 0x06000179 RID: 377 RVA: 0x00002FC7 File Offset: 0x000011C7
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool ShowOnOverlay
	{
		get
		{
			return this.mShowOnOverlay;
		}
		set
		{
			this.mShowOnOverlay = value;
		}
	}

	// Token: 0x170000B3 RID: 179
	// (get) Token: 0x0600017A RID: 378 RVA: 0x00002FD0 File Offset: 0x000011D0
	// (set) Token: 0x0600017B RID: 379 RVA: 0x00002FD8 File Offset: 0x000011D8
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool RepeatUntilKeyUp
	{
		get
		{
			return this.mRepeatUntilKeyUp;
		}
		set
		{
			this.mRepeatUntilKeyUp = value;
		}
	}

	// Token: 0x040000A5 RID: 165
	private double mX = -1.0;

	// Token: 0x040000A6 RID: 166
	private double mY = -1.0;

	// Token: 0x040000A7 RID: 167
	private string mKey;

	// Token: 0x040000A8 RID: 168
	private string mKey_alt1;

	// Token: 0x040000A9 RID: 169
	private int mCount = 5;

	// Token: 0x040000AA RID: 170
	private int mDelay = 100;

	// Token: 0x040000AB RID: 171
	internal bool mShowOnOverlay = true;

	// Token: 0x040000AC RID: 172
	private bool mRepeatUntilKeyUp = true;
}
