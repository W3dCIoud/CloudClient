﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

// Token: 0x02000012 RID: 18
[Description("Independent")]
[Serializable]
public class Script : IMAction
{
	// Token: 0x17000095 RID: 149
	// (get) Token: 0x0600013B RID: 315 RVA: 0x00002CCD File Offset: 0x00000ECD
	// (set) Token: 0x0600013C RID: 316 RVA: 0x00002CD5 File Offset: 0x00000ED5
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X
	{
		get
		{
			return this.mX;
		}
		set
		{
			this.mX = value;
		}
	}

	// Token: 0x17000096 RID: 150
	// (get) Token: 0x0600013D RID: 317 RVA: 0x00002CDE File Offset: 0x00000EDE
	// (set) Token: 0x0600013E RID: 318 RVA: 0x00002CE6 File Offset: 0x00000EE6
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y
	{
		get
		{
			return this.mY;
		}
		set
		{
			this.mY = value;
		}
	}

	// Token: 0x17000097 RID: 151
	// (get) Token: 0x0600013F RID: 319 RVA: 0x00002CEF File Offset: 0x00000EEF
	// (set) Token: 0x06000140 RID: 320 RVA: 0x00002CF7 File Offset: 0x00000EF7
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key
	{
		get
		{
			return this.mKey;
		}
		set
		{
			this.mKey = value;
		}
	}

	// Token: 0x17000098 RID: 152
	// (get) Token: 0x06000141 RID: 321 RVA: 0x00002D00 File Offset: 0x00000F00
	// (set) Token: 0x06000142 RID: 322 RVA: 0x00002D08 File Offset: 0x00000F08
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key_alt1
	{
		get
		{
			return this.mKey_1;
		}
		set
		{
			this.mKey_1 = value;
		}
	}

	// Token: 0x17000099 RID: 153
	// (get) Token: 0x06000143 RID: 323 RVA: 0x00002D11 File Offset: 0x00000F11
	// (set) Token: 0x06000144 RID: 324 RVA: 0x00002D19 File Offset: 0x00000F19
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool ShowOnOverlay
	{
		get
		{
			return this.mShowOnOverlay;
		}
		set
		{
			this.mShowOnOverlay = value;
		}
	}

	// Token: 0x1700009A RID: 154
	// (get) Token: 0x06000145 RID: 325 RVA: 0x00002D22 File Offset: 0x00000F22
	public List<string> Commands { get; } = new List<string>();

	// Token: 0x04000095 RID: 149
	private double mX = -1.0;

	// Token: 0x04000096 RID: 150
	private double mY = -1.0;

	// Token: 0x04000097 RID: 151
	private string mKey;

	// Token: 0x04000098 RID: 152
	private string mKey_1 = string.Empty;

	// Token: 0x04000099 RID: 153
	internal bool mShowOnOverlay = true;
}
