﻿using System;

// Token: 0x0200000F RID: 15
[Serializable]
public class KeyInput : IMAction
{
	// Token: 0x17000090 RID: 144
	// (get) Token: 0x0600012E RID: 302 RVA: 0x00002C78 File Offset: 0x00000E78
	// (set) Token: 0x0600012F RID: 303 RVA: 0x00002C80 File Offset: 0x00000E80
	public string KeyIn
	{
		get
		{
			return this.mKeyIn;
		}
		set
		{
			this.mKeyIn = value;
		}
	}

	// Token: 0x17000091 RID: 145
	// (get) Token: 0x06000130 RID: 304 RVA: 0x00002C89 File Offset: 0x00000E89
	// (set) Token: 0x06000131 RID: 305 RVA: 0x00002C91 File Offset: 0x00000E91
	public string KeyOut
	{
		get
		{
			return this.mKeyOut;
		}
		set
		{
			this.mKeyOut = value;
		}
	}

	// Token: 0x04000090 RID: 144
	private string mKeyIn;

	// Token: 0x04000091 RID: 145
	private string mKeyOut;
}
