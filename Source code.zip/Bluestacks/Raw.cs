﻿using System;

// Token: 0x02000010 RID: 16
[Serializable]
public class Raw : IMAction
{
	// Token: 0x17000092 RID: 146
	// (get) Token: 0x06000133 RID: 307 RVA: 0x00002C9A File Offset: 0x00000E9A
	// (set) Token: 0x06000134 RID: 308 RVA: 0x00002CA2 File Offset: 0x00000EA2
	public string Key
	{
		get
		{
			return this.mKey;
		}
		set
		{
			this.mKey = value;
		}
	}

	// Token: 0x17000093 RID: 147
	// (get) Token: 0x06000135 RID: 309 RVA: 0x00002CAB File Offset: 0x00000EAB
	// (set) Token: 0x06000136 RID: 310 RVA: 0x00002CB3 File Offset: 0x00000EB3
	public object Sequence
	{
		get
		{
			return this.mSequence;
		}
		set
		{
			this.mSequence = value;
		}
	}

	// Token: 0x04000092 RID: 146
	private string mKey;

	// Token: 0x04000093 RID: 147
	private object mSequence;
}
