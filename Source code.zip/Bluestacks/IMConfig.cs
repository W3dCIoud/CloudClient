﻿using System;
using System.Collections.Generic;
using System.Linq;
using BlueStacks.Common;
using Newtonsoft.Json;

// Token: 0x0200001C RID: 28
[Serializable]
internal class IMConfig
{
	// Token: 0x170000E3 RID: 227
	// (get) Token: 0x060001E1 RID: 481 RVA: 0x00003365 File Offset: 0x00001565
	// (set) Token: 0x060001E2 RID: 482 RVA: 0x0000336D File Offset: 0x0000156D
	public MetaData MetaData { get; set; } = new MetaData();

	// Token: 0x170000E4 RID: 228
	// (get) Token: 0x060001E3 RID: 483 RVA: 0x00003376 File Offset: 0x00001576
	// (set) Token: 0x060001E4 RID: 484 RVA: 0x0000337E File Offset: 0x0000157E
	public List<IMControlScheme> ControlSchemes { get; set; } = new List<IMControlScheme>();

	// Token: 0x170000E5 RID: 229
	// (get) Token: 0x060001E5 RID: 485 RVA: 0x00003387 File Offset: 0x00001587
	// (set) Token: 0x060001E6 RID: 486 RVA: 0x0000338F File Offset: 0x0000158F
	[JsonIgnore]
	public Dictionary<string, IMControlScheme> ControlSchemesDict { get; private set; } = new Dictionary<string, IMControlScheme>();

	// Token: 0x170000E6 RID: 230
	// (get) Token: 0x060001E7 RID: 487 RVA: 0x00003398 File Offset: 0x00001598
	// (set) Token: 0x060001E8 RID: 488 RVA: 0x000033A0 File Offset: 0x000015A0
	public Dictionary<string, Dictionary<string, string>> Strings { get; set; } = new Dictionary<string, Dictionary<string, string>>();

	// Token: 0x170000E7 RID: 231
	// (get) Token: 0x060001E9 RID: 489 RVA: 0x000033A9 File Offset: 0x000015A9
	// (set) Token: 0x060001EA RID: 490 RVA: 0x000033B1 File Offset: 0x000015B1
	[JsonIgnore]
	public IMControlScheme SelectedControlScheme { get; set; } = new IMControlScheme();

	// Token: 0x060001EB RID: 491 RVA: 0x000120CC File Offset: 0x000102CC
	internal string GetUIString(string key)
	{
		string result = key;
		if (this.Strings.ContainsKey(LocaleStrings.Locale) && this.Strings[LocaleStrings.Locale].ContainsKey(key))
		{
			result = this.Strings[LocaleStrings.Locale][key];
		}
		else if (this.Strings.ContainsKey("en-US") && this.Strings["en-US"].ContainsKey(key))
		{
			result = this.Strings["en-US"][key];
		}
		else if (this.Strings.ContainsKey("User-Defined") && this.Strings["User-Defined"].ContainsKey(key))
		{
			result = this.Strings["User-Defined"][key];
		}
		return result;
	}

	// Token: 0x060001EC RID: 492 RVA: 0x000033BA File Offset: 0x000015BA
	internal void AddString(string key)
	{
		if (!this.Strings.ContainsKey("User-Defined"))
		{
			this.Strings.Add("User-Defined", new Dictionary<string, string>());
		}
		this.Strings["User-Defined"][key] = key;
	}

	// Token: 0x060001ED RID: 493 RVA: 0x000121A8 File Offset: 0x000103A8
	public IMConfig DeepCopy()
	{
		IMConfig imconfig = (IMConfig)base.MemberwiseClone();
		MetaData metaData = this.MetaData;
		imconfig.MetaData = ((metaData != null) ? metaData.DeepCopy<MetaData>() : null);
		List<IMControlScheme> controlSchemes = this.ControlSchemes;
		List<IMControlScheme> controlSchemes2;
		if (controlSchemes == null)
		{
			controlSchemes2 = null;
		}
		else
		{
			controlSchemes2 = controlSchemes.ConvertAll<IMControlScheme>(delegate(IMControlScheme cs)
			{
				if (cs == null)
				{
					return null;
				}
				return cs.DeepCopy();
			});
		}
		imconfig.ControlSchemes = controlSchemes2;
		Dictionary<string, IMControlScheme> controlSchemesDict = this.ControlSchemesDict;
		Dictionary<string, IMControlScheme> controlSchemesDict2;
		if (controlSchemesDict == null)
		{
			controlSchemesDict2 = null;
		}
		else
		{
			controlSchemesDict2 = controlSchemesDict.ToDictionary((KeyValuePair<string, IMControlScheme> kvp) => kvp.Key, delegate(KeyValuePair<string, IMControlScheme> kvp)
			{
				IMControlScheme value = kvp.Value;
				if (value == null)
				{
					return null;
				}
				return value.DeepCopy();
			});
		}
		imconfig.ControlSchemesDict = controlSchemesDict2;
		Dictionary<string, Dictionary<string, string>> strings = this.Strings;
		Dictionary<string, Dictionary<string, string>> strings2;
		if (strings == null)
		{
			strings2 = null;
		}
		else
		{
			strings2 = strings.ToDictionary((KeyValuePair<string, Dictionary<string, string>> kvp) => kvp.Key, (KeyValuePair<string, Dictionary<string, string>> kvp) => kvp.Value);
		}
		imconfig.Strings = strings2;
		IMControlScheme selectedControlScheme = this.SelectedControlScheme;
		imconfig.SelectedControlScheme = ((selectedControlScheme != null) ? selectedControlScheme.DeepCopy() : null);
		return imconfig;
	}
}
