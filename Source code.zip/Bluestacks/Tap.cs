﻿using System;
using System.ComponentModel;

// Token: 0x02000019 RID: 25
[Description("Independent")]
[Serializable]
public class Tap : IMAction
{
	// Token: 0x170000BD RID: 189
	// (get) Token: 0x06000191 RID: 401 RVA: 0x0000306B File Offset: 0x0000126B
	// (set) Token: 0x06000192 RID: 402 RVA: 0x00003073 File Offset: 0x00001273
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X
	{
		get
		{
			return this.mX;
		}
		set
		{
			this.mX = value;
		}
	}

	// Token: 0x170000BE RID: 190
	// (get) Token: 0x06000193 RID: 403 RVA: 0x0000307C File Offset: 0x0000127C
	// (set) Token: 0x06000194 RID: 404 RVA: 0x00003084 File Offset: 0x00001284
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y
	{
		get
		{
			return this.mY;
		}
		set
		{
			this.mY = value;
		}
	}

	// Token: 0x170000BF RID: 191
	// (get) Token: 0x06000195 RID: 405 RVA: 0x0000308D File Offset: 0x0000128D
	// (set) Token: 0x06000196 RID: 406 RVA: 0x00003095 File Offset: 0x00001295
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key
	{
		get
		{
			return this.mKey;
		}
		set
		{
			this.mKey = value;
		}
	}

	// Token: 0x170000C0 RID: 192
	// (get) Token: 0x06000197 RID: 407 RVA: 0x0000309E File Offset: 0x0000129E
	// (set) Token: 0x06000198 RID: 408 RVA: 0x000030A6 File Offset: 0x000012A6
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key_alt1
	{
		get
		{
			return this.mKey_1;
		}
		set
		{
			this.mKey_1 = value;
		}
	}

	// Token: 0x170000C1 RID: 193
	// (get) Token: 0x06000199 RID: 409 RVA: 0x000030AF File Offset: 0x000012AF
	// (set) Token: 0x0600019A RID: 410 RVA: 0x000030B7 File Offset: 0x000012B7
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool ShowOnOverlay
	{
		get
		{
			return this.mShowOnOverlay;
		}
		set
		{
			this.mShowOnOverlay = value;
		}
	}

	// Token: 0x040000B6 RID: 182
	private double mX = -1.0;

	// Token: 0x040000B7 RID: 183
	private double mY = -1.0;

	// Token: 0x040000B8 RID: 184
	private string mKey;

	// Token: 0x040000B9 RID: 185
	private string mKey_1 = string.Empty;

	// Token: 0x040000BA RID: 186
	internal bool mShowOnOverlay = true;
}
