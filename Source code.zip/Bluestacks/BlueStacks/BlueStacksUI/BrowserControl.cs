﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Windows.Threading;
using BlueStacks.BlueStacksUI.BTv;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Windows7.Multitouch;
using Windows7.Multitouch.Manipulation;
using Windows7.Multitouch.WPF;
using Xilium.CefGlue;
using Xilium.CefGlue.WPF;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001E4 RID: 484
	public class BrowserControl : UserControl, IDisposable
	{
		// Token: 0x170002A0 RID: 672
		// (get) Token: 0x060011F7 RID: 4599 RVA: 0x0000CB59 File Offset: 0x0000AD59
		// (set) Token: 0x060011F8 RID: 4600 RVA: 0x0000CB7A File Offset: 0x0000AD7A
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
			set
			{
				this.mMainWindow = value;
			}
		}

		// Token: 0x170002A1 RID: 673
		// (get) Token: 0x060011F9 RID: 4601 RVA: 0x0000CB83 File Offset: 0x0000AD83
		// (set) Token: 0x060011FA RID: 4602 RVA: 0x0000CB9F File Offset: 0x0000AD9F
		public NoInternetControl NoInternetControl
		{
			get
			{
				if (this.mNoInternetControl == null)
				{
					this.mNoInternetControl = new NoInternetControl(this);
				}
				return this.mNoInternetControl;
			}
			set
			{
				this.mNoInternetControl = value;
			}
		}

		// Token: 0x14000026 RID: 38
		// (add) Token: 0x060011FB RID: 4603 RVA: 0x0006EBB0 File Offset: 0x0006CDB0
		// (remove) Token: 0x060011FC RID: 4604 RVA: 0x0006EBE8 File Offset: 0x0006CDE8
		public event ProcessMessageEventHandler ProcessMessageRecieved;

		// Token: 0x14000027 RID: 39
		// (add) Token: 0x060011FD RID: 4605 RVA: 0x0006EC20 File Offset: 0x0006CE20
		// (remove) Token: 0x060011FE RID: 4606 RVA: 0x0006EC58 File Offset: 0x0006CE58
		public event Action BrowserLoadCompleteEvent;

		// Token: 0x170002A2 RID: 674
		// (get) Token: 0x060011FF RID: 4607 RVA: 0x0000CBA8 File Offset: 0x0000ADA8
		// (set) Token: 0x06001200 RID: 4608 RVA: 0x0000CBB0 File Offset: 0x0000ADB0
		public Grid mGrid { get; set; }

		// Token: 0x170002A3 RID: 675
		// (get) Token: 0x06001201 RID: 4609 RVA: 0x0000CBB9 File Offset: 0x0000ADB9
		public List<BrowserControlTags> TagsSubscribed { get; } = new List<BrowserControlTags>();

		// Token: 0x170002A4 RID: 676
		// (get) Token: 0x06001202 RID: 4610 RVA: 0x0000CBC1 File Offset: 0x0000ADC1
		// (set) Token: 0x06001203 RID: 4611 RVA: 0x0000CBC9 File Offset: 0x0000ADC9
		public BrowserSubscriber mSubscriber { get; set; }

		// Token: 0x170002A5 RID: 677
		// (get) Token: 0x06001204 RID: 4612 RVA: 0x0000CBD2 File Offset: 0x0000ADD2
		// (set) Token: 0x06001205 RID: 4613 RVA: 0x0006EC90 File Offset: 0x0006CE90
		internal Browser CefBrowser
		{
			get
			{
				return this.mBrowser;
			}
			set
			{
				this.mBrowser = value;
				if (this.mBrowser == null)
				{
					foreach (BrowserControlTags args in this.TagsSubscribed)
					{
						BrowserSubscriber mSubscriber = this.mSubscriber;
						if (mSubscriber != null)
						{
							mSubscriber.UnsubscribeTag(args);
						}
					}
				}
			}
		}

		// Token: 0x06001206 RID: 4614 RVA: 0x0006ED00 File Offset: 0x0006CF00
		public BrowserControl()
		{
		}

		// Token: 0x06001207 RID: 4615 RVA: 0x0000CBDA File Offset: 0x0000ADDA
		public void UpdateUrlAndRefresh(string newUrl)
		{
			this.mUrl = newUrl;
			if (this.CefBrowser != null)
			{
				this.CefBrowser.StartUrl = this.mUrl;
				this.SetVisibilityOfLoader(Visibility.Visible);
				this.CefBrowser.NavigateTo(this.mUrl);
			}
		}

		// Token: 0x06001208 RID: 4616 RVA: 0x0000CC14 File Offset: 0x0000AE14
		internal void NavigateTo(string url)
		{
			if (this.CefBrowser != null)
			{
				this.SetVisibilityOfLoader(Visibility.Visible);
				this.CefBrowser.NavigateTo(url);
			}
		}

		// Token: 0x06001209 RID: 4617 RVA: 0x0000CC31 File Offset: 0x0000AE31
		public void RefreshBrowser()
		{
			if (this.CefBrowser != null)
			{
				this.CefBrowser.Refresh();
			}
		}

		// Token: 0x0600120A RID: 4618 RVA: 0x0006ED50 File Offset: 0x0006CF50
		public BrowserControl(string url)
		{
			this.InitBaseControl(url, 0f);
			this.mSubscriber = new BrowserSubscriber(this);
		}

		// Token: 0x0600120B RID: 4619 RVA: 0x0006EDB8 File Offset: 0x0006CFB8
		public void CallJsForMaps(string methodName, string appName, string packageName)
		{
			object[] array = new object[]
			{
				""
			};
			if (!string.IsNullOrEmpty(appName) || !string.IsNullOrEmpty(packageName))
			{
				JObject jobject = new JObject
				{
					{
						"name",
						appName
					},
					{
						"pkg",
						packageName
					}
				};
				array[0] = jobject.ToString(Formatting.None, new JsonConverter[0]);
			}
			if (this.CefBrowser != null)
			{
				this.CefBrowser.CallJs(methodName, array);
			}
		}

		// Token: 0x0600120C RID: 4620 RVA: 0x0006EE34 File Offset: 0x0006D034
		internal void InitBaseControl(string url, float zoomLevel = 0f)
		{
			this.customZoomLevel = zoomLevel;
			this.mUrl = url;
			base.Visibility = Visibility.Hidden;
			base.IsVisibleChanged += this.BrowserControl_IsVisibleChanged;
			this.mGrid = new Grid();
			base.Content = this.mGrid;
			if (FeatureManager.Instance.IsCreateBrowserOnStart)
			{
				this.CreateNewBrowser();
			}
		}

		// Token: 0x0600120D RID: 4621 RVA: 0x0006EE94 File Offset: 0x0006D094
		public void DisposeBrowser()
		{
			BrowserControl.sAllBrowserControls.Remove(this);
			if (this.CefBrowser != null)
			{
				this.mGrid.Children.Remove(this.CefBrowser);
				this.CefBrowser.Dispose();
				this.mBrowserHost = null;
				this.CefBrowser = null;
			}
		}

		// Token: 0x0600120E RID: 4622 RVA: 0x0000CC46 File Offset: 0x0000AE46
		private void BrowserControl_IsVisibleChanged(object _1, DependencyPropertyChangedEventArgs _2)
		{
			if (base.IsVisible)
			{
				this.CreateNewBrowser();
			}
		}

		// Token: 0x0600120F RID: 4623 RVA: 0x0000CC56 File Offset: 0x0000AE56
		internal void WelcomeTab_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs _)
		{
			if (FeatureManager.Instance.IsBrowserKilledOnTabSwitch && ((UIElement)sender).Visibility != Visibility.Visible)
			{
				this.DisposeBrowser();
			}
		}

		// Token: 0x06001210 RID: 4624 RVA: 0x0006EEE4 File Offset: 0x0006D0E4
		internal void CreateNewBrowser()
		{
			if (this.CefBrowser == null && !string.IsNullOrEmpty(this.mUrl))
			{
				this.CefBrowser = new Browser(this.customZoomLevel);
				BrowserControl.sAllBrowserControls.Add(this);
				this.CefBrowser.StartUrl = this.mUrl;
				this.mGrid.Children.Add(this.CefBrowser);
				this.CefBrowser.LoadEnd += this.MBrowser_LoadEnd;
				this.CefBrowser.ProcessMessageRecieved += this.Browser_ProcessMessageRecieved;
				this.CefBrowser.Loaded += this.Browser_Loaded;
				this.CefBrowser.LoadError += this.Browser_LoadError;
				this.CefBrowser.LoadingStateChange += this.Browser_LoadingStateChange;
				this.CefBrowser.mWPFCefBrowserExceptionHandler += this.Browser_WPFCefBrowserExceptionHandler;
				if (RegistryManager.Instance.CefDevEnv == 1)
				{
					this.CefBrowser.mAllowDevTool = true;
					this.CefBrowser.mDevToolHeader = this.mUrl;
				}
				try
				{
					this.AddTouchHandler();
				}
				catch (Exception ex)
				{
					Logger.Error("exception adding touch handler: {0}", new object[]
					{
						ex
					});
				}
			}
		}

		// Token: 0x06001211 RID: 4625 RVA: 0x0000CC77 File Offset: 0x0000AE77
		private void MBrowser_LoadEnd(object sender, LoadEndEventArgs e)
		{
			this.SetVisibilityOfLoader(Visibility.Hidden);
		}

		// Token: 0x06001212 RID: 4626 RVA: 0x0006F034 File Offset: 0x0006D234
		private void Browser_LoadError(object sender, LoadErrorEventArgs e)
		{
			if (this.CefBrowser != null)
			{
				Logger.Warning("Cef error code: {0}, error text: {1}", new object[]
				{
					e.ErrorCode,
					e.ErrorText
				});
				if (e.ErrorCode == CefErrorCode.InternetDisconnected || e.ErrorCode == CefErrorCode.TunnelConnectionFailed || e.ErrorCode == CefErrorCode.ConnectionReset || e.ErrorCode == (CefErrorCode)(-21) || e.ErrorCode == (CefErrorCode)(-130) || (e.ErrorCode == CefErrorCode.NameNotResolved && !Utils.CheckForInternetConnection()))
				{
					this.mFailedUrl = e.FailedUrl;
					base.Dispatcher.Invoke(new Action(delegate()
					{
						if (!this.mGrid.Children.Contains(this.NoInternetControl))
						{
							this.mGrid.Children.Add(this.NoInternetControl);
						}
					}), new object[0]);
				}
			}
		}

		// Token: 0x06001213 RID: 4627 RVA: 0x0006F0E4 File Offset: 0x0006D2E4
		private void SetVisibilityOfLoader(Visibility visibility)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					Grid grid = this.Parent as Grid;
					if (grid != null)
					{
						IEnumerable<CustomPictureBox> enumerable = grid.Children.OfType<CustomPictureBox>();
						if (enumerable != null && enumerable.Any<CustomPictureBox>())
						{
							enumerable.First<CustomPictureBox>().Visibility = visibility;
						}
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in set visibility of web page loader : " + ex.ToString());
				}
			}), new object[0]);
		}

		// Token: 0x06001214 RID: 4628 RVA: 0x0000CC80 File Offset: 0x0000AE80
		private void Browser_WPFCefBrowserExceptionHandler(object sender, Exception e)
		{
			Logger.Error("Handle Error in wpf cef browser.." + e.ToString());
		}

		// Token: 0x06001215 RID: 4629 RVA: 0x0006F124 File Offset: 0x0006D324
		private void Browser_LoadingStateChange(object sender, LoadingStateChangeEventArgs e)
		{
			try
			{
				if (this.customZoomLevel == 0f)
				{
					this.CefBrowser.SetZoomLevel(this.zoomLevel);
				}
				if (e.IsLoading)
				{
					base.Dispatcher.Invoke(new Action(delegate()
					{
						if (this.mGrid.Children.Contains(this.NoInternetControl))
						{
							this.mGrid.Children.Remove(this.NoInternetControl);
						}
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error while setting zoom in browser with url {0} and error :{1}", new object[]
				{
					this.mUrl,
					ex.ToString()
				});
			}
		}

		// Token: 0x06001216 RID: 4630 RVA: 0x0006F1AC File Offset: 0x0006D3AC
		private void Browser_Loaded(object sender, RoutedEventArgs e)
		{
			try
			{
				if (this.customZoomLevel == 0f)
				{
					Matrix transformToDevice = PresentationSource.FromVisual((Visual)sender).CompositionTarget.TransformToDevice;
					ScaleTransform scaleTransform = new ScaleTransform(1.0 / transformToDevice.M11, 1.0 / transformToDevice.M22);
					if (scaleTransform.CanFreeze)
					{
						scaleTransform.Freeze();
					}
					this.CefBrowser.LayoutTransform = scaleTransform;
					this.zoomLevel = Math.Log(transformToDevice.M11) / Math.Log(1.2);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error while getting zoom of browser with url {0} and error :{1}", new object[]
				{
					this.mUrl,
					ex.ToString()
				});
			}
		}

		// Token: 0x06001217 RID: 4631 RVA: 0x0006F27C File Offset: 0x0006D47C
		private void AddTouchHandler()
		{
			try
			{
				if (Handler.DigitizerCapabilities.IsMultiTouchReady)
				{
					Logger.Info("adding touch handler");
					ManipulationProcessor mManipulationProcessor = new ManipulationProcessor(ProcessorManipulations.TRANSLATE_Y);
					this.mBrowserHost = this.CefBrowser.GetHost();
					Factory.EnableStylusEvents(this.ParentWindow);
					base.StylusDown += delegate(object s, StylusDownEventArgs e)
					{
						mManipulationProcessor.ProcessDown((uint)e.StylusDevice.Id, e.GetPosition(this).ToDrawingPointF());
					};
					base.StylusUp += delegate(object s, StylusEventArgs e)
					{
						mManipulationProcessor.ProcessUp((uint)e.StylusDevice.Id, e.GetPosition(this).ToDrawingPointF());
					};
					base.StylusMove += delegate(object s, StylusEventArgs e)
					{
						mManipulationProcessor.ProcessMove((uint)e.StylusDevice.Id, e.GetPosition(this).ToDrawingPointF());
					};
					mManipulationProcessor.ManipulationDelta += this.ProcessManipulationDelta;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("exception in adding touch handler: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x06001218 RID: 4632 RVA: 0x0006F348 File Offset: 0x0006D548
		private void ProcessManipulationDelta(object sender, ManipulationDeltaEventArgs e)
		{
			Logger.Debug("ProcessManipulationDelta.." + e.TranslationDelta.Height.ToString() + "..." + e.Location.ToString());
			if (this.mBrowserHost == null)
			{
				this.mBrowserHost = this.CefBrowser.GetHost();
			}
			CefMouseEvent @event = new CefMouseEvent
			{
				X = (int)e.Location.X,
				Y = (int)e.Location.Y
			};
			this.mBrowserHost.SendMouseWheelEvent(@event, 0, (int)e.TranslationDelta.Height);
			this.mBrowserHost.SendMouseMoveEvent(new CefMouseEvent(0, 0, CefEventFlags.None), false);
		}

		// Token: 0x06001219 RID: 4633 RVA: 0x0006F414 File Offset: 0x0006D614
		private void Browser_ProcessMessageRecieved(object sender, ProcessMessageEventArgs e)
		{
			string str = "Browser to client web call :";
			CefProcessMessage message = e.Message;
			Logger.Info(str + ((message != null) ? message.ToString() : null));
			if (string.Equals(e.Message.Name, "InstallApp", StringComparison.InvariantCulture))
			{
				CefListValue arguments = e.Message.Arguments;
				string @string = arguments.GetString(0);
				string string2 = arguments.GetString(1);
				string string3 = arguments.GetString(2);
				string string4 = arguments.GetString(3);
				this.InstallApp(@string, string2, string3, string4);
				this.ParentWindow.Utils.SendMessageToAndroidForAffiliate(string4, this.SOURCE_APPCENTER);
				return;
			}
			if (string.Equals(e.Message.Name, "InstallAppVersion", StringComparison.InvariantCulture))
			{
				CefListValue arguments2 = e.Message.Arguments;
				string string5 = arguments2.GetString(0);
				string string6 = arguments2.GetString(1);
				string string7 = arguments2.GetString(2);
				string string8 = arguments2.GetString(3);
				string string9 = arguments2.GetString(4);
				this.InstallApp(string5, string6, string7, string8, string9);
				this.ParentWindow.Utils.SendMessageToAndroidForAffiliate(string8, this.SOURCE_APPCENTER);
				return;
			}
			if (string.Equals(e.Message.Name, "InstallAppGooglePlay", StringComparison.InvariantCulture))
			{
				CefListValue arguments3 = e.Message.Arguments;
				arguments3.GetString(0);
				string string10 = arguments3.GetString(1);
				arguments3.GetString(2);
				string string11 = arguments3.GetString(3);
				this.ShowAppInPlayStore(string11, string10);
				this.ParentWindow.Utils.SendMessageToAndroidForAffiliate(string11, this.SOURCE_APPCENTER);
				return;
			}
			if (string.Equals(e.Message.Name, "GoogleSearch", StringComparison.InvariantCulture))
			{
				string string12 = e.Message.Arguments.GetString(0);
				this.SearchAppInPlayStore(string12);
				ClientStats.SendGPlayClickStats(new Dictionary<string, string>
				{
					{
						"query",
						string12
					},
					{
						"source",
						"bs3_appsearch"
					}
				});
				return;
			}
			if (string.Equals(e.Message.Name, "CloseSearch", StringComparison.InvariantCulture))
			{
				this.CloseSearch();
				return;
			}
			if (string.Equals(e.Message.Name, "RefreshSearch", StringComparison.InvariantCulture))
			{
				CefListValue arguments4 = e.Message.Arguments;
				string _ = string.Empty;
				if (arguments4.Count > 0)
				{
					_ = arguments4.GetString(0);
				}
				this.RefreshSearch(_);
				return;
			}
			if (string.Equals(e.Message.Name, "ShowWebPage", StringComparison.InvariantCulture))
			{
				CefListValue arguments5 = e.Message.Arguments;
				string string13 = arguments5.GetString(0);
				string string14 = arguments5.GetString(1);
				this.ShowWebPage(string13, string14);
				return;
			}
			if (!string.Equals(e.Message.Name, "CloseBlockerAd", StringComparison.InvariantCulture))
			{
				if (string.Equals(e.Message.Name, "CheckIfPremium", StringComparison.InvariantCulture))
				{
					string string15 = e.Message.Arguments.GetString(0);
					this.CheckIfPremium(string15);
					return;
				}
				if (!string.Equals(e.Message.Name, "GetImpressionId", StringComparison.InvariantCulture))
				{
					if (string.Equals(e.Message.Name, "sendFirebaseNotification", StringComparison.InvariantCulture))
					{
						string json = e.Message.Arguments.GetString(0);
						base.Dispatcher.Invoke(new Action(delegate()
						{
							CloudNotificationManager.Instance.HandleCloudNotification(json, this.ParentWindow.mVmName);
						}), new object[0]);
						return;
					}
					if (string.Equals(e.Message.Name, "PikaWorldProfileAdded", StringComparison.InvariantCulture))
					{
						string string16 = e.Message.Arguments.GetString(0);
						RegistryManager.Instance.PikaWorldId = string16;
						return;
					}
					if (string.Equals(e.Message.Name, "subscribeModule", StringComparison.InvariantCulture))
					{
						string string17 = e.Message.Arguments.GetString(0);
						char[] separator = new char[]
						{
							','
						};
						string[] array = string17.Split(separator, StringSplitOptions.None);
						this.PopulateTagsInfo(array, array[0]);
						return;
					}
					if (string.Equals(e.Message.Name, "unsubscribeModule", StringComparison.InvariantCulture))
					{
						string string18 = e.Message.Arguments.GetString(0);
						char[] separator2 = new char[]
						{
							','
						};
						string[] tagsList = string18.Split(separator2, StringSplitOptions.None);
						this.RemoveTagsInfo(tagsList);
						return;
					}
					if (string.Equals(e.Message.Name, "subscribeClientTags", StringComparison.InvariantCulture))
					{
						string string19 = e.Message.Arguments.GetString(0);
						char[] separator3 = new char[]
						{
							','
						};
						string[] array2 = string19.Split(separator3, StringSplitOptions.None);
						if (this.mSubscriber == null)
						{
							this.mSubscriber = new BrowserSubscriber(this);
						}
						this.mSubscriber.CallbackFunction = array2[0];
						List<string> list = array2.ToList<string>();
						list.RemoveAt(0);
						using (List<string>.Enumerator enumerator = list.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								string value = enumerator.Current;
								BrowserControlTags browserControlTags = EnumHelper.Parse<BrowserControlTags>(value, BrowserControlTags.googleSigninComplete);
								this.TagsSubscribed.AddIfNotContain(browserControlTags);
								BrowserSubscriber mSubscriber = this.mSubscriber;
								if (mSubscriber != null)
								{
									mSubscriber.SubscribeTag(browserControlTags);
								}
							}
							return;
						}
					}
					if (string.Equals(e.Message.Name, "unsubscribeClientTags", StringComparison.InvariantCulture))
					{
						string string20 = e.Message.Arguments.GetString(0);
						char[] separator4 = new char[]
						{
							','
						};
						string[] array3 = string20.Split(separator4, StringSplitOptions.None);
						for (int i = 0; i < array3.Length; i++)
						{
							BrowserControlTags browserControlTags2 = EnumHelper.Parse<BrowserControlTags>(array3[i], BrowserControlTags.googleSigninComplete);
							if (this.TagsSubscribed.Contains(browserControlTags2))
							{
								this.TagsSubscribed.Remove(browserControlTags2);
								BrowserSubscriber mSubscriber2 = this.mSubscriber;
								if (mSubscriber2 != null)
								{
									mSubscriber2.UnsubscribeTag(browserControlTags2);
								}
							}
						}
						return;
					}
					if (string.Equals(e.Message.Name, "ApplyThemeName", StringComparison.InvariantCulture))
					{
						string themeName = e.Message.Arguments.GetString(0);
						base.Dispatcher.Invoke(new Action(delegate()
						{
							this.ParentWindow.Utils.ApplyTheme(themeName);
							this.ParentWindow.Utils.RestoreWallpaperImageForAllVms();
							BlueStacksUIColorManager.ApplyTheme(themeName);
						}), new object[0]);
						return;
					}
					if (string.Equals(e.Message.Name, "GoToMapsTab", StringComparison.InvariantCulture))
					{
						base.Dispatcher.Invoke(new Action(delegate()
						{
							this.GoToMapsTab();
						}), new object[0]);
						return;
					}
					if (string.Equals(e.Message.Name, "HandleClick", StringComparison.InvariantCulture))
					{
						string text = "";
						try
						{
							text = e.Message.Arguments.GetString(0);
							JToken res = JToken.Parse(text);
							base.Dispatcher.Invoke(new Action(delegate()
							{
								this.ParentWindow.HideDimOverlay();
								this.ParentWindow.Utils.HandleGenericActionFromDictionary(res.ToSerializableDictionary<string>(), "handle_browser_click", "");
							}), new object[0]);
							return;
						}
						catch (Exception ex)
						{
							Logger.Error(string.Concat(new string[]
							{
								"Error when processing click action received from gmapi. JsonString: ",
								text,
								Environment.NewLine,
								"Error: ",
								ex.ToString()
							}));
							return;
						}
					}
					if (string.Equals(e.Message.Name, "UpdateQuestRules", StringComparison.InvariantCulture))
					{
						string text2 = "";
						try
						{
							text2 = e.Message.Arguments.GetString(0);
							PromotionManager.ReadQuests(JToken.Parse(text2), true);
							return;
						}
						catch (Exception ex2)
						{
							Logger.Error(string.Concat(new string[]
							{
								"Error when processing UpdateQuestRules. JsonString: ",
								text2,
								Environment.NewLine,
								"Error: ",
								ex2.ToString()
							}));
							return;
						}
					}
					if (string.Equals(e.Message.Name, "GetGamepadConnectionStatus", StringComparison.InvariantCulture))
					{
						base.Dispatcher.Invoke(new Action(delegate()
						{
							if (this.ParentWindow != null)
							{
								BlueStacksUIUtils.SendGamepadStatusToBrowsers(this.ParentWindow.IsGamepadConnected);
							}
						}), new object[0]);
						return;
					}
					if (string.Equals(e.Message.Name, "CloseAnyPopup", StringComparison.InvariantCulture))
					{
						base.Dispatcher.Invoke(new Action(delegate()
						{
							if (this.ParentWindow != null)
							{
								this.ParentWindow.HideDimOverlay();
							}
						}), new object[0]);
						return;
					}
					if (string.Equals(e.Message.Name, "SearchAppcenter", StringComparison.OrdinalIgnoreCase))
					{
						string searchText = e.Message.Arguments.GetString(0);
						base.Dispatcher.Invoke(new Action(delegate()
						{
							this.ParentWindow.mCommonHandler.SearchAppCenter(searchText);
						}), new object[0]);
						return;
					}
					if (string.Equals(e.Message.Name, "DownloadMacro", StringComparison.OrdinalIgnoreCase))
					{
						string macroData = e.Message.Arguments.GetString(0);
						base.Dispatcher.Invoke(new Action(delegate()
						{
							this.ParentWindow.Utils.DownloadAndUpdateMacro(macroData);
						}), new object[0]);
						return;
					}
					if (string.Equals(e.Message.Name, "ChangeControlScheme", StringComparison.OrdinalIgnoreCase))
					{
						string schemeSelected = e.Message.Arguments.GetString(0);
						base.Dispatcher.Invoke(new Action(delegate()
						{
							GuidanceWindow sGuidanceWindow = KMManager.sGuidanceWindow;
							if (sGuidanceWindow == null)
							{
								return;
							}
							sGuidanceWindow.SelectControlScheme(schemeSelected);
						}), new object[0]);
						return;
					}
					if (string.Equals(e.Message.Name, "CloseOnBoarding", StringComparison.OrdinalIgnoreCase))
					{
						string string21 = e.Message.Arguments.GetString(0);
						Logger.Info("CloseOnBoarding response from browser : " + string21);
						JToken res = JToken.Parse(string21);
						base.Dispatcher.Invoke(new Action(delegate()
						{
							GameOnboardingWindow onboardingWindow = this.ParentWindow.StaticComponents.mSelectedTabButton.OnboardingWindow;
							if (onboardingWindow != null)
							{
								onboardingWindow.Close();
							}
							GuidanceWindow sGuidanceWindow = KMManager.sGuidanceWindow;
							if (sGuidanceWindow != null)
							{
								sGuidanceWindow.ShowGuidanceOnboardingBlubs(res);
							}
							this.ParentWindow.HideDimOverlay();
							GuidanceWindow sGuidanceWindow2 = KMManager.sGuidanceWindow;
							if (sGuidanceWindow2 == null)
							{
								return;
							}
							sGuidanceWindow2.DimOverLayVisibility(Visibility.Collapsed);
						}), new object[0]);
						return;
					}
					if (string.Equals(e.Message.Name, "BrowserLoaded", StringComparison.OrdinalIgnoreCase))
					{
						base.Dispatcher.Invoke(new Action(delegate()
						{
							Action browserLoadCompleteEvent = this.BrowserLoadCompleteEvent;
							if (browserLoadCompleteEvent == null)
							{
								return;
							}
							browserLoadCompleteEvent();
						}), new object[0]);
						return;
					}
					try
					{
						object[] array4 = null;
						if (e.Message.Arguments.Count > 0)
						{
							array4 = new object[e.Message.Arguments.Count];
							for (int j = 0; j < e.Message.Arguments.Count; j++)
							{
								if (e.Message.Arguments.GetString(j) != null)
								{
									array4[j] = e.Message.Arguments.GetString(j).ToString(CultureInfo.InvariantCulture);
									Logger.Info("web api call.." + e.Message.Name + "..with args.." + e.Message.Arguments.GetString(j).ToString(CultureInfo.InvariantCulture));
								}
								else
								{
									array4[j] = string.Empty;
								}
							}
						}
						base.GetType().GetMethod(e.Message.Name).Invoke(this, array4);
					}
					catch (Exception)
					{
					}
					ProcessMessageEventHandler processMessageRecieved = this.ProcessMessageRecieved;
					if (processMessageRecieved == null)
					{
						return;
					}
					processMessageRecieved(sender, e);
				}
			}
		}

		// Token: 0x0600121A RID: 4634 RVA: 0x0006FEC4 File Offset: 0x0006E0C4
		internal void RemoveTagsInfo(string[] tagsList)
		{
			foreach (string item in tagsList)
			{
				if (BrowserControl.mFirebaseTagsSubscribed.Contains(item))
				{
					BrowserControl.mFirebaseTagsSubscribed.Remove(item);
				}
			}
		}

		// Token: 0x0600121B RID: 4635 RVA: 0x0006FF00 File Offset: 0x0006E100
		public void PopulateTagsInfo(string[] tagsList, string methodName)
		{
			if (tagsList != null)
			{
				foreach (string text in tagsList)
				{
					if (!string.Equals(text, methodName, StringComparison.InvariantCultureIgnoreCase))
					{
						BrowserControl.mFirebaseTagsSubscribed.Add(text);
					}
				}
			}
			this.mFirebaseCallbackMethod = methodName;
		}

		// Token: 0x0600121C RID: 4636 RVA: 0x0000CC97 File Offset: 0x0000AE97
		public void GoToMapsTab()
		{
			if (this.ParentWindow != null)
			{
				this.ParentWindow.mTopBar.mAppTabButtons.GoToTab("pikaworld", true, false);
			}
		}

		// Token: 0x0600121D RID: 4637 RVA: 0x0006FF40 File Offset: 0x0006E140
		private void CheckIfPremium(string isPremium)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (isPremium.Equals("true", StringComparison.InvariantCultureIgnoreCase))
				{
					RegistryManager.Instance.IsPremium = true;
					this.ParentWindow.mTopBar.ChangeUserPremiumButton(true);
				}
				else
				{
					RegistryManager.Instance.IsPremium = false;
					this.ParentWindow.mTopBar.ChangeUserPremiumButton(false);
				}
				Action<bool> appRecommendationHandler = PromotionObject.AppRecommendationHandler;
				if (appRecommendationHandler == null)
				{
					return;
				}
				appRecommendationHandler(true);
			}), new object[0]);
		}

		// Token: 0x0600121E RID: 4638 RVA: 0x0006FF80 File Offset: 0x0006E180
		private void InstallApp(string iconUrl, string appName, string apkUrl, string package, string timestamp)
		{
			if (!string.IsNullOrEmpty(package))
			{
				Logger.Info("apkUrl: " + apkUrl);
				string empty = string.Empty;
				if (!string.IsNullOrEmpty(apkUrl))
				{
					base.Dispatcher.Invoke(new Action(delegate()
					{
						new DownloadInstallApk(this.ParentWindow).DownloadAndInstallApp(iconUrl, appName, apkUrl, package, false, true, timestamp);
					}), new object[0]);
				}
			}
		}

		// Token: 0x0600121F RID: 4639 RVA: 0x00070014 File Offset: 0x0006E214
		private void InstallApp(string iconUrl, string appName, string apkUrl, string package)
		{
			if (!string.IsNullOrEmpty(package))
			{
				Logger.Info("apkUrl: " + apkUrl);
				if (!string.IsNullOrEmpty(apkUrl))
				{
					base.Dispatcher.Invoke(new Action(delegate()
					{
						new DownloadInstallApk(this.ParentWindow).DownloadAndInstallApp(iconUrl, appName, apkUrl, package, false, true, "");
					}), new object[0]);
				}
			}
		}

		// Token: 0x06001220 RID: 4640 RVA: 0x00070098 File Offset: 0x0006E298
		private void ShowAppInPlayStore(string packageName, string appName)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.ParentWindow.mWelcomeTab.mFrontendPopupControl.Init(packageName, appName, PlayStoreAction.OpenApp, false);
				this.ParentWindow.mWelcomeTab.mFrontendPopupControl.Visibility = Visibility.Visible;
			}), new object[0]);
		}

		// Token: 0x06001221 RID: 4641 RVA: 0x000700E0 File Offset: 0x0006E2E0
		private void SearchAppInPlayStore(string searchString)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (searchString != null)
				{
					this.ParentWindow.mWelcomeTab.mFrontendPopupControl.Init(searchString, LocaleStrings.GetLocalizedString("STRING_MORE_GOOGLE_SEARCH_RESULT") + " \"" + searchString + "\"", PlayStoreAction.SearchApp, false);
				}
			}), new object[0]);
		}

		// Token: 0x06001222 RID: 4642 RVA: 0x0000CCBE File Offset: 0x0000AEBE
		private void CloseSearch()
		{
			if (this.CefBrowser != null)
			{
				this.CefBrowser.NavigateTo(this.mUrl);
			}
		}

		// Token: 0x06001223 RID: 4643 RVA: 0x00005D29 File Offset: 0x00003F29
		private void RefreshSearch(string _)
		{
		}

		// Token: 0x06001224 RID: 4644 RVA: 0x00070120 File Offset: 0x0006E320
		public void ShowWebPage(string title, string webUrl)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (title == null)
				{
					title = "";
				}
				if (this.ParentWindow != null)
				{
					this.ParentWindow.Utils.AppendUrlWithCommonParamsAndOpenTab(webUrl, title, "cef_tab", "");
					return;
				}
				MainWindow activatedWindow = null;
				if (BlueStacksUIUtils.DictWindows.Count > 0)
				{
					activatedWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
				}
				activatedWindow.Dispatcher.Invoke(new Action(delegate()
				{
					activatedWindow.Utils.AppendUrlWithCommonParamsAndOpenTab(webUrl, title, "cef_tab", "");
				}), new object[0]);
			}), new object[0]);
		}

		// Token: 0x06001225 RID: 4645 RVA: 0x0000CCD9 File Offset: 0x0000AED9
		public void CloseSelf()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				AppTabButton selectedTab = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab;
				if (selectedTab != null)
				{
					this.ParentWindow.mTopBar.mAppTabButtons.CloseTab(selectedTab.TabKey, false, false, false, false, "");
				}
			}), new object[0]);
		}

		// Token: 0x06001226 RID: 4646 RVA: 0x0000CCFE File Offset: 0x0000AEFE
		public void CloseBrowserQuitPopup()
		{
			this.ParentWindow.CloseBrowserQuitPopup();
		}

		// Token: 0x06001227 RID: 4647 RVA: 0x0000CD0B File Offset: 0x0000AF0B
		internal void ReInitBrowser(string url)
		{
			this.CefBrowser.Dispose();
			this.CefBrowser = null;
			this.mUrl = url;
			this.CreateNewBrowser();
		}

		// Token: 0x06001228 RID: 4648 RVA: 0x00070168 File Offset: 0x0006E368
		public static void DownloadBTV()
		{
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				MainWindow window = BlueStacksUIUtils.DictWindows[BlueStacksUIUtils.DictWindows.Keys.ToList<string>()[0]];
				window.Dispatcher.Invoke(new Action(delegate()
				{
					BTVManager.Instance.MaybeDownloadAndLaunchBTv(window);
				}), new object[0]);
			}
		}

		// Token: 0x06001229 RID: 4649 RVA: 0x000701D0 File Offset: 0x0006E3D0
		public static void DownloadDirectX()
		{
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				MainWindow activatedWindow = BlueStacksUIUtils.DictWindows[BlueStacksUIUtils.DictWindows.Keys.ToList<string>()[0]];
				activatedWindow.Dispatcher.Invoke(new Action(delegate()
				{
					string directXDownloadURL = "http://www.microsoft.com/en-us/download/details.aspx?id=35";
					CustomMessageWindow window = new CustomMessageWindow();
					window.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_ADDITIONAL_FILES_REQUIRED");
					window.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_SOME_WINDOW_FILES_MISSING");
					window.AddHyperLinkInUI(directXDownloadURL, new Uri(directXDownloadURL), delegate(object o, RequestNavigateEventArgs arg)
					{
						BlueStacksUIUtils.OpenUrl(arg.Uri.ToString());
						window.CloseWindow();
					});
					window.AddButton(ButtonColors.Blue, "STRING_DOWNLOAD_NOW", delegate(object o, EventArgs args)
					{
						BlueStacksUIUtils.OpenUrl(directXDownloadURL);
					}, null, false, null);
					window.AddButton(ButtonColors.White, "STRING_NO", null, null, false, null);
					window.Owner = activatedWindow;
					window.ShowDialog();
					activatedWindow.BringIntoView();
				}), new object[0]);
			}
		}

		// Token: 0x0600122A RID: 4650 RVA: 0x0000CD2C File Offset: 0x0000AF2C
		public static void SetSystemVolume(string level)
		{
			StreamManager.Instance.SetSystemVolume(level);
		}

		// Token: 0x0600122B RID: 4651 RVA: 0x0000CD39 File Offset: 0x0000AF39
		public static void SetMicVolume(string level)
		{
			if (string.Equals((level != null) ? level.Trim() : null, "0", StringComparison.InvariantCultureIgnoreCase))
			{
				StreamManager.mIsMicDisabled = true;
			}
			StreamManager.Instance.SetMicVolume(level);
		}

		// Token: 0x0600122C RID: 4652 RVA: 0x0000CD65 File Offset: 0x0000AF65
		public static void EnableWebcam(string width, string height, string position)
		{
			StreamManager.EnableWebcam(width, height, position);
		}

		// Token: 0x0600122D RID: 4653 RVA: 0x0000CD6F File Offset: 0x0000AF6F
		public static void DisableWebcamV2(string jsonString)
		{
			StreamManager.Instance.DisableWebcamV2(jsonString);
		}

		// Token: 0x0600122E RID: 4654 RVA: 0x0000CD7C File Offset: 0x0000AF7C
		public static void MoveWebcam(string horizontal, string vertical)
		{
			StreamManager.Instance.MoveWebcam(horizontal, vertical);
		}

		// Token: 0x0600122F RID: 4655 RVA: 0x0000CD8A File Offset: 0x0000AF8A
		public static void StopRecord()
		{
			if (StreamManager.Instance != null)
			{
				Logger.Info("Got StopRecord");
				StreamManager.Instance.StopRecord(true);
			}
		}

		// Token: 0x06001230 RID: 4656 RVA: 0x0000CDA8 File Offset: 0x0000AFA8
		public static void StopStream()
		{
			StreamManager.Instance.StopStream();
		}

		// Token: 0x06001231 RID: 4657 RVA: 0x00005D29 File Offset: 0x00003F29
		public static void ShowPreview()
		{
		}

		// Token: 0x06001232 RID: 4658 RVA: 0x00005D29 File Offset: 0x00003F29
		public static void HidePreview()
		{
		}

		// Token: 0x06001233 RID: 4659 RVA: 0x0000CDB4 File Offset: 0x0000AFB4
		public void StartObs(string _)
		{
			this.InitStreamManager();
			StreamManager.Instance.StartObs();
		}

		// Token: 0x06001234 RID: 4660 RVA: 0x00070238 File Offset: 0x0006E438
		public void GetRealtimeAppUsage(string callBackFunction)
		{
			try
			{
				Dictionary<string, Dictionary<string, long>> realtimeDictionary = AppUsageTimer.GetRealtimeDictionary();
				if (!string.IsNullOrEmpty(callBackFunction))
				{
					this.CallBackToHtml(callBackFunction, JSONUtils.GetJSONObjectString<long>(realtimeDictionary[this.ParentWindow.mVmName]));
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error while sending realtime dictionary to gmapi" + ex.ToString());
			}
		}

		// Token: 0x06001235 RID: 4661 RVA: 0x0007029C File Offset: 0x0006E49C
		public void GetInstalledAppsJsonforJS(string callBackFunction)
		{
			bool flag = false;
			MainWindow mainWindow = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				mainWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			string mVmName = mainWindow.mVmName;
			string path = Path.Combine(RegistryStrings.GadgetDir, "apps_" + mVmName + ".json");
			string text = "[" + Environment.NewLine + "]";
			using (Mutex mutex = new Mutex(false, "BlueStacks_AppJsonUpdate"))
			{
				if (mutex.WaitOne())
				{
					try
					{
						StreamReader streamReader = new StreamReader(path);
						text = streamReader.ReadToEnd();
						streamReader.Close();
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to read apps json file... Err : " + ex.ToString());
					}
					finally
					{
						mutex.ReleaseMutex();
					}
				}
			}
			if (flag)
			{
				text = text.Replace("\"", "\\\"");
			}
			text = text.Replace("\n", "");
			text = text.Replace("\r", "");
			text = Regex.Replace(text, "\\s+", " ", RegexOptions.Multiline);
			if (!string.IsNullOrEmpty(callBackFunction))
			{
				this.CallBackToHtml(callBackFunction, text);
			}
		}

		// Token: 0x06001236 RID: 4662 RVA: 0x000703E8 File Offset: 0x0006E5E8
		public void PerformOTS(string callbackFunction)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				AppIcon appIcon = this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon("com.android.vending");
				if (appIcon != null)
				{
					this.ParentWindow.mTopBar.mAppTabButtons.AddAppTab(appIcon.AppName, appIcon.PackageName, appIcon.ActivityName, appIcon.ImageName, true, true, false);
				}
			}), new object[0]);
			if (!string.IsNullOrEmpty(callbackFunction))
			{
				this.ParentWindow.mBrowserCallbackFunctionName = callbackFunction;
				this.ParentWindow.BrowserOTSCompletedCallback += this.ParentWindow_BrowserOTSCompletedCallback;
			}
		}

		// Token: 0x06001237 RID: 4663 RVA: 0x00070440 File Offset: 0x0006E640
		private void ParentWindow_BrowserOTSCompletedCallback(object sender, MainWindowEventArgs.BrowserOTSCompletedCallbackEventArgs args)
		{
			string data = RegistryManager.Instance.Token + "@@" + RegistryManager.Instance.RegisteredEmail;
			this.CallBackToHtml(args.CallbackFunction, data);
			string communityWebTabKey = LocaleStrings.GetLocalizedString("STRING_MACRO_COMMUNITY");
			Action <>9__1;
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (this.ParentWindow.mTopBar.mAppTabButtons.mDictTabs.ContainsKey(communityWebTabKey) && this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.TabKey != communityWebTabKey)
				{
					Dispatcher dispatcher = this.ParentWindow.Dispatcher;
					Action method;
					if ((method = <>9__1) == null)
					{
						method = (<>9__1 = delegate()
						{
							this.ParentWindow.mTopBar.mAppTabButtons.GoToTab(communityWebTabKey, true, false);
						});
					}
					dispatcher.Invoke(method, new object[0]);
				}
			}), new object[0]);
		}

		// Token: 0x06001238 RID: 4664 RVA: 0x000704B4 File Offset: 0x0006E6B4
		public string GetCurrentAppInfo(string callBackFunction)
		{
			MainWindow mainWindow = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				mainWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			AppTabButton selectedTab = mainWindow.mTopBar.mAppTabButtons.SelectedTab;
			if (selectedTab == null)
			{
				return "{}";
			}
			string appName = selectedTab.AppName;
			string packageName = selectedTab.PackageName;
			JObject jobject = new JObject
			{
				{
					"type",
					"app"
				},
				{
					"name",
					appName
				},
				{
					"data",
					packageName
				}
			};
			if (!string.IsNullOrEmpty(callBackFunction))
			{
				this.CallBackToHtml(callBackFunction, jobject.ToString(Formatting.None, new JsonConverter[0]));
			}
			return jobject.ToString(Formatting.None, new JsonConverter[0]);
		}

		// Token: 0x06001239 RID: 4665 RVA: 0x0000CDC7 File Offset: 0x0000AFC7
		public void StartStreamV2(string jsonString, string callbackStreamStatus, string callbackTabChanged)
		{
			Logger.Info("Got StartStreamV2");
			this.InitStreamManager();
			if (StreamManager.Instance.mReplayBufferEnabled)
			{
				StreamManager.Instance.StartReplayBuffer();
			}
			Logger.Info("Got StartStream");
			StreamManager.Instance.StartStream(jsonString, callbackStreamStatus, callbackTabChanged);
		}

		// Token: 0x0600123A RID: 4666 RVA: 0x00070574 File Offset: 0x0006E774
		private StreamManager InitStreamManager()
		{
			if (StreamManager.Instance == null)
			{
				StreamManager.Instance = new StreamManager(this.CefBrowser);
			}
			else
			{
				string hwnd;
				string text;
				StreamManager.GetStreamConfig(out hwnd, out text);
				StreamManager.Instance.SetHwnd(hwnd);
			}
			return StreamManager.Instance;
		}

		// Token: 0x0600123B RID: 4667 RVA: 0x000705B4 File Offset: 0x0006E7B4
		public void makeWebCall(string url, string scriptToInvoke)
		{
			HttpWebRequest httpWebRequest = WebRequest.Create(url) as HttpWebRequest;
			httpWebRequest.Method = "GET";
			httpWebRequest.AutomaticDecompression = DecompressionMethods.GZip;
			httpWebRequest.Headers.Add(HttpRequestHeader.AcceptEncoding, "gzip");
			string str = "Bluestacks/" + RegistryManager.Instance.ClientVersion;
			httpWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36 " + str;
			new Uri(url);
			try
			{
				Logger.Info("making a webcall at url=" + url);
				string text = null;
				using (HttpWebResponse httpWebResponse = httpWebRequest.GetResponse() as HttpWebResponse)
				{
					using (Stream responseStream = httpWebResponse.GetResponseStream())
					{
						using (StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8))
						{
							text = streamReader.ReadToEnd();
						}
					}
				}
				object[] args = new object[]
				{
					text
				};
				this.CefBrowser.CallJs(scriptToInvoke, args);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in MakeWebCall. err : " + ex.ToString());
				string text2 = "";
				object[] args2 = new object[]
				{
					text2
				};
				this.CefBrowser.CallJs(scriptToInvoke, args2);
			}
		}

		// Token: 0x0600123C RID: 4668 RVA: 0x00070710 File Offset: 0x0006E910
		public static void LaunchDialog(string jsonString)
		{
			try
			{
				JObject jobject = JObject.Parse(jsonString);
				if (jobject["parameter"] != null)
				{
					jobject["parameter"].ToString();
				}
				if (BlueStacksUIUtils.DictWindows.Count > 0)
				{
					BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in launchDialog gmApi : " + ex.ToString());
			}
		}

		// Token: 0x0600123D RID: 4669 RVA: 0x00005D29 File Offset: 0x00003F29
		public static void CloseFilterWindow(string _)
		{
		}

		// Token: 0x0600123E RID: 4670 RVA: 0x0007078C File Offset: 0x0006E98C
		public void CallBackToHtml(string callBackFunction, string data)
		{
			if (data != null)
			{
				string text = callBackFunction + "('" + ((data != null) ? data.Replace("'", "&#39;").Replace("%27", "&#39;") : null) + "')";
				Browser cefBrowser = this.CefBrowser;
				if (cefBrowser == null)
				{
					return;
				}
				string code = text;
				Browser cefBrowser2 = this.CefBrowser;
				cefBrowser.ExecuteJavaScript(code, (cefBrowser2 != null) ? cefBrowser2.getURL() : null, 0);
			}
		}

		// Token: 0x0600123F RID: 4671 RVA: 0x000707F8 File Offset: 0x0006E9F8
		protected virtual void Dispose(bool disposing)
		{
			if (!this.disposedValue)
			{
				if (this.CefBrowser != null)
				{
					this.CefBrowser.LoadEnd -= this.MBrowser_LoadEnd;
					this.CefBrowser.ProcessMessageRecieved -= this.Browser_ProcessMessageRecieved;
					this.CefBrowser.Loaded -= this.Browser_Loaded;
					this.CefBrowser.LoadError -= this.Browser_LoadError;
					this.CefBrowser.LoadingStateChange -= this.Browser_LoadingStateChange;
					this.CefBrowser.mWPFCefBrowserExceptionHandler -= this.Browser_WPFCefBrowserExceptionHandler;
					this.CefBrowser.Dispose();
					CefBrowserHost cefBrowserHost = this.mBrowserHost;
					if (cefBrowserHost != null)
					{
						cefBrowserHost.Dispose();
					}
					foreach (BrowserControlTags args in this.TagsSubscribed)
					{
						BrowserSubscriber mSubscriber = this.mSubscriber;
						if (mSubscriber != null)
						{
							mSubscriber.UnsubscribeTag(args);
						}
					}
				}
				this.disposedValue = true;
			}
		}

		// Token: 0x06001240 RID: 4672 RVA: 0x0007091C File Offset: 0x0006EB1C
		~BrowserControl()
		{
			this.Dispose(false);
		}

		// Token: 0x06001241 RID: 4673 RVA: 0x0000CE07 File Offset: 0x0000B007
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x04000BB3 RID: 2995
		private string SOURCE_APPCENTER = "BSAppCenter";

		// Token: 0x04000BB4 RID: 2996
		private float customZoomLevel;

		// Token: 0x04000BB5 RID: 2997
		private MainWindow mMainWindow;

		// Token: 0x04000BB6 RID: 2998
		private NoInternetControl mNoInternetControl;

		// Token: 0x04000BB7 RID: 2999
		private Browser mBrowser;

		// Token: 0x04000BB8 RID: 3000
		internal string mUrl;

		// Token: 0x04000BB9 RID: 3001
		private double zoomLevel = 1.0;

		// Token: 0x04000BBF RID: 3007
		internal static List<BrowserControl> sAllBrowserControls = new List<BrowserControl>();

		// Token: 0x04000BC0 RID: 3008
		internal static List<string> mFirebaseTagsSubscribed = new List<string>();

		// Token: 0x04000BC1 RID: 3009
		internal string mFirebaseCallbackMethod = string.Empty;

		// Token: 0x04000BC2 RID: 3010
		internal string mFailedUrl = string.Empty;

		// Token: 0x04000BC3 RID: 3011
		private CefBrowserHost mBrowserHost;

		// Token: 0x04000BC4 RID: 3012
		private bool disposedValue;
	}
}
