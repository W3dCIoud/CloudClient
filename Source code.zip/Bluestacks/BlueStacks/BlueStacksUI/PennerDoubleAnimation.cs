﻿using System;
using System.ComponentModel;
using System.Reflection;
using System.Windows;
using System.Windows.Media.Animation;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200019D RID: 413
	public class PennerDoubleAnimation : DoubleAnimationBase
	{
		// Token: 0x06001013 RID: 4115 RVA: 0x0000BC6C File Offset: 0x00009E6C
		public PennerDoubleAnimation()
		{
		}

		// Token: 0x06001014 RID: 4116 RVA: 0x0000BC74 File Offset: 0x00009E74
		public PennerDoubleAnimation(PennerDoubleAnimation.Equations type, double from, double to)
		{
			this.Equation = type;
			this.From = from;
			this.To = to;
		}

		// Token: 0x06001015 RID: 4117 RVA: 0x0000BC91 File Offset: 0x00009E91
		public PennerDoubleAnimation(PennerDoubleAnimation.Equations type, double from, double to, Duration duration)
		{
			this.Equation = type;
			this.From = from;
			this.To = to;
			base.Duration = duration;
		}

		// Token: 0x06001016 RID: 4118 RVA: 0x00065E64 File Offset: 0x00064064
		protected override double GetCurrentValueCore(double startValue, double targetValue, AnimationClock clock)
		{
			double result;
			try
			{
				object[] parameters = new object[]
				{
					(clock != null) ? new double?(clock.CurrentTime.Value.TotalSeconds) : null,
					this.From,
					this.To - this.From,
					base.Duration.TimeSpan.TotalSeconds
				};
				result = (double)this._EasingMethod.Invoke(this, parameters);
			}
			catch
			{
				result = this.From;
			}
			return result;
		}

		// Token: 0x06001017 RID: 4119 RVA: 0x0000BCB6 File Offset: 0x00009EB6
		protected override Freezable CreateInstanceCore()
		{
			return new PennerDoubleAnimation();
		}

		// Token: 0x06001018 RID: 4120 RVA: 0x0000BCBD File Offset: 0x00009EBD
		public static double Linear(double t, double b, double c, double d)
		{
			return c * t / d + b;
		}

		// Token: 0x06001019 RID: 4121 RVA: 0x0000BCC6 File Offset: 0x00009EC6
		public static double ExpoEaseOut(double t, double b, double c, double d)
		{
			if (t != d)
			{
				return c * (-Math.Pow(2.0, -10.0 * t / d) + 1.0) + b;
			}
			return b + c;
		}

		// Token: 0x0600101A RID: 4122 RVA: 0x0000BCFA File Offset: 0x00009EFA
		public static double ExpoEaseIn(double t, double b, double c, double d)
		{
			if (t != 0.0)
			{
				return c * Math.Pow(2.0, 10.0 * (t / d - 1.0)) + b;
			}
			return b;
		}

		// Token: 0x0600101B RID: 4123 RVA: 0x00065F20 File Offset: 0x00064120
		public static double ExpoEaseInOut(double t, double b, double c, double d)
		{
			if (t == 0.0)
			{
				return b;
			}
			if (t == d)
			{
				return b + c;
			}
			if ((t /= d / 2.0) < 1.0)
			{
				return c / 2.0 * Math.Pow(2.0, 10.0 * (t - 1.0)) + b;
			}
			return c / 2.0 * (-Math.Pow(2.0, -10.0 * (t -= 1.0)) + 2.0) + b;
		}

		// Token: 0x0600101C RID: 4124 RVA: 0x00065FD0 File Offset: 0x000641D0
		public static double ExpoEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.ExpoEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.ExpoEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x0600101D RID: 4125 RVA: 0x0000BD33 File Offset: 0x00009F33
		public static double CircEaseOut(double t, double b, double c, double d)
		{
			return c * Math.Sqrt(1.0 - (t = t / d - 1.0) * t) + b;
		}

		// Token: 0x0600101E RID: 4126 RVA: 0x0000BD5A File Offset: 0x00009F5A
		public static double CircEaseIn(double t, double b, double c, double d)
		{
			return -c * (Math.Sqrt(1.0 - (t /= d) * t) - 1.0) + b;
		}

		// Token: 0x0600101F RID: 4127 RVA: 0x00066034 File Offset: 0x00064234
		public static double CircEaseInOut(double t, double b, double c, double d)
		{
			if ((t /= d / 2.0) < 1.0)
			{
				return -c / 2.0 * (Math.Sqrt(1.0 - t * t) - 1.0) + b;
			}
			return c / 2.0 * (Math.Sqrt(1.0 - (t -= 2.0) * t) + 1.0) + b;
		}

		// Token: 0x06001020 RID: 4128 RVA: 0x000660C0 File Offset: 0x000642C0
		public static double CircEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.CircEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.CircEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x06001021 RID: 4129 RVA: 0x0000BD82 File Offset: 0x00009F82
		public static double QuadEaseOut(double t, double b, double c, double d)
		{
			return -c * (t /= d) * (t - 2.0) + b;
		}

		// Token: 0x06001022 RID: 4130 RVA: 0x0000BD9B File Offset: 0x00009F9B
		public static double QuadEaseIn(double t, double b, double c, double d)
		{
			return c * (t /= d) * t + b;
		}

		// Token: 0x06001023 RID: 4131 RVA: 0x00066124 File Offset: 0x00064324
		public static double QuadEaseInOut(double t, double b, double c, double d)
		{
			if ((t /= d / 2.0) < 1.0)
			{
				return c / 2.0 * t * t + b;
			}
			return -c / 2.0 * ((t -= 1.0) * (t - 2.0) - 1.0) + b;
		}

		// Token: 0x06001024 RID: 4132 RVA: 0x00066194 File Offset: 0x00064394
		public static double QuadEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.QuadEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.QuadEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x06001025 RID: 4133 RVA: 0x0000BDA9 File Offset: 0x00009FA9
		public static double SineEaseOut(double t, double b, double c, double d)
		{
			return c * Math.Sin(t / d * 1.5707963267948966) + b;
		}

		// Token: 0x06001026 RID: 4134 RVA: 0x0000BDC1 File Offset: 0x00009FC1
		public static double SineEaseIn(double t, double b, double c, double d)
		{
			return -c * Math.Cos(t / d * 1.5707963267948966) + c + b;
		}

		// Token: 0x06001027 RID: 4135 RVA: 0x000661F8 File Offset: 0x000643F8
		public static double SineEaseInOut(double t, double b, double c, double d)
		{
			if ((t /= d / 2.0) < 1.0)
			{
				return c / 2.0 * Math.Sin(3.141592653589793 * t / 2.0) + b;
			}
			return -c / 2.0 * (Math.Cos(3.141592653589793 * (t -= 1.0) / 2.0) - 2.0) + b;
		}

		// Token: 0x06001028 RID: 4136 RVA: 0x0006628C File Offset: 0x0006448C
		public static double SineEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.SineEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.SineEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x06001029 RID: 4137 RVA: 0x0000BDDC File Offset: 0x00009FDC
		public static double CubicEaseOut(double t, double b, double c, double d)
		{
			return c * ((t = t / d - 1.0) * t * t + 1.0) + b;
		}

		// Token: 0x0600102A RID: 4138 RVA: 0x0000BE00 File Offset: 0x0000A000
		public static double CubicEaseIn(double t, double b, double c, double d)
		{
			return c * (t /= d) * t * t + b;
		}

		// Token: 0x0600102B RID: 4139 RVA: 0x000662F0 File Offset: 0x000644F0
		public static double CubicEaseInOut(double t, double b, double c, double d)
		{
			if ((t /= d / 2.0) < 1.0)
			{
				return c / 2.0 * t * t * t + b;
			}
			return c / 2.0 * ((t -= 2.0) * t * t + 2.0) + b;
		}

		// Token: 0x0600102C RID: 4140 RVA: 0x00066358 File Offset: 0x00064558
		public static double CubicEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.CubicEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.CubicEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x0600102D RID: 4141 RVA: 0x0000BE10 File Offset: 0x0000A010
		public static double QuartEaseOut(double t, double b, double c, double d)
		{
			return -c * ((t = t / d - 1.0) * t * t * t - 1.0) + b;
		}

		// Token: 0x0600102E RID: 4142 RVA: 0x0000BE37 File Offset: 0x0000A037
		public static double QuartEaseIn(double t, double b, double c, double d)
		{
			return c * (t /= d) * t * t * t + b;
		}

		// Token: 0x0600102F RID: 4143 RVA: 0x000663BC File Offset: 0x000645BC
		public static double QuartEaseInOut(double t, double b, double c, double d)
		{
			if ((t /= d / 2.0) < 1.0)
			{
				return c / 2.0 * t * t * t * t + b;
			}
			return -c / 2.0 * ((t -= 2.0) * t * t * t - 2.0) + b;
		}

		// Token: 0x06001030 RID: 4144 RVA: 0x00066428 File Offset: 0x00064628
		public static double QuartEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.QuartEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.QuartEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x06001031 RID: 4145 RVA: 0x0000BE49 File Offset: 0x0000A049
		public static double QuintEaseOut(double t, double b, double c, double d)
		{
			return c * ((t = t / d - 1.0) * t * t * t * t + 1.0) + b;
		}

		// Token: 0x06001032 RID: 4146 RVA: 0x0000BE71 File Offset: 0x0000A071
		public static double QuintEaseIn(double t, double b, double c, double d)
		{
			return c * (t /= d) * t * t * t * t + b;
		}

		// Token: 0x06001033 RID: 4147 RVA: 0x0006648C File Offset: 0x0006468C
		public static double QuintEaseInOut(double t, double b, double c, double d)
		{
			if ((t /= d / 2.0) < 1.0)
			{
				return c / 2.0 * t * t * t * t * t + b;
			}
			return c / 2.0 * ((t -= 2.0) * t * t * t * t + 2.0) + b;
		}

		// Token: 0x06001034 RID: 4148 RVA: 0x000664FC File Offset: 0x000646FC
		public static double QuintEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.QuintEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.QuintEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x06001035 RID: 4149 RVA: 0x00066560 File Offset: 0x00064760
		public static double ElasticEaseOut(double t, double b, double c, double d)
		{
			if ((t /= d) == 1.0)
			{
				return b + c;
			}
			double num = d * 0.3;
			double num2 = num / 4.0;
			return c * Math.Pow(2.0, -10.0 * t) * Math.Sin((t * d - num2) * 6.283185307179586 / num) + c + b;
		}

		// Token: 0x06001036 RID: 4150 RVA: 0x000665D0 File Offset: 0x000647D0
		public static double ElasticEaseIn(double t, double b, double c, double d)
		{
			if ((t /= d) == 1.0)
			{
				return b + c;
			}
			double num = d * 0.3;
			double num2 = num / 4.0;
			return -(c * Math.Pow(2.0, 10.0 * (t -= 1.0)) * Math.Sin((t * d - num2) * 6.283185307179586 / num)) + b;
		}

		// Token: 0x06001037 RID: 4151 RVA: 0x0006664C File Offset: 0x0006484C
		public static double ElasticEaseInOut(double t, double b, double c, double d)
		{
			if ((t /= d / 2.0) == 2.0)
			{
				return b + c;
			}
			double num = d * 0.44999999999999996;
			double num2 = num / 4.0;
			if (t < 1.0)
			{
				return -0.5 * (c * Math.Pow(2.0, 10.0 * (t -= 1.0)) * Math.Sin((t * d - num2) * 6.283185307179586 / num)) + b;
			}
			return c * Math.Pow(2.0, -10.0 * (t -= 1.0)) * Math.Sin((t * d - num2) * 6.283185307179586 / num) * 0.5 + c + b;
		}

		// Token: 0x06001038 RID: 4152 RVA: 0x00066738 File Offset: 0x00064938
		public static double ElasticEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.ElasticEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.ElasticEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x06001039 RID: 4153 RVA: 0x0006679C File Offset: 0x0006499C
		public static double BounceEaseOut(double t, double b, double c, double d)
		{
			if ((t /= d) < 0.36363636363636365)
			{
				return c * (7.5625 * t * t) + b;
			}
			if (t < 0.7272727272727273)
			{
				return c * (7.5625 * (t -= 0.5454545454545454) * t + 0.75) + b;
			}
			if (t < 0.9090909090909091)
			{
				return c * (7.5625 * (t -= 0.8181818181818182) * t + 0.9375) + b;
			}
			return c * (7.5625 * (t -= 0.9545454545454546) * t + 0.984375) + b;
		}

		// Token: 0x0600103A RID: 4154 RVA: 0x0000BE85 File Offset: 0x0000A085
		public static double BounceEaseIn(double t, double b, double c, double d)
		{
			return c - PennerDoubleAnimation.BounceEaseOut(d - t, 0.0, c, d) + b;
		}

		// Token: 0x0600103B RID: 4155 RVA: 0x00066860 File Offset: 0x00064A60
		public static double BounceEaseInOut(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.BounceEaseIn(t * 2.0, 0.0, c, d) * 0.5 + b;
			}
			return PennerDoubleAnimation.BounceEaseOut(t * 2.0 - d, 0.0, c, d) * 0.5 + c * 0.5 + b;
		}

		// Token: 0x0600103C RID: 4156 RVA: 0x000668D8 File Offset: 0x00064AD8
		public static double BounceEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.BounceEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.BounceEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x0600103D RID: 4157 RVA: 0x0000BE9E File Offset: 0x0000A09E
		public static double BackEaseOut(double t, double b, double c, double d)
		{
			return c * ((t = t / d - 1.0) * t * (2.70158 * t + 1.70158) + 1.0) + b;
		}

		// Token: 0x0600103E RID: 4158 RVA: 0x0000BED6 File Offset: 0x0000A0D6
		public static double BackEaseIn(double t, double b, double c, double d)
		{
			return c * (t /= d) * t * (2.70158 * t - 1.70158) + b;
		}

		// Token: 0x0600103F RID: 4159 RVA: 0x0006693C File Offset: 0x00064B3C
		public static double BackEaseInOut(double t, double b, double c, double d)
		{
			double num = 1.70158;
			if ((t /= d / 2.0) < 1.0)
			{
				return c / 2.0 * (t * t * (((num *= 1.525) + 1.0) * t - num)) + b;
			}
			return c / 2.0 * ((t -= 2.0) * t * (((num *= 1.525) + 1.0) * t + num) + 2.0) + b;
		}

		// Token: 0x06001040 RID: 4160 RVA: 0x000669E0 File Offset: 0x00064BE0
		public static double BackEaseOutIn(double t, double b, double c, double d)
		{
			if (t < d / 2.0)
			{
				return PennerDoubleAnimation.BackEaseOut(t * 2.0, b, c / 2.0, d);
			}
			return PennerDoubleAnimation.BackEaseIn(t * 2.0 - d, b + c / 2.0, c / 2.0, d);
		}

		// Token: 0x06001041 RID: 4161 RVA: 0x0000BEFA File Offset: 0x0000A0FA
		private static void HandleEquationChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			(sender as PennerDoubleAnimation)._EasingMethod = typeof(PennerDoubleAnimation).GetMethod(e.NewValue.ToString());
		}

		// Token: 0x17000282 RID: 642
		// (get) Token: 0x06001042 RID: 4162 RVA: 0x0000BF22 File Offset: 0x0000A122
		// (set) Token: 0x06001043 RID: 4163 RVA: 0x0000BF34 File Offset: 0x0000A134
		[TypeConverter(typeof(PennerDoubleAnimationTypeConverter))]
		public PennerDoubleAnimation.Equations Equation
		{
			get
			{
				return (PennerDoubleAnimation.Equations)base.GetValue(PennerDoubleAnimation.EquationProperty);
			}
			set
			{
				base.SetValue(PennerDoubleAnimation.EquationProperty, value);
				this._EasingMethod = base.GetType().GetMethod(value.ToString());
			}
		}

		// Token: 0x17000283 RID: 643
		// (get) Token: 0x06001044 RID: 4164 RVA: 0x0000BF65 File Offset: 0x0000A165
		// (set) Token: 0x06001045 RID: 4165 RVA: 0x0000BF77 File Offset: 0x0000A177
		public double From
		{
			get
			{
				return (double)base.GetValue(PennerDoubleAnimation.FromProperty);
			}
			set
			{
				base.SetValue(PennerDoubleAnimation.FromProperty, value);
			}
		}

		// Token: 0x17000284 RID: 644
		// (get) Token: 0x06001046 RID: 4166 RVA: 0x0000BF8A File Offset: 0x0000A18A
		// (set) Token: 0x06001047 RID: 4167 RVA: 0x0000BF9C File Offset: 0x0000A19C
		public double To
		{
			get
			{
				return (double)base.GetValue(PennerDoubleAnimation.ToProperty);
			}
			set
			{
				base.SetValue(PennerDoubleAnimation.ToProperty, value);
			}
		}

		// Token: 0x04000AC0 RID: 2752
		private MethodInfo _EasingMethod;

		// Token: 0x04000AC1 RID: 2753
		public static readonly DependencyProperty EquationProperty = DependencyProperty.Register("Equation", typeof(PennerDoubleAnimation.Equations), typeof(PennerDoubleAnimation), new PropertyMetadata(PennerDoubleAnimation.Equations.Linear, new PropertyChangedCallback(PennerDoubleAnimation.HandleEquationChanged)));

		// Token: 0x04000AC2 RID: 2754
		public static readonly DependencyProperty FromProperty = DependencyProperty.Register("From", typeof(double), typeof(PennerDoubleAnimation), new PropertyMetadata(0.0));

		// Token: 0x04000AC3 RID: 2755
		public static readonly DependencyProperty ToProperty = DependencyProperty.Register("To", typeof(double), typeof(PennerDoubleAnimation), new PropertyMetadata(0.0));

		// Token: 0x0200019E RID: 414
		public enum Equations
		{
			// Token: 0x04000AC5 RID: 2757
			Linear,
			// Token: 0x04000AC6 RID: 2758
			QuadEaseOut,
			// Token: 0x04000AC7 RID: 2759
			QuadEaseIn,
			// Token: 0x04000AC8 RID: 2760
			QuadEaseInOut,
			// Token: 0x04000AC9 RID: 2761
			QuadEaseOutIn,
			// Token: 0x04000ACA RID: 2762
			ExpoEaseOut,
			// Token: 0x04000ACB RID: 2763
			ExpoEaseIn,
			// Token: 0x04000ACC RID: 2764
			ExpoEaseInOut,
			// Token: 0x04000ACD RID: 2765
			ExpoEaseOutIn,
			// Token: 0x04000ACE RID: 2766
			CubicEaseOut,
			// Token: 0x04000ACF RID: 2767
			CubicEaseIn,
			// Token: 0x04000AD0 RID: 2768
			CubicEaseInOut,
			// Token: 0x04000AD1 RID: 2769
			CubicEaseOutIn,
			// Token: 0x04000AD2 RID: 2770
			QuartEaseOut,
			// Token: 0x04000AD3 RID: 2771
			QuartEaseIn,
			// Token: 0x04000AD4 RID: 2772
			QuartEaseInOut,
			// Token: 0x04000AD5 RID: 2773
			QuartEaseOutIn,
			// Token: 0x04000AD6 RID: 2774
			QuintEaseOut,
			// Token: 0x04000AD7 RID: 2775
			QuintEaseIn,
			// Token: 0x04000AD8 RID: 2776
			QuintEaseInOut,
			// Token: 0x04000AD9 RID: 2777
			QuintEaseOutIn,
			// Token: 0x04000ADA RID: 2778
			CircEaseOut,
			// Token: 0x04000ADB RID: 2779
			CircEaseIn,
			// Token: 0x04000ADC RID: 2780
			CircEaseInOut,
			// Token: 0x04000ADD RID: 2781
			CircEaseOutIn,
			// Token: 0x04000ADE RID: 2782
			SineEaseOut,
			// Token: 0x04000ADF RID: 2783
			SineEaseIn,
			// Token: 0x04000AE0 RID: 2784
			SineEaseInOut,
			// Token: 0x04000AE1 RID: 2785
			SineEaseOutIn,
			// Token: 0x04000AE2 RID: 2786
			ElasticEaseOut,
			// Token: 0x04000AE3 RID: 2787
			ElasticEaseIn,
			// Token: 0x04000AE4 RID: 2788
			ElasticEaseInOut,
			// Token: 0x04000AE5 RID: 2789
			ElasticEaseOutIn,
			// Token: 0x04000AE6 RID: 2790
			BounceEaseOut,
			// Token: 0x04000AE7 RID: 2791
			BounceEaseIn,
			// Token: 0x04000AE8 RID: 2792
			BounceEaseInOut,
			// Token: 0x04000AE9 RID: 2793
			BounceEaseOutIn,
			// Token: 0x04000AEA RID: 2794
			BackEaseOut,
			// Token: 0x04000AEB RID: 2795
			BackEaseIn,
			// Token: 0x04000AEC RID: 2796
			BackEaseInOut,
			// Token: 0x04000AED RID: 2797
			BackEaseOutIn
		}
	}
}
