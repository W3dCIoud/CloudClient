﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000189 RID: 393
	public class NotificationsSettings : UserControl, IComponentConnector
	{
		// Token: 0x17000273 RID: 627
		// (get) Token: 0x06000F48 RID: 3912 RVA: 0x0000B2D6 File Offset: 0x000094D6
		// (set) Token: 0x06000F49 RID: 3913 RVA: 0x0000B2DD File Offset: 0x000094DD
		public static NotificationsSettings Instance { get; set; }

		// Token: 0x06000F4A RID: 3914 RVA: 0x0006227C File Offset: 0x0006047C
		public NotificationsSettings(MainWindow window)
		{
			NotificationsSettings.Instance = this;
			this.InitializeComponent();
			base.Visibility = Visibility.Hidden;
			this.mVmName = ((window != null) ? window.mVmName : null);
			this.mScroll.ScrollChanged += BluestacksUIColor.ScrollBarScrollChanged;
		}

		// Token: 0x06000F4B RID: 3915 RVA: 0x000622D8 File Offset: 0x000604D8
		private void NotificationSettings_Loaded(object sender, RoutedEventArgs e)
		{
			NotificationManager.Instance.ReloadNotificationDetails();
			this.mCustomNotifications.IsChecked = new bool?(false);
			this.mStackPanel.Visibility = Visibility.Hidden;
			this.mTbMuteAll.IsThreeStateCheckBox = true;
			this.mTbMuteAll.mMuteCheckBox.Group = "NotificationMute";
			this.mTbMuteAll.mAutoHideCheckBox.Group = "NotificationAutoHide";
			this.mTbMuteAll.HideAppLable();
			this.mUseInstalledApps.HideShowButton();
			this.mUseInstalledApps.HideAppLable();
			this.mUseInstalledApps.mAutoHideCheckBox.Unchecked += this.mCustomNotifications_Unchecked;
			this.mUseInstalledApps.mAutoHideCheckBox.Checked += this.mCustomNotifications_Checked;
			BlueStacksUIBinding.Bind(this.mUseInstalledApps.mAutoHideCheckBox, "STRING_CUSTOM_NOTIFICATION_SETTING");
			this.mShowRibbonNotification.HideShowButton();
			this.mShowRibbonNotification.HideAppLable();
			BlueStacksUIBinding.Bind(this.mShowRibbonNotification.mAutoHideCheckBox, "STRING_SHOW_RIBBON");
			this.mShowRibbonNotification.mAutoHideCheckBox.Unchecked += this.mShowRibbonNotification_Unchecked;
			this.mShowRibbonNotification.mAutoHideCheckBox.Checked += this.mShowRibbonNotification_Checked;
			this.mShowRibbonNotification.mAutoHideCheckBox.IsChecked = new bool?(RegistryManager.Instance.IsShowRibbonNotification);
			this.mShowToastNotification.HideShowButton();
			this.mShowToastNotification.HideAppLable();
			BlueStacksUIBinding.Bind(this.mShowToastNotification.mAutoHideCheckBox, "STRING_SHOW_TOAST");
			this.mShowToastNotification.mAutoHideCheckBox.Unchecked += this.mShowToastNotification_Unchecked;
			this.mShowToastNotification.mAutoHideCheckBox.Checked += this.mShowToastNotification_Checked;
			this.mShowToastNotification.mAutoHideCheckBox.IsChecked = new bool?(RegistryManager.Instance.IsShowToastNotification);
			this.mTbMuteAll.AppLabel = "STRING_SHOW_NOTIFICATIONS";
			BlueStacksUIBinding.Bind(this.mTbMuteAll.mMuteCheckBox, "STRING_SHOW_NOTIFICATIONS");
			this.mTbMuteAll.CheckBoxOrientation = Orientation.Horizontal;
			List<AppInfo> list = new JsonParser(this.mVmName).GetAppList().ToList<AppInfo>();
			List<string> list2 = new List<string>();
			this.AddNotificationToggleButton("BlueStacks", string.Empty);
			foreach (AppInfo appInfo in list)
			{
				if (!list2.Contains(appInfo.Package))
				{
					list2.Add(appInfo.Package);
					this.AddNotificationToggleButton(appInfo.Name, appInfo.Img);
				}
			}
		}

		// Token: 0x06000F4C RID: 3916 RVA: 0x00062578 File Offset: 0x00060778
		private void AddNotificationToggleButton(string name, string imageName)
		{
			CustomToggleButton customToggleButton = new CustomToggleButton();
			customToggleButton.mMuteCheckBox.Group = "NotificationMute";
			customToggleButton.mAutoHideCheckBox.Group = "NotificationAutoHide";
			customToggleButton.AppLabel = name;
			customToggleButton.CheckBoxOrientation = Orientation.Horizontal;
			string text = Path.Combine(RegistryStrings.GadgetDir, imageName);
			if (File.Exists(text))
			{
				customToggleButton.Image = CustomPictureBox.GetBitmapImage(text, "", true);
			}
			customToggleButton.Margin = new Thickness(0.0, 0.0, 0.0, 10.0);
			this.mStackPanel.Children.Add(customToggleButton);
		}

		// Token: 0x06000F4D RID: 3917 RVA: 0x0000B2E5 File Offset: 0x000094E5
		private void mCustomNotifications_Unchecked(object sender, RoutedEventArgs e)
		{
			this.mStackPanel.Visibility = Visibility.Hidden;
		}

		// Token: 0x06000F4E RID: 3918 RVA: 0x0000B2F3 File Offset: 0x000094F3
		private void mCustomNotifications_Checked(object sender, RoutedEventArgs e)
		{
			this.mStackPanel.Visibility = Visibility.Visible;
		}

		// Token: 0x06000F4F RID: 3919 RVA: 0x0000B301 File Offset: 0x00009501
		private void mShowRibbonNotification_Unchecked(object sender, RoutedEventArgs e)
		{
			RegistryManager.Instance.IsShowRibbonNotification = false;
		}

		// Token: 0x06000F50 RID: 3920 RVA: 0x0000B30E File Offset: 0x0000950E
		private void mShowRibbonNotification_Checked(object sender, RoutedEventArgs e)
		{
			RegistryManager.Instance.IsShowRibbonNotification = true;
		}

		// Token: 0x06000F51 RID: 3921 RVA: 0x0000B31B File Offset: 0x0000951B
		private void mShowToastNotification_Unchecked(object sender, RoutedEventArgs e)
		{
			RegistryManager.Instance.IsShowToastNotification = false;
		}

		// Token: 0x06000F52 RID: 3922 RVA: 0x0000B328 File Offset: 0x00009528
		private void mShowToastNotification_Checked(object sender, RoutedEventArgs e)
		{
			RegistryManager.Instance.IsShowToastNotification = true;
		}

		// Token: 0x06000F53 RID: 3923 RVA: 0x00062620 File Offset: 0x00060820
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/notificationssettings.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000F54 RID: 3924 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000F55 RID: 3925 RVA: 0x00062650 File Offset: 0x00060850
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((NotificationsSettings)target).Loaded += this.NotificationSettings_Loaded;
				return;
			case 2:
				this.mScroll = (ScrollViewer)target;
				return;
			case 3:
				this.mTbMuteAll = (CustomToggleButton)target;
				return;
			case 4:
				this.mShowRibbonNotification = (CustomToggleButton)target;
				return;
			case 5:
				this.mShowToastNotification = (CustomToggleButton)target;
				return;
			case 6:
				this.mCustomNotifications = (CustomCheckbox)target;
				this.mCustomNotifications.Unchecked += this.mCustomNotifications_Unchecked;
				this.mCustomNotifications.Checked += this.mCustomNotifications_Checked;
				return;
			case 7:
				this.mUseInstalledApps = (CustomToggleButton)target;
				return;
			case 8:
				this.mStackPanel = (StackPanel)target;
				return;
			case 9:
				this.mInfoIcon = (CustomPictureBox)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000A49 RID: 2633
		private string mVmName = "Android";

		// Token: 0x04000A4A RID: 2634
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ScrollViewer mScroll;

		// Token: 0x04000A4B RID: 2635
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomToggleButton mTbMuteAll;

		// Token: 0x04000A4C RID: 2636
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomToggleButton mShowRibbonNotification;

		// Token: 0x04000A4D RID: 2637
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomToggleButton mShowToastNotification;

		// Token: 0x04000A4E RID: 2638
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mCustomNotifications;

		// Token: 0x04000A4F RID: 2639
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomToggleButton mUseInstalledApps;

		// Token: 0x04000A50 RID: 2640
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mStackPanel;

		// Token: 0x04000A51 RID: 2641
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mInfoIcon;

		// Token: 0x04000A52 RID: 2642
		private bool _contentLoaded;
	}
}
