﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;
using BlueStacks.Common;
using Microsoft.VisualBasic.FileIO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000198 RID: 408
	public static class FileImporter
	{
		// Token: 0x06000FC3 RID: 4035 RVA: 0x0000B73A File Offset: 0x0000993A
		internal static void Init(MainWindow window)
		{
			window.AllowDrop = true;
			window.DragEnter += FileImporter.HandleDragEnter;
			window.Drop += FileImporter.HandleDragDrop;
		}

		// Token: 0x06000FC4 RID: 4036 RVA: 0x0000B767 File Offset: 0x00009967
		private static void HandleDragDrop(object sender, DragEventArgs e)
		{
			new Thread(delegate()
			{
				FileImporter.HandleDragDropAsync(e, sender as MainWindow);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000FC5 RID: 4037 RVA: 0x0000B798 File Offset: 0x00009998
		private static bool IsSharedFolderEnabled(int fileSystem)
		{
			if (fileSystem == 0)
			{
				Logger.Info("Shared folders disabled");
				return false;
			}
			return true;
		}

		// Token: 0x06000FC6 RID: 4038 RVA: 0x00065404 File Offset: 0x00063604
		private static void HandleDragDropAsync(DragEventArgs evt, MainWindow window)
		{
			string mVmName = window.mVmName;
			if (FileImporter.IsSharedFolderEnabled(window.EngineInstanceRegistry.FileSystem))
			{
				try
				{
					Array array = (Array)evt.Data.GetData(DataFormats.FileDrop);
					List<string> list = new List<string>();
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					for (int i = 0; i < array.Length; i++)
					{
						string text = array.GetValue(i).ToString();
						string fileName = Path.GetFileName(text);
						if (string.Equals(Path.GetExtension(text), ".apk", StringComparison.InvariantCultureIgnoreCase) || string.Equals(Path.GetExtension(text), ".xapk", StringComparison.InvariantCultureIgnoreCase))
						{
							list.Add(text);
						}
						else
						{
							dictionary.Add(fileName, text);
						}
					}
					string text2 = RegistryStrings.SharedFolderDir;
					if (dictionary.Count > 0)
					{
						string text3 = Utils.CreateRandomBstSharedFolder(text2);
						text2 = Path.Combine(RegistryStrings.SharedFolderDir, text3);
						Logger.Info("Shared Folder path : " + text2);
						foreach (KeyValuePair<string, string> keyValuePair in dictionary)
						{
							Logger.Info("DragDrop File: {0}", new object[]
							{
								keyValuePair.Key
							});
							string text4 = Path.Combine(text2, keyValuePair.Key);
							try
							{
								FileSystem.CopyFile(keyValuePair.Value, text4, UIOption.AllDialogs);
								File.SetAttributes(text4, FileAttributes.Normal);
							}
							catch (Exception ex)
							{
								Logger.Error("Failed to copy file : " + keyValuePair.Value + "...Err : " + ex.ToString());
							}
						}
						JArray jarray = new JArray
						{
							new JObject
							{
								new JProperty("foldername", text3)
							}
						};
						Dictionary<string, string> data = new Dictionary<string, string>
						{
							{
								"data",
								jarray.ToString(Formatting.None, new JsonConverter[0])
							}
						};
						Logger.Info("Sending drag drop request: " + jarray.ToString());
						try
						{
							HTTPUtils.SendRequestToGuest("fileDrop", data, mVmName, 0, null, false, 1, 0);
						}
						catch (Exception ex2)
						{
							Logger.Error("Failed to send FileDrop request. err: " + ex2.ToString());
						}
					}
					if (list.Count > 0)
					{
						foreach (string value in list)
						{
							try
							{
								Dictionary<string, string> data2 = new Dictionary<string, string>
								{
									{
										"filePath",
										value
									}
								};
								HTTPUtils.SendRequestToClient("dragDropInstall", data2, mVmName, 0, null, false, 1, 0);
							}
							catch (Exception ex3)
							{
								Logger.Warning("Failed to send drag drop install. Err: " + ex3.Message);
							}
						}
					}
				}
				catch (Exception ex4)
				{
					Logger.Error("Error in DragDrop function: " + ex4.Message);
				}
			}
		}

		// Token: 0x06000FC7 RID: 4039 RVA: 0x00065744 File Offset: 0x00063944
		public static void HandleDragEnter(object obj, DragEventArgs evt)
		{
			if (evt != null)
			{
				if (evt.Data.GetDataPresent(DataFormats.FileDrop))
				{
					evt.Effects = DragDropEffects.Copy;
					return;
				}
				Logger.Debug("FileDrop DataFormat not supported");
				string[] formats = evt.Data.GetFormats();
				Logger.Debug("Supported formats:");
				string[] array = formats;
				for (int i = 0; i < array.Length; i++)
				{
					Logger.Debug(array[i]);
				}
				evt.Effects = DragDropEffects.None;
			}
		}

		// Token: 0x06000FC8 RID: 4040 RVA: 0x000657AC File Offset: 0x000639AC
		public static string GetMimeFromFile(string filename)
		{
			string result = "";
			if (!File.Exists(filename))
			{
				return result;
			}
			byte[] array = new byte[256];
			using (FileStream fileStream = new FileStream(filename, FileMode.Open))
			{
				if (fileStream.Length >= 256L)
				{
					fileStream.Read(array, 0, 256);
				}
				else
				{
					fileStream.Read(array, 0, (int)fileStream.Length);
				}
			}
			try
			{
				uint num;
				NativeMethods.FindMimeFromData(0U, null, array, 256U, null, 0U, out num, 0U);
				IntPtr ptr = new IntPtr((long)((ulong)num));
				result = Marshal.PtrToStringUni(ptr);
				Marshal.FreeCoTaskMem(ptr);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to get mime type. err: " + ex.Message);
			}
			return result;
		}
	}
}
