﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000036 RID: 54
	[Serializable]
	public class AppPackageListObject
	{
		// Token: 0x1700011B RID: 283
		// (get) Token: 0x060002F1 RID: 753 RVA: 0x00003FC9 File Offset: 0x000021C9
		// (set) Token: 0x060002F2 RID: 754 RVA: 0x00003FD1 File Offset: 0x000021D1
		[JsonProperty(PropertyName = "app_pkg_list", DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate, NullValueHandling = NullValueHandling.Include)]
		public List<string> CloudPackageList { get; set; } = new List<string>();

		// Token: 0x060002F3 RID: 755 RVA: 0x00003FDA File Offset: 0x000021DA
		public AppPackageListObject(List<string> packageList)
		{
			this.CloudPackageList = packageList;
		}

		// Token: 0x060002F4 RID: 756 RVA: 0x00017700 File Offset: 0x00015900
		public bool IsPackageAvailable(string appPackage)
		{
			foreach (string text in this.CloudPackageList)
			{
				string text2 = text;
				if (text.EndsWith("*", StringComparison.InvariantCulture))
				{
					text2 = text.TrimEnd(new char[]
					{
						'*'
					});
				}
				if (text2.StartsWith("~", StringComparison.InvariantCulture))
				{
					if (appPackage.StartsWith(text2.Substring(1), StringComparison.InvariantCulture))
					{
						return false;
					}
				}
				else if (appPackage.StartsWith(text2, StringComparison.InvariantCulture))
				{
					return true;
				}
			}
			return false;
		}
	}
}
