﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200007E RID: 126
	public enum QuitActionItem
	{
		// Token: 0x040002A8 RID: 680
		None,
		// Token: 0x040002A9 RID: 681
		StuckAtBoot,
		// Token: 0x040002AA RID: 682
		SomethingElseWrong,
		// Token: 0x040002AB RID: 683
		SlowPerformance,
		// Token: 0x040002AC RID: 684
		WhyGoogleAccount,
		// Token: 0x040002AD RID: 685
		TroubleSigningIn,
		// Token: 0x040002AE RID: 686
		UnsureWhereStart,
		// Token: 0x040002AF RID: 687
		IssueInstallingGame,
		// Token: 0x040002B0 RID: 688
		FacingOtherTroubles
	}
}
