﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000234 RID: 564
	public class FullScreenTopBar : UserControl, IComponentConnector
	{
		// Token: 0x06001426 RID: 5158 RVA: 0x0000DCDB File Offset: 0x0000BEDB
		public FullScreenTopBar()
		{
			this.InitializeComponent();
		}

		// Token: 0x06001427 RID: 5159 RVA: 0x00079B6C File Offset: 0x00077D6C
		internal void Init(MainWindow window)
		{
			this.ParentWindow = window;
			if (!DesignerProperties.GetIsInDesignMode(this) && !RegistryManager.Instance.UseEscapeToExitFullScreen)
			{
				this.mEscCheckbox.ImageName = "checkbox_new";
			}
			this.transSlider.Value = RegistryManager.Instance.TranslucentControlsTransparency;
			if (FeatureManager.Instance.IsCustomUIForDMMSandbox)
			{
				this.mKeyMapSwitchFullScreen.Visibility = Visibility.Collapsed;
				this.mKeyMapButtonFullScreen.Visibility = Visibility.Collapsed;
				this.mLocationButtonFullScreen.Visibility = Visibility.Collapsed;
				this.mShakeButtonFullScreen.Visibility = Visibility.Collapsed;
				this.mGamePadButtonFullScreen.Visibility = Visibility.Collapsed;
				this.mTranslucentControlsButtonFullScreen.Visibility = Visibility.Collapsed;
			}
			this.mMacroRecorderFullScreen.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06001428 RID: 5160 RVA: 0x0000DCE9 File Offset: 0x0000BEE9
		private void BackButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.BackButtonHandler(false);
		}

		// Token: 0x06001429 RID: 5161 RVA: 0x0000DCFC File Offset: 0x0000BEFC
		private void HomeButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.HomeButtonHandler(true, false);
		}

		// Token: 0x0600142A RID: 5162 RVA: 0x00079C1C File Offset: 0x00077E1C
		private void SwitchKeyMapButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			ClientStats.SendMiscellaneousStatsAsync("SwitchKeyMapClicked", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "fullscreentopbar", null, null, null, null, null);
		}

		// Token: 0x0600142B RID: 5163 RVA: 0x0000DD10 File Offset: 0x0000BF10
		private void KeyMapButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mTopBarPopup.IsOpen = false;
			this.ParentWindow.mCommonHandler.KeyMapButtonHandler("MouseClick", "fullscreentopbar");
		}

		// Token: 0x0600142C RID: 5164 RVA: 0x0000DD3D File Offset: 0x0000BF3D
		private void FullScreenButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.FullScreenButtonHandler("fullScreenTopbar", "MouseClick");
		}

		// Token: 0x0600142D RID: 5165 RVA: 0x0000DD59 File Offset: 0x0000BF59
		private void LocationButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.LocationButtonHandler();
		}

		// Token: 0x0600142E RID: 5166 RVA: 0x0000DD6B File Offset: 0x0000BF6B
		private void ScreenShotButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mTopBarPopup.IsOpen = false;
			this.ParentWindow.mCommonHandler.ScreenShotButtonHandler();
		}

		// Token: 0x0600142F RID: 5167 RVA: 0x0000DD8E File Offset: 0x0000BF8E
		private void ShakeButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.ShakeButtonHandler();
		}

		// Token: 0x06001430 RID: 5168 RVA: 0x00079C54 File Offset: 0x00077E54
		private void mEscCheckbox_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (RegistryManager.Instance.UseEscapeToExitFullScreen)
			{
				this.mEscCheckbox.ImageName = "checkbox_new";
				RegistryManager.Instance.UseEscapeToExitFullScreen = false;
				return;
			}
			this.mEscCheckbox.ImageName = "checkbox_new_checked";
			RegistryManager.Instance.UseEscapeToExitFullScreen = true;
		}

		// Token: 0x06001431 RID: 5169 RVA: 0x0000DDA0 File Offset: 0x0000BFA0
		private void mMacroRecorderLandscape_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.ShowMacroRecorderWindow();
		}

		// Token: 0x06001432 RID: 5170 RVA: 0x0000DDB2 File Offset: 0x0000BFB2
		private void GamePadButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mTopBarPopup.IsOpen = false;
		}

		// Token: 0x06001433 RID: 5171 RVA: 0x00079CA4 File Offset: 0x00077EA4
		private void TranslucentControlsButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			RegistryManager.Instance.ShowKeyControlsOverlay = true;
			RegistryManager.Instance.OverlayAvailablePromptEnabled = false;
			KMManager.ShowOverlayWindow(this.ParentWindow, true, true);
			this.mChangeTransparencyPopup.PlacementTarget = this.mTranslucentControlsButtonFullScreen;
			this.mChangeTransparencyPopup.IsOpen = true;
		}

		// Token: 0x06001434 RID: 5172 RVA: 0x00079CF4 File Offset: 0x00077EF4
		private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			KMManager.ChangeTransparency(this.ParentWindow, this.transSlider.Value);
			if (this.transSlider.Value == 0.0)
			{
				if (!RegistryManager.Instance.ShowKeyControlsOverlay)
				{
					KMManager.ShowOverlayWindow(this.ParentWindow, false, false);
				}
				this.ParentWindow.mCommonHandler.OnOverlayStateChanged(false);
			}
			else
			{
				KMManager.ShowOverlayWindow(this.ParentWindow, true, false);
				this.ParentWindow.mCommonHandler.OnOverlayStateChanged(true);
			}
			this.lastSliderValue = this.transSlider.Value;
		}

		// Token: 0x06001435 RID: 5173 RVA: 0x00079D88 File Offset: 0x00077F88
		private void mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.transSlider.Value == 0.0)
			{
				this.transSlider.Value = this.lastSliderValue;
				return;
			}
			double value = this.transSlider.Value;
			this.transSlider.Value = 0.0;
			this.lastSliderValue = value;
		}

		// Token: 0x06001436 RID: 5174 RVA: 0x0000DDC5 File Offset: 0x0000BFC5
		private void mChangeTransparencyPopup_Closed(object sender, EventArgs e)
		{
			if (!this.ParentWindow.mFullScreenTopBar.IsMouseOver)
			{
				this.ParentWindow.mTopBarPopup.IsOpen = false;
			}
		}

		// Token: 0x06001437 RID: 5175 RVA: 0x00079DE4 File Offset: 0x00077FE4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/fullscreentopbar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06001438 RID: 5176 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06001439 RID: 5177 RVA: 0x00079E14 File Offset: 0x00078014
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((CustomPictureBox)target).PreviewMouseLeftButtonUp += this.BackButton_PreviewMouseLeftButtonUp;
				return;
			case 2:
				((CustomPictureBox)target).PreviewMouseLeftButtonUp += this.HomeButton_PreviewMouseLeftButtonUp;
				return;
			case 3:
				this.mEscCheckbox = (CustomPictureBox)target;
				this.mEscCheckbox.MouseLeftButtonUp += this.mEscCheckbox_MouseLeftButtonUp;
				return;
			case 4:
				this.mGamePadButtonFullScreen = (CustomPictureBox)target;
				this.mGamePadButtonFullScreen.PreviewMouseLeftButtonUp += this.GamePadButton_PreviewMouseLeftButtonUp;
				return;
			case 5:
				this.mMacroRecorderFullScreen = (CustomPictureBox)target;
				this.mMacroRecorderFullScreen.PreviewMouseLeftButtonUp += this.mMacroRecorderLandscape_PreviewMouseLeftButtonUp;
				return;
			case 6:
				this.mKeyMapSwitchFullScreen = (CustomPictureBox)target;
				this.mKeyMapSwitchFullScreen.PreviewMouseLeftButtonUp += this.SwitchKeyMapButton_PreviewMouseLeftButtonUp;
				return;
			case 7:
				this.mKeyMapButtonFullScreen = (CustomPictureBox)target;
				this.mKeyMapButtonFullScreen.PreviewMouseLeftButtonUp += this.KeyMapButton_PreviewMouseLeftButtonUp;
				return;
			case 8:
				this.mTranslucentControlsButtonFullScreen = (CustomPictureBox)target;
				this.mTranslucentControlsButtonFullScreen.PreviewMouseLeftButtonUp += this.TranslucentControlsButton_PreviewMouseLeftButtonUp;
				return;
			case 9:
				this.mFullScreenButton = (CustomPictureBox)target;
				this.mFullScreenButton.PreviewMouseLeftButtonUp += this.FullScreenButton_PreviewMouseLeftButtonUp;
				return;
			case 10:
				this.mLocationButtonFullScreen = (CustomPictureBox)target;
				this.mLocationButtonFullScreen.PreviewMouseLeftButtonUp += this.LocationButton_PreviewMouseLeftButtonUp;
				return;
			case 11:
				((CustomPictureBox)target).PreviewMouseLeftButtonUp += this.ScreenShotButton_PreviewMouseLeftButtonUp;
				return;
			case 12:
				this.mShakeButtonFullScreen = (CustomPictureBox)target;
				this.mShakeButtonFullScreen.PreviewMouseLeftButtonUp += this.ShakeButton_PreviewMouseLeftButtonUp;
				return;
			case 13:
				this.mChangeTransparencyPopup = (CustomPopUp)target;
				return;
			case 14:
				this.borderSlider = (Border)target;
				return;
			case 15:
				this.mTranslucentControlsSliderButton = (CustomPictureBox)target;
				this.mTranslucentControlsSliderButton.PreviewMouseLeftButtonUp += this.mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp;
				return;
			case 16:
				this.transSlider = (Slider)target;
				this.transSlider.ValueChanged += this.Slider_ValueChanged;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000CAB RID: 3243
		private MainWindow ParentWindow;

		// Token: 0x04000CAC RID: 3244
		private double lastSliderValue;

		// Token: 0x04000CAD RID: 3245
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mEscCheckbox;

		// Token: 0x04000CAE RID: 3246
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mGamePadButtonFullScreen;

		// Token: 0x04000CAF RID: 3247
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mMacroRecorderFullScreen;

		// Token: 0x04000CB0 RID: 3248
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mKeyMapSwitchFullScreen;

		// Token: 0x04000CB1 RID: 3249
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mKeyMapButtonFullScreen;

		// Token: 0x04000CB2 RID: 3250
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mTranslucentControlsButtonFullScreen;

		// Token: 0x04000CB3 RID: 3251
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mFullScreenButton;

		// Token: 0x04000CB4 RID: 3252
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mLocationButtonFullScreen;

		// Token: 0x04000CB5 RID: 3253
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mShakeButtonFullScreen;

		// Token: 0x04000CB6 RID: 3254
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mChangeTransparencyPopup;

		// Token: 0x04000CB7 RID: 3255
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border borderSlider;

		// Token: 0x04000CB8 RID: 3256
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mTranslucentControlsSliderButton;

		// Token: 0x04000CB9 RID: 3257
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Slider transSlider;

		// Token: 0x04000CBA RID: 3258
		private bool _contentLoaded;
	}
}
