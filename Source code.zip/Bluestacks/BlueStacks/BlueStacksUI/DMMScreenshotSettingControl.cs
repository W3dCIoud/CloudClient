﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000FE RID: 254
	public class DMMScreenshotSettingControl : UserControl, IComponentConnector
	{
		// Token: 0x060009EF RID: 2543 RVA: 0x0000841A File Offset: 0x0000661A
		public DMMScreenshotSettingControl(MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			base.Visibility = Visibility.Hidden;
			this.mChooseFolderTextBlock.Text = RegistryManager.Instance.ScreenShotsPath;
		}

		// Token: 0x060009F0 RID: 2544 RVA: 0x0000844B File Offset: 0x0000664B
		private void ChooseScreenshotFolder_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.DMMScreenshotHandler();
			this.mChooseFolderTextBlock.Text = RegistryManager.Instance.ScreenShotsPath;
		}

		// Token: 0x060009F1 RID: 2545 RVA: 0x00039F0C File Offset: 0x0003810C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/dmmscreenshotsettingcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060009F2 RID: 2546 RVA: 0x00008472 File Offset: 0x00006672
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mChooseFolderTextBlock = (TextBox)target;
				return;
			}
			if (connectionId != 2)
			{
				this._contentLoaded = true;
				return;
			}
			((Grid)target).PreviewMouseLeftButtonUp += this.ChooseScreenshotFolder_MouseLeftButtonUp;
		}

		// Token: 0x04000645 RID: 1605
		private MainWindow ParentWindow;

		// Token: 0x04000646 RID: 1606
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBox mChooseFolderTextBlock;

		// Token: 0x04000647 RID: 1607
		private bool _contentLoaded;
	}
}
