﻿using System;
using System.Collections.Generic;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000038 RID: 56
	public class BrowserSubscriber : ISubscriber
	{
		// Token: 0x1700011D RID: 285
		// (get) Token: 0x060002F8 RID: 760 RVA: 0x00004005 File Offset: 0x00002205
		// (set) Token: 0x060002F9 RID: 761 RVA: 0x0000400D File Offset: 0x0000220D
		public string CallbackFunction { get; set; }

		// Token: 0x060002FA RID: 762 RVA: 0x000177A4 File Offset: 0x000159A4
		public BrowserSubscriber(BrowserControl control)
		{
			this.mControl = control;
			foreach (BrowserControlTags args in ((control != null) ? control.TagsSubscribed : null))
			{
				this.SubscribeTag(args);
			}
		}

		// Token: 0x060002FB RID: 763 RVA: 0x00017818 File Offset: 0x00015A18
		public void SubscribeTag(BrowserControlTags args)
		{
			switch (args)
			{
			case BrowserControlTags.bootComplete:
				this.mTokens[BrowserControlTags.bootComplete] = EventAggregator.Subscribe<BootCompleteEventArgs>(new Action<BootCompleteEventArgs>(this.Message));
				return;
			case BrowserControlTags.googleSigninComplete:
				this.mTokens[BrowserControlTags.googleSigninComplete] = EventAggregator.Subscribe<GoogleSignInCompleteEventArgs>(new Action<GoogleSignInCompleteEventArgs>(this.Message));
				return;
			case BrowserControlTags.appPlayerClosing:
				this.mTokens[BrowserControlTags.appPlayerClosing] = EventAggregator.Subscribe<AppPlayerClosingEventArgs>(new Action<AppPlayerClosingEventArgs>(this.Message));
				return;
			case BrowserControlTags.tabClosing:
				this.mTokens[BrowserControlTags.tabClosing] = EventAggregator.Subscribe<TabClosingEventArgs>(new Action<TabClosingEventArgs>(this.Message));
				return;
			case BrowserControlTags.tabSwitched:
				this.mTokens[BrowserControlTags.tabSwitched] = EventAggregator.Subscribe<TabSwitchedEventArgs>(new Action<TabSwitchedEventArgs>(this.Message));
				return;
			case BrowserControlTags.appInstalled:
				this.mTokens[BrowserControlTags.appInstalled] = EventAggregator.Subscribe<AppInstalledEventArgs>(new Action<AppInstalledEventArgs>(this.Message));
				return;
			case BrowserControlTags.appUninstalled:
				this.mTokens[BrowserControlTags.appUninstalled] = EventAggregator.Subscribe<AppUninstalledEventArgs>(new Action<AppUninstalledEventArgs>(this.Message));
				return;
			default:
				return;
			}
		}

		// Token: 0x060002FC RID: 764 RVA: 0x00017920 File Offset: 0x00015B20
		public void UnsubscribeTag(BrowserControlTags args)
		{
			switch (args)
			{
			case BrowserControlTags.bootComplete:
				EventAggregator.Unsubscribe<BootCompleteEventArgs>((Subscription<BootCompleteEventArgs>)this.mTokens[BrowserControlTags.bootComplete]);
				return;
			case BrowserControlTags.googleSigninComplete:
				EventAggregator.Unsubscribe<GoogleSignInCompleteEventArgs>((Subscription<GoogleSignInCompleteEventArgs>)this.mTokens[BrowserControlTags.googleSigninComplete]);
				return;
			case BrowserControlTags.appPlayerClosing:
				EventAggregator.Unsubscribe<AppPlayerClosingEventArgs>((Subscription<AppPlayerClosingEventArgs>)this.mTokens[BrowserControlTags.appPlayerClosing]);
				return;
			case BrowserControlTags.tabClosing:
				EventAggregator.Unsubscribe<TabClosingEventArgs>((Subscription<TabClosingEventArgs>)this.mTokens[BrowserControlTags.tabClosing]);
				return;
			case BrowserControlTags.tabSwitched:
				EventAggregator.Unsubscribe<TabSwitchedEventArgs>((Subscription<TabSwitchedEventArgs>)this.mTokens[BrowserControlTags.tabSwitched]);
				return;
			case BrowserControlTags.appInstalled:
				EventAggregator.Unsubscribe<AppInstalledEventArgs>((Subscription<AppInstalledEventArgs>)this.mTokens[BrowserControlTags.appInstalled]);
				return;
			case BrowserControlTags.appUninstalled:
				EventAggregator.Unsubscribe<AppUninstalledEventArgs>((Subscription<AppUninstalledEventArgs>)this.mTokens[BrowserControlTags.appUninstalled]);
				return;
			default:
				return;
			}
		}

		// Token: 0x060002FD RID: 765 RVA: 0x000179F0 File Offset: 0x00015BF0
		public void Message(EventArgs eventArgs)
		{
			BrowserEventArgs browserEventArgs = eventArgs as BrowserEventArgs;
			JObject jobject = new JObject();
			jobject["eventRaised"] = ((browserEventArgs != null) ? browserEventArgs.ClientTag.ToString() : null);
			jobject["packageName"] = ((browserEventArgs != null) ? browserEventArgs.mPackageName : null);
			jobject["vmName"] = ((browserEventArgs != null) ? browserEventArgs.mVmName : null);
			Console.WriteLine(jobject);
			this.mControl.CallBackToHtml(this.CallbackFunction, jobject.ToString(Formatting.None, new JsonConverter[0]));
		}

		// Token: 0x040001A2 RID: 418
		private BrowserControl mControl;

		// Token: 0x040001A3 RID: 419
		private Dictionary<BrowserControlTags, object> mTokens = new Dictionary<BrowserControlTags, object>();
	}
}
