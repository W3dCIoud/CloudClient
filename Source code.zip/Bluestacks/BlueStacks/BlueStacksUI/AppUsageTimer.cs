﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using BlueStacks.Common;
using Microsoft.Win32;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200008A RID: 138
	public static class AppUsageTimer
	{
		// Token: 0x06000561 RID: 1377 RVA: 0x000058CB File Offset: 0x00003ACB
		internal static void StartTimer(string vmName, string packageName)
		{
			AppUsageTimer.StopTimer();
			AppUsageTimer.sLastAppPackage = packageName;
			AppUsageTimer.sLastVMName = vmName;
			AppUsageTimer.sStopwatch.Reset();
			AppUsageTimer.sStopwatch.Start();
		}

		// Token: 0x06000562 RID: 1378 RVA: 0x000203E8 File Offset: 0x0001E5E8
		internal static void StopTimer()
		{
			if (AppUsageTimer.sStopwatch.IsRunning && !string.IsNullOrEmpty(AppUsageTimer.sLastAppPackage))
			{
				AppUsageTimer.sStopwatch.Stop();
				long num = (long)AppUsageTimer.sStopwatch.Elapsed.TotalSeconds;
				if (AppUsageTimer.sDictAppUsageInfo.ContainsKey(AppUsageTimer.sLastVMName))
				{
					Dictionary<string, long> dictionary;
					if (AppUsageTimer.sDictAppUsageInfo[AppUsageTimer.sLastVMName].ContainsKey(AppUsageTimer.sLastAppPackage))
					{
						dictionary = AppUsageTimer.sDictAppUsageInfo[AppUsageTimer.sLastVMName];
						string key = AppUsageTimer.sLastAppPackage;
						dictionary[key] += num;
					}
					else
					{
						AppUsageTimer.sDictAppUsageInfo[AppUsageTimer.sLastVMName].Add(AppUsageTimer.sLastAppPackage, num);
					}
					dictionary = AppUsageTimer.sDictAppUsageInfo[AppUsageTimer.sLastVMName];
					dictionary["TotalUsage"] = dictionary["TotalUsage"] + num;
				}
				else
				{
					AppUsageTimer.sDictAppUsageInfo.Add(AppUsageTimer.sLastVMName, new Dictionary<string, long>
					{
						{
							"TotalUsage",
							num
						}
					});
					AppUsageTimer.sDictAppUsageInfo[AppUsageTimer.sLastVMName].Add(AppUsageTimer.sLastAppPackage, num);
				}
				AppUsageTimer.sLastAppPackage = string.Empty;
			}
		}

		// Token: 0x06000563 RID: 1379 RVA: 0x00020510 File Offset: 0x0001E710
		internal static Dictionary<string, Dictionary<string, long>> GetRealtimeDictionary()
		{
			if (AppUsageTimer.sStopwatch.IsRunning && !string.IsNullOrEmpty(AppUsageTimer.sLastAppPackage))
			{
				Dictionary<string, Dictionary<string, long>> dictionary = new Dictionary<string, Dictionary<string, long>>();
				foreach (KeyValuePair<string, Dictionary<string, long>> keyValuePair in AppUsageTimer.sDictAppUsageInfo)
				{
					dictionary.Add(keyValuePair.Key, keyValuePair.Value.ToDictionary((KeyValuePair<string, long> _) => _.Key, (KeyValuePair<string, long> _) => _.Value));
				}
				long num = (long)AppUsageTimer.sStopwatch.Elapsed.TotalSeconds;
				if (dictionary.ContainsKey(AppUsageTimer.sLastVMName))
				{
					Dictionary<string, long> dictionary2;
					if (dictionary[AppUsageTimer.sLastVMName].ContainsKey(AppUsageTimer.sLastAppPackage))
					{
						dictionary2 = dictionary[AppUsageTimer.sLastVMName];
						string key = AppUsageTimer.sLastAppPackage;
						dictionary2[key] += num;
					}
					else
					{
						dictionary[AppUsageTimer.sLastVMName].Add(AppUsageTimer.sLastAppPackage, num);
					}
					dictionary2 = dictionary[AppUsageTimer.sLastVMName];
					dictionary2["TotalUsage"] = dictionary2["TotalUsage"] + num;
				}
				else
				{
					dictionary.Add(AppUsageTimer.sLastVMName, new Dictionary<string, long>
					{
						{
							"TotalUsage",
							num
						}
					});
					dictionary[AppUsageTimer.sLastVMName].Add(AppUsageTimer.sLastAppPackage, num);
				}
				return dictionary;
			}
			return AppUsageTimer.sDictAppUsageInfo;
		}

		// Token: 0x06000564 RID: 1380 RVA: 0x000206B4 File Offset: 0x0001E8B4
		internal static long GetTotalTimeForPackageAcrossInstances(string packageName)
		{
			long num = 0L;
			try
			{
				Func<KeyValuePair<string, long>, bool> <>9__0;
				foreach (KeyValuePair<string, Dictionary<string, long>> keyValuePair in AppUsageTimer.sDictAppUsageInfo)
				{
					IEnumerable<KeyValuePair<string, long>> value = keyValuePair.Value;
					Func<KeyValuePair<string, long>, bool> predicate;
					if ((predicate = <>9__0) == null)
					{
						predicate = (<>9__0 = ((KeyValuePair<string, long> _) => string.Equals(_.Key, packageName, StringComparison.OrdinalIgnoreCase)));
					}
					IEnumerable<KeyValuePair<string, long>> source = value.Where(predicate);
					if (source.Any<KeyValuePair<string, long>>())
					{
						num += source.First<KeyValuePair<string, long>>().Value;
					}
				}
				if (!string.IsNullOrEmpty(AppUsageTimer.sLastAppPackage) && string.Compare(AppUsageTimer.sLastAppPackage, packageName, StringComparison.OrdinalIgnoreCase) == 0)
				{
					num += (long)AppUsageTimer.sStopwatch.Elapsed.TotalSeconds;
				}
				Logger.Debug("Total time for package " + packageName + " " + num.ToString());
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GetTotalTimeForPackageAcrossInstances. Err : " + ex.ToString());
			}
			return num;
		}

		// Token: 0x06000565 RID: 1381 RVA: 0x000207DC File Offset: 0x0001E9DC
		internal static long GetTotalTimeForAllPackages()
		{
			long num = 0L;
			try
			{
				foreach (KeyValuePair<string, Dictionary<string, long>> keyValuePair in AppUsageTimer.sDictAppUsageInfo)
				{
					long num2 = 0L;
					IEnumerable<KeyValuePair<string, long>> source = from _ in keyValuePair.Value
					where string.Compare(_.Key, "Home", StringComparison.OrdinalIgnoreCase) == 0
					select _;
					if (source.Any<KeyValuePair<string, long>>())
					{
						num2 += source.First<KeyValuePair<string, long>>().Value;
					}
					source = from _ in keyValuePair.Value
					where string.Compare(_.Key, "TotalUsage", StringComparison.OrdinalIgnoreCase) == 0
					select _;
					if (source.Any<KeyValuePair<string, long>>())
					{
						num += source.First<KeyValuePair<string, long>>().Value;
						num -= num2;
					}
				}
				if (!string.IsNullOrEmpty(AppUsageTimer.sLastAppPackage) && !string.Equals(AppUsageTimer.sLastAppPackage, "Home", StringComparison.InvariantCulture))
				{
					num += (long)AppUsageTimer.sStopwatch.Elapsed.TotalSeconds;
				}
				Logger.Debug("Total time for all packages " + num.ToString());
				if (num < 0L)
				{
					return 0L;
				}
				return num;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GetTotalTimeForAllPackages " + ex.ToString());
			}
			return 0L;
		}

		// Token: 0x06000566 RID: 1382 RVA: 0x00020968 File Offset: 0x0001EB68
		internal static long GetTotalTimeForPackageAfterReset(string packageName)
		{
			try
			{
				long totalTimeForPackageAcrossInstances = AppUsageTimer.GetTotalTimeForPackageAcrossInstances(packageName);
				if (totalTimeForPackageAcrossInstances < 0L)
				{
					return 0L;
				}
				return totalTimeForPackageAcrossInstances;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GetTotalTimeForPackageAfterReset. Err : " + ex.ToString());
			}
			return 0L;
		}

		// Token: 0x06000567 RID: 1383 RVA: 0x000058F2 File Offset: 0x00003AF2
		internal static void AddPackageForReset(string package, long time)
		{
			AppUsageTimer.sResetQuestDict[package] = time;
		}

		// Token: 0x06000568 RID: 1384 RVA: 0x00005900 File Offset: 0x00003B00
		internal static void SessionEventHandler()
		{
			SystemEvents.SessionSwitch += AppUsageTimer.sessionSwitchHandler;
		}

		// Token: 0x06000569 RID: 1385 RVA: 0x0000590C File Offset: 0x00003B0C
		private static void SystemEvents_SessionSwitch(object sender, SessionSwitchEventArgs e)
		{
			if (e.Reason == SessionSwitchReason.SessionLock)
			{
				AppUsageTimer.StopTimer();
				return;
			}
			if (e.Reason == SessionSwitchReason.SessionUnlock)
			{
				AppUsageTimer.StartTimerAfterResume();
			}
		}

		// Token: 0x0600056A RID: 1386 RVA: 0x0000592B File Offset: 0x00003B2B
		internal static void DetachSessionEventHandler()
		{
			SystemEvents.SessionSwitch -= AppUsageTimer.sessionSwitchHandler;
		}

		// Token: 0x0600056B RID: 1387 RVA: 0x000209B8 File Offset: 0x0001EBB8
		private static void StartTimerAfterResume()
		{
			try
			{
				if (BlueStacksUIUtils.DictWindows.ContainsKey(AppUsageTimer.sLastVMName))
				{
					MainWindow mainWindow = BlueStacksUIUtils.DictWindows[AppUsageTimer.sLastVMName];
					if (mainWindow != null && mainWindow.mTopBar.mAppTabButtons.SelectedTab != null)
					{
						AppUsageTimer.StartTimer(AppUsageTimer.sLastVMName, mainWindow.mTopBar.mAppTabButtons.SelectedTab.TabKey);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in starting timer after sleep. Err : " + ex.ToString());
			}
		}

		// Token: 0x0600056C RID: 1388 RVA: 0x00005937 File Offset: 0x00003B37
		internal static void SaveData()
		{
			AppUsageTimer.StopTimer();
			RegistryManager.Instance.AInfo = AppUsageTimer.EncryptString(JsonConvert.SerializeObject(AppUsageTimer.sDictAppUsageInfo));
		}

		// Token: 0x0600056D RID: 1389 RVA: 0x00020A44 File Offset: 0x0001EC44
		internal static string EncryptString(string encryptString)
		{
			string userGuid = RegistryManager.Instance.UserGuid;
			byte[] array = Encoding.Unicode.GetBytes(encryptString);
			Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(userGuid, AppUsageTimer.bytes);
			string result;
			using (Aes aes = Aes.Create())
			{
				aes.Key = rfc2898DeriveBytes.GetBytes(32);
				aes.IV = rfc2898DeriveBytes.GetBytes(16);
				using (MemoryStream memoryStream = new MemoryStream())
				{
					using (CryptoStream cryptoStream = new CryptoStream(memoryStream, aes.CreateEncryptor(), CryptoStreamMode.Write))
					{
						cryptoStream.Write(array, 0, array.Length);
						cryptoStream.Close();
						encryptString = Convert.ToBase64String(memoryStream.ToArray());
						result = encryptString;
					}
				}
			}
			return result;
		}

		// Token: 0x0600056E RID: 1390 RVA: 0x00020B18 File Offset: 0x0001ED18
		public static string DecryptString(string decryptString)
		{
			string userGuid = RegistryManager.Instance.UserGuid;
			decryptString = ((decryptString != null) ? decryptString.Replace(" ", "+") : null);
			byte[] array = Convert.FromBase64String(decryptString);
			Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(userGuid, AppUsageTimer.bytes);
			string result;
			using (Aes aes = Aes.Create())
			{
				aes.Key = rfc2898DeriveBytes.GetBytes(32);
				aes.IV = rfc2898DeriveBytes.GetBytes(16);
				using (MemoryStream memoryStream = new MemoryStream())
				{
					using (CryptoStream cryptoStream = new CryptoStream(memoryStream, aes.CreateDecryptor(), CryptoStreamMode.Write))
					{
						cryptoStream.Write(array, 0, array.Length);
						cryptoStream.Close();
						decryptString = Encoding.Unicode.GetString(memoryStream.ToArray());
						result = decryptString;
					}
				}
			}
			return result;
		}

		// Token: 0x040002E2 RID: 738
		internal static Dictionary<string, Dictionary<string, long>> sDictAppUsageInfo = new Dictionary<string, Dictionary<string, long>>();

		// Token: 0x040002E3 RID: 739
		private static Dictionary<string, long> sResetQuestDict = new Dictionary<string, long>();

		// Token: 0x040002E4 RID: 740
		private static Stopwatch sStopwatch = new Stopwatch();

		// Token: 0x040002E5 RID: 741
		private static string sLastAppPackage = null;

		// Token: 0x040002E6 RID: 742
		private static string sLastVMName = null;

		// Token: 0x040002E7 RID: 743
		private static SessionSwitchEventHandler sessionSwitchHandler = new SessionSwitchEventHandler(AppUsageTimer.SystemEvents_SessionSwitch);

		// Token: 0x040002E8 RID: 744
		private static readonly byte[] bytes = new byte[]
		{
			73,
			118,
			97,
			110,
			32,
			77,
			101,
			100,
			118,
			101,
			100,
			101,
			118
		};
	}
}
