﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000B1 RID: 177
	public class SettingsWindowDropdown : UserControl, IComponentConnector
	{
		// Token: 0x06000701 RID: 1793 RVA: 0x00006854 File Offset: 0x00004A54
		public SettingsWindowDropdown()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000702 RID: 1794 RVA: 0x00006862 File Offset: 0x00004A62
		internal void Init(MainWindow window)
		{
			this.ParentWindow = window;
		}

		// Token: 0x06000703 RID: 1795 RVA: 0x00029BA0 File Offset: 0x00027DA0
		private void Grid_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
			foreach (object obj in (sender as Grid).Children)
			{
				UIElement uielement = (UIElement)obj;
				if (uielement is CustomPictureBox)
				{
					(uielement as CustomPictureBox).ImageName = (uielement as CustomPictureBox).ImageName + "_hover";
				}
				if (uielement is TextBlock)
				{
					BlueStacksUIBinding.BindColor(uielement as TextBlock, Control.ForegroundProperty, "SettingsWindowTabMenuItemSelectedForeground");
				}
			}
		}

		// Token: 0x06000704 RID: 1796 RVA: 0x00029C54 File Offset: 0x00027E54
		private void Grid_MouseLeave(object sender, MouseEventArgs e)
		{
			(sender as Grid).Background = Brushes.Transparent;
			foreach (object obj in (sender as Grid).Children)
			{
				UIElement uielement = (UIElement)obj;
				if (uielement is CustomPictureBox)
				{
					(uielement as CustomPictureBox).ImageName = (uielement as CustomPictureBox).ImageName.Replace("_hover", "");
				}
				if (uielement is TextBlock)
				{
					BlueStacksUIBinding.BindColor(uielement as TextBlock, Control.ForegroundProperty, "SettingsWindowTabMenuItemForeground");
				}
			}
		}

		// Token: 0x06000705 RID: 1797 RVA: 0x0000686B File Offset: 0x00004A6B
		private void SettingsButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mNCTopBar.mSettingsDropdownPopup.IsOpen = false;
			this.ParentWindow.mCommonHandler.LaunchSettingsWindow();
		}

		// Token: 0x06000706 RID: 1798 RVA: 0x00029D08 File Offset: 0x00027F08
		private void FullscreenButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mNCTopBar.mSettingsDropdownPopup.IsOpen = false;
			if (!this.ParentWindow.mResizeHandler.IsMinMaxEnabled)
			{
				return;
			}
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (FeatureManager.Instance.IsCustomUIForDMM || this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.mTabType == TabType.AppTab)
				{
					if (this.ParentWindow.mIsFullScreen)
					{
						this.ParentWindow.RestoreWindows(false);
						return;
					}
					this.ParentWindow.FullScreenWindow();
				}
			}), new object[0]);
		}

		// Token: 0x06000707 RID: 1799 RVA: 0x00006893 File Offset: 0x00004A93
		private void SortingButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mNCTopBar.mSettingsDropdownPopup.IsOpen = false;
			CommonHandlers.ArrangeWindow();
		}

		// Token: 0x06000708 RID: 1800 RVA: 0x00029D64 File Offset: 0x00027F64
		private void AccountButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mNCTopBar.mSettingsDropdownPopup.IsOpen = false;
			if (this.ParentWindow.mGuestBootCompleted)
			{
				this.ParentWindow.mTopBar.mAppTabButtons.AddAppTab("STRING_ACCOUNT", BlueStacksUIUtils.sAndroidSettingsPackageName, BlueStacksUIUtils.sAndroidAccountSettingsActivityName, "account_tab", true, true, false);
			}
		}

		// Token: 0x06000709 RID: 1801 RVA: 0x00029DC0 File Offset: 0x00027FC0
		private void PinOnTop_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			CustomPictureBox customPictureBox = sender as CustomPictureBox;
			if (customPictureBox.ImageName.Contains("_off"))
			{
				customPictureBox.ImageName = "toggle_on";
				this.ParentWindow.EngineInstanceRegistry.IsClientOnTop = true;
				this.ParentWindow.Topmost = true;
				return;
			}
			customPictureBox.ImageName = "toggle_off";
			this.ParentWindow.EngineInstanceRegistry.IsClientOnTop = false;
			this.ParentWindow.Topmost = false;
		}

		// Token: 0x0600070A RID: 1802 RVA: 0x00029E38 File Offset: 0x00028038
		internal void LateInit()
		{
			if (BlueStacksUIUtils.DictWindows.Keys.Count == 1)
			{
				this.mSyncOperationsButtonGrid.PreviewMouseLeftButtonUp -= this.SyncOperationsButton_PreviewMouseLeftButtonUp;
				this.mSyncOperationsButtonGrid.MouseEnter -= this.Grid_MouseEnter;
				this.mSyncOperationsButtonGrid.Opacity = 0.5;
				this.mSortingGrid.PreviewMouseLeftButtonUp -= this.SortingButton_MouseLeftButtonUp;
				this.mSortingGrid.MouseEnter -= this.Grid_MouseEnter;
				this.mSortingGrid.Opacity = 0.5;
			}
			else
			{
				this.mSortingGrid.PreviewMouseLeftButtonUp -= this.SortingButton_MouseLeftButtonUp;
				this.mSortingGrid.PreviewMouseLeftButtonUp += this.SortingButton_MouseLeftButtonUp;
				this.mSortingGrid.MouseEnter -= this.Grid_MouseEnter;
				this.mSortingGrid.MouseEnter += this.Grid_MouseEnter;
				this.mSortingGrid.Opacity = 1.0;
				if ((BlueStacksUIUtils.sSyncInvolvedInstances.Contains(this.ParentWindow.mVmName) && this.ParentWindow.mIsSyncMaster) || (!BlueStacksUIUtils.sSyncInvolvedInstances.Contains(this.ParentWindow.mVmName) && BlueStacksUIUtils.DictWindows.Keys.Count - BlueStacksUIUtils.sSyncInvolvedInstances.Count > 1))
				{
					this.mSyncOperationsButtonGrid.PreviewMouseLeftButtonUp -= this.SyncOperationsButton_PreviewMouseLeftButtonUp;
					this.mSyncOperationsButtonGrid.PreviewMouseLeftButtonUp += this.SyncOperationsButton_PreviewMouseLeftButtonUp;
					this.mSyncOperationsButtonGrid.MouseEnter -= this.Grid_MouseEnter;
					this.mSyncOperationsButtonGrid.MouseEnter += this.Grid_MouseEnter;
					this.mSyncOperationsButtonGrid.Opacity = 1.0;
				}
				else
				{
					this.mSyncOperationsButtonGrid.PreviewMouseLeftButtonUp -= this.SyncOperationsButton_PreviewMouseLeftButtonUp;
					this.mSyncOperationsButtonGrid.MouseEnter -= this.Grid_MouseEnter;
					this.mSyncOperationsButtonGrid.Opacity = 0.5;
				}
			}
			if (this.ParentWindow.EngineInstanceRegistry.IsClientOnTop)
			{
				this.mPinOnTopToggleButton.ImageName = "toggle_on";
				return;
			}
			this.mPinOnTopToggleButton.ImageName = "toggle_off";
		}

		// Token: 0x0600070B RID: 1803 RVA: 0x000068B0 File Offset: 0x00004AB0
		private void SyncOperationsButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mNCTopBar.mSettingsDropdownPopup.IsOpen = false;
			this.ParentWindow.ShowSynchronizerWindow();
		}

		// Token: 0x0600070C RID: 1804 RVA: 0x0002A098 File Offset: 0x00028298
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/ncsettingsdropdown.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600070D RID: 1805 RVA: 0x0002A0C8 File Offset: 0x000282C8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mPinOnTopButtonGrid = (Grid)target;
				this.mPinOnTopButtonGrid.MouseEnter += this.Grid_MouseEnter;
				this.mPinOnTopButtonGrid.MouseLeave += this.Grid_MouseLeave;
				return;
			case 2:
				this.mPinOnTopButtonImage = (CustomPictureBox)target;
				return;
			case 3:
				this.mPinOnTopButtonText = (TextBlock)target;
				return;
			case 4:
				this.mPinOnTopToggleButton = (CustomPictureBox)target;
				this.mPinOnTopToggleButton.PreviewMouseLeftButtonUp += this.PinOnTop_MouseLeftButtonUp;
				return;
			case 5:
				this.mFullScreenButtonGrid = (Grid)target;
				this.mFullScreenButtonGrid.MouseEnter += this.Grid_MouseEnter;
				this.mFullScreenButtonGrid.MouseLeave += this.Grid_MouseLeave;
				this.mFullScreenButtonGrid.PreviewMouseLeftButtonUp += this.FullscreenButton_MouseLeftButtonUp;
				return;
			case 6:
				this.mFullScreenImage = (CustomPictureBox)target;
				return;
			case 7:
				this.mFullScreenButtonText = (TextBlock)target;
				return;
			case 8:
				this.mSyncOperationsButtonGrid = (Grid)target;
				this.mSyncOperationsButtonGrid.MouseLeave += this.Grid_MouseLeave;
				this.mSyncOperationsButtonGrid.MouseEnter += this.Grid_MouseEnter;
				this.mSyncOperationsButtonGrid.PreviewMouseLeftButtonUp += this.SyncOperationsButton_PreviewMouseLeftButtonUp;
				return;
			case 9:
				this.mSyncOperationsButtonImage = (CustomPictureBox)target;
				return;
			case 10:
				this.mSyncOperationsButtonText = (TextBlock)target;
				return;
			case 11:
				this.mSortingGrid = (Grid)target;
				this.mSortingGrid.MouseEnter += this.Grid_MouseEnter;
				this.mSortingGrid.MouseLeave += this.Grid_MouseLeave;
				this.mSortingGrid.PreviewMouseLeftButtonUp += this.SortingButton_MouseLeftButtonUp;
				return;
			case 12:
				this.mSortingButtonImage = (CustomPictureBox)target;
				return;
			case 13:
				this.mSortingButtonText = (TextBlock)target;
				return;
			case 14:
				this.mAccountGrid = (Grid)target;
				this.mAccountGrid.MouseEnter += this.Grid_MouseEnter;
				this.mAccountGrid.MouseLeave += this.Grid_MouseLeave;
				this.mAccountGrid.PreviewMouseLeftButtonUp += this.AccountButton_MouseLeftButtonUp;
				return;
			case 15:
				this.mAccountButtonImage = (CustomPictureBox)target;
				return;
			case 16:
				this.mAccountButtonText = (TextBlock)target;
				return;
			case 17:
				this.mSettingsButtonGrid = (Grid)target;
				this.mSettingsButtonGrid.MouseEnter += this.Grid_MouseEnter;
				this.mSettingsButtonGrid.MouseLeave += this.Grid_MouseLeave;
				this.mSettingsButtonGrid.PreviewMouseLeftButtonUp += this.SettingsButton_MouseLeftButtonUp;
				return;
			case 18:
				this.mSettingsButtonImage = (CustomPictureBox)target;
				return;
			case 19:
				this.mSettingsButtonText = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400040F RID: 1039
		private MainWindow ParentWindow;

		// Token: 0x04000410 RID: 1040
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mPinOnTopButtonGrid;

		// Token: 0x04000411 RID: 1041
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mPinOnTopButtonImage;

		// Token: 0x04000412 RID: 1042
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mPinOnTopButtonText;

		// Token: 0x04000413 RID: 1043
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mPinOnTopToggleButton;

		// Token: 0x04000414 RID: 1044
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mFullScreenButtonGrid;

		// Token: 0x04000415 RID: 1045
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mFullScreenImage;

		// Token: 0x04000416 RID: 1046
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mFullScreenButtonText;

		// Token: 0x04000417 RID: 1047
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mSyncOperationsButtonGrid;

		// Token: 0x04000418 RID: 1048
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mSyncOperationsButtonImage;

		// Token: 0x04000419 RID: 1049
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mSyncOperationsButtonText;

		// Token: 0x0400041A RID: 1050
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mSortingGrid;

		// Token: 0x0400041B RID: 1051
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mSortingButtonImage;

		// Token: 0x0400041C RID: 1052
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mSortingButtonText;

		// Token: 0x0400041D RID: 1053
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mAccountGrid;

		// Token: 0x0400041E RID: 1054
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mAccountButtonImage;

		// Token: 0x0400041F RID: 1055
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mAccountButtonText;

		// Token: 0x04000420 RID: 1056
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mSettingsButtonGrid;

		// Token: 0x04000421 RID: 1057
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mSettingsButtonImage;

		// Token: 0x04000422 RID: 1058
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mSettingsButtonText;

		// Token: 0x04000423 RID: 1059
		private bool _contentLoaded;
	}
}
