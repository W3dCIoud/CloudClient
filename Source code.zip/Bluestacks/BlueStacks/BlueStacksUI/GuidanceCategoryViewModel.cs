﻿using System;
using System.Collections.ObjectModel;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000040 RID: 64
	[Serializable]
	public class GuidanceCategoryViewModel : ViewModelBase
	{
		// Token: 0x17000128 RID: 296
		// (get) Token: 0x06000326 RID: 806 RVA: 0x00004153 File Offset: 0x00002353
		// (set) Token: 0x06000327 RID: 807 RVA: 0x0000415B File Offset: 0x0000235B
		public ObservableCollection<GuidanceViewModel> GuidanceViewModels
		{
			get
			{
				return this.sGuidanceViewModels;
			}
			set
			{
				base.SetProperty<ObservableCollection<GuidanceViewModel>>(ref this.sGuidanceViewModels, value, null);
			}
		}

		// Token: 0x17000129 RID: 297
		// (get) Token: 0x06000328 RID: 808 RVA: 0x0000416C File Offset: 0x0000236C
		// (set) Token: 0x06000329 RID: 809 RVA: 0x00004174 File Offset: 0x00002374
		public string Category
		{
			get
			{
				return this.mCategory;
			}
			set
			{
				base.SetProperty<string>(ref this.mCategory, value, null);
			}
		}

		// Token: 0x040001B8 RID: 440
		private ObservableCollection<GuidanceViewModel> sGuidanceViewModels = new ObservableCollection<GuidanceViewModel>();

		// Token: 0x040001B9 RID: 441
		private string mCategory;
	}
}
