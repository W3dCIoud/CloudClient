﻿using System;
using System.Collections.Generic;
using System.Reflection;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200006E RID: 110
	public class HelpArticle
	{
		// Token: 0x17000166 RID: 358
		// (get) Token: 0x0600046A RID: 1130 RVA: 0x00004FFC File Offset: 0x000031FC
		// (set) Token: 0x0600046B RID: 1131 RVA: 0x00005004 File Offset: 0x00003204
		[JsonProperty(PropertyName = "gamepad", DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate, NullValueHandling = NullValueHandling.Include)]
		public HelpArticleInfo Gamepad { get; set; }

		// Token: 0x17000167 RID: 359
		// (get) Token: 0x0600046C RID: 1132 RVA: 0x0000500D File Offset: 0x0000320D
		// (set) Token: 0x0600046D RID: 1133 RVA: 0x00005015 File Offset: 0x00003215
		[JsonProperty(PropertyName = "moba", DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate, NullValueHandling = NullValueHandling.Include)]
		public HelpArticleInfo Moba { get; set; }

		// Token: 0x17000168 RID: 360
		// (get) Token: 0x0600046E RID: 1134 RVA: 0x0000501E File Offset: 0x0000321E
		// (set) Token: 0x0600046F RID: 1135 RVA: 0x00005026 File Offset: 0x00003226
		[JsonProperty(PropertyName = "pan", DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate, NullValueHandling = NullValueHandling.Include)]
		public HelpArticleInfo Pan { get; set; }

		// Token: 0x17000169 RID: 361
		// (get) Token: 0x06000470 RID: 1136 RVA: 0x0000502F File Offset: 0x0000322F
		// (set) Token: 0x06000471 RID: 1137 RVA: 0x00005037 File Offset: 0x00003237
		[JsonProperty(PropertyName = "special", DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate, NullValueHandling = NullValueHandling.Include)]
		public HelpArticleInfo Special { get; set; }

		// Token: 0x1700016A RID: 362
		// (get) Token: 0x06000472 RID: 1138 RVA: 0x00005040 File Offset: 0x00003240
		// (set) Token: 0x06000473 RID: 1139 RVA: 0x00005048 File Offset: 0x00003248
		[JsonProperty(PropertyName = "default", DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate, NullValueHandling = NullValueHandling.Include)]
		public HelpArticleInfo Default { get; set; }

		// Token: 0x1700016B RID: 363
		// (get) Token: 0x06000474 RID: 1140 RVA: 0x00005051 File Offset: 0x00003251
		// (set) Token: 0x06000475 RID: 1141 RVA: 0x00005059 File Offset: 0x00003259
		[JsonProperty(PropertyName = "package")]
		public string Package { get; set; }

		// Token: 0x1700016C RID: 364
		// (get) Token: 0x06000476 RID: 1142 RVA: 0x00005062 File Offset: 0x00003262
		// (set) Token: 0x06000477 RID: 1143 RVA: 0x0000506A File Offset: 0x0000326A
		[JsonProperty(PropertyName = "schemespecific")]
		public Dictionary<string, HelpArticleInfo> SchemeSpecific { get; set; } = new Dictionary<string, HelpArticleInfo>();

		// Token: 0x1700016D RID: 365
		public object this[string propertyName]
		{
			get
			{
				PropertyInfo property = typeof(HelpArticle).GetProperty(propertyName, BindingFlags.IgnoreCase | BindingFlags.Instance | BindingFlags.Public);
				if (property == null)
				{
					return null;
				}
				return property.GetValue(this, null);
			}
		}
	}
}
