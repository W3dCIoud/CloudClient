﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200007F RID: 127
	public enum QuitActionItemCTA
	{
		// Token: 0x040002B2 RID: 690
		OpenLinkInBrowser,
		// Token: 0x040002B3 RID: 691
		OpenAppCenter,
		// Token: 0x040002B4 RID: 692
		OpenApplication
	}
}
