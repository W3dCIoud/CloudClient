﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Media;
using System.Threading;
using System.Timers;
using System.Web;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Windows.Threading;
using BlueStacks.BlueStacksUI.BTv;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001B3 RID: 435
	internal class CommonHandlers : IDisposable
	{
		// Token: 0x14000016 RID: 22
		// (add) Token: 0x060010B5 RID: 4277 RVA: 0x000685D0 File Offset: 0x000667D0
		// (remove) Token: 0x060010B6 RID: 4278 RVA: 0x00068608 File Offset: 0x00066808
		public event CommonHandlers.MacroBookmarkChanged MacroBookmarkChangedEvent;

		// Token: 0x14000017 RID: 23
		// (add) Token: 0x060010B7 RID: 4279 RVA: 0x00068640 File Offset: 0x00066840
		// (remove) Token: 0x060010B8 RID: 4280 RVA: 0x00068678 File Offset: 0x00066878
		public event CommonHandlers.MacroSettingsChanged MacroSettingChangedEvent;

		// Token: 0x14000018 RID: 24
		// (add) Token: 0x060010B9 RID: 4281 RVA: 0x000686B0 File Offset: 0x000668B0
		// (remove) Token: 0x060010BA RID: 4282 RVA: 0x000686E8 File Offset: 0x000668E8
		public event CommonHandlers.ShortcutKeysChanged ShortcutKeysChangedEvent;

		// Token: 0x14000019 RID: 25
		// (add) Token: 0x060010BB RID: 4283 RVA: 0x00068720 File Offset: 0x00066920
		// (remove) Token: 0x060010BC RID: 4284 RVA: 0x00068758 File Offset: 0x00066958
		public event CommonHandlers.ShortcutKeysRefresh ShortcutKeysRefreshEvent;

		// Token: 0x1400001A RID: 26
		// (add) Token: 0x060010BD RID: 4285 RVA: 0x00068790 File Offset: 0x00066990
		// (remove) Token: 0x060010BE RID: 4286 RVA: 0x000687C8 File Offset: 0x000669C8
		public event CommonHandlers.MacroDeleted MacroDeletedEvent;

		// Token: 0x1400001B RID: 27
		// (add) Token: 0x060010BF RID: 4287 RVA: 0x00068800 File Offset: 0x00066A00
		// (remove) Token: 0x060010C0 RID: 4288 RVA: 0x00068838 File Offset: 0x00066A38
		public event CommonHandlers.OverlayStateChanged OverlayStateChangedEvent;

		// Token: 0x1400001C RID: 28
		// (add) Token: 0x060010C1 RID: 4289 RVA: 0x00068870 File Offset: 0x00066A70
		// (remove) Token: 0x060010C2 RID: 4290 RVA: 0x000688A8 File Offset: 0x00066AA8
		public event CommonHandlers.MacroButtonVisibilityChanged MacroButtonVisibilityChangedEvent;

		// Token: 0x1400001D RID: 29
		// (add) Token: 0x060010C3 RID: 4291 RVA: 0x000688E0 File Offset: 0x00066AE0
		// (remove) Token: 0x060010C4 RID: 4292 RVA: 0x00068918 File Offset: 0x00066B18
		public event CommonHandlers.OperationSyncButtonVisibilityChanged OperationSyncButtonVisibilityChangedEvent;

		// Token: 0x1400001E RID: 30
		// (add) Token: 0x060010C5 RID: 4293 RVA: 0x00068950 File Offset: 0x00066B50
		// (remove) Token: 0x060010C6 RID: 4294 RVA: 0x00068988 File Offset: 0x00066B88
		public event CommonHandlers.OBSResponseTimeout OBSResponseTimeoutEvent;

		// Token: 0x1400001F RID: 31
		// (add) Token: 0x060010C7 RID: 4295 RVA: 0x000689C0 File Offset: 0x00066BC0
		// (remove) Token: 0x060010C8 RID: 4296 RVA: 0x000689F8 File Offset: 0x00066BF8
		public event CommonHandlers.ScreenRecorderStateTransitioning ScreenRecorderStateTransitioningEvent;

		// Token: 0x14000020 RID: 32
		// (add) Token: 0x060010C9 RID: 4297 RVA: 0x00068A30 File Offset: 0x00066C30
		// (remove) Token: 0x060010CA RID: 4298 RVA: 0x00068A68 File Offset: 0x00066C68
		public event CommonHandlers.BTvDownloaderMinimized BTvDownloaderMinimizedEvent;

		// Token: 0x14000021 RID: 33
		// (add) Token: 0x060010CB RID: 4299 RVA: 0x00068AA0 File Offset: 0x00066CA0
		// (remove) Token: 0x060010CC RID: 4300 RVA: 0x00068AD8 File Offset: 0x00066CD8
		public event CommonHandlers.GamepadButtonVisibilityChanged GamepadButtonVisibilityChangedEvent;

		// Token: 0x14000022 RID: 34
		// (add) Token: 0x060010CD RID: 4301 RVA: 0x00068B10 File Offset: 0x00066D10
		// (remove) Token: 0x060010CE RID: 4302 RVA: 0x00068B48 File Offset: 0x00066D48
		public event CommonHandlers.ScreenRecordingStateChanged ScreenRecordingStateChangedEvent;

		// Token: 0x14000023 RID: 35
		// (add) Token: 0x060010CF RID: 4303 RVA: 0x00068B80 File Offset: 0x00066D80
		// (remove) Token: 0x060010D0 RID: 4304 RVA: 0x00068BB8 File Offset: 0x00066DB8
		public event CommonHandlers.VolumeChanged VolumeChangedEvent;

		// Token: 0x14000024 RID: 36
		// (add) Token: 0x060010D1 RID: 4305 RVA: 0x00068BF0 File Offset: 0x00066DF0
		// (remove) Token: 0x060010D2 RID: 4306 RVA: 0x00068C28 File Offset: 0x00066E28
		public event CommonHandlers.VolumeMuted VolumeMutedEvent;

		// Token: 0x14000025 RID: 37
		// (add) Token: 0x060010D3 RID: 4307 RVA: 0x00068C60 File Offset: 0x00066E60
		// (remove) Token: 0x060010D4 RID: 4308 RVA: 0x00068C98 File Offset: 0x00066E98
		public event CommonHandlers.GameGuideButtonVisibilityChanged GameGuideButtonVisibilityChangedEvent;

		// Token: 0x060010D5 RID: 4309 RVA: 0x0000C2A8 File Offset: 0x0000A4A8
		internal void OnVolumeMuted(bool muted)
		{
			CommonHandlers.VolumeMuted volumeMutedEvent = this.VolumeMutedEvent;
			if (volumeMutedEvent == null)
			{
				return;
			}
			volumeMutedEvent(muted);
		}

		// Token: 0x060010D6 RID: 4310 RVA: 0x0000C2BB File Offset: 0x0000A4BB
		internal void OnVolumeChanged(int volumeLevel)
		{
			CommonHandlers.VolumeChanged volumeChangedEvent = this.VolumeChangedEvent;
			if (volumeChangedEvent == null)
			{
				return;
			}
			volumeChangedEvent(volumeLevel);
		}

		// Token: 0x060010D7 RID: 4311 RVA: 0x0000C2CE File Offset: 0x0000A4CE
		internal void OnScreenRecordingStateChanged(bool isRecording)
		{
			CommonHandlers.ScreenRecordingStateChanged screenRecordingStateChangedEvent = this.ScreenRecordingStateChangedEvent;
			if (screenRecordingStateChangedEvent == null)
			{
				return;
			}
			screenRecordingStateChangedEvent(isRecording);
		}

		// Token: 0x060010D8 RID: 4312 RVA: 0x0000C2E1 File Offset: 0x0000A4E1
		internal void OnGamepadButtonVisibilityChanged(bool visiblity)
		{
			CommonHandlers.GamepadButtonVisibilityChanged gamepadButtonVisibilityChangedEvent = this.GamepadButtonVisibilityChangedEvent;
			if (gamepadButtonVisibilityChangedEvent == null)
			{
				return;
			}
			gamepadButtonVisibilityChangedEvent(visiblity);
		}

		// Token: 0x060010D9 RID: 4313 RVA: 0x0000C2F4 File Offset: 0x0000A4F4
		internal void OnGameGuideButtonVisibilityChanged(bool visiblity)
		{
			CommonHandlers.GameGuideButtonVisibilityChanged gameGuideButtonVisibilityChangedEvent = this.GameGuideButtonVisibilityChangedEvent;
			if (gameGuideButtonVisibilityChangedEvent == null)
			{
				return;
			}
			gameGuideButtonVisibilityChangedEvent(visiblity);
		}

		// Token: 0x060010DA RID: 4314 RVA: 0x0000C307 File Offset: 0x0000A507
		private void OnOBSResponseTimeout()
		{
			CommonHandlers.OBSResponseTimeout obsresponseTimeoutEvent = this.OBSResponseTimeoutEvent;
			if (obsresponseTimeoutEvent == null)
			{
				return;
			}
			obsresponseTimeoutEvent();
		}

		// Token: 0x060010DB RID: 4315 RVA: 0x0000C319 File Offset: 0x0000A519
		private void OnBTvDownloaderMinimized()
		{
			CommonHandlers.BTvDownloaderMinimized btvDownloaderMinimizedEvent = this.BTvDownloaderMinimizedEvent;
			if (btvDownloaderMinimizedEvent == null)
			{
				return;
			}
			btvDownloaderMinimizedEvent();
		}

		// Token: 0x060010DC RID: 4316 RVA: 0x0000C32B File Offset: 0x0000A52B
		internal void OnScreenRecorderStateTransitioning()
		{
			CommonHandlers.ScreenRecorderStateTransitioning screenRecorderStateTransitioningEvent = this.ScreenRecorderStateTransitioningEvent;
			if (screenRecorderStateTransitioningEvent == null)
			{
				return;
			}
			screenRecorderStateTransitioningEvent();
		}

		// Token: 0x060010DD RID: 4317 RVA: 0x0000C33D File Offset: 0x0000A53D
		internal void OnMacroButtonVisibilityChanged(bool isVisible)
		{
			CommonHandlers.MacroButtonVisibilityChanged macroButtonVisibilityChangedEvent = this.MacroButtonVisibilityChangedEvent;
			if (macroButtonVisibilityChangedEvent == null)
			{
				return;
			}
			macroButtonVisibilityChangedEvent(isVisible);
		}

		// Token: 0x060010DE RID: 4318 RVA: 0x0000C350 File Offset: 0x0000A550
		internal void OnOperationSyncButtonVisibilityChanged(bool isVisible)
		{
			CommonHandlers.OperationSyncButtonVisibilityChanged operationSyncButtonVisibilityChangedEvent = this.OperationSyncButtonVisibilityChangedEvent;
			if (operationSyncButtonVisibilityChangedEvent == null)
			{
				return;
			}
			operationSyncButtonVisibilityChangedEvent(isVisible);
		}

		// Token: 0x060010DF RID: 4319 RVA: 0x00068CD0 File Offset: 0x00066ED0
		internal void OnMacroBookmarkChanged(string fileName, bool wasBookmarked)
		{
			foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
			{
				CommonHandlers mCommonHandler = keyValuePair.Value.mCommonHandler;
				if (mCommonHandler != null)
				{
					CommonHandlers.MacroBookmarkChanged macroBookmarkChangedEvent = mCommonHandler.MacroBookmarkChangedEvent;
					if (macroBookmarkChangedEvent != null)
					{
						macroBookmarkChangedEvent(fileName, wasBookmarked);
					}
				}
			}
		}

		// Token: 0x060010E0 RID: 4320 RVA: 0x00068D40 File Offset: 0x00066F40
		internal static void OnMacroSettingChanged(MacroRecording record)
		{
			foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
			{
				CommonHandlers mCommonHandler = keyValuePair.Value.mCommonHandler;
				if (mCommonHandler != null)
				{
					CommonHandlers.MacroSettingsChanged macroSettingChangedEvent = mCommonHandler.MacroSettingChangedEvent;
					if (macroSettingChangedEvent != null)
					{
						macroSettingChangedEvent(record);
					}
				}
			}
		}

		// Token: 0x060010E1 RID: 4321 RVA: 0x00068DB0 File Offset: 0x00066FB0
		internal static void OnMacroDeleted(string fileName)
		{
			foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
			{
				CommonHandlers mCommonHandler = keyValuePair.Value.mCommonHandler;
				if (mCommonHandler != null)
				{
					CommonHandlers.MacroDeleted macroDeletedEvent = mCommonHandler.MacroDeletedEvent;
					if (macroDeletedEvent != null)
					{
						macroDeletedEvent(fileName);
					}
				}
			}
		}

		// Token: 0x060010E2 RID: 4322 RVA: 0x0000C363 File Offset: 0x0000A563
		internal void OnShortcutKeysChanged(bool isEnabled)
		{
			CommonHandlers.ShortcutKeysChanged shortcutKeysChangedEvent = this.ShortcutKeysChangedEvent;
			if (shortcutKeysChangedEvent == null)
			{
				return;
			}
			shortcutKeysChangedEvent(isEnabled);
		}

		// Token: 0x060010E3 RID: 4323 RVA: 0x0000C376 File Offset: 0x0000A576
		internal void OnShortcutKeysRefresh()
		{
			CommonHandlers.ShortcutKeysRefresh shortcutKeysRefreshEvent = this.ShortcutKeysRefreshEvent;
			if (shortcutKeysRefreshEvent == null)
			{
				return;
			}
			shortcutKeysRefreshEvent();
		}

		// Token: 0x060010E4 RID: 4324 RVA: 0x0000C388 File Offset: 0x0000A588
		internal void OnOverlayStateChanged(bool isEnabled)
		{
			CommonHandlers.OverlayStateChanged overlayStateChangedEvent = this.OverlayStateChangedEvent;
			if (overlayStateChangedEvent == null)
			{
				return;
			}
			overlayStateChangedEvent(isEnabled);
		}

		// Token: 0x060010E5 RID: 4325 RVA: 0x0000C39B File Offset: 0x0000A59B
		internal CommonHandlers(MainWindow window)
		{
			this.ParentWindow = window;
		}

		// Token: 0x060010E6 RID: 4326 RVA: 0x0000C3AA File Offset: 0x0000A5AA
		public void LocationButtonHandler()
		{
			this.ParentWindow.mTopBar.mAppTabButtons.AddAppTab("STRING_MAP", "com.location.provider", "com.location.provider.MapsActivity", "ico_fakegps", true, true, false);
		}

		// Token: 0x060010E7 RID: 4327 RVA: 0x00068E20 File Offset: 0x00067020
		public void ImageTranslationHandler()
		{
			Logger.Info("Saving screenshot automatically for image translater");
			if (ImageTranslateControl.Instance == null)
			{
				using (Bitmap bitmap = this.CaptureSreenShot())
				{
					ImageTranslateControl imageTranslateControl = new ImageTranslateControl(this.ParentWindow);
					imageTranslateControl.GetTranslateImage(bitmap);
					imageTranslateControl.Visibility = Visibility.Visible;
					this.ParentWindow.ShowDimOverlay(imageTranslateControl);
				}
			}
		}

		// Token: 0x060010E8 RID: 4328 RVA: 0x0000C3D8 File Offset: 0x0000A5D8
		internal static void ToggleFarmMode(bool newStatus)
		{
			RegistryManager.Instance.CurrentFarmModeStatus = newStatus;
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
				{
					try
					{
						keyValuePair.Value.mFrontendHandler.SendFrontendRequestAsync("farmModeHandler", new Dictionary<string, string>
						{
							{
								"enable",
								RegistryManager.Instance.CurrentFarmModeStatus.ToString(CultureInfo.InvariantCulture)
							}
						});
					}
					catch
					{
					}
				}
			});
		}

		// Token: 0x060010E9 RID: 4329 RVA: 0x00068E88 File Offset: 0x00067088
		internal void SearchAppCenter(string searchString)
		{
			AppTabButton tab = this.ParentWindow.mTopBar.mAppTabButtons.GetTab("appcenter");
			bool flag;
			if (tab == null)
			{
				flag = (null != null);
			}
			else
			{
				BrowserControl browserControl = tab.GetBrowserControl();
				flag = (((browserControl != null) ? browserControl.CefBrowser : null) != null);
			}
			if (flag)
			{
				tab.GetBrowserControl().CefBrowser.ExecuteJavaScript(string.Format(CultureInfo.InvariantCulture, "openSearch(\"{0}\")", new object[]
				{
					HttpUtility.UrlEncode(searchString)
				}), tab.GetBrowserControl().CefBrowser.StartUrl, 0);
				this.ParentWindow.mTopBar.mAppTabButtons.GoToTab("appcenter", true, false);
				return;
			}
			this.ParentWindow.Utils.HandleApplicationBrowserClick(BlueStacksUIUtils.GetAppCenterUrl(null) + "&query=" + HttpUtility.UrlEncode(searchString), LocaleStrings.GetLocalizedString("STRING_APP_CENTER"), "appcenter", false, "");
		}

		// Token: 0x060010EA RID: 4330 RVA: 0x0000C40A File Offset: 0x0000A60A
		internal void HideMacroRecorderWindow()
		{
			this.ParentWindow.MacroRecorderWindow.Owner = null;
			this.ParentWindow.MacroRecorderWindow.Hide();
			this.ParentWindow.MacroRecorderWindow.ShowWithParentWindow = false;
		}

		// Token: 0x060010EB RID: 4331 RVA: 0x0000C43E File Offset: 0x0000A63E
		internal void RefreshMacroRecorderWindow()
		{
			this.ParentWindow.MacroRecorderWindow.mScriptsStackPanel.Children.Clear();
			this.ParentWindow.MacroRecorderWindow.Init();
		}

		// Token: 0x060010EC RID: 4332 RVA: 0x00068F64 File Offset: 0x00067164
		internal static void RefreshAllMacroRecorderWindow()
		{
			try
			{
				foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
				{
					if (keyValuePair.Value.MacroRecorderWindow != null)
					{
						keyValuePair.Value.MacroRecorderWindow.mScriptsStackPanel.Children.Clear();
						keyValuePair.Value.MacroRecorderWindow.Init();
					}
				}
			}
			catch (Exception ex)
			{
				string str = "Error in refreshing operation recorder window";
				Exception ex2 = ex;
				Logger.Debug(str + ((ex2 != null) ? ex2.ToString() : null));
			}
		}

		// Token: 0x060010ED RID: 4333 RVA: 0x00069018 File Offset: 0x00067218
		internal static void RefreshAllMacroWindowWithScroll()
		{
			try
			{
				foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
				{
					if (keyValuePair.Value.MacroRecorderWindow != null)
					{
						keyValuePair.Value.MacroRecorderWindow.mScriptsStackPanel.Children.Clear();
						keyValuePair.Value.MacroRecorderWindow.Init();
						keyValuePair.Value.MacroRecorderWindow.mScriptsListScrollbar.ScrollToEnd();
					}
				}
			}
			catch (Exception ex)
			{
				string str = "Error in refreshing operation recorder window";
				Exception ex2 = ex;
				Logger.Debug(str + ((ex2 != null) ? ex2.ToString() : null));
			}
		}

		// Token: 0x060010EE RID: 4334 RVA: 0x000690E0 File Offset: 0x000672E0
		internal void ShowMacroRecorderWindow()
		{
			this.ParentWindow.MacroRecorderWindow.Owner = this.ParentWindow;
			this.ParentWindow.MacroRecorderWindow.ShowWithParentWindow = true;
			this.ParentWindow.MacroRecorderWindow.Show();
			this.ParentWindow.Activate();
		}

		// Token: 0x060010EF RID: 4335 RVA: 0x00069130 File Offset: 0x00067330
		private Bitmap CaptureSreenShot()
		{
			System.Windows.Point point = this.ParentWindow.mContentGrid.PointToScreen(new System.Windows.Point(0.0, 0.0));
			System.Windows.Point point2 = new System.Windows.Point((double)Convert.ToInt32(point.X), (double)Convert.ToInt32(point.Y));
			System.Windows.Point point3 = this.ParentWindow.mContentGrid.PointToScreen(new System.Windows.Point((double)((int)this.ParentWindow.mContentGrid.ActualWidth), (double)((int)this.ParentWindow.mContentGrid.ActualHeight - 40)));
			System.Drawing.Size blockRegionSize = new System.Drawing.Size(Convert.ToInt32(point3.X - point2.X), Convert.ToInt32(point3.Y - point2.Y));
			Bitmap bitmap = new Bitmap(blockRegionSize.Width, blockRegionSize.Height);
			System.Drawing.Point upperLeftSource = new System.Drawing.Point((int)point2.X, (int)point2.Y);
			using (Graphics graphics = Graphics.FromImage(bitmap))
			{
				graphics.CopyFromScreen(upperLeftSource, System.Drawing.Point.Empty, blockRegionSize);
			}
			return bitmap;
		}

		// Token: 0x060010F0 RID: 4336 RVA: 0x00069258 File Offset: 0x00067458
		public void ScreenShotButtonHandler()
		{
			try
			{
				string str = DateTime.Now.ToString("yyyy.MM.dd_HH.mm.ss", CultureInfo.InvariantCulture);
				string str2 = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.AppName;
				if (FeatureManager.Instance.IsCustomUIForNCSoft && !string.IsNullOrEmpty(this.ParentWindow.mNCTopBar.mAppName.Text))
				{
					str2 = this.ParentWindow.mNCTopBar.mAppName.Text;
				}
				string path = str2 + "_Screenshot_" + str + ".jpg";
				string filePath = Path.Combine(Path.GetTempPath(), path);
				this.ParentWindow.mFrontendHandler.GetScreenShot(filePath);
				try
				{
					if (FeatureManager.Instance.IsCustomUIForDMM)
					{
						using (SoundPlayer soundPlayer = new SoundPlayer(Path.Combine(Path.Combine(RegistryManager.Instance.ClientInstallDir, "Assets"), "camera_shutter_click.wav")))
						{
							soundPlayer.Play();
						}
					}
				}
				catch
				{
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in screenshot button handler: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x060010F1 RID: 4337 RVA: 0x00069394 File Offset: 0x00067594
		internal void PostScreenShotWork(string screenshotFileFullPath)
		{
			try
			{
				Logger.Debug("screen shot path..." + screenshotFileFullPath);
				if (RegistryManager.Instance.IsScreenshotsLocationPopupEnabled)
				{
					this.ShowScreenShotFolderUpdatePopup();
				}
				string text = RegistryManager.Instance.ScreenShotsPath;
				if (!StringExtensions.IsValidPath(text))
				{
					string screenshotDefaultPath = RegistryStrings.ScreenshotDefaultPath;
					if (!Directory.Exists(screenshotDefaultPath))
					{
						Directory.CreateDirectory(screenshotDefaultPath);
					}
					RegistryManager.Instance.ScreenShotsPath = screenshotDefaultPath;
					text = screenshotDefaultPath;
				}
				string fileName = Path.GetFileName(screenshotFileFullPath);
				string text2 = Path.Combine(text, fileName);
				Logger.Debug("Screen shot filename.." + text2);
				if (File.Exists(text2))
				{
					File.Delete(text2);
				}
				File.Move(screenshotFileFullPath, text2);
				ClientStats.SendMiscellaneousStatsAsync("MediaFileSaveSuccess", RegistryManager.Instance.UserGuid, "ScreenShot", RegistryManager.Instance.ScreenShotsPath, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
				if (RegistryManager.Instance.IsShowToastNotification)
				{
					this.ParentWindow.ShowGeneralToast(LocaleStrings.GetLocalizedString("STRING_SCREENSHOT_SAVED"));
				}
				if (this.ParentWindow.EngineInstanceRegistry.IsSidebarVisible)
				{
					this.ParentWindow.mSidebar.ShowScreenshotSavedPopup(text2);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in post screenshot work: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x060010F2 RID: 4338 RVA: 0x000694EC File Offset: 0x000676EC
		private void ShowScreenShotFolderUpdatePopup()
		{
			RegistryManager.Instance.IsScreenshotsLocationPopupEnabled = false;
			string screenShotsPath = RegistryManager.Instance.ScreenShotsPath;
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_OPEN_MEDIA_FOLDER", "");
			customMessageWindow.AddButton(ButtonColors.Blue, "STRING_CHOOSE_CUSTOM", new EventHandler(this.ChooseCustomFolder), null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_USE_CURRENT", null, null, false, null);
			BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_CHOOSE_FOLDER_TEXT", "");
			customMessageWindow.BodyWarningTextBlock.Visibility = Visibility.Visible;
			customMessageWindow.BodyWarningTextBlock.Text = screenShotsPath;
			BlueStacksUIBinding.BindColor(customMessageWindow.BodyWarningTextBlock, TextBlock.ForegroundProperty, "HyperLinkForegroundColor");
			this.ParentWindow.ShowDimOverlay(null);
			customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
			customMessageWindow.ShowDialog();
			this.ParentWindow.HideDimOverlay();
			ClientStats.SendMiscellaneousStatsAsync("MediaFilesPathSet", RegistryManager.Instance.UserGuid, "PathChangeFromPopUp", screenShotsPath, RegistryManager.Instance.ScreenShotsPath, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null);
		}

		// Token: 0x060010F3 RID: 4339 RVA: 0x0000C46A File Offset: 0x0000A66A
		internal void AddCoordinatesToScriptText(double x, double y)
		{
			if (KMManager.sIsInScriptEditingMode && KMManager.CanvasWindow != null)
			{
				AdvancedGameControlWindow sidebarWindow = KMManager.CanvasWindow.SidebarWindow;
				if (sidebarWindow == null)
				{
					return;
				}
				sidebarWindow.InsertXYInScript(x, y);
			}
		}

		// Token: 0x060010F4 RID: 4340 RVA: 0x00069608 File Offset: 0x00067808
		private void ChooseCustomFolder(object sender, EventArgs e)
		{
			string screenShotsPath = RegistryManager.Instance.ScreenShotsPath;
			if (!Directory.Exists(screenShotsPath))
			{
				Directory.CreateDirectory(screenShotsPath);
			}
			this.ShowFolderBrowserDialog(screenShotsPath);
		}

		// Token: 0x060010F5 RID: 4341 RVA: 0x00069638 File Offset: 0x00067838
		internal void ShowFolderBrowserDialog(string screenshotPath)
		{
			using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog
			{
				SelectedPath = screenshotPath,
				ShowNewFolderButton = true
			})
			{
				if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
				{
					string selectedPath = folderBrowserDialog.SelectedPath;
					Logger.Info("dialoge selected path.." + folderBrowserDialog.SelectedPath);
					bool flag = Utils.CheckWritePermissionForFolder(selectedPath);
					Logger.Info("Permission.." + flag.ToString() + "..path.." + selectedPath);
					if (!flag)
					{
						this.ShowInvalidPathPopUp();
					}
					else
					{
						RegistryManager.Instance.ScreenShotsPath = selectedPath;
					}
				}
				else
				{
					RegistryManager.Instance.ScreenShotsPath = screenshotPath;
				}
			}
		}

		// Token: 0x060010F6 RID: 4342 RVA: 0x000696E0 File Offset: 0x000678E0
		private void ShowInvalidPathPopUp()
		{
			string defaultPicturePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "Bluestacks");
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_OPEN_MEDIA_FOLDER", "");
			customMessageWindow.AddButton(ButtonColors.Blue, "STRING_CHOOSE_ANOTHER", new EventHandler(this.ChooseCustomFolder), null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_USE_DEFAULT", delegate(object o, EventArgs e)
			{
				RegistryManager.Instance.ScreenShotsPath = defaultPicturePath;
			}, null, false, null);
			customMessageWindow.BodyTextBlockTitle.Visibility = Visibility.Visible;
			customMessageWindow.BodyTextBlockTitle.Text = LocaleStrings.GetLocalizedString("STRING_SCREENSHOT_INVALID_PATH");
			BlueStacksUIBinding.BindColor(customMessageWindow.BodyTextBlockTitle, TextBlock.ForegroundProperty, "DeleteComboTextForeground");
			customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_SCREENSHOT_USE_DEFAULT");
			customMessageWindow.BodyWarningTextBlock.Visibility = Visibility.Visible;
			customMessageWindow.BodyWarningTextBlock.Text = defaultPicturePath;
			BlueStacksUIBinding.BindColor(customMessageWindow.BodyWarningTextBlock, TextBlock.ForegroundProperty, "HyperLinkForegroundColor");
			customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
			customMessageWindow.ShowDialog();
			customMessageWindow.Close();
		}

		// Token: 0x060010F7 RID: 4343 RVA: 0x0000C490 File Offset: 0x0000A690
		public void ShakeButtonHandler()
		{
			this.ParentWindow.Utils.ShakeWindow();
			this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("shake", null);
		}

		// Token: 0x060010F8 RID: 4344 RVA: 0x000697F4 File Offset: 0x000679F4
		public void BackButtonHandler(bool receivedFromImap = false)
		{
			if (this.ParentWindow.mGuestBootCompleted)
			{
				new Thread(delegate()
				{
					VmCmdHandler.RunCommand("back", this.ParentWindow.mVmName);
				})
				{
					IsBackground = true
				}.Start();
				if (this.ParentWindow.SendClientActions && !receivedFromImap)
				{
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					Dictionary<string, string> value = new Dictionary<string, string>
					{
						{
							"EventAction",
							"BackButton"
						}
					};
					JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
					serializerSettings.Formatting = Formatting.None;
					dictionary.Add("operationData", JsonConvert.SerializeObject(value, serializerSettings));
					this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("handleClientOperation", dictionary);
				}
			}
		}

		// Token: 0x060010F9 RID: 4345 RVA: 0x0006988C File Offset: 0x00067A8C
		public void OpenBrowserInPopup(Dictionary<string, string> payload)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					string localizedString = LocaleStrings.GetLocalizedString(payload["click_action_title"]);
					string url = payload["click_action_value"].Trim();
					string urlWithParams = WebHelper.GetUrlWithParams(url);
					ClientStats.SendPopupBrowserStatsInMiscASync("request", url);
					PopupBrowserControl popupBrowserControl = new PopupBrowserControl();
					popupBrowserControl.Init(urlWithParams, localizedString, this.ParentWindow);
					ClientStats.SendPopupBrowserStatsInMiscASync("impression", url);
					this.ParentWindow.ShowDimOverlay(popupBrowserControl);
				}
				catch (Exception ex)
				{
					Logger.Error("Couldn't open popup. An exception occured. {0}", new object[]
					{
						ex
					});
				}
			}), new object[0]);
		}

		// Token: 0x060010FA RID: 4346 RVA: 0x000698D0 File Offset: 0x00067AD0
		public void HomeButtonHandler(bool isLaunch = true, bool receivedFromImap = false)
		{
			this.ParentWindow.mTopBar.mAppTabButtons.GoToTab("Home", isLaunch, false);
			if (this.ParentWindow.SendClientActions && !receivedFromImap)
			{
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				Dictionary<string, string> value = new Dictionary<string, string>
				{
					{
						"EventAction",
						"HomeButton"
					},
					{
						"IsLaunch",
						isLaunch.ToString(CultureInfo.InvariantCulture)
					}
				};
				JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
				serializerSettings.Formatting = Formatting.None;
				dictionary.Add("operationData", JsonConvert.SerializeObject(value, serializerSettings));
				this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("handleClientOperation", dictionary);
			}
		}

		// Token: 0x060010FB RID: 4347 RVA: 0x00069974 File Offset: 0x00067B74
		public void FullScreenButtonHandler(string source, string actionPerformed)
		{
			if (!this.ParentWindow.mResizeHandler.IsMinMaxEnabled)
			{
				return;
			}
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (this.ParentWindow.mIsFullScreen)
				{
					this.ParentWindow.RestoreWindows(false);
					ClientStats.SendMiscellaneousStatsAsync(source, RegistryManager.Instance.UserGuid, "RestoreFullscreen", actionPerformed, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
					return;
				}
				this.ParentWindow.FullScreenWindow();
				ClientStats.SendMiscellaneousStatsAsync(source, RegistryManager.Instance.UserGuid, "Fullscreen", actionPerformed, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
			}), new object[0]);
		}

		// Token: 0x060010FC RID: 4348 RVA: 0x000699D4 File Offset: 0x00067BD4
		internal void AddToastPopup(Window window, string message, double duration = 1.3, bool isShowCloseImage = false)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					CustomToastPopupControl customToastPopupControl = new CustomToastPopupControl(window);
					if (isShowCloseImage)
					{
						customToastPopupControl.Init(window, message, System.Windows.Media.Brushes.Black, null, System.Windows.HorizontalAlignment.Center, VerticalAlignment.Top, null, 12, null, null, isShowCloseImage);
						customToastPopupControl.Margin = new Thickness(0.0, 40.0, 0.0, 0.0);
					}
					else
					{
						customToastPopupControl.Init(window, message, System.Windows.Media.Brushes.Black, null, System.Windows.HorizontalAlignment.Center, VerticalAlignment.Center, null, 12, null, null, false);
					}
					customToastPopupControl.ShowPopup(duration);
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in showing toast popup: " + ex.ToString());
				}
			}), new object[0]);
		}

		// Token: 0x060010FD RID: 4349 RVA: 0x00069A28 File Offset: 0x00067C28
		internal void HandleClientOperation(string operationString)
		{
			try
			{
				JObject jobject = JObject.Parse(operationString);
				string text = (string)jobject["EventAction"];
				if (text != null)
				{
					if (!(text == "RunApp"))
					{
						if (!(text == "BackButton"))
						{
							if (!(text == "HomeButton"))
							{
								if (!(text == "TabSelected"))
								{
									if (text == "TabClosed")
									{
										string tabKey = jobject["tabKey"].ToObject<string>();
										bool sendStopAppToAndroid = jobject["sendStopAppToAndroid"].ToObject<bool>();
										bool forceClose = jobject["forceClose"].ToObject<bool>();
										if (!string.IsNullOrEmpty(tabKey))
										{
											this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
											{
												this.ParentWindow.mTopBar.mAppTabButtons.CloseTab(tabKey, sendStopAppToAndroid, forceClose, true, true, "");
											}), new object[0]);
										}
									}
								}
								else
								{
									string tabKey = jobject["tabKey"].ToObject<string>();
									if (!string.IsNullOrEmpty(tabKey))
									{
										this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
										{
											this.ParentWindow.mTopBar.mAppTabButtons.GoToTab(tabKey, true, true);
										}), new object[0]);
									}
								}
							}
							else
							{
								bool isLaunch = jobject["IsLaunch"].ToObject<bool>();
								this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
								{
									this.HomeButtonHandler(isLaunch, true);
								}), new object[0]);
							}
						}
						else
						{
							this.BackButtonHandler(true);
						}
					}
					else
					{
						this.ParentWindow.mAppHandler.SendRunAppRequestAsync((string)jobject["Package"], (string)jobject["Activity"], true);
					}
				}
			}
			catch (Exception ex)
			{
				string str = "Exception in HandleClientOperation. OperationString: ";
				string str2 = " Error:";
				Exception ex2 = ex;
				Logger.Error(str + operationString + str2 + ((ex2 != null) ? ex2.ToString() : null));
			}
		}

		// Token: 0x060010FE RID: 4350 RVA: 0x0000C4B8 File Offset: 0x0000A6B8
		private bool CheckForMacroVisibility()
		{
			return !this.ParentWindow.mAppHandler.IsOneTimeSetupCompleted || CommonHandlers.ShowMacroForSelectedApp(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.TabKey);
		}

		// Token: 0x060010FF RID: 4351 RVA: 0x00069C54 File Offset: 0x00067E54
		private static bool ShowMacroForSelectedApp(string appPackage)
		{
			if (PromotionObject.Instance.AppSpecificRulesList != null)
			{
				foreach (string text in PromotionObject.Instance.AppSpecificRulesList)
				{
					string text2 = text;
					if (text.EndsWith("*", StringComparison.InvariantCulture))
					{
						text2 = text.Substring(0, text.Length - 2);
					}
					if (text2.StartsWith("~", StringComparison.InvariantCulture))
					{
						if (appPackage.StartsWith(text2.Substring(1), StringComparison.InvariantCulture))
						{
							return false;
						}
					}
					else if (appPackage.StartsWith(text2, StringComparison.InvariantCulture))
					{
						return true;
					}
				}
				return false;
			}
			return false;
		}

		// Token: 0x06001100 RID: 4352 RVA: 0x00069D08 File Offset: 0x00067F08
		private static bool IsCustomCursorEnableForApp(string appPackage)
		{
			bool result;
			try
			{
				if (!RegistryManager.Instance.CustomCursorEnabled || !FeatureManager.Instance.IsCustomCursorEnabled)
				{
					result = false;
				}
				else
				{
					string text = string.Empty;
					if (PromotionObject.Instance.CustomCursorExcludedAppsList != null)
					{
						foreach (string text2 in PromotionObject.Instance.CustomCursorExcludedAppsList)
						{
							text = text2;
							if (text2.EndsWith("*", StringComparison.InvariantCulture))
							{
								text = text2.Substring(0, text2.Length - 1);
							}
							if (text.StartsWith("~", StringComparison.InvariantCulture))
							{
								if (appPackage.StartsWith(text.Substring(1), StringComparison.InvariantCulture))
								{
									return true;
								}
							}
							else if (appPackage.StartsWith(text, StringComparison.InvariantCulture))
							{
								return false;
							}
						}
					}
					result = true;
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06001101 RID: 4353 RVA: 0x0000C4F2 File Offset: 0x0000A6F2
		internal void SetCustomCursorForApp(string appPackage)
		{
			this.ToggleCursorStyle(CommonHandlers.IsCustomCursorEnableForApp(appPackage));
		}

		// Token: 0x06001102 RID: 4354 RVA: 0x00069DF4 File Offset: 0x00067FF4
		internal void ClipMouseCursorHandler(bool forceDisable = false, bool switchState = true, string statAction = "", string sourceLocation = "")
		{
			try
			{
				if (!FeatureManager.Instance.IsCustomUIForDMM)
				{
					if (forceDisable)
					{
						this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsCursorClipped = false;
					}
					else if (switchState)
					{
						this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsCursorClipped = !this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsCursorClipped;
					}
					if (this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab != null && this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.mTabType == TabType.AppTab && this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsCursorClipped)
					{
						RECT rect = default(RECT);
						if (this.ParentWindow.StaticComponents.mLastMappableWindowHandle == IntPtr.Zero)
						{
							this.ParentWindow.StaticComponents.mLastMappableWindowHandle = this.ParentWindow.mFrontendHandler.mFrontendHandle;
						}
						InteropWindow.GetWindowRect(this.ParentWindow.StaticComponents.mLastMappableWindowHandle, ref rect);
						System.Drawing.Point location = new System.Drawing.Point(rect.Left, rect.Top);
						System.Drawing.Size size = new System.Drawing.Size(rect.Right - rect.Left, rect.Bottom - rect.Top);
						System.Windows.Forms.Cursor.Clip = new Rectangle(location, size);
						this.ParentWindow.OnCursorLockChanged(true);
						if (!string.IsNullOrEmpty(statAction))
						{
							ClientStats.SendMiscellaneousStatsAsync(sourceLocation, RegistryManager.Instance.UserGuid, "LockMouseCursor", statAction, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName, null);
							if (RegistryManager.Instance.IsShowToastNotification)
							{
								this.ParentWindow.ShowGeneralToast(string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_UNLOCK_CURSOR"), new object[]
								{
									this.GetShortcutKeyFromName("STRING_TOGGLE_LOCK_CURSOR", false)
								}));
							}
						}
					}
					else
					{
						System.Windows.Forms.Cursor.Clip = Rectangle.Empty;
						this.ParentWindow.OnCursorLockChanged(false);
						if (!string.IsNullOrEmpty(statAction))
						{
							ClientStats.SendMiscellaneousStatsAsync(sourceLocation, RegistryManager.Instance.UserGuid, "UnlockMouseCursor", statAction, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName, null);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ClipMouseCursorHandler. Exception: " + ex.ToString());
			}
		}

		// Token: 0x06001103 RID: 4355 RVA: 0x0006A0B4 File Offset: 0x000682B4
		internal string GetShortcutKeyFromName(string shortcutName, bool isBossKey = false)
		{
			try
			{
				if (this.mShortcutsConfigInstance != null)
				{
					using (List<ShortcutKeys>.Enumerator enumerator = this.mShortcutsConfigInstance.Shortcut.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							ShortcutKeys shortcutKeys = enumerator.Current;
							if (string.Equals(shortcutKeys.ShortcutName, shortcutName, StringComparison.InvariantCulture))
							{
								if (isBossKey)
								{
									return shortcutKeys.ShortcutKey;
								}
								string[] array = shortcutKeys.ShortcutKey.Split(new char[]
								{
									'+',
									' '
								}, StringSplitOptions.RemoveEmptyEntries);
								string text = string.Empty;
								foreach (string key in array)
								{
									text = text + LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(key)) + " + ";
								}
								if (!string.IsNullOrEmpty(text))
								{
									return text.Substring(0, text.Length - 3);
								}
							}
						}
						goto IL_136;
					}
					goto IL_E3;
					IL_136:
					goto IL_152;
				}
				IL_E3:
				string result;
				if (shortcutName != null)
				{
					if (shortcutName == "STRING_TOGGLE_LOCK_CURSOR")
					{
						result = "Ctrl + Shift + F8";
						goto IL_131;
					}
					if (shortcutName == "STRING_TOGGLE_KEYMAP_WINDOW")
					{
						result = "Ctrl + Shift + H";
						goto IL_131;
					}
					if (shortcutName == "STRING_TOGGLE_OVERLAY")
					{
						result = "Ctrl + Shift + F6";
						goto IL_131;
					}
				}
				result = "";
				IL_131:
				return result;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GetShortcutKeyFromName: " + ex.ToString());
			}
			IL_152:
			return "";
		}

		// Token: 0x06001104 RID: 4356 RVA: 0x0006A250 File Offset: 0x00068450
		internal static void SaveMacroJson(MacroRecording record, string destFileName)
		{
			try
			{
				JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
				serializerSettings.Formatting = Formatting.Indented;
				string contents = JsonConvert.SerializeObject(record, serializerSettings);
				if (!Directory.Exists(RegistryStrings.MacroRecordingsFolderPath))
				{
					Directory.CreateDirectory(RegistryStrings.MacroRecordingsFolderPath);
				}
				File.WriteAllText(Path.Combine(RegistryStrings.MacroRecordingsFolderPath, Path.GetFileName(destFileName.ToLower(CultureInfo.InvariantCulture).Trim())), contents);
			}
			catch (Exception ex)
			{
				Logger.Error("Could not serialize the macro recording object. Ex: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x06001105 RID: 4357 RVA: 0x0006A2D8 File Offset: 0x000684D8
		internal void ToggleMacroAndSyncVisibility()
		{
			try
			{
				if (FeatureManager.Instance.ForceEnableMacroAndSync)
				{
					this.OnMacroButtonVisibilityChanged(true);
					this.OnOperationSyncButtonVisibilityChanged(true);
				}
				else if (FeatureManager.Instance.IsMacroRecorderEnabled || FeatureManager.Instance.IsOperationsSyncEnabled)
				{
					bool isVisible = this.CheckForMacroVisibility();
					if (FeatureManager.Instance.IsMacroRecorderEnabled)
					{
						this.OnMacroButtonVisibilityChanged(isVisible);
					}
					if (FeatureManager.Instance.IsOperationsSyncEnabled)
					{
						this.OnOperationSyncButtonVisibilityChanged(isVisible);
					}
				}
				else
				{
					this.OnMacroButtonVisibilityChanged(false);
					this.OnOperationSyncButtonVisibilityChanged(false);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ToggleMacroAndSyncVisibility: " + ex.ToString());
			}
		}

		// Token: 0x06001106 RID: 4358 RVA: 0x0006A380 File Offset: 0x00068580
		private void ToggleCursorStyle(bool enable)
		{
			try
			{
				Dictionary<string, string> data = new Dictionary<string, string>();
				if (enable)
				{
					data.Add("path", RegistryStrings.CursorPath);
				}
				else
				{
					data.Add("path", string.Empty);
				}
				ThreadPool.QueueUserWorkItem(delegate(object obj1)
				{
					try
					{
						HTTPUtils.SendRequestToEngine("setCursorStyle", data, this.ParentWindow.mVmName, 3000, null, false, 1, 0, "");
						this.SetDefaultCursorForClient();
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to send Show event to engine... err : " + ex.ToString());
						this.SetDefaultCursorForClient();
					}
				});
			}
			catch (Exception)
			{
				this.SetDefaultCursorForClient();
			}
		}

		// Token: 0x06001107 RID: 4359 RVA: 0x0000C500 File Offset: 0x0000A700
		private void SetDefaultCursorForClient()
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj1)
			{
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					try
					{
						Mouse.OverrideCursor = null;
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to set default cursor for client... err : " + ex.ToString());
					}
				}), new object[0]);
			});
		}

		// Token: 0x06001108 RID: 4360 RVA: 0x0000C514 File Offset: 0x0000A714
		public void LaunchSettingsWindow()
		{
			if (MainWindow.SettingsWindow == null)
			{
				MainWindow.OpenSettingsWindow(this.ParentWindow, "");
			}
		}

		// Token: 0x06001109 RID: 4361 RVA: 0x0000C52D File Offset: 0x0000A72D
		public void DMMSwitchKeyMapButtonHandler()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (this.ParentWindow.mDmmBottomBar.mKeyMapSwitch.ImageName.EndsWith("_off", StringComparison.InvariantCulture))
				{
					this.ParentWindow.mDmmBottomBar.mKeyMapSwitch.ImageName = this.ParentWindow.mDmmBottomBar.mKeyMapSwitch.ImageName.Replace("_off", string.Empty);
					BlueStacksUIBinding.Bind(this.ParentWindow.mDmmBottomBar.mKeyMapSwitch, "STRING_KEYMAPPING_ENABLED");
					BlueStacksUIBinding.Bind(this.ParentWindow.mDMMFST.mKeyMapSwitch, "STRING_KEYMAPPING_ENABLED");
					this.ParentWindow.mFrontendHandler.EnableKeyMapping(true);
					this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.EnableKeymapForDMM(true);
				}
				else
				{
					CustomPictureBox mKeyMapSwitch = this.ParentWindow.mDmmBottomBar.mKeyMapSwitch;
					mKeyMapSwitch.ImageName += "_off";
					BlueStacksUIBinding.Bind(this.ParentWindow.mDmmBottomBar.mKeyMapSwitch, "STRING_KEYMAPPING_DISABLED");
					BlueStacksUIBinding.Bind(this.ParentWindow.mDMMFST.mKeyMapSwitch, "STRING_KEYMAPPING_DISABLED");
					this.ParentWindow.mFrontendHandler.EnableKeyMapping(false);
					this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.EnableKeymapForDMM(false);
				}
				this.ParentWindow.mDMMFST.mKeyMapSwitch.ImageName = this.ParentWindow.mDmmBottomBar.mKeyMapSwitch.ImageName;
			}), new object[0]);
		}

		// Token: 0x0600110A RID: 4362 RVA: 0x0006A404 File Offset: 0x00068604
		public void SetDMMKeymapButtonsAndTransparency()
		{
			if (this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsDMMKeymapUIVisible)
			{
				this.ParentWindow.mCommonHandler.EnableKeymapButtonsForDmm(Visibility.Visible);
				this.ParentWindow.mDmmBottomBar.ShowKeyMapPopup(true);
				KMManager.ShowOverlayWindow(this.ParentWindow, true, true);
				BlueStacksUIBinding.Bind(this.ParentWindow.mDmmBottomBar.mKeyMapSwitch, "STRING_KEYMAPPING_ENABLED");
				if (this.ParentWindow.mDmmBottomBar.CurrentTransparency > 0.0)
				{
					this.SetTranslucentControlsBtnImageForDMM("eye");
				}
				else
				{
					this.SetTranslucentControlsBtnImageForDMM("eye_off");
				}
			}
			else
			{
				this.ParentWindow.mCommonHandler.EnableKeymapButtonsForDmm(Visibility.Collapsed);
				this.ParentWindow.mDmmBottomBar.ShowKeyMapPopup(false);
				KMManager.ShowOverlayWindow(this.ParentWindow, false, false);
			}
			if (this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsDMMKeymapEnabled)
			{
				this.ParentWindow.mDmmBottomBar.mKeyMapSwitch.ImageName = "keymapswitch";
				this.ParentWindow.mDMMFST.mKeyMapSwitch.ImageName = "keymapswitch";
				this.ParentWindow.mFrontendHandler.EnableKeyMapping(true);
				return;
			}
			this.ParentWindow.mDmmBottomBar.mKeyMapSwitch.ImageName = "keymapswitch_off";
			this.ParentWindow.mDMMFST.mKeyMapSwitch.ImageName = "keymapswitch_off";
			this.ParentWindow.mFrontendHandler.EnableKeyMapping(false);
		}

		// Token: 0x0600110B RID: 4363 RVA: 0x0006A584 File Offset: 0x00068784
		public void EnableKeymapButtonsForDmm(Visibility isVisible)
		{
			this.ParentWindow.mDmmBottomBar.mKeyMapButton.Visibility = isVisible;
			this.ParentWindow.mDmmBottomBar.mKeyMapSwitch.Visibility = isVisible;
			this.ParentWindow.mDmmBottomBar.mTranslucentControlsButton.Visibility = isVisible;
			this.ParentWindow.mDMMFST.mKeyMapButton.Visibility = isVisible;
			this.ParentWindow.mDMMFST.mKeyMapSwitch.Visibility = isVisible;
			this.ParentWindow.mDMMFST.mTranslucentControlsButton.Visibility = isVisible;
		}

		// Token: 0x0600110C RID: 4364 RVA: 0x0006A618 File Offset: 0x00068818
		internal void SetTranslucentControlsBtnImageForDMM(string imageName)
		{
			this.ParentWindow.mDmmBottomBar.mTranslucentControlsButton.ImageName = imageName;
			this.ParentWindow.mDmmBottomBar.mTranslucentControlsSliderButton.ImageName = this.ParentWindow.mDmmBottomBar.mTranslucentControlsButton.ImageName;
			this.ParentWindow.mDMMFST.mTranslucentControlsButton.ImageName = this.ParentWindow.mDmmBottomBar.mTranslucentControlsButton.ImageName;
			this.ParentWindow.mDMMFST.mTranslucentControlsSliderButton.ImageName = this.ParentWindow.mDmmBottomBar.mTranslucentControlsButton.ImageName;
		}

		// Token: 0x0600110D RID: 4365 RVA: 0x0006A6BC File Offset: 0x000688BC
		internal void KeyMapButtonHandler(string action, string location)
		{
			KMManager.ShowAdvancedSettings(this.ParentWindow);
			ClientStats.SendMiscellaneousStatsAsync(location, RegistryManager.Instance.UserGuid, "KeyMap", action, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x0600110E RID: 4366 RVA: 0x0006A70C File Offset: 0x0006890C
		public void DMMScreenshotHandler()
		{
			using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog
			{
				ShowNewFolderButton = true,
				Description = LocaleStrings.GetLocalizedString("STRING_CHOOSE_SCREENSHOT_FOLDER_TEXT")
			})
			{
				if (folderBrowserDialog.ShowDialog(Utils.GetIWin32Window(this.ParentWindow.Handle)) == DialogResult.OK && !string.IsNullOrEmpty(folderBrowserDialog.SelectedPath))
				{
					string screenShotsPath = Directory.Exists(folderBrowserDialog.SelectedPath) ? folderBrowserDialog.SelectedPath : RegistryStrings.ScreenshotDefaultPath;
					RegistryManager.Instance.ScreenShotsPath = screenShotsPath;
				}
			}
		}

		// Token: 0x0600110F RID: 4367 RVA: 0x0006A7A0 File Offset: 0x000689A0
		public void RecordVideoOfApp()
		{
			Logger.Debug("OBS start or stop status: {0}", new object[]
			{
				CommonHandlers.sIsOBSStartingStopping
			});
			if (!CommonHandlers.sIsOBSStartingStopping)
			{
				CommonHandlers.sIsOBSStartingStopping = true;
				if (RegistryManager.Instance.IsScreenshotsLocationPopupEnabled)
				{
					this.ShowScreenShotFolderUpdatePopup();
				}
				string text = RegistryManager.Instance.ScreenShotsPath;
				if (!StringExtensions.IsValidPath(text))
				{
					if (!Directory.Exists(RegistryStrings.ScreenshotDefaultPath))
					{
						Directory.CreateDirectory(RegistryStrings.ScreenshotDefaultPath);
					}
					RegistryManager.Instance.ScreenShotsPath = RegistryStrings.ScreenshotDefaultPath;
					text = RegistryStrings.ScreenshotDefaultPath;
				}
				string text2 = DateTime.Now.ToString("yyyy.MM.dd_HH.mm.ss.ff", CultureInfo.InvariantCulture);
				string path = string.Format(CultureInfo.InvariantCulture, Strings.ProductTopBarDisplayName + "_Recording_{0}.mp4", new object[]
				{
					text2
				});
				string filePath = Path.Combine(text, path);
				if (text == RegistryStrings.ScreenshotDefaultPath && !Directory.Exists(RegistryStrings.ScreenshotDefaultPath))
				{
					Directory.CreateDirectory(RegistryStrings.ScreenshotDefaultPath);
				}
				ClientStats.SendMiscellaneousStatsAsync("VideoRecording", RegistryManager.Instance.UserGuid, "VideoRecordingStarting", RegistryManager.Instance.ScreenShotsPath, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
				Action <>9__1;
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					try
					{
						CommonHandlers.sRecordingInstance = this.ParentWindow.mVmName;
						if (StreamManager.Instance == null)
						{
							StreamManager.Instance = new StreamManager(this.ParentWindow);
						}
						string text3 = this.ParentWindow.mFrontendHandler.mFrontendHandle.ToString();
						Dispatcher dispatcher = this.ParentWindow.Dispatcher;
						Action method;
						if ((method = <>9__1) == null)
						{
							method = (<>9__1 = delegate()
							{
								this.ParentWindow.RestrictWindowResize(true);
								this.OnScreenRecorderStateTransitioning();
								this.StartLoadingTimeoutTimer();
							});
						}
						dispatcher.Invoke(method, new object[0]);
						Process currentProcess = Process.GetCurrentProcess();
						StreamManager.Instance.Init(text3, currentProcess.Id.ToString(CultureInfo.InvariantCulture));
						StreamManager.sStopInitOBSQueue = false;
						try
						{
							StreamManager.Instance.StartObs();
						}
						catch (Exception ex)
						{
							Logger.Error("Exception in StartObs: {0}", new object[]
							{
								ex
							});
							this.ShowErrorRecordingVideoPopup();
							return;
						}
						StreamManager.Instance.SetMicVolume("0");
						StreamManager.Instance.SetHwnd(text3);
						StreamManager.Instance.SetSavePath(filePath);
						CommonHandlers.mSavedVideoRecordingFilePath = filePath;
						StreamManager.Instance.EnableVideoRecording(true);
						StreamManager.Instance.StartRecordForVideo();
						CommonHandlers.sIsRecordingVideo = true;
					}
					catch (Exception ex2)
					{
						Logger.Error("Error in RecordVideoOfApp: {0}", new object[]
						{
							ex2
						});
					}
				});
				return;
			}
		}

		// Token: 0x06001110 RID: 4368 RVA: 0x0006A8FC File Offset: 0x00068AFC
		private void StartLoadingTimeoutTimer()
		{
			if (this.mObsResponseTimeoutTimer == null)
			{
				this.mObsResponseTimeoutTimer = new System.Timers.Timer(20000.0);
				this.mObsResponseTimeoutTimer.Elapsed += this.ObsResponseTimeoutTimer_Elapsed;
				this.mObsResponseTimeoutTimer.AutoReset = false;
			}
			if (!this.mObsResponseTimeoutTimer.Enabled)
			{
				this.mObsResponseTimeoutTimer.Start();
			}
		}

		// Token: 0x06001111 RID: 4369 RVA: 0x0006A960 File Offset: 0x00068B60
		private void ObsResponseTimeoutTimer_Elapsed(object sender, ElapsedEventArgs e)
		{
			this.OnOBSResponseTimeout();
			CommonHandlers.sIsRecordingVideo = false;
			CommonHandlers.sIsOBSStartingStopping = false;
			CommonHandlers.sRecordingInstance = "";
			this.ParentWindow.RestrictWindowResize(false);
			if (StreamManager.Instance != null)
			{
				StreamManager.Instance.ShutDownForcefully();
			}
			this.ShowErrorRecordingVideoPopup();
		}

		// Token: 0x06001112 RID: 4370 RVA: 0x0006A9AC File Offset: 0x00068BAC
		internal void StopRecordVideo()
		{
			try
			{
				this.OnScreenRecorderStateTransitioning();
				this.StartLoadingTimeoutTimer();
				StreamManager.Instance.StopRecord();
			}
			catch (Exception ex)
			{
				Logger.Error("error in stop record video : {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x06001113 RID: 4371 RVA: 0x0006A9F8 File Offset: 0x00068BF8
		internal void RecordingStopped()
		{
			System.Timers.Timer timer = this.mObsResponseTimeoutTimer;
			if (timer != null)
			{
				timer.Stop();
			}
			this.ParentWindow.RestrictWindowResize(false);
			this.OnScreenRecordingStateChanged(false);
			ClientStats.SendMiscellaneousStatsAsync("VideoRecording", RegistryManager.Instance.UserGuid, "VideoRecordingDone", RegistryManager.Instance.ScreenShotsPath, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06001114 RID: 4372 RVA: 0x0006AA6C File Offset: 0x00068C6C
		internal void DownloadAndLaunchRecording(string location, string action)
		{
			Logger.Debug("value of sRecordingInstance: {0} and sIsRecordingVideo: {1}", new object[]
			{
				CommonHandlers.sRecordingInstance,
				CommonHandlers.sIsRecordingVideo
			});
			if (!CommonHandlers.sIsRecordingVideo)
			{
				if (Directory.Exists(RegistryStrings.ObsDir) && File.Exists(RegistryStrings.ObsBinaryPath))
				{
					if (!RegistryManager.Instance.IsBTVCheckedAfterUpdate && !CommonHandlers.IsBtvLatestVersionDownloaded())
					{
						this.DownloadObsPopup();
						ClientStats.SendMiscellaneousStatsAsync(location, RegistryManager.Instance.UserGuid, "VideoRecordingDownload", action, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
					}
					else if (!ProcessUtils.FindProcessByName("HD-OBS"))
					{
						if (!this.InsufficientSpacePopup())
						{
							this.RecordVideoOfApp();
							ClientStats.SendMiscellaneousStatsAsync(location, RegistryManager.Instance.UserGuid, "VideoRecordingStart", action, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
						}
					}
					else
					{
						this.ShowAlreadyRunningPopUpForOBS();
					}
				}
				else
				{
					this.DownloadObsPopup();
					ClientStats.SendMiscellaneousStatsAsync(location, RegistryManager.Instance.UserGuid, "VideoRecordingDownload", action, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
				}
				RegistryManager.Instance.IsBTVCheckedAfterUpdate = true;
				return;
			}
			if (string.Equals(CommonHandlers.sRecordingInstance, this.ParentWindow.mVmName, StringComparison.InvariantCulture))
			{
				this.StopRecordVideo();
				ClientStats.SendMiscellaneousStatsAsync(location, RegistryManager.Instance.UserGuid, "VideoRecordingStop", action, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
				return;
			}
			this.ShowAlreadyRunningPopUpForOBS();
		}

		// Token: 0x06001115 RID: 4373 RVA: 0x0006AC18 File Offset: 0x00068E18
		private bool InsufficientSpacePopup()
		{
			bool recording = true;
			double num = CommonHandlers.FindAvailableSpaceinMB(RegistryManager.Instance.ScreenShotsPath);
			EventHandler <>9__0;
			MouseButtonEventHandler <>9__1;
			while (num < 30.0 && recording)
			{
				RegistryManager.Instance.IsScreenshotsLocationPopupEnabled = false;
				string screenShotsPath = RegistryManager.Instance.ScreenShotsPath;
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_INSUFFICIENT_SPACE", "");
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_CHANGE_PATH", new EventHandler(this.ChooseCustomFolder), null, false, null);
				ButtonColors color = ButtonColors.White;
				string text = "STRING_STOP_RECORDING";
				EventHandler handle;
				if ((handle = <>9__0) == null)
				{
					handle = (<>9__0 = delegate(object o, EventArgs evt)
					{
						recording = false;
					});
				}
				customMessageWindow.AddButton(color, text, handle, null, false, null);
				UIElement closeButton = customMessageWindow.CloseButton;
				MouseButtonEventHandler value;
				if ((value = <>9__1) == null)
				{
					value = (<>9__1 = delegate(object o, MouseButtonEventArgs evt)
					{
						recording = false;
					});
				}
				closeButton.PreviewMouseUp += value;
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_INSUFFICIENT_RECORDING_SPACE", "");
				customMessageWindow.BodyWarningTextBlock.Visibility = Visibility.Visible;
				customMessageWindow.BodyWarningTextBlock.Text = screenShotsPath;
				BlueStacksUIBinding.BindColor(customMessageWindow.BodyWarningTextBlock, TextBlock.ForegroundProperty, "HyperLinkForegroundColor");
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
				num = CommonHandlers.FindAvailableSpaceinMB(RegistryManager.Instance.ScreenShotsPath);
			}
			return !recording;
		}

		// Token: 0x06001116 RID: 4374 RVA: 0x0006AD8C File Offset: 0x00068F8C
		private static double FindAvailableSpaceinMB(string path)
		{
			double result = double.MaxValue;
			string pathRoot = Path.GetPathRoot(path);
			double num = Math.Pow(2.0, 20.0);
			foreach (DriveInfo driveInfo in DriveInfo.GetDrives())
			{
				if (driveInfo.IsReady && driveInfo.Name == pathRoot)
				{
					result = (double)driveInfo.AvailableFreeSpace / num;
				}
			}
			return result;
		}

		// Token: 0x06001117 RID: 4375 RVA: 0x0006AE04 File Offset: 0x00069004
		private void ShowAlreadyRunningPopUpForOBS()
		{
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_NOT_START_RECORDER", "");
			BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_RECORDER_ALREADY_RUNNING", "");
			customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
			customMessageWindow.Owner = this.ParentWindow;
			this.ParentWindow.ShowDimOverlay(null);
			customMessageWindow.ShowDialog();
			this.ParentWindow.HideDimOverlay();
		}

		// Token: 0x06001118 RID: 4376 RVA: 0x0006AE7C File Offset: 0x0006907C
		private static bool IsBtvLatestVersionDownloaded()
		{
			string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(new Uri(CommonHandlers.GetBtvUrl()).LocalPath);
			return string.Compare(RegistryManager.Instance.CurrentBtvVersionInstalled, fileNameWithoutExtension, StringComparison.InvariantCulture) >= 0;
		}

		// Token: 0x06001119 RID: 4377 RVA: 0x0006AEB8 File Offset: 0x000690B8
		private static string GetBtvUrl()
		{
			string url = WebHelper.GetUrlWithParams(RegistryManager.Instance.Host + "/bs4/btv/GetBTVFile");
			if (!string.IsNullOrEmpty(RegistryManager.Instance.BtvDevServer))
			{
				url = RegistryManager.Instance.BtvDevServer;
			}
			return BTVManager.GetRedirectedUrl(url);
		}

		// Token: 0x0600111A RID: 4378 RVA: 0x0006AF04 File Offset: 0x00069104
		private void DownloadObsPopup()
		{
			if (CommonHandlers.sDownloading && CommonHandlers.sWindow != null && !CommonHandlers.sWindow.IsClosed)
			{
				this.DownloadObs(null, null);
				return;
			}
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_RECORDER_REQUIRED");
				customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_VIDEO_RECORDER_DOWNLOAD_BODY");
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_DOWNLOAD_NOW", new EventHandler(this.DownloadObs), null, false, null);
				customMessageWindow.Owner = this.ParentWindow;
				customMessageWindow.ContentMaxWidth = 450.0;
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
			}), new object[0]);
		}

		// Token: 0x0600111B RID: 4379 RVA: 0x0006AF58 File Offset: 0x00069158
		private void DownloadObs(object sender, EventArgs e)
		{
			if (CommonHandlers.sDownloading && CommonHandlers.sWindow != null && !CommonHandlers.sWindow.IsClosed)
			{
				BTVManager.BringToFront(CommonHandlers.sWindow);
				return;
			}
			if (!BTVManager.IsDirectXComponentsInstalled())
			{
				CustomMessageWindow downloadReqWindow = new CustomMessageWindow();
				downloadReqWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_ADDITIONAL_FILES_REQUIRED");
				downloadReqWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_SOME_WINDOW_FILES_MISSING");
				string directXDownloadURL = "http://www.microsoft.com/en-us/download/details.aspx?id=35";
				downloadReqWindow.AddHyperLinkInUI(directXDownloadURL, new Uri(directXDownloadURL), delegate(object o, RequestNavigateEventArgs arg)
				{
					BlueStacksUIUtils.OpenUrl(arg.Uri.ToString());
					downloadReqWindow.CloseWindow();
				});
				downloadReqWindow.AddButton(ButtonColors.Blue, "STRING_DOWNLOAD_NOW", delegate(object o, EventArgs args)
				{
					BlueStacksUIUtils.OpenUrl(directXDownloadURL);
				}, null, false, null);
				downloadReqWindow.Owner = this.ParentWindow;
				downloadReqWindow.ContentMaxWidth = 450.0;
				this.ParentWindow.ShowDimOverlay(null);
				downloadReqWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
				return;
			}
			CommonHandlers.sDownloading = true;
			CommonHandlers.sWindow = new CustomMessageWindow();
			BlueStacksUIBinding.Bind(CommonHandlers.sWindow.TitleTextBlock, "STRING_DOWNLOAD_ADDITIONAL", "");
			BlueStacksUIBinding.Bind(CommonHandlers.sWindow.BodyWarningTextBlock, "STRING_NOT_CLOSE_DOWNLOAD_COMPLETE", "");
			CommonHandlers.sWindow.BodyWarningTextBlock.Visibility = Visibility.Visible;
			CommonHandlers.sWindow.BodyTextBlock.Visibility = Visibility.Collapsed;
			CommonHandlers.sWindow.CloseButtonHandle(new Predicate<object>(this.RecorderDownloadCancelledHandler), null);
			CustomMessageWindow customMessageWindow = CommonHandlers.sWindow;
			customMessageWindow.MinimizeEventHandler = (EventHandler)Delegate.Combine(customMessageWindow.MinimizeEventHandler, new EventHandler(this.BtvDownloadWindowMinimizedHandler));
			CommonHandlers.sWindow.ProgressBarEnabled = true;
			CommonHandlers.sWindow.IsWindowMinizable = true;
			CommonHandlers.sWindow.IsWindowClosable = true;
			CommonHandlers.sWindow.ShowInTaskbar = false;
			CommonHandlers.sWindow.IsWithoutButtons = true;
			CommonHandlers.sWindow.ContentMaxWidth = 450.0;
			CommonHandlers.sWindow.IsDraggable = true;
			CommonHandlers.sWindow.Owner = this.ParentWindow;
			CommonHandlers.sWindow.IsShowGLWindow = true;
			CommonHandlers.sWindow.Show();
			new Thread(delegate()
			{
				string btvUrl = CommonHandlers.GetBtvUrl();
				if (btvUrl == null)
				{
					Logger.Error("The download url was null");
					this.ShowErrorDownloadingRecorder();
					return;
				}
				string fileName = Path.GetFileName(new Uri(btvUrl).LocalPath);
				string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(new Uri(btvUrl).LocalPath);
				string downloadPath = Path.Combine(Path.GetTempPath(), fileName);
				this.mDownloader = new LegacyDownloader(3, btvUrl, downloadPath);
				this.mDownloader.Download(delegate(int percent)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						if (CommonHandlers.sWindow == null)
						{
							return;
						}
						CommonHandlers.sWindow.CustomProgressBar.Value = (double)percent;
					}), new object[0]);
				}, delegate(string filePath)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						if (CommonHandlers.sWindow == null)
						{
							return;
						}
						CommonHandlers.sWindow.CustomProgressBar.Value = 100.0;
					}), new object[0]);
					Logger.Info("Successfully downloaded BlueStacks TV");
					RegistryManager.Instance.CurrentBtvVersionInstalled = fileNameWithoutExtension;
					if (BTVManager.ExtractBTv(downloadPath))
					{
						Utils.DeleteFile(downloadPath);
						this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
						{
							CustomMessageWindow customMessageWindow2 = CommonHandlers.sWindow;
							if (customMessageWindow2 != null)
							{
								customMessageWindow2.Close();
							}
							CommonHandlers.sWindow = null;
							if (this.ParentWindow.mClosed)
							{
								return;
							}
							CustomMessageWindow customMessageWindow3 = new CustomMessageWindow();
							BlueStacksUIBinding.Bind(customMessageWindow3.TitleTextBlock, "STRING_RECORDER_DOWNLOADED", "");
							BlueStacksUIBinding.Bind(customMessageWindow3.BodyTextBlock, "STRING_RECORDER_READY_BODY", "");
							customMessageWindow3.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
							customMessageWindow3.Owner = this.ParentWindow;
							customMessageWindow3.ContentMaxWidth = 450.0;
							this.ParentWindow.ShowDimOverlay(null);
							customMessageWindow3.ShowDialog();
							this.ParentWindow.HideDimOverlay();
						}), new object[0]);
						return;
					}
					Utils.DeleteFile(downloadPath);
					this.ShowErrorDownloadingRecorder();
				}, delegate(Exception ex)
				{
					Logger.Error("Failed to download file: {0}. err: {1}", new object[]
					{
						downloadPath,
						ex.Message
					});
					if (ex.InnerException is OperationCanceledException)
					{
						return;
					}
					this.ShowErrorDownloadingRecorder();
				}, null, delegate(long size)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						if (CommonHandlers.sWindow == null)
						{
							return;
						}
						CommonHandlers.sWindow.ProgressStatusTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_DOWNLOADING");
						CommonHandlers.sWindow.ProgressPercentageTextBlock.Content = ((float)size / 1048576f).ToString("F", CultureInfo.InvariantCulture) + " MB / " + this.mRecorderSizeMb.ToString("F", CultureInfo.InvariantCulture) + " MB ";
						this.mDownloadedSize = size;
					}), new object[0]);
				}, delegate(long size)
				{
					this.mRecorderSizeMb = (float)size / 1048576f;
				});
				CommonHandlers.sDownloading = false;
			})
			{
				IsBackground = true
			}.Start();
			this.mDownloadStatusTimer = new DispatcherTimer
			{
				Interval = new TimeSpan(0, 0, 5)
			};
			this.mDownloadStatusTimer.Tick += this.DownloadStatusTimerTick;
			this.mDownloadStatusTimer.Start();
		}

		// Token: 0x0600111C RID: 4380 RVA: 0x0000C552 File Offset: 0x0000A752
		private void BtvDownloadWindowMinimizedHandler(object sender, EventArgs e)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.OnBTvDownloaderMinimized();
				this.ParentWindow.Focus();
			}), new object[0]);
		}

		// Token: 0x0600111D RID: 4381 RVA: 0x0006B1E8 File Offset: 0x000693E8
		private void DownloadStatusTimerTick(object sender, EventArgs e)
		{
			if ((!CommonHandlers.sDownloading && CommonHandlers.sWindow != null) || CommonHandlers.sWindow == null)
			{
				this.mDownloadStatusTimer.Stop();
				return;
			}
			try
			{
				if (this.mLastSizeChecked != this.mDownloadedSize)
				{
					this.mLastSizeChecked = this.mDownloadedSize;
					CommonHandlers.sWindow.ProgressStatusTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_DOWNLOADING");
				}
				else
				{
					CommonHandlers.sWindow.ProgressStatusTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_WAITING_FOR_INTERNET");
				}
			}
			catch (Exception ex)
			{
				string str = "Exception in DownloadStatusTimerTick. Exception: ";
				Exception ex2 = ex;
				Logger.Error(str + ((ex2 != null) ? ex2.ToString() : null));
			}
		}

		// Token: 0x0600111E RID: 4382 RVA: 0x0000C577 File Offset: 0x0000A777
		private void ShowErrorDownloadingRecorder()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_DOWNLOAD_FAILED", "");
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_ERROR_RECORDER_DOWNLOAD", "");
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_CLOSE", null, null, false, null);
				customMessageWindow.Owner = this.ParentWindow;
				customMessageWindow.ContentMaxWidth = 450.0;
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
				CustomMessageWindow customMessageWindow2 = CommonHandlers.sWindow;
				if (customMessageWindow2 != null)
				{
					customMessageWindow2.Close();
				}
				CommonHandlers.sWindow = null;
			}), new object[0]);
		}

		// Token: 0x0600111F RID: 4383 RVA: 0x0000C59C File Offset: 0x0000A79C
		internal void ShowErrorRecordingVideoPopup()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_RECORDING_ERROR", "");
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_RECORDING_ERROR_BODY", "");
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
				customMessageWindow.Owner = this.ParentWindow;
				customMessageWindow.ContentMaxWidth = 450.0;
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
			}), new object[0]);
		}

		// Token: 0x06001120 RID: 4384 RVA: 0x0006B298 File Offset: 0x00069498
		private bool RecorderDownloadCancelledHandler(object sender)
		{
			CustomMessageWindow cancelDownloadConfirmation = new CustomMessageWindow();
			BlueStacksUIBinding.Bind(cancelDownloadConfirmation.TitleTextBlock, "STRING_DOWNLOAD_IN_PROGRESS", "");
			BlueStacksUIBinding.Bind(cancelDownloadConfirmation.BodyTextBlock, "STRING_DOWNLOAD_NOT_COMPLETE", "");
			cancelDownloadConfirmation.AddButton(ButtonColors.Red, "STRING_CANCEL", delegate(object o, EventArgs args)
			{
				CustomMessageWindow customMessageWindow = CommonHandlers.sWindow;
				if (customMessageWindow != null)
				{
					customMessageWindow.Close();
				}
				CommonHandlers.sWindow = null;
				LegacyDownloader legacyDownloader = this.mDownloader;
				if (legacyDownloader == null)
				{
					return;
				}
				legacyDownloader.AbortDownload();
			}, null, false, null);
			cancelDownloadConfirmation.AddButton(ButtonColors.White, "STRING_CONTINUE", delegate(object o, EventArgs args)
			{
				cancelDownloadConfirmation.DialogResult = new bool?(true);
			}, null, false, null);
			cancelDownloadConfirmation.Owner = this.ParentWindow;
			this.ParentWindow.ShowDimOverlay(null);
			bool? flag = cancelDownloadConfirmation.ShowDialog();
			this.ParentWindow.HideDimOverlay();
			bool? flag2 = flag;
			bool flag3 = true;
			return flag2.GetValueOrDefault() == flag3 & flag2 != null;
		}

		// Token: 0x06001121 RID: 4385 RVA: 0x0006B37C File Offset: 0x0006957C
		public void RecordingStarted()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				CommonHandlers.sIsOBSStartingStopping = false;
				System.Timers.Timer timer = this.mObsResponseTimeoutTimer;
				if (timer != null)
				{
					timer.Stop();
				}
				this.OnScreenRecordingStateChanged(true);
				if (RegistryManager.Instance.IsShowToastNotification)
				{
					this.ParentWindow.ShowGeneralToast(LocaleStrings.GetLocalizedString("STRING_RECORDING_STARTED"));
				}
			}), new object[0]);
			ClientStats.SendMiscellaneousStatsAsync("VideoRecording", RegistryManager.Instance.UserGuid, "VideoRecordingStarted", RegistryManager.Instance.ScreenShotsPath, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06001122 RID: 4386 RVA: 0x0006B3F0 File Offset: 0x000695F0
		public void StopMacroRecording()
		{
			this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("stopRecordingCombo", null);
			foreach (object obj in this.ParentWindow.MacroRecorderWindow.mScriptsStackPanel.Children)
			{
				CommonHandlers.EnableScriptControl((SingleMacroControl)obj);
			}
			this.ParentWindow.MacroRecorderWindow.mStartMacroRecordingBtn.Visibility = Visibility.Visible;
			this.ParentWindow.MacroRecorderWindow.mStopMacroRecordingBtn.Visibility = Visibility.Collapsed;
			this.ParentWindow.MacroRecorderWindow.mScriptsStackPanel.Visibility = Visibility.Visible;
			this.ParentWindow.mTopBar.mMacroRecorderToolTipPopup.IsOpen = false;
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.ParentWindow.mNCTopBar.mMacroRecordGrid.Visibility = Visibility.Collapsed;
				this.ParentWindow.mNCTopBar.mMacroRecordControl.StopTimer();
				return;
			}
			this.ParentWindow.mTopBar.mMacroRecordControl.Visibility = Visibility.Collapsed;
			this.ParentWindow.mTopBar.mMacroRecordControl.StopTimer();
		}

		// Token: 0x06001123 RID: 4387 RVA: 0x0006B528 File Offset: 0x00069728
		public void StartMacroRecording()
		{
			this.ParentWindow.mIsMacroRecorderActive = true;
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.ParentWindow.mNCTopBar.ShowRecordingIcons();
			}
			else
			{
				this.ParentWindow.mTopBar.ShowRecordingIcons();
			}
			this.ParentWindow.MacroRecorderWindow.mStartMacroRecordingBtn.Visibility = Visibility.Collapsed;
			this.ParentWindow.MacroRecorderWindow.mStopMacroRecordingBtn.Visibility = Visibility.Visible;
			foreach (object obj in this.ParentWindow.MacroRecorderWindow.mScriptsStackPanel.Children)
			{
				CommonHandlers.DisableScriptControl((SingleMacroControl)obj);
			}
			this.ParentWindow.mCommonHandler.HideMacroRecorderWindow();
			this.ParentWindow.Focus();
			this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("startRecordingCombo", null);
		}

		// Token: 0x06001124 RID: 4388 RVA: 0x0006B628 File Offset: 0x00069828
		internal void InitUiOnMacroPlayback(MacroRecording recording)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.ParentWindow.Focus();
				this.ParentWindow.MacroRecorderWindow.mStartMacroRecordingBtn.IsEnabled = false;
				this.ParentWindow.MacroRecorderWindow.mStartMacroRecordingBtn.Opacity = 0.6;
				if (FeatureManager.Instance.IsCustomUIForNCSoft)
				{
					this.ParentWindow.mNCTopBar.ShowMacroPlaybackOnTopBar(recording);
					this.ParentWindow.mNCTopBar.mMacroPlayControl.mStartTime = DateTime.Now;
				}
				else
				{
					this.ParentWindow.mTopBar.ShowMacroPlaybackOnTopBar(recording);
					this.ParentWindow.mTopBar.mMacroPlayControl.mStartTime = DateTime.Now;
				}
				this.ParentWindow.mMacroPlaying = recording.Name;
				if (recording.RestartPlayer)
				{
					this.ParentWindow.StartTimerForAppPlayerRestart(recording.RestartPlayerAfterMinutes);
				}
			}), new object[0]);
		}

		// Token: 0x06001125 RID: 4389 RVA: 0x0006B66C File Offset: 0x0006986C
		internal void PlayMacroScript(MacroRecording record)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.ParentWindow.MacroRecorderWindow.mStartMacroRecordingBtn.Visibility = Visibility.Visible;
				this.ParentWindow.MacroRecorderWindow.mStartMacroRecordingBtn.IsEnabled = false;
				this.ParentWindow.MacroRecorderWindow.mStartMacroRecordingBtn.Opacity = 0.6;
				foreach (object obj in this.ParentWindow.MacroRecorderWindow.mScriptsStackPanel.Children)
				{
					SingleMacroControl singleMacroControl = (SingleMacroControl)obj;
					if (singleMacroControl.mRecording.Name != record.Name)
					{
						CommonHandlers.DisableScriptControl(singleMacroControl);
					}
					else
					{
						singleMacroControl.mEditNameImg.IsEnabled = false;
					}
				}
				this.ParentWindow.MacroRecorderWindow.RunMacroOperation(record);
			}), new object[0]);
		}

		// Token: 0x06001126 RID: 4390 RVA: 0x0006B6B0 File Offset: 0x000698B0
		internal void FullMacroScriptPlayHandler(MacroRecording record)
		{
			string name = record.Name;
			this.ParentWindow.mCommonHandler.PlayMacroScript(record);
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.ParentWindow.mNCTopBar.mMacroPlayControl.OnScriptPlayEvent(name);
				return;
			}
			this.ParentWindow.mTopBar.mMacroPlayControl.OnScriptPlayEvent(name);
		}

		// Token: 0x06001127 RID: 4391 RVA: 0x0000C5C1 File Offset: 0x0000A7C1
		internal void StopMacroScriptHandling()
		{
			this.ParentWindow.MacroRecorderWindow.mBGMacroPlaybackWorker.CancelAsync();
			this.StopMacroPlaybackOperation();
			this.ParentWindow.SetMacroPlayBackEventHandle();
		}

		// Token: 0x06001128 RID: 4392 RVA: 0x0006B710 File Offset: 0x00069910
		internal void StopMacroPlaybackOperation()
		{
			Logger.Info("In StopMacroPlaybackOperation");
			this.ParentWindow.mIsMacroPlaying = false;
			foreach (object obj in this.ParentWindow.MacroRecorderWindow.mScriptsStackPanel.Children)
			{
				CommonHandlers.EnableScriptControl((SingleMacroControl)obj);
			}
			this.ParentWindow.MacroRecorderWindow.mStartMacroRecordingBtn.Visibility = Visibility.Visible;
			this.ParentWindow.MacroRecorderWindow.mStartMacroRecordingBtn.IsEnabled = true;
			this.ParentWindow.MacroRecorderWindow.mStartMacroRecordingBtn.Opacity = 1.0;
			this.ParentWindow.MacroRecorderWindow.mScriptsStackPanel.Visibility = Visibility.Visible;
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.ParentWindow.mNCTopBar.HideMacroPlaybackFromTopBar();
			}
			else
			{
				this.ParentWindow.mTopBar.HideMacroPlaybackFromTopBar();
			}
			this.ParentWindow.mMacroPlaying = string.Empty;
			if (this.ParentWindow.mMacroTimer != null && this.ParentWindow.mMacroTimer.Enabled)
			{
				this.ParentWindow.mMacroTimer.Enabled = false;
				this.ParentWindow.mMacroTimer.AutoReset = false;
				this.ParentWindow.mMacroTimer.Dispose();
			}
			this.ParentWindow.mTopBar.mMacroRunningToolTipPopup.IsOpen = false;
			this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("stopMacroPlayback", null);
		}

		// Token: 0x06001129 RID: 4393 RVA: 0x0006B8A8 File Offset: 0x00069AA8
		public static void EnableScriptControl(SingleMacroControl mScriptControl)
		{
			mScriptControl.Opacity = 1.0;
			mScriptControl.mBookmarkImg.IsEnabled = true;
			mScriptControl.mEditNameImg.IsEnabled = true;
			mScriptControl.mPlayScriptImg.IsEnabled = true;
			mScriptControl.mScriptSettingsImg.IsEnabled = true;
			mScriptControl.mDeleteScriptImg.IsEnabled = true;
		}

		// Token: 0x0600112A RID: 4394 RVA: 0x0006B900 File Offset: 0x00069B00
		public static void DisableScriptControl(SingleMacroControl mScriptControl)
		{
			mScriptControl.Opacity = 0.4;
			mScriptControl.mBookmarkImg.IsEnabled = false;
			mScriptControl.mEditNameImg.IsEnabled = false;
			mScriptControl.mPlayScriptImg.IsEnabled = false;
			mScriptControl.mScriptSettingsImg.IsEnabled = false;
			mScriptControl.mDeleteScriptImg.IsEnabled = false;
		}

		// Token: 0x0600112B RID: 4395 RVA: 0x0006B958 File Offset: 0x00069B58
		internal void CheckForMacroScriptOnRestart()
		{
			foreach (MacroRecording record in from MacroRecording macro in MacroGraph.Instance.Vertices
			where macro.PlayOnStart
			select macro)
			{
				this.InitUiAndPlayMacroScript(record);
			}
		}

		// Token: 0x0600112C RID: 4396 RVA: 0x0006B9D4 File Offset: 0x00069BD4
		private void InitUiAndPlayMacroScript(MacroRecording record)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.RefreshMacroRecorderWindow();
				this.ParentWindow.mTopBar.mMacroPlayControl.OnScriptPlayEvent(record.Name.ToLower(CultureInfo.InvariantCulture));
				this.PlayMacroScript(record);
			}), new object[0]);
		}

		// Token: 0x0600112D RID: 4397 RVA: 0x0006BA18 File Offset: 0x00069C18
		public static void OpenMediaFolder()
		{
			if (Directory.Exists(RegistryManager.Instance.ScreenShotsPath))
			{
				using (Process process = new Process())
				{
					process.StartInfo.UseShellExecute = true;
					process.StartInfo.FileName = RegistryManager.Instance.ScreenShotsPath;
					process.Start();
				}
			}
		}

		// Token: 0x0600112E RID: 4398 RVA: 0x0006BA80 File Offset: 0x00069C80
		public static void OpenMediaFolderWithFileSelected(string selectedFile)
		{
			if (Directory.Exists(RegistryManager.Instance.ScreenShotsPath))
			{
				using (Process process = new Process())
				{
					process.StartInfo.UseShellExecute = true;
					process.StartInfo.FileName = "explorer.exe";
					process.StartInfo.Arguments = string.Format(CultureInfo.InvariantCulture, "/select,\"{0}\"", new object[]
					{
						selectedFile
					});
					process.Start();
				}
			}
		}

		// Token: 0x0600112F RID: 4399 RVA: 0x0006BB08 File Offset: 0x00069D08
		internal void SetSidebarImageProperties(bool isVisible, CustomPictureBox cpb, TextBlock tb)
		{
			if (isVisible)
			{
				if (cpb != null)
				{
					cpb.ImageName = "sidebar_hide";
					BlueStacksUIBinding.Bind(cpb, "STRING_CLOSE_SIDEBAR");
				}
				if (tb != null)
				{
					BlueStacksUIBinding.Bind(tb, "STRING_CLOSE_SIDEBAR", "");
					return;
				}
			}
			else
			{
				if (cpb != null)
				{
					cpb.ImageName = "sidebar_show";
					BlueStacksUIBinding.Bind(cpb, "STRING_OPEN_SIDEBAR");
				}
				if (tb != null)
				{
					BlueStacksUIBinding.Bind(tb, "STRING_OPEN_SIDEBAR", "");
				}
			}
		}

		// Token: 0x06001130 RID: 4400 RVA: 0x0006BB74 File Offset: 0x00069D74
		internal void FlipSidebarVisibility(CustomPictureBox cpb, TextBlock tb)
		{
			if (cpb.ImageName == "sidebar_hide")
			{
				this.ParentWindow.mSidebar.Visibility = Visibility.Collapsed;
				cpb.ImageName = "sidebar_show";
				BlueStacksUIBinding.Bind(cpb, "STRING_OPEN_SIDEBAR");
				if (tb != null)
				{
					BlueStacksUIBinding.Bind(tb, "STRING_OPEN_SIDEBAR", "");
				}
				this.ParentWindow.EngineInstanceRegistry.IsSidebarVisible = false;
				return;
			}
			this.ParentWindow.mSidebar.Visibility = Visibility.Visible;
			cpb.ImageName = "sidebar_hide";
			BlueStacksUIBinding.Bind(cpb, "STRING_CLOSE_SIDEBAR");
			if (tb != null)
			{
				BlueStacksUIBinding.Bind(tb, "STRING_CLOSE_SIDEBAR", "");
			}
			this.ParentWindow.EngineInstanceRegistry.IsSidebarVisible = true;
		}

		// Token: 0x06001131 RID: 4401 RVA: 0x0006BC2C File Offset: 0x00069E2C
		internal void InitShortcuts()
		{
			try
			{
				this.mShortcutsConfigInstance = ShortcutConfig.LoadShortcutsConfig();
				if (this.mShortcutsConfigInstance != null)
				{
					List<ShortcutKeys> list = new List<ShortcutKeys>();
					foreach (ShortcutKeys shortcutKeys in this.mShortcutsConfigInstance.Shortcut)
					{
						if (string.Equals(shortcutKeys.ShortcutName, "STRING_MACRO_RECORDER", StringComparison.InvariantCulture))
						{
							if (!FeatureManager.Instance.IsMacroRecorderEnabled && !FeatureManager.Instance.IsCustomUIForNCSoft)
							{
								list.Add(shortcutKeys);
							}
						}
						else if (string.Equals(shortcutKeys.ShortcutName, "STRING_SYNCHRONISER", StringComparison.InvariantCulture))
						{
							if (!FeatureManager.Instance.IsOperationsSyncEnabled)
							{
								list.Add(shortcutKeys);
							}
						}
						else if (string.Equals(shortcutKeys.ShortcutName, "STRING_TOGGLE_FARM_MODE", StringComparison.InvariantCulture) && FeatureManager.Instance.IsFarmingModeDisabled)
						{
							list.Add(shortcutKeys);
						}
					}
					foreach (ShortcutKeys item in list)
					{
						this.mShortcutsConfigInstance.Shortcut.Remove(item);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("error while init shortcut : {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x06001132 RID: 4402 RVA: 0x0006BDB8 File Offset: 0x00069FB8
		internal void SaveAndReloadShortcuts()
		{
			try
			{
				this.mShortcutsConfigInstance.SaveUserDefinedShortcuts();
				CommonHandlers.ReloadShortcutsForAllInstances();
				Stats.SendMiscellaneousStatsAsync("KeyboardShortcuts", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "shortcut_save", null, null, null, null, null, "Android", 0);
			}
			catch (Exception ex)
			{
				Logger.Error("Error saving shortcut registry" + ex.ToString());
			}
		}

		// Token: 0x06001133 RID: 4403 RVA: 0x0006BE30 File Offset: 0x0006A030
		internal static void ReloadShortcutsForAllInstances()
		{
			foreach (string text in Utils.GetRunningInstancesList())
			{
				if (BlueStacksUIUtils.DictWindows.ContainsKey(text))
				{
					BlueStacksUIUtils.DictWindows[text].mCommonHandler.InitShortcuts();
					BlueStacksUIUtils.DictWindows[text].mCommonHandler.ReloadBossKey();
					BlueStacksUIUtils.DictWindows[text].mCommonHandler.ReloadTooltips();
				}
				HTTPUtils.SendRequestToEngineAsync("reloadShortcutsConfig", null, text, 0, null, false, 1, 0);
			}
		}

		// Token: 0x06001134 RID: 4404 RVA: 0x0006BED8 File Offset: 0x0006A0D8
		internal void ReloadTooltips()
		{
			foreach (SidebarElement sidebarElement in this.ParentWindow.mSidebar.mListSidebarElements)
			{
				this.ParentWindow.mSidebar.SetSidebarElementTooltip(sidebarElement, sidebarElement.mSidebarElementTooltipKey);
			}
		}

		// Token: 0x06001135 RID: 4405 RVA: 0x0000C5E9 File Offset: 0x0000A7E9
		private void ReloadBossKey()
		{
			RegistryManager.Instance.BossKey = this.GetShortcutKeyFromName("STRING_BOSSKEY_SETTING", true);
			if (string.IsNullOrEmpty(RegistryManager.Instance.BossKey))
			{
				GlobalKeyBoardMouseHooks.UnsetKey();
				return;
			}
			GlobalKeyBoardMouseHooks.SetKey(RegistryManager.Instance.BossKey);
		}

		// Token: 0x06001136 RID: 4406 RVA: 0x0006BF48 File Offset: 0x0006A148
		internal static void ArrangeWindowInTiles()
		{
			CommonHandlers.<>c__DisplayClass175_0 CS$<>8__locals1 = new CommonHandlers.<>c__DisplayClass175_0();
			CS$<>8__locals1.columns = RegistryManager.Instance.TileWindowColumnCount;
			CS$<>8__locals1.rows = (long)Math.Ceiling((double)BlueStacksUIUtils.DictWindows.Count / (double)CS$<>8__locals1.columns);
			double num = (double)Screen.PrimaryScreen.WorkingArea.Height;
			CS$<>8__locals1.y = (double)Screen.PrimaryScreen.WorkingArea.Top;
			CS$<>8__locals1.x = (double)Screen.PrimaryScreen.WorkingArea.Left;
			int num2 = 0;
			using (Dictionary<string, MainWindow>.Enumerator enumerator = BlueStacksUIUtils.DictWindows.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					CommonHandlers.<>c__DisplayClass175_1 CS$<>8__locals2 = new CommonHandlers.<>c__DisplayClass175_1();
					CS$<>8__locals2.CS$<>8__locals1 = CS$<>8__locals1;
					CS$<>8__locals2.item = enumerator.Current;
					double windowWidth = (double)((long)Screen.PrimaryScreen.WorkingArea.Width / CS$<>8__locals2.CS$<>8__locals1.columns);
					double windowHeight = (double)((long)Screen.PrimaryScreen.WorkingArea.Height / CS$<>8__locals2.CS$<>8__locals1.rows);
					double overlapWidth = 0.0;
					double overlapHeight = 0.0;
					CS$<>8__locals2.item.Value.Dispatcher.Invoke(new Action(delegate()
					{
						if (CS$<>8__locals2.item.Value.WindowState == WindowState.Minimized || CS$<>8__locals2.item.Value.WindowState == WindowState.Maximized)
						{
							CS$<>8__locals2.item.Value.RestoreWindows(true);
						}
						KMManager.CloseWindows();
						if (CS$<>8__locals2.item.Value.mAspectRatio < 1L)
						{
							if (CS$<>8__locals2.item.Value.GetWidthFromHeight(windowHeight, true, true) > windowWidth)
							{
								windowHeight = CS$<>8__locals2.item.Value.GetHeightFromWidth(windowWidth, true, true);
							}
							else
							{
								windowWidth = CS$<>8__locals2.item.Value.GetWidthFromHeight(windowHeight, true, true);
							}
							if (windowWidth < (double)CS$<>8__locals2.item.Value.MinWidthScaled)
							{
								windowWidth = (double)CS$<>8__locals2.item.Value.MinWidthScaled;
								windowHeight = CS$<>8__locals2.item.Value.GetHeightFromWidth(windowWidth, true, true);
								CommonHandlers.CalculateOverlappingLength(windowWidth, windowHeight, CS$<>8__locals2.CS$<>8__locals1.rows, CS$<>8__locals2.CS$<>8__locals1.columns, out overlapWidth, out overlapHeight);
							}
							CS$<>8__locals2.item.Value.ChangeHeightWidthTopLeft(windowWidth, windowHeight, CS$<>8__locals2.CS$<>8__locals1.y, CS$<>8__locals2.CS$<>8__locals1.x);
						}
						else
						{
							if (CS$<>8__locals2.item.Value.GetHeightFromWidth(windowWidth, true, true) > windowHeight)
							{
								windowWidth = CS$<>8__locals2.item.Value.GetWidthFromHeight(windowHeight, true, true);
							}
							else
							{
								windowHeight = CS$<>8__locals2.item.Value.GetHeightFromWidth(windowWidth, true, true);
							}
							if (windowHeight < (double)CS$<>8__locals2.item.Value.MinHeightScaled)
							{
								windowHeight = (double)CS$<>8__locals2.item.Value.MinHeightScaled;
								windowWidth = CS$<>8__locals2.item.Value.GetWidthFromHeight(windowHeight, true, true);
								CommonHandlers.CalculateOverlappingLength(windowWidth, windowHeight, CS$<>8__locals2.CS$<>8__locals1.rows, CS$<>8__locals2.CS$<>8__locals1.columns, out overlapWidth, out overlapHeight);
							}
							CS$<>8__locals2.item.Value.ChangeHeightWidthTopLeft(windowWidth, windowHeight, CS$<>8__locals2.CS$<>8__locals1.y, CS$<>8__locals2.CS$<>8__locals1.x);
						}
						if (!CS$<>8__locals2.item.Value.Topmost)
						{
							CS$<>8__locals2.item.Value.Topmost = true;
							WaitCallback callBack;
							if ((callBack = CS$<>8__locals2.<>9__1) == null)
							{
								callBack = (CS$<>8__locals2.<>9__1 = delegate(object obj)
								{
									Dispatcher dispatcher = CS$<>8__locals2.item.Value.Dispatcher;
									Action method;
									if ((method = CS$<>8__locals2.<>9__2) == null)
									{
										method = (CS$<>8__locals2.<>9__2 = delegate()
										{
											CS$<>8__locals2.item.Value.Topmost = false;
										});
									}
									dispatcher.Invoke(method, new object[0]);
								});
							}
							ThreadPool.QueueUserWorkItem(callBack);
						}
					}), new object[0]);
					CS$<>8__locals2.CS$<>8__locals1.x = CS$<>8__locals2.CS$<>8__locals1.x + (windowWidth - overlapWidth);
					num = Math.Min(num, windowHeight);
					num2++;
					if ((long)num2 % CS$<>8__locals2.CS$<>8__locals1.columns == 0L)
					{
						CS$<>8__locals2.CS$<>8__locals1.y = CS$<>8__locals2.CS$<>8__locals1.y + Math.Max(num - overlapHeight, 0.0);
						CS$<>8__locals2.CS$<>8__locals1.x = 0.0;
					}
				}
			}
		}

		// Token: 0x06001137 RID: 4407 RVA: 0x0006C1A0 File Offset: 0x0006A3A0
		internal static void CalculateOverlappingLength(double windowWidth, double windowHeight, long rows, long columns, out double overlapWidth, out double overlapHeight)
		{
			overlapHeight = 0.0;
			overlapWidth = 0.0;
			if (windowWidth * (double)columns > (double)Screen.PrimaryScreen.WorkingArea.Width)
			{
				double num = windowWidth * (double)columns - (double)Screen.PrimaryScreen.WorkingArea.Width;
				overlapWidth = num / (double)(columns - 1L);
			}
			if (windowHeight * (double)rows > (double)Screen.PrimaryScreen.WorkingArea.Height)
			{
				double num2 = windowHeight * (double)rows - (double)Screen.PrimaryScreen.WorkingArea.Height;
				overlapHeight = Math.Max(overlapHeight, num2 / (double)(rows - 1L));
			}
		}

		// Token: 0x06001138 RID: 4408 RVA: 0x0006C248 File Offset: 0x0006A448
		internal static void ArrangeWindowInCascade()
		{
			double num = (double)Screen.PrimaryScreen.WorkingArea.Top;
			double num2 = (double)Screen.PrimaryScreen.WorkingArea.Bottom;
			double num3 = (double)Screen.PrimaryScreen.WorkingArea.Left;
			double num4 = (double)Screen.PrimaryScreen.WorkingArea.Right;
			double num5 = (double)Screen.PrimaryScreen.WorkingArea.Width;
			double num6 = (double)Screen.PrimaryScreen.WorkingArea.Height;
			double windowWidth = (double)((int)(num5 / 3.0));
			double windowHeight = (double)((int)(num6 / 3.0));
			double y = num;
			double x = num3;
			using (Dictionary<string, MainWindow>.Enumerator enumerator = BlueStacksUIUtils.DictWindows.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					KeyValuePair<string, MainWindow> item = enumerator.Current;
					IntPtr handle = item.Value.Handle;
					item.Value.Dispatcher.Invoke(new Action(delegate()
					{
						if (item.Value.WindowState == WindowState.Minimized)
						{
							item.Value.RestoreWindows(false);
						}
						KMManager.CloseWindows();
						windowHeight = item.Value.GetHeightFromWidth(windowWidth, false, false);
						item.Value.ChangeHeightWidthTopLeft(windowWidth, windowHeight, y, x);
						item.Value.Focus();
					}), new object[0]);
					x += 40.0;
					y += 40.0;
					if (y >= num2 || x >= num4)
					{
						y = num + 40.0;
						x = num3 + 40.0;
					}
				}
			}
		}

		// Token: 0x06001139 RID: 4409 RVA: 0x0006C43C File Offset: 0x0006A63C
		public void SetNcSoftStreamingStatus(string status)
		{
			if (status.Equals("on", StringComparison.InvariantCultureIgnoreCase))
			{
				SidebarElement elementFromTag = this.ParentWindow.mSidebar.GetElementFromTag("sidebar_stream_video");
				this.ParentWindow.mSidebar.UpdateImage("sidebar_stream_video", "sidebar_stream_video_active");
				elementFromTag.Image.Width = 44.0;
				elementFromTag.Image.Height = 44.0;
				this.ParentWindow.mNCTopBar.ChangeTopBarColor("StreamingTopBarColor");
				this.ParentWindow.mNCTopBar.mStreamingTopbarGrid.Visibility = Visibility.Visible;
				this.ParentWindow.mIsStreaming = true;
				return;
			}
			SidebarElement elementFromTag2 = this.ParentWindow.mSidebar.GetElementFromTag("sidebar_stream_video");
			this.ParentWindow.mSidebar.UpdateImage("sidebar_stream_video", "sidebar_stream_video");
			elementFromTag2.Image.Width = 24.0;
			elementFromTag2.Image.Height = 24.0;
			this.ParentWindow.mNCTopBar.ChangeTopBarColor("TopBarColor");
			this.ParentWindow.mNCTopBar.mStreamingTopbarGrid.Visibility = Visibility.Collapsed;
			this.ParentWindow.mIsStreaming = false;
		}

		// Token: 0x0600113A RID: 4410 RVA: 0x0000C627 File Offset: 0x0000A827
		internal static void ArrangeWindow()
		{
			if (RegistryManager.Instance.ArrangeWindowMode == 0)
			{
				CommonHandlers.ArrangeWindowInTiles();
				return;
			}
			CommonHandlers.ArrangeWindowInCascade();
		}

		// Token: 0x0600113B RID: 4411 RVA: 0x0000C640 File Offset: 0x0000A840
		internal void MuteUnmuteButtonHanlder()
		{
			if (this.ParentWindow.EngineInstanceRegistry.IsMuted)
			{
				this.ParentWindow.Utils.UnmuteApplication(false);
				return;
			}
			this.ParentWindow.Utils.MuteApplication(false);
		}

		// Token: 0x0600113C RID: 4412 RVA: 0x0006C578 File Offset: 0x0006A778
		internal static string GetMacroName(string baseSchemeName = "Macro")
		{
			int length = baseSchemeName.Length;
			int num = 1;
			for (;;)
			{
				if (!(from MacroRecording macro in MacroGraph.Instance.Vertices
				select macro.Name.ToLower(CultureInfo.InvariantCulture)).Contains(string.Format(CultureInfo.InvariantCulture, "{0} ({1})", new object[]
				{
					baseSchemeName.ToLower(CultureInfo.InvariantCulture),
					num
				}).Trim()))
				{
					break;
				}
				num++;
			}
			return string.Format(CultureInfo.InvariantCulture, "{0} ({1})", new object[]
			{
				baseSchemeName,
				num
			});
		}

		// Token: 0x0600113D RID: 4413 RVA: 0x0000C677 File Offset: 0x0000A877
		internal void MouseMoveOverFrontend()
		{
			if (KMManager.sIsInScriptEditingMode && !this.ParentWindow.mIsWindowInFocus)
			{
				Logger.Info("Script focused");
				this.ParentWindow.mFrontendHandler.FocusFrontend();
			}
		}

		// Token: 0x0600113E RID: 4414 RVA: 0x0000C6A9 File Offset: 0x0000A8A9
		protected virtual void Dispose(bool disposing)
		{
			if (!this.disposedValue)
			{
				if (this.mObsResponseTimeoutTimer != null)
				{
					this.mObsResponseTimeoutTimer.Elapsed -= this.ObsResponseTimeoutTimer_Elapsed;
					this.mObsResponseTimeoutTimer.Dispose();
				}
				this.disposedValue = true;
			}
		}

		// Token: 0x0600113F RID: 4415 RVA: 0x0006C624 File Offset: 0x0006A824
		~CommonHandlers()
		{
			this.Dispose(false);
		}

		// Token: 0x06001140 RID: 4416 RVA: 0x0000C6E6 File Offset: 0x0000A8E6
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x06001141 RID: 4417 RVA: 0x0006C654 File Offset: 0x0006A854
		internal static void ReloadMacroShortcutsForAllInstances()
		{
			foreach (string text in Utils.GetRunningInstancesList())
			{
				if (BlueStacksUIUtils.DictWindows.ContainsKey(text))
				{
					HTTPUtils.SendRequestToEngineAsync("updateMacroShortcutsDict", MainWindow.sMacroMapping, text, 0, null, false, 1, 0);
				}
			}
		}

		// Token: 0x06001142 RID: 4418 RVA: 0x0006C6C4 File Offset: 0x0006A8C4
		internal void GameGuideButtonHandler(string action, string location)
		{
			if (!this.ToggleGamepadAndKeyboardGuidance("default"))
			{
				KMManager.HandleInputMapperWindow(this.ParentWindow, "");
				string packageName = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName;
				this.ParentWindow.mCommonHandler.HandlingForGameSettingsRedDotForSelectedGamePackges(packageName, true);
			}
			ClientStats.SendMiscellaneousStatsAsync(location, RegistryManager.Instance.UserGuid, "GameGuide", action, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06001143 RID: 4419 RVA: 0x0000C6F5 File Offset: 0x0000A8F5
		internal static string GetCompleteMacroRecordingPath(string macroName)
		{
			return Path.Combine(RegistryStrings.MacroRecordingsFolderPath, macroName.ToLower(CultureInfo.InvariantCulture) + ".json");
		}

		// Token: 0x06001144 RID: 4420 RVA: 0x0006C754 File Offset: 0x0006A954
		internal void ToggleSettingsBtnNotification(bool isShow)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (isShow)
				{
					if (KMManager.sGuidanceWindow != null)
					{
						KMManager.sGuidanceWindow.mSettingsBtnNotification.Visibility = Visibility.Visible;
						return;
					}
				}
				else if (KMManager.sGuidanceWindow != null)
				{
					KMManager.sGuidanceWindow.mSettingsBtnNotification.Visibility = Visibility.Collapsed;
				}
			}), new object[0]);
		}

		// Token: 0x06001145 RID: 4421 RVA: 0x0006C794 File Offset: 0x0006A994
		internal void HandlingForGameSettingsRedDotForSelectedGamePackges(string package, bool isShow)
		{
			if (PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.Contains(package))
			{
				this.RedDotToggling(isShow, this.ParentWindow.EngineInstanceRegistry.CODNotificationShown);
				return;
			}
			if (PackageActivityNames.ThirdParty.AllPUBGPackageNames.Contains(package))
			{
				this.RedDotTogglingForPubg(isShow, this.ParentWindow.EngineInstanceRegistry.PUBGNotificationShown);
				return;
			}
			if ("com.dts.freefireth".Contains(package))
			{
				this.RedDotToggling(isShow, this.ParentWindow.EngineInstanceRegistry.FreeFireNotificationShown);
				return;
			}
			if (PackageActivityNames.ThirdParty.AllSevenDeadlySinsPackageNames.Contains(package))
			{
				this.RedDotToggling(isShow, this.ParentWindow.EngineInstanceRegistry.SevenDeadlySinsNotificationShown);
			}
		}

		// Token: 0x06001146 RID: 4422 RVA: 0x0000C716 File Offset: 0x0000A916
		private void RedDotToggling(bool toShow, bool isNotificationAlreadyShown)
		{
			if (toShow)
			{
				if (!isNotificationAlreadyShown)
				{
					this.ToggleSettingsBtnNotification(true);
					return;
				}
			}
			else
			{
				this.ToggleSettingsBtnNotification(false);
			}
		}

		// Token: 0x06001147 RID: 4423 RVA: 0x0000C72D File Offset: 0x0000A92D
		private void RedDotTogglingForPubg(bool isShow, bool isNotificationAlreadyShown)
		{
			if (isShow)
			{
				if (this.ParentWindow.EngineInstanceRegistry.PUBGLaunchedCount >= 2 && !isNotificationAlreadyShown)
				{
					this.ToggleSettingsBtnNotification(true);
					return;
				}
			}
			else
			{
				this.ToggleSettingsBtnNotification(false);
			}
		}

		// Token: 0x06001148 RID: 4424 RVA: 0x0006C834 File Offset: 0x0006AA34
		internal bool ToggleGamepadAndKeyboardGuidance(string selectedTab)
		{
			if (KMManager.CheckIfKeymappingWindowVisible(true))
			{
				if (KMManager.sGuidanceWindow != null)
				{
					GuidanceWindow.HideOnNextLaunch(true);
					KMManager.sGuidanceWindow.mIsOnboardingPopupToBeShownOnGuidanceClose = true;
					KMManager.CloseWindows();
					this.ParentWindow.mSidebar.UpdateImage("sidebar_gameguide", "sidebar_gameguide");
					this.ParentWindow.StaticComponents.mSelectedTabButton.mGuidanceWindowOpen = false;
				}
				else
				{
					string a = "default";
					if (KMManager.sGuidanceWindow.mIsGamePadTabSelected)
					{
						a = "gamepad";
					}
					if (!string.Equals(a, selectedTab, StringComparison.InvariantCultureIgnoreCase))
					{
						KMManager.sGuidanceWindow.GuidanceWindowTabSelected(selectedTab);
					}
				}
				return true;
			}
			return false;
		}

		// Token: 0x04000B29 RID: 2857
		private MainWindow ParentWindow;

		// Token: 0x04000B2A RID: 2858
		internal static bool sIsRecordingVideo = false;

		// Token: 0x04000B2B RID: 2859
		internal static string sRecordingInstance = "";

		// Token: 0x04000B2C RID: 2860
		private static bool sIsOBSStartingStopping = false;

		// Token: 0x04000B2D RID: 2861
		private static bool sDownloading;

		// Token: 0x04000B2E RID: 2862
		private LegacyDownloader mDownloader;

		// Token: 0x04000B2F RID: 2863
		private static CustomMessageWindow sWindow;

		// Token: 0x04000B30 RID: 2864
		internal ShortcutConfig mShortcutsConfigInstance;

		// Token: 0x04000B31 RID: 2865
		internal static string mSavedVideoRecordingFilePath = null;

		// Token: 0x04000B42 RID: 2882
		private System.Timers.Timer mObsResponseTimeoutTimer;

		// Token: 0x04000B43 RID: 2883
		private long mDownloadedSize;

		// Token: 0x04000B44 RID: 2884
		private long mLastSizeChecked;

		// Token: 0x04000B45 RID: 2885
		private DispatcherTimer mDownloadStatusTimer;

		// Token: 0x04000B46 RID: 2886
		private float mRecorderSizeMb;

		// Token: 0x04000B47 RID: 2887
		private bool disposedValue;

		// Token: 0x020001B4 RID: 436
		// (Invoke) Token: 0x06001158 RID: 4440
		public delegate void MacroBookmarkChanged(string fileName, bool wasBookmarked);

		// Token: 0x020001B5 RID: 437
		// (Invoke) Token: 0x0600115C RID: 4444
		public delegate void MacroSettingsChanged(MacroRecording record);

		// Token: 0x020001B6 RID: 438
		// (Invoke) Token: 0x06001160 RID: 4448
		public delegate void ShortcutKeysChanged(bool isEnabled);

		// Token: 0x020001B7 RID: 439
		// (Invoke) Token: 0x06001164 RID: 4452
		public delegate void ShortcutKeysRefresh();

		// Token: 0x020001B8 RID: 440
		// (Invoke) Token: 0x06001168 RID: 4456
		public delegate void MacroDeleted(string fileName);

		// Token: 0x020001B9 RID: 441
		// (Invoke) Token: 0x0600116C RID: 4460
		public delegate void OverlayStateChanged(bool isEnabled);

		// Token: 0x020001BA RID: 442
		// (Invoke) Token: 0x06001170 RID: 4464
		public delegate void MacroButtonVisibilityChanged(bool isVisible);

		// Token: 0x020001BB RID: 443
		// (Invoke) Token: 0x06001174 RID: 4468
		public delegate void OperationSyncButtonVisibilityChanged(bool isVisible);

		// Token: 0x020001BC RID: 444
		// (Invoke) Token: 0x06001178 RID: 4472
		public delegate void OBSResponseTimeout();

		// Token: 0x020001BD RID: 445
		// (Invoke) Token: 0x0600117C RID: 4476
		public delegate void ScreenRecorderStateTransitioning();

		// Token: 0x020001BE RID: 446
		// (Invoke) Token: 0x06001180 RID: 4480
		public delegate void BTvDownloaderMinimized();

		// Token: 0x020001BF RID: 447
		// (Invoke) Token: 0x06001184 RID: 4484
		public delegate void GamepadButtonVisibilityChanged(bool visibility);

		// Token: 0x020001C0 RID: 448
		// (Invoke) Token: 0x06001188 RID: 4488
		public delegate void ScreenRecordingStateChanged(bool isRecording);

		// Token: 0x020001C1 RID: 449
		// (Invoke) Token: 0x0600118C RID: 4492
		public delegate void VolumeChanged(int volumeLevel);

		// Token: 0x020001C2 RID: 450
		// (Invoke) Token: 0x06001190 RID: 4496
		public delegate void VolumeMuted(bool muted);

		// Token: 0x020001C3 RID: 451
		// (Invoke) Token: 0x06001194 RID: 4500
		public delegate void GameGuideButtonVisibilityChanged(bool visibility);
	}
}
