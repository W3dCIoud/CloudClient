﻿using System;
using System.IO;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200007B RID: 123
	public class AppRecommendation
	{
		// Token: 0x17000194 RID: 404
		// (get) Token: 0x06000508 RID: 1288 RVA: 0x00005571 File Offset: 0x00003771
		// (set) Token: 0x06000509 RID: 1289 RVA: 0x00005579 File Offset: 0x00003779
		[JsonProperty(PropertyName = "extra_payload")]
		public SerializableDictionary<string, string> ExtraPayload { get; set; } = new SerializableDictionary<string, string>();

		// Token: 0x17000195 RID: 405
		// (get) Token: 0x0600050A RID: 1290 RVA: 0x00005582 File Offset: 0x00003782
		// (set) Token: 0x0600050B RID: 1291 RVA: 0x0000558A File Offset: 0x0000378A
		[JsonProperty(PropertyName = "app_icon_id")]
		public string IconId { get; set; }

		// Token: 0x17000196 RID: 406
		// (get) Token: 0x0600050C RID: 1292 RVA: 0x00005593 File Offset: 0x00003793
		// (set) Token: 0x0600050D RID: 1293 RVA: 0x0000559B File Offset: 0x0000379B
		[JsonProperty(PropertyName = "app_icon")]
		public string Icon { get; set; }

		// Token: 0x17000197 RID: 407
		// (get) Token: 0x0600050E RID: 1294 RVA: 0x000055A4 File Offset: 0x000037A4
		// (set) Token: 0x0600050F RID: 1295 RVA: 0x000055AC File Offset: 0x000037AC
		[JsonProperty(PropertyName = "game_genre")]
		public string GameGenre { get; set; }

		// Token: 0x17000198 RID: 408
		// (get) Token: 0x06000510 RID: 1296 RVA: 0x000055B5 File Offset: 0x000037B5
		// (set) Token: 0x06000511 RID: 1297 RVA: 0x000055BD File Offset: 0x000037BD
		[JsonProperty(PropertyName = "app_pkg")]
		public string AppPackage { get; set; }

		// Token: 0x17000199 RID: 409
		// (get) Token: 0x06000512 RID: 1298 RVA: 0x000055C6 File Offset: 0x000037C6
		// (set) Token: 0x06000513 RID: 1299 RVA: 0x000055CE File Offset: 0x000037CE
		public string ImagePath { get; set; } = string.Empty;

		// Token: 0x06000514 RID: 1300 RVA: 0x0001F448 File Offset: 0x0001D648
		internal void DeleteFile()
		{
			try
			{
				File.Delete(this.ImagePath);
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't delete AppRecommendation file: " + this.ImagePath);
				Logger.Error(ex.ToString());
			}
		}
	}
}
