﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200005A RID: 90
	internal class MainWindowEventArgs
	{
		// Token: 0x0200005B RID: 91
		internal class CursorLockChangedEventArgs : EventArgs
		{
			// Token: 0x17000159 RID: 345
			// (get) Token: 0x06000417 RID: 1047 RVA: 0x00004D0D File Offset: 0x00002F0D
			// (set) Token: 0x06000418 RID: 1048 RVA: 0x00004D15 File Offset: 0x00002F15
			public bool IsLocked { get; set; }
		}

		// Token: 0x0200005C RID: 92
		internal class FullScreenChangedEventArgs : EventArgs
		{
			// Token: 0x1700015A RID: 346
			// (get) Token: 0x0600041A RID: 1050 RVA: 0x00004D26 File Offset: 0x00002F26
			// (set) Token: 0x0600041B RID: 1051 RVA: 0x00004D2E File Offset: 0x00002F2E
			public bool IsFullscreen { get; set; }
		}

		// Token: 0x0200005D RID: 93
		internal class FrontendGridVisibilityChangedEventArgs : EventArgs
		{
			// Token: 0x1700015B RID: 347
			// (get) Token: 0x0600041D RID: 1053 RVA: 0x00004D37 File Offset: 0x00002F37
			// (set) Token: 0x0600041E RID: 1054 RVA: 0x00004D3F File Offset: 0x00002F3F
			public bool IsVisible { get; set; }
		}

		// Token: 0x0200005E RID: 94
		internal class BrowserOTSCompletedCallbackEventArgs : EventArgs
		{
			// Token: 0x1700015C RID: 348
			// (get) Token: 0x06000420 RID: 1056 RVA: 0x00004D48 File Offset: 0x00002F48
			// (set) Token: 0x06000421 RID: 1057 RVA: 0x00004D50 File Offset: 0x00002F50
			internal string CallbackFunction { get; set; }
		}
	}
}
