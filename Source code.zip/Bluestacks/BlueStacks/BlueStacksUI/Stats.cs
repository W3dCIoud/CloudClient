﻿using System;
using System.Globalization;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001AD RID: 429
	internal static class Stats
	{
		// Token: 0x17000287 RID: 647
		// (get) Token: 0x0600107F RID: 4223 RVA: 0x0000C150 File Offset: 0x0000A350
		// (set) Token: 0x06001080 RID: 4224 RVA: 0x0000C164 File Offset: 0x0000A364
		private static string SessionId
		{
			get
			{
				if (Stats.sSessionId == null)
				{
					Stats.ResetSessionId();
				}
				return Stats.sSessionId;
			}
			set
			{
				Stats.sSessionId = value;
			}
		}

		// Token: 0x06001081 RID: 4225 RVA: 0x0000C16C File Offset: 0x0000A36C
		public static string GetSessionId()
		{
			return Stats.SessionId;
		}

		// Token: 0x06001082 RID: 4226 RVA: 0x0000C173 File Offset: 0x0000A373
		public static string ResetSessionId()
		{
			Stats.SessionId = Stats.Timestamp;
			return Stats.SessionId;
		}

		// Token: 0x17000288 RID: 648
		// (get) Token: 0x06001083 RID: 4227 RVA: 0x00067E60 File Offset: 0x00066060
		private static string Timestamp
		{
			get
			{
				long num = DateTime.Now.Ticks - DateTime.Parse("01/01/1970 00:00:00", CultureInfo.InvariantCulture).Ticks;
				return (num / 10000000L).ToString(CultureInfo.InvariantCulture);
			}
		}

		// Token: 0x04000B12 RID: 2834
		private static string sSessionId;
	}
}
