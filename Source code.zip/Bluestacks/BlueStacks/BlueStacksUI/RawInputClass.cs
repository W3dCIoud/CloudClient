﻿using System;
using System.Runtime.InteropServices;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000142 RID: 322
	internal class RawInputClass
	{
		// Token: 0x06000CDD RID: 3293 RVA: 0x00054B88 File Offset: 0x00052D88
		internal static int GetDeviceID(IntPtr lParam)
		{
			try
			{
				uint cb = 0U;
				NativeMethods.GetRawInputData(lParam, 268435459U, IntPtr.Zero, ref cb, (uint)Marshal.SizeOf(typeof(RawInputClass.RawInputHeader)));
				IntPtr intPtr = Marshal.AllocHGlobal((int)cb);
				NativeMethods.GetRawInputData(lParam, 268435459U, intPtr, ref cb, (uint)Marshal.SizeOf(typeof(RawInputClass.RawInputHeader)));
				RawInputClass.RawInput rawInput = (RawInputClass.RawInput)Marshal.PtrToStructure(intPtr, typeof(RawInputClass.RawInput));
				Marshal.FreeHGlobal(intPtr);
				if (rawInput.Data.Mouse.ButtonFlags == RawMouseButtons.LeftDown || rawInput.Data.Mouse.ButtonFlags == RawMouseButtons.RightDown)
				{
					return (int)rawInput.Header.Device;
				}
				return -1;
			}
			catch (Exception ex)
			{
				Logger.Info("Exception in raw input constructor : {0}", new object[]
				{
					ex.ToString()
				});
			}
			return -1;
		}

		// Token: 0x06000CDE RID: 3294 RVA: 0x00054C68 File Offset: 0x00052E68
		public RawInputClass(IntPtr hwnd)
		{
			try
			{
				RawInputClass.RAWINPUTDEVICE[] array = new RawInputClass.RAWINPUTDEVICE[3];
				array[0].usUsagePage = 1;
				array[0].usUsage = 2;
				array[0].dwFlags = 256;
				array[0].hwndTarget = hwnd;
				array[1].usUsagePage = 1;
				array[1].usUsage = 5;
				array[1].dwFlags = 256;
				array[1].hwndTarget = hwnd;
				array[2].usUsagePage = 1;
				array[2].usUsage = 4;
				array[2].dwFlags = 256;
				array[2].hwndTarget = hwnd;
				if (!NativeMethods.RegisterRawInputDevices(array, (uint)array.Length, (uint)Marshal.SizeOf(array[0])))
				{
					Logger.Info("Failed to register raw input device(s).");
				}
				else
				{
					Logger.Info("Successfully registered raw input device(s).");
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Exception in raw input constructor : {0}", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x040008B7 RID: 2231
		private const int RID_INPUT = 268435459;

		// Token: 0x040008B8 RID: 2232
		private const int RIDEV_INPUTSINK = 256;

		// Token: 0x02000143 RID: 323
		internal struct RAWINPUTDEVICE
		{
			// Token: 0x040008B9 RID: 2233
			[MarshalAs(UnmanagedType.U2)]
			public ushort usUsagePage;

			// Token: 0x040008BA RID: 2234
			[MarshalAs(UnmanagedType.U2)]
			public ushort usUsage;

			// Token: 0x040008BB RID: 2235
			[MarshalAs(UnmanagedType.U4)]
			public int dwFlags;

			// Token: 0x040008BC RID: 2236
			public IntPtr hwndTarget;
		}

		// Token: 0x02000144 RID: 324
		internal struct RAWHID
		{
			// Token: 0x040008BD RID: 2237
			[MarshalAs(UnmanagedType.U4)]
			public int dwSizHid;

			// Token: 0x040008BE RID: 2238
			[MarshalAs(UnmanagedType.U4)]
			public int dwCount;
		}

		// Token: 0x02000145 RID: 325
		[StructLayout(LayoutKind.Explicit)]
		public struct RawMouse
		{
			// Token: 0x040008BF RID: 2239
			[FieldOffset(0)]
			public RawMouseFlags Flags;

			// Token: 0x040008C0 RID: 2240
			[FieldOffset(4)]
			public RawMouseButtons ButtonFlags;

			// Token: 0x040008C1 RID: 2241
			[FieldOffset(6)]
			public ushort ButtonData;

			// Token: 0x040008C2 RID: 2242
			[FieldOffset(8)]
			public uint RawButtons;

			// Token: 0x040008C3 RID: 2243
			[FieldOffset(12)]
			public int LastX;

			// Token: 0x040008C4 RID: 2244
			[FieldOffset(16)]
			public int LastY;

			// Token: 0x040008C5 RID: 2245
			[FieldOffset(20)]
			public uint ExtraInformation;
		}

		// Token: 0x02000146 RID: 326
		internal struct RAWKEYBOARD
		{
			// Token: 0x040008C6 RID: 2246
			[MarshalAs(UnmanagedType.U2)]
			public ushort MakeCode;

			// Token: 0x040008C7 RID: 2247
			[MarshalAs(UnmanagedType.U2)]
			public ushort Flags;

			// Token: 0x040008C8 RID: 2248
			[MarshalAs(UnmanagedType.U2)]
			public ushort Reserved;

			// Token: 0x040008C9 RID: 2249
			[MarshalAs(UnmanagedType.U2)]
			public ushort VKey;

			// Token: 0x040008CA RID: 2250
			[MarshalAs(UnmanagedType.U4)]
			public uint Message;

			// Token: 0x040008CB RID: 2251
			[MarshalAs(UnmanagedType.U4)]
			public uint ExtraInformation;
		}

		// Token: 0x02000147 RID: 327
		public enum RawInputType
		{
			// Token: 0x040008CD RID: 2253
			Mouse,
			// Token: 0x040008CE RID: 2254
			Keyboard,
			// Token: 0x040008CF RID: 2255
			HID
		}

		// Token: 0x02000148 RID: 328
		public struct RawInput
		{
			// Token: 0x06000CDF RID: 3295 RVA: 0x00009CD6 File Offset: 0x00007ED6
			public RawInput(RawInputClass.RawInputHeader _header, RawInputClass.RawInput.Union _data)
			{
				this.Header = _header;
				this.Data = _data;
			}

			// Token: 0x040008D0 RID: 2256
			public RawInputClass.RawInputHeader Header;

			// Token: 0x040008D1 RID: 2257
			public RawInputClass.RawInput.Union Data;

			// Token: 0x02000149 RID: 329
			[StructLayout(LayoutKind.Explicit)]
			public struct Union
			{
				// Token: 0x040008D2 RID: 2258
				[FieldOffset(0)]
				public RawInputClass.RawMouse Mouse;

				// Token: 0x040008D3 RID: 2259
				[FieldOffset(0)]
				public RawInputClass.RAWKEYBOARD Keyboard;

				// Token: 0x040008D4 RID: 2260
				[FieldOffset(0)]
				public RawInputClass.RAWHID HID;
			}
		}

		// Token: 0x0200014A RID: 330
		internal struct RawInputHeader
		{
			// Token: 0x040008D5 RID: 2261
			public RawInputClass.RawInputType Type;

			// Token: 0x040008D6 RID: 2262
			public int Size;

			// Token: 0x040008D7 RID: 2263
			public IntPtr Device;

			// Token: 0x040008D8 RID: 2264
			public IntPtr wParam;
		}
	}
}
