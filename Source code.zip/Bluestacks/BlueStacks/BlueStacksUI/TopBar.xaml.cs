﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using BlueStacks.BlueStacksUI.BTv;
using BlueStacks.Common;
using Microsoft.VisualBasic.Devices;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200025F RID: 607
	public partial class TopBar : UserControl, ITopBar
	{
		// Token: 0x170002D7 RID: 727
		// (get) Token: 0x06001574 RID: 5492 RVA: 0x0000E9C9 File Offset: 0x0000CBC9
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x1400002C RID: 44
		// (add) Token: 0x06001575 RID: 5493 RVA: 0x00080C08 File Offset: 0x0007EE08
		// (remove) Token: 0x06001576 RID: 5494 RVA: 0x00080C40 File Offset: 0x0007EE40
		public event PercentageChangedEventHandler PercentChanged;

		// Token: 0x170002D8 RID: 728
		// (get) Token: 0x06001577 RID: 5495 RVA: 0x0000E9EA File Offset: 0x0000CBEA
		// (set) Token: 0x06001578 RID: 5496 RVA: 0x00005D29 File Offset: 0x00003F29
		string ITopBar.AppName
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		// Token: 0x170002D9 RID: 729
		// (get) Token: 0x06001579 RID: 5497 RVA: 0x0000E9EA File Offset: 0x0000CBEA
		// (set) Token: 0x0600157A RID: 5498 RVA: 0x00005D29 File Offset: 0x00003F29
		string ITopBar.CharacterName
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		// Token: 0x0600157B RID: 5499 RVA: 0x00080C78 File Offset: 0x0007EE78
		public static Point GetMousePosition()
		{
			NativeMethods.Win32Point win32Point = default(NativeMethods.Win32Point);
			NativeMethods.GetCursorPos(ref win32Point);
			return new Point((double)win32Point.X, (double)win32Point.Y);
		}

		// Token: 0x0600157C RID: 5500 RVA: 0x00080CA8 File Offset: 0x0007EEA8
		public TopBar()
		{
			this.InitializeComponent();
			if (FeatureManager.Instance.IsCustomUIForDMMSandbox)
			{
				this.TopBarOptionsPanelElementVisibility(this.mUserAccountBtn, false);
				this.TopBarOptionsPanelElementVisibility(this.mWarningButton, false);
			}
			else
			{
				if (!FeatureManager.Instance.IsUserAccountBtnEnabled)
				{
					this.TopBarOptionsPanelElementVisibility(this.mUserAccountBtn, false);
				}
				if (!FeatureManager.Instance.IsWarningBtnEnabled)
				{
					this.TopBarOptionsPanelElementVisibility(this.mWarningButton, false);
				}
			}
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				this.mConfigButton.Visibility = Visibility.Collapsed;
				this.TopBarOptionsPanelElementVisibility(this.mNotificationCentreButton, false);
				this.WindowHeaderGrid.Visibility = Visibility.Collapsed;
				this.TopBarOptionsPanelElementVisibility(this.mUserAccountBtn, false);
				this.mWarningButton.ToolTip = null;
				this.mSidebarButton.Visibility = Visibility.Collapsed;
			}
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				this.TopBarOptionsPanelElementVisibility(this.mUserAccountBtn, false);
				this.TopBarOptionsPanelElementVisibility(this.mNotificationCentreButton, false);
			}
			if (!string.Equals(this.mTitleIcon.ImageName, Strings.TitleBarIconImageName, StringComparison.InvariantCulture))
			{
				this.mTitleIcon.ImageName = Strings.TitleBarIconImageName;
			}
			if (Strings.TitleBarProductIconWidth != null)
			{
				this.mTitleIcon.Width = Strings.TitleBarProductIconWidth.Value;
			}
			if (Strings.TitleBarTextMaxWidth != null)
			{
				this.mTitleText.MaxWidth = Strings.TitleBarTextMaxWidth.Value;
			}
			this.mVersionText.Text = RegistryManager.Instance.ClientVersion;
		}

		// Token: 0x0600157D RID: 5501 RVA: 0x00080E4C File Offset: 0x0007F04C
		private void ParentWindow_GuestBootCompletedEvent(object sender, EventArgs args)
		{
			if (this.ParentWindow.EngineInstanceRegistry.IsSidebarVisible && base.Visibility == Visibility.Visible && this.ParentWindow.mSidebar.Visibility != Visibility.Visible && !FeatureManager.Instance.IsCustomUIForDMM)
			{
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					this.ParentWindow.mCommonHandler.FlipSidebarVisibility(this.mSidebarButton, null);
				}), new object[0]);
			}
		}

		// Token: 0x0600157E RID: 5502 RVA: 0x0000E9ED File Offset: 0x0000CBED
		internal void ChangeDownloadPercent(int percent)
		{
			PercentageChangedEventHandler percentChanged = this.PercentChanged;
			if (percentChanged == null)
			{
				return;
			}
			percentChanged(this, new PercentageChangedEventArgs
			{
				Percentage = percent
			});
		}

		// Token: 0x0600157F RID: 5503 RVA: 0x00080EB4 File Offset: 0x0007F0B4
		internal void InitializeSnailButton()
		{
			if (FeatureManager.Instance.IsCustomUIForDMMSandbox || !FeatureManager.Instance.IsWarningBtnEnabled)
			{
				return;
			}
			string deviceCaps = RegistryManager.Instance.DeviceCaps;
			if (string.IsNullOrEmpty(deviceCaps))
			{
				this.mSnailMode = PerformanceState.VtxEnabled;
				this.TopBarOptionsPanelElementVisibility(this.mWarningButton, false);
				return;
			}
			JObject deviceCapsData = JObject.Parse(deviceCaps);
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (deviceCapsData["cpu_hvm"].ToString().Equals("True", StringComparison.OrdinalIgnoreCase) && deviceCapsData["bios_hvm"].ToString().Equals("False", StringComparison.OrdinalIgnoreCase))
				{
					if (deviceCapsData["engine_enabled"].ToString().Equals(EngineState.raw.ToString(), StringComparison.OrdinalIgnoreCase))
					{
						this.mSnailMode = PerformanceState.VtxDisabled;
						this.TopBarOptionsPanelElementVisibility(this.mWarningButton, true);
					}
				}
				else if (deviceCapsData["cpu_hvm"].ToString().Equals("False", StringComparison.OrdinalIgnoreCase))
				{
					this.mSnailMode = PerformanceState.NoVtxSupport;
					this.TopBarOptionsPanelElementVisibility(this.mWarningButton, true);
				}
				else if (deviceCapsData["cpu_hvm"].ToString().Equals("True", StringComparison.OrdinalIgnoreCase) && deviceCapsData["bios_hvm"].ToString().Equals("True", StringComparison.OrdinalIgnoreCase))
				{
					this.mSnailMode = PerformanceState.VtxEnabled;
					this.TopBarOptionsPanelElementVisibility(this.mWarningButton, false);
				}
				this.RefreshWarningButton();
			}), new object[0]);
		}

		// Token: 0x06001580 RID: 5504 RVA: 0x00080F3C File Offset: 0x0007F13C
		internal void RefreshWarningButton()
		{
			if (FeatureManager.Instance.IsCustomUIForDMMSandbox || !FeatureManager.Instance.IsWarningBtnEnabled)
			{
				return;
			}
			if (this.mSnailMode != PerformanceState.VtxEnabled)
			{
				this.TopBarOptionsPanelElementVisibility(this.mWarningButton, true);
				this.AddVtxNotification();
				return;
			}
			this.TopBarOptionsPanelElementVisibility(this.mWarningButton, false);
		}

		// Token: 0x06001581 RID: 5505 RVA: 0x0000EA0C File Offset: 0x0000CC0C
		internal void AddVtxNotification()
		{
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				return;
			}
			base.Dispatcher.Invoke(new Action(delegate()
			{
				bool dontOverwrite = true;
				GenericNotificationItem genericNotificationItem = new GenericNotificationItem
				{
					CreationTime = DateTime.Now,
					IsDeferred = false,
					Priority = NotificationPriority.Important,
					ShowRibbon = false,
					Id = "VtxNotification",
					NotificationMenuImageName = "SlowPerformance.png",
					Title = LocaleStrings.GetLocalizedString("STRING_DISABLED_VT_TITLE"),
					Message = LocaleStrings.GetLocalizedString("STRING_DISABLED_VT")
				};
				SerializableDictionary<string, string> dicToAdd = new SerializableDictionary<string, string>
				{
					{
						"click_generic_action",
						"UserBrowser"
					},
					{
						"click_action_value",
						WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
						{
							WebHelper.GetServerHost(),
							"help_articles"
						})) + "&article=enable_virtualization"
					}
				};
				genericNotificationItem.ExtraPayload.ClearAddRange(dicToAdd);
				GenericNotificationManager.Instance.AddNewNotification(genericNotificationItem, dontOverwrite);
				this.RefreshNotificationCentreButton();
			}), new object[0]);
		}

		// Token: 0x06001582 RID: 5506 RVA: 0x0000EA39 File Offset: 0x0000CC39
		internal void AddRamNotification()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				bool dontOverwrite = true;
				GenericNotificationItem genericNotificationItem = new GenericNotificationItem
				{
					IsDeferred = false,
					Priority = NotificationPriority.Important,
					ShowRibbon = false,
					Id = "ramNotification",
					NotificationMenuImageName = "SlowPerformance.png",
					Title = LocaleStrings.GetLocalizedString("STRING_RAM_NOTIF_TITLE"),
					Message = LocaleStrings.GetLocalizedString("STRING_RAM_NOTIF")
				};
				SerializableDictionary<string, string> dicToAdd = new SerializableDictionary<string, string>
				{
					{
						"click_generic_action",
						"UserBrowser"
					},
					{
						"click_action_value",
						WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
						{
							WebHelper.GetServerHost(),
							"help_articles"
						})) + "&article=bs3_nougat_min_requirements"
					}
				};
				genericNotificationItem.ExtraPayload.ClearAddRange(dicToAdd);
				GenericNotificationManager.Instance.AddNewNotification(genericNotificationItem, dontOverwrite);
				this.RefreshNotificationCentreButton();
			}), new object[0]);
		}

		// Token: 0x06001583 RID: 5507 RVA: 0x00080F8C File Offset: 0x0007F18C
		private void UserAccountButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked account button");
			if (this.ParentWindow.mGuestBootCompleted && this.ParentWindow.mAppHandler.IsOneTimeSetupCompleted)
			{
				if (FeatureManager.Instance.IsOpenActivityFromAccountIcon)
				{
					this.mAppTabButtons.AddAppTab("STRING_ACCOUNT", BlueStacksUIUtils.sUserAccountPackageName, BlueStacksUIUtils.sUserAccountActivityName, "account_tab", true, true, false);
					return;
				}
				string text = WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/bluestacks_account");
				text += "&email=";
				text += RegistryManager.Instance.RegisteredEmail;
				text += "&token=";
				text += RegistryManager.Instance.Token;
				this.mAppTabButtons.AddWebTab(text, "STRING_ACCOUNT", "account_tab", true, "account_tab", false);
			}
		}

		// Token: 0x06001584 RID: 5508 RVA: 0x0000EA59 File Offset: 0x0000CC59
		private void ConfigButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mPreferenceDropDownControl.LateInit();
			this.mSettingsMenuPopup.IsOpen = true;
			this.mConfigButton.ImageName = "cfgmenu_hover";
		}

		// Token: 0x06001585 RID: 5509 RVA: 0x0000EA82 File Offset: 0x0000CC82
		private void MinimizeButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked minimize button");
			this.ParentWindow.MinimizeWindow();
		}

		// Token: 0x06001586 RID: 5510 RVA: 0x0000EA99 File Offset: 0x0000CC99
		internal void MaxmizeButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked Maximize\\Restore button");
			if (this.ParentWindow.WindowState == WindowState.Normal && !this.ParentWindow.mIsDmmMaximised)
			{
				this.ParentWindow.MaximizeWindow();
				return;
			}
			this.ParentWindow.RestoreWindows(false);
		}

		// Token: 0x06001587 RID: 5511 RVA: 0x0000EAD7 File Offset: 0x0000CCD7
		private void CloseButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked close Bluestacks button");
			this.ParentWindow.CloseWindow();
			Stats.SendCommonClientStatsAsync("minimize_bluestacks_notification", "BlueStacks_close", this.ParentWindow.mVmName, "", "", "");
		}

		// Token: 0x06001588 RID: 5512 RVA: 0x0000EB17 File Offset: 0x0000CD17
		private void NotificationPopup_Opened(object sender, EventArgs e)
		{
			this.mConfigButton.IsEnabled = false;
		}

		// Token: 0x06001589 RID: 5513 RVA: 0x0000EB25 File Offset: 0x0000CD25
		private void NotificationPopup_Closed(object sender, EventArgs e)
		{
			this.mConfigButton.IsEnabled = true;
			this.mConfigButton.ImageName = "cfgmenu";
		}

		// Token: 0x0600158A RID: 5514 RVA: 0x0000EB43 File Offset: 0x0000CD43
		internal void ChangeUserPremiumButton(bool isPremium)
		{
			if (isPremium)
			{
				this.mUserAccountBtn.ImageName = BlueStacksUIUtils.sPremiumUserImageName;
				return;
			}
			this.mUserAccountBtn.ImageName = BlueStacksUIUtils.sLoggedInImageName;
		}

		// Token: 0x0600158B RID: 5515 RVA: 0x00006BEE File Offset: 0x00004DEE
		private void PreferenceDropDownControl_MouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x0600158C RID: 5516 RVA: 0x00081064 File Offset: 0x0007F264
		private void mWarningButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked warning button for speed up Bluestacks ");
			this.mWarningButton.ImageName = "warning";
			SpeedUpBlueStacks speedUpBlueStacks = new SpeedUpBlueStacks();
			if (this.mSnailMode == PerformanceState.NoVtxSupport)
			{
				speedUpBlueStacks.mUpgradeComputer.Visibility = Visibility.Visible;
			}
			else if (this.mSnailMode == PerformanceState.VtxDisabled)
			{
				speedUpBlueStacks.mEnableVt.Visibility = Visibility.Visible;
			}
			new ContainerWindow(this.ParentWindow, speedUpBlueStacks, 640.0, 200.0, false, true);
		}

		// Token: 0x0600158D RID: 5517 RVA: 0x0000EB69 File Offset: 0x0000CD69
		private void mBtvButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked btv button");
			BTVManager.Instance.StartBlueStacksTV();
		}

		// Token: 0x0600158E RID: 5518 RVA: 0x000810E0 File Offset: 0x0007F2E0
		private void TopBar_Loaded(object sender, RoutedEventArgs e)
		{
			if (FeatureManager.Instance.IsBTVEnabled && string.Equals(Strings.CurrentDefaultVmName, this.ParentWindow.mVmName, StringComparison.InvariantCulture))
			{
				this.TopBarOptionsPanelElementVisibility(this.mBtvButton, true);
			}
			this.RefreshNotificationCentreButton();
			if (!this.ParentWindow.mGuestBootCompleted)
			{
				this.ParentWindow.mCommonHandler.SetSidebarImageProperties(false, this.mSidebarButton, null);
				this.ParentWindow.GuestBootCompleted += this.ParentWindow_GuestBootCompletedEvent;
			}
			this.ParentWindow.mCommonHandler.ScreenRecordingStateChangedEvent += this.TopBar_ScreenRecordingStateChangedEvent;
			VideoRecordingStatus videoRecordingStatus = this.mVideoRecordStatusControl;
			videoRecordingStatus.RecordingStoppedEvent = (Action)Delegate.Combine(videoRecordingStatus.RecordingStoppedEvent, new Action(this.TopBar_RecordingStoppedEvent));
			if (this.ParentWindow.mVmName == "Android" && this.mTitleIcon.ToolTip.ToString().Equals(Strings.ProductTopBarDisplayName, StringComparison.OrdinalIgnoreCase))
			{
				this.mTitleIcon.ToolTip = new ToolTip
				{
					Content = (Strings.ProductDisplayName ?? "")
				};
			}
		}

		// Token: 0x0600158F RID: 5519 RVA: 0x0000EB7F File Offset: 0x0000CD7F
		private void TopBar_RecordingStoppedEvent()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.mVideoRecordStatusControl.Visibility = Visibility.Collapsed;
			}), new object[0]);
		}

		// Token: 0x06001590 RID: 5520 RVA: 0x000811FC File Offset: 0x0007F3FC
		private void TopBar_ScreenRecordingStateChangedEvent(bool isRecording)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (isRecording)
				{
					if (this.mVideoRecordStatusControl.Visibility != Visibility.Visible && CommonHandlers.sIsRecordingVideo)
					{
						this.mVideoRecordStatusControl.Init(this.ParentWindow);
						this.mVideoRecordStatusControl.Visibility = Visibility.Visible;
						return;
					}
				}
				else
				{
					this.mVideoRecordStatusControl.ResetTimer();
					this.mVideoRecordStatusControl.Visibility = Visibility.Collapsed;
				}
			}), new object[0]);
		}

		// Token: 0x06001591 RID: 5521 RVA: 0x00081240 File Offset: 0x0007F440
		private void mNotificationCentreButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked notification_centre button");
			this.mNotificationDrawerControl.ParentWindow = this.ParentWindow;
			this.mNotificationDrawerControl.Width = 370.0;
			this.mNotificationDrawerControl.Populate(GenericNotificationManager.GetNotificationItems((GenericNotificationItem x) => !x.IsDeleted));
			ClientStats.SendMiscellaneousStatsAsync("NotificationBellIconClicked", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, null, null, null, null, null, null);
			this.mNotificationCentrePopup.IsOpen = true;
		}

		// Token: 0x06001592 RID: 5522 RVA: 0x000812DC File Offset: 0x0007F4DC
		internal bool CheckForRam()
		{
			int num = 0;
			try
			{
				num = (int)(ulong.Parse(new ComputerInfo().TotalPhysicalMemory.ToString(CultureInfo.InvariantCulture), CultureInfo.InvariantCulture) / this.MB_MULTIPLIER);
			}
			catch (Exception ex)
			{
				Logger.Error(ex.ToString());
			}
			return num < 4096;
		}

		// Token: 0x06001593 RID: 5523 RVA: 0x00081340 File Offset: 0x0007F540
		internal void RefreshNotificationCentreButton()
		{
			if (!this.ParentWindow.EngineInstanceRegistry.IsGoogleSigninDone || !this.ParentWindow.IsDefaultVM || !FeatureManager.Instance.IsShowNotificationCentre || RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				this.TopBarOptionsPanelElementVisibility(this.mNotificationCentreButton, false);
				return;
			}
			this.TopBarOptionsPanelElementVisibility(this.mNotificationCentreButton, true);
			if (GenericNotificationManager.GetNotificationItems((GenericNotificationItem x) => !x.IsRead && !x.IsDeleted && x.Priority == NotificationPriority.Important).Count > 0)
			{
				this.mNotificationCentreButton.ImageName = "notification_crucial";
				return;
			}
			if (GenericNotificationManager.GetNotificationItems((GenericNotificationItem x) => !x.IsRead && !x.IsDeleted).Count > 0)
			{
				this.mNotificationCentreButton.ImageName = "notification_dot";
				return;
			}
			this.mNotificationCentreButton.ImageName = "notification";
		}

		// Token: 0x06001594 RID: 5524 RVA: 0x00081438 File Offset: 0x0007F638
		private void mNotificationCentreDropDownBorder_LayoutUpdated(object sender, EventArgs e)
		{
			RectangleGeometry rectangleGeometry = new RectangleGeometry();
			Rect rect = new Rect
			{
				Height = this.mNotificationCentreDropDownBorder.ActualHeight,
				Width = this.mNotificationCentreDropDownBorder.ActualWidth
			};
			BlueStacksUIBinding.BindCornerRadiusToDouble(rectangleGeometry, RectangleGeometry.RadiusXProperty, "PreferenceDropDownRadius");
			BlueStacksUIBinding.BindCornerRadiusToDouble(rectangleGeometry, RectangleGeometry.RadiusYProperty, "PreferenceDropDownRadius");
			rectangleGeometry.Rect = rect;
			this.mNotificationCentreDropDownBorder.Clip = rectangleGeometry;
		}

		// Token: 0x06001595 RID: 5525 RVA: 0x000814AC File Offset: 0x0007F6AC
		internal void ShowRecordingIcons()
		{
			this.mMacroRecordControl.Init(this.ParentWindow);
			this.mMacroRecordControl.Visibility = Visibility.Visible;
			this.mMacroRecordControl.StartTimer();
			if (!this.ParentWindow.mIsFullScreen)
			{
				this.ParentWindow.mTopBar.mMacroRecorderToolTipPopup.IsOpen = true;
				this.ParentWindow.mTopBar.mMacroRecorderToolTipPopup.StaysOpen = true;
				this.mMacroRecordingPopupTimer = new DispatcherTimer
				{
					Interval = new TimeSpan(0, 0, 0, 5, 0)
				};
				this.mMacroRecordingPopupTimer.Tick += this.MacroRecordingPopupTimer_Tick;
				this.mMacroRecordingPopupTimer.Start();
			}
		}

		// Token: 0x06001596 RID: 5526 RVA: 0x0000EBA4 File Offset: 0x0000CDA4
		private void MacroRecordingPopupTimer_Tick(object sender, EventArgs e)
		{
			this.ParentWindow.mTopBar.mMacroRecorderToolTipPopup.IsOpen = false;
			(sender as DispatcherTimer).Stop();
		}

		// Token: 0x06001597 RID: 5527 RVA: 0x00081558 File Offset: 0x0007F758
		internal void HideRecordingIcons()
		{
			this.mConfigButton.Visibility = Visibility.Visible;
			if (this.ParentWindow.EngineInstanceRegistry.IsGoogleSigninDone)
			{
				this.TopBarOptionsPanelElementVisibility(this.mNotificationCentreButton, true);
				this.TopBarOptionsPanelElementVisibility(this.mUserAccountBtn, true);
			}
			this.mMacroRecordControl.Visibility = Visibility.Collapsed;
			this.mMacroRecorderToolTipPopup.IsOpen = false;
		}

		// Token: 0x06001598 RID: 5528 RVA: 0x000815B8 File Offset: 0x0007F7B8
		internal void ShowMacroPlaybackOnTopBar(MacroRecording record)
		{
			if (!FeatureManager.Instance.IsCustomUIForDMM)
			{
				this.mMacroPlayControl.Init(this.ParentWindow, record);
				this.mMacroPlayControl.Visibility = Visibility.Visible;
				if (!this.ParentWindow.mIsFullScreen)
				{
					this.ParentWindow.mTopBar.mMacroRunningToolTipPopup.IsOpen = true;
					this.ParentWindow.mTopBar.mMacroRunningToolTipPopup.StaysOpen = true;
					this.mMacroRunningPopupTimer = new DispatcherTimer
					{
						Interval = new TimeSpan(0, 0, 0, 5, 0)
					};
					this.mMacroRunningPopupTimer.Tick += this.MacroRunningPopupTimer_Tick;
					this.mMacroRunningPopupTimer.Start();
				}
			}
		}

		// Token: 0x06001599 RID: 5529 RVA: 0x0000EBC7 File Offset: 0x0000CDC7
		private void MacroRunningPopupTimer_Tick(object sender, EventArgs e)
		{
			this.ParentWindow.mTopBar.mMacroRunningToolTipPopup.IsOpen = false;
			(sender as DispatcherTimer).Stop();
		}

		// Token: 0x0600159A RID: 5530 RVA: 0x00081668 File Offset: 0x0007F868
		internal void HideMacroPlaybackFromTopBar()
		{
			if (!FeatureManager.Instance.IsCustomUIForDMM)
			{
				this.mConfigButton.Visibility = Visibility.Visible;
				if (this.ParentWindow.EngineInstanceRegistry.IsGoogleSigninDone)
				{
					this.TopBarOptionsPanelElementVisibility(this.mNotificationCentreButton, true);
					this.TopBarOptionsPanelElementVisibility(this.mUserAccountBtn, true);
				}
				this.mMacroPlayControl.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x0600159B RID: 5531 RVA: 0x000816C8 File Offset: 0x0007F8C8
		internal void UpdateMacroRecordingProgress()
		{
			if (this.ParentWindow.mIsMacroPlaying || this.ParentWindow.mIsMacroRecorderActive)
			{
				this.mConfigButton.Visibility = Visibility.Visible;
				if (this.ParentWindow.EngineInstanceRegistry.IsGoogleSigninDone)
				{
					this.TopBarOptionsPanelElementVisibility(this.mNotificationCentreButton, true);
					this.TopBarOptionsPanelElementVisibility(this.mUserAccountBtn, true);
				}
			}
		}

		// Token: 0x0600159C RID: 5532 RVA: 0x0000EBEA File Offset: 0x0000CDEA
		internal void ShowSyncIcon()
		{
			this.TopBarOptionsPanelElementVisibility(this.mOperationsSyncGrid, true);
		}

		// Token: 0x0600159D RID: 5533 RVA: 0x0000EBF9 File Offset: 0x0000CDF9
		internal void HideSyncIcon()
		{
			this.TopBarOptionsPanelElementVisibility(this.mOperationsSyncGrid, false);
		}

		// Token: 0x0600159E RID: 5534 RVA: 0x0000EC08 File Offset: 0x0000CE08
		private void MSidebarButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			MainWindow parentWindow = this.ParentWindow;
			if (parentWindow == null)
			{
				return;
			}
			CommonHandlers mCommonHandler = parentWindow.mCommonHandler;
			if (mCommonHandler == null)
			{
				return;
			}
			mCommonHandler.FlipSidebarVisibility(sender as CustomPictureBox, null);
		}

		// Token: 0x0600159F RID: 5535 RVA: 0x0000EC2B File Offset: 0x0000CE2B
		private void TopBar_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (!DesignerProperties.GetIsInDesignMode(this))
			{
				this.TopBarButtonsHandling();
			}
		}

		// Token: 0x060015A0 RID: 5536 RVA: 0x00081728 File Offset: 0x0007F928
		private void TopBarButtonsHandling()
		{
			double num = base.ActualWidth - 180.0 - (double)(this.mAppTabButtons.mDictTabs.Count * 48);
			double num2 = this.mOptionsDockPanel.ActualWidth;
			if (num2 > num)
			{
				using (IEnumerator<KeyValuePair<FrameworkElement, double>> enumerator = this.mOptionsPriorityPanel.Values.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						KeyValuePair<FrameworkElement, double> keyValuePair = enumerator.Current;
						if (keyValuePair.Key.Visibility == Visibility.Visible)
						{
							keyValuePair.Key.Visibility = Visibility.Collapsed;
							num2 -= keyValuePair.Value;
						}
						if (num2 < num)
						{
							break;
						}
					}
					return;
				}
			}
			for (int i = this.mOptionsPriorityPanel.Count - 1; i >= 0; i--)
			{
				KeyValuePair<FrameworkElement, double> value = this.mOptionsPriorityPanel.ElementAt(i).Value;
				if (value.Key.Visibility == Visibility.Collapsed)
				{
					if (num2 + value.Value >= num)
					{
						break;
					}
					value.Key.Visibility = Visibility.Visible;
					num2 += value.Value;
				}
			}
		}

		// Token: 0x060015A1 RID: 5537 RVA: 0x0008183C File Offset: 0x0007FA3C
		private bool ContainsKey(FrameworkElement element)
		{
			foreach (KeyValuePair<FrameworkElement, double> keyValuePair in this.mOptionsPriorityPanel.Values)
			{
				if (keyValuePair.Key == element)
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x060015A2 RID: 5538 RVA: 0x00081898 File Offset: 0x0007FA98
		private void RemoveKey(FrameworkElement element)
		{
			foreach (KeyValuePair<int, KeyValuePair<FrameworkElement, double>> keyValuePair in this.mOptionsPriorityPanel)
			{
				if (keyValuePair.Value.Key == element)
				{
					this.mOptionsPriorityPanel.Remove(keyValuePair.Key);
					break;
				}
			}
		}

		// Token: 0x060015A3 RID: 5539 RVA: 0x00081908 File Offset: 0x0007FB08
		internal void TopBarOptionsPanelElementVisibility(FrameworkElement element, bool isVisible)
		{
			if (isVisible)
			{
				double num = base.ActualWidth - 180.0 - (double)(this.mAppTabButtons.mDictTabs.Count * 48);
				if (this.mOptionsDockPanel.ActualWidth + element.Width < num)
				{
					element.Visibility = Visibility.Visible;
				}
				else
				{
					element.Visibility = Visibility.Collapsed;
				}
				if (!this.ContainsKey(element))
				{
					this.mOptionsPriorityPanel.Add(int.Parse(element.Tag.ToString(), CultureInfo.InvariantCulture), new KeyValuePair<FrameworkElement, double>(element, element.Width));
					return;
				}
			}
			else
			{
				element.Visibility = Visibility.Collapsed;
				if (this.ContainsKey(element))
				{
					this.RemoveKey(element);
				}
			}
		}

		// Token: 0x060015A4 RID: 5540 RVA: 0x0000EC3B File Offset: 0x0000CE3B
		void ITopBar.ShowSyncPanel(bool isSource)
		{
			this.mOperationsSyncGrid.Visibility = Visibility.Visible;
			if (isSource)
			{
				this.mPlayPauseSyncButton.ImageName = "pause_title_bar";
				this.mPlayPauseSyncButton.Visibility = Visibility.Visible;
				this.mStopSyncButton.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x060015A5 RID: 5541 RVA: 0x0000EC74 File Offset: 0x0000CE74
		void ITopBar.HideSyncPanel()
		{
			this.mOperationsSyncGrid.Visibility = Visibility.Collapsed;
			this.mPlayPauseSyncButton.Visibility = Visibility.Collapsed;
			this.mStopSyncButton.Visibility = Visibility.Collapsed;
			this.mSyncInstancesToolTipPopup.IsOpen = false;
		}

		// Token: 0x060015A6 RID: 5542 RVA: 0x000819B4 File Offset: 0x0007FBB4
		private void PlayPauseSyncButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if ((sender as CustomPictureBox).ImageName.Equals("pause_title_bar", StringComparison.InvariantCultureIgnoreCase))
			{
				(sender as CustomPictureBox).ImageName = "play_title_bar";
				this.ParentWindow.mSynchronizerWindow.PauseAllSyncOperations();
				return;
			}
			(sender as CustomPictureBox).ImageName = "pause_title_bar";
			this.ParentWindow.mSynchronizerWindow.PlayAllSyncOperations();
		}

		// Token: 0x060015A7 RID: 5543 RVA: 0x0000ECA6 File Offset: 0x0000CEA6
		private void StopSyncButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			((ITopBar)this).HideSyncPanel();
			this.ParentWindow.mSynchronizerWindow.StopAllSyncOperations();
			if (RegistryManager.Instance.IsShowToastNotification)
			{
				this.ParentWindow.ShowGeneralToast(LocaleStrings.GetLocalizedString("STRING_SYNC_STOPPED"));
			}
		}

		// Token: 0x060015A8 RID: 5544 RVA: 0x0000ECDF File Offset: 0x0000CEDF
		private void OperationsSyncGrid_MouseEnter(object sender, MouseEventArgs e)
		{
			if (this.ParentWindow.mIsSynchronisationActive)
			{
				this.mSyncInstancesToolTipPopup.IsOpen = true;
			}
		}

		// Token: 0x060015A9 RID: 5545 RVA: 0x0000ECFA File Offset: 0x0000CEFA
		private void OperationsSyncGrid_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.ParentWindow.mIsSynchronisationActive && !this.mOperationsSyncGrid.IsMouseOver && !this.mSyncInstancesToolTipPopup.IsMouseOver)
			{
				this.mSyncInstancesToolTipPopup.IsOpen = false;
			}
		}

		// Token: 0x060015AA RID: 5546 RVA: 0x0000ED2F File Offset: 0x0000CF2F
		private void SyncInstancesToolTip_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.mOperationsSyncGrid.IsMouseOver && !this.mSyncInstancesToolTipPopup.IsMouseOver)
			{
				this.mSyncInstancesToolTipPopup.IsOpen = false;
			}
		}

		// Token: 0x060015AB RID: 5547 RVA: 0x00081A1C File Offset: 0x0007FC1C
		internal void ClosePopups()
		{
			if (this.mMacroRecorderToolTipPopup.IsOpen)
			{
				this.mMacroRecorderToolTipPopup.IsOpen = false;
			}
			if (this.mMacroRunningToolTipPopup.IsOpen)
			{
				this.mMacroRunningToolTipPopup.IsOpen = false;
			}
			if (this.mNotificationCentrePopup.IsOpen)
			{
				this.mNotificationCentrePopup.IsOpen = false;
			}
			if (this.mSettingsMenuPopup.IsOpen)
			{
				this.mSettingsMenuPopup.IsOpen = false;
			}
			if (this.mSyncInstancesToolTipPopup.IsOpen)
			{
				this.mSyncInstancesToolTipPopup.IsOpen = false;
			}
		}

		// Token: 0x04000DDA RID: 3546
		private MainWindow mMainWindow;

		// Token: 0x04000DDC RID: 3548
		private SortedList<int, KeyValuePair<FrameworkElement, double>> mOptionsPriorityPanel = new SortedList<int, KeyValuePair<FrameworkElement, double>>();

		// Token: 0x04000DDD RID: 3549
		internal double mMinimumExpectedTopBarWidth = 320.0;

		// Token: 0x04000DDE RID: 3550
		internal PerformanceState mSnailMode;

		// Token: 0x04000DDF RID: 3551
		private DispatcherTimer mMacroRunningPopupTimer;

		// Token: 0x04000DE0 RID: 3552
		private DispatcherTimer mMacroRecordingPopupTimer;

		// Token: 0x04000DE1 RID: 3553
		private ulong MB_MULTIPLIER = 1048576UL;
	}
}
