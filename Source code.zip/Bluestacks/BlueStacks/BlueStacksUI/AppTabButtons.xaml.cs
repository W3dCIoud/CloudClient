﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200002D RID: 45
	public partial class AppTabButtons : UserControl
	{
		// Token: 0x17000116 RID: 278
		// (get) Token: 0x060002B2 RID: 690 RVA: 0x00003D4E File Offset: 0x00001F4E
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x17000117 RID: 279
		// (get) Token: 0x060002B3 RID: 691 RVA: 0x00003D6F File Offset: 0x00001F6F
		// (set) Token: 0x060002B4 RID: 692 RVA: 0x00003D77 File Offset: 0x00001F77
		public EventHandler<EventArgs> EventOnTabChanged { get; set; }

		// Token: 0x17000118 RID: 280
		// (get) Token: 0x060002B5 RID: 693 RVA: 0x00003D80 File Offset: 0x00001F80
		public List<string> ListTabHistory { get; } = new List<string>();

		// Token: 0x17000119 RID: 281
		// (get) Token: 0x060002B6 RID: 694 RVA: 0x00015410 File Offset: 0x00013610
		public int AreaForTABS
		{
			get
			{
				int num = (int)(base.ActualWidth - 20.0);
				if (num < 0)
				{
					num = 0;
				}
				return num;
			}
		}

		// Token: 0x1700011A RID: 282
		// (get) Token: 0x060002B7 RID: 695 RVA: 0x00003D88 File Offset: 0x00001F88
		internal AppTabButton SelectedTab
		{
			get
			{
				return this.ParentWindow.StaticComponents.mSelectedTabButton;
			}
		}

		// Token: 0x060002B8 RID: 696 RVA: 0x00015438 File Offset: 0x00013638
		public AppTabButtons()
		{
			this.InitializeComponent();
			if (!DesignerProperties.GetIsInDesignMode(this))
			{
				base.SizeChanged += this.Window_SizeChanged;
				base.Loaded += this.AppTabButtons_Loaded;
			}
		}

		// Token: 0x060002B9 RID: 697 RVA: 0x00003D9A File Offset: 0x00001F9A
		private void AppTabButtons_Loaded(object sender, RoutedEventArgs e)
		{
			base.Loaded -= this.AppTabButtons_Loaded;
			if (!FeatureManager.Instance.IsCustomUIForDMM && RegistryManager.Instance.InstallationType == InstallationTypes.FullEdition)
			{
				this.AddHomeTab();
			}
		}

		// Token: 0x060002BA RID: 698 RVA: 0x000154C0 File Offset: 0x000136C0
		internal void AddHomeTab()
		{
			AppTabButton appTabButton = new AppTabButton();
			this.mHomeAppTabButton = appTabButton;
			this.mPanel.Children.Insert(0, appTabButton);
			appTabButton.Init("STRING_HOME", "Home", string.Empty, "home", this.ParentWindow.WelcomeTabParentGrid, "Home");
			BlueStacksUIBinding.Bind(appTabButton.mTabLabel, "STRING_HOME");
			appTabButton.MouseUp += this.AppTabButton_MouseUp;
			this.mDictTabs[appTabButton.PackageName] = appTabButton;
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				appTabButton.Visibility = Visibility.Collapsed;
			}
			this.ResizeTabs();
			this.GoToTab("Home", false, false);
		}

		// Token: 0x060002BB RID: 699 RVA: 0x00003DCD File Offset: 0x00001FCD
		internal void AddHiddenAppTabAndLaunch(string packageName, string activityName)
		{
			this.AddAppTab("", packageName, activityName, "", true, true, false);
			this.ParentWindow.StaticComponents.mSelectedTabButton.Visibility = Visibility.Collapsed;
		}

		// Token: 0x060002BC RID: 700 RVA: 0x00015574 File Offset: 0x00013774
		internal void AddAppTab(string appName, string packageName, string activityName, string imageName, bool isSwitch, bool isLaunch, bool receivedFromImap = false)
		{
			this.DoExtraHandlingForApp(packageName);
			this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon(packageName);
			if (this.mDictTabs.ContainsKey(packageName))
			{
				this.GoToTab(packageName, isLaunch, receivedFromImap);
				return;
			}
			AppTabButton mSelectedTabButton = this.ParentWindow.StaticComponents.mSelectedTabButton;
			AppTabButton appTabButton = new AppTabButton();
			appTabButton.Init(appName, packageName, activityName, imageName, this.ParentWindow.FrontendParentGrid, packageName);
			appTabButton.MouseUp += this.AppTabButton_MouseUp;
			if (this.ParentWindow.mDiscordhandler != null)
			{
				this.ParentWindow.mDiscordhandler.AssignTabChangeEvent(appTabButton);
			}
			if (FeatureManager.Instance.IsCustomUIForDMM && this.ParentWindow.mDmmBottomBar != null)
			{
				AppTabButton appTabButton2 = appTabButton;
				appTabButton2.EventOnTabChanged = (EventHandler<TabChangeEventArgs>)Delegate.Combine(appTabButton2.EventOnTabChanged, new EventHandler<TabChangeEventArgs>(this.ParentWindow.mDmmBottomBar.Tab_Changed));
			}
			this.mDictTabs.Add(packageName, appTabButton);
			this.mPanel.Children.Add(appTabButton);
			if (Oem.Instance.SendAppClickStatsFromClient)
			{
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					AppInfo appInfoFromPackageName = new JsonParser(this.ParentWindow.mVmName).GetAppInfoFromPackageName(packageName);
					string appVersion = string.Empty;
					string appVersionName = string.Empty;
					if (appInfoFromPackageName != null)
					{
						if (!string.IsNullOrEmpty(appInfoFromPackageName.Version))
						{
							appVersion = appInfoFromPackageName.Version;
						}
						if (!string.IsNullOrEmpty(appInfoFromPackageName.VersionName))
						{
							appVersionName = appInfoFromPackageName.VersionName;
						}
					}
					Stats.SendAppStats(appName, packageName, appVersion, "HomeVersionNotKnown", Stats.AppType.app, this.ParentWindow.mVmName, appVersionName);
				});
			}
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				appTabButton.Visibility = Visibility.Collapsed;
			}
			else if (mSelectedTabButton != null && mSelectedTabButton.IsPortraitModeTab && mSelectedTabButton.mTabType == TabType.AppTab)
			{
				appTabButton.IsPortraitModeTab = true;
			}
			this.ResizeTabs();
			if (isSwitch)
			{
				this.GoToTab(packageName, isLaunch, receivedFromImap);
			}
		}

		// Token: 0x060002BD RID: 701 RVA: 0x00015728 File Offset: 0x00013928
		private void DoExtraHandlingForApp(string packageName)
		{
			if (RegistryManager.Instance.FirstAppLaunchState == AppLaunchState.Installed && JsonParser.GetInstalledAppsList(this.ParentWindow.mVmName).Contains(packageName))
			{
				RegistryManager.Instance.FirstAppLaunchState = AppLaunchState.Launched;
			}
			if (!AppConfigurationManager.Instance.VmAppConfig[this.ParentWindow.mVmName].ContainsKey(packageName))
			{
				AppConfigurationManager.Instance.VmAppConfig[this.ParentWindow.mVmName][packageName] = new AppSettings();
			}
		}

		// Token: 0x060002BE RID: 702 RVA: 0x000157AC File Offset: 0x000139AC
		internal void AddWebTab(string url, string tabName, string imageName, bool isSwitch, string tabKey = "", bool forceRefresh = false)
		{
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				return;
			}
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				Process.Start(url);
				return;
			}
			bool flag = false;
			if (!string.IsNullOrEmpty(tabKey))
			{
				flag = true;
			}
			if (this.mDictTabs.ContainsKey(flag ? tabKey : url))
			{
				if (this.mDictTabs[flag ? tabKey : url].GetBrowserControl() == null)
				{
					this.mDictTabs[tabKey].mControlGrid = this.ParentWindow.AddBrowser(url);
					this.mDictTabs[tabKey].Init(tabName, url, imageName, this.mDictTabs[tabKey].mControlGrid, tabKey);
				}
				if (flag && string.Compare(url, this.mDictTabs[tabKey].PackageName, StringComparison.OrdinalIgnoreCase) != 0)
				{
					BrowserControl browserControl = this.mDictTabs[tabKey].GetBrowserControl();
					this.mDictTabs[tabKey].Init(tabName, url, imageName, this.mDictTabs[tabKey].mControlGrid, tabKey);
					if (browserControl != null)
					{
						browserControl.UpdateUrlAndRefresh(url);
					}
				}
				else if (forceRefresh)
				{
					BrowserControl browserControl = this.mDictTabs[flag ? tabKey : url].GetBrowserControl();
					browserControl.UpdateUrlAndRefresh(browserControl.mUrl);
				}
				this.GoToTab(flag ? tabKey : url, true, false);
				return;
			}
			AppTabButton appTabButton = new AppTabButton();
			Grid grid = this.ParentWindow.AddBrowser(url);
			grid.Visibility = Visibility.Visible;
			appTabButton.Init(tabName, url, imageName, grid, flag ? tabKey : url);
			appTabButton.MouseUp += this.AppTabButton_MouseUp;
			if (this.ParentWindow.mDiscordhandler != null)
			{
				this.ParentWindow.mDiscordhandler.AssignTabChangeEvent(appTabButton);
			}
			this.mDictTabs.Add(flag ? tabKey : url, appTabButton);
			this.mPanel.Children.Add(appTabButton);
			this.ResizeTabs();
			if (isSwitch)
			{
				this.GoToTab(flag ? tabKey : url, true, false);
			}
			ClientStats.SendMiscellaneousStatsAsync("WebTabLaunched", RegistryManager.Instance.UserGuid, url, appTabButton.AppLabel, RegistryManager.Instance.Version, Oem.Instance.OEM, null, null, null);
		}

		// Token: 0x060002BF RID: 703 RVA: 0x000159D4 File Offset: 0x00013BD4
		internal void KillWebTabs()
		{
			if (RegistryManager.Instance.SwitchKillWebTab)
			{
				foreach (KeyValuePair<string, AppTabButton> keyValuePair in this.mDictTabs)
				{
					if (keyValuePair.Value.mTabType == TabType.WebTab)
					{
						BrowserControl browserControl = null;
						foreach (object obj in keyValuePair.Value.mControlGrid.Children)
						{
							browserControl = (obj as BrowserControl);
							if (browserControl != null && browserControl.CefBrowser != null)
							{
								foreach (BrowserControlTags args in browserControl.TagsSubscribed)
								{
									BrowserSubscriber mSubscriber = browserControl.mSubscriber;
									if (mSubscriber != null)
									{
										mSubscriber.UnsubscribeTag(args);
									}
								}
								browserControl.CefBrowser.Dispose();
								browserControl.CefBrowser = null;
							}
						}
					}
				}
			}
		}

		// Token: 0x060002C0 RID: 704 RVA: 0x00015B08 File Offset: 0x00013D08
		private void AppTabButton_MouseUp(object sender, MouseButtonEventArgs e)
		{
			if (e.ChangedButton == MouseButton.Middle)
			{
				string tabKey = (sender as AppTabButton).TabKey;
				if (!string.IsNullOrEmpty(tabKey))
				{
					this.CloseTab(tabKey, true, false, false, false, "");
				}
			}
		}

		// Token: 0x060002C1 RID: 705 RVA: 0x00003DFA File Offset: 0x00001FFA
		private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (!this.ParentWindow.mIsFullScreen)
			{
				this.RefreshUI();
			}
		}

		// Token: 0x060002C2 RID: 706 RVA: 0x00015B44 File Offset: 0x00013D44
		private void RefreshUI()
		{
			if ((DateTime.Now - this.mLastTimeOfSizeChangeEventRecieved).TotalSeconds > 2.0)
			{
				this.mLastTimeOfSizeChangeEventRecieved = DateTime.Now;
				this.mSizeChangedEventCountInLast2Seconds = 1;
			}
			else
			{
				this.mSizeChangedEventCountInLast2Seconds++;
			}
			if (this.mSizeChangedEventCountInLast2Seconds > 500)
			{
				return;
			}
			if (this.ParentWindow.IsUIInPortraitMode)
			{
				this.SwitchToIconMode(true);
			}
			else
			{
				this.SwitchToIconMode(false);
			}
			this.ResizeTabs();
		}

		// Token: 0x060002C3 RID: 707 RVA: 0x00015BC8 File Offset: 0x00013DC8
		private void SwitchToIconMode(bool isSwitchToIconMode)
		{
			if (isSwitchToIconMode)
			{
				this.mTabMinWidth = 38;
				if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
				{
					this.mMoreTabButton.Visibility = Visibility.Hidden;
					this.ParentWindow.mTopBar.mTitleText.Visibility = Visibility.Collapsed;
				}
				else if (!FeatureManager.Instance.IsCustomUIForDMM)
				{
					this.ParentWindow.mTopBar.mTitleTextGrid.Visibility = Visibility.Collapsed;
				}
				this.mMoreTabButton.MakeTabParallelogram(false);
			}
			else
			{
				if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
				{
					this.ParentWindow.mTopBar.mTitleText.Visibility = Visibility.Visible;
				}
				this.mTabMinWidth = 48;
				this.mMoreTabButton.MakeTabParallelogram(true);
			}
			this.ParentWindow.mTopBar.RefreshWarningButton();
		}

		// Token: 0x060002C4 RID: 708 RVA: 0x00015C88 File Offset: 0x00013E88
		internal void ResizeTabs()
		{
			if (!this.ParentWindow.mIsFullScreen)
			{
				double num = this.MacroGridHandling();
				num += this.VideoRecordingGridHandling();
				if (this.ParentWindow.mTopBar.ActualWidth > this.ParentWindow.mTopBar.mMinimumExpectedTopBarWidth + num + 40.0)
				{
					this.ParentWindow.mTopBar.mTitleIcon.Visibility = Visibility.Visible;
				}
				else
				{
					this.ParentWindow.mTopBar.mTitleIcon.Visibility = Visibility.Collapsed;
				}
				if (this.ParentWindow.mTopBar.ActualWidth > this.ParentWindow.mTopBar.mMinimumExpectedTopBarWidth + 140.0 + num + (double)(this.mDictTabs.Count * 48))
				{
					this.ParentWindow.mTopBar.mTitleTextGrid.Visibility = Visibility.Visible;
				}
				else
				{
					this.ParentWindow.mTopBar.mTitleTextGrid.Visibility = Visibility.Collapsed;
				}
				int num2 = this.mPanel.Children.Count + this.mHiddenButtons.Children.Count;
				if (num2 > 0)
				{
					double num3 = (double)this.mTabMinWidth;
					if (this.AreaForTABS >= num2 * this.mTabMinWidth)
					{
						num3 = (double)(this.AreaForTABS / num2);
					}
					for (int i = 0; i < this.mPanel.Children.Count; i++)
					{
						(this.mPanel.Children[i] as AppTabButton).ResizeButton(num3);
					}
					if ((double)this.AreaForTABS >= num3 * (double)num2)
					{
						if (this.mHiddenButtons.Children.Count > 0)
						{
							this.ShowXTabs(this.mHiddenButtons.Children.Count, num3);
						}
					}
					else
					{
						int num4 = this.AreaForTABS / this.mTabMinWidth - 1;
						if (FeatureManager.Instance.IsCustomUIForDMM)
						{
							int num5 = (int)Math.Floor(BlueStacksUIBinding.Instance.CornerRadiusModel["TabMarginPortrait"].TopLeft);
							int num6 = (int)Math.Floor(this.mMoreTabButton.ActualWidth) + num5;
							num4 = (this.AreaForTABS - num6) / (this.mTabMinWidth + num5);
						}
						if (num4 > num2)
						{
							num4 = num2;
						}
						if (num4 > this.mPanel.Children.Count || num2 == 1)
						{
							this.ShowXTabs(num4 - this.mPanel.Children.Count, num3);
						}
						else if (num4 < this.mPanel.Children.Count)
						{
							this.HideXTabs(this.mPanel.Children.Count - num4);
						}
					}
				}
				if (this.mHiddenButtons.Children.Count > 0)
				{
					this.mMoreTabButton.Visibility = Visibility.Visible;
					this.mMoreTabButton.MoreTabsButtonHandling();
					return;
				}
				this.mMoreTabButton.Visibility = Visibility.Hidden;
			}
		}

		// Token: 0x060002C5 RID: 709 RVA: 0x00015F4C File Offset: 0x0001414C
		private double MacroGridHandling()
		{
			double num = 0.0;
			if (this.ParentWindow.mTopBar.mMacroRecordControl.Visibility == Visibility.Visible)
			{
				num = this.ParentWindow.mTopBar.mMacroRecordControl.MaxWidth;
			}
			else if (this.ParentWindow.mTopBar.mMacroPlayControl.Visibility == Visibility.Visible)
			{
				num = this.ParentWindow.mTopBar.mMacroPlayControl.MaxWidth;
			}
			if (num > 0.0)
			{
				if (this.ParentWindow.mTopBar.ActualWidth > this.ParentWindow.mTopBar.mMinimumExpectedTopBarWidth + num)
				{
					this.ParentWindow.mTopBar.mMacroRecordControl.TimerDisplay.Visibility = Visibility.Visible;
					this.ParentWindow.mTopBar.mMacroPlayControl.mDescriptionPanel.Visibility = Visibility.Visible;
				}
				else
				{
					this.ParentWindow.mTopBar.mMacroRecordControl.TimerDisplay.Visibility = Visibility.Collapsed;
					this.ParentWindow.mTopBar.mMacroPlayControl.mDescriptionPanel.Visibility = Visibility.Collapsed;
				}
			}
			return num;
		}

		// Token: 0x060002C6 RID: 710 RVA: 0x00016064 File Offset: 0x00014264
		private double VideoRecordingGridHandling()
		{
			double num = 0.0;
			if (this.ParentWindow.mTopBar.mVideoRecordStatusControl.Visibility == Visibility.Visible)
			{
				num = this.ParentWindow.mTopBar.mVideoRecordStatusControl.MaxWidth;
			}
			if (num > 0.0)
			{
				if (this.ParentWindow.mTopBar.ActualWidth > this.ParentWindow.mTopBar.mMinimumExpectedTopBarWidth + num)
				{
					this.ParentWindow.mTopBar.mVideoRecordStatusControl.mDescriptionPanel.Visibility = Visibility.Visible;
				}
				else
				{
					this.ParentWindow.mTopBar.mVideoRecordStatusControl.mDescriptionPanel.Visibility = Visibility.Collapsed;
				}
			}
			return num;
		}

		// Token: 0x060002C7 RID: 711 RVA: 0x00016114 File Offset: 0x00014314
		private void ShowXTabs(int x, double tabWidth)
		{
			for (int i = 0; i < x; i++)
			{
				AppTabButton appTabButton = this.mDictTabs.Values.First<AppTabButton>();
				foreach (AppTabButton appTabButton2 in this.mDictTabs.Values)
				{
					if (this.mHiddenButtons.Children.Contains(appTabButton2))
					{
						appTabButton = appTabButton2;
						break;
					}
				}
				appTabButton.ResizeButton(tabWidth);
				appTabButton.UpdateUIForDropDown(false);
				if (!this.mPanel.Children.Contains(appTabButton))
				{
					this.mHiddenButtons.Children.Remove(appTabButton);
					if (appTabButton.mTabType == TabType.HomeTab)
					{
						this.mPanel.Children.Insert(0, appTabButton);
					}
					else
					{
						this.mPanel.Children.Add(appTabButton);
					}
				}
			}
		}

		// Token: 0x060002C8 RID: 712 RVA: 0x00016200 File Offset: 0x00014400
		private void HideXTabs(int x)
		{
			for (int i = 0; i < x; i++)
			{
				AppTabButton appTabButton = this.mDictTabs.Values.Last<AppTabButton>();
				for (int j = this.mDictTabs.Count - 1; j >= 0; j--)
				{
					AppTabButton value = this.mDictTabs.ElementAt(j).Value;
					if (this.mPanel.Children.Contains(value))
					{
						appTabButton = value;
						break;
					}
				}
				appTabButton.UpdateUIForDropDown(true);
				if (!this.mHiddenButtons.Children.Contains(appTabButton))
				{
					this.mPanel.Children.Remove(appTabButton);
					this.mHiddenButtons.Children.Add(appTabButton);
				}
			}
		}

		// Token: 0x060002C9 RID: 713 RVA: 0x000162B4 File Offset: 0x000144B4
		internal void CloseTab(string tabKey, bool sendStopAppToAndroid = false, bool forceClose = false, bool dontCheckQuitPopup = false, bool receivedFromImap = false, string topActivityPackageName = "")
		{
			if (this.mDictTabs.ContainsKey(tabKey))
			{
				if (this.ParentWindow.SendClientActions && !receivedFromImap)
				{
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					Dictionary<string, string> value = new Dictionary<string, string>
					{
						{
							"EventAction",
							"TabClosed"
						},
						{
							"tabKey",
							tabKey
						},
						{
							"sendStopAppToAndroid",
							sendStopAppToAndroid.ToString(CultureInfo.InvariantCulture)
						},
						{
							"forceClose",
							forceClose.ToString(CultureInfo.InvariantCulture)
						}
					};
					JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
					serializerSettings.Formatting = Formatting.None;
					dictionary.Add("operationData", JsonConvert.SerializeObject(value, serializerSettings));
					this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("handleClientOperation", dictionary);
				}
				AppTabButton appTabButton = this.mDictTabs[tabKey];
				if (appTabButton.mTabType == TabType.WebTab)
				{
					BrowserControl browserControl = null;
					foreach (object obj in appTabButton.mControlGrid.Children)
					{
						browserControl = (obj as BrowserControl);
						if (browserControl != null)
						{
							break;
						}
					}
					string arg = string.Empty;
					if (browserControl != null)
					{
						arg = browserControl.mUrl;
						appTabButton.mControlGrid.Children.Remove(browserControl);
						if (browserControl.CefBrowser != null)
						{
							foreach (BrowserControlTags args in browserControl.TagsSubscribed)
							{
								BrowserSubscriber mSubscriber = browserControl.mSubscriber;
								if (mSubscriber != null)
								{
									mSubscriber.UnsubscribeTag(args);
								}
							}
							browserControl.CefBrowser.Dispose();
						}
					}
					ClientStats.SendMiscellaneousStatsAsync("WebTabClosed", RegistryManager.Instance.UserGuid, arg, appTabButton.AppLabel, RegistryManager.Instance.Version, Oem.Instance.OEM, null, null, null);
				}
				if (FeatureManager.Instance.IsCheckForQuitPopup && !RegistryManager.Instance.Guest[this.ParentWindow.mVmName].IsGoogleSigninDone && appTabButton.mTabType == TabType.AppTab && appTabButton.PackageName == "com.android.vending")
				{
					QuitPopupControl quitPopupControl = new QuitPopupControl(this.ParentWindow);
					string text = "exit_popup_ots";
					quitPopupControl.CurrentPopupTag = text;
					BlueStacksUIBinding.Bind(quitPopupControl.TitleTextBlock, "STRING_YOU_ARE_ONE_STEP_AWAY", "");
					BlueStacksUIBinding.Bind(quitPopupControl.mCloseBlueStacksButton, "STRING_CLOSE_TAB");
					quitPopupControl.AddQuitActionItem(QuitActionItem.WhyGoogleAccount);
					quitPopupControl.AddQuitActionItem(QuitActionItem.TroubleSigningIn);
					quitPopupControl.AddQuitActionItem(QuitActionItem.SomethingElseWrong);
					quitPopupControl.CloseBlueStacksButton.PreviewMouseUp += delegate(object sender, MouseButtonEventArgs e)
					{
						this.CloseTabAfterQuitPopup(tabKey, sendStopAppToAndroid, forceClose);
					};
					quitPopupControl.CrossButtonPictureBox.PreviewMouseUp += delegate(object sender, MouseButtonEventArgs e)
					{
						if (string.Equals(topActivityPackageName, "com.bluestacks.appmart", StringComparison.InvariantCulture))
						{
							this.CloseTabAfterQuitPopup(tabKey, sendStopAppToAndroid, forceClose);
						}
					};
					new ContainerWindow(this.ParentWindow, quitPopupControl, quitPopupControl.Width, quitPopupControl.Height, false, true);
					ClientStats.SendLocalQuitPopupStatsAsync(text, "popup_shown");
					return;
				}
				if (!FeatureManager.Instance.IsCustomUIForDMM && !dontCheckQuitPopup && appTabButton.mTabType == TabType.AppTab && tabKey != this.mLastPackageForQuitPopupDisplayed && !this.ParentWindow.SendClientActions && !receivedFromImap)
				{
					if (this.ParentWindow.mWelcomeTab.mHomeApp.CheckDictAppIconFor(tabKey, (AppIcon _) => _.IsInstalledApp))
					{
						if (this.ParentWindow.mWelcomeTab.mHomeApp.CheckDictAppIconFor(tabKey, (AppIcon _) => !_.IsAppSuggestionActive))
						{
							ProgressBar el = new ProgressBar
							{
								ProgressText = "STRING_LOADING_MESSAGE",
								Visibility = Visibility.Hidden
							};
							this.ParentWindow.ShowDimOverlay(el);
							this.mLastPackageForQuitPopupDisplayed = tabKey;
							new Thread(delegate()
							{
								if (this.ParentWindow.Utils.CheckQuitPopupFromCloud(tabKey))
								{
									return;
								}
								this.Dispatcher.Invoke(new Action(delegate()
								{
									this.CloseTabAfterQuitPopup(tabKey, sendStopAppToAndroid, forceClose);
								}), new object[0]);
							})
							{
								IsBackground = true
							}.Start();
							goto IL_44B;
						}
					}
				}
				this.CloseTabAfterQuitPopup(tabKey, sendStopAppToAndroid, forceClose);
				IL_44B:
				this.ParentWindow.mCommonHandler.HandlingForGameSettingsRedDotForSelectedGamePackges(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName, false);
			}
		}

		// Token: 0x060002CA RID: 714 RVA: 0x00016754 File Offset: 0x00014954
		internal void CloseTabAfterQuitPopup(string tabKey, bool sendStopAppToAndroid, bool forceClose)
		{
			if (this.mDictTabs.ContainsKey(tabKey))
			{
				AppTabButton appTabButton = this.mDictTabs[tabKey];
				if (appTabButton.mTabType != TabType.HomeTab && this.ParentWindow.mDimOverlay != null && this.ParentWindow.mDimOverlay.Control != null && ((FeatureManager.Instance.IsCustomUIForNCSoft && this.ParentWindow.mDimOverlay.Control.GetType() == this.ParentWindow.ScreenLockInstance.GetType()) || !FeatureManager.Instance.IsCustomUIForNCSoft))
				{
					this.ParentWindow.HideDimOverlay();
					this.mPopup.IsOpen = false;
				}
				this.mLastPackageForQuitPopupDisplayed = "";
				if (appTabButton.mTabType != TabType.HomeTab || forceClose)
				{
					Publisher.PublishMessage(BrowserControlTags.tabClosing, appTabButton.PackageName, this.ParentWindow.mVmName);
					(appTabButton.Parent as Panel).Children.Remove(appTabButton);
					this.mDictTabs.Remove(tabKey);
					if (appTabButton.mTabType == TabType.AppTab || appTabButton.mTabType == TabType.HomeTab)
					{
						this.ParentWindow.mCommonHandler.ToggleMacroAndSyncVisibility();
					}
					if (sendStopAppToAndroid && appTabButton.mTabType == TabType.AppTab)
					{
						this.ParentWindow.mAppHandler.StopAppRequest(appTabButton.PackageName);
					}
					this.ListTabHistory.RemoveAll((string n) => n.Equals(tabKey, StringComparison.OrdinalIgnoreCase));
					if (this.ParentWindow.mDiscordhandler != null)
					{
						this.ParentWindow.mDiscordhandler.RemoveAppFromTimestampList(tabKey);
					}
					if (FeatureManager.Instance.IsCustomUIForDMM && this.ListTabHistory.Count == 0)
					{
						this.ParentWindow.Hide();
						this.ParentWindow.RestoreWindows(false);
						if (this.ParentWindow.mDMMRecommendedWindow != null)
						{
							this.ParentWindow.mDMMRecommendedWindow.Visibility = Visibility.Hidden;
						}
						this.ParentWindow.StaticComponents.mSelectedTabButton.IsPortraitModeTab = false;
					}
					else if (appTabButton.IsSelected)
					{
						if (this.ListTabHistory.Count != 0)
						{
							this.GoToTab(this.ListTabHistory[this.ListTabHistory.Count - 1], true, false);
						}
						else
						{
							Logger.Fatal("No tab to go back to! Ignoring");
						}
					}
					this.ResizeTabs();
				}
			}
		}

		// Token: 0x060002CB RID: 715 RVA: 0x0001699C File Offset: 0x00014B9C
		internal bool GoToTab(string key, bool isLaunch = true, bool receivedFromImap = false)
		{
			bool result = false;
			if (InteropWindow.GetForegroundWindow() != this.ParentWindow.Handle)
			{
				this.ParentWindow.mIsFocusComeFromImap = true;
			}
			if (this.mDictTabs.ContainsKey(key))
			{
				if (FeatureManager.Instance.IsCustomUIForDMM && this.ParentWindow.mFrontendGrid.Visibility != Visibility.Visible)
				{
					this.ParentWindow.mFrontendGrid.Visibility = Visibility.Visible;
					this.ParentWindow.mDmmProgressControl.Visibility = Visibility.Hidden;
				}
				AppTabButton appTabButton = this.mDictTabs[key];
				if (!appTabButton.IsSelected)
				{
					appTabButton.IsLaunchOnSelection = isLaunch;
					if (KMManager.sGuidanceWindow != null && GuidanceWindow.sIsDirty)
					{
						appTabButton.mIsAnyOperationPendingForTab = true;
					}
					else
					{
						appTabButton.mIsAnyOperationPendingForTab = false;
					}
					appTabButton.Select(true, receivedFromImap);
					result = true;
					EventHandler<TabChangeEventArgs> eventOnTabChanged = appTabButton.EventOnTabChanged;
					if (eventOnTabChanged != null)
					{
						eventOnTabChanged(null, new TabChangeEventArgs(appTabButton.AppName, appTabButton.PackageName, appTabButton.mTabType));
					}
				}
				else
				{
					result = true;
				}
			}
			return result;
		}

		// Token: 0x060002CC RID: 716 RVA: 0x00003E0F File Offset: 0x0000200F
		internal bool GoToTab(int index)
		{
			return this.mDictTabs.Count > index && this.GoToTab(this.mPanel.Children.OfType<AppTabButton>().Last<AppTabButton>().TabKey, true, false);
		}

		// Token: 0x060002CD RID: 717 RVA: 0x00003E43 File Offset: 0x00002043
		internal AppTabButton GetTab(string packageName)
		{
			if (this.mDictTabs.ContainsKey(packageName))
			{
				return this.mDictTabs[packageName];
			}
			return null;
		}

		// Token: 0x060002CE RID: 718 RVA: 0x00003E61 File Offset: 0x00002061
		private void MoreTabButton_Click(object sender, RoutedEventArgs e)
		{
			this.mPopup.IsOpen = true;
		}

		// Token: 0x060002CF RID: 719 RVA: 0x00003E6F File Offset: 0x0000206F
		private void NotificationPopup_Opened(object sender, EventArgs e)
		{
			this.mMoreTabButton.IsEnabled = false;
		}

		// Token: 0x060002D0 RID: 720 RVA: 0x00003E7D File Offset: 0x0000207D
		private void NotificationPopup_Closed(object sender, EventArgs e)
		{
			this.mMoreTabButton.IsEnabled = true;
		}

		// Token: 0x060002D1 RID: 721 RVA: 0x00003E8B File Offset: 0x0000208B
		private void NotificaitonPopup_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			new Thread(delegate()
			{
				Thread.Sleep(100);
				base.Dispatcher.Invoke(new Action(delegate()
				{
					this.mPopup.IsOpen = false;
				}), new object[0]);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060002D2 RID: 722 RVA: 0x00016A94 File Offset: 0x00014C94
		internal void EnableAppTabs(bool isEnableTab)
		{
			foreach (KeyValuePair<string, AppTabButton> keyValuePair in this.mDictTabs)
			{
				if (keyValuePair.Value.mTabType == TabType.AppTab)
				{
					keyValuePair.Value.IsEnabled = isEnableTab;
				}
			}
		}

		// Token: 0x060002D3 RID: 723 RVA: 0x00016AFC File Offset: 0x00014CFC
		internal bool IsAppRunning()
		{
			foreach (KeyValuePair<string, AppTabButton> keyValuePair in this.mDictTabs)
			{
				if (keyValuePair.Value.mTabType == TabType.AppTab)
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x060002D4 RID: 724 RVA: 0x00016B60 File Offset: 0x00014D60
		internal void RestartTab(string package)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.CloseTab(package, true, true, true, false, "");
			}), new object[0]);
			Thread.Sleep(1000);
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon(package).OpenApp(false);
			}), new object[0]);
		}

		// Token: 0x0400017F RID: 383
		private MainWindow mMainWindow;

		// Token: 0x04000180 RID: 384
		internal AppTabButton mHomeAppTabButton;

		// Token: 0x04000181 RID: 385
		private int mTabMinWidth = 48;

		// Token: 0x04000182 RID: 386
		private DateTime mLastTimeOfSizeChangeEventRecieved = DateTime.Now;

		// Token: 0x04000183 RID: 387
		private int mSizeChangedEventCountInLast2Seconds = 1;

		// Token: 0x04000184 RID: 388
		internal Dictionary<string, AppTabButton> mDictTabs = new Dictionary<string, AppTabButton>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04000187 RID: 391
		internal string mLastPackageForQuitPopupDisplayed = "";

		// Token: 0x0200002E RID: 46
		private enum TabMode
		{
			// Token: 0x0400018F RID: 399
			ParallelogramMode,
			// Token: 0x04000190 RID: 400
			IconMode
		}
	}
}
