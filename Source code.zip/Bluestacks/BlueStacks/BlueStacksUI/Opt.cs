﻿using System;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200018E RID: 398
	public sealed class Opt : GetOpt
	{
		// Token: 0x17000274 RID: 628
		// (get) Token: 0x06000F73 RID: 3955 RVA: 0x0000B43D File Offset: 0x0000963D
		// (set) Token: 0x06000F74 RID: 3956 RVA: 0x0000B445 File Offset: 0x00009645
		public string vmname { get; set; } = "Android";

		// Token: 0x17000275 RID: 629
		// (get) Token: 0x06000F75 RID: 3957 RVA: 0x0000B44E File Offset: 0x0000964E
		// (set) Token: 0x06000F76 RID: 3958 RVA: 0x0000B456 File Offset: 0x00009656
		public bool h { get; set; }

		// Token: 0x17000276 RID: 630
		// (get) Token: 0x06000F77 RID: 3959 RVA: 0x0000B45F File Offset: 0x0000965F
		// (set) Token: 0x06000F78 RID: 3960 RVA: 0x0000B467 File Offset: 0x00009667
		public bool mergeCfg { get; set; }

		// Token: 0x17000277 RID: 631
		// (get) Token: 0x06000F79 RID: 3961 RVA: 0x0000B470 File Offset: 0x00009670
		// (set) Token: 0x06000F7A RID: 3962 RVA: 0x0000B478 File Offset: 0x00009678
		public bool isForceInstall { get; set; }

		// Token: 0x17000278 RID: 632
		// (get) Token: 0x06000F7B RID: 3963 RVA: 0x0000B481 File Offset: 0x00009681
		// (set) Token: 0x06000F7C RID: 3964 RVA: 0x0000B489 File Offset: 0x00009689
		public string newPDPath { get; set; } = string.Empty;

		// Token: 0x17000279 RID: 633
		// (get) Token: 0x06000F7D RID: 3965 RVA: 0x0000B492 File Offset: 0x00009692
		// (set) Token: 0x06000F7E RID: 3966 RVA: 0x0000B49A File Offset: 0x0000969A
		public bool isUpgradeFromImap13 { get; set; }

		// Token: 0x1700027A RID: 634
		// (get) Token: 0x06000F7F RID: 3967 RVA: 0x0000B4A3 File Offset: 0x000096A3
		// (set) Token: 0x06000F80 RID: 3968 RVA: 0x0000B4AB File Offset: 0x000096AB
		public bool force { get; set; }

		// Token: 0x1700027B RID: 635
		// (get) Token: 0x06000F81 RID: 3969 RVA: 0x0000B4B4 File Offset: 0x000096B4
		// (set) Token: 0x06000F82 RID: 3970 RVA: 0x0000B4BC File Offset: 0x000096BC
		public bool launchedFromSysTray { get; set; }

		// Token: 0x1700027C RID: 636
		// (get) Token: 0x06000F83 RID: 3971 RVA: 0x0000B4C5 File Offset: 0x000096C5
		// (set) Token: 0x06000F84 RID: 3972 RVA: 0x0000B4CD File Offset: 0x000096CD
		public string Json
		{
			get
			{
				return this.json;
			}
			set
			{
				this.json = Uri.UnescapeDataString(value);
			}
		}

		// Token: 0x06000F85 RID: 3973 RVA: 0x0000B4DB File Offset: 0x000096DB
		private Opt()
		{
		}

		// Token: 0x1700027D RID: 637
		// (get) Token: 0x06000F86 RID: 3974 RVA: 0x0006405C File Offset: 0x0006225C
		public static Opt Instance
		{
			get
			{
				if (Opt.instance == null)
				{
					object obj = Opt.syncRoot;
					lock (obj)
					{
						if (Opt.instance == null)
						{
							Opt.instance = new Opt();
						}
					}
				}
				return Opt.instance;
			}
		}

		// Token: 0x04000A88 RID: 2696
		private static volatile Opt instance;

		// Token: 0x04000A89 RID: 2697
		private static object syncRoot = new object();

		// Token: 0x04000A92 RID: 2706
		private string json = "";
	}
}
