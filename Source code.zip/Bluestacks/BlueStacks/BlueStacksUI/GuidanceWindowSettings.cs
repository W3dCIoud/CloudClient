﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Markup;
using System.Windows.Navigation;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200011D RID: 285
	public class GuidanceWindowSettings : UserControl, IComponentConnector
	{
		// Token: 0x06000B46 RID: 2886 RVA: 0x00042CE8 File Offset: 0x00040EE8
		public GuidanceWindowSettings()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000B47 RID: 2887 RVA: 0x00042D5C File Offset: 0x00040F5C
		internal void Init(MainWindow window)
		{
			this.ParentWindow = window;
			string packageName = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName;
			string str = WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
			{
				WebHelper.GetServerHost(),
				"help_articles"
			})) + "&article=";
			if (PackageActivityNames.ThirdParty.AllPUBGPackageNames.Contains(packageName))
			{
				this.PUBGGrid.Visibility = Visibility.Visible;
				this.mCurrentPUBGResolution = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GamingResolutionPubg;
				if (!string.IsNullOrEmpty(this.mCurrentPUBGResolution))
				{
					if (this.mCurrentPUBGResolution == "1")
					{
						this.m720Resolution.IsChecked = new bool?(true);
					}
					else if (this.mCurrentPUBGResolution == "1.5")
					{
						this.m1080Resolution.IsChecked = new bool?(true);
					}
					else
					{
						this.m2kResolution.IsChecked = new bool?(true);
					}
				}
				else
				{
					this.m720Resolution.IsChecked = new bool?(true);
				}
				this.mSelectedPUBGResolution = this.mCurrentPUBGResolution;
				this.mCurrentPUBGDisplay = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityPubg;
				if (!string.IsNullOrEmpty(this.mCurrentPUBGDisplay))
				{
					if (this.mCurrentPUBGDisplay == "-1")
					{
						this.mAutoDisplay.IsChecked = new bool?(true);
					}
					else if (this.mCurrentPUBGDisplay == "0")
					{
						this.mSmoothDisplay.IsChecked = new bool?(true);
					}
					else if (this.mCurrentPUBGDisplay == "1")
					{
						this.mBalancedDisplay.IsChecked = new bool?(true);
					}
					else
					{
						this.mHDDisplay.IsChecked = new bool?(true);
					}
				}
				else
				{
					this.mAutoDisplay.IsChecked = new bool?(true);
				}
				this.mSelectedPUBGDisplay = this.mCurrentPUBGDisplay;
				this.mKnowMoreLink.NavigateUri = new Uri(str + "game_settings_know_more_pubg");
			}
			if (PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.Contains(packageName))
			{
				this.CODGrid.Visibility = Visibility.Visible;
				this.mCurrentCODResolution = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GamingResolutionCOD;
				if (!string.IsNullOrEmpty(this.mCurrentCODResolution))
				{
					if (this.mCurrentCODResolution == "720")
					{
						this.mCOD720Resolution.IsChecked = new bool?(true);
					}
					else if (this.mCurrentCODResolution == "1080")
					{
						this.mCOD1080Resolution.IsChecked = new bool?(true);
					}
					else if (this.mCurrentCODResolution == "1440")
					{
						this.mCOD2kResolution.IsChecked = new bool?(true);
					}
					else
					{
						this.mCOD4kResolution.IsChecked = new bool?(true);
					}
				}
				else
				{
					this.mCOD720Resolution.IsChecked = new bool?(true);
				}
				this.mSelectedCODResolution = this.mCurrentCODResolution;
				this.mCurrentCODDisplay = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityCOD;
				if (!string.IsNullOrEmpty(this.mCurrentCODDisplay))
				{
					if (this.mCurrentCODDisplay == "-1")
					{
						this.mCODAutoDisplay.IsChecked = new bool?(true);
					}
					else if (this.mCurrentCODDisplay == "0")
					{
						this.mCODSmoothDisplay.IsChecked = new bool?(true);
					}
					else if (this.mCurrentCODDisplay == "1")
					{
						this.mCODBalancedDisplay.IsChecked = new bool?(true);
					}
					else
					{
						this.mCODHDDisplay.IsChecked = new bool?(true);
					}
				}
				else
				{
					this.mCODAutoDisplay.IsChecked = new bool?(true);
				}
				this.mSelectedCODDisplay = this.mCurrentCODDisplay;
				this.mKnowMoreLink.NavigateUri = new Uri(str + "game_settings_know_more_callofduty");
			}
			if ("com.dts.freefireth".Contains(packageName))
			{
				this.FreeFireGrid.Visibility = Visibility.Visible;
				if (this.ParentWindow.EngineInstanceRegistry.IsFreeFireInGameSettingsCustomized)
				{
					GuidanceWindowSettings.mCurrentFeatures = FeatureBitHelper.EnableFeature(2UL, GuidanceWindowSettings.mCurrentFeatures);
					GuidanceWindowSettings.mNewFeatures = GuidanceWindowSettings.mCurrentFeatures;
					this.mInGameFreeFireSettingsCheckBox.IsChecked = new bool?(true);
				}
				this.mKnowMoreLink.NavigateUri = new Uri(str + "game_settings_know_more_freefire");
			}
			if (PackageActivityNames.ThirdParty.AllSevenDeadlySinsPackageNames.Contains(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName))
			{
				this.SevenDeadlyGrid.Visibility = Visibility.Visible;
				if (this.ParentWindow.EngineInstanceRegistry.SevenDeadlySinsLandscape)
				{
					this.m7DSLandscapeCheckBox.IsChecked = new bool?(true);
				}
				this.mKnowMoreLink.NavigateUri = new Uri(str + "game_settings_know_more_sevendeadly");
			}
			this.mKnowMoreLink.Inlines.Clear();
			this.mKnowMoreLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_KNOW_MORE"));
		}

		// Token: 0x06000B48 RID: 2888 RVA: 0x00043264 File Offset: 0x00041464
		private void Resolution_Checked(object sender, RoutedEventArgs e)
		{
			if (this.m720Resolution.IsChecked.Value)
			{
				this.mSelectedPUBGResolution = "1";
			}
			else if (this.m1080Resolution.IsChecked.Value)
			{
				this.mSelectedPUBGResolution = "1.5";
			}
			else if (this.m2kResolution.IsChecked.Value)
			{
				this.mSelectedPUBGResolution = "2";
			}
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x06000B49 RID: 2889 RVA: 0x000432DC File Offset: 0x000414DC
		private void Display_Checked(object sender, RoutedEventArgs e)
		{
			if (this.mAutoDisplay.IsChecked.Value)
			{
				this.mSelectedPUBGDisplay = "-1";
			}
			else if (this.mSmoothDisplay.IsChecked.Value)
			{
				this.mSelectedPUBGDisplay = "0";
			}
			else if (this.mBalancedDisplay.IsChecked.Value)
			{
				this.mSelectedPUBGDisplay = "1";
			}
			else if (this.mHDDisplay.IsChecked.Value)
			{
				this.mSelectedPUBGDisplay = "2";
			}
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x06000B4A RID: 2890 RVA: 0x00043378 File Offset: 0x00041578
		internal void SaveChangesBtn_Click(object sender, RoutedEventArgs e)
		{
			if (this.mSelectedPUBGResolution != this.mCurrentPUBGResolution)
			{
				RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GamingResolutionPubg = this.mSelectedPUBGResolution;
				this.mCurrentPUBGResolution = this.mSelectedPUBGResolution;
				string text = this.mSelectedPUBGResolution;
				if (text != null)
				{
					if (!(text == "1"))
					{
						if (!(text == "1.5"))
						{
							if (text == "2")
							{
								this.SendGameSettingsStat("pubg_res_1440");
							}
						}
						else
						{
							this.SendGameSettingsStat("pubg_res_1080");
						}
					}
					else
					{
						this.SendGameSettingsStat("pubg_res_720");
					}
				}
			}
			if (this.mSelectedPUBGDisplay != this.mCurrentPUBGDisplay)
			{
				RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityPubg = this.mSelectedPUBGDisplay;
				this.mCurrentPUBGDisplay = this.mSelectedPUBGDisplay;
				string text = this.mSelectedPUBGDisplay;
				if (text != null)
				{
					if (!(text == "-1"))
					{
						if (!(text == "1"))
						{
							if (!(text == "2"))
							{
								if (text == "0")
								{
									this.SendGameSettingsStat("pubg_gfx_smooth");
								}
							}
							else
							{
								this.SendGameSettingsStat("pubg_gfx_hd");
							}
						}
						else
						{
							this.SendGameSettingsStat("pubg_gfx_balanced");
						}
					}
					else
					{
						this.SendGameSettingsStat("pubg_gfx_auto");
					}
				}
			}
			if (this.mSelectedCODResolution != this.mCurrentCODResolution)
			{
				RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GamingResolutionCOD = this.mSelectedCODResolution;
				this.mCurrentCODResolution = this.mSelectedCODResolution;
				string text = this.mSelectedCODResolution;
				if (text != null)
				{
					if (!(text == "720"))
					{
						if (!(text == "1080"))
						{
							if (!(text == "1440"))
							{
								if (text == "2160")
								{
									this.SendGameSettingsStat("cod_res_1440");
								}
							}
							else
							{
								this.SendGameSettingsStat("cod_res_1440");
							}
						}
						else
						{
							this.SendGameSettingsStat("cod_res_1080");
						}
					}
					else
					{
						this.SendGameSettingsStat("cod_res_720");
					}
				}
			}
			if (this.mSelectedCODDisplay != this.mCurrentCODDisplay)
			{
				RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityCOD = this.mSelectedCODDisplay;
				this.mCurrentCODDisplay = this.mSelectedCODDisplay;
				string text = this.mSelectedCODDisplay;
				if (text != null)
				{
					if (!(text == "-1"))
					{
						if (!(text == "1"))
						{
							if (!(text == "2"))
							{
								if (text == "0")
								{
									this.SendGameSettingsStat("cod_gfx_smooth");
								}
							}
							else
							{
								this.SendGameSettingsStat("cod_gfx_hd");
							}
						}
						else
						{
							this.SendGameSettingsStat("cod_gfx_balanced");
						}
					}
					else
					{
						this.SendGameSettingsStat("cod_gfx_auto");
					}
				}
			}
			bool flag;
			if (GuidanceWindowSettings.IsAnyFeatureDifferent() && this.WasFeatureChanged(2UL, out flag))
			{
				this.SendGameSettingsEnabledToGuest(flag);
				this.ParentWindow.EngineInstanceRegistry.IsFreeFireInGameSettingsCustomized = flag;
				if (flag)
				{
					this.SendGameSettingsStat("freefire_optimizegame_enabled");
				}
				else
				{
					this.SendGameSettingsStat("freefire_optimizegame_disabled");
				}
			}
			if (PackageActivityNames.ThirdParty.AllSevenDeadlySinsPackageNames.Contains(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName))
			{
				bool sevenDeadlySinsLandscape = this.ParentWindow.EngineInstanceRegistry.SevenDeadlySinsLandscape;
				bool? isChecked = this.m7DSLandscapeCheckBox.IsChecked;
				if (!(sevenDeadlySinsLandscape == isChecked.GetValueOrDefault() & isChecked != null))
				{
					string mVmName = this.ParentWindow.mVmName;
					string packageName = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName;
					isChecked = this.m7DSLandscapeCheckBox.IsChecked;
					bool flag2 = true;
					Utils.SetCustomAppSize(mVmName, packageName, (isChecked.GetValueOrDefault() == flag2 & isChecked != null) ? ScreenMode.full : ScreenMode.original);
					MainWindow parentWindow = this.ParentWindow;
					isChecked = this.m7DSLandscapeCheckBox.IsChecked;
					flag2 = true;
					KMManager.SelectSchemeIfPresent(parentWindow, (isChecked.GetValueOrDefault() == flag2 & isChecked != null) ? "Landscape" : "Portrait", "gamesettings", false);
					InstanceRegistry engineInstanceRegistry = this.ParentWindow.EngineInstanceRegistry;
					isChecked = this.m7DSLandscapeCheckBox.IsChecked;
					flag2 = true;
					engineInstanceRegistry.SevenDeadlySinsLandscape = (isChecked.GetValueOrDefault() == flag2 & isChecked != null);
					isChecked = this.m7DSLandscapeCheckBox.IsChecked;
					flag2 = true;
					if (isChecked.GetValueOrDefault() == flag2 & isChecked != null)
					{
						this.SendGameSettingsStat("seven_deadly_sins_landscape_enabled");
					}
					else
					{
						this.SendGameSettingsStat("seven_deadly_sins_landscape_disabled");
					}
				}
			}
			GuidanceWindowSettings.mCurrentFeatures = GuidanceWindowSettings.mNewFeatures;
			bool flag3 = this.mRestartRequired;
			this.CheckAndToggleSaveButton();
			if (e != null)
			{
				this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_CHANGES_SAVED"));
				if (flag3)
				{
					if (PackageActivityNames.ThirdParty.AllPUBGPackageNames.Contains(this.ParentWindow.StaticComponents.mSelectedTabButton.PackageName))
					{
						CustomMessageWindow customMessageWindow = new CustomMessageWindow();
						string path = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_RESTART_OBJECT"), new object[]
						{
							"PUBG Mobile"
						});
						BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, path, "");
						string path2 = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_SETTING_CHANGED_RESTART_APP_MESSAGE"), new object[]
						{
							"PUBG Mobile"
						});
						BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, path2, "");
						customMessageWindow.AddButton(ButtonColors.Blue, "STRING_RESTART_NOW", new EventHandler(KMManager.sGuidanceWindow.RestartConfirmationAcceptedHandler), null, false, null);
						customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
						customMessageWindow.Owner = this.ParentWindow;
						customMessageWindow.ShowDialog();
						return;
					}
					if (PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.Contains(this.ParentWindow.StaticComponents.mSelectedTabButton.PackageName))
					{
						CustomMessageWindow customMessageWindow2 = new CustomMessageWindow();
						string path3 = string.Format(CultureInfo.InvariantCulture, "{0} {1}", new object[]
						{
							LocaleStrings.GetLocalizedString("STRING_RESTART"),
							"Call of Duty: Mobile"
						});
						BlueStacksUIBinding.Bind(customMessageWindow2.TitleTextBlock, path3, "");
						string path4 = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_SETTING_CHANGED_RESTART_APP_MESSAGE"), new object[]
						{
							"Call of Duty: Mobile"
						});
						BlueStacksUIBinding.Bind(customMessageWindow2.BodyTextBlock, path4, "");
						customMessageWindow2.AddButton(ButtonColors.Blue, "STRING_RESTART_NOW", new EventHandler(KMManager.sGuidanceWindow.RestartConfirmationAcceptedHandler), null, false, null);
						customMessageWindow2.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
						customMessageWindow2.Owner = this.ParentWindow;
						customMessageWindow2.ShowDialog();
						return;
					}
					if (PackageActivityNames.ThirdParty.AllSevenDeadlySinsPackageNames.Contains(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName))
					{
						CustomMessageWindow customMessageWindow3 = new CustomMessageWindow();
						string path5 = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_RESTART_OBJECT"), new object[]
						{
							this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.AppName
						});
						BlueStacksUIBinding.Bind(customMessageWindow3.TitleTextBlock, path5, "");
						string path6 = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_SETTING_CHANGED_RESTART_APP_MESSAGE"), new object[]
						{
							this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.AppName
						});
						BlueStacksUIBinding.Bind(customMessageWindow3.BodyTextBlock, path6, "");
						customMessageWindow3.AddButton(ButtonColors.Blue, "STRING_RESTART_NOW", new EventHandler(KMManager.sGuidanceWindow.RestartConfirmationAcceptedHandler), null, false, null);
						customMessageWindow3.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
						customMessageWindow3.Owner = this.ParentWindow;
						customMessageWindow3.ShowDialog();
					}
				}
			}
		}

		// Token: 0x06000B4B RID: 2891 RVA: 0x00043AFC File Offset: 0x00041CFC
		private void AddToastPopup(string message)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (this.mToastPopup == null)
				{
					this.mToastPopup = new CustomToastPopupControl(this);
				}
				Thickness value = new Thickness(0.0, 0.0, 0.0, 50.0);
				this.mToastPopup.Init(this, message, null, null, HorizontalAlignment.Center, VerticalAlignment.Bottom, new Thickness?(value), 12, null, null);
				this.mToastPopup.ShowPopup(1.3);
			}), new object[0]);
		}

		// Token: 0x06000B4C RID: 2892 RVA: 0x0003A7BC File Offset: 0x000389BC
		private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
		{
			try
			{
				Logger.Info("Opening url: " + e.Uri.AbsoluteUri);
				BlueStacksUIUtils.OpenUrl(e.Uri.AbsoluteUri);
				e.Handled = true;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in opening url" + ex.ToString());
			}
		}

		// Token: 0x06000B4D RID: 2893 RVA: 0x000090C4 File Offset: 0x000072C4
		private void InGameFreeFireSettingsCheckBox_Checked(object sender, RoutedEventArgs e)
		{
			GuidanceWindowSettings.mNewFeatures = FeatureBitHelper.EnableFeature(2UL, GuidanceWindowSettings.mNewFeatures);
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x06000B4E RID: 2894 RVA: 0x000090DD File Offset: 0x000072DD
		private void InGameFreeFireSettingsCheckBox_Unchecked(object sender, RoutedEventArgs e)
		{
			GuidanceWindowSettings.mNewFeatures = FeatureBitHelper.DisableFeature(2UL, GuidanceWindowSettings.mNewFeatures);
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x06000B4F RID: 2895 RVA: 0x00043B3C File Offset: 0x00041D3C
		private void SendGameSettingsEnabledToGuest(bool enabled)
		{
			string text = "{";
			text += string.Format(CultureInfo.InvariantCulture, "\"package_name\":\"{0}\",", new object[]
			{
				"com.dts.freefireth"
			});
			text += string.Format(CultureInfo.InvariantCulture, "\"game_settings_enabled\":\"{0}\"", new object[]
			{
				enabled.ToString(CultureInfo.InvariantCulture)
			});
			text += "}";
			VmCmdHandler.RunCommandAsync(string.Format(CultureInfo.InvariantCulture, "{0} {1}", new object[]
			{
				"gameSettingsEnabled",
				text
			}), null, null, this.ParentWindow.mVmName);
		}

		// Token: 0x06000B50 RID: 2896 RVA: 0x00043BE0 File Offset: 0x00041DE0
		private void CheckAndToggleSaveButton()
		{
			if (this.mSelectedPUBGResolution != this.mCurrentPUBGResolution || this.mSelectedPUBGDisplay != this.mCurrentPUBGDisplay || this.mSelectedCODResolution != this.mCurrentCODResolution || this.mSelectedCODDisplay != this.mCurrentCODDisplay)
			{
				this.mSaveChangesBtn.IsEnabled = true;
				this.mRestartRequired = true;
				if (PackageActivityNames.ThirdParty.AllPUBGPackageNames.Contains(KMManager.sPackageName))
				{
					this.mChangeSchemeInfo.Visibility = Visibility.Visible;
					return;
				}
			}
			else if (PackageActivityNames.ThirdParty.AllSevenDeadlySinsPackageNames.Contains(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName))
			{
				bool sevenDeadlySinsLandscape = this.ParentWindow.EngineInstanceRegistry.SevenDeadlySinsLandscape;
				bool? isChecked = this.m7DSLandscapeCheckBox.IsChecked;
				if (!(sevenDeadlySinsLandscape == isChecked.GetValueOrDefault() & isChecked != null))
				{
					this.mSaveChangesBtn.IsEnabled = true;
					this.mRestartRequired = true;
					this.mChangeSchemeInfo.Visibility = Visibility.Collapsed;
					return;
				}
				this.mSaveChangesBtn.IsEnabled = false;
				this.mRestartRequired = false;
				this.mChangeSchemeInfo.Visibility = Visibility.Collapsed;
				return;
			}
			else if (GuidanceWindowSettings.IsAnyFeatureDifferent())
			{
				this.mRestartRequired = false;
				this.mSaveChangesBtn.IsEnabled = true;
				if (PackageActivityNames.ThirdParty.AllPUBGPackageNames.Contains(KMManager.sPackageName))
				{
					this.mChangeSchemeInfo.Visibility = Visibility.Visible;
					return;
				}
			}
			else
			{
				this.mSaveChangesBtn.IsEnabled = false;
				this.mRestartRequired = false;
				this.mChangeSchemeInfo.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x06000B51 RID: 2897 RVA: 0x000090F6 File Offset: 0x000072F6
		private static bool IsAnyFeatureDifferent()
		{
			return GuidanceWindowSettings.mCurrentFeatures != GuidanceWindowSettings.mNewFeatures;
		}

		// Token: 0x06000B52 RID: 2898 RVA: 0x00009107 File Offset: 0x00007307
		private bool WasFeatureChanged(ulong featureMask, out bool isEnabled)
		{
			return FeatureBitHelper.WasFeatureChanged(featureMask, GuidanceWindowSettings.mNewFeatures, GuidanceWindowSettings.mCurrentFeatures, out isEnabled);
		}

		// Token: 0x06000B53 RID: 2899 RVA: 0x00043D5C File Offset: 0x00041F5C
		private void SendGameSettingsStat(string statsTag)
		{
			ClientStats.SendMiscellaneousStatsAsync("client_game_settings", RegistryManager.Instance.UserGuid, statsTag, RegistryManager.Instance.ClientVersion, ((GLMode)this.ParentWindow.EngineInstanceRegistry.GlMode).ToString(), ((GLRenderer)this.ParentWindow.EngineInstanceRegistry.GlRenderMode).ToString(), null, null, null);
		}

		// Token: 0x06000B54 RID: 2900 RVA: 0x00043DC8 File Offset: 0x00041FC8
		private void CODResolution_Checked(object sender, RoutedEventArgs e)
		{
			if (this.mCOD720Resolution.IsChecked.Value)
			{
				this.mSelectedCODResolution = "720";
			}
			else if (this.mCOD1080Resolution.IsChecked.Value)
			{
				this.mSelectedCODResolution = "1080";
			}
			else if (this.mCOD2kResolution.IsChecked.Value)
			{
				this.mSelectedCODResolution = "1440";
			}
			else if (this.mCOD4kResolution.IsChecked.Value)
			{
				this.mSelectedCODResolution = "2160";
			}
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x06000B55 RID: 2901 RVA: 0x00043E64 File Offset: 0x00042064
		private void CODDisplay_Checked(object sender, RoutedEventArgs e)
		{
			if (this.mCODAutoDisplay.IsChecked.Value)
			{
				this.mSelectedCODDisplay = "-1";
			}
			else if (this.mCODSmoothDisplay.IsChecked.Value)
			{
				this.mSelectedCODDisplay = "0";
			}
			else if (this.mCODBalancedDisplay.IsChecked.Value)
			{
				this.mSelectedCODDisplay = "1";
			}
			else if (this.mCODHDDisplay.IsChecked.Value)
			{
				this.mSelectedCODDisplay = "2";
			}
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x06000B56 RID: 2902 RVA: 0x0000911A File Offset: 0x0000731A
		private void SDSLandscapeCheckBox_Checked(object sender, RoutedEventArgs e)
		{
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x06000B57 RID: 2903 RVA: 0x0000911A File Offset: 0x0000731A
		private void SDSLandscapeCheckBox_Unchecked(object sender, RoutedEventArgs e)
		{
			this.CheckAndToggleSaveButton();
		}

		// Token: 0x06000B58 RID: 2904 RVA: 0x00043F00 File Offset: 0x00042100
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/guidancewindowsettings.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000B59 RID: 2905 RVA: 0x00043F30 File Offset: 0x00042130
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mScrollBar = (ScrollViewer)target;
				return;
			case 2:
				this.CODGrid = (StackPanel)target;
				return;
			case 3:
				this.mCODGamingResolutionGrid = (Grid)target;
				return;
			case 4:
				this.mCOD720Resolution = (CustomRadioButton)target;
				this.mCOD720Resolution.Checked += this.CODResolution_Checked;
				return;
			case 5:
				this.mCOD1080Resolution = (CustomRadioButton)target;
				this.mCOD1080Resolution.Checked += this.CODResolution_Checked;
				return;
			case 6:
				this.mCOD2kResolution = (CustomRadioButton)target;
				this.mCOD2kResolution.Checked += this.CODResolution_Checked;
				return;
			case 7:
				this.mCOD4kResolution = (CustomRadioButton)target;
				this.mCOD4kResolution.Checked += this.CODResolution_Checked;
				return;
			case 8:
				this.mCODDisplayQualityGrid = (Grid)target;
				return;
			case 9:
				this.mCODAutoDisplay = (CustomRadioButton)target;
				this.mCODAutoDisplay.Checked += this.CODDisplay_Checked;
				return;
			case 10:
				this.mCODSmoothDisplay = (CustomRadioButton)target;
				this.mCODSmoothDisplay.Checked += this.CODDisplay_Checked;
				return;
			case 11:
				this.mCODBalancedDisplay = (CustomRadioButton)target;
				this.mCODBalancedDisplay.Checked += this.CODDisplay_Checked;
				return;
			case 12:
				this.mCODHDDisplay = (CustomRadioButton)target;
				this.mCODHDDisplay.Checked += this.CODDisplay_Checked;
				return;
			case 13:
				this.FreeFireGrid = (StackPanel)target;
				return;
			case 14:
				this.mOptimizedFreeFireSettings = (Grid)target;
				return;
			case 15:
				this.mInGameFreeFireSettingsCheckBox = (CustomCheckbox)target;
				this.mInGameFreeFireSettingsCheckBox.Checked += this.InGameFreeFireSettingsCheckBox_Checked;
				this.mInGameFreeFireSettingsCheckBox.Unchecked += this.InGameFreeFireSettingsCheckBox_Unchecked;
				return;
			case 16:
				this.mInGameFreeFireSettingsHelpTextBlock = (TextBlock)target;
				return;
			case 17:
				this.SevenDeadlyGrid = (StackPanel)target;
				return;
			case 18:
				this.m7DSLandscapeCheckBox = (CustomCheckbox)target;
				this.m7DSLandscapeCheckBox.Checked += this.SDSLandscapeCheckBox_Checked;
				this.m7DSLandscapeCheckBox.Unchecked += this.SDSLandscapeCheckBox_Unchecked;
				return;
			case 19:
				this.PUBGGrid = (StackPanel)target;
				return;
			case 20:
				this.mPUBGGamingResolutionGrid = (Grid)target;
				return;
			case 21:
				this.m720Resolution = (CustomRadioButton)target;
				this.m720Resolution.Checked += this.Resolution_Checked;
				return;
			case 22:
				this.m720ResolutionMessage = (TextBlock)target;
				return;
			case 23:
				this.m1080Resolution = (CustomRadioButton)target;
				this.m1080Resolution.Checked += this.Resolution_Checked;
				return;
			case 24:
				this.m2kResolution = (CustomRadioButton)target;
				this.m2kResolution.Checked += this.Resolution_Checked;
				return;
			case 25:
				this.mDisplayQualityGrid = (Grid)target;
				return;
			case 26:
				this.mAutoDisplay = (CustomRadioButton)target;
				this.mAutoDisplay.Checked += this.Display_Checked;
				return;
			case 27:
				this.mSmoothDisplay = (CustomRadioButton)target;
				this.mSmoothDisplay.Checked += this.Display_Checked;
				return;
			case 28:
				this.mBalancedDisplay = (CustomRadioButton)target;
				this.mBalancedDisplay.Checked += this.Display_Checked;
				return;
			case 29:
				this.mHDDisplay = (CustomRadioButton)target;
				this.mHDDisplay.Checked += this.Display_Checked;
				return;
			case 30:
				this.mChangeSchemeInfo = (Border)target;
				return;
			case 31:
				this.mSaveChangesBtn = (CustomButton)target;
				this.mSaveChangesBtn.Click += this.SaveChangesBtn_Click;
				return;
			case 32:
				this.mKnowMoreLink = (Hyperlink)target;
				this.mKnowMoreLink.RequestNavigate += this.Hyperlink_RequestNavigate;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400073B RID: 1851
		private MainWindow ParentWindow;

		// Token: 0x0400073C RID: 1852
		private const ulong FREEFIRE_ENABLE_OPTIMIZE_INGAME_SETTINGS = 2UL;

		// Token: 0x0400073D RID: 1853
		private static ulong mCurrentFeatures;

		// Token: 0x0400073E RID: 1854
		private static ulong mNewFeatures;

		// Token: 0x0400073F RID: 1855
		private CustomToastPopupControl mToastPopup;

		// Token: 0x04000740 RID: 1856
		private string mCurrentPUBGResolution = "1";

		// Token: 0x04000741 RID: 1857
		private string mSelectedPUBGResolution = "1";

		// Token: 0x04000742 RID: 1858
		private string mCurrentPUBGDisplay = "-1";

		// Token: 0x04000743 RID: 1859
		private string mSelectedPUBGDisplay = "-1";

		// Token: 0x04000744 RID: 1860
		private string mCurrentCODResolution = "1";

		// Token: 0x04000745 RID: 1861
		private string mSelectedCODResolution = "1";

		// Token: 0x04000746 RID: 1862
		private string mCurrentCODDisplay = "-1";

		// Token: 0x04000747 RID: 1863
		private string mSelectedCODDisplay = "-1";

		// Token: 0x04000748 RID: 1864
		internal bool mRestartRequired;

		// Token: 0x04000749 RID: 1865
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ScrollViewer mScrollBar;

		// Token: 0x0400074A RID: 1866
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel CODGrid;

		// Token: 0x0400074B RID: 1867
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mCODGamingResolutionGrid;

		// Token: 0x0400074C RID: 1868
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mCOD720Resolution;

		// Token: 0x0400074D RID: 1869
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mCOD1080Resolution;

		// Token: 0x0400074E RID: 1870
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mCOD2kResolution;

		// Token: 0x0400074F RID: 1871
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mCOD4kResolution;

		// Token: 0x04000750 RID: 1872
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mCODDisplayQualityGrid;

		// Token: 0x04000751 RID: 1873
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mCODAutoDisplay;

		// Token: 0x04000752 RID: 1874
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mCODSmoothDisplay;

		// Token: 0x04000753 RID: 1875
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mCODBalancedDisplay;

		// Token: 0x04000754 RID: 1876
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mCODHDDisplay;

		// Token: 0x04000755 RID: 1877
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel FreeFireGrid;

		// Token: 0x04000756 RID: 1878
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mOptimizedFreeFireSettings;

		// Token: 0x04000757 RID: 1879
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mInGameFreeFireSettingsCheckBox;

		// Token: 0x04000758 RID: 1880
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mInGameFreeFireSettingsHelpTextBlock;

		// Token: 0x04000759 RID: 1881
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel SevenDeadlyGrid;

		// Token: 0x0400075A RID: 1882
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox m7DSLandscapeCheckBox;

		// Token: 0x0400075B RID: 1883
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel PUBGGrid;

		// Token: 0x0400075C RID: 1884
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mPUBGGamingResolutionGrid;

		// Token: 0x0400075D RID: 1885
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton m720Resolution;

		// Token: 0x0400075E RID: 1886
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock m720ResolutionMessage;

		// Token: 0x0400075F RID: 1887
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton m1080Resolution;

		// Token: 0x04000760 RID: 1888
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton m2kResolution;

		// Token: 0x04000761 RID: 1889
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mDisplayQualityGrid;

		// Token: 0x04000762 RID: 1890
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mAutoDisplay;

		// Token: 0x04000763 RID: 1891
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mSmoothDisplay;

		// Token: 0x04000764 RID: 1892
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mBalancedDisplay;

		// Token: 0x04000765 RID: 1893
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mHDDisplay;

		// Token: 0x04000766 RID: 1894
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mChangeSchemeInfo;

		// Token: 0x04000767 RID: 1895
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mSaveChangesBtn;

		// Token: 0x04000768 RID: 1896
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Hyperlink mKnowMoreLink;

		// Token: 0x04000769 RID: 1897
		private bool _contentLoaded;

		// Token: 0x0200011E RID: 286
		private class MiscStatsTag
		{
			// Token: 0x0400076A RID: 1898
			internal const string PUBGResolution720 = "pubg_res_720";

			// Token: 0x0400076B RID: 1899
			internal const string PUBGResolution1080 = "pubg_res_1080";

			// Token: 0x0400076C RID: 1900
			internal const string PUBGResolution1440 = "pubg_res_1440";

			// Token: 0x0400076D RID: 1901
			internal const string PUBGGraphicsAuto = "pubg_gfx_auto";

			// Token: 0x0400076E RID: 1902
			internal const string PUBGGraphicsSmooth = "pubg_gfx_smooth";

			// Token: 0x0400076F RID: 1903
			internal const string PUBGGraphicsBalanced = "pubg_gfx_balanced";

			// Token: 0x04000770 RID: 1904
			internal const string PUBGGraphicsHD = "pubg_gfx_hd";

			// Token: 0x04000771 RID: 1905
			internal const string FreeFireOptimizeIngameSettingsOn = "freefire_optimizegame_enabled";

			// Token: 0x04000772 RID: 1906
			internal const string FreeFireOptimizeIngameSettingsOff = "freefire_optimizegame_disabled";

			// Token: 0x04000773 RID: 1907
			internal const string SevenDeadlySinsLandscapeOn = "seven_deadly_sins_landscape_enabled";

			// Token: 0x04000774 RID: 1908
			internal const string SevenDeadlySinsLandscapeOff = "seven_deadly_sins_landscape_disabled";

			// Token: 0x04000775 RID: 1909
			internal const string CODResolution720 = "cod_res_720";

			// Token: 0x04000776 RID: 1910
			internal const string CODResolution1080 = "cod_res_1080";

			// Token: 0x04000777 RID: 1911
			internal const string CODResolution1440 = "cod_res_1440";

			// Token: 0x04000778 RID: 1912
			internal const string CODResolution2160 = "cod_res_2160";

			// Token: 0x04000779 RID: 1913
			internal const string CODGraphicsAuto = "cod_gfx_auto";

			// Token: 0x0400077A RID: 1914
			internal const string CODGraphicsSmooth = "cod_gfx_smooth";

			// Token: 0x0400077B RID: 1915
			internal const string CODGraphicsBalanced = "cod_gfx_balanced";

			// Token: 0x0400077C RID: 1916
			internal const string CODGraphicsHD = "cod_gfx_hd";
		}
	}
}
