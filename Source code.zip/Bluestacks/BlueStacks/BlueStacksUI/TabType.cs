﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200002A RID: 42
	public enum TabType
	{
		// Token: 0x04000152 RID: 338
		AppTab,
		// Token: 0x04000153 RID: 339
		WebTab,
		// Token: 0x04000154 RID: 340
		HomeTab
	}
}
