﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000120 RID: 288
	public class KeymapCanvasWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x17000200 RID: 512
		// (get) Token: 0x06000B5E RID: 2910 RVA: 0x00009122 File Offset: 0x00007322
		// (set) Token: 0x06000B5F RID: 2911 RVA: 0x000443FC File Offset: 0x000425FC
		public static bool sIsDirty
		{
			get
			{
				return KeymapCanvasWindow.IsDirty;
			}
			set
			{
				KeymapCanvasWindow.IsDirty = value;
				if (KMManager.CanvasWindow != null && KMManager.CanvasWindow.SidebarWindow != null)
				{
					KMManager.CanvasWindow.SidebarWindow.mUndoBtn.IsEnabled = KeymapCanvasWindow.IsDirty;
					KMManager.CanvasWindow.SidebarWindow.mSaveBtn.IsEnabled = KeymapCanvasWindow.IsDirty;
				}
			}
		}

		// Token: 0x17000201 RID: 513
		// (get) Token: 0x06000B60 RID: 2912 RVA: 0x00009129 File Offset: 0x00007329
		// (set) Token: 0x06000B61 RID: 2913 RVA: 0x00009131 File Offset: 0x00007331
		internal bool IsInOverlayMode
		{
			get
			{
				return this.mIsInOverlayMode;
			}
			set
			{
				this.mIsInOverlayMode = value;
				base.IsShowGLWindow = value;
			}
		}

		// Token: 0x06000B62 RID: 2914 RVA: 0x00044454 File Offset: 0x00042654
		internal KeymapCanvasWindow(MainWindow window)
		{
			this.ParentWindow = window;
			this.InitializeComponent();
			this.mParentWindowHeight = this.ParentWindow.ActualHeight * MainWindow.sScalingFactor;
			this.mParentWindowWidth = this.ParentWindow.ActualWidth * MainWindow.sScalingFactor;
			this.mParentWindowTop = this.ParentWindow.Top * MainWindow.sScalingFactor;
			this.mParentWindowLeft = this.ParentWindow.Left * MainWindow.sScalingFactor;
		}

		// Token: 0x06000B63 RID: 2915 RVA: 0x00009141 File Offset: 0x00007341
		internal void ClearWindow()
		{
			this.dictCanvasElement.Clear();
			KMManager.listCanvasElement.Clear();
			CanvasElement.dictPoints.Clear();
			this.mCanvas.Children.Clear();
		}

		// Token: 0x06000B64 RID: 2916 RVA: 0x0004455C File Offset: 0x0004275C
		private void Canvas_MouseEnter(object sender, MouseEventArgs e)
		{
			if (KMManager.IsDragging)
			{
				this.isNewElementAdded = true;
				KeymapCanvasWindow.sIsDirty = true;
				List<IMAction> lstAction = KMManager.ClearElement();
				this.AddNewCanvasElement(lstAction, false);
				this.StartMoving(this.mCanvasElement, e.GetPosition(this));
			}
		}

		// Token: 0x06000B65 RID: 2917 RVA: 0x000445A0 File Offset: 0x000427A0
		public void AddNewCanvasElement(List<IMAction> lstAction, bool isTap = false)
		{
			if (lstAction != null)
			{
				this.mCanvasElement = new CanvasElement(this, this.ParentWindow);
				double value = (base.ActualWidth - this.mCanvasElement.ActualWidth) * 100.0 / (base.ActualWidth * 3.0) + (double)(this.mTapXMargin * this.mCurrentTapElementDisplayCol);
				double value2 = (base.ActualHeight - this.mCanvasElement.ActualHeight) * 100.0 / (base.ActualHeight * 3.0) + (double)(this.mTapYMargin * this.mCurrentTapElementDisplayRow);
				foreach (IMAction imaction in lstAction)
				{
					if (isTap)
					{
						imaction.PositionX = Math.Round(value, 2);
						imaction.PositionY = Math.Round(value2, 2);
					}
					this.mCanvasElement.AddAction(imaction);
					this.dictCanvasElement.Add(imaction, this.mCanvasElement);
					if (isTap)
					{
						this.mCanvasElement.ShowTextBox(this.mCanvasElement.dictTextElemets.First<KeyValuePair<Positions, Tuple<string, TextBox, TextBlock, List<IMAction>>>>().Value.Item3);
					}
					if (!imaction.IsChildAction && imaction.Type != KeyActionType.MOBADpad)
					{
						this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Add(imaction);
					}
				}
				this.mCurrentTapElementDisplayCol++;
				if (this.mCurrentTapElementDisplayCol == this.mMaxElementPerRow)
				{
					this.mCurrentTapElementDisplayCol = 0;
					this.mCurrentTapElementDisplayRow++;
				}
				this.mCanvasElement.MouseLeftButtonDown += this.MoveIcon_PreviewMouseDown;
				this.mCanvasElement.mResizeIcon.PreviewMouseDown += this.ResizeIcon_PreviewMouseDown;
				this.mCanvas.Children.Add(this.mCanvasElement);
			}
		}

		// Token: 0x06000B66 RID: 2918 RVA: 0x00044790 File Offset: 0x00042990
		private void ResizeIcon_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			KMManager.CheckAndCreateNewScheme();
			this.mCanvasElement = WpfUtils.FindVisualParent<CanvasElement>(sender as DependencyObject);
			this.mCanvasElement.mResizeIcon.Focus();
			this.startPoint = e.GetPosition(this);
			this.mCanvas.PreviewMouseMove += this.CanvasResizeExistingElement_MouseMove;
			KeymapCanvasWindow.sIsDirty = true;
			e.Handled = true;
			Mouse.Capture(this.mCanvas);
		}

		// Token: 0x06000B67 RID: 2919 RVA: 0x00044804 File Offset: 0x00042A04
		private void CanvasResizeExistingElement_MouseMove(object sender, MouseEventArgs e)
		{
			base.Cursor = Cursors.SizeNWSE;
			Point position = e.GetPosition(this);
			double num = position.X - this.startPoint.X;
			double num2 = position.Y - this.startPoint.Y;
			double num3 = num2;
			if (Math.Abs(num) > Math.Abs(num2))
			{
				num3 = num;
			}
			num3 = Math.Round(num3, 2);
			double num4 = this.mCanvasElement.ActualWidth + num3;
			if (num4 < 40.0)
			{
				num4 = 40.0;
				num3 = num4 - this.mCanvasElement.ActualWidth;
			}
			if (num4 < 70.0)
			{
				double top = this.mCanvasElement.ActualHeight - 20.0;
				this.mCanvasElement.mSkillImage.Margin = new Thickness(-50.0, top, 10.0, 0.0);
			}
			if (this.mCanvasElement.mSkillImage.Visibility == Visibility.Visible)
			{
				this.mCanvasElement.mActionIcon.Visibility = Visibility.Visible;
			}
			double num5 = Canvas.GetTop(this.mCanvasElement);
			double num6 = Canvas.GetLeft(this.mCanvasElement);
			if (double.IsNaN(num5))
			{
				num5 = 0.0;
			}
			if (double.IsNaN(num6))
			{
				num6 = 0.0;
			}
			num5 -= num3 / 2.0;
			num6 -= num3 / 2.0;
			this.mCanvasElement.Width = num4;
			this.mCanvasElement.Height = num4;
			Canvas.SetLeft(this.mCanvasElement, num6);
			Canvas.SetTop(this.mCanvasElement, num5);
			this.mCanvasElement.UpdatePosition(num5, num6);
			this.startPoint = position;
		}

		// Token: 0x06000B68 RID: 2920 RVA: 0x000449C4 File Offset: 0x00042BC4
		internal void ReloadCanvasWindow()
		{
			this.mCurrentTapElementDisplayRow = 0;
			this.mCurrentTapElementDisplayCol = 0;
			if (this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab != null)
			{
				KMManager.LoadIMActions(this.ParentWindow, this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName);
			}
			this.mCanvas.Children.Clear();
			this.Init();
		}

		// Token: 0x06000B69 RID: 2921 RVA: 0x00044A34 File Offset: 0x00042C34
		private void MoveIcon_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			CanvasElement canvasElement = sender as CanvasElement;
			if ((canvasElement.MOBASkillSettingsPopup != null && canvasElement.MOBASkillSettingsPopup.IsOpen) || canvasElement.MOBAOtherSettingsMoreInfoPopup.IsOpen || canvasElement.MOBASkillSettingsMoreInfoPopup.IsOpen)
			{
				e.Handled = true;
				return;
			}
			canvasElement.TopOnClick = Canvas.GetTop(canvasElement);
			canvasElement.LeftOnClick = Canvas.GetLeft(canvasElement);
			Point position = e.GetPosition(this);
			if (!canvasElement.mResizeIcon.IsMouseOver && !canvasElement.mCloseIcon.IsMouseOver)
			{
				if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
				{
					if (canvasElement.ListActionItem.First<IMAction>().Type == KeyActionType.Swipe)
					{
						bool isNewScheme = true;
						using (List<IMAction>.Enumerator enumerator = canvasElement.ListActionItem.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								IMAction originalAction = enumerator.Current;
								this.CreateGameControlCopy(originalAction, e.GetPosition(this), isNewScheme);
								isNewScheme = false;
							}
							goto IL_11F;
						}
					}
					if (!canvasElement.ListActionItem.First<IMAction>().IsChildAction)
					{
						this.CreateGameControlCopy(canvasElement.ListActionItem.First<IMAction>(), e.GetPosition(this), true);
					}
				}
				else
				{
					this.StartMoving(canvasElement, position);
				}
				IL_11F:
				e.Handled = true;
			}
		}

		// Token: 0x06000B6A RID: 2922 RVA: 0x00044B78 File Offset: 0x00042D78
		private void CreateGameControlCopy(IMAction originalAction, Point point, bool isNewScheme = true)
		{
			IMAction imaction = originalAction.DeepCopy<IMAction>();
			imaction.PositionX = originalAction.PositionX + 1.0;
			List<CanvasElement> source = this.AddCanvasElementsForAction(imaction, false);
			if (isNewScheme)
			{
				KMManager.CheckAndCreateNewScheme();
			}
			this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Add(imaction);
			this.StartMoving(source.First<CanvasElement>(), point);
		}

		// Token: 0x06000B6B RID: 2923 RVA: 0x00009172 File Offset: 0x00007372
		private void CanvasMoveExistingElement_MouseMove(object sender, MouseEventArgs e)
		{
			KMManager.CheckAndCreateNewScheme();
			base.Focus();
			this.MoveElement(e.GetPosition(this));
		}

		// Token: 0x06000B6C RID: 2924 RVA: 0x00044BDC File Offset: 0x00042DDC
		internal void StartMoving(CanvasElement element, Point p)
		{
			if (this.mCanvasElement == null || this.mCanvasElement == element)
			{
				if (!element.mSkillImage.IsMouseOver)
				{
					KeymapCanvasWindow.sIsDirty = true;
				}
				this.mCanvasElement = element;
				this.startPoint = p;
				this.mCanvas.PreviewMouseMove -= this.CanvasMoveExistingElement_MouseMove;
				this.mCanvas.PreviewMouseMove += this.CanvasMoveExistingElement_MouseMove;
			}
		}

		// Token: 0x06000B6D RID: 2925 RVA: 0x00044C4C File Offset: 0x00042E4C
		internal void MoveElement(Point p1)
		{
			if (this.mCanvasElement.IsLoaded)
			{
				base.Cursor = Cursors.Hand;
				double num = Canvas.GetTop(this.mCanvasElement);
				double num2 = Canvas.GetLeft(this.mCanvasElement);
				if (double.IsNaN(num))
				{
					num = 0.0;
				}
				if (double.IsNaN(num2))
				{
					num2 = 0.0;
				}
				double num3 = num2 + this.mCanvasElement.ActualWidth / 2.0;
				double num4 = num + this.mCanvasElement.ActualHeight / 2.0;
				num3 += p1.X - this.startPoint.X;
				num4 += p1.Y - this.startPoint.Y;
				num3 = ((num3 < 0.0) ? 0.0 : num3);
				num4 = ((num4 < 0.0) ? 0.0 : num4);
				num3 = ((num3 > this.mCanvas.ActualWidth) ? this.mCanvas.ActualWidth : num3);
				num4 = ((num4 > this.mCanvas.ActualHeight) ? this.mCanvas.ActualHeight : num4);
				num2 = num3 - this.mCanvasElement.ActualWidth / 2.0;
				num = num4 - this.mCanvasElement.ActualHeight / 2.0;
				Canvas.SetLeft(this.mCanvasElement, num2);
				Canvas.SetTop(this.mCanvasElement, num);
				this.mCanvasElement.UpdatePosition(num, num2);
				this.startPoint = p1;
			}
		}

		// Token: 0x06000B6E RID: 2926 RVA: 0x00044DD4 File Offset: 0x00042FD4
		internal void Init()
		{
			IMConfig selectedConfig = this.ParentWindow.SelectedConfig;
			if (((selectedConfig != null) ? selectedConfig.SelectedControlScheme : null) == null)
			{
				return;
			}
			IMConfig selectedConfig2 = this.ParentWindow.SelectedConfig;
			int value = ((selectedConfig2 != null) ? new int?(selectedConfig2.SelectedControlScheme.GetHashCode()) : null).Value;
			if (this.mOldControlSchemeHashCode == value)
			{
				return;
			}
			this.mOldControlSchemeHashCode = value;
			this.ClearWindow();
			IMConfig selectedConfig3 = this.ParentWindow.SelectedConfig;
			bool flag;
			if (selectedConfig3 == null)
			{
				flag = false;
			}
			else
			{
				IMControlScheme selectedControlScheme = selectedConfig3.SelectedControlScheme;
				int? num = (selectedControlScheme != null) ? new int?(selectedControlScheme.GameControls.Count) : null;
				int num2 = 0;
				flag = (num.GetValueOrDefault() > num2 & num != null);
			}
			if (flag)
			{
				foreach (IMAction imaction in this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls)
				{
					if (!this.IsInOverlayMode || imaction.IsVisibleInOverlay)
					{
						this.AddCanvasElementsForAction(imaction, true);
					}
					else if (!imaction.IsVisibleInOverlay)
					{
						List<CanvasElement> canvasElement = CanvasElement.GetCanvasElement(imaction, this, this.ParentWindow);
						foreach (CanvasElement canvasElement2 in canvasElement)
						{
							canvasElement2.Visibility = Visibility.Hidden;
						}
						KMManager.listCanvasElement.Add(canvasElement);
					}
				}
			}
		}

		// Token: 0x06000B6F RID: 2927 RVA: 0x00044F68 File Offset: 0x00043168
		internal void InitLayout()
		{
			MainWindow parentWindow = this.ParentWindow;
			Grid mFrontendGrid = parentWindow.mFrontendGrid;
			Point point = mFrontendGrid.TranslatePoint(default(Point), parentWindow);
			if (this.IsInOverlayMode)
			{
				base.Background = Brushes.Transparent;
				this.mCanvas.Background = Brushes.Transparent;
				this.mCanvas.Margin = default(Thickness);
				if (FeatureManager.Instance.IsCustomUIForDMM)
				{
					base.Opacity = RegistryManager.Instance.TranslucentControlsTransparency;
				}
				else
				{
					this.mCanvas.Opacity = 1.0;
				}
				this.Handle = new WindowInteropHelper(this).EnsureHandle();
				int dwNewLong = 1207959552;
				InteropWindow.SetWindowLong(this.Handle, -16, dwNewLong);
				return;
			}
			IntereopRect fullscreenMonitorSize = WindowWndProcHandler.GetFullscreenMonitorSize(this.ParentWindow.Handle, true);
			double num = (double)fullscreenMonitorSize.Width - (double)this.mSidebarWidth * MainWindow.sScalingFactor;
			if (!this.ParentWindow.EngineInstanceRegistry.IsSidebarVisible)
			{
				num -= this.ParentWindow.mSidebar.Width * MainWindow.sScalingFactor;
			}
			double num2 = this.ParentWindow.GetHeightFromWidth(num, true, false);
			if (num2 > (double)fullscreenMonitorSize.Height)
			{
				num2 = (double)fullscreenMonitorSize.Height;
				num = this.ParentWindow.GetWidthFromHeight(num2, true, false);
			}
			double top;
			if (this.ParentWindow.Top * MainWindow.sScalingFactor + num2 > (double)(fullscreenMonitorSize.Y + fullscreenMonitorSize.Height))
			{
				top = (double)fullscreenMonitorSize.Y + ((double)fullscreenMonitorSize.Height - num2) / 2.0;
			}
			else
			{
				top = this.ParentWindow.Top * MainWindow.sScalingFactor;
			}
			double left;
			if (this.ParentWindow.Left * MainWindow.sScalingFactor + num + (double)this.mSidebarWidth * MainWindow.sScalingFactor > (double)(fullscreenMonitorSize.X + fullscreenMonitorSize.Width))
			{
				left = (double)fullscreenMonitorSize.X + ((double)fullscreenMonitorSize.Width - num - (double)this.mSidebarWidth * MainWindow.sScalingFactor) / 2.0;
			}
			else
			{
				left = this.ParentWindow.Left * MainWindow.sScalingFactor;
			}
			this.ParentWindow.ChangeHeightWidthTopLeft(num, num2, top, left);
			base.Width = this.ParentWindow.ActualWidth;
			base.Height = this.ParentWindow.ActualHeight;
			base.Top = this.ParentWindow.Top;
			base.Left = this.ParentWindow.Left;
			Point point2 = new Point(parentWindow.ActualWidth - (mFrontendGrid.ActualWidth + point.X), parentWindow.ActualHeight - (mFrontendGrid.ActualHeight + point.Y));
			this.mCanvas.Margin = new Thickness(point.X, point.Y, point2.X, point2.Y);
			this.mCanvas.Width = mFrontendGrid.ActualWidth;
			this.mCanvas.Height = mFrontendGrid.ActualHeight;
		}

		// Token: 0x06000B70 RID: 2928 RVA: 0x00045264 File Offset: 0x00043464
		private List<CanvasElement> AddCanvasElementsForAction(IMAction item, bool isLoadingFromFile = false)
		{
			List<CanvasElement> canvasElement = CanvasElement.GetCanvasElement(item, this, this.ParentWindow);
			foreach (CanvasElement canvasElement2 in canvasElement)
			{
				canvasElement2.mIsLoadingfromFile = isLoadingFromFile;
				foreach (IMAction key in canvasElement2.ListActionItem)
				{
					this.dictCanvasElement[key] = canvasElement2;
				}
				if (canvasElement2.Parent == null)
				{
					this.mCanvas.Children.Add(canvasElement2);
					canvasElement2.MouseLeftButtonDown -= this.MoveIcon_PreviewMouseDown;
					canvasElement2.mResizeIcon.PreviewMouseDown -= this.ResizeIcon_PreviewMouseDown;
					canvasElement2.MouseLeftButtonDown += this.MoveIcon_PreviewMouseDown;
					canvasElement2.mResizeIcon.PreviewMouseDown += this.ResizeIcon_PreviewMouseDown;
				}
				if (this.SidebarWindow == null)
				{
					canvasElement2.Visibility = Visibility.Hidden;
				}
			}
			KMManager.listCanvasElement.Add(canvasElement);
			return canvasElement;
		}

		// Token: 0x06000B71 RID: 2929 RVA: 0x00045398 File Offset: 0x00043598
		private void Canvas_MouseUp(object sender, MouseButtonEventArgs e)
		{
			base.Cursor = Cursors.Arrow;
			if (this.mCanvasElement != null)
			{
				UIElement element = this.mCanvasElement;
				int num = this.zIndex;
				this.zIndex = num + 1;
				Panel.SetZIndex(element, num);
				this.mCanvasElement.ShowOtherIcons(true);
				if (this.mCanvasElement.IsMouseDirectlyOver)
				{
					e.Handled = true;
				}
				if (this.isNewElementAdded && this.mCanvasElement.dictTextElemets.Count > 0)
				{
					this.isNewElementAdded = false;
					this.mCanvasElement.ShowTextBox(this.mCanvasElement.dictTextElemets.First<KeyValuePair<Positions, Tuple<string, TextBox, TextBlock, List<IMAction>>>>().Value.Item3);
				}
			}
			this.startPoint = new Point(-1.0, -1.0);
			this.mCanvas.PreviewMouseMove -= this.CanvasMoveExistingElement_MouseMove;
			this.mCanvas.PreviewMouseMove -= this.CanvasResizeExistingElement_MouseMove;
			Mouse.Capture(null);
			this.mCanvasElement = null;
		}

		// Token: 0x06000B72 RID: 2930 RVA: 0x0000918D File Offset: 0x0000738D
		private void KeymapCanvasWindow_Closing(object sender, CancelEventArgs e)
		{
			this.mIsClosing = true;
			this.ParentWindow.Focus();
		}

		// Token: 0x06000B73 RID: 2931 RVA: 0x000091A2 File Offset: 0x000073A2
		private void CustomWindow_Closed(object sender, EventArgs e)
		{
			if (KMManager.dictOverlayWindow.ContainsKey(this.ParentWindow) && KMManager.dictOverlayWindow[this.ParentWindow] == this)
			{
				KMManager.dictOverlayWindow.Remove(this.ParentWindow);
			}
		}

		// Token: 0x06000B74 RID: 2932 RVA: 0x0004549C File Offset: 0x0004369C
		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			InteropWindow.RemoveWindowFromAltTabUI(new WindowInteropHelper(this).Handle);
			if (!this.IsInOverlayMode)
			{
				this.ShowSideBarWindow();
			}
			else
			{
				this.Handle = new WindowInteropHelper(this).Handle;
				int dwNewLong = 1207959552;
				InteropWindow.SetWindowLong(this.Handle, -16, dwNewLong);
				this.ParentWindow.mFrontendHandler.UpdateOverlaySizeStatus();
				this.ParentWindow.LocationChanged += this.ParentWindow_LocationChanged;
				this.ParentWindow.Activated += this.ParentWindow_Activated;
				this.ParentWindow.Deactivated += this.ParentWindow_Deactivated;
				this.UpdateSize();
			}
			this.Init();
		}

		// Token: 0x06000B75 RID: 2933 RVA: 0x000091DA File Offset: 0x000073DA
		private void ParentWindow_Deactivated(object sender, EventArgs e)
		{
			if (!this.mIsClosing && (KMManager.sGuidanceWindow == null || !KMManager.sGuidanceWindow.IsActive || KMManager.sGuidanceWindow.ParentWindow != this.ParentWindow))
			{
				base.Hide();
			}
		}

		// Token: 0x06000B76 RID: 2934 RVA: 0x0000920F File Offset: 0x0000740F
		private void ParentWindow_Activated(object sender, EventArgs e)
		{
			if (!this.mIsClosing)
			{
				base.Show();
			}
		}

		// Token: 0x06000B77 RID: 2935 RVA: 0x0000921F File Offset: 0x0000741F
		private void ParentWindow_LocationChanged(object sender, EventArgs e)
		{
			this.UpdateSize();
		}

		// Token: 0x06000B78 RID: 2936 RVA: 0x00045554 File Offset: 0x00043754
		internal void UpdateSize()
		{
			if (this.ParentWindow.StaticComponents.mLastMappableWindowHandle != IntPtr.Zero && !this.mIsClosing)
			{
				if (this.mIsShowWindow)
				{
					this.mIsShowWindow = false;
					Logger.Debug("KMP KeymapCanvasWindow UpdateSize");
					this.ParentWindow.mFrontendHandler.DeactivateFrontend();
					base.Show();
					return;
				}
				RECT rect = default(RECT);
				InteropWindow.GetWindowRect(this.ParentWindow.StaticComponents.mLastMappableWindowHandle, ref rect);
				int left = rect.Left;
				int top = rect.Top;
				int w = rect.Right - rect.Left;
				int h = rect.Bottom - rect.Top;
				InteropWindow.SetWindowPos(this.Handle, (IntPtr)0, left, top, w, h, 16448U);
				this.ParentWindow.mFrontendHandler.FocusFrontend();
			}
		}

		// Token: 0x06000B79 RID: 2937 RVA: 0x00045638 File Offset: 0x00043838
		private Point GetCorrectCoordinateLocationForAndroid(Point p)
		{
			double x = p.X * 100.0 / this.ParentWindow.Width;
			double y = p.Y * 100.0 / this.ParentWindow.Height;
			return new Point(x, y);
		}

		// Token: 0x06000B7A RID: 2938 RVA: 0x00045688 File Offset: 0x00043888
		private void ShowSideBarWindow()
		{
			if (this.SidebarWindow == null)
			{
				this.SidebarWindow = new AdvancedGameControlWindow(this.ParentWindow);
				this.SidebarWindow.Init(this);
				this.ParentWindow.StaticComponents.mSelectedTabButton.mGuidanceWindowOpen = false;
				this.SidebarWindow.Owner = this;
				this.SidebarWindow.Show();
				this.SidebarWindow.Activate();
			}
		}

		// Token: 0x06000B7B RID: 2939 RVA: 0x000456F4 File Offset: 0x000438F4
		private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (CanvasElement.sFocusedTextBox != null)
			{
				WpfUtils.FindVisualParent<CanvasElement>(CanvasElement.sFocusedTextBox as DependencyObject).TxtBox_LostFocus(CanvasElement.sFocusedTextBox, new RoutedEventArgs());
				return;
			}
			if (double.IsNaN(this.CanvasWindowLeft) && double.IsNaN(this.CanvasWindowTop))
			{
				this.CanvasWindowLeft = base.Left;
				this.CanvasWindowTop = base.Top;
				this.mMousePointForNewTap = Mouse.GetPosition(this.mCanvas);
			}
			KeymapCanvasWindow.sIsDirty = true;
			try
			{
				base.DragMove();
			}
			catch (Exception)
			{
			}
			if (Math.Abs(this.CanvasWindowLeft - base.Left) < 2.0 && Math.Abs(this.CanvasWindowTop - base.Top) < 2.0)
			{
				if (KMManager.sIsInScriptEditingMode && this.mIsExtraSettingsPopupOpened)
				{
					return;
				}
				IMAction item = new Tap
				{
					Type = KeyActionType.Tap
				};
				if (this.ParentWindow.SelectedConfig.ControlSchemes.Count == 0 && CanvasElement.sFocusedTextBox != null)
				{
					WpfUtils.FindVisualParent<CanvasElement>(CanvasElement.sFocusedTextBox as DependencyObject).TxtBox_LostFocus(CanvasElement.sFocusedTextBox, new RoutedEventArgs());
				}
				else
				{
					if (this.ParentWindow.SelectedConfig.ControlSchemes.Count == 0)
					{
						KMManager.AddNewControlSchemeAndSelect(this.ParentWindow, null, false);
					}
					else if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
					{
						KMManager.CheckAndCreateNewScheme();
					}
					this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Add(item);
					List<CanvasElement> source = this.AddCanvasElementsForAction(item, false);
					source.First<CanvasElement>().SetMousePoint(this.mMousePointForNewTap);
					source.First<CanvasElement>().IsRemoveIfEmpty = true;
					source.First<CanvasElement>().ShowTextBox(source.First<CanvasElement>().dictTextElemets.First<KeyValuePair<Positions, Tuple<string, TextBox, TextBlock, List<IMAction>>>>().Value.Item3);
				}
			}
			this.CanvasWindowLeft = double.NaN;
			this.CanvasWindowTop = double.NaN;
		}

		// Token: 0x06000B7C RID: 2940 RVA: 0x000458F4 File Offset: 0x00043AF4
		private void CustomWindow_MouseDown(object sender, MouseButtonEventArgs e)
		{
			this.mMousePointForNewTap = Mouse.GetPosition(this.mCanvas);
			this.CanvasWindowLeft = base.Left;
			this.CanvasWindowTop = base.Top;
			try
			{
				base.DragMove();
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000B7D RID: 2941 RVA: 0x00009227 File Offset: 0x00007427
		private void CustomWindow_LocationChanged(object sender, EventArgs e)
		{
			if (!this.IsInOverlayMode)
			{
				this.ParentWindow.Top = base.Top;
				this.ParentWindow.Left = base.Left;
			}
		}

		// Token: 0x06000B7E RID: 2942 RVA: 0x00045948 File Offset: 0x00043B48
		private void CustomWindow_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			foreach (object obj in this.mCanvas.Children)
			{
				(obj as CanvasElement).SetElementLayout(false);
			}
		}

		// Token: 0x06000B7F RID: 2943 RVA: 0x000459A4 File Offset: 0x00043BA4
		private void MCanvas_PreviewMouseMove(object sender, MouseEventArgs e)
		{
			ToolTip toolTip = new ToolTip();
			if (KMManager.sIsInScriptEditingMode)
			{
				Point correctCoordinateLocationForAndroid = this.GetCorrectCoordinateLocationForAndroid(Mouse.GetPosition(this.mCanvas));
				if (toolTip.IsOpen)
				{
					toolTip.IsOpen = false;
				}
				toolTip.Content = string.Format(" X: {0} Y: {1}", correctCoordinateLocationForAndroid.X, correctCoordinateLocationForAndroid.Y);
				toolTip.StaysOpen = true;
				toolTip.Placement = PlacementMode.Mouse;
				toolTip.IsOpen = true;
			}
		}

		// Token: 0x06000B80 RID: 2944 RVA: 0x00045A1C File Offset: 0x00043C1C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/keymapcanvaswindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000B81 RID: 2945 RVA: 0x00045A4C File Offset: 0x00043C4C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((KeymapCanvasWindow)target).Closing += this.KeymapCanvasWindow_Closing;
				((KeymapCanvasWindow)target).Closed += this.CustomWindow_Closed;
				((KeymapCanvasWindow)target).Loaded += this.Window_Loaded;
				((KeymapCanvasWindow)target).LocationChanged += this.CustomWindow_LocationChanged;
				((KeymapCanvasWindow)target).MouseLeftButtonDown += this.CustomWindow_MouseDown;
				((KeymapCanvasWindow)target).SizeChanged += this.CustomWindow_SizeChanged;
				return;
			case 2:
				((Grid)target).MouseLeftButtonDown += this.Canvas_MouseDown;
				return;
			case 3:
				this.mCanvas = (Canvas)target;
				this.mCanvas.MouseEnter += this.Canvas_MouseEnter;
				this.mCanvas.PreviewMouseUp += this.Canvas_MouseUp;
				this.mCanvas.MouseDown += this.CustomWindow_MouseDown;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400077F RID: 1919
		private int mCurrentTapElementDisplayRow;

		// Token: 0x04000780 RID: 1920
		private int mCurrentTapElementDisplayCol;

		// Token: 0x04000781 RID: 1921
		private int mTapYMargin = 5;

		// Token: 0x04000782 RID: 1922
		private int mTapXMargin = 5;

		// Token: 0x04000783 RID: 1923
		private int mMaxElementPerRow = 10;

		// Token: 0x04000784 RID: 1924
		internal bool mIsShowWindow = true;

		// Token: 0x04000785 RID: 1925
		private bool isNewElementAdded;

		// Token: 0x04000786 RID: 1926
		private int mSidebarWidth = 260;

		// Token: 0x04000787 RID: 1927
		private MainWindow ParentWindow;

		// Token: 0x04000788 RID: 1928
		internal AdvancedGameControlWindow SidebarWindow;

		// Token: 0x04000789 RID: 1929
		private Point startPoint = new Point(-1.0, -1.0);

		// Token: 0x0400078A RID: 1930
		private int zIndex;

		// Token: 0x0400078B RID: 1931
		internal CanvasElement mCanvasElement;

		// Token: 0x0400078C RID: 1932
		internal double mParentWindowHeight;

		// Token: 0x0400078D RID: 1933
		internal double mParentWindowWidth;

		// Token: 0x0400078E RID: 1934
		internal double mParentWindowTop;

		// Token: 0x0400078F RID: 1935
		internal double mParentWindowLeft;

		// Token: 0x04000790 RID: 1936
		internal Dictionary<IMAction, CanvasElement> dictCanvasElement = new Dictionary<IMAction, CanvasElement>();

		// Token: 0x04000791 RID: 1937
		internal static bool IsDirty;

		// Token: 0x04000792 RID: 1938
		internal static bool sWasMaximized;

		// Token: 0x04000793 RID: 1939
		internal bool mIsExtraSettingsPopupOpened;

		// Token: 0x04000794 RID: 1940
		private int mOldControlSchemeHashCode;

		// Token: 0x04000795 RID: 1941
		private bool mIsInOverlayMode;

		// Token: 0x04000796 RID: 1942
		internal bool mIsClosing;

		// Token: 0x04000797 RID: 1943
		internal double SidebarWindowLeft = -1.0;

		// Token: 0x04000798 RID: 1944
		internal double SidebarWindowTop = -1.0;

		// Token: 0x04000799 RID: 1945
		internal double CanvasWindowLeft = -1.0;

		// Token: 0x0400079A RID: 1946
		internal double CanvasWindowTop = -1.0;

		// Token: 0x0400079B RID: 1947
		private Point mMousePointForNewTap;

		// Token: 0x0400079C RID: 1948
		private IntPtr Handle;

		// Token: 0x0400079D RID: 1949
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Canvas mCanvas;

		// Token: 0x0400079E RID: 1950
		private bool _contentLoaded;
	}
}
