﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000104 RID: 260
	public class SpeedUpBlueStacks : UserControl, IComponentConnector
	{
		// Token: 0x06000A1F RID: 2591 RVA: 0x00008721 File Offset: 0x00006921
		public SpeedUpBlueStacks()
		{
			this.InitializeComponent();
			this.SetUrl();
			this.SetContent();
		}

		// Token: 0x06000A20 RID: 2592 RVA: 0x0003A8D0 File Offset: 0x00038AD0
		private void SetUrl()
		{
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				this.mEnableVt.mHyperLink.NavigateUri = new Uri("http://help.dmm.com/-/detail/=/qid=45997/");
				this.mUpgradeComputer.mHyperLink.NavigateUri = new Uri("http://help.dmm.com/-/detail/=/qid=45997/");
				this.mConfigureAntivirus.mHyperLink.NavigateUri = new Uri("http://help.dmm.com/-/detail/=/qid=45997/");
				this.mDiasbleHyperV.mHyperLink.NavigateUri = new Uri("http://help.dmm.com/-/detail/=/qid=45997/");
				this.mPowerPlan.mHyperLink.NavigateUri = new Uri("http://help.dmm.com/-/detail/=/qid=45997/");
				return;
			}
			string str = WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
			{
				WebHelper.GetServerHost(),
				"help_articles"
			})) + "&article=";
			this.mEnableVt.mHyperLink.NavigateUri = new Uri(str + "enable_virtualization");
			this.mUpgradeComputer.mHyperLink.NavigateUri = new Uri(str + "bs3_nougat_min_requirements");
			this.mConfigureAntivirus.mHyperLink.NavigateUri = new Uri(str + "disable_antivirus");
			this.mDiasbleHyperV.mHyperLink.NavigateUri = new Uri(str + "disable_hypervisor");
			this.mPowerPlan.mHyperLink.NavigateUri = new Uri(str + "change_powerplan");
		}

		// Token: 0x06000A21 RID: 2593 RVA: 0x0003AA44 File Offset: 0x00038C44
		private void SetContent()
		{
			BlueStacksUIBinding.Bind(this.mEnableVt.mTitleText, "STRING_ENABLE_VIRT", "");
			BlueStacksUIBinding.Bind(this.mEnableVt.mBodyText, "STRING_ENABLE_VIRT_BODY", "");
			this.mEnableVt.mHyperLink.Inlines.Clear();
			this.mEnableVt.mHyperLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_ENABLE_VIRT_HYPERLINK"));
			this.mEnableVt.mImage.ImageName = "virtualization";
			BlueStacksUIBinding.Bind(this.mDiasbleHyperV.mTitleText, "STRING_DISABLE_HYPERV", "");
			BlueStacksUIBinding.Bind(this.mDiasbleHyperV.mBodyText, "STRING_DISABLE_HYPERV_BODY", "");
			this.mDiasbleHyperV.mHyperLink.Inlines.Clear();
			this.mDiasbleHyperV.mHyperLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_DISABLE_HYPERV_HYPERLINK"));
			this.mDiasbleHyperV.mImage.ImageName = "hypervisor";
			BlueStacksUIBinding.Bind(this.mConfigureAntivirus.mTitleText, "STRING_CONFIGURE_ANTIVIRUS", "");
			BlueStacksUIBinding.Bind(this.mConfigureAntivirus.mBodyText, "STRING_CONFIGURE_ANTIVIRUS_BODY", "");
			this.mConfigureAntivirus.mHyperLink.Inlines.Clear();
			this.mConfigureAntivirus.mHyperLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_CONFIGURE_ANTIVIRUS_HYPERLINK"));
			this.mConfigureAntivirus.mImage.ImageName = "antivirus";
			BlueStacksUIBinding.Bind(this.mPowerPlan.mTitleText, "STRING_POWER_PLAN", "");
			BlueStacksUIBinding.Bind(this.mPowerPlan.mBodyText, "STRING_POWER_PLAN_BODY", "");
			this.mPowerPlan.mHyperLink.Inlines.Clear();
			this.mPowerPlan.mHyperLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_POWER_PLAN_HYPERLINK"));
			this.mPowerPlan.mImage.ImageName = "powerplan";
			BlueStacksUIBinding.Bind(this.mUpgradeComputer.mTitleText, "STRING_UPGRADE_SYSTEM", "");
			BlueStacksUIBinding.Bind(this.mUpgradeComputer.mBodyText, "STRING_UPGRADE_SYSTEM_BODY", "");
			this.mUpgradeComputer.mHyperLink.Inlines.Clear();
			this.mUpgradeComputer.mHyperLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_UPGRADE_SYSTEM_HYPERLINK"));
			this.mUpgradeComputer.mImage.ImageName = "upgrade";
		}

		// Token: 0x06000A22 RID: 2594 RVA: 0x0000873B File Offset: 0x0000693B
		private void CloseBtn_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked close button speedUpBluestacks");
			BlueStacksUIUtils.CloseContainerWindow(this);
		}

		// Token: 0x06000A23 RID: 2595 RVA: 0x0003ACC4 File Offset: 0x00038EC4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/speedupbluestacks.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000A24 RID: 2596 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000A25 RID: 2597 RVA: 0x0003ACF4 File Offset: 0x00038EF4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.CloseBtn = (CustomPictureBox)target;
				this.CloseBtn.PreviewMouseLeftButtonUp += this.CloseBtn_PreviewMouseLeftButtonUp;
				return;
			case 2:
				this.mEnableVt = (SpeedUpBluestacksUserControl)target;
				return;
			case 3:
				this.mConfigureAntivirus = (SpeedUpBluestacksUserControl)target;
				return;
			case 4:
				this.mDiasbleHyperV = (SpeedUpBluestacksUserControl)target;
				return;
			case 5:
				this.mPowerPlan = (SpeedUpBluestacksUserControl)target;
				return;
			case 6:
				this.mUpgradeComputer = (SpeedUpBluestacksUserControl)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000669 RID: 1641
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox CloseBtn;

		// Token: 0x0400066A RID: 1642
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal SpeedUpBluestacksUserControl mEnableVt;

		// Token: 0x0400066B RID: 1643
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal SpeedUpBluestacksUserControl mConfigureAntivirus;

		// Token: 0x0400066C RID: 1644
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal SpeedUpBluestacksUserControl mDiasbleHyperV;

		// Token: 0x0400066D RID: 1645
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal SpeedUpBluestacksUserControl mPowerPlan;

		// Token: 0x0400066E RID: 1646
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal SpeedUpBluestacksUserControl mUpgradeComputer;

		// Token: 0x0400066F RID: 1647
		private bool _contentLoaded;
	}
}
