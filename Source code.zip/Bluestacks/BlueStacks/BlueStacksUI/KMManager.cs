﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Interop;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000123 RID: 291
	internal static class KMManager
	{
		// Token: 0x17000203 RID: 515
		// (get) Token: 0x06000BAB RID: 2987 RVA: 0x00009306 File Offset: 0x00007506
		public static bool IsDragging
		{
			get
			{
				return KMManager.sDragCanvasElement != null;
			}
		}

		// Token: 0x06000BAC RID: 2988 RVA: 0x0004839C File Offset: 0x0004659C
		internal static void GetCurrentParserVersion(MainWindow window)
		{
			try
			{
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					try
					{
						JObject jobject = JObject.Parse(window.mFrontendHandler.SendFrontendRequest("getkeymappingparserversion", null));
						if (jobject["success"].ToObject<bool>())
						{
							KMManager.ParserVersion = jobject["parserversion"].ToString();
						}
					}
					catch (Exception ex2)
					{
						Logger.Error("Failed to get/parse result for getkeymappingparserversion");
						Logger.Error(ex2.ToString());
					}
				});
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in KMManager init: " + ex.ToString());
			}
		}

		// Token: 0x06000BAD RID: 2989 RVA: 0x000483F4 File Offset: 0x000465F4
		internal static void CheckAndCreateNewScheme()
		{
			if (BlueStacksUIUtils.LastActivatedWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				bool isBookMarked = BlueStacksUIUtils.LastActivatedWindow.SelectedConfig.SelectedControlScheme.IsBookMarked;
				IMControlScheme imcontrolScheme = (from scheme in BlueStacksUIUtils.LastActivatedWindow.OriginalLoadedConfig.ControlSchemes
				where scheme.BuiltIn && string.Equals(scheme.Name, BlueStacksUIUtils.LastActivatedWindow.SelectedConfig.SelectedControlScheme.Name, StringComparison.InvariantCulture)
				select scheme).FirstOrDefault<IMControlScheme>();
				if (imcontrolScheme != null)
				{
					KMManager.AddNewControlSchemeAndSelectImap(BlueStacksUIUtils.LastActivatedWindow, imcontrolScheme);
					BlueStacksUIUtils.LastActivatedWindow.SelectedConfig.SelectedControlScheme.IsBookMarked = isBookMarked;
				}
			}
		}

		// Token: 0x06000BAE RID: 2990 RVA: 0x00048488 File Offset: 0x00046688
		internal static string GetInputmapperFile(string packageName = "")
		{
			string result = string.Empty;
			try
			{
				if (File.Exists(KMManager.GetInputmapperUserFilePath(packageName)))
				{
					result = KMManager.GetInputmapperUserFilePath(packageName);
				}
				else if (File.Exists(KMManager.GetInputmapperDefaultFilePath(packageName)))
				{
					result = KMManager.GetInputmapperDefaultFilePath(packageName);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Excpetion in GetInputMapper: " + ex.ToString());
			}
			return result;
		}

		// Token: 0x06000BAF RID: 2991 RVA: 0x000484F0 File Offset: 0x000466F0
		internal static bool CheckGamepadCompatible(string packageName)
		{
			try
			{
				if (KMManager.dictGamepadEligibility.ContainsKey(packageName))
				{
					return KMManager.dictGamepadEligibility[packageName];
				}
				string inputmapperFile = KMManager.GetInputmapperFile(packageName);
				bool flag = false;
				if (!string.IsNullOrEmpty(inputmapperFile))
				{
					string text = "";
					using (Mutex mutex = new Mutex(false, "BlueStacks_CfgAccess"))
					{
						if (mutex.WaitOne())
						{
							try
							{
								text = File.ReadAllText(inputmapperFile);
								flag = true;
							}
							catch (Exception arg)
							{
								Logger.Error(string.Format("Failed to read cfg file... filepath: {0} Err : {1}", inputmapperFile, arg));
							}
							finally
							{
								mutex.ReleaseMutex();
							}
						}
					}
					if (flag)
					{
						foreach (string value in Constants.ImapGamepadEvents)
						{
							if (text.Contains(value))
							{
								KMManager.dictGamepadEligibility[packageName] = true;
								return true;
							}
						}
					}
				}
				KMManager.dictGamepadEligibility[packageName] = false;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in CheckGamepadCompatible: " + ex.ToString());
			}
			return false;
		}

		// Token: 0x06000BB0 RID: 2992 RVA: 0x00009310 File Offset: 0x00007510
		internal static string GetInputmapperDefaultFilePath(string packageName = "")
		{
			if (string.IsNullOrEmpty(packageName))
			{
				packageName = KMManager.sPackageName;
			}
			return Path.Combine(RegistryStrings.InputMapperFolder, packageName + ".cfg");
		}

		// Token: 0x06000BB1 RID: 2993 RVA: 0x00048624 File Offset: 0x00046824
		internal static void UpdateUIForGamepadEvent(string text, bool isDown)
		{
			if (text.Contains("GamepadStart", StringComparison.InvariantCultureIgnoreCase) || text.Contains("GamepadBack", StringComparison.InvariantCultureIgnoreCase))
			{
				return;
			}
			string str = string.Empty;
			string value = ".";
			if (text.Contains(value))
			{
				str = text.Substring(text.IndexOf(value, StringComparison.InvariantCultureIgnoreCase));
				text = text.Substring(0, text.IndexOf(value, StringComparison.InvariantCultureIgnoreCase));
			}
			if (KMManager.CanvasWindow != null && KMManager.CanvasWindow.IsVisible && KMManager.sGamepadDualTextbox != null)
			{
				if (string.Equals(KMManager.sGamepadDualTextbox.ActionItemProperty, "GamepadStick", StringComparison.InvariantCultureIgnoreCase))
				{
					text = KMManager.CheckForAnalogEvent(text);
				}
				if (!string.IsNullOrEmpty(text))
				{
					if (KMManager.sGamepadDualTextbox.LstActionItem[0].Type != KeyActionType.Tap && KMManager.sGamepadDualTextbox.LstActionItem[0].Type != KeyActionType.TapRepeat && KMManager.sGamepadDualTextbox.LstActionItem[0].Type != KeyActionType.Script)
					{
						KMManager.sGamepadDualTextbox.mKeyTextBox.Text = LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + text);
						KMManager.sGamepadDualTextbox.Setvalue(text + str);
						KMManager.sGamepadDualTextbox.mKeyTextBox.ToolTip = KMManager.sGamepadDualTextbox.mKeyTextBox.Text;
						return;
					}
					KMManager.CheckItemToAddInList(text, isDown);
					if (KMManager.pressedGamepadKeyList.Count > 2)
					{
						KMManager.pressedGamepadKeyList.Clear();
						KMManager.sGamepadDualTextbox.mKeyTextBox.Text = string.Empty;
						KMManager.sGamepadDualTextbox.Setvalue(string.Empty);
						KMManager.sGamepadDualTextbox.mKeyTextBox.ToolTip = string.Empty;
						return;
					}
					if (KMManager.pressedGamepadKeyList.Count == 2)
					{
						string str2 = IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(0)) + " + " + IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(1));
						KMManager.sGamepadDualTextbox.mKeyTextBox.Text = LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(0))) + " + " + LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(1)));
						KMManager.sGamepadDualTextbox.Setvalue(str2 + str);
						KMManager.sGamepadDualTextbox.mKeyTextBox.ToolTip = KMManager.sGamepadDualTextbox.mKeyTextBox.Text;
						KMManager.pressedGamepadKeyList.Clear();
						return;
					}
					if (KMManager.pressedGamepadKeyList.Count == 1)
					{
						string stringForUI = IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(0));
						KMManager.sGamepadDualTextbox.mKeyTextBox.Text = LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + stringForUI);
						KMManager.sGamepadDualTextbox.Setvalue(stringForUI + str);
						KMManager.sGamepadDualTextbox.mKeyTextBox.ToolTip = KMManager.sGamepadDualTextbox.mKeyTextBox.Text;
						return;
					}
				}
			}
			else if (KMManager.sGuidanceWindow != null && KMManager.sGuidanceWindow.IsVisible && KMManager.CurrentIMapTextBox != null && KMManager.CurrentIMapTextBox.IMActionItems != null && KMManager.CurrentIMapTextBox.IMActionItems.Any<IMActionItem>())
			{
				KMManager.CheckAndCreateNewScheme();
				GuidanceWindow.sIsDirty = true;
				if (KMManager.CurrentIMapTextBox.IMActionItems != null)
				{
					if (KMManager.CurrentIMapTextBox.IMActionItems.Any((IMActionItem item) => string.Equals(item.ActionItem, "GamepadStick", StringComparison.InvariantCultureIgnoreCase)))
					{
						text = KMManager.CheckForAnalogEvent(text);
					}
				}
				if (!string.IsNullOrEmpty(text))
				{
					if (KMManager.CurrentIMapTextBox.ActionType == KeyActionType.Tap || KMManager.CurrentIMapTextBox.ActionType == KeyActionType.TapRepeat || KMManager.CurrentIMapTextBox.ActionType == KeyActionType.Script)
					{
						KMManager.CheckItemToAddInList(text, isDown);
						if (KMManager.pressedGamepadKeyList.Count > 2)
						{
							KMManager.pressedGamepadKeyList.Clear();
							KMManager.CurrentIMapTextBox.Tag = string.Empty;
							KMManager.CurrentIMapTextBox.Text = string.Empty;
							using (IEnumerator<IMActionItem> enumerator = KMManager.CurrentIMapTextBox.IMActionItems.GetEnumerator())
							{
								while (enumerator.MoveNext())
								{
									IMActionItem item5 = enumerator.Current;
									IMapTextBox.Setvalue(item5, string.Empty);
								}
								return;
							}
						}
						if (KMManager.pressedGamepadKeyList.Count == 2)
						{
							string str3 = IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(0)) + " + " + IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(1));
							KMManager.CurrentIMapTextBox.Tag = str3 + str;
							KMManager.CurrentIMapTextBox.Text = LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(0))) + " + " + LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(1)));
							foreach (IMActionItem item2 in KMManager.CurrentIMapTextBox.IMActionItems)
							{
								IMapTextBox.Setvalue(item2, KMManager.CurrentIMapTextBox.Tag.ToString());
							}
							KMManager.pressedGamepadKeyList.Clear();
							return;
						}
						if (KMManager.pressedGamepadKeyList.Count != 1)
						{
							return;
						}
						string stringForUI2 = IMAPKeys.GetStringForUI(KMManager.pressedGamepadKeyList.Keys.ElementAt(0));
						KMManager.CurrentIMapTextBox.Tag = stringForUI2 + str;
						KMManager.CurrentIMapTextBox.Text = LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + stringForUI2);
						using (IEnumerator<IMActionItem> enumerator = KMManager.CurrentIMapTextBox.IMActionItems.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								IMActionItem item3 = enumerator.Current;
								IMapTextBox.Setvalue(item3, KMManager.CurrentIMapTextBox.Tag.ToString());
							}
							return;
						}
					}
					KMManager.CurrentIMapTextBox.Tag = text + str;
					KMManager.CurrentIMapTextBox.Text = LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(text));
					foreach (IMActionItem item4 in KMManager.CurrentIMapTextBox.IMActionItems)
					{
						IMapTextBox.Setvalue(item4, KMManager.CurrentIMapTextBox.Tag.ToString());
					}
				}
			}
		}

		// Token: 0x06000BB2 RID: 2994 RVA: 0x00048CA8 File Offset: 0x00046EA8
		private static void CheckItemToAddInList(string text, bool isDown)
		{
			if (KMManager.pressedGamepadKeyList.ContainsKey(text) && KMManager.pressedGamepadKeyList[text] && !isDown)
			{
				KMManager.pressedGamepadKeyList.Remove(text);
			}
			if (!KMManager.pressedGamepadKeyList.ContainsKey(text) && isDown)
			{
				KMManager.pressedGamepadKeyList.Add(text, isDown);
			}
		}

		// Token: 0x06000BB3 RID: 2995 RVA: 0x00048CFC File Offset: 0x00046EFC
		private static string CheckForAnalogEvent(string text)
		{
			string result = string.Empty;
			if (string.Equals(text, "GamepadLStickUp", StringComparison.InvariantCultureIgnoreCase) || string.Equals(text, "GamepadLStickDown", StringComparison.InvariantCultureIgnoreCase) || string.Equals(text, "GamepadLStickLeft", StringComparison.InvariantCultureIgnoreCase) || string.Equals(text, "GamepadLStickRight", StringComparison.InvariantCultureIgnoreCase))
			{
				result = "LeftStick";
			}
			else if (string.Equals(text, "GamepadRStickUp", StringComparison.InvariantCultureIgnoreCase) || string.Equals(text, "GamepadRStickDown", StringComparison.InvariantCultureIgnoreCase) || string.Equals(text, "GamepadRStickLeft", StringComparison.InvariantCultureIgnoreCase) || string.Equals(text, "GamepadRStickRight", StringComparison.InvariantCultureIgnoreCase))
			{
				result = "RightStick";
			}
			return result;
		}

		// Token: 0x06000BB4 RID: 2996 RVA: 0x00009336 File Offset: 0x00007536
		internal static string GetInputmapperUserFilePath(string packageName = "")
		{
			if (string.IsNullOrEmpty(packageName))
			{
				packageName = KMManager.sPackageName;
			}
			return Path.Combine(Path.Combine(RegistryStrings.InputMapperFolder, "UserFiles"), packageName + ".cfg");
		}

		// Token: 0x06000BB5 RID: 2997 RVA: 0x00009366 File Offset: 0x00007566
		internal static bool KeyMappingFilesAvailable(string packageName)
		{
			return !string.IsNullOrEmpty(KMManager.GetInputmapperFile(packageName));
		}

		// Token: 0x06000BB6 RID: 2998 RVA: 0x00048D90 File Offset: 0x00046F90
		internal static bool IsSelectedSchemeSmart(MainWindow mainWindow)
		{
			if (mainWindow == null)
			{
				return false;
			}
			IMConfig selectedConfig = mainWindow.SelectedConfig;
			int? num;
			if (selectedConfig == null)
			{
				num = null;
			}
			else
			{
				IMControlScheme selectedControlScheme = selectedConfig.SelectedControlScheme;
				if (selectedControlScheme == null)
				{
					num = null;
				}
				else
				{
					List<JObject> images = selectedControlScheme.Images;
					num = ((images != null) ? new int?(images.Count) : null);
				}
			}
			int? num2 = num;
			int num3 = 0;
			return num2.GetValueOrDefault() > num3 & num2 != null;
		}

		// Token: 0x06000BB7 RID: 2999 RVA: 0x00048E00 File Offset: 0x00047000
		internal static bool IsShowShootingModeTooltip(MainWindow mainWindow)
		{
			bool result = false;
			foreach (IMAction imaction in mainWindow.SelectedConfig.SelectedControlScheme.GameControls)
			{
				Pan pan = imaction as Pan;
				if (pan != null)
				{
					if ((pan.Tweaks & 32) != 0)
					{
						return false;
					}
					result = true;
				}
			}
			return result;
		}

		// Token: 0x06000BB8 RID: 3000 RVA: 0x00048E74 File Offset: 0x00047074
		internal static void HandleInputMapperWindow(MainWindow mainWindow, string isSelectedTab = "")
		{
			if (FeatureManager.Instance.IsCustomUIForNCSoft && mainWindow.mDimOverlay != null && mainWindow.mDimOverlay.Control != null && mainWindow.mDimOverlay.Control.GetType() == mainWindow.ScreenLockInstance.GetType() && mainWindow.ScreenLockInstance.IsVisible)
			{
				return;
			}
			if (mainWindow.mTopBar.mAppTabButtons.SelectedTab.mTabType != TabType.AppTab)
			{
				return;
			}
			KeymapCanvasWindow canvasWindow = KMManager.CanvasWindow;
			if (((canvasWindow != null) ? canvasWindow.SidebarWindow : null) != null)
			{
				return;
			}
			if (mainWindow.SelectedConfig != null && mainWindow.SelectedConfig.SelectedControlScheme != null)
			{
				if (mainWindow.SelectedConfig.ControlSchemes.Any((IMControlScheme scheme) => !string.IsNullOrEmpty(scheme.Name)))
				{
					mainWindow.StaticComponents.mSelectedTabButton.mGuidanceWindowOpen = true;
					mainWindow.mSidebar.UpdateImage("sidebar_gameguide", "sidebar_gameguide_active");
					KMManager.sGuidanceWindow = new GuidanceWindow(mainWindow);
					KMManager.sGuidanceWindow.GuidanceWindowTabSelected(isSelectedTab);
					KMManager.sGuidanceWindow.Show();
					mainWindow.Focus();
					return;
				}
			}
			if (string.Equals(isSelectedTab, "gamepad", StringComparison.InvariantCultureIgnoreCase))
			{
				KMManager.ShowAdvancedSettings(mainWindow);
			}
		}

		// Token: 0x06000BB9 RID: 3001 RVA: 0x00048FA4 File Offset: 0x000471A4
		internal static void ResizeMainWindow(MainWindow window)
		{
			Screen screen = Screen.FromHandle(new WindowInteropHelper(window).Handle);
			double sScalingFactor = MainWindow.sScalingFactor;
			Rectangle rectangle = new Rectangle((int)((double)screen.WorkingArea.X / sScalingFactor), (int)((double)screen.WorkingArea.Y / sScalingFactor), (int)((double)screen.WorkingArea.Width / sScalingFactor), (int)((double)screen.WorkingArea.Height / sScalingFactor));
			if (window.Top + window.ActualHeight > (double)rectangle.Height)
			{
				window.Top = ((double)rectangle.Height - window.ActualHeight) / 2.0;
			}
			if (window.Left < 0.0 || window.Left + window.ActualWidth > (double)rectangle.Width)
			{
				window.Left = ((double)rectangle.Width - window.ActualWidth) / 2.0;
			}
		}

		// Token: 0x06000BBA RID: 3002 RVA: 0x00049094 File Offset: 0x00047294
		internal static void ShowAdvancedSettings(MainWindow mainWindow)
		{
			if (mainWindow.WindowState != WindowState.Normal)
			{
				mainWindow.RestoreWindows(false);
				KeymapCanvasWindow.sWasMaximized = true;
			}
			KMManager.CloseWindows();
			if (KMManager.sGuidanceWindow == null)
			{
				KMManager.CanvasWindow = new KeymapCanvasWindow(mainWindow)
				{
					Owner = mainWindow
				};
				KMManager.CanvasWindow.InitLayout();
				KMManager.ShowOverlayWindow(mainWindow, false, false);
				KMManager.CanvasWindow.ShowDialog();
				if (RegistryManager.Instance.ShowKeyControlsOverlay)
				{
					KMManager.ShowOverlayWindow(mainWindow, true, false);
				}
			}
		}

		// Token: 0x06000BBB RID: 3003 RVA: 0x00049108 File Offset: 0x00047308
		internal static void ShowOverlayWindow(MainWindow mainWindow, bool isShow, bool isreload = false)
		{
			if (isShow && RegistryManager.Instance.TranslucentControlsTransparency != 0.0)
			{
				if (mainWindow != null && !KMManager.dictOverlayWindow.ContainsKey(mainWindow) && mainWindow != null)
				{
					TopBar mTopBar = mainWindow.mTopBar;
					bool flag;
					if (mTopBar == null)
					{
						flag = (null != null);
					}
					else
					{
						AppTabButtons mAppTabButtons = mTopBar.mAppTabButtons;
						if (mAppTabButtons == null)
						{
							flag = (null != null);
						}
						else
						{
							AppTabButton selectedTab = mAppTabButtons.SelectedTab;
							flag = (((selectedTab != null) ? selectedTab.PackageName : null) != null);
						}
					}
					if (flag && mainWindow != null)
					{
						TopBar mTopBar2 = mainWindow.mTopBar;
						TabType? tabType;
						if (mTopBar2 == null)
						{
							tabType = null;
						}
						else
						{
							AppTabButtons mAppTabButtons2 = mTopBar2.mAppTabButtons;
							tabType = ((mAppTabButtons2 != null) ? new TabType?(mAppTabButtons2.SelectedTab.mTabType) : null);
						}
						TabType? tabType2 = tabType;
						TabType tabType3 = TabType.AppTab;
						if (tabType2.GetValueOrDefault() == tabType3 & tabType2 != null)
						{
							if (FeatureManager.Instance.IsCustomUIForNCSoft && mainWindow.mDimOverlay != null && mainWindow.mDimOverlay.Control != null && mainWindow.mDimOverlay.Control.GetType() == mainWindow.ScreenLockInstance.GetType() && mainWindow.ScreenLockInstance.IsVisible)
							{
								return;
							}
							bool flag2 = KMManager.sIsInScriptEditingMode;
							KeymapCanvasWindow keymapCanvasWindow = new KeymapCanvasWindow(mainWindow);
							KMManager.dictOverlayWindow[mainWindow] = keymapCanvasWindow;
							keymapCanvasWindow.IsInOverlayMode = true;
							keymapCanvasWindow.Owner = mainWindow;
							keymapCanvasWindow.InitLayout();
							if (mainWindow.mFrontendHandler.mFrontendHandle == IntPtr.Zero)
							{
								mainWindow.mFrontendHandler.ReparentingCompletedAction = new Action<MainWindow>(KMManager.ShowOverlayWindowAfterReparenting);
								goto IL_1D9;
							}
							KMManager.ShowOverlayWindowAfterReparenting(mainWindow);
							goto IL_1D9;
						}
					}
				}
				if (mainWindow != null && KMManager.dictOverlayWindow.ContainsKey(mainWindow))
				{
					if (isreload)
					{
						KMManager.dictOverlayWindow[mainWindow].ReloadCanvasWindow();
					}
					KMManager.dictOverlayWindow[mainWindow].UpdateSize();
				}
			}
			else if (mainWindow != null && KMManager.dictOverlayWindow.ContainsKey(mainWindow) && !KMManager.dictOverlayWindow[mainWindow].mIsClosing)
			{
				KMManager.dictOverlayWindow[mainWindow].Close();
			}
			IL_1D9:
			KMManager.ToggleOverlayVisibility(mainWindow);
		}

		// Token: 0x06000BBC RID: 3004 RVA: 0x000492F4 File Offset: 0x000474F4
		private static void ToggleOverlayVisibility(MainWindow mainWindow)
		{
			int num = 0;
			try
			{
				KeymapCanvasWindow canvasWindow = KMManager.CanvasWindow;
				if (((canvasWindow != null) ? canvasWindow.SidebarWindow : null) == null)
				{
					foreach (char c in KMManager.sGameControlsEnabledDisabledArray)
					{
						if (mainWindow.SelectedConfig.SelectedControlScheme.GameControls[num].IsVisibleInOverlay)
						{
							if (c == '1')
							{
								using (List<CanvasElement>.Enumerator enumerator = KMManager.listCanvasElement[num].GetEnumerator())
								{
									while (enumerator.MoveNext())
									{
										CanvasElement canvasElement = enumerator.Current;
										IMAction imaction = canvasElement.ListActionItem.First<IMAction>();
										if (imaction.Type == KeyActionType.Pan && (((Pan)imaction).IsLookAroundEnabled || ((Pan)imaction).IsShootOnClickEnabled))
										{
											canvasElement.Visibility = Visibility.Hidden;
										}
										else
										{
											canvasElement.Visibility = Visibility.Visible;
										}
									}
									goto IL_110;
								}
								goto IL_D6;
							}
							goto IL_D6;
							IL_110:
							num++;
							goto IL_114;
							IL_D6:
							foreach (CanvasElement canvasElement2 in KMManager.listCanvasElement[num])
							{
								canvasElement2.Visibility = Visibility.Hidden;
							}
							goto IL_110;
						}
						num++;
						IL_114:;
					}
				}
			}
			catch (Exception ex)
			{
				string str = "ERROR : GameControl not found in canvas elements. ";
				Exception ex2 = ex;
				Logger.Error(str + ((ex2 != null) ? ex2.ToString() : null));
			}
		}

		// Token: 0x06000BBD RID: 3005 RVA: 0x00049494 File Offset: 0x00047694
		private static void ShowOverlayWindowAfterReparenting(MainWindow window)
		{
			window.Dispatcher.Invoke(new Action(delegate()
			{
				if (window != null)
				{
					window.mFrontendHandler.ShowGLWindow();
					if (KMManager.dictOverlayWindow.ContainsKey(window))
					{
						KeymapCanvasWindow keymapCanvasWindow = KMManager.dictOverlayWindow[window];
						if (keymapCanvasWindow != null && !keymapCanvasWindow.mIsClosing)
						{
							keymapCanvasWindow.Opacity = RegistryManager.Instance.TranslucentControlsTransparency;
							if (window.StaticComponents.mLastMappableWindowHandle != IntPtr.Zero)
							{
								keymapCanvasWindow.Show();
								if (KMManager.sIsInScriptEditingMode && KMManager.CanvasWindow.SidebarWindow != null)
								{
									KMManager.CanvasWindow.SidebarWindow.Owner = keymapCanvasWindow;
									KMManager.CanvasWindow.SidebarWindow.Activate();
								}
							}
						}
					}
				}
			}), new object[0]);
		}

		// Token: 0x06000BBE RID: 3006 RVA: 0x00009376 File Offset: 0x00007576
		internal static void ChangeTransparency(MainWindow window, double value)
		{
			if (window != null && KMManager.dictOverlayWindow.ContainsKey(window))
			{
				KMManager.dictOverlayWindow[window].Opacity = value;
			}
			RegistryManager.Instance.TranslucentControlsTransparency = value;
		}

		// Token: 0x06000BBF RID: 3007 RVA: 0x000494D4 File Offset: 0x000476D4
		internal static void CloseWindows()
		{
			if (KMManager.sGuidanceWindow != null && !KMManager.sGuidanceWindow.IsClosed)
			{
				try
				{
					KMManager.sGuidanceWindow.Close();
				}
				catch (Exception ex)
				{
					Logger.Error("exception closing GameControlWindow " + ex.ToString());
				}
			}
			if (KMManager.CanvasWindow != null && !KMManager.CanvasWindow.mIsClosing)
			{
				try
				{
					KMManager.CanvasWindow.SidebarWindow.Close();
				}
				catch (Exception ex2)
				{
					Logger.Error("exception closing GameControlWindow " + ex2.ToString());
				}
			}
		}

		// Token: 0x06000BC0 RID: 3008 RVA: 0x00049570 File Offset: 0x00047770
		internal static void LoadIMActions(MainWindow mainWindow, string packageName)
		{
			Logger.Debug("Extralog: LoadImAction called. vmName:" + mainWindow.mVmName + "..." + Environment.StackTrace);
			KMManager.sPackageName = packageName;
			string inputmapperFile = KMManager.GetInputmapperFile("");
			try
			{
				KMManager.ClearConfig(mainWindow);
				if (File.Exists(inputmapperFile))
				{
					mainWindow.SelectedConfig = KMManager.GetDeserializedIMConfigObject(inputmapperFile, true);
					if (mainWindow.SelectedConfig.ControlSchemes.Any<IMControlScheme>())
					{
						foreach (IMControlScheme imcontrolScheme in mainWindow.SelectedConfig.ControlSchemes)
						{
							if (mainWindow.SelectedConfig.ControlSchemesDict.ContainsKey(imcontrolScheme.Name))
							{
								if (mainWindow.SelectedConfig.ControlSchemesDict[imcontrolScheme.Name].BuiltIn)
								{
									mainWindow.SelectedConfig.ControlSchemesDict[imcontrolScheme.Name] = imcontrolScheme;
								}
							}
							else
							{
								mainWindow.SelectedConfig.ControlSchemesDict[imcontrolScheme.Name] = imcontrolScheme;
							}
						}
						IMControlScheme imcontrolScheme2 = (from scheme in mainWindow.SelectedConfig.ControlSchemes
						where scheme.Selected
						select scheme).FirstOrDefault<IMControlScheme>();
						mainWindow.SelectedConfig.SelectedControlScheme = (imcontrolScheme2 ?? mainWindow.SelectedConfig.ControlSchemes[0]);
					}
					mainWindow.OriginalLoadedConfig = mainWindow.SelectedConfig.DeepCopy();
				}
				KMManager.CheckForShootingModeTooltip(mainWindow);
				if (!AppConfigurationManager.Instance.VmAppConfig[mainWindow.mVmName].ContainsKey(packageName))
				{
					AppConfigurationManager.Instance.VmAppConfig[mainWindow.mVmName][packageName] = new AppSettings();
				}
				if (!AppConfigurationManager.Instance.VmAppConfig[mainWindow.mVmName][packageName].IsDefaultSchemeRecorded)
				{
					string tag = "DefaultScheme";
					string userGuid = RegistryManager.Instance.UserGuid;
					IMConfig selectedConfig = mainWindow.SelectedConfig;
					string arg;
					if (selectedConfig == null)
					{
						arg = null;
					}
					else
					{
						IMControlScheme selectedControlScheme = selectedConfig.SelectedControlScheme;
						arg = ((selectedControlScheme != null) ? selectedControlScheme.Name : null);
					}
					ClientStats.SendMiscellaneousStatsAsync(tag, userGuid, packageName, arg, null, null, null, null, null);
					AppConfigurationManager.Instance.VmAppConfig[mainWindow.mVmName][packageName].IsDefaultSchemeRecorded = true;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error parsing file " + inputmapperFile + ex.ToString());
			}
		}

		// Token: 0x06000BC1 RID: 3009 RVA: 0x000497F0 File Offset: 0x000479F0
		internal static void SendSchemeChangedStats(MainWindow window, string source = "")
		{
			ClientStats.SendMiscellaneousStatsAsync("SchemeChanged", RegistryManager.Instance.UserGuid, KMManager.sPackageName, window.SelectedConfig.SelectedControlScheme.Name, source, null, null, null, null);
		}

		// Token: 0x06000BC2 RID: 3010 RVA: 0x0004982C File Offset: 0x00047A2C
		internal static void PopulateMOBADpadAsChildOfDpad(IMConfig imConfigObj)
		{
			foreach (IMControlScheme imcontrolScheme in imConfigObj.ControlSchemes)
			{
				List<Dpad> list = new List<Dpad>();
				List<MOBADpad> list2 = new List<MOBADpad>();
				foreach (IMAction imaction in imcontrolScheme.GameControls)
				{
					if (imaction.Type == KeyActionType.Dpad)
					{
						Dpad item = imaction as Dpad;
						list.Add(item);
					}
					else if (imaction.Type == KeyActionType.MOBADpad)
					{
						MOBADpad item2 = imaction as MOBADpad;
						list2.Add(item2);
					}
				}
				foreach (MOBADpad mobadpad in list2)
				{
					foreach (Dpad dpad in list)
					{
						if (mobadpad.X.Equals(dpad.X) && mobadpad.Y.Equals(dpad.Y))
						{
							dpad.mMOBADpad = mobadpad;
							mobadpad.mDpad = dpad;
							mobadpad.ParentAction = dpad;
							break;
						}
					}
				}
			}
		}

		// Token: 0x06000BC3 RID: 3011 RVA: 0x000499F4 File Offset: 0x00047BF4
		internal static MOBADpad GetMOBADPad(MainWindow mainWindow)
		{
			foreach (IMAction imaction in mainWindow.SelectedConfig.SelectedControlScheme.GameControls)
			{
				if (imaction.Type == KeyActionType.MOBADpad)
				{
					MOBADpad mobadpad = imaction as MOBADpad;
					if (mobadpad.OriginX != -1.0 && mobadpad.OriginY != -1.0)
					{
						return mobadpad;
					}
				}
			}
			return null;
		}

		// Token: 0x06000BC4 RID: 3012 RVA: 0x00049A84 File Offset: 0x00047C84
		internal static IMConfig GetDeserializedIMConfigObject(string fileName, bool isFileNameUsed = true)
		{
			IMConfig imconfig;
			if (!isFileNameUsed)
			{
				imconfig = JsonConvert.DeserializeObject<IMConfig>(fileName, Utils.GetSerializerSettings());
			}
			else
			{
				bool flag = false;
				string value = "";
				using (Mutex mutex = new Mutex(false, "BlueStacks_CfgAccess"))
				{
					if (mutex.WaitOne())
					{
						try
						{
							value = File.ReadAllText(fileName);
							flag = true;
						}
						catch (Exception arg)
						{
							Logger.Error(string.Format("Failed to read cfg file... filepath: {0} Err : {1}", fileName, arg));
						}
						finally
						{
							mutex.ReleaseMutex();
						}
					}
				}
				if (!flag)
				{
					throw new Exception("Could not read file " + fileName);
				}
				imconfig = JsonConvert.DeserializeObject<IMConfig>(value, Utils.GetSerializerSettings());
			}
			KMManager.PopulateMOBADpadAsChildOfDpad(imconfig);
			return imconfig;
		}

		// Token: 0x06000BC5 RID: 3013 RVA: 0x000093A4 File Offset: 0x000075A4
		internal static IMControlScheme GetNewControlSchemes(string name)
		{
			return new IMControlScheme
			{
				Name = name
			};
		}

		// Token: 0x06000BC6 RID: 3014 RVA: 0x00049B48 File Offset: 0x00047D48
		internal static ComboBoxSchemeControl GetComboBoxSchemeControlFromName(string schemeName)
		{
			foreach (object obj in KMManager.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children)
			{
				ComboBoxSchemeControl comboBoxSchemeControl = (ComboBoxSchemeControl)obj;
				if (comboBoxSchemeControl.mSchemeName.Text == schemeName)
				{
					return comboBoxSchemeControl;
				}
			}
			return null;
		}

		// Token: 0x06000BC7 RID: 3015 RVA: 0x00049BC8 File Offset: 0x00047DC8
		internal static void AddNewControlSchemeAndSelect(MainWindow mainWindow, IMControlScheme toCopyFromScheme = null, bool isCopyOrNew = false)
		{
			bool flag = false;
			if (toCopyFromScheme != null && toCopyFromScheme.Selected)
			{
				IMConfig selectedConfig = mainWindow.SelectedConfig;
				if (string.Equals((selectedConfig != null) ? selectedConfig.SelectedControlScheme.Name : null, toCopyFromScheme.Name, StringComparison.InvariantCulture))
				{
					flag = true;
				}
			}
			IMControlScheme imcontrolScheme;
			if (toCopyFromScheme != null)
			{
				imcontrolScheme = toCopyFromScheme.DeepCopy();
				if (flag)
				{
					List<IMAction> gameControls = toCopyFromScheme.GameControls;
					toCopyFromScheme.SetGameControls(imcontrolScheme.GameControls);
					imcontrolScheme.SetGameControls(gameControls);
				}
			}
			else
			{
				imcontrolScheme = new IMControlScheme();
			}
			imcontrolScheme.Name = KMManager.GetNewSchemeName(mainWindow, toCopyFromScheme, isCopyOrNew);
			imcontrolScheme.Selected = true;
			imcontrolScheme.BuiltIn = false;
			mainWindow.SelectedConfig.ControlSchemes.Add(imcontrolScheme);
			bool isBookMarked = false;
			if (mainWindow.SelectedConfig.ControlSchemesDict.ContainsKey(imcontrolScheme.Name))
			{
				if (mainWindow.SelectedConfig.ControlSchemesDict[imcontrolScheme.Name].BuiltIn)
				{
					isBookMarked = mainWindow.SelectedConfig.ControlSchemesDict[imcontrolScheme.Name].IsBookMarked;
					mainWindow.SelectedConfig.ControlSchemesDict[imcontrolScheme.Name] = imcontrolScheme;
				}
			}
			else
			{
				mainWindow.SelectedConfig.ControlSchemesDict.Add(imcontrolScheme.Name, imcontrolScheme);
			}
			imcontrolScheme.IsBookMarked = isBookMarked;
			if (isCopyOrNew && KMManager.CanvasWindow != null && KMManager.CanvasWindow.SidebarWindow != null)
			{
				KMManager.CanvasWindow.SidebarWindow.mSchemeComboBox.mName.Text = imcontrolScheme.Name;
				ComboBoxSchemeControl comboBoxSchemeControl = new ComboBoxSchemeControl(KMManager.CanvasWindow, mainWindow);
				comboBoxSchemeControl.mSchemeName.Text = LocaleStrings.GetLocalizedString(imcontrolScheme.Name);
				comboBoxSchemeControl.IsEnabled = true;
				BlueStacksUIBinding.BindColor(comboBoxSchemeControl, System.Windows.Controls.Control.BackgroundProperty, "AdvancedGameControlButtonGridBackground");
				KMManager.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children.Add(comboBoxSchemeControl);
			}
			if (mainWindow.SelectedConfig.SelectedControlScheme != null)
			{
				if (KMManager.CanvasWindow != null && KMManager.CanvasWindow.SidebarWindow != null)
				{
					ComboBoxSchemeControl comboBoxSchemeControlFromName = KMManager.GetComboBoxSchemeControlFromName(mainWindow.SelectedConfig.SelectedControlScheme.Name);
					if (comboBoxSchemeControlFromName != null)
					{
						BlueStacksUIBinding.BindColor(comboBoxSchemeControlFromName, System.Windows.Controls.Control.BackgroundProperty, "ComboBoxBackgroundColor");
					}
				}
				mainWindow.SelectedConfig.SelectedControlScheme.Selected = false;
			}
			mainWindow.SelectedConfig.SelectedControlScheme = imcontrolScheme;
			KeymapCanvasWindow.sIsDirty = true;
			if (!flag && KMManager.CanvasWindow != null)
			{
				KMManager.CanvasWindow.Init();
			}
			if (isCopyOrNew && KMManager.CanvasWindow != null && KMManager.CanvasWindow.SidebarWindow != null)
			{
				KMManager.CanvasWindow.SidebarWindow.FillProfileCombo();
			}
		}

		// Token: 0x06000BC8 RID: 3016 RVA: 0x00049E30 File Offset: 0x00048030
		private static void AddNewControlSchemeAndSelectImap(MainWindow mainWindow, IMControlScheme builtInScheme)
		{
			IMConfig selectedConfig = mainWindow.SelectedConfig;
			IMControlScheme imcontrolScheme = (selectedConfig != null) ? selectedConfig.SelectedControlScheme : null;
			int? num;
			if (mainWindow == null)
			{
				num = null;
			}
			else
			{
				IMConfig selectedConfig2 = mainWindow.SelectedConfig;
				num = ((selectedConfig2 != null) ? new int?(selectedConfig2.ControlSchemes.IndexOf(imcontrolScheme)) : null);
			}
			int? num2 = num;
			if (num2 != null)
			{
				int? num3 = num2;
				int num4 = -1;
				if (num3.GetValueOrDefault() > num4 & num3 != null)
				{
					mainWindow.SelectedConfig.ControlSchemes[num2.Value] = builtInScheme.DeepCopy();
					mainWindow.SelectedConfig.ControlSchemes[num2.Value].IsBookMarked = false;
				}
			}
			imcontrolScheme.BuiltIn = false;
			foreach (IMControlScheme imcontrolScheme2 in mainWindow.SelectedConfig.ControlSchemes)
			{
				imcontrolScheme2.Selected = false;
			}
			mainWindow.SelectedConfig.ControlSchemes.Add(imcontrolScheme);
			if (mainWindow.SelectedConfig.ControlSchemesDict.ContainsKey(imcontrolScheme.Name))
			{
				mainWindow.SelectedConfig.ControlSchemesDict[imcontrolScheme.Name] = imcontrolScheme;
			}
			mainWindow.SelectedConfig.SelectedControlScheme = imcontrolScheme;
			imcontrolScheme.Selected = true;
		}

		// Token: 0x06000BC9 RID: 3017 RVA: 0x00049F84 File Offset: 0x00048184
		internal static string GetNewSchemeName(MainWindow mainWindow, IMControlScheme builtInScheme, bool isCopyOrNew)
		{
			string text;
			if (builtInScheme == null)
			{
				text = "Custom";
			}
			else
			{
				text = builtInScheme.Name;
				if (builtInScheme.BuiltIn && !isCopyOrNew)
				{
					return text;
				}
			}
			List<string> list = new List<string>();
			foreach (IMControlScheme imcontrolScheme in mainWindow.SelectedConfig.ControlSchemes)
			{
				list.Add(imcontrolScheme.Name);
			}
			return KMManager.GetUniqueName(text, list);
		}

		// Token: 0x06000BCA RID: 3018 RVA: 0x0004A010 File Offset: 0x00048210
		internal static string GetUniqueName(string baseName, IEnumerable<string> nameCollection)
		{
			int length = baseName.Length;
			int num = 0;
			bool flag = false;
			foreach (string text in nameCollection)
			{
				if (string.Compare(baseName, 0, text, 0, length, StringComparison.OrdinalIgnoreCase) == 0)
				{
					flag = true;
					if (text.Length > length + 3 && text[length] == ' ' && text[length + 1] == '(' && text[text.Length - 1] == ')')
					{
						int num2;
						try
						{
							num2 = int.Parse(text.Substring(length + 2, text.Length - length - 3), CultureInfo.InvariantCulture);
						}
						catch (Exception)
						{
							continue;
						}
						if (num2 > num)
						{
							num = num2;
						}
					}
				}
			}
			if (!flag)
			{
				return baseName;
			}
			return string.Format(CultureInfo.InvariantCulture, "{0} ({1})", new object[]
			{
				baseName,
				num + 1
			});
		}

		// Token: 0x06000BCB RID: 3019 RVA: 0x0004A110 File Offset: 0x00048310
		internal static bool IsValidCfg(string fileName)
		{
			bool result;
			try
			{
				if (JsonConvert.DeserializeObject(File.ReadAllText(fileName)) == null)
				{
					result = false;
				}
				else
				{
					result = true;
				}
			}
			catch (Exception)
			{
				Logger.Error("invalid cfg file: {0}", new object[]
				{
					fileName
				});
				result = false;
			}
			return result;
		}

		// Token: 0x06000BCC RID: 3020 RVA: 0x0004A15C File Offset: 0x0004835C
		private static void CheckForShootingModeTooltip(MainWindow window)
		{
			try
			{
				foreach (IMAction imaction in window.SelectedConfig.SelectedControlScheme.GameControls)
				{
					if (imaction.Type == KeyActionType.Pan)
					{
						KMManager.sShootingModeKey = ((Pan)imaction).KeyStartStop.ToString(CultureInfo.InvariantCulture);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in showing shooting mode tooltip: " + ex.ToString());
			}
		}

		// Token: 0x06000BCD RID: 3021 RVA: 0x000093B2 File Offset: 0x000075B2
		internal static void ClearConfig(MainWindow mainWindow)
		{
			MOBADpad.sListMOBADpad.Clear();
			Dpad.sListDpad.Clear();
			mainWindow.SelectedConfig = null;
			mainWindow.OriginalLoadedConfig = null;
		}

		// Token: 0x06000BCE RID: 3022 RVA: 0x0004A1FC File Offset: 0x000483FC
		internal static void GetCanvasElement(MainWindow mainWindow, IMAction action, Canvas canvas, bool addToCanvas = true)
		{
			KMManager.sDragCanvasElement = new CanvasElement(KMManager.CanvasWindow, mainWindow);
			KMManager.sDragCanvasElement.AddAction(action);
			KMManager.sDragCanvasElement.Opacity = 0.1;
			if (addToCanvas)
			{
				canvas.Children.Add(KMManager.sDragCanvasElement);
			}
			if (action.Type == KeyActionType.Swipe)
			{
				KMManager.AssignSwapValues(action);
				List<Direction> list = Enum.GetValues(typeof(Direction)).Cast<Direction>().ToList<Direction>();
				list.Remove(action.Direction);
				foreach (Direction direction in list)
				{
					IMAction imaction = action.DeepCopy<IMAction>();
					imaction.Direction = direction;
					imaction.RadiusProperty = action.RadiusProperty;
					KMManager.AssignSwapValues(imaction);
					KMManager.sDragCanvasElement.AddAction(imaction);
				}
				action.RadiusProperty = action.RadiusProperty;
			}
		}

		// Token: 0x06000BCF RID: 3023 RVA: 0x0004A2F4 File Offset: 0x000484F4
		private static void AssignSwapValues(IMAction action)
		{
			if (action.Direction == Direction.Up)
			{
				(action as Swipe).Key = IMAPKeys.GetStringForUI(Key.Up);
				return;
			}
			if (action.Direction == Direction.Down)
			{
				(action as Swipe).Key = IMAPKeys.GetStringForUI(Key.Down);
				return;
			}
			if (action.Direction == Direction.Left)
			{
				(action as Swipe).Key = IMAPKeys.GetStringForUI(Key.Left);
				return;
			}
			(action as Swipe).Key = IMAPKeys.GetStringForUI(Key.Right);
		}

		// Token: 0x06000BD0 RID: 3024 RVA: 0x0004A368 File Offset: 0x00048568
		internal static List<IMAction> ClearElement()
		{
			List<IMAction> result = null;
			if (KMManager.sDragCanvasElement != null)
			{
				result = KMManager.sDragCanvasElement.ListActionItem;
				System.Windows.Controls.Panel panel = KMManager.sDragCanvasElement.Parent as System.Windows.Controls.Panel;
				if (panel != null)
				{
					panel.Children.Remove(KMManager.sDragCanvasElement);
				}
				KMManager.sDragCanvasElement = null;
			}
			return result;
		}

		// Token: 0x06000BD1 RID: 3025 RVA: 0x0004A3B4 File Offset: 0x000485B4
		internal static void RepositionCanvasElement()
		{
			if (KMManager.sDragCanvasElement != null)
			{
				System.Windows.Point position = Mouse.GetPosition(KMManager.sDragCanvasElement.Parent as IInputElement);
				Canvas.SetTop(KMManager.sDragCanvasElement, position.Y - KMManager.sDragCanvasElement.ActualHeight / 2.0);
				Canvas.SetLeft(KMManager.sDragCanvasElement, position.X - KMManager.sDragCanvasElement.ActualWidth / 2.0);
			}
		}

		// Token: 0x06000BD2 RID: 3026 RVA: 0x0004A42C File Offset: 0x0004862C
		internal static void SaveIMActions(MainWindow mainWindow, bool isSavedFromGameControlWindow, bool isdDeleteIfEmpty = false)
		{
			Logger.Debug(string.Format("ExtraLog:Calling SaveIMActions, VmName:{0}, Scheme:{1}, SchemeCount:{2}", mainWindow.mVmName, mainWindow.SelectedConfig.SelectedControlScheme.Name, mainWindow.SelectedConfig.ControlSchemes.Count));
			if (!KeymapCanvasWindow.sIsDirty && !GuidanceWindow.sIsDirty && !isdDeleteIfEmpty)
			{
				Logger.Info("No changes were made in config file. Not saving");
				return;
			}
			KeymapCanvasWindow.sIsDirty = false;
			GuidanceWindow.sIsDirty = false;
			KMManager.sGamepadDualTextbox = null;
			string inputmapperUserFilePath = KMManager.GetInputmapperUserFilePath("");
			KMManager.CheckForShootingModeTooltip(mainWindow);
			try
			{
				string directoryName = Path.GetDirectoryName(inputmapperUserFilePath);
				if (!Directory.Exists(directoryName))
				{
					Directory.CreateDirectory(directoryName);
				}
				KMManager.CleanupGuidanceAccordingToSchemes(mainWindow.SelectedConfig.ControlSchemes, mainWindow.SelectedConfig.Strings);
				KMManager.SaveAndUpdateKeymapUI(mainWindow, isSavedFromGameControlWindow, inputmapperUserFilePath);
			}
			catch (Exception ex)
			{
				Logger.Error("Error saving file  for " + inputmapperUserFilePath + Environment.NewLine + ex.ToString());
			}
		}

		// Token: 0x06000BD3 RID: 3027 RVA: 0x0004A51C File Offset: 0x0004871C
		private static void SaveAndUpdateKeymapUI(MainWindow mainWindow, bool isSavedFromGameControlWindow, string path)
		{
			Logger.Debug(string.Format("ExtraLog:Calling SaveAndUpdateKeymapUI, VmName:{0}, Scheme:{1}, SchemeCount:{2}", mainWindow.mVmName, mainWindow.SelectedConfig.SelectedControlScheme.Name, mainWindow.SelectedConfig.ControlSchemes.Count));
			try
			{
				mainWindow.SelectedConfig.MetaData.ParserVersion = KMManager.ParserVersion;
				JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
				serializerSettings.Formatting = Formatting.Indented;
				string contents = JsonConvert.SerializeObject(mainWindow.SelectedConfig, serializerSettings);
				bool callUpdateGrm = false;
				if (!File.Exists(path))
				{
					callUpdateGrm = true;
				}
				using (Mutex mutex = new Mutex(false, "BlueStacks_CfgAccess"))
				{
					if (mutex.WaitOne())
					{
						try
						{
							Logger.Debug(string.Format("ExtraLog:Calling WriteAllText, VmName:{0}, Scheme:{1}, SchemeCount:{2}", mainWindow.mVmName, mainWindow.SelectedConfig.SelectedControlScheme.Name, mainWindow.SelectedConfig.ControlSchemes.Count));
							File.WriteAllText(path, contents);
						}
						catch (Exception arg)
						{
							Logger.Error(string.Format("Failed to write cfg path: {0} Err : {1}", path, arg));
						}
						finally
						{
							mutex.ReleaseMutex();
						}
					}
				}
				Logger.Debug(string.Format("ExtraLog:Updating Original Config, VmName:{0}, Scheme:{1}, SchemeCount:{2}", mainWindow.mVmName, mainWindow.SelectedConfig.SelectedControlScheme.Name, mainWindow.SelectedConfig.ControlSchemes.Count));
				mainWindow.OriginalLoadedConfig = mainWindow.SelectedConfig.DeepCopy();
				bool isEnabled = false;
				if (mainWindow.OriginalLoadedConfig.ControlSchemes != null && mainWindow.OriginalLoadedConfig.ControlSchemes.Count > 0)
				{
					isEnabled = true;
				}
				else
				{
					isEnabled = false;
				}
				mainWindow.Dispatcher.Invoke(new Action(delegate()
				{
					if (KMManager.CanvasWindow != null && KMManager.CanvasWindow.SidebarWindow != null)
					{
						KMManager.CanvasWindow.SidebarWindow.mExport.IsEnabled = isEnabled;
					}
					mainWindow.mCommonHandler.OnGameGuideButtonVisibilityChanged(isEnabled);
					ClientStats.SendKeyMappingUIStatsAsync("cfg_saved", KMManager.sPackageName, isSavedFromGameControlWindow ? "edit_keys" : "advanced");
					if (callUpdateGrm)
					{
						GrmHandler.RequirementConfigUpdated(mainWindow.mVmName);
					}
					BlueStacksUIUtils.RefreshKeyMap(KMManager.sPackageName);
					if (KMManager.dictGamepadEligibility.ContainsKey(KMManager.sPackageName))
					{
						KMManager.dictGamepadEligibility.Remove(KMManager.sPackageName);
					}
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in SaveAndUpdateKeymapUI.." + ex.ToString());
			}
		}

		// Token: 0x06000BD4 RID: 3028 RVA: 0x0004A7B0 File Offset: 0x000489B0
		internal static void SaveConfigToFile(string path, IMConfig config)
		{
			JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
			serializerSettings.Formatting = Formatting.Indented;
			string contents = JsonConvert.SerializeObject(config, serializerSettings);
			File.WriteAllText(path, contents);
		}

		// Token: 0x06000BD5 RID: 3029 RVA: 0x0004A7DC File Offset: 0x000489DC
		internal static bool CheckIfKeymappingWindowVisible(bool checkForGuidanceWindow = false)
		{
			bool isVisible = false;
			bool guidanceWindowVisible = false;
			try
			{
				BlueStacksUIUtils.LastActivatedWindow.Dispatcher.Invoke(new Action(delegate()
				{
					if (KMManager.sGuidanceWindow != null && (KMManager.sGuidanceWindow.IsActive || KMManager.sGuidanceWindow.IsVisible))
					{
						guidanceWindowVisible = true;
					}
					if (KMManager.CanvasWindow != null && KMManager.CanvasWindow.IsActive)
					{
						isVisible = true;
					}
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Info("Exception in checkifkeymappingwindowvisible: " + ex.ToString());
			}
			if (checkForGuidanceWindow)
			{
				return guidanceWindowVisible;
			}
			return isVisible;
		}

		// Token: 0x06000BD6 RID: 3030 RVA: 0x0004A85C File Offset: 0x00048A5C
		internal static void CallGamepadHandler(MainWindow mainWindow, string isEnable = "true")
		{
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"enable",
					isEnable
				}
			};
			mainWindow.mFrontendHandler.SendFrontendRequestAsync("toggleGamepadButton", data);
		}

		// Token: 0x06000BD7 RID: 3031 RVA: 0x0004A88C File Offset: 0x00048A8C
		internal static string GetStringsToShowInUI(string text)
		{
			string[] array = text.ToString(CultureInfo.InvariantCulture).Split(new char[]
			{
				'+'
			}, StringSplitOptions.RemoveEmptyEntries);
			string result = string.Empty;
			if (array.Length == 2)
			{
				string stringForUI = IMAPKeys.GetStringForUI(array[0].Trim());
				string stringForUI2 = IMAPKeys.GetStringForUI(array[1].Trim());
				result = Constants.ImapLocaleStringsConstant + stringForUI + " + " + stringForUI2;
			}
			else if (array.Length == 1)
			{
				string stringForUI = IMAPKeys.GetStringForUI(array[0].Trim());
				result = Constants.ImapLocaleStringsConstant + stringForUI;
			}
			return result;
		}

		// Token: 0x06000BD8 RID: 3032 RVA: 0x0004A914 File Offset: 0x00048B14
		internal static Dictionary<string, Dictionary<string, string>> CleanupGuidanceAccordingToSchemes(List<IMControlScheme> schemes, Dictionary<string, Dictionary<string, string>> locales)
		{
			HashSet<string> guidanceInUse = new HashSet<string>();
			foreach (IMControlScheme imcontrolScheme in schemes)
			{
				foreach (IMAction imaction in imcontrolScheme.GameControls)
				{
					guidanceInUse.UnionWith(imaction.Guidance.Values);
					guidanceInUse.Add(imaction.GuidanceCategory);
				}
			}
			Func<KeyValuePair<string, string>, bool> <>9__0;
			foreach (string key in locales.Keys)
			{
				IEnumerable<KeyValuePair<string, string>> source = locales[key];
				Func<KeyValuePair<string, string>, bool> predicate;
				if ((predicate = <>9__0) == null)
				{
					predicate = (<>9__0 = ((KeyValuePair<string, string> kv) => !guidanceInUse.Contains(kv.Key)));
				}
				foreach (KeyValuePair<string, string> keyValuePair in source.Where(predicate).ToList<KeyValuePair<string, string>>())
				{
					locales[key].Remove(keyValuePair.Key);
				}
			}
			return locales;
		}

		// Token: 0x06000BD9 RID: 3033 RVA: 0x0004AA90 File Offset: 0x00048C90
		public static string GetPackageFromCfgFile(string cfgFileName)
		{
			string result = string.Empty;
			if (!string.IsNullOrEmpty(cfgFileName))
			{
				result = Path.GetFileNameWithoutExtension(cfgFileName);
			}
			return result;
		}

		// Token: 0x06000BDA RID: 3034 RVA: 0x0004AAB4 File Offset: 0x00048CB4
		public static void MergeConfig(string pdPath)
		{
			Logger.Info("In MergeConfig");
			try
			{
				string text = Path.Combine(pdPath, "Engine\\UserData\\InputMapper\\UserFiles");
				string[] files = Directory.GetFiles(text);
				for (int i = 0; i < files.Length; i++)
				{
					FileInfo fileInfo = new FileInfo(files[i]);
					string path = Path.Combine(pdPath, "Engine\\UserData\\InputMapper");
					string text2 = Path.Combine(path, fileInfo.Name);
					string text3 = Path.Combine(text, fileInfo.Name);
					IMConfig deserializedIMConfigObject = KMManager.GetDeserializedIMConfigObject(text3, true);
					if (deserializedIMConfigObject.ControlSchemes.Count == 1)
					{
						deserializedIMConfigObject.ControlSchemes[0].Selected = true;
					}
					if (!File.Exists(text2))
					{
						KMManager.SaveConfigToFile(Path.Combine(path, "UserFiles\\" + fileInfo.Name), deserializedIMConfigObject);
					}
					else
					{
						KMManager.ControlSchemesHandling(KMManager.GetPackageFromCfgFile(fileInfo.Name), text3, text2);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in merging cfg. err: " + ex.ToString());
			}
		}

		// Token: 0x06000BDB RID: 3035 RVA: 0x0004ABBC File Offset: 0x00048DBC
		internal static void MergeConflictingGuidanceStrings(IMConfig newConfig, List<IMControlScheme> toCopyFromSchemes, Dictionary<string, Dictionary<string, string>> stringsToImport)
		{
			HashSet<string> hashSet = new HashSet<string>();
			HashSet<string> hashSet2 = new HashSet<string>();
			foreach (string text in stringsToImport.Keys)
			{
				hashSet2.UnionWith(stringsToImport[text].Keys);
				if (newConfig.Strings.Keys.Contains(text))
				{
					hashSet2.UnionWith(newConfig.Strings[text].Keys);
					foreach (string text2 in stringsToImport[text].Keys)
					{
						if (newConfig.Strings[text].Keys.Contains(text2) && stringsToImport[text][text2] != newConfig.Strings[text][text2])
						{
							hashSet.Add(text2);
						}
					}
				}
			}
			foreach (string text3 in hashSet)
			{
				string uniqueName = KMManager.GetUniqueName(text3, hashSet2);
				foreach (IMControlScheme imcontrolScheme in toCopyFromSchemes)
				{
					foreach (IMAction imaction in imcontrolScheme.GameControls)
					{
						if (imaction.GuidanceCategory == text3)
						{
							imaction.GuidanceCategory = uniqueName;
						}
						foreach (string key in imaction.Guidance.Keys)
						{
							if (imaction.Guidance[key] == text3)
							{
								imaction.Guidance[key] = uniqueName;
								break;
							}
						}
					}
				}
				foreach (Dictionary<string, string> dictionary in stringsToImport.Values)
				{
					if (dictionary.ContainsKey(text3))
					{
						dictionary[uniqueName] = dictionary[text3];
						dictionary.Remove(text3);
					}
				}
			}
			foreach (KeyValuePair<string, Dictionary<string, string>> keyValuePair in stringsToImport)
			{
				if (newConfig.Strings.ContainsKey(keyValuePair.Key))
				{
					using (Dictionary<string, string>.Enumerator enumerator8 = keyValuePair.Value.GetEnumerator())
					{
						while (enumerator8.MoveNext())
						{
							KeyValuePair<string, string> keyValuePair2 = enumerator8.Current;
							newConfig.Strings[keyValuePair.Key][keyValuePair2.Key] = keyValuePair2.Value;
						}
						continue;
					}
				}
				newConfig.Strings[keyValuePair.Key] = keyValuePair.Value;
			}
		}

		// Token: 0x06000BDC RID: 3036 RVA: 0x0004AFD0 File Offset: 0x000491D0
		public static void ControlSchemesHandlingWhileCfgUpdateFromCloud(string package)
		{
			string path = Path.Combine(RegistryStrings.InputMapperFolder, "UserFiles");
			string userFilesCfgPath = string.Format(CultureInfo.InvariantCulture, Path.Combine(path, package) + ".cfg", new object[0]);
			string inputMapperCfgPath = string.Format(CultureInfo.InvariantCulture, Path.Combine(RegistryStrings.InputMapperFolder, package) + ".cfg", new object[0]);
			KMManager.ControlSchemesHandlingFromCloud(package, userFilesCfgPath, inputMapperCfgPath);
		}

		// Token: 0x06000BDD RID: 3037 RVA: 0x0004B040 File Offset: 0x00049240
		private static void ControlSchemesHandling(string package, string userFilesCfgPath, string inputMapperCfgPath)
		{
			try
			{
				if (File.Exists(userFilesCfgPath))
				{
					IMConfig deserializedIMConfigObject = KMManager.GetDeserializedIMConfigObject(inputMapperCfgPath, true);
					IMConfig deserializedIMConfigObject2 = KMManager.GetDeserializedIMConfigObject(userFilesCfgPath, true);
					KMManager.MergeConflictingGuidanceStrings(deserializedIMConfigObject, deserializedIMConfigObject2.ControlSchemes, deserializedIMConfigObject2.Strings);
					deserializedIMConfigObject2.Strings = deserializedIMConfigObject.Strings;
					List<IMControlScheme> list = new List<IMControlScheme>();
					foreach (IMControlScheme imcontrolScheme in deserializedIMConfigObject.ControlSchemes)
					{
						if (imcontrolScheme.BuiltIn)
						{
							list.Add(imcontrolScheme);
						}
					}
					IMControlScheme imcontrolScheme2;
					bool flag = KMManager.IsBuiltInSchemeSelected(deserializedIMConfigObject2, out imcontrolScheme2);
					List<IMControlScheme> list2 = new List<IMControlScheme>();
					foreach (IMControlScheme imcontrolScheme3 in deserializedIMConfigObject2.ControlSchemes)
					{
						if (imcontrolScheme3.BuiltIn)
						{
							list2.Add(imcontrolScheme3);
						}
					}
					foreach (IMControlScheme item in list2)
					{
						deserializedIMConfigObject2.ControlSchemes.Remove(item);
					}
					List<string> list3 = (from scheme in list
					select scheme.Name).ToList<string>();
					List<string> list4 = (from scheme in deserializedIMConfigObject2.ControlSchemes
					select scheme.Name).ToList<string>();
					list4.AddRange(list3);
					string str = " (Custom)";
					foreach (IMControlScheme imcontrolScheme4 in deserializedIMConfigObject2.ControlSchemes)
					{
						if (list3.Contains(imcontrolScheme4.Name))
						{
							imcontrolScheme4.Name = KMManager.GetUniqueName(imcontrolScheme4.Name + str, list4);
							list4.Add(imcontrolScheme4.Name);
						}
					}
					foreach (IMControlScheme item2 in list)
					{
						deserializedIMConfigObject2.ControlSchemes.Add(item2);
					}
					if (!flag)
					{
						using (List<IMControlScheme>.Enumerator enumerator = deserializedIMConfigObject2.ControlSchemes.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								IMControlScheme imcontrolScheme5 = enumerator.Current;
								if (imcontrolScheme5.BuiltIn)
								{
									if (!Opt.Instance.isUpgradeFromImap13 || !string.Equals(package, "com.dts.freefireth", StringComparison.InvariantCultureIgnoreCase))
									{
										imcontrolScheme5.Selected = false;
									}
								}
								else if (Opt.Instance.isUpgradeFromImap13 && string.Equals(package, "com.dts.freefireth", StringComparison.InvariantCultureIgnoreCase))
								{
									imcontrolScheme5.Selected = false;
								}
							}
							goto IL_345;
						}
					}
					if (imcontrolScheme2 != null)
					{
						IMControlScheme imcontrolScheme6 = null;
						bool flag2 = false;
						foreach (IMControlScheme imcontrolScheme7 in deserializedIMConfigObject2.ControlSchemes)
						{
							if (imcontrolScheme7.BuiltIn)
							{
								if (imcontrolScheme7.Name == imcontrolScheme2.Name)
								{
									imcontrolScheme7.Selected = true;
									flag2 = true;
								}
								else if (imcontrolScheme7.Selected)
								{
									imcontrolScheme6 = imcontrolScheme7;
								}
							}
						}
						if (imcontrolScheme6 != null && flag2)
						{
							imcontrolScheme6.Selected = false;
						}
					}
					IL_345:
					if (string.Equals(package, "com.dts.freefireth", StringComparison.InvariantCultureIgnoreCase) || PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.Any((string codPckg) => string.Equals(codPckg, package, StringComparison.InvariantCultureIgnoreCase)))
					{
						Dictionary<string, IMControlScheme> dictionary = new Dictionary<string, IMControlScheme>();
						foreach (IMControlScheme imcontrolScheme8 in list2)
						{
							if (imcontrolScheme8.Images != null && imcontrolScheme8.Images.Count > 0)
							{
								string key = JsonConvert.SerializeObject(imcontrolScheme8.Images, Utils.GetSerializerSettings());
								dictionary.Add(key, imcontrolScheme8);
							}
						}
						foreach (IMControlScheme imcontrolScheme9 in deserializedIMConfigObject2.ControlSchemes)
						{
							if (imcontrolScheme9.Images != null && !imcontrolScheme9.BuiltIn && imcontrolScheme9.Images.Count > 0)
							{
								string images = JsonConvert.SerializeObject(imcontrolScheme9.Images, Utils.GetSerializerSettings());
								IEnumerable<KeyValuePair<string, IMControlScheme>> prevSchemesMatchingImages = from kvp in dictionary
								where string.Compare(kvp.Key, images, StringComparison.InvariantCultureIgnoreCase) == 0
								select kvp;
								if (prevSchemesMatchingImages.Any<KeyValuePair<string, IMControlScheme>>())
								{
									IEnumerable<IMControlScheme> source = from newScheme in list
									where string.Compare(newScheme.Name, prevSchemesMatchingImages.First<KeyValuePair<string, IMControlScheme>>().Value.Name, StringComparison.InvariantCultureIgnoreCase) == 0
									select newScheme;
									if (source.Any<IMControlScheme>() && source.First<IMControlScheme>().Images != null && source.First<IMControlScheme>().Images.Any<JObject>())
									{
										imcontrolScheme9.SetImages(source.First<IMControlScheme>().Images);
									}
								}
							}
						}
					}
					KMManager.SaveConfigToFile(userFilesCfgPath, deserializedIMConfigObject2);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in updating control schemes err: " + ex.ToString());
			}
		}

		// Token: 0x06000BDE RID: 3038 RVA: 0x0004B63C File Offset: 0x0004983C
		internal static void SelectSchemeIfPresent(MainWindow window, string schemeNameToSelect, string statSource, bool forceSave)
		{
			IEnumerable<IMControlScheme> source = from scheme in window.SelectedConfig.ControlSchemes
			where string.Equals(scheme.Name, schemeNameToSelect, StringComparison.InvariantCulture)
			select scheme;
			bool flag = true;
			if (source.Any<IMControlScheme>())
			{
				IMControlScheme imcontrolScheme;
				if (source.Count<IMControlScheme>() == 1)
				{
					imcontrolScheme = source.FirstOrDefault<IMControlScheme>();
				}
				else
				{
					imcontrolScheme = (from scheme in source
					where !scheme.BuiltIn
					select scheme).FirstOrDefault<IMControlScheme>();
				}
				if (imcontrolScheme == null || (imcontrolScheme.Name == window.SelectedConfig.SelectedControlScheme.Name && !forceSave))
				{
					flag = false;
				}
				else
				{
					window.SelectedConfig.SelectedControlScheme.Selected = false;
					imcontrolScheme.Selected = true;
					window.SelectedConfig.SelectedControlScheme = imcontrolScheme;
				}
			}
			if (flag)
			{
				KeymapCanvasWindow.sIsDirty = true;
				KMManager.SaveIMActions(window, false, false);
				if (RegistryManager.Instance.ShowKeyControlsOverlay)
				{
					KMManager.ShowOverlayWindow(window, true, true);
				}
				BlueStacksUIUtils.RefreshKeyMap(KMManager.sPackageName);
				KMManager.SendSchemeChangedStats(window, statSource);
			}
		}

		// Token: 0x06000BDF RID: 3039 RVA: 0x0004B740 File Offset: 0x00049940
		private static bool IsBuiltInSchemeSelected(IMConfig prevConfig, out IMControlScheme selectedScheme)
		{
			selectedScheme = null;
			foreach (IMControlScheme imcontrolScheme in prevConfig.ControlSchemes)
			{
				if (imcontrolScheme.Selected && imcontrolScheme.BuiltIn)
				{
					selectedScheme = imcontrolScheme;
					return true;
				}
			}
			return false;
		}

		// Token: 0x06000BE0 RID: 3040 RVA: 0x0004B7AC File Offset: 0x000499AC
		private static void ControlSchemesHandlingFromCloud(string package, string userFilesCfgPath, string inputMapperCfgPath)
		{
			try
			{
				if (File.Exists(userFilesCfgPath))
				{
					IMConfig deserializedIMConfigObject = KMManager.GetDeserializedIMConfigObject(inputMapperCfgPath, true);
					IMConfig deserializedIMConfigObject2 = KMManager.GetDeserializedIMConfigObject(userFilesCfgPath, true);
					KMManager.MergeConflictingGuidanceStrings(deserializedIMConfigObject, deserializedIMConfigObject2.ControlSchemes, deserializedIMConfigObject2.Strings);
					IEnumerable<IMControlScheme> enumerable = from scheme in deserializedIMConfigObject2.ControlSchemes
					where !scheme.BuiltIn
					select scheme;
					if (enumerable.Any<IMControlScheme>())
					{
						foreach (IMControlScheme item in enumerable)
						{
							deserializedIMConfigObject.ControlSchemes.Add(item);
						}
					}
					string selectedSchemeName = string.Empty;
					IMControlScheme imcontrolScheme = (from scheme in deserializedIMConfigObject2.ControlSchemes
					where scheme.Selected
					select scheme).FirstOrDefault<IMControlScheme>();
					if (imcontrolScheme != null)
					{
						selectedSchemeName = imcontrolScheme.Name;
					}
					deserializedIMConfigObject.ControlSchemes.ForEach(delegate(IMControlScheme scheme)
					{
						scheme.Selected = false;
					});
					if (imcontrolScheme != null)
					{
						List<IMControlScheme> list = (from scheme in deserializedIMConfigObject.ControlSchemes
						where string.Equals(scheme.Name, selectedSchemeName, StringComparison.InvariantCultureIgnoreCase)
						select scheme).ToList<IMControlScheme>();
						if (list.Count == 1)
						{
							list[0].Selected = true;
						}
						else if (list.Count == 2)
						{
							IMControlScheme imcontrolScheme2 = (from scheme in list
							where !scheme.BuiltIn
							select scheme).FirstOrDefault<IMControlScheme>();
							if (imcontrolScheme2 != null)
							{
								imcontrolScheme2.Selected = true;
							}
						}
					}
					IEnumerable<IMControlScheme> enumerable2 = from scheme in deserializedIMConfigObject2.ControlSchemes
					where scheme.BuiltIn
					select scheme;
					if (enumerable2.Any<IMControlScheme>())
					{
						using (IEnumerator<IMControlScheme> enumerator = enumerable2.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								IMControlScheme userScheme = enumerator.Current;
								IMControlScheme imcontrolScheme3 = (from scheme in deserializedIMConfigObject.ControlSchemes
								where scheme.BuiltIn && string.Equals(scheme.Name, userScheme.Name, StringComparison.InvariantCultureIgnoreCase)
								select scheme).FirstOrDefault<IMControlScheme>();
								if (imcontrolScheme3 != null)
								{
									imcontrolScheme3.IsBookMarked = userScheme.IsBookMarked;
								}
							}
						}
						if (string.Equals(package, "com.dts.freefireth", StringComparison.InvariantCultureIgnoreCase) || PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.Any((string codPckg) => string.Equals(codPckg, package, StringComparison.InvariantCultureIgnoreCase)))
						{
							Dictionary<string, IMControlScheme> dictionary = new Dictionary<string, IMControlScheme>();
							foreach (IMControlScheme imcontrolScheme4 in enumerable2)
							{
								if (imcontrolScheme4.Images != null && imcontrolScheme4.Images.Count > 0)
								{
									string key = JsonConvert.SerializeObject(imcontrolScheme4.Images, Utils.GetSerializerSettings());
									dictionary.Add(key, imcontrolScheme4);
								}
							}
							foreach (IMControlScheme imcontrolScheme5 in from scheme in deserializedIMConfigObject.ControlSchemes
							where !scheme.BuiltIn
							select scheme)
							{
								if (imcontrolScheme5.Images != null && imcontrolScheme5.Images.Count > 0)
								{
									string key2 = JsonConvert.SerializeObject(imcontrolScheme5.Images, Utils.GetSerializerSettings());
									if (dictionary.ContainsKey(key2))
									{
										IMControlScheme userSchemeMatchingBuiltInImage = dictionary[key2];
										IMControlScheme imcontrolScheme6 = deserializedIMConfigObject.ControlSchemes.Where((IMControlScheme cloudScheme) => cloudScheme.BuiltIn && string.Equals(cloudScheme.Name, userSchemeMatchingBuiltInImage.Name, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault<IMControlScheme>();
										if (imcontrolScheme6 != null && imcontrolScheme6.Images != null && imcontrolScheme6.Images.Any<JObject>())
										{
											imcontrolScheme5.SetImages(imcontrolScheme6.Images);
										}
									}
								}
							}
						}
					}
					KMManager.SaveConfigToFile(userFilesCfgPath, deserializedIMConfigObject);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in updating control schemes err: " + ex.ToString());
			}
		}

		// Token: 0x06000BE1 RID: 3041 RVA: 0x0004BC28 File Offset: 0x00049E28
		internal static string CheckForGamepadSuffix(string text)
		{
			if (text.Contains("Gamepad", StringComparison.InvariantCultureIgnoreCase))
			{
				string value = ".";
				if (text.Contains(value))
				{
					text = text.Substring(0, text.IndexOf(value, StringComparison.InvariantCultureIgnoreCase));
				}
			}
			return text;
		}

		// Token: 0x06000BE2 RID: 3042 RVA: 0x0004BC64 File Offset: 0x00049E64
		internal static string GetKeyUIValue(string text)
		{
			return string.Join(" + ", (from singleItem in text.Split(new char[]
			{
				'+'
			}).ToList<string>()
			select LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(KMManager.CheckForGamepadSuffix(singleItem.Trim())))).ToArray<string>());
		}

		// Token: 0x06000BE3 RID: 3043 RVA: 0x0004BCBC File Offset: 0x00049EBC
		internal static void ShowShootingModeTooltip(MainWindow mainWindow, string package)
		{
			if (!KMManager.CheckIfKeymappingWindowVisible(false) && KMManager.KeyMappingFilesAvailable(package) && !mainWindow.mTopBar.mAppTabButtons.SelectedTab.mIsShootingModeToastDisplayed && !KMManager.IsSelectedSchemeSmart(mainWindow) && KMManager.IsShowShootingModeTooltip(mainWindow))
			{
				string[] array = LocaleStrings.GetLocalizedString("STRING_PRESS_TO_AIM_AND_SHOOT").Split(new char[]
				{
					'{',
					'}'
				});
				mainWindow.ToggleFullScreenToastVisibility(true, array[0], IMAPKeys.GetStringForUI(KMManager.sShootingModeKey), array[2]);
				mainWindow.mTopBar.mAppTabButtons.SelectedTab.mIsShootingModeToastDisplayed = true;
			}
		}

		// Token: 0x040007D9 RID: 2009
		internal static KeymapCanvasWindow CanvasWindow = null;

		// Token: 0x040007DA RID: 2010
		internal static GuidanceWindow sGuidanceWindow = null;

		// Token: 0x040007DB RID: 2011
		internal static string mComboEvents = string.Empty;

		// Token: 0x040007DC RID: 2012
		internal static bool sIsCancelComboClicked = false;

		// Token: 0x040007DD RID: 2013
		internal static bool sIsSaveComboClicked = false;

		// Token: 0x040007DE RID: 2014
		internal static bool sIsComboRecordingOn = false;

		// Token: 0x040007DF RID: 2015
		internal static DualTextBlockControl sGamepadDualTextbox = null;

		// Token: 0x040007E0 RID: 2016
		internal static IMapTextBox CurrentIMapTextBox = null;

		// Token: 0x040007E1 RID: 2017
		internal static Dictionary<string, bool> dictGamepadEligibility = new Dictionary<string, bool>();

		// Token: 0x040007E2 RID: 2018
		internal static string sShootingModeKey = "F1";

		// Token: 0x040007E3 RID: 2019
		public static Dictionary<string, bool> pressedGamepadKeyList = new Dictionary<string, bool>();

		// Token: 0x040007E4 RID: 2020
		public static string sGameControlsEnabledDisabledArray = string.Empty;

		// Token: 0x040007E5 RID: 2021
		public static string sOldGameControlsEnabledDisabledArray = string.Empty;

		// Token: 0x040007E6 RID: 2022
		public static List<List<CanvasElement>> listCanvasElement = new List<List<CanvasElement>>();

		// Token: 0x040007E7 RID: 2023
		internal static bool sIsInScriptEditingMode = false;

		// Token: 0x040007E8 RID: 2024
		internal static Dictionary<MainWindow, KeymapCanvasWindow> dictOverlayWindow = new Dictionary<MainWindow, KeymapCanvasWindow>();

		// Token: 0x040007E9 RID: 2025
		internal static CanvasElement sDragCanvasElement;

		// Token: 0x040007EA RID: 2026
		public static string ParserVersion = "16";

		// Token: 0x040007EB RID: 2027
		internal static string sPackageName = string.Empty;

		// Token: 0x040007EC RID: 2028
		internal static GuidanceVideoType sVideoMode = GuidanceVideoType.Default;

		// Token: 0x040007ED RID: 2029
		internal static bool sIsDeveloperModeOn = false;

		// Token: 0x040007EE RID: 2030
		internal static List<OnBoardingPopupWindow> onBoardingPopupWindows = new List<OnBoardingPopupWindow>();
	}
}
