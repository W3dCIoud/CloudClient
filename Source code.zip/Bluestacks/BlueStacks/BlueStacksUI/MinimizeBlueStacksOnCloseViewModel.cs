﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using BlueStacks.Common;
using GalaSoft.MvvmLight.Command;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200004E RID: 78
	public class MinimizeBlueStacksOnCloseViewModel : INotifyPropertyChanged
	{
		// Token: 0x14000002 RID: 2
		// (add) Token: 0x06000398 RID: 920 RVA: 0x00019D14 File Offset: 0x00017F14
		// (remove) Token: 0x06000399 RID: 921 RVA: 0x00019D4C File Offset: 0x00017F4C
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x17000143 RID: 323
		// (get) Token: 0x0600039A RID: 922 RVA: 0x00004786 File Offset: 0x00002986
		// (set) Token: 0x0600039B RID: 923 RVA: 0x0000478E File Offset: 0x0000298E
		public MainWindow ParentWindow { get; set; }

		// Token: 0x17000144 RID: 324
		// (get) Token: 0x0600039C RID: 924 RVA: 0x00004797 File Offset: 0x00002997
		// (set) Token: 0x0600039D RID: 925 RVA: 0x0000479F File Offset: 0x0000299F
		public bool IsDoNotShowAgainChkBoxChecked
		{
			get
			{
				return this.mIsDoNotShowAgainChkBoxChecked;
			}
			set
			{
				this.mIsDoNotShowAgainChkBoxChecked = value;
				this.NotifyPropertyChanged("IsDoNotShowAgainChkBoxChecked");
			}
		}

		// Token: 0x17000145 RID: 325
		// (get) Token: 0x0600039E RID: 926 RVA: 0x000047B3 File Offset: 0x000029B3
		// (set) Token: 0x0600039F RID: 927 RVA: 0x000047BB File Offset: 0x000029BB
		public bool IsQuitBluestacksChecked
		{
			get
			{
				return this.mIsQuitBluestacksChecked;
			}
			set
			{
				this.mIsQuitBluestacksChecked = value;
				this.NotifyPropertyChanged("IsQuitBluestacksChecked");
			}
		}

		// Token: 0x17000146 RID: 326
		// (get) Token: 0x060003A0 RID: 928 RVA: 0x000047CF File Offset: 0x000029CF
		// (set) Token: 0x060003A1 RID: 929 RVA: 0x000047D7 File Offset: 0x000029D7
		public bool IsMinimizeBlueStacksRadioBtnChecked
		{
			get
			{
				return this.mIsMinimizeBlueStacksRadioBtnChecked;
			}
			set
			{
				this.mIsMinimizeBlueStacksRadioBtnChecked = value;
				this.NotifyPropertyChanged("IsMinimizeBlueStacksRadioBtnChecked");
			}
		}

		// Token: 0x17000147 RID: 327
		// (get) Token: 0x060003A2 RID: 930 RVA: 0x000047EB File Offset: 0x000029EB
		public static Dictionary<string, string> LocaleModel
		{
			get
			{
				return BlueStacksUIBinding.Instance.LocaleModel;
			}
		}

		// Token: 0x17000148 RID: 328
		// (get) Token: 0x060003A3 RID: 931 RVA: 0x000047F7 File Offset: 0x000029F7
		public static Dictionary<string, Brush> ColorModel
		{
			get
			{
				return BlueStacksUIBinding.Instance.ColorModel;
			}
		}

		// Token: 0x17000149 RID: 329
		// (get) Token: 0x060003A4 RID: 932 RVA: 0x00004803 File Offset: 0x00002A03
		// (set) Token: 0x060003A5 RID: 933 RVA: 0x0000480B File Offset: 0x00002A0B
		public ICommand CloseControlCommand { get; set; }

		// Token: 0x1700014A RID: 330
		// (get) Token: 0x060003A6 RID: 934 RVA: 0x00004814 File Offset: 0x00002A14
		// (set) Token: 0x060003A7 RID: 935 RVA: 0x0000481C File Offset: 0x00002A1C
		public ICommand MinimizeCommand { get; set; }

		// Token: 0x1700014B RID: 331
		// (get) Token: 0x060003A8 RID: 936 RVA: 0x00004825 File Offset: 0x00002A25
		// (set) Token: 0x060003A9 RID: 937 RVA: 0x0000482D File Offset: 0x00002A2D
		public ICommand QuitCommand { get; set; }

		// Token: 0x060003AA RID: 938 RVA: 0x00004836 File Offset: 0x00002A36
		private void NotifyPropertyChanged(string propertyName)
		{
			if (this.PropertyChanged != null)
			{
				this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x060003AB RID: 939 RVA: 0x00004852 File Offset: 0x00002A52
		public MinimizeBlueStacksOnCloseViewModel(MainWindow window)
		{
			this.ParentWindow = window;
			this.Init();
		}

		// Token: 0x060003AC RID: 940 RVA: 0x00019D84 File Offset: 0x00017F84
		private void Init()
		{
			this.CloseControlCommand = new RelayCommand<UserControl>(new Action<UserControl>(this.Close), false);
			this.MinimizeCommand = new RelayCommand<UserControl>(new Action<UserControl>(this.MinimizeBluestacksHandler), false);
			this.QuitCommand = new RelayCommand(new Action(this.QuitBlueStacks), false);
			if (this.ParentWindow.EngineInstanceRegistry.IsMinimizeSelectedOnReceiveGameNotificationPopup)
			{
				this.IsMinimizeBlueStacksRadioBtnChecked = true;
				return;
			}
			this.IsQuitBluestacksChecked = true;
		}

		// Token: 0x060003AD RID: 941 RVA: 0x0000486E File Offset: 0x00002A6E
		private void DoNotShowAgainPromptHandler()
		{
			if (this.IsDoNotShowAgainChkBoxChecked)
			{
				this.ParentWindow.EngineInstanceRegistry.IsShowMinimizeBlueStacksPopupOnClose = false;
			}
		}

		// Token: 0x060003AE RID: 942 RVA: 0x00019DFC File Offset: 0x00017FFC
		private void QuitBlueStacks()
		{
			Stats.SendCommonClientStatsAsync("minimize_bluestacks_notification", "BlueStacks_exit_popup", this.ParentWindow.mVmName, "", "", "");
			this.ParentWindow.EngineInstanceRegistry.IsMinimizeSelectedOnReceiveGameNotificationPopup = false;
			this.DoNotShowAgainPromptHandler();
			this.ParentWindow.CloseWindowHandler();
		}

		// Token: 0x060003AF RID: 943 RVA: 0x00019E54 File Offset: 0x00018054
		private void MinimizeBluestacksHandler(UserControl control)
		{
			Stats.SendCommonClientStatsAsync("minimize_bluestacks_notification", "BlueStacks_minimize_popup", this.ParentWindow.mVmName, "", "", "");
			this.ParentWindow.EngineInstanceRegistry.IsMinimizeSelectedOnReceiveGameNotificationPopup = true;
			this.DoNotShowAgainPromptHandler();
			this.Close(control);
			this.CloseAllTabs();
			BlueStacksUIUtils.HideUnhideParentWindow(true, this.ParentWindow);
			this.HandlingForAutoHide();
		}

		// Token: 0x060003B0 RID: 944 RVA: 0x00019EC0 File Offset: 0x000180C0
		private void HandlingForAutoHide()
		{
			Logger.Info("In HandlingForAutoHide");
			this.ParentWindow.mIsMinimizedThroughCloseButton = true;
			Logger.Debug("In sIsMinimizedThroughCloseButton =" + this.ParentWindow.mIsMinimizedThroughCloseButton.ToString());
			HTTPUtils.SendRequestToAgentAsync("overrideDesktopNotificationSettings", new Dictionary<string, string>
			{
				{
					"override",
					"True"
				}
			}, this.ParentWindow.mVmName, 0, null, false, 1, 0);
		}

		// Token: 0x060003B1 RID: 945 RVA: 0x00019F34 File Offset: 0x00018134
		private void CloseAllTabs()
		{
			Dictionary<string, AppTabButton> dictionary = new Dictionary<string, AppTabButton>();
			foreach (KeyValuePair<string, AppTabButton> keyValuePair in this.ParentWindow.mTopBar.mAppTabButtons.mDictTabs)
			{
				dictionary.Add(keyValuePair.Key, keyValuePair.Value);
			}
			foreach (KeyValuePair<string, AppTabButton> keyValuePair2 in dictionary)
			{
				this.ParentWindow.mTopBar.mAppTabButtons.CloseTabAfterQuitPopup(keyValuePair2.Key, true, false);
			}
		}

		// Token: 0x060003B2 RID: 946 RVA: 0x0001A000 File Offset: 0x00018200
		private void Close(UserControl control)
		{
			try
			{
				BlueStacksUIUtils.CloseContainerWindow(control);
				this.ParentWindow.HideDimOverlay();
				control.Visibility = Visibility.Hidden;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while trying to close CloseBluestacksControl from dimoverlay " + ex.ToString());
			}
		}

		// Token: 0x040001E7 RID: 487
		private bool mIsDoNotShowAgainChkBoxChecked;

		// Token: 0x040001E8 RID: 488
		private bool mIsQuitBluestacksChecked;

		// Token: 0x040001E9 RID: 489
		private bool mIsMinimizeBlueStacksRadioBtnChecked = true;
	}
}
