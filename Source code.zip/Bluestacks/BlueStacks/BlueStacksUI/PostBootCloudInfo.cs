﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200003A RID: 58
	public class PostBootCloudInfo
	{
		// Token: 0x17000120 RID: 288
		// (get) Token: 0x06000303 RID: 771 RVA: 0x00004047 File Offset: 0x00002247
		// (set) Token: 0x06000304 RID: 772 RVA: 0x0000404F File Offset: 0x0000224F
		public AppPackageListObject GameNotificationAppPackages { get; set; }

		// Token: 0x17000121 RID: 289
		// (get) Token: 0x06000305 RID: 773 RVA: 0x00004058 File Offset: 0x00002258
		// (set) Token: 0x06000306 RID: 774 RVA: 0x00004060 File Offset: 0x00002260
		public OnBoardingInfo OnBoardingInfo { get; set; } = new OnBoardingInfo();

		// Token: 0x17000122 RID: 290
		// (get) Token: 0x06000307 RID: 775 RVA: 0x00004069 File Offset: 0x00002269
		// (set) Token: 0x06000308 RID: 776 RVA: 0x00004071 File Offset: 0x00002271
		public AppSpecificCustomCursorInfo AppSpecificCustomCursorInfo { get; set; } = new AppSpecificCustomCursorInfo();
	}
}
