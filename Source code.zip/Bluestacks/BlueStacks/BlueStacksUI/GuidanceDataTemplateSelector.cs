﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000044 RID: 68
	public class GuidanceDataTemplateSelector : DataTemplateSelector
	{
		// Token: 0x0600033F RID: 831 RVA: 0x000187B0 File Offset: 0x000169B0
		public override DataTemplate SelectTemplate(object item, DependencyObject container)
		{
			FrameworkElement frameworkElement = container as FrameworkElement;
			if (frameworkElement != null && item != null)
			{
				if (item is GuidanceViewModel)
				{
					return frameworkElement.FindResource("GuidanceViewModelTemplate") as DataTemplate;
				}
				if (item is GuidanceEditTextModel)
				{
					return frameworkElement.FindResource("GuidanceEditTextModelTemplate") as DataTemplate;
				}
				if (item is GuidanceEditDecimalModel)
				{
					return frameworkElement.FindResource("GuidanceEditDecimalModelTemplate") as DataTemplate;
				}
				if (item is GuidanceCategoryViewModel)
				{
					return frameworkElement.FindResource("GuidanceCategoryViewModelTemplate") as DataTemplate;
				}
				if (item is GuidanceCategoryEditModel)
				{
					return frameworkElement.FindResource("GuidanceCategoryEditModelTemplate") as DataTemplate;
				}
			}
			return null;
		}
	}
}
