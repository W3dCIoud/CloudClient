﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000121 RID: 289
	public class KeymapExtraSettingWindow : CustomPopUp, IComponentConnector
	{
		// Token: 0x17000202 RID: 514
		// (get) Token: 0x06000B83 RID: 2947 RVA: 0x00009253 File Offset: 0x00007453
		public List<IMAction> ListAction { get; } = new List<IMAction>();

		// Token: 0x06000B84 RID: 2948 RVA: 0x00045B70 File Offset: 0x00043D70
		public KeymapExtraSettingWindow(MainWindow window)
		{
			this.InitializeComponent();
			base.IsFocusOnMouseClick = true;
			this.ParentWindow = window;
			this.mStackPanel = (this.mScrollBar.Content as StackPanel);
			this.AddGuidanceCategories();
			this.AddDualTextBlockControl();
			this.SetPopupDraggableProperty();
		}

		// Token: 0x06000B85 RID: 2949 RVA: 0x0000925B File Offset: 0x0000745B
		private void AddDualTextBlockControl()
		{
			this.AddDualTextBlockControlToMOBAPanel();
			this.AddDualTextBlockControlToLookAroundPanel();
			this.AddDualTextBlockControlToShootGBPanel();
			this.AddDualTextBlockControlToMOBASkillCancelGBPanel();
			this.AddDualTextBlockControlToGroupBox();
		}

		// Token: 0x06000B86 RID: 2950 RVA: 0x00045BEC File Offset: 0x00043DEC
		private void AddDualTextBlockControlToGroupBox()
		{
			this.mEnableConditionTB = new DualTextBlockControl(this.ParentWindow)
			{
				Margin = new Thickness(0.0, 5.0, 0.0, 0.0),
				VerticalAlignment = VerticalAlignment.Top,
				HorizontalAlignment = HorizontalAlignment.Stretch,
				Height = 32.0
			};
			this.mEnableConditionGB.Content = this.mEnableConditionTB;
			this.mNoteTB = new DualTextBlockControl(this.ParentWindow)
			{
				Margin = new Thickness(0.0, 5.0, 0.0, 0.0),
				VerticalAlignment = VerticalAlignment.Top,
				HorizontalAlignment = HorizontalAlignment.Stretch,
				Height = 32.0
			};
			this.mNoteGB.Content = this.mNoteTB;
			this.mStartConditionTB = new DualTextBlockControl(this.ParentWindow)
			{
				Margin = new Thickness(0.0, 5.0, 0.0, 0.0),
				VerticalAlignment = VerticalAlignment.Top,
				HorizontalAlignment = HorizontalAlignment.Stretch,
				Height = 32.0
			};
			this.mStartConditionGB.Content = this.mStartConditionTB;
		}

		// Token: 0x06000B87 RID: 2951 RVA: 0x00045D44 File Offset: 0x00043F44
		internal void AddDualTextBlockControlToMOBASkillCancelGBPanel()
		{
			this.mMOBASkillCancelDTB = new DualTextBlockControl(this.ParentWindow)
			{
				Margin = new Thickness(0.0, 5.0, 0.0, 0.0)
			};
			this.mMOBASkillCancelGBPanel.Children.Add(this.mMOBASkillCancelDTB);
		}

		// Token: 0x06000B88 RID: 2952 RVA: 0x00045DA8 File Offset: 0x00043FA8
		private void AddDualTextBlockControlToShootGBPanel()
		{
			this.mShootXDTB = new DualTextBlockControl(this.ParentWindow)
			{
				Margin = new Thickness(0.0, 5.0, 0.0, 0.0)
			};
			this.mShootYDTB = new DualTextBlockControl(this.ParentWindow)
			{
				Margin = new Thickness(0.0, 5.0, 0.0, 0.0)
			};
			this.mShootDTB = new DualTextBlockControl(this.ParentWindow)
			{
				Margin = new Thickness(0.0, 5.0, 0.0, 0.0)
			};
			this.mShootGBPanel.Children.Add(this.mShootXDTB);
			this.mShootGBPanel.Children.Add(this.mShootYDTB);
			this.mShootGBPanel.Children.Add(this.mShootDTB);
		}

		// Token: 0x06000B89 RID: 2953 RVA: 0x00045EBC File Offset: 0x000440BC
		private void AddDualTextBlockControlToLookAroundPanel()
		{
			this.mLookAroundXDTB = new DualTextBlockControl(this.ParentWindow)
			{
				Margin = new Thickness(0.0, 5.0, 0.0, 0.0)
			};
			this.mLookAroundYDTB = new DualTextBlockControl(this.ParentWindow)
			{
				Margin = new Thickness(0.0, 5.0, 0.0, 0.0)
			};
			this.mLookAroundDTB = new DualTextBlockControl(this.ParentWindow)
			{
				Margin = new Thickness(0.0, 5.0, 0.0, 0.0)
			};
			this.mLookAroundPanel.Children.Add(this.mLookAroundXDTB);
			this.mLookAroundPanel.Children.Add(this.mLookAroundYDTB);
			this.mLookAroundPanel.Children.Add(this.mLookAroundDTB);
		}

		// Token: 0x06000B8A RID: 2954 RVA: 0x00045FD0 File Offset: 0x000441D0
		private void AddDualTextBlockControlToMOBAPanel()
		{
			this.mMOBADpadOriginXDTB = new DualTextBlockControl(this.ParentWindow)
			{
				Margin = new Thickness(0.0, 5.0, 0.0, 0.0)
			};
			this.mMOBADpadOriginYDTB = new DualTextBlockControl(this.ParentWindow)
			{
				Margin = new Thickness(0.0, 5.0, 0.0, 0.0)
			};
			this.mMOBADpadCharSpeedDTB = new DualTextBlockControl(this.ParentWindow)
			{
				Margin = new Thickness(0.0, 5.0, 0.0, 0.0)
			};
			this.mMOBADpadKeyDTB = new DualTextBlockControl(this.ParentWindow)
			{
				Margin = new Thickness(0.0, 5.0, 0.0, 0.0)
			};
			this.mMOBAPanel.Children.Add(this.mMOBADpadOriginXDTB);
			this.mMOBAPanel.Children.Add(this.mMOBADpadOriginYDTB);
			this.mMOBAPanel.Children.Add(this.mMOBADpadCharSpeedDTB);
			this.mMOBAPanel.Children.Add(this.mMOBADpadKeyDTB);
		}

		// Token: 0x06000B8B RID: 2955 RVA: 0x0004613C File Offset: 0x0004433C
		private void AddGuidanceCategories()
		{
			this.mListSuggestions.Clear();
			foreach (IMAction imaction in this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls)
			{
				string item;
				if (string.Equals(imaction.GuidanceCategory, "MISC", StringComparison.InvariantCulture))
				{
					item = LocaleStrings.GetLocalizedString("STRING_" + imaction.GuidanceCategory);
				}
				else
				{
					item = this.ParentWindow.SelectedConfig.GetUIString(imaction.GuidanceCategory);
				}
				if (!this.mListSuggestions.Contains(item))
				{
					this.mListSuggestions.Add(item);
				}
			}
		}

		// Token: 0x06000B8C RID: 2956 RVA: 0x0000927B File Offset: 0x0000747B
		private void AddListOfSuggestions()
		{
			this.mGuidanceCategoryComboBox.AddSuggestions(this.mListSuggestions);
		}

		// Token: 0x06000B8D RID: 2957 RVA: 0x0000928E File Offset: 0x0000748E
		private void CloseButton_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			base.IsOpen = false;
		}

		// Token: 0x06000B8E RID: 2958 RVA: 0x00046200 File Offset: 0x00044400
		private void DeleteButton_Click(object sender, RoutedEventArgs e)
		{
			KMManager.CheckAndCreateNewScheme();
			KeymapCanvasWindow.sIsDirty = true;
			foreach (IMAction item in this.ListAction)
			{
				this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Remove(item);
			}
			(this.mCanvasElement.Parent as Canvas).Children.Remove(this.mCanvasElement);
			base.IsOpen = false;
			foreach (KeyValuePair<IMAction, CanvasElement> keyValuePair in KMManager.CanvasWindow.dictCanvasElement)
			{
				if (keyValuePair.Key.ParentAction == this.ListAction.First<IMAction>())
				{
					keyValuePair.Value.RemoveAction("");
					this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Remove(keyValuePair.Value.ListActionItem.First<IMAction>());
				}
			}
		}

		// Token: 0x06000B8F RID: 2959 RVA: 0x00046330 File Offset: 0x00044530
		private void SetPopupDraggableProperty()
		{
			try
			{
				KeymapExtraSettingWindow.<>c__DisplayClass34_0 CS$<>8__locals1 = new KeymapExtraSettingWindow.<>c__DisplayClass34_0();
				CS$<>8__locals1.Thumb = new Thumb
				{
					Width = 0.0,
					Height = 0.0
				};
				this.mHeaderGrid.Children.Add(CS$<>8__locals1.Thumb);
				this.mHeaderGrid.MouseLeftButtonDown -= CS$<>8__locals1.<SetPopupDraggableProperty>g__mouseDownHandler|0;
				this.mHeaderGrid.MouseLeftButtonDown += CS$<>8__locals1.<SetPopupDraggableProperty>g__mouseDownHandler|0;
				CS$<>8__locals1.Thumb.DragDelta -= this.<SetPopupDraggableProperty>g__deltaEventHandler|34_1;
				CS$<>8__locals1.Thumb.DragDelta += this.<SetPopupDraggableProperty>g__deltaEventHandler|34_1;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in draggable popup: " + ex.ToString());
			}
		}

		// Token: 0x06000B90 RID: 2960 RVA: 0x0004640C File Offset: 0x0004460C
		internal void Init(bool isGamepadTabSelected = false)
		{
			bool sIsDirty = KeymapCanvasWindow.sIsDirty;
			this.mDictGroupBox.Clear();
			this.mDummyGrid.Children.Clear();
			this.mStackPanel.Children.Clear();
			this.mDictDualTextBox.Clear();
			BlueStacksUIBinding.Bind(this.mHeader, Constants.ImapLocaleStringsConstant + this.ListAction.First<IMAction>().Type.ToString() + "_Settings", "");
			if (KMManager.sIsDeveloperModeOn)
			{
				this.mEnableConditionTB.Visibility = Visibility.Visible;
				this.mEnableConditionGB.Visibility = Visibility.Visible;
				this.mEnableConditionTB.ActionItemProperty = "EnableCondition";
				this.mStartConditionTB.Visibility = Visibility.Visible;
				this.mStartConditionGB.Visibility = Visibility.Visible;
				this.mStartConditionTB.ActionItemProperty = "StartCondition";
				this.mNoteTB.Visibility = Visibility.Visible;
				this.mNoteGB.Visibility = Visibility.Visible;
				this.mNoteTB.ActionItemProperty = "Note";
			}
			this.AddListOfSuggestions();
			this.mStackPanel.Children.Add(this.mGuidanceCategory);
			this.mStackPanel.Children.Add(this.mTabsGrid);
			if (isGamepadTabSelected)
			{
				this.mKeyboardTabBorder.BorderThickness = new Thickness(1.0, 1.0, 0.0, 1.0);
				this.mKeyboardTabBorder.Background = Brushes.Transparent;
				BlueStacksUIBinding.BindColor(this.mKeyboardTabBorder, Border.BorderBrushProperty, "GuidanceKeyBorderBackgroundColor");
				BlueStacksUIBinding.BindColor(this.mGamepadTabBorder, Border.BackgroundProperty, "GuidanceKeyBorderBackgroundColor");
				this.mGamepadTabBorder.BorderThickness = new Thickness(0.0);
			}
			else
			{
				this.mGamepadTabBorder.BorderThickness = new Thickness(0.0, 1.0, 1.0, 1.0);
				this.mGamepadTabBorder.Background = Brushes.Transparent;
				BlueStacksUIBinding.BindColor(this.mKeyboardTabBorder, Border.BackgroundProperty, "GuidanceKeyBorderBackgroundColor");
				this.mKeyboardTabBorder.BorderThickness = new Thickness(0.0);
			}
			foreach (IMAction imaction in this.ListAction)
			{
				if (string.Equals(imaction.GuidanceCategory, "MISC", StringComparison.InvariantCulture))
				{
					this.mGuidanceCategoryComboBox.mAutoComboBox.Text = LocaleStrings.GetLocalizedString("STRING_" + imaction.GuidanceCategory);
				}
				else
				{
					this.mGuidanceCategoryComboBox.mAutoComboBox.Text = this.ParentWindow.SelectedConfig.GetUIString(imaction.GuidanceCategory);
				}
				if (KMManager.sIsDeveloperModeOn)
				{
					this.mEnableConditionGB.Visibility = Visibility.Visible;
					this.mEnableConditionTB.Visibility = Visibility.Visible;
					this.mEnableConditionTB.AddActionItem(imaction);
					this.mNoteGB.Visibility = Visibility.Visible;
					this.mNoteTB.Visibility = Visibility.Visible;
					this.mNoteTB.AddActionItem(imaction);
					this.mStartConditionGB.Visibility = Visibility.Visible;
					this.mStartConditionTB.Visibility = Visibility.Visible;
					this.mStartConditionTB.AddActionItem(imaction);
				}
				else
				{
					this.mEnableConditionGB.Visibility = Visibility.Collapsed;
					this.mStartConditionGB.Visibility = Visibility.Collapsed;
					this.mNoteGB.Visibility = Visibility.Collapsed;
				}
				foreach (KeyValuePair<string, PropertyInfo> item in IMAction.DictPopUpUIElements[imaction.Type])
				{
					if (string.Equals(item.Key, "IsMOBADpadEnabled", StringComparison.InvariantCultureIgnoreCase))
					{
						this.mStackPanel.Children.Add(this.mMOBAGB);
						this.mMOBACB.IsChecked = new bool?(Convert.ToBoolean(imaction[item.Key], CultureInfo.InvariantCulture));
						this.mMOBADpadCharSpeedDTB.IsEnabled = this.mMOBACB.IsChecked.Value;
						this.mMOBADpadCharSpeedDTB.mKeyPropertyNameTextBox.IsEnabled = false;
						this.mMOBADpadCharSpeedDTB.ActionItemProperty = "CharSpeed";
						this.mMOBADpadCharSpeedDTB.AddActionItem((imaction as Dpad).mMOBADpad);
						this.mMOBADpadOriginXDTB.IsEnabled = this.mMOBACB.IsChecked.Value;
						this.mMOBADpadOriginXDTB.mKeyPropertyNameTextBox.IsEnabled = false;
						this.mMOBADpadOriginXDTB.ActionItemProperty = "OriginX";
						this.mMOBADpadOriginXDTB.AddActionItem((imaction as Dpad).mMOBADpad);
						this.mMOBADpadOriginYDTB.IsEnabled = this.mMOBACB.IsChecked.Value;
						this.mMOBADpadOriginYDTB.mKeyPropertyNameTextBox.IsEnabled = false;
						this.mMOBADpadOriginYDTB.ActionItemProperty = "OriginY";
						this.mMOBADpadOriginYDTB.AddActionItem((imaction as Dpad).mMOBADpad);
						this.mMOBADpadKeyDTB.IsEnabled = this.mMOBACB.IsChecked.Value;
						this.mMOBADpadKeyDTB.mKeyPropertyNameTextBox.IsEnabled = false;
						this.mMOBADpadKeyDTB.mKeyTextBox.IsEnabled = false;
						this.mMOBADpadKeyDTB.ActionItemProperty = "KeyMove";
						this.mMOBADpadKeyDTB.AddActionItem((imaction as Dpad).mMOBADpad);
					}
					else if (string.Equals(item.Key, "IsCancelSkillEnabled", StringComparison.InvariantCultureIgnoreCase))
					{
						this.mStackPanel.Children.Add(this.mMOBASkillCancelGB);
						this.mMOBASkillCancelCB.IsChecked = new bool?(Convert.ToBoolean(imaction[item.Key], CultureInfo.InvariantCulture));
						this.mMOBASkillCancelDTB.IsEnabled = this.mMOBASkillCancelCB.IsChecked.Value;
						if (isGamepadTabSelected)
						{
							this.mMOBASkillCancelDTB.ActionItemProperty = "KeyCancel_alt1";
						}
						else
						{
							this.mMOBASkillCancelDTB.ActionItemProperty = "KeyCancel";
						}
						this.mMOBASkillCancelDTB.AddActionItem(imaction);
					}
					else if (string.Equals(item.Key, "IsLookAroundEnabled", StringComparison.InvariantCultureIgnoreCase))
					{
						this.mStackPanel.Children.Add(this.mLookAroundGB);
						this.mLookAroundCB.IsChecked = new bool?(Convert.ToBoolean(imaction[item.Key], CultureInfo.InvariantCulture));
						this.mLookAroundDTB.IsEnabled = this.mLookAroundCB.IsChecked.Value;
						this.mLookAroundDTB.ActionItemProperty = "KeyLookAround";
						this.mLookAroundDTB.AddActionItem(imaction);
						this.mLookAroundXDTB.IsEnabled = this.mLookAroundCB.IsChecked.Value;
						this.mLookAroundXDTB.mKeyPropertyNameTextBox.IsEnabled = false;
						this.mLookAroundXDTB.ActionItemProperty = "LookAroundX";
						this.mLookAroundXDTB.AddActionItem(imaction);
						this.mLookAroundYDTB.IsEnabled = this.mLookAroundCB.IsChecked.Value;
						this.mLookAroundYDTB.mKeyPropertyNameTextBox.IsEnabled = false;
						this.mLookAroundYDTB.ActionItemProperty = "LookAroundY";
						this.mLookAroundYDTB.AddActionItem(imaction);
					}
					else if (string.Equals(item.Key, "IsShootOnClickEnabled", StringComparison.InvariantCultureIgnoreCase))
					{
						this.mStackPanel.Children.Add(this.mShootGB);
						this.mShootCB.IsChecked = new bool?(Convert.ToBoolean(imaction[item.Key], CultureInfo.InvariantCulture));
						this.mShootDTB.IsEnabled = this.mShootCB.IsChecked.Value;
						this.mShootDTB.mKeyTextBox.IsEnabled = false;
						this.mShootDTB.ActionItemProperty = "KeyAction";
						this.mShootDTB.AddActionItem(imaction);
						this.mShootXDTB.IsEnabled = this.mShootCB.IsChecked.Value;
						this.mShootXDTB.mKeyPropertyNameTextBox.IsEnabled = false;
						this.mShootXDTB.ActionItemProperty = "LButtonX";
						this.mShootXDTB.AddActionItem(imaction);
						this.mShootYDTB.IsEnabled = this.mShootCB.IsChecked.Value;
						this.mShootYDTB.mKeyPropertyNameTextBox.IsEnabled = false;
						this.mShootYDTB.ActionItemProperty = "LButtonY";
						this.mShootYDTB.AddActionItem(imaction);
					}
					else if (string.Equals(item.Key, "ShowOnOverlay", StringComparison.InvariantCultureIgnoreCase))
					{
						this.mOverlayCB.IsChecked = new bool?(Convert.ToBoolean(imaction[item.Key], CultureInfo.InvariantCulture));
						this.mOverlayCB.Tag = item.Key;
						if (!this.mStackPanel.Children.Contains(this.mOverlayGB))
						{
							this.mStackPanel.Children.Add(this.mOverlayGB);
						}
					}
					else if (imaction.Type == KeyActionType.FreeLook && (string.Equals(item.Key, "Sensitivity", StringComparison.InvariantCultureIgnoreCase) || string.Equals(item.Key, "Speed", StringComparison.InvariantCultureIgnoreCase) || string.Equals(item.Key, "MouseAcceleration", StringComparison.InvariantCultureIgnoreCase)))
					{
						if (((FreeLook)imaction).DeviceType == 0)
						{
							if (string.Equals(item.Key, "Speed", StringComparison.InvariantCultureIgnoreCase))
							{
								this.AddFields(item, imaction);
							}
						}
						else if (string.Equals(item.Key, "Sensitivity", StringComparison.InvariantCultureIgnoreCase) || string.Equals(item.Key, "MouseAcceleration", StringComparison.InvariantCultureIgnoreCase))
						{
							this.AddFields(item, imaction);
						}
					}
					else if (isGamepadTabSelected)
					{
						if (item.Key.ToString(CultureInfo.InvariantCulture).EndsWith("_alt1", StringComparison.InvariantCulture) || !item.Key.ToString(CultureInfo.InvariantCulture).StartsWith("Key", StringComparison.InvariantCulture))
						{
							this.AddFields(item, imaction);
						}
					}
					else if (!item.Key.ToString(CultureInfo.InvariantCulture).EndsWith("_alt1", StringComparison.InvariantCulture))
					{
						this.AddFields(item, imaction);
					}
				}
				if (KMManager.sIsDeveloperModeOn && imaction.Type == KeyActionType.MOBASkill)
				{
					foreach (KeyValuePair<string, PropertyInfo> item2 in IMAction.sDictDevModeUIElements[imaction.Type])
					{
						if (isGamepadTabSelected)
						{
							if (item2.Key.ToString(CultureInfo.InvariantCulture).EndsWith("_alt1", StringComparison.InvariantCulture) || !item2.Key.ToString(CultureInfo.InvariantCulture).StartsWith("Key", StringComparison.InvariantCulture))
							{
								this.AddFields(item2, imaction);
							}
						}
						else if (!item2.Key.ToString(CultureInfo.InvariantCulture).EndsWith("_alt1", StringComparison.InvariantCulture))
						{
							this.AddFields(item2, imaction);
						}
					}
				}
			}
			if (KMManager.sIsDeveloperModeOn)
			{
				this.mStackPanel.Children.Add(this.mEnableConditionGB);
				this.mStackPanel.Children.Add(this.mNoteGB);
				this.mStackPanel.Children.Add(this.mStartConditionGB);
			}
			this.UpdateFieldsForMOBADpad();
			KeymapCanvasWindow.sIsDirty = sIsDirty;
		}

		// Token: 0x06000B91 RID: 2961 RVA: 0x00046FA8 File Offset: 0x000451A8
		private void AddFields(KeyValuePair<string, PropertyInfo> item, IMAction action)
		{
			bool isAddDirectionAttribute = false;
			object[] customAttributes = item.Value.GetCustomAttributes(typeof(CategoryAttribute), true);
			CategoryAttribute categoryAttribute = customAttributes[0] as CategoryAttribute;
			string category = categoryAttribute.Category;
			string text = categoryAttribute.Category + "~" + item.Key;
			customAttributes = item.Value.GetCustomAttributes(typeof(DescriptionAttribute), true);
			if (customAttributes.Length != 0 && (customAttributes[0] as DescriptionAttribute).Description.Contains("NotCommon"))
			{
				text = text + "~" + action.Direction.ToString();
				isAddDirectionAttribute = true;
			}
			GroupBox groupBox = this.GetGroupBox(category);
			if (this.mDictDualTextBox.ContainsKey(text))
			{
				this.mDictDualTextBox[text].AddActionItem(action);
				return;
			}
			DualTextBlockControl dualTextBlockControl = new DualTextBlockControl(this.ParentWindow)
			{
				IsAddDirectionAttribute = isAddDirectionAttribute,
				ActionItemProperty = item.Key
			};
			dualTextBlockControl.AddActionItem(action);
			if (string.Equals(item.Key, "GuidanceCategory", StringComparison.InvariantCultureIgnoreCase))
			{
				dualTextBlockControl.mKeyPropertyNameTextBox.IsEnabled = false;
				this.mStackPanel.Children.Remove(groupBox);
				this.mStackPanel.Children.Insert(0, groupBox);
			}
			(groupBox.Content as StackPanel).Children.Add(dualTextBlockControl);
			this.mDictDualTextBox[text] = dualTextBlockControl;
		}

		// Token: 0x06000B92 RID: 2962 RVA: 0x0004710C File Offset: 0x0004530C
		private GroupBox GetGroupBox(string category)
		{
			GroupBox groupBox;
			if (this.mDictGroupBox.ContainsKey(category))
			{
				groupBox = this.mDictGroupBox[category];
			}
			else
			{
				groupBox = new GroupBox();
				this.mDictGroupBox.Add(category, groupBox);
				groupBox.Header = LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + category);
				this.mStackPanel.Children.Add(groupBox);
				groupBox.Content = new StackPanel();
			}
			return groupBox;
		}

		// Token: 0x06000B93 RID: 2963 RVA: 0x00008CF2 File Offset: 0x00006EF2
		private void CustomPictureBox_MouseEnter(object sender, MouseEventArgs e)
		{
			base.Cursor = Cursors.Hand;
		}

		// Token: 0x06000B94 RID: 2964 RVA: 0x00009297 File Offset: 0x00007497
		private void CustomPictureBox_MouseLeave(object sender, MouseEventArgs e)
		{
			if (KMManager.CanvasWindow.mCanvasElement == null)
			{
				base.Cursor = Cursors.Arrow;
			}
		}

		// Token: 0x06000B95 RID: 2965 RVA: 0x00047180 File Offset: 0x00045380
		private void MOBAHeroCB_CheckedChanged(object sender, RoutedEventArgs e)
		{
			if (this.ListAction.Count > 0)
			{
				KMManager.CheckAndCreateNewScheme();
				this.mMOBADpadCharSpeedDTB.IsEnabled = this.mMOBACB.IsChecked.Value;
				this.mMOBADpadOriginXDTB.IsEnabled = this.mMOBACB.IsChecked.Value;
				this.mMOBADpadOriginYDTB.IsEnabled = this.mMOBACB.IsChecked.Value;
				this.mMOBADpadKeyDTB.IsEnabled = this.mMOBACB.IsChecked.Value;
				this.mMOBADpadKeyDTB.mKeyTextBox.IsEnabled = false;
				Dpad dpad = this.ListAction.First<IMAction>() as Dpad;
				if (this.mMOBACB.IsChecked.Value)
				{
					dpad.mMOBADpad.mDpad = dpad;
					dpad.mMOBADpad.ParentAction = dpad;
				}
				else if (dpad.IsMOBADpadEnabled)
				{
					MOBADpad.sListMOBADpad.Remove(dpad.mMOBADpad);
					if (KMManager.CanvasWindow.dictCanvasElement.ContainsKey(dpad.mMOBADpad))
					{
						KMManager.CanvasWindow.dictCanvasElement[dpad.mMOBADpad].RemoveAction("");
						KMManager.CanvasWindow.dictCanvasElement.Remove(dpad.mMOBADpad);
					}
					this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Remove(dpad.mMOBADpad);
					dpad.mMOBADpad.OriginX = (dpad.mMOBADpad.OriginY = -1.0);
				}
				this.UpdateFieldsForMOBADpad();
				KeymapCanvasWindow.sIsDirty = true;
			}
			if (this.mMOBAPB != null)
			{
				this.mMOBAPB.IsEnabled = this.mMOBACB.IsChecked.Value;
			}
		}

		// Token: 0x06000B96 RID: 2966 RVA: 0x0004734C File Offset: 0x0004554C
		private void MOBAHeroPictureBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
			KMManager.CheckAndCreateNewScheme();
			base.IsOpen = false;
			Dpad dpad = this.ListAction.First<IMAction>() as Dpad;
			if (KMManager.CanvasWindow.dictCanvasElement.ContainsKey(dpad.mMOBADpad))
			{
				CanvasElement element = KMManager.CanvasWindow.dictCanvasElement[dpad.mMOBADpad];
				KMManager.CanvasWindow.StartMoving(element, new Point(Canvas.GetLeft(element), Canvas.GetTop(element)));
				return;
			}
			dpad.mMOBADpad.X = dpad.X;
			dpad.mMOBADpad.Y = dpad.Y;
			KMManager.CheckAndCreateNewScheme();
			this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Add(dpad.mMOBADpad);
			this.AddUIInCanvas(dpad.mMOBADpad);
		}

		// Token: 0x06000B97 RID: 2967 RVA: 0x00047414 File Offset: 0x00045614
		private void UpdateFieldsForMOBADpad()
		{
			if (this.ListAction.First<IMAction>().Type == KeyActionType.Dpad && this.mMOBACB.IsChecked != null)
			{
				foreach (KeyValuePair<string, DualTextBlockControl> keyValuePair in this.mDictDualTextBox)
				{
					if (keyValuePair.Key.Contains("~Key"))
					{
						keyValuePair.Value.mKeyTextBox.IsEnabled = !this.mMOBACB.IsChecked.Value;
						keyValuePair.Value.mKeyPropertyNameTextBox.IsEnabled = !this.mMOBACB.IsChecked.Value;
						if (!keyValuePair.Value.mKeyTextBox.IsEnabled)
						{
							keyValuePair.Value.mKeyPropertyNameTextBox.Text = string.Empty;
							keyValuePair.Value.mKeyTextBox.Tag = string.Empty;
							keyValuePair.Value.mKeyTextBox.Text = string.Empty;
						}
					}
				}
			}
		}

		// Token: 0x06000B98 RID: 2968 RVA: 0x00047550 File Offset: 0x00045750
		private void MOBASkillCancelCB_CheckedChanged(object sender, RoutedEventArgs e)
		{
			if (this.ListAction.Count > 0)
			{
				KMManager.CheckAndCreateNewScheme();
				this.mMOBASkillCancelDTB.IsEnabled = this.mMOBASkillCancelCB.IsChecked.Value;
				MOBASkill mobaskill = this.ListAction.First<IMAction>() as MOBASkill;
				if (this.mMOBASkillCancelCB.IsChecked.Value)
				{
					mobaskill.mMOBASkillCancel = new MOBASkillCancel(mobaskill);
				}
				else if (mobaskill.IsCancelSkillEnabled)
				{
					if (KMManager.CanvasWindow.dictCanvasElement.ContainsKey(mobaskill.mMOBASkillCancel))
					{
						KMManager.CanvasWindow.dictCanvasElement[mobaskill.mMOBASkillCancel].RemoveAction("KeyCancel");
						KMManager.CanvasWindow.dictCanvasElement.Remove(mobaskill.mMOBASkillCancel);
						this.mMOBASkillCancelDTB.mKeyPropertyNameTextBox.Text = string.Empty;
					}
					mobaskill.CancelX = (mobaskill.CancelY = -1.0);
				}
				KeymapCanvasWindow.sIsDirty = true;
			}
			if (this.mMOBASkillCancelPB != null)
			{
				this.mMOBASkillCancelPB.IsEnabled = this.mMOBASkillCancelCB.IsChecked.Value;
			}
		}

		// Token: 0x06000B99 RID: 2969 RVA: 0x00047678 File Offset: 0x00045878
		private void MOBASkillCancelPictureBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
			KMManager.CheckAndCreateNewScheme();
			base.IsOpen = false;
			MOBASkill mobaskill = this.ListAction.First<IMAction>() as MOBASkill;
			if (KMManager.CanvasWindow.dictCanvasElement.ContainsKey(mobaskill.mMOBASkillCancel))
			{
				CanvasElement element = KMManager.CanvasWindow.dictCanvasElement[mobaskill.mMOBASkillCancel];
				KMManager.CanvasWindow.StartMoving(element, new Point(Canvas.GetLeft(element), Canvas.GetTop(element)));
				return;
			}
			this.AddUIInCanvas(mobaskill.mMOBASkillCancel);
		}

		// Token: 0x06000B9A RID: 2970 RVA: 0x000476F8 File Offset: 0x000458F8
		private void LookAroundCB_CheckedChanged(object sender, RoutedEventArgs e)
		{
			if (this.ListAction.Count > 0)
			{
				KMManager.CheckAndCreateNewScheme();
				this.mLookAroundXDTB.IsEnabled = this.mLookAroundCB.IsChecked.Value;
				this.mLookAroundYDTB.IsEnabled = this.mLookAroundCB.IsChecked.Value;
				this.mLookAroundDTB.IsEnabled = this.mLookAroundCB.IsChecked.Value;
				Pan pan = this.ListAction.First<IMAction>() as Pan;
				if (this.mLookAroundCB.IsChecked.Value)
				{
					pan.mLookAround = new LookAround(pan);
				}
				else if (pan.IsLookAroundEnabled)
				{
					if (KMManager.CanvasWindow.dictCanvasElement.ContainsKey(pan.mLookAround))
					{
						KMManager.CanvasWindow.dictCanvasElement[pan.mLookAround].RemoveAction("KeyLookAround");
						KMManager.CanvasWindow.dictCanvasElement.Remove(pan.mLookAround);
						this.mLookAroundDTB.mKeyPropertyNameTextBox.Text = string.Empty;
					}
					pan.LookAroundX = (pan.LookAroundY = -1.0);
				}
				KeymapCanvasWindow.sIsDirty = true;
			}
			if (this.mLookAroundPB != null)
			{
				this.mLookAroundPB.IsEnabled = this.mLookAroundCB.IsChecked.Value;
			}
		}

		// Token: 0x06000B9B RID: 2971 RVA: 0x0004785C File Offset: 0x00045A5C
		private void LookAroundPictureBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
			KMManager.CheckAndCreateNewScheme();
			base.IsOpen = false;
			Pan pan = this.ListAction.First<IMAction>() as Pan;
			if (KMManager.CanvasWindow.dictCanvasElement.ContainsKey(pan.mLookAround))
			{
				CanvasElement element = KMManager.CanvasWindow.dictCanvasElement[pan.mLookAround];
				KMManager.CanvasWindow.StartMoving(element, new Point(Canvas.GetLeft(element), Canvas.GetTop(element)));
				return;
			}
			this.AddUIInCanvas(pan.mLookAround);
		}

		// Token: 0x06000B9C RID: 2972 RVA: 0x000478DC File Offset: 0x00045ADC
		private void ShootCB_CheckedChanged(object sender, RoutedEventArgs e)
		{
			if (this.ListAction.Count > 0)
			{
				KMManager.CheckAndCreateNewScheme();
				this.mShootXDTB.IsEnabled = this.mShootCB.IsChecked.Value;
				this.mShootYDTB.IsEnabled = this.mShootCB.IsChecked.Value;
				this.mShootDTB.IsEnabled = this.mShootCB.IsChecked.Value;
				Pan pan = this.ListAction.First<IMAction>() as Pan;
				if (this.mShootCB.IsChecked.Value)
				{
					pan.mPanShoot = new PanShoot(pan);
				}
				else if (pan.IsShootOnClickEnabled)
				{
					if (KMManager.CanvasWindow.dictCanvasElement.ContainsKey(pan.mPanShoot))
					{
						KMManager.CanvasWindow.dictCanvasElement[pan.mPanShoot].RemoveAction("KeyAction");
						KMManager.CanvasWindow.dictCanvasElement.Remove(pan.mPanShoot);
						this.mShootDTB.mKeyPropertyNameTextBox.Text = string.Empty;
					}
					pan.LButtonX = (pan.LButtonY = -1.0);
				}
				KeymapCanvasWindow.sIsDirty = true;
			}
			if (this.mShootPB != null)
			{
				this.mShootPB.IsEnabled = this.mShootCB.IsChecked.Value;
			}
		}

		// Token: 0x06000B9D RID: 2973 RVA: 0x00047A40 File Offset: 0x00045C40
		private void ShootPictureBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
			KMManager.CheckAndCreateNewScheme();
			base.IsOpen = false;
			Pan pan = this.ListAction.First<IMAction>() as Pan;
			if (KMManager.CanvasWindow.dictCanvasElement.ContainsKey(pan.mPanShoot))
			{
				CanvasElement element = KMManager.CanvasWindow.dictCanvasElement[pan.mPanShoot];
				KMManager.CanvasWindow.StartMoving(element, new Point(Canvas.GetLeft(element), Canvas.GetTop(element)));
				return;
			}
			this.AddUIInCanvas(pan.mPanShoot);
		}

		// Token: 0x06000B9E RID: 2974 RVA: 0x00047AC0 File Offset: 0x00045CC0
		private void mOverlayCB_Checked(object sender, RoutedEventArgs e)
		{
			if (this.ListAction.Count > 0)
			{
				KMManager.CheckAndCreateNewScheme();
				foreach (IMAction imaction in this.ListAction)
				{
					imaction.IsVisibleInOverlay = true;
				}
				KeymapCanvasWindow.sIsDirty = true;
			}
		}

		// Token: 0x06000B9F RID: 2975 RVA: 0x00047B2C File Offset: 0x00045D2C
		private void mOverlayCB_Unchecked(object sender, RoutedEventArgs e)
		{
			KMManager.CheckAndCreateNewScheme();
			if (this.ListAction.Count > 0)
			{
				foreach (IMAction imaction in this.ListAction)
				{
					imaction.IsVisibleInOverlay = false;
				}
			}
			KeymapCanvasWindow.sIsDirty = true;
		}

		// Token: 0x06000BA0 RID: 2976 RVA: 0x000092B0 File Offset: 0x000074B0
		private void AddUIInCanvas(IMAction hero)
		{
			base.Cursor = Cursors.Hand;
			KMManager.GetCanvasElement(this.ParentWindow, hero, this.mCanvas, true);
		}

		// Token: 0x06000BA1 RID: 2977 RVA: 0x00008C87 File Offset: 0x00006E87
		private void mCanvas_PreviewMouseMove(object sender, MouseEventArgs e)
		{
			KMManager.RepositionCanvasElement();
		}

		// Token: 0x06000BA2 RID: 2978 RVA: 0x00008C8E File Offset: 0x00006E8E
		private void mCanvas_MouseUp(object sender, MouseButtonEventArgs e)
		{
			base.Cursor = Cursors.Arrow;
			KMManager.ClearElement();
		}

		// Token: 0x06000BA3 RID: 2979 RVA: 0x00047B98 File Offset: 0x00045D98
		private void mGamepadTabBorder_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			try
			{
				KMManager.CheckAndCreateNewScheme();
				foreach (IMAction imaction in this.ListAction)
				{
					if (!string.Equals(imaction.GuidanceCategory, this.mGuidanceCategoryComboBox.mAutoComboBox.Text, StringComparison.InvariantCulture))
					{
						imaction.GuidanceCategory = this.mGuidanceCategoryComboBox.mAutoComboBox.Text;
						KeymapCanvasWindow.sIsDirty = true;
						this.ParentWindow.SelectedConfig.AddString(imaction.GuidanceCategory);
					}
				}
				this.mGamepadTabBorder.BorderThickness = new Thickness(0.0, 1.0, 1.0, 1.0);
				this.mGamepadTabBorder.Background = Brushes.Transparent;
				BlueStacksUIBinding.BindColor(this.mGamepadTabBorder, Border.BorderBrushProperty, "GuidanceKeyBorderBackgroundColor");
				BlueStacksUIBinding.BindColor(this.mKeyboardTabBorder, Border.BackgroundProperty, "GuidanceKeyBorderBackgroundColor");
				this.mKeyboardTabBorder.BorderThickness = new Thickness(0.0);
				this.AddGuidanceCategories();
				this.Init(true);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in switching to Gamepad tab: " + ex.ToString());
			}
		}

		// Token: 0x06000BA4 RID: 2980 RVA: 0x00047D0C File Offset: 0x00045F0C
		private void mKeyboardTabBorder_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			try
			{
				KMManager.CheckAndCreateNewScheme();
				foreach (IMAction imaction in this.ListAction)
				{
					if (!string.Equals(imaction.GuidanceCategory, this.mGuidanceCategoryComboBox.mAutoComboBox.Text, StringComparison.InvariantCulture))
					{
						imaction.GuidanceCategory = this.mGuidanceCategoryComboBox.mAutoComboBox.Text;
						KeymapCanvasWindow.sIsDirty = true;
						this.ParentWindow.SelectedConfig.AddString(imaction.GuidanceCategory);
					}
				}
				this.AddGuidanceCategories();
				this.mKeyboardTabBorder.BorderThickness = new Thickness(1.0, 1.0, 0.0, 1.0);
				this.mKeyboardTabBorder.Background = Brushes.Transparent;
				BlueStacksUIBinding.BindColor(this.mGamepadTabBorder, Border.BackgroundProperty, "GuidanceKeyBorderBackgroundColor");
				this.mGamepadTabBorder.BorderThickness = new Thickness(0.0);
				this.Init(false);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in switching to Keyboard tab: " + ex.ToString());
			}
		}

		// Token: 0x06000BA5 RID: 2981 RVA: 0x00047E6C File Offset: 0x0004606C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/keymapextrasettingwindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000BA6 RID: 2982 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000BA7 RID: 2983 RVA: 0x00047E9C File Offset: 0x0004609C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mHeaderGrid = (Grid)target;
				return;
			case 2:
				this.mHeader = (TextBlock)target;
				return;
			case 3:
				((CustomPictureBox)target).PreviewMouseLeftButtonDown += this.CloseButton_MouseLeftButtonDown;
				return;
			case 4:
				this.mScrollBar = (CustomScrollViewer)target;
				return;
			case 5:
				this.mDeleteButton = (CustomButton)target;
				this.mDeleteButton.Click += this.DeleteButton_Click;
				return;
			case 6:
				this.mDummyGrid = (Grid)target;
				return;
			case 7:
				this.mMOBAGB = (GroupBox)target;
				return;
			case 8:
				this.mMOBAPanel = (StackPanel)target;
				return;
			case 9:
				this.mMOBACB = (CustomCheckbox)target;
				this.mMOBACB.Checked += this.MOBAHeroCB_CheckedChanged;
				this.mMOBACB.Unchecked += this.MOBAHeroCB_CheckedChanged;
				return;
			case 10:
				this.mMOBAPB = (CustomPictureBox)target;
				this.mMOBAPB.MouseEnter += this.CustomPictureBox_MouseEnter;
				this.mMOBAPB.MouseLeave += this.CustomPictureBox_MouseLeave;
				this.mMOBAPB.MouseDown += this.MOBAHeroPictureBox_MouseDown;
				return;
			case 11:
				this.mGuidanceCategory = (GroupBox)target;
				return;
			case 12:
				this.mGuidanceCategoryComboBox = (AutoCompleteComboBox)target;
				return;
			case 13:
				this.mTabsGrid = (GroupBox)target;
				return;
			case 14:
				this.mKeyboardTabBorder = (Border)target;
				this.mKeyboardTabBorder.MouseLeftButtonUp += this.mKeyboardTabBorder_MouseLeftButtonUp;
				return;
			case 15:
				this.keyboardBtn = (TextBlock)target;
				return;
			case 16:
				this.mGamepadTabBorder = (Border)target;
				this.mGamepadTabBorder.MouseLeftButtonUp += this.mGamepadTabBorder_MouseLeftButtonUp;
				return;
			case 17:
				this.gamepadBtn = (TextBlock)target;
				return;
			case 18:
				this.mMOBASkillCancelGB = (GroupBox)target;
				return;
			case 19:
				this.mMOBASkillCancelGBPanel = (StackPanel)target;
				return;
			case 20:
				this.mMOBASkillCancelCB = (CustomCheckbox)target;
				this.mMOBASkillCancelCB.Checked += this.MOBASkillCancelCB_CheckedChanged;
				this.mMOBASkillCancelCB.Unchecked += this.MOBASkillCancelCB_CheckedChanged;
				return;
			case 21:
				this.mMOBASkillCancelPB = (CustomPictureBox)target;
				this.mMOBASkillCancelPB.MouseEnter += this.CustomPictureBox_MouseEnter;
				this.mMOBASkillCancelPB.MouseLeave += this.CustomPictureBox_MouseLeave;
				this.mMOBASkillCancelPB.MouseDown += this.MOBASkillCancelPictureBox_MouseDown;
				return;
			case 22:
				this.mLookAroundGB = (GroupBox)target;
				return;
			case 23:
				this.mLookAroundPanel = (StackPanel)target;
				return;
			case 24:
				this.mLookAroundCB = (CustomCheckbox)target;
				this.mLookAroundCB.Checked += this.LookAroundCB_CheckedChanged;
				this.mLookAroundCB.Unchecked += this.LookAroundCB_CheckedChanged;
				return;
			case 25:
				this.mLookAroundPB = (CustomPictureBox)target;
				this.mLookAroundPB.MouseEnter += this.CustomPictureBox_MouseEnter;
				this.mLookAroundPB.MouseLeave += this.CustomPictureBox_MouseLeave;
				this.mLookAroundPB.MouseDown += this.LookAroundPictureBox_MouseDown;
				return;
			case 26:
				this.mShootGB = (GroupBox)target;
				return;
			case 27:
				this.mShootGBPanel = (StackPanel)target;
				return;
			case 28:
				this.mShootCB = (CustomCheckbox)target;
				this.mShootCB.Checked += this.ShootCB_CheckedChanged;
				this.mShootCB.Unchecked += this.ShootCB_CheckedChanged;
				return;
			case 29:
				this.mShootPB = (CustomPictureBox)target;
				this.mShootPB.MouseEnter += this.CustomPictureBox_MouseEnter;
				this.mShootPB.MouseLeave += this.CustomPictureBox_MouseLeave;
				this.mShootPB.MouseDown += this.ShootPictureBox_MouseDown;
				return;
			case 30:
				this.mSchemesGB = (GroupBox)target;
				return;
			case 31:
				this.mEnableConditionGB = (GroupBox)target;
				return;
			case 32:
				this.mNoteGB = (GroupBox)target;
				return;
			case 33:
				this.mStartConditionGB = (GroupBox)target;
				return;
			case 34:
				this.mOverlayGB = (GroupBox)target;
				return;
			case 35:
				this.mOverlayCB = (CustomCheckbox)target;
				this.mOverlayCB.Checked += this.mOverlayCB_Checked;
				this.mOverlayCB.Unchecked += this.mOverlayCB_Unchecked;
				return;
			case 36:
				this.mCanvas = (Canvas)target;
				this.mCanvas.PreviewMouseMove += this.mCanvas_PreviewMouseMove;
				this.mCanvas.MouseUp += this.mCanvas_MouseUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x06000BA8 RID: 2984 RVA: 0x000092D0 File Offset: 0x000074D0
		[CompilerGenerated]
		private void <SetPopupDraggableProperty>g__deltaEventHandler|34_1(object o, DragDeltaEventArgs e)
		{
			base.HorizontalOffset += e.HorizontalChange;
			base.VerticalOffset += e.VerticalChange;
		}

		// Token: 0x0400079F RID: 1951
		private Dictionary<string, GroupBox> mDictGroupBox = new Dictionary<string, GroupBox>();

		// Token: 0x040007A0 RID: 1952
		private Dictionary<string, DualTextBlockControl> mDictDualTextBox = new Dictionary<string, DualTextBlockControl>();

		// Token: 0x040007A2 RID: 1954
		private List<string> mListSuggestions = new List<string>();

		// Token: 0x040007A3 RID: 1955
		internal CanvasElement mCanvasElement;

		// Token: 0x040007A4 RID: 1956
		private StackPanel mStackPanel;

		// Token: 0x040007A5 RID: 1957
		private MainWindow ParentWindow;

		// Token: 0x040007A6 RID: 1958
		private DualTextBlockControl mMOBADpadOriginXDTB;

		// Token: 0x040007A7 RID: 1959
		private DualTextBlockControl mMOBADpadOriginYDTB;

		// Token: 0x040007A8 RID: 1960
		private DualTextBlockControl mMOBADpadCharSpeedDTB;

		// Token: 0x040007A9 RID: 1961
		private DualTextBlockControl mMOBADpadKeyDTB;

		// Token: 0x040007AA RID: 1962
		private DualTextBlockControl mLookAroundXDTB;

		// Token: 0x040007AB RID: 1963
		private DualTextBlockControl mLookAroundYDTB;

		// Token: 0x040007AC RID: 1964
		private DualTextBlockControl mLookAroundDTB;

		// Token: 0x040007AD RID: 1965
		private DualTextBlockControl mShootXDTB;

		// Token: 0x040007AE RID: 1966
		private DualTextBlockControl mShootYDTB;

		// Token: 0x040007AF RID: 1967
		private DualTextBlockControl mShootDTB;

		// Token: 0x040007B0 RID: 1968
		private DualTextBlockControl mMOBASkillCancelDTB;

		// Token: 0x040007B1 RID: 1969
		private DualTextBlockControl mEnableConditionTB;

		// Token: 0x040007B2 RID: 1970
		private DualTextBlockControl mStartConditionTB;

		// Token: 0x040007B3 RID: 1971
		private DualTextBlockControl mNoteTB;

		// Token: 0x040007B4 RID: 1972
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mHeaderGrid;

		// Token: 0x040007B5 RID: 1973
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mHeader;

		// Token: 0x040007B6 RID: 1974
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomScrollViewer mScrollBar;

		// Token: 0x040007B7 RID: 1975
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mDeleteButton;

		// Token: 0x040007B8 RID: 1976
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mDummyGrid;

		// Token: 0x040007B9 RID: 1977
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal GroupBox mMOBAGB;

		// Token: 0x040007BA RID: 1978
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mMOBAPanel;

		// Token: 0x040007BB RID: 1979
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mMOBACB;

		// Token: 0x040007BC RID: 1980
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mMOBAPB;

		// Token: 0x040007BD RID: 1981
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal GroupBox mGuidanceCategory;

		// Token: 0x040007BE RID: 1982
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal AutoCompleteComboBox mGuidanceCategoryComboBox;

		// Token: 0x040007BF RID: 1983
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal GroupBox mTabsGrid;

		// Token: 0x040007C0 RID: 1984
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mKeyboardTabBorder;

		// Token: 0x040007C1 RID: 1985
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock keyboardBtn;

		// Token: 0x040007C2 RID: 1986
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mGamepadTabBorder;

		// Token: 0x040007C3 RID: 1987
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock gamepadBtn;

		// Token: 0x040007C4 RID: 1988
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal GroupBox mMOBASkillCancelGB;

		// Token: 0x040007C5 RID: 1989
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mMOBASkillCancelGBPanel;

		// Token: 0x040007C6 RID: 1990
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mMOBASkillCancelCB;

		// Token: 0x040007C7 RID: 1991
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mMOBASkillCancelPB;

		// Token: 0x040007C8 RID: 1992
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal GroupBox mLookAroundGB;

		// Token: 0x040007C9 RID: 1993
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mLookAroundPanel;

		// Token: 0x040007CA RID: 1994
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mLookAroundCB;

		// Token: 0x040007CB RID: 1995
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mLookAroundPB;

		// Token: 0x040007CC RID: 1996
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal GroupBox mShootGB;

		// Token: 0x040007CD RID: 1997
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mShootGBPanel;

		// Token: 0x040007CE RID: 1998
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mShootCB;

		// Token: 0x040007CF RID: 1999
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mShootPB;

		// Token: 0x040007D0 RID: 2000
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal GroupBox mSchemesGB;

		// Token: 0x040007D1 RID: 2001
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal GroupBox mEnableConditionGB;

		// Token: 0x040007D2 RID: 2002
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal GroupBox mNoteGB;

		// Token: 0x040007D3 RID: 2003
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal GroupBox mStartConditionGB;

		// Token: 0x040007D4 RID: 2004
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal GroupBox mOverlayGB;

		// Token: 0x040007D5 RID: 2005
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mOverlayCB;

		// Token: 0x040007D6 RID: 2006
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Canvas mCanvas;

		// Token: 0x040007D7 RID: 2007
		private bool _contentLoaded;
	}
}
