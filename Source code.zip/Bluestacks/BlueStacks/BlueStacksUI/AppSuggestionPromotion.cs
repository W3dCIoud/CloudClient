﻿using System;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200017B RID: 379
	[JsonObject(MemberSerialization.OptIn)]
	public class AppSuggestionPromotion
	{
		// Token: 0x17000252 RID: 594
		// (get) Token: 0x06000EBC RID: 3772 RVA: 0x0000AC34 File Offset: 0x00008E34
		// (set) Token: 0x06000EBD RID: 3773 RVA: 0x0000AC3C File Offset: 0x00008E3C
		[JsonProperty("app_pkg", NullValueHandling = NullValueHandling.Ignore)]
		public string AppPackage { get; set; } = string.Empty;

		// Token: 0x17000253 RID: 595
		// (get) Token: 0x06000EBE RID: 3774 RVA: 0x0000AC45 File Offset: 0x00008E45
		// (set) Token: 0x06000EBF RID: 3775 RVA: 0x0000AC4D File Offset: 0x00008E4D
		[JsonProperty("app_activity", NullValueHandling = NullValueHandling.Ignore)]
		public string AppActivity { get; set; }

		// Token: 0x17000254 RID: 596
		// (get) Token: 0x06000EC0 RID: 3776 RVA: 0x0000AC56 File Offset: 0x00008E56
		// (set) Token: 0x06000EC1 RID: 3777 RVA: 0x0000AC5E File Offset: 0x00008E5E
		[JsonProperty("show_red_dot", NullValueHandling = NullValueHandling.Ignore)]
		public bool IsShowRedDot { get; set; }

		// Token: 0x17000255 RID: 597
		// (get) Token: 0x06000EC2 RID: 3778 RVA: 0x0000AC67 File Offset: 0x00008E67
		// (set) Token: 0x06000EC3 RID: 3779 RVA: 0x0000AC6F File Offset: 0x00008E6F
		[JsonProperty("app_name", NullValueHandling = NullValueHandling.Ignore)]
		public string AppName { get; set; }

		// Token: 0x17000256 RID: 598
		// (get) Token: 0x06000EC4 RID: 3780 RVA: 0x0000AC78 File Offset: 0x00008E78
		// (set) Token: 0x06000EC5 RID: 3781 RVA: 0x0000AC80 File Offset: 0x00008E80
		[JsonProperty("app_icon", NullValueHandling = NullValueHandling.Ignore)]
		public string AppIcon { get; set; }

		// Token: 0x17000257 RID: 599
		// (get) Token: 0x06000EC6 RID: 3782 RVA: 0x0000AC89 File Offset: 0x00008E89
		// (set) Token: 0x06000EC7 RID: 3783 RVA: 0x0000AC91 File Offset: 0x00008E91
		[JsonProperty("app_icon_id", NullValueHandling = NullValueHandling.Ignore)]
		public string AppIconId { get; set; }

		// Token: 0x17000258 RID: 600
		// (get) Token: 0x06000EC8 RID: 3784 RVA: 0x0000AC9A File Offset: 0x00008E9A
		// (set) Token: 0x06000EC9 RID: 3785 RVA: 0x0000ACA2 File Offset: 0x00008EA2
		[JsonProperty("tooltip", NullValueHandling = NullValueHandling.Ignore)]
		public string ToolTip { get; set; }

		// Token: 0x17000259 RID: 601
		// (get) Token: 0x06000ECA RID: 3786 RVA: 0x0000ACAB File Offset: 0x00008EAB
		// (set) Token: 0x06000ECB RID: 3787 RVA: 0x0000ACB3 File Offset: 0x00008EB3
		[JsonProperty("cross_promotion_pkg", NullValueHandling = NullValueHandling.Ignore)]
		public string CrossPromotionPackage { get; set; }

		// Token: 0x1700025A RID: 602
		// (get) Token: 0x06000ECC RID: 3788 RVA: 0x0000ACBC File Offset: 0x00008EBC
		// (set) Token: 0x06000ECD RID: 3789 RVA: 0x0000ACC4 File Offset: 0x00008EC4
		[JsonProperty("location", NullValueHandling = NullValueHandling.Ignore)]
		public string AppLocation { get; set; } = string.Empty;

		// Token: 0x1700025B RID: 603
		// (get) Token: 0x06000ECE RID: 3790 RVA: 0x0000ACCD File Offset: 0x00008ECD
		// (set) Token: 0x06000ECF RID: 3791 RVA: 0x0000ACD5 File Offset: 0x00008ED5
		[JsonProperty("is_email_required", NullValueHandling = NullValueHandling.Ignore)]
		public bool IsEmailRequired { get; set; }

		// Token: 0x1700025C RID: 604
		// (get) Token: 0x06000ED0 RID: 3792 RVA: 0x0000ACDE File Offset: 0x00008EDE
		// (set) Token: 0x06000ED1 RID: 3793 RVA: 0x0000ACE6 File Offset: 0x00008EE6
		public SerializableDictionary<string, string> ExtraPayload { get; set; } = new SerializableDictionary<string, string>();

		// Token: 0x1700025D RID: 605
		// (get) Token: 0x06000ED2 RID: 3794 RVA: 0x0000ACEF File Offset: 0x00008EEF
		// (set) Token: 0x06000ED3 RID: 3795 RVA: 0x0000ACF7 File Offset: 0x00008EF7
		[JsonProperty("is_animation", NullValueHandling = NullValueHandling.Ignore)]
		public bool IsAnimation { get; set; }

		// Token: 0x1700025E RID: 606
		// (get) Token: 0x06000ED4 RID: 3796 RVA: 0x0000AD00 File Offset: 0x00008F00
		// (set) Token: 0x06000ED5 RID: 3797 RVA: 0x0000AD08 File Offset: 0x00008F08
		[JsonProperty("animation_time", NullValueHandling = NullValueHandling.Ignore)]
		public int AnimationTime { get; set; }

		// Token: 0x1700025F RID: 607
		// (get) Token: 0x06000ED6 RID: 3798 RVA: 0x0000AD11 File Offset: 0x00008F11
		// (set) Token: 0x06000ED7 RID: 3799 RVA: 0x0000AD19 File Offset: 0x00008F19
		[JsonProperty("is_icon_border", NullValueHandling = NullValueHandling.Ignore)]
		public bool IsIconBorder { get; set; }

		// Token: 0x17000260 RID: 608
		// (get) Token: 0x06000ED8 RID: 3800 RVA: 0x0000AD22 File Offset: 0x00008F22
		// (set) Token: 0x06000ED9 RID: 3801 RVA: 0x0000AD2A File Offset: 0x00008F2A
		[JsonProperty("icon_border_url", NullValueHandling = NullValueHandling.Ignore)]
		public string IconBorderUrl { get; set; }

		// Token: 0x17000261 RID: 609
		// (get) Token: 0x06000EDA RID: 3802 RVA: 0x0000AD33 File Offset: 0x00008F33
		// (set) Token: 0x06000EDB RID: 3803 RVA: 0x0000AD3B File Offset: 0x00008F3B
		[JsonProperty("icon_border_click_url", NullValueHandling = NullValueHandling.Ignore)]
		public string IconBorderClickUrl { get; set; }

		// Token: 0x17000262 RID: 610
		// (get) Token: 0x06000EDC RID: 3804 RVA: 0x0000AD44 File Offset: 0x00008F44
		// (set) Token: 0x06000EDD RID: 3805 RVA: 0x0000AD4C File Offset: 0x00008F4C
		[JsonProperty("icon_border_id", NullValueHandling = NullValueHandling.Ignore)]
		public string IconBorderId { get; set; }

		// Token: 0x17000263 RID: 611
		// (get) Token: 0x06000EDE RID: 3806 RVA: 0x0000AD55 File Offset: 0x00008F55
		// (set) Token: 0x06000EDF RID: 3807 RVA: 0x0000AD5D File Offset: 0x00008F5D
		[JsonProperty("icon_border_hover_url", NullValueHandling = NullValueHandling.Ignore)]
		public string IconBorderHoverUrl { get; set; }

		// Token: 0x17000264 RID: 612
		// (get) Token: 0x06000EE0 RID: 3808 RVA: 0x0000AD66 File Offset: 0x00008F66
		// (set) Token: 0x06000EE1 RID: 3809 RVA: 0x0000AD6E File Offset: 0x00008F6E
		public string AppIconPath { get; set; }

		// Token: 0x17000265 RID: 613
		// (get) Token: 0x06000EE2 RID: 3810 RVA: 0x0000AD77 File Offset: 0x00008F77
		// (set) Token: 0x06000EE3 RID: 3811 RVA: 0x0000AD7F File Offset: 0x00008F7F
		[JsonProperty("app_icon_width", NullValueHandling = NullValueHandling.Ignore)]
		public double IconWidth { get; set; }

		// Token: 0x17000266 RID: 614
		// (get) Token: 0x06000EE4 RID: 3812 RVA: 0x0000AD88 File Offset: 0x00008F88
		// (set) Token: 0x06000EE5 RID: 3813 RVA: 0x0000AD90 File Offset: 0x00008F90
		[JsonProperty("app_icon_height", NullValueHandling = NullValueHandling.Ignore)]
		public double IconHeight { get; set; }
	}
}
