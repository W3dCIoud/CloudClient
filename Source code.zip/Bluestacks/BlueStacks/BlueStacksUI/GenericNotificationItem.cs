﻿using System;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000077 RID: 119
	public class GenericNotificationItem
	{
		// Token: 0x17000177 RID: 375
		// (get) Token: 0x060004C6 RID: 1222 RVA: 0x00005323 File Offset: 0x00003523
		// (set) Token: 0x060004C7 RID: 1223 RVA: 0x0000532B File Offset: 0x0000352B
		public string Id { get; set; }

		// Token: 0x17000178 RID: 376
		// (get) Token: 0x060004C8 RID: 1224 RVA: 0x00005334 File Offset: 0x00003534
		// (set) Token: 0x060004C9 RID: 1225 RVA: 0x0000533C File Offset: 0x0000353C
		public string Title { get; set; }

		// Token: 0x17000179 RID: 377
		// (get) Token: 0x060004CA RID: 1226 RVA: 0x00005345 File Offset: 0x00003545
		// (set) Token: 0x060004CB RID: 1227 RVA: 0x0000534D File Offset: 0x0000354D
		public string Message { get; set; }

		// Token: 0x1700017A RID: 378
		// (get) Token: 0x060004CC RID: 1228 RVA: 0x00005356 File Offset: 0x00003556
		// (set) Token: 0x060004CD RID: 1229 RVA: 0x0000535E File Offset: 0x0000355E
		public NotificationPriority Priority { get; set; } = NotificationPriority.Normal;

		// Token: 0x1700017B RID: 379
		// (get) Token: 0x060004CE RID: 1230 RVA: 0x00005367 File Offset: 0x00003567
		// (set) Token: 0x060004CF RID: 1231 RVA: 0x0000536F File Offset: 0x0000356F
		public bool ShowRibbon { get; set; }

		// Token: 0x1700017C RID: 380
		// (get) Token: 0x060004D0 RID: 1232 RVA: 0x00005378 File Offset: 0x00003578
		// (set) Token: 0x060004D1 RID: 1233 RVA: 0x00005380 File Offset: 0x00003580
		public DateTime CreationTime { get; set; } = DateTime.Now;

		// Token: 0x1700017D RID: 381
		// (get) Token: 0x060004D2 RID: 1234 RVA: 0x00005389 File Offset: 0x00003589
		// (set) Token: 0x060004D3 RID: 1235 RVA: 0x00005391 File Offset: 0x00003591
		public string NotificationMenuImageUrl { get; set; }

		// Token: 0x1700017E RID: 382
		// (get) Token: 0x060004D4 RID: 1236 RVA: 0x0000539A File Offset: 0x0000359A
		// (set) Token: 0x060004D5 RID: 1237 RVA: 0x000053A2 File Offset: 0x000035A2
		public string NotificationMenuImageName { get; set; }

		// Token: 0x1700017F RID: 383
		// (get) Token: 0x060004D6 RID: 1238 RVA: 0x000053AB File Offset: 0x000035AB
		// (set) Token: 0x060004D7 RID: 1239 RVA: 0x000053B3 File Offset: 0x000035B3
		public bool IsRead { get; set; }

		// Token: 0x17000180 RID: 384
		// (get) Token: 0x060004D8 RID: 1240 RVA: 0x000053BC File Offset: 0x000035BC
		// (set) Token: 0x060004D9 RID: 1241 RVA: 0x000053C4 File Offset: 0x000035C4
		public NotificationPayloadType PayloadType { get; set; }

		// Token: 0x17000181 RID: 385
		// (get) Token: 0x060004DA RID: 1242 RVA: 0x000053CD File Offset: 0x000035CD
		// (set) Token: 0x060004DB RID: 1243 RVA: 0x000053D5 File Offset: 0x000035D5
		public bool IsDeleted { get; set; }

		// Token: 0x17000182 RID: 386
		// (get) Token: 0x060004DC RID: 1244 RVA: 0x000053DE File Offset: 0x000035DE
		// (set) Token: 0x060004DD RID: 1245 RVA: 0x000053E6 File Offset: 0x000035E6
		public bool IsDeferred { get; set; }

		// Token: 0x17000183 RID: 387
		// (get) Token: 0x060004DE RID: 1246 RVA: 0x000053EF File Offset: 0x000035EF
		// (set) Token: 0x060004DF RID: 1247 RVA: 0x000053F7 File Offset: 0x000035F7
		public string DeferredApp { get; set; }

		// Token: 0x17000184 RID: 388
		// (get) Token: 0x060004E0 RID: 1248 RVA: 0x00005400 File Offset: 0x00003600
		// (set) Token: 0x060004E1 RID: 1249 RVA: 0x00005408 File Offset: 0x00003608
		public long DeferredAppUsage { get; set; }

		// Token: 0x17000185 RID: 389
		// (get) Token: 0x060004E2 RID: 1250 RVA: 0x00005411 File Offset: 0x00003611
		// (set) Token: 0x060004E3 RID: 1251 RVA: 0x00005419 File Offset: 0x00003619
		public GenericNotificationDesignItem NotificationDesignItem { get; set; }

		// Token: 0x17000186 RID: 390
		// (get) Token: 0x060004E4 RID: 1252 RVA: 0x00005422 File Offset: 0x00003622
		// (set) Token: 0x060004E5 RID: 1253 RVA: 0x0000542A File Offset: 0x0000362A
		public SerializableDictionary<string, string> ExtraPayload { get; set; } = new SerializableDictionary<string, string>();
	}
}
