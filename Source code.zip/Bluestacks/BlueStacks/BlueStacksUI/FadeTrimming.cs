﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200010D RID: 269
	public static class FadeTrimming
	{
		// Token: 0x06000A85 RID: 2693 RVA: 0x00008B60 File Offset: 0x00006D60
		public static bool GetIsEnabled(DependencyObject obj)
		{
			return (bool)((obj != null) ? obj.GetValue(FadeTrimming.IsEnabledProperty) : null);
		}

		// Token: 0x06000A86 RID: 2694 RVA: 0x00008B78 File Offset: 0x00006D78
		public static void SetIsEnabled(DependencyObject obj, bool value)
		{
			if (obj != null)
			{
				obj.SetValue(FadeTrimming.IsEnabledProperty, value);
			}
		}

		// Token: 0x06000A87 RID: 2695 RVA: 0x00008B8E File Offset: 0x00006D8E
		public static void SetIsVerticalFadingEnabled(DependencyObject obj, bool value)
		{
			if (obj != null)
			{
				obj.SetValue(FadeTrimming.IsVerticalFadingEnabledProperty, value);
			}
		}

		// Token: 0x06000A88 RID: 2696 RVA: 0x00008BA4 File Offset: 0x00006DA4
		private static FadeTrimming.Fader GetFader(DependencyObject obj)
		{
			return (FadeTrimming.Fader)obj.GetValue(FadeTrimming.FaderProperty);
		}

		// Token: 0x06000A89 RID: 2697 RVA: 0x00008BB6 File Offset: 0x00006DB6
		private static void SetFader(DependencyObject obj, FadeTrimming.Fader value)
		{
			obj.SetValue(FadeTrimming.FaderProperty, value);
		}

		// Token: 0x06000A8A RID: 2698 RVA: 0x0003CDB0 File Offset: 0x0003AFB0
		private static void HandleVerticalFadingEnabled(DependencyObject source, DependencyPropertyChangedEventArgs e)
		{
			TextBlock textBlock = source as TextBlock;
			if (textBlock != null)
			{
				FadeTrimming.Fader fader = FadeTrimming.GetFader(textBlock);
				if (fader != null)
				{
					fader.ToggleVerticalFading((bool)e.NewValue);
				}
			}
		}

		// Token: 0x06000A8B RID: 2699 RVA: 0x0003CDE4 File Offset: 0x0003AFE4
		private static void HandleIsEnabledChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
		{
			TextBlock textBlock = source as TextBlock;
			if (textBlock != null)
			{
				if ((bool)e.OldValue)
				{
					FadeTrimming.Fader fader = FadeTrimming.GetFader(textBlock);
					if (fader != null)
					{
						fader.Detach();
						FadeTrimming.SetFader(textBlock, null);
					}
					textBlock.Loaded -= FadeTrimming.HandleTextBlockLoaded;
					textBlock.Unloaded -= FadeTrimming.HandleTextBlockUnloaded;
				}
				if ((bool)e.NewValue)
				{
					textBlock.Loaded += FadeTrimming.HandleTextBlockLoaded;
					textBlock.Unloaded += FadeTrimming.HandleTextBlockUnloaded;
					FadeTrimming.Fader fader2 = new FadeTrimming.Fader(textBlock);
					FadeTrimming.SetFader(textBlock, fader2);
					fader2.Attach();
				}
			}
		}

		// Token: 0x06000A8C RID: 2700 RVA: 0x0003CE90 File Offset: 0x0003B090
		private static void HandleTextBlockUnloaded(object sender, RoutedEventArgs e)
		{
			DependencyObject dependencyObject = sender as DependencyObject;
			if (dependencyObject != null)
			{
				FadeTrimming.Fader fader = FadeTrimming.GetFader(dependencyObject);
				if (fader != null)
				{
					fader.Detach();
				}
			}
		}

		// Token: 0x06000A8D RID: 2701 RVA: 0x0003CEB8 File Offset: 0x0003B0B8
		private static void HandleTextBlockLoaded(object sender, RoutedEventArgs e)
		{
			DependencyObject dependencyObject = sender as DependencyObject;
			if (dependencyObject != null)
			{
				FadeTrimming.Fader fader = FadeTrimming.GetFader(dependencyObject);
				if (fader != null)
				{
					fader.Attach();
				}
			}
		}

		// Token: 0x06000A8E RID: 2702 RVA: 0x0003CEE0 File Offset: 0x0003B0E0
		private static bool HorizontalBrushNeedsUpdating(LinearGradientBrush brush, double visibleWidth)
		{
			return brush.EndPoint.X < visibleWidth - 1E-05 || brush.EndPoint.X > visibleWidth + 1E-05;
		}

		// Token: 0x06000A8F RID: 2703 RVA: 0x0003CF28 File Offset: 0x0003B128
		private static bool VerticalBrushNeedsUpdating(LinearGradientBrush brush, double visibleHeight)
		{
			return brush.EndPoint.Y < visibleHeight - 1E-05 || brush.EndPoint.Y > visibleHeight + 1E-05;
		}

		// Token: 0x040006AB RID: 1707
		private const double Epsilon = 1E-05;

		// Token: 0x040006AC RID: 1708
		private const double FadeWidth = 10.0;

		// Token: 0x040006AD RID: 1709
		private const double FadeHeight = 20.0;

		// Token: 0x040006AE RID: 1710
		public static readonly DependencyProperty IsEnabledProperty = DependencyProperty.RegisterAttached("IsEnabled", typeof(bool), typeof(FadeTrimming), new PropertyMetadata(false, new PropertyChangedCallback(FadeTrimming.HandleIsEnabledChanged)));

		// Token: 0x040006AF RID: 1711
		private static readonly DependencyProperty FaderProperty = DependencyProperty.RegisterAttached("Fader", typeof(FadeTrimming.Fader), typeof(FadeTrimming), new PropertyMetadata(null));

		// Token: 0x040006B0 RID: 1712
		public static readonly DependencyProperty IsVerticalFadingEnabledProperty = DependencyProperty.RegisterAttached("IsVerticalFadingEnabledProperty", typeof(bool), typeof(FadeTrimming), new PropertyMetadata(false, new PropertyChangedCallback(FadeTrimming.HandleVerticalFadingEnabled)));

		// Token: 0x0200010E RID: 270
		private class Fader
		{
			// Token: 0x06000A91 RID: 2705 RVA: 0x00008BC4 File Offset: 0x00006DC4
			public Fader(TextBlock textBlock)
			{
				this._textBlock = textBlock;
			}

			// Token: 0x06000A92 RID: 2706 RVA: 0x0003D01C File Offset: 0x0003B21C
			public void Attach()
			{
				FrameworkElement frameworkElement = VisualTreeHelper.GetParent(this._textBlock) as FrameworkElement;
				if (frameworkElement != null && !this._isAttached)
				{
					frameworkElement.SizeChanged += new SizeChangedEventHandler(this.UpdateForegroundBrush);
					this._textBlock.SizeChanged += new SizeChangedEventHandler(this.UpdateForegroundBrush);
					this._opacityMask = this._textBlock.OpacityMask;
					if (this._verticalFadingEnabled || this._textBlock.TextWrapping == TextWrapping.NoWrap)
					{
						this._textBlock.TextTrimming = TextTrimming.None;
					}
					this.UpdateForegroundBrush(this._textBlock, EventArgs.Empty);
					this._isAttached = true;
				}
			}

			// Token: 0x06000A93 RID: 2707 RVA: 0x0003D0BC File Offset: 0x0003B2BC
			public void Detach()
			{
				this._textBlock.SizeChanged -= new SizeChangedEventHandler(this.UpdateForegroundBrush);
				FrameworkElement frameworkElement = VisualTreeHelper.GetParent(this._textBlock) as FrameworkElement;
				if (frameworkElement != null)
				{
					frameworkElement.SizeChanged -= new SizeChangedEventHandler(this.UpdateForegroundBrush);
				}
				this._textBlock.OpacityMask = this._opacityMask;
				this._isAttached = false;
			}

			// Token: 0x06000A94 RID: 2708 RVA: 0x00008BD3 File Offset: 0x00006DD3
			public void ToggleVerticalFading(bool newValue)
			{
				this._verticalFadingEnabled = newValue;
				this.UpdateForegroundBrush(this._textBlock, EventArgs.Empty);
			}

			// Token: 0x06000A95 RID: 2709 RVA: 0x0003D120 File Offset: 0x0003B320
			private void UpdateForegroundBrush(object sender, EventArgs e)
			{
				Geometry layoutClip = LayoutInformation.GetLayoutClip(this._textBlock);
				bool flag = layoutClip != null && ((this._textBlock.TextWrapping == TextWrapping.NoWrap && layoutClip.Bounds.Width > 0.0 && layoutClip.Bounds.Width < this._textBlock.ActualWidth) || (this._verticalFadingEnabled && this._textBlock.TextWrapping == TextWrapping.Wrap && layoutClip.Bounds.Height > 0.0 && layoutClip.Bounds.Height < this._textBlock.ActualHeight));
				if (this._isClipped && !flag)
				{
					this._textBlock.OpacityMask = this._opacityMask;
					this._brush = null;
					this._isClipped = false;
				}
				if (flag)
				{
					double width = layoutClip.Bounds.Width;
					double height = layoutClip.Bounds.Height;
					bool flag2 = this._textBlock.TextWrapping == TextWrapping.Wrap;
					if (this._brush == null)
					{
						this._brush = (flag2 ? this.GetVerticalClipBrush(height) : this.GetHorizontalClipBrush(width));
						this._textBlock.OpacityMask = this._brush;
					}
					else if (flag2 && FadeTrimming.VerticalBrushNeedsUpdating(this._brush, height))
					{
						this._brush.EndPoint = new Point(0.0, height);
						this._brush.GradientStops[1].Offset = (height - 20.0) / height;
					}
					else if (!flag2 && FadeTrimming.HorizontalBrushNeedsUpdating(this._brush, width))
					{
						this._brush.EndPoint = new Point(width, 0.0);
						this._brush.GradientStops[1].Offset = (width - 10.0) / width;
					}
					this._isClipped = true;
				}
			}

			// Token: 0x06000A96 RID: 2710 RVA: 0x0003D318 File Offset: 0x0003B518
			private LinearGradientBrush GetHorizontalClipBrush(double visibleWidth)
			{
				return new LinearGradientBrush
				{
					MappingMode = BrushMappingMode.Absolute,
					StartPoint = new Point(0.0, 0.0),
					EndPoint = new Point(visibleWidth, 0.0),
					GradientStops = 
					{
						new GradientStop
						{
							Color = Colors.Black,
							Offset = 0.0
						},
						new GradientStop
						{
							Color = Colors.Black,
							Offset = (visibleWidth - 10.0) / visibleWidth
						},
						new GradientStop
						{
							Color = Colors.Transparent,
							Offset = 1.0
						}
					}
				};
			}

			// Token: 0x06000A97 RID: 2711 RVA: 0x0003D3E8 File Offset: 0x0003B5E8
			private LinearGradientBrush GetVerticalClipBrush(double visibleHeight)
			{
				return new LinearGradientBrush
				{
					MappingMode = BrushMappingMode.Absolute,
					StartPoint = new Point(0.0, 0.0),
					EndPoint = new Point(0.0, visibleHeight),
					GradientStops = 
					{
						new GradientStop
						{
							Color = Colors.Black,
							Offset = 0.0
						},
						new GradientStop
						{
							Color = Colors.Black,
							Offset = (visibleHeight - 20.0) / visibleHeight
						},
						new GradientStop
						{
							Color = Colors.Transparent,
							Offset = 1.0
						}
					}
				};
			}

			// Token: 0x040006B1 RID: 1713
			private readonly TextBlock _textBlock;

			// Token: 0x040006B2 RID: 1714
			private bool _isAttached;

			// Token: 0x040006B3 RID: 1715
			private LinearGradientBrush _brush;

			// Token: 0x040006B4 RID: 1716
			private Brush _opacityMask;

			// Token: 0x040006B5 RID: 1717
			private bool _isClipped;

			// Token: 0x040006B6 RID: 1718
			private bool _verticalFadingEnabled;
		}
	}
}
