﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Controls;
using System.Windows.Threading;
using System.Xml;
using System.Xml.Serialization;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200027B RID: 635
	public class AppHandler
	{
		// Token: 0x170002F2 RID: 754
		// (get) Token: 0x06001717 RID: 5911 RVA: 0x0000FCD3 File Offset: 0x0000DED3
		// (set) Token: 0x06001718 RID: 5912 RVA: 0x0000FCDB File Offset: 0x0000DEDB
		public SerializableDictionary<string, DateTime> CdnAppdict { get; set; } = new SerializableDictionary<string, DateTime>();

		// Token: 0x170002F3 RID: 755
		// (get) Token: 0x06001719 RID: 5913 RVA: 0x0000FCE4 File Offset: 0x0000DEE4
		// (set) Token: 0x0600171A RID: 5914 RVA: 0x0000FCEC File Offset: 0x0000DEEC
		public string mLastAppDisplayed { get; set; } = string.Empty;

		// Token: 0x170002F4 RID: 756
		// (get) Token: 0x0600171B RID: 5915 RVA: 0x0000FCF5 File Offset: 0x0000DEF5
		// (set) Token: 0x0600171C RID: 5916 RVA: 0x0000FCFD File Offset: 0x0000DEFD
		public string mLastRunAppSentForSynced { get; set; } = string.Empty;

		// Token: 0x170002F5 RID: 757
		// (get) Token: 0x0600171D RID: 5917 RVA: 0x0000FD06 File Offset: 0x0000DF06
		// (set) Token: 0x0600171E RID: 5918 RVA: 0x0000FD0E File Offset: 0x0000DF0E
		public string mAppDisplayedOccured { get; set; } = string.Empty;

		// Token: 0x170002F6 RID: 758
		// (get) Token: 0x0600171F RID: 5919 RVA: 0x0000FD17 File Offset: 0x0000DF17
		public static List<string> ListIgnoredApps { get; } = new List<string>
		{
			"tv.gamepop.home",
			"com.pop.store",
			"com.pop.store51",
			"com.bluestacks.s2p5105",
			"com.bluestacks.help",
			"mpi.v23",
			"com.google.android.gms",
			"com.google.android.gsf.login",
			"com.android.deskclock",
			"me.onemobile.android",
			"me.onemobile.lite.android",
			"android.rk.RockVideoPlayer.RockVideoPlayer",
			"com.bluestacks.chartapp",
			"com.bluestacks.setupapp",
			"com.android.gallery3d",
			"com.bluestacks.keymappingtool",
			"com.baidu.appsearch",
			"com.bluestacks.s2p",
			"com.bluestacks.windowsfilemanager",
			"com.android.quicksearchbox",
			"com.bluestacks.setup",
			"com.bluestacks.appsettings",
			"mpi.v23",
			"com.bluestacks.setup",
			"com.bluestacks.gamepophome",
			"com.bluestacks.appfinder",
			"com.android.providers.downloads.ui",
			"com.google.android.instantapps.supervisor"
		};

		// Token: 0x170002F7 RID: 759
		// (get) Token: 0x06001720 RID: 5920 RVA: 0x0000FD1E File Offset: 0x0000DF1E
		// (set) Token: 0x06001721 RID: 5921 RVA: 0x0008A800 File Offset: 0x00088A00
		public bool IsOneTimeSetupCompleted
		{
			get
			{
				if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition && GameConfig.Instance.AppGenericAction == GenericAction.InstallCDN)
				{
					return true;
				}
				if (!this.mIsOneTimeSetupCompleted)
				{
					this.StartOTSCheckThread();
				}
				return this.mIsOneTimeSetupCompleted;
			}
			set
			{
				this.mIsOneTimeSetupCompleted = value;
				this.ParentWindow.EngineInstanceRegistry.IsOneTimeSetupDone = value;
				Logger.Info("One time setup completed. Will perform tasks now");
				object obj = this.sOTSLock;
				lock (obj)
				{
					Logger.Info("Performing OTS completed tasks");
					if (value && this.EventOnOneTimeSetupCompleted != null)
					{
						this.EventOnOneTimeSetupCompleted(this.ParentWindow, new EventArgs());
						this.EventOnOneTimeSetupCompleted = null;
					}
				}
			}
		}

		// Token: 0x06001722 RID: 5922 RVA: 0x0008A888 File Offset: 0x00088A88
		private void StartOTSCheckThread()
		{
			if (this.mOtsCheckThread == null)
			{
				object obj = this.mOtsCheckLock;
				lock (obj)
				{
					if (this.mOtsCheckThread == null)
					{
						try
						{
							this.mOtsCheckThread = new Thread(delegate()
							{
								Logger.Info("Checking for if OTS completed");
								while (!this.mIsOneTimeSetupCompleted)
								{
									this.CheckingOneTimeSetupCompleted();
									Thread.Sleep(2 * this.oneSecond);
								}
							})
							{
								IsBackground = true
							};
							this.mOtsCheckThread.Start();
						}
						catch (Exception ex)
						{
							Logger.Error("Failed to create ots check thread.");
							Logger.Error(ex.ToString());
						}
					}
				}
			}
		}

		// Token: 0x170002F8 RID: 760
		// (get) Token: 0x06001723 RID: 5923 RVA: 0x0000FD50 File Offset: 0x0000DF50
		// (set) Token: 0x06001724 RID: 5924 RVA: 0x0000FD66 File Offset: 0x0000DF66
		public bool IsGuestReady
		{
			get
			{
				if (!this.mIsGuestReady)
				{
					this.SignalGuestReady();
				}
				return this.mIsGuestReady;
			}
			set
			{
				this.mIsGuestReady = value;
			}
		}

		// Token: 0x06001725 RID: 5925 RVA: 0x0000FD6F File Offset: 0x0000DF6F
		private void SignalGuestReady()
		{
			if (!FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.ParentWindow.GuestBoot_Completed();
				return;
			}
			this.ParentWindow.Utils.sBootCheckTimer.Enabled = false;
			this.ParentWindow.mEnableLaunchPlayForNCSoft = true;
		}

		// Token: 0x06001726 RID: 5926 RVA: 0x0008A918 File Offset: 0x00088B18
		private void CheckingOneTimeSetupCompleted()
		{
			try
			{
				string text = JObject.Parse(HTTPUtils.SendRequestToGuest("isOTSCompleted", null, this.ParentWindow.mVmName, 1000, null, false, 1, 0))["result"].ToString();
				if (text.Equals("ok", StringComparison.InvariantCultureIgnoreCase))
				{
					Logger.Info("OTS result: {0}", new object[]
					{
						text
					});
					this.IsOneTimeSetupCompleted = true;
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Exception in checking OneTimeSetupCompleted with vmName {0}. Err: {1}", new object[]
				{
					this.ParentWindow.mVmName,
					ex.Message
				});
			}
		}

		// Token: 0x170002F9 RID: 761
		// (get) Token: 0x06001727 RID: 5927 RVA: 0x0000FDAB File Offset: 0x0000DFAB
		// (set) Token: 0x06001728 RID: 5928 RVA: 0x0000FDB3 File Offset: 0x0000DFB3
		public string SwitchWhenPackageNameRecieved
		{
			get
			{
				return this.mSwitchWhenPackageNameRecieved;
			}
			set
			{
				this.mSwitchWhenPackageNameRecieved = value;
				if (!string.IsNullOrEmpty(this.mSwitchWhenPackageNameRecieved) && this.mSwitchWhenPackageNameRecieved.Equals(this.mLastAppDisplayed, StringComparison.InvariantCultureIgnoreCase))
				{
					this.AppLaunched(this.mSwitchWhenPackageNameRecieved, true);
				}
			}
		}

		// Token: 0x170002FA RID: 762
		// (get) Token: 0x06001729 RID: 5929 RVA: 0x0000FDEA File Offset: 0x0000DFEA
		// (set) Token: 0x0600172A RID: 5930 RVA: 0x0000FDF2 File Offset: 0x0000DFF2
		public EventHandler<EventArgs> EventOnOneTimeSetupCompleted { get; set; }

		// Token: 0x170002FB RID: 763
		// (get) Token: 0x0600172B RID: 5931 RVA: 0x0000FDFB File Offset: 0x0000DFFB
		// (set) Token: 0x0600172C RID: 5932 RVA: 0x0000FE02 File Offset: 0x0000E002
		public static EventHandler<EventArgs> EventOnAppDisplayed { get; set; }

		// Token: 0x0600172D RID: 5933 RVA: 0x0008A9C0 File Offset: 0x00088BC0
		internal AppHandler(MainWindow window)
		{
			this.ParentWindow = window;
			string cdnappsTimeStamp = RegistryManager.Instance.CDNAppsTimeStamp;
			if (!string.IsNullOrEmpty(cdnappsTimeStamp))
			{
				using (XmlReader xmlReader = XmlReader.Create(new StringReader(cdnappsTimeStamp)))
				{
					XmlSerializer xmlSerializer = new XmlSerializer(typeof(SerializableDictionary<string, DateTime>));
					this.CdnAppdict = (SerializableDictionary<string, DateTime>)xmlSerializer.Deserialize(xmlReader);
				}
			}
			this.mIsOneTimeSetupCompleted = this.ParentWindow.EngineInstanceRegistry.IsOneTimeSetupDone;
		}

		// Token: 0x0600172E RID: 5934 RVA: 0x0008AABC File Offset: 0x00088CBC
		public bool IsAppInstalled(string package)
		{
			bool result = false;
			string text;
			if (new JsonParser(this.ParentWindow.mVmName).IsAppInstalled(package, out text))
			{
				result = true;
			}
			return result;
		}

		// Token: 0x0600172F RID: 5935 RVA: 0x0008AAE8 File Offset: 0x00088CE8
		public bool IsAppInstalled(string package, out string version)
		{
			bool result = false;
			if (new JsonParser(this.ParentWindow.mVmName).IsAppInstalled(package, out version))
			{
				result = true;
			}
			return result;
		}

		// Token: 0x06001730 RID: 5936 RVA: 0x0008AB14 File Offset: 0x00088D14
		public void AppLaunched(string packageName, bool forced = false)
		{
			object obj = this.sLockObject;
			lock (obj)
			{
				if (!this.ParentWindow.mClosed)
				{
					if ((packageName == BlueStacksUIUtils.sUserAccountPackageName || packageName == "com.android.vending") && this.mSwitchWhenPackageNameRecieved == "com.android.vending")
					{
						packageName = this.mSwitchWhenPackageNameRecieved;
						if (string.Compare(this.mLastRunAppSentForSynced, packageName, StringComparison.OrdinalIgnoreCase) == 0)
						{
							this.mSwitchWhenPackageNameRecieved = "";
						}
					}
					if (forced || !string.Equals(packageName, this.mLastAppDisplayed, StringComparison.InvariantCultureIgnoreCase))
					{
						if (!this.mIsOneTimeSetupCompleted)
						{
							if (!string.IsNullOrEmpty(packageName) && (packageName.StartsWith("com.google.android.gms", StringComparison.InvariantCultureIgnoreCase) || packageName.Equals("com.google.android.setupwizard", StringComparison.InvariantCultureIgnoreCase)))
							{
								this.StartOTSCheckThread();
							}
						}
						else
						{
							Logger.Info("SwitchWhenPackageNameRecieved: {0}", new object[]
							{
								this.mSwitchWhenPackageNameRecieved
							});
							this.ParentWindow.ShowLoadingGrid(false);
							bool receivedFromImap = string.Compare(this.mLastRunAppSentForSynced, packageName, StringComparison.OrdinalIgnoreCase) == 0;
							if (receivedFromImap)
							{
								this.mLastRunAppSentForSynced = "";
							}
							if (!string.IsNullOrEmpty(this.mSwitchWhenPackageNameRecieved) && string.Equals(packageName, this.mSwitchWhenPackageNameRecieved, StringComparison.OrdinalIgnoreCase))
							{
								this.mSwitchWhenPackageNameRecieved = string.Empty;
								if (AppHandler.EventOnAppDisplayed == null)
								{
									this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
									{
										this.ParentWindow.mTopBar.mAppTabButtons.GoToTab(packageName, receivedFromImap, false);
										Publisher.PublishMessage(BrowserControlTags.tabSwitched, packageName, this.ParentWindow.mVmName);
										if (PackageActivityNames.ThirdParty.AllPUBGPackageNames.Contains(packageName))
										{
											this.DoPUBGLaunchCountHandling(packageName);
										}
										this.ParentWindow.mCommonHandler.HandlingForGameSettingsRedDotForSelectedGamePackges(packageName, true);
									}), new object[0]);
								}
								else
								{
									EventHandler<EventArgs> eventOnAppDisplayed = AppHandler.EventOnAppDisplayed;
									AppHandler.EventOnAppDisplayed = null;
									eventOnAppDisplayed(this.ParentWindow, new EventArgs());
								}
							}
							else if (this.mDefaultLauncher.Equals(packageName, StringComparison.InvariantCultureIgnoreCase))
							{
								if (!FeatureManager.Instance.IsCustomUIForDMM)
								{
									Logger.Info("Assuming app is crashed/exited going to last tab");
									this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
									{
										if (this.ParentWindow.mFrontendGrid != null)
										{
											if (this.ParentWindow.mFrontendGrid.Parent as Grid == this.ParentWindow.FrontendParentGrid)
											{
												if (this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab != null && this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.mTabType == TabType.AppTab)
												{
													this.ParentWindow.mTopBar.mAppTabButtons.CloseTab(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.TabKey, false, false, true, false, packageName);
												}
												if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
												{
													this.PerformGamingAction("", "");
													return;
												}
											}
											else
											{
												this.ParentWindow.mWelcomeTab.mFrontendPopupControl.HideWindow();
											}
										}
									}), new object[0]);
								}
							}
							else
							{
								AppIcon icon = this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon(packageName);
								if (icon != null)
								{
									this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
									{
										this.ParentWindow.mTopBar.mAppTabButtons.AddAppTab(icon.AppName, icon.PackageName, icon.ActivityName, icon.ImageName, true, false, receivedFromImap);
									}), new object[0]);
								}
							}
							this.mLastAppDisplayed = packageName;
						}
					}
				}
			}
		}

		// Token: 0x06001731 RID: 5937 RVA: 0x0000FE0A File Offset: 0x0000E00A
		public void HandleAppDisplayed(string packageName)
		{
			if (string.Equals(packageName, this.mDefaultLauncher, StringComparison.InvariantCultureIgnoreCase))
			{
				Logger.Info("Home app is displayed...closing tab");
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					if (this.ParentWindow.mFrontendGrid != null && this.ParentWindow.mFrontendGrid.Parent as Grid == this.ParentWindow.FrontendParentGrid && this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab != null && this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.mTabType == TabType.AppTab)
					{
						this.ParentWindow.mTopBar.mAppTabButtons.CloseTab(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.TabKey, false, false, true, false, "");
					}
				}), new object[0]);
			}
		}

		// Token: 0x06001732 RID: 5938 RVA: 0x0000FE48 File Offset: 0x0000E048
		internal void GoHome()
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				VmCmdHandler.RunCommand("home", this.ParentWindow.mVmName);
			});
		}

		// Token: 0x06001733 RID: 5939 RVA: 0x0008ADF8 File Offset: 0x00088FF8
		public string GetDefaultLauncher()
		{
			string result = "com.bluestacks.appmart";
			try
			{
				string text = HTTPUtils.SendRequestToGuest("getDefaultLauncher", null, this.ParentWindow.mVmName, 0, null, false, 1, 0);
				Logger.Info("GetDefaultLauncher response = " + text);
				JObject jobject = JObject.Parse(text);
				string a = jobject["result"].ToString().Trim();
				if (a == "ok")
				{
					result = jobject["defaultLauncher"].ToString().Trim();
				}
				else if (a == "error" && jobject["reason"].ToString().Trim() == "no default launcher")
				{
					result = "none";
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GetDefauntLauncher. Err." + ex.ToString());
			}
			return result;
		}

		// Token: 0x06001734 RID: 5940 RVA: 0x0000FE5C File Offset: 0x0000E05C
		internal void StartCustomActivity(Dictionary<string, string> data)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					Logger.Info("Starting a custom activity");
					foreach (KeyValuePair<string, string> keyValuePair in data)
					{
						Logger.Debug("Data = {0} , {1}", new object[]
						{
							keyValuePair.Key,
							keyValuePair.Value
						});
					}
					HTTPUtils.SendRequestToGuest("customStartActivity", data, this.ParentWindow.mVmName, 0, null, false, 1, 0);
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in launching custom activity. Err: " + ex.Message);
				}
			});
		}

		// Token: 0x06001735 RID: 5941 RVA: 0x0000FE82 File Offset: 0x0000E082
		internal void SetDefaultLauncher(string launcherName)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					Dictionary<string, string> data = new Dictionary<string, string>
					{
						{
							"d",
							launcherName
						}
					};
					string text = HTTPUtils.SendRequestToGuest("setDefaultLauncher", data, this.ParentWindow.mVmName, 0, null, false, 1, 0);
					Logger.Info("Setlauncher res: {0}", new object[]
					{
						text
					});
					data = new Dictionary<string, string>
					{
						{
							"arg",
							""
						}
					};
					text = HTTPUtils.SendRequestToGuest("home", data, this.ParentWindow.mVmName, 0, null, false, 1, 0);
					Logger.Info("the response for home command is {0}", new object[]
					{
						text
					});
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in SetDefaultLauncher. Err:{0}", new object[]
					{
						ex.ToString()
					});
				}
			});
		}

		// Token: 0x06001736 RID: 5942 RVA: 0x0008AEDC File Offset: 0x000890DC
		internal void AppUninstalled(string package)
		{
			this.ParentWindow.mWelcomeTab.mHomeApp.RemoveAppIcon(package, null);
			this.ParentWindow.mWelcomeTab.mHomeApp.RemoveAppIcon(package + "_macro", null);
			this.ParentWindow.mTopBar.mAppTabButtons.CloseTab(package, false, false, true, false, "");
			if (PackageActivityNames.ThirdParty.AllPUBGPackageNames.Contains(package))
			{
				this.ParentWindow.EngineInstanceRegistry.PUBGLaunchedCount = 0;
				this.ParentWindow.EngineInstanceRegistry.PUBGNotificationShown = false;
				return;
			}
			if (PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.Contains(package))
			{
				this.ParentWindow.EngineInstanceRegistry.CODNotificationShown = false;
				return;
			}
			if ("com.dts.freefireth".Contains(package))
			{
				this.ParentWindow.EngineInstanceRegistry.FreeFireNotificationShown = false;
				return;
			}
			if (PackageActivityNames.ThirdParty.AllSevenDeadlySinsPackageNames.Contains(package))
			{
				this.ParentWindow.EngineInstanceRegistry.SevenDeadlySinsNotificationShown = false;
				Utils.SetCustomAppSize(this.ParentWindow.mVmName, package, ScreenMode.original);
				KMManager.SelectSchemeIfPresent(this.ParentWindow, "Portrait", "appuninstalled", false);
				this.ParentWindow.EngineInstanceRegistry.SevenDeadlySinsLandscape = false;
			}
		}

		// Token: 0x06001737 RID: 5943 RVA: 0x0008B008 File Offset: 0x00089208
		internal void AppInstalled(string package)
		{
			this.ParentWindow.mWelcomeTab.mHomeApp.AddAppIcon(package);
			if (FeatureManager.Instance.IsShowAppRecommendations || !RegistryManager.Instance.IsPremium)
			{
				this.ParentWindow.mWelcomeTab.mHomeApp.UpdateRecommendedAppsInstallStatus(package);
			}
			GrmHandler.RefreshGrmIndication(package, this.ParentWindow.mVmName);
			GrmHandler.SendUpdateGrmPackagesToAndroid(this.ParentWindow.mVmName);
			GuidanceCloudInfoManager.Instance.AppsGuidanceCloudInfoRefresh();
			if (RegistryManager.Instance.FirstAppLaunchState == AppLaunchState.Fresh)
			{
				RegistryManager.Instance.FirstAppLaunchState = AppLaunchState.Installed;
			}
			if (!AppConfigurationManager.Instance.VmAppConfig[this.ParentWindow.mVmName].ContainsKey(package))
			{
				AppConfigurationManager.Instance.VmAppConfig[this.ParentWindow.mVmName][package] = new AppSettings();
			}
			AppConfigurationManager.Instance.VmAppConfig[this.ParentWindow.mVmName][package].IsAppOnboardingCompleted = false;
			AppConfigurationManager.Instance.VmAppConfig[this.ParentWindow.mVmName][package].IsGeneralAppOnBoardingCompleted = false;
		}

		// Token: 0x06001738 RID: 5944 RVA: 0x0000FEA8 File Offset: 0x0000E0A8
		internal void UpdateDefaultLauncher()
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				string text = this.GetDefaultLauncher();
				Logger.Info("DefaultLauncher " + text);
				if (text.Equals("none", StringComparison.InvariantCultureIgnoreCase))
				{
					text = "com.bluestacks.appmart";
					this.SetDefaultLauncher(text);
				}
				if (text.Equals("com.android.provision", StringComparison.InvariantCultureIgnoreCase))
				{
					text = "com.bluestacks.appmart";
				}
				this.mDefaultLauncher = text;
			});
		}

		// Token: 0x06001739 RID: 5945 RVA: 0x0000FEBC File Offset: 0x0000E0BC
		internal void SendSearchPlayRequestAsync(string searchQuery)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				if (searchQuery.Contains("search::"))
				{
					searchQuery = searchQuery.Remove(0, 8);
				}
				VmCmdHandler.RunCommand(string.Format(CultureInfo.InvariantCulture, "searchplay {0}", new object[]
				{
					searchQuery
				}), this.ParentWindow.mVmName);
			});
		}

		// Token: 0x0600173A RID: 5946 RVA: 0x0000FEE2 File Offset: 0x0000E0E2
		internal void LaunchPlayRequestAsync(string packageName)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				VmCmdHandler.RunCommand(string.Format(CultureInfo.InvariantCulture, "launchplay?pkgname={0}", new object[]
				{
					packageName
				}), this.ParentWindow.mVmName);
			});
		}

		// Token: 0x0600173B RID: 5947 RVA: 0x0000FF08 File Offset: 0x0000E108
		public void SendRunAppRequestAsync(string package, string activity = "", bool receivedFromImap = false)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				if (this.ParentWindow.SendClientActions && !receivedFromImap)
				{
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					Dictionary<string, string> value = new Dictionary<string, string>
					{
						{
							"EventAction",
							"RunApp"
						},
						{
							"Package",
							package
						},
						{
							"Activity",
							activity
						}
					};
					JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
					serializerSettings.Formatting = Newtonsoft.Json.Formatting.None;
					dictionary.Add("operationData", JsonConvert.SerializeObject(value, serializerSettings));
					this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("handleClientOperation", dictionary);
				}
				if (receivedFromImap)
				{
					this.mLastRunAppSentForSynced = package;
					if (package == "com.android.vending")
					{
						this.mSwitchWhenPackageNameRecieved = package;
					}
				}
				if (string.IsNullOrEmpty(activity))
				{
					AppIcon appIcon = this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon(package);
					if (appIcon != null)
					{
						activity = appIcon.ActivityName;
					}
					if (string.IsNullOrEmpty(activity))
					{
						activity = ".Main";
						Logger.Info("Empty activity name ovveriding .Main for package: " + package);
					}
				}
				if (PackageActivityNames.ThirdParty.AllPUBGPackageNames.Contains(package))
				{
					string displayQualityPubg = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityPubg;
					string gamingResolutionPubg = RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GamingResolutionPubg;
					if (string.Equals(displayQualityPubg, "-1", StringComparison.InvariantCulture) && string.Equals(gamingResolutionPubg, "1", StringComparison.InvariantCulture))
					{
						this.SendRunex(package, activity);
						return;
					}
					StringBuilder stringBuilder = new StringBuilder();
					using (JsonWriter jsonWriter = new JsonTextWriter(new StringWriter(stringBuilder)))
					{
						jsonWriter.WriteStartObject();
						if (string.Equals(RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityPubg, "-1", StringComparison.InvariantCulture))
						{
							jsonWriter.WritePropertyName("renderqualitylevel");
							jsonWriter.WriteValue("0");
						}
						else
						{
							jsonWriter.WritePropertyName("renderqualitylevel");
							jsonWriter.WriteValue(RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityPubg);
						}
						jsonWriter.WritePropertyName("contentscale");
						jsonWriter.WriteValue(RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GamingResolutionPubg);
						jsonWriter.WriteEndObject();
					}
					Dictionary<string, string> data = new Dictionary<string, string>
					{
						{
							"component",
							package + "/" + activity
						},
						{
							"extras",
							stringBuilder.ToString()
						}
					};
					string str = HTTPUtils.SendRequestToGuest("customStartActivity", data, this.ParentWindow.mVmName, 0, null, false, 1, 0);
					Logger.Info("The response we get is: " + str);
					return;
				}
				else
				{
					if (PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.Contains(package))
					{
						int value2 = int.Parse(RegistryManager.Instance.Guest[this.ParentWindow.mVmName].DisplayQualityCOD, CultureInfo.InvariantCulture);
						int value3 = int.Parse(RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GamingResolutionCOD, CultureInfo.InvariantCulture);
						int value4 = int.Parse("1", CultureInfo.InvariantCulture);
						StringBuilder stringBuilder2 = new StringBuilder();
						using (JsonWriter jsonWriter2 = new JsonTextWriter(new StringWriter(stringBuilder2)))
						{
							jsonWriter2.WriteStartObject();
							if (string.Equals(value2.ToString(CultureInfo.InvariantCulture), "-1", StringComparison.InvariantCulture))
							{
								jsonWriter2.WritePropertyName("QualityLevel");
								jsonWriter2.WriteValue(int.Parse("0", CultureInfo.InvariantCulture));
							}
							else
							{
								jsonWriter2.WritePropertyName("QualityLevel");
								jsonWriter2.WriteValue(value2);
							}
							jsonWriter2.WritePropertyName("ResolutionHeight");
							jsonWriter2.WriteValue(value3);
							jsonWriter2.WritePropertyName("FrameRateLevel");
							jsonWriter2.WriteValue(value4);
							jsonWriter2.WriteEndObject();
						}
						Dictionary<string, string> data2 = new Dictionary<string, string>
						{
							{
								"component",
								package + "/" + activity
							},
							{
								"extras",
								stringBuilder2.ToString()
							}
						};
						string str2 = HTTPUtils.SendRequestToGuest("customStartActivity", data2, this.ParentWindow.mVmName, 0, null, false, 1, 0);
						Logger.Info("The response we get is: " + str2);
						return;
					}
					if ("com.android.chrome".Equals(package, StringComparison.InvariantCultureIgnoreCase))
					{
						HTTPUtils.SendRequestToGuest("launchchrome", null, this.ParentWindow.mVmName, 0, null, false, 1, 0);
						return;
					}
					this.SendRunex(package, activity);
					return;
				}
			});
		}

		// Token: 0x0600173C RID: 5948 RVA: 0x0000FF3C File Offset: 0x0000E13C
		internal void SendRunex(string package, string activity)
		{
			VmCmdHandler.RunCommand(string.Format(CultureInfo.InvariantCulture, "runex {0}/{1}", new object[]
			{
				package,
				activity
			}), this.ParentWindow.mVmName);
		}

		// Token: 0x0600173D RID: 5949 RVA: 0x0000FF6C File Offset: 0x0000E16C
		internal void StopAppRequest(string packageName)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					Logger.Info("Will send stop {0} request", new object[]
					{
						packageName
					});
					Dictionary<string, string> data = new Dictionary<string, string>
					{
						{
							"appPackage",
							packageName
						}
					};
					string text = this.ParentWindow.mFrontendHandler.SendFrontendRequest("stopAppInfo", data);
					Logger.Info("the response we get is {0}", new object[]
					{
						text
					});
					Logger.Info(VmCmdHandler.RunCommand(string.Format(CultureInfo.InvariantCulture, "StopApp {0}", new object[]
					{
						packageName
					}), this.ParentWindow.mVmName));
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in StopAppRequest. Err : " + ex.ToString());
				}
			});
		}

		// Token: 0x0600173E RID: 5950 RVA: 0x0000FF92 File Offset: 0x0000E192
		internal void SendRequestToRemoveAccountAndCloseWindowASync(bool closeWindow = false)
		{
			Action <>9__1;
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				try
				{
					string str = HTTPUtils.SendRequestToGuest("removeAccountsInfo", null, this.ParentWindow.mVmName, 0, null, false, 1, 0);
					Logger.Info("Account removed response: " + str);
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in removing account, Ex: " + ex.Message);
				}
				if (closeWindow)
				{
					Dispatcher dispatcher = this.ParentWindow.Dispatcher;
					Action method;
					if ((method = <>9__1) == null)
					{
						method = (<>9__1 = delegate()
						{
							this.ParentWindow.ForceCloseWindow();
						});
					}
					dispatcher.Invoke(method, new object[0]);
				}
			});
		}

		// Token: 0x0600173F RID: 5951 RVA: 0x0008B130 File Offset: 0x00089330
		internal void WriteXMl(bool isAppInstall, string packageName, DateTime timestamp)
		{
			if (isAppInstall)
			{
				this.CdnAppdict[packageName] = timestamp;
				using (StringWriter stringWriter = new StringWriter())
				{
					new XmlSerializer(typeof(SerializableDictionary<string, DateTime>)).Serialize(stringWriter, this.CdnAppdict);
					RegistryManager.Instance.CDNAppsTimeStamp = stringWriter.ToString();
					return;
				}
			}
			if (this.CdnAppdict.ContainsKey(packageName))
			{
				this.CdnAppdict.Remove(packageName);
				using (StringWriter stringWriter2 = new StringWriter())
				{
					new XmlSerializer(typeof(SerializableDictionary<string, DateTime>)).Serialize(stringWriter2, this.CdnAppdict);
					RegistryManager.Instance.CDNAppsTimeStamp = stringWriter2.ToString();
				}
			}
		}

		// Token: 0x06001740 RID: 5952 RVA: 0x0008B200 File Offset: 0x00089400
		internal void PerformGamingAction(string pkgName = "", string activityName = "")
		{
			GenericAction action;
			if (string.IsNullOrEmpty(pkgName))
			{
				pkgName = GameConfig.Instance.PkgName;
				activityName = GameConfig.Instance.ActivityName;
				action = GameConfig.Instance.AppGenericAction;
			}
			else
			{
				action = GenericAction.InstallPlay;
			}
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (this.IsAppInstalled(pkgName))
				{
					this.SendRunAppRequestAsync(pkgName, "", false);
					return;
				}
				if (action == GenericAction.InstallPlay)
				{
					this.LaunchPlayRequestAsync(pkgName);
				}
			}), new object[0]);
		}

		// Token: 0x06001741 RID: 5953 RVA: 0x0008B288 File Offset: 0x00089488
		private void DoPUBGLaunchCountHandling(string packageName)
		{
			this.ParentWindow.EngineInstanceRegistry.PUBGLaunchedCount++;
			if (this.ParentWindow.EngineInstanceRegistry.PUBGLaunchedCount == 2147483647)
			{
				this.ParentWindow.EngineInstanceRegistry.PUBGLaunchedCount = 3;
			}
			if (PackageActivityNames.ThirdParty.AllPUBGPackageNames.Contains(packageName) && this.ParentWindow.EngineInstanceRegistry.PUBGLaunchedCount == 2 && !this.ParentWindow.EngineInstanceRegistry.PUBGNotificationShown)
			{
				this.ParentWindow.mCommonHandler.ToggleSettingsBtnNotification(true);
			}
		}

		// Token: 0x04000EE2 RID: 3810
		private MainWindow ParentWindow;

		// Token: 0x04000EE6 RID: 3814
		private Thread mOtsCheckThread;

		// Token: 0x04000EE7 RID: 3815
		private object mOtsCheckLock = new object();

		// Token: 0x04000EE8 RID: 3816
		private int oneSecond = 1000;

		// Token: 0x04000EEA RID: 3818
		private bool mIsOneTimeSetupCompleted;

		// Token: 0x04000EEB RID: 3819
		private bool mIsGuestReady;

		// Token: 0x04000EEC RID: 3820
		internal bool mGuestReadyCheckStarted;

		// Token: 0x04000EED RID: 3821
		internal string mDefaultLauncher = "com.bluestacks.appmart";

		// Token: 0x04000EEE RID: 3822
		private object sLockObject = new object();

		// Token: 0x04000EEF RID: 3823
		private object sOTSLock = new object();

		// Token: 0x04000EF0 RID: 3824
		private string mSwitchWhenPackageNameRecieved = string.Empty;
	}
}
