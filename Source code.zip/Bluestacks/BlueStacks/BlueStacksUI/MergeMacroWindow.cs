﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000A8 RID: 168
	public class MergeMacroWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x170001BC RID: 444
		// (get) Token: 0x060006AF RID: 1711 RVA: 0x000065BC File Offset: 0x000047BC
		// (set) Token: 0x060006B0 RID: 1712 RVA: 0x000065C4 File Offset: 0x000047C4
		internal MacroRecording MergedMacroRecording { get; set; }

		// Token: 0x060006B1 RID: 1713 RVA: 0x000065CD File Offset: 0x000047CD
		public MergeMacroWindow(MacroRecorderWindow window, MainWindow mainWindow)
		{
			this.InitializeComponent();
			this.mMacroRecorderWindow = window;
			this.ParentWindow = mainWindow;
		}

		// Token: 0x060006B2 RID: 1714 RVA: 0x0002782C File Offset: 0x00025A2C
		internal void Init(MacroRecording mergedMacro = null, SingleMacroControl singleMacroControl = null)
		{
			try
			{
				this.mMacroNameStackPanel.Visibility = ((mergedMacro == null) ? Visibility.Visible : Visibility.Collapsed);
				this.mOriginalMacroRecording = mergedMacro;
				int num = 0;
				using (List<MacroRecording>.Enumerator enumerator = (from MacroRecording o in MacroGraph.Instance.Vertices
				orderby DateTime.ParseExact(o.TimeCreated, "yyyyMMddTHHmmss", CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal)
				select o).ToList<MacroRecording>().GetEnumerator())
				{
					Func<BiDirectionalVertex<MacroRecording>, bool> <>9__1;
					while (enumerator.MoveNext())
					{
						MacroRecording record = enumerator.Current;
						this.ParentWindow.mIsScriptsPresent = true;
						if (!record.Equals(mergedMacro))
						{
							if (mergedMacro != null)
							{
								BiDirectionalGraph<MacroRecording> instance = MacroGraph.Instance;
								IEnumerable<BiDirectionalVertex<MacroRecording>> vertices = MacroGraph.Instance.Vertices;
								Func<BiDirectionalVertex<MacroRecording>, bool> predicate;
								if ((predicate = <>9__1) == null)
								{
									predicate = (<>9__1 = ((BiDirectionalVertex<MacroRecording> macro) => macro.Equals(mergedMacro)));
								}
								if (instance.DoesParentExist(vertices.Where(predicate).FirstOrDefault<BiDirectionalVertex<MacroRecording>>(), (from macro in MacroGraph.Instance.Vertices
								where macro.Equals(record)
								select macro).FirstOrDefault<BiDirectionalVertex<MacroRecording>>()))
								{
									continue;
								}
							}
							MacroToAdd macroToAdd = new MacroToAdd(this, record.Name);
							if (num % 2 == 0)
							{
								BlueStacksUIBinding.BindColor(macroToAdd, Control.BackgroundProperty, "DarkBandingColor");
							}
							else
							{
								BlueStacksUIBinding.BindColor(macroToAdd, Control.BackgroundProperty, "LightBandingColor");
							}
							this.mCurrentMacroScripts.Children.Add(macroToAdd);
							num++;
						}
					}
				}
				if (singleMacroControl != null)
				{
					this.mSingleMacroControl = singleMacroControl;
				}
				if (mergedMacro == null)
				{
					string timeCreated = DateTime.Now.ToString("yyyyMMddTHHmmss", CultureInfo.InvariantCulture);
					this.MergedMacroRecording = new MacroRecording
					{
						Name = CommonHandlers.GetMacroName("Macro"),
						TimeCreated = timeCreated,
						MergedMacroConfigurations = new ObservableCollection<MergedMacroConfiguration>()
					};
					this.mUnifyButton.Visibility = Visibility.Collapsed;
					BlueStacksUIBinding.Bind(this.mMergeButton, "STRING_MERGE");
					BlueStacksUIBinding.Bind(this.mMergeMacroWindowHeading, "STRING_MERGE_MACROS", "");
				}
				else
				{
					this.MergedMacroRecording = mergedMacro.DeepCopy<MacroRecording>();
					BlueStacksUIBinding.Bind(this.mMergeButton, "STRING_UPDATE_SETTING");
					BlueStacksUIBinding.Bind(this.mMergeMacroWindowHeading, "STRING_EDIT_MERGED_MACRO", "");
					this.mUnifyButton.Visibility = Visibility.Visible;
				}
				this.MacroName.Text = this.MergedMacroRecording.Name;
				this.mMacroDragControl.Init();
				this.MergedMacroRecording.MergedMacroConfigurations.CollectionChanged -= this.Items_CollectionChanged;
				this.MergedMacroRecording.MergedMacroConfigurations.CollectionChanged += this.Items_CollectionChanged;
				this.Items_CollectionChanged(null, null);
				this.DataModificationTracker.Lock(this.mOriginalMacroRecording, new List<string>
				{
					"IsGroupButtonVisible",
					"IsUnGroupButtonVisible",
					"IsSettingsVisible",
					"IsFirstListBoxItem",
					"IsLastListBoxItem",
					"Parents",
					"Childs",
					"IsVisited"
				}, true);
				this.CheckIfCanSave();
			}
			catch (Exception ex)
			{
				Logger.Error("Error in export window init err: " + ex.ToString());
			}
		}

		// Token: 0x060006B3 RID: 1715 RVA: 0x00027BB0 File Offset: 0x00025DB0
		private void Items_CollectionChanged(object sender, NotifyCollectionChangedEventArgs args)
		{
			if (args != null)
			{
				if (args.OldItems != null)
				{
					foreach (object obj in args.OldItems)
					{
						((INotifyPropertyChanged)obj).PropertyChanged -= this.Item_PropertyChanged;
					}
				}
				if (args.NewItems == null)
				{
					goto IL_E1;
				}
				using (IEnumerator enumerator = args.NewItems.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						object obj2 = enumerator.Current;
						((INotifyPropertyChanged)obj2).PropertyChanged += this.Item_PropertyChanged;
					}
					goto IL_E1;
				}
			}
			foreach (MergedMacroConfiguration mergedMacroConfiguration in this.MergedMacroRecording.MergedMacroConfigurations)
			{
				mergedMacroConfiguration.PropertyChanged += this.Item_PropertyChanged;
			}
			IL_E1:
			foreach (MergedMacroConfiguration mergedMacroConfiguration2 in this.MergedMacroRecording.MergedMacroConfigurations)
			{
				mergedMacroConfiguration2.IsGroupButtonVisible = true;
				mergedMacroConfiguration2.IsFirstListBoxItem = false;
				mergedMacroConfiguration2.IsLastListBoxItem = false;
				mergedMacroConfiguration2.IsUnGroupButtonVisible = (mergedMacroConfiguration2.MacrosToRun.Count > 1);
			}
			if (this.MergedMacroRecording.MergedMacroConfigurations.Count > 0)
			{
				this.MergedMacroRecording.MergedMacroConfigurations[0].IsGroupButtonVisible = false;
				this.MergedMacroRecording.MergedMacroConfigurations[0].IsFirstListBoxItem = true;
				this.MergedMacroRecording.MergedMacroConfigurations[this.MergedMacroRecording.MergedMacroConfigurations.Count - 1].IsLastListBoxItem = true;
				this.mMergedMacrosHeader.Visibility = Visibility.Visible;
				this.mHelpCenterImage.Visibility = Visibility.Visible;
				this.mMergedMacrosFooter.IsEnabled = true;
			}
			else
			{
				this.mMergedMacrosHeader.Visibility = Visibility.Collapsed;
				this.mHelpCenterImage.Visibility = Visibility.Collapsed;
				this.mMergedMacrosFooter.IsEnabled = false;
			}
			this.CheckIfCanSave();
		}

		// Token: 0x060006B4 RID: 1716 RVA: 0x000065F4 File Offset: 0x000047F4
		private void Item_PropertyChanged(object sender, PropertyChangedEventArgs args)
		{
			this.CheckIfCanSave();
		}

		// Token: 0x060006B5 RID: 1717 RVA: 0x00027DE0 File Offset: 0x00025FE0
		private void CheckIfCanSave()
		{
			bool flag = this.MergedMacroRecording.MergedMacroConfigurations.Count > 0 && (this.MergedMacroRecording.MergedMacroConfigurations.Count > 1 || this.MergedMacroRecording.MergedMacroConfigurations[0].MacrosToRun.Count > 1);
			UIElement uielement = this.mMergeButton;
			bool isEnabled;
			if ((this.mMacroNameStackPanel.Visibility == Visibility.Collapsed || this.MacroName.InputTextValidity == TextValidityOptions.Success) && flag)
			{
				if (this.MergedMacroRecording.MergedMacroConfigurations.All((MergedMacroConfiguration macro) => macro.LoopCount > 0))
				{
					isEnabled = this.DataModificationTracker.HasChanged(this.MergedMacroRecording);
					goto IL_B9;
				}
			}
			isEnabled = false;
			IL_B9:
			uielement.IsEnabled = isEnabled;
			this.mUnifyButton.IsEnabled = flag;
			this.mMacroSettings.IsEnabled = flag;
		}

		// Token: 0x060006B6 RID: 1718 RVA: 0x00027EC4 File Offset: 0x000260C4
		private void Close_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "merge_macro_close", null, null, null, null, null);
			this.CloseWindow();
		}

		// Token: 0x060006B7 RID: 1719 RVA: 0x000065FC File Offset: 0x000047FC
		private void CloseWindow()
		{
			base.Close();
			this.mMacroRecorderWindow.mMergeMacroWindow = null;
			this.mMacroRecorderWindow.mOverlayGrid.Visibility = Visibility.Collapsed;
			if (this.mSingleMacroControl != null && this.mOriginalMacroRecording != null)
			{
				this.UpdateMacroRecordingInfoForSingleMacroControl();
			}
		}

		// Token: 0x060006B8 RID: 1720 RVA: 0x00027F00 File Offset: 0x00026100
		private void UpdateMacroRecordingInfoForSingleMacroControl()
		{
			MacroRecording record = JsonConvert.DeserializeObject<MacroRecording>(File.ReadAllText(CommonHandlers.GetCompleteMacroRecordingPath(this.mOriginalMacroRecording.Name)), Utils.GetSerializerSettings());
			this.mSingleMacroControl.UpdateMacroRecordingObject(record);
		}

		// Token: 0x060006B9 RID: 1721 RVA: 0x00027F3C File Offset: 0x0002613C
		private void MergeButton_Click(object sender, RoutedEventArgs e)
		{
			if (this.mOriginalMacroRecording == null)
			{
				this.mOriginalMacroRecording = new MacroRecording();
			}
			this.mOriginalMacroRecording.CopyFrom(this.MergedMacroRecording);
			this.mMacroRecorderWindow.SaveMacroRecord(this.mOriginalMacroRecording);
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "merge_macro_success", null, null, null, null, null);
			this.CloseWindow();
		}

		// Token: 0x060006BA RID: 1722 RVA: 0x00027FAC File Offset: 0x000261AC
		private void MacroName_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (this.mMacroNameStackPanel.Visibility == Visibility.Visible)
			{
				if (string.IsNullOrEmpty(this.MacroName.Text.Trim()))
				{
					this.mErrorText.Text = LocaleStrings.GetLocalizedString("STRING_MACRO_NAME_NULL_MESSAGE");
					this.MacroName.InputTextValidity = TextValidityOptions.Error;
				}
				else if (this.MacroName.Text.Trim().IndexOfAny(System.IO.Path.GetInvalidFileNameChars()) >= 0)
				{
					this.mErrorText.Text = string.Format(CultureInfo.InvariantCulture, "{0} {1} {2}", new object[]
					{
						LocaleStrings.GetLocalizedString("STRING_MACRO_NAME_ERROR"),
						Environment.NewLine,
						"\\ / : * ? \" < > |"
					});
					this.MacroName.InputTextValidity = TextValidityOptions.Error;
				}
				else if (Constants.ReservedFileNamesList.Contains(this.MacroName.Text.Trim().ToLower(CultureInfo.InvariantCulture)))
				{
					this.mErrorText.Text = LocaleStrings.GetLocalizedString("STRING_MACRO_FILE_NAME_ERROR");
					this.MacroName.InputTextValidity = TextValidityOptions.Error;
				}
				else if (MacroGraph.Instance.Vertices.Cast<MacroRecording>().Any((MacroRecording macro) => string.Equals(macro.Name, this.MacroName.Text.Trim(), StringComparison.InvariantCultureIgnoreCase)))
				{
					this.mErrorText.Text = LocaleStrings.GetLocalizedString("STRING_MACRO_NOT_SAVED_MESSAGE");
					this.MacroName.InputTextValidity = TextValidityOptions.Error;
				}
				else
				{
					this.MacroName.InputTextValidity = TextValidityOptions.Success;
				}
				this.mErrorNamePopup.IsOpen = (this.MacroName.InputTextValidity == TextValidityOptions.Error);
				this.MergedMacroRecording.Name = this.MacroName.Text;
				this.CheckIfCanSave();
			}
		}

		// Token: 0x060006BB RID: 1723 RVA: 0x00028140 File Offset: 0x00026340
		private void MacroSettings_Click(object sender, RoutedEventArgs e)
		{
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "merge_macro_settings", null, null, null, null, null);
			if (this.mMacroSettingsWindow == null || this.mMacroSettingsWindow.IsClosed)
			{
				this.mMacroSettingsWindow = new MacroSettingsWindow(this.ParentWindow, this.MergedMacroRecording, this.mMacroRecorderWindow);
				this.mMacroSettingsWindow.Closed += delegate(object o, EventArgs e)
				{
					this.CheckIfCanSave();
				};
			}
			this.mMacroSettingsWindow.ShowDialog();
		}

		// Token: 0x060006BC RID: 1724 RVA: 0x000281CC File Offset: 0x000263CC
		private void UnifyButton_Click(object sender, RoutedEventArgs e)
		{
			if (this.mOriginalMacroRecording == null)
			{
				this.mOriginalMacroRecording = new MacroRecording();
			}
			this.mOriginalMacroRecording.CopyFrom(this.MergedMacroRecording);
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.TitleTextBlock.Text = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_UNIFY_0"), new object[]
			{
				this.mOriginalMacroRecording.Name
			});
			BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_UNIFIYING_LOSE_CONFIGURE", "");
			bool closeWindow = false;
			customMessageWindow.AddButton(ButtonColors.Blue, string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_CONTINUE"), new object[]
			{
				""
			}).Trim(), delegate(object o, EventArgs evt)
			{
				ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "merge_unify", null, null, null, null, null);
				this.mMacroRecorderWindow.FlattenRecording(this.mOriginalMacroRecording, false);
				CommonHandlers.SaveMacroJson(this.mOriginalMacroRecording, this.mOriginalMacroRecording.Name + ".json");
				CommonHandlers.RefreshAllMacroRecorderWindow();
				closeWindow = true;
			}, null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", delegate(object o, EventArgs evt)
			{
				ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "merge_unify_cancel", null, null, null, null, null);
			}, null, false, null);
			customMessageWindow.CloseButtonHandle(delegate(object o, EventArgs e)
			{
				ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "merge_unify_cancel", null, null, null, null, null);
			}, null);
			customMessageWindow.Owner = this;
			customMessageWindow.ShowDialog();
			if (closeWindow)
			{
				this.CloseWindow();
			}
		}

		// Token: 0x060006BD RID: 1725 RVA: 0x00006637 File Offset: 0x00004837
		private void MacroName_MouseEnter(object sender, MouseEventArgs e)
		{
			if (this.MacroName.InputTextValidity == TextValidityOptions.Error)
			{
				this.mErrorNamePopup.IsOpen = true;
				this.mErrorNamePopup.StaysOpen = true;
				return;
			}
			this.mErrorNamePopup.IsOpen = false;
		}

		// Token: 0x060006BE RID: 1726 RVA: 0x0000666C File Offset: 0x0000486C
		private void MacroName_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mErrorNamePopup.IsOpen = false;
		}

		// Token: 0x060006BF RID: 1727 RVA: 0x0000667A File Offset: 0x0000487A
		private void mHelpCenterImage_MouseDown(object sender, MouseButtonEventArgs e)
		{
			Utils.OpenUrl(WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
			{
				WebHelper.GetServerHost(),
				"help_articles"
			})) + "&article=MergeMacro_Help");
		}

		// Token: 0x060006C0 RID: 1728 RVA: 0x0002830C File Offset: 0x0002650C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/mergemacrowindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060006C1 RID: 1729 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060006C2 RID: 1730 RVA: 0x0002833C File Offset: 0x0002653C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				this.mMergeMacroWindowHeading = (TextBlock)target;
				return;
			case 3:
				this.mUnifyButton = (CustomButton)target;
				this.mUnifyButton.Click += this.UnifyButton_Click;
				return;
			case 4:
				((CustomPictureBox)target).MouseLeftButtonUp += this.Close_MouseLeftButtonUp;
				return;
			case 5:
				this.mCurrentMacroScripts = (StackPanel)target;
				return;
			case 6:
				this.mLineSeperator = (Line)target;
				return;
			case 7:
				this.mMergedMacrosHeader = (TextBlock)target;
				return;
			case 8:
				this.mHelpCenterImage = (CustomPictureBox)target;
				this.mHelpCenterImage.MouseDown += this.mHelpCenterImage_MouseDown;
				return;
			case 9:
				this.mMacroDragControl = (MacroAddedDragControl)target;
				return;
			case 10:
				this.mMergedMacrosFooter = (StackPanel)target;
				return;
			case 11:
				this.mMacroNameStackPanel = (StackPanel)target;
				return;
			case 12:
				this.MacroName = (CustomTextBox)target;
				this.MacroName.MouseEnter += this.MacroName_MouseEnter;
				this.MacroName.MouseLeave += this.MacroName_MouseLeave;
				this.MacroName.TextChanged += this.MacroName_TextChanged;
				return;
			case 13:
				this.mMacroSettings = (CustomButton)target;
				this.mMacroSettings.Click += this.MacroSettings_Click;
				return;
			case 14:
				this.mMergeButton = (CustomButton)target;
				this.mMergeButton.Click += this.MergeButton_Click;
				return;
			case 15:
				this.mErrorNamePopup = (CustomPopUp)target;
				return;
			case 16:
				this.mMaskBorder1 = (Border)target;
				return;
			case 17:
				this.mErrorText = (TextBlock)target;
				return;
			case 18:
				this.mDownArrow = (System.Windows.Shapes.Path)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040003C6 RID: 966
		private readonly DataModificationTracker DataModificationTracker = new DataModificationTracker();

		// Token: 0x040003C7 RID: 967
		private MacroRecorderWindow mMacroRecorderWindow;

		// Token: 0x040003C8 RID: 968
		private MainWindow ParentWindow;

		// Token: 0x040003C9 RID: 969
		private MacroRecording mOriginalMacroRecording;

		// Token: 0x040003CB RID: 971
		internal int mAddedMacroTag;

		// Token: 0x040003CC RID: 972
		private MacroSettingsWindow mMacroSettingsWindow;

		// Token: 0x040003CD RID: 973
		private SingleMacroControl mSingleMacroControl;

		// Token: 0x040003CE RID: 974
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder;

		// Token: 0x040003CF RID: 975
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mMergeMacroWindowHeading;

		// Token: 0x040003D0 RID: 976
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mUnifyButton;

		// Token: 0x040003D1 RID: 977
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mCurrentMacroScripts;

		// Token: 0x040003D2 RID: 978
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Line mLineSeperator;

		// Token: 0x040003D3 RID: 979
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mMergedMacrosHeader;

		// Token: 0x040003D4 RID: 980
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mHelpCenterImage;

		// Token: 0x040003D5 RID: 981
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal MacroAddedDragControl mMacroDragControl;

		// Token: 0x040003D6 RID: 982
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mMergedMacrosFooter;

		// Token: 0x040003D7 RID: 983
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mMacroNameStackPanel;

		// Token: 0x040003D8 RID: 984
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox MacroName;

		// Token: 0x040003D9 RID: 985
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mMacroSettings;

		// Token: 0x040003DA RID: 986
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mMergeButton;

		// Token: 0x040003DB RID: 987
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mErrorNamePopup;

		// Token: 0x040003DC RID: 988
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder1;

		// Token: 0x040003DD RID: 989
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mErrorText;

		// Token: 0x040003DE RID: 990
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal System.Windows.Shapes.Path mDownArrow;

		// Token: 0x040003DF RID: 991
		private bool _contentLoaded;
	}
}
