﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000C9 RID: 201
	public class NotificationDrawerItem : UserControl, IComponentConnector
	{
		// Token: 0x06000833 RID: 2099 RVA: 0x000073BD File Offset: 0x000055BD
		public NotificationDrawerItem()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000834 RID: 2100 RVA: 0x0002FD98 File Offset: 0x0002DF98
		internal void InitFromGenricNotificationItem(GenericNotificationItem item, MainWindow parentWin)
		{
			this.ParentWindow = parentWin;
			this.Id = item.Id;
			this.titleText.Text = item.Title;
			this.messageText.Text = item.Message;
			if (!item.IsRead)
			{
				this.ChangeToUnreadBackground();
			}
			else
			{
				this.ChangeToReadBackground();
			}
			if (!string.IsNullOrEmpty(item.NotificationMenuImageName) && !string.IsNullOrEmpty(item.NotificationMenuImageUrl) && !File.Exists(Path.Combine(RegistryStrings.PromotionDirectory, item.NotificationMenuImageName)))
			{
				item.NotificationMenuImageName = Utils.TinyDownloader(item.NotificationMenuImageUrl, item.NotificationMenuImageName, RegistryStrings.PromotionDirectory, false);
			}
			this.icon.ImageName = item.NotificationMenuImageName;
			this.dateText.Text = DateTimeHelper.GetReadableDateTimeString(item.CreationTime);
		}

		// Token: 0x06000835 RID: 2101 RVA: 0x0002FE68 File Offset: 0x0002E068
		private void UserControl_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mCloseBtn.IsMouseOver)
			{
				this.ParentWindow.mTopBar.mNotificationCentrePopup.IsOpen = false;
				NotificationDrawer mNotificationDrawerControl = this.ParentWindow.mTopBar.mNotificationDrawerControl;
				GenericNotificationManager instance = GenericNotificationManager.Instance;
				List<string> list = new List<string>();
				list.Add(this.Id);
				mNotificationDrawerControl.Populate(instance.MarkNotification(list, delegate(GenericNotificationItem x)
				{
					x.IsDeleted = true;
				}));
				this.ParentWindow.mTopBar.mNotificationCentrePopup.IsOpen = true;
				this.ParentWindow.mTopBar.RefreshNotificationCentreButton();
				return;
			}
			if (this.ParentWindow != null && this.ParentWindow.mGuestBootCompleted)
			{
				GenericNotificationItem notificationItem = GenericNotificationManager.Instance.GetNotificationItem(this.Id);
				if (notificationItem != null)
				{
					this.ParentWindow.Utils.HandleGenericActionFromDictionary(notificationItem.ExtraPayload, "notification_drawer", notificationItem.NotificationMenuImageName);
					ClientStats.SendMiscellaneousStatsAsync("NotificationDrawerItemClicked", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, notificationItem.Id, notificationItem.Title, JsonConvert.SerializeObject(notificationItem.ExtraPayload), null, null, null);
					GenericNotificationManager instance2 = GenericNotificationManager.Instance;
					List<string> list2 = new List<string>();
					list2.Add(notificationItem.Id);
					instance2.MarkNotification(list2, delegate(GenericNotificationItem x)
					{
						x.IsRead = true;
					});
					this.ChangeToReadBackground();
					this.ParentWindow.mTopBar.RefreshNotificationCentreButton();
				}
			}
		}

		// Token: 0x06000836 RID: 2102 RVA: 0x000073CB File Offset: 0x000055CB
		internal void ChangeToUnreadBackground()
		{
			base.Background = Brushes.Transparent;
		}

		// Token: 0x06000837 RID: 2103 RVA: 0x000073D8 File Offset: 0x000055D8
		internal void ChangeToReadBackground()
		{
			base.Opacity = 0.5;
			base.Background = Brushes.Transparent;
		}

		// Token: 0x06000838 RID: 2104 RVA: 0x000073F4 File Offset: 0x000055F4
		private void UserControl_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mCloseBtn.Visibility = Visibility.Visible;
			BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x06000839 RID: 2105 RVA: 0x00007412 File Offset: 0x00005612
		private void UserControl_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mCloseBtn.Visibility = Visibility.Hidden;
			if (!GenericNotificationManager.Instance.GetNotificationItem(this.Id).IsRead)
			{
				this.ChangeToUnreadBackground();
				return;
			}
			this.ChangeToReadBackground();
		}

		// Token: 0x0600083A RID: 2106 RVA: 0x0002FFF0 File Offset: 0x0002E1F0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/genericnotification/notificationdraweritem.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600083B RID: 2107 RVA: 0x00030020 File Offset: 0x0002E220
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((NotificationDrawerItem)target).MouseLeftButtonUp += this.UserControl_MouseLeftButtonUp;
				((NotificationDrawerItem)target).MouseEnter += this.UserControl_MouseEnter;
				((NotificationDrawerItem)target).MouseLeave += this.UserControl_MouseLeave;
				return;
			case 2:
				this.icon = (CustomPictureBox)target;
				return;
			case 3:
				this.titleText = (TextBlock)target;
				return;
			case 4:
				this.dateText = (TextBlock)target;
				return;
			case 5:
				this.messageText = (TextBlock)target;
				return;
			case 6:
				this.mCloseBtn = (CustomPictureBox)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040004E3 RID: 1251
		internal string Id;

		// Token: 0x040004E4 RID: 1252
		private MainWindow ParentWindow;

		// Token: 0x040004E5 RID: 1253
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox icon;

		// Token: 0x040004E6 RID: 1254
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock titleText;

		// Token: 0x040004E7 RID: 1255
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock dateText;

		// Token: 0x040004E8 RID: 1256
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock messageText;

		// Token: 0x040004E9 RID: 1257
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCloseBtn;

		// Token: 0x040004EA RID: 1258
		private bool _contentLoaded;
	}
}
