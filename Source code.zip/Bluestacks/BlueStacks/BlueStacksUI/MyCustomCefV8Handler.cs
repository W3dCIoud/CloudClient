﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using BlueStacks.BlueStacksUI.BTv;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Xilium.CefGlue;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001FA RID: 506
	internal class MyCustomCefV8Handler : CefV8Handler
	{
		// Token: 0x06001279 RID: 4729 RVA: 0x0000D151 File Offset: 0x0000B351
		protected override bool Execute(string name, CefV8Value obj, CefV8Value[] arguments, out CefV8Value returnValue, out string exception)
		{
			returnValue = CefV8Value.CreateString("");
			this.ReceiveJsFunctionCall(arguments, ref returnValue);
			exception = null;
			return true;
		}

		// Token: 0x0600127A RID: 4730 RVA: 0x00070E4C File Offset: 0x0006F04C
		private void ReceiveJsFunctionCall(CefV8Value[] arguments, ref CefV8Value returnValue)
		{
			JObject jobject = JObject.Parse(arguments[0].GetStringValue());
			string text = jobject["data"].ToString();
			if (string.IsNullOrEmpty(text) || text.Equals("null", StringComparison.InvariantCultureIgnoreCase))
			{
				text = "[]";
			}
			JArray jarray = JArray.Parse(text);
			object[] array = null;
			if (!jarray.IsNullOrEmpty())
			{
				array = new object[jarray.Count];
				for (int i = 0; i < jarray.Count; i++)
				{
					array[i] = jarray[i].ToString();
				}
			}
			try
			{
				try
				{
					if (jobject.ContainsKey("callbackFunction"))
					{
						this.mCallBackFunction = jobject["callbackFunction"].ToString();
					}
				}
				catch
				{
					Logger.Info("Error in callback function name.");
				}
				if (jobject["calledFunction"].ToString().IndexOf("LogInfo", StringComparison.InvariantCulture) == -1)
				{
					Logger.Debug("Calling function from GM API.." + jobject["calledFunction"].ToString());
				}
				jobject["calledFunction"].ToString();
				object obj;
				try
				{
					Type[] typeArray = Type.GetTypeArray(array);
					obj = base.GetType().GetMethod(jobject["calledFunction"].ToString(), typeArray).Invoke(this, array);
				}
				catch (Exception)
				{
					obj = base.GetType().GetMethod(jobject["calledFunction"].ToString()).Invoke(this, array);
				}
				if (obj != null)
				{
					returnValue = CefV8Value.CreateString((string)obj);
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Error in ReceiveJSFunctionCall: " + ex.ToString());
			}
		}

		// Token: 0x0600127B RID: 4731 RVA: 0x00071008 File Offset: 0x0006F208
		public string isBTVInstalled()
		{
			if (!BTVManager.IsBTVInstalled())
			{
				using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("DownloadBTV"))
				{
					CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
					return "false";
				}
			}
			if (!BTVManager.IsDirectXComponentsInstalled())
			{
				using (CefProcessMessage cefProcessMessage2 = CefProcessMessage.Create("DownloadDirectX"))
				{
					CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage2);
					return "false";
				}
			}
			return "true";
		}

		// Token: 0x0600127C RID: 4732 RVA: 0x000710A4 File Offset: 0x0006F2A4
		public void sendFirebaseNotification(string data)
		{
			Logger.Debug("Got call for sendFirebaseNotification");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("sendFirebaseNotification"))
			{
				cefProcessMessage.Arguments.SetString(0, data);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x0600127D RID: 4733 RVA: 0x00071104 File Offset: 0x0006F304
		public void subscribeModule(string tag)
		{
			Logger.Info("Subscribe html module");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("subscribeModule"))
			{
				cefProcessMessage.Arguments.SetString(0, tag);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x0600127E RID: 4734 RVA: 0x00071164 File Offset: 0x0006F364
		public void UnsubscribeModule(string tag)
		{
			Logger.Info("Unsubscribe html module");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("unsubscribeModule"))
			{
				cefProcessMessage.Arguments.SetString(0, tag);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x0600127F RID: 4735 RVA: 0x000711C4 File Offset: 0x0006F3C4
		public void subscribeToClientTags(string tag)
		{
			Logger.Info("Subscribe to client tags");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("subscribeClientTags"))
			{
				cefProcessMessage.Arguments.SetString(0, tag);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x06001280 RID: 4736 RVA: 0x00071224 File Offset: 0x0006F424
		public void UnsubscribeToClientTags(string tag)
		{
			Logger.Info("Unsubscribe to client tags");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("unsubscribeClientTags"))
			{
				cefProcessMessage.Arguments.SetString(0, tag);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x06001281 RID: 4737 RVA: 0x00071284 File Offset: 0x0006F484
		public void HandleClick(string json)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("HandleClick"))
			{
				cefProcessMessage.Arguments.SetString(0, json);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x06001282 RID: 4738 RVA: 0x000712D8 File Offset: 0x0006F4D8
		public void UpdateQuestRules(string json)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("UpdateQuestRules"))
			{
				cefProcessMessage.Arguments.SetString(0, json);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x06001283 RID: 4739 RVA: 0x0007132C File Offset: 0x0006F52C
		public void pikaworldprofileadded(string profileId)
		{
			Logger.Debug("Got call for PikaWorldProfileAdded");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("PikaWorldProfileAdded"))
			{
				cefProcessMessage.Arguments.SetString(0, profileId);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x06001284 RID: 4740 RVA: 0x0000D16E File Offset: 0x0000B36E
		public string getPikaWorldUserId()
		{
			return RegistryManager.Instance.PikaWorldId;
		}

		// Token: 0x06001285 RID: 4741 RVA: 0x0007138C File Offset: 0x0006F58C
		public void getGamepadConnectionStatus()
		{
			Logger.Debug("Got call for getGamepadConnectionStatus");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("GetGamepadConnectionStatus"))
			{
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x06001286 RID: 4742 RVA: 0x000713DC File Offset: 0x0006F5DC
		public string IsAnyAppRunning()
		{
			string text = "isAnyAppRunning";
			string result;
			try
			{
				result = HTTPUtils.SendRequestToClient(text, null, "Android", 0, null, false, 1, 0).ToLower(CultureInfo.InvariantCulture);
			}
			catch (Exception ex)
			{
				Logger.Error("An unexpected error occured in {0}. Err: {1}", new object[]
				{
					text,
					ex.ToString()
				});
				result = null;
			}
			return result;
		}

		// Token: 0x06001287 RID: 4743 RVA: 0x00071440 File Offset: 0x0006F640
		public void goToMapsTab()
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("GoToMapsTab"))
			{
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x06001288 RID: 4744 RVA: 0x00071488 File Offset: 0x0006F688
		public void clearmapsnotification()
		{
			Logger.Info("Got call from browser for maps clear notification");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("ClearMapsNotification"))
			{
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x06001289 RID: 4745 RVA: 0x000714D8 File Offset: 0x0006F6D8
		public void installapp(string appIcon, string appName, string apkUrl, string packageName)
		{
			Logger.Info("Get Call from browser of Install App :" + appName);
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("InstallApp"))
			{
				CefListValue arguments = cefProcessMessage.Arguments;
				arguments.SetString(0, appIcon);
				arguments.SetString(1, appName);
				arguments.SetString(2, apkUrl);
				arguments.SetString(3, packageName);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x0600128A RID: 4746 RVA: 0x00071558 File Offset: 0x0006F758
		public string installapp(string appIcon, string appName, string apkUrl, string packageName, string timestamp)
		{
			Logger.Info("Get Call from browser of Install App with version :" + appName);
			string result;
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("InstallAppVersion"))
			{
				CefListValue arguments = cefProcessMessage.Arguments;
				arguments.SetString(0, appIcon);
				arguments.SetString(1, appName);
				arguments.SetString(2, apkUrl);
				arguments.SetString(3, packageName);
				arguments.SetString(4, timestamp);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
				result = "true";
			}
			return result;
		}

		// Token: 0x0600128B RID: 4747 RVA: 0x000715EC File Offset: 0x0006F7EC
		public void installapp_google(string appIcon, string appName, string apkUrl, string packageName)
		{
			Logger.Info("Get Call from browser of Install App from googleplay :" + appName);
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("InstallAppGooglePlay"))
			{
				CefListValue arguments = cefProcessMessage.Arguments;
				arguments.SetString(0, appIcon);
				arguments.SetString(1, appName);
				arguments.SetString(2, apkUrl);
				arguments.SetString(3, packageName);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x0600128C RID: 4748 RVA: 0x0007166C File Offset: 0x0006F86C
		public void checkifpremium(string isPremium)
		{
			Logger.Info("Got call from blocker ad browser of premium subscription");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("CheckIfPremium"))
			{
				cefProcessMessage.Arguments.SetString(0, isPremium);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x0600128D RID: 4749 RVA: 0x000716CC File Offset: 0x0006F8CC
		public void applyTheme(string themeName)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("ApplyThemeName"))
			{
				cefProcessMessage.Arguments.SetString(0, themeName);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x0600128E RID: 4750 RVA: 0x0000D17A File Offset: 0x0000B37A
		public List<string> getsupportedactiontypes()
		{
			return Enum.GetNames(typeof(GenericAction)).ToList<string>();
		}

		// Token: 0x0600128F RID: 4751 RVA: 0x00071720 File Offset: 0x0006F920
		public void getimpressionid(string impressionId)
		{
			Logger.Info("Get call from browser of impression_id :" + impressionId);
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("GetImpressionId"))
			{
				cefProcessMessage.Arguments.SetString(0, impressionId);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
				cefProcessMessage.Dispose();
			}
		}

		// Token: 0x06001290 RID: 4752 RVA: 0x0007178C File Offset: 0x0006F98C
		public string installedapps()
		{
			List<AppInfo> list = new JsonParser("Android").GetAppList().ToList<AppInfo>();
			string text = string.Empty;
			foreach (AppInfo appInfo in list)
			{
				text = text + appInfo.Package + ",";
			}
			return text;
		}

		// Token: 0x06001291 RID: 4753 RVA: 0x00071800 File Offset: 0x0006FA00
		public void openapp(string appIcon, string appName, string apkUrl, string packageName)
		{
			Logger.Info("Get Call from browser of open App :" + appName);
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("InstallApp"))
			{
				CefListValue arguments = cefProcessMessage.Arguments;
				arguments.SetString(0, appIcon);
				arguments.SetString(1, appName);
				arguments.SetString(2, apkUrl);
				arguments.SetString(3, packageName);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x06001292 RID: 4754 RVA: 0x00071880 File Offset: 0x0006FA80
		public void showdetails(string url)
		{
			using (CefBrowser browser = CefV8Context.GetCurrentContext().GetBrowser())
			{
				CefProcessMessage cefProcessMessage = CefProcessMessage.Create(url);
				browser.SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
				cefProcessMessage.Dispose();
			}
		}

		// Token: 0x06001293 RID: 4755 RVA: 0x000718CC File Offset: 0x0006FACC
		public void searchappcenter(string searchString)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("SearchAppcenter"))
			{
				cefProcessMessage.Arguments.SetString(0, searchString);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x06001294 RID: 4756 RVA: 0x00005D29 File Offset: 0x00003F29
		public void browser2Client()
		{
		}

		// Token: 0x06001295 RID: 4757 RVA: 0x0000D190 File Offset: 0x0000B390
		public string getguid()
		{
			return RegistryManager.Instance.UserGuid;
		}

		// Token: 0x06001296 RID: 4758 RVA: 0x0000D190 File Offset: 0x0000B390
		public string GetUserGUID()
		{
			return RegistryManager.Instance.UserGuid;
		}

		// Token: 0x06001297 RID: 4759 RVA: 0x00071920 File Offset: 0x0006FB20
		public void feedback(string email, string appName, string description, string downloadURl)
		{
			string clientVersion = RegistryManager.Instance.ClientVersion;
			description = description.Replace("&", " ");
			description += "\n From Client VER=";
			description += clientVersion;
			string text = string.Concat(new string[]
			{
				"-startwithparam \"",
				email,
				"&Others&",
				appName,
				"&",
				description,
				"&",
				downloadURl,
				"\""
			});
			using (Process process = new Process())
			{
				process.StartInfo.FileName = Path.Combine(RegistryStrings.InstallDir, "HD-LogCollector.exe");
				Logger.Info("The arguments being passed to log collector is :{0}", new object[]
				{
					text
				});
				process.StartInfo.Arguments = text;
				process.Start();
			}
		}

		// Token: 0x06001298 RID: 4760 RVA: 0x00071A0C File Offset: 0x0006FC0C
		public void openLogCollector()
		{
			string installDir = RegistryStrings.InstallDir;
			using (Process process = new Process())
			{
				process.StartInfo.FileName = Path.Combine(installDir, "HD-LogCollector.exe");
				Logger.Info("Open log collector through gmApi from dir: " + installDir);
				process.Start();
			}
		}

		// Token: 0x06001299 RID: 4761 RVA: 0x00071A70 File Offset: 0x0006FC70
		public void closesearch()
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("CloseSearch"))
			{
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x0600129A RID: 4762 RVA: 0x00071AB8 File Offset: 0x0006FCB8
		public void refresh_search()
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("RefreshSearch"))
			{
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x0600129B RID: 4763 RVA: 0x00071B00 File Offset: 0x0006FD00
		public void refresh_search(string searchString)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("RefreshSearch"))
			{
				cefProcessMessage.Arguments.SetString(0, searchString);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x0600129C RID: 4764 RVA: 0x00071B54 File Offset: 0x0006FD54
		public void google_search(string searchString)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("GoogleSearch"))
			{
				cefProcessMessage.Arguments.SetString(0, searchString);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x0600129D RID: 4765 RVA: 0x00071BA8 File Offset: 0x0006FDA8
		public string getusertoken()
		{
			return new JObject
			{
				{
					"email",
					RegistryManager.Instance.RegisteredEmail
				},
				{
					"token",
					RegistryManager.Instance.Token
				}
			}.ToString(Formatting.None, new JsonConverter[0]);
		}

		// Token: 0x0600129E RID: 4766 RVA: 0x00005D29 File Offset: 0x00003F29
		public void preinstallapp()
		{
		}

		// Token: 0x0600129F RID: 4767 RVA: 0x0000D19C File Offset: 0x0000B39C
		public void openurl(string url)
		{
			Process.Start(url);
		}

		// Token: 0x060012A0 RID: 4768 RVA: 0x0000D1A5 File Offset: 0x0000B3A5
		public string prod_ver()
		{
			return RegistryManager.Instance.Version;
		}

		// Token: 0x060012A1 RID: 4769 RVA: 0x0000D1A5 File Offset: 0x0000B3A5
		public string getengineguid()
		{
			return RegistryManager.Instance.Version;
		}

		// Token: 0x060012A2 RID: 4770 RVA: 0x0000D1A5 File Offset: 0x0000B3A5
		public string EngineVersion()
		{
			return RegistryManager.Instance.Version;
		}

		// Token: 0x060012A3 RID: 4771 RVA: 0x0000D1B1 File Offset: 0x0000B3B1
		public string ClientVersion()
		{
			return RegistryManager.Instance.ClientVersion;
		}

		// Token: 0x060012A4 RID: 4772 RVA: 0x00071BFC File Offset: 0x0006FDFC
		public string CampaignName()
		{
			string result;
			try
			{
				JObject jobject = JObject.Parse(RegistryManager.Instance.CampaignJson);
				if (jobject["campaign_name"] != null)
				{
					result = jobject["campaign_name"].ToString();
				}
				else
				{
					result = "";
				}
			}
			catch
			{
				Logger.Error("error while sending campaign name in gm api");
				result = "";
			}
			return result;
		}

		// Token: 0x060012A5 RID: 4773 RVA: 0x0000D1BD File Offset: 0x0000B3BD
		public string get_oem()
		{
			return RegistryManager.Instance.Oem;
		}

		// Token: 0x060012A6 RID: 4774 RVA: 0x0000D190 File Offset: 0x0000B390
		public string bgp_uuid()
		{
			return RegistryManager.Instance.UserGuid;
		}

		// Token: 0x060012A7 RID: 4775 RVA: 0x0000D1C9 File Offset: 0x0000B3C9
		public string BGPDevUrl()
		{
			return RegistryManager.Instance.BGPDevUrl;
		}

		// Token: 0x060012A8 RID: 4776 RVA: 0x0000D1D5 File Offset: 0x0000B3D5
		public string DevCloudUrl()
		{
			return RegistryManager.Instance.Host;
		}

		// Token: 0x060012A9 RID: 4777 RVA: 0x0000D1E1 File Offset: 0x0000B3E1
		public string GetMachineId()
		{
			return GuidUtils.GetBlueStacksMachineId();
		}

		// Token: 0x060012AA RID: 4778 RVA: 0x0000D1E8 File Offset: 0x0000B3E8
		public string GetVersionId()
		{
			return GuidUtils.GetBlueStacksVersionId();
		}

		// Token: 0x060012AB RID: 4779 RVA: 0x00071C68 File Offset: 0x0006FE68
		public string SetFirebaseHost(string hostName)
		{
			object obj = MyCustomCefV8Handler.sLock;
			string result;
			lock (obj)
			{
				if (!string.IsNullOrEmpty(RegistryManager.Instance.CurrentFirebaseHost))
				{
					result = "false";
				}
				else
				{
					RegistryManager.Instance.CurrentFirebaseHost = hostName;
					result = "true";
				}
			}
			return result;
		}

		// Token: 0x060012AC RID: 4780 RVA: 0x00071CC8 File Offset: 0x0006FEC8
		public void closeAnyPopup()
		{
			Logger.Info("Got call from browser of closeAnyPopup");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("CloseAnyPopup"))
			{
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012AD RID: 4781 RVA: 0x00071D18 File Offset: 0x0006FF18
		public void closeself()
		{
			Logger.Info("Got call from browser of closeself");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("CloseSelf"))
			{
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012AE RID: 4782 RVA: 0x00071D68 File Offset: 0x0006FF68
		public void closequitpopup()
		{
			Logger.Info("Got call from browser of closequitpopup");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("CloseBrowserQuitPopup"))
			{
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012AF RID: 4783 RVA: 0x00071DB8 File Offset: 0x0006FFB8
		public void downloadMacro(string macroData)
		{
			Logger.Info("Got call from browser of downloadmacro");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("DownloadMacro"))
			{
				cefProcessMessage.Arguments.SetString(0, macroData);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012B0 RID: 4784 RVA: 0x0000D1EF File Offset: 0x0000B3EF
		public string getCurrentMacros()
		{
			Logger.Info("Got call from browser of getcurrentmacros");
			return string.Join("|", BlueStacksUIUtils.GetMacroList().ToArray());
		}

		// Token: 0x060012B1 RID: 4785 RVA: 0x0000D20F File Offset: 0x0000B40F
		public string uploadLocalMacro(string macroName)
		{
			Logger.Info("Got call from browser of uploadlocalmacro");
			return BlueStacksUIUtils.GetBase64MacroData(macroName);
		}

		// Token: 0x060012B2 RID: 4786 RVA: 0x00071E18 File Offset: 0x00070018
		public void performOTS()
		{
			Logger.Info("Got call from browser of performOTS");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("PerformOTS"))
			{
				cefProcessMessage.Arguments.SetString(0, this.mCallBackFunction);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012B3 RID: 4787 RVA: 0x00071E7C File Offset: 0x0007007C
		public void changeControlScheme(string schemeSelected)
		{
			Logger.Info("Got call from browser of changeControlScheme");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("ChangeControlScheme"))
			{
				cefProcessMessage.Arguments.SetString(0, schemeSelected);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012B4 RID: 4788 RVA: 0x00071EDC File Offset: 0x000700DC
		public void closeOnBoarding(string json)
		{
			Logger.Info("Got call from browser of closeOnBoarding");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("CloseOnBoarding"))
			{
				cefProcessMessage.Arguments.SetString(0, json);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012B5 RID: 4789 RVA: 0x00071F3C File Offset: 0x0007013C
		public void browserLoaded()
		{
			Logger.Info("Got call from browser of browserLoaded");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("BrowserLoaded"))
			{
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012B6 RID: 4790 RVA: 0x0000D221 File Offset: 0x0000B421
		public void LogInfo(string info)
		{
			Logger.Info("HtmlLog: " + info);
		}

		// Token: 0x060012B7 RID: 4791 RVA: 0x0000D233 File Offset: 0x0000B433
		public string GetSystemRAM()
		{
			return Profile.RAM;
		}

		// Token: 0x060012B8 RID: 4792 RVA: 0x0000D23A File Offset: 0x0000B43A
		public string GetLocale()
		{
			return RegistryManager.Instance.UserSelectedLocale;
		}

		// Token: 0x060012B9 RID: 4793 RVA: 0x0000D246 File Offset: 0x0000B446
		public string GetSystemCPU()
		{
			return Profile.CPU;
		}

		// Token: 0x060012BA RID: 4794 RVA: 0x0000D24D File Offset: 0x0000B44D
		public string GetSystemGPU()
		{
			return Profile.GPU;
		}

		// Token: 0x060012BB RID: 4795 RVA: 0x0000D254 File Offset: 0x0000B454
		public string GetSystemOS()
		{
			return Profile.OS;
		}

		// Token: 0x060012BC RID: 4796 RVA: 0x0000D25B File Offset: 0x0000B45B
		public string GetCurrentSessionId()
		{
			Logger.Info("In GetCurrentSessionId");
			return Stats.GetSessionId();
		}

		// Token: 0x060012BD RID: 4797 RVA: 0x00071F8C File Offset: 0x0007018C
		public void showWebPage(string title, string webUrl)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("ShowWebPage"))
			{
				CefListValue arguments = cefProcessMessage.Arguments;
				arguments.SetString(0, title);
				arguments.SetString(1, webUrl);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012BE RID: 4798 RVA: 0x00071FEC File Offset: 0x000701EC
		public void HidePreview()
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("HidePreview"))
			{
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012BF RID: 4799 RVA: 0x00072034 File Offset: 0x00070234
		public void ShowPreview()
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("ShowPreview"))
			{
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012C0 RID: 4800 RVA: 0x0007207C File Offset: 0x0007027C
		public void StartObs(string callbackFunction)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("StartObs"))
			{
				cefProcessMessage.Arguments.SetString(0, callbackFunction);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012C1 RID: 4801 RVA: 0x000720D0 File Offset: 0x000702D0
		public void StartStreamViewStatsRecorder(string label, string jsonString)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("StartStreamViewStatsRecorder"))
			{
				CefListValue arguments = cefProcessMessage.Arguments;
				arguments.SetString(0, label);
				arguments.SetString(1, jsonString);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012C2 RID: 4802 RVA: 0x0000D26C File Offset: 0x0000B46C
		public string GetStreamConfig()
		{
			Logger.Info("In GetStreamConfig");
			return StreamManager.GetStreamConfig();
		}

		// Token: 0x060012C3 RID: 4803 RVA: 0x00072130 File Offset: 0x00070330
		public void LaunchDialog(string jsonString)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("LaunchDialog"))
			{
				cefProcessMessage.Arguments.SetString(0, jsonString);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012C4 RID: 4804 RVA: 0x00072184 File Offset: 0x00070384
		public void StartStreamV2(string jsonString, string callbackStreamStatus, string callbackTabChanged)
		{
			Logger.Info("Got StartStreamV2");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("StartStreamV2"))
			{
				CefListValue arguments = cefProcessMessage.Arguments;
				arguments.SetString(0, jsonString);
				arguments.SetString(1, callbackStreamStatus);
				arguments.SetString(2, callbackTabChanged);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012C5 RID: 4805 RVA: 0x000721F4 File Offset: 0x000703F4
		public void StopStream()
		{
			Logger.Info("Got StopStream");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("StopStream"))
			{
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012C6 RID: 4806 RVA: 0x0000D27D File Offset: 0x0000B47D
		public void StartRecord()
		{
			MyCustomCefV8Handler.StartRecordV2("{}");
		}

		// Token: 0x060012C7 RID: 4807 RVA: 0x00072244 File Offset: 0x00070444
		public static void StartRecordV2(string jsonString)
		{
			Logger.Info("Got StartRecordV2");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("StartRecordV2"))
			{
				cefProcessMessage.Arguments.SetString(0, jsonString);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012C8 RID: 4808 RVA: 0x000722A4 File Offset: 0x000704A4
		public void StopRecord()
		{
			Logger.Info("Got StopStream");
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("StopRecord"))
			{
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012C9 RID: 4809 RVA: 0x000722F4 File Offset: 0x000704F4
		public void SetSystemVolume(string level)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("SetSystemVolume"))
			{
				cefProcessMessage.Arguments.SetString(0, level);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012CA RID: 4810 RVA: 0x00072348 File Offset: 0x00070548
		public void SetMicVolume(string level)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("SetMicVolume"))
			{
				cefProcessMessage.Arguments.SetString(0, level);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012CB RID: 4811 RVA: 0x0007239C File Offset: 0x0007059C
		public void EnableWebcam(string width, string height, string position)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("EnableWebcam"))
			{
				Logger.Info("Got EnableWebcam");
				CefListValue arguments = cefProcessMessage.Arguments;
				arguments.SetString(0, width);
				arguments.SetString(1, height);
				arguments.SetString(2, position);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012CC RID: 4812 RVA: 0x0007240C File Offset: 0x0007060C
		public void DisableWebcamV2(string jsonString)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("DisableWebcamV2"))
			{
				Logger.Info("Got DisableWebcamV2");
				cefProcessMessage.Arguments.SetString(0, jsonString);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012CD RID: 4813 RVA: 0x0007246C File Offset: 0x0007066C
		public void MoveWebcam(string horizontal, string vertical)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("MoveWebcam"))
			{
				CefListValue arguments = cefProcessMessage.Arguments;
				arguments.SetString(0, horizontal);
				arguments.SetString(1, vertical);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012CE RID: 4814 RVA: 0x0000D289 File Offset: 0x0000B489
		public void SetStreamName(string name)
		{
			Logger.Info("Got SetStreamName: " + name);
			RegistryManager.Instance.StreamName = name;
		}

		// Token: 0x060012CF RID: 4815 RVA: 0x0000D2A6 File Offset: 0x0000B4A6
		public void SetServerLocation(string location)
		{
			Logger.Info("Got SetServerLocation: " + location);
			RegistryManager.Instance.ServerLocation = location;
		}

		// Token: 0x060012D0 RID: 4816 RVA: 0x0000D2C3 File Offset: 0x0000B4C3
		public void SetChannelName(string channelName)
		{
			RegistryManager.Instance.ChannelName = channelName;
		}

		// Token: 0x060012D1 RID: 4817 RVA: 0x000724CC File Offset: 0x000706CC
		public string GetRealtimeAppUsage()
		{
			string result;
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("GetRealtimeAppUsage"))
			{
				cefProcessMessage.Arguments.SetString(0, this.mCallBackFunction);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
				result = "";
			}
			return result;
		}

		// Token: 0x060012D2 RID: 4818 RVA: 0x0007252C File Offset: 0x0007072C
		public string GetInstalledAppsJsonforJS()
		{
			string result;
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("GetInstalledAppsJsonforJS"))
			{
				cefProcessMessage.Arguments.SetString(0, this.mCallBackFunction);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
				result = "";
			}
			return result;
		}

		// Token: 0x060012D3 RID: 4819 RVA: 0x0007258C File Offset: 0x0007078C
		public string GetCurrentAppInfo()
		{
			string result;
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("GetCurrentAppInfo"))
			{
				cefProcessMessage.Arguments.SetString(0, this.mCallBackFunction);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
				result = "";
			}
			return result;
		}

		// Token: 0x060012D4 RID: 4820 RVA: 0x000725EC File Offset: 0x000707EC
		public string GetGMPort()
		{
			Logger.Info("In GetGMPort");
			return RegistryManager.Instance.PartnerServerPort.ToString(CultureInfo.InvariantCulture);
		}

		// Token: 0x060012D5 RID: 4821 RVA: 0x0000D2D0 File Offset: 0x0000B4D0
		public string ResetSessionId()
		{
			Logger.Info("In ResetSessionId");
			return Stats.ResetSessionId();
		}

		// Token: 0x060012D6 RID: 4822 RVA: 0x0007261C File Offset: 0x0007081C
		public void makeWebCall(string url, string scriptToInvoke)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("makeWebCall"))
			{
				CefListValue arguments = cefProcessMessage.Arguments;
				arguments.SetString(0, url);
				arguments.SetString(1, scriptToInvoke);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012D7 RID: 4823 RVA: 0x0000D2E1 File Offset: 0x0000B4E1
		public void ShowWebPageInBrowser(string url)
		{
			Logger.Info("Showing " + url + " in default browser");
			BlueStacksUIUtils.OpenUrl(url);
		}

		// Token: 0x060012D8 RID: 4824 RVA: 0x0007267C File Offset: 0x0007087C
		public void DialogClickHandler(string jsonString)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("DialogClickHandler"))
			{
				cefProcessMessage.Arguments.SetString(0, jsonString);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012D9 RID: 4825 RVA: 0x000726D0 File Offset: 0x000708D0
		public void CloseDialog(string jsonString)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("CloseDialog"))
			{
				cefProcessMessage.Arguments.SetString(0, jsonString);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012DA RID: 4826 RVA: 0x00072724 File Offset: 0x00070924
		public void ShowAdvancedSettings()
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("ShowAdvancedSettings"))
			{
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012DB RID: 4827 RVA: 0x0007276C File Offset: 0x0007096C
		public void LaunchFilterWindow(string channel, string sessionId)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("LaunchFilterWindow"))
			{
				CefListValue arguments = cefProcessMessage.Arguments;
				arguments.SetString(0, channel);
				arguments.SetString(1, sessionId);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012DC RID: 4828 RVA: 0x000727CC File Offset: 0x000709CC
		public void ChangeFilterTheme(string theme)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("ChangeFilterTheme"))
			{
				cefProcessMessage.Arguments.SetString(0, theme);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012DD RID: 4829 RVA: 0x00072820 File Offset: 0x00070A20
		public void UpdateThemeSettings(string currentTheme, string settingsJson)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("UpdateThemeSettings"))
			{
				CefListValue arguments = cefProcessMessage.Arguments;
				arguments.SetString(0, currentTheme);
				arguments.SetString(1, settingsJson);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012DE RID: 4830 RVA: 0x00072880 File Offset: 0x00070A80
		public void CloseFilterWindow(string jsonArray)
		{
			using (CefProcessMessage cefProcessMessage = CefProcessMessage.Create("CloseFilterWindow"))
			{
				cefProcessMessage.Arguments.SetString(0, jsonArray);
				CefV8Context.GetCurrentContext().GetBrowser().SendProcessMessage(CefProcessId.Browser, cefProcessMessage);
			}
		}

		// Token: 0x060012DF RID: 4831 RVA: 0x0000D2FE File Offset: 0x0000B4FE
		public string IsFacebook()
		{
			if (string.Equals(RegistryManager.Instance.BtvNetwork, "facebook", StringComparison.InvariantCulture))
			{
				return "true";
			}
			return "false";
		}

		// Token: 0x04000BF5 RID: 3061
		private static object sLock = new object();

		// Token: 0x04000BF6 RID: 3062
		private string mCallBackFunction;
	}
}
