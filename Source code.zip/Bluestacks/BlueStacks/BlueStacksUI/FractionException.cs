﻿using System;
using System.Runtime.Serialization;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200019B RID: 411
	[Serializable]
	public class FractionException : Exception
	{
		// Token: 0x0600100C RID: 4108 RVA: 0x0000BC38 File Offset: 0x00009E38
		public FractionException()
		{
		}

		// Token: 0x0600100D RID: 4109 RVA: 0x0000BC40 File Offset: 0x00009E40
		public FractionException(string Message) : base(Message)
		{
		}

		// Token: 0x0600100E RID: 4110 RVA: 0x0000BC49 File Offset: 0x00009E49
		public FractionException(string Message, Exception InnerException) : base(Message, InnerException)
		{
		}

		// Token: 0x0600100F RID: 4111 RVA: 0x0000BC53 File Offset: 0x00009E53
		protected FractionException(SerializationInfo serializationInfo, StreamingContext streamingContext) : base(serializationInfo, streamingContext)
		{
		}
	}
}
