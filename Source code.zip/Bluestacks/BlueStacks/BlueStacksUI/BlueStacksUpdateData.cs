﻿using System;
using System.Collections.Generic;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001AF RID: 431
	internal class BlueStacksUpdateData
	{
		// Token: 0x17000295 RID: 661
		// (get) Token: 0x06001090 RID: 4240 RVA: 0x0000C1D8 File Offset: 0x0000A3D8
		// (set) Token: 0x06001091 RID: 4241 RVA: 0x0000C1E0 File Offset: 0x0000A3E0
		public string ClientVersion { get; set; } = "";

		// Token: 0x17000296 RID: 662
		// (get) Token: 0x06001092 RID: 4242 RVA: 0x0000C1E9 File Offset: 0x0000A3E9
		// (set) Token: 0x06001093 RID: 4243 RVA: 0x0000C1F1 File Offset: 0x0000A3F1
		public string EngineVersion { get; set; } = "";

		// Token: 0x17000297 RID: 663
		// (get) Token: 0x06001094 RID: 4244 RVA: 0x0000C1FA File Offset: 0x0000A3FA
		// (set) Token: 0x06001095 RID: 4245 RVA: 0x0000C202 File Offset: 0x0000A402
		public bool IsFullInstaller { get; set; }

		// Token: 0x17000298 RID: 664
		// (get) Token: 0x06001096 RID: 4246 RVA: 0x0000C20B File Offset: 0x0000A40B
		// (set) Token: 0x06001097 RID: 4247 RVA: 0x0000C213 File Offset: 0x0000A413
		public string Md5 { get; set; } = "";

		// Token: 0x17000299 RID: 665
		// (get) Token: 0x06001098 RID: 4248 RVA: 0x0000C21C File Offset: 0x0000A41C
		// (set) Token: 0x06001099 RID: 4249 RVA: 0x0000C224 File Offset: 0x0000A424
		public string UpdateType { get; set; } = "";

		// Token: 0x1700029A RID: 666
		// (get) Token: 0x0600109A RID: 4250 RVA: 0x0000C22D File Offset: 0x0000A42D
		// (set) Token: 0x0600109B RID: 4251 RVA: 0x0000C235 File Offset: 0x0000A435
		public string DownloadUrl { get; set; } = "";

		// Token: 0x1700029B RID: 667
		// (get) Token: 0x0600109C RID: 4252 RVA: 0x0000C23E File Offset: 0x0000A43E
		// (set) Token: 0x0600109D RID: 4253 RVA: 0x0000C246 File Offset: 0x0000A446
		public List<string> UpdateDescrption { get; set; } = new List<string>();

		// Token: 0x1700029C RID: 668
		// (get) Token: 0x0600109E RID: 4254 RVA: 0x0000C24F File Offset: 0x0000A44F
		// (set) Token: 0x0600109F RID: 4255 RVA: 0x0000C257 File Offset: 0x0000A457
		public bool IsUpdateAvailble { get; set; }

		// Token: 0x1700029D RID: 669
		// (get) Token: 0x060010A0 RID: 4256 RVA: 0x0000C260 File Offset: 0x0000A460
		// (set) Token: 0x060010A1 RID: 4257 RVA: 0x0000C268 File Offset: 0x0000A468
		public string UpdateDownloadLocation { get; set; } = "";

		// Token: 0x1700029E RID: 670
		// (get) Token: 0x060010A2 RID: 4258 RVA: 0x0000C271 File Offset: 0x0000A471
		// (set) Token: 0x060010A3 RID: 4259 RVA: 0x0000C279 File Offset: 0x0000A479
		public string DetailedChangeLogsUrl { get; set; } = "";

		// Token: 0x1700029F RID: 671
		// (get) Token: 0x060010A4 RID: 4260 RVA: 0x0000C282 File Offset: 0x0000A482
		// (set) Token: 0x060010A5 RID: 4261 RVA: 0x0000C28A File Offset: 0x0000A48A
		public bool IsTryAgain { get; set; }
	}
}
