﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using System.Windows.Threading;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000B2 RID: 178
	public class Sidebar : UserControl, IComponentConnector
	{
		// Token: 0x170001C0 RID: 448
		// (get) Token: 0x0600070F RID: 1807 RVA: 0x000068D3 File Offset: 0x00004AD3
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x06000710 RID: 1808 RVA: 0x0002A428 File Offset: 0x00028628
		public Sidebar()
		{
			this.InitializeComponent();
			this.mMoreButton.Image.ImageName = "sidebar_options_close";
			if (this.mListPopups == null)
			{
				this.mListPopups = new List<CustomPopUp>(8)
				{
					this.mChangeTransparencyPopup,
					this.mVolumeSliderPopup,
					this.mOverlayTooltip,
					this.mMacroButtonPopup,
					this.mGameControlButtonPopup,
					this.mRecordScreenPopup,
					this.mScreenshotPopup,
					this.mMoreElements
				};
			}
			BlueStacksUIBinding.Instance.PropertyChanged += this.BlueStacksUIBinding_PropertyChanged;
		}

		// Token: 0x06000711 RID: 1809 RVA: 0x000068F4 File Offset: 0x00004AF4
		private void BlueStacksUIBinding_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			if (e.PropertyName == "LocaleModel")
			{
				this.ParentWindow.mCommonHandler.ReloadTooltips();
			}
		}

		// Token: 0x06000712 RID: 1810 RVA: 0x0002A504 File Offset: 0x00028704
		internal void BindEvents()
		{
			this.ParentWindow.CursorLockChangedEvent += this.ParentWindow_CursorLockChangedEvent;
			this.ParentWindow.FullScreenChanged += this.ParentWindow_FullScreenChangedEvent;
			this.ParentWindow.FrontendGridVisibilityChanged += this.ParentWindow_FrontendGridVisibleChangedEvent;
			this.ParentWindow.mCommonHandler.ScreenRecordingStateChangedEvent += this.ParentWindow_ScreenRecordingStateChangedEvent;
			this.ParentWindow.mCommonHandler.OverlayStateChangedEvent += this.ParentWindow_OverlayStateChangedEvent;
			this.ParentWindow.mCommonHandler.MacroButtonVisibilityChangedEvent += this.ParentWindow_MacroButtonVisibilityChangedEvent;
			this.ParentWindow.mCommonHandler.OperationSyncButtonVisibilityChangedEvent += this.ParentWindow_OperationSyncButtonVisibilityChangedEvent;
			this.ParentWindow.mCommonHandler.ScreenRecorderStateTransitioningEvent += this.ParentWindow_ScreenRecordingInitingEvent;
			this.ParentWindow.mCommonHandler.OBSResponseTimeoutEvent += this.ParentWindow_OBSResponseTimeoutEvent;
			this.ParentWindow.mCommonHandler.BTvDownloaderMinimizedEvent += this.ParentWindow_BTvDownloaderMinimizedEvent;
			this.ParentWindow.mCommonHandler.GamepadButtonVisibilityChangedEvent += this.ParentWindow_GamepadButtonVisibilityChangedEvent;
			this.ParentWindow.mCommonHandler.VolumeChangedEvent += this.ParentWindow_VolumeChangedEvent;
			this.ParentWindow.mCommonHandler.VolumeMutedEvent += this.ParentWindow_VolumeMutedEvent;
			PromotionObject.AppSpecificRulesHandler = (EventHandler)Delegate.Combine(PromotionObject.AppSpecificRulesHandler, new EventHandler(this.PromotionUpdated));
			this.ParentWindow.mCommonHandler.GameGuideButtonVisibilityChangedEvent += this.ParentWindow_GameGuideButtonVisibilityChangedEvent;
			if (this.ParentWindow.mGuestBootCompleted)
			{
				this.ToggleBootCompletedState();
				return;
			}
			this.ParentWindow.GuestBootCompleted += this.ParentWindow_GuestBootCompletedEvent;
		}

		// Token: 0x06000713 RID: 1811 RVA: 0x00006918 File Offset: 0x00004B18
		private void ParentWindow_GameGuideButtonVisibilityChangedEvent(bool visibility)
		{
			this.ChangeElementState("sidebar_gameguide", visibility);
		}

		// Token: 0x06000714 RID: 1812 RVA: 0x00006926 File Offset: 0x00004B26
		private void PromotionUpdated(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.ToggleMacroAndSyncVisibility();
		}

		// Token: 0x06000715 RID: 1813 RVA: 0x00006938 File Offset: 0x00004B38
		public void UpdateMuteAllInstancesCheckbox()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (RegistryManager.Instance.AreAllInstancesMuted)
				{
					this.mMuteInstancesCheckboxImage.ImageName = "bgpcheckbox_checked";
					return;
				}
				this.mMuteInstancesCheckboxImage.ImageName = "bgpcheckbox";
			}), new object[0]);
		}

		// Token: 0x06000716 RID: 1814 RVA: 0x0002A6D8 File Offset: 0x000288D8
		private void ParentWindow_VolumeMutedEvent(bool muted)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (muted)
				{
					this.mVolumeMuteUnmuteImage.ImageName = "sidebar_volume_muted_popup";
					this.UpdateImage("sidebar_volume", "sidebar_volume_muted");
				}
				else
				{
					this.mVolumeMuteUnmuteImage.ImageName = "sidebar_volume_popup";
					this.UpdateToDefaultImage("sidebar_volume");
				}
				this.UpdateMuteAllInstancesCheckbox();
			}), new object[0]);
		}

		// Token: 0x06000717 RID: 1815 RVA: 0x0002A71C File Offset: 0x0002891C
		private void ParentWindow_VolumeChangedEvent(int volumeLevel)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.mVolumeSlider.Value = (double)volumeLevel;
				this.mCurrentVolumeValue.Text = volumeLevel.ToString(CultureInfo.InvariantCulture);
			}), new object[0]);
		}

		// Token: 0x06000718 RID: 1816 RVA: 0x0000695D File Offset: 0x00004B5D
		private void ParentWindow_GamepadButtonVisibilityChangedEvent(bool visibility)
		{
			this.ChangeElementState("sidebar_gamepad", visibility);
		}

		// Token: 0x06000719 RID: 1817 RVA: 0x0002A760 File Offset: 0x00028960
		private void ParentWindow_BTvDownloaderMinimizedEvent()
		{
			this.RecordScreenPopupHeader.Visibility = Visibility.Collapsed;
			this.RecordScreenPopupBody.Visibility = Visibility.Visible;
			this.RecordScreenPopupHyperlink.Visibility = Visibility.Collapsed;
			BlueStacksUIBinding.Bind(this.RecordScreenPopupBody, "STRING_DOWNLOAD_BACKGROUND", "");
			this.mRecordScreenPopup.StaysOpen = false;
			this.mRecordScreenPopup.IsOpen = true;
		}

		// Token: 0x0600071A RID: 1818 RVA: 0x0000696B File Offset: 0x00004B6B
		private void ParentWindow_OBSResponseTimeoutEvent()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				SidebarElement elementFromTag = this.GetElementFromTag("sidebar_video_capture");
				elementFromTag.Image.IsImageToBeRotated = false;
				Sidebar.UpdateToDefaultImage(elementFromTag);
			}), new object[0]);
		}

		// Token: 0x0600071B RID: 1819 RVA: 0x0002A7C0 File Offset: 0x000289C0
		private void ParentWindow_ScreenRecordingInitingEvent()
		{
			SidebarElement elementFromTag = this.GetElementFromTag("sidebar_video_capture");
			Sidebar.UpdateImage(elementFromTag, "sidebar_video_loading");
			elementFromTag.Image.Visibility = Visibility.Hidden;
			elementFromTag.Image.IsImageToBeRotated = true;
			elementFromTag.Image.Visibility = Visibility.Visible;
			this.RecordScreenPopupHyperlink.Visibility = Visibility.Collapsed;
			this.RecordScreenPopupBody.Visibility = Visibility.Collapsed;
			this.mRecordScreenClose.Visibility = Visibility.Collapsed;
		}

		// Token: 0x0600071C RID: 1820 RVA: 0x00006990 File Offset: 0x00004B90
		private void ParentWindow_OperationSyncButtonVisibilityChangedEvent(bool isVisible)
		{
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				return;
			}
			this.ToggleElementVisibilty("sidebar_operation", isVisible);
		}

		// Token: 0x0600071D RID: 1821 RVA: 0x0002A82C File Offset: 0x00028A2C
		private void ToggleElementVisibilty(SidebarElement ele, bool isVisible)
		{
			if (ele != null)
			{
				if (isVisible)
				{
					ele.Visibility = Visibility.Visible;
				}
				else
				{
					ele.Visibility = Visibility.Collapsed;
				}
				if (ele.IsInMainSidebar)
				{
					int num = this.mElementsStackPanel.Children.IndexOf(ele);
					int num2 = this.mListSidebarElements.IndexOf(ele);
					if (num != -1 && num != num2)
					{
						this.mElementsStackPanel.Children.RemoveAt(num);
						int count = this.mElementsStackPanel.Children.Count;
						if (num2 >= count)
						{
							ele.IsInMainSidebar = false;
						}
						else
						{
							this.mElementsStackPanel.Children.Insert(num2 + 1, ele);
						}
					}
				}
				this.FixMarginOfSurroundingElement(ele);
				this.UpdateTotalVisibleElementCount();
				this.ArrangeAllSidebarElements();
			}
		}

		// Token: 0x0600071E RID: 1822 RVA: 0x0002A8D8 File Offset: 0x00028AD8
		private SidebarElement GetPreviousVisibleSidebarElement(SidebarElement ele)
		{
			SidebarElement previousSidebarElement = this.GetPreviousSidebarElement(ele);
			if (previousSidebarElement.Visibility != Visibility.Visible)
			{
				return this.GetPreviousSidebarElement(previousSidebarElement);
			}
			return previousSidebarElement;
		}

		// Token: 0x0600071F RID: 1823 RVA: 0x0002A900 File Offset: 0x00028B00
		private SidebarElement GetPreviousSidebarElement(SidebarElement ele)
		{
			int num = this.mListSidebarElements.IndexOf(ele);
			if (num != 0)
			{
				return this.mListSidebarElements[num - 1];
			}
			return ele;
		}

		// Token: 0x06000720 RID: 1824 RVA: 0x0002A930 File Offset: 0x00028B30
		private void FixMarginOfSurroundingElement(SidebarElement currentElement)
		{
			if (currentElement != null && currentElement.Visibility == Visibility.Visible)
			{
				if (currentElement.IsLastElementOfGroup)
				{
					if (currentElement.IsCurrentLastElementOfGroup)
					{
						return;
					}
					currentElement.IsCurrentLastElementOfGroup = true;
					Sidebar.IncreaseElementBottomMarginIfLast(currentElement);
					SidebarElement previousVisibleSidebarElement = this.GetPreviousVisibleSidebarElement(currentElement);
					if (previousVisibleSidebarElement != currentElement)
					{
						previousVisibleSidebarElement.IsCurrentLastElementOfGroup = false;
						Sidebar.DecreaseElementBottomMargin(previousVisibleSidebarElement);
						Thickness margin = previousVisibleSidebarElement.Margin;
						margin.Bottom = 2.0;
						previousVisibleSidebarElement.Margin = margin;
						return;
					}
				}
			}
			else if (currentElement.IsCurrentLastElementOfGroup)
			{
				currentElement.IsCurrentLastElementOfGroup = false;
				SidebarElement previousVisibleSidebarElement2 = this.GetPreviousVisibleSidebarElement(currentElement);
				if (previousVisibleSidebarElement2 != currentElement)
				{
					previousVisibleSidebarElement2.IsCurrentLastElementOfGroup = true;
					Sidebar.IncreaseElementBottomMarginIfLast(previousVisibleSidebarElement2);
				}
			}
		}

		// Token: 0x06000721 RID: 1825 RVA: 0x0002A9C8 File Offset: 0x00028BC8
		private void ToggleElementVisibilty(string elementKey, bool isVisible)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.ToggleElementVisibilty(this.GetElementFromTag(elementKey), isVisible);
			}), new object[0]);
		}

		// Token: 0x06000722 RID: 1826 RVA: 0x000069AB File Offset: 0x00004BAB
		private void ParentWindow_MacroButtonVisibilityChangedEvent(bool isVisible)
		{
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				return;
			}
			this.ToggleElementVisibilty("sidebar_macro", isVisible);
		}

		// Token: 0x06000723 RID: 1827 RVA: 0x0002AA14 File Offset: 0x00028C14
		private void ParentWindow_OverlayStateChangedEvent(bool isEnabled)
		{
			SidebarElement elementFromTag = this.GetElementFromTag("sidebar_overlay");
			if (isEnabled)
			{
				Sidebar.UpdateToDefaultImage(elementFromTag);
				if (RegistryManager.Instance.TranslucentControlsTransparency == 0.0)
				{
					if (this.mLastSliderValue == 0.0)
					{
						RegistryManager.Instance.TranslucentControlsTransparency = 0.5;
						this.transSlider.Value = 0.5;
					}
					else
					{
						RegistryManager.Instance.TranslucentControlsTransparency = this.mLastSliderValue;
						this.transSlider.Value = this.mLastSliderValue;
					}
				}
			}
			else
			{
				Sidebar.UpdateImage(elementFromTag, "sidebar_overlay_inactive");
				double value = this.transSlider.Value;
				this.transSlider.Value = 0.0;
				this.mLastSliderValue = value;
			}
			KMManager.ShowOverlayWindow(this.ParentWindow, true, false);
		}

		// Token: 0x06000724 RID: 1828 RVA: 0x000069C6 File Offset: 0x00004BC6
		private void MSidebarPopup_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mMoreElements.IsOpen)
			{
				this.mMoreElements.IsOpen = false;
			}
		}

		// Token: 0x06000725 RID: 1829 RVA: 0x0002AAEC File Offset: 0x00028CEC
		private void ParentWindow_ScreenRecordingStateChangedEvent(bool isRecording)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				SidebarElement elementFromTag = this.GetElementFromTag("sidebar_video_capture");
				elementFromTag.Image.IsImageToBeRotated = false;
				if (isRecording)
				{
					Sidebar.UpdateImage(elementFromTag, "sidebar_video_capture_active");
					this.ChangeElementState("sidebar_fullscreen", false);
					BlueStacksUIBinding.Bind(this.RecordScreenPopupHeader, "STRING_STOP_RECORDING", "");
					this.RecordScreenPopupHeader.Visibility = Visibility.Visible;
					this.RecordScreenPopupHyperlink.Visibility = Visibility.Collapsed;
					this.RecordScreenPopupBody.Visibility = Visibility.Collapsed;
					this.mRecordScreenClose.Visibility = Visibility.Collapsed;
				}
				else
				{
					Sidebar.UpdateToDefaultImage(elementFromTag);
					this.RecordScreenPopupBody.Visibility = Visibility.Visible;
					this.RecordScreenPopupHeader.Visibility = Visibility.Visible;
					BlueStacksUIBinding.Bind(this.RecordScreenPopupHeader, "STRING_RECORDING_SAVED", "");
					BlueStacksUIBinding.Bind(this.RecordScreenPopupBody, "STRING_CLICK_TO_SEE_VIDEO", "");
					this.RecordScreenPopupBody.Visibility = Visibility.Collapsed;
					this.RecordScreenPopupHyperlink.Visibility = Visibility.Visible;
					BlueStacksUIBinding.Bind(this.mRecorderClickLink, "STRING_CLICK_TO_SEE_VIDEO", "");
					this.RecordScreenPopupBody.Visibility = Visibility.Visible;
					this.mRecordScreenClose.Visibility = Visibility.Visible;
					if (this.ParentWindow.mIsWindowInFocus && elementFromTag.IsInMainSidebar)
					{
						this.mRecordScreenPopup.PlacementTarget = elementFromTag;
						this.mRecordScreenPopup.StaysOpen = false;
						this.mRecordScreenPopup.IsOpen = true;
					}
					if (RegistryManager.Instance.IsShowToastNotification)
					{
						this.ParentWindow.ShowGeneralToast(LocaleStrings.GetLocalizedString("STRING_RECORDING_SAVED"));
					}
					if (this.ParentWindow.mFrontendGrid.IsVisible)
					{
						this.ChangeElementState("sidebar_fullscreen", true);
					}
				}
				this.SetVideoRecordingTooltip(isRecording);
			}), new object[0]);
		}

		// Token: 0x06000726 RID: 1830 RVA: 0x0002AB30 File Offset: 0x00028D30
		internal void ShowScreenshotSavedPopup(string screenshotPath)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				SidebarElement elementFromTag = this.GetElementFromTag("sidebar_screenshot");
				this.SetSidebarElementTooltip(elementFromTag, "STRING_TOOLBAR_CAMERA");
				if (this.ParentWindow.mIsWindowInFocus && elementFromTag.IsInMainSidebar)
				{
					this.mScreenshotPopup.PlacementTarget = elementFromTag;
					this.mScreenshotPopup.StaysOpen = false;
					this.mScreenshotPopup.IsOpen = true;
					this.currentScreenshotSavedPath = screenshotPath;
				}
			}), new object[0]);
		}

		// Token: 0x06000727 RID: 1831 RVA: 0x0002AB74 File Offset: 0x00028D74
		private void ParentWindow_FrontendGridVisibleChangedEvent(object sender, MainWindowEventArgs.FrontendGridVisibilityChangedEventArgs args)
		{
			this.ChangeElementState("sidebar_lock_cursor", args.IsVisible);
			if (!CommonHandlers.sIsRecordingVideo)
			{
				this.ChangeElementState("sidebar_fullscreen", args.IsVisible);
			}
			this.ChangeElementState("sidebar_toggle", args.IsVisible);
			this.ChangeElementState("sidebar_controls", args.IsVisible);
			this.ChangeElementState("sidebar_overlay", args.IsVisible);
			this.ChangeElementState("sidebar_back", args.IsVisible);
			this.ChangeElementState("sidebar_home", args.IsVisible);
			this.ChangeElementState("sidebar_screenshot", args.IsVisible);
			this.ChangeElementState("sidebar_video_capture", args.IsVisible);
			if (!args.IsVisible)
			{
				this.ChangeElementState("sidebar_gamepad", args.IsVisible);
				this.ChangeElementState("sidebar_gameguide", args.IsVisible);
			}
		}

		// Token: 0x06000728 RID: 1832 RVA: 0x0002AC4C File Offset: 0x00028E4C
		private void InitDefaultSettings()
		{
			if (this.ParentWindow.mIsFullScreen)
			{
				this.UpdateImage("sidebar_fullscreen", "sidebar_fullscreen_minimize");
			}
			if (!FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.ToggleElementVisibilty("sidebar_macro", false);
				this.ToggleElementVisibilty("sidebar_operation", false);
				if (RegistryManager.Instance.TranslucentControlsTransparency == 0.0)
				{
					this.UpdateImage("sidebar_overlay", "sidebar_overlay_inactive");
					this.mTranslucentControlsSliderButton.ImageName = "sidebar_overlay_inactive_popup";
				}
			}
			else
			{
				this.ToggleElementVisibilty("sidebar_overlay", false);
				this.ToggleElementVisibilty("sidebar_overlay_inactive", false);
			}
			this.SetupVolumeInitState();
			this.transSlider.Value = RegistryManager.Instance.TranslucentControlsTransparency;
			this.mOverlayPopUpMessage.Text = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_ON_SCREEN_CONTROLS_BODY"), new object[]
			{
				this.ParentWindow.mCommonHandler.GetShortcutKeyFromName("STRING_TOGGLE_OVERLAY", false)
			});
		}

		// Token: 0x06000729 RID: 1833 RVA: 0x0002AD44 File Offset: 0x00028F44
		private void SetupVolumeInitState()
		{
			if (this.ParentWindow.EngineInstanceRegistry.IsMuted)
			{
				this.UpdateImage("sidebar_volume", "sidebar_volume_muted");
				this.mVolumeMuteUnmuteImage.ImageName = "sidebar_volume_muted_popup";
			}
			this.UpdateMuteAllInstancesCheckbox();
			this.mVolumeSlider.Value = (double)this.ParentWindow.Utils.CurrentVolumeLevel;
			this.mCurrentVolumeValue.Text = this.ParentWindow.Utils.CurrentVolumeLevel.ToString(CultureInfo.InvariantCulture);
		}

		// Token: 0x0600072A RID: 1834 RVA: 0x0002ADD0 File Offset: 0x00028FD0
		internal void ToggleSidebarVisibilityInFullscreen(bool isVisible)
		{
			this.ParentWindow.mFullscreenSidebarPopup.IsOpen = isVisible;
			if (isVisible)
			{
				this.ParentWindow.mFullscreenSidebarPopup.Height = this.ParentWindow.MainGrid.ActualHeight;
				this.ParentWindow.mFullscreenSidebarPopup.HorizontalOffset = this.ParentWindow.MainGrid.ActualWidth / 2.0;
				this.ParentWindow.mFullscreenSidebarPopupInnerGrid.Height = this.ParentWindow.MainGrid.ActualHeight;
				return;
			}
			this.mListPopups.All((CustomPopUp x) => x.IsOpen = false);
		}

		// Token: 0x0600072B RID: 1835 RVA: 0x0002AE88 File Offset: 0x00029088
		private void ParentWindow_FullScreenChangedEvent(object sender, MainWindowEventArgs.FullScreenChangedEventArgs args)
		{
			object obj = this.mSyncRoot;
			lock (obj)
			{
				this.mIsInFullscreenMode = args.IsFullscreen;
				this.SetupSidebarForFullscreen(this.mIsInFullscreenMode);
				if (this.mIsInFullscreenMode)
				{
					this.UpdateImage("sidebar_fullscreen", "sidebar_fullscreen_minimize");
				}
				else
				{
					this.UpdateImage("sidebar_fullscreen", "sidebar_fullscreen");
					this.ParentWindow.mFullscreenSidebarPopup.IsOpen = false;
				}
				this.ArrangeAllSidebarElements();
			}
		}

		// Token: 0x0600072C RID: 1836 RVA: 0x0002AF14 File Offset: 0x00029114
		private void SetupSidebarForFullscreen(bool isFullScreen)
		{
			if (isFullScreen)
			{
				if (this.ParentWindow.mMainWindowTopGrid.Children.Contains(this))
				{
					this.ParentWindow.mMainWindowTopGrid.Children.Remove(this);
					this.ParentWindow.mFullscreenSidebarPopupInnerGrid.Children.Add(this);
					base.MouseLeave += this.Sidebar_MouseLeave;
				}
				base.Visibility = Visibility.Visible;
				return;
			}
			if (this.ParentWindow.mFullscreenSidebarPopupInnerGrid.Children.Contains(this))
			{
				this.ParentWindow.mFullscreenSidebarPopupInnerGrid.Children.Remove(this);
				this.ParentWindow.mMainWindowTopGrid.Children.Add(this);
				base.MouseLeave -= this.Sidebar_MouseLeave;
			}
			if (this.ParentWindow.EngineInstanceRegistry.IsSidebarVisible)
			{
				base.Visibility = Visibility.Visible;
				return;
			}
			base.Visibility = Visibility.Collapsed;
		}

		// Token: 0x0600072D RID: 1837 RVA: 0x000069E1 File Offset: 0x00004BE1
		private void Sidebar_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!base.IsMouseOver)
			{
				if (this.mListPopups.All((CustomPopUp x) => !x.IsOpen))
				{
					this.ToggleSidebarVisibilityInFullscreen(false);
				}
			}
		}

		// Token: 0x0600072E RID: 1838 RVA: 0x00006A1E File Offset: 0x00004C1E
		private void ParentWindow_CursorLockChangedEvent(object sender, MainWindowEventArgs.CursorLockChangedEventArgs args)
		{
			if (args.IsLocked)
			{
				this.UpdateImage("sidebar_lock_cursor", "sidebar_lock_cursor_active");
				return;
			}
			this.UpdateImage("sidebar_lock_cursor", "sidebar_lock_cursor");
		}

		// Token: 0x0600072F RID: 1839 RVA: 0x00006A49 File Offset: 0x00004C49
		private void ParentWindow_GuestBootCompletedEvent(object sender, EventArgs args)
		{
			this.ToggleBootCompletedState();
		}

		// Token: 0x06000730 RID: 1840 RVA: 0x00006A51 File Offset: 0x00004C51
		private void ToggleBootCompletedState()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.ChangeElementState("sidebar_stream_video", true);
				this.ChangeElementState("sidebar_volume", true);
				this.ChangeElementState("sidebar_macro", true);
				this.ChangeElementState("sidebar_operation", true);
				this.ChangeElementState("sidebar_location", true);
				this.ChangeElementState("sidebar_rotate", true);
			}), new object[0]);
		}

		// Token: 0x06000731 RID: 1841 RVA: 0x00006A76 File Offset: 0x00004C76
		private static void ChangeElementState(SidebarElement ele, bool isEnabled)
		{
			if (ele != null)
			{
				ele.IsEnabled = isEnabled;
			}
		}

		// Token: 0x06000732 RID: 1842 RVA: 0x00006A82 File Offset: 0x00004C82
		private void ChangeElementState(string elementTag, bool isEnabled)
		{
			Sidebar.ChangeElementState(this.GetElementFromTag(elementTag), isEnabled);
		}

		// Token: 0x06000733 RID: 1843 RVA: 0x0002AFFC File Offset: 0x000291FC
		private void Sidebar_Loaded(object sender, RoutedEventArgs e)
		{
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				return;
			}
			if (!this.mIsLoadedOnce)
			{
				this.mIsLoadedOnce = true;
				this.BindEvents();
				this.SetPlacementTargets();
				this.InitDefaultSettings();
				this.mMacroBookmarkPopup.SetParentWindowAndBindEvents(this.ParentWindow);
				this.ParentWindow.mCommonHandler.ToggleMacroAndSyncVisibility();
			}
			this.ParentWindow.mCommonHandler.ClipMouseCursorHandler(false, false, "", "");
			this.SetVideoRecordingTooltipForNCSoft();
		}

		// Token: 0x06000734 RID: 1844 RVA: 0x0002B07C File Offset: 0x0002927C
		private void MMacroButtonAndPopup_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.mMacroButtonPopup.IsOpen)
			{
				if (this.mMacroBookmarkTimer == null)
				{
					this.mMacroBookmarkTimer = new DispatcherTimer
					{
						Interval = new TimeSpan(0, 0, 0, 0, 500)
					};
					this.mMacroBookmarkTimer.Tick += this.MMacroBookmarkTimer_Tick;
				}
				else
				{
					this.mMacroBookmarkTimer.Stop();
				}
				this.mMacroBookmarkTimer.Start();
			}
		}

		// Token: 0x06000735 RID: 1845 RVA: 0x0002B0EC File Offset: 0x000292EC
		private void MMacroBookmarkTimer_Tick(object sender, EventArgs e)
		{
			if (!this.mMacroButtonPopup.IsMouseOver && !this.GetElementFromTag("sidebar_macro").IsMouseOver)
			{
				this.mMacroButtonPopup.IsOpen = false;
				if (this.mIsInFullscreenMode && !base.IsMouseOver)
				{
					this.ToggleSidebarVisibilityInFullscreen(false);
				}
			}
			(sender as DispatcherTimer).Stop();
		}

		// Token: 0x06000736 RID: 1846 RVA: 0x0002B148 File Offset: 0x00029348
		private void MacroButtonHandler(object sender, EventArgs e)
		{
			if (this.ParentWindow.mIsMacroRecorderActive)
			{
				this.ParentWindow.ShowToast(LocaleStrings.GetLocalizedString("STRING_STOP_RECORDING_FIRST"), "", "", false);
				return;
			}
			if (RegistryManager.Instance.BookmarkedScriptList.Length != 0 && !this.mMoreElements.IsOpen)
			{
				this.mMacroButtonPopup.IsOpen = true;
				return;
			}
			this.ParentWindow.mCommonHandler.ShowMacroRecorderWindow();
			this.mMacroButtonPopup.IsOpen = false;
			this.ToggleSidebarVisibilityInFullscreen(false);
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "MacroRecorder", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06000737 RID: 1847 RVA: 0x0002B20C File Offset: 0x0002940C
		private void OperationSyncHandler(object sender, EventArgs e)
		{
			this.ParentWindow.ShowSynchronizerWindow();
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "OperationSync", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06000738 RID: 1848 RVA: 0x00006A91 File Offset: 0x00004C91
		private void KeymapToggleHandler(object sender, EventArgs e)
		{
			this.KeyMapSwitchButtonHandler(sender as SidebarElement);
		}

		// Token: 0x06000739 RID: 1849 RVA: 0x0002B264 File Offset: 0x00029464
		private void KeyMapControlsButton_PreviewMouseRightButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Right Click on keymap control UI button ");
			try
			{
				if ((Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl)) && (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt)))
				{
					KMManager.sIsDeveloperModeOn = true;
				}
				else
				{
					KMManager.sIsDeveloperModeOn = false;
				}
				KMManager.LoadIMActions(this.ParentWindow, this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName);
				KMManager.ShowAdvancedSettings(this.ParentWindow);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception on right click on keymap button: " + ex.ToString());
			}
		}

		// Token: 0x0600073A RID: 1850 RVA: 0x0002B308 File Offset: 0x00029508
		internal void KeyMapSwitchButtonHandler(SidebarElement ele)
		{
			bool fromSideBar = true;
			if (ele == null)
			{
				ele = this.GetElementFromTag("sidebar_toggle");
				fromSideBar = false;
			}
			if (ele == null)
			{
				return;
			}
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (!KMManager.sIsComboRecordingOn)
				{
					if (string.Equals(ele.Image.ImageName, "sidebar_toggle_off", StringComparison.InvariantCulture))
					{
						Sidebar.UpdateToDefaultImage(ele);
						this.ParentWindow.mFrontendHandler.EnableKeyMapping(true);
						ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "ToggleKeymapOn", fromSideBar ? "MouseClick" : "Shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
						return;
					}
					Sidebar.UpdateImage(ele, "sidebar_toggle_off");
					this.ParentWindow.mFrontendHandler.EnableKeyMapping(false);
					ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "ToggleKeymapOff", fromSideBar ? "MouseClick" : "Shortcut", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
				}
			}), new object[0]);
		}

		// Token: 0x0600073B RID: 1851 RVA: 0x0002B37C File Offset: 0x0002957C
		private void SetPlacementTargets()
		{
			this.mChangeTransparencyPopup.PlacementTarget = this.GetElementFromTag("sidebar_overlay");
			this.mVolumeSliderPopup.PlacementTarget = this.GetElementFromTag("sidebar_volume");
			this.mOverlayTooltip.PlacementTarget = this.GetElementFromTag("sidebar_overlay");
			this.mRecordScreenPopup.PlacementTarget = this.GetElementFromTag("sidebar_video_capture");
			this.mScreenshotPopup.PlacementTarget = this.GetElementFromTag("sidebar_screenshot");
			this.mMacroButtonPopup.PlacementTarget = this.GetElementFromTag("sidebar_macro");
			this.mGameControlButtonPopup.PlacementTarget = this.GetElementFromTag("sidebar_controls");
		}

		// Token: 0x0600073C RID: 1852 RVA: 0x0002B424 File Offset: 0x00029624
		internal void InitElements()
		{
			SidebarConfig.sFilePath = System.IO.Path.Combine(RegistryStrings.GadgetDir, string.Format(CultureInfo.InvariantCulture, "SidebarConfig_{0}.json", new object[]
			{
				this.ParentWindow.mVmName
			}));
			foreach (List<string> ls in SidebarConfig.Instance.GroupElements)
			{
				this.CreateAndAddElementsToStackPanel(ls);
			}
			this.InitStaticElements();
			this.UpdateTotalVisibleElementCount();
		}

		// Token: 0x0600073D RID: 1853 RVA: 0x0002B4BC File Offset: 0x000296BC
		private void UpdateTotalVisibleElementCount()
		{
			this.mTotalVisibleElements = (from item in this.mListSidebarElements
			where item.Visibility == Visibility.Visible
			select item).Count<SidebarElement>();
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.mTotalVisibleElements--;
				return;
			}
			this.mTotalVisibleElements -= 3;
		}

		// Token: 0x0600073E RID: 1854 RVA: 0x0002B528 File Offset: 0x00029728
		private void InitStaticElements()
		{
			SidebarElement ele = this.CreateElement("sidebar_gameguide", "STRING_TOGGLE_KEYMAP_WINDOW", new EventHandler(this.OpenGameGuideButtonHandler));
			this.AddElement(ele, true);
			Sidebar.ChangeElementState(ele, false);
			if (!FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				ele = this.CreateElement("sidebar_settings", "STRING_SETTINGS", new EventHandler(this.GoSettingsHandler));
				this.AddElement(ele, true);
			}
			ele = this.CreateElement("sidebar_back", "STRING_BACK", new EventHandler(this.GoBackHandler));
			this.AddElement(ele, true);
			Sidebar.ChangeElementState(ele, false);
		}

		// Token: 0x0600073F RID: 1855 RVA: 0x0002B5C0 File Offset: 0x000297C0
		private void CreateAndAddElementsToStackPanel(List<string> ls)
		{
			SidebarElement sidebarElement = null;
			foreach (string text in ls)
			{
				if (text == null)
				{
					goto IL_609;
				}
				uint num = <PrivateImplementationDetails>.ComputeStringHash(text);
				if (num <= 1613331775U)
				{
					if (num <= 964859351U)
					{
						if (num <= 784514210U)
						{
							if (num != 33101451U)
							{
								if (num != 784514210U)
								{
									goto IL_609;
								}
								if (!(text == "sidebar_lock_cursor"))
								{
									goto IL_609;
								}
								sidebarElement = this.CreateElement("sidebar_lock_cursor", "STRING_TOGGLE_LOCK_CURSOR", new EventHandler(this.LockCursorHandler));
								this.AddElement(sidebarElement, false);
								Sidebar.ChangeElementState(sidebarElement, false);
							}
							else
							{
								if (!(text == "sidebar_gamepad"))
								{
									goto IL_609;
								}
								sidebarElement = this.CreateElement("sidebar_gamepad", "STRING_GAMEPAD_CONTROLS", new EventHandler(this.GamepadControlsWindowHandler));
								this.AddElement(sidebarElement, false);
								Sidebar.ChangeElementState(sidebarElement, false);
							}
						}
						else if (num != 785324652U)
						{
							if (num != 964859351U)
							{
								goto IL_609;
							}
							if (!(text == "sidebar_rotate"))
							{
								goto IL_609;
							}
							sidebarElement = this.CreateElement("sidebar_rotate", "STRING_ROTATE", new EventHandler(this.RotateHandler));
							this.AddElement(sidebarElement, false);
							Sidebar.ChangeElementState(sidebarElement, false);
						}
						else
						{
							if (!(text == "sidebar_macro"))
							{
								goto IL_609;
							}
							sidebarElement = this.CreateElement("sidebar_macro", "STRING_MACRO_RECORDER", new EventHandler(this.MacroButtonHandler));
							sidebarElement.MouseLeave += this.MMacroButtonAndPopup_MouseLeave;
							this.AddElement(sidebarElement, false);
						}
					}
					else if (num <= 1275655550U)
					{
						if (num != 1198477406U)
						{
							if (num != 1275655550U)
							{
								goto IL_609;
							}
							if (!(text == "sidebar_video_capture"))
							{
								goto IL_609;
							}
							sidebarElement = this.CreateElement("sidebar_video_capture", "STRING_RECORD_SCREEN", new EventHandler(this.ScreenRecorderButtonHandler));
							this.AddElement(sidebarElement, false);
							Sidebar.ChangeElementState(sidebarElement, false);
						}
						else
						{
							if (!(text == "sidebar_shake"))
							{
								goto IL_609;
							}
							sidebarElement = this.CreateElement("sidebar_shake", "STRING_SHAKE", new EventHandler(this.ShakeHandler));
							this.AddElement(sidebarElement, false);
						}
					}
					else if (num != 1508932284U)
					{
						if (num != 1613331775U)
						{
							goto IL_609;
						}
						if (!(text == "sidebar_location"))
						{
							goto IL_609;
						}
						sidebarElement = this.CreateElement("sidebar_location", "STRING_SET_LOCATION", new EventHandler(this.LocationHandler));
						this.AddElement(sidebarElement, false);
						Sidebar.ChangeElementState(sidebarElement, false);
					}
					else
					{
						if (!(text == "sidebar_screenshot"))
						{
							goto IL_609;
						}
						sidebarElement = this.CreateElement("sidebar_screenshot", "STRING_TOOLBAR_CAMERA", new EventHandler(this.ScreenshotHandler));
						this.AddElement(sidebarElement, false);
						Sidebar.ChangeElementState(sidebarElement, false);
					}
				}
				else if (num <= 2204537713U)
				{
					if (num <= 1828502634U)
					{
						if (num != 1740645932U)
						{
							if (num != 1828502634U)
							{
								goto IL_609;
							}
							if (!(text == "sidebar_controls"))
							{
								goto IL_609;
							}
							sidebarElement = this.CreateElement("sidebar_controls", "STRING_CONTROLS_EDITOR", new EventHandler(this.GameControlButtonHandler));
							sidebarElement.PreviewMouseRightButtonUp += this.KeyMapControlsButton_PreviewMouseRightButtonUp;
							sidebarElement.MouseLeave += this.GameControlButtonPopup_MouseLeave;
							this.AddElement(sidebarElement, false);
							Sidebar.ChangeElementState(sidebarElement, false);
						}
						else
						{
							if (!(text == "sidebar_stream_video"))
							{
								goto IL_609;
							}
							sidebarElement = this.CreateElement("sidebar_stream_video", "STRING_START_STREAMING", new EventHandler(this.StreamingHandler));
							this.AddElement(sidebarElement, false);
							Sidebar.ChangeElementState(sidebarElement, false);
						}
					}
					else if (num != 1902815577U)
					{
						if (num != 2204537713U)
						{
							goto IL_609;
						}
						if (!(text == "sidebar_operation"))
						{
							goto IL_609;
						}
						sidebarElement = this.CreateElement("sidebar_operation", "STRING_SYNCHRONISER", new EventHandler(this.OperationSyncHandler));
						this.AddElement(sidebarElement, false);
					}
					else
					{
						if (!(text == "sidebar_media_folder"))
						{
							goto IL_609;
						}
						sidebarElement = this.CreateElement("sidebar_media_folder", "STRING_OPEN_MEDIA_FOLDER", new EventHandler(this.MediaFolderHandler));
						this.AddElement(sidebarElement, false);
					}
				}
				else if (num <= 3250257129U)
				{
					if (num != 2888420628U)
					{
						if (num != 3250257129U)
						{
							goto IL_609;
						}
						if (!(text == "sidebar_fullscreen"))
						{
							goto IL_609;
						}
						sidebarElement = this.CreateElement("sidebar_fullscreen", "STRING_UPDATED_FULLSCREEN_BUTTON_TOOLTIP", new EventHandler(this.FullScreenHandler));
						this.AddElement(sidebarElement, false);
						Sidebar.ChangeElementState(sidebarElement, false);
					}
					else
					{
						if (!(text == "sidebar_toggle"))
						{
							goto IL_609;
						}
						sidebarElement = this.CreateElement("sidebar_toggle", "STRING_TOGGLE_KEYMAPPING_STATE", new EventHandler(this.KeymapToggleHandler));
						this.AddElement(sidebarElement, false);
						Sidebar.ChangeElementState(sidebarElement, false);
					}
				}
				else if (num != 3462101782U)
				{
					if (num != 3723511498U)
					{
						if (num != 3976567256U)
						{
							goto IL_609;
						}
						if (!(text == "sidebar_overlay"))
						{
							goto IL_609;
						}
						sidebarElement = this.CreateElement("sidebar_overlay", "STRING_TOGGLE_OVERLAY", new EventHandler(this.KeymappingControlsTransparencyButtonHandler));
						this.AddElement(sidebarElement, false);
						sidebarElement.MouseLeave += this.ChangeTransparencyPopup_MouseLeave;
						Sidebar.ChangeElementState(sidebarElement, false);
					}
					else
					{
						if (!(text == "sidebar_volume"))
						{
							goto IL_609;
						}
						sidebarElement = this.CreateElement("sidebar_volume", "STRING_CHANGE_VOLUME", new EventHandler(this.VolumeButtonHandler));
						this.AddElement(sidebarElement, false);
						sidebarElement.MouseLeave += this.VolumeSliderPopup_MouseLeave;
						Sidebar.ChangeElementState(sidebarElement, false);
					}
				}
				else
				{
					if (!(text == "sidebar_mm"))
					{
						goto IL_609;
					}
					sidebarElement = this.CreateElement("sidebar_mm", "STRING_TOGGLE_MULTIINSTANCE_WINDOW", new EventHandler(this.MIManagerHandler));
					this.AddElement(sidebarElement, false);
				}
				IL_61D:
				if (text == ls.Last<string>())
				{
					sidebarElement.IsLastElementOfGroup = true;
					sidebarElement.IsCurrentLastElementOfGroup = true;
					Sidebar.IncreaseElementBottomMarginIfLast(sidebarElement);
					continue;
				}
				continue;
				IL_609:
				Logger.Warning("Unhandled sidebar element found: {0}", new object[]
				{
					text
				});
				goto IL_61D;
			}
		}

		// Token: 0x06000740 RID: 1856 RVA: 0x0002BC44 File Offset: 0x00029E44
		private void StreamingHandler(object sender, EventArgs e)
		{
			bool mIsStreaming = this.ParentWindow.mIsStreaming;
			NCSoftUtils.Instance.SendStreamingEvent(this.ParentWindow.mVmName, mIsStreaming ? "off" : "on");
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, mIsStreaming ? "StreamVideoOff" : "StreamVideoOn", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06000741 RID: 1857 RVA: 0x0002BCCC File Offset: 0x00029ECC
		private void GamepadControlsWindowHandler(object sender, EventArgs e)
		{
			if (!this.ParentWindow.mCommonHandler.ToggleGamepadAndKeyboardGuidance("gamepad"))
			{
				KMManager.HandleInputMapperWindow(this.ParentWindow, "gamepad");
			}
			string tag = "sidebar";
			string userGuid = RegistryManager.Instance.UserGuid;
			string arg = "GamePad";
			string arg2 = "MouseClick";
			string clientVersion = RegistryManager.Instance.ClientVersion;
			string version = RegistryManager.Instance.Version;
			string oem = RegistryManager.Instance.Oem;
			AppTabButton selectedTab = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab;
			ClientStats.SendMiscellaneousStatsAsync(tag, userGuid, arg, arg2, clientVersion, version, oem, (selectedTab != null) ? selectedTab.PackageName : null, null);
		}

		// Token: 0x06000742 RID: 1858 RVA: 0x0002BD60 File Offset: 0x00029F60
		private void MediaFolderHandler(object sender, EventArgs e)
		{
			CommonHandlers.OpenMediaFolder();
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "MediaFolder", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06000743 RID: 1859 RVA: 0x0002BDB0 File Offset: 0x00029FB0
		private void GoBackHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.BackButtonHandler(false);
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "Back", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06000744 RID: 1860 RVA: 0x00006A9F File Offset: 0x00004C9F
		private void GoHomeHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.HomeButtonHandler(true, false);
		}

		// Token: 0x06000745 RID: 1861 RVA: 0x0002BE0C File Offset: 0x0002A00C
		private void GoSettingsHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.LaunchSettingsWindow();
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "Settings", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06000746 RID: 1862 RVA: 0x0002BE68 File Offset: 0x0002A068
		private void MIManagerHandler(object sender, EventArgs e)
		{
			try
			{
				Process.Start(System.IO.Path.Combine(RegistryStrings.InstallDir, "HD-MultiInstanceManager.exe"));
				ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "MultiInstance", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't launch MI Manager. Ex: {0}", new object[]
				{
					ex.Message
				});
			}
		}

		// Token: 0x06000747 RID: 1863 RVA: 0x00006AB3 File Offset: 0x00004CB3
		private void RotateHandler(object sender, EventArgs e)
		{
			this.RotateButtonHandler("MouseClick");
		}

		// Token: 0x06000748 RID: 1864 RVA: 0x0002BEF8 File Offset: 0x0002A0F8
		internal void RotateButtonHandler(string action)
		{
			this.mIsUIInPortraitModeBeforeChange = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsPortraitModeTab;
			this.ParentWindow.AppForcedOrientationDict[this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName] = !this.mIsUIInPortraitModeBeforeChange;
			this.ParentWindow.ChangeOrientationFromClient(!this.mIsUIInPortraitModeBeforeChange, true);
			string text = this.mIsUIInPortraitModeBeforeChange ? "landscape" : "portrait";
			string tag = "sidebar";
			string userGuid = RegistryManager.Instance.UserGuid;
			string arg = "Rotate";
			string clientVersion = RegistryManager.Instance.ClientVersion;
			string version = RegistryManager.Instance.Version;
			string oem = RegistryManager.Instance.Oem;
			string arg2 = text;
			AppTabButton selectedTab = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab;
			ClientStats.SendMiscellaneousStatsAsync(tag, userGuid, arg, action, clientVersion, version, oem, arg2, (selectedTab != null) ? selectedTab.PackageName : null);
		}

		// Token: 0x06000749 RID: 1865 RVA: 0x0002BFE4 File Offset: 0x0002A1E4
		private void ShakeHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.ShakeButtonHandler();
			string tag = "sidebar";
			string userGuid = RegistryManager.Instance.UserGuid;
			string arg = "Shake";
			string arg2 = "MouseClick";
			string clientVersion = RegistryManager.Instance.ClientVersion;
			string version = RegistryManager.Instance.Version;
			string oem = RegistryManager.Instance.Oem;
			AppTabButton selectedTab = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab;
			ClientStats.SendMiscellaneousStatsAsync(tag, userGuid, arg, arg2, clientVersion, version, oem, (selectedTab != null) ? selectedTab.PackageName : null, null);
		}

		// Token: 0x0600074A RID: 1866 RVA: 0x0002C060 File Offset: 0x0002A260
		private void LocationHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.LocationButtonHandler();
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "SetLocation", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x0600074B RID: 1867 RVA: 0x00006AC0 File Offset: 0x00004CC0
		private void LockCursorHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.ClipMouseCursorHandler(false, true, "MouseClick", "sidebar");
		}

		// Token: 0x0600074C RID: 1868 RVA: 0x00006ADE File Offset: 0x00004CDE
		private void ScreenshotHandler(object sender, EventArgs e)
		{
			ToolTipService.SetToolTip(sender as SidebarElement, null);
			this.mScreenshotPopup.IsOpen = false;
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				Thread.Sleep(100);
				this.ParentWindow.mCommonHandler.ScreenShotButtonHandler();
				ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "Screenshot", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
			});
		}

		// Token: 0x0600074D RID: 1869 RVA: 0x0002C0BC File Offset: 0x0002A2BC
		private void VolumeButtonHandler(object sender, EventArgs e)
		{
			if (!this.GetElementFromTag("sidebar_volume").IsInMainSidebar)
			{
				this.mVolumeSliderPopup.StaysOpen = false;
			}
			else
			{
				this.mVolumeSliderPopup.StaysOpen = true;
			}
			if (this.mVolumeSliderPopup.IsOpen)
			{
				this.mVolumeSliderPopup.IsOpen = false;
				return;
			}
			this.mVolumeSliderPopup.IsOpen = true;
		}

		// Token: 0x0600074E RID: 1870 RVA: 0x00006B0A File Offset: 0x00004D0A
		private void FullScreenHandler(object sender, EventArgs e)
		{
			if (!this.ParentWindow.mStreamingModeEnabled)
			{
				this.ParentWindow.mCommonHandler.FullScreenButtonHandler("sidebar", "MouseClick");
			}
		}

		// Token: 0x0600074F RID: 1871 RVA: 0x0002C11C File Offset: 0x0002A31C
		internal SidebarElement GetElementFromTag(string tag)
		{
			if (this.mListSidebarElements.Count >= 1)
			{
				return (from item in this.mListSidebarElements
				where (string)item.Tag == tag
				select item).FirstOrDefault<SidebarElement>();
			}
			return null;
		}

		// Token: 0x06000750 RID: 1872 RVA: 0x00006B33 File Offset: 0x00004D33
		public void AddElement(SidebarElement ele, bool isStaticElement = false)
		{
			if (isStaticElement)
			{
				this.mStaticButtonsStackPanel.Children.Add(ele);
				return;
			}
			this.mElementsStackPanel.Children.Add(ele);
		}

		// Token: 0x06000751 RID: 1873 RVA: 0x00006B5D File Offset: 0x00004D5D
		public void UpdateToDefaultImage(string tag)
		{
			Sidebar.UpdateToDefaultImage(this.GetElementFromTag(tag));
		}

		// Token: 0x06000752 RID: 1874 RVA: 0x00006B6B File Offset: 0x00004D6B
		public void UpdateImage(string tag, string newImage)
		{
			Sidebar.UpdateImage(this.GetElementFromTag(tag), newImage);
		}

		// Token: 0x06000753 RID: 1875 RVA: 0x00006B7A File Offset: 0x00004D7A
		public static void UpdateToDefaultImage(SidebarElement ele)
		{
			if (ele != null)
			{
				ele.Image.ImageName = (string)ele.Tag;
			}
		}

		// Token: 0x06000754 RID: 1876 RVA: 0x00006B95 File Offset: 0x00004D95
		public static void UpdateImage(SidebarElement ele, string newImage)
		{
			if (ele != null)
			{
				ele.Image.ImageName = newImage;
			}
		}

		// Token: 0x06000755 RID: 1877 RVA: 0x0002C164 File Offset: 0x0002A364
		private static void DecreaseElementBottomMargin(SidebarElement ele)
		{
			Thickness margin = ele.Margin;
			margin.Bottom = 2.0;
			ele.Margin = margin;
		}

		// Token: 0x06000756 RID: 1878 RVA: 0x0002C190 File Offset: 0x0002A390
		private static void IncreaseElementBottomMarginIfLast(SidebarElement ele)
		{
			if (ele.IsCurrentLastElementOfGroup)
			{
				Thickness margin = ele.Margin;
				margin.Bottom = 10.0;
				ele.Margin = margin;
			}
		}

		// Token: 0x06000757 RID: 1879 RVA: 0x0002C1C4 File Offset: 0x0002A3C4
		private SidebarElement CreateElement(string imageName, string toolTipKey, EventHandler evt)
		{
			SidebarElement sidebarElement = new SidebarElement
			{
				Margin = new Thickness(0.0, 2.0, 0.0, 2.0),
				Visibility = Visibility.Visible,
				mSidebarElementTooltipKey = toolTipKey
			};
			sidebarElement.Image.ImageName = imageName;
			sidebarElement.Tag = imageName;
			sidebarElement.PreviewMouseLeftButtonUp += this.SidebarElement_PreviewMouseLeftButtonUp;
			sidebarElement.IsVisibleChanged += this.SidebarElement_IsVisibleChanged;
			this.SetSidebarElementTooltip(sidebarElement, toolTipKey);
			this.mDictActions.Add(sidebarElement, evt);
			this.mListSidebarElements.Add(sidebarElement);
			return sidebarElement;
		}

		// Token: 0x06000758 RID: 1880 RVA: 0x0002C270 File Offset: 0x0002A470
		internal void SetSidebarElementTooltip(SidebarElement ele, string toolTipKey)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				string text;
				if (ele.Tag.ToString() == "sidebar_volume")
				{
					text = Sidebar.GetTooltip(LocaleStrings.GetLocalizedString("STRING_INCREASE_VOLUME"), this.ParentWindow.mCommonHandler.GetShortcutKeyFromName("STRING_INCREASE_VOLUME", false), " ");
					text = text + "\n" + Sidebar.GetTooltip(LocaleStrings.GetLocalizedString("STRING_DECREASE_VOLUME"), this.ParentWindow.mCommonHandler.GetShortcutKeyFromName("STRING_DECREASE_VOLUME", false), " ");
					this.mVolumeMuteUnmuteImage.ToolTip = Sidebar.GetTooltip(LocaleStrings.GetLocalizedString("STRING_TOGGLE_MUTE_STATE"), this.ParentWindow.mCommonHandler.GetShortcutKeyFromName("STRING_TOGGLE_MUTE_STATE", false), "\n");
				}
				else
				{
					text = Sidebar.GetTooltip(LocaleStrings.GetLocalizedString(toolTipKey), this.ParentWindow.mCommonHandler.GetShortcutKeyFromName(toolTipKey, false), "\n");
				}
				ele.ToolTip = new ToolTip
				{
					Content = text
				};
			}), new object[0]);
		}

		// Token: 0x06000759 RID: 1881 RVA: 0x0002C2BC File Offset: 0x0002A4BC
		private static string GetTooltip(string text, string shortcut, string delimiter = "\n")
		{
			if (!string.IsNullOrEmpty(shortcut))
			{
				return string.Format(CultureInfo.InvariantCulture, string.Concat(new string[]
				{
					text,
					delimiter,
					"(",
					shortcut,
					")"
				}), new object[0]);
			}
			if (!string.IsNullOrEmpty(text))
			{
				return text;
			}
			return null;
		}

		// Token: 0x0600075A RID: 1882 RVA: 0x0002C314 File Offset: 0x0002A514
		private void SidebarElement_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (!this.mIsOneSidebarElementLoadedBinded && (bool)e.NewValue)
			{
				this.mIsOneSidebarElementLoadedBinded = true;
				SidebarElement sidebarElement = sender as SidebarElement;
				if (sidebarElement != null && this.mSidebarElementApproxHeight == 0.0)
				{
					int num = (int)sidebarElement.Height + 2 * (int)sidebarElement.Margin.Top;
					int num2 = (from item in this.mListSidebarElements
					where item.IsLastElementOfGroup
					select item).Count<SidebarElement>();
					int num3 = num * this.mElementsStackPanel.Children.Count + (num2 - 1) * 8;
					this.mSidebarElementApproxHeight = (double)(num3 / this.mElementsStackPanel.Children.Count + 2);
					Logger.Info("Aprrox: {0}", new object[]
					{
						this.mSidebarElementApproxHeight
					});
				}
			}
			this.UpdateTotalVisibleElementCount();
		}

		// Token: 0x0600075B RID: 1883 RVA: 0x0002C408 File Offset: 0x0002A608
		private void SidebarElement_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			SidebarElement sidebarElement = sender as SidebarElement;
			if (this.mDictActions.ContainsKey(sidebarElement))
			{
				EventHandler eventHandler = this.mDictActions[sidebarElement];
				if (eventHandler == null)
				{
					return;
				}
				eventHandler(sidebarElement, new EventArgs());
			}
		}

		// Token: 0x0600075C RID: 1884 RVA: 0x00006BA6 File Offset: 0x00004DA6
		private void MSidebar_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			this.ArrangeAllSidebarElements();
		}

		// Token: 0x0600075D RID: 1885 RVA: 0x0002C448 File Offset: 0x0002A648
		internal void ArrangeAllSidebarElements()
		{
			try
			{
				if (base.Visibility == Visibility.Visible)
				{
					double num = base.ActualHeight - this.mBottomGrid.ActualHeight - this.mMoreButton.ActualHeight;
					if (num > 0.0)
					{
						int num2 = Math.Min((int)(num / this.mSidebarElementApproxHeight), this.mTotalVisibleElements);
						List<SidebarElement> list = (from item in this.mElementsStackPanel.Children.OfType<SidebarElement>()
						where item.Visibility == Visibility.Visible
						select item).ToList<SidebarElement>();
						int count = list.Count;
						if (count > num2)
						{
							int num3 = count - num2;
							for (int i = 1; i <= num3; i++)
							{
								SidebarElement sidebarElement = list[count - i];
								this.mElementsStackPanel.Children.Remove(sidebarElement);
								sidebarElement.IsInMainSidebar = false;
							}
						}
						else if (count < num2)
						{
							int num4 = num2 - count;
							SidebarElement[] array = (from item in this.mListSidebarElements
							where !item.IsInMainSidebar
							select item).ToArray<SidebarElement>();
							for (int j = 0; j < num4; j++)
							{
								if (array.Length > j)
								{
									SidebarElement sidebarElement2 = array[j];
									sidebarElement2.IsInMainSidebar = true;
									this.AddToVisibleElementsPanel(sidebarElement2);
								}
							}
						}
						if (this.mListSidebarElements.Any((SidebarElement x) => !x.IsInMainSidebar))
						{
							this.mMoreButton.Visibility = Visibility.Visible;
						}
						else
						{
							this.mMoreButton.Visibility = Visibility.Collapsed;
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("XXX SR: An error occured while rearranging elements. Ex: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x0600075E RID: 1886 RVA: 0x0002C610 File Offset: 0x0002A810
		private void AddToVisibleElementsPanel(SidebarElement ele)
		{
			StackPanel stackPanel = ele.Parent as StackPanel;
			if (stackPanel != null)
			{
				stackPanel.Children.Remove(ele);
			}
			this.mElementsStackPanel.Children.Add(ele);
			Sidebar.IncreaseElementBottomMarginIfLast(ele);
		}

		// Token: 0x0600075F RID: 1887 RVA: 0x00006BAE File Offset: 0x00004DAE
		public void SetHeight()
		{
			base.Height = this.ParentWindow.mContentGrid.ActualHeight;
		}

		// Token: 0x06000760 RID: 1888 RVA: 0x0002C650 File Offset: 0x0002A850
		private void MMoreElements_Opened(object sender, EventArgs e)
		{
			this.SidebarPopupContentClear();
			this.mSidebarPopup.InitAllElements(from x in this.mListSidebarElements
			where !x.IsInMainSidebar
			select x);
			Sidebar.UpdateImage(this.mMoreButton, "sidebar_options_open");
			BlueStacksUIBinding.Bind(this.mMoreButton, "STRING_CLOSE");
		}

		// Token: 0x06000761 RID: 1889 RVA: 0x00006BC6 File Offset: 0x00004DC6
		private void MMoreElements_Closed(object sender, EventArgs e)
		{
			this.SidebarPopupContentClear();
			Sidebar.UpdateImage(this.mMoreButton, "sidebar_options_close");
			BlueStacksUIBinding.Bind(this.mMoreButton, "STRING_MORE_BUTTON");
		}

		// Token: 0x06000762 RID: 1890 RVA: 0x0002C6B8 File Offset: 0x0002A8B8
		private void SidebarPopupContentClear()
		{
			foreach (object obj in this.mSidebarPopup.mMainStackPanel.Children)
			{
				((StackPanel)obj).Children.Clear();
			}
			this.mSidebarPopup.mMainStackPanel.Children.Clear();
		}

		// Token: 0x06000763 RID: 1891 RVA: 0x00006BEE File Offset: 0x00004DEE
		private void MSidebarPopup_PreviewMouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x06000764 RID: 1892 RVA: 0x00006BF7 File Offset: 0x00004DF7
		private void MMoreButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mMoreElements.IsOpen = !this.mMoreElements.IsOpen;
		}

		// Token: 0x06000765 RID: 1893 RVA: 0x0002C734 File Offset: 0x0002A934
		private void MMoreButton_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.mMoreButton.IsMouseOver)
			{
				if (this.mListPopups.All((CustomPopUp x) => !x.IsMouseOver) && this.mMoreElements.IsOpen)
				{
					if (this.mSidebarPopupTimer == null)
					{
						this.mSidebarPopupTimer = new DispatcherTimer
						{
							Interval = new TimeSpan(0, 0, 0, 0, 500)
						};
						this.mSidebarPopupTimer.Tick += this.SidebarPopupTimer_Tick;
					}
					else
					{
						this.mSidebarPopupTimer.Stop();
					}
					this.mSidebarPopupTimer.Start();
				}
			}
		}

		// Token: 0x06000766 RID: 1894 RVA: 0x0002C7E0 File Offset: 0x0002A9E0
		private void SidebarPopupTimer_Tick(object sender, EventArgs e)
		{
			if (!this.mMoreButton.IsMouseOver)
			{
				if (this.mListPopups.All((CustomPopUp x) => !x.IsMouseOver))
				{
					this.mListPopups.Select(delegate(CustomPopUp c)
					{
						c.IsOpen = false;
						return c;
					}).ToList<CustomPopUp>();
					if (this.mIsInFullscreenMode && !base.IsMouseOver)
					{
						this.ToggleSidebarVisibilityInFullscreen(false);
					}
				}
			}
			(sender as DispatcherTimer).Stop();
		}

		// Token: 0x06000767 RID: 1895 RVA: 0x00006BEE File Offset: 0x00004DEE
		private void ClosePopup_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x06000768 RID: 1896 RVA: 0x0002C878 File Offset: 0x0002AA78
		private void mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.transSlider.Value == 0.0)
			{
				this.transSlider.Value = this.mLastSliderValue;
				this.mTranslucentControlsSliderButton.ImageName = "sidebar_overlay_popup";
				return;
			}
			double value = this.transSlider.Value;
			this.transSlider.Value = 0.0;
			this.mLastSliderValue = value;
			this.mTranslucentControlsSliderButton.ImageName = "sidebar_overlay_inactive_popup";
		}

		// Token: 0x06000769 RID: 1897 RVA: 0x0002C8F4 File Offset: 0x0002AAF4
		private void TransparencySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			KMManager.ChangeTransparency(this.ParentWindow, this.transSlider.Value);
			if (this.transSlider.Value == 0.0)
			{
				this.mTranslucentControlsSliderButton.ImageName = "sidebar_overlay_inactive_popup";
				if (!RegistryManager.Instance.ShowKeyControlsOverlay)
				{
					KMManager.ShowOverlayWindow(this.ParentWindow, false, false);
				}
				this.ParentWindow_OverlayStateChangedEvent(false);
			}
			else
			{
				this.mTranslucentControlsSliderButton.ImageName = "sidebar_overlay_popup";
				KMManager.ShowOverlayWindow(this.ParentWindow, true, false);
				this.ParentWindow_OverlayStateChangedEvent(true);
			}
			this.mLastSliderValue = this.transSlider.Value;
		}

		// Token: 0x0600076A RID: 1898 RVA: 0x00006C12 File Offset: 0x00004E12
		private void OverlayTooltipCPB_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mOverlayTooltip.IsOpen = false;
			this.mIsOverlayTooltipClosed = true;
			e.Handled = true;
		}

		// Token: 0x0600076B RID: 1899 RVA: 0x0002C994 File Offset: 0x0002AB94
		private void OverlayDoNotShowCheckbox_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (string.Equals(this.mOverlayDoNotShowCheckboxImage.ImageName, "bgpcheckbox", StringComparison.InvariantCulture))
			{
				this.mOverlayDoNotShowCheckboxImage.ImageName = "bgpcheckbox_checked";
				RegistryManager.Instance.OverlayAvailablePromptEnabled = false;
			}
			else
			{
				this.mOverlayDoNotShowCheckboxImage.ImageName = "bgpcheckbox";
				RegistryManager.Instance.OverlayAvailablePromptEnabled = true;
			}
			e.Handled = true;
		}

		// Token: 0x0600076C RID: 1900 RVA: 0x00006C2E File Offset: 0x00004E2E
		private void ScreenRecorderButtonHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.DownloadAndLaunchRecording("sidebar", "MouseClick");
		}

		// Token: 0x0600076D RID: 1901 RVA: 0x00006C4A File Offset: 0x00004E4A
		private void RecordScreenPopupClose_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mRecordScreenPopup.IsOpen = false;
		}

		// Token: 0x0600076E RID: 1902 RVA: 0x0002C9F8 File Offset: 0x0002ABF8
		private void RecordScreenPopup_Closed(object sender, EventArgs e)
		{
			if (CommonHandlers.sIsRecordingVideo)
			{
				BlueStacksUIBinding.Bind(this.RecordScreenPopupHeader, "STRING_STOP_RECORDING", "");
				this.RecordScreenPopupHeader.Visibility = Visibility.Visible;
				this.RecordScreenPopupBody.Visibility = Visibility.Collapsed;
				this.mRecordScreenClose.Visibility = Visibility.Collapsed;
			}
			else
			{
				BlueStacksUIBinding.Bind(this.RecordScreenPopupHeader, "STRING_RECORD_SCREEN", "");
				BlueStacksUIBinding.Bind(this.RecordScreenPopupBody, "STRING_RECORD_SCREEN_PLAYING", "");
				this.RecordScreenPopupHeader.Visibility = Visibility.Visible;
				this.RecordScreenPopupBody.Visibility = Visibility.Visible;
				this.mRecordScreenClose.Visibility = Visibility.Collapsed;
			}
			this.mRecordScreenPopup.StaysOpen = true;
			this.RecordScreenPopupHyperlink.Visibility = Visibility.Collapsed;
		}

		// Token: 0x0600076F RID: 1903 RVA: 0x0002CAB0 File Offset: 0x0002ACB0
		private void KeymappingControlsTransparencyButtonHandler(object sender, EventArgs e)
		{
			RegistryManager.Instance.ShowKeyControlsOverlay = true;
			RegistryManager.Instance.OverlayAvailablePromptEnabled = false;
			KMManager.ShowOverlayWindow(this.ParentWindow, true, false);
			if (!this.GetElementFromTag("sidebar_overlay").IsInMainSidebar)
			{
				this.mChangeTransparencyPopup.StaysOpen = false;
			}
			else
			{
				this.mChangeTransparencyPopup.StaysOpen = true;
			}
			this.mChangeTransparencyPopup.IsOpen = true;
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "Overlay", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06000770 RID: 1904 RVA: 0x00006C58 File Offset: 0x00004E58
		private void RecordScreenPopupHyperlink_Click(object sender, RoutedEventArgs e)
		{
			CommonHandlers.OpenMediaFolderWithFileSelected(CommonHandlers.mSavedVideoRecordingFilePath);
			this.mRecordScreenPopup.IsOpen = false;
		}

		// Token: 0x06000771 RID: 1905 RVA: 0x0002CB58 File Offset: 0x0002AD58
		private void RecordScreenClose_IsVisibleChanged(object _, DependencyPropertyChangedEventArgs e)
		{
			if ((bool)e.NewValue)
			{
				this.RecordScreenPopupHeader.Margin = new Thickness(0.0, 0.0, 20.0, 0.0);
				return;
			}
			this.RecordScreenPopupHeader.Margin = new Thickness(0.0);
		}

		// Token: 0x06000772 RID: 1906 RVA: 0x0002CBC4 File Offset: 0x0002ADC4
		private void MSidebar_IsVisibleChanged(object _, DependencyPropertyChangedEventArgs e)
		{
			if (!this.mIsInFullscreenMode && base.IsLoaded)
			{
				if ((bool)e.NewValue)
				{
					this.ParentWindow.ParentWindowWidthDiff = 62;
					this.ParentWindow.Width = this.ParentWindow.ActualWidth + base.Width;
					this.ArrangeAllSidebarElements();
				}
				else
				{
					this.ParentWindow.ParentWindowWidthDiff = 2;
					this.ParentWindow.Width = Math.Max(this.ParentWindow.ActualWidth - base.Width, this.ParentWindow.MinWidth);
				}
				this.ParentWindow.HandleDisplaySettingsChanged();
				this.ParentWindow.Height = this.ParentWindow.GetHeightFromWidth(this.ParentWindow.Width, false, false);
			}
		}

		// Token: 0x06000773 RID: 1907 RVA: 0x00006C70 File Offset: 0x00004E70
		private void MMacroButtonPopup_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mMacroButtonPopup.IsOpen = true;
		}

		// Token: 0x06000774 RID: 1908 RVA: 0x0002CC90 File Offset: 0x0002AE90
		internal void ShowOverlayTooltip(bool isShow, bool force = false)
		{
			if (this.GetElementFromTag("sidebar_overlay") == null || !RegistryManager.Instance.OverlayAvailablePromptEnabled)
			{
				return;
			}
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (isShow)
				{
					this.mIsPendingShowOverlayTooltip = true;
					this.ActualOverlayTooltip(force);
					return;
				}
				this.mOverlayTooltip.IsOpen = false;
			}), new object[0]);
		}

		// Token: 0x06000775 RID: 1909 RVA: 0x0002CCF0 File Offset: 0x0002AEF0
		private void ActualOverlayTooltip(bool force = false)
		{
			if (RegistryManager.Instance.OverlayAvailablePromptEnabled && !this.mIsOverlayTooltipClosed && this.mIsPendingShowOverlayTooltip && (!RegistryManager.Instance.IsAutoShowGuidance || Array.Exists<string>(RegistryManager.Instance.DisabledGuidancePackages, (string element) => element == this.ParentWindow.StaticComponents.mSelectedTabButton.PackageName) || force) && !this.mIsInFullscreenMode && !FeatureManager.Instance.IsCustomUIForNCSoft && base.Visibility == Visibility.Visible)
			{
				this.mIsPendingShowOverlayTooltip = false;
				this.mOverlayTooltip.IsOpen = true;
			}
		}

		// Token: 0x06000776 RID: 1910 RVA: 0x0002CD78 File Offset: 0x0002AF78
		private void ActualKeymapPopup()
		{
			if (!RegistryManager.Instance.OverlayAvailablePromptEnabled || this.mIsOverlayTooltipClosed)
			{
				string packageName = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName;
				if (AppConfigurationManager.Instance.VmAppConfig[this.ParentWindow.mVmName][packageName].IsKeymappingTooltipShown)
				{
					return;
				}
				AppConfigurationManager.Instance.VmAppConfig[this.ParentWindow.mVmName][packageName].IsKeymappingTooltipShown = true;
			}
		}

		// Token: 0x06000777 RID: 1911 RVA: 0x0002CE04 File Offset: 0x0002B004
		internal void ShowKeyMapPopup(bool isShow)
		{
			if (this.GetElementFromTag("sidebar_controls") == null)
			{
				return;
			}
			if (isShow)
			{
				if (!Array.Exists<string>(RegistryManager.Instance.DisabledGuidancePackages, (string element) => element == this.ParentWindow.StaticComponents.mSelectedTabButton.PackageName) && RegistryManager.Instance.IsAutoShowGuidance)
				{
					KMManager.HandleInputMapperWindow(this.ParentWindow, "");
					return;
				}
				this.ActualKeymapPopup();
			}
		}

		// Token: 0x06000778 RID: 1912 RVA: 0x0002CE64 File Offset: 0x0002B064
		private void OpenMacroGridPreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.ShowMacroRecorderWindow();
			this.mMacroButtonPopup.IsOpen = false;
			this.ToggleSidebarVisibilityInFullscreen(false);
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "MacroRecorder", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, "MacroBookmarkPopup", null);
		}

		// Token: 0x06000779 RID: 1913 RVA: 0x00006C7E File Offset: 0x00004E7E
		private void OpenMacroGridMouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x0600077A RID: 1914 RVA: 0x00006C95 File Offset: 0x00004E95
		private void OpenMacroGridMouseLeave(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "SidebarBackground");
		}

		// Token: 0x0600077B RID: 1915 RVA: 0x0002CED8 File Offset: 0x0002B0D8
		private void VolumeImage_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.MuteUnmuteButtonHanlder();
			if (this.ParentWindow.EngineInstanceRegistry.IsMuted)
			{
				ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "VolumeOn", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
				return;
			}
			ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "VolumeOff", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x0600077C RID: 1916 RVA: 0x0002CF84 File Offset: 0x0002B184
		private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			this.mCurrentVolumeValue.Text = Math.Round(e.NewValue).ToString(CultureInfo.InvariantCulture);
		}

		// Token: 0x0600077D RID: 1917 RVA: 0x0002CFB4 File Offset: 0x0002B1B4
		private void VolumeSlider_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			int volumeInFrontendAsync = Convert.ToInt32(this.mVolumeSlider.Value);
			this.ParentWindow.Utils.SetVolumeInFrontendAsync(volumeInFrontendAsync);
		}

		// Token: 0x0600077E RID: 1918 RVA: 0x0002CFE4 File Offset: 0x0002B1E4
		private void MuteInstancesCheckboxImage_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mMuteInstancesCheckboxImage.ImageName.Equals("bgpcheckbox", StringComparison.OrdinalIgnoreCase))
			{
				this.mMuteInstancesCheckboxImage.ImageName = "bgpcheckbox_checked";
				RegistryManager.Instance.AreAllInstancesMuted = true;
				this.SendMuteUnmuteRequestToAllInstances(true);
				ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "VolumeOffAll", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
			}
			else
			{
				this.mMuteInstancesCheckboxImage.ImageName = "bgpcheckbox";
				RegistryManager.Instance.AreAllInstancesMuted = false;
				this.SendMuteUnmuteRequestToAllInstances(false);
				ClientStats.SendMiscellaneousStatsAsync("sidebar", RegistryManager.Instance.UserGuid, "VolumeOnAll", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
			}
			e.Handled = true;
		}

		// Token: 0x0600077F RID: 1919 RVA: 0x0002D0D4 File Offset: 0x0002B2D4
		private void SendMuteUnmuteRequestToAllInstances(bool isMute)
		{
			foreach (string text in RegistryManager.Instance.VmList)
			{
				if (isMute)
				{
					if (BlueStacksUIUtils.DictWindows.Keys.Contains(text))
					{
						BlueStacksUIUtils.DictWindows[text].Utils.MuteApplication(true);
					}
				}
				else if (BlueStacksUIUtils.DictWindows.Keys.Contains(text))
				{
					BlueStacksUIUtils.DictWindows[text].Utils.UnmuteApplication(true);
				}
			}
		}

		// Token: 0x06000780 RID: 1920 RVA: 0x0002D154 File Offset: 0x0002B354
		private void ChangeTransparencyPopup_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.mChangeTransparencyPopup.IsOpen)
			{
				if (this.mChangeTransparencyPopupTimer == null)
				{
					this.mChangeTransparencyPopupTimer = new DispatcherTimer
					{
						Interval = new TimeSpan(0, 0, 0, 0, 500)
					};
					this.mChangeTransparencyPopupTimer.Tick += this.ChangeTransparencyPopupTimer_Tick;
				}
				else
				{
					this.mChangeTransparencyPopupTimer.Stop();
				}
				this.mChangeTransparencyPopupTimer.Start();
			}
		}

		// Token: 0x06000781 RID: 1921 RVA: 0x0002D1C4 File Offset: 0x0002B3C4
		private void ChangeTransparencyPopupTimer_Tick(object sender, EventArgs e)
		{
			if (!this.mChangeTransparencyPopup.IsMouseOver && !this.GetElementFromTag("sidebar_overlay").IsMouseOver)
			{
				this.mChangeTransparencyPopup.IsOpen = false;
				if (this.mIsInFullscreenMode && !base.IsMouseOver)
				{
					this.ToggleSidebarVisibilityInFullscreen(false);
				}
			}
			(sender as DispatcherTimer).Stop();
		}

		// Token: 0x06000782 RID: 1922 RVA: 0x00006CAC File Offset: 0x00004EAC
		private void ChangeTransparencyPopup_MouseEnter(object sender, MouseEventArgs e)
		{
			if (!this.GetElementFromTag("sidebar_overlay").IsInMainSidebar)
			{
				this.mChangeTransparencyPopup.StaysOpen = false;
			}
			else
			{
				this.mChangeTransparencyPopup.StaysOpen = true;
			}
			this.mChangeTransparencyPopup.IsOpen = true;
		}

		// Token: 0x06000783 RID: 1923 RVA: 0x00006CE6 File Offset: 0x00004EE6
		private void VolumeSliderPopup_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mVolumeSliderPopup.IsOpen = true;
		}

		// Token: 0x06000784 RID: 1924 RVA: 0x0002D220 File Offset: 0x0002B420
		private void VolumeSliderPopup_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.mVolumeSliderPopup.IsOpen)
			{
				if (this.mVolumeSliderPopupTimer == null)
				{
					this.mVolumeSliderPopupTimer = new DispatcherTimer
					{
						Interval = new TimeSpan(0, 0, 1)
					};
					this.mVolumeSliderPopupTimer.Tick += this.VolumeSliderPopupTimer_Tick;
				}
				else
				{
					this.mVolumeSliderPopupTimer.Stop();
				}
				this.mVolumeSliderPopupTimer.Start();
			}
		}

		// Token: 0x06000785 RID: 1925 RVA: 0x0002D28C File Offset: 0x0002B48C
		internal void VolumeSliderPopupTimer_Tick(object sender, EventArgs e)
		{
			if (!this.mVolumeSliderPopup.IsMouseOver && !this.GetElementFromTag("sidebar_volume").IsMouseOver)
			{
				this.mVolumeSliderPopup.IsOpen = false;
				if (this.mIsInFullscreenMode && !base.IsMouseOver)
				{
					this.ToggleSidebarVisibilityInFullscreen(false);
				}
			}
			(sender as DispatcherTimer).Stop();
		}

		// Token: 0x06000786 RID: 1926 RVA: 0x00006CF4 File Offset: 0x00004EF4
		private void ScreenshotPopupClose_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mScreenshotPopup.IsOpen = false;
		}

		// Token: 0x06000787 RID: 1927 RVA: 0x00006D02 File Offset: 0x00004F02
		private void ScreenshotPopupHyperlink_Click(object sender, RoutedEventArgs e)
		{
			CommonHandlers.OpenMediaFolderWithFileSelected(this.currentScreenshotSavedPath);
			this.mScreenshotPopup.IsOpen = false;
		}

		// Token: 0x06000788 RID: 1928 RVA: 0x00006D1B File Offset: 0x00004F1B
		private void GameControlButtonPopup_MouseEnter(object sender, MouseEventArgs e)
		{
			if (!this.GetElementFromTag("sidebar_controls").IsInMainSidebar)
			{
				this.mGameControlButtonPopup.StaysOpen = false;
			}
			else
			{
				this.mGameControlButtonPopup.StaysOpen = true;
			}
			this.mGameControlButtonPopup.IsOpen = true;
		}

		// Token: 0x06000789 RID: 1929 RVA: 0x0002D2E8 File Offset: 0x0002B4E8
		private void GameControlButtonPopup_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.mGameControlButtonPopup.IsOpen)
			{
				if (this.mGameControlBookmarkTimer == null)
				{
					this.mGameControlBookmarkTimer = new DispatcherTimer
					{
						Interval = new TimeSpan(0, 0, 0, 0, 500)
					};
					this.mGameControlBookmarkTimer.Tick += this.GameControlBookmarkTimer_Tick;
				}
				else
				{
					this.mGameControlBookmarkTimer.Stop();
				}
				this.mGameControlBookmarkTimer.Start();
			}
		}

		// Token: 0x0600078A RID: 1930 RVA: 0x0002D358 File Offset: 0x0002B558
		private void GameControlBookmarkTimer_Tick(object sender, EventArgs e)
		{
			if (!this.mGameControlButtonPopup.IsMouseOver && !this.GetElementFromTag("sidebar_controls").IsMouseOver)
			{
				this.mGameControlButtonPopup.IsOpen = false;
				if (this.ParentWindow.mIsFullScreen)
				{
					this.ToggleSidebarVisibilityInFullscreen(false);
				}
			}
			(sender as DispatcherTimer).Stop();
		}

		// Token: 0x0600078B RID: 1931 RVA: 0x0002D3B0 File Offset: 0x0002B5B0
		private void GameControlButtonHandler(object sender, EventArgs e)
		{
			bool flag = true;
			this.mBookmarkedSchemesStackPanel.Children.Clear();
			foreach (IMControlScheme imcontrolScheme in this.ParentWindow.SelectedConfig.ControlSchemes)
			{
				if (imcontrolScheme.IsBookMarked)
				{
					SchemeBookmarkControl element = new SchemeBookmarkControl(imcontrolScheme, this.ParentWindow);
					this.mBookmarkedSchemesStackPanel.Children.Add(element);
					flag = false;
				}
			}
			if (!flag)
			{
				if (KMManager.sGuidanceWindow != null && !KMManager.sGuidanceWindow.IsClosed)
				{
					KMManager.sGuidanceWindow.Close();
				}
				if (!this.GetElementFromTag("sidebar_controls").IsInMainSidebar)
				{
					this.mGameControlButtonPopup.StaysOpen = false;
				}
				else
				{
					this.mGameControlButtonPopup.StaysOpen = true;
				}
				this.mGameControlButtonPopup.IsOpen = true;
				return;
			}
			this.ParentWindow.mCommonHandler.KeyMapButtonHandler("MouseClick", "sidebar");
			this.mGameControlButtonPopup.IsOpen = false;
			this.ToggleSidebarVisibilityInFullscreen(false);
		}

		// Token: 0x0600078C RID: 1932 RVA: 0x00006D55 File Offset: 0x00004F55
		private void OpenGameControlPreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.KeyMapButtonHandler("MouseClick", "sidebar");
			this.mGameControlButtonPopup.IsOpen = false;
			this.ToggleSidebarVisibilityInFullscreen(false);
		}

		// Token: 0x0600078D RID: 1933 RVA: 0x00006C7E File Offset: 0x00004E7E
		private void OpenGameControlMouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x0600078E RID: 1934 RVA: 0x00006D84 File Offset: 0x00004F84
		private void OpenGameControlMouseLeave(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ComboBoxBackgroundColor");
		}

		// Token: 0x0600078F RID: 1935 RVA: 0x0002D4C8 File Offset: 0x0002B6C8
		internal void ChangeVideoRecordingImage(string imageName)
		{
			SidebarElement elementFromTag = this.GetElementFromTag("sidebar_video_capture");
			if (elementFromTag != null)
			{
				elementFromTag.Image.IsImageToBeRotated = false;
				Sidebar.UpdateImage(elementFromTag, imageName);
			}
		}

		// Token: 0x06000790 RID: 1936 RVA: 0x0002D4F8 File Offset: 0x0002B6F8
		private void SetVideoRecordingTooltipForNCSoft()
		{
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				SidebarElement elementFromTag = this.GetElementFromTag("sidebar_video_capture");
				if (elementFromTag != null)
				{
					ToolTip toolTip = elementFromTag.ToolTip as ToolTip;
					toolTip.Content = Convert.ToString(toolTip.Content, CultureInfo.InvariantCulture).Replace(LocaleStrings.GetLocalizedString("STRING_RECORD_SCREEN"), LocaleStrings.GetLocalizedString("STRING_RECORD_SCREEN_WITHOUT_BETA"));
				}
			}
		}

		// Token: 0x06000791 RID: 1937 RVA: 0x0002D55C File Offset: 0x0002B75C
		internal void SetVideoRecordingTooltip(bool isRecording)
		{
			SidebarElement elementFromTag = this.GetElementFromTag("sidebar_video_capture");
			if (elementFromTag != null)
			{
				ToolTip toolTip = elementFromTag.ToolTip as ToolTip;
				if (isRecording)
				{
					if (FeatureManager.Instance.IsCustomUIForNCSoft)
					{
						toolTip.Content = Convert.ToString(toolTip.Content, CultureInfo.InvariantCulture).Replace(LocaleStrings.GetLocalizedString("STRING_RECORD_SCREEN_WITHOUT_BETA"), LocaleStrings.GetLocalizedString("STRING_STOP_RECORDING"));
						return;
					}
					toolTip.Content = Convert.ToString(toolTip.Content, CultureInfo.InvariantCulture).Replace(LocaleStrings.GetLocalizedString("STRING_RECORD_SCREEN"), LocaleStrings.GetLocalizedString("STRING_STOP_RECORDING"));
					return;
				}
				else
				{
					if (FeatureManager.Instance.IsCustomUIForNCSoft)
					{
						toolTip.Content = Convert.ToString(toolTip.Content, CultureInfo.InvariantCulture).Replace(LocaleStrings.GetLocalizedString("STRING_STOP_RECORDING"), LocaleStrings.GetLocalizedString("STRING_RECORD_SCREEN_WITHOUT_BETA"));
						return;
					}
					toolTip.Content = Convert.ToString(toolTip.Content, CultureInfo.InvariantCulture).Replace(LocaleStrings.GetLocalizedString("STRING_STOP_RECORDING"), LocaleStrings.GetLocalizedString("STRING_RECORD_SCREEN"));
				}
			}
		}

		// Token: 0x06000792 RID: 1938 RVA: 0x00006D9B File Offset: 0x00004F9B
		private void VolumeSliderPopup_Closed(object sender, EventArgs e)
		{
			if (!this.GetElementFromTag("sidebar_volume").IsInMainSidebar)
			{
				this.MMoreButton_MouseLeave(null, null);
			}
		}

		// Token: 0x06000793 RID: 1939 RVA: 0x00006DB7 File Offset: 0x00004FB7
		private void GameControlButtonPopup_Closed(object sender, EventArgs e)
		{
			if (!this.GetElementFromTag("sidebar_controls").IsInMainSidebar)
			{
				this.MMoreButton_MouseLeave(null, null);
			}
		}

		// Token: 0x06000794 RID: 1940 RVA: 0x00006DD3 File Offset: 0x00004FD3
		private void ChangeTransparencyPopup_Closed(object sender, EventArgs e)
		{
			if (!this.GetElementFromTag("sidebar_overlay").IsInMainSidebar)
			{
				this.MMoreButton_MouseLeave(null, null);
			}
		}

		// Token: 0x06000795 RID: 1941 RVA: 0x00006DEF File Offset: 0x00004FEF
		private void OpenGameGuideButtonHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.GameGuideButtonHandler("MouseClick", "sidebar");
		}

		// Token: 0x06000796 RID: 1942 RVA: 0x0002D664 File Offset: 0x0002B864
		public void ShowFullscreenOnboardingPopup()
		{
			if (this.ParentWindow.mSidebar.Visibility == Visibility.Collapsed || string.IsNullOrEmpty(this.ParentWindow.mCommonHandler.GetShortcutKeyFromName("STRING_UPDATED_FULLSCREEN_BUTTON_TOOLTIP", false)))
			{
				return;
			}
			SidebarElement sidebarElement = (from SidebarElement s in this.ParentWindow.mSidebar.mElementsStackPanel.Children
			where s.Image.ImageName == "sidebar_fullscreen"
			select s).FirstOrDefault<SidebarElement>();
			if (sidebarElement == null)
			{
				return;
			}
			OnBoardingPopupWindow onBoardingPopupWindow = new OnBoardingPopupWindow(this.ParentWindow, this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName);
			this.ParentWindow.LastOpenedWindow = onBoardingPopupWindow;
			onBoardingPopupWindow.Owner = this.ParentWindow;
			onBoardingPopupWindow.PlacementTarget = sidebarElement;
			onBoardingPopupWindow.Title = "FullScreenBlurb";
			onBoardingPopupWindow.LeftMargin = 310;
			onBoardingPopupWindow.TopMargin = 45;
			onBoardingPopupWindow.IsLastPopup = true;
			onBoardingPopupWindow.HeaderContent = LocaleStrings.GetLocalizedString("STRING_PLAY_BIGGER_HEADER");
			onBoardingPopupWindow.bodyTextBlock.Visibility = Visibility.Collapsed;
			onBoardingPopupWindow.bodyContentBlurbControl.Visibility = Visibility.Visible;
			onBoardingPopupWindow.bodyContentBlurbControl.FirstMessage.Text = LocaleStrings.GetLocalizedString("STRING_PLAY_BIGGER_MESSAGE");
			onBoardingPopupWindow.bodyContentBlurbControl.KeyMessage.Text = this.ParentWindow.mCommonHandler.GetShortcutKeyFromName("STRING_UPDATED_FULLSCREEN_BUTTON_TOOLTIP", false);
			onBoardingPopupWindow.bodyContentBlurbControl.SecondMessage.Text = LocaleStrings.GetLocalizedString("STRING_PLAY_BIGGER_FULL_SCREEN_MESSAGE");
			onBoardingPopupWindow.PopArrowAlignment = PopupArrowAlignment.Right;
			onBoardingPopupWindow.SetValue(Window.LeftProperty, sidebarElement.PointToScreen(new Point(0.0, 0.0)).X / MainWindow.sScalingFactor - (double)onBoardingPopupWindow.LeftMargin);
			onBoardingPopupWindow.SetValue(Window.TopProperty, sidebarElement.PointToScreen(new Point(0.0, 0.0)).Y / MainWindow.sScalingFactor - (double)onBoardingPopupWindow.TopMargin);
			onBoardingPopupWindow.RightArrow.Margin = new Thickness(0.0, 20.0, 0.0, 0.0);
			onBoardingPopupWindow.RightArrow.VerticalAlignment = VerticalAlignment.Top;
			onBoardingPopupWindow.ShowDialog();
		}

		// Token: 0x06000797 RID: 1943 RVA: 0x0002D8AC File Offset: 0x0002BAAC
		public void ShowGuidanceOnboardingPopup()
		{
			SidebarElement sidebarElement = (from SidebarElement s in this.ParentWindow.mSidebar.mStaticButtonsStackPanel.Children
			where s.Image.ImageName == "sidebar_gameguide" || s.Image.ImageName == "sidebar_gameguide_active"
			select s).FirstOrDefault<SidebarElement>();
			if (sidebarElement == null)
			{
				return;
			}
			this.mGameControlsBlurbPopup.PlacementTarget = sidebarElement;
			this.mGameControlsBlurbPopup.IsOpen = true;
			this.mGameControlsBlurbPopup.IsTopmost = true;
		}

		// Token: 0x06000798 RID: 1944 RVA: 0x0002D928 File Offset: 0x0002BB28
		private void OnBoardingPopupNext_Click(object sender, RoutedEventArgs e)
		{
			Stats.SendCommonClientStatsAsync("general-onboarding", "okay_clicked", this.ParentWindow.mVmName, this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName, "ViewControlBlurb", "");
			this.mGameControlsBlurbPopup.IsOpen = false;
		}

		// Token: 0x06000799 RID: 1945 RVA: 0x0002D980 File Offset: 0x0002BB80
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/sidebar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600079A RID: 1946 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600079B RID: 1947 RVA: 0x0002D9B0 File Offset: 0x0002BBB0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mSidebar = (Sidebar)target;
				this.mSidebar.SizeChanged += this.MSidebar_SizeChanged;
				this.mSidebar.IsVisibleChanged += this.MSidebar_IsVisibleChanged;
				this.mSidebar.Loaded += this.Sidebar_Loaded;
				return;
			case 2:
				this.mBorder = (Border)target;
				return;
			case 3:
				this.mGrid = (Grid)target;
				return;
			case 4:
				this.mTopGrid = (Grid)target;
				return;
			case 5:
				this.mElementsStackPanel = (StackPanel)target;
				return;
			case 6:
				this.mMoreButton = (SidebarElement)target;
				return;
			case 7:
				this.mChangeTransparencyPopup = (CustomPopUp)target;
				return;
			case 8:
				this.mMaskBorder2 = (Border)target;
				return;
			case 9:
				this.mTranslucentControlsSliderButton = (CustomPictureBox)target;
				this.mTranslucentControlsSliderButton.PreviewMouseLeftButtonUp += this.mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp;
				return;
			case 10:
				this.transSlider = (Slider)target;
				this.transSlider.ValueChanged += this.TransparencySlider_ValueChanged;
				return;
			case 11:
				this.mVolumeSliderPopup = (CustomPopUp)target;
				return;
			case 12:
				this.mMaskBorder3 = (Border)target;
				return;
			case 13:
				this.mVolumeMuteUnmuteImage = (CustomPictureBox)target;
				this.mVolumeMuteUnmuteImage.PreviewMouseLeftButtonUp += this.VolumeImage_PreviewMouseLeftButtonUp;
				return;
			case 14:
				this.mVolumeSlider = (Slider)target;
				this.mVolumeSlider.PreviewMouseLeftButtonUp += this.VolumeSlider_PreviewMouseLeftButtonUp;
				this.mVolumeSlider.ValueChanged += this.VolumeSlider_ValueChanged;
				return;
			case 15:
				this.mCurrentVolumeValue = (TextBlock)target;
				return;
			case 16:
				this.mMuteInstancesCheckboxImage = (CustomPictureBox)target;
				this.mMuteInstancesCheckboxImage.MouseLeftButtonUp += this.MuteInstancesCheckboxImage_MouseLeftButtonUp;
				return;
			case 17:
				this.mMuteAllInstancesTextBlock = (TextBlock)target;
				this.mMuteAllInstancesTextBlock.MouseLeftButtonUp += this.MuteInstancesCheckboxImage_MouseLeftButtonUp;
				return;
			case 18:
				this.mOverlayTooltip = (CustomPopUp)target;
				return;
			case 19:
				this.mMaskBorder4 = (Border)target;
				return;
			case 20:
				((CustomPictureBox)target).MouseLeftButtonUp += this.OverlayTooltipCPB_MouseLeftButtonUp;
				return;
			case 21:
				this.mOverlayPopUpTitle = (TextBlock)target;
				return;
			case 22:
				this.mOverlayPopUpMessage = (TextBlock)target;
				return;
			case 23:
				this.mOverlayDoNotShowCheckboxImage = (CustomPictureBox)target;
				this.mOverlayDoNotShowCheckboxImage.MouseLeftButtonUp += this.OverlayDoNotShowCheckbox_MouseLeftButtonUp;
				return;
			case 24:
				this.mOverlayDontShowPopUp = (TextBlock)target;
				this.mOverlayDontShowPopUp.MouseLeftButtonUp += this.OverlayDoNotShowCheckbox_MouseLeftButtonUp;
				return;
			case 25:
				this.mMacroButtonPopup = (CustomPopUp)target;
				return;
			case 26:
				this.mMaskBorder5 = (Border)target;
				return;
			case 27:
				this.mMacroBookmarkPopup = (MacroBookmarksPopup)target;
				return;
			case 28:
				this.mCustomiseSectionTag = (Grid)target;
				return;
			case 29:
				this.mCustomiseSectionBorderLine = (Separator)target;
				return;
			case 30:
				((Grid)target).PreviewMouseLeftButtonUp += this.OpenMacroGridPreviewMouseLeftButtonUp;
				((Grid)target).MouseEnter += this.OpenMacroGridMouseEnter;
				((Grid)target).MouseLeave += this.OpenMacroGridMouseLeave;
				return;
			case 31:
				this.mOpenMacroTextbox = (TextBlock)target;
				return;
			case 32:
				this.mGameControlButtonPopup = (CustomPopUp)target;
				return;
			case 33:
				this.mMaskBorder6 = (Border)target;
				return;
			case 34:
				this.mBookmarkedSchemesStackPanel = (StackPanel)target;
				return;
			case 35:
				((Grid)target).PreviewMouseLeftButtonUp += this.OpenGameControlPreviewMouseLeftButtonUp;
				((Grid)target).MouseEnter += this.OpenGameControlMouseEnter;
				((Grid)target).MouseLeave += this.OpenGameControlMouseLeave;
				return;
			case 36:
				this.mOpenGameControlTextbox = (TextBlock)target;
				return;
			case 37:
				this.mRecordScreenPopup = (CustomPopUp)target;
				return;
			case 38:
				this.mMaskBorder7 = (Border)target;
				return;
			case 39:
				this.mRecordScreenClose = (CustomPictureBox)target;
				this.mRecordScreenClose.IsVisibleChanged += this.RecordScreenClose_IsVisibleChanged;
				this.mRecordScreenClose.MouseLeftButtonUp += this.RecordScreenPopupClose_MouseLeftButtonUp;
				return;
			case 40:
				this.RecordScreenPopupHeader = (TextBlock)target;
				return;
			case 41:
				this.RecordScreenPopupBody = (TextBlock)target;
				return;
			case 42:
				this.RecordScreenPopupHyperlink = (TextBlock)target;
				return;
			case 43:
				((Hyperlink)target).Click += this.RecordScreenPopupHyperlink_Click;
				return;
			case 44:
				this.mRecorderClickLink = (TextBlock)target;
				return;
			case 45:
				this.mScreenshotPopup = (CustomPopUp)target;
				return;
			case 46:
				this.mMaskBorder8 = (Border)target;
				return;
			case 47:
				this.mScreenshotClose = (CustomPictureBox)target;
				this.mScreenshotClose.MouseLeftButtonUp += this.ScreenshotPopupClose_MouseLeftButtonUp;
				return;
			case 48:
				this.ScreenshotPopupHeader = (TextBlock)target;
				return;
			case 49:
				this.ScreenshotPopupHyperlink = (TextBlock)target;
				return;
			case 50:
				((Hyperlink)target).Click += this.ScreenshotPopupHyperlink_Click;
				return;
			case 51:
				this.mScreenshotClickLink = (TextBlock)target;
				return;
			case 52:
				this.mGameControlsBlurbPopup = (CustomPopUp)target;
				return;
			case 53:
				this.mMaskBorder10 = (Border)target;
				return;
			case 54:
				this.ContentGrid = (Grid)target;
				return;
			case 55:
				this.headerTextBlock = (TextBlock)target;
				return;
			case 56:
				this.bodyTextBlock = (TextBlock)target;
				return;
			case 57:
				this.OkayButton = (CustomButton)target;
				this.OkayButton.Click += this.OnBoardingPopupNext_Click;
				return;
			case 58:
				this.RightArrow = (System.Windows.Shapes.Path)target;
				return;
			case 59:
				this.mMoreElements = (CustomPopUp)target;
				return;
			case 60:
				this.mPopupGrid = (Grid)target;
				return;
			case 61:
				this.mMaskBorder = (Border)target;
				return;
			case 62:
				this.mSidebarPopup = (SidebarPopup)target;
				return;
			case 63:
				this.mBottomGrid = (Grid)target;
				return;
			case 64:
				this.mStaticButtonsStackPanel = (StackPanel)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000424 RID: 1060
		private Dictionary<SidebarElement, EventHandler> mDictActions = new Dictionary<SidebarElement, EventHandler>();

		// Token: 0x04000425 RID: 1061
		internal List<SidebarElement> mListSidebarElements = new List<SidebarElement>();

		// Token: 0x04000426 RID: 1062
		private int mTotalVisibleElements;

		// Token: 0x04000427 RID: 1063
		private double mSidebarElementApproxHeight;

		// Token: 0x04000428 RID: 1064
		internal bool mIsUIInPortraitModeBeforeChange;

		// Token: 0x04000429 RID: 1065
		internal bool mIsOverlayTooltipClosed;

		// Token: 0x0400042A RID: 1066
		private bool mIsPendingShowOverlayTooltip;

		// Token: 0x0400042B RID: 1067
		internal double mLastSliderValue;

		// Token: 0x0400042C RID: 1068
		private bool mIsLoadedOnce;

		// Token: 0x0400042D RID: 1069
		private bool mIsInFullscreenMode;

		// Token: 0x0400042E RID: 1070
		private DispatcherTimer mMacroBookmarkTimer;

		// Token: 0x0400042F RID: 1071
		private DispatcherTimer mGameControlBookmarkTimer;

		// Token: 0x04000430 RID: 1072
		private DispatcherTimer mChangeTransparencyPopupTimer;

		// Token: 0x04000431 RID: 1073
		internal DispatcherTimer mVolumeSliderPopupTimer;

		// Token: 0x04000432 RID: 1074
		private DispatcherTimer mSidebarPopupTimer;

		// Token: 0x04000433 RID: 1075
		private string currentScreenshotSavedPath;

		// Token: 0x04000434 RID: 1076
		private readonly object mSyncRoot = new object();

		// Token: 0x04000435 RID: 1077
		private MainWindow mMainWindow;

		// Token: 0x04000436 RID: 1078
		private bool mIsOneSidebarElementLoadedBinded;

		// Token: 0x04000437 RID: 1079
		internal List<CustomPopUp> mListPopups;

		// Token: 0x04000438 RID: 1080
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Sidebar mSidebar;

		// Token: 0x04000439 RID: 1081
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mBorder;

		// Token: 0x0400043A RID: 1082
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mGrid;

		// Token: 0x0400043B RID: 1083
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mTopGrid;

		// Token: 0x0400043C RID: 1084
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mElementsStackPanel;

		// Token: 0x0400043D RID: 1085
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal SidebarElement mMoreButton;

		// Token: 0x0400043E RID: 1086
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mChangeTransparencyPopup;

		// Token: 0x0400043F RID: 1087
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder2;

		// Token: 0x04000440 RID: 1088
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mTranslucentControlsSliderButton;

		// Token: 0x04000441 RID: 1089
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Slider transSlider;

		// Token: 0x04000442 RID: 1090
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mVolumeSliderPopup;

		// Token: 0x04000443 RID: 1091
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder3;

		// Token: 0x04000444 RID: 1092
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mVolumeMuteUnmuteImage;

		// Token: 0x04000445 RID: 1093
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Slider mVolumeSlider;

		// Token: 0x04000446 RID: 1094
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mCurrentVolumeValue;

		// Token: 0x04000447 RID: 1095
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mMuteInstancesCheckboxImage;

		// Token: 0x04000448 RID: 1096
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mMuteAllInstancesTextBlock;

		// Token: 0x04000449 RID: 1097
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mOverlayTooltip;

		// Token: 0x0400044A RID: 1098
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder4;

		// Token: 0x0400044B RID: 1099
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mOverlayPopUpTitle;

		// Token: 0x0400044C RID: 1100
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mOverlayPopUpMessage;

		// Token: 0x0400044D RID: 1101
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mOverlayDoNotShowCheckboxImage;

		// Token: 0x0400044E RID: 1102
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mOverlayDontShowPopUp;

		// Token: 0x0400044F RID: 1103
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mMacroButtonPopup;

		// Token: 0x04000450 RID: 1104
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder5;

		// Token: 0x04000451 RID: 1105
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal MacroBookmarksPopup mMacroBookmarkPopup;

		// Token: 0x04000452 RID: 1106
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mCustomiseSectionTag;

		// Token: 0x04000453 RID: 1107
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Separator mCustomiseSectionBorderLine;

		// Token: 0x04000454 RID: 1108
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mOpenMacroTextbox;

		// Token: 0x04000455 RID: 1109
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mGameControlButtonPopup;

		// Token: 0x04000456 RID: 1110
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder6;

		// Token: 0x04000457 RID: 1111
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mBookmarkedSchemesStackPanel;

		// Token: 0x04000458 RID: 1112
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mOpenGameControlTextbox;

		// Token: 0x04000459 RID: 1113
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mRecordScreenPopup;

		// Token: 0x0400045A RID: 1114
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder7;

		// Token: 0x0400045B RID: 1115
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mRecordScreenClose;

		// Token: 0x0400045C RID: 1116
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock RecordScreenPopupHeader;

		// Token: 0x0400045D RID: 1117
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock RecordScreenPopupBody;

		// Token: 0x0400045E RID: 1118
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock RecordScreenPopupHyperlink;

		// Token: 0x0400045F RID: 1119
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mRecorderClickLink;

		// Token: 0x04000460 RID: 1120
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mScreenshotPopup;

		// Token: 0x04000461 RID: 1121
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder8;

		// Token: 0x04000462 RID: 1122
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mScreenshotClose;

		// Token: 0x04000463 RID: 1123
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock ScreenshotPopupHeader;

		// Token: 0x04000464 RID: 1124
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock ScreenshotPopupHyperlink;

		// Token: 0x04000465 RID: 1125
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mScreenshotClickLink;

		// Token: 0x04000466 RID: 1126
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mGameControlsBlurbPopup;

		// Token: 0x04000467 RID: 1127
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder10;

		// Token: 0x04000468 RID: 1128
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid ContentGrid;

		// Token: 0x04000469 RID: 1129
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock headerTextBlock;

		// Token: 0x0400046A RID: 1130
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock bodyTextBlock;

		// Token: 0x0400046B RID: 1131
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton OkayButton;

		// Token: 0x0400046C RID: 1132
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal System.Windows.Shapes.Path RightArrow;

		// Token: 0x0400046D RID: 1133
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mMoreElements;

		// Token: 0x0400046E RID: 1134
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mPopupGrid;

		// Token: 0x0400046F RID: 1135
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder;

		// Token: 0x04000470 RID: 1136
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal SidebarPopup mSidebarPopup;

		// Token: 0x04000471 RID: 1137
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mBottomGrid;

		// Token: 0x04000472 RID: 1138
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mStaticButtonsStackPanel;

		// Token: 0x04000473 RID: 1139
		private bool _contentLoaded;
	}
}
