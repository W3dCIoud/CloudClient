﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000232 RID: 562
	public struct ZipFileEntry : IEquatable<ZipFileEntry>
	{
		// Token: 0x170002B1 RID: 689
		// (get) Token: 0x060013FA RID: 5114 RVA: 0x0000DB20 File Offset: 0x0000BD20
		// (set) Token: 0x060013FB RID: 5115 RVA: 0x0000DB28 File Offset: 0x0000BD28
		public Compression Method { readonly get; set; }

		// Token: 0x170002B2 RID: 690
		// (get) Token: 0x060013FC RID: 5116 RVA: 0x0000DB31 File Offset: 0x0000BD31
		// (set) Token: 0x060013FD RID: 5117 RVA: 0x0000DB39 File Offset: 0x0000BD39
		public string FilenameInZip { readonly get; set; }

		// Token: 0x170002B3 RID: 691
		// (get) Token: 0x060013FE RID: 5118 RVA: 0x0000DB42 File Offset: 0x0000BD42
		// (set) Token: 0x060013FF RID: 5119 RVA: 0x0000DB4A File Offset: 0x0000BD4A
		public uint FileSize { readonly get; set; }

		// Token: 0x170002B4 RID: 692
		// (get) Token: 0x06001400 RID: 5120 RVA: 0x0000DB53 File Offset: 0x0000BD53
		// (set) Token: 0x06001401 RID: 5121 RVA: 0x0000DB5B File Offset: 0x0000BD5B
		public uint CompressedSize { readonly get; set; }

		// Token: 0x170002B5 RID: 693
		// (get) Token: 0x06001402 RID: 5122 RVA: 0x0000DB64 File Offset: 0x0000BD64
		// (set) Token: 0x06001403 RID: 5123 RVA: 0x0000DB6C File Offset: 0x0000BD6C
		public uint HeaderOffset { readonly get; set; }

		// Token: 0x170002B6 RID: 694
		// (get) Token: 0x06001404 RID: 5124 RVA: 0x0000DB75 File Offset: 0x0000BD75
		// (set) Token: 0x06001405 RID: 5125 RVA: 0x0000DB7D File Offset: 0x0000BD7D
		public uint FileOffset { readonly get; set; }

		// Token: 0x170002B7 RID: 695
		// (get) Token: 0x06001406 RID: 5126 RVA: 0x0000DB86 File Offset: 0x0000BD86
		// (set) Token: 0x06001407 RID: 5127 RVA: 0x0000DB8E File Offset: 0x0000BD8E
		public uint HeaderSize { readonly get; set; }

		// Token: 0x170002B8 RID: 696
		// (get) Token: 0x06001408 RID: 5128 RVA: 0x0000DB97 File Offset: 0x0000BD97
		// (set) Token: 0x06001409 RID: 5129 RVA: 0x0000DB9F File Offset: 0x0000BD9F
		public uint Crc32 { readonly get; set; }

		// Token: 0x170002B9 RID: 697
		// (get) Token: 0x0600140A RID: 5130 RVA: 0x0000DBA8 File Offset: 0x0000BDA8
		// (set) Token: 0x0600140B RID: 5131 RVA: 0x0000DBB0 File Offset: 0x0000BDB0
		public DateTime ModifyTime { readonly get; set; }

		// Token: 0x170002BA RID: 698
		// (get) Token: 0x0600140C RID: 5132 RVA: 0x0000DBB9 File Offset: 0x0000BDB9
		// (set) Token: 0x0600140D RID: 5133 RVA: 0x0000DBC1 File Offset: 0x0000BDC1
		public string Comment { readonly get; set; }

		// Token: 0x170002BB RID: 699
		// (get) Token: 0x0600140E RID: 5134 RVA: 0x0000DBCA File Offset: 0x0000BDCA
		// (set) Token: 0x0600140F RID: 5135 RVA: 0x0000DBD2 File Offset: 0x0000BDD2
		public bool EncodeUTF8 { readonly get; set; }

		// Token: 0x06001410 RID: 5136 RVA: 0x0007971C File Offset: 0x0007791C
		public override bool Equals(object obj)
		{
			if (obj is ZipFileEntry)
			{
				ZipFileEntry other = (ZipFileEntry)obj;
				return this.Equals(other);
			}
			return false;
		}

		// Token: 0x06001411 RID: 5137 RVA: 0x00079744 File Offset: 0x00077944
		public bool Equals(ZipFileEntry other)
		{
			return this.Method == other.Method && this.FilenameInZip == other.FilenameInZip && this.FileSize == other.FileSize && this.CompressedSize == other.CompressedSize && this.HeaderOffset == other.HeaderOffset && this.FileOffset == other.FileOffset && this.HeaderSize == other.HeaderSize && this.Crc32 == other.Crc32 && this.ModifyTime == other.ModifyTime && this.Comment == other.Comment && this.EncodeUTF8 == other.EncodeUTF8;
		}

		// Token: 0x06001412 RID: 5138 RVA: 0x0000DBDB File Offset: 0x0000BDDB
		public override string ToString()
		{
			return this.FilenameInZip;
		}

		// Token: 0x06001413 RID: 5139 RVA: 0x0000DBE3 File Offset: 0x0000BDE3
		public static bool operator ==(ZipFileEntry left, ZipFileEntry right)
		{
			return left.Equals(right);
		}

		// Token: 0x06001414 RID: 5140 RVA: 0x0000DBED File Offset: 0x0000BDED
		public static bool operator !=(ZipFileEntry left, ZipFileEntry right)
		{
			return !(left == right);
		}

		// Token: 0x06001415 RID: 5141 RVA: 0x00079810 File Offset: 0x00077A10
		public override int GetHashCode()
		{
			return this.Method.GetHashCode() ^ this.FilenameInZip.GetHashCode() ^ this.FileSize.GetHashCode() ^ this.CompressedSize.GetHashCode() ^ this.HeaderOffset.GetHashCode() ^ this.FileOffset.GetHashCode() ^ this.HeaderSize.GetHashCode() ^ this.Crc32.GetHashCode() ^ this.ModifyTime.GetHashCode() ^ this.Comment.GetHashCode() ^ this.EncodeUTF8.GetHashCode();
		}
	}
}
