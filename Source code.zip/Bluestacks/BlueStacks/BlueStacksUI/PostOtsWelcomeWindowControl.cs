﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000E3 RID: 227
	public class PostOtsWelcomeWindowControl : UserControl, IDisposable, IComponentConnector
	{
		// Token: 0x06000930 RID: 2352 RVA: 0x00007DBE File Offset: 0x00005FBE
		public PostOtsWelcomeWindowControl(MainWindow ParentWindow)
		{
			this.InitializeComponent();
			this.ParentWindow = ParentWindow;
		}

		// Token: 0x06000931 RID: 2353 RVA: 0x00036234 File Offset: 0x00034434
		private void PostOtsWelcome_Loaded(object sender, RoutedEventArgs e)
		{
			Logger.Info("PostOtsWelcome window loaded");
			this.loginSyncTimer = new Timer(10000.0);
			this.loginSyncTimer.Elapsed += this.OnLoginSyncTimeout;
			this.loginSyncTimer.AutoReset = false;
			if (!string.IsNullOrEmpty(RegistryManager.Instance.Token))
			{
				this.ChangeBasedonTokenReceived("true");
				return;
			}
			this.StartingTimer();
		}

		// Token: 0x06000932 RID: 2354 RVA: 0x000362A8 File Offset: 0x000344A8
		public void ChangeBasedonTokenReceived(string status)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					Logger.Info("In ChangeBasedonTokenReceived");
					this.mLoadingImage.Visibility = Visibility.Collapsed;
					if (status.Equals("true", StringComparison.InvariantCultureIgnoreCase))
					{
						this.mPostOtsImage.ImageName = "success_ots_icon";
						this.mPostOtsWarning.Visibility = Visibility.Collapsed;
						this.mCloseButton.Visibility = Visibility.Collapsed;
						BlueStacksUIBinding.Bind(this.mPostOtsLabel, "STRING_POST_OTS_SUCCESS_MESSAGE");
						BlueStacksUIBinding.Bind(this.mPostOtsButton, "STRING_POST_OTS_SUCCESS_BUTTON_MESSAGE");
						this.mSuccess = new bool?(true);
					}
					else
					{
						this.mPostOtsImage.ImageName = "failure_ots_icon";
						this.mPostOtsWarning.Visibility = Visibility.Visible;
						this.mCloseButton.Visibility = Visibility.Visible;
						BlueStacksUIBinding.Bind(this.mPostOtsLabel, "STRING_POST_OTS_FAILED_MESSAGE");
						BlueStacksUIBinding.Bind(this.mPostOtsButton, "STRING_POST_OTS_FAILED_BUTTON_MESSAGE");
						this.mSuccess = new bool?(false);
					}
					if (this.loginSyncTimer != null)
					{
						this.loginSyncTimer.Stop();
					}
					this.mPostOtsButton.IsEnabled = true;
				}
				catch (Exception ex)
				{
					Logger.Error(string.Concat(new string[]
					{
						" Exception in ChangeBasedOnTokenReceived Status: ",
						status,
						Environment.NewLine,
						"Error: ",
						ex.ToString()
					}));
				}
			}), new object[0]);
		}

		// Token: 0x06000933 RID: 2355 RVA: 0x00007DD3 File Offset: 0x00005FD3
		private void StartingTimer()
		{
			Logger.Info("Starting Timer");
			this.loginSyncTimer.Stop();
			this.loginSyncTimer.Start();
			this.loginSyncTimer.Enabled = true;
		}

		// Token: 0x06000934 RID: 2356 RVA: 0x000362E8 File Offset: 0x000344E8
		private void OnLoginSyncTimeout(object source, ElapsedEventArgs e)
		{
			try
			{
				Logger.Error("Login Sync timed out.");
				if (this.mSuccess == null)
				{
					this.ChangeBasedonTokenReceived("false");
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in login sync timer timeout " + ex.ToString());
			}
		}

		// Token: 0x06000935 RID: 2357 RVA: 0x00036344 File Offset: 0x00034544
		private void mPostOtsButton_Click(object sender, RoutedEventArgs e)
		{
			Logger.Info("mPostOtsButton clicked");
			if (this.mSuccess != null)
			{
				if (this.mSuccess.Value)
				{
					this.loginSyncTimer.Dispose();
					BlueStacksUIUtils.CloseContainerWindow(this);
					return;
				}
				base.Dispatcher.Invoke(new Action(delegate()
				{
					this.mPostOtsImage.ImageName = "syncing_ots_icon";
					this.mLoadingImage.Visibility = Visibility.Visible;
					this.mPostOtsWarning.Visibility = Visibility.Collapsed;
					this.mCloseButton.Visibility = Visibility.Collapsed;
					BlueStacksUIBinding.Bind(this.mPostOtsLabel, "STRING_POST_OTS_SYNCING_MESSAGE");
					BlueStacksUIBinding.Bind(this.mPostOtsButton, "STRING_POST_OTS_SYNCING_BUTTON_MESSAGE");
					this.mPostOtsButton.IsEnabled = false;
				}), new object[0]);
				this.SendRetryBluestacksLoginRequest(this.ParentWindow.mVmName);
			}
		}

		// Token: 0x06000936 RID: 2358 RVA: 0x000363B8 File Offset: 0x000345B8
		private void CloseButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			try
			{
				Logger.Info("Clicked postotswelcome window close button");
				this.ParentWindow.CloseWindow();
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in closing bluestacks from postotswelcome window, " + ex.ToString());
			}
		}

		// Token: 0x06000937 RID: 2359 RVA: 0x00036404 File Offset: 0x00034604
		private void SendRetryBluestacksLoginRequest(string vmName)
		{
			try
			{
				Logger.Info("Sending retry call for token to android, since token is not received successfully");
				this.mSuccess = null;
				this.StartingTimer();
				BlueStacksUIUtils.SendBluestacksLoginRequest(vmName);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in SendRetryBluestacksLoginRequest: " + ex.ToString());
			}
		}

		// Token: 0x06000938 RID: 2360 RVA: 0x00007E01 File Offset: 0x00006001
		protected virtual void Dispose(bool disposing)
		{
			if (!this.disposedValue)
			{
				if (this.loginSyncTimer != null)
				{
					this.loginSyncTimer.Elapsed -= this.OnLoginSyncTimeout;
					this.loginSyncTimer.Dispose();
				}
				this.disposedValue = true;
			}
		}

		// Token: 0x06000939 RID: 2361 RVA: 0x00036460 File Offset: 0x00034660
		~PostOtsWelcomeWindowControl()
		{
			this.Dispose(false);
		}

		// Token: 0x0600093A RID: 2362 RVA: 0x00007E3E File Offset: 0x0000603E
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x0600093B RID: 2363 RVA: 0x00036490 File Offset: 0x00034690
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/postotswelcomewindowcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600093C RID: 2364 RVA: 0x000364C0 File Offset: 0x000346C0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((PostOtsWelcomeWindowControl)target).Loaded += this.PostOtsWelcome_Loaded;
				return;
			case 2:
				this.mCloseButton = (CustomPictureBox)target;
				this.mCloseButton.MouseLeftButtonUp += this.CloseButton_MouseLeftButtonUp;
				return;
			case 3:
				this.mPostOtsImage = (CustomPictureBox)target;
				return;
			case 4:
				this.mLoadingImage = (CustomPictureBox)target;
				return;
			case 5:
				this.mPostOtsLabel = (Label)target;
				return;
			case 6:
				this.mPostOtsWarning = (TextBlock)target;
				return;
			case 7:
				this.mPostOtsButton = (CustomButton)target;
				this.mPostOtsButton.Click += this.mPostOtsButton_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040005B6 RID: 1462
		private bool? mSuccess;

		// Token: 0x040005B7 RID: 1463
		private Timer loginSyncTimer;

		// Token: 0x040005B8 RID: 1464
		private MainWindow ParentWindow;

		// Token: 0x040005B9 RID: 1465
		private bool disposedValue;

		// Token: 0x040005BA RID: 1466
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCloseButton;

		// Token: 0x040005BB RID: 1467
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mPostOtsImage;

		// Token: 0x040005BC RID: 1468
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mLoadingImage;

		// Token: 0x040005BD RID: 1469
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Label mPostOtsLabel;

		// Token: 0x040005BE RID: 1470
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mPostOtsWarning;

		// Token: 0x040005BF RID: 1471
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mPostOtsButton;

		// Token: 0x040005C0 RID: 1472
		private bool _contentLoaded;
	}
}
