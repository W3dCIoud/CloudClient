﻿using System;
using System.Collections.Generic;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000070 RID: 112
	public class GuidanceCloudInfo
	{
		// Token: 0x17000172 RID: 370
		// (get) Token: 0x06000484 RID: 1156 RVA: 0x000050FE File Offset: 0x000032FE
		public Dictionary<string, CustomThumbnail> CustomThumbnails { get; } = new Dictionary<string, CustomThumbnail>();

		// Token: 0x17000173 RID: 371
		// (get) Token: 0x06000485 RID: 1157 RVA: 0x00005106 File Offset: 0x00003306
		public Dictionary<GuidanceVideoType, VideoThumbnailInfo> DefaultThumbnails { get; } = new Dictionary<GuidanceVideoType, VideoThumbnailInfo>();

		// Token: 0x17000174 RID: 372
		// (get) Token: 0x06000486 RID: 1158 RVA: 0x0000510E File Offset: 0x0000330E
		public Dictionary<string, HelpArticle> HelpArticles { get; } = new Dictionary<string, HelpArticle>();
	}
}
