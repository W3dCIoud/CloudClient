﻿using System;
using System.Collections.ObjectModel;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200004C RID: 76
	[Serializable]
	public class GuidanceViewModel : ViewModelBase
	{
		// Token: 0x17000140 RID: 320
		// (get) Token: 0x06000390 RID: 912 RVA: 0x00004725 File Offset: 0x00002925
		// (set) Token: 0x06000391 RID: 913 RVA: 0x0000472D File Offset: 0x0000292D
		public ObservableCollection<string> GuidanceTexts
		{
			get
			{
				return this.mGuidanceTexts;
			}
			set
			{
				base.SetProperty<ObservableCollection<string>>(ref this.mGuidanceTexts, value, null);
			}
		}

		// Token: 0x17000141 RID: 321
		// (get) Token: 0x06000392 RID: 914 RVA: 0x0000473E File Offset: 0x0000293E
		// (set) Token: 0x06000393 RID: 915 RVA: 0x00004746 File Offset: 0x00002946
		public ObservableCollection<string> GuidanceKeys
		{
			get
			{
				return this.mGuidanceKeys;
			}
			set
			{
				base.SetProperty<ObservableCollection<string>>(ref this.mGuidanceKeys, value, null);
			}
		}

		// Token: 0x040001E2 RID: 482
		private ObservableCollection<string> mGuidanceTexts = new ObservableCollection<string>();

		// Token: 0x040001E3 RID: 483
		private ObservableCollection<string> mGuidanceKeys = new ObservableCollection<string>();
	}
}
