﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000055 RID: 85
	public class MOBASkillSettingsPopup : CustomPopUp, IComponentConnector
	{
		// Token: 0x060003FA RID: 1018 RVA: 0x00004BCB File Offset: 0x00002DCB
		public MOBASkillSettingsPopup(CanvasElement canvasElement)
		{
			this.mCanvasElement = canvasElement;
			this.InitializeComponent();
			CanvasElement canvasElement2 = this.mCanvasElement;
			base.PlacementTarget = ((canvasElement2 != null) ? canvasElement2.mSkillImage : null);
		}

		// Token: 0x060003FB RID: 1019 RVA: 0x0001ABD8 File Offset: 0x00018DD8
		private void MobaSkillsRadioButton_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			this.mCanvasElement.MOBASkillSettingsMoreInfoPopup.IsOpen = false;
			this.mCanvasElement.MOBAOtherSettingsMoreInfoPopup.IsOpen = false;
			CustomRadioButton customRadioButton = sender as CustomRadioButton;
			customRadioButton.IsChecked = new bool?(true);
			KeymapCanvasWindow.sIsDirty = true;
			string name = customRadioButton.Name;
			string skillName;
			if (name != null)
			{
				if (name == "mManualSkill")
				{
					this.mCanvasElement.AssignMobaSkill(false, false);
					skillName = "ManualSkill";
					goto IL_C4;
				}
				if (name == "mAutoSkill")
				{
					this.mCanvasElement.AssignMobaSkill(true, false);
					skillName = "AutoSkill";
					goto IL_C4;
				}
				if (name == "mQuickSkill")
				{
					this.mCanvasElement.AssignMobaSkill(true, true);
					skillName = "QuickSkill";
					goto IL_C4;
				}
			}
			this.mCanvasElement.AssignMobaSkill(true, true);
			skillName = "QuickSkill";
			IL_C4:
			this.mCanvasElement.SendMOBAStats("moba_skill_changed", skillName);
		}

		// Token: 0x060003FC RID: 1020 RVA: 0x00004BF8 File Offset: 0x00002DF8
		private void MOBASkillSettingsPopup_Opened(object sender, EventArgs e)
		{
			this.mCanvasElement.mSkillImage.IsEnabled = false;
		}

		// Token: 0x060003FD RID: 1021 RVA: 0x00004C0B File Offset: 0x00002E0B
		private void MOBASkillSettingsPopup_Closed(object sender, EventArgs e)
		{
			this.mCanvasElement.mSkillImage.IsEnabled = true;
			this.mCanvasElement.MOBAOtherSettingsMoreInfoPopup.IsOpen = false;
			this.mCanvasElement.MOBASkillSettingsMoreInfoPopup.IsOpen = false;
		}

		// Token: 0x060003FE RID: 1022 RVA: 0x00004C40 File Offset: 0x00002E40
		private void HelpIcon_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mCanvasElement.MOBAOtherSettingsMoreInfoPopup.IsOpen = false;
			this.mCanvasElement.MOBASkillSettingsMoreInfoPopup.IsOpen = true;
			this.mCanvasElement.MOBASkillSettingsMoreInfoPopup.StaysOpen = true;
		}

		// Token: 0x060003FF RID: 1023 RVA: 0x00004C75 File Offset: 0x00002E75
		private void OtherSettingsHelpIcon_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mCanvasElement.MOBASkillSettingsMoreInfoPopup.IsOpen = false;
			this.mCanvasElement.MOBAOtherSettingsMoreInfoPopup.IsOpen = true;
			this.mCanvasElement.MOBAOtherSettingsMoreInfoPopup.StaysOpen = true;
		}

		// Token: 0x06000400 RID: 1024 RVA: 0x00004CAA File Offset: 0x00002EAA
		private void StopMovementCheckbox_Checked(object sender, RoutedEventArgs e)
		{
			this.SetStopMobaDpadValue(true);
			this.mCanvasElement.SendMOBAStats("stop_moba_dpad_checked", "");
		}

		// Token: 0x06000401 RID: 1025 RVA: 0x0001ACBC File Offset: 0x00018EBC
		private void SetStopMobaDpadValue(bool isChecked)
		{
			this.mCanvasElement.MOBASkillSettingsMoreInfoPopup.IsOpen = false;
			this.mCanvasElement.MOBAOtherSettingsMoreInfoPopup.IsOpen = false;
			KMManager.CheckAndCreateNewScheme();
			this.mStopMovementCheckbox.IsChecked = new bool?(isChecked);
			if (this.mCanvasElement.ListActionItem.First<IMAction>().Type == KeyActionType.MOBASkill)
			{
				((MOBASkill)this.mCanvasElement.ListActionItem.First<IMAction>()).StopMOBADpad = isChecked;
			}
			KeymapCanvasWindow.sIsDirty = true;
		}

		// Token: 0x06000402 RID: 1026 RVA: 0x00004CC8 File Offset: 0x00002EC8
		private void StopMovementCheckbox_Unchecked(object sender, RoutedEventArgs e)
		{
			this.SetStopMobaDpadValue(false);
			this.mCanvasElement.SendMOBAStats("stop_moba_dpad_unchecked", "");
		}

		// Token: 0x06000403 RID: 1027 RVA: 0x0001AD3C File Offset: 0x00018F3C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/mobaskillsettingspopup.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000404 RID: 1028 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000405 RID: 1029 RVA: 0x0001AD6C File Offset: 0x00018F6C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMOBASkillSettingsPopup = (MOBASkillSettingsPopup)target;
				return;
			case 2:
				this.mBorder = (Border)target;
				return;
			case 3:
				this.mMaskBorder3 = (Border)target;
				return;
			case 4:
				this.mHeaderGrid = (Grid)target;
				return;
			case 5:
				this.mHelpIcon = (CustomPictureBox)target;
				this.mHelpIcon.MouseEnter += this.HelpIcon_MouseEnter;
				return;
			case 6:
				this.mQuickSkill = (CustomRadioButton)target;
				this.mQuickSkill.PreviewMouseLeftButtonDown += this.MobaSkillsRadioButton_PreviewMouseLeftButtonDown;
				return;
			case 7:
				this.mAutoSkill = (CustomRadioButton)target;
				this.mAutoSkill.PreviewMouseLeftButtonDown += this.MobaSkillsRadioButton_PreviewMouseLeftButtonDown;
				return;
			case 8:
				this.mManualSkill = (CustomRadioButton)target;
				this.mManualSkill.PreviewMouseLeftButtonDown += this.MobaSkillsRadioButton_PreviewMouseLeftButtonDown;
				return;
			case 9:
				this.mOtherSettingsGrid = (Grid)target;
				return;
			case 10:
				this.mOtherSettingsHelpIcon = (CustomPictureBox)target;
				this.mOtherSettingsHelpIcon.MouseEnter += this.OtherSettingsHelpIcon_MouseEnter;
				return;
			case 11:
				this.mStopMovementCheckbox = (CustomCheckbox)target;
				this.mStopMovementCheckbox.Checked += this.StopMovementCheckbox_Checked;
				this.mStopMovementCheckbox.Unchecked += this.StopMovementCheckbox_Unchecked;
				return;
			case 12:
				this.DownArrow = (Path)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000225 RID: 549
		private CanvasElement mCanvasElement;

		// Token: 0x04000226 RID: 550
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal MOBASkillSettingsPopup mMOBASkillSettingsPopup;

		// Token: 0x04000227 RID: 551
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mBorder;

		// Token: 0x04000228 RID: 552
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder3;

		// Token: 0x04000229 RID: 553
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mHeaderGrid;

		// Token: 0x0400022A RID: 554
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mHelpIcon;

		// Token: 0x0400022B RID: 555
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mQuickSkill;

		// Token: 0x0400022C RID: 556
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mAutoSkill;

		// Token: 0x0400022D RID: 557
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mManualSkill;

		// Token: 0x0400022E RID: 558
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mOtherSettingsGrid;

		// Token: 0x0400022F RID: 559
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mOtherSettingsHelpIcon;

		// Token: 0x04000230 RID: 560
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mStopMovementCheckbox;

		// Token: 0x04000231 RID: 561
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Path DownArrow;

		// Token: 0x04000232 RID: 562
		private bool _contentLoaded;
	}
}
