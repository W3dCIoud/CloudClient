﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Shapes;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000056 RID: 86
	public class SkillIconToolTipPopup : CustomPopUp, IComponentConnector
	{
		// Token: 0x06000406 RID: 1030 RVA: 0x00004CE6 File Offset: 0x00002EE6
		public SkillIconToolTipPopup(CanvasElement canvasElement)
		{
			this.InitializeComponent();
			base.PlacementTarget = ((canvasElement != null) ? canvasElement.mSkillImage : null);
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x0001AEFC File Offset: 0x000190FC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/skillicontooltippopup.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000408 RID: 1032 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000409 RID: 1033 RVA: 0x0001AF2C File Offset: 0x0001912C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder1 = (Border)target;
				return;
			case 2:
				this.mSkillIconHeaderText = (TextBlock)target;
				return;
			case 3:
				this.mDownArrow = (Path)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000233 RID: 563
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder1;

		// Token: 0x04000234 RID: 564
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mSkillIconHeaderText;

		// Token: 0x04000235 RID: 565
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Path mDownArrow;

		// Token: 0x04000236 RID: 566
		private bool _contentLoaded;
	}
}
