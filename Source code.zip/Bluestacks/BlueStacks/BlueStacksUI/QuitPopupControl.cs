﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000E8 RID: 232
	public class QuitPopupControl : UserControl, IDimOverlayControl, IComponentConnector
	{
		// Token: 0x170001DA RID: 474
		// (get) Token: 0x0600096C RID: 2412 RVA: 0x00006230 File Offset: 0x00004430
		// (set) Token: 0x0600096D RID: 2413 RVA: 0x00005D29 File Offset: 0x00003F29
		bool IDimOverlayControl.IsCloseOnOverLayClick
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		// Token: 0x170001DB RID: 475
		// (get) Token: 0x0600096E RID: 2414 RVA: 0x00008027 File Offset: 0x00006227
		// (set) Token: 0x0600096F RID: 2415 RVA: 0x0000802F File Offset: 0x0000622F
		public bool ShowControlInSeparateWindow { get; set; } = true;

		// Token: 0x06000970 RID: 2416 RVA: 0x00008038 File Offset: 0x00006238
		bool IDimOverlayControl.Close()
		{
			this.Close();
			return true;
		}

		// Token: 0x06000971 RID: 2417 RVA: 0x0000624E File Offset: 0x0000444E
		bool IDimOverlayControl.Show()
		{
			base.Visibility = Visibility.Visible;
			return true;
		}

		// Token: 0x06000972 RID: 2418 RVA: 0x00008042 File Offset: 0x00006242
		public QuitPopupControl(MainWindow window)
		{
			this.ParentWindow = window;
			this.InitializeComponent();
		}

		// Token: 0x06000973 RID: 2419 RVA: 0x00008069 File Offset: 0x00006269
		private void Close_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.Close();
			ClientStats.SendLocalQuitPopupStatsAsync(this.CurrentPopupTag, "click_action_close");
		}

		// Token: 0x170001DC RID: 476
		// (get) Token: 0x06000974 RID: 2420 RVA: 0x00008082 File Offset: 0x00006282
		public TextBlock TitleTextBlock
		{
			get
			{
				return this.mTitleText;
			}
		}

		// Token: 0x170001DD RID: 477
		// (get) Token: 0x06000975 RID: 2421 RVA: 0x0000808A File Offset: 0x0000628A
		public CustomButton CloseBlueStacksButton
		{
			get
			{
				return this.mCloseBlueStacksButton;
			}
		}

		// Token: 0x170001DE RID: 478
		// (get) Token: 0x06000976 RID: 2422 RVA: 0x00008092 File Offset: 0x00006292
		public CustomButton ReturnBlueStacksButton
		{
			get
			{
				return this.mReturnBlueStacksButton;
			}
		}

		// Token: 0x170001DF RID: 479
		// (get) Token: 0x06000977 RID: 2423 RVA: 0x0000809A File Offset: 0x0000629A
		public CustomPictureBox CrossButtonPictureBox
		{
			get
			{
				return this.mCrossButtonPictureBox;
			}
		}

		// Token: 0x06000978 RID: 2424 RVA: 0x000080A2 File Offset: 0x000062A2
		private void CloseBlueStacksButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.Close();
			if (this.HasSuccessfulEventOccured)
			{
				ClientStats.SendLocalQuitPopupStatsAsync(this.CurrentPopupTag, "click_action_continue_bluestacks");
				return;
			}
			ClientStats.SendLocalQuitPopupStatsAsync(this.CurrentPopupTag, "popup_closed");
		}

		// Token: 0x170001E0 RID: 480
		// (get) Token: 0x06000979 RID: 2425 RVA: 0x000080D4 File Offset: 0x000062D4
		// (set) Token: 0x0600097A RID: 2426 RVA: 0x000080DC File Offset: 0x000062DC
		public bool HasSuccessfulEventOccured
		{
			get
			{
				return this.mHasSuccessfulEventOccured;
			}
			set
			{
				if (value)
				{
					this.mHasSuccessfulEventOccured = value;
					this.mTitleGrid.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#0BA200");
				}
			}
		}

		// Token: 0x170001E1 RID: 481
		// (get) Token: 0x0600097B RID: 2427 RVA: 0x00008107 File Offset: 0x00006307
		// (set) Token: 0x0600097C RID: 2428 RVA: 0x0000810F File Offset: 0x0000630F
		public string CurrentPopupTag { get; set; } = string.Empty;

		// Token: 0x0600097D RID: 2429 RVA: 0x00037164 File Offset: 0x00035364
		public void AddQuitActionItem(QuitActionItem item)
		{
			bool flag = this.mQuitElementStackPanel.Children.Count != 0;
			QuitActionElement quitActionElement = new QuitActionElement(this.ParentWindow, this)
			{
				Width = 210.0,
				ActionElement = item,
				ParentPopupTag = this.CurrentPopupTag
			};
			if (flag)
			{
				quitActionElement.Margin = new Thickness(32.0, 0.0, 0.0, 0.0);
			}
			this.mQuitElementStackPanel.Children.Add(quitActionElement);
		}

		// Token: 0x0600097E RID: 2430 RVA: 0x000371F8 File Offset: 0x000353F8
		internal bool Close()
		{
			try
			{
				BlueStacksUIUtils.CloseContainerWindow(this);
				this.ParentWindow.HideDimOverlay();
				base.Visibility = Visibility.Hidden;
				return true;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while trying to close quitpopup from dimoverlay " + ex.ToString());
			}
			return false;
		}

		// Token: 0x0600097F RID: 2431 RVA: 0x00008118 File Offset: 0x00006318
		private void ReturnBlueStacksButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.Close();
			ClientStats.SendLocalQuitPopupStatsAsync(this.CurrentPopupTag, "click_action_return_bluestacks");
		}

		// Token: 0x06000980 RID: 2432 RVA: 0x0003724C File Offset: 0x0003544C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/quitpopupcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000981 RID: 2433 RVA: 0x0003727C File Offset: 0x0003547C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mParentGrid = (Grid)target;
				return;
			case 2:
				this.mTitleGrid = (Grid)target;
				return;
			case 3:
				this.mCrossButtonPictureBox = (CustomPictureBox)target;
				this.mCrossButtonPictureBox.PreviewMouseLeftButtonUp += this.Close_PreviewMouseLeftButtonUp;
				return;
			case 4:
				this.mTitleText = (TextBlock)target;
				return;
			case 5:
				this.mOptionsGrid = (Grid)target;
				return;
			case 6:
				this.mQuitElementStackPanel = (StackPanel)target;
				return;
			case 7:
				this.mFooterGrid = (Grid)target;
				return;
			case 8:
				this.mReturnBlueStacksButton = (CustomButton)target;
				this.mReturnBlueStacksButton.PreviewMouseLeftButtonUp += this.ReturnBlueStacksButton_PreviewMouseLeftButtonUp;
				return;
			case 9:
				this.mCloseBlueStacksButton = (CustomButton)target;
				this.mCloseBlueStacksButton.PreviewMouseLeftButtonUp += this.CloseBlueStacksButton_PreviewMouseLeftButtonUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040005E1 RID: 1505
		private MainWindow ParentWindow;

		// Token: 0x040005E2 RID: 1506
		private bool mHasSuccessfulEventOccured;

		// Token: 0x040005E4 RID: 1508
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mParentGrid;

		// Token: 0x040005E5 RID: 1509
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mTitleGrid;

		// Token: 0x040005E6 RID: 1510
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCrossButtonPictureBox;

		// Token: 0x040005E7 RID: 1511
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mTitleText;

		// Token: 0x040005E8 RID: 1512
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mOptionsGrid;

		// Token: 0x040005E9 RID: 1513
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mQuitElementStackPanel;

		// Token: 0x040005EA RID: 1514
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mFooterGrid;

		// Token: 0x040005EB RID: 1515
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mReturnBlueStacksButton;

		// Token: 0x040005EC RID: 1516
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mCloseBlueStacksButton;

		// Token: 0x040005ED RID: 1517
		private bool _contentLoaded;
	}
}
