﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200022C RID: 556
	public class FrontendOTSControl : UserControl, IComponentConnector
	{
		// Token: 0x170002AC RID: 684
		// (get) Token: 0x060013C4 RID: 5060 RVA: 0x0000D8CB File Offset: 0x0000BACB
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x060013C5 RID: 5061 RVA: 0x0000D8EC File Offset: 0x0000BAEC
		public FrontendOTSControl()
		{
			this.InitializeComponent();
			this.OneTimeSetupCompletedEventHandle = (EventHandler<EventArgs>)Delegate.Combine(this.OneTimeSetupCompletedEventHandle, new EventHandler<EventArgs>(this.OneTimeSetup_Completed));
		}

		// Token: 0x060013C6 RID: 5062 RVA: 0x000782E8 File Offset: 0x000764E8
		private void UserControl_IsVisibleChanged(object _1, DependencyPropertyChangedEventArgs _2)
		{
			if (base.Visibility == Visibility.Visible)
			{
				BlueStacksUIBinding.Bind(this.mBaseControl.mTitleLabel, "STRING_GOOGLE_LOGIN_MESSAGE");
				this.mBaseControl.Init(this, this.ParentWindow.mFrontendGrid, true, true);
				this.mBaseControl.ShowContent();
				this.ParentWindow.mAppHandler.EventOnOneTimeSetupCompleted = this.OneTimeSetupCompletedEventHandle;
			}
		}

		// Token: 0x060013C7 RID: 5063 RVA: 0x0000D91C File Offset: 0x0000BB1C
		private void OneTimeSetup_Completed(object sender, EventArgs e)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mBaseControl.HideWindow();
			}), new object[0]);
		}

		// Token: 0x060013C8 RID: 5064 RVA: 0x0007834C File Offset: 0x0007654C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/frontendotscontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060013C9 RID: 5065 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060013CA RID: 5066 RVA: 0x0000D93C File Offset: 0x0000BB3C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				((FrontendOTSControl)target).IsVisibleChanged += this.UserControl_IsVisibleChanged;
				return;
			}
			if (connectionId != 2)
			{
				this._contentLoaded = true;
				return;
			}
			this.mBaseControl = (DimControlWithProgresBar)target;
		}

		// Token: 0x04000C74 RID: 3188
		private MainWindow mMainWindow;

		// Token: 0x04000C75 RID: 3189
		private EventHandler<EventArgs> OneTimeSetupCompletedEventHandle;

		// Token: 0x04000C76 RID: 3190
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal DimControlWithProgresBar mBaseControl;

		// Token: 0x04000C77 RID: 3191
		private bool _contentLoaded;
	}
}
