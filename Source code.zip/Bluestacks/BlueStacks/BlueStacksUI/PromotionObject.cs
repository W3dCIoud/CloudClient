﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000178 RID: 376
	public class PromotionObject
	{
		// Token: 0x1400000C RID: 12
		// (add) Token: 0x06000E48 RID: 3656 RVA: 0x0005FC6C File Offset: 0x0005DE6C
		// (remove) Token: 0x06000E49 RID: 3657 RVA: 0x0005FCA0 File Offset: 0x0005DEA0
		private static event EventHandler mBootPromotionHandler;

		// Token: 0x17000222 RID: 546
		// (get) Token: 0x06000E4A RID: 3658 RVA: 0x0000A827 File Offset: 0x00008A27
		// (set) Token: 0x06000E4B RID: 3659 RVA: 0x0000A82E File Offset: 0x00008A2E
		internal static EventHandler BootPromotionHandler
		{
			get
			{
				return PromotionObject.mBootPromotionHandler;
			}
			set
			{
				PromotionObject.mBootPromotionHandler = value;
			}
		}

		// Token: 0x06000E4C RID: 3660 RVA: 0x0005FCD4 File Offset: 0x0005DED4
		internal void SetDefaultMoreAppsOrder(bool overwrite = true)
		{
			if (this.MoreAppsDockOrder.Count == 0 || overwrite)
			{
				this.MoreAppsDockOrder.ClearAddRange(new SerializableDictionary<string, int>
				{
					{
						"com.android.chrome",
						2
					},
					{
						"com.android.camera2",
						2
					},
					{
						"com.bluestacks.settings",
						3
					},
					{
						"com.bluestacks.filemanager",
						4
					},
					{
						"instance_manager",
						5
					},
					{
						"help_center",
						6
					}
				});
			}
		}

		// Token: 0x06000E4D RID: 3661 RVA: 0x0000A836 File Offset: 0x00008A36
		internal void SetDefaultDockOrder(bool overwrite = true)
		{
			if (this.DockOrder.Count == 0 || overwrite)
			{
				this.DockOrder.ClearAddRange(new SerializableDictionary<string, int>
				{
					{
						"appcenter",
						1
					},
					{
						"pikaworld",
						2
					}
				});
			}
		}

		// Token: 0x06000E4E RID: 3662 RVA: 0x0000A872 File Offset: 0x00008A72
		internal void SetDefaultMyAppsOrder(bool overwrite = true)
		{
			if (this.MyAppsOrder.Count == 0 || overwrite)
			{
				this.MyAppsOrder.ClearAddRange(new SerializableDictionary<string, int>
				{
					{
						"com.android.vending",
						1
					}
				});
			}
		}

		// Token: 0x06000E4F RID: 3663 RVA: 0x0000A8A2 File Offset: 0x00008AA2
		internal void SetDefaultOrder(bool overwrite = true)
		{
			this.SetDefaultMyAppsOrder(overwrite);
			this.SetDefaultDockOrder(overwrite);
			this.SetDefaultMoreAppsOrder(overwrite);
		}

		// Token: 0x1400000D RID: 13
		// (add) Token: 0x06000E50 RID: 3664 RVA: 0x0005FD4C File Offset: 0x0005DF4C
		// (remove) Token: 0x06000E51 RID: 3665 RVA: 0x0005FD80 File Offset: 0x0005DF80
		private static event EventHandler mBackgroundPromotionHandler;

		// Token: 0x17000223 RID: 547
		// (get) Token: 0x06000E52 RID: 3666 RVA: 0x0000A8B9 File Offset: 0x00008AB9
		// (set) Token: 0x06000E53 RID: 3667 RVA: 0x0000A8C0 File Offset: 0x00008AC0
		internal static EventHandler BackgroundPromotionHandler
		{
			get
			{
				return PromotionObject.mBackgroundPromotionHandler;
			}
			set
			{
				PromotionObject.mBackgroundPromotionHandler = value;
				if (!PromotionObject.mIsPromotionLoading)
				{
					PromotionObject.mBackgroundPromotionHandler(PromotionObject.Instance, new EventArgs());
				}
			}
		}

		// Token: 0x1400000E RID: 14
		// (add) Token: 0x06000E54 RID: 3668 RVA: 0x0005FDB4 File Offset: 0x0005DFB4
		// (remove) Token: 0x06000E55 RID: 3669 RVA: 0x0005FDE8 File Offset: 0x0005DFE8
		private static event EventHandler mPromotionHandler;

		// Token: 0x17000224 RID: 548
		// (get) Token: 0x06000E56 RID: 3670 RVA: 0x0000A8E3 File Offset: 0x00008AE3
		// (set) Token: 0x06000E57 RID: 3671 RVA: 0x0000A8EA File Offset: 0x00008AEA
		internal static EventHandler PromotionHandler
		{
			get
			{
				return PromotionObject.mPromotionHandler;
			}
			set
			{
				PromotionObject.mPromotionHandler = value;
				if (!PromotionObject.mIsPromotionLoading)
				{
					PromotionObject.mPromotionHandler(PromotionObject.Instance, new EventArgs());
				}
			}
		}

		// Token: 0x1400000F RID: 15
		// (add) Token: 0x06000E58 RID: 3672 RVA: 0x0005FE1C File Offset: 0x0005E01C
		// (remove) Token: 0x06000E59 RID: 3673 RVA: 0x0005FE50 File Offset: 0x0005E050
		private static event EventHandler mAppSpecificRulesHandler;

		// Token: 0x17000225 RID: 549
		// (get) Token: 0x06000E5A RID: 3674 RVA: 0x0000A90D File Offset: 0x00008B0D
		// (set) Token: 0x06000E5B RID: 3675 RVA: 0x0000A914 File Offset: 0x00008B14
		internal static EventHandler AppSpecificRulesHandler
		{
			get
			{
				return PromotionObject.mAppSpecificRulesHandler;
			}
			set
			{
				PromotionObject.mAppSpecificRulesHandler = value;
				if (!PromotionObject.mIsPromotionLoading)
				{
					PromotionObject.mAppSpecificRulesHandler(PromotionObject.Instance, new EventArgs());
				}
			}
		}

		// Token: 0x14000010 RID: 16
		// (add) Token: 0x06000E5C RID: 3676 RVA: 0x0005FE84 File Offset: 0x0005E084
		// (remove) Token: 0x06000E5D RID: 3677 RVA: 0x0005FEB8 File Offset: 0x0005E0B8
		private static event Action<bool> mAppSuggestionHandler;

		// Token: 0x17000226 RID: 550
		// (get) Token: 0x06000E5E RID: 3678 RVA: 0x0000A937 File Offset: 0x00008B37
		// (set) Token: 0x06000E5F RID: 3679 RVA: 0x0000A93E File Offset: 0x00008B3E
		internal static Action<bool> AppSuggestionHandler
		{
			get
			{
				return PromotionObject.mAppSuggestionHandler;
			}
			set
			{
				PromotionObject.mAppSuggestionHandler = value;
			}
		}

		// Token: 0x14000011 RID: 17
		// (add) Token: 0x06000E60 RID: 3680 RVA: 0x0005FEEC File Offset: 0x0005E0EC
		// (remove) Token: 0x06000E61 RID: 3681 RVA: 0x0005FF20 File Offset: 0x0005E120
		private static event Action<bool> mAppRecommendationHandler;

		// Token: 0x17000227 RID: 551
		// (get) Token: 0x06000E62 RID: 3682 RVA: 0x0000A946 File Offset: 0x00008B46
		// (set) Token: 0x06000E63 RID: 3683 RVA: 0x0000A94D File Offset: 0x00008B4D
		internal static Action<bool> AppRecommendationHandler
		{
			get
			{
				return PromotionObject.mAppRecommendationHandler;
			}
			set
			{
				PromotionObject.mAppRecommendationHandler = value;
			}
		}

		// Token: 0x14000012 RID: 18
		// (add) Token: 0x06000E64 RID: 3684 RVA: 0x0005FF54 File Offset: 0x0005E154
		// (remove) Token: 0x06000E65 RID: 3685 RVA: 0x0005FF88 File Offset: 0x0005E188
		private static event Action mQuestHandler;

		// Token: 0x17000228 RID: 552
		// (get) Token: 0x06000E66 RID: 3686 RVA: 0x0000A955 File Offset: 0x00008B55
		// (set) Token: 0x06000E67 RID: 3687 RVA: 0x0000A95C File Offset: 0x00008B5C
		internal static Action QuestHandler
		{
			get
			{
				return PromotionObject.mQuestHandler;
			}
			set
			{
				PromotionObject.mQuestHandler = value;
			}
		}

		// Token: 0x17000229 RID: 553
		// (get) Token: 0x06000E68 RID: 3688 RVA: 0x0000A964 File Offset: 0x00008B64
		private static string FilePath
		{
			get
			{
				return Path.Combine(RegistryStrings.PromotionDirectory, "bst_promotion");
			}
		}

		// Token: 0x06000E69 RID: 3689 RVA: 0x0005FFBC File Offset: 0x0005E1BC
		internal static void LoadDataFromFile()
		{
			try
			{
				if (File.Exists(PromotionObject.FilePath))
				{
					using (XmlReader xmlReader = XmlReader.Create(PromotionObject.FilePath, new XmlReaderSettings
					{
						ProhibitDtd = true
					}))
					{
						Logger.Info("vikramTest: Loading PromotionObject Settings from " + PromotionObject.FilePath);
						PromotionObject.Instance = (PromotionObject)new XmlSerializer(typeof(PromotionObject)).Deserialize(xmlReader);
						Logger.Info("vikramTest: Done loading promotionObject.");
						PromotionObject.Instance.QuestHdPlayerRules.ClearSync<string, long>();
						PromotionObject.Instance.QuestRules.ClearSync<QuestRule>();
						PromotionObject.Instance.ResetQuestRules.ClearSync<string, long[]>();
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error Loading PromotionObject Settings " + ex.ToString());
			}
			finally
			{
				if (PromotionObject.Instance == null)
				{
					PromotionObject.Instance = new PromotionObject();
				}
				if (PromotionObject.Instance.DockOrder.Count == 0)
				{
					PromotionObject.Instance.SetDefaultDockOrder(true);
				}
				PromotionObject.CacheOldBootPromotions();
			}
		}

		// Token: 0x06000E6A RID: 3690 RVA: 0x0000A975 File Offset: 0x00008B75
		private static void CacheOldBootPromotions()
		{
			PromotionObject.Instance.DictOldBootPromotions.ClearAddRange(PromotionObject.Instance.DictBootPromotions);
		}

		// Token: 0x06000E6B RID: 3691 RVA: 0x000600DC File Offset: 0x0005E2DC
		internal static void Save()
		{
			try
			{
				if (!Directory.Exists(Directory.GetParent(PromotionObject.FilePath).FullName))
				{
					Directory.CreateDirectory(Directory.GetParent(PromotionObject.FilePath).FullName);
				}
				using (XmlTextWriter xmlTextWriter = new XmlTextWriter(PromotionObject.FilePath, Encoding.UTF8)
				{
					Formatting = Formatting.Indented
				})
				{
					new XmlSerializer(typeof(PromotionObject)).Serialize(xmlTextWriter, PromotionObject.Instance);
					xmlTextWriter.Flush();
				}
			}
			catch (Exception ex)
			{
				Logger.Info(ex.ToString());
			}
		}

		// Token: 0x06000E6C RID: 3692 RVA: 0x00060184 File Offset: 0x0005E384
		internal void PromotionLoaded()
		{
			PromotionObject.mIsPromotionLoading = false;
			EventHandler eventHandler = PromotionObject.mBootPromotionHandler;
			if (eventHandler != null)
			{
				eventHandler(this, new EventArgs());
			}
			EventHandler eventHandler2 = PromotionObject.mBackgroundPromotionHandler;
			if (eventHandler2 != null)
			{
				eventHandler2(this, new EventArgs());
			}
			Action action = PromotionObject.mQuestHandler;
			if (action != null)
			{
				action();
			}
			Action<bool> action2 = PromotionObject.mAppSuggestionHandler;
			if (action2 != null)
			{
				action2(true);
			}
			Action<bool> action3 = PromotionObject.mAppRecommendationHandler;
			if (action3 != null)
			{
				action3(true);
			}
			EventHandler eventHandler3 = PromotionObject.mPromotionHandler;
			if (eventHandler3 != null)
			{
				eventHandler3(this, new EventArgs());
			}
			EventHandler eventHandler4 = PromotionObject.mAppSpecificRulesHandler;
			if (eventHandler4 == null)
			{
				return;
			}
			eventHandler4(this, new EventArgs());
		}

		// Token: 0x1700022A RID: 554
		// (get) Token: 0x06000E6D RID: 3693 RVA: 0x0000A990 File Offset: 0x00008B90
		[XmlIgnore]
		public List<string> AppSpecificRulesList { get; } = new List<string>();

		// Token: 0x1700022B RID: 555
		// (get) Token: 0x06000E6E RID: 3694 RVA: 0x0000A998 File Offset: 0x00008B98
		public List<string> CustomCursorExcludedAppsList { get; } = new List<string>
		{
			"com.android.vending"
		};

		// Token: 0x1700022C RID: 556
		// (get) Token: 0x06000E6F RID: 3695 RVA: 0x0000A9A0 File Offset: 0x00008BA0
		// (set) Token: 0x06000E70 RID: 3696 RVA: 0x0000A9A8 File Offset: 0x00008BA8
		[XmlIgnore]
		public bool IsRootAccessEnabled { get; set; }

		// Token: 0x1700022D RID: 557
		// (get) Token: 0x06000E71 RID: 3697 RVA: 0x0000A9B1 File Offset: 0x00008BB1
		// (set) Token: 0x06000E72 RID: 3698 RVA: 0x0000A9B9 File Offset: 0x00008BB9
		public string MyAppsPromotionID { get; set; } = string.Empty;

		// Token: 0x1700022E RID: 558
		// (get) Token: 0x06000E73 RID: 3699 RVA: 0x0000A9C2 File Offset: 0x00008BC2
		// (set) Token: 0x06000E74 RID: 3700 RVA: 0x0000A9CA File Offset: 0x00008BCA
		public string MyAppsCrossPromotionID { get; set; } = string.Empty;

		// Token: 0x1700022F RID: 559
		// (get) Token: 0x06000E75 RID: 3701 RVA: 0x0000A9D3 File Offset: 0x00008BD3
		// (set) Token: 0x06000E76 RID: 3702 RVA: 0x0000A9DB File Offset: 0x00008BDB
		public string BackgroundPromotionID { get; set; } = string.Empty;

		// Token: 0x17000230 RID: 560
		// (get) Token: 0x06000E77 RID: 3703 RVA: 0x0000A9E4 File Offset: 0x00008BE4
		// (set) Token: 0x06000E78 RID: 3704 RVA: 0x0000A9EC File Offset: 0x00008BEC
		public string BackgroundPromotionImagePath { get; set; } = string.Empty;

		// Token: 0x17000231 RID: 561
		// (get) Token: 0x06000E79 RID: 3705 RVA: 0x0000A9F5 File Offset: 0x00008BF5
		// (set) Token: 0x06000E7A RID: 3706 RVA: 0x0000A9FD File Offset: 0x00008BFD
		public SerializableDictionary<string, AppIconPromotionObject> DictAppsPromotions { get; set; } = new SerializableDictionary<string, AppIconPromotionObject>();

		// Token: 0x17000232 RID: 562
		// (get) Token: 0x06000E7B RID: 3707 RVA: 0x0000AA06 File Offset: 0x00008C06
		// (set) Token: 0x06000E7C RID: 3708 RVA: 0x0000AA0E File Offset: 0x00008C0E
		public string QuestName { get; set; }

		// Token: 0x17000233 RID: 563
		// (get) Token: 0x06000E7D RID: 3709 RVA: 0x0000AA17 File Offset: 0x00008C17
		// (set) Token: 0x06000E7E RID: 3710 RVA: 0x0000AA1F File Offset: 0x00008C1F
		public string QuestActionType { get; set; }

		// Token: 0x17000234 RID: 564
		// (get) Token: 0x06000E7F RID: 3711 RVA: 0x0000AA28 File Offset: 0x00008C28
		public List<QuestRule> QuestRules { get; } = new List<QuestRule>();

		// Token: 0x17000235 RID: 565
		// (get) Token: 0x06000E80 RID: 3712 RVA: 0x0000AA30 File Offset: 0x00008C30
		// (set) Token: 0x06000E81 RID: 3713 RVA: 0x0000AA38 File Offset: 0x00008C38
		public SerializableDictionary<string, long[]> ResetQuestRules { get; set; } = new SerializableDictionary<string, long[]>();

		// Token: 0x17000236 RID: 566
		// (get) Token: 0x06000E82 RID: 3714 RVA: 0x0000AA41 File Offset: 0x00008C41
		// (set) Token: 0x06000E83 RID: 3715 RVA: 0x0000AA49 File Offset: 0x00008C49
		public SerializableDictionary<string, long> QuestHdPlayerRules { get; set; } = new SerializableDictionary<string, long>();

		// Token: 0x17000237 RID: 567
		// (get) Token: 0x06000E84 RID: 3716 RVA: 0x0000AA52 File Offset: 0x00008C52
		// (set) Token: 0x06000E85 RID: 3717 RVA: 0x0000AA5A File Offset: 0x00008C5A
		public SerializableDictionary<string, int> MyAppsOrder { get; set; } = new SerializableDictionary<string, int>();

		// Token: 0x17000238 RID: 568
		// (get) Token: 0x06000E86 RID: 3718 RVA: 0x0000AA63 File Offset: 0x00008C63
		// (set) Token: 0x06000E87 RID: 3719 RVA: 0x0000AA6B File Offset: 0x00008C6B
		public SerializableDictionary<string, int> DockOrder { get; set; } = new SerializableDictionary<string, int>
		{
			{
				"appcenter",
				1
			},
			{
				"com.android.vending",
				2
			},
			{
				"pikaworld",
				3
			},
			{
				"macro_recorder",
				4
			},
			{
				"instance_manager",
				5
			},
			{
				"help_center",
				6
			}
		};

		// Token: 0x17000239 RID: 569
		// (get) Token: 0x06000E88 RID: 3720 RVA: 0x0000AA74 File Offset: 0x00008C74
		// (set) Token: 0x06000E89 RID: 3721 RVA: 0x0000AA7C File Offset: 0x00008C7C
		public SerializableDictionary<string, int> MoreAppsDockOrder { get; set; } = new SerializableDictionary<string, int>
		{
			{
				"appcenter",
				1
			},
			{
				"com.android.vending",
				2
			},
			{
				"pikaworld",
				3
			},
			{
				"macro_recorder",
				4
			},
			{
				"instance_manager",
				5
			},
			{
				"help_center",
				6
			}
		};

		// Token: 0x1700023A RID: 570
		// (get) Token: 0x06000E8A RID: 3722 RVA: 0x0000AA85 File Offset: 0x00008C85
		// (set) Token: 0x06000E8B RID: 3723 RVA: 0x0000AA8D File Offset: 0x00008C8D
		internal SerializableDictionary<string, BootPromotion> DictOldBootPromotions { get; set; } = new SerializableDictionary<string, BootPromotion>();

		// Token: 0x1700023B RID: 571
		// (get) Token: 0x06000E8C RID: 3724 RVA: 0x0000AA96 File Offset: 0x00008C96
		// (set) Token: 0x06000E8D RID: 3725 RVA: 0x0000AA9E File Offset: 0x00008C9E
		public int BootPromoDisplaytime { get; set; } = 4000;

		// Token: 0x1700023C RID: 572
		// (get) Token: 0x06000E8E RID: 3726 RVA: 0x0000AAA7 File Offset: 0x00008CA7
		// (set) Token: 0x06000E8F RID: 3727 RVA: 0x0000AAAF File Offset: 0x00008CAF
		public SerializableDictionary<string, BootPromotion> DictBootPromotions { get; set; } = new SerializableDictionary<string, BootPromotion>();

		// Token: 0x1700023D RID: 573
		// (get) Token: 0x06000E90 RID: 3728 RVA: 0x0000AAB8 File Offset: 0x00008CB8
		// (set) Token: 0x06000E91 RID: 3729 RVA: 0x0000AAC0 File Offset: 0x00008CC0
		public SerializableDictionary<string, SearchRecommendation> SearchRecommendations { get; set; } = new SerializableDictionary<string, SearchRecommendation>();

		// Token: 0x1700023E RID: 574
		// (get) Token: 0x06000E92 RID: 3730 RVA: 0x0000AAC9 File Offset: 0x00008CC9
		// (set) Token: 0x06000E93 RID: 3731 RVA: 0x0000AAD1 File Offset: 0x00008CD1
		public AppRecommendationSection AppRecommendations { get; set; } = new AppRecommendationSection();

		// Token: 0x1700023F RID: 575
		// (get) Token: 0x06000E94 RID: 3732 RVA: 0x0000AADA File Offset: 0x00008CDA
		public List<AppSuggestionPromotion> AppSuggestionList { get; } = new List<AppSuggestionPromotion>();

		// Token: 0x17000240 RID: 576
		// (get) Token: 0x06000E95 RID: 3733 RVA: 0x0000AAE2 File Offset: 0x00008CE2
		public List<string> BlackListedApplicationsList { get; } = new List<string>();

		// Token: 0x17000241 RID: 577
		// (get) Token: 0x06000E96 RID: 3734 RVA: 0x0000AAEA File Offset: 0x00008CEA
		// (set) Token: 0x06000E97 RID: 3735 RVA: 0x0000AAF2 File Offset: 0x00008CF2
		public SerializableDictionary<string, string> StartupTab { get; set; } = new SerializableDictionary<string, string>();

		// Token: 0x17000242 RID: 578
		// (get) Token: 0x06000E98 RID: 3736 RVA: 0x0000AAFB File Offset: 0x00008CFB
		// (set) Token: 0x06000E99 RID: 3737 RVA: 0x0000AB03 File Offset: 0x00008D03
		public bool IsShowOtsFeedback { get; set; }

		// Token: 0x17000243 RID: 579
		// (get) Token: 0x06000E9A RID: 3738 RVA: 0x0000AB0C File Offset: 0x00008D0C
		// (set) Token: 0x06000E9B RID: 3739 RVA: 0x0000AB14 File Offset: 0x00008D14
		public string DiscordClientID { get; set; }

		// Token: 0x17000244 RID: 580
		// (get) Token: 0x06000E9C RID: 3740 RVA: 0x0000AB1D File Offset: 0x00008D1D
		// (set) Token: 0x06000E9D RID: 3741 RVA: 0x0000AB25 File Offset: 0x00008D25
		public bool IsSecurityMetricsEnable { get; set; }

		// Token: 0x040009A9 RID: 2473
		private static bool mIsPromotionLoading = true;

		// Token: 0x040009AA RID: 2474
		internal static volatile bool mIsBootPromotionLoading = true;

		// Token: 0x040009B2 RID: 2482
		private const string sPromotionFilename = "bst_promotion";

		// Token: 0x040009B3 RID: 2483
		internal static PromotionObject Instance = null;
	}
}
