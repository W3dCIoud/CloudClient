﻿using System;
using System.Collections.Generic;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200019C RID: 412
	public static class HttpHandlerSetup
	{
		// Token: 0x17000281 RID: 641
		// (get) Token: 0x06001010 RID: 4112 RVA: 0x0000BC5D File Offset: 0x00009E5D
		// (set) Token: 0x06001011 RID: 4113 RVA: 0x0000BC64 File Offset: 0x00009E64
		public static HTTPServer Server { get; set; }

		// Token: 0x06001012 RID: 4114 RVA: 0x00065E1C File Offset: 0x0006401C
		public static void InitHTTPServer(Dictionary<string, HTTPServer.RequestHandler> routes)
		{
			int num = 2871;
			int maxPort = num + 10;
			HttpHandlerSetup.Server = HTTPUtils.SetupServer(num, maxPort, routes, string.Empty);
			RegistryManager.Instance.PartnerServerPort = HttpHandlerSetup.Server.Port;
			HttpHandlerSetup.Server.Run();
		}
	}
}
