﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Markup;
using BlueStacks.Common;
using Microsoft.Win32;
using Xilium.CefGlue;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000263 RID: 611
	public partial class App : System.Windows.Application
	{
		// Token: 0x170002DA RID: 730
		// (get) Token: 0x060015BC RID: 5564 RVA: 0x0000EDC7 File Offset: 0x0000CFC7
		// (set) Token: 0x060015BD RID: 5565 RVA: 0x0000EDCE File Offset: 0x0000CFCE
		public static Mutex BlueStacksUILock
		{
			get
			{
				return App.mBluestacksUILock;
			}
			set
			{
				App.mBluestacksUILock = value;
			}
		}

		// Token: 0x170002DB RID: 731
		// (get) Token: 0x060015BE RID: 5566 RVA: 0x0000EDD6 File Offset: 0x0000CFD6
		// (set) Token: 0x060015BF RID: 5567 RVA: 0x0000EDDD File Offset: 0x0000CFDD
		internal static bool IsApplicationActive { get; set; }

		// Token: 0x060015C1 RID: 5569 RVA: 0x00082564 File Offset: 0x00080764
		private static void HandleDisplaySettingsChanged(object sender, EventArgs e)
		{
			try
			{
				foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>())
				{
					if (mainWindow != null && !mainWindow.mClosed)
					{
						mainWindow.HandleDisplaySettingsChanged();
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in HandleDisplaySettingsChanged. Exception: " + ex.ToString());
			}
		}

		// Token: 0x060015C2 RID: 5570 RVA: 0x000825F0 File Offset: 0x000807F0
		private static void ParseWebMagnetArgs(ref string[] args)
		{
			if (args.Length != 0 && args[0].StartsWith("bluestacksgp:", StringComparison.InvariantCultureIgnoreCase))
			{
				Logger.Info("Handling web uri: " + args[0]);
				string[] array = args[0].Split(new char[]
				{
					':'
				}, 2);
				string[] array2 = new string[args.Length + 1];
				string[] array3 = Uri.UnescapeDataString(array[1]).TrimStart(new char[0]).Split(new char[]
				{
					' '
				}, 2);
				if (array3.Length > 1)
				{
					Array.Copy(array3, 0, array2, 0, 2);
					Array.Copy(args, 1, array2, 2, args.Length - 1);
					args = array2;
					return;
				}
				args[0] = array3[0];
			}
		}

		// Token: 0x060015C3 RID: 5571 RVA: 0x0000EDE5 File Offset: 0x0000CFE5
		private static void InitExceptionAndLogging()
		{
			Logger.InitLog("BlueStacksUI", "BlueStacksUI", true);
			System.Windows.Forms.Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
			System.Windows.Forms.Application.ThreadException += App.Application_ThreadException;
			AppDomain.CurrentDomain.UnhandledException += App.CurrentDomain_UnhandledException;
		}

		// Token: 0x060015C4 RID: 5572 RVA: 0x0000EE24 File Offset: 0x0000D024
		private static void Application_Startup(object sender, StartupEventArgs e)
		{
			Logger.Info("In Application_Startup");
			ServicePointManager.ServerCertificateValidationCallback = (RemoteCertificateValidationCallback)Delegate.Combine(ServicePointManager.ServerCertificateValidationCallback, new RemoteCertificateValidationCallback(App.ValidateRemoteCertificate));
			ServicePointManager.DefaultConnectionLimit = 1000;
		}

		// Token: 0x060015C5 RID: 5573 RVA: 0x00007255 File Offset: 0x00005455
		private static bool ValidateRemoteCertificate(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors policyErrors)
		{
			return true;
		}

		// Token: 0x060015C6 RID: 5574 RVA: 0x0008269C File Offset: 0x0008089C
		private static void CheckIfAlreadyRunning()
		{
			try
			{
				if (ProcessUtils.IsAlreadyRunning("Global\\BlueStacks_DiskCompactor_Lockbgp"))
				{
					Logger.Info("Disk compaction is running in background");
					using (List<string>.Enumerator enumerator = GetProcessExecutionPath.GetApplicationPath(Process.GetProcessesByName("DiskCompactionTool")).GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							if (enumerator.Current.Equals(Path.Combine(RegistryStrings.InstallDir, "DiskCompactionTool.exe"), StringComparison.InvariantCultureIgnoreCase))
							{
								CustomMessageWindow customMessageWindow = new CustomMessageWindow();
								customMessageWindow.ImageName = "ProductLogo";
								customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_EXIT_BLUESTACKS_DUE_TO_DISK_COMPACTION_HEADING");
								customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_EXIT_BLUESTACKS_DUE_TO_DISK_COMPACTION_MESSAGE");
								customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
								customMessageWindow.CloseButtonHandle(null, null);
								customMessageWindow.ShowDialog();
								Logger.Info("Disk compaction running for this instance. Exiting this instance");
								App.ExitApplication();
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to check if disk compaction is running: " + ex.Message);
			}
			string text;
			if (!Opt.Instance.force && ProcessUtils.IsAnyInstallerProcesRunning(out text) && !string.IsNullOrEmpty(text))
			{
				Logger.Info(text + " process is running. Exiting BlueStacks");
				App.ExitApplication();
			}
			if (ProcessUtils.CheckAlreadyRunningAndTakeLock("Global\\BlueStacks_BlueStacksUI_Lockbgp", out App.mBluestacksUILock))
			{
				try
				{
					Logger.Info("Relaunching client for vm : " + Opt.Instance.vmname);
					Dictionary<string, string> dictionary = new Dictionary<string, string>
					{
						{
							"vmname",
							Opt.Instance.vmname
						},
						{
							"hidden",
							Opt.Instance.h.ToString(CultureInfo.InvariantCulture)
						}
					};
					if (Opt.Instance.launchedFromSysTray)
					{
						dictionary.Add("all", "True");
					}
					if (!string.IsNullOrEmpty(Opt.Instance.Json))
					{
						dictionary.Add("json", Opt.Instance.Json);
						string str = HTTPUtils.SendRequestToClient("openPackage", dictionary, Opt.Instance.vmname, 0, null, false, 1, 0);
						Logger.Debug("OpenPackage result: " + str);
					}
					else
					{
						string str2 = HTTPUtils.SendRequestToClient("showWindow", dictionary, Opt.Instance.vmname, 0, null, false, 1, 0);
						Logger.Debug("ShowWindow result: " + str2);
					}
				}
				catch (Exception ex2)
				{
					Logger.Error(ex2.ToString());
				}
				Logger.Info("BlueStacksUI already running. Exiting this instance");
				App.ExitApplication();
				return;
			}
			try
			{
				Logger.Debug("Checking for existing process not exited");
				List<Process> list = Process.GetProcessesByName(Process.GetCurrentProcess().ProcessName).ToList<Process>();
				if (ProcessUtils.IsLockInUse("Global\\BlueStacks_BlueStacksUI_Closing_Lockbgp"))
				{
					foreach (Process process in list)
					{
						if (process.Id != Process.GetCurrentProcess().Id)
						{
							process.Kill();
						}
					}
				}
			}
			catch (Exception ex3)
			{
				Logger.Warning("Ignoring error closing previous instances" + ex3.ToString());
			}
		}

		// Token: 0x060015C7 RID: 5575 RVA: 0x000829C0 File Offset: 0x00080BC0
		private static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
		{
			if (App.CheckForIgnoredExceptions(e.Exception.ToString()))
			{
				Logger.Error("Unhandled Thread Exception:");
				Logger.Error(e.Exception.ToString());
				if (!FeatureManager.Instance.IsCustomUIForNCSoft)
				{
					System.Windows.Forms.MessageBox.Show("BlueStacks App Player.\nError: " + e.Exception.ToString());
				}
				App.ExitApplication();
			}
		}

		// Token: 0x060015C8 RID: 5576 RVA: 0x00082A28 File Offset: 0x00080C28
		private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			if (App.CheckForIgnoredExceptions(((Exception)e.ExceptionObject).ToString()))
			{
				App.CheckForIgnoredExceptions(((Exception)e.ExceptionObject).ToString());
				Logger.Error("Unhandled Application Exception.");
				Logger.Error("Err: " + e.ExceptionObject.ToString());
				if (!FeatureManager.Instance.IsCustomUIForNCSoft)
				{
					System.Windows.Forms.MessageBox.Show("BlueStacks App Player.\nError: " + ((Exception)e.ExceptionObject).ToString());
				}
				App.ExitApplication();
			}
		}

		// Token: 0x060015C9 RID: 5577 RVA: 0x0000EE5A File Offset: 0x0000D05A
		private static bool CheckForIgnoredExceptions(string s)
		{
			if (s.Contains("GetFocusedElementFromWinEvent"))
			{
				Logger.Warning("Ignoring Unhandled Application Exception: " + s);
				return false;
			}
			return true;
		}

		// Token: 0x060015CA RID: 5578 RVA: 0x00082AB8 File Offset: 0x00080CB8
		internal static void ExitApplication()
		{
			foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>())
			{
				if (mainWindow != null && !mainWindow.mClosed)
				{
					mainWindow.ForceCloseWindow();
				}
			}
			App.UnwindEvents();
			App.ReleaseLock();
			Process.GetCurrentProcess().Kill();
		}

		// Token: 0x060015CB RID: 5579 RVA: 0x00082B34 File Offset: 0x00080D34
		internal static void UnwindEvents()
		{
			try
			{
				SystemEvents.DisplaySettingsChanged -= App.HandleDisplaySettingsChanged;
			}
			catch (Exception ex)
			{
				string str = "Couldn't unwind events properly; ";
				Exception ex2 = ex;
				Logger.Error(str + ((ex2 != null) ? ex2.ToString() : null));
			}
		}

		// Token: 0x060015CC RID: 5580 RVA: 0x00082B84 File Offset: 0x00080D84
		internal static void ReleaseLock()
		{
			try
			{
				BluestacksProcessHelper.TakeLock("Global\\BlueStacks_BlueStacksUI_Closing_Lockbgp");
				if (App.BlueStacksUILock != null)
				{
					App.BlueStacksUILock.Close();
					App.BlueStacksUILock = null;
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Ignoring Exception while releasing lock. Err : " + ex.ToString());
			}
		}

		// Token: 0x060015CD RID: 5581 RVA: 0x00082BE0 File Offset: 0x00080DE0
		private void Application_Activated(object sender, EventArgs e)
		{
			App.IsApplicationActive = true;
			foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>())
			{
				mainWindow.SendTempGamepadState(true);
			}
		}

		// Token: 0x060015CE RID: 5582 RVA: 0x00082C40 File Offset: 0x00080E40
		private void Application_Deactivated(object sender, EventArgs e)
		{
			App.IsApplicationActive = false;
			foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>())
			{
				if (mainWindow.mStreamingModeEnabled)
				{
					mainWindow.SendTempGamepadState(true);
				}
				else
				{
					mainWindow.SendTempGamepadState(false);
				}
			}
		}

		// Token: 0x04000E1C RID: 3612
		private static Mutex mBluestacksUILock;

		// Token: 0x04000E1E RID: 3614
		internal static Fraction defaultResolution;
	}
}
