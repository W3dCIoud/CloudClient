﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000139 RID: 313
	public class GuidanceVideoWindow : CustomWindow, IDisposable, IComponentConnector
	{
		// Token: 0x06000CA4 RID: 3236 RVA: 0x00009A7F File Offset: 0x00007C7F
		public GuidanceVideoWindow(MainWindow parentWindow)
		{
			this.ParentWindow = parentWindow;
			this.InitializeComponent();
		}

		// Token: 0x06000CA5 RID: 3237 RVA: 0x00053678 File Offset: 0x00051878
		private void GuidanceVideoWindow_IsVisibleChanged(object _1, DependencyPropertyChangedEventArgs eventArgs)
		{
			if (base.IsVisible)
			{
				ClientStats.SendKeyMappingUIStatsAsync("video_clicked", KMManager.sPackageName, KMManager.sVideoMode.ToString());
				this.mBrowser = new BrowserControl();
				BrowserControl browserControl = this.mBrowser;
				string sPackageName = KMManager.sPackageName;
				string videoMode = KMManager.sVideoMode.ToString().ToLower(CultureInfo.InvariantCulture);
				MainWindow parentWindow = this.ParentWindow;
				string selectedSchemeName;
				if (parentWindow == null)
				{
					selectedSchemeName = null;
				}
				else
				{
					IMConfig selectedConfig = parentWindow.SelectedConfig;
					if (selectedConfig == null)
					{
						selectedSchemeName = null;
					}
					else
					{
						IMControlScheme selectedControlScheme = selectedConfig.SelectedControlScheme;
						selectedSchemeName = ((selectedControlScheme != null) ? selectedControlScheme.Name : null);
					}
				}
				browserControl.InitBaseControl(BlueStacksUIUtils.GetVideoTutorialUrl(sPackageName, videoMode, selectedSchemeName), 0f);
				this.mBrowser.Visibility = Visibility.Visible;
				this.mBrowserGrid.Children.Add(this.mBrowser);
			}
			try
			{
				if ((bool)eventArgs.NewValue)
				{
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					dictionary["allInstances"] = "False";
					dictionary["explicit"] = "False";
					Dictionary<string, string> data = dictionary;
					HTTPUtils.SendRequestToEngineAsync("mute", data, this.ParentWindow.mVmName, 0, null, false, 1, 0);
					this.ParentWindow.mCommonHandler.OnVolumeMuted(true);
				}
				else if (!RegistryManager.Instance.AreAllInstancesMuted && !this.ParentWindow.EngineInstanceRegistry.IsMuted)
				{
					Dictionary<string, string> dictionary2 = new Dictionary<string, string>();
					dictionary2["allInstances"] = "False";
					Dictionary<string, string> data2 = dictionary2;
					HTTPUtils.SendRequestToEngineAsync("unmute", data2, this.ParentWindow.mVmName, 0, null, false, 1, 0);
					this.ParentWindow.mCommonHandler.OnVolumeMuted(false);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send mute to frontend. Ex: " + ex.Message);
			}
		}

		// Token: 0x06000CA6 RID: 3238 RVA: 0x00009A94 File Offset: 0x00007C94
		internal void CloseWindow()
		{
			if (this.mBrowser != null)
			{
				this.mBrowser.DisposeBrowser();
				this.mBrowserGrid.Children.Remove(this.mBrowser);
				this.mBrowser = null;
			}
		}

		// Token: 0x06000CA7 RID: 3239 RVA: 0x00004956 File Offset: 0x00002B56
		private void CloseButton_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			base.Close();
		}

		// Token: 0x06000CA8 RID: 3240 RVA: 0x00009AC6 File Offset: 0x00007CC6
		private void mWindow_Closing(object sender, CancelEventArgs e)
		{
			this.CloseWindow();
		}

		// Token: 0x06000CA9 RID: 3241 RVA: 0x00009ACE File Offset: 0x00007CCE
		protected virtual void Dispose(bool disposing)
		{
			if (!this.disposedValue)
			{
				BrowserControl browserControl = this.mBrowser;
				if (browserControl != null)
				{
					browserControl.Dispose();
				}
				this.disposedValue = true;
			}
		}

		// Token: 0x06000CAA RID: 3242 RVA: 0x00053828 File Offset: 0x00051A28
		~GuidanceVideoWindow()
		{
			this.Dispose(false);
		}

		// Token: 0x06000CAB RID: 3243 RVA: 0x00009AF2 File Offset: 0x00007CF2
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x06000CAC RID: 3244 RVA: 0x00053858 File Offset: 0x00051A58
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/guidancevideowindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000CAD RID: 3245 RVA: 0x00053888 File Offset: 0x00051A88
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mWindow = (GuidanceVideoWindow)target;
				this.mWindow.IsVisibleChanged += this.GuidanceVideoWindow_IsVisibleChanged;
				this.mWindow.Closing += this.mWindow_Closing;
				return;
			case 2:
				this.mMainBrowserGrid = (Grid)target;
				return;
			case 3:
				this.mMaskBorder = (Border)target;
				return;
			case 4:
				this.mBrowserGrid = (Grid)target;
				return;
			case 5:
				((CustomPictureBox)target).PreviewMouseUp += this.CloseButton_PreviewMouseUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000871 RID: 2161
		private BrowserControl mBrowser;

		// Token: 0x04000872 RID: 2162
		internal MainWindow ParentWindow;

		// Token: 0x04000873 RID: 2163
		private bool disposedValue;

		// Token: 0x04000874 RID: 2164
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal GuidanceVideoWindow mWindow;

		// Token: 0x04000875 RID: 2165
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mMainBrowserGrid;

		// Token: 0x04000876 RID: 2166
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder;

		// Token: 0x04000877 RID: 2167
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mBrowserGrid;

		// Token: 0x04000878 RID: 2168
		private bool _contentLoaded;
	}
}
