﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000079 RID: 121
	internal sealed class GenericNotificationManager
	{
		// Token: 0x060004FC RID: 1276 RVA: 0x0000552E File Offset: 0x0000372E
		private GenericNotificationManager()
		{
		}

		// Token: 0x17000192 RID: 402
		// (get) Token: 0x060004FD RID: 1277 RVA: 0x0001F08C File Offset: 0x0001D28C
		public static GenericNotificationManager Instance
		{
			get
			{
				if (GenericNotificationManager.sInstance == null)
				{
					object obj = GenericNotificationManager.syncRoot;
					lock (obj)
					{
						if (GenericNotificationManager.sInstance == null)
						{
							GenericNotificationManager.sInstance = new GenericNotificationManager();
						}
					}
				}
				return GenericNotificationManager.sInstance;
			}
		}

		// Token: 0x17000193 RID: 403
		// (get) Token: 0x060004FE RID: 1278 RVA: 0x00005541 File Offset: 0x00003741
		internal static string GenericNotificationFilePath
		{
			get
			{
				return Path.Combine(RegistryStrings.PromotionDirectory, "bst_genericNotification");
			}
		}

		// Token: 0x060004FF RID: 1279 RVA: 0x0001F0E4 File Offset: 0x0001D2E4
		public void AddNewNotification(GenericNotificationItem notificationItem, bool dontOverwrite = false)
		{
			int i = 3;
			while (i > 0)
			{
				i--;
				try
				{
					SerializableDictionary<string, GenericNotificationItem> savedNotifications = GenericNotificationManager.GetSavedNotifications();
					if (!dontOverwrite)
					{
						savedNotifications[notificationItem.Id] = notificationItem;
						this.SaveNotifications(savedNotifications);
					}
					else if (!savedNotifications.ContainsKey(notificationItem.Id))
					{
						savedNotifications[notificationItem.Id] = notificationItem;
						this.SaveNotifications(savedNotifications);
					}
					break;
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to add notification id : {0} titled : {1} and msg : {2}... Err : {3}", new object[]
					{
						notificationItem.Id,
						notificationItem.Title,
						notificationItem.Message,
						ex.ToString()
					});
				}
			}
		}

		// Token: 0x06000500 RID: 1280 RVA: 0x0001F18C File Offset: 0x0001D38C
		private void SaveNotifications(SerializableDictionary<string, GenericNotificationItem> lstItem)
		{
			using (XmlTextWriter xmlTextWriter = new XmlTextWriter(GenericNotificationManager.GenericNotificationFilePath, Encoding.UTF8))
			{
				xmlTextWriter.Formatting = Formatting.Indented;
				new XmlSerializer(typeof(SerializableDictionary<string, GenericNotificationItem>)).Serialize(xmlTextWriter, lstItem);
				xmlTextWriter.Flush();
			}
			this.mDict = lstItem;
		}

		// Token: 0x06000501 RID: 1281 RVA: 0x0001F1F0 File Offset: 0x0001D3F0
		private static SerializableDictionary<string, GenericNotificationItem> GetSavedNotifications()
		{
			SerializableDictionary<string, GenericNotificationItem> result = new SerializableDictionary<string, GenericNotificationItem>();
			if (File.Exists(GenericNotificationManager.GenericNotificationFilePath))
			{
				try
				{
					using (XmlReader xmlReader = XmlReader.Create(GenericNotificationManager.GenericNotificationFilePath, new XmlReaderSettings
					{
						ProhibitDtd = true
					}))
					{
						result = (SerializableDictionary<string, GenericNotificationItem>)new XmlSerializer(typeof(SerializableDictionary<string, GenericNotificationItem>)).Deserialize(xmlReader);
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception when reading saved notifications." + ex.ToString());
				}
			}
			return result;
		}

		// Token: 0x06000502 RID: 1282 RVA: 0x0001F284 File Offset: 0x0001D484
		internal GenericNotificationItem GetNotificationItem(string id)
		{
			if (this.mDict.ContainsKey(id))
			{
				return this.mDict[id];
			}
			SerializableDictionary<string, GenericNotificationItem> notificationItems = GenericNotificationManager.GetNotificationItems((GenericNotificationItem _) => _.Id == id);
			if (notificationItems.Count > 0)
			{
				return notificationItems.First<KeyValuePair<string, GenericNotificationItem>>().Value;
			}
			return null;
		}

		// Token: 0x06000503 RID: 1283 RVA: 0x0001F2F0 File Offset: 0x0001D4F0
		public SerializableDictionary<string, GenericNotificationItem> MarkNotification(IEnumerable<string> ids, Action<GenericNotificationItem> setter)
		{
			int i = 3;
			SerializableDictionary<string, GenericNotificationItem> serializableDictionary = new SerializableDictionary<string, GenericNotificationItem>();
			while (i > 0)
			{
				i--;
				try
				{
					serializableDictionary = GenericNotificationManager.GetSavedNotifications();
					foreach (string text in ids)
					{
						if (text != null && serializableDictionary.ContainsKey(text))
						{
							setter(serializableDictionary[text]);
						}
					}
					this.SaveNotifications(serializableDictionary);
					break;
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to mark notification... Err : " + ex.ToString());
				}
			}
			return serializableDictionary;
		}

		// Token: 0x06000504 RID: 1284 RVA: 0x0001F394 File Offset: 0x0001D594
		public static SerializableDictionary<string, GenericNotificationItem> GetNotificationItems(Predicate<GenericNotificationItem> getter)
		{
			int i = 3;
			SerializableDictionary<string, GenericNotificationItem> serializableDictionary = new SerializableDictionary<string, GenericNotificationItem>();
			SerializableDictionary<string, GenericNotificationItem> serializableDictionary2 = new SerializableDictionary<string, GenericNotificationItem>();
			while (i > 0)
			{
				i--;
				try
				{
					serializableDictionary = GenericNotificationManager.GetSavedNotifications();
					break;
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to get notification... Err : " + ex.ToString());
				}
			}
			foreach (KeyValuePair<string, GenericNotificationItem> keyValuePair in serializableDictionary)
			{
				if (getter(keyValuePair.Value))
				{
					serializableDictionary2.Add(keyValuePair.Key, keyValuePair.Value);
				}
			}
			return serializableDictionary2;
		}

		// Token: 0x04000297 RID: 663
		private static volatile GenericNotificationManager sInstance;

		// Token: 0x04000298 RID: 664
		private static object syncRoot = new object();

		// Token: 0x04000299 RID: 665
		private SerializableDictionary<string, GenericNotificationItem> mDict = new SerializableDictionary<string, GenericNotificationItem>();
	}
}
