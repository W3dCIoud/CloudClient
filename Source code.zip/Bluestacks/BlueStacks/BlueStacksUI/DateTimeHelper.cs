﻿using System;
using System.Globalization;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000152 RID: 338
	internal class DateTimeHelper
	{
		// Token: 0x06000D4E RID: 3406 RVA: 0x00057CD0 File Offset: 0x00055ED0
		internal static string GetReadableDateTimeString(DateTime yourDate)
		{
			if (yourDate.ToLocalTime().Date == DateTime.Now.Date)
			{
				return "Today at " + yourDate.ToLocalTime().ToString("HH:mm", CultureInfo.InvariantCulture);
			}
			if (yourDate.ToLocalTime().Date.Year == DateTime.Now.Date.Year)
			{
				return yourDate.ToLocalTime().ToString("%d MMM',' HH:mm", CultureInfo.InvariantCulture);
			}
			return yourDate.ToLocalTime().ToString("%d MMM yyyy',' HH:mm", CultureInfo.InvariantCulture);
		}
	}
}
