﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000133 RID: 307
	public class ComboBoxSchemeControl : UserControl, IComponentConnector
	{
		// Token: 0x06000C61 RID: 3169 RVA: 0x000098D7 File Offset: 0x00007AD7
		public ComboBoxSchemeControl(KeymapCanvasWindow window, MainWindow mainWindow)
		{
			this.CanvasWindow = window;
			this.ParentWindow = mainWindow;
			this.InitializeComponent();
		}

		// Token: 0x06000C62 RID: 3170 RVA: 0x00050AD4 File Offset: 0x0004ECD4
		private void Bookmark_img_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!this.mSchemeName.IsReadOnly)
			{
				this.HandleNameEdit(this);
			}
			if (this.ParentWindow.SelectedConfig.ControlSchemesDict.ContainsKey(this.mSchemeName.Text))
			{
				IMControlScheme imcontrolScheme = this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeName.Text];
				if (imcontrolScheme.IsBookMarked)
				{
					imcontrolScheme.IsBookMarked = false;
					this.mBookmarkImg.ImageName = "bookmark";
				}
				else
				{
					List<IMControlScheme> controlSchemes = this.ParentWindow.SelectedConfig.ControlSchemes;
					bool flag;
					if (controlSchemes == null)
					{
						flag = false;
					}
					else
					{
						flag = (controlSchemes.Count((IMControlScheme scheme) => scheme.IsBookMarked) < 5);
					}
					if (flag)
					{
						imcontrolScheme.IsBookMarked = true;
						this.mBookmarkImg.ImageName = "bookmarked";
					}
					else
					{
						this.CanvasWindow.SidebarWindow.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_BOOKMARK_SCHEMES_WARNING"));
					}
				}
				this.CanvasWindow.SidebarWindow.FillProfileCombo();
				KeymapCanvasWindow.sIsDirty = true;
			}
			e.Handled = true;
		}

		// Token: 0x06000C63 RID: 3171 RVA: 0x00050BEC File Offset: 0x0004EDEC
		private void EditImg_MouseDown(object sender, MouseButtonEventArgs e)
		{
			this.mEditImg.Visibility = Visibility.Collapsed;
			this.mSaveImg.Visibility = Visibility.Visible;
			this.mOldSchemeName = this.mSchemeName.Text;
			this.mSchemeName.Focusable = true;
			this.mSchemeName.IsReadOnly = false;
			this.mSchemeName.CaretIndex = this.mSchemeName.Text.Length;
			this.mSchemeName.Focus();
			e.Handled = true;
		}

		// Token: 0x06000C64 RID: 3172 RVA: 0x000098F3 File Offset: 0x00007AF3
		private void SaveImg_MouseDown(object sender, MouseButtonEventArgs e)
		{
			this.HandleNameEdit(this);
			e.Handled = true;
		}

		// Token: 0x06000C65 RID: 3173 RVA: 0x00050C68 File Offset: 0x0004EE68
		private bool EditedNameIsAllowed(string text, ComboBoxSchemeControl toBeRenamedControl)
		{
			if (string.IsNullOrEmpty(text.Trim()))
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this.CanvasWindow.SidebarWindow, LocaleStrings.GetLocalizedString("STRING_INVALID_SCHEME_NAME"), 1.3, false);
				return false;
			}
			foreach (object obj in this.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children)
			{
				ComboBoxSchemeControl comboBoxSchemeControl = (ComboBoxSchemeControl)obj;
				if (comboBoxSchemeControl.mSchemeName.Text.ToLower(CultureInfo.InvariantCulture).Trim() == text.ToLower(CultureInfo.InvariantCulture).Trim() && comboBoxSchemeControl != toBeRenamedControl)
				{
					this.ParentWindow.mCommonHandler.AddToastPopup(this.CanvasWindow.SidebarWindow, LocaleStrings.GetLocalizedString("STRING_INVALID_SCHEME_NAME"), 1.3, false);
					return false;
				}
				if (comboBoxSchemeControl.mSchemeName.Text.Trim().IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
				{
					string message = string.Format(CultureInfo.InvariantCulture, "{0} {1} {2}", new object[]
					{
						LocaleStrings.GetLocalizedString("STRING_SCHEME_INVALID_CHARACTERS"),
						Environment.NewLine,
						"\\ / : * ? \" < > |"
					});
					this.ParentWindow.mCommonHandler.AddToastPopup(this.CanvasWindow.SidebarWindow, message, 3.0, false);
					return false;
				}
			}
			return true;
		}

		// Token: 0x06000C66 RID: 3174 RVA: 0x00050E0C File Offset: 0x0004F00C
		private void CopyImg_MouseDown(object sender, MouseButtonEventArgs e)
		{
			bool flag = false;
			foreach (object obj in this.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children)
			{
				ComboBoxSchemeControl comboBoxSchemeControl = (ComboBoxSchemeControl)obj;
				if (!comboBoxSchemeControl.mSchemeName.IsReadOnly)
				{
					this.HandleNameEdit(comboBoxSchemeControl);
					flag = true;
					e.Handled = true;
					break;
				}
			}
			if (!flag)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow, this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeName.Text], true);
			}
			e.Handled = true;
		}

		// Token: 0x06000C67 RID: 3175 RVA: 0x00050ECC File Offset: 0x0004F0CC
		private void DeleteImg_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!this.mSchemeName.IsReadOnly)
			{
				this.HandleNameEdit(this);
			}
			if (!this.ParentWindow.EngineInstanceRegistry.ShowSchemeDeletePopup)
			{
				this.DeleteControlScheme();
				e.Handled = true;
				return;
			}
			this.mDeleteScriptMessageWindow = new CustomMessageWindow();
			this.mDeleteScriptMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_DELETE_SCHEME");
			this.mDeleteScriptMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_DELETE_SCHEME_CONFIRMATION");
			this.mDeleteScriptMessageWindow.CheckBox.Content = LocaleStrings.GetLocalizedString("STRING_DOWNLOAD_GOOGLE_APP_POPUP_STRING_04");
			this.mDeleteScriptMessageWindow.CheckBox.Visibility = Visibility.Visible;
			this.mDeleteScriptMessageWindow.CheckBox.IsChecked = new bool?(false);
			this.mDeleteScriptMessageWindow.AddButton(ButtonColors.Blue, LocaleStrings.GetLocalizedString("STRING_DELETE"), new EventHandler(this.UpdateSettingsAndDeleteScheme), null, false, null);
			this.mDeleteScriptMessageWindow.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_CANCEL"), delegate(object o, EventArgs evt)
			{
				KeymapCanvasWindow.sIsDirty = false;
				GuidanceWindow.sIsDirty = false;
			}, null, false, null);
			this.mDeleteScriptMessageWindow.CloseButtonHandle(delegate(object o, EventArgs evt)
			{
			}, null);
			this.mDeleteScriptMessageWindow.Owner = this.CanvasWindow;
			this.mDeleteScriptMessageWindow.ShowDialog();
			e.Handled = true;
		}

		// Token: 0x06000C68 RID: 3176 RVA: 0x0005103C File Offset: 0x0004F23C
		private void UpdateSettingsAndDeleteScheme(object sender, EventArgs e)
		{
			this.ParentWindow.EngineInstanceRegistry.ShowSchemeDeletePopup = !this.mDeleteScriptMessageWindow.CheckBox.IsChecked.Value;
			this.mDeleteScriptMessageWindow = null;
			this.DeleteControlScheme();
		}

		// Token: 0x06000C69 RID: 3177 RVA: 0x00051084 File Offset: 0x0004F284
		private void DeleteControlScheme()
		{
			if (this.ParentWindow.SelectedConfig.ControlSchemesDict.ContainsKey(this.mSchemeName.Text) && !this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeName.Text].BuiltIn)
			{
				if (this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeName.Text].Selected)
				{
					this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeName.Text].Selected = false;
					if (this.ParentWindow.SelectedConfig.ControlSchemes.Count > 1)
					{
						if (this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem == (this.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children[0] as ComboBoxSchemeControl).mSchemeName.Text.ToString(CultureInfo.InvariantCulture))
						{
							this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem = (this.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children[1] as ComboBoxSchemeControl).mSchemeName.Text.ToString(CultureInfo.InvariantCulture);
						}
						else
						{
							this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem = (this.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children[0] as ComboBoxSchemeControl).mSchemeName.Text.ToString(CultureInfo.InvariantCulture);
						}
						this.ParentWindow.SelectedConfig.ControlSchemesDict[this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem].Selected = true;
						this.CanvasWindow.SidebarWindow.mSchemeComboBox.mName.Text = this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem;
						this.ParentWindow.SelectedConfig.SelectedControlScheme = this.ParentWindow.SelectedConfig.ControlSchemesDict[this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem];
						this.CanvasWindow.SidebarWindow.ProfileChanged();
					}
					else
					{
						this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem = null;
						BlueStacksUIBinding.Bind(this.CanvasWindow.SidebarWindow.mSchemeComboBox.mName, "Custom", "");
					}
				}
				this.ParentWindow.SelectedConfig.ControlSchemes.Remove(this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeName.Text]);
				this.ParentWindow.SelectedConfig.ControlSchemesDict.Remove(this.mSchemeName.Text);
				ComboBoxSchemeControl comboBoxSchemeControlFromName = KMManager.GetComboBoxSchemeControlFromName(this.mSchemeName.Text);
				if (comboBoxSchemeControlFromName != null)
				{
					this.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children.Remove(comboBoxSchemeControlFromName);
				}
				KeymapCanvasWindow.sIsDirty = true;
				this.CanvasWindow.SidebarWindow.FillProfileCombo();
				if (this.ParentWindow.SelectedConfig.ControlSchemes.Count == 0)
				{
					this.CanvasWindow.ClearWindow();
				}
			}
		}

		// Token: 0x06000C6A RID: 3178 RVA: 0x000513E8 File Offset: 0x0004F5E8
		private void ComboBoxItem_MouseDown(object sender, MouseButtonEventArgs e)
		{
			bool flag = false;
			foreach (object obj in this.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children)
			{
				ComboBoxSchemeControl comboBoxSchemeControl = (ComboBoxSchemeControl)obj;
				if (!comboBoxSchemeControl.mSchemeName.IsReadOnly)
				{
					this.HandleNameEdit(comboBoxSchemeControl);
					flag = true;
					e.Handled = true;
					break;
				}
			}
			if (!flag)
			{
				if (this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem == this.mSchemeName.Text)
				{
					this.CanvasWindow.SidebarWindow.mSchemeComboBox.mItems.IsOpen = false;
					return;
				}
				if (this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem != null)
				{
					this.ParentWindow.SelectedConfig.ControlSchemesDict[this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem].Selected = false;
				}
				this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeName.Text].Selected = true;
				this.ParentWindow.SelectedConfig.ControlSchemesDict[this.ParentWindow.SelectedConfig.SelectedControlScheme.Name].Selected = false;
				this.ParentWindow.SelectedConfig.SelectedControlScheme = this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeName.Text];
				this.CanvasWindow.SidebarWindow.FillProfileCombo();
				this.CanvasWindow.SidebarWindow.ProfileChanged();
				this.CanvasWindow.SidebarWindow.mSchemeComboBox.mItems.IsOpen = false;
				KeymapCanvasWindow.sIsDirty = true;
				KMManager.SendSchemeChangedStats(this.ParentWindow, "controls_editor");
			}
		}

		// Token: 0x06000C6B RID: 3179 RVA: 0x00005F17 File Offset: 0x00004117
		private void ComboBoxItem_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x06000C6C RID: 3180 RVA: 0x000515D8 File Offset: 0x0004F7D8
		private void ComboBoxItem_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.mSchemeName.Text != this.CanvasWindow.SidebarWindow.mSchemeComboBox.SelectedItem)
			{
				BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "ComboBoxBackgroundColor");
				return;
			}
			BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "ContextMenuItemBackgroundSelectedColor");
		}

		// Token: 0x06000C6D RID: 3181 RVA: 0x00009903 File Offset: 0x00007B03
		private void ComboBoxItem_LostFocus(object sender, RoutedEventArgs e)
		{
			if (this.mSchemeName.Focusable)
			{
				this.HandleNameEdit(this);
			}
			e.Handled = true;
		}

		// Token: 0x06000C6E RID: 3182 RVA: 0x00051630 File Offset: 0x0004F830
		private void HandleNameEdit(ComboBoxSchemeControl control)
		{
			control.mEditImg.Visibility = Visibility.Visible;
			control.mSaveImg.Visibility = Visibility.Collapsed;
			if (this.EditedNameIsAllowed(control.mSchemeName.Text, control))
			{
				if (this.ParentWindow.SelectedConfig.ControlSchemesDict.ContainsKey(control.mOldSchemeName))
				{
					IMControlScheme imcontrolScheme = this.ParentWindow.SelectedConfig.ControlSchemesDict[control.mOldSchemeName];
					imcontrolScheme.Name = control.mSchemeName.Text.Trim();
					this.ParentWindow.SelectedConfig.ControlSchemesDict.Remove(control.mOldSchemeName);
					this.ParentWindow.SelectedConfig.ControlSchemesDict.Add(imcontrolScheme.Name, imcontrolScheme);
					this.CanvasWindow.SidebarWindow.FillProfileCombo();
					KeymapCanvasWindow.sIsDirty = true;
				}
			}
			else
			{
				control.mSchemeName.Text = control.mOldSchemeName;
			}
			control.mSchemeName.Focusable = false;
			control.mSchemeName.IsReadOnly = true;
		}

		// Token: 0x06000C6F RID: 3183 RVA: 0x00009920 File Offset: 0x00007B20
		private void MSchemeName_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Return)
			{
				this.HandleNameEdit(this);
			}
		}

		// Token: 0x06000C70 RID: 3184 RVA: 0x00051738 File Offset: 0x0004F938
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/comboboxschemecontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000C71 RID: 3185 RVA: 0x00051768 File Offset: 0x0004F968
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((ComboBoxSchemeControl)target).MouseDown += this.ComboBoxItem_MouseDown;
				((ComboBoxSchemeControl)target).MouseEnter += this.ComboBoxItem_MouseEnter;
				((ComboBoxSchemeControl)target).MouseLeave += this.ComboBoxItem_MouseLeave;
				((ComboBoxSchemeControl)target).LostFocus += this.ComboBoxItem_LostFocus;
				return;
			case 2:
				this.mSchemeControl = (Grid)target;
				return;
			case 3:
				this.mBookmarkImg = (CustomPictureBox)target;
				this.mBookmarkImg.MouseDown += this.Bookmark_img_MouseDown;
				return;
			case 4:
				this.mSchemeName = (CustomTextBox)target;
				this.mSchemeName.KeyUp += this.MSchemeName_KeyUp;
				return;
			case 5:
				this.mEditImg = (CustomPictureBox)target;
				this.mEditImg.MouseDown += this.EditImg_MouseDown;
				return;
			case 6:
				this.mSaveImg = (CustomPictureBox)target;
				this.mSaveImg.MouseDown += this.SaveImg_MouseDown;
				return;
			case 7:
				this.mCopyImg = (CustomPictureBox)target;
				this.mCopyImg.MouseDown += this.CopyImg_MouseDown;
				return;
			case 8:
				this.mDeleteImg = (CustomPictureBox)target;
				this.mDeleteImg.MouseDown += this.DeleteImg_MouseDown;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000845 RID: 2117
		private KeymapCanvasWindow CanvasWindow;

		// Token: 0x04000846 RID: 2118
		private MainWindow ParentWindow;

		// Token: 0x04000847 RID: 2119
		private CustomMessageWindow mDeleteScriptMessageWindow;

		// Token: 0x04000848 RID: 2120
		internal string mOldSchemeName;

		// Token: 0x04000849 RID: 2121
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mSchemeControl;

		// Token: 0x0400084A RID: 2122
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mBookmarkImg;

		// Token: 0x0400084B RID: 2123
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mSchemeName;

		// Token: 0x0400084C RID: 2124
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mEditImg;

		// Token: 0x0400084D RID: 2125
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mSaveImg;

		// Token: 0x0400084E RID: 2126
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCopyImg;

		// Token: 0x0400084F RID: 2127
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mDeleteImg;

		// Token: 0x04000850 RID: 2128
		private bool _contentLoaded;
	}
}
