﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000F4 RID: 244
	public class DeviceProfileControl : UserControl, IComponentConnector
	{
		// Token: 0x060009BF RID: 2495 RVA: 0x000387AC File Offset: 0x000369AC
		public DeviceProfileControl(MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			base.Visibility = Visibility.Hidden;
			base.IsVisibleChanged += this.DeviceProfileControl_IsVisibleChanged;
			this.mManufacturerTextBox.TextChanged += this.MManufacturerTextBox_TextChanged;
			this.mModelNumberTextBox.TextChanged += this.MManufacturerTextBox_TextChanged;
			this.mBrandTextBox.TextChanged += this.MManufacturerTextBox_TextChanged;
			if (PromotionObject.Instance.IsRootAccessEnabled || FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.mRootAccessGrid.Visibility = Visibility.Visible;
				MainWindow parentWindow = this.ParentWindow;
				this.mCurrentRootAccessStatus = this.GetRootAccessStatusFromAndroid((parentWindow != null) ? parentWindow.mVmName : null);
				this.mEnableRootAccessCheckBox.IsChecked = new bool?(this.mCurrentRootAccessStatus);
			}
			this.mScrollBar.ScrollChanged += BluestacksUIColor.ScrollBarScrollChanged;
			this.mGettingProfilesFromCloud = false;
		}

		// Token: 0x060009C0 RID: 2496 RVA: 0x000388CC File Offset: 0x00036ACC
		private bool GetRootAccessStatusFromAndroid(string vmname)
		{
			bool result;
			try
			{
				Dictionary<string, string> data = new Dictionary<string, string>
				{
					{
						"d",
						"bst.config.bindmount"
					}
				};
				JObject jobject = JObject.Parse(HTTPUtils.SendRequestToGuest("getprop", data, vmname, 0, null, false, 1, 0));
				if (string.Equals(jobject["result"].ToString(), "ok", StringComparison.InvariantCulture))
				{
					if (string.Equals(jobject["value"].ToString(), "1", StringComparison.InvariantCulture))
					{
						result = true;
					}
					else
					{
						result = false;
					}
				}
				else
				{
					result = false;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Getting root status from android: " + ex.ToString());
				result = false;
			}
			return result;
		}

		// Token: 0x060009C1 RID: 2497 RVA: 0x00038978 File Offset: 0x00036B78
		private void ChangeLoadingGridVisibility(bool state)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (state)
				{
					this.mProfileLoader.Visibility = Visibility.Visible;
					this.mNoInternetWarning.Visibility = Visibility.Collapsed;
					this.mChildGrid.Visibility = Visibility.Collapsed;
					this.mMobileOperatorGrid.Visibility = Visibility.Collapsed;
					this.mTryAgainBtnGrid.Visibility = Visibility.Collapsed;
					return;
				}
				this.mProfileLoader.Visibility = Visibility.Collapsed;
				this.mNoInternetWarning.Visibility = Visibility.Collapsed;
				this.mChildGrid.Visibility = Visibility.Visible;
				if (RegistryManager.Instance.IsCacodeValid)
				{
					this.mMobileOperatorGrid.Visibility = Visibility.Visible;
				}
				this.mTryAgainBtnGrid.Visibility = Visibility.Collapsed;
			}), new object[0]);
		}

		// Token: 0x060009C2 RID: 2498 RVA: 0x000389B8 File Offset: 0x00036BB8
		private void ChangeNoInternetGridVisibility(bool state)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (state)
				{
					this.mProfileLoader.Visibility = Visibility.Collapsed;
					this.mNoInternetWarning.Visibility = Visibility.Visible;
					this.mChildGrid.Visibility = Visibility.Collapsed;
					this.mMobileOperatorGrid.Visibility = Visibility.Collapsed;
					this.mTryAgainBtnGrid.Visibility = Visibility.Visible;
					return;
				}
				this.mProfileLoader.Visibility = Visibility.Visible;
				this.mNoInternetWarning.Visibility = Visibility.Collapsed;
				this.mChildGrid.Visibility = Visibility.Collapsed;
				this.mMobileOperatorGrid.Visibility = Visibility.Collapsed;
				this.mTryAgainBtnGrid.Visibility = Visibility.Collapsed;
			}), new object[0]);
		}

		// Token: 0x060009C3 RID: 2499 RVA: 0x000389F8 File Offset: 0x00036BF8
		private void DeviceProfileControl_IsVisibleChanged(object _1, DependencyPropertyChangedEventArgs _2)
		{
			if (base.IsVisible)
			{
				if (!this.mGettingProfilesFromCloud)
				{
					this.mGettingProfilesFromCloud = true;
					this.ChangeLoadingGridVisibility(true);
					this.ChangeNoInternetGridVisibility(false);
					this.GetPreDefinedProfilesFromCloud();
					return;
				}
			}
			else
			{
				this.mSaveChangesBtn.IsEnabled = false;
				this.mEnableRootAccessCheckBox.IsChecked = new bool?(this.mCurrentRootAccessStatus);
			}
		}

		// Token: 0x060009C4 RID: 2500 RVA: 0x00038A54 File Offset: 0x00036C54
		private void SetUIAccordingToCurrentDeviceProfile()
		{
			this.mPredefinedProfilesComboBox.SelectionChanged -= this.mPredefinedProfilesComboBox_SelectionChanged;
			this.mMobileOperatorsCombobox.SelectionChanged -= this.MobileOperatorsCombobox_SelectionChanged;
			if (this.mCurrentDeviceProfileObject == null)
			{
				this.mPredefinedProfilesComboBox.Visibility = Visibility.Visible;
				this.mCustomProfileGrid.Visibility = Visibility.Collapsed;
			}
			else
			{
				JToken jtoken = this.mCurrentDeviceProfileObject["pcode"];
				if (string.Equals((jtoken != null) ? jtoken.ToString() : null, "custom", StringComparison.InvariantCulture))
				{
					this.mPredefinedProfilesComboBox.Visibility = Visibility.Collapsed;
					this.mCustomProfileGrid.Visibility = Visibility.Visible;
					this.mModelNumberTextBox.Text = this.mCurrentDeviceProfileObject["model"].ToString();
					this.mBrandTextBox.Text = this.mCurrentDeviceProfileObject["brand"].ToString();
					this.mManufacturerTextBox.Text = this.mCurrentDeviceProfileObject["manufacturer"].ToString();
					this.mCustomProfile.IsChecked = new bool?(true);
					this.mPredefinedProfilesComboBox.SelectedItem = null;
				}
				else
				{
					this.mPredefinedProfilesComboBox.Visibility = Visibility.Visible;
					this.mCustomProfileGrid.Visibility = Visibility.Collapsed;
					Dictionary<string, ComboBoxItem> dictionary = this.mDeviceProfileComboBoxItems;
					JToken jtoken2 = this.mCurrentDeviceProfileObject["pcode"];
					if (dictionary.ContainsKey((jtoken2 != null) ? jtoken2.ToString() : null))
					{
						this.mPredefinedProfilesComboBox.SelectedItem = this.mDeviceProfileComboBoxItems[this.mCurrentDeviceProfileObject["pcode"].ToString()];
					}
					this.mChooseProfile.IsChecked = new bool?(true);
					this.mModelNumberTextBox.Text = string.Empty;
					this.mBrandTextBox.Text = string.Empty;
					this.mManufacturerTextBox.Text = string.Empty;
				}
				Dictionary<string, ComboBoxItem> dictionary2 = this.mMobileOperatorComboboxItems;
				JToken jtoken3 = this.mCurrentDeviceProfileObject["caSelector"];
				if (dictionary2.ContainsKey((jtoken3 != null) ? jtoken3.ToString() : null))
				{
					this.mMobileOperatorsCombobox.SelectedItem = this.mMobileOperatorComboboxItems[this.mCurrentDeviceProfileObject["caSelector"].ToString()];
				}
			}
			this.mMobileOperatorsCombobox.SelectionChanged += this.MobileOperatorsCombobox_SelectionChanged;
			this.mPredefinedProfilesComboBox.SelectionChanged += this.mPredefinedProfilesComboBox_SelectionChanged;
			this.ChangeLoadingGridVisibility(false);
		}

		// Token: 0x060009C5 RID: 2501 RVA: 0x00008311 File Offset: 0x00006511
		private void GetPreDefinedProfilesFromCloud()
		{
			new Thread(delegate()
			{
				try
				{
					this.GetCurrentDeviceProfileFromAndroid(this.ParentWindow.mVmName);
					if (this.mPreDefinedProfilesList.Count == 0 || this.mMobileOperatorsList.Count == 0)
					{
						string url = string.Format(CultureInfo.InvariantCulture, "{0}/{1}/{2}", new object[]
						{
							RegistryManager.Instance.Host,
							"bs4",
							"get_device_profile_list"
						});
						Dictionary<string, string> commonPOSTData = WebHelper.GetCommonPOSTData();
						commonPOSTData.Add("ca_code", Utils.GetValueInBootParams("caCode", this.ParentWindow.mVmName, ""));
						JObject jobject = JObject.Parse(BstHttpClient.Post(url, commonPOSTData, null, false, this.ParentWindow.mVmName, 0, 1, 0, false));
						if (jobject != null && (bool)jobject["success"])
						{
							if (!JsonExtensions.IsNullOrEmptyBrackets(jobject["device_profile_list"].ToString()))
							{
								foreach (JObject jobject2 in jobject["device_profile_list"].ToArray<JToken>())
								{
									this.mPreDefinedProfilesList[jobject2["pcode"].ToString()] = jobject2["display_name"].ToString();
								}
							}
							if (jobject.ContainsKey("ca_selector_list") && !JsonExtensions.IsNullOrEmptyBrackets(jobject["ca_selector_list"].ToString()))
							{
								foreach (JObject jobject3 in jobject["ca_selector_list"].ToArray<JToken>())
								{
									this.mMobileOperatorsList[jobject3["ca_selector"].ToString()] = jobject3["display_name"].ToString();
								}
							}
							this.AddPreDefinedProfilesinComboBox();
						}
					}
					else
					{
						this.AddPreDefinedProfilesinComboBox();
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Error while getting device profile from cloud : " + ex.ToString());
					this.ChangeNoInternetGridVisibility(true);
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060009C6 RID: 2502 RVA: 0x00008330 File Offset: 0x00006530
		internal void GetCurrentDeviceProfileFromAndroid(string vmName)
		{
			if (string.Equals(VmCmdHandler.SendRequest("currentdeviceprofile", null, vmName, out this.mCurrentDeviceProfileObject), "ok", StringComparison.InvariantCulture))
			{
				this.mCurrentDeviceProfileObject.Remove("result");
			}
		}

		// Token: 0x060009C7 RID: 2503 RVA: 0x00008362 File Offset: 0x00006562
		private void AddPreDefinedProfilesinComboBox()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				foreach (string key in this.mPreDefinedProfilesList.Keys)
				{
					ComboBoxItem comboBoxItem = new ComboBoxItem
					{
						Content = this.mPreDefinedProfilesList[key]
					};
					this.mPredefinedProfilesComboBox.Items.Add(comboBoxItem);
					if (this.mDeviceProfileComboBoxItems.ContainsKey(key))
					{
						this.mDeviceProfileComboBoxItems[key] = comboBoxItem;
					}
					else
					{
						this.mDeviceProfileComboBoxItems.Add(key, comboBoxItem);
					}
				}
				foreach (string key2 in this.mMobileOperatorsList.Keys)
				{
					ComboBoxItem comboBoxItem2 = new ComboBoxItem
					{
						Content = this.mMobileOperatorsList[key2]
					};
					this.mMobileOperatorsCombobox.Items.Add(comboBoxItem2);
					this.mMobileOperatorComboboxItems[key2] = comboBoxItem2;
				}
				this.SetUIAccordingToCurrentDeviceProfile();
			}), new object[0]);
		}

		// Token: 0x060009C8 RID: 2504 RVA: 0x00038CB0 File Offset: 0x00036EB0
		private void Profile_Checked(object sender, RoutedEventArgs e)
		{
			if (this.mChooseProfile.IsChecked.Value)
			{
				this.mPredefinedProfilesComboBox.Visibility = Visibility.Visible;
				this.mCustomProfileGrid.Visibility = Visibility.Collapsed;
				return;
			}
			if (this.mCustomProfile.IsChecked.Value)
			{
				this.mPredefinedProfilesComboBox.Visibility = Visibility.Collapsed;
				this.mCustomProfileGrid.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x060009C9 RID: 2505 RVA: 0x00038D18 File Offset: 0x00036F18
		private void mPredefinedProfilesComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			string text;
			JObject changedDeviceProfileObject = this.GetChangedDeviceProfileObject(out text);
			UIElement uielement = this.mSaveChangesBtn;
			bool isEnabled;
			if (JToken.DeepEquals(this.mCurrentDeviceProfileObject, changedDeviceProfileObject))
			{
				bool? isChecked = this.mEnableRootAccessCheckBox.IsChecked;
				bool flag = this.mCurrentRootAccessStatus;
				isEnabled = !(isChecked.GetValueOrDefault() == flag & isChecked != null);
			}
			else
			{
				isEnabled = true;
			}
			uielement.IsEnabled = isEnabled;
		}

		// Token: 0x060009CA RID: 2506 RVA: 0x00038D18 File Offset: 0x00036F18
		private void MManufacturerTextBox_TextChanged(object sender, TextChangedEventArgs e)
		{
			string text;
			JObject changedDeviceProfileObject = this.GetChangedDeviceProfileObject(out text);
			UIElement uielement = this.mSaveChangesBtn;
			bool isEnabled;
			if (JToken.DeepEquals(this.mCurrentDeviceProfileObject, changedDeviceProfileObject))
			{
				bool? isChecked = this.mEnableRootAccessCheckBox.IsChecked;
				bool flag = this.mCurrentRootAccessStatus;
				isEnabled = !(isChecked.GetValueOrDefault() == flag & isChecked != null);
			}
			else
			{
				isEnabled = true;
			}
			uielement.IsEnabled = isEnabled;
		}

		// Token: 0x060009CB RID: 2507 RVA: 0x00038D74 File Offset: 0x00036F74
		private JObject GetChangedDeviceProfileObject(out string jsonString)
		{
			jsonString = "{";
			JObject jobject = new JObject();
			string text = this.mCurrentDeviceProfileObject["pcode"].ToString();
			string text2 = this.mCurrentDeviceProfileObject["caSelector"].ToString();
			if (this.mChooseProfile.IsChecked.Value)
			{
				if (this.mPredefinedProfilesComboBox.SelectedItem != null)
				{
					string selectedDeviceProfile = (this.mPredefinedProfilesComboBox.SelectedItem as ComboBoxItem).Content.ToString();
					text = this.mPreDefinedProfilesList.FirstOrDefault((KeyValuePair<string, string> x) => x.Value == selectedDeviceProfile).Key;
				}
				jsonString += string.Format(CultureInfo.InvariantCulture, "\"createcustomprofile\":\"{0}\",", new object[]
				{
					"false"
				});
				jsonString += string.Format(CultureInfo.InvariantCulture, "\"pcode\":\"{0}\",", new object[]
				{
					text
				});
				jobject["pcode"] = text;
			}
			else
			{
				jsonString += string.Format(CultureInfo.InvariantCulture, "\"createcustomprofile\":\"{0}\",", new object[]
				{
					"true"
				});
				jsonString += string.Format(CultureInfo.InvariantCulture, "\"model\":\"{0}\",", new object[]
				{
					this.mModelNumberTextBox.Text
				});
				jsonString += string.Format(CultureInfo.InvariantCulture, "\"brand\":\"{0}\",", new object[]
				{
					this.mBrandTextBox.Text
				});
				jsonString += string.Format(CultureInfo.InvariantCulture, "\"manufacturer\":\"{0}\",", new object[]
				{
					this.mManufacturerTextBox.Text
				});
				jobject["pcode"] = "custom";
				jobject["model"] = this.mModelNumberTextBox.Text;
				jobject["brand"] = this.mBrandTextBox.Text;
				jobject["manufacturer"] = this.mManufacturerTextBox.Text;
			}
			if (this.mMobileOperatorsCombobox.SelectedItem != null)
			{
				string selectedMobileOperator = (this.mMobileOperatorsCombobox.SelectedItem as ComboBoxItem).Content.ToString();
				if (!string.IsNullOrEmpty(selectedMobileOperator))
				{
					text2 = this.mMobileOperatorsList.FirstOrDefault((KeyValuePair<string, string> x) => x.Value == selectedMobileOperator).Key;
				}
			}
			jsonString += string.Format(CultureInfo.InvariantCulture, "\"caSelector\":\"{0}\"", new object[]
			{
				text2
			});
			jsonString += "}";
			jobject.Add("caSelector", text2);
			return jobject;
		}

		// Token: 0x060009CC RID: 2508 RVA: 0x00039040 File Offset: 0x00037240
		private void SaveChangesBtn_Click(object sender, RoutedEventArgs e)
		{
			this.mSaveChangesBtn.IsEnabled = false;
			string json;
			JObject changedDeviceProfileObject = this.GetChangedDeviceProfileObject(out json);
			this.SendDeviceProfileChangeToGuest(json, changedDeviceProfileObject);
			bool? isChecked = this.mEnableRootAccessCheckBox.IsChecked;
			bool flag = this.mCurrentRootAccessStatus;
			if (!(isChecked.GetValueOrDefault() == flag & isChecked != null))
			{
				string res = null;
				new Thread(delegate()
				{
					try
					{
						if (!this.mCurrentRootAccessStatus)
						{
							res = HTTPUtils.SendRequestToGuest("bindmount", null, this.ParentWindow.mVmName, 0, null, false, 1, 0);
						}
						else
						{
							res = HTTPUtils.SendRequestToGuest("unbindmount", null, this.ParentWindow.mVmName, 0, null, false, 1, 0);
						}
						if (string.Equals(JObject.Parse(res)["result"].ToString(), "ok", StringComparison.InvariantCulture))
						{
							this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_CHANGES_SAVED"));
							this.mCurrentRootAccessStatus = !this.mCurrentRootAccessStatus;
							this.SendStatsOfRootAccessStatusAsync("success", this.mCurrentRootAccessStatus);
							if (SecurityMetrics.SecurityMetricsInstanceList.ContainsKey(this.ParentWindow.mVmName) && this.mCurrentRootAccessStatus)
							{
								SecurityMetrics.SecurityMetricsInstanceList[this.ParentWindow.mVmName].AddSecurityBreach(SecurityBreach.DEVICE_ROOTED, string.Empty);
							}
						}
						else
						{
							this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_ROOT_ACCESS_FAILURE"));
							this.Dispatcher.Invoke(new Action(delegate()
							{
								this.mEnableRootAccessCheckBox.IsChecked = new bool?(this.mCurrentRootAccessStatus);
							}), new object[0]);
							this.SendStatsOfRootAccessStatusAsync("failed", this.mCurrentRootAccessStatus);
						}
						ClientStats.SendMiscellaneousStatsAsync("Setting-save", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "Advanced-Settings", "", null, this.ParentWindow.mVmName, null, null);
					}
					catch (Exception ex)
					{
						Logger.Error("Exception in sending mount unmount request to Android: " + ex.ToString());
					}
				})
				{
					IsBackground = true
				}.Start();
			}
		}

		// Token: 0x060009CD RID: 2509 RVA: 0x000390C0 File Offset: 0x000372C0
		private void AddToastPopup(string message)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (this.mToastPopup == null)
				{
					this.mToastPopup = new CustomToastPopupControl(this);
				}
				Thickness value = new Thickness(0.0, 0.0, 0.0, 50.0);
				this.mToastPopup.Init(this, message, null, null, HorizontalAlignment.Center, VerticalAlignment.Bottom, new Thickness?(value), 12, null, null);
				this.mToastPopup.ShowPopup(1.3);
			}), new object[0]);
		}

		// Token: 0x060009CE RID: 2510 RVA: 0x00039100 File Offset: 0x00037300
		private static void SendStatsOfDeviceProfileChangeAsync(string successString, JObject newDeviceProfile, JObject oldDeviceProfile)
		{
			ClientStats.SendMiscellaneousStatsAsync("DeviceProfileChangeStats", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, successString, JsonConvert.SerializeObject(newDeviceProfile), JsonConvert.SerializeObject(oldDeviceProfile), RegistryManager.Instance.Version, "DeviceProfileSetting", null);
		}

		// Token: 0x060009CF RID: 2511 RVA: 0x00039148 File Offset: 0x00037348
		private void SendStatsOfRootAccessStatusAsync(string successString, bool rootedstatus)
		{
			string arg = rootedstatus ? "Rooted" : "Unrooted";
			ClientStats.SendMiscellaneousStatsAsync("DeviceRootingStats", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, successString, arg, this.ParentWindow.mVmName, null, null);
		}

		// Token: 0x060009D0 RID: 2512 RVA: 0x00008382 File Offset: 0x00006582
		private void TryAgainBtn_Click(object sender, RoutedEventArgs e)
		{
			this.ChangeNoInternetGridVisibility(false);
			this.ChangeLoadingGridVisibility(true);
			this.GetPreDefinedProfilesFromCloud();
		}

		// Token: 0x060009D1 RID: 2513 RVA: 0x00038D18 File Offset: 0x00036F18
		private void mEnableRootAccessCheckBox_Click(object sender, RoutedEventArgs e)
		{
			string text;
			JObject changedDeviceProfileObject = this.GetChangedDeviceProfileObject(out text);
			UIElement uielement = this.mSaveChangesBtn;
			bool isEnabled;
			if (JToken.DeepEquals(this.mCurrentDeviceProfileObject, changedDeviceProfileObject))
			{
				bool? isChecked = this.mEnableRootAccessCheckBox.IsChecked;
				bool flag = this.mCurrentRootAccessStatus;
				isEnabled = !(isChecked.GetValueOrDefault() == flag & isChecked != null);
			}
			else
			{
				isEnabled = true;
			}
			uielement.IsEnabled = isEnabled;
		}

		// Token: 0x060009D2 RID: 2514 RVA: 0x0003919C File Offset: 0x0003739C
		private void SendDeviceProfileChangeToGuest(string json, JObject changedDeviceProfileObject)
		{
			if (Utils.CheckIfDeviceProfileChanged(this.mCurrentDeviceProfileObject, changedDeviceProfileObject))
			{
				string command = string.Format(CultureInfo.InvariantCulture, "{0} {1}", new object[]
				{
					"changeDeviceProfile",
					json
				});
				Logger.Info("Command for device profile change: " + command);
				new Thread(delegate()
				{
					try
					{
						string text = VmCmdHandler.RunCommand(command, this.ParentWindow.mVmName);
						Logger.Info("Result for device profile change command: " + text);
						if (string.Equals(text, "ok", StringComparison.InvariantCulture))
						{
							this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_CHANGES_SAVED"));
							DeviceProfileControl.SendStatsOfDeviceProfileChangeAsync("success", changedDeviceProfileObject, this.mCurrentDeviceProfileObject);
							this.mCurrentDeviceProfileObject = changedDeviceProfileObject;
							Utils.UpdateValueInBootParams("pcode", changedDeviceProfileObject["pcode"].ToString(), this.ParentWindow.mVmName, false);
							Utils.UpdateValueInBootParams("caSelector", changedDeviceProfileObject["caSelector"].ToString(), this.ParentWindow.mVmName, false);
							if (SecurityMetrics.SecurityMetricsInstanceList.ContainsKey(this.ParentWindow.mVmName))
							{
								SecurityMetrics.SecurityMetricsInstanceList[this.ParentWindow.mVmName].AddSecurityBreach(SecurityBreach.DEVICE_PROFILE_CHANGED, string.Empty);
							}
						}
						else
						{
							this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_SWITCH_PROFILE_FAILED"));
							DeviceProfileControl.SendStatsOfDeviceProfileChangeAsync("failed", changedDeviceProfileObject, this.mCurrentDeviceProfileObject);
						}
						this.Dispatcher.Invoke(new Action(delegate()
						{
							this.SetUIAccordingToCurrentDeviceProfile();
						}), new object[0]);
					}
					catch (Exception ex)
					{
						Logger.Error("Exception in change to predefined Pcode call to android: " + ex.ToString());
					}
				})
				{
					IsBackground = true
				}.Start();
			}
		}

		// Token: 0x060009D3 RID: 2515 RVA: 0x00038D18 File Offset: 0x00036F18
		private void MobileOperatorsCombobox_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			string text;
			JObject changedDeviceProfileObject = this.GetChangedDeviceProfileObject(out text);
			UIElement uielement = this.mSaveChangesBtn;
			bool isEnabled;
			if (JToken.DeepEquals(this.mCurrentDeviceProfileObject, changedDeviceProfileObject))
			{
				bool? isChecked = this.mEnableRootAccessCheckBox.IsChecked;
				bool flag = this.mCurrentRootAccessStatus;
				isEnabled = !(isChecked.GetValueOrDefault() == flag & isChecked != null);
			}
			else
			{
				isEnabled = true;
			}
			uielement.IsEnabled = isEnabled;
		}

		// Token: 0x060009D4 RID: 2516 RVA: 0x00039238 File Offset: 0x00037438
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/deviceprofilecontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060009D5 RID: 2517 RVA: 0x00039268 File Offset: 0x00037468
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mScrollBar = (ScrollViewer)target;
				return;
			case 2:
				this.mProfileLoader = (Border)target;
				return;
			case 3:
				this.mNoInternetWarning = (Border)target;
				return;
			case 4:
				this.mChildGrid = (Grid)target;
				return;
			case 5:
				this.mChooseProfile = (CustomRadioButton)target;
				this.mChooseProfile.Checked += this.Profile_Checked;
				return;
			case 6:
				this.mPredefinedProfilesComboBox = (CustomComboBox)target;
				this.mPredefinedProfilesComboBox.SelectionChanged += this.mPredefinedProfilesComboBox_SelectionChanged;
				return;
			case 7:
				this.mCustomProfile = (CustomRadioButton)target;
				this.mCustomProfile.Checked += this.Profile_Checked;
				return;
			case 8:
				this.mCustomProfileGrid = (Grid)target;
				return;
			case 9:
				this.mManufacturerTextBox = (CustomTextBox)target;
				return;
			case 10:
				this.mBrandTextBox = (CustomTextBox)target;
				return;
			case 11:
				this.mModelNumberTextBox = (CustomTextBox)target;
				return;
			case 12:
				this.mTryAgainBtnGrid = (Grid)target;
				return;
			case 13:
				((CustomButton)target).Click += this.TryAgainBtn_Click;
				return;
			case 14:
				this.mMobileOperatorGrid = (Grid)target;
				return;
			case 15:
				this.mMobileOpertorText = (TextBlock)target;
				return;
			case 16:
				this.mMobileNetworkSetupText = (TextBlock)target;
				return;
			case 17:
				this.mMobileOperatorsCombobox = (CustomComboBox)target;
				this.mMobileOperatorsCombobox.SelectionChanged += this.MobileOperatorsCombobox_SelectionChanged;
				return;
			case 18:
				this.mRootAccessGrid = (Grid)target;
				return;
			case 19:
				this.mEnableRootAccessCheckBox = (CustomCheckbox)target;
				this.mEnableRootAccessCheckBox.Click += this.mEnableRootAccessCheckBox_Click;
				return;
			case 20:
				this.mInfoIcon = (CustomPictureBox)target;
				return;
			case 21:
				this.mSaveChangesBtn = (CustomButton)target;
				this.mSaveChangesBtn.Click += this.SaveChangesBtn_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000618 RID: 1560
		private JObject mCurrentDeviceProfileObject;

		// Token: 0x04000619 RID: 1561
		private Dictionary<string, string> mPreDefinedProfilesList = new Dictionary<string, string>();

		// Token: 0x0400061A RID: 1562
		private Dictionary<string, ComboBoxItem> mDeviceProfileComboBoxItems = new Dictionary<string, ComboBoxItem>();

		// Token: 0x0400061B RID: 1563
		private Dictionary<string, string> mMobileOperatorsList = new Dictionary<string, string>();

		// Token: 0x0400061C RID: 1564
		private Dictionary<string, ComboBoxItem> mMobileOperatorComboboxItems = new Dictionary<string, ComboBoxItem>();

		// Token: 0x0400061D RID: 1565
		private CustomToastPopupControl mToastPopup;

		// Token: 0x0400061E RID: 1566
		private MainWindow ParentWindow;

		// Token: 0x0400061F RID: 1567
		private bool mGettingProfilesFromCloud;

		// Token: 0x04000620 RID: 1568
		private bool mCurrentRootAccessStatus;

		// Token: 0x04000621 RID: 1569
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ScrollViewer mScrollBar;

		// Token: 0x04000622 RID: 1570
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mProfileLoader;

		// Token: 0x04000623 RID: 1571
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mNoInternetWarning;

		// Token: 0x04000624 RID: 1572
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mChildGrid;

		// Token: 0x04000625 RID: 1573
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mChooseProfile;

		// Token: 0x04000626 RID: 1574
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomComboBox mPredefinedProfilesComboBox;

		// Token: 0x04000627 RID: 1575
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mCustomProfile;

		// Token: 0x04000628 RID: 1576
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mCustomProfileGrid;

		// Token: 0x04000629 RID: 1577
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mManufacturerTextBox;

		// Token: 0x0400062A RID: 1578
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mBrandTextBox;

		// Token: 0x0400062B RID: 1579
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mModelNumberTextBox;

		// Token: 0x0400062C RID: 1580
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mTryAgainBtnGrid;

		// Token: 0x0400062D RID: 1581
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mMobileOperatorGrid;

		// Token: 0x0400062E RID: 1582
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mMobileOpertorText;

		// Token: 0x0400062F RID: 1583
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mMobileNetworkSetupText;

		// Token: 0x04000630 RID: 1584
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomComboBox mMobileOperatorsCombobox;

		// Token: 0x04000631 RID: 1585
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mRootAccessGrid;

		// Token: 0x04000632 RID: 1586
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mEnableRootAccessCheckBox;

		// Token: 0x04000633 RID: 1587
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mInfoIcon;

		// Token: 0x04000634 RID: 1588
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mSaveChangesBtn;

		// Token: 0x04000635 RID: 1589
		private bool _contentLoaded;
	}
}
