﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000080 RID: 128
	public enum QuitActionItemProperty
	{
		// Token: 0x040002B6 RID: 694
		ImageName,
		// Token: 0x040002B7 RID: 695
		BodyText,
		// Token: 0x040002B8 RID: 696
		CallToAction,
		// Token: 0x040002B9 RID: 697
		ActionText,
		// Token: 0x040002BA RID: 698
		ActionValue,
		// Token: 0x040002BB RID: 699
		StatEventName
	}
}
