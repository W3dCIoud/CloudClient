﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200009E RID: 158
	public class SchemeBookmarkControl : UserControl, IComponentConnector
	{
		// Token: 0x0600061A RID: 1562 RVA: 0x00024B5C File Offset: 0x00022D5C
		public SchemeBookmarkControl(IMControlScheme scheme, MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			this.mSchemeName.Text = ((scheme != null) ? scheme.Name : null);
			if (scheme.Selected)
			{
				this.mCheckbox.ImageName = "radio_selected";
				BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "ContextMenuItemBackgroundSelectedColor");
			}
		}

		// Token: 0x0600061B RID: 1563 RVA: 0x00005F17 File Offset: 0x00004117
		private void UserControl_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x0600061C RID: 1564 RVA: 0x00024BBC File Offset: 0x00022DBC
		private void UserControl_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme != null && this.mSchemeName.Text != this.ParentWindow.SelectedConfig.SelectedControlScheme.Name)
			{
				BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "ComboBoxBackgroundColor");
				return;
			}
			BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "ContextMenuItemBackgroundSelectedColor");
		}

		// Token: 0x0600061D RID: 1565 RVA: 0x00024C24 File Offset: 0x00022E24
		private void UserControl_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.mCheckbox.ImageName == "radio_unselected")
			{
				foreach (object obj in this.ParentWindow.mSidebar.mBookmarkedSchemesStackPanel.Children)
				{
					SchemeBookmarkControl schemeBookmarkControl = (SchemeBookmarkControl)obj;
					schemeBookmarkControl.mCheckbox.ImageName = "radio_unselected";
					BlueStacksUIBinding.BindColor(schemeBookmarkControl, Control.BackgroundProperty, "ComboBoxBackgroundColor");
				}
				this.mCheckbox.ImageName = "radio_selected";
				BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "SelectedTabBackgroundColor");
				KMManager.SelectSchemeIfPresent(this.ParentWindow, this.mSchemeName.Text, "bookmark", true);
			}
		}

		// Token: 0x0600061E RID: 1566 RVA: 0x00024CFC File Offset: 0x00022EFC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/schemebookmarkcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600061F RID: 1567 RVA: 0x00024D2C File Offset: 0x00022F2C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((SchemeBookmarkControl)target).MouseEnter += this.UserControl_MouseEnter;
				((SchemeBookmarkControl)target).MouseLeave += this.UserControl_MouseLeave;
				((SchemeBookmarkControl)target).MouseDown += this.UserControl_PreviewMouseDown;
				return;
			case 2:
				this.mCheckbox = (CustomPictureBox)target;
				return;
			case 3:
				this.mSchemeName = (CustomTextBox)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000358 RID: 856
		private MainWindow ParentWindow;

		// Token: 0x04000359 RID: 857
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCheckbox;

		// Token: 0x0400035A RID: 858
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mSchemeName;

		// Token: 0x0400035B RID: 859
		private bool _contentLoaded;
	}
}
