﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000DF RID: 223
	public class PikaNotificationControl : UserControl, IComponentConnector
	{
		// Token: 0x0600090A RID: 2314 RVA: 0x00007C6F File Offset: 0x00005E6F
		public PikaNotificationControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600090B RID: 2315 RVA: 0x000351E4 File Offset: 0x000333E4
		private void pikanotificationcontrol_MouseUp(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow != null && this.ParentWindow.mGuestBootCompleted)
			{
				this.ParentWindow.Utils.HandleGenericActionFromDictionary(this.mNotificationItem.ExtraPayload, "notification_ribbon", this.mNotificationItem.NotificationMenuImageName);
				ClientStats.SendMiscellaneousStatsAsync("RibbonClicked", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, this.mNotificationItem.Id, this.mNotificationItem.Title, JsonConvert.SerializeObject(this.mNotificationItem.ExtraPayload), null, null, null);
				GenericNotificationManager instance = GenericNotificationManager.Instance;
				List<string> list = new List<string>();
				list.Add(this.mNotificationItem.Id);
				instance.MarkNotification(list, delegate(GenericNotificationItem x)
				{
					x.IsRead = true;
				});
				IEnumerable<NotificationDrawerItem> source = from _ in (this.ParentWindow.mTopBar.mNotificationDrawerControl.mNotificationScroll.Content as StackPanel).Children.OfType<NotificationDrawerItem>()
				where _.Id == this.mNotificationItem.Id
				select _;
				if (source.Any<NotificationDrawerItem>())
				{
					source.First<NotificationDrawerItem>().ChangeToReadBackground();
				}
				this.ParentWindow.mTopBar.RefreshNotificationCentreButton();
				this.CloseClicked(sender, e);
			}
		}

		// Token: 0x0600090C RID: 2316 RVA: 0x0003532C File Offset: 0x0003352C
		private void ApplyHoverColors(bool hover)
		{
			if (hover)
			{
				if (string.IsNullOrEmpty(this.mNotificationItem.NotificationDesignItem.HoverBorderColor))
				{
					this.mNotificationItem.NotificationDesignItem.HoverBorderColor = this.mNotificationItem.NotificationDesignItem.BorderColor;
				}
				this.notificationBorder.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(this.mNotificationItem.NotificationDesignItem.HoverBorderColor));
				if (string.IsNullOrEmpty(this.mNotificationItem.NotificationDesignItem.HoverRibboncolor))
				{
					this.mNotificationItem.NotificationDesignItem.HoverRibboncolor = this.mNotificationItem.NotificationDesignItem.Ribboncolor;
				}
				this.ribbonStroke.Stroke = new SolidColorBrush((Color)ColorConverter.ConvertFromString(this.mNotificationItem.NotificationDesignItem.HoverBorderColor));
				this.ribbonBack.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString(this.mNotificationItem.NotificationDesignItem.HoverRibboncolor));
				if (this.mNotificationItem.NotificationDesignItem.HoverBackGroundGradient.Count == 0)
				{
					this.mNotificationItem.NotificationDesignItem.HoverBackGroundGradient.ClearAddRange(this.mNotificationItem.NotificationDesignItem.BackgroundGradient);
				}
				this.backgroundPanel.Background = new LinearGradientBrush(new GradientStopCollection(from _ in this.mNotificationItem.NotificationDesignItem.HoverBackGroundGradient
				select new GradientStop((Color)ColorConverter.ConvertFromString(_.Key), _.Value)));
				return;
			}
			this.notificationBorder.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(this.mNotificationItem.NotificationDesignItem.BorderColor));
			this.ribbonStroke.Stroke = new SolidColorBrush((Color)ColorConverter.ConvertFromString(this.mNotificationItem.NotificationDesignItem.BorderColor));
			this.ribbonBack.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString(this.mNotificationItem.NotificationDesignItem.Ribboncolor));
			this.backgroundPanel.Background = new LinearGradientBrush(new GradientStopCollection(from _ in this.mNotificationItem.NotificationDesignItem.BackgroundGradient
			select new GradientStop((Color)ColorConverter.ConvertFromString(_.Key), _.Value)));
		}

		// Token: 0x0600090D RID: 2317 RVA: 0x00035578 File Offset: 0x00033778
		internal void Init(GenericNotificationItem notifItem)
		{
			this.mNotificationItem = notifItem;
			this.titleText.Text = notifItem.Title;
			this.titleText.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(notifItem.NotificationDesignItem.TitleForeGroundColor));
			this.messageText.Text = notifItem.Message;
			this.messageText.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(notifItem.NotificationDesignItem.MessageForeGroundColor));
			this.notificationBorder.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(notifItem.NotificationDesignItem.BorderColor));
			this.ribbonStroke.Stroke = new SolidColorBrush((Color)ColorConverter.ConvertFromString(notifItem.NotificationDesignItem.BorderColor));
			if (notifItem.NotificationDesignItem.BackgroundGradient.Count == 0)
			{
				notifItem.NotificationDesignItem.BackgroundGradient.Add(new SerializableKeyValuePair<string, double>("#FFF350", 0.0));
				notifItem.NotificationDesignItem.BackgroundGradient.Add(new SerializableKeyValuePair<string, double>("#FFF8AF", 0.3));
				notifItem.NotificationDesignItem.BackgroundGradient.Add(new SerializableKeyValuePair<string, double>("#FFE940", 0.6));
				notifItem.NotificationDesignItem.BackgroundGradient.Add(new SerializableKeyValuePair<string, double>("#FCE74E", 0.8));
				notifItem.NotificationDesignItem.BackgroundGradient.Add(new SerializableKeyValuePair<string, double>("#FDF09C", 0.9));
				notifItem.NotificationDesignItem.BackgroundGradient.Add(new SerializableKeyValuePair<string, double>("#FFE227", 1.0));
			}
			this.backgroundPanel.Background = new LinearGradientBrush(new GradientStopCollection(from _ in notifItem.NotificationDesignItem.BackgroundGradient
			select new GradientStop((Color)ColorConverter.ConvertFromString(_.Key), _.Value)));
			if (string.IsNullOrEmpty(notifItem.NotificationDesignItem.Ribboncolor))
			{
				this.ribbonBack.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFF350"));
			}
			else
			{
				this.ribbonBack.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString(notifItem.NotificationDesignItem.Ribboncolor));
			}
			if (string.IsNullOrEmpty(notifItem.NotificationDesignItem.LeftGifName))
			{
				this.pikaGif.Visibility = Visibility.Collapsed;
			}
			else
			{
				this.pikaGif.Visibility = Visibility.Visible;
				this.pikaGif.ImageName = notifItem.NotificationDesignItem.LeftGifName;
			}
			Canvas.SetLeft(this, 0.0);
		}

		// Token: 0x0600090E RID: 2318 RVA: 0x00007C7D File Offset: 0x00005E7D
		private void PikaNotificationControl_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mCloseBtn.Visibility = Visibility.Hidden;
			this.ApplyHoverColors(false);
		}

		// Token: 0x0600090F RID: 2319 RVA: 0x00007C92 File Offset: 0x00005E92
		private void PikaNotificationControl_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mCloseBtn.Visibility = Visibility.Visible;
			this.ApplyHoverColors(true);
		}

		// Token: 0x14000008 RID: 8
		// (add) Token: 0x06000910 RID: 2320 RVA: 0x00035818 File Offset: 0x00033A18
		// (remove) Token: 0x06000911 RID: 2321 RVA: 0x00035850 File Offset: 0x00033A50
		public event EventHandler CloseClicked;

		// Token: 0x06000912 RID: 2322 RVA: 0x00007CA7 File Offset: 0x00005EA7
		private void CloseBtn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Pika notification close button clicked");
			this.CloseClicked(sender, e);
			e.Handled = true;
		}

		// Token: 0x06000913 RID: 2323 RVA: 0x00035888 File Offset: 0x00033A88
		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			try
			{
				if (File.Exists(System.IO.Path.Combine(RegistryStrings.PromotionDirectory, this.pikaGif.ImageName)))
				{
					ImageSource value = new BitmapImage(new Uri(System.IO.Path.Combine(RegistryStrings.PromotionDirectory, this.pikaGif.ImageName)));
					ImageBehavior.SetAnimatedSource(this.pikaGif, value);
				}
				else if (File.Exists(System.IO.Path.Combine(CustomPictureBox.AssetsDir, this.pikaGif.ImageName)))
				{
					ImageSource value2 = new BitmapImage(new Uri(System.IO.Path.Combine(CustomPictureBox.AssetsDir, this.pikaGif.ImageName)));
					ImageBehavior.SetAnimatedSource(this.pikaGif, value2);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while loading pika notification. " + ex.ToString());
			}
		}

		// Token: 0x06000914 RID: 2324 RVA: 0x00035954 File Offset: 0x00033B54
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/pikanotificationcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000915 RID: 2325 RVA: 0x00035984 File Offset: 0x00033B84
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((PikaNotificationControl)target).AddHandler(Mouse.MouseUpEvent, new MouseButtonEventHandler(this.pikanotificationcontrol_MouseUp));
				((PikaNotificationControl)target).MouseEnter += this.PikaNotificationControl_MouseEnter;
				((PikaNotificationControl)target).MouseLeave += this.PikaNotificationControl_MouseLeave;
				((PikaNotificationControl)target).Loaded += this.UserControl_Loaded;
				return;
			case 2:
				this.mNotificationGrid = (Grid)target;
				return;
			case 3:
				this.ribbonBack = (System.Windows.Shapes.Path)target;
				return;
			case 4:
				this.ribbonStroke = (System.Windows.Shapes.Path)target;
				return;
			case 5:
				this.backgroundPanel = (StackPanel)target;
				return;
			case 6:
				this.pikaGif = (CustomPictureBox)target;
				return;
			case 7:
				this.titleText = (TextBlock)target;
				return;
			case 8:
				this.messageText = (TextBlock)target;
				return;
			case 9:
				this.notificationBorder = (Border)target;
				return;
			case 10:
				this.mCloseBtn = (CustomPictureBox)target;
				this.mCloseBtn.MouseLeftButtonUp += this.CloseBtn_MouseLeftButtonUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400058F RID: 1423
		internal MainWindow ParentWindow;

		// Token: 0x04000590 RID: 1424
		private GenericNotificationItem mNotificationItem;

		// Token: 0x04000592 RID: 1426
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mNotificationGrid;

		// Token: 0x04000593 RID: 1427
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal System.Windows.Shapes.Path ribbonBack;

		// Token: 0x04000594 RID: 1428
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal System.Windows.Shapes.Path ribbonStroke;

		// Token: 0x04000595 RID: 1429
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel backgroundPanel;

		// Token: 0x04000596 RID: 1430
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox pikaGif;

		// Token: 0x04000597 RID: 1431
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock titleText;

		// Token: 0x04000598 RID: 1432
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock messageText;

		// Token: 0x04000599 RID: 1433
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border notificationBorder;

		// Token: 0x0400059A RID: 1434
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCloseBtn;

		// Token: 0x0400059B RID: 1435
		private bool _contentLoaded;
	}
}
