﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Effects;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001FB RID: 507
	public partial class ContainerWindow : CustomWindow
	{
		// Token: 0x060012E2 RID: 4834 RVA: 0x000728D4 File Offset: 0x00070AD4
		public ContainerWindow(MainWindow window, UserControl control, double width, double height, bool autoHeight = false, bool isShow = true)
		{
			ContainerWindow <>4__this = this;
			this.InitializeComponent();
			base.Closing += delegate(object o, CancelEventArgs e)
			{
				<>4__this.ClosingContainerWindow(o, e, control);
			};
			this.SetShadowBorder();
			this.SetOuterBorder();
			this.SetMaskGrid();
			if (autoHeight)
			{
				base.Width = width + 64.0;
				base.SizeToContent = SizeToContent.Height;
			}
			else
			{
				base.Width = width + 60.0;
				base.Height = height + 60.0;
			}
			base.Owner = window;
			if (window != null)
			{
				if (window.mDMMRecommendedWindow != null && window.mDMMRecommendedWindow.Visibility == Visibility.Visible && window.IsUIInPortraitMode)
				{
					double num = (window.Width + window.mDMMRecommendedWindow.Width - base.Width) / 2.0 + window.Left;
					double num2 = (window.Height - base.Height) / 2.0 + window.Top;
					double num3 = num + base.Width;
					double num4 = num2 + base.Height;
					if (num > 0.0 && num3 < SystemParameters.PrimaryScreenWidth && num2 > 0.0 && num4 < SystemParameters.PrimaryScreenHeight)
					{
						base.Left = num;
						base.Top = num2;
					}
					else
					{
						base.WindowStartupLocation = WindowStartupLocation.CenterOwner;
					}
				}
				else if (window.WindowState == WindowState.Minimized)
				{
					base.WindowStartupLocation = WindowStartupLocation.CenterScreen;
				}
				else
				{
					base.WindowStartupLocation = WindowStartupLocation.CenterOwner;
				}
				this.ContentGrid.Children.Add(control);
				if (isShow)
				{
					if (window != null)
					{
						window.ShowDimOverlay(null);
						base.Owner = window.mDimOverlay;
					}
					base.ShowDialog();
					if (window != null)
					{
						window.HideDimOverlay();
					}
				}
			}
		}

		// Token: 0x060012E3 RID: 4835 RVA: 0x00072A94 File Offset: 0x00070C94
		private void ClosingContainerWindow(object _1, CancelEventArgs _2, UserControl control)
		{
			IDimOverlayControl dimOverlayControl = control as IDimOverlayControl;
			if (dimOverlayControl != null)
			{
				dimOverlayControl.Close();
			}
			if (control != null)
			{
				this.ContentGrid.Children.Remove(control);
			}
		}

		// Token: 0x060012E4 RID: 4836 RVA: 0x00072AC8 File Offset: 0x00070CC8
		private void SetShadowBorder()
		{
			this.mShadowBorder.SnapsToDevicePixels = true;
			this.mShadowBorder.SetValue(RenderOptions.EdgeModeProperty, EdgeMode.Aliased);
			BlueStacksUIBinding.BindCornerRadius(this.mShadowBorder, Border.CornerRadiusProperty, "SettingsWindowRadius");
			DropShadowEffect dropShadowEffect = new DropShadowEffect();
			BlueStacksUIBinding.BindColor(dropShadowEffect, DropShadowEffect.ColorProperty, "PopupShadowColor");
			dropShadowEffect.Direction = 270.0;
			dropShadowEffect.ShadowDepth = 0.0;
			dropShadowEffect.BlurRadius = 15.0;
			dropShadowEffect.Opacity = 0.7;
			this.mShadowBorder.Effect = dropShadowEffect;
		}

		// Token: 0x060012E5 RID: 4837 RVA: 0x00072B6C File Offset: 0x00070D6C
		private void SetOuterBorder()
		{
			BlueStacksUIBinding.BindColor(this.mOuterBorder, Control.BackgroundProperty, "ContextMenuItemBackgroundColor");
			BlueStacksUIBinding.BindColor(this.mOuterBorder, Control.BorderBrushProperty, "PopupBorderBrush");
			BlueStacksUIBinding.BindCornerRadius(this.mOuterBorder, Border.CornerRadiusProperty, "SettingsWindowRadius");
		}

		// Token: 0x060012E6 RID: 4838 RVA: 0x00072BB8 File Offset: 0x00070DB8
		private void SetMaskGrid()
		{
			this.mMaskBorder.SnapsToDevicePixels = true;
			this.mMaskBorder.SetValue(RenderOptions.EdgeModeProperty, EdgeMode.Aliased);
			BlueStacksUIBinding.BindColor(this.mMaskBorder, Control.BackgroundProperty, "ContextMenuItemBackgroundColor");
			BlueStacksUIBinding.BindCornerRadius(this.mMaskBorder, Border.CornerRadiusProperty, "SettingsWindowRadius");
			VisualBrush opacityMask = new VisualBrush(this.mMaskBorder)
			{
				Stretch = Stretch.None
			};
			this.mMainGrid.OpacityMask = opacityMask;
		}
	}
}
