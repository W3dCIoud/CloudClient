﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200013A RID: 314
	public class ImportSchemesWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x06000CAE RID: 3246 RVA: 0x00009B01 File Offset: 0x00007D01
		public ImportSchemesWindow(KeymapCanvasWindow window, MainWindow mainWindow)
		{
			this.InitializeComponent();
			this.CanvasWindow = window;
			this.ParentWindow = mainWindow;
			this.mSchemesStackPanel = (this.mSchemesListScrollbar.Content as StackPanel);
		}

		// Token: 0x06000CAF RID: 3247 RVA: 0x00009B3E File Offset: 0x00007D3E
		private void Close_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.CloseWindow();
		}

		// Token: 0x06000CB0 RID: 3248 RVA: 0x00009B46 File Offset: 0x00007D46
		private void CloseWindow()
		{
			base.Close();
			this.CanvasWindow.SidebarWindow.mImportSchemesWindow = null;
			this.CanvasWindow.SidebarWindow.mOverlayGrid.Visibility = Visibility.Hidden;
			this.CanvasWindow.SidebarWindow.Focus();
		}

		// Token: 0x06000CB1 RID: 3249 RVA: 0x00053934 File Offset: 0x00051B34
		internal void Init(string fileName)
		{
			try
			{
				List<string> schemeNames = new List<string>();
				foreach (IMControlScheme imcontrolScheme in this.ParentWindow.SelectedConfig.ControlSchemes)
				{
					schemeNames.Add(imcontrolScheme.Name);
				}
				this.mSchemesStackPanel.Children.Clear();
				JObject jobject = JObject.Parse(File.ReadAllText(fileName));
				int? configVersion = ConfigConverter.GetConfigVersion(jobject);
				int num = 14;
				IMConfig deserializedIMConfigObject;
				if (configVersion.GetValueOrDefault() < num & configVersion != null)
				{
					object value = ConfigConverter.Convert(jobject, "14", false, true);
					JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
					serializerSettings.Formatting = Formatting.Indented;
					deserializedIMConfigObject = KMManager.GetDeserializedIMConfigObject(JsonConvert.SerializeObject(value, serializerSettings), false);
				}
				else
				{
					configVersion = ConfigConverter.GetConfigVersion(jobject);
					num = 16;
					if ((configVersion.GetValueOrDefault() < num & configVersion != null) && (string.Equals(this.ParentWindow.StaticComponents.mSelectedTabButton.PackageName, "com.dts.freefireth", StringComparison.InvariantCultureIgnoreCase) || PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.Contains(this.ParentWindow.StaticComponents.mSelectedTabButton.PackageName)))
					{
						JObject jobject2 = jobject;
						foreach (JToken jtoken in ((IEnumerable<JToken>)jobject["ControlSchemes"]))
						{
							JObject jobject3 = (JObject)jtoken;
							jobject3["Images"] = ConfigConverter.ConvertImagesArrayForPV16(jobject3);
						}
						jobject2["MetaData"]["Comment"] = string.Format(CultureInfo.InvariantCulture, "Generated automatically from ver {0}", new object[]
						{
							(int)jobject2["MetaData"]["ParserVersion"]
						});
						jobject2["MetaData"]["ParserVersion"] = 16;
						JsonSerializerSettings serializerSettings2 = Utils.GetSerializerSettings();
						serializerSettings2.Formatting = Formatting.Indented;
						deserializedIMConfigObject = KMManager.GetDeserializedIMConfigObject(JsonConvert.SerializeObject(jobject2, serializerSettings2), false);
					}
					else
					{
						deserializedIMConfigObject = KMManager.GetDeserializedIMConfigObject(fileName, true);
					}
				}
				this.mStringsToImport = deserializedIMConfigObject.Strings;
				this.mNumberOfSchemesSelectedForImport = 0;
				(from scheme in deserializedIMConfigObject.ControlSchemes
				where scheme.BuiltIn
				select scheme).ToList<IMControlScheme>().ForEach(delegate(IMControlScheme scheme)
				{
					base.<Init>g__AddSchemeToImportCheckbox|4(scheme);
				});
				(from scheme in deserializedIMConfigObject.ControlSchemes
				where !scheme.BuiltIn
				select scheme).ToList<IMControlScheme>().ForEach(delegate(IMControlScheme scheme)
				{
					if (this.dict.Keys.Contains(scheme.Name.ToLower(CultureInfo.InvariantCulture).Trim()))
					{
						scheme.Name += " (Edited)";
						scheme.Name = KMManager.GetUniqueName(scheme.Name, schemeNames);
					}
					base.<Init>g__AddSchemeToImportCheckbox|4(scheme);
				});
			}
			catch (Exception ex)
			{
				Logger.Error("Error in import window init err: " + ex.ToString());
			}
		}

		// Token: 0x06000CB2 RID: 3250 RVA: 0x00053C60 File Offset: 0x00051E60
		internal void Box_Unchecked(object sender, RoutedEventArgs e)
		{
			this.mNumberOfSchemesSelectedForImport--;
			if (this.mNumberOfSchemesSelectedForImport == this.mSchemesStackPanel.Children.Count - 1)
			{
				this.mSelectAllBtn.IsChecked = new bool?(false);
			}
			if (this.mNumberOfSchemesSelectedForImport == 0)
			{
				this.mImportBtn.IsEnabled = false;
			}
		}

		// Token: 0x06000CB3 RID: 3251 RVA: 0x00053CBC File Offset: 0x00051EBC
		internal void Box_Checked(object sender, RoutedEventArgs e)
		{
			this.mNumberOfSchemesSelectedForImport++;
			if (this.mNumberOfSchemesSelectedForImport == this.mSchemesStackPanel.Children.Count)
			{
				this.mSelectAllBtn.IsChecked = new bool?(true);
			}
			if (this.mNumberOfSchemesSelectedForImport == 1)
			{
				this.mImportBtn.IsEnabled = true;
			}
		}

		// Token: 0x06000CB4 RID: 3252 RVA: 0x00053D18 File Offset: 0x00051F18
		private bool EditedNameIsAllowed(string text, ImportSchemesWindowControl item)
		{
			if (string.IsNullOrEmpty(text.Trim()))
			{
				BlueStacksUIBinding.Bind(item.mWarningMsg, LocaleStrings.GetLocalizedString("STRING_INVALID_SCHEME_NAME"), "");
				return false;
			}
			if (text.Trim().IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
			{
				BlueStacksUIBinding.Bind(item.mWarningMsg, LocaleStrings.GetLocalizedString("STRING_INVALID_SCHEME_NAME"), "");
				return false;
			}
			using (List<IMControlScheme>.Enumerator enumerator = this.ParentWindow.SelectedConfig.ControlSchemes.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.Name.ToLower(CultureInfo.InvariantCulture).Trim() == text.ToLower(CultureInfo.InvariantCulture).Trim())
					{
						return false;
					}
				}
			}
			foreach (object obj in this.mSchemesStackPanel.Children)
			{
				ImportSchemesWindowControl importSchemesWindowControl = (ImportSchemesWindowControl)obj;
				bool? isChecked = importSchemesWindowControl.mContent.IsChecked;
				bool flag = true;
				if ((isChecked.GetValueOrDefault() == flag & isChecked != null) && importSchemesWindowControl.mBlock.Visibility == Visibility.Visible && importSchemesWindowControl.mImportName.Text.ToLower(CultureInfo.InvariantCulture).Trim() == text.ToLower(CultureInfo.InvariantCulture).Trim() && importSchemesWindowControl.mContent.Content.ToString().Trim().ToLower(CultureInfo.InvariantCulture) != item.mContent.Content.ToString().Trim().ToLower(CultureInfo.InvariantCulture))
				{
					return false;
				}
				isChecked = importSchemesWindowControl.mContent.IsChecked;
				flag = true;
				if ((isChecked.GetValueOrDefault() == flag & isChecked != null) && importSchemesWindowControl.mContent.Content.ToString().ToLower(CultureInfo.InvariantCulture).Trim() == text.ToLower(CultureInfo.InvariantCulture).Trim())
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x06000CB5 RID: 3253 RVA: 0x00053F74 File Offset: 0x00052174
		private void ImportBtn_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				int num = 0;
				bool flag = true;
				List<IMControlScheme> list = new List<IMControlScheme>();
				foreach (object obj in this.mSchemesStackPanel.Children)
				{
					ImportSchemesWindowControl importSchemesWindowControl = (ImportSchemesWindowControl)obj;
					bool? isChecked = importSchemesWindowControl.mContent.IsChecked;
					bool flag2 = true;
					if (isChecked.GetValueOrDefault() == flag2 & isChecked != null)
					{
						list.Add(this.dict.ElementAt(num).Value);
						if ((from key in this.ParentWindow.SelectedConfig.ControlSchemesDict.Keys
						select key.ToLower(CultureInfo.InvariantCulture).Trim()).Contains(importSchemesWindowControl.mContent.Content.ToString().ToLower(CultureInfo.InvariantCulture).Trim()))
						{
							if (!this.EditedNameIsAllowed(importSchemesWindowControl.mImportName.Text, importSchemesWindowControl))
							{
								importSchemesWindowControl.mImportName.InputTextValidity = TextValidityOptions.Error;
								if (!string.IsNullOrEmpty(importSchemesWindowControl.mImportName.Text) && importSchemesWindowControl.mImportName.Text.Trim().IndexOfAny(Path.GetInvalidFileNameChars()) < 0)
								{
									BlueStacksUIBinding.Bind(importSchemesWindowControl.mWarningMsg, LocaleStrings.GetLocalizedString("STRING_DUPLICATE_SCHEME_NAME_WARNING"), "");
								}
								importSchemesWindowControl.mWarningMsg.Visibility = Visibility.Visible;
								flag = false;
							}
							else
							{
								importSchemesWindowControl.mImportName.InputTextValidity = TextValidityOptions.Success;
								importSchemesWindowControl.mWarningMsg.Visibility = Visibility.Collapsed;
							}
						}
					}
					num++;
				}
				if (list.Count == 0)
				{
					this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_SCHEME_SELECTED"), 1.3, false);
				}
				else if (flag)
				{
					foreach (IMControlScheme imcontrolScheme in list)
					{
						ImportSchemesWindowControl controlFromScheme = this.GetControlFromScheme(imcontrolScheme);
						if ((from key in this.ParentWindow.SelectedConfig.ControlSchemesDict.Keys
						select key.ToLower(CultureInfo.InvariantCulture)).Contains(controlFromScheme.mContent.Content.ToString().ToLower(CultureInfo.InvariantCulture).Trim()))
						{
							imcontrolScheme.Name = controlFromScheme.mImportName.Text.Trim();
						}
					}
					this.mStringsToImport = KMManager.CleanupGuidanceAccordingToSchemes(list, this.mStringsToImport);
					this.ImportSchemes(list, this.mStringsToImport);
					KeymapCanvasWindow.sIsDirty = true;
					KMManager.SaveIMActions(this.ParentWindow, false, false);
					this.CanvasWindow.SidebarWindow.FillProfileCombo();
					this.CanvasWindow.SidebarWindow.ProfileChanged();
					KMManager.SendSchemeChangedStats(this.ParentWindow, "import_scheme");
					this.ParentWindow.mCommonHandler.AddToastPopup(this.CanvasWindow.SidebarWindow, LocaleStrings.GetLocalizedString("STRING_CONTROLS_IMPORTED"), 1.3, false);
					this.CloseWindow();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error while importing script. err:" + ex.ToString());
			}
		}

		// Token: 0x06000CB6 RID: 3254 RVA: 0x00054300 File Offset: 0x00052500
		private ImportSchemesWindowControl GetControlFromScheme(IMControlScheme scheme)
		{
			foreach (object obj in this.mSchemesStackPanel.Children)
			{
				ImportSchemesWindowControl importSchemesWindowControl = (ImportSchemesWindowControl)obj;
				if (importSchemesWindowControl.mContent.Content.ToString().Trim().ToLower(CultureInfo.InvariantCulture) == scheme.Name.ToLower(CultureInfo.InvariantCulture).Trim())
				{
					return importSchemesWindowControl;
				}
			}
			return null;
		}

		// Token: 0x06000CB7 RID: 3255 RVA: 0x0005439C File Offset: 0x0005259C
		private void SelectAllBtn_Click(object sender, RoutedEventArgs e)
		{
			if (this.mSelectAllBtn.IsChecked.Value)
			{
				using (IEnumerator enumerator = this.mSchemesStackPanel.Children.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						object obj = enumerator.Current;
						((ImportSchemesWindowControl)obj).mContent.IsChecked = new bool?(true);
					}
					return;
				}
			}
			foreach (object obj2 in this.mSchemesStackPanel.Children)
			{
				((ImportSchemesWindowControl)obj2).mContent.IsChecked = new bool?(false);
			}
		}

		// Token: 0x06000CB8 RID: 3256 RVA: 0x0005446C File Offset: 0x0005266C
		internal void ImportSchemes(List<IMControlScheme> toCopyFromSchemes, Dictionary<string, Dictionary<string, string>> stringsToImport)
		{
			bool flag = false;
			bool flag2 = false;
			KMManager.MergeConflictingGuidanceStrings(this.ParentWindow.SelectedConfig, toCopyFromSchemes, stringsToImport);
			if (this.ParentWindow.SelectedConfig.ControlSchemes.Count > 0)
			{
				flag = true;
			}
			foreach (IMControlScheme imcontrolScheme in toCopyFromSchemes)
			{
				IMControlScheme imcontrolScheme2 = imcontrolScheme.DeepCopy();
				if (flag)
				{
					imcontrolScheme2.Selected = false;
				}
				imcontrolScheme2.BuiltIn = false;
				imcontrolScheme2.IsBookMarked = false;
				this.CanvasWindow.SidebarWindow.mSchemeComboBox.mName.Text = imcontrolScheme2.Name;
				this.ParentWindow.SelectedConfig.ControlSchemes.Add(imcontrolScheme2);
				this.ParentWindow.SelectedConfig.ControlSchemesDict.Add(imcontrolScheme2.Name, imcontrolScheme2);
				ComboBoxSchemeControl comboBoxSchemeControl = new ComboBoxSchemeControl(this.CanvasWindow, this.ParentWindow);
				comboBoxSchemeControl.mSchemeName.Text = LocaleStrings.GetLocalizedString(imcontrolScheme2.Name);
				comboBoxSchemeControl.IsEnabled = true;
				BlueStacksUIBinding.BindColor(comboBoxSchemeControl, Control.BackgroundProperty, "ComboBoxBackgroundColor");
				this.CanvasWindow.SidebarWindow.mSchemeComboBox.Items.Children.Add(comboBoxSchemeControl);
			}
			if (!flag)
			{
				using (List<IMControlScheme>.Enumerator enumerator = this.ParentWindow.SelectedConfig.ControlSchemes.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						if (enumerator.Current.Selected)
						{
							flag2 = true;
							break;
						}
					}
				}
				if (!flag2)
				{
					this.ParentWindow.SelectedConfig.ControlSchemes[0].Selected = true;
				}
			}
		}

		// Token: 0x06000CB9 RID: 3257 RVA: 0x00054630 File Offset: 0x00052830
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/importschemeswindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000CBA RID: 3258 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000CBB RID: 3259 RVA: 0x00054660 File Offset: 0x00052860
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				((CustomPictureBox)target).MouseLeftButtonUp += this.Close_MouseLeftButtonUp;
				return;
			case 3:
				this.mSchemesListScrollbar = (ScrollViewer)target;
				return;
			case 4:
				this.mSelectAllBtn = (CustomCheckbox)target;
				this.mSelectAllBtn.Click += this.SelectAllBtn_Click;
				return;
			case 5:
				this.mImportBtn = (CustomButton)target;
				this.mImportBtn.Click += this.ImportBtn_Click;
				return;
			case 6:
				this.mLoadingGrid = (ProgressBar)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000879 RID: 2169
		private KeymapCanvasWindow CanvasWindow;

		// Token: 0x0400087A RID: 2170
		private MainWindow ParentWindow;

		// Token: 0x0400087B RID: 2171
		internal StackPanel mSchemesStackPanel;

		// Token: 0x0400087C RID: 2172
		internal int mNumberOfSchemesSelectedForImport;

		// Token: 0x0400087D RID: 2173
		private Dictionary<string, IMControlScheme> dict = new Dictionary<string, IMControlScheme>();

		// Token: 0x0400087E RID: 2174
		private Dictionary<string, Dictionary<string, string>> mStringsToImport;

		// Token: 0x0400087F RID: 2175
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder;

		// Token: 0x04000880 RID: 2176
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ScrollViewer mSchemesListScrollbar;

		// Token: 0x04000881 RID: 2177
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mSelectAllBtn;

		// Token: 0x04000882 RID: 2178
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mImportBtn;

		// Token: 0x04000883 RID: 2179
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ProgressBar mLoadingGrid;

		// Token: 0x04000884 RID: 2180
		private bool _contentLoaded;
	}
}
