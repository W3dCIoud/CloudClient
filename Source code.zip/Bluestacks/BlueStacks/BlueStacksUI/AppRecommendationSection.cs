﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200007C RID: 124
	public class AppRecommendationSection
	{
		// Token: 0x1700019A RID: 410
		// (get) Token: 0x06000516 RID: 1302 RVA: 0x000055F5 File Offset: 0x000037F5
		// (set) Token: 0x06000517 RID: 1303 RVA: 0x000055FD File Offset: 0x000037FD
		[JsonProperty(PropertyName = "section_header")]
		public string AppSuggestionHeader { get; set; }

		// Token: 0x1700019B RID: 411
		// (get) Token: 0x06000518 RID: 1304 RVA: 0x00005606 File Offset: 0x00003806
		// (set) Token: 0x06000519 RID: 1305 RVA: 0x0000560E File Offset: 0x0000380E
		[JsonProperty(PropertyName = "client_show_count", DefaultValueHandling = DefaultValueHandling.Populate)]
		[DefaultValue(3)]
		public int ClientShowCount { get; set; } = 3;

		// Token: 0x1700019C RID: 412
		// (get) Token: 0x0600051A RID: 1306 RVA: 0x00005617 File Offset: 0x00003817
		[JsonProperty(PropertyName = "suggested_apps")]
		public List<AppRecommendation> AppSuggestions { get; } = new List<AppRecommendation>();
	}
}
