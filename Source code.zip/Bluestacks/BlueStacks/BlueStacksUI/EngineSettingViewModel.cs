﻿using System;
using System.Globalization;
using System.Windows;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200003C RID: 60
	public class EngineSettingViewModel : EngineSettingBaseViewModel
	{
		// Token: 0x0600030D RID: 781 RVA: 0x000040A6 File Offset: 0x000022A6
		public EngineSettingViewModel(MainWindow owner, string vmName) : base(owner, vmName, false)
		{
			this.ParentWindow = owner;
			this._VmName = vmName;
		}

		// Token: 0x0600030E RID: 782 RVA: 0x00017B14 File Offset: 0x00015D14
		protected override void Save(object param)
		{
			if (base.Status == Status.Progress)
			{
				Logger.Info("Compatibility check is running");
				return;
			}
			if (base.IsRestartRequired())
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.Owner = base.Owner;
				customMessageWindow.WindowStartupLocation = WindowStartupLocation.CenterOwner;
				customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_RESTART_BLUESTACKS");
				customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_RESTART_BLUESTACKS_MESSAGE");
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_RESTART_NOW", delegate(object o, EventArgs e)
				{
					this.ParentWindow.mChangedABIValue = base.ABISetting.ToString("D");
					if (base.EngineData.ABISetting != base.ABISetting)
					{
						VmCmdHandler.RunCommand(string.Format(CultureInfo.InvariantCulture, "{0} {1}", new object[]
						{
							"switchAbi",
							base.ABISetting.ToString("D")
						}), this._VmName);
					}
					base.SaveEngineSettings();
					base.Owner.Close();
					this.ParentWindow.IsForceRestart = true;
					BlueStacksUIUtils.CloseContainerWindow(this.ParentWindow);
					BlueStacksUIUtils.RestartInstance(this._VmName);
				}, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, "STRING_DISCARD_CHANGES", delegate(object o, EventArgs e)
				{
					base.Init();
				}, null, false, null);
				customMessageWindow.ShowDialog();
			}
			else
			{
				base.SaveEngineSettings();
				base.AddToastPopupUserControl(LocaleStrings.GetLocalizedString("STRING_CHANGES_SAVED"));
			}
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				base.Owner.Close();
			}
		}

		// Token: 0x040001AD RID: 429
		private string _VmName;

		// Token: 0x040001AE RID: 430
		private MainWindow ParentWindow;
	}
}
