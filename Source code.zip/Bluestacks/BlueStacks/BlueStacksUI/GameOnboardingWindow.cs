﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000050 RID: 80
	public class GameOnboardingWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x1700014C RID: 332
		// (get) Token: 0x060003B6 RID: 950 RVA: 0x000048A3 File Offset: 0x00002AA3
		// (set) Token: 0x060003B7 RID: 951 RVA: 0x000048AB File Offset: 0x00002AAB
		private BrowserControl mBrowser { get; set; }

		// Token: 0x1700014D RID: 333
		// (get) Token: 0x060003B8 RID: 952 RVA: 0x000048B4 File Offset: 0x00002AB4
		// (set) Token: 0x060003B9 RID: 953 RVA: 0x000048BC File Offset: 0x00002ABC
		public string PackageName { get; set; }

		// Token: 0x1700014E RID: 334
		// (get) Token: 0x060003BA RID: 954 RVA: 0x000048C5 File Offset: 0x00002AC5
		// (set) Token: 0x060003BB RID: 955 RVA: 0x000048CD File Offset: 0x00002ACD
		public MainWindow ParentWindow { get; set; }

		// Token: 0x1700014F RID: 335
		// (get) Token: 0x060003BC RID: 956 RVA: 0x000048D6 File Offset: 0x00002AD6
		// (set) Token: 0x060003BD RID: 957 RVA: 0x000048DE File Offset: 0x00002ADE
		public Grid controlGrid { get; set; }

		// Token: 0x060003BE RID: 958 RVA: 0x000048E7 File Offset: 0x00002AE7
		public GameOnboardingWindow(MainWindow mainWindow, string packageName)
		{
			this.PackageName = packageName;
			this.ParentWindow = mainWindow;
			this.InitializeComponent();
		}

		// Token: 0x060003BF RID: 959 RVA: 0x0001A180 File Offset: 0x00018380
		private void GameOnboardingWindow_IsVisibleChanged(object _1, DependencyPropertyChangedEventArgs _2)
		{
			if (base.IsVisible)
			{
				this.mBrowser = new BrowserControl();
				this.mBrowser.BrowserLoadCompleteEvent += this.BrowserLoadCompleteEvent;
				this.mBrowser.InitBaseControl(BlueStacksUIUtils.GetOnboardingUrl(this.PackageName), 0f);
				this.mBrowser.Visibility = Visibility.Visible;
				this.mBrowser.ParentWindow = this.ParentWindow;
				this.mBrowserGridTemp.Children.Add(this.mBrowser);
				this.controlGrid = this.AddBrowser("");
				this.controlGrid.Visibility = Visibility.Visible;
				this.mBrowserGrid.Children.Add(this.controlGrid);
				this.dispatcherTimer = new DispatcherTimer();
				this.dispatcherTimer.Tick += this.DispatcherTimer_Tick;
				this.dispatcherTimer.Interval = new TimeSpan(0, 0, PostBootCloudInfoManager.Instance.mPostBootCloudInfo.OnBoardingInfo.OnBoardingSkipTimer);
				this.dispatcherTimer.Start();
			}
		}

		// Token: 0x060003C0 RID: 960 RVA: 0x0001A290 File Offset: 0x00018490
		internal Grid AddBrowser(string url)
		{
			Grid grid = new Grid();
			BrowserControl element = new BrowserControl(url)
			{
				Visibility = Visibility.Visible
			};
			CustomPictureBox element2 = new CustomPictureBox
			{
				HorizontalAlignment = HorizontalAlignment.Center,
				VerticalAlignment = VerticalAlignment.Center,
				Height = 30.0,
				Width = 30.0,
				ImageName = "loader",
				IsImageToBeRotated = true
			};
			grid.Children.Add(element);
			grid.Children.Add(element2);
			grid.Visibility = Visibility.Hidden;
			return grid;
		}

		// Token: 0x060003C1 RID: 961 RVA: 0x0001A318 File Offset: 0x00018518
		private void BrowserLoadCompleteEvent()
		{
			AppConfigurationManager.Instance.VmAppConfig[this.ParentWindow.mVmName][this.PackageName].IsAppOnboardingCompleted = true;
			this.mBrowserGrid.Children.Remove(this.controlGrid);
			this.mBrowserGridTemp.Children.Remove(this.mBrowser);
			this.mBrowserGrid.Children.Add(this.mBrowser);
		}

		// Token: 0x060003C2 RID: 962 RVA: 0x00004903 File Offset: 0x00002B03
		private void DispatcherTimer_Tick(object _1, EventArgs _2)
		{
			this.mSkipOnboardingButton.Visibility = Visibility.Visible;
			this.dispatcherTimer.Stop();
		}

		// Token: 0x060003C3 RID: 963 RVA: 0x0000491C File Offset: 0x00002B1C
		internal void CloseWindow()
		{
			if (this.mBrowser != null)
			{
				this.mBrowser.DisposeBrowser();
				this.mBrowserGrid.Children.Remove(this.mBrowser);
				this.mBrowser = null;
			}
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x0000494E File Offset: 0x00002B4E
		private void mWindow_Closing(object sender, CancelEventArgs e)
		{
			this.CloseWindow();
		}

		// Token: 0x060003C5 RID: 965 RVA: 0x0001A394 File Offset: 0x00018594
		private void SkipOnboardingButton_Click(object sender, RoutedEventArgs e)
		{
			AppConfigurationManager.Instance.VmAppConfig[this.ParentWindow.mVmName][this.PackageName].IsAppOnboardingCompleted = true;
			AppConfigurationManager.Instance.VmAppConfig[this.ParentWindow.mVmName][this.PackageName].IsGeneralAppOnBoardingCompleted = true;
			AppConfigurationManager.Instance.VmAppConfig[this.ParentWindow.mVmName][this.PackageName].IsCloseGuidanceOnboardingCompleted = true;
			this.ParentWindow.HideDimOverlay();
			GuidanceWindow sGuidanceWindow = KMManager.sGuidanceWindow;
			if (sGuidanceWindow != null)
			{
				sGuidanceWindow.DimOverLayVisibility(Visibility.Collapsed);
			}
			Stats.SendCommonClientStatsAsync("onboarding-tutorial", "onboarding_skipped", this.ParentWindow.mVmName, this.PackageName, "", "");
			base.Close();
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x00004956 File Offset: 0x00002B56
		private void CloseButton_PreviewMouseUp(object sender, RoutedEventArgs e)
		{
			base.Close();
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x0000495E File Offset: 0x00002B5E
		private void mWindow_Loaded(object sender, RoutedEventArgs e)
		{
			Stats.SendCommonClientStatsAsync("onboarding-tutorial", "client_impression", this.ParentWindow.mVmName, this.PackageName, "", "");
		}

		// Token: 0x060003C8 RID: 968 RVA: 0x0000498A File Offset: 0x00002B8A
		private void mWindow_Closed(object sender, EventArgs e)
		{
			Stats.SendCommonClientStatsAsync("onboarding-tutorial", "client_closed", this.ParentWindow.mVmName, this.PackageName, "", "");
		}

		// Token: 0x060003C9 RID: 969 RVA: 0x000049B6 File Offset: 0x00002BB6
		private void mWindow_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.System && e.SystemKey == Key.F4)
			{
				e.Handled = true;
			}
		}

		// Token: 0x060003CA RID: 970 RVA: 0x0001A470 File Offset: 0x00018670
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/gameonboardingwindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060003CB RID: 971 RVA: 0x0001A4A0 File Offset: 0x000186A0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mWindow = (GameOnboardingWindow)target;
				this.mWindow.IsVisibleChanged += this.GameOnboardingWindow_IsVisibleChanged;
				this.mWindow.Loaded += this.mWindow_Loaded;
				this.mWindow.Closed += this.mWindow_Closed;
				this.mWindow.Closing += this.mWindow_Closing;
				this.mWindow.KeyDown += this.mWindow_KeyDown;
				return;
			case 2:
				this.mBrowserGrid = (Grid)target;
				return;
			case 3:
				this.mSkipOnboardingButton = (CustomButton)target;
				this.mSkipOnboardingButton.Click += this.SkipOnboardingButton_Click;
				return;
			case 4:
				this.mBrowserGridTemp = (Grid)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040001FC RID: 508
		private DispatcherTimer dispatcherTimer;

		// Token: 0x04000200 RID: 512
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal GameOnboardingWindow mWindow;

		// Token: 0x04000201 RID: 513
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mBrowserGrid;

		// Token: 0x04000202 RID: 514
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mSkipOnboardingButton;

		// Token: 0x04000203 RID: 515
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mBrowserGridTemp;

		// Token: 0x04000204 RID: 516
		private bool _contentLoaded;
	}
}
