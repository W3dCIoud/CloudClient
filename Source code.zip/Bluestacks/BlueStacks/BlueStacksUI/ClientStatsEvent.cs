﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001AE RID: 430
	public static class ClientStatsEvent
	{
		// Token: 0x17000289 RID: 649
		// (get) Token: 0x06001084 RID: 4228 RVA: 0x0000C184 File Offset: 0x0000A384
		public static string UpgradePopup
		{
			get
			{
				return "upgrade_popup";
			}
		}

		// Token: 0x1700028A RID: 650
		// (get) Token: 0x06001085 RID: 4229 RVA: 0x0000C18B File Offset: 0x0000A38B
		public static string UpgradePopupCross
		{
			get
			{
				return "upgrade_popup_cross";
			}
		}

		// Token: 0x1700028B RID: 651
		// (get) Token: 0x06001086 RID: 4230 RVA: 0x0000C192 File Offset: 0x0000A392
		public static string UpgradePopupDwnld
		{
			get
			{
				return "upgrade_popup_dwnld";
			}
		}

		// Token: 0x1700028C RID: 652
		// (get) Token: 0x06001087 RID: 4231 RVA: 0x0000C199 File Offset: 0x0000A399
		public static string SettingsGearDwnld
		{
			get
			{
				return "settingsgear_dwnld";
			}
		}

		// Token: 0x1700028D RID: 653
		// (get) Token: 0x06001088 RID: 4232 RVA: 0x0000C1A0 File Offset: 0x0000A3A0
		public static string InstallPopupNow
		{
			get
			{
				return "install_popup_now";
			}
		}

		// Token: 0x1700028E RID: 654
		// (get) Token: 0x06001089 RID: 4233 RVA: 0x0000C1A7 File Offset: 0x0000A3A7
		public static string InstallPopupLater
		{
			get
			{
				return "install_popup_later";
			}
		}

		// Token: 0x1700028F RID: 655
		// (get) Token: 0x0600108A RID: 4234 RVA: 0x0000C1AE File Offset: 0x0000A3AE
		public static string InstallPopupCross
		{
			get
			{
				return "install_popup_cross";
			}
		}

		// Token: 0x17000290 RID: 656
		// (get) Token: 0x0600108B RID: 4235 RVA: 0x0000C1B5 File Offset: 0x0000A3B5
		public static string SettingCheckUpdate
		{
			get
			{
				return "setting_check_update";
			}
		}

		// Token: 0x17000291 RID: 657
		// (get) Token: 0x0600108C RID: 4236 RVA: 0x0000C1BC File Offset: 0x0000A3BC
		public static string SettingUpdateAvailable
		{
			get
			{
				return "setting_update_available";
			}
		}

		// Token: 0x17000292 RID: 658
		// (get) Token: 0x0600108D RID: 4237 RVA: 0x0000C1C3 File Offset: 0x0000A3C3
		public static string SettingUpdateNotAvailable
		{
			get
			{
				return "setting_update_not_available";
			}
		}

		// Token: 0x17000293 RID: 659
		// (get) Token: 0x0600108E RID: 4238 RVA: 0x0000C1CA File Offset: 0x0000A3CA
		public static string SettingDownloadUpdate
		{
			get
			{
				return "setting_download_update";
			}
		}

		// Token: 0x17000294 RID: 660
		// (get) Token: 0x0600108F RID: 4239 RVA: 0x0000C1D1 File Offset: 0x0000A3D1
		public static string SettingInstallUpdate
		{
			get
			{
				return "setting_install_update";
			}
		}
	}
}
