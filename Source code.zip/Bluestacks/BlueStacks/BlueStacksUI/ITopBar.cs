﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000111 RID: 273
	internal interface ITopBar
	{
		// Token: 0x170001FC RID: 508
		// (get) Token: 0x06000AA6 RID: 2726
		// (set) Token: 0x06000AA7 RID: 2727
		string AppName { get; set; }

		// Token: 0x170001FD RID: 509
		// (get) Token: 0x06000AA8 RID: 2728
		// (set) Token: 0x06000AA9 RID: 2729
		string CharacterName { get; set; }

		// Token: 0x06000AAA RID: 2730
		void ShowSyncPanel(bool show = false);

		// Token: 0x06000AAB RID: 2731
		void HideSyncPanel();
	}
}
