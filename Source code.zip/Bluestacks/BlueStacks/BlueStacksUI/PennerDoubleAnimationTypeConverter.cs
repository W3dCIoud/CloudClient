﻿using System;
using System.ComponentModel;
using System.Globalization;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200019F RID: 415
	public class PennerDoubleAnimationTypeConverter : TypeConverter
	{
		// Token: 0x06001049 RID: 4169 RVA: 0x0000BFAF File Offset: 0x0000A1AF
		public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
		{
			return sourceType == typeof(string);
		}

		// Token: 0x0600104A RID: 4170 RVA: 0x0000BFBE File Offset: 0x0000A1BE
		public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
		{
			return destinationType == typeof(Enum);
		}

		// Token: 0x0600104B RID: 4171 RVA: 0x00066AF8 File Offset: 0x00064CF8
		public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
		{
			foreach (object obj in Enum.GetValues(typeof(PennerDoubleAnimation.Equations)))
			{
				int num = (int)obj;
				if (Enum.GetName(typeof(PennerDoubleAnimation.Equations), num) == ((value != null) ? value.ToString() : null))
				{
					return (PennerDoubleAnimation.Equations)num;
				}
			}
			return null;
		}

		// Token: 0x0600104C RID: 4172 RVA: 0x00066B88 File Offset: 0x00064D88
		public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
		{
			if (value != null)
			{
				return ((PennerDoubleAnimation.Equations)value).ToString();
			}
			return null;
		}
	}
}
