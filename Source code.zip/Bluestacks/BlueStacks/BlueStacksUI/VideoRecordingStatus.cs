﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000108 RID: 264
	public class VideoRecordingStatus : UserControl, IComponentConnector
	{
		// Token: 0x170001F3 RID: 499
		// (get) Token: 0x06000A53 RID: 2643 RVA: 0x0000888B File Offset: 0x00006A8B
		// (set) Token: 0x06000A54 RID: 2644 RVA: 0x00008893 File Offset: 0x00006A93
		public DateTime mStartTime { get; set; }

		// Token: 0x06000A55 RID: 2645 RVA: 0x0000889C File Offset: 0x00006A9C
		public VideoRecordingStatus()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000A56 RID: 2646 RVA: 0x000088B1 File Offset: 0x00006AB1
		private void StopRecord_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ResetTimer();
			Action recordingStoppedEvent = this.RecordingStoppedEvent;
			if (recordingStoppedEvent != null)
			{
				recordingStoppedEvent();
			}
			this.ParentWindow.mCommonHandler.StopRecordVideo();
		}

		// Token: 0x06000A57 RID: 2647 RVA: 0x000088DA File Offset: 0x00006ADA
		private void BlinkPlayingIcon_Tick(object sender, EventArgs e)
		{
			this.ToggleRecordingIcon();
		}

		// Token: 0x06000A58 RID: 2648 RVA: 0x0003C234 File Offset: 0x0003A434
		internal void StopTimer()
		{
			DispatcherTimer dispatcherTimer = this.mBlinkPlayingIconTimer;
			if (dispatcherTimer != null && dispatcherTimer.IsEnabled)
			{
				DispatcherTimer dispatcherTimer2 = this.mBlinkPlayingIconTimer;
				if (dispatcherTimer2 != null)
				{
					dispatcherTimer2.Stop();
				}
			}
			DispatcherTimer dispatcherTimer3 = this.mTimer;
			if (dispatcherTimer3 != null && dispatcherTimer3.IsEnabled)
			{
				DispatcherTimer dispatcherTimer4 = this.mTimer;
				if (dispatcherTimer4 == null)
				{
					return;
				}
				dispatcherTimer4.Stop();
			}
		}

		// Token: 0x06000A59 RID: 2649 RVA: 0x000088E2 File Offset: 0x00006AE2
		internal void StartTimer()
		{
			this.mBlinkPlayingIconTimer.Start();
		}

		// Token: 0x06000A5A RID: 2650 RVA: 0x0003C28C File Offset: 0x0003A48C
		private void ToggleRecordingIcon()
		{
			if (this.mToggleBlinkImage)
			{
				this.mRecordingImage.ImageName = "sidebar_video_capture";
			}
			else
			{
				this.mRecordingImage.ImageName = "sidebar_video_capture_active";
			}
			if (FeatureManager.Instance.IsCustomUIForNCSoft && this.ParentWindow.mSidebar != null)
			{
				this.ParentWindow.mSidebar.ChangeVideoRecordingImage(this.mRecordingImage.ImageName);
			}
			this.mToggleBlinkImage = !this.mToggleBlinkImage;
		}

		// Token: 0x06000A5B RID: 2651 RVA: 0x0003C308 File Offset: 0x0003A508
		internal void Init(MainWindow parentWindow)
		{
			this.ParentWindow = parentWindow;
			if (this.mBlinkPlayingIconTimer == null)
			{
				this.mBlinkPlayingIconTimer = new DispatcherTimer(new TimeSpan(0, 0, 0, 0, 500), DispatcherPriority.Render, new EventHandler(this.BlinkPlayingIcon_Tick), Dispatcher.CurrentDispatcher);
				this.mStartTime = DateTime.Now;
				this.mTimer = new DispatcherTimer(new TimeSpan(0, 0, 0, 0, 50), DispatcherPriority.Render, new EventHandler(this.T_Tick), Dispatcher.CurrentDispatcher);
				this.StartTimer();
			}
		}

		// Token: 0x06000A5C RID: 2652 RVA: 0x0003C388 File Offset: 0x0003A588
		private void T_Tick(object sender, EventArgs e)
		{
			TimeSpan timeSpan = DateTime.Now - this.mStartTime;
			string text = string.Format(CultureInfo.InvariantCulture, "{0:00}:{1:00}:{2:00}", new object[]
			{
				timeSpan.Minutes,
				timeSpan.Seconds,
				timeSpan.Milliseconds / 10
			});
			this.mTimerDisplay.Text = text;
		}

		// Token: 0x06000A5D RID: 2653 RVA: 0x000088EF File Offset: 0x00006AEF
		internal void ResetTimer()
		{
			this.StopTimer();
			this.mBlinkPlayingIconTimer = null;
			this.mTimer = null;
		}

		// Token: 0x06000A5E RID: 2654 RVA: 0x0003C3F8 File Offset: 0x0003A5F8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/videorecordingstatus.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000A5F RID: 2655 RVA: 0x0003C428 File Offset: 0x0003A628
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				this.mRecordingImage = (CustomPictureBox)target;
				return;
			case 3:
				this.mDescriptionPanel = (StackPanel)target;
				return;
			case 4:
				this.mRunningVideo = (TextBlock)target;
				return;
			case 5:
				this.mTimerDisplay = (TextBlock)target;
				return;
			case 6:
				this.mStopVideoRecordImg = (CustomPictureBox)target;
				this.mStopVideoRecordImg.PreviewMouseLeftButtonUp += this.StopRecord_PreviewMouseLeftButtonUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400068E RID: 1678
		private MainWindow ParentWindow;

		// Token: 0x0400068F RID: 1679
		private DispatcherTimer mBlinkPlayingIconTimer;

		// Token: 0x04000690 RID: 1680
		private DispatcherTimer mTimer;

		// Token: 0x04000692 RID: 1682
		private bool mToggleBlinkImage = true;

		// Token: 0x04000693 RID: 1683
		internal Action RecordingStoppedEvent;

		// Token: 0x04000694 RID: 1684
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder;

		// Token: 0x04000695 RID: 1685
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mRecordingImage;

		// Token: 0x04000696 RID: 1686
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mDescriptionPanel;

		// Token: 0x04000697 RID: 1687
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mRunningVideo;

		// Token: 0x04000698 RID: 1688
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mTimerDisplay;

		// Token: 0x04000699 RID: 1689
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mStopVideoRecordImg;

		// Token: 0x0400069A RID: 1690
		private bool _contentLoaded;
	}
}
