﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interactivity;
using System.Windows.Markup;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000051 RID: 81
	public partial class OnBoardingPopupWindow : CustomWindow, INotifyPropertyChanged
	{
		// Token: 0x14000003 RID: 3
		// (add) Token: 0x060003CC RID: 972 RVA: 0x0001A590 File Offset: 0x00018790
		// (remove) Token: 0x060003CD RID: 973 RVA: 0x0001A5C8 File Offset: 0x000187C8
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x060003CE RID: 974 RVA: 0x000049D6 File Offset: 0x00002BD6
		protected void OnPropertyChanged(string property)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged == null)
			{
				return;
			}
			propertyChanged(this, new PropertyChangedEventArgs(property));
		}

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x060003CF RID: 975 RVA: 0x0001A600 File Offset: 0x00018800
		// (remove) Token: 0x060003D0 RID: 976 RVA: 0x0001A638 File Offset: 0x00018838
		public event Action Startevent;

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x060003D1 RID: 977 RVA: 0x0001A670 File Offset: 0x00018870
		// (remove) Token: 0x060003D2 RID: 978 RVA: 0x0001A6A8 File Offset: 0x000188A8
		public event Action Endevent;

		// Token: 0x17000150 RID: 336
		// (get) Token: 0x060003D3 RID: 979 RVA: 0x000049EF File Offset: 0x00002BEF
		// (set) Token: 0x060003D4 RID: 980 RVA: 0x000049F7 File Offset: 0x00002BF7
		public string HeaderContent
		{
			get
			{
				return this.mHeaderContent;
			}
			set
			{
				if (this.mHeaderContent != value)
				{
					this.mHeaderContent = value;
					this.OnPropertyChanged("HeaderContent");
				}
			}
		}

		// Token: 0x17000151 RID: 337
		// (get) Token: 0x060003D5 RID: 981 RVA: 0x00004A19 File Offset: 0x00002C19
		// (set) Token: 0x060003D6 RID: 982 RVA: 0x00004A21 File Offset: 0x00002C21
		public string BodyContent
		{
			get
			{
				return this.mBodyContent;
			}
			set
			{
				if (this.mBodyContent != value)
				{
					this.mBodyContent = value;
					this.OnPropertyChanged("BodyContent");
				}
			}
		}

		// Token: 0x17000152 RID: 338
		// (get) Token: 0x060003D7 RID: 983 RVA: 0x00004A43 File Offset: 0x00002C43
		// (set) Token: 0x060003D8 RID: 984 RVA: 0x00004A4B File Offset: 0x00002C4B
		public bool IsLastPopup
		{
			get
			{
				return this.mIsLastPopup;
			}
			set
			{
				if (this.mIsLastPopup != value)
				{
					this.mIsLastPopup = value;
					this.OnPropertyChanged("IsLastPopup");
				}
			}
		}

		// Token: 0x17000153 RID: 339
		// (get) Token: 0x060003D9 RID: 985 RVA: 0x00004A68 File Offset: 0x00002C68
		// (set) Token: 0x060003DA RID: 986 RVA: 0x00004A70 File Offset: 0x00002C70
		public PopupArrowAlignment PopArrowAlignment
		{
			get
			{
				return this.mPopArrowAlignment;
			}
			set
			{
				if (this.mPopArrowAlignment != value)
				{
					this.mPopArrowAlignment = value;
					this.OnPropertyChanged("PopArrowAlignment");
				}
			}
		}

		// Token: 0x17000154 RID: 340
		// (get) Token: 0x060003DB RID: 987 RVA: 0x00004A8D File Offset: 0x00002C8D
		// (set) Token: 0x060003DC RID: 988 RVA: 0x00004A95 File Offset: 0x00002C95
		public UIElement PlacementTarget { get; set; }

		// Token: 0x17000155 RID: 341
		// (get) Token: 0x060003DD RID: 989 RVA: 0x00004A9E File Offset: 0x00002C9E
		// (set) Token: 0x060003DE RID: 990 RVA: 0x00004AA6 File Offset: 0x00002CA6
		public int LeftMargin { get; set; }

		// Token: 0x17000156 RID: 342
		// (get) Token: 0x060003DF RID: 991 RVA: 0x00004AAF File Offset: 0x00002CAF
		// (set) Token: 0x060003E0 RID: 992 RVA: 0x00004AB7 File Offset: 0x00002CB7
		public int TopMargin { get; set; }

		// Token: 0x17000157 RID: 343
		// (get) Token: 0x060003E1 RID: 993 RVA: 0x00004AC0 File Offset: 0x00002CC0
		// (set) Token: 0x060003E2 RID: 994 RVA: 0x00004AC8 File Offset: 0x00002CC8
		public string PackageName { get; set; }

		// Token: 0x17000158 RID: 344
		// (get) Token: 0x060003E3 RID: 995 RVA: 0x00004AD1 File Offset: 0x00002CD1
		// (set) Token: 0x060003E4 RID: 996 RVA: 0x00004AD9 File Offset: 0x00002CD9
		public MainWindow ParentWindow { get; set; }

		// Token: 0x060003E5 RID: 997 RVA: 0x00004AE2 File Offset: 0x00002CE2
		public OnBoardingPopupWindow(MainWindow mainWindow, string packageName)
		{
			this.PackageName = packageName;
			this.ParentWindow = mainWindow;
			this.InitializeComponent();
		}

		// Token: 0x060003E6 RID: 998 RVA: 0x00004B05 File Offset: 0x00002D05
		private void CustomWindow_Loaded(object sender, RoutedEventArgs e)
		{
			Action startevent = this.Startevent;
			if (startevent != null)
			{
				startevent();
			}
			Interaction.GetBehaviors(this).Add(new ResizeBlurbBehaviour());
		}

		// Token: 0x060003E7 RID: 999 RVA: 0x00004B28 File Offset: 0x00002D28
		public void CloseWindow()
		{
			Action endevent = this.Endevent;
			if (endevent != null)
			{
				endevent();
			}
			base.Close();
		}

		// Token: 0x060003E8 RID: 1000 RVA: 0x00004B41 File Offset: 0x00002D41
		private void OnBoardingPopupSkip_Click(object sender, RoutedEventArgs e)
		{
			this.CloseWindow();
			KMManager.onBoardingPopupWindows.Clear();
		}

		// Token: 0x060003E9 RID: 1001 RVA: 0x0001A6E0 File Offset: 0x000188E0
		private void OnBoardingPopupNext_Click(object sender, RoutedEventArgs e)
		{
			Stats.SendCommonClientStatsAsync("general-onboarding", "okay_clicked", this.ParentWindow.mVmName, this.PackageName, base.Title, "");
			this.CloseWindow();
			if (KMManager.onBoardingPopupWindows.Count > 0)
			{
				OnBoardingPopupWindow onBoardingPopupWindow = KMManager.onBoardingPopupWindows.First<OnBoardingPopupWindow>();
				KMManager.onBoardingPopupWindows.Remove(onBoardingPopupWindow);
				onBoardingPopupWindow.ShowDialog();
			}
		}

		// Token: 0x060003EA RID: 1002 RVA: 0x0001A74C File Offset: 0x0001894C
		private void CustomWindow_KeyDown(object sender, KeyEventArgs e)
		{
			if (e2.Key == Key.System && e2.SystemKey == Key.F4)
			{
				e2.Handled = true;
				return;
			}
			string keyPressed = string.Empty;
			if (e2.Key == Key.System)
			{
				keyPressed = MainWindow.GetShortcutKey(e2.SystemKey);
			}
			else
			{
				keyPressed = MainWindow.GetShortcutKey(e2.Key);
			}
			MainWindow mainWindow = (MainWindow)base.Owner;
			if (string.Equals(keyPressed, mainWindow.mCommonHandler.GetShortcutKeyFromName("STRING_UPDATED_FULLSCREEN_BUTTON_TOOLTIP", false), StringComparison.InvariantCulture) && base.Title == "FullScreenBlurb")
			{
				ShortcutKeys shortcutKeys = (from e in mainWindow.mCommonHandler.mShortcutsConfigInstance.Shortcut
				where e.ShortcutKey.Equals(keyPressed, StringComparison.InvariantCulture)
				select e).First<ShortcutKeys>();
				ClientHotKeys clienthotKey = (ClientHotKeys)Enum.Parse(typeof(ClientHotKeys), shortcutKeys.ShortcutName);
				mainWindow.HandleClientHotKey(clienthotKey);
				this.CloseWindow();
			}
		}

		// Token: 0x04000208 RID: 520
		private string mHeaderContent;

		// Token: 0x04000209 RID: 521
		private string mBodyContent;

		// Token: 0x0400020A RID: 522
		private bool mIsLastPopup;

		// Token: 0x0400020B RID: 523
		private PopupArrowAlignment mPopArrowAlignment = PopupArrowAlignment.Top;
	}
}
