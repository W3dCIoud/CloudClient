﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000107 RID: 263
	public class PopupBrowserControl : UserControl, IDimOverlayControl, IComponentConnector
	{
		// Token: 0x06000A44 RID: 2628 RVA: 0x00008845 File Offset: 0x00006A45
		bool IDimOverlayControl.Close()
		{
			base.Visibility = Visibility.Hidden;
			this.ClosePopupBrowser();
			return true;
		}

		// Token: 0x170001F1 RID: 497
		// (get) Token: 0x06000A45 RID: 2629 RVA: 0x00006230 File Offset: 0x00004430
		// (set) Token: 0x06000A46 RID: 2630 RVA: 0x00005D29 File Offset: 0x00003F29
		bool IDimOverlayControl.IsCloseOnOverLayClick
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		// Token: 0x06000A47 RID: 2631 RVA: 0x0000624E File Offset: 0x0000444E
		bool IDimOverlayControl.Show()
		{
			base.Visibility = Visibility.Visible;
			return true;
		}

		// Token: 0x170001F2 RID: 498
		// (get) Token: 0x06000A48 RID: 2632 RVA: 0x00008855 File Offset: 0x00006A55
		// (set) Token: 0x06000A49 RID: 2633 RVA: 0x0000885D File Offset: 0x00006A5D
		public bool ShowControlInSeparateWindow { get; set; } = true;

		// Token: 0x06000A4A RID: 2634 RVA: 0x00008866 File Offset: 0x00006A66
		public PopupBrowserControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000A4B RID: 2635 RVA: 0x0003C028 File Offset: 0x0003A228
		public void Init(string url, string title, MainWindow window)
		{
			this.mTitle.Text = title;
			this.mBrowser.mUrl = url;
			this.mBrowser.mGrid = new Grid();
			this.mBrowser.Content = this.mBrowser.mGrid;
			this.mBrowser.CreateNewBrowser();
			if (window != null)
			{
				window.SizeChanged += this.Window_SizeChanged;
			}
			this.ParentWindow = window;
			this.mBrowser.ParentWindow = window;
			this.FixUpUILayout();
		}

		// Token: 0x06000A4C RID: 2636 RVA: 0x0000887B File Offset: 0x00006A7B
		private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			this.FixUpUILayout();
		}

		// Token: 0x06000A4D RID: 2637 RVA: 0x0003C0AC File Offset: 0x0003A2AC
		private void FixUpUILayout()
		{
			if (this.ParentWindow.mIsFullScreen || this.ParentWindow.WindowState == WindowState.Maximized)
			{
				base.Width = 880.0;
				base.Height = 530.0;
				return;
			}
			base.Width = 780.0;
			base.Height = 480.0;
		}

		// Token: 0x06000A4E RID: 2638 RVA: 0x0003C114 File Offset: 0x0003A314
		public void ClosePopupBrowser()
		{
			ClientStats.SendPopupBrowserStatsInMiscASync("closed", this.mBrowser.mUrl);
			if (this.ParentWindow != null)
			{
				this.ParentWindow.HideDimOverlay();
			}
			if (this.mBrowser.CefBrowser != null)
			{
				this.mBrowser.DisposeBrowser();
			}
			base.Visibility = Visibility.Hidden;
		}

		// Token: 0x06000A4F RID: 2639 RVA: 0x00008883 File Offset: 0x00006A83
		private void CloseBtn_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ClosePopupBrowser();
		}

		// Token: 0x06000A50 RID: 2640 RVA: 0x0003C168 File Offset: 0x0003A368
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/popupbrowsercontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000A51 RID: 2641 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000A52 RID: 2642 RVA: 0x0003C198 File Offset: 0x0003A398
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mGridBorder = (Border)target;
				return;
			case 2:
				this.mOuterGrid = (Grid)target;
				return;
			case 3:
				this.mTitle = (TextBlock)target;
				return;
			case 4:
				this.CloseBtn = (CustomPictureBox)target;
				this.CloseBtn.PreviewMouseLeftButtonUp += this.CloseBtn_PreviewMouseLeftButtonUp;
				return;
			case 5:
				this.mGrid = (Grid)target;
				return;
			case 6:
				this.mBrowser = (BrowserControl)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000685 RID: 1669
		private MainWindow ParentWindow;

		// Token: 0x04000687 RID: 1671
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mGridBorder;

		// Token: 0x04000688 RID: 1672
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mOuterGrid;

		// Token: 0x04000689 RID: 1673
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mTitle;

		// Token: 0x0400068A RID: 1674
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox CloseBtn;

		// Token: 0x0400068B RID: 1675
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mGrid;

		// Token: 0x0400068C RID: 1676
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal BrowserControl mBrowser;

		// Token: 0x0400068D RID: 1677
		private bool _contentLoaded;
	}
}
