﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200014C RID: 332
	public class SidebarPopup : UserControl, IComponentConnector
	{
		// Token: 0x17000212 RID: 530
		// (get) Token: 0x06000CEB RID: 3307 RVA: 0x00009D39 File Offset: 0x00007F39
		private int NumColumns
		{
			get
			{
				return this.mMainStackPanel.Children.Count;
			}
		}

		// Token: 0x06000CEC RID: 3308 RVA: 0x00009D4B File Offset: 0x00007F4B
		public SidebarPopup()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000CED RID: 3309 RVA: 0x000550DC File Offset: 0x000532DC
		public void AddElement(SidebarElement element)
		{
			if (element != null)
			{
				SidebarPopup.RemoveParentIfExists(element);
				if (this.NumColumns == 0)
				{
					this.AddToNewPanel(element);
					return;
				}
				StackPanel stackPanel = this.mMainStackPanel.Children[this.NumColumns - 1] as StackPanel;
				if (stackPanel.Children.Count == 3)
				{
					this.AddToNewPanel(element);
					return;
				}
				stackPanel.Children.Add(element);
			}
		}

		// Token: 0x06000CEE RID: 3310 RVA: 0x00055144 File Offset: 0x00053344
		private static void RemoveParentIfExists(SidebarElement element)
		{
			StackPanel stackPanel = element.Parent as StackPanel;
			if (stackPanel != null)
			{
				stackPanel.Children.Remove(element);
			}
		}

		// Token: 0x06000CEF RID: 3311 RVA: 0x00009D59 File Offset: 0x00007F59
		private void AddToNewPanel(SidebarElement element)
		{
			this.CreateStackPanel().Children.Add(element);
		}

		// Token: 0x06000CF0 RID: 3312 RVA: 0x0005516C File Offset: 0x0005336C
		public SidebarElement PopElement()
		{
			StackPanel stackPanel = this.mMainStackPanel.Children[this.NumColumns - 1] as StackPanel;
			SidebarElement sidebarElement = stackPanel.Children[stackPanel.Children.Count - 1] as SidebarElement;
			stackPanel.Children.Remove(sidebarElement);
			if (stackPanel.Children.Count == 0)
			{
				this.mMainStackPanel.Children.Remove(stackPanel);
			}
			return sidebarElement;
		}

		// Token: 0x06000CF1 RID: 3313 RVA: 0x000551E0 File Offset: 0x000533E0
		private StackPanel CreateStackPanel()
		{
			StackPanel stackPanel = new StackPanel
			{
				Margin = new Thickness(2.0, 0.0, 2.0, 0.0),
				Orientation = Orientation.Vertical
			};
			this.mMainStackPanel.Children.Add(stackPanel);
			return stackPanel;
		}

		// Token: 0x06000CF2 RID: 3314 RVA: 0x00005D29 File Offset: 0x00003F29
		private void SidebarPopup_Loaded(object sender, RoutedEventArgs e)
		{
		}

		// Token: 0x06000CF3 RID: 3315 RVA: 0x0005523C File Offset: 0x0005343C
		internal void InitAllElements(IEnumerable<SidebarElement> listOfHiddenElements)
		{
			foreach (SidebarElement sidebarElement in listOfHiddenElements)
			{
				if (sidebarElement.Visibility == Visibility.Visible)
				{
					sidebarElement.Margin = new Thickness(0.0, 2.0, 0.0, 2.0);
					this.AddElement(sidebarElement);
				}
			}
		}

		// Token: 0x06000CF4 RID: 3316 RVA: 0x000552BC File Offset: 0x000534BC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/sidebarpopup.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000CF5 RID: 3317 RVA: 0x000552EC File Offset: 0x000534EC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((SidebarPopup)target).Loaded += this.SidebarPopup_Loaded;
				return;
			case 2:
				this.mGrid = (Grid)target;
				return;
			case 3:
				this.mMainStackPanel = (StackPanel)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040008DD RID: 2269
		private const int NumElementsPerRow = 3;

		// Token: 0x040008DE RID: 2270
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mGrid;

		// Token: 0x040008DF RID: 2271
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mMainStackPanel;

		// Token: 0x040008E0 RID: 2272
		private bool _contentLoaded;
	}
}
