﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200008E RID: 142
	public class CustomPersistentToastPopupControl : UserControl, IComponentConnector
	{
		// Token: 0x06000582 RID: 1410 RVA: 0x000059F4 File Offset: 0x00003BF4
		public CustomPersistentToastPopupControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000583 RID: 1411 RVA: 0x00020E94 File Offset: 0x0001F094
		public CustomPersistentToastPopupControl(Window window)
		{
			this.InitializeComponent();
			if (window != null)
			{
				Grid grid = new Grid();
				object content = window.Content;
				window.Content = grid;
				grid.Children.Add(content as UIElement);
				grid.Children.Add(this);
			}
		}

		// Token: 0x06000584 RID: 1412 RVA: 0x00020EE4 File Offset: 0x0001F0E4
		public bool Init(MainWindow window, string text)
		{
			this.ParentWindow = window;
			if (this.ParentWindow != null && this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsShootingModeTooltipEnabled && RegistryManager.Instance.IsShootingModeTooltipVisible)
			{
				base.Visibility = Visibility.Visible;
				this.mPersistentToastTextblock.Text = text;
				this.mPersistentToastPopupBorder.HorizontalAlignment = HorizontalAlignment.Center;
				this.mPersistentToastPopupBorder.VerticalAlignment = VerticalAlignment.Center;
				base.UpdateLayout();
				return true;
			}
			return false;
		}

		// Token: 0x06000585 RID: 1413 RVA: 0x00005A02 File Offset: 0x00003C02
		private void MCloseIcon_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mCloseSettingsPopup.IsOpen = true;
		}

		// Token: 0x06000586 RID: 1414 RVA: 0x00005A10 File Offset: 0x00003C10
		private void Grid_MouseEnter(object sender, MouseEventArgs e)
		{
			(sender as Grid).Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#33FFFFFF"));
		}

		// Token: 0x06000587 RID: 1415 RVA: 0x00005A31 File Offset: 0x00003C31
		private void Grid_MouseLeave(object sender, MouseEventArgs e)
		{
			(sender as Grid).Background = Brushes.Transparent;
		}

		// Token: 0x06000588 RID: 1416 RVA: 0x00005A43 File Offset: 0x00003C43
		private void mNeverShowAgain_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mCloseSettingsPopup.IsOpen = false;
			base.Visibility = Visibility.Collapsed;
			RegistryManager.Instance.IsShootingModeTooltipVisible = false;
		}

		// Token: 0x06000589 RID: 1417 RVA: 0x00005A63 File Offset: 0x00003C63
		private void Close_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mCloseSettingsPopup.IsOpen = false;
			base.Visibility = Visibility.Collapsed;
			this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.IsShootingModeTooltipEnabled = false;
		}

		// Token: 0x0600058A RID: 1418 RVA: 0x00020F5C File Offset: 0x0001F15C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/custompersistenttoastpopupcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600058B RID: 1419 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600058C RID: 1420 RVA: 0x00020F8C File Offset: 0x0001F18C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mPersistentToastPopupBorder = (Border)target;
				return;
			case 2:
				this.mCloseIcon = (CustomPictureBox)target;
				this.mCloseIcon.MouseLeftButtonUp += this.MCloseIcon_MouseLeftButtonUp;
				return;
			case 3:
				this.mPersistentToastTextblock = (TextBlock)target;
				return;
			case 4:
				this.mCloseSettingsPopup = (CustomPopUp)target;
				return;
			case 5:
				this.dummyGrid = (Grid)target;
				return;
			case 6:
				this.mCloseSettingsPopupBorder = (Border)target;
				return;
			case 7:
				this.mMaskBorder1 = (Border)target;
				return;
			case 8:
				((Grid)target).MouseEnter += this.Grid_MouseEnter;
				((Grid)target).MouseLeave += this.Grid_MouseLeave;
				((Grid)target).MouseLeftButtonUp += this.mNeverShowAgain_MouseLeftButtonUp;
				return;
			case 9:
				((Grid)target).MouseEnter += this.Grid_MouseEnter;
				((Grid)target).MouseLeave += this.Grid_MouseLeave;
				((Grid)target).MouseLeftButtonUp += this.Close_MouseLeftButtonUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040002F3 RID: 755
		private MainWindow ParentWindow;

		// Token: 0x040002F4 RID: 756
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mPersistentToastPopupBorder;

		// Token: 0x040002F5 RID: 757
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCloseIcon;

		// Token: 0x040002F6 RID: 758
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mPersistentToastTextblock;

		// Token: 0x040002F7 RID: 759
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mCloseSettingsPopup;

		// Token: 0x040002F8 RID: 760
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid dummyGrid;

		// Token: 0x040002F9 RID: 761
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mCloseSettingsPopupBorder;

		// Token: 0x040002FA RID: 762
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder1;

		// Token: 0x040002FB RID: 763
		private bool _contentLoaded;
	}
}
