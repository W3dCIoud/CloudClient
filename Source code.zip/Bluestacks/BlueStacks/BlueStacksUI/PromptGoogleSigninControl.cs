﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000E5 RID: 229
	public class PromptGoogleSigninControl : UserControl, IComponentConnector
	{
		// Token: 0x06000940 RID: 2368 RVA: 0x00007E4D File Offset: 0x0000604D
		public PromptGoogleSigninControl(MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
		}

		// Token: 0x06000941 RID: 2369 RVA: 0x00006BEE File Offset: 0x00004DEE
		private void CloseBtn_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x06000942 RID: 2370 RVA: 0x000367B0 File Offset: 0x000349B0
		private void CloseBtn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			try
			{
				ClientStats.SendMiscellaneousStatsAsync("GoogleSigninClose", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, null, null, RegistryManager.Instance.InstallID, null, null, null);
				BlueStacksUIUtils.CloseContainerWindow(this);
			}
			catch (Exception ex)
			{
				string str = "Exception in CloseBtn_MouseLeftButtonUp. Exception: ";
				Exception ex2 = ex;
				Logger.Error(str + ((ex2 != null) ? ex2.ToString() : null));
			}
		}

		// Token: 0x06000943 RID: 2371 RVA: 0x00036824 File Offset: 0x00034A24
		private void SigninBtn_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				AppIcon appIcon = this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon("com.android.vending");
				if (appIcon != null)
				{
					this.ParentWindow.mTopBar.mAppTabButtons.AddAppTab(appIcon.AppName, appIcon.PackageName, appIcon.ActivityName, appIcon.ImageName, true, true, false);
				}
				ClientStats.SendMiscellaneousStatsAsync("GoogleSigninClick", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, null, null, RegistryManager.Instance.InstallID, null, null, null);
				BlueStacksUIUtils.CloseContainerWindow(this);
			}
			catch (Exception ex)
			{
				string str = "Exception in SigninBtn_Click. Exception: ";
				Exception ex2 = ex;
				Logger.Error(str + ((ex2 != null) ? ex2.ToString() : null));
			}
		}

		// Token: 0x06000944 RID: 2372 RVA: 0x000368E4 File Offset: 0x00034AE4
		private void SigninLaterBtn_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				ClientStats.SendMiscellaneousStatsAsync("GoogleSigninLater", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, null, null, RegistryManager.Instance.InstallID, null, null, null);
				BlueStacksUIUtils.CloseContainerWindow(this);
			}
			catch (Exception ex)
			{
				string str = "Exception in SigninLaterBtn_Click. Exception: ";
				Exception ex2 = ex;
				Logger.Error(str + ((ex2 != null) ? ex2.ToString() : null));
			}
		}

		// Token: 0x06000945 RID: 2373 RVA: 0x00036958 File Offset: 0x00034B58
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/promptgooglesignincontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000946 RID: 2374 RVA: 0x00036988 File Offset: 0x00034B88
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.CloseBtn = (CustomPictureBox)target;
				this.CloseBtn.PreviewMouseDown += this.CloseBtn_PreviewMouseDown;
				this.CloseBtn.MouseLeftButtonUp += this.CloseBtn_MouseLeftButtonUp;
				return;
			case 2:
				this.SigninLaterBtn = (CustomButton)target;
				this.SigninLaterBtn.Click += this.SigninLaterBtn_Click;
				return;
			case 3:
				this.SigninBtn = (CustomButton)target;
				this.SigninBtn.Click += this.SigninBtn_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040005C3 RID: 1475
		private MainWindow ParentWindow;

		// Token: 0x040005C4 RID: 1476
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox CloseBtn;

		// Token: 0x040005C5 RID: 1477
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton SigninLaterBtn;

		// Token: 0x040005C6 RID: 1478
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton SigninBtn;

		// Token: 0x040005C7 RID: 1479
		private bool _contentLoaded;
	}
}
