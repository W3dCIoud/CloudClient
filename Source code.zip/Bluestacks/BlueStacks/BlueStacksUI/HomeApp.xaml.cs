﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000235 RID: 565
	public partial class HomeApp : System.Windows.Controls.UserControl
	{
		// Token: 0x14000028 RID: 40
		// (add) Token: 0x0600143A RID: 5178 RVA: 0x0007A064 File Offset: 0x00078264
		// (remove) Token: 0x0600143B RID: 5179 RVA: 0x0007A09C File Offset: 0x0007829C
		internal event Action PlayGif;

		// Token: 0x14000029 RID: 41
		// (add) Token: 0x0600143C RID: 5180 RVA: 0x0007A0D4 File Offset: 0x000782D4
		// (remove) Token: 0x0600143D RID: 5181 RVA: 0x0007A10C File Offset: 0x0007830C
		internal event Action PauseGif;

		// Token: 0x170002BF RID: 703
		// (get) Token: 0x0600143E RID: 5182 RVA: 0x0000DDEA File Offset: 0x0000BFEA
		private MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x0600143F RID: 5183 RVA: 0x0007A144 File Offset: 0x00078344
		public HomeApp(MainWindow window)
		{
			this.InitializeComponent();
			this.mMainWindow = window;
			this.SetWallpaper();
			this.InstalledAppsDrawer = (this.InstalledAppsDrawerScrollBar.Content as WrapPanel);
			this.SetLocalizedString();
			if (!DesignerProperties.GetIsInDesignMode(this) && PromotionObject.Instance != null)
			{
				PromotionObject.BackgroundPromotionHandler = (EventHandler)Delegate.Combine(PromotionObject.BackgroundPromotionHandler, new EventHandler(this.HomeApp_BackgroundPromotionHandler));
			}
			if (!FeatureManager.Instance.IsMultiInstanceControlsGridVisible)
			{
				this.mMultiInstanceControlsGrid.Visibility = Visibility.Hidden;
			}
			if (!FeatureManager.Instance.IsAppSettingsAvailable)
			{
				this.mAppSettings.Visibility = Visibility.Hidden;
				this.mGridSeparator.Visibility = Visibility.Hidden;
			}
			this.searchHoverTimer = new DispatcherTimer
			{
				Interval = TimeSpan.FromMilliseconds(700.0)
			};
			this.searchHoverTimer.Tick += delegate(object <p0>, EventArgs <p1>)
			{
				this.OpenSearchSuggestions();
			};
			this.Mask.CornerRadius = new CornerRadius(0.0, this.searchTextBoxBorder.CornerRadius.TopRight, this.searchTextBoxBorder.CornerRadius.BottomRight, 0.0);
		}

		// Token: 0x170002C0 RID: 704
		// (get) Token: 0x06001440 RID: 5184 RVA: 0x0000DE0B File Offset: 0x0000C00B
		// (set) Token: 0x06001441 RID: 5185 RVA: 0x0000DE13 File Offset: 0x0000C013
		internal bool SideHtmlBrowserInited { get; set; }

		// Token: 0x170002C1 RID: 705
		// (get) Token: 0x06001442 RID: 5186 RVA: 0x0000DE1C File Offset: 0x0000C01C
		// (set) Token: 0x06001443 RID: 5187 RVA: 0x0000DE24 File Offset: 0x0000C024
		internal BrowserControl SideHtmlBrowser { get; set; }

		// Token: 0x06001444 RID: 5188 RVA: 0x0007A298 File Offset: 0x00078498
		internal void InitiateSideHtmlBrowser()
		{
			object obj = HomeApp.syncRoot;
			lock (obj)
			{
				if (FeatureManager.Instance.IsHtmlSideBar && !this.ParentWindow.mWelcomeTab.mHomeApp.SideHtmlBrowserInited && CefHelper.CefInited && !RegistryManager.Instance.IsPremium)
				{
					this.ParentWindow.mWelcomeTab.mHomeApp.CreateSideHtmlBrowserControl();
				}
			}
		}

		// Token: 0x06001445 RID: 5189 RVA: 0x0000DE2D File Offset: 0x0000C02D
		internal void CreateSideHtmlBrowserControl()
		{
			this.SideHtmlBrowserInited = true;
			base.Dispatcher.Invoke(new Action(delegate()
			{
				BrowserControl browserControl = new BrowserControl(BlueStacksUIUtils.GetHtmlSidePanelUrl())
				{
					Visibility = Visibility.Visible
				};
				CustomPictureBox element = new CustomPictureBox
				{
					HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
					VerticalAlignment = VerticalAlignment.Center,
					Height = 30.0,
					Width = 30.0,
					ImageName = "loader",
					IsImageToBeRotated = true
				};
				this.mAppRecommendationsGrid.Children.Add(browserControl);
				this.mAppRecommendationsGrid.Children.Add(element);
				browserControl.CreateNewBrowser();
				this.SideHtmlBrowser = browserControl;
			}), new object[0]);
		}

		// Token: 0x06001446 RID: 5190 RVA: 0x0007A318 File Offset: 0x00078518
		internal void ChangeSideRecommendationsVisibility(bool isAppRecommendationsVisible, bool isSearchBarVisible)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (!isAppRecommendationsVisible)
				{
					if (!isAppRecommendationsVisible)
					{
						this.mAppRecommendationsGrid.Visibility = Visibility.Collapsed;
						this.InstalledAppsDrawerScrollBar.SetValue(Grid.ColumnSpanProperty, 2);
						this.mMultiInstanceControlsGrid.SetValue(Grid.ColumnSpanProperty, 2);
						if (isSearchBarVisible)
						{
							this.mSearchGrid.Visibility = Visibility.Visible;
							this.mSearchGrid.Margin = new Thickness(0.0, 20.0, 20.0, 0.0);
							this.mSearchGrid.Width = 350.0;
							this.mIsShowSearchRecommendations = true;
							this.mSearchRecommendationBorder.Margin = new Thickness(0.0, 59.0, 20.0, 0.0);
							this.mSearchRecommendationBorder.Width = 350.0;
							return;
						}
						this.mSearchGrid.Visibility = Visibility.Collapsed;
					}
					return;
				}
				this.mAppRecommendationsGrid.Visibility = Visibility.Visible;
				this.InstalledAppsDrawerScrollBar.SetValue(Grid.ColumnSpanProperty, 1);
				this.mMultiInstanceControlsGrid.SetValue(Grid.ColumnSpanProperty, 1);
				if (isSearchBarVisible)
				{
					this.mDiscoverApps.Visibility = Visibility.Visible;
					this.appRecomScrollViewer.Visibility = Visibility.Visible;
					this.mSearchGrid.Visibility = Visibility.Visible;
					this.mSearchGrid.Margin = new Thickness(20.0, 54.0, 20.0, 0.0);
					this.mSearchGrid.Width = 240.0;
					this.mIsShowSearchRecommendations = false;
					this.mSearchRecommendationBorder.Margin = new Thickness(20.0, 88.0, 20.0, 0.0);
					this.mSearchRecommendationBorder.Width = 240.0;
					return;
				}
				this.mSearchGrid.Visibility = Visibility.Collapsed;
				this.mDiscoverApps.Visibility = Visibility.Collapsed;
				this.appRecomScrollViewer.Visibility = Visibility.Collapsed;
				this.mAppRecommendationsGrid.Width = 345.0;
			}), new object[0]);
		}

		// Token: 0x06001447 RID: 5191 RVA: 0x0000DE54 File Offset: 0x0000C054
		internal void UpdateGamepadIcons()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				foreach (KeyValuePair<string, AppIcon> keyValuePair in this.dictAppIcons)
				{
					if (keyValuePair.Value.IsGamepadCompatible)
					{
						keyValuePair.Value.mGamepadIcon.ImageName = (this.ParentWindow.IsGamepadConnected ? "apps_connected_icon" : "apps_disconnected_icon");
					}
				}
			}), new object[0]);
		}

		// Token: 0x06001448 RID: 5192 RVA: 0x0000DE74 File Offset: 0x0000C074
		internal bool CheckDictAppIconFor(string packagename, Predicate<AppIcon> pred)
		{
			return this.dictAppIcons.ContainsKey(packagename) && pred(this.dictAppIcons[packagename]);
		}

		// Token: 0x06001449 RID: 5193 RVA: 0x0000DE98 File Offset: 0x0000C098
		private void SetWallpaper()
		{
			if (File.Exists(HomeApp.BackgroundImagePath))
			{
				this.mBackgroundImage.IsFullImagePath = true;
				this.mBackgroundImage.ImageName = HomeApp.BackgroundImagePath;
			}
		}

		// Token: 0x0600144A RID: 5194 RVA: 0x0000DEC2 File Offset: 0x0000C0C2
		private void HomeApp_BackgroundPromotionHandler(object sender, EventArgs e)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (string.IsNullOrEmpty(PromotionObject.Instance.BackgroundPromotionImagePath))
				{
					this.SetWallpaper();
					return;
				}
				this.mBackgroundImage.IsFullImagePath = true;
				this.mBackgroundImage.ImageName = PromotionObject.Instance.BackgroundPromotionImagePath;
			}), new object[0]);
		}

		// Token: 0x0600144B RID: 5195 RVA: 0x0000DEE2 File Offset: 0x0000C0E2
		internal void HomeApp_AppSuggestionHandler(bool checkForAnimationIcon)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				new List<string>();
				this.RemoveIconIfExists();
				object obj = ((ICollection)PromotionObject.Instance.AppSuggestionList).SyncRoot;
				lock (obj)
				{
					foreach (AppSuggestionPromotion appSuggestionPromotion in PromotionObject.Instance.AppSuggestionList)
					{
						if (!new JsonParser(this.ParentWindow.mVmName).IsAppInstalled(appSuggestionPromotion.AppPackage))
						{
							if (HomeApp.CheckIfPresentInRedDotShownRegistry(appSuggestionPromotion.AppPackage))
							{
								appSuggestionPromotion.IsShowRedDot = false;
							}
							this.AddAppSuggestionIcon(appSuggestionPromotion);
						}
						else
						{
							if (!HomeApp.CheckIfPresentInRedDotShownRegistry(appSuggestionPromotion.AppPackage) && appSuggestionPromotion.IsShowRedDot)
							{
								this.AddRedDot(appSuggestionPromotion.AppPackage);
							}
							else
							{
								appSuggestionPromotion.IsShowRedDot = false;
							}
							this.AddBorderInIcon(appSuggestionPromotion);
						}
					}
				}
				bool enable = this.dictAppIcons.Keys.Intersect(PackageActivityNames.ThirdParty.AllOneStorePackageNames).Any<string>();
				foreach (string appPackage in PackageActivityNames.ThirdParty.AllOneStorePackageNames)
				{
					Utils.EnableDisableApp(appPackage, enable, this.ParentWindow.mVmName);
				}
				this.StartGif();
			}), new object[0]);
		}

		// Token: 0x0600144C RID: 5196 RVA: 0x0000DF02 File Offset: 0x0000C102
		internal static void AppSuggestionPromotion()
		{
			Action<bool> appSuggestionHandler = PromotionObject.AppSuggestionHandler;
			if (appSuggestionHandler == null)
			{
				return;
			}
			appSuggestionHandler(false);
		}

		// Token: 0x0600144D RID: 5197 RVA: 0x0007A360 File Offset: 0x00078560
		internal static bool CheckIfPresentInRedDotShownRegistry(string package)
		{
			string redDotShownOnIcon = RegistryManager.Instance.RedDotShownOnIcon;
			if (!string.IsNullOrEmpty(redDotShownOnIcon))
			{
				char[] separator = new char[]
				{
					','
				};
				foreach (string text in redDotShownOnIcon.Split(separator, StringSplitOptions.None))
				{
					if (!string.IsNullOrEmpty(package) && text.Equals(package, StringComparison.InvariantCultureIgnoreCase))
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x0600144E RID: 5198 RVA: 0x0007A3C0 File Offset: 0x000785C0
		internal void AddIconWithRedDot(string appPackage)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				object obj = ((ICollection)PromotionObject.Instance.AppSuggestionList).SyncRoot;
				lock (obj)
				{
					JsonParser jsonParser = new JsonParser(this.ParentWindow.mVmName);
					foreach (AppSuggestionPromotion appSuggestionPromotion in PromotionObject.Instance.AppSuggestionList)
					{
						if (string.Equals(appSuggestionPromotion.AppPackage, appPackage, StringComparison.InvariantCulture))
						{
							if (!jsonParser.IsAppInstalled(appSuggestionPromotion.AppPackage))
							{
								HomeApp.RemovePackageInRedDotShownRegistry(appSuggestionPromotion.AppPackage);
								this.AddAppSuggestionIcon(appSuggestionPromotion);
							}
							else
							{
								HomeApp.RemovePackageInRedDotShownRegistry(appSuggestionPromotion.AppPackage);
								this.AddRedDot(appPackage);
							}
						}
					}
				}
			}), new object[0]);
		}

		// Token: 0x0600144F RID: 5199 RVA: 0x0007A400 File Offset: 0x00078600
		internal void RemoveIconIfExists()
		{
			List<string> list = new List<string>();
			JsonParser jsonParser = new JsonParser(this.ParentWindow.mVmName);
			using (Dictionary<string, AppIcon>.ValueCollection.Enumerator enumerator = this.dictAppIcons.Values.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					AppIcon icon = enumerator.Current;
					object obj = ((ICollection)PromotionObject.Instance.AppSuggestionList).SyncRoot;
					lock (obj)
					{
						if (!icon.IsAppSuggestionActive)
						{
							if (icon.IsInstalledApp)
							{
								continue;
							}
							if (!PromotionObject.Instance.AppSuggestionList.Any((AppSuggestionPromotion _) => string.Equals(_.AppLocation, "more_apps", StringComparison.InvariantCulture)))
							{
								continue;
							}
						}
						if (!PromotionObject.Instance.AppSuggestionList.Any((AppSuggestionPromotion _) => string.Equals(_.AppPackage, icon.PackageName, StringComparison.InvariantCultureIgnoreCase)))
						{
							if (!jsonParser.IsAppInstalled(icon.PackageName))
							{
								list.Add(icon.PackageName);
							}
							else
							{
								icon.RemovePromotionBorderInstalledApp();
							}
						}
					}
				}
			}
			foreach (string package in list)
			{
				this.RemoveAppIcon(package, null);
			}
		}

		// Token: 0x06001450 RID: 5200 RVA: 0x0007A580 File Offset: 0x00078780
		internal void AddRedDot(string package)
		{
			try
			{
				if (this.dictAppIcons.ContainsKey(package))
				{
					this.dictAppIcons[package].mRedDotNotifIcon.Visibility = Visibility.Visible;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in showing red dot on installed app: " + ex.ToString());
			}
		}

		// Token: 0x06001451 RID: 5201 RVA: 0x0007A5DC File Offset: 0x000787DC
		internal static void AddPackageInRedDotShownRegistry(string appPackage)
		{
			string text = RegistryManager.Instance.RedDotShownOnIcon;
			if (!string.IsNullOrEmpty(text))
			{
				text = text + "," + appPackage;
			}
			else
			{
				text = appPackage;
			}
			RegistryManager.Instance.RedDotShownOnIcon = text;
		}

		// Token: 0x06001452 RID: 5202 RVA: 0x0007A618 File Offset: 0x00078818
		internal static void RemovePackageInRedDotShownRegistry(string appPackage)
		{
			string redDotShownOnIcon = RegistryManager.Instance.RedDotShownOnIcon;
			char[] separator = new char[]
			{
				','
			};
			string[] array = (from w in redDotShownOnIcon.Split(separator, StringSplitOptions.None)
			where !w.Contains(appPackage)
			select w).ToArray<string>();
			string text = string.Empty;
			foreach (string text2 in array)
			{
				if (!string.IsNullOrEmpty(text2))
				{
					text = text + text2.ToString(CultureInfo.InvariantCulture) + ",";
				}
			}
			RegistryManager.Instance.RedDotShownOnIcon = text;
		}

		// Token: 0x06001453 RID: 5203 RVA: 0x0000DF14 File Offset: 0x0000C114
		internal void ReInitAppJson()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.InitIcons();
			}), new object[0]);
		}

		// Token: 0x06001454 RID: 5204 RVA: 0x0000DF34 File Offset: 0x0000C134
		internal void Init()
		{
			if (!DesignerProperties.GetIsInDesignMode(this))
			{
				this.InitSystemIcons();
				this.InitIcons();
			}
			this.GetSearchTextFromCloud();
		}

		// Token: 0x06001455 RID: 5205 RVA: 0x0000DF50 File Offset: 0x0000C150
		private void GetSearchTextFromCloud()
		{
			new Thread(delegate()
			{
				try
				{
					this.defaultSearchBoxText = LocaleStrings.GetLocalizedString("STRING_SEARCH");
					string urlWithParams = WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/app_center_searchdefaultquery");
					Logger.Debug("url for search api :" + urlWithParams);
					string text = BstHttpClient.Get(urlWithParams, null, false, string.Empty, 0, 1, 0, false);
					Logger.Debug("result for app_center_searchdefaultquery : " + text);
					JObject jobject = JObject.Parse(text);
					if ((bool)jobject["success"])
					{
						string text2 = jobject["result"].ToString().Trim();
						if (!string.IsNullOrEmpty(text2))
						{
							this.defaultSearchBoxText = text2;
						}
						Logger.Debug("response from search text cloud api :" + text2);
					}
				}
				catch (Exception ex)
				{
					Logger.Warning("Failed to fetch text from cloud... Err : " + ex.ToString());
				}
				base.Dispatcher.Invoke(new Action(delegate()
				{
					this.mSearchTextBox.Text = this.defaultSearchBoxText;
				}), new object[0]);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06001456 RID: 5206 RVA: 0x0007A6B8 File Offset: 0x000788B8
		internal void InitAppPromotionEvents()
		{
			if (PromotionObject.Instance != null)
			{
				PromotionObject.AppSuggestionHandler = (Action<bool>)Delegate.Combine(PromotionObject.AppSuggestionHandler, new Action<bool>(this.HomeApp_AppSuggestionHandler));
				PromotionObject.AppRecommendationHandler = (Action<bool>)Delegate.Combine(PromotionObject.AppRecommendationHandler, new Action<bool>(this.ShowAppRecommendations));
			}
		}

		// Token: 0x06001457 RID: 5207 RVA: 0x0007A70C File Offset: 0x0007890C
		private void InitIcons()
		{
			foreach (AppInfo item in new JsonParser(this.ParentWindow.mVmName).GetAppList().ToList<AppInfo>())
			{
				this.AddIcon(item);
			}
		}

		// Token: 0x06001458 RID: 5208 RVA: 0x0007A774 File Offset: 0x00078974
		private void InitSystemIcons()
		{
			List<AppInfo> list = new JsonParser(string.Empty).GetAppList().ToList<AppInfo>();
			this.moreAppsIcon.AddToDock(50.0, 50.0);
			if (this.mMoreAppsDockPanel.Children.Count <= 1)
			{
				foreach (AppInfo appInfo in list)
				{
					if (string.Compare(appInfo.Package, "com.android.vending", StringComparison.OrdinalIgnoreCase) != 0 && string.Compare(appInfo.Package, "com.google.android.play.games", StringComparison.OrdinalIgnoreCase) != 0)
					{
						AppIcon newIconForKey = this.GetNewIconForKey(appInfo.Package);
						newIconForKey.Init(appInfo);
						newIconForKey.AppName = "STRING_" + appInfo.Name.ToUpper(CultureInfo.InvariantCulture).Trim().Replace(" ", "_") + "_APP";
						newIconForKey.IsInstalledApp = false;
						newIconForKey.AddToMoreAppsDock(55.0, 55.0);
						this.AddMoreAppsDockPanelIcon(newIconForKey);
					}
					else
					{
						AppIcon newIconForKey2 = this.GetNewIconForKey(appInfo.Package);
						newIconForKey2.Init(appInfo);
						newIconForKey2.IsInstalledApp = false;
						newIconForKey2.mIsAppRemovable = false;
						newIconForKey2.AppName = "STRING_" + appInfo.Name.ToUpper(CultureInfo.InvariantCulture).Trim().Replace(" ", "_") + "_APP";
						this.AddInstallDrawerIcon(newIconForKey2);
					}
				}
			}
		}

		// Token: 0x06001459 RID: 5209 RVA: 0x0000DF6F File Offset: 0x0000C16F
		private void SetLocalizedString()
		{
			this.mLoadingGrid.ProgressText = "STRING_LOADING_ENGINE";
		}

		// Token: 0x0600145A RID: 5210 RVA: 0x0007A91C File Offset: 0x00078B1C
		private AppIcon AddIcon(AppInfo item)
		{
			AppIcon newIconForKey = this.GetNewIconForKey(item.Package);
			newIconForKey.Init(item);
			this.AddInstallDrawerIcon(newIconForKey);
			return newIconForKey;
		}

		// Token: 0x0600145B RID: 5211 RVA: 0x0007A948 File Offset: 0x00078B48
		private void RearrangeAppJson()
		{
			foreach (AppInfo appInfo in new JsonParser(this.ParentWindow.mVmName).GetAppList().ToList<AppInfo>())
			{
				try
				{
					if (this.dictAppIcons.ContainsKey(appInfo.Package))
					{
						AppIcon appIcon = this.dictAppIcons[appInfo.Package];
						this.InstalledAppsDrawer.Children.Remove(appIcon);
						this.AddInstallDrawerIcon(appIcon);
					}
				}
				catch (Exception ex)
				{
					Logger.Warning("Exception in rearrange package: " + ex.ToString());
				}
			}
		}

		// Token: 0x0600145C RID: 5212 RVA: 0x0007AA0C File Offset: 0x00078C0C
		private void AddInstallDrawerIcon(AppIcon icon)
		{
			if (string.Compare(icon.PackageName, "com.android.vending", StringComparison.OrdinalIgnoreCase) == 0)
			{
				icon.MyAppPriority = 1;
			}
			if (this.ParentWindow.mAppHandler != null && !this.ParentWindow.mAppHandler.IsAppInstalled(icon.PackageName) && PromotionObject.Instance.MyAppsOrder.ContainsKey(icon.PackageName) && icon.MyAppPriority != PromotionObject.Instance.MyAppsOrder[icon.PackageName])
			{
				icon.MyAppPriority = PromotionObject.Instance.MyAppsOrder[icon.PackageName];
			}
			int num = 0;
			using (IEnumerator<AppIcon> enumerator = this.InstalledAppsDrawer.Children.OfType<AppIcon>().GetEnumerator())
			{
				while (enumerator.MoveNext() && enumerator.Current.MyAppPriority <= icon.MyAppPriority)
				{
					num++;
				}
			}
			this.InstalledAppsDrawer.Children.Insert(num, icon);
		}

		// Token: 0x0600145D RID: 5213 RVA: 0x0007AB10 File Offset: 0x00078D10
		internal void AddAppIcon(string package)
		{
			AppInfo appInfoFromPackageName = new JsonParser(this.ParentWindow.mVmName).GetAppInfoFromPackageName(package);
			if (appInfoFromPackageName != null)
			{
				this.AddIcon(appInfoFromPackageName);
			}
		}

		// Token: 0x0600145E RID: 5214 RVA: 0x0007AB40 File Offset: 0x00078D40
		internal void AddAppIcon(string package, string appName, string apkUrl, DownloadInstallApk downloader)
		{
			if (!string.IsNullOrEmpty(package))
			{
				AppIcon newIconForKey = this.GetNewIconForKey(package);
				newIconForKey.Init(package, appName, apkUrl, downloader);
				this.AddInstallDrawerIcon(newIconForKey);
			}
		}

		// Token: 0x0600145F RID: 5215 RVA: 0x0007AB70 File Offset: 0x00078D70
		internal void AddMacroAppIcon(string package)
		{
			if (!string.IsNullOrEmpty(package) && this.GetAppIcon(package) != null)
			{
				string key = package + "_macro";
				AppIcon newIconForKey = this.GetNewIconForKey(key);
				string appname = LocaleStrings.GetLocalizedString("STRING_REROLL_APP_PREFIX") + " - " + this.GetAppIcon(package).AppName;
				newIconForKey.InitRerollIcon(package, appname);
				this.AddInstallDrawerIcon(newIconForKey);
			}
		}

		// Token: 0x06001460 RID: 5216 RVA: 0x0000DF81 File Offset: 0x0000C181
		private void TestEvent(object sender, RoutedEventArgs e)
		{
			System.Windows.MessageBox.Show("asjkhjkdf");
		}

		// Token: 0x06001461 RID: 5217 RVA: 0x0000DF8E File Offset: 0x0000C18E
		private void TestEvent2(object sender, RoutedEventArgs e)
		{
			System.Windows.MessageBox.Show("New Message!");
		}

		// Token: 0x06001462 RID: 5218 RVA: 0x0000DF9B File Offset: 0x0000C19B
		internal void StartGif()
		{
			Action playGif = this.PlayGif;
			if (playGif == null)
			{
				return;
			}
			playGif();
		}

		// Token: 0x06001463 RID: 5219 RVA: 0x0000DFAD File Offset: 0x0000C1AD
		internal void StopGif()
		{
			Action pauseGif = this.PauseGif;
			if (pauseGif == null)
			{
				return;
			}
			pauseGif();
		}

		// Token: 0x06001464 RID: 5220 RVA: 0x0007ABD4 File Offset: 0x00078DD4
		internal AppIcon AddAppSuggestionIcon(AppSuggestionPromotion appSuggestionInfo)
		{
			string appPackage = appSuggestionInfo.AppPackage;
			double height = 50.0;
			double width = 50.0;
			AppIcon newIconForKey = this.GetNewIconForKey(appPackage);
			try
			{
				if (newIconForKey != null)
				{
					newIconForKey.IsAppSuggestionActive = true;
					newIconForKey.PackageName = appPackage;
					if (appSuggestionInfo.IsShowRedDot)
					{
						newIconForKey.mRedDotNotifIcon.Visibility = Visibility.Visible;
					}
					newIconForKey.Init(appSuggestionInfo);
					if (!appSuggestionInfo.IsEmailRequired || RegistryManager.Instance.Guest[this.ParentWindow.mVmName].IsGoogleSigninDone)
					{
						if (string.Equals(appSuggestionInfo.AppLocation, "dock", StringComparison.InvariantCultureIgnoreCase))
						{
							if (newIconForKey.IsGifIcon)
							{
								this.PlayGif += newIconForKey.GifAppIconPlay;
								this.PauseGif += newIconForKey.GifAppIconPause;
							}
							if (appSuggestionInfo.IconHeight != 0.0)
							{
								height = appSuggestionInfo.IconHeight;
							}
							if (appSuggestionInfo.IconWidth != 0.0)
							{
								width = appSuggestionInfo.IconWidth;
							}
							newIconForKey.AddToDock(height, width);
							this.AddDockPanelIcon(newIconForKey);
						}
						else if (string.Equals(appSuggestionInfo.AppLocation, "more_apps", StringComparison.InvariantCultureIgnoreCase))
						{
							newIconForKey.AddToMoreAppsDock(55.0, 55.0);
							this.AddMoreAppsDockPanelIcon(newIconForKey);
						}
						else
						{
							this.AddInstallDrawerIcon(newIconForKey);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in adding app suggestion icon: " + ex.ToString());
			}
			return newIconForKey;
		}

		// Token: 0x06001465 RID: 5221 RVA: 0x0007AD54 File Offset: 0x00078F54
		private void AddDockPanelIcon(AppIcon icon)
		{
			if (PromotionObject.Instance.DockOrder.ContainsKey(icon.PackageName) && icon.MyAppPriority != PromotionObject.Instance.DockOrder[icon.PackageName])
			{
				icon.MyAppPriority = PromotionObject.Instance.DockOrder[icon.PackageName];
			}
			int num = 0;
			using (IEnumerator<AppIcon> enumerator = this.mDockPanel.Children.OfType<AppIcon>().GetEnumerator())
			{
				while (enumerator.MoveNext() && enumerator.Current.MyAppPriority <= icon.MyAppPriority)
				{
					num++;
				}
			}
			this.mDockPanel.Children.Insert(num, icon);
			this.mDockPanel.Children.Remove(this.moreAppsIcon);
			this.mDockPanel.Children.Add(this.moreAppsIcon);
		}

		// Token: 0x06001466 RID: 5222 RVA: 0x0007AE44 File Offset: 0x00079044
		private void AddMoreAppsDockPanelIcon(AppIcon icon)
		{
			if (PromotionObject.Instance.MoreAppsDockOrder.ContainsKey(icon.PackageName) && icon.MyAppPriority != PromotionObject.Instance.MoreAppsDockOrder[icon.PackageName])
			{
				icon.MyAppPriority = PromotionObject.Instance.MoreAppsDockOrder[icon.PackageName];
			}
			int num = 0;
			using (IEnumerator<AppIcon> enumerator = this.mMoreAppsDockPanel.Children.OfType<AppIcon>().GetEnumerator())
			{
				while (enumerator.MoveNext() && enumerator.Current.MyAppPriority <= icon.MyAppPriority)
				{
					num++;
				}
			}
			if (string.Equals(icon.PackageName, "macro_recorder", StringComparison.InvariantCulture))
			{
				if (!FeatureManager.Instance.IsMacroRecorderEnabled)
				{
					return;
				}
				icon.Visibility = Visibility.Collapsed;
			}
			this.mMoreAppsDockPanel.Children.Insert(num, icon);
		}

		// Token: 0x06001467 RID: 5223 RVA: 0x0007AF30 File Offset: 0x00079130
		internal void AddBorderInIcon(AppSuggestionPromotion appSuggestion)
		{
			string appPackage = appSuggestion.AppPackage;
			if (this.dictAppIcons.ContainsKey(appPackage))
			{
				this.dictAppIcons[appPackage].AddPromotionBorderInstalledApp(appSuggestion);
			}
		}

		// Token: 0x06001468 RID: 5224 RVA: 0x0007AF64 File Offset: 0x00079164
		private AppIcon GetNewIconForKey(string key)
		{
			AppIcon appIcon = new AppIcon();
			this.RemoveAppIcon(key, appIcon);
			this.dictAppIcons[key] = appIcon;
			return appIcon;
		}

		// Token: 0x06001469 RID: 5225 RVA: 0x0007AF90 File Offset: 0x00079190
		internal void PropogateAppIconProperties(string package, AppIcon newAppIconCreated)
		{
			newAppIconCreated.IsAppIncompat = this.dictAppIcons[package].IsAppIncompat;
			newAppIconCreated.mGl3ErrorIcon.Visibility = this.dictAppIcons[package].mGl3ErrorIcon.Visibility;
			newAppIconCreated.mGl3InfoIcon.Visibility = this.dictAppIcons[package].mGl3InfoIcon.Visibility;
		}

		// Token: 0x0600146A RID: 5226 RVA: 0x0007AFF8 File Offset: 0x000791F8
		internal void RemoveAppIcon(string package, AppIcon newAppIconCreated = null)
		{
			if (package != null && this.dictAppIcons.ContainsKey(package))
			{
				if (newAppIconCreated != null)
				{
					this.PropogateAppIconProperties(package, newAppIconCreated);
				}
				if (this.dictAppIcons[package].IsGifIcon)
				{
					this.PlayGif -= this.dictAppIcons[package].GifAppIconPlay;
					this.PauseGif -= this.dictAppIcons[package].GifAppIconPause;
				}
				this.InstalledAppsDrawer.Children.Remove(this.dictAppIcons[package]);
				this.mDockPanel.Children.Remove(this.dictAppIcons[package]);
				this.mMoreAppsDockPanel.Children.Remove(this.dictAppIcons[package]);
				this.dictAppIcons.Remove(package);
			}
		}

		// Token: 0x0600146B RID: 5227 RVA: 0x0007B0D8 File Offset: 0x000792D8
		internal AppIcon GetAppIcon(string packageName)
		{
			if (FeatureManager.Instance.IsCustomUIForNCSoft && packageName == BlueStacksUIUtils.sUserAccountPackageName)
			{
				Logger.Info("Setting packageName to com.android.vending when com.uncube.account is received");
				packageName = "com.android.vending";
			}
			AppIcon result = null;
			if (this.dictAppIcons.ContainsKey(packageName) && !string.IsNullOrEmpty(packageName))
			{
				result = this.dictAppIcons[packageName];
			}
			return result;
		}

		// Token: 0x0600146C RID: 5228 RVA: 0x0000DFBF File Offset: 0x0000C1BF
		internal AppIcon GetMacroAppIcon(string packageName)
		{
			return this.GetAppIcon(packageName + "_macro");
		}

		// Token: 0x0600146D RID: 5229 RVA: 0x0007B138 File Offset: 0x00079338
		internal void DownloadStarted(string packageName)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					this.dictAppIcons[packageName].DownloadStarted();
				}
				catch
				{
				}
			}), new object[0]);
		}

		// Token: 0x0600146E RID: 5230 RVA: 0x0007B178 File Offset: 0x00079378
		internal void UpdateAppDownloadProgress(string packageName, int percent)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					this.dictAppIcons[packageName].UpdateAppDownloadProgress(percent);
				}
				catch
				{
				}
			}), new object[0]);
		}

		// Token: 0x0600146F RID: 5231 RVA: 0x0007B1C0 File Offset: 0x000793C0
		internal void DownloadFailed(string packageName)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					this.dictAppIcons[packageName].DownloadFailed();
				}
				catch
				{
				}
			}), new object[0]);
		}

		// Token: 0x06001470 RID: 5232 RVA: 0x0007B200 File Offset: 0x00079400
		internal void DownloadCompleted(string packageName, string filePath)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					this.dictAppIcons[packageName].DownloadCompleted(filePath);
				}
				catch
				{
				}
			}), new object[0]);
		}

		// Token: 0x06001471 RID: 5233 RVA: 0x0007B248 File Offset: 0x00079448
		internal void ApkInstallStart(string packageName, string filePath)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					this.dictAppIcons[packageName].ApkInstallStart(filePath);
				}
				catch
				{
				}
			}), new object[0]);
		}

		// Token: 0x06001472 RID: 5234 RVA: 0x0007B290 File Offset: 0x00079490
		internal void ApkInstallFailed(string packageName)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					this.dictAppIcons[packageName].ApkInstallFailed();
				}
				catch
				{
				}
			}), new object[0]);
		}

		// Token: 0x06001473 RID: 5235 RVA: 0x0007B2D0 File Offset: 0x000794D0
		internal void ApkInstallCompleted(string packageName)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					this.dictAppIcons[packageName].ApkInstallCompleted();
				}
				catch
				{
				}
			}), new object[0]);
		}

		// Token: 0x06001474 RID: 5236 RVA: 0x0000DFD2 File Offset: 0x0000C1D2
		private void HomeApp_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (e.OriginalSource == this.InstalledAppsDrawerScrollBar)
			{
				this.ParentWindow.StaticComponents.ShowUninstallButtons(false);
			}
		}

		// Token: 0x06001475 RID: 5237 RVA: 0x00006BEE File Offset: 0x00004DEE
		private void MultiInstanceContextMenu_ContextMenuOpening(object sender, ContextMenuEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x06001476 RID: 5238 RVA: 0x0000DFF3 File Offset: 0x0000C1F3
		private void InstallApkIcon_Click(object sender, RoutedEventArgs e)
		{
			new DownloadInstallApk(this.ParentWindow).ChooseAndInstallApk();
		}

		// Token: 0x06001477 RID: 5239 RVA: 0x0000E005 File Offset: 0x0000C205
		private void UnInstallApkIcon_Click(object sender, RoutedEventArgs e)
		{
			this.ParentWindow.StaticComponents.ShowUninstallButtons(true);
		}

		// Token: 0x06001478 RID: 5240 RVA: 0x00006C7E File Offset: 0x00004E7E
		private void Grid_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, System.Windows.Controls.Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x06001479 RID: 5241 RVA: 0x00005A31 File Offset: 0x00003C31
		private void Grid_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			(sender as Grid).Background = System.Windows.Media.Brushes.Transparent;
		}

		// Token: 0x0600147A RID: 5242 RVA: 0x0007B310 File Offset: 0x00079510
		internal void RestoreWallpaperImage()
		{
			this.mBackgroundImage.IsFullImagePath = false;
			this.mBackgroundImage.ImageName = "fancybg.jpg";
			try
			{
				if (File.Exists(HomeApp.BackgroundImagePath))
				{
					File.Delete(HomeApp.BackgroundImagePath);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in deletion of image:" + ex.ToString());
			}
		}

		// Token: 0x0600147B RID: 5243 RVA: 0x0007B37C File Offset: 0x0007957C
		public static void ChooseWallpaper()
		{
			try
			{
				using (OpenFileDialog openFileDialog = new OpenFileDialog
				{
					Title = LocaleStrings.GetLocalizedString("STRING_CHANGE_WALLPAPER"),
					RestoreDirectory = true,
					DefaultExt = ".jpg",
					Filter = "Image files (*.jpg, *.jpeg, *.png) | *.jpg; *.jpeg; *.png"
				})
				{
					if (openFileDialog.ShowDialog() == DialogResult.OK)
					{
						HomeApp.ApplyWallpaper(openFileDialog.FileName);
						ClientStats.SendMiscellaneousStatsAsync("WallPaperStats", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "Premium", "Changed_Wallpaper", null, null, null, null);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in changing wallpaper:" + ex.ToString());
				System.Windows.MessageBox.Show("Cannot change wallpaper.Please try again.", "Error");
			}
		}

		// Token: 0x0600147C RID: 5244 RVA: 0x0007B450 File Offset: 0x00079650
		internal static void ApplyWallpaper(string filepath)
		{
			Bitmap bitmap = new Bitmap(filepath);
			bitmap.Save(HomeApp.BackgroundImagePath);
			bitmap.Dispose();
			foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>())
			{
				mainWindow.mWelcomeTab.mHomeApp.mBackgroundImage.ImageName = HomeApp.BackgroundImagePath;
				mainWindow.mWelcomeTab.mHomeApp.mBackgroundImage.ReloadImages();
			}
		}

		// Token: 0x0600147D RID: 5245 RVA: 0x0000E018 File Offset: 0x0000C218
		private void ChooseNewGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			HomeApp.ChooseWallpaper();
		}

		// Token: 0x0600147E RID: 5246 RVA: 0x0000E01F File Offset: 0x0000C21F
		internal void OpenAppSuggestionPopup(AppSuggestionPromotion appInfoForShowingPopup, UIElement appNameTextBlock, bool staysOpen = true)
		{
			if (appInfoForShowingPopup.ToolTip != null)
			{
				this.mSuggestedAppPopUp.PlacementTarget = appNameTextBlock;
				this.mSuggestedAppPopUp.IsOpen = true;
				this.mSuggestedAppPopUp.StaysOpen = staysOpen;
				this.mAppSuggestionPopUp.Text = appInfoForShowingPopup.ToolTip;
			}
		}

		// Token: 0x0600147F RID: 5247 RVA: 0x0000E05E File Offset: 0x0000C25E
		internal void OpenGamepadSupportPopup(UIElement appNameTextBlock, bool staysOpen = true)
		{
			this.mGamepadSupportPopUp.PlacementTarget = appNameTextBlock;
			this.mGamepadSupportPopUp.IsOpen = true;
			this.mGamepadSupportPopUp.StaysOpen = staysOpen;
		}

		// Token: 0x06001480 RID: 5248 RVA: 0x0000E084 File Offset: 0x0000C284
		private void mAppSettings_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.mAppSettingsPopup.IsOpen = true;
		}

		// Token: 0x06001481 RID: 5249 RVA: 0x0000DFF3 File Offset: 0x0000C1F3
		private void mInstallApkGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			new DownloadInstallApk(this.ParentWindow).ChooseAndInstallApk();
		}

		// Token: 0x06001482 RID: 5250 RVA: 0x0000E092 File Offset: 0x0000C292
		private void mDeleteAppsGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.StaticComponents.ShowUninstallButtons(true);
			this.mAppSettingsPopup.IsOpen = false;
		}

		// Token: 0x06001483 RID: 5251 RVA: 0x0000E0B1 File Offset: 0x0000C2B1
		private void mAppSettingsPopup_Opened(object sender, EventArgs e)
		{
			this.mAppSettings.IsEnabled = false;
		}

		// Token: 0x06001484 RID: 5252 RVA: 0x0000E0BF File Offset: 0x0000C2BF
		private void mAppSettingsPopup_Closed(object sender, EventArgs e)
		{
			this.mAppSettings.IsEnabled = true;
		}

		// Token: 0x06001485 RID: 5253 RVA: 0x0007B4E8 File Offset: 0x000796E8
		private void InstalledAppsDrawerScrollBar_ScrollChanged(object sender, ScrollChangedEventArgs e)
		{
			double verticalOffset = this.InstalledAppsDrawerScrollBar.VerticalOffset;
			if (this.InstalledAppsDrawerScrollBar.ComputedVerticalScrollBarVisibility != Visibility.Visible)
			{
				this.InstalledAppsDrawerScrollBar.OpacityMask = null;
				return;
			}
			if (verticalOffset <= 1.0)
			{
				this.InstalledAppsDrawerScrollBar.OpacityMask = BluestacksUIColor.mTopOpacityMask;
				return;
			}
			if (verticalOffset == this.InstalledAppsDrawerScrollBar.ScrollableHeight)
			{
				this.InstalledAppsDrawerScrollBar.OpacityMask = BluestacksUIColor.mBottomOpacityMask;
				return;
			}
			this.InstalledAppsDrawerScrollBar.OpacityMask = BluestacksUIColor.mScrolledOpacityMask;
		}

		// Token: 0x06001486 RID: 5254 RVA: 0x0000E0CD File Offset: 0x0000C2CD
		private void Close_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mMoreAppsDockPopup.IsOpen = false;
			this.mMoreAppsDockPopup.StaysOpen = false;
		}

		// Token: 0x06001487 RID: 5255 RVA: 0x0007B568 File Offset: 0x00079768
		private void MoreAppsIcon_Click(object sender, RoutedEventArgs e)
		{
			AppIcon appIcon = sender as AppIcon;
			this.mDockAppIconToolTipPopup.IsOpen = false;
			this.mMoreAppsDockPopup.PlacementTarget = appIcon.mAppImage;
			this.mMoreAppsDockPopup.IsOpen = true;
		}

		// Token: 0x06001488 RID: 5256 RVA: 0x0000E0E7 File Offset: 0x0000C2E7
		private void mCloseAppSuggPopup_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.CloseAppSuggestionPopup();
		}

		// Token: 0x06001489 RID: 5257 RVA: 0x0000E0EF File Offset: 0x0000C2EF
		internal void CloseAppSuggestionPopup()
		{
			this.mSuggestedAppPopUp.IsOpen = false;
		}

		// Token: 0x0600148A RID: 5258 RVA: 0x0000E0FD File Offset: 0x0000C2FD
		private void mCloseGamepadPopup_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mGamepadSupportPopUp.IsOpen = false;
		}

		// Token: 0x0600148B RID: 5259 RVA: 0x0007B5A8 File Offset: 0x000797A8
		internal void ShowAppRecommendations(bool isContentReloadRequired)
		{
			try
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					if ((this.ParentWindow != null && this.ParentWindow.ActualWidth <= 700.0) || FeatureManager.Instance.IsCustomUIForDMMSandbox || !FeatureManager.Instance.IsSearchBarVisible || RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
					{
						if (this.mCurrentSidePanelVisibility != null)
						{
							SidePanelVisibility? sidePanelVisibility = this.mCurrentSidePanelVisibility;
							SidePanelVisibility sidePanelVisibility2 = SidePanelVisibility.BothSearchBarAndSidepanelHidden;
							if (sidePanelVisibility.GetValueOrDefault() == sidePanelVisibility2 & sidePanelVisibility != null)
							{
								return;
							}
						}
						this.ChangeSideRecommendationsVisibility(false, false);
						this.mCurrentSidePanelVisibility = new SidePanelVisibility?(SidePanelVisibility.BothSearchBarAndSidepanelHidden);
						return;
					}
					if (!RegistryManager.Instance.IsPremium)
					{
						if (!FeatureManager.Instance.IsHtmlSideBar)
						{
							if (!FeatureManager.Instance.IsShowAppRecommendations)
							{
								goto IL_EA;
							}
							AppRecommendationSection appRecommendations = PromotionObject.Instance.AppRecommendations;
							if (appRecommendations != null && appRecommendations.AppSuggestions.Count == 0)
							{
								goto IL_EA;
							}
						}
						if (!FeatureManager.Instance.IsHtmlSideBar)
						{
							if (isContentReloadRequired || !this.mIsSidePanelContentLoadedOnce)
							{
								this.mAppRecommendationSectionsPanel.Children.Clear();
								AppRecommendationSection appRecommendations2 = PromotionObject.Instance.AppRecommendations;
								RecommendedAppsSection recommendedAppsSection = new RecommendedAppsSection(appRecommendations2.AppSuggestionHeader);
								recommendedAppsSection.AddSuggestedApps(this.ParentWindow, appRecommendations2.AppSuggestions, appRecommendations2.ClientShowCount);
								if (recommendedAppsSection.mAppRecommendationsPanel.Children.Count != 0)
								{
									this.mAppRecommendationSectionsPanel.Children.Add(recommendedAppsSection);
									this.mAppRecommendationSectionsPanel.Visibility = Visibility.Visible;
									this.mAppRecommendationsGenericMessages.Visibility = Visibility.Collapsed;
									this.SendAppRecommendationsImpressionStats();
								}
								this.mIsSidePanelContentLoadedOnce = true;
							}
							if (this.mCurrentSidePanelVisibility != null)
							{
								SidePanelVisibility? sidePanelVisibility = this.mCurrentSidePanelVisibility;
								SidePanelVisibility sidePanelVisibility2 = SidePanelVisibility.BothSearchBarAndSidepanelVisible;
								if (sidePanelVisibility.GetValueOrDefault() == sidePanelVisibility2 & sidePanelVisibility != null)
								{
									return;
								}
							}
							this.ChangeSideRecommendationsVisibility(true, true);
							this.mCurrentSidePanelVisibility = new SidePanelVisibility?(SidePanelVisibility.BothSearchBarAndSidepanelVisible);
							return;
						}
						if (!this.SideHtmlBrowserInited)
						{
							this.InitiateSideHtmlBrowser();
						}
						if (!RegistryManager.Instance.IsPremium)
						{
							if (this.mCurrentSidePanelVisibility != null)
							{
								SidePanelVisibility? sidePanelVisibility = this.mCurrentSidePanelVisibility;
								SidePanelVisibility sidePanelVisibility2 = SidePanelVisibility.OnlySidepanelVisible;
								if (sidePanelVisibility.GetValueOrDefault() == sidePanelVisibility2 & sidePanelVisibility != null)
								{
									return;
								}
							}
							this.ChangeSideRecommendationsVisibility(true, false);
							this.mCurrentSidePanelVisibility = new SidePanelVisibility?(SidePanelVisibility.OnlySidepanelVisible);
							return;
						}
						return;
					}
					IL_EA:
					if (this.mCurrentSidePanelVisibility != null)
					{
						SidePanelVisibility? sidePanelVisibility = this.mCurrentSidePanelVisibility;
						SidePanelVisibility sidePanelVisibility2 = SidePanelVisibility.OnlySearchBarVisible;
						if (sidePanelVisibility.GetValueOrDefault() == sidePanelVisibility2 & sidePanelVisibility != null)
						{
							return;
						}
					}
					this.ChangeSideRecommendationsVisibility(false, true);
					this.mCurrentSidePanelVisibility = new SidePanelVisibility?(SidePanelVisibility.OnlySearchBarVisible);
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Warning("Exception in showing app recommendations, " + ex.ToString());
			}
		}

		// Token: 0x0600148C RID: 5260 RVA: 0x0007B614 File Offset: 0x00079814
		private void SendAppRecommendationsImpressionStats()
		{
			JArray jarray = new JArray();
			RecommendedAppsSection recommendedAppsSection = this.mAppRecommendationSectionsPanel.Children[0] as RecommendedAppsSection;
			for (int i = 0; i < recommendedAppsSection.mAppRecommendationsPanel.Children.Count; i++)
			{
				RecommendedApps recommendedApps = recommendedAppsSection.mAppRecommendationsPanel.Children[i] as RecommendedApps;
				JObject item = new JObject
				{
					{
						"app_loc",
						(recommendedApps.AppRecomendation.ExtraPayload["click_generic_action"] == "InstallCDN") ? "cdn" : "gplay"
					},
					{
						"app_pkg",
						recommendedApps.AppRecomendation.ExtraPayload["click_action_packagename"]
					},
					{
						"is_installed",
						this.ParentWindow.mAppHandler.IsAppInstalled(recommendedApps.AppRecomendation.ExtraPayload["click_action_packagename"]) ? "true" : "false"
					},
					{
						"app_position",
						recommendedApps.RecommendedAppPosition.ToString(CultureInfo.InvariantCulture)
					},
					{
						"app_rank",
						recommendedApps.RecommendedAppRank.ToString(CultureInfo.InvariantCulture)
					}
				};
				jarray.Add(item);
			}
			ClientStats.SendFrontendClickStats("apps_recommendation", "impression", null, null, null, null, null, jarray.ToString(Formatting.None, new JsonConverter[0]));
		}

		// Token: 0x0600148D RID: 5261 RVA: 0x0007B794 File Offset: 0x00079994
		internal void UpdateRecommendedAppsInstallStatus(string package)
		{
			if (this.mAppRecommendationSectionsPanel.Children.Count > 0)
			{
				int num = -1;
				RecommendedAppsSection recommendedAppsSection = this.mAppRecommendationSectionsPanel.Children[0] as RecommendedAppsSection;
				RecommendedApps recommendedApps = null;
				for (int i = 0; i < recommendedAppsSection.mAppRecommendationsPanel.Children.Count; i++)
				{
					RecommendedApps recommendedApps2 = recommendedAppsSection.mAppRecommendationsPanel.Children[i] as RecommendedApps;
					if (recommendedApps2.AppRecomendation.AppPackage.Equals(package, StringComparison.InvariantCultureIgnoreCase))
					{
						num = i;
						recommendedApps = recommendedApps2;
						break;
					}
				}
				if (num != -1)
				{
					recommendedAppsSection.mAppRecommendationsPanel.Children.RemoveAt(num);
					if (this.sAppRecommendationsPool.Count > 0)
					{
						int num2 = 1;
						for (int j = 0; j < this.sAppRecommendationsPool.Count; j++)
						{
							RecommendedApps recommendedApps3 = this.sAppRecommendationsPool[j];
							if (!this.ParentWindow.mAppHandler.IsAppInstalled(recommendedApps3.AppRecomendation.ExtraPayload["click_action_packagename"]))
							{
								recommendedApps3.RecommendedAppPosition = recommendedApps.RecommendedAppPosition;
								recommendedAppsSection.mAppRecommendationsPanel.Children.Insert(num, recommendedApps3);
								JArray jarray = new JArray();
								JObject item = new JObject
								{
									{
										"app_loc",
										(recommendedApps3.AppRecomendation.ExtraPayload["click_generic_action"] == "InstallCDN") ? "cdn" : "gplay"
									},
									{
										"app_pkg",
										recommendedApps3.AppRecomendation.ExtraPayload["click_action_packagename"]
									},
									{
										"is_installed",
										this.ParentWindow.mAppHandler.IsAppInstalled(recommendedApps3.AppRecomendation.ExtraPayload["click_action_packagename"]) ? "true" : "false"
									},
									{
										"app_position",
										recommendedApps3.RecommendedAppPosition.ToString(CultureInfo.InvariantCulture)
									},
									{
										"app_rank",
										recommendedApps3.RecommendedAppRank.ToString(CultureInfo.InvariantCulture)
									}
								};
								jarray.Add(item);
								ClientStats.SendFrontendClickStats("apps_recommendation", "impression", null, null, null, null, null, jarray.ToString(Formatting.None, new JsonConverter[0]));
								break;
							}
							num2++;
						}
						this.sAppRecommendationsPool.RemoveRange(0, num2);
					}
					if (recommendedAppsSection.mAppRecommendationsPanel.Children.Count == 0)
					{
						this.mAppRecommendationSectionsPanel.Children.Remove(recommendedAppsSection);
					}
					if (this.mAppRecommendationSectionsPanel.Children.Count == 0)
					{
						this.mAppRecommendationSectionsPanel.Visibility = Visibility.Collapsed;
						this.mAppRecommendationsGenericMessages.Visibility = Visibility.Visible;
					}
				}
			}
		}

		// Token: 0x0600148E RID: 5262 RVA: 0x0007BA58 File Offset: 0x00079C58
		private void SearchTextBox_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
		{
			if (this.ParentWindow.mWelcomeTab.IsPromotionVisible)
			{
				return;
			}
			if (this.mSearchTextBox.Text == this.defaultSearchBoxText)
			{
				this.mSearchTextBox.Text = string.Empty;
			}
			this.OpenSearchSuggestions();
			BlueStacksUIBinding.BindColor(this.mSearchTextBox, System.Windows.Controls.Control.ForegroundProperty, "SearchGridForegroundFocusedColor");
		}

		// Token: 0x0600148F RID: 5263 RVA: 0x0007BABC File Offset: 0x00079CBC
		private void SearchTextBox_LostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
		{
			if (!this.mSearchRecommendationBorder.IsMouseOver)
			{
				this.HideSearchSuggestions();
			}
			if (this.ParentWindow.mWelcomeTab.IsPromotionVisible)
			{
				return;
			}
			if (string.IsNullOrEmpty(this.mSearchTextBox.Text))
			{
				this.mSearchTextBox.Text = this.defaultSearchBoxText;
			}
			if (string.Equals(this.mSearchTextBox.Text, this.defaultSearchBoxText, StringComparison.InvariantCulture))
			{
				BlueStacksUIBinding.BindColor(this.mSearchTextBox, System.Windows.Controls.Control.ForegroundProperty, "SearchGridForegroundColor");
				return;
			}
			BlueStacksUIBinding.BindColor(this.mSearchTextBox, System.Windows.Controls.Control.ForegroundProperty, "SearchGridForegroundFocusedColor");
		}

		// Token: 0x06001490 RID: 5264 RVA: 0x0000E10B File Offset: 0x0000C30B
		private void CustomPictureBox_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.SearchApp();
		}

		// Token: 0x06001491 RID: 5265 RVA: 0x0000E113 File Offset: 0x0000C313
		private void SearchTextBox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			if (this.mSearchRecommendationBorder.Visibility == Visibility.Visible)
			{
				this.HideSearchSuggestions();
			}
			if (e.Key == Key.Return)
			{
				this.SearchApp();
			}
		}

		// Token: 0x06001492 RID: 5266 RVA: 0x0007BB58 File Offset: 0x00079D58
		private void SearchApp()
		{
			if (this.ParentWindow.mWelcomeTab.IsPromotionVisible)
			{
				return;
			}
			if (!string.IsNullOrEmpty(this.mSearchTextBox.Text))
			{
				this.ParentWindow.mCommonHandler.SearchAppCenter(this.mSearchTextBox.Text);
			}
		}

		// Token: 0x06001493 RID: 5267 RVA: 0x0007BBA8 File Offset: 0x00079DA8
		private void OpenSearchSuggestions()
		{
			try
			{
				if (this.mSearchRecommendationBorder.Visibility != Visibility.Visible && (string.IsNullOrEmpty(this.mSearchTextBox.Text) || this.mSearchTextBox.Text == this.defaultSearchBoxText) && PromotionObject.Instance.SearchRecommendations.Count > 0 && this.mIsShowSearchRecommendations)
				{
					this.searchRecomItems.Children.Clear();
					Separator separator = new Separator
					{
						Margin = new Thickness(0.0),
						Style = (base.FindResource(System.Windows.Controls.ToolBar.SeparatorStyleKey) as Style)
					};
					BlueStacksUIBinding.BindColor(separator, System.Windows.Controls.Control.BackgroundProperty, "VerticalSeparator");
					this.searchRecomItems.Children.Add(separator);
					System.Windows.Controls.Label label = new System.Windows.Controls.Label
					{
						Content = LocaleStrings.GetLocalizedString("STRING_MOST_SEARCHED_APPS")
					};
					BlueStacksUIBinding.BindColor(label, System.Windows.Controls.Control.ForegroundProperty, "SearchGridForegroundColor");
					label.FontSize = 14.0;
					label.Padding = new Thickness(10.0, 5.0, 5.0, 5.0);
					this.searchRecomItems.Children.Add(label);
					foreach (KeyValuePair<string, SearchRecommendation> keyValuePair in PromotionObject.Instance.SearchRecommendations)
					{
						RecommendedAppItem recommendedAppItem = new RecommendedAppItem();
						recommendedAppItem.Populate(this.ParentWindow, keyValuePair.Value);
						recommendedAppItem.Padding = new Thickness(5.0, 0.0, 0.0, 0.0);
						this.searchRecomItems.Children.Add(recommendedAppItem);
					}
					this.mSearchRecommendationBorder.CornerRadius = new CornerRadius(0.0, 0.0, this.searchTextBoxBorder.CornerRadius.BottomRight, this.searchTextBoxBorder.CornerRadius.BottomLeft);
					this.Mask.CornerRadius = new CornerRadius(0.0, this.searchTextBoxBorder.CornerRadius.TopRight, 0.0, 0.0);
					this.searchTextBoxBorder.CornerRadius = new CornerRadius(this.searchTextBoxBorder.CornerRadius.TopLeft, this.searchTextBoxBorder.CornerRadius.TopRight, 0.0, 0.0);
					this.mSearchRecommendationBorder.Visibility = Visibility.Visible;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception when trying to open search recommendations. " + ex.ToString());
			}
		}

		// Token: 0x06001494 RID: 5268 RVA: 0x0007BEAC File Offset: 0x0007A0AC
		private void HideSearchSuggestions()
		{
			if (this.mSearchRecommendationBorder.Visibility == Visibility.Visible)
			{
				this.searchTextBoxBorder.CornerRadius = new CornerRadius(this.searchTextBoxBorder.CornerRadius.TopLeft, this.searchTextBoxBorder.CornerRadius.TopRight, this.mSearchRecommendationBorder.CornerRadius.BottomRight, this.mSearchRecommendationBorder.CornerRadius.BottomLeft);
				this.Mask.CornerRadius = new CornerRadius(0.0, this.searchTextBoxBorder.CornerRadius.TopRight, this.mSearchRecommendationBorder.CornerRadius.BottomRight, 0.0);
				this.mSearchRecommendationBorder.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x06001495 RID: 5269 RVA: 0x0000E137 File Offset: 0x0000C337
		private void search_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.searchHoverTimer.Stop();
			if (!this.mSearchTextBox.IsFocused && !this.mSearchRecommendationBorder.IsMouseOver && !this.mSearchGrid.IsMouseOver)
			{
				this.HideSearchSuggestions();
			}
		}

		// Token: 0x06001496 RID: 5270 RVA: 0x0000E171 File Offset: 0x0000C371
		private void Search_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			this.searchHoverTimer.Start();
		}

		// Token: 0x06001497 RID: 5271 RVA: 0x0007BF7C File Offset: 0x0007A17C
		internal void ShowAppPopupAfterUpgrade(string packageName)
		{
			try
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					if (this.dictAppIcons.ContainsKey(packageName) && File.Exists(KMManager.GetInputmapperUserFilePath(packageName)))
					{
						CustomMessageWindow customMessageWindow = new CustomMessageWindow();
						customMessageWindow.TitleTextBlock.Text = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_SMART_CONTROLS_ENABLED_0"), new object[]
						{
							"Garena Free Fire"
						});
						customMessageWindow.BodyTextBlock.Text = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_FREEFIRE_NOTIFICATION_MESSAGE"), new object[]
						{
							"Garena Free Fire"
						});
						customMessageWindow.BodyWarningTextBlock.Visibility = Visibility.Visible;
						BlueStacksUIBinding.Bind(customMessageWindow.BodyWarningTextBlock, "STRING_FREEFIRE_NOTIFICATION_DETAIL", "");
						customMessageWindow.BodyWarningTextBlock.FontWeight = FontWeights.Light;
						BlueStacksUIBinding.BindColor(customMessageWindow.BodyWarningTextBlock, System.Windows.Controls.Control.ForegroundProperty, "SettingsWindowForegroundDimDimColor");
						customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
						customMessageWindow.UrlTextBlock.Visibility = Visibility.Visible;
						customMessageWindow.UrlLink.Inlines.Add(LocaleStrings.GetLocalizedString("STRING_FREEFIRE_NOTIFICATION_LINK"));
						string uriString = WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
						{
							WebHelper.GetServerHost(),
							"help_articles"
						})) + "&article=smart_control";
						customMessageWindow.UrlLink.NavigateUri = new Uri(uriString);
						customMessageWindow.UrlLink.RequestNavigate += this.OpenSmartControlHelp;
						this.ParentWindow.ShowDimOverlay(null);
						customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
						customMessageWindow.ShowDialog();
						if (this.ParentWindow.mDimOverlay != null && this.ParentWindow.mDimOverlay.OwnedWindows.OfType<ContainerWindow>().Any<ContainerWindow>())
						{
							this.ParentWindow.HideDimOverlay();
						}
					}
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Warning("Exception in showing app notifications after upgrade: " + ex.ToString());
			}
		}

		// Token: 0x06001498 RID: 5272 RVA: 0x0000E17E File Offset: 0x0000C37E
		private void OpenSmartControlHelp(object sender, RequestNavigateEventArgs e)
		{
			BlueStacksUIUtils.OpenUrl(e.Uri.OriginalString);
		}

		// Token: 0x04000CBB RID: 3259
		private Dictionary<string, AppIcon> dictAppIcons = new Dictionary<string, AppIcon>();

		// Token: 0x04000CBC RID: 3260
		private WrapPanel InstalledAppsDrawer;

		// Token: 0x04000CBD RID: 3261
		private DispatcherTimer searchHoverTimer;

		// Token: 0x04000CC0 RID: 3264
		private string defaultSearchBoxText = LocaleStrings.GetLocalizedString("STRING_SEARCH");

		// Token: 0x04000CC1 RID: 3265
		private bool mIsShowSearchRecommendations;

		// Token: 0x04000CC2 RID: 3266
		private SidePanelVisibility? mCurrentSidePanelVisibility;

		// Token: 0x04000CC3 RID: 3267
		private bool mIsSidePanelContentLoadedOnce;

		// Token: 0x04000CC4 RID: 3268
		internal List<RecommendedApps> sAppRecommendationsPool = new List<RecommendedApps>();

		// Token: 0x04000CC5 RID: 3269
		internal static string BackgroundImagePath = System.IO.Path.Combine(RegistryManager.Instance.UserDefinedDir, "Client\\Assets\\backgroundImage");

		// Token: 0x04000CC6 RID: 3270
		private MainWindow mMainWindow;

		// Token: 0x04000CC7 RID: 3271
		private static object syncRoot = new object();
	}
}
