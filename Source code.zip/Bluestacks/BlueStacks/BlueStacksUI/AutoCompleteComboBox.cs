﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200008D RID: 141
	public class AutoCompleteComboBox : UserControl, IComponentConnector
	{
		// Token: 0x06000578 RID: 1400 RVA: 0x00020C64 File Offset: 0x0001EE64
		public AutoCompleteComboBox()
		{
			this.InitializeComponent();
			this.mAutoComboBox.IsDropDownOpen = false;
			this.mAutoComboBox.Loaded += delegate(object <p0>, RoutedEventArgs <p1>)
			{
				TextBox textBox = this.mAutoComboBox.Template.FindName("PART_EditableTextBox", this.mAutoComboBox) as TextBox;
				if (textBox != null)
				{
					textBox.TextChanged += this.EditTextBox_TextChanged;
				}
			};
			this.mAutoComboBox.DropDownOpened += this.MAutoComboBox_DropDownOpened;
			EventManager.RegisterClassHandler(typeof(TextBox), UIElement.KeyUpEvent, new RoutedEventHandler(this.DeselectText));
		}

		// Token: 0x06000579 RID: 1401 RVA: 0x00020CE4 File Offset: 0x0001EEE4
		private void DeselectText(object sender, RoutedEventArgs e)
		{
			TextBox textBox = e.OriginalSource as TextBox;
			if (textBox != null && textBox.Text.Length < 2)
			{
				textBox.SelectionLength = 0;
				textBox.SelectionStart = 1;
			}
		}

		// Token: 0x0600057A RID: 1402 RVA: 0x00020D1C File Offset: 0x0001EF1C
		private void EditTextBox_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (Keyboard.IsKeyDown(Key.Down))
			{
				e.Handled = true;
				return;
			}
			TextBox textBox = sender as TextBox;
			this.mAutoComboBox_TextChanged(textBox.Text);
		}

		// Token: 0x0600057B RID: 1403 RVA: 0x000059B8 File Offset: 0x00003BB8
		private void MAutoComboBox_DropDownOpened(object sender, EventArgs e)
		{
			this.mAutoComboBox.SelectedItem = null;
		}

		// Token: 0x0600057C RID: 1404 RVA: 0x00020D50 File Offset: 0x0001EF50
		public void AddItems(string key)
		{
			ComboBoxItem newItem = new ComboBoxItem
			{
				Content = key
			};
			this.mAutoComboBox.Items.Add(newItem);
		}

		// Token: 0x0600057D RID: 1405 RVA: 0x000059C6 File Offset: 0x00003BC6
		public void AddSuggestions(List<string> listOfSuggestions)
		{
			this.mListData.Clear();
			this.mListData = listOfSuggestions;
		}

		// Token: 0x0600057E RID: 1406 RVA: 0x00020D7C File Offset: 0x0001EF7C
		private void mAutoComboBox_TextChanged(string msg)
		{
			bool flag = false;
			if (string.IsNullOrEmpty(msg))
			{
				this.mAutoComboBox.IsDropDownOpen = false;
			}
			this.mAutoComboBox.Items.Clear();
			foreach (string text in this.mListData)
			{
				if (text.StartsWith(msg, StringComparison.InvariantCultureIgnoreCase))
				{
					this.AddItems(text);
					flag = true;
				}
			}
			if (flag)
			{
				this.mAutoComboBox.IsDropDownOpen = true;
				return;
			}
			this.mAutoComboBox.IsDropDownOpen = false;
		}

		// Token: 0x0600057F RID: 1407 RVA: 0x00020E20 File Offset: 0x0001F020
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/autocompletecombobox.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000580 RID: 1408 RVA: 0x000059DA File Offset: 0x00003BDA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mAutoComboBox = (CustomComboBox)target;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x040002F0 RID: 752
		private List<string> mListData = new List<string>();

		// Token: 0x040002F1 RID: 753
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomComboBox mAutoComboBox;

		// Token: 0x040002F2 RID: 754
		private bool _contentLoaded;
	}
}
