﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000231 RID: 561
	public enum Compression : ushort
	{
		// Token: 0x04000C94 RID: 3220
		Store,
		// Token: 0x04000C95 RID: 3221
		Deflate = 8
	}
}
