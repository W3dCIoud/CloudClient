﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200025B RID: 603
	public partial class WelcomeTab : UserControl
	{
		// Token: 0x170002D4 RID: 724
		// (get) Token: 0x06001560 RID: 5472 RVA: 0x0000E8EC File Offset: 0x0000CAEC
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x170002D5 RID: 725
		// (get) Token: 0x06001561 RID: 5473 RVA: 0x0000E90D File Offset: 0x0000CB0D
		internal bool IsPromotionVisible
		{
			get
			{
				return this.mPromotionGrid.Visibility == Visibility.Visible;
			}
		}

		// Token: 0x06001562 RID: 5474 RVA: 0x0000E91D File Offset: 0x0000CB1D
		public WelcomeTab()
		{
			this.InitializeComponent();
			if (this.ParentWindow != null)
			{
				this.ParentWindow.mCommonHandler.MacroButtonVisibilityChangedEvent += this.ParentWindow_MacroButtonVisibilityChangedEvent;
			}
		}

		// Token: 0x06001563 RID: 5475 RVA: 0x00080A3C File Offset: 0x0007EC3C
		private void ParentWindow_MacroButtonVisibilityChangedEvent(bool isVisible)
		{
			HomeApp homeApp = this.mHomeApp;
			IEnumerable<AppIcon> enumerable;
			if (homeApp == null)
			{
				enumerable = null;
			}
			else
			{
				enumerable = from icon in homeApp.mMoreAppsDockPanel.Children.OfType<AppIcon>()
				where string.Equals(icon.PackageName, "macro_recorder", StringComparison.InvariantCulture)
				select icon;
			}
			IEnumerable<AppIcon> source = enumerable;
			if (source.Any<AppIcon>())
			{
				source.FirstOrDefault<AppIcon>().Visibility = (isVisible ? Visibility.Visible : Visibility.Collapsed);
			}
		}

		// Token: 0x06001564 RID: 5476 RVA: 0x00080AA4 File Offset: 0x0007ECA4
		internal void Init()
		{
			this.mHomeApp = new HomeApp(this.ParentWindow);
			if (!this.mContentGrid.Children.Contains(this.mHomeApp))
			{
				this.mContentGrid.Children.Add(this.mHomeApp);
			}
			this.mHomeApp.Init();
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				this.mHomeApp.Visibility = Visibility.Hidden;
				this.mBackground.ImageName = Path.Combine(RegistryManager.Instance.ClientInstallDir, "Promo\\boot_promo_0.png");
				this.mBackground.Visibility = Visibility.Visible;
			}
			if (FeatureManager.Instance.IsPromotionDisabled)
			{
				this.RemovePromotionGrid();
				this.mHomeApp.mLoadingGrid.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x06001565 RID: 5477 RVA: 0x0000E94F File Offset: 0x0000CB4F
		internal void RemovePromotionGrid()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mPromotionGrid.Visibility = Visibility.Hidden;
				this.mPromotionControl.Stop();
				this.mHomeApp.mSearchTextBox.IsEnabled = true;
			}), new object[0]);
		}

		// Token: 0x04000DCF RID: 3535
		internal HomeApp mHomeApp;

		// Token: 0x04000DD0 RID: 3536
		private MainWindow mMainWindow;
	}
}
