﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI.Controls
{
	// Token: 0x0200028B RID: 651
	public partial class SkinSelectorControl : UserControl
	{
		// Token: 0x0600176E RID: 5998 RVA: 0x000100B9 File Offset: 0x0000E2B9
		public SkinSelectorControl()
		{
			this.InitializeComponent();
		}
	}
}
