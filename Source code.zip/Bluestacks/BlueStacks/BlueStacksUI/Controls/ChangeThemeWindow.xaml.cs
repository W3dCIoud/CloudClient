﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI.Controls
{
	// Token: 0x0200028A RID: 650
	public partial class ChangeThemeWindow : UserControl
	{
		// Token: 0x06001767 RID: 5991 RVA: 0x00010088 File Offset: 0x0000E288
		public ChangeThemeWindow(MainWindow parentWindow)
		{
			this.InitializeComponent();
			this.ParentWindow = parentWindow;
			this.ThemesDrawer = (this.mThemesDrawerScrollBar.Content as WrapPanel);
			this.AddSkinImages();
		}

		// Token: 0x06001768 RID: 5992 RVA: 0x0008C11C File Offset: 0x0008A31C
		public void AddSkinImages()
		{
			try
			{
				this.ThemesDrawer.Children.Clear();
				foreach (string text in Directory.GetDirectories(RegistryManager.Instance.ClientInstallDir))
				{
					if (File.Exists(Path.Combine(text, "ThemeThumbnail.png")))
					{
						string themeName = BlueStacksUIColorManager.GetThemeName(text);
						SkinSelectorControl skinSelectorControl = new SkinSelectorControl
						{
							Visibility = Visibility.Visible,
							HorizontalAlignment = HorizontalAlignment.Center,
							VerticalAlignment = VerticalAlignment.Top
						};
						skinSelectorControl.mThemeImage.Visibility = Visibility.Visible;
						skinSelectorControl.mThemeName.Visibility = Visibility.Visible;
						skinSelectorControl.mThemeImage.IsFullImagePath = true;
						skinSelectorControl.mThemeImage.ImageName = Path.Combine(text, "ThemeThumbnail.png");
						skinSelectorControl.mThemeCheckButton.Height = 30.0;
						skinSelectorControl.mThemeName.ToolTip = themeName;
						skinSelectorControl.mThemeName.Width = double.NaN;
						skinSelectorControl.mThemeCheckButton.Width = double.NaN;
						skinSelectorControl.mThemeName.Text = themeName;
						BlueStacksUIBinding.BindColor(skinSelectorControl.mThemeName, TextBlock.ForegroundProperty, "ContextMenuItemForegroundColor");
						skinSelectorControl.mThemeCheckButton.Tag = Path.GetFileName(text);
						skinSelectorControl.mThemeCheckButton.Click += this.ThemeApplyButton_Click;
						if (string.Compare(RegistryManager.ClientThemeName, Path.GetFileName(text), StringComparison.OrdinalIgnoreCase) == 0)
						{
							skinSelectorControl.mThemeAppliedText.Text = LocaleStrings.GetLocalizedString("STRING_APPLIED");
							skinSelectorControl.mThemeAppliedText.Visibility = Visibility.Visible;
							skinSelectorControl.mThemeAppliedText.Margin = new Thickness(0.0, 3.0, 4.0, 0.0);
						}
						else
						{
							skinSelectorControl.mThemeCheckButton.ButtonColor = ButtonColors.Blue;
							skinSelectorControl.mThemeCheckButton.IsEnabled = true;
							skinSelectorControl.mThemeCheckButton.Content = LocaleStrings.GetLocalizedString("STRING_APPLY");
							skinSelectorControl.mThemeCheckButton.Visibility = Visibility.Visible;
						}
						this.ThemesDrawer.Children.Add(skinSelectorControl);
						this.mThemesDrawerScrollBar.Visibility = Visibility.Visible;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in populating themes in skin widget " + ex.ToString());
			}
		}

		// Token: 0x06001769 RID: 5993 RVA: 0x0008C374 File Offset: 0x0008A574
		private void ThemeApplyButton_Click(object sender, RoutedEventArgs e)
		{
			Logger.Info("Clicked theme apply button");
			string themeName = (sender as CustomButton).Tag.ToString();
			this.ParentWindow.Utils.ApplyTheme(themeName);
			this.AddSkinImages();
			this.ParentWindow.Utils.RestoreWallpaperImageForAllVms();
		}

		// Token: 0x0600176A RID: 5994 RVA: 0x00007B5F File Offset: 0x00005D5F
		private void mCrossButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			BlueStacksUIUtils.CloseContainerWindow(this);
		}

		// Token: 0x0600176B RID: 5995 RVA: 0x00006BEE File Offset: 0x00004DEE
		private void mCrossButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x04000F10 RID: 3856
		private WrapPanel ThemesDrawer;

		// Token: 0x04000F11 RID: 3857
		private MainWindow ParentWindow;
	}
}
