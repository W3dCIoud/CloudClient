﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using BlueStacks.Common;
using Microsoft.VisualBasic;
using Microsoft.Win32;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200014D RID: 333
	public partial class ThemeEditorWindow : CustomWindow
	{
		// Token: 0x17000213 RID: 531
		// (get) Token: 0x06000CF6 RID: 3318 RVA: 0x00009D6D File Offset: 0x00007F6D
		// (set) Token: 0x06000CF7 RID: 3319 RVA: 0x00009D85 File Offset: 0x00007F85
		public static ThemeEditorWindow Instance
		{
			get
			{
				if (ThemeEditorWindow.mInstance == null)
				{
					ThemeEditorWindow.mInstance = new ThemeEditorWindow();
				}
				return ThemeEditorWindow.mInstance;
			}
			set
			{
				ThemeEditorWindow.mInstance = value;
			}
		}

		// Token: 0x06000CF8 RID: 3320 RVA: 0x00055348 File Offset: 0x00053548
		public ThemeEditorWindow()
		{
			this.InitializeComponent();
			base.Closing += this.ThemeEditorWindow_Closing;
			base.Activated += this.ThemeEditorWindow_Activated;
			this.sliderX.Value = BlueStacksUIColorManager.AppliedTheme.AppIconRectangleGeometry.RadiusX;
			this.sliderY.Value = BlueStacksUIColorManager.AppliedTheme.AppIconRectangleGeometry.RadiusY;
			this.TabTransFormLandscape.IsChecked = new bool?(true);
			this.ListView2.ItemsSource = BlueStacksUIBinding.Instance.ImageModel.Keys.ToList<string>();
			using (DataTable dataTable = new DataTable())
			{
				dataTable.Columns.Add(new DataColumn("Category", typeof(string)));
				dataTable.Columns.Add(new DataColumn("Name", typeof(string)));
				dataTable.Columns.Add(new DataColumn("Brush", typeof(Brush)));
				foreach (KeyValuePair<string, Brush> keyValuePair in BlueStacksUIColorManager.AppliedTheme.DictBrush)
				{
					DataRow dataRow = dataTable.NewRow();
					dataRow["Name"] = keyValuePair.Key;
					dataRow["Brush"] = keyValuePair.Value;
					if (BlueStacksUIColorManager.AppliedTheme.DictCategory.ContainsKey(keyValuePair.Key))
					{
						dataRow["Category"] = BlueStacksUIColorManager.AppliedTheme.DictCategory[keyValuePair.Key];
					}
					dataTable.Rows.Add(dataRow);
				}
				DataView defaultView = dataTable.DefaultView;
				defaultView.Sort = "Category asc";
				DataTable dataSource = defaultView.ToTable();
				this.dataGrid.ColumnsToBeGrouped.Add(0);
				this.dataGrid.DataSource = dataSource;
				this.dataGrid.CellClick += this.DataGrid_CellClick;
				this.dataGrid.CellValueChanged += this.DataGrid_CellValueChanged;
				this.dataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
				this.dataGrid.Columns["Brush"].Visible = false;
			}
			using (DataTable dataTable2 = new DataTable())
			{
				dataTable2.Columns.Add(new DataColumn("Name", typeof(string)));
				dataTable2.Columns.Add(new DataColumn("CornerRadius", typeof(CornerRadius)));
				foreach (KeyValuePair<string, CornerRadius> keyValuePair2 in BlueStacksUIColorManager.AppliedTheme.DictCornerRadius)
				{
					DataRow dataRow2 = dataTable2.NewRow();
					dataRow2["Name"] = keyValuePair2.Key;
					dataRow2["CornerRadius"] = keyValuePair2.Value;
					dataTable2.Rows.Add(dataRow2);
				}
				this.dataGrid1.DataSource = dataTable2;
				this.dataGrid1.CellClick += this.DataGrid1_CellClick;
				this.dataGrid1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
			}
			this.ignore = false;
		}

		// Token: 0x06000CF9 RID: 3321 RVA: 0x00055728 File Offset: 0x00053928
		private void DataGrid1_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			this.ignore = true;
			try
			{
				this.topleftCornerRadius.Value = BlueStacksUIColorManager.AppliedTheme.DictCornerRadius[this.dataGrid1.Rows[e.RowIndex].Cells["Name"].Value.ToString()].TopLeft;
				this.toprightcornerradius.Value = BlueStacksUIColorManager.AppliedTheme.DictCornerRadius[this.dataGrid1.Rows[e.RowIndex].Cells["Name"].Value.ToString()].TopRight;
				this.bottomleftCornerRadius.Value = BlueStacksUIColorManager.AppliedTheme.DictCornerRadius[this.dataGrid1.Rows[e.RowIndex].Cells["Name"].Value.ToString()].BottomLeft;
				this.bottomrightcornerradius.Value = BlueStacksUIColorManager.AppliedTheme.DictCornerRadius[this.dataGrid1.Rows[e.RowIndex].Cells["Name"].Value.ToString()].BottomRight;
			}
			catch (Exception ex)
			{
				Console.WriteLine("exception:" + ex.ToString());
			}
			this.ignore = false;
		}

		// Token: 0x06000CFA RID: 3322 RVA: 0x000558C0 File Offset: 0x00053AC0
		private void DataGrid_CellValueChanged(object sender, DataGridViewCellEventArgs e)
		{
			if (this.dataGrid.Columns[e.ColumnIndex].Name == "Category")
			{
				BlueStacksUIColorManager.AppliedTheme.DictCategory[this.dataGrid.Rows[e.RowIndex].Cells["Name"].Value.ToString()] = this.dataGrid.Rows[e.RowIndex].Cells["Category"].Value.ToString();
				this.dataGrid.Sort(this.dataGrid.Columns[e.ColumnIndex], ListSortDirection.Ascending);
			}
		}

		// Token: 0x06000CFB RID: 3323 RVA: 0x00055988 File Offset: 0x00053B88
		private void DataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			this.ignore = true;
			try
			{
				this.sliderA.Value = (double)(BlueStacksUIColorManager.AppliedTheme.DictBrush[this.dataGrid.Rows[e.RowIndex].Cells["Name"].Value.ToString()] as SolidColorBrush).Color.A;
				this.sliderR.Value = (double)(BlueStacksUIColorManager.AppliedTheme.DictBrush[this.dataGrid.Rows[e.RowIndex].Cells["Name"].Value.ToString()] as SolidColorBrush).Color.R;
				this.sliderG.Value = (double)(BlueStacksUIColorManager.AppliedTheme.DictBrush[this.dataGrid.Rows[e.RowIndex].Cells["Name"].Value.ToString()] as SolidColorBrush).Color.G;
				this.sliderB.Value = (double)(BlueStacksUIColorManager.AppliedTheme.DictBrush[this.dataGrid.Rows[e.RowIndex].Cells["Name"].Value.ToString()] as SolidColorBrush).Color.B;
				this.textBox.Text = this.dataGrid.Rows[e.RowIndex].Cells["Brush"].Value.ToString();
			}
			catch (Exception ex)
			{
				Console.WriteLine("exception:" + ex.ToString());
			}
			this.ignore = false;
		}

		// Token: 0x06000CFC RID: 3324 RVA: 0x00055B84 File Offset: 0x00053D84
		private void ThemeEditorWindow_Activated(object sender, EventArgs e)
		{
			if (this.isCreateDraftDirectory)
			{
				this.ListView2.ItemsSource = BlueStacksUIBinding.Instance.ImageModel.Keys.ToList<string>();
				this.isCreateDraftDirectory = false;
				ThemeEditorWindow.CopyEverything(CustomPictureBox.AssetsDir, this.DraftDirectory);
				File.Delete(Path.Combine(this.DraftDirectory, "ThemeThumbnail.png"));
			}
		}

		// Token: 0x06000CFD RID: 3325 RVA: 0x00009D8D File Offset: 0x00007F8D
		private void ThemeEditorWindow_Closing(object sender, CancelEventArgs e)
		{
			this.isCreateDraftDirectory = true;
			e.Cancel = true;
			base.Hide();
		}

		// Token: 0x06000CFE RID: 3326 RVA: 0x00055BE4 File Offset: 0x00053DE4
		private void Color_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			try
			{
				byte a = (byte)this.sliderA.Value;
				byte r = (byte)this.sliderR.Value;
				byte g = (byte)this.sliderG.Value;
				byte b = (byte)this.sliderB.Value;
				Color color = Color.FromArgb(a, r, g, b);
				Brush background = new SolidColorBrush(color);
				this.gridColor.Background = background;
				if (!this.ignore)
				{
					this.textBox.Text = color.ToString(CultureInfo.InvariantCulture);
					BlueStacksUIColorManager.AppliedTheme.DictBrush[this.dataGrid.CurrentRow.Cells["Name"].Value.ToString()] = new SolidColorBrush(new ColorUtils(color).WPFColor);
					if (this.dataGrid.CurrentRow.Cells["Category"].Value.ToString().Equals("*MainColors*", StringComparison.OrdinalIgnoreCase))
					{
						BlueStacksUIColorManager.AppliedTheme.CalculateAndNotify(true);
					}
					else
					{
						BlueStacksUIColorManager.AppliedTheme.NotifyUIElements();
					}
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000CFF RID: 3327 RVA: 0x00055D10 File Offset: 0x00053F10
		private void textBox_TextChanged(object sender, TextChangedEventArgs e)
		{
			try
			{
				if (!this.ignore)
				{
					SolidColorBrush solidColorBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(this.textBox.Text));
					this.sliderA.Value = (double)solidColorBrush.Color.A;
					this.sliderR.Value = (double)solidColorBrush.Color.R;
					this.sliderG.Value = (double)solidColorBrush.Color.G;
					this.sliderB.Value = (double)solidColorBrush.Color.B;
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000D00 RID: 3328 RVA: 0x00055DC0 File Offset: 0x00053FC0
		private void Curve_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			if (!this.ignore)
			{
				BlueStacksUIColorManager.AppliedTheme.AppIconRectangleGeometry.RadiusX = this.sliderX.Value;
				BlueStacksUIColorManager.AppliedTheme.AppIconRectangleGeometry.RadiusY = this.sliderY.Value;
				BlueStacksUIColorManager.AppliedTheme.NotifyUIElements();
			}
		}

		// Token: 0x06000D01 RID: 3329 RVA: 0x00055E14 File Offset: 0x00054014
		private void Load_Click(object sender, RoutedEventArgs e)
		{
			using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog
			{
				SelectedPath = RegistryManager.Instance.ClientInstallDir
			})
			{
				if (folderBrowserDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK && !string.IsNullOrEmpty(folderBrowserDialog.SelectedPath))
				{
					string selectedPath = folderBrowserDialog.SelectedPath;
					if (File.Exists(Path.Combine(folderBrowserDialog.SelectedPath, "ThemeFile")))
					{
						string fileName = Path.GetFileName(folderBrowserDialog.SelectedPath);
						if (!folderBrowserDialog.SelectedPath.Contains(RegistryManager.Instance.ClientInstallDir))
						{
							string text = Path.Combine(RegistryManager.Instance.ClientInstallDir, fileName);
							if (Directory.Exists(text))
							{
								System.Windows.MessageBox.Show("Theme with this name already exists. Please rename the folder an try again");
							}
							else
							{
								Directory.CreateDirectory(text);
								ThemeEditorWindow.CopyEverything(folderBrowserDialog.SelectedPath, text);
							}
						}
						BlueStacksUIColorManager.ReloadAppliedTheme(fileName);
					}
					else
					{
						System.Windows.MessageBox.Show("Please select theme folder");
					}
				}
			}
		}

		// Token: 0x06000D02 RID: 3330 RVA: 0x00055EFC File Offset: 0x000540FC
		private void Save_Click(object sender, RoutedEventArgs e)
		{
			string text = Interaction.InputBox("Theme name", "BlueStacks Theme Editor Tool", string.Format(CultureInfo.CurrentCulture, "{0:F}", new object[]
			{
				DateTime.Now
			}), 0, 0);
			if (Directory.Exists(Path.Combine(RegistryManager.Instance.ClientInstallDir, text)))
			{
				System.Windows.MessageBox.Show("Already Exists. Please retry");
				return;
			}
			Directory.CreateDirectory(Path.Combine(RegistryManager.Instance.ClientInstallDir, text));
			ThemeEditorWindow.CopyEverything(this.DraftDirectory, Path.Combine(RegistryManager.Instance.ClientInstallDir, text));
			RegistryManager.Instance.SetClientThemeNameInRegistry(text);
			Window w = BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>()[0];
			w.Dispatcher.Invoke(new Action(delegate()
			{
				RenderTargetBitmap renderTargetBitmap = new RenderTargetBitmap((int)w.ActualWidth, (int)w.ActualHeight, 0.0, 0.0, PixelFormats.Pbgra32);
				renderTargetBitmap.Render(BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>()[0]);
				PngBitmapEncoder pngBitmapEncoder = new PngBitmapEncoder();
				pngBitmapEncoder.Frames.Add(BitmapFrame.Create(renderTargetBitmap));
				using (Stream stream = File.Create(Path.Combine(CustomPictureBox.AssetsDir, "ThemeThumbnail.png")))
				{
					pngBitmapEncoder.Save(stream);
				}
			}), new object[0]);
			BlueStacksUIColorManager.AppliedTheme.Save(BlueStacksUIColorManager.GetThemeFilePath(RegistryManager.ClientThemeName));
			CustomPictureBox.UpdateImagesFromNewDirectory("");
		}

		// Token: 0x06000D03 RID: 3331 RVA: 0x00056000 File Offset: 0x00054200
		private static void CopyEverything(string SourcePath, string DestinationPath)
		{
			string[] array = Directory.GetDirectories(SourcePath, "*", SearchOption.AllDirectories);
			for (int i = 0; i < array.Length; i++)
			{
				Directory.CreateDirectory(array[i].Replace(SourcePath, DestinationPath));
			}
			foreach (string text in Directory.GetFiles(SourcePath, "*.*", SearchOption.AllDirectories))
			{
				File.Copy(text, text.Replace(SourcePath, DestinationPath), true);
			}
		}

		// Token: 0x06000D04 RID: 3332 RVA: 0x00056064 File Offset: 0x00054264
		private void tabangle_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			if (!this.ignore)
			{
				if (this.SearchTextBoxCurvature.IsChecked.Value)
				{
					BlueStacksUIColorManager.AppliedTheme.TextBoxTransForm = new SkewTransform(this.tabangleX.Value, this.tabangleY.Value);
					BlueStacksUIColorManager.AppliedTheme.TextBoxAntiTransForm = new SkewTransform(this.tabangleX.Value * -1.0, this.tabangleY.Value * -1.0);
					BlueStacksUIColorManager.AppliedTheme.NotifyUIElements();
					return;
				}
				if (this.TabTransFormLandscape.IsChecked.Value)
				{
					BlueStacksUIColorManager.AppliedTheme.TabTransform = new SkewTransform(this.tabangleX.Value, this.tabangleY.Value);
					BlueStacksUIColorManager.AppliedTheme.NotifyUIElements();
					return;
				}
				BlueStacksUIColorManager.AppliedTheme.TabTransformPortrait = new SkewTransform(this.tabangleX.Value, this.tabangleY.Value);
				BlueStacksUIColorManager.AppliedTheme.NotifyUIElements();
			}
		}

		// Token: 0x06000D05 RID: 3333 RVA: 0x00056170 File Offset: 0x00054370
		private void TabTransFormCheckedPortrait(object sender, RoutedEventArgs e)
		{
			this.ignore = true;
			this.tabangleX.Value = BlueStacksUIColorManager.AppliedTheme.TabTransformPortrait.AngleX;
			this.tabangleY.Value = BlueStacksUIColorManager.AppliedTheme.TabTransformPortrait.AngleY;
			this.ignore = false;
		}

		// Token: 0x06000D06 RID: 3334 RVA: 0x000561C0 File Offset: 0x000543C0
		private void SearchTextBoxCurvatureChecked(object sender, RoutedEventArgs e)
		{
			this.ignore = true;
			this.tabangleX.Value = BlueStacksUIColorManager.AppliedTheme.TextBoxTransForm.AngleX;
			this.tabangleY.Value = BlueStacksUIColorManager.AppliedTheme.TextBoxTransForm.AngleY;
			this.ignore = false;
		}

		// Token: 0x06000D07 RID: 3335 RVA: 0x00056210 File Offset: 0x00054410
		private void TabTransFormCheckedLandscape(object sender, RoutedEventArgs e)
		{
			this.ignore = true;
			this.tabangleX.Value = BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleX;
			this.tabangleY.Value = BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleY;
			this.ignore = false;
		}

		// Token: 0x06000D08 RID: 3336 RVA: 0x00056260 File Offset: 0x00054460
		private void cornerRadiusChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			if (!this.ignore)
			{
				BlueStacksUIColorManager.AppliedTheme.DictCornerRadius[this.dataGrid1.CurrentRow.Cells["Name"].Value.ToString()] = new CornerRadius(this.topleftCornerRadius.Value, this.toprightcornerradius.Value, this.bottomrightcornerradius.Value, this.bottomleftCornerRadius.Value);
				try
				{
					this.dataGrid1[1, this.dataGrid1.CurrentRow.Index].Value = new CornerRadius(this.topleftCornerRadius.Value, this.toprightcornerradius.Value, this.bottomrightcornerradius.Value, this.bottomleftCornerRadius.Value);
				}
				catch (Exception)
				{
				}
				BlueStacksUIColorManager.AppliedTheme.NotifyUIElements();
			}
		}

		// Token: 0x06000D09 RID: 3337 RVA: 0x00056354 File Offset: 0x00054554
		private void ListViewItem_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			if (this.ListView2.SelectedItem != null)
			{
				this.selectedItem = this.ListView2.SelectedItem.ToString();
				CustomPictureBox.SetBitmapImage(this.pictureBox, this.ListView2.SelectedItem.ToString(), false);
			}
		}

		// Token: 0x06000D0A RID: 3338 RVA: 0x000563A0 File Offset: 0x000545A0
		private void pictureBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!string.IsNullOrEmpty(this.selectedItem))
			{
				Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog();
				bool? flag = openFileDialog.ShowDialog();
				if (flag != null && flag.Value)
				{
					string fileName = openFileDialog.FileName;
					string text = Path.Combine(this.DraftDirectory, this.selectedItem.ToString(CultureInfo.InvariantCulture));
					if (!File.Exists(text))
					{
						text += ".png";
					}
					File.Copy(fileName, text, true);
					CustomPictureBox.UpdateImagesFromNewDirectory(this.DraftDirectory);
				}
			}
		}

		// Token: 0x040008E1 RID: 2273
		internal const string THUMBNAIL_ICON = "ThemeThumbnail.png";

		// Token: 0x040008E2 RID: 2274
		private string selectedItem = string.Empty;

		// Token: 0x040008E3 RID: 2275
		private bool isCreateDraftDirectory = true;

		// Token: 0x040008E4 RID: 2276
		private bool ignore = true;

		// Token: 0x040008E5 RID: 2277
		private static ThemeEditorWindow mInstance;

		// Token: 0x040008E6 RID: 2278
		private const string DraftFolderName = "Drafts";

		// Token: 0x040008E7 RID: 2279
		private string DraftDirectory = Path.Combine(RegistryManager.Instance.ClientInstallDir, "Drafts");
	}
}
