﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200022D RID: 557
	public class FrontendPopupControl : UserControl, IComponentConnector
	{
		// Token: 0x170002AD RID: 685
		// (get) Token: 0x060013CC RID: 5068 RVA: 0x0000D981 File Offset: 0x0000BB81
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x170002AE RID: 686
		// (get) Token: 0x060013CD RID: 5069 RVA: 0x0000D9A2 File Offset: 0x0000BBA2
		// (set) Token: 0x060013CE RID: 5070 RVA: 0x0000D9AA File Offset: 0x0000BBAA
		public PlayStoreAction mAction { get; set; }

		// Token: 0x060013CF RID: 5071 RVA: 0x0000D9B3 File Offset: 0x0000BBB3
		public FrontendPopupControl()
		{
			this.InitializeComponent();
			this.RequestedAppDisplayed = (EventHandler<EventArgs>)Delegate.Combine(this.RequestedAppDisplayed, new EventHandler<EventArgs>(this.RequestedApp_Displayed));
		}

		// Token: 0x060013D0 RID: 5072 RVA: 0x0007837C File Offset: 0x0007657C
		private void ProcessArgs(string googlePlayStoreArg, bool isWindowForcedTillLoaded)
		{
			this.mGooglePlayStoreArg = googlePlayStoreArg;
			this.mIsWindowForcedTillLoaded = isWindowForcedTillLoaded;
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mBaseControl.Init(this, this.ParentWindow.mFrontendGrid, false, isWindowForcedTillLoaded);
				this.mBaseControl.DimBackground();
				this.ParentWindow.mCommonHandler.SetCustomCursorForApp("com.android.vending");
				if (this.mAction == PlayStoreAction.OpenApp)
				{
					if (this.ParentWindow.mAppHandler.IsAppInstalled(googlePlayStoreArg))
					{
						this.ParentWindow.mAppHandler.SendRunAppRequestAsync(googlePlayStoreArg, "", false);
					}
					else
					{
						AppHandler.EventOnAppDisplayed = this.RequestedAppDisplayed;
						this.ParentWindow.mAppHandler.LaunchPlayRequestAsync(googlePlayStoreArg);
					}
					this.ParentWindow.mAppHandler.SwitchWhenPackageNameRecieved = "com.android.vending";
					return;
				}
				if (this.mAction == PlayStoreAction.SearchApp)
				{
					AppHandler.EventOnAppDisplayed = this.RequestedAppDisplayed;
					this.ParentWindow.mAppHandler.SendSearchPlayRequestAsync(googlePlayStoreArg);
					this.ParentWindow.mAppHandler.SwitchWhenPackageNameRecieved = "com.android.vending";
					return;
				}
				if (this.mAction == PlayStoreAction.CustomActivity)
				{
					AppHandler.EventOnAppDisplayed = this.RequestedAppDisplayed;
					this.ParentWindow.mAppHandler.SwitchWhenPackageNameRecieved = "com.android.vending";
					Dictionary<string, string> data = new Dictionary<string, string>
					{
						{
							"action",
							googlePlayStoreArg
						}
					};
					this.ParentWindow.mAppHandler.StartCustomActivity(data);
				}
			}), new object[0]);
		}

		// Token: 0x060013D1 RID: 5073 RVA: 0x0000D9E3 File Offset: 0x0000BBE3
		internal void Reload()
		{
			if (base.Visibility == Visibility.Visible && !string.IsNullOrEmpty(this.mGooglePlayStoreArg))
			{
				this.ProcessArgs(this.mGooglePlayStoreArg, this.mIsWindowForcedTillLoaded);
			}
		}

		// Token: 0x060013D2 RID: 5074 RVA: 0x0000DA0C File Offset: 0x0000BC0C
		internal void RequestedApp_Displayed(object sender, EventArgs e)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mBaseControl.ShowContent();
			}), new object[0]);
		}

		// Token: 0x060013D3 RID: 5075 RVA: 0x000783DC File Offset: 0x000765DC
		internal void Init(string args, string appName, PlayStoreAction action, bool isWindowForcedTillLoaded = false)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (!this.ParentWindow.mGuestBootCompleted)
				{
					CustomMessageWindow customMessageWindow = new CustomMessageWindow();
					BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_POST_OTS_SYNCING_BUTTON_MESSAGE", "");
					BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_GUEST_NOT_BOOTED", "");
					customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
					customMessageWindow.Owner = this.ParentWindow;
					customMessageWindow.ShowDialog();
					return;
				}
				if (action == PlayStoreAction.OpenApp && this.ParentWindow.mAppHandler.IsAppInstalled(args) && !"com.android.vending".Equals(args, StringComparison.InvariantCultureIgnoreCase))
				{
					AppIcon appIcon = this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon(args);
					if (appIcon != null)
					{
						if (appIcon.IsAppIncompat)
						{
							GrmHandler.HandleCompatibility(appIcon.PackageName, this.ParentWindow.mVmName);
							return;
						}
						this.ParentWindow.mTopBar.mAppTabButtons.AddAppTab(appIcon.AppName, appIcon.PackageName, appIcon.ActivityName, appIcon.ImageName, true, true, false);
						return;
					}
				}
				else if (!string.IsNullOrEmpty(args))
				{
					if (!this.ParentWindow.WelcomeTabParentGrid.IsVisible)
					{
						this.ParentWindow.mCommonHandler.HomeButtonHandler(false, false);
					}
					this.mBaseControl.mTitleLabel.Content = appName;
					this.mAction = action;
					this.Visibility = Visibility.Visible;
					this.ParentWindow.ChangeOrientationFromClient(false, false);
					this.ProcessArgs(args, isWindowForcedTillLoaded);
				}
			}), new object[0]);
		}

		// Token: 0x060013D4 RID: 5076 RVA: 0x0000DA2C File Offset: 0x0000BC2C
		internal void HideWindow()
		{
			this.mBaseControl.HideWindow();
		}

		// Token: 0x060013D5 RID: 5077 RVA: 0x00078434 File Offset: 0x00076634
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/frontendpopupcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060013D6 RID: 5078 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060013D7 RID: 5079 RVA: 0x0000DA39 File Offset: 0x0000BC39
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mBaseControl = (DimControlWithProgresBar)target;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x04000C78 RID: 3192
		private MainWindow mMainWindow;

		// Token: 0x04000C7A RID: 3194
		private EventHandler<EventArgs> RequestedAppDisplayed;

		// Token: 0x04000C7B RID: 3195
		private string mGooglePlayStoreArg;

		// Token: 0x04000C7C RID: 3196
		private bool mIsWindowForcedTillLoaded;

		// Token: 0x04000C7D RID: 3197
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal DimControlWithProgresBar mBaseControl;

		// Token: 0x04000C7E RID: 3198
		private bool _contentLoaded;
	}
}
