﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000150 RID: 336
	public partial class CFGReorderWindow : CustomWindow
	{
		// Token: 0x17000214 RID: 532
		// (get) Token: 0x06000D14 RID: 3348 RVA: 0x00009DF1 File Offset: 0x00007FF1
		public static CFGReorderWindow Instance
		{
			get
			{
				if (CFGReorderWindow.mInstance == null)
				{
					CFGReorderWindow.mInstance = new CFGReorderWindow();
				}
				return CFGReorderWindow.mInstance;
			}
		}

		// Token: 0x06000D15 RID: 3349 RVA: 0x00056A64 File Offset: 0x00054C64
		public CFGReorderWindow()
		{
			this.InitializeComponent();
			base.Closing += this.CFGReorderWindow_Closing;
			base.Owner = BlueStacksUIUtils.DictWindows[Strings.CurrentDefaultVmName];
			base.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		}

		// Token: 0x06000D16 RID: 3350 RVA: 0x00056AC4 File Offset: 0x00054CC4
		private void ClearState()
		{
			this.mCurrentlySelectedCFG = null;
			this.mLoadedCFGDict.Clear();
			this.mLoadedCFGsListView.Items.Clear();
			this.mSchemeTreeMapping.Clear();
			this.ClearIMLists();
			this.mLoadedCFGsListView.Visibility = Visibility.Collapsed;
			this.mSchemesListView.Visibility = Visibility.Collapsed;
			this.mIMActionsTreeView.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000D17 RID: 3351 RVA: 0x00009E09 File Offset: 0x00008009
		private void ClearIMLists()
		{
			this.mSchemesList = new ObservableCollection<IMControlScheme>();
			this.ClearIMActionsTree();
		}

		// Token: 0x06000D18 RID: 3352 RVA: 0x00009E1C File Offset: 0x0000801C
		private void ClearIMActionsTree()
		{
			this.mIMActionsTreeView.Items.Clear();
		}

		// Token: 0x06000D19 RID: 3353 RVA: 0x00009E2E File Offset: 0x0000802E
		private void CFGReorderWindow_Closing(object sender, CancelEventArgs e)
		{
			e.Cancel = true;
			base.Hide();
			this.ClearState();
		}

		// Token: 0x06000D1A RID: 3354 RVA: 0x00056B28 File Offset: 0x00054D28
		private void LoadCFGButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ClearState();
			List<string> list = new List<string>();
			string text = Path.Combine(RegistryStrings.InputMapperFolder, "UserFiles");
			if (!Directory.Exists(text) || Directory.GetFileSystemEntries(text).Length == 0)
			{
				text = RegistryStrings.InputMapperFolder;
			}
			using (OpenFileDialog openFileDialog = new OpenFileDialog
			{
				Filter = "BlueStacks keyboard controls (*.cfg)|*.cfg",
				InitialDirectory = text,
				Multiselect = true,
				RestoreDirectory = true
			})
			{
				if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
				{
					foreach (string text2 in openFileDialog.FileNames)
					{
						if (!this.CheckValidCFGAndLoad(text2))
						{
							list.Add(Path.GetFileNameWithoutExtension(text2));
						}
					}
					if (list.Count > 0)
					{
						System.Windows.MessageBox.Show("The following CFG files could not be loaded.\n" + string.Join("\n", list.ToArray()));
					}
					if (this.mLoadedCFGDict.Count > 0)
					{
						this.InitCFGList();
						this.mLoadedCFGsListView.Visibility = Visibility.Visible;
						this.mLoadedCFGsListView.SelectedIndex = 0;
					}
				}
			}
		}

		// Token: 0x06000D1B RID: 3355 RVA: 0x00056C44 File Offset: 0x00054E44
		private bool CheckValidCFGAndLoad(string filePath)
		{
			bool result = false;
			try
			{
				IMConfig value = JsonConvert.DeserializeObject<IMConfig>(File.ReadAllText(filePath), Utils.GetSerializerSettings());
				result = true;
				this.mLoadedCFGDict.Add(filePath, value);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to read cfg file... filepath: " + filePath + " Err : " + ex.Message);
			}
			return result;
		}

		// Token: 0x06000D1C RID: 3356 RVA: 0x00056CA4 File Offset: 0x00054EA4
		private List<IMAction> GetFinalListOfActions(Dictionary<string, List<IMAction>> dict)
		{
			List<IMAction> list = new List<IMAction>();
			foreach (string text in dict.Keys)
			{
				foreach (IMAction imaction in dict[text])
				{
					imaction.GuidanceCategory = text;
					list.Add(imaction);
				}
			}
			return list;
		}

		// Token: 0x06000D1D RID: 3357 RVA: 0x00056D44 File Offset: 0x00054F44
		private void SaveCFGButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			foreach (object obj in ((IEnumerable)this.mLoadedCFGsListView.Items))
			{
				System.Windows.Controls.ListViewItem listViewItem = (System.Windows.Controls.ListViewItem)obj;
				if (listViewItem.Content.ToString().EndsWith("* (modified)", StringComparison.InvariantCulture))
				{
					try
					{
						string text = listViewItem.Tag.ToString();
						IMConfig imconfig = this.mLoadedCFGDict[text];
						List<IMControlScheme> list = new List<IMControlScheme>();
						foreach (IMControlScheme imcontrolScheme in imconfig.ControlSchemes)
						{
							IMControlScheme imcontrolScheme2 = imcontrolScheme.DeepCopy();
							imcontrolScheme2.SetGameControls(this.GetFinalListOfActions(this.mSchemeTreeMapping[imconfig][imcontrolScheme]));
							list.Add(imcontrolScheme2);
						}
						imconfig.ControlSchemes = list;
						JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
						serializerSettings.Formatting = Formatting.Indented;
						this.WriteFile(text, JsonConvert.SerializeObject(imconfig, serializerSettings));
						listViewItem.Content = listViewItem.Content.ToString().TrimEnd("* (modified)".ToCharArray());
					}
					catch (Exception arg)
					{
						string text2 = string.Format("Couldn't write to file: {0}, Ex: {1}", listViewItem.Tag.ToString(), arg);
						Logger.Error(text2);
						System.Windows.MessageBox.Show(text2);
					}
				}
			}
		}

		// Token: 0x06000D1E RID: 3358 RVA: 0x00056EF0 File Offset: 0x000550F0
		private void WriteFile(string fullFilePath, string output)
		{
			string text = fullFilePath + ".tmp";
			if (File.Exists(text))
			{
				File.Delete(text);
			}
			File.WriteAllText(text, output);
			if (File.Exists(fullFilePath))
			{
				File.Delete(fullFilePath);
			}
			File.Move(text, fullFilePath);
		}

		// Token: 0x06000D1F RID: 3359 RVA: 0x00056F34 File Offset: 0x00055134
		private T FindVisualParent<T>(DependencyObject child) where T : DependencyObject
		{
			DependencyObject parent = VisualTreeHelper.GetParent(child);
			if (parent == null)
			{
				return default(T);
			}
			T t = parent as T;
			if (t != null)
			{
				return t;
			}
			return this.FindVisualParent<T>(parent);
		}

		// Token: 0x06000D20 RID: 3360 RVA: 0x00056F74 File Offset: 0x00055174
		private void MapTreeViewFromDict(Dictionary<string, List<IMAction>> dict)
		{
			foreach (string text in dict.Keys)
			{
				TreeViewItem treeViewItem = new TreeViewItem();
				treeViewItem.Header = text;
				foreach (IMAction imaction in dict[text])
				{
					TreeViewItem treeViewItem2 = new TreeViewItem();
					treeViewItem2.Header = CFGReorderWindow.GetGuidanceFromIMAction(imaction.Guidance.Values);
					treeViewItem2.Tag = imaction;
					treeViewItem.Items.Add(treeViewItem2);
				}
				this.mIMActionsTreeView.Items.Add(treeViewItem);
			}
		}

		// Token: 0x06000D21 RID: 3361 RVA: 0x00057058 File Offset: 0x00055258
		private void BuildIMActionsTree()
		{
			if (this.mSchemeTreeMapping.ContainsKey(this.mCurrentlySelectedCFG) && this.mSchemeTreeMapping[this.mCurrentlySelectedCFG].ContainsKey(this.mCurrentlySelectedScheme))
			{
				this.MapTreeViewFromDict(this.mSchemeTreeMapping[this.mCurrentlySelectedCFG][this.mCurrentlySelectedScheme]);
				return;
			}
			foreach (IMControlScheme imcontrolScheme in this.mCurrentlySelectedCFG.ControlSchemes)
			{
				Dictionary<string, List<IMAction>> dictionary = new Dictionary<string, List<IMAction>>();
				foreach (IMAction imaction in imcontrolScheme.GameControls)
				{
					if (!dictionary.ContainsKey(imaction.GuidanceCategory))
					{
						dictionary[imaction.GuidanceCategory] = new List<IMAction>();
					}
					dictionary[imaction.GuidanceCategory].Add(imaction);
				}
				if (!this.mSchemeTreeMapping.ContainsKey(this.mCurrentlySelectedCFG))
				{
					this.mSchemeTreeMapping[this.mCurrentlySelectedCFG] = new Dictionary<IMControlScheme, Dictionary<string, List<IMAction>>>();
				}
				this.mSchemeTreeMapping[this.mCurrentlySelectedCFG][imcontrolScheme] = dictionary;
				if (imcontrolScheme == this.mCurrentlySelectedScheme)
				{
					this.MapTreeViewFromDict(dictionary);
				}
			}
		}

		// Token: 0x06000D22 RID: 3362 RVA: 0x000571CC File Offset: 0x000553CC
		private static string GetGuidanceFromIMAction(Dictionary<string, string>.ValueCollection valuePairs)
		{
			if (valuePairs.Count == 0)
			{
				return "NO_GUIDANCE";
			}
			string text = "";
			foreach (string str in valuePairs)
			{
				text = text + str + " / ";
			}
			if (text.Length > 5)
			{
				text = text.Substring(0, text.Length - 3);
			}
			return text;
		}

		// Token: 0x06000D23 RID: 3363 RVA: 0x00057250 File Offset: 0x00055450
		private void InitCFGList()
		{
			foreach (string text in this.mLoadedCFGDict.Keys)
			{
				System.Windows.Controls.ListViewItem listViewItem = new System.Windows.Controls.ListViewItem();
				listViewItem.Content = Path.GetFileNameWithoutExtension(text);
				listViewItem.Tag = text;
				this.mLoadedCFGsListView.Items.Add(listViewItem);
			}
		}

		// Token: 0x06000D24 RID: 3364 RVA: 0x00009E43 File Offset: 0x00008043
		private void GenerateTreeView()
		{
			this.mIMActionsTreeView.PreviewMouseMove += this.TreeView_PreviewMouseMove;
			this.mIMActionsTreeView.ItemContainerStyle = this.GetIMActionsListStyle();
		}

		// Token: 0x06000D25 RID: 3365 RVA: 0x000572CC File Offset: 0x000554CC
		private void GenerateSchemesListView()
		{
			this.mSchemesListView.DisplayMemberPath = "Name";
			this.mSchemesListView.ItemsSource = this.mSchemesList;
			this.mSchemesListView.PreviewMouseMove += this.ListView_PreviewMouseMove;
			this.mSchemesListView.ItemContainerStyle = this.GetSchemesListStyle();
		}

		// Token: 0x06000D26 RID: 3366 RVA: 0x00057324 File Offset: 0x00055524
		private Style GetSchemesListStyle()
		{
			return new Style(typeof(System.Windows.Controls.ListViewItem))
			{
				Setters = 
				{
					new Setter(UIElement.AllowDropProperty, true),
					new EventSetter(UIElement.PreviewMouseLeftButtonDownEvent, new MouseButtonEventHandler(this.AnyItem_PreviewMouseLeftButtonDown)),
					new EventSetter(UIElement.DropEvent, new System.Windows.DragEventHandler(this.SchemeItem_Drop))
				}
			};
		}

		// Token: 0x06000D27 RID: 3367 RVA: 0x000573A0 File Offset: 0x000555A0
		private Style GetIMActionsListStyle()
		{
			return new Style(typeof(TreeViewItem))
			{
				Setters = 
				{
					new Setter(UIElement.AllowDropProperty, true),
					new EventSetter(UIElement.PreviewMouseLeftButtonDownEvent, new MouseButtonEventHandler(this.AnyItem_PreviewMouseLeftButtonDown)),
					new EventSetter(UIElement.DropEvent, new System.Windows.DragEventHandler(this.IMActionItem_Drop))
				}
			};
		}

		// Token: 0x06000D28 RID: 3368 RVA: 0x0005741C File Offset: 0x0005561C
		private void ListView_PreviewMouseMove(object sender, System.Windows.Input.MouseEventArgs e)
		{
			Point position = e.GetPosition(null);
			Vector vector = this._dragStartPoint - position;
			if (e.LeftButton == MouseButtonState.Pressed && (Math.Abs(vector.X) > SystemParameters.MinimumHorizontalDragDistance || Math.Abs(vector.Y) > SystemParameters.MinimumVerticalDragDistance))
			{
				System.Windows.Controls.ListViewItem listViewItem = this.FindVisualParent<System.Windows.Controls.ListViewItem>((DependencyObject)e.OriginalSource);
				if (listViewItem != null)
				{
					DragDrop.DoDragDrop(listViewItem, listViewItem.DataContext, System.Windows.DragDropEffects.Move);
				}
			}
		}

		// Token: 0x06000D29 RID: 3369 RVA: 0x00057490 File Offset: 0x00055690
		private void TreeView_PreviewMouseMove(object sender, System.Windows.Input.MouseEventArgs e)
		{
			Point position = e.GetPosition(null);
			Vector vector = this._dragStartPoint - position;
			if (e.LeftButton == MouseButtonState.Pressed && (Math.Abs(vector.X) > SystemParameters.MinimumHorizontalDragDistance || Math.Abs(vector.Y) > SystemParameters.MinimumVerticalDragDistance))
			{
				TreeViewItem treeViewItem = this.FindVisualParent<TreeViewItem>((DependencyObject)e.OriginalSource);
				if (treeViewItem != null)
				{
					DragDrop.DoDragDrop(treeViewItem, treeViewItem, System.Windows.DragDropEffects.Move);
				}
			}
		}

		// Token: 0x06000D2A RID: 3370 RVA: 0x00009E6D File Offset: 0x0000806D
		private void AnyItem_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			this._dragStartPoint = e.GetPosition(null);
		}

		// Token: 0x06000D2B RID: 3371 RVA: 0x00057500 File Offset: 0x00055700
		private void SchemeItem_Drop(object sender, System.Windows.DragEventArgs e)
		{
			IMControlScheme imcontrolScheme = e.Data.GetData(typeof(IMControlScheme)) as IMControlScheme;
			IMControlScheme item = ((System.Windows.Controls.ListViewItem)sender).DataContext as IMControlScheme;
			int num = this.mSchemesListView.Items.IndexOf(imcontrolScheme);
			int num2 = this.mSchemesListView.Items.IndexOf(item);
			if (num == -1 || num2 == -1)
			{
				return;
			}
			this.MoveItem(imcontrolScheme, num, num2);
			this.mSchemesListView.Items.Refresh();
			this.MarkCurrentCFGModified();
		}

		// Token: 0x06000D2C RID: 3372 RVA: 0x00057588 File Offset: 0x00055788
		private void MarkCurrentCFGModified()
		{
			ListBoxItem listBoxItem = this.mLoadedCFGsListView.SelectedItem as ListBoxItem;
			if (!listBoxItem.Content.ToString().EndsWith("* (modified)", StringComparison.InvariantCulture))
			{
				ListBoxItem listBoxItem2 = listBoxItem;
				object content = listBoxItem2.Content;
				listBoxItem2.Content = ((content != null) ? content.ToString() : null) + "* (modified)";
			}
		}

		// Token: 0x06000D2D RID: 3373 RVA: 0x000575E0 File Offset: 0x000557E0
		public static ItemsControl GetSelectedTreeViewItemParent(TreeViewItem item)
		{
			DependencyObject parent = VisualTreeHelper.GetParent(item);
			while (!(parent is TreeViewItem) && !(parent is System.Windows.Controls.TreeView))
			{
				parent = VisualTreeHelper.GetParent(parent);
			}
			return parent as ItemsControl;
		}

		// Token: 0x06000D2E RID: 3374 RVA: 0x00057614 File Offset: 0x00055814
		private void IMActionItem_Drop(object sender, System.Windows.DragEventArgs e)
		{
			TreeViewItem sourceItem = e.Data.GetData(typeof(TreeViewItem)) as TreeViewItem;
			TreeViewItem targetItem = e.Source as TreeViewItem;
			CFGReorderWindow.TreeItemDrop item = new CFGReorderWindow.TreeItemDrop(sourceItem, targetItem, this.mIMActionsTreeView);
			this.MoveItem2(item);
			this.mIMActionsTreeView.Items.Refresh();
			this.UpdateTreeDictionary();
			this.MarkCurrentCFGModified();
		}

		// Token: 0x06000D2F RID: 3375 RVA: 0x00057678 File Offset: 0x00055878
		private void UpdateTreeDictionary()
		{
			Dictionary<string, List<IMAction>> dictionary = new Dictionary<string, List<IMAction>>();
			foreach (object obj in ((IEnumerable)this.mIMActionsTreeView.Items))
			{
				TreeViewItem treeViewItem = (TreeViewItem)obj;
				List<IMAction> list = new List<IMAction>();
				foreach (object obj2 in ((IEnumerable)treeViewItem.Items))
				{
					TreeViewItem treeViewItem2 = (TreeViewItem)obj2;
					list.Add((IMAction)treeViewItem2.Tag);
				}
				dictionary[(string)treeViewItem.Header] = list;
			}
			this.mSchemeTreeMapping[this.mCurrentlySelectedCFG][this.mCurrentlySelectedScheme] = dictionary;
		}

		// Token: 0x06000D30 RID: 3376 RVA: 0x00057768 File Offset: 0x00055968
		private void MoveItem2(CFGReorderWindow.TreeItemDrop item)
		{
			if (item.IsTargetCategory != item.IsSourceCategory)
			{
				return;
			}
			if (item.AreSourceAndTargetCategories)
			{
				if (this.mIMActionsTreeView.Items.Count > item.SourceIndex)
				{
					this.mIMActionsTreeView.Items.RemoveAt(item.SourceIndex);
					this.mIMActionsTreeView.Items.Insert(item.TargetIndex, item.Source);
					return;
				}
			}
			else if (item.SourceParent.Items.Count > item.SourceIndex && item.TargetParent.Items.Count > item.TargetIndex)
			{
				item.SourceParent.Items.RemoveAt(item.SourceIndex);
				item.TargetParent.Items.Insert(item.TargetIndex, item.Source);
			}
		}

		// Token: 0x06000D31 RID: 3377 RVA: 0x0005783C File Offset: 0x00055A3C
		private void MoveItem(IMControlScheme source, int sourceIndex, int targetIndex)
		{
			if (sourceIndex < targetIndex)
			{
				this.mSchemesList.Insert(targetIndex + 1, source);
				this.mSchemesList.RemoveAt(sourceIndex);
				return;
			}
			int num = sourceIndex + 1;
			if (this.mSchemesList.Count + 1 > num)
			{
				this.mSchemesList.Insert(targetIndex, source);
				this.mSchemesList.RemoveAt(num);
			}
		}

		// Token: 0x06000D32 RID: 3378 RVA: 0x00057898 File Offset: 0x00055A98
		private void LoadedCFGsListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (this.mLoadedCFGsListView.SelectedItem == null)
			{
				return;
			}
			this.ClearIMLists();
			this.mCurrentlySelectedCFG = this.mLoadedCFGDict[(string)(this.mLoadedCFGsListView.SelectedItem as System.Windows.Controls.ListViewItem).Tag];
			this.mSchemesList = this.mCurrentlySelectedCFG.ControlSchemes;
			this.GenerateSchemesListView();
			this.mIMActionsTreeView.Items.Clear();
			if (this.mSchemesListView.Items.Count > 0)
			{
				this.mSchemesListView.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x06000D33 RID: 3379 RVA: 0x0005792C File Offset: 0x00055B2C
		private void mSchemesListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			int selectedIndex = this.mSchemesListView.SelectedIndex;
			if (selectedIndex == -1)
			{
				return;
			}
			this.mCurrentlySelectedScheme = this.mSchemesList[selectedIndex];
			this.ClearIMActionsTree();
			this.BuildIMActionsTree();
			this.GenerateTreeView();
			if (this.mIMActionsTreeView.Items.Count > 0)
			{
				this.mIMActionsTreeView.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x06000D34 RID: 3380 RVA: 0x00057990 File Offset: 0x00055B90
		private void mIMActionsTreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
		{
			this.mActionTextBox.IsEnabled = false;
			this.mActionTextBox.ScrollToLine(0);
			try
			{
				IMAction imaction = (IMAction)(this.mIMActionsTreeView.SelectedItem as TreeViewItem).Tag;
				if (imaction != null)
				{
					JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
					serializerSettings.Formatting = Formatting.Indented;
					this.mActionTextBox.Text = JsonConvert.SerializeObject(imaction, serializerSettings);
					this.mActionJsonGrid.Visibility = Visibility.Visible;
				}
				else
				{
					this.mActionTextBox.Text = "";
					this.mActionJsonGrid.Visibility = Visibility.Collapsed;
				}
			}
			catch
			{
				this.mActionTextBox.Text = "";
				this.mActionJsonGrid.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x06000D35 RID: 3381 RVA: 0x00009E7C File Offset: 0x0000807C
		private void EditButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			System.Windows.MessageBox.Show("Not implemented");
			this.mActionTextBox.IsEnabled = true;
		}

		// Token: 0x06000D36 RID: 3382 RVA: 0x00009E95 File Offset: 0x00008095
		private void SaveButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			System.Windows.MessageBox.Show("Not implemented");
		}

		// Token: 0x06000D37 RID: 3383 RVA: 0x00005D29 File Offset: 0x00003F29
		private void mLoadedCFGsListView_Scroll(object sender, System.Windows.Controls.Primitives.ScrollEventArgs e)
		{
		}

		// Token: 0x04000910 RID: 2320
		private IMConfig mCurrentlySelectedCFG;

		// Token: 0x04000911 RID: 2321
		private IMControlScheme mCurrentlySelectedScheme;

		// Token: 0x04000912 RID: 2322
		private Dictionary<string, IMConfig> mLoadedCFGDict = new Dictionary<string, IMConfig>();

		// Token: 0x04000913 RID: 2323
		private IList<IMControlScheme> mSchemesList;

		// Token: 0x04000914 RID: 2324
		private const string NO_GUIDANCE = "NO_GUIDANCE";

		// Token: 0x04000915 RID: 2325
		private const string CFG_MODIFIED_SUFFIX = "* (modified)";

		// Token: 0x04000916 RID: 2326
		private Dictionary<IMConfig, Dictionary<IMControlScheme, Dictionary<string, List<IMAction>>>> mSchemeTreeMapping = new Dictionary<IMConfig, Dictionary<IMControlScheme, Dictionary<string, List<IMAction>>>>();

		// Token: 0x04000917 RID: 2327
		private static CFGReorderWindow mInstance;

		// Token: 0x04000918 RID: 2328
		private Point _dragStartPoint;

		// Token: 0x02000151 RID: 337
		private class TreeItemDrop
		{
			// Token: 0x17000215 RID: 533
			// (get) Token: 0x06000D3B RID: 3387 RVA: 0x00009EA2 File Offset: 0x000080A2
			// (set) Token: 0x06000D3C RID: 3388 RVA: 0x00009EAA File Offset: 0x000080AA
			public TreeViewItem Source { get; set; }

			// Token: 0x17000216 RID: 534
			// (get) Token: 0x06000D3D RID: 3389 RVA: 0x00009EB3 File Offset: 0x000080B3
			// (set) Token: 0x06000D3E RID: 3390 RVA: 0x00009EBB File Offset: 0x000080BB
			public TreeViewItem Target { get; set; }

			// Token: 0x17000217 RID: 535
			// (get) Token: 0x06000D3F RID: 3391 RVA: 0x00009EC4 File Offset: 0x000080C4
			// (set) Token: 0x06000D40 RID: 3392 RVA: 0x00009ECC File Offset: 0x000080CC
			public bool IsSourceCategory { get; set; }

			// Token: 0x17000218 RID: 536
			// (get) Token: 0x06000D41 RID: 3393 RVA: 0x00009ED5 File Offset: 0x000080D5
			// (set) Token: 0x06000D42 RID: 3394 RVA: 0x00009EDD File Offset: 0x000080DD
			public bool IsTargetCategory { get; set; }

			// Token: 0x17000219 RID: 537
			// (get) Token: 0x06000D43 RID: 3395 RVA: 0x00009EE6 File Offset: 0x000080E6
			// (set) Token: 0x06000D44 RID: 3396 RVA: 0x00009EEE File Offset: 0x000080EE
			public TreeViewItem SourceParent { get; set; }

			// Token: 0x1700021A RID: 538
			// (get) Token: 0x06000D45 RID: 3397 RVA: 0x00009EF7 File Offset: 0x000080F7
			// (set) Token: 0x06000D46 RID: 3398 RVA: 0x00009EFF File Offset: 0x000080FF
			public TreeViewItem TargetParent { get; set; }

			// Token: 0x1700021B RID: 539
			// (get) Token: 0x06000D47 RID: 3399 RVA: 0x00009F08 File Offset: 0x00008108
			// (set) Token: 0x06000D48 RID: 3400 RVA: 0x00009F10 File Offset: 0x00008110
			public int SourceIndex { get; set; } = -1;

			// Token: 0x1700021C RID: 540
			// (get) Token: 0x06000D49 RID: 3401 RVA: 0x00009F19 File Offset: 0x00008119
			// (set) Token: 0x06000D4A RID: 3402 RVA: 0x00009F21 File Offset: 0x00008121
			public int TargetIndex { get; set; } = -1;

			// Token: 0x1700021D RID: 541
			// (get) Token: 0x06000D4B RID: 3403 RVA: 0x00009F2A File Offset: 0x0000812A
			// (set) Token: 0x06000D4C RID: 3404 RVA: 0x00009F32 File Offset: 0x00008132
			public bool AreSourceAndTargetCategories { get; set; }

			// Token: 0x06000D4D RID: 3405 RVA: 0x00057BE8 File Offset: 0x00055DE8
			public TreeItemDrop(TreeViewItem sourceItem, TreeViewItem targetItem, System.Windows.Controls.TreeView currentTree)
			{
				this.Source = sourceItem;
				this.Target = targetItem;
				this.SourceParent = (CFGReorderWindow.GetSelectedTreeViewItemParent(sourceItem) as TreeViewItem);
				if (this.SourceParent != null)
				{
					this.SourceIndex = this.SourceParent.Items.IndexOf(this.Source);
				}
				else
				{
					this.IsSourceCategory = true;
					this.SourceIndex = currentTree.Items.IndexOf(this.Source);
				}
				this.TargetParent = (CFGReorderWindow.GetSelectedTreeViewItemParent(targetItem) as TreeViewItem);
				if (this.TargetParent != null)
				{
					this.TargetIndex = this.TargetParent.Items.IndexOf(this.Target);
				}
				else
				{
					this.IsTargetCategory = true;
					this.TargetIndex = currentTree.Items.IndexOf(this.Target);
				}
				this.AreSourceAndTargetCategories = (this.SourceParent == null);
			}
		}
	}
}
