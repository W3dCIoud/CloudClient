﻿using System;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000048 RID: 72
	[Serializable]
	public class IMActionItem : ViewModelBase
	{
		// Token: 0x17000136 RID: 310
		// (get) Token: 0x06000354 RID: 852 RVA: 0x000043D3 File Offset: 0x000025D3
		// (set) Token: 0x06000355 RID: 853 RVA: 0x000043DB File Offset: 0x000025DB
		public string ActionItem
		{
			get
			{
				return this.mActionItem;
			}
			set
			{
				base.SetProperty<string>(ref this.mActionItem, value, null);
			}
		}

		// Token: 0x17000137 RID: 311
		// (get) Token: 0x06000356 RID: 854 RVA: 0x000043EC File Offset: 0x000025EC
		// (set) Token: 0x06000357 RID: 855 RVA: 0x000043F4 File Offset: 0x000025F4
		public IMAction IMAction
		{
			get
			{
				return this.mIMAction;
			}
			set
			{
				base.SetProperty<IMAction>(ref this.mIMAction, value, null);
			}
		}

		// Token: 0x040001D0 RID: 464
		private string mActionItem;

		// Token: 0x040001D1 RID: 465
		private IMAction mIMAction;
	}
}
