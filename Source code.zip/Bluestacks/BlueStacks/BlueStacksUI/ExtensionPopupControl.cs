﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000E1 RID: 225
	public class ExtensionPopupControl : UserControl, IComponentConnector
	{
		// Token: 0x0600091D RID: 2333 RVA: 0x00007D0A File Offset: 0x00005F0A
		public ExtensionPopupControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x0600091E RID: 2334 RVA: 0x00035ABC File Offset: 0x00033CBC
		// (remove) Token: 0x0600091F RID: 2335 RVA: 0x00035AF4 File Offset: 0x00033CF4
		public event EventHandler DownloadClicked;

		// Token: 0x06000920 RID: 2336 RVA: 0x00035B2C File Offset: 0x00033D2C
		internal void LoadExtensionPopupFromFolder(string folderPath)
		{
			if (!Path.IsPathRooted(folderPath))
			{
				folderPath = Path.Combine(CustomPictureBox.AssetsDir, folderPath);
			}
			if (Directory.Exists(folderPath))
			{
				try
				{
					string path = Path.Combine(folderPath, "extensionPopup.json");
					if (File.Exists(path))
					{
						ExtensionPopupControl.ExtensionPopupContext context = ExtensionPopupControl.ExtensionPopupContext.ReadJson(JObject.Parse(File.ReadAllText(path)));
						this.slideShow.ImagesFolderPath = folderPath;
						this.ApplyContext(context);
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Error while trying to read extensionpopup.json from " + folderPath + "." + ex.ToString());
				}
			}
		}

		// Token: 0x06000921 RID: 2337 RVA: 0x00035BC0 File Offset: 0x00033DC0
		private void ApplyContext(ExtensionPopupControl.ExtensionPopupContext context)
		{
			BlueStacksUIBinding.Bind(this.mTitle, context.Title);
			BlueStacksUIBinding.Bind(this.mSubTitle, context.SubTitle);
			BlueStacksUIBinding.Bind(this.mTagLine, context.TagLine, "");
			BlueStacksUIBinding.Bind(this.mDescription, context.Description, "");
			if (context.features != null && context.features.Any<string>())
			{
				BlueStacksUIBinding.Bind(this.mFeaturesText, context.FeaturesText, "");
				using (IEnumerator<string> enumerator = context.features.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						string path = enumerator.Current;
						TextBlock textBlock = new TextBlock
						{
							FontSize = 13.0
						};
						BlueStacksUIBinding.BindColor(textBlock, Control.ForegroundProperty, "SettingsWindowTabMenuItemForeground");
						textBlock.Margin = new Thickness(7.0, 0.0, 0.0, 5.0);
						textBlock.TextWrapping = TextWrapping.Wrap;
						BlueStacksUIBinding.Bind(textBlock, path, "");
						TextBlock textBlock2 = new TextBlock
						{
							Text = "•"
						};
						BlueStacksUIBinding.BindColor(textBlock2, Control.ForegroundProperty, "SettingsWindowTabMenuItemForeground");
						textBlock2.FontSize = 13.0;
						textBlock2.FontWeight = FontWeights.Bold;
						textBlock2.Margin = new Thickness(0.0, 0.0, 0.0, 5.0);
						BulletDecorator element = new BulletDecorator
						{
							Bullet = textBlock2,
							Child = textBlock
						};
						this.mFeaturesStack.Children.Add(element);
					}
					goto IL_1B7;
				}
			}
			this.mFeaturesText.Text = "";
			IL_1B7:
			if (context.ExtensionDetails != null && context.ExtensionDetails.Any<KeyValuePair<string, string>>())
			{
				BlueStacksUIBinding.Bind(this.mDetailsText, context.ExtensionDetailText, "");
				using (IEnumerator<KeyValuePair<string, string>> enumerator2 = context.ExtensionDetails.GetEnumerator())
				{
					while (enumerator2.MoveNext())
					{
						KeyValuePair<string, string> keyValuePair = enumerator2.Current;
						Grid grid = new Grid();
						grid.ColumnDefinitions.Add(new ColumnDefinition
						{
							Width = new GridLength(1.0, GridUnitType.Star)
						});
						grid.ColumnDefinitions.Add(new ColumnDefinition
						{
							Width = new GridLength(1.6, GridUnitType.Star)
						});
						TextBlock textBlock3 = new TextBlock
						{
							FontSize = 13.0
						};
						BlueStacksUIBinding.BindColor(textBlock3, Control.ForegroundProperty, "SettingsWindowTabMenuItemForeground");
						textBlock3.Margin = new Thickness(0.0, 0.0, 0.0, 5.0);
						textBlock3.TextWrapping = TextWrapping.Wrap;
						BlueStacksUIBinding.Bind(textBlock3, keyValuePair.Key, "");
						grid.Children.Add(textBlock3);
						Grid.SetColumn(textBlock3, 0);
						TextBlock textBlock4 = new TextBlock
						{
							FontSize = 13.0
						};
						BlueStacksUIBinding.BindColor(textBlock4, Control.ForegroundProperty, "SettingsWindowTabMenuItemForeground");
						textBlock4.Margin = new Thickness(7.0, 0.0, 0.0, 5.0);
						textBlock4.TextWrapping = TextWrapping.Wrap;
						BlueStacksUIBinding.Bind(textBlock4, keyValuePair.Value, "");
						grid.Children.Add(textBlock4);
						Grid.SetColumn(textBlock4, 1);
						this.mDetailsStack.Children.Add(grid);
					}
					return;
				}
			}
			this.mDetailsText.Text = "";
		}

		// Token: 0x06000922 RID: 2338 RVA: 0x00007B5F File Offset: 0x00005D5F
		private void CloseBtn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			BlueStacksUIUtils.CloseContainerWindow(this);
		}

		// Token: 0x06000923 RID: 2339 RVA: 0x00007D18 File Offset: 0x00005F18
		private void mDownloadButton_Click(object sender, RoutedEventArgs e)
		{
			Logger.Info("Clicked DownloadNow Button");
			EventHandler downloadClicked = this.DownloadClicked;
			if (downloadClicked == null)
			{
				return;
			}
			downloadClicked(sender, e);
		}

		// Token: 0x06000924 RID: 2340 RVA: 0x00007D36 File Offset: 0x00005F36
		private void DetailsStack_Initialized(object sender, EventArgs e)
		{
			this.mDetailsStack = (sender as StackPanel);
		}

		// Token: 0x06000925 RID: 2341 RVA: 0x00007D44 File Offset: 0x00005F44
		private void DetailsText_Initialized(object sender, EventArgs e)
		{
			this.mDetailsText = (sender as TextBlock);
		}

		// Token: 0x06000926 RID: 2342 RVA: 0x00007D52 File Offset: 0x00005F52
		private void TagLine_Initialized(object sender, EventArgs e)
		{
			this.mTagLine = (sender as TextBlock);
		}

		// Token: 0x06000927 RID: 2343 RVA: 0x00007D60 File Offset: 0x00005F60
		private void Description_Initialized(object sender, EventArgs e)
		{
			this.mDescription = (sender as TextBlock);
		}

		// Token: 0x06000928 RID: 2344 RVA: 0x00007D6E File Offset: 0x00005F6E
		private void FeaturesText_Initialized(object sender, EventArgs e)
		{
			this.mFeaturesText = (sender as TextBlock);
		}

		// Token: 0x06000929 RID: 2345 RVA: 0x00007D7C File Offset: 0x00005F7C
		private void FeaturesStack_Initialized(object sender, EventArgs e)
		{
			this.mFeaturesStack = (sender as StackPanel);
		}

		// Token: 0x0600092A RID: 2346 RVA: 0x00035FA8 File Offset: 0x000341A8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/extensionpopupcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600092B RID: 2347 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600092C RID: 2348 RVA: 0x00035FD8 File Offset: 0x000341D8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mTitle = (Label)target;
				return;
			case 2:
				this.mSubTitle = (Label)target;
				return;
			case 3:
				this.mDownloadButton = (CustomButton)target;
				this.mDownloadButton.Click += this.mDownloadButton_Click;
				return;
			case 4:
				this.mCloseBtn = (CustomPictureBox)target;
				this.mCloseBtn.MouseLeftButtonUp += this.CloseBtn_MouseLeftButtonUp;
				return;
			case 5:
				((TextBlock)target).Initialized += this.TagLine_Initialized;
				return;
			case 6:
				((TextBlock)target).Initialized += this.Description_Initialized;
				return;
			case 7:
				((StackPanel)target).Initialized += this.FeaturesStack_Initialized;
				return;
			case 8:
				((TextBlock)target).Initialized += this.FeaturesText_Initialized;
				return;
			case 9:
				((StackPanel)target).Initialized += this.DetailsStack_Initialized;
				return;
			case 10:
				((TextBlock)target).Initialized += this.DetailsText_Initialized;
				return;
			case 11:
				this.slideShow = (SlideShowControl)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040005A1 RID: 1441
		private StackPanel mFeaturesStack;

		// Token: 0x040005A2 RID: 1442
		private StackPanel mDetailsStack;

		// Token: 0x040005A3 RID: 1443
		private TextBlock mDetailsText;

		// Token: 0x040005A4 RID: 1444
		private TextBlock mTagLine;

		// Token: 0x040005A5 RID: 1445
		private TextBlock mDescription;

		// Token: 0x040005A6 RID: 1446
		private TextBlock mFeaturesText;

		// Token: 0x040005A8 RID: 1448
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Label mTitle;

		// Token: 0x040005A9 RID: 1449
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Label mSubTitle;

		// Token: 0x040005AA RID: 1450
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mDownloadButton;

		// Token: 0x040005AB RID: 1451
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCloseBtn;

		// Token: 0x040005AC RID: 1452
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal SlideShowControl slideShow;

		// Token: 0x040005AD RID: 1453
		private bool _contentLoaded;

		// Token: 0x020000E2 RID: 226
		[JsonObject(MemberSerialization.OptIn)]
		internal class ExtensionPopupContext
		{
			// Token: 0x0600092D RID: 2349 RVA: 0x00007D8A File Offset: 0x00005F8A
			public static ExtensionPopupControl.ExtensionPopupContext ReadJson(JObject input)
			{
				ExtensionPopupControl.ExtensionPopupContext extensionPopupContext = input.ToObject<ExtensionPopupControl.ExtensionPopupContext>();
				extensionPopupContext.features = input["features"].ToIenumerableString();
				extensionPopupContext.ExtensionDetails = input["ExtensionDetails"].ToStringStringEnumerableKvp();
				return extensionPopupContext;
			}

			// Token: 0x0600092E RID: 2350 RVA: 0x00036124 File Offset: 0x00034324
			public void WriteJson(JObject writer)
			{
				writer.Add("Title", this.Title);
				writer.Add("SubTitle", this.SubTitle);
				writer.Add("TagLine", this.TagLine);
				writer.Add("Description", this.Description);
				writer.Add("FeaturesText", this.FeaturesText);
				writer.Add("features", new JArray
				{
					this.features.ToList<string>()
				});
				writer.Add("ExtensionDetailText", this.ExtensionDetailText);
				writer.Add("ExtensionDetails");
				foreach (KeyValuePair<string, string> keyValuePair in this.ExtensionDetails)
				{
					writer.Add(keyValuePair.Key, keyValuePair.Value);
				}
			}

			// Token: 0x040005AE RID: 1454
			[JsonProperty("Title", NullValueHandling = NullValueHandling.Ignore)]
			internal string Title;

			// Token: 0x040005AF RID: 1455
			[JsonProperty("SubTitle", NullValueHandling = NullValueHandling.Ignore)]
			internal string SubTitle;

			// Token: 0x040005B0 RID: 1456
			[JsonProperty("TagLine", NullValueHandling = NullValueHandling.Ignore)]
			internal string TagLine;

			// Token: 0x040005B1 RID: 1457
			[JsonProperty("Description", NullValueHandling = NullValueHandling.Ignore)]
			internal string Description;

			// Token: 0x040005B2 RID: 1458
			[JsonProperty("FeaturesText", NullValueHandling = NullValueHandling.Ignore)]
			internal string FeaturesText;

			// Token: 0x040005B3 RID: 1459
			[JsonProperty("dummyFeatures", NullValueHandling = NullValueHandling.Ignore)]
			internal IEnumerable<string> features;

			// Token: 0x040005B4 RID: 1460
			[JsonProperty("ExtensionDetailText", NullValueHandling = NullValueHandling.Ignore)]
			internal string ExtensionDetailText;

			// Token: 0x040005B5 RID: 1461
			[JsonProperty("dummyExtensionDetails", NullValueHandling = NullValueHandling.Ignore)]
			internal IEnumerable<KeyValuePair<string, string>> ExtensionDetails;
		}
	}
}
