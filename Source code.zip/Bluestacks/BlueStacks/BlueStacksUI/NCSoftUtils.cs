﻿using System;
using System.Collections.Generic;
using System.Threading;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000153 RID: 339
	internal class NCSoftUtils
	{
		// Token: 0x1700021E RID: 542
		// (get) Token: 0x06000D50 RID: 3408 RVA: 0x00057D88 File Offset: 0x00055F88
		internal static NCSoftUtils Instance
		{
			get
			{
				if (NCSoftUtils.mInstance == null)
				{
					object obj = NCSoftUtils.sync;
					lock (obj)
					{
						if (NCSoftUtils.mInstance == null)
						{
							NCSoftUtils.mInstance = new NCSoftUtils();
						}
					}
				}
				return NCSoftUtils.mInstance;
			}
		}

		// Token: 0x06000D51 RID: 3409 RVA: 0x00057DD8 File Offset: 0x00055FD8
		private int GetNCSoftAgentPort()
		{
			if (this.mNCSoftAgentPort != -1)
			{
				return this.mNCSoftAgentPort;
			}
			string sharedMemoryName = "ngpmmf";
			uint numBytes = 2U;
			try
			{
				this.mNCSoftAgentPort = MemoryMappedFile.GetNCSoftAgentPort(sharedMemoryName, numBytes);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to get ncsoft agent port");
				Logger.Error(ex.ToString());
			}
			return this.mNCSoftAgentPort;
		}

		// Token: 0x06000D52 RID: 3410 RVA: 0x00057E38 File Offset: 0x00056038
		internal void SendAppCrashEvent(string crashReason, string vmName)
		{
			try
			{
				int ncsoftAgentPort = this.GetNCSoftAgentPort();
				if (ncsoftAgentPort != -1)
				{
					Dictionary<string, string> data = new Dictionary<string, string>
					{
						{
							"vm_name",
							vmName
						},
						{
							"err_message",
							crashReason
						}
					};
					Logger.Info("Sending app crash event to NCSoft Agent for vm: " + vmName);
					Logger.Info("Reason: " + crashReason);
					string msg = HTTPUtils.SendRequestToNCSoftAgent(ncsoftAgentPort, "error/crash", data, vmName, 0, null, false, 1, 0);
					Logger.Info("app crash event resp:");
					Logger.Info(msg);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to report app crash. Ex : " + ex.ToString());
			}
		}

		// Token: 0x06000D53 RID: 3411 RVA: 0x00009F3B File Offset: 0x0000813B
		internal void SendGoogleLoginEventAsync(string vmName)
		{
			ThreadPool.QueueUserWorkItem(delegate(object o)
			{
				try
				{
					int ncsoftAgentPort = this.GetNCSoftAgentPort();
					if (ncsoftAgentPort != -1)
					{
						Dictionary<string, string> data = new Dictionary<string, string>
						{
							{
								"vm_name",
								vmName
							},
							{
								"first",
								"true"
							}
						};
						Logger.Info("Sending google login event to NCSoft Agent for vm: " + vmName);
						string msg = HTTPUtils.SendRequestToNCSoftAgent(ncsoftAgentPort, "account/google/login", data, vmName, 0, null, false, 1, 0);
						Logger.Info("account google login event resp:");
						Logger.Info(msg);
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to report google login. Ex : " + ex.ToString());
				}
			});
		}

		// Token: 0x06000D54 RID: 3412 RVA: 0x00009F61 File Offset: 0x00008161
		internal void SendStreamingEvent(string vmName, string streamingStatus)
		{
			ThreadPool.QueueUserWorkItem(delegate(object o)
			{
				try
				{
					int ncsoftAgentPort = this.GetNCSoftAgentPort();
					if (ncsoftAgentPort != -1)
					{
						Dictionary<string, string> data = new Dictionary<string, string>
						{
							{
								"button",
								"streaming"
							},
							{
								"state",
								streamingStatus
							},
							{
								"vm_name",
								vmName
							}
						};
						Logger.Info("Sending streaming event to NCSoft Agent for vm: " + vmName);
						Logger.Info("Status : " + streamingStatus);
						string msg = HTTPUtils.SendRequestToNCSoftAgent(ncsoftAgentPort, "action/button/streaming", data, vmName, 0, null, false, 1, 0);
						Logger.Info("action button streaming event resp:");
						Logger.Info(msg);
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to report action button streaming. Ex : " + ex.ToString());
				}
			});
		}

		// Token: 0x0400092C RID: 2348
		private static object sync = new object();

		// Token: 0x0400092D RID: 2349
		internal List<string> BlackListedApps = new List<string>
		{
			"com.bluestacks",
			"com.google",
			"com.android",
			"com.uncube"
		};

		// Token: 0x0400092E RID: 2350
		private int mNCSoftAgentPort = -1;

		// Token: 0x0400092F RID: 2351
		private static NCSoftUtils mInstance = null;
	}
}
