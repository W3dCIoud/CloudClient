﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;
using System.Timers;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000083 RID: 131
	internal class SecurityMetrics : IDisposable
	{
		// Token: 0x170001A1 RID: 417
		// (get) Token: 0x06000527 RID: 1319 RVA: 0x0000569C File Offset: 0x0000389C
		// (set) Token: 0x06000528 RID: 1320 RVA: 0x000056A3 File Offset: 0x000038A3
		public static SerializableDictionary<string, SecurityMetrics> SecurityMetricsInstanceList { get; set; } = new SerializableDictionary<string, SecurityMetrics>();

		// Token: 0x06000529 RID: 1321 RVA: 0x0001F91C File Offset: 0x0001DB1C
		public SecurityMetrics(string vmName)
		{
			this.mVmName = vmName;
			this.mTimer = new System.Timers.Timer
			{
				Interval = 86400000.0
			};
			this.mTimer.Elapsed += this.OnTimedEvent;
			this.mTimer.AutoReset = true;
			this.mTimer.Enabled = true;
			new Thread(delegate()
			{
				this.CheckMd5HashOfRootVdi();
				this.CheckAppPlayerRootInfoFromAndroidBstk();
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x0600052A RID: 1322 RVA: 0x000056AB File Offset: 0x000038AB
		private void OnTimedEvent(object sender, ElapsedEventArgs e)
		{
			this.SendSecurityBreachesStatsToCloud(false);
		}

		// Token: 0x0600052B RID: 1323 RVA: 0x000056B4 File Offset: 0x000038B4
		internal static void Init(string vmName)
		{
			if (!SecurityMetrics.SecurityMetricsInstanceList.ContainsKey(vmName))
			{
				SecurityMetrics.SecurityMetricsInstanceList.Add(vmName, new SecurityMetrics(vmName));
			}
		}

		// Token: 0x0600052C RID: 1324 RVA: 0x000056D4 File Offset: 0x000038D4
		internal void SendSecurityBreachesStatsToCloud(bool isOnClose = false)
		{
			new Thread(delegate()
			{
				try
				{
					this.AddBlacklistedRunningApplicationsToSecurityBreaches();
					if (this.mSecurityBreachesList.Count > 0)
					{
						string urlWithParams = WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
						{
							RegistryManager.Instance.Host,
							"/bs4/security_metrics"
						}));
						Dictionary<string, string> data = new Dictionary<string, string>
						{
							{
								"security_metric_data",
								this.GetSecurityMetricsData()
							}
						};
						BstHttpClient.Post(urlWithParams, data, null, false, this.mVmName, 10000, 1, 0, false);
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception while sending security stats to cloud : {0}", new object[]
					{
						ex.ToString()
					});
				}
				if (isOnClose)
				{
					SecurityMetrics.SecurityMetricsInstanceList.Remove(this.mVmName);
				}
			}).Start();
		}

		// Token: 0x0600052D RID: 1325 RVA: 0x0001F9A8 File Offset: 0x0001DBA8
		private string GetSecurityMetricsData()
		{
			string text = string.Empty;
			StringBuilder stringBuilder = new StringBuilder();
			using (StringWriter stringWriter = new StringWriter(stringBuilder))
			{
				using (JsonWriter jsonWriter = new JsonTextWriter(stringWriter)
				{
					Formatting = Formatting.Indented
				})
				{
					jsonWriter.WriteStartObject();
					foreach (SecurityBreach securityBreach in this.mSecurityBreachesList.Keys)
					{
						if (securityBreach != SecurityBreach.SCRIPT_TOOLS)
						{
							if (securityBreach - SecurityBreach.DEVICE_PROBED <= 3)
							{
								jsonWriter.WritePropertyName(securityBreach.ToString().ToLower(CultureInfo.InvariantCulture));
								jsonWriter.WriteValue(this.mSecurityBreachesList[securityBreach]);
							}
						}
						else
						{
							jsonWriter.WritePropertyName(securityBreach.ToString().ToLower(CultureInfo.InvariantCulture));
							jsonWriter.WriteStartObject();
							jsonWriter.WritePropertyName("running_blacklist_programs");
							jsonWriter.WriteValue(this.mSecurityBreachesList[securityBreach]);
							jsonWriter.WriteEndObject();
						}
					}
					jsonWriter.WriteEndObject();
					text = stringBuilder.ToString();
					Logger.Debug("security data " + text);
				}
			}
			return text;
		}

		// Token: 0x0600052E RID: 1326 RVA: 0x0001FAF8 File Offset: 0x0001DCF8
		private void AddBlacklistedRunningApplicationsToSecurityBreaches()
		{
			List<string> blackListedApplicationsList = PromotionObject.Instance.BlackListedApplicationsList;
			List<string> list = new List<string>();
			foreach (string text in blackListedApplicationsList)
			{
				if (ProcessUtils.FindProcessByName(text))
				{
					list.Add(text);
				}
			}
			if (list.Count > 0)
			{
				string data = JsonConvert.SerializeObject(list);
				this.AddSecurityBreach(SecurityBreach.SCRIPT_TOOLS, data);
			}
		}

		// Token: 0x0600052F RID: 1327 RVA: 0x0001FB78 File Offset: 0x0001DD78
		internal void AddSecurityBreach(SecurityBreach breach, string data)
		{
			try
			{
				if (!this.mSecurityBreachesList.ContainsKey(breach))
				{
					this.mSecurityBreachesList.Add(breach, data);
					Logger.Info("Security breach added for: {0}", new object[]
					{
						breach
					});
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in adding security breach: {0}", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x06000530 RID: 1328 RVA: 0x0001FBE8 File Offset: 0x0001DDE8
		internal void CheckMd5HashOfRootVdi()
		{
			try
			{
				string blockDevice0Path = RegistryManager.Instance.Guest["Android"].BlockDevice0Path;
				string rootVdiMd5Hash = RegistryManager.Instance.RootVdiMd5Hash;
				if (string.IsNullOrEmpty(rootVdiMd5Hash))
				{
					Utils.CreateMD5HashOfRootVdi();
				}
				else
				{
					string md5HashFromFile = Utils.GetMD5HashFromFile(blockDevice0Path);
					if (!string.IsNullOrEmpty(md5HashFromFile) && !string.Equals(md5HashFromFile, rootVdiMd5Hash, StringComparison.OrdinalIgnoreCase))
					{
						this.AddSecurityBreach(SecurityBreach.DEVICE_ROOTED, string.Empty);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in checking md5 hash of root vdi: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x06000531 RID: 1329 RVA: 0x0001FC78 File Offset: 0x0001DE78
		private void CheckAppPlayerRootInfoFromAndroidBstk()
		{
			try
			{
				JArray jarray = JArray.Parse(HTTPUtils.SendRequestToEngine("isAppPlayerRooted", null, this.mVmName, 0, null, false, 1, 0, ""));
				if ((bool)jarray[0]["success"] && (bool)jarray[0]["isRooted"])
				{
					this.AddSecurityBreach(SecurityBreach.DEVICE_ROOTED, string.Empty);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in checking root info from engine: {0}", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x06000532 RID: 1330 RVA: 0x000056FE File Offset: 0x000038FE
		protected virtual void Dispose(bool disposing)
		{
			if (!this.disposedValue)
			{
				if (this.mTimer != null)
				{
					this.mTimer.Elapsed -= this.OnTimedEvent;
					this.mTimer.Dispose();
				}
				this.disposedValue = true;
			}
		}

		// Token: 0x06000533 RID: 1331 RVA: 0x0001FD10 File Offset: 0x0001DF10
		~SecurityMetrics()
		{
			this.Dispose(false);
		}

		// Token: 0x06000534 RID: 1332 RVA: 0x0000573B File Offset: 0x0000393B
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x040002C5 RID: 709
		private Dictionary<SecurityBreach, string> mSecurityBreachesList = new Dictionary<SecurityBreach, string>();

		// Token: 0x040002C6 RID: 710
		private string mVmName;

		// Token: 0x040002C7 RID: 711
		private System.Timers.Timer mTimer;

		// Token: 0x040002C8 RID: 712
		private bool disposedValue;
	}
}
