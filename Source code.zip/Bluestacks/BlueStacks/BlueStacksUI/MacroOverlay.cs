﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000C6 RID: 198
	public class MacroOverlay : UserControl, IDimOverlayControl, IComponentConnector
	{
		// Token: 0x170001CA RID: 458
		// (get) Token: 0x06000817 RID: 2071 RVA: 0x000072E1 File Offset: 0x000054E1
		// (set) Token: 0x06000818 RID: 2072 RVA: 0x000072E9 File Offset: 0x000054E9
		public MainWindow ParentWindow { get; set; }

		// Token: 0x06000819 RID: 2073 RVA: 0x000072F2 File Offset: 0x000054F2
		public MacroOverlay()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600081A RID: 2074 RVA: 0x00007300 File Offset: 0x00005500
		public MacroOverlay(MainWindow mainWindow)
		{
			this.ParentWindow = mainWindow;
		}

		// Token: 0x0600081B RID: 2075 RVA: 0x0000730F File Offset: 0x0000550F
		private void CloseButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.HideOverlay();
			this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("abortReroll", null);
		}

		// Token: 0x0600081C RID: 2076 RVA: 0x0000732D File Offset: 0x0000552D
		private void HideOverlay()
		{
			this.ParentWindow.HideDimOverlay();
		}

		// Token: 0x0600081D RID: 2077 RVA: 0x0002F8B0 File Offset: 0x0002DAB0
		internal void ShowPromptAndHideOverlay()
		{
			if (base.Visibility == Visibility.Visible)
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_REROLL_COMPLETED", "");
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_REROLL_COMPLETED_SUCCESS", "");
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
				this.HideOverlay();
			}
		}

		// Token: 0x0600081E RID: 2078 RVA: 0x0000681D File Offset: 0x00004A1D
		bool IDimOverlayControl.Close()
		{
			base.Visibility = Visibility.Hidden;
			return true;
		}

		// Token: 0x170001CB RID: 459
		// (get) Token: 0x0600081F RID: 2079 RVA: 0x0000733A File Offset: 0x0000553A
		// (set) Token: 0x06000820 RID: 2080 RVA: 0x00007342 File Offset: 0x00005542
		bool IDimOverlayControl.IsCloseOnOverLayClick
		{
			get
			{
				return this.mIsCloseOnOverLayClick;
			}
			set
			{
				this.mIsCloseOnOverLayClick = value;
			}
		}

		// Token: 0x170001CC RID: 460
		// (get) Token: 0x06000821 RID: 2081 RVA: 0x0000734B File Offset: 0x0000554B
		// (set) Token: 0x06000822 RID: 2082 RVA: 0x00007353 File Offset: 0x00005553
		public bool ShowControlInSeparateWindow { get; set; }

		// Token: 0x06000823 RID: 2083 RVA: 0x0000624E File Offset: 0x0000444E
		bool IDimOverlayControl.Show()
		{
			base.Visibility = Visibility.Visible;
			return true;
		}

		// Token: 0x06000824 RID: 2084 RVA: 0x0002F938 File Offset: 0x0002DB38
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/macrooverlay.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000825 RID: 2085 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000826 RID: 2086 RVA: 0x0000735C File Offset: 0x0000555C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				((CustomPictureBox)target).PreviewMouseLeftButtonUp += this.CloseButton_PreviewMouseLeftButtonUp;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x040004D5 RID: 1237
		private bool mIsCloseOnOverLayClick;

		// Token: 0x040004D7 RID: 1239
		private bool _contentLoaded;
	}
}
