﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Navigation;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000103 RID: 259
	public class SpeedUpBluestacksUserControl : UserControl, IComponentConnector
	{
		// Token: 0x06000A1B RID: 2587 RVA: 0x000086E8 File Offset: 0x000068E8
		public SpeedUpBluestacksUserControl()
		{
			this.InitializeComponent();
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				this.mHyperLink.Foreground = (SolidColorBrush)new BrushConverter().ConvertFrom("#FF328CF2");
			}
		}

		// Token: 0x06000A1C RID: 2588 RVA: 0x0003A7BC File Offset: 0x000389BC
		private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
		{
			try
			{
				Logger.Info("Opening url: " + e.Uri.AbsoluteUri);
				BlueStacksUIUtils.OpenUrl(e.Uri.AbsoluteUri);
				e.Handled = true;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in opening url" + ex.ToString());
			}
		}

		// Token: 0x06000A1D RID: 2589 RVA: 0x0003A824 File Offset: 0x00038A24
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/speedupbluestacksusercontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000A1E RID: 2590 RVA: 0x0003A854 File Offset: 0x00038A54
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mTitleText = (TextBlock)target;
				return;
			case 2:
				this.mBodyText = (TextBlock)target;
				return;
			case 3:
				this.mImage = (CustomPictureBox)target;
				return;
			case 4:
				this.mHyperLink = (Hyperlink)target;
				this.mHyperLink.RequestNavigate += this.Hyperlink_RequestNavigate;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000664 RID: 1636
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mTitleText;

		// Token: 0x04000665 RID: 1637
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mBodyText;

		// Token: 0x04000666 RID: 1638
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mImage;

		// Token: 0x04000667 RID: 1639
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Hyperlink mHyperLink;

		// Token: 0x04000668 RID: 1640
		private bool _contentLoaded;
	}
}
