﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000244 RID: 580
	public partial class HomeAppTabButton : Button
	{
		// Token: 0x170002C2 RID: 706
		// (get) Token: 0x060014C2 RID: 5314 RVA: 0x0000E249 File Offset: 0x0000C449
		// (set) Token: 0x060014C3 RID: 5315 RVA: 0x0000E251 File Offset: 0x0000C451
		public string Key { get; set; } = string.Empty;

		// Token: 0x170002C3 RID: 707
		// (get) Token: 0x060014C4 RID: 5316 RVA: 0x0000E25A File Offset: 0x0000C45A
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x170002C4 RID: 708
		// (get) Token: 0x060014C5 RID: 5317 RVA: 0x0000E27B File Offset: 0x0000C47B
		// (set) Token: 0x060014C6 RID: 5318 RVA: 0x0000E288 File Offset: 0x0000C488
		public string Text
		{
			get
			{
				return this.mTabHeader.Text;
			}
			set
			{
				this.Key = value + "-Normal";
				this.ImageBox.ImageName = this.Key;
				BlueStacksUIBinding.Bind(this.mTabHeader, value, "");
			}
		}

		// Token: 0x170002C5 RID: 709
		// (get) Token: 0x060014C7 RID: 5319 RVA: 0x0000E2BD File Offset: 0x0000C4BD
		// (set) Token: 0x060014C8 RID: 5320 RVA: 0x0000E2C5 File Offset: 0x0000C4C5
		public int Column { get; internal set; }

		// Token: 0x170002C6 RID: 710
		// (get) Token: 0x060014C9 RID: 5321 RVA: 0x0000E2CE File Offset: 0x0000C4CE
		// (set) Token: 0x060014CA RID: 5322 RVA: 0x0000E2D6 File Offset: 0x0000C4D6
		public BrowserControl AssociatedUserControl
		{
			get
			{
				return this.mAssociatedUserControl;
			}
			set
			{
				this.mAssociatedUserControl = value;
				if (this.mAssociatedUserControl != null)
				{
					this.mAssociatedUserControl.RenderTransform = this.mTranslateTransform;
				}
			}
		}

		// Token: 0x060014CB RID: 5323 RVA: 0x0007D300 File Offset: 0x0007B500
		private void AssociatedGrid_LayoutUpdated(object sender, EventArgs e)
		{
			try
			{
				if (!this.IsSelected && Math.Abs(Math.Abs(this.mTranslateTransform.X) - this.mAssociatedUserControl.ActualWidth) <= 10.0)
				{
					this.mAssociatedUserControl.Visibility = Visibility.Hidden;
					this.mAssociatedUserControl.LayoutUpdated -= this.AssociatedGrid_LayoutUpdated;
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Error updating " + ex.ToString());
			}
		}

		// Token: 0x170002C7 RID: 711
		// (get) Token: 0x060014CC RID: 5324 RVA: 0x0000E2F8 File Offset: 0x0000C4F8
		// (set) Token: 0x060014CD RID: 5325 RVA: 0x0007D390 File Offset: 0x0007B590
		public bool IsSelected
		{
			get
			{
				return this.mIsSelected;
			}
			set
			{
				if (this.ParentWindow.StaticComponents.mSelectedHomeAppTabButton != this || !value)
				{
					this.mIsSelected = value;
					if (this.ParentWindow.StaticComponents.mSelectedHomeAppTabButton != null)
					{
						HomeAppTabButton mSelectedHomeAppTabButton = this.ParentWindow.StaticComponents.mSelectedHomeAppTabButton;
						if (this.Column > mSelectedHomeAppTabButton.Column)
						{
							HomeAppTabButton.mIsSwipeDirectonLeft = true;
						}
						else
						{
							HomeAppTabButton.mIsSwipeDirectonLeft = false;
						}
						this.ParentWindow.StaticComponents.mSelectedHomeAppTabButton = null;
						if (this.mAssociatedUserControl == mSelectedHomeAppTabButton.mAssociatedUserControl)
						{
							mSelectedHomeAppTabButton.IsAnimationIgnored = true;
							this.IsAnimationIgnored = true;
						}
						mSelectedHomeAppTabButton.IsSelected = false;
					}
					if (this.mIsSelected)
					{
						BlueStacksUIBinding.BindColor(this.mTabHeader, TextBlock.ForegroundProperty, "SelectedHomeAppTabForegroundColor");
						BlueStacksUIBinding.BindColor(this.mBottomGrid, Panel.BackgroundProperty, "HomeAppTabBackgroundColor");
						this.ParentWindow.StaticComponents.mSelectedHomeAppTabButton = this;
						this.ParentWindow.Utils.ResetPendingUIOperations();
						this.mGridHighlighterBox.Visibility = Visibility.Visible;
						this.AnimateAssociatedGrid(true);
						this.ImageBox.ImageName = this.Key.Replace("Normal", "Active");
						if (this.mAssociatedUserControl.CefBrowser != null)
						{
							MiscUtils.SetFocusAsync(this.ParentWindow.mWelcomeTab.mHomeApp.mSearchTextBox, this.animationTime + 100);
							MiscUtils.SetFocusAsync(this.mAssociatedUserControl.CefBrowser, 0);
							return;
						}
					}
					else
					{
						BlueStacksUIBinding.BindColor(this.mTabHeader, TextBlock.ForegroundProperty, "HomeAppTabForegroundColor");
						this.mGridHighlighterBox.Visibility = Visibility.Hidden;
						this.AnimateAssociatedGrid(false);
						this.ImageBox.ImageName = this.Key.Replace("Active", "Normal");
					}
				}
			}
		}

		// Token: 0x170002C8 RID: 712
		// (get) Token: 0x060014CE RID: 5326 RVA: 0x0000E300 File Offset: 0x0000C500
		// (set) Token: 0x060014CF RID: 5327 RVA: 0x0000E308 File Offset: 0x0000C508
		public bool IsAnimationIgnored { get; set; }

		// Token: 0x060014D0 RID: 5328 RVA: 0x0007D544 File Offset: 0x0007B744
		private void AnimateAssociatedGrid(bool show)
		{
			if (this.IsAnimationIgnored)
			{
				this.IsAnimationIgnored = false;
				return;
			}
			this.mAssociatedUserControl.LayoutUpdated += this.AssociatedGrid_LayoutUpdated;
			DoubleAnimation animation;
			if (show)
			{
				this.mAssociatedUserControl.Visibility = Visibility.Visible;
				if (HomeAppTabButton.mIsSwipeDirectonLeft)
				{
					animation = new DoubleAnimation(this.mAssociatedUserControl.ActualWidth, 0.0, TimeSpan.FromMilliseconds((double)this.animationTime));
				}
				else
				{
					animation = new DoubleAnimation(-1.0 * this.mAssociatedUserControl.ActualWidth, 0.0, TimeSpan.FromMilliseconds((double)this.animationTime));
				}
			}
			else if (HomeAppTabButton.mIsSwipeDirectonLeft)
			{
				animation = new DoubleAnimation(0.0, -1.0 * this.mAssociatedUserControl.ActualWidth, TimeSpan.FromMilliseconds((double)this.animationTime));
			}
			else
			{
				animation = new DoubleAnimation(0.0, this.mAssociatedUserControl.ActualWidth, TimeSpan.FromMilliseconds((double)this.animationTime));
			}
			this.mTranslateTransform.BeginAnimation(TranslateTransform.XProperty, animation);
		}

		// Token: 0x060014D1 RID: 5329 RVA: 0x0000E311 File Offset: 0x0000C511
		public HomeAppTabButton()
		{
			this.InitializeComponent();
		}

		// Token: 0x060014D2 RID: 5330 RVA: 0x0000E340 File Offset: 0x0000C540
		private void Button_Click(object sender, RoutedEventArgs e)
		{
			this.IsSelected = true;
		}

		// Token: 0x060014D3 RID: 5331 RVA: 0x0000E349 File Offset: 0x0000C549
		private void Button_MouseEnter(object sender, MouseEventArgs e)
		{
			if (!this.IsSelected)
			{
				BlueStacksUIBinding.BindColor(this.mBottomGrid, Panel.BackgroundProperty, "HomeAppTabBackgroundHoverColor");
				BlueStacksUIBinding.BindColor(this.mTabHeader, TextBlock.ForegroundProperty, "HomeAppTabForegroundHoverColor");
			}
		}

		// Token: 0x060014D4 RID: 5332 RVA: 0x0000E37D File Offset: 0x0000C57D
		private void Button_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.IsSelected)
			{
				BlueStacksUIBinding.BindColor(this.mBottomGrid, Panel.BackgroundProperty, "HomeAppTabBackgroundColor");
				BlueStacksUIBinding.BindColor(this.mTabHeader, TextBlock.ForegroundProperty, "HomeAppTabForegroundColor");
			}
		}

		// Token: 0x060014D5 RID: 5333 RVA: 0x0000E3B1 File Offset: 0x0000C5B1
		private void Button_Loaded(object sender, RoutedEventArgs e)
		{
			this.SetMaxWidth(0.0);
		}

		// Token: 0x060014D6 RID: 5334 RVA: 0x0007D670 File Offset: 0x0007B870
		internal void SetMaxWidth(double extraWidth = 0.0)
		{
			double num = 0.0;
			Typeface typeface = new Typeface(this.mTabHeader.FontFamily, this.mTabHeader.FontStyle, this.mTabHeader.FontWeight, this.mTabHeader.FontStretch);
			FormattedText formattedText = new FormattedText(this.mTabHeader.Text, Thread.CurrentThread.CurrentCulture, this.mTabHeader.FlowDirection, typeface, this.mTabHeader.FontSize, this.mTabHeader.Foreground);
			num += this.mAppTabNotificationCountBorder.ActualWidth;
			num += formattedText.WidthIncludingTrailingWhitespace;
			num += this.tabGrid.ActualHeight;
			num += 30.0;
			if (extraWidth == 1.7976931348623157E+308)
			{
				if (this.tabGrid.ColumnDefinitions[0].Width.IsStar)
				{
					num += 50.0;
				}
			}
			else
			{
				num += extraWidth;
			}
			int column = Grid.GetColumn(this.mTabHeader);
			if ((extraWidth > 0.0 && extraWidth < 1.7976931348623157E+308) || (this.tabGrid.ColumnDefinitions[0].Width.IsStar && extraWidth == 1.7976931348623157E+308))
			{
				this.tabGrid.ColumnDefinitions[column].Width = new GridLength(1.0, GridUnitType.Auto);
				this.tabGrid.ColumnDefinitions[0].Width = new GridLength(1.0, GridUnitType.Star);
				this.tabGrid.ColumnDefinitions[5].Width = new GridLength(1.0, GridUnitType.Star);
			}
			else
			{
				this.tabGrid.ColumnDefinitions[column].Width = new GridLength(1.0, GridUnitType.Star);
				this.tabGrid.ColumnDefinitions[0].Width = new GridLength(0.0, GridUnitType.Pixel);
				this.tabGrid.ColumnDefinitions[5].Width = new GridLength(0.0, GridUnitType.Pixel);
			}
			column = Grid.GetColumn(this);
			((Grid)base.Parent).ColumnDefinitions[column].MaxWidth = num;
		}

		// Token: 0x060014D7 RID: 5335 RVA: 0x0000E3B1 File Offset: 0x0000C5B1
		private void mAppTabNotificationCountBorder_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			this.SetMaxWidth(0.0);
		}

		// Token: 0x04000D1A RID: 3354
		private int animationTime = 150;

		// Token: 0x04000D1B RID: 3355
		private MainWindow mMainWindow;

		// Token: 0x04000D1D RID: 3357
		private static bool mIsSwipeDirectonLeft = true;

		// Token: 0x04000D1E RID: 3358
		private TranslateTransform mTranslateTransform = new TranslateTransform();

		// Token: 0x04000D1F RID: 3359
		private BrowserControl mAssociatedUserControl;

		// Token: 0x04000D20 RID: 3360
		private bool mIsSelected;
	}
}
