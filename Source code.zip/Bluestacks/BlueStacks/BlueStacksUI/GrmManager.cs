﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200006A RID: 106
	internal class GrmManager
	{
		// Token: 0x0600044B RID: 1099 RVA: 0x00004EC3 File Offset: 0x000030C3
		internal static void UpdateGrmAsync(IEnumerable<string> listOfPackages = null)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				if (AppRequirementsParser.Instance.Requirements == null)
				{
					AppRequirementsParser.Instance.PopulateRequirementsFromFile();
				}
				GrmManager.GetGrmFromCloud(listOfPackages);
			});
		}

		// Token: 0x0600044C RID: 1100 RVA: 0x0001D464 File Offset: 0x0001B664
		private static void GetGrmFromCloud(IEnumerable<string> listOfPackages = null)
		{
			try
			{
				if (listOfPackages != null && listOfPackages.Any<string>())
				{
					List<string> list = new List<string>();
					foreach (string vmName in RegistryManager.Instance.VmList)
					{
						list = list.Union(JsonParser.GetInstalledAppsList(vmName)).ToList<string>();
					}
					if (!listOfPackages.Intersect(list).Any<string>())
					{
						return;
					}
				}
				JObject jobject = JObject.Parse(HTTPUtils.SendRequestToCloud("grm/files", null, "Android", 0, null, false, 1, 0, false));
				if ((int)jobject["code"] == 200 && jobject["data"].Value<bool>("success"))
				{
					string url = jobject["data"]["files"].Value<string>("translations_file");
					string fullJson = BstHttpClient.Get(jobject["data"]["files"].Value<string>("config_file"), null, false, Strings.CurrentDefaultVmName, 0, 1, 0, false);
					string translationJson = BstHttpClient.Get(url, null, false, Strings.CurrentDefaultVmName, 0, 1, 0, false);
					AppRequirementsParser.Instance.UpdateOverwriteRequirements(fullJson, translationJson);
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Error Getting Grm json " + ex.ToString());
			}
		}
	}
}
