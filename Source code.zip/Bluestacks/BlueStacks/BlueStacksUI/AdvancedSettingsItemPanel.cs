﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Effects;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000131 RID: 305
	public class AdvancedSettingsItemPanel : UserControl, IComponentConnector
	{
		// Token: 0x17000204 RID: 516
		// (get) Token: 0x06000C0E RID: 3086 RVA: 0x0000952E File Offset: 0x0000772E
		// (set) Token: 0x06000C0F RID: 3087 RVA: 0x00009536 File Offset: 0x00007736
		public EventHandler Tap
		{
			get
			{
				return this.mTap;
			}
			set
			{
				this.mTap = value;
			}
		}

		// Token: 0x17000205 RID: 517
		// (get) Token: 0x06000C10 RID: 3088 RVA: 0x0000953F File Offset: 0x0000773F
		// (set) Token: 0x06000C11 RID: 3089 RVA: 0x00009547 File Offset: 0x00007747
		public EventHandler MouseDragStart
		{
			get
			{
				return this.mMouseDragStart;
			}
			set
			{
				this.mMouseDragStart = value;
			}
		}

		// Token: 0x17000206 RID: 518
		// (get) Token: 0x06000C12 RID: 3090 RVA: 0x00009550 File Offset: 0x00007750
		// (set) Token: 0x06000C13 RID: 3091 RVA: 0x0004C07C File Offset: 0x0004A27C
		public KeyActionType ActionType
		{
			get
			{
				return this.mActionType;
			}
			set
			{
				this.mActionType = value;
				this.mImage.ImageName = this.mActionType.ToString() + "_sidebar";
				BlueStacksUIBinding.Bind(this.mActionHeader, Constants.ImapLocaleStringsConstant + this.mActionType.ToString() + "_Header_Edit_UI", "");
			}
		}

		// Token: 0x06000C14 RID: 3092 RVA: 0x00009558 File Offset: 0x00007758
		public AdvancedSettingsItemPanel()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000C15 RID: 3093 RVA: 0x0004C0E8 File Offset: 0x0004A2E8
		private void Image_MouseEnter(object sender, MouseEventArgs e)
		{
			base.Cursor = Cursors.Hand;
			this.mDragImage.Visibility = Visibility.Visible;
			BlueStacksUIBinding.BindColor(this.mBorder, Control.BorderBrushProperty, "AdvancedGameControlHeaderBackgroundColor");
			this.mBorder.Effect = new DropShadowEffect
			{
				Direction = 270.0,
				ShadowDepth = 3.0,
				BlurRadius = 12.0,
				Opacity = 0.75,
				Color = ((SolidColorBrush)this.mBorder.Background).Color
			};
		}

		// Token: 0x06000C16 RID: 3094 RVA: 0x0004C188 File Offset: 0x0004A388
		private void Image_MouseLeave(object sender, MouseEventArgs e)
		{
			if (KMManager.sDragCanvasElement == null)
			{
				base.Cursor = Cursors.Arrow;
			}
			this.mDragImage.Visibility = Visibility.Hidden;
			BlueStacksUIBinding.BindColor(this.mBorder, Control.BorderBrushProperty, "AdvancedSettingsItemPanelBorder");
			this.mBorder.Effect = null;
		}

		// Token: 0x06000C17 RID: 3095 RVA: 0x00009566 File Offset: 0x00007766
		private void Image_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			this.mousePressedPosition = new Point?(e.GetPosition(this));
		}

		// Token: 0x06000C18 RID: 3096 RVA: 0x0004C1D4 File Offset: 0x0004A3D4
		private void Image_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			this.mouseReleasedPosition = new Point?(e.GetPosition(this));
			if (this.mousePressedPosition.Equals(this.mouseReleasedPosition))
			{
				EventHandler tap = this.Tap;
				if (tap != null)
				{
					tap(this, null);
				}
			}
			else
			{
				KMManager.ClearElement();
			}
			this.ReatchedMouseMove();
		}

		// Token: 0x06000C19 RID: 3097 RVA: 0x0000957A File Offset: 0x0000777A
		private void OnTimedElapsed(object sender, ElapsedEventArgs e)
		{
			if (!this.mousePressedPosition.Equals(this.mouseReleasedPosition))
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					EventHandler mouseDragStart = this.MouseDragStart;
					if (mouseDragStart == null)
					{
						return;
					}
					mouseDragStart(this, null);
				}), new object[0]);
			}
		}

		// Token: 0x06000C1A RID: 3098 RVA: 0x0004C234 File Offset: 0x0004A434
		private void Image_MouseMove(object sender, MouseEventArgs e)
		{
			if (this.mousePressedPosition != null && !this.mousePressedPosition.Equals(this.mouseReleasedPosition))
			{
				base.MouseMove -= this.Image_MouseMove;
				EventHandler mouseDragStart = this.MouseDragStart;
				if (mouseDragStart == null)
				{
					return;
				}
				mouseDragStart(this, null);
			}
		}

		// Token: 0x06000C1B RID: 3099 RVA: 0x000095B8 File Offset: 0x000077B8
		public void ReatchedMouseMove()
		{
			this.mousePressedPosition = null;
			base.MouseMove -= this.Image_MouseMove;
			base.MouseMove += this.Image_MouseMove;
		}

		// Token: 0x06000C1C RID: 3100 RVA: 0x0004C290 File Offset: 0x0004A490
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/advancedsettingsitempanel.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000C1D RID: 3101 RVA: 0x0004C2C0 File Offset: 0x0004A4C0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((AdvancedSettingsItemPanel)target).MouseEnter += this.Image_MouseEnter;
				((AdvancedSettingsItemPanel)target).MouseLeave += this.Image_MouseLeave;
				((AdvancedSettingsItemPanel)target).PreviewMouseDown += this.Image_PreviewMouseDown;
				((AdvancedSettingsItemPanel)target).MouseMove += this.Image_MouseMove;
				((AdvancedSettingsItemPanel)target).PreviewMouseUp += this.Image_PreviewMouseUp;
				return;
			case 2:
				this.mBorder = (Border)target;
				return;
			case 3:
				this.mDragImage = (CustomPictureBox)target;
				return;
			case 4:
				this.mImage = (CustomPictureBox)target;
				return;
			case 5:
				this.mActionHeader = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000810 RID: 2064
		private EventHandler mTap;

		// Token: 0x04000811 RID: 2065
		private EventHandler mMouseDragStart;

		// Token: 0x04000812 RID: 2066
		private KeyActionType mActionType;

		// Token: 0x04000813 RID: 2067
		private Point? mousePressedPosition;

		// Token: 0x04000814 RID: 2068
		private Point? mouseReleasedPosition;

		// Token: 0x04000815 RID: 2069
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mBorder;

		// Token: 0x04000816 RID: 2070
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mDragImage;

		// Token: 0x04000817 RID: 2071
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mImage;

		// Token: 0x04000818 RID: 2072
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mActionHeader;

		// Token: 0x04000819 RID: 2073
		private bool _contentLoaded;
	}
}
