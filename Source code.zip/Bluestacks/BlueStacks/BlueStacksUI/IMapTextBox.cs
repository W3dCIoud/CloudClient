﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000049 RID: 73
	public class IMapTextBox : XTextBox, IComponentConnector
	{
		// Token: 0x06000359 RID: 857 RVA: 0x0000440D File Offset: 0x0000260D
		public IMapTextBox()
		{
			this.InitializeComponent();
			InputMethod.SetIsInputMethodEnabled(this, false);
			base.ClearValue(IMapTextBox.IMActionItemsProperty);
			base.Loaded += this.IMapTextBox_Loaded;
		}

		// Token: 0x17000138 RID: 312
		// (get) Token: 0x0600035A RID: 858 RVA: 0x0000444A File Offset: 0x0000264A
		// (set) Token: 0x0600035B RID: 859 RVA: 0x0000445C File Offset: 0x0000265C
		public bool IsKeyBoardInFocus
		{
			get
			{
				return (bool)base.GetValue(IMapTextBox.IsKeyBoardInFocusProperty);
			}
			set
			{
				base.SetValue(IMapTextBox.IsKeyBoardInFocusProperty, value);
			}
		}

		// Token: 0x0600035C RID: 860 RVA: 0x00018850 File Offset: 0x00016A50
		private static void OnKeyBoardInFocusChanged(DependencyObject sender, DependencyPropertyChangedEventArgs args)
		{
			IMapTextBox mapTextBox = sender as IMapTextBox;
			bool flag;
			if (mapTextBox != null && bool.TryParse(args.NewValue.ToString(), out flag))
			{
				KMManager.CurrentIMapTextBox = (flag ? mapTextBox : null);
			}
		}

		// Token: 0x17000139 RID: 313
		// (get) Token: 0x0600035D RID: 861 RVA: 0x0000446F File Offset: 0x0000266F
		// (set) Token: 0x0600035E RID: 862 RVA: 0x00004481 File Offset: 0x00002681
		public Type PropertyType
		{
			get
			{
				return (Type)base.GetValue(IMapTextBox.PropertyTypeProperty);
			}
			set
			{
				base.SetValue(IMapTextBox.PropertyTypeProperty, value);
			}
		}

		// Token: 0x1700013A RID: 314
		// (get) Token: 0x0600035F RID: 863 RVA: 0x0000448F File Offset: 0x0000268F
		// (set) Token: 0x06000360 RID: 864 RVA: 0x000044A1 File Offset: 0x000026A1
		public KeyActionType ActionType
		{
			get
			{
				return (KeyActionType)base.GetValue(IMapTextBox.ActionTypeProperty);
			}
			set
			{
				base.SetValue(IMapTextBox.ActionTypeProperty, value);
			}
		}

		// Token: 0x1700013B RID: 315
		// (get) Token: 0x06000361 RID: 865 RVA: 0x000044B4 File Offset: 0x000026B4
		// (set) Token: 0x06000362 RID: 866 RVA: 0x000044C6 File Offset: 0x000026C6
		public ObservableCollection<IMActionItem> IMActionItems
		{
			get
			{
				return (ObservableCollection<IMActionItem>)base.GetValue(IMapTextBox.IMActionItemsProperty);
			}
			set
			{
				if (value == null)
				{
					base.ClearValue(IMapTextBox.IMActionItemsProperty);
					return;
				}
				base.SetValue(IMapTextBox.IMActionItemsProperty, value);
			}
		}

		// Token: 0x06000363 RID: 867 RVA: 0x00018888 File Offset: 0x00016A88
		private void IMapTextBox_Loaded(object sender, RoutedEventArgs e)
		{
			if (base.TextBlock != null)
			{
				base.TextBlock.TextTrimming = TextTrimming.None;
				base.TextBlock.TextWrapping = TextWrapping.Wrap;
			}
			if (!string.IsNullOrEmpty(base.Tag.ToString()))
			{
				string[] array = base.Tag.ToString().Split(new char[]
				{
					'+'
				});
				if (array.Length != 0)
				{
					if (this.IMActionItems[0].ActionItem.Contains("_alt1", StringComparison.InvariantCultureIgnoreCase) || this.IMActionItems[0].ActionItem.Contains("Gamepad", StringComparison.InvariantCultureIgnoreCase))
					{
						base.Text = string.Join(" + ", (from x in array.ToList<string>()
						select LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(x.Trim()))).ToArray<string>());
						return;
					}
					base.Text = string.Join(" + ", (from x in array.ToList<string>()
					select LocaleStrings.GetLocalizedString(KMManager.GetStringsToShowInUI(x.Trim()))).ToArray<string>());
				}
			}
		}

		// Token: 0x06000364 RID: 868 RVA: 0x000189A8 File Offset: 0x00016BA8
		protected override void OnGotFocus(RoutedEventArgs e)
		{
			base.OnGotFocus(e);
			KMManager.CurrentIMapTextBox = this;
			KMManager.pressedGamepadKeyList.Clear();
			KMManager.CallGamepadHandler(BlueStacksUIUtils.LastActivatedWindow, "true");
			base.TextChanged -= this.IMapTextBox_TextChanged;
			base.TextChanged += this.IMapTextBox_TextChanged;
			base.PreviewMouseWheel -= this.IMapTextBox_PreviewMouseWheel;
			base.PreviewMouseWheel += this.IMapTextBox_PreviewMouseWheel;
			this.SetCaretIndex();
		}

		// Token: 0x06000365 RID: 869 RVA: 0x00018A2C File Offset: 0x00016C2C
		private void IMapTextBox_PreviewMouseWheel(object sender, MouseWheelEventArgs args)
		{
			if (args != null && args.Delta != 0 && this.IMActionItems != null && this.IMActionItems.Any<IMActionItem>())
			{
				foreach (IMActionItem imactionItem in this.IMActionItems)
				{
					if (imactionItem.ActionItem.StartsWith("Key", StringComparison.InvariantCulture))
					{
						base.Tag = ((args.Delta < 0) ? "MouseWheelDown" : "MouseWheelUp");
						this.SetValueHandling(imactionItem);
						BlueStacksUIBinding.Bind(this, Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(base.Tag.ToString()));
					}
					if (this.PropertyType.Equals(typeof(bool)))
					{
						bool flag = !Convert.ToBoolean(imactionItem.IMAction[imactionItem.ActionItem], CultureInfo.InvariantCulture);
						base.Tag = flag;
						IMapTextBox.Setvalue(imactionItem, flag.ToString(CultureInfo.InvariantCulture));
						string imapLocaleStringsConstant = Constants.ImapLocaleStringsConstant;
						object tag = base.Tag;
						BlueStacksUIBinding.Bind(this, imapLocaleStringsConstant + ((tag != null) ? tag.ToString() : null));
						args.Handled = true;
					}
				}
				args.Handled = true;
			}
			this.SetCaretIndex();
		}

		// Token: 0x06000366 RID: 870 RVA: 0x00018B84 File Offset: 0x00016D84
		private void IMapTextBox_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (this.IMActionItems != null && this.IMActionItems.Any<IMActionItem>())
			{
				foreach (IMActionItem valueHandling in this.IMActionItems)
				{
					this.SetValueHandling(valueHandling);
				}
				KMManager.CheckAndCreateNewScheme();
			}
			this.SetCaretIndex();
		}

		// Token: 0x06000367 RID: 871 RVA: 0x00018BF4 File Offset: 0x00016DF4
		protected override void OnLostFocus(RoutedEventArgs e)
		{
			base.TextChanged -= this.IMapTextBox_TextChanged;
			base.PreviewMouseWheel -= this.IMapTextBox_PreviewMouseWheel;
			KMManager.CurrentIMapTextBox = null;
			base.InputTextValidity = TextValidityOptions.Success;
			ToolTip toolTip = base.ToolTip as ToolTip;
			if (toolTip != null)
			{
				toolTip.IsOpen = false;
			}
			KMManager.CurrentIMapTextBox = null;
			base.OnLostFocus(e);
		}

		// Token: 0x06000368 RID: 872 RVA: 0x00018C58 File Offset: 0x00016E58
		protected override void OnPreviewKeyDown(KeyEventArgs args)
		{
			if (args != null && args.Key != Key.Escape)
			{
				if (this.IMActionItems != null && this.IMActionItems.Any<IMActionItem>())
				{
					foreach (IMActionItem imactionItem in this.IMActionItems)
					{
						if (imactionItem.ActionItem.StartsWith("Key", StringComparison.InvariantCulture))
						{
							if (imactionItem.IMAction.Type == KeyActionType.Tap || imactionItem.IMAction.Type == KeyActionType.TapRepeat || imactionItem.IMAction.Type == KeyActionType.Script)
							{
								if (args.Key == Key.Back || args.SystemKey == Key.Back)
								{
									base.Tag = string.Empty;
									string imapLocaleStringsConstant = Constants.ImapLocaleStringsConstant;
									object tag = base.Tag;
									BlueStacksUIBinding.Bind(this, imapLocaleStringsConstant + ((tag != null) ? tag.ToString() : null));
								}
								else if (IMAPKeys.mDictKeys.ContainsKey(args.SystemKey) || IMAPKeys.mDictKeys.ContainsKey(args.Key))
								{
									if (args.SystemKey == Key.LeftAlt || args.SystemKey == Key.RightAlt || args.SystemKey == Key.F10)
									{
										this.mKeyList.AddIfNotContain(args.SystemKey);
									}
									else if (args.KeyboardDevice.Modifiers != ModifierKeys.None)
									{
										if (args.KeyboardDevice.Modifiers == ModifierKeys.Alt)
										{
											this.mKeyList.AddIfNotContain(args.SystemKey);
										}
										else if (args.KeyboardDevice.Modifiers == (ModifierKeys.Alt | ModifierKeys.Shift))
										{
											this.mKeyList.AddIfNotContain(args.SystemKey);
										}
										else
										{
											this.mKeyList.AddIfNotContain(args.Key);
										}
									}
									else
									{
										this.mKeyList.AddIfNotContain(args.Key);
									}
								}
							}
							else
							{
								if (args.Key == Key.System && IMAPKeys.mDictKeys.ContainsKey(args.SystemKey))
								{
									base.Tag = IMAPKeys.GetStringForFile(args.SystemKey);
									BlueStacksUIBinding.Bind(this, Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(args.SystemKey));
								}
								else if (IMAPKeys.mDictKeys.ContainsKey(args.Key))
								{
									base.Tag = IMAPKeys.GetStringForFile(args.Key);
									BlueStacksUIBinding.Bind(this, Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(args.Key));
								}
								else if (args.Key == Key.Back)
								{
									base.Tag = string.Empty;
									BlueStacksUIBinding.Bind(this, Constants.ImapLocaleStringsConstant + string.Empty);
								}
								args.Handled = true;
							}
						}
						if (string.Equals(imactionItem.ActionItem, "GamepadStick", StringComparison.InvariantCulture))
						{
							if (args.Key == Key.Back || args.Key == Key.Delete)
							{
								base.Tag = string.Empty;
								BlueStacksUIBinding.Bind(this, Constants.ImapLocaleStringsConstant + string.Empty);
							}
							args.Handled = true;
						}
						if (this.PropertyType.Equals(typeof(bool)))
						{
							bool flag = !Convert.ToBoolean(imactionItem.IMAction[imactionItem.ActionItem], CultureInfo.InvariantCulture);
							base.Tag = flag;
							IMapTextBox.Setvalue(imactionItem, flag.ToString(CultureInfo.InvariantCulture));
							string imapLocaleStringsConstant2 = Constants.ImapLocaleStringsConstant;
							object tag2 = base.Tag;
							BlueStacksUIBinding.Bind(this, imapLocaleStringsConstant2 + ((tag2 != null) ? tag2.ToString() : null));
							args.Handled = true;
						}
					}
				}
				base.Focus();
				args.Handled = true;
			}
			if (this.PropertyType.Equals(typeof(bool)))
			{
				KMManager.CheckAndCreateNewScheme();
			}
			this.SetCaretIndex();
			base.OnPreviewKeyDown(args);
		}

		// Token: 0x06000369 RID: 873 RVA: 0x00019004 File Offset: 0x00017204
		protected override void OnPreviewMouseDown(MouseButtonEventArgs args)
		{
			if (args != null)
			{
				if (this.IMActionItems != null && this.IMActionItems.Any<IMActionItem>())
				{
					foreach (IMActionItem imactionItem in this.IMActionItems)
					{
						if (imactionItem.ActionItem.StartsWith("Key", StringComparison.InvariantCulture))
						{
							if (args.MiddleButton == MouseButtonState.Pressed)
							{
								args.Handled = true;
								base.Tag = "MouseMButton";
								BlueStacksUIBinding.Bind(this, Constants.ImapLocaleStringsConstant + "MouseMButton");
							}
							else if (args.RightButton == MouseButtonState.Pressed)
							{
								args.Handled = true;
								base.Tag = "MouseRButton";
								BlueStacksUIBinding.Bind(this, Constants.ImapLocaleStringsConstant + "MouseRButton");
							}
							else if (args.XButton1 == MouseButtonState.Pressed)
							{
								args.Handled = true;
								base.Tag = "MouseXButton1";
								BlueStacksUIBinding.Bind(this, Constants.ImapLocaleStringsConstant + "MouseXButton1");
							}
							else if (args.XButton2 == MouseButtonState.Pressed)
							{
								args.Handled = true;
								base.Tag = "MouseXButton2";
								BlueStacksUIBinding.Bind(this, Constants.ImapLocaleStringsConstant + "MouseXButton2");
							}
						}
						if (this.PropertyType.Equals(typeof(bool)))
						{
							bool flag = !Convert.ToBoolean(imactionItem.IMAction[imactionItem.ActionItem], CultureInfo.InvariantCulture);
							base.Tag = flag;
							IMapTextBox.Setvalue(imactionItem, flag.ToString(CultureInfo.InvariantCulture));
							string imapLocaleStringsConstant = Constants.ImapLocaleStringsConstant;
							object tag = base.Tag;
							BlueStacksUIBinding.Bind(this, imapLocaleStringsConstant + ((tag != null) ? tag.ToString() : null));
						}
					}
				}
				if (args.LeftButton == MouseButtonState.Pressed && base.IsKeyboardFocusWithin)
				{
					args.Handled = true;
				}
				base.Focus();
				args.Handled = true;
			}
			if (this.PropertyType.Equals(typeof(bool)))
			{
				KMManager.CheckAndCreateNewScheme();
			}
			this.SetCaretIndex();
			base.OnPreviewMouseDown(args);
		}

		// Token: 0x0600036A RID: 874 RVA: 0x00019224 File Offset: 0x00017424
		protected override void OnKeyUp(KeyEventArgs args)
		{
			if (args != null)
			{
				if (this.IMActionItems != null && this.IMActionItems.Any<IMActionItem>())
				{
					foreach (IMActionItem imactionItem in this.IMActionItems)
					{
						if (imactionItem.IMAction.Type == KeyActionType.Tap || imactionItem.IMAction.Type == KeyActionType.TapRepeat || imactionItem.IMAction.Type == KeyActionType.Script)
						{
							if (this.mKeyList.Count >= 2)
							{
								string text = IMAPKeys.GetStringForUI(this.mKeyList.ElementAt(this.mKeyList.Count - 2)) + " + " + IMAPKeys.GetStringForUI(this.mKeyList.ElementAt(this.mKeyList.Count - 1));
								string tag = IMAPKeys.GetStringForFile(this.mKeyList.ElementAt(this.mKeyList.Count - 2)) + " + " + IMAPKeys.GetStringForFile(this.mKeyList.ElementAt(this.mKeyList.Count - 1));
								base.Tag = tag;
								base.Text = text;
								this.SetValueHandling(imactionItem);
							}
							else if (this.mKeyList.Count == 1)
							{
								string text = IMAPKeys.GetStringForUI(this.mKeyList.ElementAt(0));
								string tag = IMAPKeys.GetStringForFile(this.mKeyList.ElementAt(0));
								base.Tag = tag;
								base.Text = text;
								this.SetValueHandling(imactionItem);
							}
							this.mKeyList.Clear();
						}
					}
				}
				args.Handled = true;
			}
			if (this.PropertyType.Equals(typeof(bool)))
			{
				KMManager.CheckAndCreateNewScheme();
			}
			this.SetCaretIndex();
			base.OnKeyUp(args);
		}

		// Token: 0x0600036B RID: 875 RVA: 0x00019400 File Offset: 0x00017600
		private void SetValueHandling(IMActionItem item)
		{
			string text = item.IMAction[item.ActionItem].ToString();
			if (base.IsLoaded)
			{
				KMManager.CallGamepadHandler(BlueStacksUIUtils.LastActivatedWindow, "true");
			}
			if (this.PropertyType.Equals(typeof(double)))
			{
				double num;
				if (double.TryParse(base.Text, out num))
				{
					text = base.Text;
				}
				else if (!string.IsNullOrEmpty(base.Text))
				{
					base.Text = text;
				}
			}
			else if (this.PropertyType.Equals(typeof(int)))
			{
				int num2;
				if (int.TryParse(base.Text, out num2))
				{
					text = base.Text;
				}
				else if (!string.IsNullOrEmpty(base.Text))
				{
					base.Text = text;
				}
			}
			else if (this.PropertyType.Equals(typeof(bool)))
			{
				text = base.Tag.ToString();
			}
			else
			{
				text = base.Tag.ToString();
			}
			IMapTextBox.Setvalue(item, text);
		}

		// Token: 0x0600036C RID: 876 RVA: 0x00019500 File Offset: 0x00017700
		internal static void Setvalue(IMActionItem item, string value)
		{
			if (!string.Equals(item.IMAction[item.ActionItem].ToString(), value, StringComparison.InvariantCulture))
			{
				item.IMAction[item.ActionItem] = value;
			}
			Logger.Debug("GUIDANCE: " + item.IMAction.Type.ToString());
		}

		// Token: 0x0600036D RID: 877 RVA: 0x000044E3 File Offset: 0x000026E3
		private void SetCaretIndex()
		{
			if (!string.IsNullOrEmpty(base.Text))
			{
				base.CaretIndex = base.Text.Length;
			}
		}

		// Token: 0x0600036E RID: 878 RVA: 0x00019568 File Offset: 0x00017768
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/guidancemodels/imaptextbox.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600036F RID: 879 RVA: 0x00004503 File Offset: 0x00002703
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mTextBox = (IMapTextBox)target;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x040001D2 RID: 466
		private List<Key> mKeyList = new List<Key>();

		// Token: 0x040001D3 RID: 467
		public static readonly DependencyProperty IsKeyBoardInFocusProperty = DependencyProperty.Register("IsKeyBoardInFocus", typeof(bool), typeof(IMapTextBox), new PropertyMetadata(false, new PropertyChangedCallback(IMapTextBox.OnKeyBoardInFocusChanged)));

		// Token: 0x040001D4 RID: 468
		public static readonly DependencyProperty PropertyTypeProperty = DependencyProperty.Register("PropertyType", typeof(Type), typeof(IMapTextBox), new PropertyMetadata());

		// Token: 0x040001D5 RID: 469
		public static readonly DependencyProperty ActionTypeProperty = DependencyProperty.Register("ActionType", typeof(KeyActionType), typeof(IMapTextBox), new PropertyMetadata());

		// Token: 0x040001D6 RID: 470
		public static readonly DependencyProperty IMActionItemsProperty = DependencyProperty.Register("IMActionItems", typeof(ObservableCollection<IMActionItem>), typeof(IMapTextBox), new PropertyMetadata());

		// Token: 0x040001D7 RID: 471
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal IMapTextBox mTextBox;

		// Token: 0x040001D8 RID: 472
		private bool _contentLoaded;
	}
}
