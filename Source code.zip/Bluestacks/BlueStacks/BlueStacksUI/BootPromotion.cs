﻿using System;
using System.IO;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000089 RID: 137
	[Serializable]
	public class BootPromotion
	{
		// Token: 0x170001A5 RID: 421
		// (get) Token: 0x0600054F RID: 1359 RVA: 0x00005843 File Offset: 0x00003A43
		// (set) Token: 0x06000550 RID: 1360 RVA: 0x0000584B File Offset: 0x00003A4B
		public int Order { get; set; }

		// Token: 0x170001A6 RID: 422
		// (get) Token: 0x06000551 RID: 1361 RVA: 0x00005854 File Offset: 0x00003A54
		// (set) Token: 0x06000552 RID: 1362 RVA: 0x0000585C File Offset: 0x00003A5C
		public SerializableDictionary<string, string> ExtraPayload { get; set; } = new SerializableDictionary<string, string>();

		// Token: 0x170001A7 RID: 423
		// (get) Token: 0x06000553 RID: 1363 RVA: 0x00005865 File Offset: 0x00003A65
		// (set) Token: 0x06000554 RID: 1364 RVA: 0x0000586D File Offset: 0x00003A6D
		public string Id { get; set; }

		// Token: 0x170001A8 RID: 424
		// (get) Token: 0x06000555 RID: 1365 RVA: 0x00005876 File Offset: 0x00003A76
		// (set) Token: 0x06000556 RID: 1366 RVA: 0x0000587E File Offset: 0x00003A7E
		public string ButtonText { get; set; } = string.Empty;

		// Token: 0x170001A9 RID: 425
		// (get) Token: 0x06000557 RID: 1367 RVA: 0x00005887 File Offset: 0x00003A87
		// (set) Token: 0x06000558 RID: 1368 RVA: 0x0000588F File Offset: 0x00003A8F
		public string ImagePath { get; set; } = string.Empty;

		// Token: 0x170001AA RID: 426
		// (get) Token: 0x06000559 RID: 1369 RVA: 0x00005898 File Offset: 0x00003A98
		// (set) Token: 0x0600055A RID: 1370 RVA: 0x000058A0 File Offset: 0x00003AA0
		public string ThemeEnabled { get; set; } = string.Empty;

		// Token: 0x170001AB RID: 427
		// (get) Token: 0x0600055B RID: 1371 RVA: 0x000058A9 File Offset: 0x00003AA9
		// (set) Token: 0x0600055C RID: 1372 RVA: 0x000058B1 File Offset: 0x00003AB1
		public string ThemeName { get; set; } = string.Empty;

		// Token: 0x170001AC RID: 428
		// (get) Token: 0x0600055D RID: 1373 RVA: 0x000058BA File Offset: 0x00003ABA
		// (set) Token: 0x0600055E RID: 1374 RVA: 0x000058C2 File Offset: 0x00003AC2
		public string PromoBtnClickStatusText { get; set; } = string.Empty;

		// Token: 0x0600055F RID: 1375 RVA: 0x00020344 File Offset: 0x0001E544
		internal void DeleteFile()
		{
			try
			{
				File.Delete(this.ImagePath);
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't delete bootpromo file: " + this.ImagePath);
				Logger.Error(ex.ToString());
			}
		}
	}
}
