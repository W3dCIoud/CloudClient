﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200014F RID: 335
	public class GroupByGrid : DataGridView
	{
		// Token: 0x06000D10 RID: 3344 RVA: 0x00009DA3 File Offset: 0x00007FA3
		protected override void OnCellFormatting(DataGridViewCellFormattingEventArgs args)
		{
			base.OnCellFormatting(args);
			if (args != null)
			{
				if (args.RowIndex == 0)
				{
					return;
				}
				if (this.IsRepeatedCellValue(args.RowIndex, args.ColumnIndex))
				{
					args.Value = string.Empty;
					args.FormattingApplied = true;
				}
			}
		}

		// Token: 0x06000D11 RID: 3345 RVA: 0x00056964 File Offset: 0x00054B64
		private bool IsRepeatedCellValue(int rowIndex, int colIndex)
		{
			DataGridViewCell dataGridViewCell = base.Rows[rowIndex].Cells[colIndex];
			DataGridViewCell dataGridViewCell2 = base.Rows[rowIndex - 1].Cells[colIndex];
			return this.ColumnsToBeGrouped.Contains(colIndex) && (dataGridViewCell.Value == dataGridViewCell2.Value || (dataGridViewCell.Value != null && dataGridViewCell2.Value != null && dataGridViewCell.Value.ToString() == dataGridViewCell2.Value.ToString()));
		}

		// Token: 0x06000D12 RID: 3346 RVA: 0x000569F4 File Offset: 0x00054BF4
		protected override void OnCellPainting(DataGridViewCellPaintingEventArgs args)
		{
			base.OnCellPainting(args);
			if (args != null)
			{
				args.AdvancedBorderStyle.Bottom = DataGridViewAdvancedCellBorderStyle.None;
				if (args.RowIndex < 1 || args.ColumnIndex < 0)
				{
					return;
				}
				if (this.IsRepeatedCellValue(args.RowIndex, args.ColumnIndex))
				{
					args.AdvancedBorderStyle.Top = DataGridViewAdvancedCellBorderStyle.None;
					return;
				}
				args.AdvancedBorderStyle.Top = base.AdvancedCellBorderStyle.Top;
			}
		}

		// Token: 0x0400090F RID: 2319
		internal List<int> ColumnsToBeGrouped = new List<int>();
	}
}
