﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000C2 RID: 194
	public class Gl3CustomWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x060007FD RID: 2045 RVA: 0x0000721F File Offset: 0x0000541F
		public Gl3CustomWindow(MainWindow parentWindow)
		{
			this.mParentWindow = parentWindow;
			this.InitializeComponent();
		}

		// Token: 0x060007FE RID: 2046 RVA: 0x0002F1B8 File Offset: 0x0002D3B8
		private void mGetButton_Click(object sender, RoutedEventArgs e)
		{
			Logger.Info("Clicked Restart to opengl button");
			if (RegistryManager.Instance.GLES3 && this.mParentWindow.EngineInstanceRegistry.GlRenderMode != 1)
			{
				this.mParentWindow.EngineInstanceRegistry.GlRenderMode = 1;
				BlueStacksUIUtils.RestartInstance(this.mParentWindow.mVmName);
				return;
			}
			base.Close();
		}

		// Token: 0x060007FF RID: 2047 RVA: 0x00007234 File Offset: 0x00005434
		private void Close_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked Gl3 custom window close button");
			base.Close();
		}

		// Token: 0x06000800 RID: 2048 RVA: 0x0002F218 File Offset: 0x0002D418
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/gl3customwindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000801 RID: 2049 RVA: 0x0002F248 File Offset: 0x0002D448
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				this.mParentGrid = (Grid)target;
				return;
			case 3:
				this.mTextBlockGrid = (Grid)target;
				return;
			case 4:
				this.mCustomMessageBoxCloseButton = (CustomPictureBox)target;
				this.mCustomMessageBoxCloseButton.PreviewMouseLeftButtonUp += this.Close_PreviewMouseLeftButtonUp;
				return;
			case 5:
				this.mTitleText = (TextBlock)target;
				return;
			case 6:
				this.mTitleIcon = (CustomPictureBox)target;
				return;
			case 7:
				this.mBodyTextBlock = (TextBlock)target;
				return;
			case 8:
				this.mHintGrid = (Grid)target;
				return;
			case 9:
				this.mHintTextBlock = (TextBlock)target;
				return;
			case 10:
				this.mHintGrid1 = (Grid)target;
				return;
			case 11:
				this.mHintTextBlock1 = (TextBlock)target;
				return;
			case 12:
				this.mButton = (CustomButton)target;
				this.mButton.Click += this.mGetButton_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040004B9 RID: 1209
		private MainWindow mParentWindow;

		// Token: 0x040004BA RID: 1210
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder;

		// Token: 0x040004BB RID: 1211
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mParentGrid;

		// Token: 0x040004BC RID: 1212
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mTextBlockGrid;

		// Token: 0x040004BD RID: 1213
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCustomMessageBoxCloseButton;

		// Token: 0x040004BE RID: 1214
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mTitleText;

		// Token: 0x040004BF RID: 1215
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mTitleIcon;

		// Token: 0x040004C0 RID: 1216
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mBodyTextBlock;

		// Token: 0x040004C1 RID: 1217
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mHintGrid;

		// Token: 0x040004C2 RID: 1218
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mHintTextBlock;

		// Token: 0x040004C3 RID: 1219
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mHintGrid1;

		// Token: 0x040004C4 RID: 1220
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mHintTextBlock1;

		// Token: 0x040004C5 RID: 1221
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mButton;

		// Token: 0x040004C6 RID: 1222
		private bool _contentLoaded;
	}
}
