﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200006C RID: 108
	internal sealed class GuidanceCloudInfoManager
	{
		// Token: 0x1700015D RID: 349
		// (get) Token: 0x06000450 RID: 1104 RVA: 0x00004F05 File Offset: 0x00003105
		private static string BstGuidanceFilePath
		{
			get
			{
				return Path.Combine(RegistryStrings.PromotionDirectory, "bst_guidance");
			}
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x00004F16 File Offset: 0x00003116
		private GuidanceCloudInfoManager()
		{
		}

		// Token: 0x1700015E RID: 350
		// (get) Token: 0x06000452 RID: 1106 RVA: 0x0001D5BC File Offset: 0x0001B7BC
		// (set) Token: 0x06000453 RID: 1107 RVA: 0x00004F29 File Offset: 0x00003129
		public static GuidanceCloudInfoManager Instance
		{
			get
			{
				if (GuidanceCloudInfoManager.sInstance == null)
				{
					object obj = GuidanceCloudInfoManager.sLock;
					lock (obj)
					{
						if (GuidanceCloudInfoManager.sInstance == null)
						{
							GuidanceCloudInfoManager.sInstance = new GuidanceCloudInfoManager();
						}
					}
				}
				return GuidanceCloudInfoManager.sInstance;
			}
			set
			{
				GuidanceCloudInfoManager.sInstance = value;
			}
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x0001D60C File Offset: 0x0001B80C
		private static JToken GetGuidanceCloudInfoData()
		{
			JToken result = null;
			try
			{
				string urlWithParams = WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}/{2}", new object[]
				{
					RegistryManager.Instance.Host,
					"bs4",
					"guidance_window"
				}));
				string text = BstHttpClient.Post(urlWithParams, new Dictionary<string, string>
				{
					{
						"app_pkgs",
						GuidanceCloudInfoManager.GetInstalledAppDataFromAllVms()
					}
				}, null, false, "Android", 0, 1, 0, false);
				Logger.Debug("Guidance Cloud Info Url: " + urlWithParams);
				Logger.Debug("Guidance Cloud Info Response: " + text);
				result = JToken.Parse(text);
			}
			catch (Exception ex)
			{
				Logger.Warning("Error Getting GetGuidanceCloudInfoData " + ex.ToString());
			}
			return result;
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x0001D6CC File Offset: 0x0001B8CC
		private static string GetInstalledAppDataFromAllVms()
		{
			string[] vmList = RegistryManager.Instance.VmList;
			JArray jarray = new JArray();
			try
			{
				string[] array = vmList;
				for (int i = 0; i < array.Length; i++)
				{
					foreach (AppInfo appInfo in new JsonParser(array[i]).GetAppList().ToList<AppInfo>())
					{
						string package = appInfo.Package;
						jarray.Add(package);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in getting all installed apps from all Vms: {0}", new object[]
				{
					ex.ToString()
				});
			}
			return jarray.ToString(Formatting.None, new JsonConverter[0]);
		}

		// Token: 0x06000456 RID: 1110 RVA: 0x00004F31 File Offset: 0x00003131
		internal void AppsGuidanceCloudInfoRefresh()
		{
			new Thread(delegate()
			{
				if (File.Exists(GuidanceCloudInfoManager.BstGuidanceFilePath))
				{
					this.mGuidanceCloudInfo = JsonConvert.DeserializeObject<GuidanceCloudInfo>(File.ReadAllText(GuidanceCloudInfoManager.BstGuidanceFilePath));
				}
				JToken guidanceCloudInfoData = GuidanceCloudInfoManager.GetGuidanceCloudInfoData();
				if (guidanceCloudInfoData != null)
				{
					GuidanceCloudInfo guidanceCloudInfo = new GuidanceCloudInfo();
					GuidanceCloudInfoManager.SetAppsVideoThumbnail(guidanceCloudInfo, guidanceCloudInfoData);
					GuidanceCloudInfoManager.SetAppsReadArticle(guidanceCloudInfo, guidanceCloudInfoData);
					GuidanceCloudInfoManager.SaveToFile(guidanceCloudInfo);
					this.mGuidanceCloudInfo = guidanceCloudInfo;
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x0001D794 File Offset: 0x0001B994
		private static void SaveToFile(GuidanceCloudInfo guidanceCloudInfo)
		{
			try
			{
				string contents = JsonConvert.SerializeObject(guidanceCloudInfo, Formatting.Indented, Utils.GetSerializerSettings());
				if (!Directory.Exists(RegistryStrings.PromotionDirectory))
				{
					Directory.CreateDirectory(RegistryStrings.PromotionDirectory);
				}
				File.WriteAllText(GuidanceCloudInfoManager.BstGuidanceFilePath, contents);
			}
			catch (Exception)
			{
				Logger.Warning("Error in saving GuidanceCloudInfo to file");
			}
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x0001D7F0 File Offset: 0x0001B9F0
		private static void SetAppsVideoThumbnail(GuidanceCloudInfo mCurrentAppsGuidanceCloudInfo, JToken res)
		{
			try
			{
				foreach (JToken jtoken in JArray.Parse(res.GetValue("custom_thumbnails").ToString(CultureInfo.InvariantCulture)))
				{
					CustomThumbnail customThumbnail = JsonConvert.DeserializeObject<CustomThumbnail>(jtoken.ToString(), Utils.GetSerializerSettings());
					foreach (object obj in Enum.GetValues(typeof(GuidanceVideoType)))
					{
						GuidanceVideoType guidanceVideoType = (GuidanceVideoType)obj;
						if (guidanceVideoType == GuidanceVideoType.SchemeSpecific)
						{
							using (Dictionary<string, VideoThumbnailInfo>.Enumerator enumerator3 = ((Dictionary<string, VideoThumbnailInfo>)customThumbnail[guidanceVideoType.ToString()]).GetEnumerator())
							{
								while (enumerator3.MoveNext())
								{
									KeyValuePair<string, VideoThumbnailInfo> keyValuePair = enumerator3.Current;
									VideoThumbnailInfo value = keyValuePair.Value;
									value.ThumbnailType = guidanceVideoType;
									value.ImagePath = Utils.TinyDownloader(value.ThumbnailUrl, "VideoThumbnail_" + customThumbnail.Package + value.ThumbnailId, RegistryStrings.PromotionDirectory, false);
								}
								continue;
							}
						}
						if (customThumbnail[guidanceVideoType.ToString()] != null)
						{
							VideoThumbnailInfo videoThumbnailInfo = (VideoThumbnailInfo)customThumbnail[guidanceVideoType.ToString()];
							videoThumbnailInfo.ThumbnailType = guidanceVideoType;
							videoThumbnailInfo.ImagePath = Utils.TinyDownloader(videoThumbnailInfo.ThumbnailUrl, "VideoThumbnail_" + customThumbnail.Package + videoThumbnailInfo.ThumbnailId, RegistryStrings.PromotionDirectory, false);
						}
					}
					mCurrentAppsGuidanceCloudInfo.CustomThumbnails[customThumbnail.Package] = customThumbnail;
				}
				foreach (JToken jtoken2 in JArray.Parse(res.GetValue("default_thumbnails").ToString(CultureInfo.InvariantCulture)))
				{
					VideoThumbnailInfo videoThumbnailInfo2 = JsonConvert.DeserializeObject<VideoThumbnailInfo>(jtoken2.ToString(), Utils.GetSerializerSettings());
					videoThumbnailInfo2.ImagePath = Utils.TinyDownloader(videoThumbnailInfo2.ThumbnailUrl, "VideoThumbnail_DefaultPackage_" + videoThumbnailInfo2.ThumbnailId, RegistryStrings.PromotionDirectory, false);
					mCurrentAppsGuidanceCloudInfo.DefaultThumbnails[videoThumbnailInfo2.ThumbnailType] = videoThumbnailInfo2;
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Error Loading Apps VideoThumbnail" + ex.ToString());
			}
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x0001DAC0 File Offset: 0x0001BCC0
		private static void SetAppsReadArticle(GuidanceCloudInfo mCurrentAppsGuidanceCloudInfo, JToken res)
		{
			try
			{
				foreach (JToken jtoken in JArray.Parse(res.GetValue("help_article").ToString(CultureInfo.InvariantCulture)))
				{
					HelpArticle helpArticle = JsonConvert.DeserializeObject<HelpArticle>(jtoken.ToString(), Utils.GetSerializerSettings());
					mCurrentAppsGuidanceCloudInfo.HelpArticles[helpArticle.Package] = helpArticle;
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Error Loading Apps ReadArticle" + ex.ToString());
			}
		}

		// Token: 0x04000257 RID: 599
		private static GuidanceCloudInfoManager sInstance = null;

		// Token: 0x04000258 RID: 600
		private static readonly object sLock = new object();

		// Token: 0x04000259 RID: 601
		private const string sGuidanceCloudInfoFilename = "bst_guidance";

		// Token: 0x0400025A RID: 602
		internal GuidanceCloudInfo mGuidanceCloudInfo = new GuidanceCloudInfo();
	}
}
