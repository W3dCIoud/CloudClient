﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000EA RID: 234
	public class RecommendedApps : UserControl, IComponentConnector
	{
		// Token: 0x0600098C RID: 2444 RVA: 0x00008183 File Offset: 0x00006383
		public RecommendedApps()
		{
			this.InitializeComponent();
		}

		// Token: 0x170001E4 RID: 484
		// (get) Token: 0x0600098D RID: 2445 RVA: 0x00008191 File Offset: 0x00006391
		// (set) Token: 0x0600098E RID: 2446 RVA: 0x00008199 File Offset: 0x00006399
		internal AppRecommendation AppRecomendation { get; set; }

		// Token: 0x170001E5 RID: 485
		// (get) Token: 0x0600098F RID: 2447 RVA: 0x000081A2 File Offset: 0x000063A2
		// (set) Token: 0x06000990 RID: 2448 RVA: 0x000081AA File Offset: 0x000063AA
		internal int RecommendedAppPosition { get; set; }

		// Token: 0x170001E6 RID: 486
		// (get) Token: 0x06000991 RID: 2449 RVA: 0x000081B3 File Offset: 0x000063B3
		// (set) Token: 0x06000992 RID: 2450 RVA: 0x000081BB File Offset: 0x000063BB
		internal int RecommendedAppRank { get; set; }

		// Token: 0x170001E7 RID: 487
		// (get) Token: 0x06000993 RID: 2451 RVA: 0x000081C4 File Offset: 0x000063C4
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x06000994 RID: 2452 RVA: 0x000375EC File Offset: 0x000357EC
		internal void Populate(AppRecommendation recom, int appPosition, int appRank)
		{
			this.AppRecomendation = recom;
			this.recomIcon.IsFullImagePath = true;
			this.recomIcon.ImageName = recom.ImagePath;
			this.appNameTextBlock.Text = recom.ExtraPayload["click_action_title"];
			this.appGenreTextBlock.Text = recom.GameGenre;
			this.RecommendedAppPosition = appPosition;
			this.RecommendedAppRank = appRank;
		}

		// Token: 0x06000995 RID: 2453 RVA: 0x00037658 File Offset: 0x00035858
		private void Recommendation_Click(object sender, MouseButtonEventArgs e)
		{
			try
			{
				JArray jarray = new JArray();
				JObject item = new JObject
				{
					{
						"app_loc",
						(this.AppRecomendation.ExtraPayload["click_generic_action"] == "InstallCDN") ? "cdn" : "gplay"
					},
					{
						"app_pkg",
						this.AppRecomendation.ExtraPayload["click_action_packagename"]
					},
					{
						"is_installed",
						this.ParentWindow.mAppHandler.IsAppInstalled(this.AppRecomendation.ExtraPayload["click_action_packagename"]) ? "true" : "false"
					},
					{
						"app_position",
						this.RecommendedAppPosition.ToString(CultureInfo.InvariantCulture)
					},
					{
						"app_rank",
						this.RecommendedAppRank.ToString(CultureInfo.InvariantCulture)
					}
				};
				jarray.Add(item);
				ClientStats.SendFrontendClickStats("apps_recommendation", "click", null, this.AppRecomendation.ExtraPayload["click_action_packagename"], null, null, null, jarray.ToString(Formatting.None, new JsonConverter[0]));
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while sending stats to cloud for apps_recommendation_click " + ex.ToString());
			}
			this.ParentWindow.Utils.HandleGenericActionFromDictionary(this.AppRecomendation.ExtraPayload, "search_suggestion", "");
		}

		// Token: 0x06000996 RID: 2454 RVA: 0x000081E5 File Offset: 0x000063E5
		private void UserControl_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(this.mMainGrid, Control.BackgroundProperty, "SearchGridBackgroundHoverColor");
		}

		// Token: 0x06000997 RID: 2455 RVA: 0x000081FC File Offset: 0x000063FC
		private void UserControl_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mMainGrid.Background = Brushes.Transparent;
		}

		// Token: 0x06000998 RID: 2456 RVA: 0x000377F4 File Offset: 0x000359F4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/recommendedapps.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000999 RID: 2457 RVA: 0x00037824 File Offset: 0x00035A24
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMainGrid = (Grid)target;
				this.mMainGrid.MouseEnter += this.UserControl_MouseEnter;
				this.mMainGrid.MouseLeave += this.UserControl_MouseLeave;
				this.mMainGrid.PreviewMouseLeftButtonUp += this.Recommendation_Click;
				return;
			case 2:
				this.recomIcon = (CustomPictureBox)target;
				return;
			case 3:
				this.appNameTextBlock = (TextBlock)target;
				return;
			case 4:
				this.appGenreTextBlock = (TextBlock)target;
				return;
			case 5:
				this.installButton = (CustomButton)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040005F7 RID: 1527
		private MainWindow mMainWindow;

		// Token: 0x040005F8 RID: 1528
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mMainGrid;

		// Token: 0x040005F9 RID: 1529
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox recomIcon;

		// Token: 0x040005FA RID: 1530
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock appNameTextBlock;

		// Token: 0x040005FB RID: 1531
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock appGenreTextBlock;

		// Token: 0x040005FC RID: 1532
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton installButton;

		// Token: 0x040005FD RID: 1533
		private bool _contentLoaded;
	}
}
