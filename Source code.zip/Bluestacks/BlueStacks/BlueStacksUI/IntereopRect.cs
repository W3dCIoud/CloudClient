﻿using System;
using System.Drawing;
using System.Globalization;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200024E RID: 590
	public struct IntereopRect : IEquatable<IntereopRect>
	{
		// Token: 0x170002C9 RID: 713
		// (get) Token: 0x060014F9 RID: 5369 RVA: 0x0000E45B File Offset: 0x0000C65B
		// (set) Token: 0x060014FA RID: 5370 RVA: 0x0000E463 File Offset: 0x0000C663
		public int Left { readonly get; set; }

		// Token: 0x170002CA RID: 714
		// (get) Token: 0x060014FB RID: 5371 RVA: 0x0000E46C File Offset: 0x0000C66C
		// (set) Token: 0x060014FC RID: 5372 RVA: 0x0000E474 File Offset: 0x0000C674
		public int Top { readonly get; set; }

		// Token: 0x170002CB RID: 715
		// (get) Token: 0x060014FD RID: 5373 RVA: 0x0000E47D File Offset: 0x0000C67D
		// (set) Token: 0x060014FE RID: 5374 RVA: 0x0000E485 File Offset: 0x0000C685
		public int Right { readonly get; set; }

		// Token: 0x170002CC RID: 716
		// (get) Token: 0x060014FF RID: 5375 RVA: 0x0000E48E File Offset: 0x0000C68E
		// (set) Token: 0x06001500 RID: 5376 RVA: 0x0000E496 File Offset: 0x0000C696
		public int Bottom { readonly get; set; }

		// Token: 0x06001501 RID: 5377 RVA: 0x0000E49F File Offset: 0x0000C69F
		public IntereopRect(int left, int top, int right, int bottom)
		{
			this.Left = left;
			this.Top = top;
			this.Right = right;
			this.Bottom = bottom;
		}

		// Token: 0x06001502 RID: 5378 RVA: 0x0000E4BE File Offset: 0x0000C6BE
		public IntereopRect(Rectangle r)
		{
			this = new IntereopRect(r.Left, r.Top, r.Right, r.Bottom);
		}

		// Token: 0x170002CD RID: 717
		// (get) Token: 0x06001503 RID: 5379 RVA: 0x0000E4E2 File Offset: 0x0000C6E2
		// (set) Token: 0x06001504 RID: 5380 RVA: 0x0000E4EA File Offset: 0x0000C6EA
		public int X
		{
			get
			{
				return this.Left;
			}
			set
			{
				this.Right -= this.Left - value;
				this.Left = value;
			}
		}

		// Token: 0x170002CE RID: 718
		// (get) Token: 0x06001505 RID: 5381 RVA: 0x0000E508 File Offset: 0x0000C708
		// (set) Token: 0x06001506 RID: 5382 RVA: 0x0000E510 File Offset: 0x0000C710
		public int Y
		{
			get
			{
				return this.Top;
			}
			set
			{
				this.Bottom -= this.Top - value;
				this.Top = value;
			}
		}

		// Token: 0x170002CF RID: 719
		// (get) Token: 0x06001507 RID: 5383 RVA: 0x0000E52E File Offset: 0x0000C72E
		// (set) Token: 0x06001508 RID: 5384 RVA: 0x0000E53D File Offset: 0x0000C73D
		public int Height
		{
			get
			{
				return this.Bottom - this.Top;
			}
			set
			{
				this.Bottom = value + this.Top;
			}
		}

		// Token: 0x170002D0 RID: 720
		// (get) Token: 0x06001509 RID: 5385 RVA: 0x0000E54D File Offset: 0x0000C74D
		// (set) Token: 0x0600150A RID: 5386 RVA: 0x0000E55C File Offset: 0x0000C75C
		public int Width
		{
			get
			{
				return this.Right - this.Left;
			}
			set
			{
				this.Right = value + this.Left;
			}
		}

		// Token: 0x170002D1 RID: 721
		// (get) Token: 0x0600150B RID: 5387 RVA: 0x0000E56C File Offset: 0x0000C76C
		// (set) Token: 0x0600150C RID: 5388 RVA: 0x0000E57F File Offset: 0x0000C77F
		public Point Location
		{
			get
			{
				return new Point(this.Left, this.Top);
			}
			set
			{
				this.X = value.X;
				this.Y = value.Y;
			}
		}

		// Token: 0x170002D2 RID: 722
		// (get) Token: 0x0600150D RID: 5389 RVA: 0x0000E59B File Offset: 0x0000C79B
		// (set) Token: 0x0600150E RID: 5390 RVA: 0x0000E5AE File Offset: 0x0000C7AE
		public Size Size
		{
			get
			{
				return new Size(this.Width, this.Height);
			}
			set
			{
				this.Width = value.Width;
				this.Height = value.Height;
			}
		}

		// Token: 0x0600150F RID: 5391 RVA: 0x0000E5CA File Offset: 0x0000C7CA
		public static implicit operator Rectangle(IntereopRect r)
		{
			return new Rectangle(r.Left, r.Top, r.Width, r.Height);
		}

		// Token: 0x06001510 RID: 5392 RVA: 0x0000E5ED File Offset: 0x0000C7ED
		public static implicit operator IntereopRect(Rectangle r)
		{
			return new IntereopRect(r);
		}

		// Token: 0x06001511 RID: 5393 RVA: 0x0007E250 File Offset: 0x0007C450
		public static bool operator ==(IntereopRect r1, IntereopRect r2)
		{
			if (r1.Equals(default(IntereopRect)))
			{
				return r2.Equals(default(IntereopRect));
			}
			return r1.Equals(r2);
		}

		// Token: 0x06001512 RID: 5394 RVA: 0x0000E5F5 File Offset: 0x0000C7F5
		public static bool operator !=(IntereopRect r1, IntereopRect r2)
		{
			return !(r1 == r2);
		}

		// Token: 0x06001513 RID: 5395 RVA: 0x0000E601 File Offset: 0x0000C801
		public bool Equals(IntereopRect r)
		{
			return r.Left == this.Left && r.Top == this.Top && r.Right == this.Right && r.Bottom == this.Bottom;
		}

		// Token: 0x06001514 RID: 5396 RVA: 0x0000E641 File Offset: 0x0000C841
		public override bool Equals(object obj)
		{
			if (obj is IntereopRect)
			{
				return this.Equals((IntereopRect)obj);
			}
			return obj is Rectangle && this.Equals(new IntereopRect((Rectangle)obj));
		}

		// Token: 0x06001515 RID: 5397 RVA: 0x0007E288 File Offset: 0x0007C488
		public override int GetHashCode()
		{
			return this.GetHashCode();
		}

		// Token: 0x06001516 RID: 5398 RVA: 0x0007E2B0 File Offset: 0x0007C4B0
		public override string ToString()
		{
			return string.Format(CultureInfo.CurrentCulture, "{{Left={0},Top={1},Right={2},Bottom={3}}}", new object[]
			{
				this.Left,
				this.Top,
				this.Right,
				this.Bottom
			});
		}

		// Token: 0x06001517 RID: 5399 RVA: 0x0000E673 File Offset: 0x0000C873
		public Rectangle ToRectangle()
		{
			return new Rectangle(this.Left, this.Top, this.Width, this.Height);
		}

		// Token: 0x06001518 RID: 5400 RVA: 0x0000E692 File Offset: 0x0000C892
		public IntereopRect ToIntereopRect()
		{
			return new IntereopRect(this);
		}
	}
}
