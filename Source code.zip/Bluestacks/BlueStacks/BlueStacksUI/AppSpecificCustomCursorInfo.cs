﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000037 RID: 55
	[Serializable]
	public class AppSpecificCustomCursorInfo
	{
		// Token: 0x1700011C RID: 284
		// (get) Token: 0x060002F5 RID: 757 RVA: 0x00003FF4 File Offset: 0x000021F4
		// (set) Token: 0x060002F6 RID: 758 RVA: 0x00003FFC File Offset: 0x000021FC
		public AppPackageListObject CustomCursorAppPackages { get; set; }
	}
}
