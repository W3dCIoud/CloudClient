﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000EB RID: 235
	public class RecommendedAppsSection : UserControl, IComponentConnector
	{
		// Token: 0x0600099A RID: 2458 RVA: 0x0000820E File Offset: 0x0000640E
		public RecommendedAppsSection(string header)
		{
			this.InitializeComponent();
			this.mSectionHeader.Text = header;
		}

		// Token: 0x0600099B RID: 2459 RVA: 0x000378E0 File Offset: 0x00035AE0
		internal void AddSuggestedApps(MainWindow ParentWindow, List<AppRecommendation> suggestedApps, int clientShowCount)
		{
			int num = 1;
			int num2 = 1;
			ParentWindow.mWelcomeTab.mHomeApp.sAppRecommendationsPool.Clear();
			foreach (AppRecommendation appRecommendation in suggestedApps)
			{
				if (!ParentWindow.mAppHandler.IsAppInstalled(appRecommendation.ExtraPayload["click_action_packagename"]))
				{
					RecommendedApps recommendedApps = new RecommendedApps();
					recommendedApps.Populate(appRecommendation, num, num2);
					if (num <= clientShowCount)
					{
						this.mAppRecommendationsPanel.Children.Add(recommendedApps);
						num++;
					}
					else
					{
						ParentWindow.mWelcomeTab.mHomeApp.sAppRecommendationsPool.Add(recommendedApps);
					}
				}
				num2++;
			}
		}

		// Token: 0x0600099C RID: 2460 RVA: 0x000379A8 File Offset: 0x00035BA8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/recommendedappssection.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600099D RID: 2461 RVA: 0x00008228 File Offset: 0x00006428
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mSectionHeader = (TextBlock)target;
				return;
			}
			if (connectionId != 2)
			{
				this._contentLoaded = true;
				return;
			}
			this.mAppRecommendationsPanel = (StackPanel)target;
		}

		// Token: 0x040005FE RID: 1534
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mSectionHeader;

		// Token: 0x040005FF RID: 1535
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mAppRecommendationsPanel;

		// Token: 0x04000600 RID: 1536
		private bool _contentLoaded;
	}
}
