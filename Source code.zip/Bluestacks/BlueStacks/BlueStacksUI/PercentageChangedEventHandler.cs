﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200025E RID: 606
	// (Invoke) Token: 0x06001571 RID: 5489
	public delegate void PercentageChangedEventHandler(object sender, PercentageChangedEventArgs args);
}
