﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000186 RID: 390
	public class BackupRestoreSettingsControl : UserControl, IComponentConnector
	{
		// Token: 0x06000F23 RID: 3875 RVA: 0x00061A18 File Offset: 0x0005FC18
		public BackupRestoreSettingsControl(MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			if (this.ParentWindow != null && !this.ParentWindow.IsDefaultVM)
			{
				this.mBackupRestoreGrid.Visibility = Visibility.Collapsed;
				this.mLineSeperator.Visibility = Visibility.Collapsed;
			}
			base.Visibility = Visibility.Hidden;
		}

		// Token: 0x06000F24 RID: 3876 RVA: 0x00061A6C File Offset: 0x0005FC6C
		private void RestoreBtn_Click(object sender, RoutedEventArgs e)
		{
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.ImageName = "backup_restore_popup_window";
			BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_RESTORE_BACKUP", "");
			BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_MAKE_SURE_LATEST_WARNING", "");
			customMessageWindow.AddButton(ButtonColors.Blue, "STRING_RESTORE_BUTTON", delegate(object sender1, EventArgs e1)
			{
				this.LaunchDataManager("restore");
			}, null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
			customMessageWindow.Owner = this.ParentWindow;
			customMessageWindow.ShowDialog();
		}

		// Token: 0x06000F25 RID: 3877 RVA: 0x00061AF0 File Offset: 0x0005FCF0
		private void BackupBtn_Click(object sender, RoutedEventArgs e)
		{
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.ImageName = "backup_restore_popup_window";
			BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_BACKUP_WARNING", "");
			BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_BLUESTACKS_BACKUP_PROMPT", "");
			customMessageWindow.AddButton(ButtonColors.Blue, "STRING_BACKUP", delegate(object sender1, EventArgs e1)
			{
				this.LaunchDataManager("backup");
			}, null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
			customMessageWindow.Owner = this.ParentWindow;
			customMessageWindow.ShowDialog();
		}

		// Token: 0x06000F26 RID: 3878 RVA: 0x00061B74 File Offset: 0x0005FD74
		private void DiskCleanupBtn_Click(object sender, RoutedEventArgs e)
		{
			EventHandler <>9__1;
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (ProcessUtils.IsAlreadyRunning("Global\\BlueStacks_DiskCompactor_Lockbgp"))
				{
					CustomMessageWindow customMessageWindow = new CustomMessageWindow();
					customMessageWindow.ImageName = "disk_cleanup_popup_window";
					customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_DISK_CLEANUP_MULTIPLE_RUN_HEADING");
					customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_DISK_CLEANUP_MULTIPLE_RUN_MESSAGE");
					customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
					customMessageWindow.CloseButtonHandle(null, null);
					customMessageWindow.Owner = this.ParentWindow;
					customMessageWindow.ShowDialog();
					return;
				}
				CustomMessageWindow customMessageWindow2 = new CustomMessageWindow();
				customMessageWindow2.ImageName = "disk_cleanup_popup_window";
				customMessageWindow2.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_DISK_CLEANUP");
				customMessageWindow2.BodyTextBlockTitle.Text = LocaleStrings.GetLocalizedString("STRING_DISK_CLEANUP_MESSAGE");
				customMessageWindow2.BodyTextBlockTitle.Visibility = Visibility.Visible;
				customMessageWindow2.BodyTextBlockTitle.FontWeight = FontWeights.Regular;
				customMessageWindow2.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_CONTINUE_CONFIRMATION");
				customMessageWindow2.AddButton(ButtonColors.White, "STRING_CLOSE", null, null, false, null);
				ButtonColors color = ButtonColors.Blue;
				string text = "STRING_CONTINUE";
				EventHandler handle;
				if ((handle = <>9__1) == null)
				{
					handle = (<>9__1 = delegate(object sender1, EventArgs e1)
					{
						this.LaunchDiskCompaction(sender, null);
					});
				}
				customMessageWindow2.AddButton(color, text, handle, null, false, null);
				customMessageWindow2.CloseButtonHandle(null, null);
				customMessageWindow2.Owner = this.ParentWindow;
				customMessageWindow2.ShowDialog();
			}), new object[0]);
		}

		// Token: 0x06000F27 RID: 3879 RVA: 0x00061BB8 File Offset: 0x0005FDB8
		private void LaunchDataManager(string argument)
		{
			foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
			{
				if (argument == "backup")
				{
					keyValuePair.Value.CloseAllWindowAndPerform(new EventHandler(this.Closing_WindowHandlerForBackup));
				}
				else if (argument == "restore")
				{
					keyValuePair.Value.CloseAllWindowAndPerform(new EventHandler(this.Closing_WindowHandlerForRestore));
				}
			}
		}

		// Token: 0x06000F28 RID: 3880 RVA: 0x00061C50 File Offset: 0x0005FE50
		private void LaunchDiskCompaction(object sender, MouseButtonEventArgs e)
		{
			try
			{
				BlueStacksUIUtils.HideUnhideBlueStacks(true);
				using (Process process = new Process())
				{
					process.StartInfo.FileName = System.IO.Path.Combine(RegistryStrings.InstallDir, "DiskCompactionTool.exe");
					process.StartInfo.Arguments = string.Format(CultureInfo.InvariantCulture, "-vmname:{0} -relaunch", new object[]
					{
						this.ParentWindow.mVmName
					});
					process.Start();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in starting disk compaction" + ex.ToString());
			}
		}

		// Token: 0x06000F29 RID: 3881 RVA: 0x00061CFC File Offset: 0x0005FEFC
		internal void Closing_WindowHandlerForBackup(object sender, EventArgs e)
		{
			try
			{
				Dictionary<string, string> data = new Dictionary<string, string>
				{
					{
						"relaunch",
						"true"
					},
					{
						"sendResponseImmediately",
						"true"
					}
				};
				HTTPUtils.SendRequestToAgent("backup", data, this.ParentWindow.mVmName, 0, null, false, 1, 0);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in closing window handler for backup" + ex.ToString());
			}
		}

		// Token: 0x06000F2A RID: 3882 RVA: 0x00061D78 File Offset: 0x0005FF78
		internal void Closing_WindowHandlerForRestore(object sender, EventArgs e)
		{
			try
			{
				Utils.KillCurrentOemProcessByName("HD-MultiInstanceManager", null);
				Dictionary<string, string> data = new Dictionary<string, string>
				{
					{
						"relaunch",
						"true"
					},
					{
						"sendResponseImmediately",
						"true"
					}
				};
				HTTPUtils.SendRequestToAgent("restore", data, this.ParentWindow.mVmName, 0, null, false, 1, 0);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in closing window handler for restore" + ex.ToString());
			}
		}

		// Token: 0x06000F2B RID: 3883 RVA: 0x00061DFC File Offset: 0x0005FFFC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/backuprestoresettingscontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000F2C RID: 3884 RVA: 0x00061E2C File Offset: 0x0006002C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mDiskCleanupGrid = (Grid)target;
				return;
			case 2:
				this.mDiskCleanupBtn = (CustomButton)target;
				this.mDiskCleanupBtn.Click += this.DiskCleanupBtn_Click;
				return;
			case 3:
				this.mLineSeperator = (Line)target;
				return;
			case 4:
				this.mBackupRestoreGrid = (Grid)target;
				return;
			case 5:
				this.mRestoreBtn = (CustomButton)target;
				this.mRestoreBtn.Click += this.RestoreBtn_Click;
				return;
			case 6:
				this.mBackupBtn = (CustomButton)target;
				this.mBackupBtn.Click += this.BackupBtn_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000A35 RID: 2613
		private MainWindow ParentWindow;

		// Token: 0x04000A36 RID: 2614
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mDiskCleanupGrid;

		// Token: 0x04000A37 RID: 2615
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mDiskCleanupBtn;

		// Token: 0x04000A38 RID: 2616
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Line mLineSeperator;

		// Token: 0x04000A39 RID: 2617
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mBackupRestoreGrid;

		// Token: 0x04000A3A RID: 2618
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mRestoreBtn;

		// Token: 0x04000A3B RID: 2619
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mBackupBtn;

		// Token: 0x04000A3C RID: 2620
		private bool _contentLoaded;
	}
}
