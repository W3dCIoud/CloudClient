﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001B0 RID: 432
	public class UpdateDownloadProgress : CustomWindow, IComponentConnector
	{
		// Token: 0x060010A7 RID: 4263 RVA: 0x0000C293 File Offset: 0x0000A493
		public UpdateDownloadProgress()
		{
			this.InitializeComponent();
			base.IsShowGLWindow = true;
		}

		// Token: 0x060010A8 RID: 4264 RVA: 0x000260D8 File Offset: 0x000242D8
		private void Grid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			if (!e.OriginalSource.GetType().Equals(typeof(CustomPictureBox)))
			{
				try
				{
					base.DragMove();
				}
				catch
				{
				}
			}
		}

		// Token: 0x060010A9 RID: 4265 RVA: 0x00005BEB File Offset: 0x00003DEB
		private void HideBtn_Click(object sender, RoutedEventArgs e)
		{
			base.Hide();
		}

		// Token: 0x060010AA RID: 4266 RVA: 0x00005BEB File Offset: 0x00003DEB
		private void mCloseBtn_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			base.Hide();
		}

		// Token: 0x060010AB RID: 4267 RVA: 0x00067F14 File Offset: 0x00066114
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/updatedownloadprogress.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060010AC RID: 4268 RVA: 0x00067F44 File Offset: 0x00066144
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mUpdateDownloadProgressUserControl = (UpdateDownloadProgress)target;
				return;
			case 2:
				this.mMaskBorder = (Border)target;
				return;
			case 3:
				((Grid)target).MouseLeftButtonDown += this.Grid_MouseLeftButtonDown;
				return;
			case 4:
				this.titleLabel = (TextBlock)target;
				return;
			case 5:
				this.mCloseBtn = (CustomPictureBox)target;
				this.mCloseBtn.PreviewMouseLeftButtonUp += this.mCloseBtn_PreviewMouseLeftButtonUp;
				return;
			case 6:
				this.mUpdateDownloadProgressBar = (BlueProgressBar)target;
				return;
			case 7:
				this.mUpdateDownloadProgressPercentage = (Label)target;
				return;
			case 8:
				this.mHideBtn = (CustomButton)target;
				this.mHideBtn.Click += this.HideBtn_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000B1E RID: 2846
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal UpdateDownloadProgress mUpdateDownloadProgressUserControl;

		// Token: 0x04000B1F RID: 2847
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder;

		// Token: 0x04000B20 RID: 2848
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock titleLabel;

		// Token: 0x04000B21 RID: 2849
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCloseBtn;

		// Token: 0x04000B22 RID: 2850
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal BlueProgressBar mUpdateDownloadProgressBar;

		// Token: 0x04000B23 RID: 2851
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Label mUpdateDownloadProgressPercentage;

		// Token: 0x04000B24 RID: 2852
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mHideBtn;

		// Token: 0x04000B25 RID: 2853
		private bool _contentLoaded;
	}
}
