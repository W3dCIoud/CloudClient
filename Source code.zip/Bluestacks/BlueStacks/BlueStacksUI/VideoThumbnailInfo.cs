﻿using System;
using System.IO;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200006F RID: 111
	public class VideoThumbnailInfo
	{
		// Token: 0x1700016E RID: 366
		// (get) Token: 0x0600047A RID: 1146 RVA: 0x000050A7 File Offset: 0x000032A7
		// (set) Token: 0x0600047B RID: 1147 RVA: 0x000050AF File Offset: 0x000032AF
		[JsonProperty(PropertyName = "thumbnail_id")]
		public string ThumbnailId { get; set; }

		// Token: 0x1700016F RID: 367
		// (get) Token: 0x0600047C RID: 1148 RVA: 0x000050B8 File Offset: 0x000032B8
		// (set) Token: 0x0600047D RID: 1149 RVA: 0x000050C0 File Offset: 0x000032C0
		[JsonProperty(PropertyName = "thumbnail_url")]
		public string ThumbnailUrl { get; set; }

		// Token: 0x17000170 RID: 368
		// (get) Token: 0x0600047E RID: 1150 RVA: 0x000050C9 File Offset: 0x000032C9
		// (set) Token: 0x0600047F RID: 1151 RVA: 0x000050D1 File Offset: 0x000032D1
		[JsonProperty(PropertyName = "type", DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate, NullValueHandling = NullValueHandling.Include)]
		public GuidanceVideoType ThumbnailType { get; set; }

		// Token: 0x17000171 RID: 369
		// (get) Token: 0x06000480 RID: 1152 RVA: 0x000050DA File Offset: 0x000032DA
		// (set) Token: 0x06000481 RID: 1153 RVA: 0x000050E2 File Offset: 0x000032E2
		public string ImagePath { get; set; } = string.Empty;

		// Token: 0x06000482 RID: 1154 RVA: 0x0001DBBC File Offset: 0x0001BDBC
		internal void DeleteFile()
		{
			try
			{
				File.Delete(this.ImagePath);
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't delete AppRecommendation file: " + this.ImagePath);
				Logger.Error(ex.ToString());
			}
		}
	}
}
