﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using BlueStacks.BlueStacksUI.Controls;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200025A RID: 602
	public class PreferenceDropDownControl : UserControl, IComponentConnector, IStyleConnector
	{
		// Token: 0x170002D3 RID: 723
		// (get) Token: 0x06001530 RID: 5424 RVA: 0x0000E783 File Offset: 0x0000C983
		// (set) Token: 0x06001531 RID: 5425 RVA: 0x0000E78B File Offset: 0x0000C98B
		public MainWindow ParentWindow { get; set; }

		// Token: 0x1400002A RID: 42
		// (add) Token: 0x06001532 RID: 5426 RVA: 0x0007F03C File Offset: 0x0007D23C
		// (remove) Token: 0x06001533 RID: 5427 RVA: 0x0007F074 File Offset: 0x0007D274
		private event EventHandler LogoutConfirmationResetAccountAcceptedHandler;

		// Token: 0x1400002B RID: 43
		// (add) Token: 0x06001534 RID: 5428 RVA: 0x0007F0AC File Offset: 0x0007D2AC
		// (remove) Token: 0x06001535 RID: 5429 RVA: 0x0007F0E4 File Offset: 0x0007D2E4
		private event EventHandler RestoreDefaultConfirmationClicked;

		// Token: 0x06001536 RID: 5430 RVA: 0x0007F11C File Offset: 0x0007D31C
		public PreferenceDropDownControl()
		{
			this.InitializeComponent();
			this.LogoutConfirmationResetAccountAcceptedHandler += this.PreferenceDropDownControl_CloseWindowConfirmationResetAccountAcceptedHandler;
			this.RestoreDefaultConfirmationClicked += this.PreferenceDropDownControl_RestoreDefaultConfirmationClicked;
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				this.mSpeedUpBstGrid.Visibility = Visibility.Collapsed;
				this.mUpgradeToFullBlueStacks.Visibility = Visibility.Visible;
			}
			if (!FeatureManager.Instance.IsShowSpeedUpTips)
			{
				this.mSpeedUpBstGrid.Visibility = Visibility.Collapsed;
			}
			if (!FeatureManager.Instance.IsShowHelpCenter)
			{
				this.mHelpCenterGrid.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x06001537 RID: 5431 RVA: 0x0007F1B0 File Offset: 0x0007D3B0
		private void PreferenceDropDownControl_RestoreDefaultConfirmationClicked(object sender, EventArgs e)
		{
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "RestoreDefaultWallpaper", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, "Premium", null);
			this.mChooseWallpaperPopup.IsOpen = false;
			this.ParentWindow.Utils.RestoreWallpaperImageForAllVms();
		}

		// Token: 0x06001538 RID: 5432 RVA: 0x0007F21C File Offset: 0x0007D41C
		internal void Init(MainWindow parentWindow)
		{
			this.ParentWindow = parentWindow;
			if (Oem.Instance.IsRemoveAccountOnExit)
			{
				this.mLogoutButtonGrid.Visibility = Visibility.Visible;
			}
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				this.mUpgradeToFullTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_UPGRADE_TO_STANDARD_BST").Replace(GameConfig.Instance.AppName, "BlueStacks");
			}
		}

		// Token: 0x06001539 RID: 5433 RVA: 0x0007F280 File Offset: 0x0007D480
		internal void LateInit()
		{
			if (FeatureManager.Instance.ShowClientOnTopPreference)
			{
				if (this.ParentWindow.EngineInstanceRegistry.IsClientOnTop)
				{
					this.mPinToTopToggleButton.ImageName = this.mPinToTopToggleButton.ImageName.Replace("_off", "_on");
				}
				else
				{
					this.mPinToTopToggleButton.ImageName = this.mPinToTopToggleButton.ImageName.Replace("_on", "_off");
				}
			}
			else
			{
				this.mPinToTopGrid.Visibility = Visibility.Collapsed;
			}
			if (FeatureManager.Instance.IsThemeEnabled && RegistryManager.Instance.InstallationType != InstallationTypes.GamingEdition)
			{
				this.mChangeSkinGrid.Visibility = Visibility.Visible;
			}
			if (this.ParentWindow != null && this.ParentWindow.EngineInstanceRegistry.IsGoogleSigninDone && !FeatureManager.Instance.IsWallpaperChangeDisabled && RegistryManager.Instance.InstallationType != InstallationTypes.GamingEdition)
			{
				this.mChangeWallpaperGrid.Visibility = Visibility.Visible;
			}
			this.mAutoAlignGrid.MouseLeftButtonUp += this.AutoAlign_MouseLeftButtonUp;
			this.mAutoAlignGrid.Opacity = 1.0;
			if (!FeatureManager.Instance.IsOperationsSyncEnabled)
			{
				this.mSyncGrid.Visibility = Visibility.Collapsed;
			}
			else if (BlueStacksUIUtils.sSyncInvolvedInstances.Contains(this.ParentWindow.mVmName) && !this.ParentWindow.mIsSyncMaster)
			{
				this.mSyncGrid.PreviewMouseLeftButtonUp -= this.SyncGrid_MouseLeftButtonUp;
				this.mSyncGrid.MouseEnter -= this.Grid_MouseEnter;
				this.mSyncGrid.Opacity = 0.5;
			}
			else
			{
				this.mSyncGrid.PreviewMouseLeftButtonUp -= this.SyncGrid_MouseLeftButtonUp;
				this.mSyncGrid.PreviewMouseLeftButtonUp += this.SyncGrid_MouseLeftButtonUp;
				this.mSyncGrid.MouseEnter -= this.Grid_MouseEnter;
				this.mSyncGrid.MouseEnter += this.Grid_MouseEnter;
				this.mSyncGrid.Opacity = 1.0;
			}
			this.SectionsTagVisibilityToggling();
		}

		// Token: 0x0600153A RID: 5434 RVA: 0x0000E794 File Offset: 0x0000C994
		internal void SectionsTagVisibilityToggling()
		{
			this.mCustomiseSectionTag.Visibility = (PreferenceDropDownControl.CheckSectionTagVisibility(this.mCustomiseSection) ? Visibility.Visible : Visibility.Collapsed);
			this.mHelpandsupportSectionTag.Visibility = (PreferenceDropDownControl.CheckSectionTagVisibility(this.mHelpandsupportSection) ? Visibility.Visible : Visibility.Collapsed);
		}

		// Token: 0x0600153B RID: 5435 RVA: 0x0007F490 File Offset: 0x0007D690
		private static bool CheckSectionTagVisibility(Grid sectionGrid)
		{
			using (IEnumerator enumerator = sectionGrid.Children.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if ((((UIElement)enumerator.Current) as Grid).Visibility == Visibility.Visible)
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x0600153C RID: 5436 RVA: 0x00006C7E File Offset: 0x00004E7E
		private void Grid_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x0600153D RID: 5437 RVA: 0x00005A31 File Offset: 0x00003C31
		private void Grid_MouseLeave(object sender, MouseEventArgs e)
		{
			(sender as Grid).Background = Brushes.Transparent;
		}

		// Token: 0x0600153E RID: 5438 RVA: 0x0007F4F4 File Offset: 0x0007D6F4
		private void EngineSettingGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked settings button");
			this.ParentWindow.mTopBar.mSettingsMenuPopup.IsOpen = false;
			this.ParentWindow.mCommonHandler.LaunchSettingsWindow();
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "Settings", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x0600153F RID: 5439 RVA: 0x0007F570 File Offset: 0x0007D770
		private void ReportProblemGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked report problem button");
			using (Process process = new Process())
			{
				process.StartInfo.Arguments = "-vmname:" + this.ParentWindow.mVmName;
				process.StartInfo.FileName = System.IO.Path.Combine(RegistryStrings.InstallDir, "HD-LogCollector.exe");
				process.Start();
			}
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "ReportProblem", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06001540 RID: 5440 RVA: 0x0007F628 File Offset: 0x0007D828
		private void LogoutButtonGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked logout button");
			if (this.ParentWindow.mGuestBootCompleted)
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_LOGOUT_BLUESTACKS3", "");
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_REMOVE_GOOGLE_ACCOUNT", "");
				customMessageWindow.AddButton(ButtonColors.Red, "STRING_LOGOUT_BUTTON", this.LogoutConfirmationResetAccountAcceptedHandler, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
				ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "Logout", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
			}
		}

		// Token: 0x06001541 RID: 5441 RVA: 0x0000E7CE File Offset: 0x0000C9CE
		private void PreferenceDropDownControl_CloseWindowConfirmationResetAccountAcceptedHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mAppHandler.SendRequestToRemoveAccountAndCloseWindowASync(false);
		}

		// Token: 0x06001542 RID: 5442 RVA: 0x0007F710 File Offset: 0x0007D910
		private void SpeedUpBstGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked SpeedUp BlueStacks button");
			SpeedUpBlueStacks speedUpBlueStacks = new SpeedUpBlueStacks();
			if (this.ParentWindow.mTopBar.mSnailMode == PerformanceState.VtxDisabled)
			{
				speedUpBlueStacks.mEnableVt.Visibility = Visibility.Visible;
			}
			speedUpBlueStacks.mUpgradeComputer.Visibility = Visibility.Visible;
			speedUpBlueStacks.mPowerPlan.Visibility = Visibility.Visible;
			speedUpBlueStacks.mConfigureAntivirus.Visibility = Visibility.Visible;
			new ContainerWindow(this.ParentWindow, speedUpBlueStacks, 640.0, 440.0, false, true);
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "SpeedUpBlueStacks", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06001543 RID: 5443 RVA: 0x0007F7D0 File Offset: 0x0007D9D0
		private void mHelpCenterGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			string helpCenterUrl = BlueStacksUIUtils.GetHelpCenterUrl();
			this.ParentWindow.mTopBar.mSettingsMenuPopup.IsOpen = false;
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "HelpCentre", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				Process.Start(helpCenterUrl);
				return;
			}
			this.ParentWindow.mTopBar.mAppTabButtons.AddWebTab(helpCenterUrl, "STRING_FEEDBACK", "help_center", true, "FEEDBACK_TEXT", false);
		}

		// Token: 0x06001544 RID: 5444 RVA: 0x0007F874 File Offset: 0x0007DA74
		private void mChangeSkinGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			ChangeThemeWindow control = new ChangeThemeWindow(this.ParentWindow);
			int num = 504;
			int num2 = 652;
			new ContainerWindow(this.ParentWindow, control, (double)num2, (double)num, false, true);
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "ChangeSkin", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06001545 RID: 5445 RVA: 0x0000E7E1 File Offset: 0x0000C9E1
		private void NotificationPopup_Opened(object sender, EventArgs e)
		{
			this.dummyGridForSize2.Visibility = Visibility.Visible;
		}

		// Token: 0x06001546 RID: 5446 RVA: 0x0000E7EF File Offset: 0x0000C9EF
		private void NotificationPopup_Closed(object sender, EventArgs e)
		{
			this.mChangeWallpaperGrid.Background = Brushes.Transparent;
		}

		// Token: 0x06001547 RID: 5447 RVA: 0x0007F8EC File Offset: 0x0007DAEC
		private void ChooseNewGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mTopBar.mSettingsMenuPopup.IsOpen = false;
			if (RegistryManager.Instance.IsPremium)
			{
				ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "ChangeWallPaperButton", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, "Premium", null);
				HomeApp.ChooseWallpaper();
				return;
			}
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "ChangeWallPaperButton", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, "NonPremium", null);
			string str = "/bluestacks_account?extra=section:plans";
			string text = WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + str);
			text += "&email=";
			text += RegistryManager.Instance.RegisteredEmail;
			text += "&token=";
			text += RegistryManager.Instance.Token;
			this.ParentWindow.mTopBar.mAppTabButtons.AddWebTab(text, "STRING_ACCOUNT", "account_tab", true, "account_tab", false);
		}

		// Token: 0x06001548 RID: 5448 RVA: 0x0007FA20 File Offset: 0x0007DC20
		private void SetDefaultGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (File.Exists(HomeApp.BackgroundImagePath))
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_LBL_RESTORE_DEFAULT", "");
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_RESTORE_DEFAULT_WALLPAPER", "");
				customMessageWindow.AddButton(ButtonColors.Red, "STRING_RESTORE_BUTTON", this.RestoreDefaultConfirmationClicked, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
			}
		}

		// Token: 0x06001549 RID: 5449 RVA: 0x0007FAC0 File Offset: 0x0007DCC0
		private void mChangeWallpaperGrid_MouseEnter(object sender, MouseEventArgs e)
		{
			if (File.Exists(HomeApp.BackgroundImagePath))
			{
				this.mChangeWallpaperGrid.MouseLeftButtonUp -= this.ChooseNewGrid_MouseLeftButtonUp;
				this.mWallpaperPopup.PlacementTarget = this.mChooseNewGrid;
				this.mChooseWallpaperPopup.IsOpen = false;
				this.mChooseWallpaperPopup.IsOpen = true;
			}
			else
			{
				if (!RegistryManager.Instance.IsPremium)
				{
					this.mWallpaperPopup.PlacementTarget = this.mChangeWallpaperGrid;
					this.mWallpaperPopup.IsOpen = false;
					this.mWallpaperPopup.IsOpen = true;
				}
				this.mChangeWallpaperGrid.MouseLeftButtonUp -= this.ChooseNewGrid_MouseLeftButtonUp;
				this.mChangeWallpaperGrid.MouseLeftButtonUp += this.ChooseNewGrid_MouseLeftButtonUp;
			}
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x0600154A RID: 5450 RVA: 0x0007FB94 File Offset: 0x0007DD94
		private void mChangeWallpaperGrid_MouseLeave(object sender, MouseEventArgs e)
		{
			(sender as Grid).Background = Brushes.Transparent;
			if (!this.mChangeWallpaperGrid.IsMouseOver && !this.mChooseWallpaperPopupGrid.IsMouseOver && !this.mWallpaperPopupGrid.IsMouseOver)
			{
				this.mChooseWallpaperPopup.IsOpen = false;
				this.mWallpaperPopup.IsOpen = false;
			}
		}

		// Token: 0x0600154B RID: 5451 RVA: 0x0000E801 File Offset: 0x0000CA01
		private void ChooseNewGrid_MouseEnter(object sender, MouseEventArgs e)
		{
			if (!RegistryManager.Instance.IsPremium)
			{
				this.mWallpaperPopup.IsOpen = true;
			}
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x0600154C RID: 5452 RVA: 0x0000E830 File Offset: 0x0000CA30
		private void ChooseNewGrid_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.mChooseNewGrid.IsMouseOver && !this.mWallpaperPopupGrid.IsMouseOver)
			{
				this.mWallpaperPopup.IsOpen = false;
			}
			(sender as Grid).Background = Brushes.Transparent;
		}

		// Token: 0x0600154D RID: 5453 RVA: 0x0000E868 File Offset: 0x0000CA68
		private void SetDefaultGrid_MouseLeave(object sender, MouseEventArgs e)
		{
			if (File.Exists(HomeApp.BackgroundImagePath))
			{
				(sender as Grid).Background = Brushes.Transparent;
			}
		}

		// Token: 0x0600154E RID: 5454 RVA: 0x0000E886 File Offset: 0x0000CA86
		private void SetDefaultGrid_MouseEnter(object sender, MouseEventArgs e)
		{
			if (File.Exists(HomeApp.BackgroundImagePath))
			{
				BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
			}
		}

		// Token: 0x0600154F RID: 5455 RVA: 0x0000E8A9 File Offset: 0x0000CAA9
		private void mWallpaperPopup_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.mChooseNewGrid.IsMouseOver)
			{
				this.mWallpaperPopup.IsOpen = false;
			}
		}

		// Token: 0x06001550 RID: 5456 RVA: 0x0007FBF0 File Offset: 0x0007DDF0
		private void mChooseWallpaperPopup_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.mChangeWallpaperGrid.IsMouseOver && !this.mChooseWallpaperPopupGrid.IsMouseOver && !this.mWallpaperPopupGrid.IsMouseOver)
			{
				this.mChooseWallpaperPopup.IsOpen = false;
				this.mWallpaperPopup.IsOpen = false;
			}
		}

		// Token: 0x06001551 RID: 5457 RVA: 0x0007FC3C File Offset: 0x0007DE3C
		private void mUpgradeToFullBlueStacks_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			string text = LocaleStrings.GetLocalizedString("STRING_UPGRADE_TO_STANDARD_BST");
			string text2 = string.Format(CultureInfo.InvariantCulture, "{0} {1}", new object[]
			{
				LocaleStrings.GetLocalizedString("STRING_CONTINUING_WILL_UPGRADE_TO_STD_BST"),
				LocaleStrings.GetLocalizedString("STRING_LAUNCH_BLUESTACKS_FROM_DESK_SHORTCUT")
			});
			text = text.Replace(GameConfig.Instance.AppName, "BlueStacks");
			text2 = text2.Replace(GameConfig.Instance.AppName, "BlueStacks");
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.AddButton(ButtonColors.Blue, "STRING_YES", new EventHandler(this.UpgradeToFullBstHandler), null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_NO", null, null, false, null);
			BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, text, "");
			BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, text2, "");
			this.ParentWindow.ShowDimOverlay(null);
			customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
			customMessageWindow.ShowDialog();
			this.ParentWindow.HideDimOverlay();
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "UpgradeBlueStacks", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06001552 RID: 5458 RVA: 0x0007FD70 File Offset: 0x0007DF70
		private void UpgradeToFullBstHandler(object sender, EventArgs e)
		{
			this.ParentWindow.mWelcomeTab.mBackground.Visibility = Visibility.Visible;
			this.ParentWindow.ShowDimOverlayForUpgrade();
			using (BackgroundWorker backgroundWorker = new BackgroundWorker())
			{
				backgroundWorker.DoWork += this.MBWUpdateToFullVersion_DoWork;
				backgroundWorker.RunWorkerCompleted += this.MBWUpdateToFullVersion_RunWorkerCompleted;
				backgroundWorker.RunWorkerAsync();
			}
		}

		// Token: 0x06001553 RID: 5459 RVA: 0x0000E8C4 File Offset: 0x0000CAC4
		private void MBWUpdateToFullVersion_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			this.ParentWindow.MainWindow_CloseWindowConfirmationAcceptedHandler(null, null);
		}

		// Token: 0x06001554 RID: 5460 RVA: 0x0000E8D3 File Offset: 0x0000CAD3
		private void MBWUpdateToFullVersion_DoWork(object sender, DoWorkEventArgs e)
		{
			Utils.UpgradeToFullVersionAndCreateBstShortcut(true);
		}

		// Token: 0x06001555 RID: 5461 RVA: 0x0007FDEC File Offset: 0x0007DFEC
		private void SyncGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mTopBar.mSettingsMenuPopup.IsOpen = false;
			this.ParentWindow.ShowSynchronizerWindow();
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "OperationSync", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06001556 RID: 5462 RVA: 0x0007FE58 File Offset: 0x0007E058
		private void mUpgradeBluestacksStatus_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mUpgradeBluestacksStatusTextBlock.Text.ToString(CultureInfo.InvariantCulture).Equals(LocaleStrings.GetLocalizedString("STRING_DOWNLOAD_UPDATE"), StringComparison.OrdinalIgnoreCase))
			{
				ClientStats.SendBluestacksUpdaterUIStatsAsync(ClientStatsEvent.SettingsGearDwnld, "");
				UpdatePrompt updatePrompt = new UpdatePrompt(BlueStacksUpdater.sBstUpdateData)
				{
					Height = 215.0,
					Width = 400.0
				};
				new ContainerWindow(this.ParentWindow, updatePrompt, (double)((int)updatePrompt.Width), (double)((int)updatePrompt.Height), false, true);
				return;
			}
			if (this.mUpgradeBluestacksStatusTextBlock.Text.ToString(CultureInfo.InvariantCulture).Equals(LocaleStrings.GetLocalizedString("STRING_DOWNLOADING_UPDATE"), StringComparison.OrdinalIgnoreCase))
			{
				this.ParentWindow.mTopBar.mSettingsMenuPopup.IsOpen = false;
				BlueStacksUpdater.ShowDownloadProgress();
				return;
			}
			if (this.mUpgradeBluestacksStatusTextBlock.Text.ToString(CultureInfo.InvariantCulture).Equals(LocaleStrings.GetLocalizedString("STRING_INSTALL_UPDATE"), StringComparison.OrdinalIgnoreCase))
			{
				this.ParentWindow.ShowInstallPopup();
			}
		}

		// Token: 0x06001557 RID: 5463 RVA: 0x0007FF5C File Offset: 0x0007E15C
		internal void ToggleStreamingMode(bool enable)
		{
			if (enable)
			{
				this.mStreaminModeToggleButton.ImageName = this.mStreaminModeToggleButton.ImageName.Replace("_off", "_on");
				return;
			}
			this.mStreaminModeToggleButton.ImageName = this.mStreaminModeToggleButton.ImageName.Replace("_on", "_off");
		}

		// Token: 0x06001558 RID: 5464 RVA: 0x0007FFB8 File Offset: 0x0007E1B8
		private void AutoAlign_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mTopBar.mSettingsMenuPopup.IsOpen = false;
			CommonHandlers.ArrangeWindow();
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "AutoAlign", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x06001559 RID: 5465 RVA: 0x00080020 File Offset: 0x0007E220
		private void PinToTop_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			CustomPictureBox customPictureBox = sender as CustomPictureBox;
			if (customPictureBox.ImageName.Contains("_off"))
			{
				customPictureBox.ImageName = "toggle_on";
				this.ParentWindow.EngineInstanceRegistry.IsClientOnTop = true;
				this.ParentWindow.Topmost = true;
				ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "PinToTopOn", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
				return;
			}
			customPictureBox.ImageName = "toggle_off";
			this.ParentWindow.EngineInstanceRegistry.IsClientOnTop = false;
			this.ParentWindow.Topmost = false;
			ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "PinToTopOff", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
		}

		// Token: 0x0600155A RID: 5466 RVA: 0x00080114 File Offset: 0x0007E314
		private void Streaming_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			CustomPictureBox customPictureBox = sender as CustomPictureBox;
			if (customPictureBox.ImageName.Contains("_off"))
			{
				customPictureBox.ImageName = "toggle_on";
				this.ParentWindow.mFrontendHandler.ToggleStreamingMode(true);
				ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "StreamingModeStart", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
			}
			else
			{
				customPictureBox.ImageName = "toggle_off";
				this.ParentWindow.mFrontendHandler.ToggleStreamingMode(false);
				ClientStats.SendMiscellaneousStatsAsync("hamburgerMenu", RegistryManager.Instance.UserGuid, "StreamingModeStop", "MouseClick", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
			}
			this.ParentWindow.mTopBar.mSettingsMenuPopup.IsOpen = false;
		}

		// Token: 0x0600155B RID: 5467 RVA: 0x0000E8DB File Offset: 0x0000CADB
		private void TextBlock_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (sender != null)
			{
				(sender as TextBlock).SetTextblockTooltip();
			}
		}

		// Token: 0x0600155C RID: 5468 RVA: 0x00080208 File Offset: 0x0007E408
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/preferencedropdowncontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600155D RID: 5469 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600155E RID: 5470 RVA: 0x00080238 File Offset: 0x0007E438
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 2:
				this.EngineSettingGrid = (Grid)target;
				this.EngineSettingGrid.MouseEnter += this.Grid_MouseEnter;
				this.EngineSettingGrid.MouseLeave += this.Grid_MouseLeave;
				this.EngineSettingGrid.PreviewMouseLeftButtonUp += this.EngineSettingGrid_MouseLeftButtonUp;
				return;
			case 3:
				this.mEngineSettingsButtonImage = (CustomPictureBox)target;
				return;
			case 4:
				this.mSettingsBtnNotification = (Ellipse)target;
				return;
			case 5:
				this.mPinToTopGrid = (Grid)target;
				this.mPinToTopGrid.MouseEnter += this.Grid_MouseEnter;
				this.mPinToTopGrid.MouseLeave += this.Grid_MouseLeave;
				return;
			case 6:
				this.mPinToTopImage = (CustomPictureBox)target;
				return;
			case 7:
				this.mPinToTopToggleButton = (CustomPictureBox)target;
				this.mPinToTopToggleButton.PreviewMouseLeftButtonUp += this.PinToTop_MouseLeftButtonUp;
				return;
			case 8:
				this.mStreamingMode = (Grid)target;
				this.mStreamingMode.MouseEnter += this.Grid_MouseEnter;
				this.mStreamingMode.MouseLeave += this.Grid_MouseLeave;
				return;
			case 9:
				this.mStreamingModeImage = (CustomPictureBox)target;
				return;
			case 10:
				this.mStreaminModeToggleButton = (CustomPictureBox)target;
				this.mStreaminModeToggleButton.PreviewMouseLeftButtonUp += this.Streaming_MouseLeftButtonUp;
				return;
			case 11:
				this.mMultiInstanceSectionTag = (Grid)target;
				return;
			case 12:
				this.mMultiInstanceSectionBorderLine = (Separator)target;
				return;
			case 13:
				this.mMultiInstanceSection = (Grid)target;
				return;
			case 14:
				this.mSyncGrid = (Grid)target;
				this.mSyncGrid.MouseEnter += this.Grid_MouseEnter;
				this.mSyncGrid.MouseLeave += this.Grid_MouseLeave;
				this.mSyncGrid.PreviewMouseLeftButtonUp += this.SyncGrid_MouseLeftButtonUp;
				return;
			case 15:
				this.mSyncOperationsImage = (CustomPictureBox)target;
				return;
			case 16:
				this.mAutoAlignGrid = (Grid)target;
				this.mAutoAlignGrid.MouseEnter += this.Grid_MouseEnter;
				this.mAutoAlignGrid.MouseLeave += this.Grid_MouseLeave;
				this.mAutoAlignGrid.PreviewMouseLeftButtonUp += this.AutoAlign_MouseLeftButtonUp;
				return;
			case 17:
				this.mAutoAlignImage = (CustomPictureBox)target;
				return;
			case 18:
				this.mUpgradeBluestacksStatus = (Grid)target;
				this.mUpgradeBluestacksStatus.MouseEnter += this.Grid_MouseEnter;
				this.mUpgradeBluestacksStatus.MouseLeave += this.Grid_MouseLeave;
				this.mUpgradeBluestacksStatus.MouseLeftButtonUp += this.mUpgradeBluestacksStatus_MouseLeftButtonUp;
				return;
			case 19:
				this.mUpdateImage = (CustomPictureBox)target;
				return;
			case 20:
				this.mUpgradeBluestacksStatusTextBlock = (TextBlock)target;
				return;
			case 21:
				this.mUpdateDownloadProgressPercentage = (Label)target;
				return;
			case 22:
				this.mUpgradeToFullBlueStacks = (Grid)target;
				this.mUpgradeToFullBlueStacks.MouseEnter += this.Grid_MouseEnter;
				this.mUpgradeToFullBlueStacks.MouseLeave += this.Grid_MouseLeave;
				this.mUpgradeToFullBlueStacks.MouseLeftButtonUp += this.mUpgradeToFullBlueStacks_MouseLeftButtonUp;
				return;
			case 23:
				this.mUpgradeToFullTextBlock = (TextBlock)target;
				return;
			case 24:
				this.mLogoutButtonGrid = (Grid)target;
				this.mLogoutButtonGrid.MouseEnter += this.Grid_MouseEnter;
				this.mLogoutButtonGrid.MouseLeave += this.Grid_MouseLeave;
				this.mLogoutButtonGrid.MouseLeftButtonUp += this.LogoutButtonGrid_MouseLeftButtonUp;
				return;
			case 25:
				this.mCustomiseSectionTag = (Grid)target;
				return;
			case 26:
				this.mCustomiseSectionBorderLine = (Separator)target;
				return;
			case 27:
				this.mCustomiseSection = (Grid)target;
				return;
			case 28:
				this.mChangeSkinGrid = (Grid)target;
				this.mChangeSkinGrid.MouseEnter += this.Grid_MouseEnter;
				this.mChangeSkinGrid.MouseLeave += this.Grid_MouseLeave;
				this.mChangeSkinGrid.PreviewMouseLeftButtonUp += this.mChangeSkinGrid_MouseLeftButtonUp;
				return;
			case 29:
				this.mChangeSkinImage = (CustomPictureBox)target;
				return;
			case 30:
				this.mChangeWallpaperGrid = (Grid)target;
				this.mChangeWallpaperGrid.MouseEnter += this.mChangeWallpaperGrid_MouseEnter;
				this.mChangeWallpaperGrid.MouseLeave += this.mChangeWallpaperGrid_MouseLeave;
				return;
			case 31:
				this.mChangeWallpaperImage = (CustomPictureBox)target;
				return;
			case 32:
				this.mHelpandsupportSectionTag = (Grid)target;
				return;
			case 33:
				this.mHelpAndSupportSectionBorderLine = (Separator)target;
				return;
			case 34:
				this.mHelpandsupportSection = (Grid)target;
				return;
			case 35:
				this.ReportProblemGrid = (Grid)target;
				this.ReportProblemGrid.MouseEnter += this.Grid_MouseEnter;
				this.ReportProblemGrid.MouseLeave += this.Grid_MouseLeave;
				this.ReportProblemGrid.MouseLeftButtonUp += this.ReportProblemGrid_MouseLeftButtonUp;
				return;
			case 36:
				this.mHelpCenterGrid = (Grid)target;
				this.mHelpCenterGrid.MouseEnter += this.Grid_MouseEnter;
				this.mHelpCenterGrid.MouseLeave += this.Grid_MouseLeave;
				this.mHelpCenterGrid.PreviewMouseLeftButtonUp += this.mHelpCenterGrid_MouseLeftButtonUp;
				return;
			case 37:
				this.mHelpCenterImage = (CustomPictureBox)target;
				return;
			case 38:
				this.mSpeedUpBstGrid = (Grid)target;
				this.mSpeedUpBstGrid.MouseEnter += this.Grid_MouseEnter;
				this.mSpeedUpBstGrid.MouseLeave += this.Grid_MouseLeave;
				this.mSpeedUpBstGrid.PreviewMouseLeftButtonUp += this.SpeedUpBstGrid_MouseLeftButtonUp;
				return;
			case 39:
				this.mSpeedUpBstImage = (CustomPictureBox)target;
				return;
			case 40:
				this.mWallpaperPopup = (CustomPopUp)target;
				return;
			case 41:
				this.mWallpaperPopupGrid = (Grid)target;
				return;
			case 42:
				this.dummyGridForSize = (Grid)target;
				return;
			case 43:
				this.mWallpaperPopupBorder = (Border)target;
				return;
			case 44:
				this.mMaskBorder = (Border)target;
				return;
			case 45:
				this.mTitleText = (TextBlock)target;
				return;
			case 46:
				this.mBodyText = (TextBlock)target;
				return;
			case 47:
				this.RightArrow = (System.Windows.Shapes.Path)target;
				return;
			case 48:
				this.mChooseWallpaperPopup = (CustomPopUp)target;
				return;
			case 49:
				this.mChooseWallpaperPopupGrid = (Grid)target;
				return;
			case 50:
				this.dummyGridForSize2 = (Grid)target;
				return;
			case 51:
				this.mPopupGridBorder = (Border)target;
				return;
			case 52:
				this.mMaskBorder2 = (Border)target;
				return;
			case 53:
				this.mChooseNewGrid = (Grid)target;
				this.mChooseNewGrid.MouseEnter += this.ChooseNewGrid_MouseEnter;
				this.mChooseNewGrid.MouseLeave += this.ChooseNewGrid_MouseLeave;
				this.mChooseNewGrid.MouseLeftButtonUp += this.ChooseNewGrid_MouseLeftButtonUp;
				return;
			case 54:
				this.mSetDefaultGrid = (Grid)target;
				this.mSetDefaultGrid.MouseEnter += this.SetDefaultGrid_MouseEnter;
				this.mSetDefaultGrid.MouseLeave += this.SetDefaultGrid_MouseLeave;
				this.mSetDefaultGrid.MouseLeftButtonUp += this.SetDefaultGrid_MouseLeftButtonUp;
				return;
			case 55:
				this.mRestoreDefaultText = (TextBlock)target;
				return;
			case 56:
				this.mRightArrow = (System.Windows.Shapes.Path)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0600155F RID: 5471 RVA: 0x000809F4 File Offset: 0x0007EBF4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				EventSetter eventSetter = new EventSetter();
				eventSetter.Event = FrameworkElement.SizeChangedEvent;
				eventSetter.Handler = new SizeChangedEventHandler(this.TextBlock_SizeChanged);
				((Style)target).Setters.Add(eventSetter);
			}
		}

		// Token: 0x04000D97 RID: 3479
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid EngineSettingGrid;

		// Token: 0x04000D98 RID: 3480
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mEngineSettingsButtonImage;

		// Token: 0x04000D99 RID: 3481
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Ellipse mSettingsBtnNotification;

		// Token: 0x04000D9A RID: 3482
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mPinToTopGrid;

		// Token: 0x04000D9B RID: 3483
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mPinToTopImage;

		// Token: 0x04000D9C RID: 3484
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mPinToTopToggleButton;

		// Token: 0x04000D9D RID: 3485
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mStreamingMode;

		// Token: 0x04000D9E RID: 3486
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mStreamingModeImage;

		// Token: 0x04000D9F RID: 3487
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mStreaminModeToggleButton;

		// Token: 0x04000DA0 RID: 3488
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mMultiInstanceSectionTag;

		// Token: 0x04000DA1 RID: 3489
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Separator mMultiInstanceSectionBorderLine;

		// Token: 0x04000DA2 RID: 3490
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mMultiInstanceSection;

		// Token: 0x04000DA3 RID: 3491
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mSyncGrid;

		// Token: 0x04000DA4 RID: 3492
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mSyncOperationsImage;

		// Token: 0x04000DA5 RID: 3493
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mAutoAlignGrid;

		// Token: 0x04000DA6 RID: 3494
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mAutoAlignImage;

		// Token: 0x04000DA7 RID: 3495
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mUpgradeBluestacksStatus;

		// Token: 0x04000DA8 RID: 3496
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mUpdateImage;

		// Token: 0x04000DA9 RID: 3497
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mUpgradeBluestacksStatusTextBlock;

		// Token: 0x04000DAA RID: 3498
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Label mUpdateDownloadProgressPercentage;

		// Token: 0x04000DAB RID: 3499
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mUpgradeToFullBlueStacks;

		// Token: 0x04000DAC RID: 3500
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mUpgradeToFullTextBlock;

		// Token: 0x04000DAD RID: 3501
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mLogoutButtonGrid;

		// Token: 0x04000DAE RID: 3502
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mCustomiseSectionTag;

		// Token: 0x04000DAF RID: 3503
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Separator mCustomiseSectionBorderLine;

		// Token: 0x04000DB0 RID: 3504
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mCustomiseSection;

		// Token: 0x04000DB1 RID: 3505
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mChangeSkinGrid;

		// Token: 0x04000DB2 RID: 3506
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mChangeSkinImage;

		// Token: 0x04000DB3 RID: 3507
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mChangeWallpaperGrid;

		// Token: 0x04000DB4 RID: 3508
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mChangeWallpaperImage;

		// Token: 0x04000DB5 RID: 3509
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mHelpandsupportSectionTag;

		// Token: 0x04000DB6 RID: 3510
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Separator mHelpAndSupportSectionBorderLine;

		// Token: 0x04000DB7 RID: 3511
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mHelpandsupportSection;

		// Token: 0x04000DB8 RID: 3512
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid ReportProblemGrid;

		// Token: 0x04000DB9 RID: 3513
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mHelpCenterGrid;

		// Token: 0x04000DBA RID: 3514
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mHelpCenterImage;

		// Token: 0x04000DBB RID: 3515
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mSpeedUpBstGrid;

		// Token: 0x04000DBC RID: 3516
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mSpeedUpBstImage;

		// Token: 0x04000DBD RID: 3517
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mWallpaperPopup;

		// Token: 0x04000DBE RID: 3518
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mWallpaperPopupGrid;

		// Token: 0x04000DBF RID: 3519
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid dummyGridForSize;

		// Token: 0x04000DC0 RID: 3520
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mWallpaperPopupBorder;

		// Token: 0x04000DC1 RID: 3521
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder;

		// Token: 0x04000DC2 RID: 3522
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mTitleText;

		// Token: 0x04000DC3 RID: 3523
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mBodyText;

		// Token: 0x04000DC4 RID: 3524
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal System.Windows.Shapes.Path RightArrow;

		// Token: 0x04000DC5 RID: 3525
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mChooseWallpaperPopup;

		// Token: 0x04000DC6 RID: 3526
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mChooseWallpaperPopupGrid;

		// Token: 0x04000DC7 RID: 3527
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid dummyGridForSize2;

		// Token: 0x04000DC8 RID: 3528
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mPopupGridBorder;

		// Token: 0x04000DC9 RID: 3529
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder2;

		// Token: 0x04000DCA RID: 3530
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mChooseNewGrid;

		// Token: 0x04000DCB RID: 3531
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mSetDefaultGrid;

		// Token: 0x04000DCC RID: 3532
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mRestoreDefaultText;

		// Token: 0x04000DCD RID: 3533
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal System.Windows.Shapes.Path mRightArrow;

		// Token: 0x04000DCE RID: 3534
		private bool _contentLoaded;
	}
}
