﻿using System;
using System.Runtime.InteropServices;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000071 RID: 113
	internal static class NativeMethods
	{
		// Token: 0x06000488 RID: 1160
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		[return: MarshalAs(UnmanagedType.Bool)]
		internal static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

		// Token: 0x06000489 RID: 1161
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);

		// Token: 0x0600048A RID: 1162
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern IntPtr SetWindowsHookEx(int idHook, GlobalKeyBoardMouseHooks.LowLevelMouseProc lpfn, IntPtr hMod, uint dwThreadId);

		// Token: 0x0600048B RID: 1163
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		[return: MarshalAs(UnmanagedType.Bool)]
		internal static extern bool UnhookWindowsHookEx(IntPtr hhk);

		// Token: 0x0600048C RID: 1164
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

		// Token: 0x0600048D RID: 1165
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern IntPtr GetModuleHandle(string lpModuleName);

		// Token: 0x0600048E RID: 1166
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern IntPtr SetWindowsHookEx(int idHook, GlobalKeyBoardMouseHooks.LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

		// Token: 0x0600048F RID: 1167
		[DllImport("User32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern uint GetRawInputData(IntPtr hRawInput, uint uiCommand, IntPtr pData, ref uint pcbSize, uint cbSizeHeader);

		// Token: 0x06000490 RID: 1168
		[DllImport("User32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern bool RegisterRawInputDevices(RawInputClass.RAWINPUTDEVICE[] pRawInputDevice, uint uiNumDevices, uint cbSize);

		// Token: 0x06000491 RID: 1169
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		[return: MarshalAs(UnmanagedType.Bool)]
		internal static extern bool GetCursorPos(ref NativeMethods.Win32Point pt);

		// Token: 0x06000492 RID: 1170
		[DllImport("winmm.dll", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern int waveOutGetVolume(IntPtr h, out uint dwVolume);

		// Token: 0x06000493 RID: 1171
		[DllImport("winmm.dll", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern int waveOutSetVolume(IntPtr h, uint dwVolume);

		// Token: 0x06000494 RID: 1172
		[DllImport("urlmon.dll", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern uint FindMimeFromData(uint pBC, [MarshalAs(UnmanagedType.LPStr)] string pwzUrl, [MarshalAs(UnmanagedType.LPArray)] byte[] pBuffer, uint cbSize, [MarshalAs(UnmanagedType.LPStr)] string pwzMimeProposed, uint dwMimeFlags, out uint ppwzMimeOut, uint dwReserverd);

		// Token: 0x06000495 RID: 1173
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern IntPtr SendMessage(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

		// Token: 0x06000496 RID: 1174
		[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern IntPtr MonitorFromWindow(IntPtr handle, int flags);

		// Token: 0x06000497 RID: 1175
		[DllImport("User32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern bool GetMonitorInfo(IntPtr hmonitor, [In] [Out] WindowWndProcHandler.MONITORINFOEX info);

		// Token: 0x06000498 RID: 1176
		[DllImport("shell32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern IntPtr SHAppBarMessage(int msg, ref WindowWndProcHandler.APPBARDATA data);

		// Token: 0x02000072 RID: 114
		internal struct Win32Point
		{
			// Token: 0x0400026F RID: 623
			public int X;

			// Token: 0x04000270 RID: 624
			public int Y;
		}
	}
}
