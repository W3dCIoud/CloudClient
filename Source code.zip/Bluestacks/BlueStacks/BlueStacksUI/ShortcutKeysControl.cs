﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000AE RID: 174
	public class ShortcutKeysControl : UserControl, IComponentConnector
	{
		// Token: 0x060006E0 RID: 1760 RVA: 0x0002911C File Offset: 0x0002731C
		public ShortcutKeysControl(MainWindow window, SettingsWindow settingsWindow)
		{
			this.InitializeComponent();
			base.Visibility = Visibility.Hidden;
			this.ParentWindow = window;
			this.ParentSettingsWindow = settingsWindow;
			this.mShortcutKeyPanel = (this.mShortcutKeyScrollBar.Content as StackPanel);
			if (this.ParentWindow != null)
			{
				if (this.ParentWindow.mCommonHandler.mShortcutsConfigInstance != null)
				{
					this.AddShortcutKeyElements();
				}
				if (!string.IsNullOrEmpty(RegistryManager.Instance.UserDefinedShortcuts))
				{
					this.mRevertBtn.IsEnabled = true;
				}
				this.ParentWindow.mCommonHandler.ShortcutKeysChangedEvent += this.ShortcutKeysChangedEvent;
				this.ParentWindow.mCommonHandler.ShortcutKeysRefreshEvent += this.ShortcutKeysRefreshEvent;
			}
			this.mShortcutKeyScrollBar.ScrollChanged += BluestacksUIColor.ScrollBarScrollChanged;
		}

		// Token: 0x060006E1 RID: 1761 RVA: 0x000291F8 File Offset: 0x000273F8
		private void ShortcutKeysRefreshEvent()
		{
			IEnumerable<ShortcutKeyControlElement> enumerable = from ele in (from ele in this.mShortcutUIElements.SelectMany((KeyValuePair<string, Tuple<GroupBox, List<ShortcutKeyControlElement>>> x) => x.Value.Item2)
			group ele by ele.mShortcutKeyTextBox.Text into grp
			where grp.Count<ShortcutKeyControlElement>() == 1
			select grp).SelectMany((IGrouping<string, ShortcutKeyControlElement> grp) => grp)
			where !string.IsNullOrEmpty(ele.mShortcutKeyTextBox.Text)
			select ele;
			int num = 0;
			foreach (ShortcutKeyControlElement shortcutKeyControlElement in enumerable)
			{
				if (!shortcutKeyControlElement.mIsShortcutSameAsMacroShortcut)
				{
					shortcutKeyControlElement.mKeyInfoPopup.IsOpen = false;
					shortcutKeyControlElement.mShortcutKeyTextBox.InputTextValidity = TextValidityOptions.Success;
					num++;
				}
			}
			if (num == (from ele in this.mShortcutUIElements.SelectMany((KeyValuePair<string, Tuple<GroupBox, List<ShortcutKeyControlElement>>> x) => x.Value.Item2)
			where !string.IsNullOrEmpty(ele.mShortcutKeyTextBox.Text)
			select ele).Count<ShortcutKeyControlElement>())
			{
				this.ParentWindow.mCommonHandler.OnShortcutKeysChanged(true);
				return;
			}
			this.ParentWindow.mCommonHandler.OnShortcutKeysChanged(false);
		}

		// Token: 0x060006E2 RID: 1762 RVA: 0x00006792 File Offset: 0x00004992
		private void ShortcutKeysChangedEvent(bool isEnabled)
		{
			this.mSaveBtn.IsEnabled = isEnabled;
		}

		// Token: 0x060006E3 RID: 1763 RVA: 0x00029394 File Offset: 0x00027594
		private void AddShortcutKeyElements()
		{
			try
			{
				new List<ShortcutKeys>();
				this.mShortcutKeyPanel.Children.Clear();
				this.mShortcutUIElements.Clear();
				foreach (ShortcutKeys shortcutKeys in this.ParentWindow.mCommonHandler.mShortcutsConfigInstance.Shortcut)
				{
					this.CreateShortcutCategory(shortcutKeys.ShortcutCategory);
					this.AddElement(shortcutKeys);
				}
				foreach (KeyValuePair<string, Tuple<GroupBox, List<ShortcutKeyControlElement>>> keyValuePair in this.mShortcutUIElements)
				{
					this.mShortcutKeyPanel.Children.Add(keyValuePair.Value.Item1);
					foreach (FrameworkElement element in keyValuePair.Value.Item2)
					{
						(keyValuePair.Value.Item1.Content as StackPanel).Children.Add(element);
					}
				}
				this.mShortcutUIElements.First<KeyValuePair<string, Tuple<GroupBox, List<ShortcutKeyControlElement>>>>().Value.Item1.Margin = new Thickness(0.0);
			}
			catch (Exception ex)
			{
				Logger.Error("Error in adding shortcut elements: " + ex.ToString());
			}
		}

		// Token: 0x060006E4 RID: 1764 RVA: 0x00029568 File Offset: 0x00027768
		private void AddElement(ShortcutKeys ele)
		{
			ShortcutKeyControlElement shortcutKeyControlElement = new ShortcutKeyControlElement(this.ParentWindow, this.ParentSettingsWindow);
			BlueStacksUIBinding.Bind(shortcutKeyControlElement.mShortcutNameTextBlock, ele.ShortcutName, "");
			string[] array = ele.ShortcutKey.Split(new char[]
			{
				'+',
				' '
			}, StringSplitOptions.RemoveEmptyEntries);
			string text = string.Empty;
			foreach (string key in array)
			{
				text = text + LocaleStrings.GetLocalizedString(Constants.ImapLocaleStringsConstant + IMAPKeys.GetStringForUI(key)) + " + ";
			}
			this.mShortcutUIElements[ele.ShortcutCategory].Item2.Add(shortcutKeyControlElement);
			if (!string.IsNullOrEmpty(text))
			{
				shortcutKeyControlElement.mShortcutKeyTextBox.Text = text.Substring(0, text.Length - 3);
			}
			shortcutKeyControlElement.mUserDefinedConfigList = new List<ShortcutKeys>
			{
				ele
			};
			if (ele.ReadOnlyTextbox)
			{
				shortcutKeyControlElement.mShortcutKeyTextBox.IsEnabled = false;
			}
		}

		// Token: 0x060006E5 RID: 1765 RVA: 0x0002965C File Offset: 0x0002785C
		private void CreateShortcutCategory(string categoryName)
		{
			if (!this.mShortcutUIElements.ContainsKey(categoryName))
			{
				string localizedString = LocaleStrings.GetLocalizedString(categoryName);
				GroupBox groupBox = new GroupBox
				{
					Content = new StackPanel(),
					Header = localizedString,
					Tag = categoryName,
					Margin = new Thickness(0.0, 20.0, 0.0, 0.0),
					FontSize = 16.0
				};
				BlueStacksUIBinding.BindColor(groupBox, Control.ForegroundProperty, "SettingsWindowTabMenuItemLegendForeground");
				groupBox.BorderThickness = new Thickness(0.0);
				BlueStacksUIBinding.BindColor(new TextBlock
				{
					Text = localizedString,
					Tag = categoryName,
					FontStretch = FontStretches.ExtraExpanded,
					HorizontalAlignment = HorizontalAlignment.Center,
					Margin = new Thickness(0.0, 0.0, 0.0, 10.0),
					TextWrapping = TextWrapping.WrapWithOverflow
				}, TextBlock.ForegroundProperty, "SettingsWindowTabMenuItemLegendForeground");
				this.mShortcutUIElements.Add(categoryName, new Tuple<GroupBox, List<ShortcutKeyControlElement>>(groupBox, new List<ShortcutKeyControlElement>()));
			}
		}

		// Token: 0x060006E6 RID: 1766 RVA: 0x00029784 File Offset: 0x00027984
		private void SaveBtnClick(object sender, RoutedEventArgs e)
		{
			this.ParentWindow.mCommonHandler.SaveAndReloadShortcuts();
			this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_CHANGES_SAVED"));
			this.ParentSettingsWindow.mIsShortcutEdited = false;
			this.mSaveBtn.IsEnabled = false;
			this.mRevertBtn.IsEnabled = true;
			if (this.ParentWindow.mCommonHandler.mShortcutsConfigInstance.Shortcut != null)
			{
				this.RefreshShortcutConfigForUI();
			}
			ClientStats.SendMiscellaneousStatsAsync("Setting-save", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "Shortcut-Settings", "", null, this.ParentWindow.mVmName, null, null);
		}

		// Token: 0x060006E7 RID: 1767 RVA: 0x00029828 File Offset: 0x00027A28
		private void RefreshShortcutConfigForUI()
		{
			foreach (ShortcutKeys shortcutKeys in this.ParentWindow.mCommonHandler.mShortcutsConfigInstance.Shortcut)
			{
				foreach (ShortcutKeyControlElement shortcutKeyControlElement in this.mShortcutUIElements[shortcutKeys.ShortcutCategory].Item2)
				{
					ShortcutKeyControlElement shortcutKeyControlElement2 = shortcutKeyControlElement as ShortcutKeyControlElement;
					if (string.Equals(shortcutKeyControlElement2.mShortcutNameTextBlock.Text, LocaleStrings.GetLocalizedString(shortcutKeys.ShortcutName), StringComparison.InvariantCulture))
					{
						shortcutKeyControlElement2.mUserDefinedConfigList = new List<ShortcutKeys>
						{
							shortcutKeys
						};
					}
				}
			}
		}

		// Token: 0x060006E8 RID: 1768 RVA: 0x00029908 File Offset: 0x00027B08
		private void RevertBtnClick(object sender, RoutedEventArgs e)
		{
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_RESTORE_DEFAULTS");
			customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_RESTORE_SHORTCUTS");
			customMessageWindow.AddButton(ButtonColors.Red, LocaleStrings.GetLocalizedString("STRING_RESTORE_BUTTON"), delegate(object o, EventArgs evt)
			{
				this.RestoreDefaultShortcuts();
				this.mRevertBtn.IsEnabled = false;
			}, null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_CANCEL"), delegate(object o, EventArgs evt)
			{
			}, null, false, null);
			customMessageWindow.CloseButtonHandle(null, null);
			customMessageWindow.Owner = this.ParentWindow;
			customMessageWindow.ShowDialog();
		}

		// Token: 0x060006E9 RID: 1769 RVA: 0x000299B4 File Offset: 0x00027BB4
		private void RestoreDefaultShortcuts()
		{
			RegistryManager.Instance.UserDefinedShortcuts = string.Empty;
			this.ParentSettingsWindow.mIsShortcutEdited = false;
			CommonHandlers.ReloadShortcutsForAllInstances();
			if (this.ParentWindow.mCommonHandler.mShortcutsConfigInstance != null)
			{
				this.AddShortcutKeyElements();
			}
			this.mSaveBtn.IsEnabled = false;
			Stats.SendMiscellaneousStatsAsync("KeyboardShortcuts", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "shortcut_restore_default", null, null, null, null, null, "Android", 0);
		}

		// Token: 0x060006EA RID: 1770 RVA: 0x00029A34 File Offset: 0x00027C34
		private void AddToastPopup(string message)
		{
			try
			{
				if (this.mToastPopup == null)
				{
					this.mToastPopup = new CustomToastPopupControl(this);
				}
				this.mToastPopup.Init(this.ParentWindow, message, null, null, HorizontalAlignment.Center, VerticalAlignment.Bottom, null, 12, null, null, false);
				this.mToastPopup.ShowPopup(1.3);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in showing toast popup: " + ex.ToString());
			}
		}

		// Token: 0x060006EB RID: 1771 RVA: 0x00029AC0 File Offset: 0x00027CC0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/shortcutkeyscontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060006EC RID: 1772 RVA: 0x00029AF0 File Offset: 0x00027CF0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mShortcutKeyScrollBar = (ScrollViewer)target;
				return;
			case 2:
				this.mRevertBtn = (CustomButton)target;
				this.mRevertBtn.Click += this.RevertBtnClick;
				return;
			case 3:
				this.mSaveBtn = (CustomButton)target;
				this.mSaveBtn.Click += this.SaveBtnClick;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040003F9 RID: 1017
		private MainWindow ParentWindow;

		// Token: 0x040003FA RID: 1018
		private SettingsWindow ParentSettingsWindow;

		// Token: 0x040003FB RID: 1019
		private StackPanel mShortcutKeyPanel;

		// Token: 0x040003FC RID: 1020
		private CustomToastPopupControl mToastPopup;

		// Token: 0x040003FD RID: 1021
		private Dictionary<string, Tuple<GroupBox, List<ShortcutKeyControlElement>>> mShortcutUIElements = new Dictionary<string, Tuple<GroupBox, List<ShortcutKeyControlElement>>>();

		// Token: 0x040003FE RID: 1022
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ScrollViewer mShortcutKeyScrollBar;

		// Token: 0x040003FF RID: 1023
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mRevertBtn;

		// Token: 0x04000400 RID: 1024
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mSaveBtn;

		// Token: 0x04000401 RID: 1025
		private bool _contentLoaded;
	}
}
