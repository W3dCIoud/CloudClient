﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200013F RID: 319
	public class SchemeComboBox : UserControl, IComponentConnector
	{
		// Token: 0x17000210 RID: 528
		// (get) Token: 0x06000CCE RID: 3278 RVA: 0x00009C02 File Offset: 0x00007E02
		// (set) Token: 0x06000CCF RID: 3279 RVA: 0x00009C0A File Offset: 0x00007E0A
		public string mSelectedItem { get; set; }

		// Token: 0x17000211 RID: 529
		// (get) Token: 0x06000CD0 RID: 3280 RVA: 0x00009C13 File Offset: 0x00007E13
		// (set) Token: 0x06000CD1 RID: 3281 RVA: 0x00009C1B File Offset: 0x00007E1B
		public string SelectedItem
		{
			get
			{
				return this.mSelectedItem;
			}
			set
			{
				this.mSelectedItem = value;
			}
		}

		// Token: 0x06000CD2 RID: 3282 RVA: 0x00009C24 File Offset: 0x00007E24
		public SchemeComboBox()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000CD3 RID: 3283 RVA: 0x00009C32 File Offset: 0x00007E32
		private void OnRequestBringIntoView(object sender, RequestBringIntoViewEventArgs e)
		{
			if (Keyboard.IsKeyDown(Key.Down) || Keyboard.IsKeyDown(Key.Up))
			{
				return;
			}
			e.Handled = true;
		}

		// Token: 0x06000CD4 RID: 3284 RVA: 0x00006BEE File Offset: 0x00004DEE
		private void ComboBoxItem_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x06000CD5 RID: 3285 RVA: 0x00009C4E File Offset: 0x00007E4E
		private void ComboBoxItem_Selected(object sender, RoutedEventArgs e)
		{
			((ComboBoxSchemeControl)sender).mBookmarkImg.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000CD6 RID: 3286 RVA: 0x00009C61 File Offset: 0x00007E61
		private void NewProfile_MouseDown(object sender, MouseButtonEventArgs e)
		{
			KMManager.AddNewControlSchemeAndSelect(BlueStacksUIUtils.LastActivatedWindow, null, true);
			KMManager.CanvasWindow.ClearWindow();
		}

		// Token: 0x06000CD7 RID: 3287 RVA: 0x00009C79 File Offset: 0x00007E79
		private void NewProfile_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(this.NewProfile, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x06000CD8 RID: 3288 RVA: 0x00009C90 File Offset: 0x00007E90
		private void NewProfile_MouseLeave(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(this.NewProfile, Panel.BackgroundProperty, "ComboBoxBackgroundColor");
		}

		// Token: 0x06000CD9 RID: 3289 RVA: 0x00054A58 File Offset: 0x00052C58
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/schemecombobox.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000CDA RID: 3290 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000CDB RID: 3291 RVA: 0x00054A88 File Offset: 0x00052C88
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this._this = (SchemeComboBox)target;
				return;
			case 2:
				this.mGrid = (Grid)target;
				return;
			case 3:
				this.TogglePopupButton = (ToggleButton)target;
				return;
			case 4:
				this.mName = (TextBlock)target;
				return;
			case 5:
				this.Arrow = (Path)target;
				return;
			case 6:
				this.mItems = (CustomPopUp)target;
				return;
			case 7:
				this.mSchemesListScrollbar = (ScrollViewer)target;
				return;
			case 8:
				this.Items = (StackPanel)target;
				return;
			case 9:
				this.NewProfile = (Grid)target;
				this.NewProfile.MouseDown += this.NewProfile_MouseDown;
				this.NewProfile.MouseEnter += this.NewProfile_MouseEnter;
				this.NewProfile.MouseLeave += this.NewProfile_MouseLeave;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400089A RID: 2202
		public static readonly DependencyProperty SelectedItemProperty = DependencyProperty.Register("SelectedItem", typeof(string), typeof(ComboBoxSchemeControl), new UIPropertyMetadata(string.Empty));

		// Token: 0x0400089B RID: 2203
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal SchemeComboBox _this;

		// Token: 0x0400089C RID: 2204
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mGrid;

		// Token: 0x0400089D RID: 2205
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ToggleButton TogglePopupButton;

		// Token: 0x0400089E RID: 2206
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mName;

		// Token: 0x0400089F RID: 2207
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Path Arrow;

		// Token: 0x040008A0 RID: 2208
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mItems;

		// Token: 0x040008A1 RID: 2209
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ScrollViewer mSchemesListScrollbar;

		// Token: 0x040008A2 RID: 2210
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel Items;

		// Token: 0x040008A3 RID: 2211
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid NewProfile;

		// Token: 0x040008A4 RID: 2212
		private bool _contentLoaded;
	}
}
