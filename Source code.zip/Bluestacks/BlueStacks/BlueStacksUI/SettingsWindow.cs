﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000EC RID: 236
	public class SettingsWindow : SettingsWindowBase
	{
		// Token: 0x0600099E RID: 2462 RVA: 0x000379D8 File Offset: 0x00035BD8
		public SettingsWindow(MainWindow window, string startUpTab)
		{
			SettingsWindow <>4__this = this;
			this.ParentWindow = window;
			base.SettingsControlNameList.Add("STRING_DISPLAY_SETTINGS");
			base.SettingsControlNameList.Add("STRING_ENGINE_SETTING");
			if (window != null)
			{
				if (window.mGuestBootCompleted)
				{
					base.SettingsControlNameList.Add("STRING_ADVANCED");
				}
				if (window.mCommonHandler.mShortcutsConfigInstance != null)
				{
					base.SettingsControlNameList.Add("STRING_SHORTCUT_KEY_SETTINGS");
				}
				else
				{
					Logger.Warning("Not showing shortcuts settings as the config instance is null");
				}
			}
			base.SettingsControlNameList.Add("STRING_ABOUT_SETTING");
			this.UpdateSettingsListAndStartTabForCustomOEMs();
			base.Loaded += delegate(object sender, RoutedEventArgs e)
			{
				<>4__this.SettingsWindow_Loaded(window);
			};
			if (!string.IsNullOrEmpty(startUpTab))
			{
				base.StartUpTab = startUpTab;
			}
			this.CreateAllButtons(base.StartUpTab);
			this.ChangeSettingsTab(window, base.StartUpTab);
		}

		// Token: 0x0600099F RID: 2463 RVA: 0x00037AEC File Offset: 0x00035CEC
		public void ChangeSettingsTab(MainWindow window, string tab)
		{
			UserControl userControl = this.GetUserControl(tab, window);
			if (userControl == null)
			{
				userControl = this.GetUserControl("STRING_DISPLAY_SETTINGS", window);
			}
			base.AddControlInGridAndDict(tab, userControl);
			base.BringToFront(userControl);
			if (!this.mSettingsButtons[tab].IsSelected)
			{
				this.mSettingsButtons[tab].IsSelected = true;
				this.mSettingsButtons[tab].IsEnabled = true;
			}
		}

		// Token: 0x060009A0 RID: 2464 RVA: 0x00037B58 File Offset: 0x00035D58
		public void UpdateSettingsListAndStartTabForCustomOEMs()
		{
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				base.SettingsControlNameList = new List<string>
				{
					"STRING_DISPLAY_SETTINGS",
					"STRING_ENGINE_SETTING",
					"STRING_SCREENSHOT"
				};
				return;
			}
			if (FeatureManager.Instance.IsCustomUIForDMMSandbox)
			{
				base.SettingsControlNameList = new List<string>
				{
					"STRING_ABOUT_SETTING"
				};
				base.StartUpTab = "STRING_ABOUT_SETTING";
				return;
			}
			if (string.Equals(Oem.Instance.OEM, "yoozoo", StringComparison.InvariantCulture))
			{
				base.SettingsControlNameList = new List<string>
				{
					"STRING_DISPLAY_SETTINGS",
					"STRING_ENGINE_SETTING",
					"STRING_PREFERENCES"
				};
				return;
			}
			if (RegistryManager.Instance.InstallationType == InstallationTypes.GamingEdition)
			{
				base.SettingsControlNameList = new List<string>
				{
					"STRING_DISPLAY_SETTINGS",
					"STRING_ENGINE_SETTING",
					"STRING_ABOUT_SETTING"
				};
				return;
			}
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				base.SettingsControlNameList = new List<string>
				{
					"STRING_DISPLAY_SETTINGS",
					"STRING_ENGINE_SETTING",
					"STRING_PREFERENCES",
					"STRING_SHORTCUT_KEY_SETTINGS",
					"STRING_USER_DATA_SETTINGS"
				};
			}
		}

		// Token: 0x060009A1 RID: 2465 RVA: 0x00037C98 File Offset: 0x00035E98
		private UserControl GetUserControl(string controlName, MainWindow window)
		{
			if (controlName != null)
			{
				uint num = <PrivateImplementationDetails>.ComputeStringHash(controlName);
				if (num <= 2395752955U)
				{
					if (num <= 1158533478U)
					{
						if (num != 453138840U)
						{
							if (num == 1158533478U)
							{
								if (controlName == "STRING_NOTIFICATION")
								{
									return new NotificationsSettings(window);
								}
							}
						}
						else if (controlName == "STRING_ENGINE_SETTING")
						{
							return SettingsWindow.GetEngineView(window);
						}
					}
					else if (num != 2256989329U)
					{
						if (num == 2395752955U)
						{
							if (controlName == "STRING_ADVANCED")
							{
								return new DeviceProfileControl(window);
							}
						}
					}
					else if (controlName == "STRING_SCREENSHOT")
					{
						return new DMMScreenshotSettingControl(window);
					}
				}
				else if (num <= 2925263117U)
				{
					if (num != 2851124811U)
					{
						if (num == 2925263117U)
						{
							if (controlName == "STRING_USER_DATA_SETTINGS")
							{
								return new BackupRestoreSettingsControl(window);
							}
						}
					}
					else if (controlName == "STRING_DISPLAY_SETTINGS")
					{
						return new DisplaySettingsControl(window);
					}
				}
				else if (num != 3082043033U)
				{
					if (num != 3350936637U)
					{
						if (num == 3467783225U)
						{
							if (controlName == "STRING_SHORTCUT_KEY_SETTINGS")
							{
								return new ShortcutKeysControl(window, this);
							}
						}
					}
					else if (controlName == "STRING_PREFERENCES")
					{
						return new PreferencesSettingsControl(window);
					}
				}
				else if (controlName == "STRING_ABOUT_SETTING")
				{
					return new AboutSettingsControl(window, this);
				}
			}
			return null;
		}

		// Token: 0x060009A2 RID: 2466 RVA: 0x00037E28 File Offset: 0x00036028
		private static EngineSettingBase GetEngineView(MainWindow window)
		{
			EngineSettingBase engineSettingBase = new EngineSettingBase
			{
				Visibility = Visibility.Collapsed
			};
			EngineSettingViewModel dataContext = new EngineSettingViewModel(window, window.mVmName)
			{
				ParentView = engineSettingBase
			};
			engineSettingBase.DataContext = dataContext;
			return engineSettingBase;
		}

		// Token: 0x060009A3 RID: 2467 RVA: 0x00037E60 File Offset: 0x00036060
		private void SettingsWindow_Loaded(MainWindow window)
		{
			Window.GetWindow(this).Closing += this.SettingWindow_Closing;
			new Thread(delegate()
			{
				Thread.Sleep(500);
				using (List<string>.Enumerator enumerator = this.SettingsControlNameList.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						string settingName = enumerator.Current;
						if (!string.Equals(settingName, this.StartUpTab, StringComparison.InvariantCulture))
						{
							this.Dispatcher.Invoke(new Action(delegate()
							{
								UserControl userControl = this.GetUserControl(settingName, window);
								if (userControl != null)
								{
									this.AddControlInGridAndDict(settingName, userControl);
									foreach (object obj in this.SettingsWindowStackPanel.Children)
									{
										CustomSettingsButton customSettingsButton = (CustomSettingsButton)obj;
										if (customSettingsButton.Name == settingName)
										{
											customSettingsButton.IsEnabled = true;
										}
									}
								}
							}), new object[0]);
						}
					}
				}
				this.Dispatcher.Invoke(new Action(delegate()
				{
					this.SetPopupOffset();
				}), new object[0]);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060009A4 RID: 2468 RVA: 0x00037EB4 File Offset: 0x000360B4
		private void SettingWindow_Closing(object sender, CancelEventArgs e)
		{
			try
			{
				MainWindow.CloseSettingsWindow(null);
				if (this.mIsShortcutEdited && this.mIsShortcutSaveBtnEnabled)
				{
					CommonHandlers.ReloadShortcutsForAllInstances();
				}
			}
			catch (Exception ex)
			{
				string str = "Exception in SettingsWindowClosing. Exception: ";
				Exception ex2 = ex;
				Logger.Error(str + ((ex2 != null) ? ex2.ToString() : null));
			}
		}

		// Token: 0x060009A5 RID: 2469 RVA: 0x00037F10 File Offset: 0x00036110
		private void CreateAllButtons(string mstartUpTab)
		{
			foreach (string text in base.SettingsControlNameList)
			{
				CustomSettingsButton customSettingsButton = new CustomSettingsButton
				{
					Name = text,
					Group = "Settings"
				};
				this.mSettingsButtons.Add(text, customSettingsButton);
				TextBlock textBlock = new TextBlock
				{
					FontSize = 15.0,
					TextWrapping = TextWrapping.Wrap
				};
				BlueStacksUIBinding.Bind(textBlock, text, "");
				customSettingsButton.Content = textBlock;
				customSettingsButton.MinHeight = 40.0;
				customSettingsButton.FontWeight = FontWeights.Normal;
				customSettingsButton.IsTabStop = false;
				customSettingsButton.FocusVisualStyle = null;
				customSettingsButton.IsEnabled = false;
				customSettingsButton.PreviewMouseDown += this.ValidateAndSwitchTab;
				base.SettingsWindowStackPanel.Children.Add(customSettingsButton);
				if (mstartUpTab == text)
				{
					customSettingsButton.IsEnabled = true;
					customSettingsButton.IsSelected = true;
				}
			}
		}

		// Token: 0x060009A6 RID: 2470 RVA: 0x00038020 File Offset: 0x00036220
		private void ValidateAndSwitchTab(object sender, MouseButtonEventArgs args)
		{
			SettingsWindow.<>c__DisplayClass15_0 CS$<>8__locals1 = new SettingsWindow.<>c__DisplayClass15_0();
			CS$<>8__locals1.args = args;
			CS$<>8__locals1.<>4__this = this;
			CS$<>8__locals1.sender = sender;
			CustomSettingsButton customSettingsButton = CS$<>8__locals1.sender as CustomSettingsButton;
			if (base.SettingsWindowControlsDict[customSettingsButton.Name].GetType() == base.visibleControl.GetType())
			{
				return;
			}
			EngineSettingBase engineSettingBase = base.visibleControl as EngineSettingBase;
			if (engineSettingBase != null)
			{
				EngineSettingBaseViewModel engineSettingBaseViewModel = engineSettingBase.DataContext as EngineSettingBaseViewModel;
				if (engineSettingBaseViewModel != null)
				{
					if (engineSettingBaseViewModel.Status == Status.Progress)
					{
						Logger.Info("Compatibility check is running");
						return;
					}
					if (engineSettingBaseViewModel.IsDirty())
					{
						CustomMessageWindow customMessageWindow = new CustomMessageWindow();
						customMessageWindow.Owner = engineSettingBaseViewModel.Owner;
						customMessageWindow.WindowStartupLocation = WindowStartupLocation.CenterOwner;
						BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_DISCARD_CHANGES", "");
						BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_SETTING_TAB_CHANGE_MESSAGE", "");
						customMessageWindow.AddButton(ButtonColors.Blue, "STRING_NO", delegate(object o, EventArgs e)
						{
							CS$<>8__locals1.args.Handled = true;
						}, null, false, null);
						customMessageWindow.AddButton(ButtonColors.White, "STRING_DISCARD_CHANGES", delegate(object o, EventArgs e)
						{
							CS$<>8__locals1.<>4__this.SettingsBtn_Click(CS$<>8__locals1.sender, null);
						}, null, false, null);
						customMessageWindow.ShowDialog();
						return;
					}
					base.SettingsBtn_Click(CS$<>8__locals1.sender, null);
					return;
				}
			}
			UserControl visibleControl = base.visibleControl;
			DisplaySettingsControl displaySetting = visibleControl as DisplaySettingsControl;
			if (displaySetting != null && displaySetting.IsDirty())
			{
				CustomMessageWindow customMessageWindow2 = new CustomMessageWindow();
				customMessageWindow2.Owner = displaySetting.ParentWindow;
				customMessageWindow2.WindowStartupLocation = WindowStartupLocation.CenterOwner;
				BlueStacksUIBinding.Bind(customMessageWindow2.TitleTextBlock, "STRING_DISCARD_CHANGES", "");
				BlueStacksUIBinding.Bind(customMessageWindow2.BodyTextBlock, "STRING_SETTING_TAB_CHANGE_MESSAGE", "");
				customMessageWindow2.AddButton(ButtonColors.Blue, "STRING_NO", delegate(object o, EventArgs e)
				{
					CS$<>8__locals1.args.Handled = true;
				}, null, false, null);
				customMessageWindow2.AddButton(ButtonColors.White, "STRING_DISCARD_CHANGES", delegate(object o, EventArgs e)
				{
					displaySetting.DiscardCurrentChangingModel();
					CS$<>8__locals1.<>4__this.SettingsBtn_Click(CS$<>8__locals1.sender, null);
				}, null, false, null);
				customMessageWindow2.ShowDialog();
				return;
			}
			base.SettingsBtn_Click(CS$<>8__locals1.sender, null);
		}

		// Token: 0x060009A7 RID: 2471 RVA: 0x00038228 File Offset: 0x00036428
		protected override void SetPopupOffset()
		{
			if (this.ParentWindow.mTopBar.mSnailMode == PerformanceState.VtxDisabled && !base.IsVtxLearned && base.CheckWidth())
			{
				base.EnableVTPopup.HorizontalOffset = base.SettingsWindowStackPanel.ActualWidth;
				base.EnableVTPopup.Width = base.SettingsWindowGrid.ActualWidth;
				base.EnableVTPopup.IsOpen = true;
			}
		}

		// Token: 0x060009A8 RID: 2472 RVA: 0x00038290 File Offset: 0x00036490
		public override void CloseButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked settings menu close button");
			bool staysOpen = false;
			bool mIsSomeRestartButtonActive = false;
			UserControl visibleControl = base.visibleControl;
			EngineSettingBase engineSettingBase = visibleControl as EngineSettingBase;
			if (engineSettingBase == null)
			{
				DisplaySettingsControl displaySettingsControl = visibleControl as DisplaySettingsControl;
				if (displaySettingsControl != null)
				{
					mIsSomeRestartButtonActive = displaySettingsControl.IsDirty();
				}
			}
			else
			{
				EngineSettingViewModel engineSettingViewModel = engineSettingBase.DataContext as EngineSettingViewModel;
				if (engineSettingViewModel.Status == Status.Progress)
				{
					Logger.Info("Compatibility check is running");
					return;
				}
				mIsSomeRestartButtonActive = engineSettingViewModel.IsDirty();
			}
			if (mIsSomeRestartButtonActive)
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_DISCARD_CHANGES", "");
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_SETTING_CLOSE_MESSAGE"), new object[]
				{
					"bluestacks"
				}), "");
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_NO", delegate(object o, EventArgs evt)
				{
					mIsSomeRestartButtonActive = true;
				}, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, "STRING_DISCARD_CHANGES", delegate(object o, EventArgs evt)
				{
					mIsSomeRestartButtonActive = false;
				}, null, false, null);
				customMessageWindow.Owner = this.ParentWindow;
				customMessageWindow.ShowDialog();
			}
			if (mIsSomeRestartButtonActive)
			{
				return;
			}
			GrmHandler.RequirementConfigUpdated(this.ParentWindow.mVmName);
			if (this.mIsShortcutEdited && this.mIsShortcutSaveBtnEnabled)
			{
				CustomMessageWindow customMessageWindow2 = new CustomMessageWindow();
				BlueStacksUIBinding.Bind(customMessageWindow2.TitleTextBlock, "STRING_SAVE_CHANGES_QUESTION", "");
				BlueStacksUIBinding.Bind(customMessageWindow2.BodyTextBlock, "STRING_UNSAVED_CHANGES", "");
				customMessageWindow2.AddButton(ButtonColors.Blue, "STRING_SAVE_CHANGES", delegate(object o, EventArgs evt)
				{
					this.ParentWindow.mCommonHandler.SaveAndReloadShortcuts();
					this.mIsShortcutEdited = false;
				}, null, false, null);
				customMessageWindow2.AddButton(ButtonColors.White, "STRING_DISCARD", delegate(object o, EventArgs evt)
				{
					CommonHandlers.ReloadShortcutsForAllInstances();
				}, null, false, null);
				customMessageWindow2.Owner = this.ParentWindow;
				customMessageWindow2.CloseButton.PreviewMouseLeftButtonUp += delegate(object o, MouseButtonEventArgs evt)
				{
					staysOpen = true;
				};
				customMessageWindow2.ShowDialog();
			}
			else if (this.mDuplicateShortcutsList.Count > 0)
			{
				CommonHandlers.ReloadShortcutsForAllInstances();
			}
			if (staysOpen)
			{
				return;
			}
			BlueStacksUIUtils.CloseContainerWindow(this);
		}

		// Token: 0x060009A9 RID: 2473 RVA: 0x000384B8 File Offset: 0x000366B8
		internal void RestartActions()
		{
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				BlueStacksUIUtils.CloseContainerWindow(this);
				this.ParentWindow.Close();
				return;
			}
			if (BlueStacksUIUtils.DictWindows.Count == 1)
			{
				App.defaultResolution = new Fraction((long)RegistryManager.Instance.Guest[Strings.CurrentDefaultVmName].GuestWidth, (long)RegistryManager.Instance.Guest[Strings.CurrentDefaultVmName].GuestHeight);
				PromotionManager.ReloadPromotionsAsync();
			}
			string mChangedABIValue = this.ParentWindow.mChangedABIValue;
			if (!string.IsNullOrEmpty(mChangedABIValue))
			{
				string text = VmCmdHandler.RunCommand(string.Format(CultureInfo.InvariantCulture, "{0} {1}", new object[]
				{
					"switchAbi",
					mChangedABIValue
				}), this.ParentWindow.mVmName);
				Logger.Info("Result for switch abi command: " + text);
				if (string.Equals(text, "ok", StringComparison.InvariantCulture))
				{
					ClientStats.SendMiscellaneousStatsAsync("ABIChanged", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, (mChangedABIValue == "15") ? ABISetting.Auto.ToString() : ABISetting.ARM.ToString(), "bgp", null, null, null, null);
					Utils.UpdateValueInBootParams("abivalue", mChangedABIValue, this.ParentWindow.mVmName, true);
					this.ParentWindow.mChangedABIValue = null;
				}
			}
			BlueStacksUIUtils.CloseContainerWindow(this);
			BlueStacksUIUtils.RestartInstance(this.ParentWindow.mVmName);
		}

		// Token: 0x04000601 RID: 1537
		private MainWindow ParentWindow;

		// Token: 0x04000602 RID: 1538
		internal CustomSettingsButton updateButton;

		// Token: 0x04000603 RID: 1539
		internal CustomSettingsButton gameSettingsButton;

		// Token: 0x04000604 RID: 1540
		internal bool mIsShortcutEdited;

		// Token: 0x04000605 RID: 1541
		internal bool mIsShortcutSaveBtnEnabled;

		// Token: 0x04000606 RID: 1542
		internal List<string> mDuplicateShortcutsList = new List<string>();

		// Token: 0x04000607 RID: 1543
		internal Dictionary<string, CustomSettingsButton> mSettingsButtons = new Dictionary<string, CustomSettingsButton>();
	}
}
