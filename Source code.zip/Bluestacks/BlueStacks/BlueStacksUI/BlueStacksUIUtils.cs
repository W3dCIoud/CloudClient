﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using BlueStacks.Common;
using Microsoft.VisualBasic.Devices;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000158 RID: 344
	internal class BlueStacksUIUtils : IDisposable
	{
		// Token: 0x1700021F RID: 543
		// (get) Token: 0x06000D62 RID: 3426 RVA: 0x00009FEA File Offset: 0x000081EA
		// (set) Token: 0x06000D63 RID: 3427 RVA: 0x00058294 File Offset: 0x00056494
		public int CurrentVolumeLevel
		{
			get
			{
				return this.mCurrentVolumeLevel;
			}
			private set
			{
				if (value <= 0)
				{
					this.mCurrentVolumeLevel = 0;
				}
				else if (value >= 100)
				{
					this.mCurrentVolumeLevel = 100;
				}
				else
				{
					this.mCurrentVolumeLevel = value;
				}
				this.ParentWindow.EngineInstanceRegistry.Volume = this.mCurrentVolumeLevel;
				this.ParentWindow.mCommonHandler.OnVolumeChanged(this.mCurrentVolumeLevel);
			}
		}

		// Token: 0x06000D64 RID: 3428 RVA: 0x00009FF2 File Offset: 0x000081F2
		internal static bool IsAlphabet(char c)
		{
			return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
		}

		// Token: 0x06000D65 RID: 3429 RVA: 0x000582F0 File Offset: 0x000564F0
		internal BlueStacksUIUtils(MainWindow window)
		{
			this.ParentWindow = window;
			this.mCurrentVolumeLevel = this.ParentWindow.EngineInstanceRegistry.Volume;
		}

		// Token: 0x06000D66 RID: 3430 RVA: 0x0005833C File Offset: 0x0005653C
		internal static void CloseContainerWindow(FrameworkElement control)
		{
			FrameworkElement frameworkElement = control;
			while (frameworkElement != null && !(frameworkElement is ContainerWindow))
			{
				frameworkElement = (frameworkElement.Parent as FrameworkElement);
			}
			if (frameworkElement != null)
			{
				(frameworkElement as ContainerWindow).Close();
			}
		}

		// Token: 0x06000D67 RID: 3431 RVA: 0x00058374 File Offset: 0x00056574
		internal static void RefreshKeyMap(string packageName)
		{
			using (Dictionary<string, MainWindow>.Enumerator enumerator = BlueStacksUIUtils.DictWindows.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					KeyValuePair<string, MainWindow> item = enumerator.Current;
					try
					{
						if (string.Equals(item.Value.mTopBar.mAppTabButtons.SelectedTab.PackageName, packageName, StringComparison.InvariantCulture))
						{
							item.Value.mFrontendHandler.RefreshKeyMap(packageName);
							if (RegistryManager.Instance.ShowKeyControlsOverlay)
							{
								KMManager.LoadIMActions(item.Value, packageName);
								if (KMManager.CanvasWindow == null || !KMManager.CanvasWindow.IsVisible || KMManager.CanvasWindow.Owner.GetHashCode() != item.Value.GetHashCode())
								{
									Dispatcher.CurrentDispatcher.BeginInvoke(new Action(delegate()
									{
										if (KMManager.dictOverlayWindow.ContainsKey(item.Value) && BlueStacksUIUtils.LastActivatedWindow != item.Value)
										{
											KMManager.dictOverlayWindow[item.Value].Init();
										}
									}), new object[0]);
								}
							}
						}
					}
					catch (Exception ex)
					{
						Logger.Error(string.Concat(new string[]
						{
							ex.ToString(),
							Environment.NewLine,
							"Exception refreshing mapping of package : ",
							packageName,
							" for instance : ",
							item.Value.mVmName
						}));
					}
				}
			}
		}

		// Token: 0x06000D68 RID: 3432 RVA: 0x0000A00F File Offset: 0x0000820F
		public static bool IsModal(Window window)
		{
			return (bool)typeof(Window).GetField("_showingAsDialog", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(window);
		}

		// Token: 0x06000D69 RID: 3433 RVA: 0x000584F0 File Offset: 0x000566F0
		private static void CloseWindows(Window win)
		{
			for (int i = win.OwnedWindows.Count - 1; i >= 0; i--)
			{
				BlueStacksUIUtils.CloseWindows(win.OwnedWindows[i]);
				if (win.OwnedWindows[i] != null && win.OwnedWindows[i].IsLoaded && win.OwnedWindows[i].Visibility == Visibility.Visible)
				{
					if (BlueStacksUIUtils.IsModal(win.OwnedWindows[i]))
					{
						win.OwnedWindows[i].Close();
					}
					else
					{
						win.OwnedWindows[i].Visibility = Visibility.Hidden;
					}
				}
			}
		}

		// Token: 0x06000D6A RID: 3434 RVA: 0x00058598 File Offset: 0x00056798
		internal static void HideUnhideBlueStacks(bool isHide)
		{
			foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values)
			{
				if (!mainWindow.mIsMinimizedThroughCloseButton)
				{
					BlueStacksUIUtils.HideUnhideParentWindow(isHide, mainWindow);
				}
			}
		}

		// Token: 0x06000D6B RID: 3435 RVA: 0x000585F8 File Offset: 0x000567F8
		internal static void HideUnhideParentWindow(bool isHide, MainWindow window)
		{
			if (isHide)
			{
				window.Dispatcher.Invoke(new Action(delegate()
				{
					BlueStacksUIUtils.CloseWindows(window);
					window.Visibility = Visibility.Hidden;
					if (window.mIsFullScreen)
					{
						window.WindowState = WindowState.Normal;
					}
					window.ShowInTaskbar = false;
					window.mFrontendHandler.DeactivateFrontend();
				}), new object[0]);
				return;
			}
			window.ShowInTaskbar = true;
			if (window.mIsFullScreen)
			{
				window.WindowState = WindowState.Maximized;
			}
			window.Visibility = Visibility.Visible;
			window.Activate();
			if (!window.Topmost)
			{
				window.Topmost = true;
				Action <>9__2;
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					Dispatcher dispatcher = window.Dispatcher;
					Action method;
					if ((method = <>9__2) == null)
					{
						method = (<>9__2 = delegate()
						{
							window.Topmost = false;
						});
					}
					dispatcher.Invoke(method, new object[0]);
				});
			}
			if (RegistryManager.Instance.ShowKeyControlsOverlay)
			{
				KMManager.ShowOverlayWindow(window, true, false);
			}
		}

		// Token: 0x06000D6C RID: 3436 RVA: 0x000586BC File Offset: 0x000568BC
		internal void MuteApplication(bool allInstances)
		{
			NativeMethods.waveOutSetVolume(IntPtr.Zero, 0U);
			try
			{
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary["allInstances"] = allInstances.ToString(CultureInfo.InvariantCulture);
				dictionary["explicit"] = "true";
				Dictionary<string, string> data = dictionary;
				HTTPUtils.SendRequestToEngine("mute", data, this.ParentWindow.mVmName, 0, null, false, 1, 0, "");
				this.ParentWindow.mCommonHandler.OnVolumeMuted(true);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send mute to frontend. Ex: " + ex.Message);
			}
		}

		// Token: 0x06000D6D RID: 3437 RVA: 0x00058760 File Offset: 0x00056960
		internal void UnmuteApplication(bool allInstances)
		{
			if (!FeatureManager.Instance.IsCustomUIForDMM)
			{
				if (allInstances && this.ParentWindow.EngineInstanceRegistry.IsMuted)
				{
					this.ParentWindow.mSidebar.UpdateMuteAllInstancesCheckbox();
					return;
				}
				if (!allInstances && RegistryManager.Instance.AreAllInstancesMuted)
				{
					RegistryManager.Instance.AreAllInstancesMuted = false;
					foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values)
					{
						mainWindow.mSidebar.UpdateMuteAllInstancesCheckbox();
					}
				}
			}
			NativeMethods.waveOutSetVolume(IntPtr.Zero, uint.MaxValue);
			try
			{
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary["allInstances"] = allInstances.ToString(CultureInfo.InvariantCulture);
				Dictionary<string, string> data = dictionary;
				HTTPUtils.SendRequestToEngine("unmute", data, this.ParentWindow.mVmName, 0, null, false, 1, 0, "");
				this.ParentWindow.mCommonHandler.OnVolumeMuted(false);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send mute to frontend. Ex: " + ex.Message);
			}
		}

		// Token: 0x06000D6E RID: 3438 RVA: 0x0000A032 File Offset: 0x00008232
		internal void SetCurrentVolumeForDMM(int previousVolume, int newVolume)
		{
			new Thread(delegate()
			{
				try
				{
					this.ParentWindow.Utils.SetVolumeInFrontendAsync(newVolume);
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						this.ParentWindow.mDmmBottomBar.CurrentVolume = previousVolume;
					}), new object[0]);
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to set volume... Err : " + ex.ToString());
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						this.ParentWindow.mDmmBottomBar.CurrentVolume = previousVolume;
					}), new object[0]);
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000D6F RID: 3439 RVA: 0x0000A06A File Offset: 0x0000826A
		internal void SetVolumeLevelFromAndroid(int volume)
		{
			this.CurrentVolumeLevel = volume;
		}

		// Token: 0x06000D70 RID: 3440 RVA: 0x0000A073 File Offset: 0x00008273
		internal void SetVolumeInFrontendAsync(int newVolume)
		{
			int currentVolumeLevel = this.CurrentVolumeLevel;
			new Thread(delegate()
			{
				try
				{
					if (this.ParentWindow.mGuestBootCompleted)
					{
						Dictionary<string, string> data = new Dictionary<string, string>
						{
							{
								"vol",
								newVolume.ToString(CultureInfo.InvariantCulture)
							}
						};
						if (Convert.ToBoolean(JArray.Parse(HTTPUtils.SendRequestToEngine("setVolume", data, this.ParentWindow.mVmName, 0, null, false, 1, 0, ""))[0]["success"], CultureInfo.InvariantCulture))
						{
							this.CurrentVolumeLevel = newVolume;
						}
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to set volume. Ex: " + ex.ToString());
				}
				if (this.CurrentVolumeLevel == 0)
				{
					this.MuteApplication(false);
				}
				if (this.ParentWindow.EngineInstanceRegistry.IsMuted && this.CurrentVolumeLevel != 0)
				{
					this.UnmuteApplication(false);
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000D71 RID: 3441 RVA: 0x0000A0AB File Offset: 0x000082AB
		internal void GetCurrentVolumeAtBootAsyncAndSetMuteInstancesState()
		{
			new Thread(delegate()
			{
				try
				{
					int millisecondsTimeout = 1000;
					int volume = this.mCurrentVolumeLevel;
					int i = 60;
					while (i > 0)
					{
						i--;
						try
						{
							JObject jobject = JObject.Parse(HTTPUtils.SendRequestToGuest("getVolume", null, this.ParentWindow.mVmName, 0, null, true, 1, 0));
							if (!(jobject["result"].ToString() != "ok"))
							{
								volume = Convert.ToInt32(jobject["volume"].ToString(), CultureInfo.InvariantCulture);
								break;
							}
							Thread.Sleep(millisecondsTimeout);
						}
						catch (Exception ex)
						{
							Logger.Warning("Failed to get volume from guest: {0}", new object[]
							{
								ex.Message
							});
							Thread.Sleep(millisecondsTimeout);
						}
					}
					this.CurrentVolumeLevel = volume;
					if (FeatureManager.Instance.IsCustomUIForDMM)
					{
						this.ParentWindow.mDmmBottomBar.Dispatcher.Invoke(new Action(delegate()
						{
							this.ParentWindow.mDmmBottomBar.CurrentVolume = volume;
						}), new object[0]);
					}
					if (RegistryManager.Instance.AreAllInstancesMuted)
					{
						this.MuteApplication(true);
					}
				}
				catch (Exception ex2)
				{
					Logger.Error("Failed to get volume: " + ex2.ToString());
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000D72 RID: 3442 RVA: 0x0000A0CA File Offset: 0x000082CA
		internal static void RestartInstance(string vmName)
		{
			if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
			{
				BlueStacksUIUtils.DictWindows[vmName].RestartInstanceAndPerform(null);
			}
		}

		// Token: 0x06000D73 RID: 3443 RVA: 0x00058888 File Offset: 0x00056A88
		internal static void SwitchAndRestartInstanceInAgl(string vmName)
		{
			if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
			{
				BlueStacksUIUtils.DictWindows[vmName].EngineInstanceRegistry.GlRenderMode = 1;
				Utils.UpdateValueInBootParams("GlMode", "2", vmName, true);
				BlueStacksUIUtils.DictWindows[vmName].EngineInstanceRegistry.GlMode = 2;
				BlueStacksUIUtils.RestartInstance(vmName);
			}
		}

		// Token: 0x06000D74 RID: 3444 RVA: 0x000588E8 File Offset: 0x00056AE8
		internal static void SwitchAndRestartInstanceInOglAfterRunningGlCheck(string vmName, Action openApp)
		{
			if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
			{
				if (BlueStacksUIUtils.isOglSupported == null)
				{
					BlueStacksUIUtils.DictWindows[vmName].mExitProgressGrid.ProgressText = "STRING_RUNNING_CHECKS";
					BlueStacksUIUtils.DictWindows[vmName].mExitProgressGrid.Visibility = Visibility.Visible;
					using (BackgroundWorker backgroundWorker = new BackgroundWorker())
					{
						backgroundWorker.DoWork += BlueStacksUIUtils.Bgw_DoWork;
						backgroundWorker.RunWorkerCompleted += BlueStacksUIUtils.Bgw_RunWorkerCompleted;
						backgroundWorker.RunWorkerAsync(new object[]
						{
							vmName,
							openApp
						});
						return;
					}
				}
				BlueStacksUIUtils.Bgw_RunWorkerCompleted(new object(), new RunWorkerCompletedEventArgs(new object[]
				{
					vmName,
					openApp
				}, null, false));
			}
		}

		// Token: 0x06000D75 RID: 3445 RVA: 0x000589BC File Offset: 0x00056BBC
		private static void Bgw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			if (e.Error != null)
			{
				return;
			}
			string text = ((object[])e.Result)[0].ToString();
			Action openApp = (Action)((object[])e.Result)[1];
			BlueStacksUIUtils.DictWindows[text].mExitProgressGrid.ProgressText = "STRING_CLOSING_BLUESTACKS";
			BlueStacksUIUtils.DictWindows[text].mExitProgressGrid.Visibility = Visibility.Hidden;
			bool? flag = BlueStacksUIUtils.isOglSupported;
			bool flag2 = true;
			if (flag.GetValueOrDefault() == flag2 & flag != null)
			{
				BlueStacksUIUtils.DictWindows[text].EngineInstanceRegistry.GlRenderMode = 1;
				Utils.UpdateValueInBootParams("GlMode", "1", text, true);
				BlueStacksUIUtils.DictWindows[text].EngineInstanceRegistry.GlMode = 1;
				BlueStacksUIUtils.RestartInstance(text);
				return;
			}
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_OPENGL_NOT_SUPPORTED");
			customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_OPENGL_NOTSUPPORTED_BODY");
			customMessageWindow.AddButton(ButtonColors.Blue, LocaleStrings.GetLocalizedString("STRING_CONTINUE"), delegate(object o, EventArgs args)
			{
				openApp();
			}, null, false, null);
			customMessageWindow.Owner = BlueStacksUIUtils.DictWindows[text];
			BlueStacksUIUtils.DictWindows[text].ShowDimOverlay(null);
			customMessageWindow.ShowDialog();
			BlueStacksUIUtils.DictWindows[text].HideDimOverlay();
		}

		// Token: 0x06000D76 RID: 3446 RVA: 0x00058B1C File Offset: 0x00056D1C
		private static void Bgw_DoWork(object sender, DoWorkEventArgs e)
		{
			int num;
			string text;
			string text2;
			string text3;
			BlueStacksUIUtils.isOglSupported = new bool?(Utils.CheckOpenGlSupport(out num, out text, out text2, out text3, RegistryStrings.InstallDir));
			e.Result = e.Argument;
		}

		// Token: 0x06000D77 RID: 3447 RVA: 0x00058B54 File Offset: 0x00056D54
		internal static void SwitchAndRestartInstanceInDx(string vmName)
		{
			if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
			{
				BlueStacksUIUtils.DictWindows[vmName].EngineInstanceRegistry.GlRenderMode = 4;
				Utils.UpdateValueInBootParams("GlMode", "1", vmName, true);
				BlueStacksUIUtils.DictWindows[vmName].EngineInstanceRegistry.GlMode = 1;
				BlueStacksUIUtils.RestartInstance(vmName);
			}
		}

		// Token: 0x06000D78 RID: 3448 RVA: 0x00058BB4 File Offset: 0x00056DB4
		internal static void SwitchAndRestartInstanceInAdx(string vmName)
		{
			if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
			{
				BlueStacksUIUtils.DictWindows[vmName].EngineInstanceRegistry.GlRenderMode = 4;
				Utils.UpdateValueInBootParams("GlMode", "2", vmName, true);
				BlueStacksUIUtils.DictWindows[vmName].EngineInstanceRegistry.GlMode = 2;
				BlueStacksUIUtils.RestartInstance(vmName);
			}
		}

		// Token: 0x06000D79 RID: 3449 RVA: 0x00058C14 File Offset: 0x00056E14
		internal void RunAppOrCreateTabButton(string packageName)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (this.ParentWindow.mTopBar.mAppTabButtons.mHomeAppTabButton.IsSelected)
				{
					this.ParentWindow.mAppHandler.SendRunAppRequestAsync(packageName, "", false);
					return;
				}
				AppIcon appIcon = this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon(packageName);
				if (appIcon != null)
				{
					this.ParentWindow.mTopBar.mAppTabButtons.AddAppTab(appIcon.AppName, appIcon.PackageName, appIcon.ActivityName, appIcon.ImageName, false, false, false);
				}
			}), new object[0]);
		}

		// Token: 0x06000D7A RID: 3450 RVA: 0x00058C58 File Offset: 0x00056E58
		internal void ResetPendingUIOperations()
		{
			try
			{
				if (this.ParentWindow.mGuestBootCompleted)
				{
					this.ParentWindow.mAppHandler.SwitchWhenPackageNameRecieved = string.Empty;
					AppHandler.EventOnAppDisplayed = null;
					if (FeatureManager.Instance.IsCustomUIForDMM)
					{
						this.ParentWindow.mDmmBottomBar.ShowKeyMapPopup(false);
					}
					else
					{
						this.ParentWindow.mSidebar.ShowKeyMapPopup(false);
						this.ParentWindow.mSidebar.ShowOverlayTooltip(false, false);
					}
					this.ParentWindow.mWelcomeTab.mFrontendPopupControl.HideWindow();
					this.ParentWindow.StaticComponents.ShowUninstallButtons(false);
					this.ParentWindow.ClosePopUps();
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Error in ResetPendingUIOperations " + ex.ToString());
			}
		}

		// Token: 0x06000D7B RID: 3451 RVA: 0x0000A0EA File Offset: 0x000082EA
		internal static void AddBootEventHandler(string vmName, EventHandler bootedEvennt)
		{
			if (BlueStacksUIUtils.BootEventsForMIManager.ContainsKey(vmName))
			{
				BlueStacksUIUtils.BootEventsForMIManager[vmName].Add(bootedEvennt);
				return;
			}
			BlueStacksUIUtils.BootEventsForMIManager.Add(vmName, new List<EventHandler>
			{
				bootedEvennt
			});
		}

		// Token: 0x06000D7C RID: 3452 RVA: 0x00058D30 File Offset: 0x00056F30
		internal static void InvokeMIManagerEvents(string VmName)
		{
			if (BlueStacksUIUtils.BootEventsForMIManager.ContainsKey(VmName))
			{
				foreach (EventHandler eventHandler in BlueStacksUIUtils.BootEventsForMIManager[VmName])
				{
					eventHandler(null, null);
				}
			}
		}

		// Token: 0x06000D7D RID: 3453 RVA: 0x00058D94 File Offset: 0x00056F94
		internal void ShakeWindow()
		{
			if (this.ParentWindow.WindowState == WindowState.Maximized)
			{
				this.ParentWindow.StoryBoard.Begin();
				return;
			}
			int i = 10;
			int num = 5;
			int num2 = 0;
			int num3 = 0;
			while (i > 0)
			{
				if (num3 == 0)
				{
					num2 = num;
				}
				else if (num3 == 1)
				{
					num2 = num * -1;
				}
				else if (num3 == 2)
				{
					num2 = num * -1;
				}
				else if (num3 == 3)
				{
					num2 = num;
				}
				num3++;
				if (num3 == 4)
				{
					num3 = 0;
					i--;
				}
				this.ParentWindow.Left += (double)num2;
				Thread.Sleep(30);
			}
		}

		// Token: 0x06000D7E RID: 3454 RVA: 0x00058E1C File Offset: 0x0005701C
		internal static void RunInstance(string vmName, bool hiddenMode = false)
		{
			if (!BlueStacksUIUtils.lstCreatingWindows.Contains(vmName))
			{
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName) && !hiddenMode)
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[vmName].ShowWindow(false);
					}), new object[0]);
					return;
				}
				Application.Current.Dispatcher.Invoke(new Action(delegate()
				{
					BlueStacksUIUtils.lstCreatingWindows.Add(vmName);
					MainWindow mainWindow = new MainWindow(vmName);
					BlueStacksUIUtils.DictWindows[vmName] = mainWindow;
					BlueStacksUIUtils.lstCreatingWindows.Remove(vmName);
					if (!hiddenMode)
					{
						mainWindow.ShowWindow(true);
					}
				}), new object[0]);
			}
		}

		// Token: 0x06000D7F RID: 3455 RVA: 0x0000A122 File Offset: 0x00008322
		internal void CheckGuestFailedAsync()
		{
			this.sBootCheckTimer.Elapsed += this.SBootCheckTimer_Elapsed;
			this.sBootCheckTimer.Enabled = true;
		}

		// Token: 0x06000D80 RID: 3456 RVA: 0x00058EBC File Offset: 0x000570BC
		internal static void HideAllBlueStacks()
		{
			foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>())
			{
				BlueStacksUIUtils.CloseWindows(mainWindow);
				mainWindow.ShowInTaskbar = false;
				mainWindow.Hide();
			}
		}

		// Token: 0x06000D81 RID: 3457 RVA: 0x0000A147 File Offset: 0x00008347
		private void SBootCheckTimer_Elapsed(object sender, ElapsedEventArgs e)
		{
			(sender as System.Timers.Timer).Enabled = false;
			if (!this.ParentWindow.mGuestBootCompleted)
			{
				this.SendGuestBootFailureStats("boot timeout exception");
			}
		}

		// Token: 0x06000D82 RID: 3458 RVA: 0x00058F24 File Offset: 0x00057124
		public static string GetFinalRedirectedUrl(string url)
		{
			HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
			httpWebRequest.Method = "GET";
			httpWebRequest.AllowAutoRedirect = true;
			string str = "Bluestacks/" + RegistryManager.Instance.ClientVersion;
			httpWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36 " + str;
			httpWebRequest.Headers.Add("x_oem", RegistryManager.Instance.Oem);
			httpWebRequest.Headers.Set("x_email", RegistryManager.Instance.RegisteredEmail);
			httpWebRequest.Headers.Add("x_guid", RegistryManager.Instance.UserGuid);
			httpWebRequest.Headers.Add("x_prod_ver", RegistryManager.Instance.Version);
			httpWebRequest.Headers.Add("x_home_app_ver", RegistryManager.Instance.ClientVersion);
			string result;
			try
			{
				result = httpWebRequest.GetResponse().ResponseUri.ToString();
			}
			catch (Exception ex)
			{
				Logger.Error("Error in getting redirected url" + ex.ToString());
				result = null;
			}
			return result;
		}

		// Token: 0x06000D83 RID: 3459 RVA: 0x00059038 File Offset: 0x00057238
		internal void SendGuestBootFailureStats(string errorString)
		{
			if (RegistryManager.Instance.IsEngineUpgraded == 1 && RegistryManager.Instance.IsClientFirstLaunch == 1)
			{
				ClientStats.SendClientStatsAsync("update_init", "fail", "engine_activity", "", errorString, "");
			}
			else if (RegistryManager.Instance.IsClientFirstLaunch == 1)
			{
				ClientStats.SendClientStatsAsync("first_init", "fail", "engine_activity", "", errorString, "");
			}
			else
			{
				ClientStats.SendClientStatsAsync("init", "fail", "engine_activity", "", errorString, "");
			}
			this.ParentWindow.HandleRestartPopup();
		}

		// Token: 0x06000D84 RID: 3460 RVA: 0x000590D8 File Offset: 0x000572D8
		internal static bool CheckForMacrAvailable(string packageName)
		{
			string path = Path.Combine(Path.Combine(RegistryManager.Instance.EngineDataDir, "UserData\\InputMapper"), packageName + "_macro.cfg");
			string path2 = Path.Combine(Path.Combine(RegistryManager.Instance.EngineDataDir, "UserData\\InputMapper\\UserFiles"), packageName + "_macro.cfg");
			return File.Exists(path) || File.Exists(path2);
		}

		// Token: 0x06000D85 RID: 3461 RVA: 0x00059140 File Offset: 0x00057340
		internal static string GetVideoTutorialUrl(string packageName, string videoMode, string selectedSchemeName)
		{
			string text = WebHelper.GetServerHost();
			text = text.Substring(0, text.Length - 4);
			string text2 = string.Empty;
			if (GuidanceVideoType.SchemeSpecific.ToString().ToLower(CultureInfo.InvariantCulture).Equals(videoMode, StringComparison.InvariantCulture))
			{
				text2 = WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}?app_pkg={2}&mode={3}&scheme={4}", new object[]
				{
					text,
					"videoTutorial",
					packageName,
					videoMode,
					selectedSchemeName
				}));
			}
			else
			{
				text2 = WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}?app_pkg={2}&mode={3}", new object[]
				{
					text,
					"videoTutorial",
					packageName,
					videoMode
				}));
			}
			if (!RegistryManager.Instance.IgnoreAutoPlayPackageList.Contains(packageName))
			{
				text2 = string.Format(CultureInfo.InvariantCulture, "{0}&autoplay=1", new object[]
				{
					text2
				});
				List<string> ignoreAutoPlayPackageList = RegistryManager.Instance.IgnoreAutoPlayPackageList;
				ignoreAutoPlayPackageList.Add(packageName);
				RegistryManager.Instance.IgnoreAutoPlayPackageList = ignoreAutoPlayPackageList;
			}
			else
			{
				text2 = string.Format(CultureInfo.InvariantCulture, "{0}&autoplay=0", new object[]
				{
					text2
				});
			}
			if (!string.IsNullOrEmpty(RegistryManager.Instance.Partner))
			{
				text2 += string.Format(CultureInfo.InvariantCulture, "&partner={0}", new object[]
				{
					RegistryManager.Instance.Partner
				});
			}
			return text2;
		}

		// Token: 0x06000D86 RID: 3462 RVA: 0x0000A16D File Offset: 0x0000836D
		internal static string GetOnboardingUrl(string packageName)
		{
			return WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}?app_pkg={2}", new object[]
			{
				RegistryManager.Instance.Host,
				"bs3/page/onboarding-tutorial",
				packageName
			}));
		}

		// Token: 0x06000D87 RID: 3463 RVA: 0x00059290 File Offset: 0x00057490
		internal void SetKeyMapping(string packageName, string source)
		{
			string path = Path.Combine(RegistryManager.Instance.EngineDataDir, "UserData\\InputMapper\\UserFiles");
			string destFileName = Path.Combine(path, string.Format(CultureInfo.InvariantCulture, "{0}.cfg", new object[]
			{
				packageName
			}));
			string sourceFileName = Path.Combine(path, string.Format(CultureInfo.InvariantCulture, "{0}_{1}.cfg", new object[]
			{
				packageName,
				source
			}));
			try
			{
				File.Copy(sourceFileName, destFileName, true);
			}
			catch (Exception ex)
			{
				Logger.Error("Faield to copy cfgs... Err : " + ex.ToString());
				return;
			}
			this.ParentWindow.mFrontendHandler.RefreshKeyMap(packageName);
		}

		// Token: 0x06000D88 RID: 3464 RVA: 0x0005933C File Offset: 0x0005753C
		internal static void OpenUrl(string url)
		{
			try
			{
				Process.Start(url);
			}
			catch (Win32Exception)
			{
				try
				{
					Process.Start("IExplore.exe", url);
				}
				catch (Exception ex)
				{
					Logger.Warning("Not able to launch the url " + url + "Ignoring Exception: " + ex.ToString());
				}
			}
			catch (Exception ex2)
			{
				Logger.Warning("Not able to launch the url " + url + "Ignoring Exception: " + ex2.ToString());
			}
		}

		// Token: 0x06000D89 RID: 3465 RVA: 0x000593C8 File Offset: 0x000575C8
		internal bool IsSufficientRAMAvailable()
		{
			Logger.Info("Checking for physical memory...");
			long num = long.Parse(SystemUtils.GetSysInfo("Select TotalPhysicalMemory from Win32_ComputerSystem"), CultureInfo.InvariantCulture);
			long num2 = 1073741824L;
			return num >= num2;
		}

		// Token: 0x06000D8A RID: 3466 RVA: 0x00059400 File Offset: 0x00057600
		public void SendMessageToAndroidForAffiliate(string pkgName, string source)
		{
			try
			{
				Logger.Info("Sending message to Android for affiliate");
				Dictionary<string, string> dictionary = new Dictionary<string, string>
				{
					{
						"action",
						"com.bluestacks.home.AFFILIATE_HANDLER_HTML"
					}
				};
				JObject jobject = new JObject
				{
					{
						"success",
						true
					},
					{
						"app_pkg",
						pkgName
					},
					{
						"WINDOWS_SOURCE",
						source
					}
				};
				dictionary.Add("extras", jobject.ToString(Formatting.None, new JsonConverter[0]));
				HTTPUtils.SendRequestToGuest("customStartService", dictionary, this.ParentWindow.mVmName, 0, null, false, 1, 0);
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't send message to Adnroid: " + ex.ToString());
			}
		}

		// Token: 0x06000D8B RID: 3467 RVA: 0x000594C4 File Offset: 0x000576C4
		public void AppendUrlWithCommonParamsAndOpenTab(string url, string title, string imagePath, string tabKey = "")
		{
			try
			{
				url = WebHelper.GetUrlWithParams(url);
				if (new Uri(url).Host.Contains("bluestacks", StringComparison.InvariantCultureIgnoreCase))
				{
					string registeredEmail = RegistryManager.Instance.RegisteredEmail;
					string token = RegistryManager.Instance.Token;
					if (string.IsNullOrEmpty(registeredEmail))
					{
						Logger.Warning("User email not found. Not opening webpage.");
					}
					if (string.IsNullOrEmpty(token))
					{
						Logger.Warning("User token not found. Not opening webpage.");
					}
				}
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					this.ParentWindow.mTopBar.mAppTabButtons.AddWebTab(url, title, imagePath, true, tabKey, false);
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception when parsing uri for opening in webtab " + ex.ToString());
			}
		}

		// Token: 0x06000D8C RID: 3468 RVA: 0x000595B0 File Offset: 0x000577B0
		public void ApplyTheme(string themeName)
		{
			BlueStacksUIColorManager.ReloadAppliedTheme(themeName);
			BlueStacksUIUtils.RefreshAppCenterUrl();
			BlueStacksUIUtils.RefreshHtmlSidePanelUrl();
			this.ParentWindow.mCommonHandler.SetCustomCursorForApp(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName);
			ClientStats.SendMiscellaneousStatsAsync("SkinChangedStats", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.ClientThemeName, null, null, null, null);
		}

		// Token: 0x06000D8D RID: 3469 RVA: 0x00059628 File Offset: 0x00057828
		public void RestoreWallpaperImageForAllVms()
		{
			foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>())
			{
				mainWindow.mWelcomeTab.mHomeApp.RestoreWallpaperImage();
			}
		}

		// Token: 0x06000D8E RID: 3470 RVA: 0x0005968C File Offset: 0x0005788C
		internal static string GetAppCenterUrl(string tabId)
		{
			string text = WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/page/appcenter-v2");
			text += "&theme=";
			text += RegistryManager.ClientThemeName;
			text += "&naked=1";
			if (!string.IsNullOrEmpty(tabId))
			{
				text += "&tabid=";
				text += tabId;
			}
			return text;
		}

		// Token: 0x06000D8F RID: 3471 RVA: 0x0000A1A2 File Offset: 0x000083A2
		internal static string GetHtmlSidePanelUrl()
		{
			return WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/page/myapps-sidepanel") + "&theme=" + RegistryManager.ClientThemeName;
		}

		// Token: 0x06000D90 RID: 3472 RVA: 0x0000A1CC File Offset: 0x000083CC
		internal static string GetGiftTabUrl()
		{
			return WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/gift") + "&theme=" + RegistryManager.ClientThemeName;
		}

		// Token: 0x06000D91 RID: 3473 RVA: 0x0000A1F6 File Offset: 0x000083F6
		internal static string GetPikaWorldUrl()
		{
			return WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/pikaworld") + "&naked=1";
		}

		// Token: 0x06000D92 RID: 3474 RVA: 0x000596F0 File Offset: 0x000578F0
		internal void SwitchProfile(string vmName, string pcode)
		{
			try
			{
				Dictionary<string, string> data = new Dictionary<string, string>();
				JObject jobject = new JObject
				{
					{
						"pcode",
						pcode
					},
					{
						"createcustomprofile",
						"false"
					}
				};
				data.Add("data", jobject.ToString(Formatting.None, new JsonConverter[0]));
				BlueStacksUIUtils.DictWindows[vmName].mExitProgressGrid.ProgressText = "STRING_SWITCHING_PROFILE";
				BlueStacksUIUtils.DictWindows[vmName].mExitProgressGrid.Visibility = Visibility.Visible;
				Action <>9__1;
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					JObject jobject2 = new JObject();
					jobject2["pcode"] = Utils.GetValueInBootParams("pcode", this.ParentWindow.mVmName, "");
					JObject value = jobject2;
					string text = HTTPUtils.SendRequestToGuest("changeDeviceProfile", data, vmName, 0, null, false, 3, 60000);
					Logger.Info("Response for ChangeDeviceProfile: " + text);
					JObject jobject3 = JObject.Parse(text);
					Dispatcher dispatcher = this.ParentWindow.Dispatcher;
					Action method;
					if ((method = <>9__1) == null)
					{
						method = (<>9__1 = delegate()
						{
							this.ParentWindow.mExitProgressGrid.ProgressText = "STRING_CLOSING_BLUESTACKS";
							this.ParentWindow.mExitProgressGrid.Visibility = Visibility.Hidden;
						});
					}
					dispatcher.Invoke(method, new object[0]);
					JObject jobject4 = new JObject();
					jobject4["pcode"] = pcode;
					JObject value2 = jobject4;
					if (jobject3["result"].ToString() == "ok")
					{
						Logger.Info("Successfully updated Device Profile.");
						Utils.UpdateValueInBootParams("pcode", pcode, this.ParentWindow.mVmName, false);
						this.ParentWindow.mCommonHandler.AddToastPopup(this.ParentWindow, LocaleStrings.GetLocalizedString("STRING_SWITCH_PROFILE_UPDATED"), 1.3, false);
						ClientStats.SendMiscellaneousStatsAsync("DeviceProfileChangeStats", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "success", JsonConvert.SerializeObject(value2), JsonConvert.SerializeObject(value), RegistryManager.Instance.Version, "GRM", null);
						return;
					}
					Logger.Warning("DeviceProfile Update failed in android");
					this.ParentWindow.mCommonHandler.AddToastPopup(this.ParentWindow, LocaleStrings.GetLocalizedString("STRING_SWITCH_PROFILE_FAILED"), 1.3, false);
					ClientStats.SendMiscellaneousStatsAsync("DeviceProfileChangeStats", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "failed", JsonConvert.SerializeObject(value2), JsonConvert.SerializeObject(value), RegistryManager.Instance.Version, "GRM", null);
				});
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in SwitchProfileAndRestart: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x06000D93 RID: 3475 RVA: 0x0000A216 File Offset: 0x00008416
		internal static string GetHelpCenterUrl()
		{
			return WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/feedback");
		}

		// Token: 0x06000D94 RID: 3476 RVA: 0x00059804 File Offset: 0x00057A04
		internal static void RefreshHtmlSidePanelUrl()
		{
			foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values)
			{
				try
				{
					BrowserControl sideHtmlBrowser = mainWindow.mWelcomeTab.mHomeApp.SideHtmlBrowser;
					if (sideHtmlBrowser != null)
					{
						sideHtmlBrowser.ReInitBrowser(BlueStacksUIUtils.GetHtmlSidePanelUrl());
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Error while refreshing side html panel for vmname: {0} and exception is: {1}", new object[]
					{
						mainWindow.mVmName,
						ex
					});
				}
			}
		}

		// Token: 0x06000D95 RID: 3477 RVA: 0x000598A4 File Offset: 0x00057AA4
		internal static void RefreshAppCenterUrl()
		{
			if (BlueStacksUIUtils.DictWindows.ContainsKey(Strings.CurrentDefaultVmName))
			{
				MainWindow mainWindow = BlueStacksUIUtils.DictWindows[Strings.CurrentDefaultVmName];
				AppTabButton tab = mainWindow.mTopBar.mAppTabButtons.GetTab("appcenter");
				if (tab != null && tab.GetBrowserControl() != null)
				{
					tab.GetBrowserControl().NavigateTo(BlueStacksUIUtils.GetAppCenterUrl(""));
				}
				AppTabButton tab2 = mainWindow.mTopBar.mAppTabButtons.GetTab("gift");
				if (tab2 != null && tab2.GetBrowserControl() != null)
				{
					tab2.GetBrowserControl().NavigateTo(BlueStacksUIUtils.GetGiftTabUrl());
				}
			}
		}

		// Token: 0x06000D96 RID: 3478 RVA: 0x0000A22C File Offset: 0x0000842C
		internal static string GetMacroCommunityUrl(string currentAppPackage)
		{
			return WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/page/macro-share") + "&pkg=" + currentAppPackage;
		}

		// Token: 0x06000D97 RID: 3479 RVA: 0x00059938 File Offset: 0x00057B38
		internal bool IsRequiredFreeRAMAvailable()
		{
			try
			{
				ulong num = 1048576UL;
				ulong availablePhysicalMemory = new ComputerInfo().AvailablePhysicalMemory;
				int num2 = this.ParentWindow.EngineInstanceRegistry.Memory + 100;
				if (num2 > 2148)
				{
					num2 = 2148;
				}
				ulong num3 = (ulong)((long)num2 * (long)num);
				if (availablePhysicalMemory < num3)
				{
					Logger.Warning("Available physical memory is less than required. {0} < {1}", new object[]
					{
						availablePhysicalMemory / num,
						num2
					});
					return false;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("An error occurred while finding free RAM");
				Logger.Error(ex.ToString());
			}
			return true;
		}

		// Token: 0x06000D98 RID: 3480 RVA: 0x000599D8 File Offset: 0x00057BD8
		internal bool CheckQuitPopupLocal()
		{
			try
			{
				if (!this.ParentWindow.mGuestBootCompleted)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						QuitPopupControl quitPopupControl = new QuitPopupControl(this.ParentWindow);
						string text = "exit_popup_boot";
						quitPopupControl.CurrentPopupTag = text;
						BlueStacksUIBinding.Bind(quitPopupControl.TitleTextBlock, "STRING_TROUBLE_STARTING_BLUESTACKS", "");
						BlueStacksUIBinding.Bind(quitPopupControl.mCloseBlueStacksButton, "STRING_CLOSE_BLUESTACKS");
						quitPopupControl.AddQuitActionItem(QuitActionItem.StuckAtBoot);
						quitPopupControl.AddQuitActionItem(QuitActionItem.SlowPerformance);
						quitPopupControl.AddQuitActionItem(QuitActionItem.SomethingElseWrong);
						quitPopupControl.CloseBlueStacksButton.PreviewMouseUp += new MouseButtonEventHandler(this.ParentWindow.MainWindow_CloseWindowConfirmationAcceptedHandler);
						this.ParentWindow.HideDimOverlay();
						this.ParentWindow.ShowDimOverlay(quitPopupControl);
						ClientStats.SendLocalQuitPopupStatsAsync(text, "popup_shown");
					}), new object[0]);
					return true;
				}
				if (!RegistryManager.Instance.Guest[this.ParentWindow.mVmName].IsGoogleSigninDone && string.Equals(this.ParentWindow.StaticComponents.mSelectedTabButton.PackageName, "com.android.vending", StringComparison.InvariantCultureIgnoreCase))
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						QuitPopupControl quitPopupControl = new QuitPopupControl(this.ParentWindow);
						string text = "exit_popup_ots";
						quitPopupControl.CurrentPopupTag = text;
						BlueStacksUIBinding.Bind(quitPopupControl.TitleTextBlock, "STRING_YOU_ARE_ONE_STEP_AWAY", "");
						BlueStacksUIBinding.Bind(quitPopupControl.mCloseBlueStacksButton, "STRING_CLOSE_BLUESTACKS");
						quitPopupControl.AddQuitActionItem(QuitActionItem.WhyGoogleAccount);
						quitPopupControl.AddQuitActionItem(QuitActionItem.TroubleSigningIn);
						quitPopupControl.AddQuitActionItem(QuitActionItem.SomethingElseWrong);
						quitPopupControl.CloseBlueStacksButton.PreviewMouseUp += new MouseButtonEventHandler(this.ParentWindow.MainWindow_CloseWindowConfirmationAcceptedHandler);
						this.ParentWindow.HideDimOverlay();
						this.ParentWindow.ShowDimOverlay(quitPopupControl);
						ClientStats.SendLocalQuitPopupStatsAsync(text, "popup_shown");
					}), new object[0]);
					return true;
				}
				if (this.ParentWindow.mVmName == "Android" && RegistryManager.Instance.FirstAppLaunchState != AppLaunchState.Launched)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						QuitPopupControl quitPopupControl = new QuitPopupControl(this.ParentWindow);
						string text = "exit_popup_no_app";
						quitPopupControl.CurrentPopupTag = text;
						BlueStacksUIBinding.Bind(quitPopupControl.TitleTextBlock, "STRING_HAVING_TROUBLE_STARTING_GAME", "");
						BlueStacksUIBinding.Bind(quitPopupControl.ReturnBlueStacksButton, "STRING_RETURN_BLUESTACKS");
						BlueStacksUIBinding.Bind(quitPopupControl.CloseBlueStacksButton, "STRING_CLOSE_BLUESTACKS");
						quitPopupControl.AddQuitActionItem(QuitActionItem.UnsureWhereStart);
						quitPopupControl.AddQuitActionItem(QuitActionItem.IssueInstallingGame);
						quitPopupControl.AddQuitActionItem(QuitActionItem.FacingOtherTroubles);
						quitPopupControl.CloseBlueStacksButton.PreviewMouseUp += new MouseButtonEventHandler(this.ParentWindow.MainWindow_CloseWindowConfirmationAcceptedHandler);
						this.ParentWindow.HideDimOverlay();
						this.ParentWindow.ShowDimOverlay(quitPopupControl);
						ClientStats.SendLocalQuitPopupStatsAsync(text, "popup_shown");
					}), new object[0]);
					return true;
				}
				if (this.ParentWindow.EngineInstanceRegistry.IsShowMinimizeBlueStacksPopupOnClose && this.ParentWindow.Utils.CheckIfMinimizeBlueStacksPopupToBeShown())
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						this.ParentWindow.HideDimOverlay();
						MinimizeBlueStacksOnCloseView minimizeBlueStacksOnCloseView = new MinimizeBlueStacksOnCloseView(this.ParentWindow);
						new ContainerWindow(this.ParentWindow, minimizeBlueStacksOnCloseView, minimizeBlueStacksOnCloseView.Width, minimizeBlueStacksOnCloseView.Height, true, true);
					}), new object[0]);
					return true;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while trying to show local quit popup. " + ex.ToString());
			}
			return false;
		}

		// Token: 0x06000D99 RID: 3481 RVA: 0x00059B58 File Offset: 0x00057D58
		private bool CheckIfMinimizeBlueStacksPopupToBeShown()
		{
			if (PostBootCloudInfoManager.Instance.mPostBootCloudInfo != null)
			{
				foreach (string appPackage in Utils.GetInstalledPackagesFromAppsJSon(this.ParentWindow.mVmName).Split(new char[]
				{
					','
				}).ToList<string>())
				{
					AppPackageListObject gameNotificationAppPackages = PostBootCloudInfoManager.Instance.mPostBootCloudInfo.GameNotificationAppPackages;
					if (((gameNotificationAppPackages != null) ? new bool?(gameNotificationAppPackages.IsPackageAvailable(appPackage)) : null).Value)
					{
						return true;
					}
				}
				return false;
			}
			return false;
		}

		// Token: 0x06000D9A RID: 3482 RVA: 0x00059C0C File Offset: 0x00057E0C
		public void OpenPikaAccountPage()
		{
			if (this.ParentWindow.mAppHandler.IsOneTimeSetupCompleted && !string.IsNullOrEmpty(RegistryManager.Instance.RegisteredEmail))
			{
				string text = WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/bluestacks_account?extra=section:pika");
				text += "&email=";
				text += RegistryManager.Instance.RegisteredEmail;
				text += "&token=";
				text += RegistryManager.Instance.Token;
				this.ParentWindow.mTopBar.mAppTabButtons.AddWebTab(text, "STRING_ACCOUNT", "account_tab", true, "account_tab", true);
			}
		}

		// Token: 0x06000D9B RID: 3483 RVA: 0x00059CB8 File Offset: 0x00057EB8
		internal void HandleApplicationBrowserClick(string clickActionValue, string title, string key, bool paramsOnlyActionValue = false, string customImageName = "")
		{
			title = title.Trim();
			string imagePath = "cef_tab";
			if (key != null)
			{
				uint num = <PrivateImplementationDetails>.ComputeStringHash(key);
				if (num > 2737665056U)
				{
					if (num <= 3655924613U)
					{
						if (num != 2938085890U)
						{
							if (num != 3655924613U)
							{
								goto IL_209;
							}
							if (!(key == "appcenter"))
							{
								goto IL_209;
							}
							goto IL_138;
						}
						else if (!(key == "pikaworld"))
						{
							goto IL_209;
						}
					}
					else if (num != 3727264231U)
					{
						if (num != 3975455884U)
						{
							goto IL_209;
						}
						if (!(key == "MAPS_TEXT"))
						{
							goto IL_209;
						}
					}
					else
					{
						if (!(key == "GIFT_TEXT"))
						{
							goto IL_209;
						}
						goto IL_172;
					}
					clickActionValue = HTTPUtils.MergeQueryParams(BlueStacksUIUtils.GetPikaWorldUrl(), clickActionValue, paramsOnlyActionValue);
					if (string.IsNullOrEmpty(title))
					{
						title = LocaleStrings.GetLocalizedString("STRING_MAPS");
					}
					key = "pikaworld";
					imagePath = "pikaworld";
					goto IL_209;
				}
				if (num <= 2322801903U)
				{
					if (num != 255579182U)
					{
						if (num != 2322801903U)
						{
							goto IL_209;
						}
						if (!(key == "gift"))
						{
							goto IL_209;
						}
						goto IL_172;
					}
					else if (!(key == "APP_CENTER_TEXT"))
					{
						goto IL_209;
					}
				}
				else if (num != 2333368623U)
				{
					if (num != 2737665056U)
					{
						goto IL_209;
					}
					if (!(key == "FEEDBACK_TEXT"))
					{
						goto IL_209;
					}
					clickActionValue = HTTPUtils.MergeQueryParams(BlueStacksUIUtils.GetHelpCenterUrl(), clickActionValue, paramsOnlyActionValue);
					Process.Start(clickActionValue);
					return;
				}
				else
				{
					if (!(key == "preregistration"))
					{
						goto IL_209;
					}
					if (string.IsNullOrEmpty(title))
					{
						title = LocaleStrings.GetLocalizedString("STRING_PREREGISTER");
					}
					imagePath = "preregistration";
					goto IL_209;
				}
				IL_138:
				clickActionValue = HTTPUtils.MergeQueryParams(BlueStacksUIUtils.GetAppCenterUrl(""), clickActionValue, paramsOnlyActionValue);
				if (string.IsNullOrEmpty(title))
				{
					title = LocaleStrings.GetLocalizedString("STRING_APP_CENTER");
				}
				key = "appcenter";
				imagePath = "appcenter";
				goto IL_209;
				IL_172:
				clickActionValue = HTTPUtils.MergeQueryParams(BlueStacksUIUtils.GetGiftTabUrl(), clickActionValue, paramsOnlyActionValue);
				if (string.IsNullOrEmpty(title))
				{
					title = LocaleStrings.GetLocalizedString("STRING_GIFT");
				}
				key = "gift";
				imagePath = "gift";
			}
			IL_209:
			if (!string.IsNullOrEmpty(customImageName))
			{
				imagePath = customImageName;
			}
			this.ParentWindow.Utils.AppendUrlWithCommonParamsAndOpenTab(clickActionValue, title, imagePath, key);
		}

		// Token: 0x06000D9C RID: 3484 RVA: 0x0000A24D File Offset: 0x0000844D
		private static string GetImagePath(Dictionary<string, string> payload, string customImageName = "")
		{
			if (!string.IsNullOrEmpty(customImageName))
			{
				return customImageName;
			}
			if (payload.ContainsKey("icon_path"))
			{
				return payload["icon_path"];
			}
			return "";
		}

		// Token: 0x06000D9D RID: 3485 RVA: 0x00059EF0 File Offset: 0x000580F0
		public void HandleGenericActionFromDictionary(Dictionary<string, string> payload, string source, string customImageName = "")
		{
			try
			{
				if (payload.ContainsKey("click_generic_action"))
				{
					GenericAction genericAction = EnumHelper.Parse<GenericAction>(payload["click_generic_action"], GenericAction.None);
					if (genericAction <= GenericAction.SettingsMenu)
					{
						if (genericAction <= GenericAction.UserBrowser)
						{
							switch (genericAction)
							{
							case GenericAction.InstallPlay:
								if (!this.ParentWindow.mAppHandler.IsAppInstalled(payload["click_action_packagename"]))
								{
									this.ParentWindow.Utils.SendMessageToAndroidForAffiliate(payload["click_action_packagename"], source);
								}
								this.ParentWindow.mWelcomeTab.mFrontendPopupControl.Init(payload["click_action_packagename"], payload["click_action_title"], PlayStoreAction.OpenApp, true);
								goto IL_48B;
							case GenericAction.InstallCDN:
								if (!this.ParentWindow.mAppHandler.IsAppInstalled(payload["click_action_packagename"]))
								{
									this.ParentWindow.Utils.SendMessageToAndroidForAffiliate(payload["click_action_packagename"], source);
								}
								this.ParentWindow.mAppInstaller.DownloadAndInstallApp(string.Empty, payload["click_action_title"], payload["click_action_value"], payload["click_action_packagename"], false, true, "");
								goto IL_48B;
							case (GenericAction)3:
								break;
							case GenericAction.ApplicationBrowser:
								this.HandleApplicationBrowserClick(payload["click_action_value"], payload["click_action_title"], payload.ContainsKey("click_action_key") ? payload["click_action_key"] : "", false, BlueStacksUIUtils.GetImagePath(payload, customImageName));
								goto IL_48B;
							default:
								if (genericAction == GenericAction.UserBrowser)
								{
									BlueStacksUIUtils.OpenUrl(payload["click_action_value"]);
									goto IL_48B;
								}
								break;
							}
						}
						else if (genericAction != GenericAction.HomeAppTab)
						{
							if (genericAction == GenericAction.SettingsMenu)
							{
								this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
								{
									MainWindow.OpenSettingsWindow(this.ParentWindow, payload["click_action_value"]);
								}), new object[0]);
								goto IL_48B;
							}
						}
						else
						{
							this.ParentWindow.mTopBar.mAppTabButtons.GoToTab("Home", true, false);
							if (string.Compare(payload["click_action_value"], "my_app_text", StringComparison.OrdinalIgnoreCase) == 0)
							{
								goto IL_48B;
							}
							if (payload.ContainsKey("query_params") && !string.IsNullOrEmpty(payload["query_params"].Trim()))
							{
								this.HandleApplicationBrowserClick(payload["query_params"], "", payload["click_action_value"], true, customImageName);
								goto IL_48B;
							}
							this.HandleApplicationBrowserClick("", "", payload["click_action_value"], true, customImageName);
							goto IL_48B;
						}
					}
					else if (genericAction <= GenericAction.OpenSystemApp)
					{
						if (genericAction != GenericAction.KeyBasedPopup)
						{
							if (genericAction == GenericAction.OpenSystemApp)
							{
								this.ParentWindow.mTopBar.mAppTabButtons.AddAppTab(payload["click_action_title"], payload["click_action_packagename"], payload["click_action_app_activity"], BlueStacksUIUtils.GetImagePath(payload, customImageName), false, true, false);
								this.ParentWindow.mAppHandler.SwitchWhenPackageNameRecieved = payload["click_action_packagename"];
								this.ParentWindow.mAppHandler.SendRunAppRequestAsync(payload["click_action_packagename"], payload["click_action_app_activity"], false);
								goto IL_48B;
							}
						}
						else
						{
							string text = payload["click_action_key"].Trim().ToLower(CultureInfo.InvariantCulture);
							if (text == null)
							{
								goto IL_48B;
							}
							if (text == "instance_manager")
							{
								BlueStacksUIUtils.LaunchMultiInstanceManager();
								goto IL_48B;
							}
							if (!(text == "macro_recorder"))
							{
								goto IL_48B;
							}
							this.ParentWindow.mCommonHandler.ShowMacroRecorderWindow();
							goto IL_48B;
						}
					}
					else
					{
						if (genericAction == GenericAction.PopupBrowser)
						{
							this.ParentWindow.mCommonHandler.OpenBrowserInPopup(payload);
							goto IL_48B;
						}
						if (genericAction == GenericAction.QuickLaunch)
						{
							BlueStacksUIUtils.LaunchAllInstancesAndArrange();
							goto IL_48B;
						}
					}
					Logger.Warning("Unknown case {0}", new object[]
					{
						payload["click_generic_action"]
					});
				}
				IL_48B:;
			}
			catch (Exception ex)
			{
				Logger.Error(string.Concat(new string[]
				{
					"Exception on handling click event for payload ",
					payload.ToDebugString<string, string>(),
					Environment.NewLine,
					"Exception: ",
					ex.ToString()
				}));
			}
		}

		// Token: 0x06000D9E RID: 3486 RVA: 0x0005A3E8 File Offset: 0x000585E8
		internal bool CheckQuitPopupFromCloud(string appPackage = "")
		{
			bool result;
			try
			{
				Logger.Info("IsQuitPopupNotificationReceived status: " + this.ParentWindow.IsQuitPopupNotficationReceived.ToString());
				if (!RegistryManager.Instance.ShowGamingSummary || !this.ParentWindow.IsQuitPopupNotficationReceived || (string.IsNullOrEmpty(appPackage) && !this.ParentWindow.mQuitPopupBrowserControl.ShowOnQuit) || (!string.Equals(this.ParentWindow.mQuitPopupBrowserControl.mPackage, appPackage, StringComparison.InvariantCulture) && !string.Equals(this.ParentWindow.mQuitPopupBrowserControl.mPackage, "*", StringComparison.InvariantCulture) && !string.IsNullOrEmpty(appPackage)))
				{
					result = false;
				}
				else
				{
					this.ParentWindow.IsQuitPopupNotficationReceived = false;
					string url = this.ParentWindow.mQuitPopupBrowserControl.mUrl;
					if (this.ParentWindow.mQuitPopupBrowserControl.mForceReload)
					{
						string str = JsonConvert.SerializeObject(AppUsageTimer.GetRealtimeDictionary()[this.ParentWindow.mVmName], Formatting.None);
						string urlOverideParams = "usage_data=" + str;
						url = HTTPUtils.MergeQueryParams(url, urlOverideParams, true);
						url = WebHelper.GetUrlWithParams(url);
						this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
						{
							Logger.Info("Is mFirebaseBrowserControl null : " + ((this.ParentWindow.FirebaseBrowserControlGrid == null) ? "true" : "false"));
							foreach (object obj in this.ParentWindow.FirebaseBrowserControlGrid.Children)
							{
								BrowserControl browserControl = obj as BrowserControl;
								if (browserControl != null)
								{
									object[] args = new object[]
									{
										url
									};
									browserControl.CefBrowser.CallJs("setIframeUrl", args);
									break;
								}
							}
						}), new object[0]);
					}
					else
					{
						url = WebHelper.GetUrlWithParams(url);
					}
					if (!string.IsNullOrEmpty(url))
					{
						this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
						{
							this.ParentWindow.HideDimOverlay();
							this.ParentWindow.ShowBrowserQuitPopUp(url, appPackage);
						}), new object[0]);
						result = true;
					}
					else
					{
						result = false;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while trying to show quit popup. " + ex.ToString());
				result = false;
			}
			return result;
		}

		// Token: 0x06000D9F RID: 3487 RVA: 0x0000A277 File Offset: 0x00008477
		internal static void LaunchMultiInstanceManager()
		{
			if (!FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				ProcessUtils.GetProcessObject(Path.Combine(RegistryStrings.InstallDir, "HD-MultiInstanceManager.exe"), null, false).Start();
			}
		}

		// Token: 0x06000DA0 RID: 3488 RVA: 0x0005A5D8 File Offset: 0x000587D8
		internal static void RemoveChildFromParent(UIElement child)
		{
			DependencyObject parent = VisualTreeHelper.GetParent(child);
			Panel panel = parent as Panel;
			if (panel != null)
			{
				panel.Children.Remove(child);
			}
			ContentControl contentControl = parent as ContentControl;
			if (contentControl != null)
			{
				contentControl.Content = null;
			}
			Decorator decorator = parent as Decorator;
			if (decorator != null)
			{
				decorator.Child = null;
			}
		}

		// Token: 0x06000DA1 RID: 3489 RVA: 0x0005A624 File Offset: 0x00058824
		public static void UpdateLocale(string locale, string vmToIgnore = "")
		{
			new List<string>();
			using (List<string>.Enumerator enumerator = RegistryManager.Instance.VmList.ToList<string>().GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					string vmName = enumerator.Current;
					try
					{
						if (!RegistryManager.Instance.Guest.ContainsKey(vmName))
						{
							InstanceRegistry value = new InstanceRegistry(vmName);
							RegistryManager.Instance.Guest.Add(vmName, value);
						}
						if (RegistryManager.Instance.UserSelectedLocale != RegistryManager.Instance.Guest[vmName].Locale)
						{
							RegistryManager.Instance.Guest[vmName].Locale = locale;
							Utils.UpdateValueInBootParams("LANG", locale, vmName, false);
							if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName) && string.Compare(vmName, vmToIgnore.Trim(), StringComparison.OrdinalIgnoreCase) != 0)
							{
								string cmd = string.Format(CultureInfo.InvariantCulture, "setlocale {0}", new object[]
								{
									locale
								});
								new Thread(delegate()
								{
									if (VmCmdHandler.RunCommand(cmd, vmName) == null)
									{
										Logger.Error("Set locale did not work for vm " + vmName);
									}
								})
								{
									IsBackground = true
								}.Start();
							}
						}
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to change locale for vm : " + vmName);
						Logger.Error(ex.ToString());
					}
				}
			}
			HTTPUtils.SendRequestToAgentAsync("reinitlocalization", null, "Android", 0, null, false, 1, 0);
			LocaleStrings.InitLocalization(null, "Android", false);
		}

		// Token: 0x06000DA2 RID: 3490 RVA: 0x0005A7F0 File Offset: 0x000589F0
		internal static bool SendBluestacksLoginRequest(string vmName)
		{
			bool result = false;
			try
			{
				Dictionary<string, string> dictionary = new Dictionary<string, string>
				{
					{
						"action",
						"com.bluestacks.account.RETRY_BLUESTACKS_LOGIN"
					}
				};
				JObject jobject = new JObject
				{
					{
						"windows",
						"true"
					}
				};
				dictionary.Add("extras", jobject.ToString(Formatting.None, new JsonConverter[0]));
				Logger.Info("Sending bluestacks login request");
				HTTPUtils.SendRequestToGuest("customStartService".ToLower(CultureInfo.InvariantCulture), dictionary, vmName, 500, null, false, 1, 0);
				result = true;
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't send request to guest for login. Ex: {0}", new object[]
				{
					ex.Message
				});
			}
			return result;
		}

		// Token: 0x06000DA3 RID: 3491 RVA: 0x0000A2A1 File Offset: 0x000084A1
		internal static bool CheckIfMacroScriptBookmarked(string fileName)
		{
			return RegistryManager.Instance.BookmarkedScriptList.Contains(fileName);
		}

		// Token: 0x06000DA4 RID: 3492 RVA: 0x0000A2B8 File Offset: 0x000084B8
		internal static string GetMacroPlaybackEventName(string vmname)
		{
			return string.Format(CultureInfo.InvariantCulture, "{0}-{1}", new object[]
			{
				"MacroPlayBack",
				vmname
			});
		}

		// Token: 0x06000DA5 RID: 3493 RVA: 0x0005A8A4 File Offset: 0x00058AA4
		internal void HandleLaunchPlay(string package)
		{
			object obj = BlueStacksUIUtils.mLaunchPlaySyncObj;
			lock (obj)
			{
				int i = 180000;
				while (i > 0)
				{
					i--;
					if (this.ParentWindow.mEnableLaunchPlayForNCSoft || (!FeatureManager.Instance.IsCustomUIForNCSoft && this.ParentWindow.mGuestBootCompleted))
					{
						break;
					}
					Thread.Sleep(1000);
				}
				if (i > 0)
				{
					HTTPUtils.SendRequestToGuest(string.Format(CultureInfo.InvariantCulture, "launchplay?pkgname={0}", new object[]
					{
						package
					}), null, this.ParentWindow.mVmName, 0, null, false, 1, 0);
				}
			}
		}

		// Token: 0x06000DA6 RID: 3494 RVA: 0x0005A94C File Offset: 0x00058B4C
		internal void VolumeDownHandler()
		{
			if (this.CurrentVolumeLevel == 0)
			{
				return;
			}
			int num = this.CurrentVolumeLevel - 7;
			if (num <= 0)
			{
				num = 0;
			}
			this.SetVolumeInFrontendAsync(num);
		}

		// Token: 0x06000DA7 RID: 3495 RVA: 0x0005A978 File Offset: 0x00058B78
		internal void VolumeUpHandler()
		{
			if (this.CurrentVolumeLevel >= 100)
			{
				return;
			}
			int num = this.CurrentVolumeLevel + 7;
			if (num >= 100)
			{
				num = 100;
			}
			this.SetVolumeInFrontendAsync(num);
		}

		// Token: 0x06000DA8 RID: 3496 RVA: 0x0000A2DB File Offset: 0x000084DB
		internal void ToggleTopBarSidebarEnabled(bool isEnabled)
		{
			this.ParentWindow.TopBar.IsEnabled = isEnabled;
			this.ParentWindow.mSidebar.IsEnabled = isEnabled;
		}

		// Token: 0x06000DA9 RID: 3497 RVA: 0x0005A9A8 File Offset: 0x00058BA8
		internal static void SendGamepadStatusToBrowsers(bool status)
		{
			try
			{
				object[] array = new object[]
				{
					""
				};
				array[0] = status.ToString(CultureInfo.InvariantCulture);
				foreach (BrowserControl browserControl in BrowserControl.sAllBrowserControls)
				{
					try
					{
						if (browserControl != null && browserControl.CefBrowser != null)
						{
							browserControl.CefBrowser.CallJs("toggleGamePadSupport", array);
						}
					}
					catch (Exception ex)
					{
						Logger.Error("Exception in sending gamepad status to browser:" + browserControl.mUrl + Environment.NewLine + ex.ToString());
					}
				}
			}
			catch (Exception ex2)
			{
				Logger.Error("Exception in sending gamepad status to browser:" + ex2.ToString());
			}
		}

		// Token: 0x06000DAA RID: 3498 RVA: 0x0005AA88 File Offset: 0x00058C88
		internal static double GetDefaultHeight()
		{
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				return SystemParameters.MaximizedPrimaryScreenHeight * 0.6 + 94.0;
			}
			return SystemParameters.MaximizedPrimaryScreenHeight * 0.75 + 94.0;
		}

		// Token: 0x06000DAB RID: 3499 RVA: 0x0000A2FF File Offset: 0x000084FF
		protected virtual void Dispose(bool disposing)
		{
			if (!this.disposedValue)
			{
				if (this.sBootCheckTimer != null)
				{
					this.sBootCheckTimer.Elapsed -= this.SBootCheckTimer_Elapsed;
					this.sBootCheckTimer.Dispose();
				}
				this.disposedValue = true;
			}
		}

		// Token: 0x06000DAC RID: 3500 RVA: 0x0005AAD4 File Offset: 0x00058CD4
		~BlueStacksUIUtils()
		{
			this.Dispose(false);
		}

		// Token: 0x06000DAD RID: 3501 RVA: 0x0000A33C File Offset: 0x0000853C
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x06000DAE RID: 3502 RVA: 0x0005AB04 File Offset: 0x00058D04
		internal static Dictionary<string, string> GetEngineSettingsData(string vmName)
		{
			return new Dictionary<string, string>
			{
				{
					"cpu",
					RegistryManager.Instance.Guest[vmName].VCPUs.ToString(CultureInfo.InvariantCulture)
				},
				{
					"ram",
					RegistryManager.Instance.Guest[vmName].Memory.ToString(CultureInfo.InvariantCulture)
				},
				{
					"glMode",
					RegistryManager.Instance.Guest[vmName].GlMode.ToString(CultureInfo.InvariantCulture)
				},
				{
					"glRenderMode",
					RegistryManager.Instance.Guest[vmName].GlRenderMode.ToString(CultureInfo.InvariantCulture)
				},
				{
					"gpu",
					RegistryManager.Instance.AvailableGPUDetails
				}
			};
		}

		// Token: 0x06000DAF RID: 3503 RVA: 0x0005ABE0 File Offset: 0x00058DE0
		internal static Dictionary<string, string> GetResolutionData()
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			int guestWidth = RegistryManager.Instance.Guest[Strings.CurrentDefaultVmName].GuestWidth;
			int guestHeight = RegistryManager.Instance.Guest[Strings.CurrentDefaultVmName].GuestHeight;
			string value = Convert.ToString(guestWidth, CultureInfo.InvariantCulture) + "x" + Convert.ToString(guestHeight, CultureInfo.InvariantCulture);
			dictionary.Add("resolution", value);
			double num = (double)guestWidth / (double)guestHeight;
			string value2 = "landscape";
			if (num < 1.0)
			{
				value2 = "portrait";
			}
			dictionary.Add("resolution_type", value2);
			return dictionary;
		}

		// Token: 0x06000DB0 RID: 3504 RVA: 0x0005AC7C File Offset: 0x00058E7C
		internal void DownloadAndUpdateMacro(string macroData)
		{
			try
			{
				JObject jobject = JObject.Parse(macroData);
				string value = jobject["macro_name"].ToString();
				string url = jobject["download_link"].ToString();
				string userName = jobject["nickname"].ToString();
				string authorPageUrl = jobject["author_url"].ToString();
				string macroId = jobject["macro_id"].ToString();
				string macroPageUrl = jobject["macro_url"].ToString();
				string invalidCharsFreeName;
				if (value.GetValidFileName(out invalidCharsFreeName))
				{
					string path = string.Format(CultureInfo.InvariantCulture, "{0}.json", new object[]
					{
						invalidCharsFreeName
					});
					string filePath = Path.Combine(Path.GetTempPath(), path);
					new Thread(delegate()
					{
						using (WebClient webClient = new WebClient())
						{
							try
							{
								webClient.DownloadFile(url, filePath);
							}
							catch (Exception ex)
							{
								Logger.Error("Failed to download macro at path : " + filePath + ". Ex : " + ex.ToString());
							}
							finally
							{
								if (webClient != null)
								{
									webClient.Dispose();
								}
							}
							if (File.Exists(filePath))
							{
								this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
								{
									try
									{
										MacroRecording macroRecording = JsonConvert.DeserializeObject<MacroRecording>(File.ReadAllText(filePath), Utils.GetSerializerSettings());
										int num;
										try
										{
											if (!string.IsNullOrEmpty(userName))
											{
												macroRecording.User = userName;
											}
											Uri authorPageUrl;
											if (!string.IsNullOrEmpty(authorPageUrl) && Uri.TryCreate(authorPageUrl, UriKind.RelativeOrAbsolute, out authorPageUrl))
											{
												macroRecording.AuthorPageUrl = authorPageUrl;
											}
											if (!string.IsNullOrEmpty(macroId))
											{
												macroRecording.MacroId = macroId;
											}
											Uri macroPageUrl;
											if (!string.IsNullOrEmpty(macroPageUrl) && Uri.TryCreate(macroPageUrl, UriKind.RelativeOrAbsolute, out macroPageUrl))
											{
												macroRecording.MacroPageUrl = macroPageUrl;
											}
											macroRecording.Name = invalidCharsFreeName;
											if (string.IsNullOrEmpty(macroRecording.TimeCreated))
											{
												macroRecording.TimeCreated = DateTime.Now.ToString("yyyyMMddTHHmmss", CultureInfo.InvariantCulture);
											}
											bool flag = false;
											this.ParentWindow.MacroRecorderWindow.mRenamingMacrosList.Clear();
											this.ParentWindow.MacroRecorderWindow.mImportMultiMacroAsUnified = new bool?(true);
											num = this.ParentWindow.MacroRecorderWindow.ImportMacroRecordings(new List<MacroRecording>
											{
												macroRecording
											}, ref flag);
											if (flag)
											{
												num = 3;
											}
										}
										catch (Exception ex2)
										{
											Logger.Error("Failed to import macro recording.");
											Logger.Error(ex2.ToString());
											num = 2;
										}
										if (num == 0)
										{
											foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
											{
												if (keyValuePair.Value.MacroRecorderWindow != null)
												{
													keyValuePair.Value.MacroRecorderWindow.mScriptsStackPanel.Children.Clear();
													keyValuePair.Value.MacroRecorderWindow.Init();
												}
											}
										}
										this.ParentWindow.mCommonHandler.ShowMacroRecorderWindow();
										this.ParentWindow.MacroRecorderWindow.ValidateReturnCode(num);
									}
									catch (Exception ex3)
									{
										Logger.Error("Failed to deserialize downloaded macro.");
										Logger.Error(ex3.ToString());
									}
								}), new object[0]);
								try
								{
									File.Delete(filePath);
								}
								catch
								{
								}
							}
						}
					})
					{
						IsBackground = true
					}.Start();
				}
			}
			catch (Exception arg)
			{
				Logger.Error(string.Format("Invalid data in DowloadMacro api : {0}", arg));
			}
		}

		// Token: 0x06000DB1 RID: 3505 RVA: 0x0005AD9C File Offset: 0x00058F9C
		internal static List<string> GetMacroList()
		{
			List<string> list = new List<string>();
			try
			{
				MacroGraph.ReCreateMacroGraphInstance();
				foreach (BiDirectionalVertex<MacroRecording> biDirectionalVertex in MacroGraph.Instance.Vertices)
				{
					MacroRecording macroRecording = (MacroRecording)biDirectionalVertex;
					if (!string.IsNullOrEmpty(macroRecording.Name) && string.IsNullOrEmpty(macroRecording.MacroId))
					{
						list.Add(macroRecording.Name);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Debug("Failed to get macro list. Ex : " + ex.ToString());
			}
			return list;
		}

		// Token: 0x06000DB2 RID: 3506 RVA: 0x0005AE44 File Offset: 0x00059044
		internal static string GetBase64MacroData(string macroName)
		{
			string result = string.Empty;
			try
			{
				JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
				string path = Path.Combine(RegistryStrings.MacroRecordingsFolderPath, macroName.ToLower(CultureInfo.InvariantCulture).Trim()) + ".json";
				MacroRecording macroRecording = (from MacroRecording macro in MacroGraph.Instance.Vertices
				where string.Equals(macroName, macro.Name, StringComparison.InvariantCultureIgnoreCase)
				select macro).FirstOrDefault<MacroRecording>();
				if (macroRecording.RecordingType == RecordingTypes.SingleRecording)
				{
					Logger.Info("Uploading single recording macro");
					result = Convert.ToBase64String(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(macroRecording, serializerSettings)));
				}
				else
				{
					List<string> list = new List<string>();
					foreach (BiDirectionalVertex<MacroRecording> biDirectionalVertex in MacroGraph.Instance.GetAllChilds(macroRecording))
					{
						MacroRecording macroRecording2 = (MacroRecording)biDirectionalVertex;
						list.Add(File.ReadAllText(Path.Combine(RegistryStrings.MacroRecordingsFolderPath, macroRecording2.Name.ToLower(CultureInfo.InvariantCulture).Trim() + ".json")));
					}
					MacroRecording macroRecording3 = JsonConvert.DeserializeObject<MacroRecording>(File.ReadAllText(path), serializerSettings);
					macroRecording3.SourceRecordings = list;
					result = Convert.ToBase64String(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(macroRecording3, serializerSettings)));
					Logger.Info("Uploading merged macro");
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Coulnd't upload macro recording {0}, Ex: {1}", new object[]
				{
					macroName,
					ex
				});
			}
			return result;
		}

		// Token: 0x06000DB3 RID: 3507 RVA: 0x0000A34B File Offset: 0x0000854B
		private static void LaunchAllInstancesAndArrange()
		{
			ThreadPool.QueueUserWorkItem(delegate(object job)
			{
				RegistryManager.ClearRegistryMangerInstance();
				foreach (string text in RegistryManager.Instance.VmList)
				{
					if (!BlueStacksUIUtils.DictWindows.ContainsKey(text))
					{
						BlueStacksUIUtils.RunInstance(text, false);
						int num = RegistryManager.Instance.BatchInstanceStartInterval;
						if (num <= 0)
						{
							num = 2;
						}
						Thread.Sleep(num * 1000);
					}
				}
			});
		}

		// Token: 0x04000938 RID: 2360
		private MainWindow ParentWindow;

		// Token: 0x04000939 RID: 2361
		private int mCurrentVolumeLevel = 33;

		// Token: 0x0400093A RID: 2362
		internal static object mLaunchPlaySyncObj = new object();

		// Token: 0x0400093B RID: 2363
		internal static string sLoggedInImageName = "loggedin";

		// Token: 0x0400093C RID: 2364
		internal static string sPremiumUserImageName = "premiumuser";

		// Token: 0x0400093D RID: 2365
		internal static string sUserAccountPackageName = "com.uncube.account";

		// Token: 0x0400093E RID: 2366
		internal static string sUserAccountActivityName = "com.bluestacks.account.activities.AccountActivity_";

		// Token: 0x0400093F RID: 2367
		internal static string sAndroidSettingsPackageName = "com.android.settings";

		// Token: 0x04000940 RID: 2368
		internal static string sAndroidAccountSettingsActivityName = "com.android.settings.BstAccountsSettings";

		// Token: 0x04000941 RID: 2369
		internal static bool sStopStatSendingThread = false;

		// Token: 0x04000942 RID: 2370
		internal System.Timers.Timer sBootCheckTimer = new System.Timers.Timer(360000.0);

		// Token: 0x04000943 RID: 2371
		internal static List<string> lstCreatingWindows = new List<string>();

		// Token: 0x04000944 RID: 2372
		internal static Dictionary<string, MainWindow> DictWindows = new Dictionary<string, MainWindow>();

		// Token: 0x04000945 RID: 2373
		internal static bool sIsSynchronizationActive = false;

		// Token: 0x04000946 RID: 2374
		internal static List<string> sSelectedInstancesForSync = new List<string>();

		// Token: 0x04000947 RID: 2375
		public static MainWindow LastActivatedWindow;

		// Token: 0x04000948 RID: 2376
		public static MainWindow ActivatedWindow;

		// Token: 0x04000949 RID: 2377
		public static Dictionary<string, List<EventHandler>> BootEventsForMIManager = new Dictionary<string, List<EventHandler>>();

		// Token: 0x0400094A RID: 2378
		public static List<string> sSyncInvolvedInstances = new List<string>();

		// Token: 0x0400094B RID: 2379
		private static bool? isOglSupported = null;

		// Token: 0x0400094C RID: 2380
		private bool disposedValue;
	}
}
