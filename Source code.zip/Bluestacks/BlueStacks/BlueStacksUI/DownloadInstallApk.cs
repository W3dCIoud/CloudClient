﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001DD RID: 477
	internal class DownloadInstallApk
	{
		// Token: 0x060011D2 RID: 4562 RVA: 0x0000C9EE File Offset: 0x0000ABEE
		public DownloadInstallApk(MainWindow mainWindow)
		{
			this.ParentWindow = mainWindow;
		}

		// Token: 0x060011D3 RID: 4563 RVA: 0x0000C9FD File Offset: 0x0000ABFD
		public static SerialWorkQueue SerialWorkQueueInstaller(string vmName)
		{
			if (!DownloadInstallApk.mSerialQueue.ContainsKey(vmName))
			{
				DownloadInstallApk.mSerialQueue[vmName] = new SerialWorkQueue();
			}
			return DownloadInstallApk.mSerialQueue[vmName];
		}

		// Token: 0x060011D4 RID: 4564 RVA: 0x0006DBD0 File Offset: 0x0006BDD0
		internal void DownloadAndInstallAppFromJson(string campaignJson)
		{
			try
			{
				JObject resJson = JObject.Parse(campaignJson);
				string iconUrl = "";
				string appName = "";
				string apkUrl = "";
				string package = "";
				resJson.AssignIfContains("app_icon_url", delegate(string x)
				{
					iconUrl = x.Trim();
				});
				resJson.AssignIfContains("app_name", delegate(string x)
				{
					appName = x.Trim();
				});
				resJson.AssignIfContains("app_url", delegate(string x)
				{
					apkUrl = x.Trim();
				});
				resJson.AssignIfContains("app_pkg", delegate(string x)
				{
					package = x.Trim();
				});
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					if (string.IsNullOrEmpty(apkUrl))
					{
						this.ParentWindow.mWelcomeTab.mFrontendPopupControl.Init(package, appName, PlayStoreAction.OpenApp, false);
						return;
					}
					this.DownloadAndInstallApp(iconUrl, appName, apkUrl, package, true, true, "");
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Info("Error in Fle. Json string : " + campaignJson + "Error: " + ex.ToString());
			}
		}

		// Token: 0x060011D5 RID: 4565 RVA: 0x0006DCD0 File Offset: 0x0006BED0
		internal void DownloadAndInstallApp(string iconUrl, string appName, string apkUrl, string packageName, bool isLaunchAfterInstall, bool isDeleteApk, string timestamp = "")
		{
			if (this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon(packageName) == null || this.ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon(packageName).IsAppSuggestionActive)
			{
				if (!string.IsNullOrEmpty(apkUrl))
				{
					this.DownloadApk(iconUrl, appName, apkUrl, packageName, isLaunchAfterInstall, isDeleteApk, timestamp);
				}
				return;
			}
			if (!this.ParentWindow.mAppHandler.IsAppInstalled(packageName))
			{
				this.ParentWindow.mTopBar.mAppTabButtons.GoToTab("Home", true, false);
				return;
			}
			if (string.IsNullOrEmpty(timestamp))
			{
				this.ParentWindow.mAppHandler.SendRunAppRequestAsync(packageName, "", false);
				return;
			}
			bool flag = true;
			DateTime t = DateTime.Parse(timestamp, CultureInfo.InvariantCulture);
			DateTime t2 = DateTime.MaxValue;
			if (this.ParentWindow.mAppHandler.CdnAppdict.ContainsKey(packageName))
			{
				t2 = this.ParentWindow.mAppHandler.CdnAppdict[packageName];
				if (t <= t2)
				{
					flag = false;
				}
			}
			if (flag)
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_INSTALL_UPDATE", "");
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_APP_UPGRADE", "");
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_UPGRADE_TEXT", delegate(object sender1, EventArgs e1)
				{
					this.DownloadApk(iconUrl, appName, apkUrl, packageName, isLaunchAfterInstall, isDeleteApk, timestamp);
				}, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, "STRING_CONTINUE_ANYWAY", delegate(object sender1, EventArgs e1)
				{
					this.ParentWindow.mAppHandler.SendRunAppRequestAsync(packageName, "", false);
				}, null, false, null);
				customMessageWindow.Owner = this.ParentWindow;
				customMessageWindow.ShowDialog();
				return;
			}
			this.ParentWindow.mAppHandler.SendRunAppRequestAsync(packageName, "", false);
		}

		// Token: 0x060011D6 RID: 4566 RVA: 0x0006DEFC File Offset: 0x0006C0FC
		internal void DownloadApk(string iconUrl, string appName, string apkUrl, string packageName, bool isLaunchAfterInstall, bool isDeleteApk, string timestamp)
		{
			Utils.TinyDownloader(iconUrl, packageName + ".png", "", false);
			this.ParentWindow.mWelcomeTab.mHomeApp.AddAppIcon(packageName, appName, apkUrl, this);
			this.DownloadApk(apkUrl, packageName, isLaunchAfterInstall, isDeleteApk, timestamp);
		}

		// Token: 0x060011D7 RID: 4567 RVA: 0x0000CA27 File Offset: 0x0000AC27
		internal static string DownloadIcon(string packageName)
		{
			return Utils.DownloadIcon(packageName, "", false);
		}

		// Token: 0x060011D8 RID: 4568 RVA: 0x0006DF4C File Offset: 0x0006C14C
		public void DownloadApk(string apkUrl, string packageName, bool isLaunchAfterInstall, bool isDeleteApk, string timestamp = "")
		{
			string apkUrl2 = apkUrl;
			if (apkUrl == null)
			{
				return;
			}
			if (DownloadInstallApk.IsContainsGoogleAdId(apkUrl2))
			{
				apkUrl = this.AddGoogleAdidWithApk(apkUrl2);
			}
			apkUrl = BlueStacksUIUtils.GetFinalRedirectedUrl(apkUrl);
			if (apkUrl == null)
			{
				return;
			}
			string input = packageName + ".apk";
			string text = Path.Combine(RegistryStrings.DataDir, "DownloadedApk");
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
			string path = Regex.Replace(input, "[\\x22\\\\\\/:*?|<>]", " ");
			string apkFilePath = Path.Combine(text, path);
			Logger.Info("Downloading Apk file to: " + apkFilePath);
			this.ParentWindow.mWelcomeTab.mHomeApp.DownloadStarted(packageName);
			ClientStats.SendClientStatsAsync("download", "unknown", "app_install", packageName, "", "");
			this.mDownloadThread = new Thread(delegate()
			{
				this.mIsDownloading = true;
				this.mDownloader = new LegacyDownloader(3, apkUrl, apkFilePath);
				this.mDownloader.Download(delegate(int percent)
				{
					this.ParentWindow.mWelcomeTab.mHomeApp.UpdateAppDownloadProgress(packageName, percent);
				}, delegate(string filePath)
				{
					ClientStats.SendClientStatsAsync("download", "success", "app_install", packageName, "", "");
					this.mIsDownloading = false;
					this.ParentWindow.mWelcomeTab.mHomeApp.DownloadCompleted(packageName, filePath);
					this.InstallApk(packageName, filePath, isLaunchAfterInstall, isDeleteApk, timestamp);
					DownloadInstallApk.sDownloadedApkList.Add(packageName);
				}, delegate(Exception ex)
				{
					ClientStats.SendClientStatsAsync("download", "fail", "app_install", packageName, "", "");
					this.ParentWindow.mWelcomeTab.mHomeApp.DownloadFailed(packageName);
					Logger.Error("Failed to download file: {0}. err: {1}", new object[]
					{
						apkFilePath,
						ex.Message
					});
				}, null, null, null);
			})
			{
				IsBackground = true
			};
			this.mDownloadThread.Start();
		}

		// Token: 0x060011D9 RID: 4569 RVA: 0x0006E094 File Offset: 0x0006C294
		private string AddGoogleAdidWithApk(string apkUrl)
		{
			Logger.Info("In AddGoogleAdidWithApk");
			string newValue = "google_aid=00000000-0000-0000-0000-000000000000";
			string result;
			try
			{
				JObject jobject = JObject.Parse(HTTPUtils.SendRequestToGuest("getGoogleAdID", null, this.ParentWindow.mVmName, 0, null, false, 1, 0));
				if (jobject["result"].ToString() == "ok")
				{
					string text = jobject["googleadid"].ToString();
					string newValue2 = string.Format(CultureInfo.InvariantCulture, "google_aid={0}", new object[]
					{
						text
					});
					result = apkUrl.Replace("google_aid={google_aid}", newValue2);
				}
				else
				{
					result = apkUrl.Replace("google_aid={google_aid}", newValue);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in adding google adId" + ex.ToString());
				result = apkUrl.Replace("google_aid={google_aid}", newValue);
			}
			return result;
		}

		// Token: 0x060011DA RID: 4570 RVA: 0x0000CA35 File Offset: 0x0000AC35
		private static bool IsContainsGoogleAdId(string apkUrl)
		{
			return apkUrl.ToLower(CultureInfo.InvariantCulture).Contains("google_aid={google_aid}");
		}

		// Token: 0x060011DB RID: 4571 RVA: 0x0006E174 File Offset: 0x0006C374
		internal void AbortApkDownload(string packageName)
		{
			ClientStats.SendClientStatsAsync("download", "cancel", "app_install", packageName, "", "");
			if (this.mDownloader != null)
			{
				this.mDownloader.AbortDownload();
			}
			if (this.mDownloadThread != null)
			{
				this.mDownloadThread.Abort();
			}
		}

		// Token: 0x060011DC RID: 4572 RVA: 0x0006E1C8 File Offset: 0x0006C3C8
		internal void ChooseAndInstallApk()
		{
			using (OpenFileDialog openFileDialog = new OpenFileDialog
			{
				Filter = "Android Files (*.apk, *.xapk)|*.apk; *.xapk",
				Multiselect = true,
				RestoreDirectory = true
			})
			{
				if (openFileDialog.ShowDialog() == DialogResult.OK)
				{
					foreach (string text in openFileDialog.FileNames)
					{
						Logger.Info("File Selected : " + text);
						this.InstallApk(text, true);
					}
				}
			}
		}

		// Token: 0x060011DD RID: 4573 RVA: 0x0006E24C File Offset: 0x0006C44C
		internal void InstallApk(string apkPath, bool addToChooseApkList = false)
		{
			Logger.Info("Console: Installing apk: {0}", new object[]
			{
				apkPath
			});
			string package = string.Empty;
			string appName = string.Empty;
			if (string.Equals(Path.GetExtension(apkPath), ".xapk", StringComparison.InvariantCultureIgnoreCase))
			{
				JToken jtoken = Utils.ExtractInfoFromXapk(apkPath);
				if (jtoken != null)
				{
					package = jtoken.GetValue("package_name");
					appName = jtoken.GetValue("name");
					Logger.Debug("Package name from manifest.json.." + package);
				}
			}
			else
			{
				AppInfoExtractor apkInfo = AppInfoExtractor.GetApkInfo(apkPath);
				package = apkInfo.PackageName;
				appName = apkInfo.AppName;
			}
			if (addToChooseApkList)
			{
				DownloadInstallApk.sApkInstalledFromChooser.Add(package);
			}
			if (!string.IsNullOrEmpty(package))
			{
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					this.ParentWindow.mWelcomeTab.mHomeApp.AddAppIcon(package, appName, string.Empty, this);
				}), new object[0]);
			}
			this.InstallApk(package, apkPath, false, false, "");
		}

		// Token: 0x060011DE RID: 4574 RVA: 0x0006E35C File Offset: 0x0006C55C
		internal void InstallApk(string packageName, string apkPath, bool isLaunchAfterInstall, bool isDeleteApk, string timestamp = "")
		{
			this.ParentWindow.mWelcomeTab.mHomeApp.ApkInstallStart(packageName, apkPath);
			DownloadInstallApk.SerialWorkQueueInstaller(this.ParentWindow.mVmName).Enqueue(delegate
			{
				Logger.Info("Installing apk: {0}", new object[]
				{
					apkPath
				});
				int num = BluestacksProcessHelper.RunApkInstaller(apkPath, true, this.ParentWindow.mVmName);
				Logger.Info("Apk installer exit code: {0}", new object[]
				{
					num
				});
				if (num == 0)
				{
					if (DownloadInstallApk.sDownloadedApkList.Contains(packageName))
					{
						ClientStats.SendClientStatsAsync("install_from_download", "success", "app_install", packageName, "", "");
						DownloadInstallApk.sDownloadedApkList.Remove(packageName);
						this.UpdateCdnAppEntry(true, packageName, timestamp);
					}
					else if (DownloadInstallApk.sApkInstalledFromChooser.Contains(packageName))
					{
						ClientStats.SendClientStatsAsync("install", "success", "app_install", packageName, "", "");
						DownloadInstallApk.sApkInstalledFromChooser.Remove(packageName);
					}
					this.ParentWindow.mWelcomeTab.mHomeApp.ApkInstallCompleted(packageName);
					if (isLaunchAfterInstall)
					{
						this.ParentWindow.Utils.RunAppOrCreateTabButton(packageName);
					}
					Logger.Info("Installation successful.");
					if (isDeleteApk)
					{
						File.Delete(apkPath);
					}
					Logger.Info("Install Completed : " + packageName);
					return;
				}
				if (DownloadInstallApk.sDownloadedApkList.Contains(packageName))
				{
					ClientStats.SendClientStatsAsync("install_from_download", "fail", "app_install", packageName, num.ToString(CultureInfo.InvariantCulture), "");
					DownloadInstallApk.sDownloadedApkList.Remove(packageName);
				}
				else if (DownloadInstallApk.sApkInstalledFromChooser.Contains(packageName))
				{
					ClientStats.SendClientStatsAsync("install", "fail", "app_install", packageName, num.ToString(CultureInfo.InvariantCulture), "");
					DownloadInstallApk.sApkInstalledFromChooser.Remove(packageName);
				}
				ClientStats.SendGeneralStats("apk_inst_error", new Dictionary<string, string>
				{
					{
						"errcode",
						Convert.ToString(num, CultureInfo.InvariantCulture)
					},
					{
						"precode",
						"0"
					},
					{
						"app_pkg",
						packageName
					}
				});
				this.ParentWindow.mWelcomeTab.mHomeApp.ApkInstallFailed(packageName);
			});
		}

		// Token: 0x060011DF RID: 4575 RVA: 0x0006E3E0 File Offset: 0x0006C5E0
		internal int InstallFLEApk(string packageName, string apkPath)
		{
			Logger.Info("Installing apk: {0}", new object[]
			{
				apkPath
			});
			int num = BluestacksProcessHelper.RunApkInstaller(apkPath, true, this.ParentWindow.mVmName);
			Logger.Info("Apk installer exit code: {0}", new object[]
			{
				num
			});
			if (num == 0)
			{
				if (DownloadInstallApk.sDownloadedApkList.Contains(packageName))
				{
					ClientStats.SendClientStatsAsync("install_from_download", "success", "app_install", packageName, "", "");
					DownloadInstallApk.sDownloadedApkList.Remove(packageName);
					this.UpdateCdnAppEntry(true, packageName, "");
				}
				else if (DownloadInstallApk.sApkInstalledFromChooser.Contains(packageName))
				{
					ClientStats.SendClientStatsAsync("install", "success", "app_install", packageName, "", "");
					DownloadInstallApk.sApkInstalledFromChooser.Remove(packageName);
				}
				this.ParentWindow.Utils.RunAppOrCreateTabButton(packageName);
				Logger.Info("Installation successful.");
				File.Delete(apkPath);
			}
			else
			{
				if (DownloadInstallApk.sDownloadedApkList.Contains(packageName))
				{
					ClientStats.SendClientStatsAsync("install_from_download", "fail", "app_install", packageName, num.ToString(CultureInfo.InvariantCulture), "");
					DownloadInstallApk.sDownloadedApkList.Remove(packageName);
				}
				else if (DownloadInstallApk.sApkInstalledFromChooser.Contains(packageName))
				{
					ClientStats.SendClientStatsAsync("install", "fail", "app_install", packageName, num.ToString(CultureInfo.InvariantCulture), "");
					DownloadInstallApk.sApkInstalledFromChooser.Remove(packageName);
				}
				ClientStats.SendGeneralStats("apk_inst_error", new Dictionary<string, string>
				{
					{
						"errcode",
						Convert.ToString(num, CultureInfo.InvariantCulture)
					},
					{
						"precode",
						"0"
					},
					{
						"app_pkg",
						packageName
					}
				});
			}
			Logger.Info("Install Completed : " + packageName);
			return num;
		}

		// Token: 0x060011E0 RID: 4576 RVA: 0x0006E5AC File Offset: 0x0006C7AC
		internal void UninstallApp(string packageName)
		{
			DownloadInstallApk.SerialWorkQueueInstaller(this.ParentWindow.mVmName).Enqueue(delegate
			{
				Logger.Info("Uninstall started : " + packageName);
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary["package"] = packageName;
				Dictionary<string, string> data = dictionary;
				try
				{
					JArray jarray = JArray.Parse(HTTPUtils.SendRequestToAgent("uninstall", data, this.ParentWindow.mVmName, 0, null, false, 1, 0));
					try
					{
						if (!JObject.Parse(jarray[0].ToString())["success"].ToObject<bool>())
						{
							ClientStats.SendClientStatsAsync("uninstall", "fail", "app_install", packageName, "", "");
						}
						else
						{
							this.UpdateCdnAppEntry(false, packageName, "");
						}
					}
					catch
					{
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to uninstall app. Err: " + ex.Message);
				}
				Logger.Info("Uninstall completed for " + packageName);
			});
		}

		// Token: 0x060011E1 RID: 4577 RVA: 0x0006E5F0 File Offset: 0x0006C7F0
		internal void UpdateCdnAppEntry(bool isAdd, string packageName, string timestamp)
		{
			DateTime timestamp2 = DateTime.MinValue;
			if (!string.IsNullOrEmpty(timestamp))
			{
				timestamp2 = DateTime.Parse(timestamp, CultureInfo.InvariantCulture);
			}
			this.ParentWindow.mAppHandler.WriteXMl(isAdd, packageName, timestamp2);
		}

		// Token: 0x04000B8C RID: 2956
		internal const string mIconUrl = "https://cloud.bluestacks.com/app/icon?pkg={0}&fallback=false";

		// Token: 0x04000B8D RID: 2957
		private Thread mDownloadThread;

		// Token: 0x04000B8E RID: 2958
		public bool mIsDownloading;

		// Token: 0x04000B8F RID: 2959
		private LegacyDownloader mDownloader;

		// Token: 0x04000B90 RID: 2960
		private static Dictionary<string, SerialWorkQueue> mSerialQueue = new Dictionary<string, SerialWorkQueue>();

		// Token: 0x04000B91 RID: 2961
		internal static List<string> sDownloadedApkList = new List<string>();

		// Token: 0x04000B92 RID: 2962
		internal static List<string> sApkInstalledFromChooser = new List<string>();

		// Token: 0x04000B93 RID: 2963
		private MainWindow ParentWindow;
	}
}
