﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200017C RID: 380
	public class QuestRuleState
	{
		// Token: 0x17000267 RID: 615
		// (get) Token: 0x06000EE7 RID: 3815 RVA: 0x0000ADC2 File Offset: 0x00008FC2
		// (set) Token: 0x06000EE8 RID: 3816 RVA: 0x0000ADCA File Offset: 0x00008FCA
		public long Interaction { get; set; }

		// Token: 0x17000268 RID: 616
		// (get) Token: 0x06000EE9 RID: 3817 RVA: 0x0000ADD3 File Offset: 0x00008FD3
		// (set) Token: 0x06000EEA RID: 3818 RVA: 0x0000ADDB File Offset: 0x00008FDB
		public long TotalTime { get; set; }

		// Token: 0x17000269 RID: 617
		// (get) Token: 0x06000EEB RID: 3819 RVA: 0x0000ADE4 File Offset: 0x00008FE4
		// (set) Token: 0x06000EEC RID: 3820 RVA: 0x0000ADEC File Offset: 0x00008FEC
		public QuestRule QuestRules { get; set; }
	}
}
