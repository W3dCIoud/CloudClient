﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000E6 RID: 230
	public class QuitActionElement : UserControl, IComponentConnector
	{
		// Token: 0x06000947 RID: 2375 RVA: 0x00007E62 File Offset: 0x00006062
		public QuitActionElement(MainWindow window, QuitPopupControl qpc)
		{
			this.ParentWindow = window;
			this.ParentQuitPopup = qpc;
			this.InitializeComponent();
		}

		// Token: 0x170001D2 RID: 466
		// (get) Token: 0x06000948 RID: 2376 RVA: 0x00007E9F File Offset: 0x0000609F
		// (set) Token: 0x06000949 RID: 2377 RVA: 0x00007EA7 File Offset: 0x000060A7
		public string ParentPopupTag { get; set; } = string.Empty;

		// Token: 0x0600094A RID: 2378 RVA: 0x00036A38 File Offset: 0x00034C38
		private void SetProperties(QuitActionItem item)
		{
			string value = QuitActionCollection.Actions[item][QuitActionItemProperty.CallToAction];
			this.mBodyTextBlock.Text = QuitActionCollection.Actions[item][QuitActionItemProperty.BodyText];
			this.mMainImage.ImageName = QuitActionCollection.Actions[item][QuitActionItemProperty.ImageName];
			this.mHyperlinkTextBlock.Text = QuitActionCollection.Actions[item][QuitActionItemProperty.ActionText];
			this.mQuitActionValue = QuitActionCollection.Actions[item][QuitActionItemProperty.ActionValue];
			this.mCTAEventName = QuitActionCollection.Actions[item][QuitActionItemProperty.StatEventName];
			this.mCallToAction = (QuitActionItemCTA)Enum.Parse(typeof(QuitActionItemCTA), value, true);
		}

		// Token: 0x170001D3 RID: 467
		// (get) Token: 0x0600094B RID: 2379 RVA: 0x00007EB0 File Offset: 0x000060B0
		// (set) Token: 0x0600094C RID: 2380 RVA: 0x00007EC2 File Offset: 0x000060C2
		public QuitActionItem ActionElement
		{
			get
			{
				return (QuitActionItem)base.GetValue(QuitActionElement.ActionElementProperty);
			}
			set
			{
				base.SetValue(QuitActionElement.ActionElementProperty, value);
			}
		}

		// Token: 0x0600094D RID: 2381 RVA: 0x00036AF8 File Offset: 0x00034CF8
		private static void ActionElementPropertyChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			QuitActionElement quitActionElement = d as QuitActionElement;
			if (!DesignerProperties.GetIsInDesignMode(quitActionElement))
			{
				quitActionElement.SetProperties((QuitActionItem)e.NewValue);
			}
		}

		// Token: 0x0600094E RID: 2382 RVA: 0x00036B28 File Offset: 0x00034D28
		private void QAE_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			try
			{
				switch (this.mCallToAction)
				{
				case QuitActionItemCTA.OpenLinkInBrowser:
					if (!string.IsNullOrEmpty(this.mQuitActionValue))
					{
						BlueStacksUIUtils.OpenUrl(this.mQuitActionValue);
					}
					this.SendCTAStat();
					break;
				case QuitActionItemCTA.OpenAppCenter:
					this.OpenAppCenter();
					this.ParentQuitPopup.Close();
					this.SendCTAStat();
					break;
				case QuitActionItemCTA.OpenApplication:
					if (!string.IsNullOrEmpty(this.mQuitActionValue))
					{
						Process.Start(this.mQuitActionValue);
					}
					this.SendCTAStat();
					break;
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Some error while CallToAction of QuitPopup. Ex: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x0600094F RID: 2383 RVA: 0x00036BD4 File Offset: 0x00034DD4
		private void OpenAppCenter()
		{
			try
			{
				MainWindow parentWindow = this.ParentWindow;
				if (parentWindow != null)
				{
					parentWindow.Utils.HandleApplicationBrowserClick(BlueStacksUIUtils.GetAppCenterUrl(null), LocaleStrings.GetLocalizedString("STRING_APP_CENTER"), "appcenter", false, "");
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't open app center. Ex: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x06000950 RID: 2384 RVA: 0x00007ED5 File Offset: 0x000060D5
		private void SendCTAStat()
		{
			ClientStats.SendLocalQuitPopupStatsAsync(this.ParentPopupTag, this.mCTAEventName);
		}

		// Token: 0x06000951 RID: 2385 RVA: 0x00007EE8 File Offset: 0x000060E8
		private void QAE_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mExternalLinkImage.Visibility = Visibility.Hidden;
			BlueStacksUIBinding.BindColor(this.maskBorder, Border.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
			base.Cursor = Cursors.Hand;
		}

		// Token: 0x06000952 RID: 2386 RVA: 0x00007F16 File Offset: 0x00006116
		private void QAE_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mExternalLinkImage.Visibility = Visibility.Hidden;
			BlueStacksUIBinding.BindColor(this.maskBorder, Border.BackgroundProperty, "LightBandingColor");
			base.Cursor = Cursors.Arrow;
		}

		// Token: 0x06000953 RID: 2387 RVA: 0x00036C3C File Offset: 0x00034E3C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/quitactionelement.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000954 RID: 2388 RVA: 0x00036C6C File Offset: 0x00034E6C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((QuitActionElement)target).MouseEnter += this.QAE_MouseEnter;
				((QuitActionElement)target).MouseLeave += this.QAE_MouseLeave;
				((QuitActionElement)target).PreviewMouseUp += this.QAE_PreviewMouseUp;
				return;
			case 2:
				this.maskBorder = (Border)target;
				return;
			case 3:
				this.mParentGrid = (Grid)target;
				return;
			case 4:
				this.mExternalLinkImage = (CustomPictureBox)target;
				return;
			case 5:
				this.mMainImage = (CustomPictureBox)target;
				return;
			case 6:
				this.mBodyTextBlock = (TextBlock)target;
				return;
			case 7:
				this.mHyperlinkTextBlock = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040005C8 RID: 1480
		private MainWindow ParentWindow;

		// Token: 0x040005C9 RID: 1481
		private QuitPopupControl ParentQuitPopup;

		// Token: 0x040005CA RID: 1482
		private string mQuitActionValue = string.Empty;

		// Token: 0x040005CB RID: 1483
		private string mCTAEventName = string.Empty;

		// Token: 0x040005CC RID: 1484
		private QuitActionItemCTA mCallToAction;

		// Token: 0x040005CE RID: 1486
		public static readonly DependencyProperty ActionElementProperty = DependencyProperty.Register("ActionElement", typeof(QuitActionItem), typeof(QuitActionElement), new PropertyMetadata(QuitActionItem.None, new PropertyChangedCallback(QuitActionElement.ActionElementPropertyChangedCallback)));

		// Token: 0x040005CF RID: 1487
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border maskBorder;

		// Token: 0x040005D0 RID: 1488
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mParentGrid;

		// Token: 0x040005D1 RID: 1489
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mExternalLinkImage;

		// Token: 0x040005D2 RID: 1490
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mMainImage;

		// Token: 0x040005D3 RID: 1491
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mBodyTextBlock;

		// Token: 0x040005D4 RID: 1492
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mHyperlinkTextBlock;

		// Token: 0x040005D5 RID: 1493
		private bool _contentLoaded;
	}
}
