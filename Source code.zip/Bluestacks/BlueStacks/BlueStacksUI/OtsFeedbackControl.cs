﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000DD RID: 221
	public class OtsFeedbackControl : UserControl, IComponentConnector
	{
		// Token: 0x170001D1 RID: 465
		// (get) Token: 0x060008F9 RID: 2297 RVA: 0x00007B39 File Offset: 0x00005D39
		// (set) Token: 0x060008FA RID: 2298 RVA: 0x00007B41 File Offset: 0x00005D41
		public MainWindow ParentWindow { get; set; }

		// Token: 0x060008FB RID: 2299 RVA: 0x00007B4A File Offset: 0x00005D4A
		public OtsFeedbackControl(MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
		}

		// Token: 0x060008FC RID: 2300 RVA: 0x00007B5F File Offset: 0x00005D5F
		private void CloseBtn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			BlueStacksUIUtils.CloseContainerWindow(this);
		}

		// Token: 0x060008FD RID: 2301 RVA: 0x00034F00 File Offset: 0x00033100
		private void SubmitButton_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				if (this.TestEmail(this.txtEmail.Text) && this.TestPhone(this.txtPhone.Text))
				{
					ClientStats.SendMiscellaneousStatsAsync("OTSFeedback", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, this.txtDescIssue.Text, this.txtEmail.Text, this.txtPhone.Text, null, null, null);
					new Thread(delegate()
					{
						try
						{
							new Process
							{
								StartInfo = 
								{
									Arguments = "-silent",
									FileName = Path.Combine(RegistryStrings.InstallDir, "HD-LogCollector.exe")
								}
							}.Start();
						}
						catch (Exception ex2)
						{
							Logger.Error("Exception in starting HD-logCollector.exe: " + ex2.ToString());
						}
					})
					{
						IsBackground = true
					}.Start();
					BlueStacksUIUtils.CloseContainerWindow(this);
					CustomMessageWindow customMessageWindow = new CustomMessageWindow();
					customMessageWindow.ImageName = "help";
					customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_THANK_YOU");
					customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_APPRECIATE_FEEDBACK");
					customMessageWindow.AddButton(ButtonColors.Blue, LocaleStrings.GetLocalizedString("STRING_CLOSE"), null, null, false, null);
					customMessageWindow.Owner = this.ParentWindow;
					this.ParentWindow.ShowDimOverlay(null);
					customMessageWindow.ShowDialog();
					this.ParentWindow.HideDimOverlay();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Submitting ots feedback " + ex.ToString());
			}
		}

		// Token: 0x060008FE RID: 2302 RVA: 0x00007B67 File Offset: 0x00005D67
		private bool TestEmail(string text)
		{
			BlueStacksUIBinding.BindColor(this.txtEmailBorder, Border.BorderBrushProperty, "SettingsWindowTabMenuItemForeground");
			if (!Regex.IsMatch(text, "^(?(\")(\".+?(?<!\\\\)\"@)|(([0-9a-z]((\\.(?!\\.))|[-!#\\$%&'\\*\\+/=\\?\\^`\\{\\}\\|~\\w])*)(?<=[0-9a-z])@))(?(\\[)(\\[(\\d{1,3}\\.){3}\\d{1,3}\\])|(([0-9a-z][-0-9a-z]*[0-9a-z]*\\.)+[a-z0-9][\\-a-z0-9]{0,22}[a-z0-9]))$", RegexOptions.IgnoreCase))
			{
				this.txtEmailBorder.BorderBrush = Brushes.Red;
				return false;
			}
			return true;
		}

		// Token: 0x060008FF RID: 2303 RVA: 0x00007B9F File Offset: 0x00005D9F
		private bool TestPhone(string text)
		{
			BlueStacksUIBinding.BindColor(this.txtPhoneBorder, Border.BorderBrushProperty, "SettingsWindowTabMenuItemForeground");
			if (!Regex.IsMatch(text, OtsFeedbackControl.MakeCombinedPattern(OtsFeedbackControl.m_Phone_Patterns), RegexOptions.IgnoreCase))
			{
				this.txtPhoneBorder.BorderBrush = Brushes.Red;
				return false;
			}
			return true;
		}

		// Token: 0x06000900 RID: 2304 RVA: 0x00007BDC File Offset: 0x00005DDC
		private static string MakeCombinedPattern(IEnumerable<string> patterns)
		{
			return string.Join("|", (from item in patterns
			select "(" + item + ")").ToArray<string>());
		}

		// Token: 0x06000901 RID: 2305 RVA: 0x00007C12 File Offset: 0x00005E12
		private void txtEmail_TextChanged(object sender, TextChangedEventArgs e)
		{
			this.TestEmail(this.txtEmail.Text);
		}

		// Token: 0x06000902 RID: 2306 RVA: 0x00007C26 File Offset: 0x00005E26
		private void txtPhone_TextChanged(object sender, TextChangedEventArgs e)
		{
			this.TestPhone(this.txtPhone.Text);
		}

		// Token: 0x06000903 RID: 2307 RVA: 0x00035060 File Offset: 0x00033260
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/otsfeedbackcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000904 RID: 2308 RVA: 0x00035090 File Offset: 0x00033290
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mCloseBtn = (CustomPictureBox)target;
				this.mCloseBtn.MouseLeftButtonUp += this.CloseBtn_MouseLeftButtonUp;
				return;
			case 2:
				this.txtDescIssue = (TextBox)target;
				return;
			case 3:
				this.txtEmailBorder = (Border)target;
				return;
			case 4:
				this.txtEmail = (TextBox)target;
				this.txtEmail.TextChanged += this.txtEmail_TextChanged;
				return;
			case 5:
				this.txtPhoneBorder = (Border)target;
				return;
			case 6:
				this.txtPhone = (TextBox)target;
				this.txtPhone.TextChanged += this.txtPhone_TextChanged;
				return;
			case 7:
				((CustomButton)target).Click += this.SubmitButton_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000584 RID: 1412
		private static List<string> m_Phone_Patterns = new List<string>
		{
			"^[\\d\\s-\\+]{5,15}$"
		};

		// Token: 0x04000585 RID: 1413
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCloseBtn;

		// Token: 0x04000586 RID: 1414
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBox txtDescIssue;

		// Token: 0x04000587 RID: 1415
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border txtEmailBorder;

		// Token: 0x04000588 RID: 1416
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBox txtEmail;

		// Token: 0x04000589 RID: 1417
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border txtPhoneBorder;

		// Token: 0x0400058A RID: 1418
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBox txtPhone;

		// Token: 0x0400058B RID: 1419
		private bool _contentLoaded;
	}
}
