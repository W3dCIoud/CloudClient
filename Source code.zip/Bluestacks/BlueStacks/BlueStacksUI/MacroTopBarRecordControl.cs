﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000A3 RID: 163
	public class MacroTopBarRecordControl : UserControl, IComponentConnector
	{
		// Token: 0x06000645 RID: 1605 RVA: 0x00006059 File Offset: 0x00004259
		public MacroTopBarRecordControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000646 RID: 1606 RVA: 0x00025350 File Offset: 0x00023550
		internal void Init(MainWindow window)
		{
			this.ParentWindow = window;
			this.mTimer = new DispatcherTimer(new TimeSpan(0, 0, 0, 0, 50), DispatcherPriority.Render, new EventHandler(this.T_Tick), Dispatcher.CurrentDispatcher);
			this.mPlayMacroImg.Visibility = Visibility.Collapsed;
			this.mPauseMacroImg.Visibility = Visibility.Visible;
			this.mBlinkRecordingIconTimer = new DispatcherTimer(new TimeSpan(0, 0, 0, 0, 500), DispatcherPriority.Render, new EventHandler(this.BlinkRecordingIcon_Tick), Dispatcher.CurrentDispatcher);
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				BlueStacksUIBinding.Bind(this.ParentWindow.mNCTopBar.mMacroRecordingTooltip, "STRING_PAUSE_RECORDING_TOOLTIP", "");
				return;
			}
			BlueStacksUIBinding.Bind(this.ParentWindow.mTopBar.mMacroRecordingTooltip, "STRING_PAUSE_RECORDING_TOOLTIP", "");
		}

		// Token: 0x06000647 RID: 1607 RVA: 0x0000606E File Offset: 0x0000426E
		private void BlinkRecordingIcon_Tick(object sender, EventArgs e)
		{
			this.ToggleRecordingIcon();
		}

		// Token: 0x06000648 RID: 1608 RVA: 0x0002541C File Offset: 0x0002361C
		private void PauseMacroRecording_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("pauseRecordingCombo", null);
			this.PauseTimer();
			this.mPauseMacroImg.Visibility = Visibility.Collapsed;
			this.mPlayMacroImg.Visibility = Visibility.Visible;
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_record_pause", null, RecordingTypes.SingleRecording.ToString(), null, null, null);
		}

		// Token: 0x06000649 RID: 1609 RVA: 0x00006076 File Offset: 0x00004276
		private void ResumeMacroRecording_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("startRecordingCombo", null);
			this.ResumeTimer();
			this.mPlayMacroImg.Visibility = Visibility.Collapsed;
			this.mPauseMacroImg.Visibility = Visibility.Visible;
		}

		// Token: 0x0600064A RID: 1610 RVA: 0x00025494 File Offset: 0x00023694
		private void StopMacroRecording_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.StopMacroRecording();
			this.mBlinkRecordingIconTimer.Stop();
			this.mRecordingImage.ImageName = "recording_macro_title_bar";
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_record_stop", null, RecordingTypes.SingleRecording.ToString(), null, null, null);
		}

		// Token: 0x0600064B RID: 1611 RVA: 0x000060AC File Offset: 0x000042AC
		internal void StopTimer()
		{
			this.mTimer.Stop();
			this.mBlinkRecordingIconTimer.Stop();
		}

		// Token: 0x0600064C RID: 1612 RVA: 0x000060C4 File Offset: 0x000042C4
		internal void StartTimer()
		{
			this.mTimer.Start();
			this.mStartTime = DateTime.Now;
			this.mBlinkRecordingIconTimer.Start();
		}

		// Token: 0x0600064D RID: 1613 RVA: 0x00025504 File Offset: 0x00023704
		private void T_Tick(object sender, EventArgs e)
		{
			TimeSpan timeSpan = DateTime.Now - this.mStartTime;
			string text = string.Format(CultureInfo.InvariantCulture, "{0:00}:{1:00}:{2:00}", new object[]
			{
				timeSpan.Minutes,
				timeSpan.Seconds,
				timeSpan.Milliseconds / 10
			});
			this.TimerDisplay.Text = text;
		}

		// Token: 0x0600064E RID: 1614 RVA: 0x000060E7 File Offset: 0x000042E7
		private void ToggleRecordingIcon()
		{
			if (this.mShowRecordingIcon)
			{
				this.mRecordingImage.ImageName = "recording_macro_active";
				this.mShowRecordingIcon = false;
				return;
			}
			this.mRecordingImage.ImageName = "recording_macro";
			this.mShowRecordingIcon = true;
		}

		// Token: 0x0600064F RID: 1615 RVA: 0x00006120 File Offset: 0x00004320
		internal void PauseTimer()
		{
			this.mTimer.IsEnabled = false;
			this.mTimer.Stop();
			this.mPauseTime = DateTime.Now;
			this.mBlinkRecordingIconTimer.Stop();
			this.mShowRecordingIcon = true;
			this.ToggleRecordingIcon();
		}

		// Token: 0x06000650 RID: 1616 RVA: 0x00025574 File Offset: 0x00023774
		internal void ResumeTimer()
		{
			TimeSpan t = DateTime.Now - this.mPauseTime;
			this.mStartTime += t;
			this.mTimer.IsEnabled = true;
			this.mTimer.Start();
			this.mBlinkRecordingIconTimer.Start();
			this.mShowRecordingIcon = true;
			this.ToggleRecordingIcon();
		}

		// Token: 0x06000651 RID: 1617 RVA: 0x000255D4 File Offset: 0x000237D4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/macrotopbarrecordcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000652 RID: 1618 RVA: 0x00025604 File Offset: 0x00023804
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				this.mRecordingImage = (CustomPictureBox)target;
				return;
			case 3:
				this.TimerDisplay = (TextBlock)target;
				return;
			case 4:
				this.mPauseMacroImg = (CustomPictureBox)target;
				this.mPauseMacroImg.PreviewMouseLeftButtonUp += this.PauseMacroRecording_MouseLeftButtonUp;
				return;
			case 5:
				this.mPlayMacroImg = (CustomPictureBox)target;
				this.mPlayMacroImg.PreviewMouseLeftButtonUp += this.ResumeMacroRecording_MouseLeftButtonUp;
				return;
			case 6:
				this.mStopMacroImg = (CustomPictureBox)target;
				this.mStopMacroImg.PreviewMouseLeftButtonUp += this.StopMacroRecording_PreviewMouseLeftButtonUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000370 RID: 880
		private MainWindow ParentWindow;

		// Token: 0x04000371 RID: 881
		private DispatcherTimer mTimer;

		// Token: 0x04000372 RID: 882
		private DispatcherTimer mBlinkRecordingIconTimer;

		// Token: 0x04000373 RID: 883
		private DateTime mStartTime;

		// Token: 0x04000374 RID: 884
		private DateTime mPauseTime;

		// Token: 0x04000375 RID: 885
		private bool mShowRecordingIcon = true;

		// Token: 0x04000376 RID: 886
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder;

		// Token: 0x04000377 RID: 887
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mRecordingImage;

		// Token: 0x04000378 RID: 888
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock TimerDisplay;

		// Token: 0x04000379 RID: 889
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mPauseMacroImg;

		// Token: 0x0400037A RID: 890
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mPlayMacroImg;

		// Token: 0x0400037B RID: 891
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mStopMacroImg;

		// Token: 0x0400037C RID: 892
		private bool _contentLoaded;
	}
}
