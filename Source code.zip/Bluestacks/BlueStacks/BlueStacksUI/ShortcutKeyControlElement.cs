﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000AD RID: 173
	public class ShortcutKeyControlElement : UserControl, IComponentConnector
	{
		// Token: 0x170001BD RID: 445
		// (get) Token: 0x060006D1 RID: 1745 RVA: 0x0000671F File Offset: 0x0000491F
		// (set) Token: 0x060006D2 RID: 1746 RVA: 0x00006727 File Offset: 0x00004927
		internal List<ShortcutKeys> mUserDefinedConfigList { get; set; }

		// Token: 0x060006D3 RID: 1747 RVA: 0x000285FC File Offset: 0x000267FC
		public ShortcutKeyControlElement(MainWindow window, SettingsWindow settingsWindow)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			this.ParentSettingsWindow = settingsWindow;
			InputMethod.SetIsInputMethodEnabled(this.mShortcutKeyTextBox, false);
			MainWindow parentWindow = this.ParentWindow;
			foreach (string value in (parentWindow != null) ? parentWindow.mCommonHandler.mShortcutsConfigInstance.DefaultModifier.Split(new char[]
			{
				','
			}, StringSplitOptions.RemoveEmptyEntries) : null)
			{
				Key key = (Key)Enum.Parse(typeof(Key), value);
				this.mDefaultModifierForUI = this.mDefaultModifierForUI + IMAPKeys.GetStringForUI(key) + " + ";
				this.mDefaultModifierForFile = this.mDefaultModifierForFile + IMAPKeys.GetStringForFile(key) + " + ";
			}
		}

		// Token: 0x060006D4 RID: 1748 RVA: 0x00006730 File Offset: 0x00004930
		private static bool IsValid(Key key)
		{
			return key != Key.LeftAlt && key != Key.RightAlt && key != Key.LeftShift && key != Key.RightShift && key != Key.LeftCtrl && key != Key.RightCtrl && key != Key.None && key != Key.System;
		}

		// Token: 0x060006D5 RID: 1749 RVA: 0x0000675E File Offset: 0x0000495E
		private void ShortcutKeyTextBoxKeyUp(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Snapshot || e.SystemKey == Key.Snapshot)
			{
				this.HandleShortcutKeyDown(e);
			}
		}

		// Token: 0x060006D6 RID: 1750 RVA: 0x0000677B File Offset: 0x0000497B
		private void ShortcutKeyTextBoxKeyDown(object sender, KeyEventArgs e)
		{
			this.HandleShortcutKeyDown(e);
		}

		// Token: 0x060006D7 RID: 1751 RVA: 0x000286D4 File Offset: 0x000268D4
		private void HandleShortcutKeyDown(KeyEventArgs e)
		{
			Logger.Debug("SHORTCUT: PrintKey............" + e.Key.ToString());
			Logger.Debug("SHORTCUT: PrintSystemKey............" + e.SystemKey.ToString());
			if (((IMAPKeys.mDictKeys.ContainsKey(e.Key) || IMAPKeys.mDictKeys.ContainsKey(e.SystemKey)) && (ShortcutKeyControlElement.IsValid(e.Key) || ShortcutKeyControlElement.IsValid(e.SystemKey))) || e.Key == Key.Back || e.Key == Key.Delete)
			{
				string text = string.Empty;
				string text2 = string.Empty;
				string str = string.Empty;
				this.mShortcutKeyTextBox.Tag = string.Empty;
				if (e.KeyboardDevice.Modifiers != ModifierKeys.None)
				{
					if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
					{
						text = IMAPKeys.GetStringForUI(Key.LeftCtrl) + " + ";
						this.mShortcutKeyTextBox.Tag = IMAPKeys.GetStringForFile(Key.LeftCtrl) + " + ";
					}
					if (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt))
					{
						text2 = IMAPKeys.GetStringForUI(Key.LeftAlt) + " + ";
						CustomTextBox customTextBox = this.mShortcutKeyTextBox;
						object tag = customTextBox.Tag;
						customTextBox.Tag = ((tag != null) ? tag.ToString() : null) + IMAPKeys.GetStringForFile(Key.LeftAlt) + " + ";
					}
					if (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift))
					{
						str = IMAPKeys.GetStringForUI(Key.LeftShift) + " + ";
						CustomTextBox customTextBox2 = this.mShortcutKeyTextBox;
						object tag2 = customTextBox2.Tag;
						customTextBox2.Tag = ((tag2 != null) ? tag2.ToString() : null) + IMAPKeys.GetStringForFile(Key.LeftShift) + " + ";
					}
					if ((string.IsNullOrEmpty(text) && !string.IsNullOrEmpty(text2)) || e.SystemKey == Key.F10)
					{
						this.mShortcutKeyTextBox.Text = text + text2 + str + IMAPKeys.GetStringForUI(e.SystemKey);
						CustomTextBox customTextBox3 = this.mShortcutKeyTextBox;
						object tag3 = customTextBox3.Tag;
						customTextBox3.Tag = ((tag3 != null) ? tag3.ToString() : null) + IMAPKeys.GetStringForFile(e.SystemKey);
					}
					else
					{
						this.mShortcutKeyTextBox.Text = text + text2 + str + IMAPKeys.GetStringForUI(e.Key);
						CustomTextBox customTextBox4 = this.mShortcutKeyTextBox;
						object tag4 = customTextBox4.Tag;
						customTextBox4.Tag = ((tag4 != null) ? tag4.ToString() : null) + IMAPKeys.GetStringForFile(e.Key);
					}
				}
				else if (e.Key == Key.Back || e.Key == Key.Delete)
				{
					this.mShortcutKeyTextBox.Text = string.Empty;
					this.mShortcutKeyTextBox.Tag = string.Empty;
					if (this.ParentSettingsWindow.mDuplicateShortcutsList.Contains(this.mShortcutNameTextBlock.Text))
					{
						this.ParentSettingsWindow.mDuplicateShortcutsList.Remove(this.mShortcutNameTextBlock.Text);
					}
					this.SetSaveButtonState(this.ParentSettingsWindow.mIsShortcutEdited);
				}
				else if (e.Key == Key.Escape)
				{
					if (string.Equals(this.mDefaultModifierForFile, "Shift + ", StringComparison.InvariantCulture))
					{
						this.mShortcutKeyTextBox.Text = this.mDefaultModifierForUI + IMAPKeys.GetStringForUI(e.Key);
						this.mShortcutKeyTextBox.Tag = this.mDefaultModifierForFile + IMAPKeys.GetStringForFile(e.Key);
					}
				}
				else if ((e.Key == Key.D0 || e.SystemKey == Key.D0) && string.Equals(this.mDefaultModifierForUI, "Ctrl + Shift + ", StringComparison.InvariantCulture))
				{
					this.mShortcutKeyTextBox.Text = string.Empty;
					this.mShortcutKeyTextBox.Tag = string.Empty;
					this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_WINDOW_ACTION_ERROR"));
				}
				else if (e.Key == Key.System)
				{
					this.mShortcutKeyTextBox.Text = this.mDefaultModifierForUI + IMAPKeys.GetStringForUI(e.SystemKey);
					this.mShortcutKeyTextBox.Tag = this.mDefaultModifierForFile + IMAPKeys.GetStringForFile(e.SystemKey);
				}
				else
				{
					this.mShortcutKeyTextBox.Text = this.mDefaultModifierForUI + IMAPKeys.GetStringForUI(e.Key);
					this.mShortcutKeyTextBox.Tag = this.mDefaultModifierForFile + IMAPKeys.GetStringForFile(e.Key);
				}
				e.Handled = true;
				this.mShortcutKeyTextBox.CaretIndex = this.mShortcutKeyTextBox.Text.Length;
				this.mIsShortcutSameAsMacroShortcut = false;
				if ((MainWindow.sMacroMapping.ContainsKey(IMAPKeys.GetStringForUI(e.Key)) || MainWindow.sMacroMapping.ContainsKey(IMAPKeys.GetStringForUI(e.SystemKey))) && (string.Equals(this.mShortcutKeyTextBox.Text, text + text2 + IMAPKeys.GetStringForUI(e.Key), StringComparison.InvariantCulture) || string.Equals(this.mShortcutKeyTextBox.Text, text + text2 + IMAPKeys.GetStringForUI(e.SystemKey), StringComparison.InvariantCulture)))
				{
					this.mIsShortcutSameAsMacroShortcut = true;
				}
				if (string.Equals(this.mShortcutKeyTextBox.Text, "Alt + F4", StringComparison.InvariantCulture))
				{
					this.mShortcutKeyTextBox.Text = string.Empty;
					this.mShortcutKeyTextBox.Tag = string.Empty;
					this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_WINDOW_ACTION_ERROR"));
				}
				foreach (ShortcutKeys shortcutKeys in this.mUserDefinedConfigList)
				{
					this.mShortcutKeyTextBox.InputTextValidity = TextValidityOptions.Success;
					this.mKeyInfoPopup.IsOpen = false;
					this.ParentSettingsWindow.mIsShortcutEdited = true;
					this.CheckIfShortcutAlreadyUsed();
					this.ParentWindow.mCommonHandler.OnShortcutKeysRefresh();
					if (string.Equals(LocaleStrings.GetLocalizedString(shortcutKeys.ShortcutName), this.mShortcutNameTextBlock.Text, StringComparison.InvariantCulture) && !string.Equals(shortcutKeys.ShortcutKey, this.mShortcutKeyTextBox.Text, StringComparison.InvariantCulture))
					{
						shortcutKeys.ShortcutKey = this.mShortcutKeyTextBox.Tag.ToString();
						Stats.SendMiscellaneousStatsAsync("KeyboardShortcuts", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "shortcut_edit", this.mShortcutNameTextBlock.Text, null, null, null, null, "Android", 0);
					}
				}
			}
		}

		// Token: 0x060006D8 RID: 1752 RVA: 0x00028D1C File Offset: 0x00026F1C
		private void AddToastPopup(string message)
		{
			try
			{
				if (this.mToastPopup == null)
				{
					this.mToastPopup = new CustomToastPopupControl(this.ParentSettingsWindow);
				}
				this.mToastPopup.Init(this.ParentSettingsWindow, message, null, null, HorizontalAlignment.Center, VerticalAlignment.Top, null, 12, null, null);
				this.mToastPopup.Margin = new Thickness(20.0, 30.0, 0.0, 0.0);
				this.mToastPopup.ShowPopup(1.3);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in showing toast popup: " + ex.ToString());
			}
		}

		// Token: 0x060006D9 RID: 1753 RVA: 0x00028DE0 File Offset: 0x00026FE0
		private void CheckIfShortcutAlreadyUsed()
		{
			this.mErrorMessageShown = false;
			foreach (ShortcutKeys shortcutKeys in this.ParentWindow.mCommonHandler.mShortcutsConfigInstance.Shortcut)
			{
				if ((!string.IsNullOrEmpty(shortcutKeys.ShortcutKey) && string.Equals(shortcutKeys.ShortcutKey, this.mShortcutKeyTextBox.Tag.ToString(), StringComparison.InvariantCulture) && !string.Equals(LocaleStrings.GetLocalizedString(shortcutKeys.ShortcutName), this.mShortcutNameTextBlock.Text, StringComparison.InvariantCulture)) || this.mIsShortcutSameAsMacroShortcut)
				{
					this.mKeyInfoPopup.PlacementTarget = this.mShortcutKeyTextBox;
					this.mShortcutKeyTextBox.InputTextValidity = TextValidityOptions.Error;
					this.mKeyInfoPopup.IsOpen = true;
					this.mErrorMessageShown = true;
					if (!this.ParentSettingsWindow.mDuplicateShortcutsList.Contains(this.mShortcutNameTextBlock.Text))
					{
						this.ParentSettingsWindow.mDuplicateShortcutsList.Add(this.mShortcutNameTextBlock.Text);
					}
				}
			}
			if (!this.mErrorMessageShown && this.ParentSettingsWindow.mDuplicateShortcutsList.Contains(this.mShortcutNameTextBlock.Text))
			{
				this.ParentSettingsWindow.mDuplicateShortcutsList.Remove(this.mShortcutNameTextBlock.Text);
			}
			this.SetSaveButtonState(this.ParentSettingsWindow.mIsShortcutEdited);
		}

		// Token: 0x060006DA RID: 1754 RVA: 0x00028F54 File Offset: 0x00027154
		private void SetSaveButtonState(bool isEdited)
		{
			if (this.ParentSettingsWindow.mDuplicateShortcutsList.Count == 0 && isEdited)
			{
				this.ParentWindow.mCommonHandler.OnShortcutKeysChanged(true);
				this.ParentSettingsWindow.mIsShortcutSaveBtnEnabled = true;
				return;
			}
			this.ParentWindow.mCommonHandler.OnShortcutKeysChanged(false);
			this.ParentSettingsWindow.mIsShortcutSaveBtnEnabled = false;
		}

		// Token: 0x060006DB RID: 1755 RVA: 0x00028FB4 File Offset: 0x000271B4
		private void ShortcutKeyTextBoxMouseEnter(object sender, MouseEventArgs e)
		{
			if (this.mShortcutKeyTextBox.InputTextValidity == TextValidityOptions.Error)
			{
				this.mKeyInfoPopup.PlacementTarget = this.mShortcutKeyTextBox;
				this.mKeyInfoPopup.IsOpen = true;
				this.mKeyInfoPopup.StaysOpen = true;
				return;
			}
			this.mKeyInfoPopup.IsOpen = false;
		}

		// Token: 0x060006DC RID: 1756 RVA: 0x00006784 File Offset: 0x00004984
		private void ShortcutKeyTextBoxMouseLeave(object sender, MouseEventArgs e)
		{
			this.mKeyInfoPopup.IsOpen = false;
		}

		// Token: 0x060006DD RID: 1757 RVA: 0x00029008 File Offset: 0x00027208
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/shortcutkeycontrolelement.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060006DE RID: 1758 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060006DF RID: 1759 RVA: 0x00029038 File Offset: 0x00027238
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mShortcutNameTextBlock = (TextBlock)target;
				return;
			case 2:
				this.mShortcutKeyTextBox = (CustomTextBox)target;
				this.mShortcutKeyTextBox.PreviewKeyDown += this.ShortcutKeyTextBoxKeyDown;
				this.mShortcutKeyTextBox.MouseEnter += this.ShortcutKeyTextBoxMouseEnter;
				this.mShortcutKeyTextBox.MouseLeave += this.ShortcutKeyTextBoxMouseLeave;
				this.mShortcutKeyTextBox.PreviewKeyUp += this.ShortcutKeyTextBoxKeyUp;
				return;
			case 3:
				this.mKeyInfoPopup = (CustomPopUp)target;
				return;
			case 4:
				this.mMaskBorder = (Border)target;
				return;
			case 5:
				this.mKeyInfoText = (TextBlock)target;
				return;
			case 6:
				this.mDownArrow = (Path)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040003EB RID: 1003
		internal MainWindow ParentWindow;

		// Token: 0x040003EC RID: 1004
		internal SettingsWindow ParentSettingsWindow;

		// Token: 0x040003ED RID: 1005
		internal string mDefaultModifierForUI = string.Empty;

		// Token: 0x040003EE RID: 1006
		internal string mDefaultModifierForFile = string.Empty;

		// Token: 0x040003EF RID: 1007
		private bool mErrorMessageShown;

		// Token: 0x040003F0 RID: 1008
		internal bool mIsShortcutSameAsMacroShortcut;

		// Token: 0x040003F1 RID: 1009
		private CustomToastPopupControl mToastPopup;

		// Token: 0x040003F2 RID: 1010
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mShortcutNameTextBlock;

		// Token: 0x040003F3 RID: 1011
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mShortcutKeyTextBox;

		// Token: 0x040003F4 RID: 1012
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mKeyInfoPopup;

		// Token: 0x040003F5 RID: 1013
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder;

		// Token: 0x040003F6 RID: 1014
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mKeyInfoText;

		// Token: 0x040003F7 RID: 1015
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Path mDownArrow;

		// Token: 0x040003F8 RID: 1016
		private bool _contentLoaded;
	}
}
