﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace BlueStacks.BlueStacksUI.Properties
{
	// Token: 0x02000289 RID: 649
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "14.0.0.0")]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x170002FC RID: 764
		// (get) Token: 0x06001764 RID: 5988 RVA: 0x00010063 File Offset: 0x0000E263
		public static Settings Default
		{
			get
			{
				return Settings.defaultInstance;
			}
		}

		// Token: 0x04000F0F RID: 3855
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());
	}
}
