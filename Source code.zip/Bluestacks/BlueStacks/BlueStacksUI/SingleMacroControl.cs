﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Navigation;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000CD RID: 205
	public class SingleMacroControl : UserControl, IComponentConnector
	{
		// Token: 0x170001D0 RID: 464
		// (get) Token: 0x06000867 RID: 2151 RVA: 0x0000772E File Offset: 0x0000592E
		// (set) Token: 0x06000868 RID: 2152 RVA: 0x00007736 File Offset: 0x00005936
		public bool IsBookmarked
		{
			get
			{
				return this.mIsBookmarked;
			}
			set
			{
				this.mIsBookmarked = value;
				this.ToggleBookmarkIcon(value);
			}
		}

		// Token: 0x06000869 RID: 2153 RVA: 0x00007746 File Offset: 0x00005946
		private void ToggleBookmarkIcon(bool isBookmarked)
		{
			if (isBookmarked)
			{
				this.mBookmarkImg.ImageName = "bookmarked";
				return;
			}
			this.mBookmarkImg.ImageName = "bookmark";
		}

		// Token: 0x0600086A RID: 2154 RVA: 0x000308BC File Offset: 0x0002EABC
		internal SingleMacroControl(MainWindow parentWindow, MacroRecording record, MacroRecorderWindow recorderWindow)
		{
			this.InitializeComponent();
			this.mRecording = record;
			this.ParentWindow = parentWindow;
			this.mMacroRecorderWindow = recorderWindow;
			InputMethod.SetIsInputMethodEnabled(this.mMacroShortcutTextBox, false);
			this.mTimestamp.Text = DateTime.ParseExact(this.mRecording.TimeCreated, "yyyyMMddTHHmmss", CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal).ToString("yyyy.MM.dd HH.mm.ss", CultureInfo.InvariantCulture);
			this.mScriptName.Text = this.mRecording.Name;
			this.mMacroShortcutTextBox.Text = IMAPKeys.GetStringForUI(this.mRecording.Shortcut);
			this.mScriptName.ToolTip = this.mScriptName.Text;
			if (record.RecordingType == RecordingTypes.MultiRecording)
			{
				this.mScriptSettingsImg.Visibility = Visibility.Collapsed;
				this.mMergeScriptSettingsImg.Visibility = Visibility.Visible;
			}
			if (!string.IsNullOrEmpty(this.mRecording.Shortcut))
			{
				Key key = IMAPKeys.mDictKeys.FirstOrDefault((KeyValuePair<Key, string> x) => x.Value == this.mRecording.Shortcut).Key;
				this.mMacroShortcutTextBox.Tag = IMAPKeys.GetStringForFile(key);
				MainWindow.sMacroMapping[this.mMacroShortcutTextBox.Tag.ToString()] = this.mScriptName.Text;
			}
			else
			{
				this.mMacroShortcutTextBox.Tag = "";
			}
			this.IsBookmarked = BlueStacksUIUtils.CheckIfMacroScriptBookmarked(this.mRecording.Name);
			if (record.PlayOnStart)
			{
				this.mAutorunImage.Visibility = Visibility.Visible;
			}
			if (this.ParentWindow.mIsMacroPlaying && string.Equals(this.mRecording.Name, this.ParentWindow.mMacroPlaying, StringComparison.InvariantCulture))
			{
				this.ToggleScriptPlayPauseUi(true);
				return;
			}
			this.ToggleScriptPlayPauseUi(false);
		}

		// Token: 0x0600086B RID: 2155 RVA: 0x0000776C File Offset: 0x0000596C
		public void UpdateMacroRecordingObject(MacroRecording record)
		{
			this.mRecording = record;
		}

		// Token: 0x0600086C RID: 2156 RVA: 0x00023988 File Offset: 0x00021B88
		public static bool DeleteScriptNameFromBookmarkedScriptListIfPresent(string fileName)
		{
			if (RegistryManager.Instance.BookmarkedScriptList.Contains(fileName))
			{
				List<string> list = new List<string>(RegistryManager.Instance.BookmarkedScriptList);
				list.Remove(fileName);
				RegistryManager.Instance.BookmarkedScriptList = list.ToArray();
				return true;
			}
			return false;
		}

		// Token: 0x0600086D RID: 2157 RVA: 0x00030A74 File Offset: 0x0002EC74
		public bool AddScriptNameToBookmarkedScriptListIfNotPresent(string fileName)
		{
			if (!RegistryManager.Instance.BookmarkedScriptList.Contains(this.mRecording.Name))
			{
				List<string> list = new List<string>(RegistryManager.Instance.BookmarkedScriptList)
				{
					fileName
				};
				RegistryManager.Instance.BookmarkedScriptList = list.ToArray();
				return true;
			}
			return false;
		}

		// Token: 0x0600086E RID: 2158 RVA: 0x00030AC8 File Offset: 0x0002ECC8
		private void UpdateMacroDeleteWindowSettings()
		{
			this.ParentWindow.EngineInstanceRegistry.ShowMacroDeletePopup = !this.mDeleteScriptMessageWindow.CheckBox.IsChecked.Value;
			this.mDeleteScriptMessageWindow = null;
		}

		// Token: 0x0600086F RID: 2159 RVA: 0x00030B08 File Offset: 0x0002ED08
		private void DeleteMacroScript()
		{
			string path = Path.Combine(RegistryStrings.MacroRecordingsFolderPath, this.mRecording.Name + ".json");
			if (File.Exists(path))
			{
				File.Delete(path);
			}
			if (this.mRecording.Shortcut != null && MainWindow.sMacroMapping.ContainsKey(this.mRecording.Shortcut))
			{
				MainWindow.sMacroMapping.Remove(this.mRecording.Shortcut);
			}
			SingleMacroControl.DeleteScriptNameFromBookmarkedScriptListIfPresent(this.mRecording.Name);
			MacroRecording vertex = (from MacroRecording macro in MacroGraph.Instance.Vertices
			where string.Equals(macro.Name, this.mRecording.Name, StringComparison.InvariantCultureIgnoreCase)
			select macro).FirstOrDefault<MacroRecording>();
			MacroGraph.Instance.RemoveVertex(vertex);
			if (this.ParentWindow.mAutoRunMacro != null && this.ParentWindow.mAutoRunMacro.Name.ToLower(CultureInfo.InvariantCulture).Trim() == this.mRecording.Name.ToLower(CultureInfo.InvariantCulture).Trim())
			{
				this.ParentWindow.mAutoRunMacro = null;
			}
			CommonHandlers.RefreshAllMacroRecorderWindow();
			CommonHandlers.OnMacroDeleted(this.mRecording.Name);
		}

		// Token: 0x06000870 RID: 2160 RVA: 0x00007775 File Offset: 0x00005975
		private void SingleMacroControl_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(this.mGrid, Control.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
			this.mEditNameImg.Visibility = Visibility.Visible;
		}

		// Token: 0x06000871 RID: 2161 RVA: 0x00007798 File Offset: 0x00005998
		private void SingleMacroControl_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mGrid.Background = new SolidColorBrush(Colors.Transparent);
			this.mEditNameImg.Visibility = Visibility.Hidden;
		}

		// Token: 0x06000872 RID: 2162 RVA: 0x00005D29 File Offset: 0x00003F29
		private void PauseScriptImg_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
		}

		// Token: 0x06000873 RID: 2163 RVA: 0x00030C30 File Offset: 0x0002EE30
		private void StopScriptImg_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ToggleScriptPlayPauseUi(false);
			this.ParentWindow.mCommonHandler.StopMacroScriptHandling();
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_stop", null, this.mRecording.RecordingType.ToString(), null, null, null);
		}

		// Token: 0x06000874 RID: 2164 RVA: 0x000077BB File Offset: 0x000059BB
		internal void ToggleScriptPlayPauseUi(bool isScriptRunning)
		{
			if (isScriptRunning)
			{
				this.mScriptPlayPanel.Visibility = Visibility.Collapsed;
				this.mScriptRunningPanel.Visibility = Visibility.Visible;
				return;
			}
			this.mScriptPlayPanel.Visibility = Visibility.Visible;
			this.mScriptRunningPanel.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000875 RID: 2165 RVA: 0x00030C94 File Offset: 0x0002EE94
		private void ScriptSettingsImg_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mMacroRecorderWindow.mOverlayGrid.Visibility = Visibility.Visible;
			MacroRecording macroRecording = (from MacroRecording macro in MacroGraph.Instance.Vertices
			where macro.Equals(this.mRecording)
			select macro).FirstOrDefault<MacroRecording>();
			MacroRecording macroRecording2 = this.mRecording;
			if (macroRecording2 != null && macroRecording2.RecordingType == RecordingTypes.MultiRecording)
			{
				ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "merge_macro_edit", null, null, null, null, null);
				if (this.mMacroRecorderWindow.mMergeMacroWindow == null)
				{
					this.mMacroRecorderWindow.mMergeMacroWindow = new MergeMacroWindow(this.mMacroRecorderWindow, this.ParentWindow)
					{
						Owner = this.ParentWindow
					};
				}
				this.mMacroRecorderWindow.mMergeMacroWindow.Init(macroRecording, this);
				this.mMacroRecorderWindow.mMergeMacroWindow.Show();
				return;
			}
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_window_settings", null, this.mRecording.RecordingType.ToString(), null, null, null);
			if (this.mMacroSettingsWindow == null || this.mMacroSettingsWindow.IsClosed)
			{
				this.mMacroSettingsWindow = new MacroSettingsWindow(this.ParentWindow, macroRecording, this.mMacroRecorderWindow);
			}
			this.mMacroSettingsWindow.ShowDialog();
		}

		// Token: 0x06000876 RID: 2166 RVA: 0x00030DEC File Offset: 0x0002EFEC
		private void BookMarkScriptImg_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.IsBookmarked)
			{
				this.IsBookmarked = false;
				SingleMacroControl.DeleteScriptNameFromBookmarkedScriptListIfPresent(this.mRecording.Name);
				this.ParentWindow.mCommonHandler.OnMacroBookmarkChanged(this.mRecording.Name, false);
			}
			else if (RegistryManager.Instance.BookmarkedScriptList.Length < 5)
			{
				this.IsBookmarked = true;
				this.AddScriptNameToBookmarkedScriptListIfNotPresent(this.mRecording.Name);
				this.ParentWindow.mCommonHandler.OnMacroBookmarkChanged(this.mRecording.Name, true);
			}
			else
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this.mMacroRecorderWindow, LocaleStrings.GetLocalizedString("STRING_BOOKMARK_MACRO_WARNING"), 4.0, true);
			}
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_window_bookmark", null, this.mRecording.RecordingType.ToString(), null, null, null);
		}

		// Token: 0x06000877 RID: 2167 RVA: 0x00030EE8 File Offset: 0x0002F0E8
		private void DeleteScriptImg_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			MacroRecording currentRecording = (from MacroRecording macro in MacroGraph.Instance.Vertices
			where string.Equals(macro.Name, this.mRecording.Name, StringComparison.InvariantCultureIgnoreCase)
			select macro).FirstOrDefault<MacroRecording>();
			if (currentRecording == null)
			{
				return;
			}
			if (currentRecording.Parents.Count > 0)
			{
				this.mDeleteScriptMessageWindow = new CustomMessageWindow();
				this.mDeleteScriptMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_DELETE_DEPENDENT_MACRO");
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(LocaleStrings.GetLocalizedString("STRING_MACRO_IN_USE_BY_OTHER_MACROS"));
				stringBuilder.Append(" ");
				stringBuilder.Append(string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_MACRO_LOSE_CONFIGURABILITY"), new object[]
				{
					this.mRecording.Name
				}));
				this.mDeleteScriptMessageWindow.BodyTextBlock.Text = stringBuilder.ToString();
				this.mDeleteScriptMessageWindow.AddButton(ButtonColors.Red, LocaleStrings.GetLocalizedString("STRING_DELETE_ANYWAY"), delegate(object o, EventArgs evt)
				{
					int i;
					int j;
					for (i = currentRecording.Parents.Count - 1; i >= 0; i = j - 1)
					{
						MacroRecording macroRecording = (from MacroRecording macro in MacroGraph.Instance.Vertices
						where macro.Equals(currentRecording.Parents[i])
						select macro).FirstOrDefault<MacroRecording>();
						this.mMacroRecorderWindow.FlattenRecording(currentRecording.Parents[i] as MacroRecording, false);
						CommonHandlers.SaveMacroJson(currentRecording.Parents[i] as MacroRecording, (currentRecording.Parents[i] as MacroRecording).Name + ".json");
						foreach (object obj in this.mMacroRecorderWindow.mScriptsStackPanel.Children)
						{
							SingleMacroControl singleMacroControl = (SingleMacroControl)obj;
							if (singleMacroControl.mRecording.Name.ToLower(CultureInfo.InvariantCulture).Trim() == macroRecording.Name.ToLower(CultureInfo.InvariantCulture).Trim())
							{
								singleMacroControl.mScriptSettingsImg.ImageName = "macro_settings";
							}
						}
						MacroGraph.Instance.DeLinkMacroChild(currentRecording.Parents[i] as MacroRecording);
						j = i;
					}
					this.DeleteMacroScript();
					CommonHandlers.RefreshAllMacroRecorderWindow();
				}, null, false, null);
				this.mDeleteScriptMessageWindow.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_DONT_DELETE"), delegate(object o, EventArgs evt)
				{
				}, null, false, null);
				this.mDeleteScriptMessageWindow.CloseButtonHandle(delegate(object o, EventArgs evt)
				{
				}, null);
				this.mDeleteScriptMessageWindow.Owner = this.ParentWindow;
				this.mDeleteScriptMessageWindow.ShowDialog();
				return;
			}
			if (!this.ParentWindow.EngineInstanceRegistry.ShowMacroDeletePopup)
			{
				this.DeleteMacroScript();
				return;
			}
			this.mDeleteScriptMessageWindow = new CustomMessageWindow();
			this.mDeleteScriptMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_DELETE_MACRO");
			this.mDeleteScriptMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_DELETE_SCRIPT");
			this.mDeleteScriptMessageWindow.CheckBox.Content = LocaleStrings.GetLocalizedString("STRING_DOWNLOAD_GOOGLE_APP_POPUP_STRING_04");
			this.mDeleteScriptMessageWindow.CheckBox.Visibility = Visibility.Visible;
			this.mDeleteScriptMessageWindow.CheckBox.IsChecked = new bool?(false);
			this.mDeleteScriptMessageWindow.AddButton(ButtonColors.Red, LocaleStrings.GetLocalizedString("STRING_DELETE"), new EventHandler(this.FlattenTargetMacrosAndDeleteSourceMacro), null, false, null);
			this.mDeleteScriptMessageWindow.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_CANCEL"), delegate(object o, EventArgs evt)
			{
				this.ParentWindow.EngineInstanceRegistry.ShowMacroDeletePopup = !this.mDeleteScriptMessageWindow.CheckBox.IsChecked.Value;
			}, null, false, null);
			this.mDeleteScriptMessageWindow.CloseButtonHandle(delegate(object o, EventArgs evt)
			{
			}, null);
			this.mDeleteScriptMessageWindow.Owner = this.ParentWindow;
			this.mDeleteScriptMessageWindow.ShowDialog();
		}

		// Token: 0x06000878 RID: 2168 RVA: 0x000077F1 File Offset: 0x000059F1
		private void FlattenTargetMacrosAndDeleteSourceMacro(object sender, EventArgs e)
		{
			this.UpdateMacroDeleteWindowSettings();
			this.DeleteMacroScript();
		}

		// Token: 0x06000879 RID: 2169 RVA: 0x000311AC File Offset: 0x0002F3AC
		private void PlayScriptImg_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow.mIsMacroPlaying)
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this.mMacroRecorderWindow, LocaleStrings.GetLocalizedString("STRING_STOP_THE_SCRIPT"), 4.0, true);
				return;
			}
			if (MacroGraph.CheckIfDependentMacrosAreAvailable(this.mRecording))
			{
				this.ToggleScriptPlayPauseUi(true);
				this.ParentWindow.mCommonHandler.PlayMacroScript(this.mRecording);
				ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_play", "macro_popup", this.mRecording.RecordingType.ToString(), string.IsNullOrEmpty(this.mRecording.MacroId) ? "local" : "community", null, null);
				this.ParentWindow.mCommonHandler.HideMacroRecorderWindow();
				return;
			}
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.Owner = this.mMacroRecorderWindow;
			BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_ERROR_IN_MERGE_MACRO", "");
			customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", delegate(object o, EventArgs evt)
			{
			}, null, false, null);
			customMessageWindow.ShowDialog();
		}

		// Token: 0x0600087A RID: 2170 RVA: 0x000312F0 File Offset: 0x0002F4F0
		private void EditMacroName_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (string.Equals(this.mEditNameImg.ImageName, "edit_icon", StringComparison.InvariantCulture))
			{
				e.Handled = true;
				this.mScriptName.IsEnabled = true;
				this.mEditNameImg.ImageName = "macro_name_save";
				this.mScriptName.Width = this.mScriptNameGrid.ActualWidth - this.mEditNameImg.ActualWidth - this.mTimestamp.ActualWidth - this.mPrefix.ActualWidth - 30.0;
				this.mLastScriptName = this.mScriptName.Text;
				this.mScriptName.Focusable = true;
				this.mScriptName.IsReadOnly = false;
				this.mScriptName.Focus();
				BlueStacksUIBinding.Bind(this.mEditNameImg, "STRING_SAVE");
				this.mScriptName.CaretIndex = this.mScriptName.Text.Length;
				return;
			}
			this.PerformSaveMacroNameOperations();
		}

		// Token: 0x0600087B RID: 2171 RVA: 0x000313E8 File Offset: 0x0002F5E8
		private void PerformSaveMacroNameOperations()
		{
			this.mScriptName.IsEnabled = false;
			this.mScriptName.Focusable = false;
			this.mScriptName.IsReadOnly = true;
			this.mScriptName.BorderThickness = new Thickness(0.0);
			this.mEditNameImg.ImageName = "edit_icon";
			BlueStacksUIBinding.Bind(this.mEditNameImg, "STRING_RENAME");
			this.SaveMacroName();
		}

		// Token: 0x0600087C RID: 2172 RVA: 0x00031458 File Offset: 0x0002F658
		private void SaveMacroName()
		{
			if (string.IsNullOrEmpty(this.mScriptName.Text.Trim()))
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this.ParentWindow.MacroRecorderWindow, LocaleStrings.GetLocalizedString("STRING_MACRO_NAME_NULL_MESSAGE"), 4.0, true);
				this.mScriptName.Text = this.mLastScriptName;
				return;
			}
			if ((from MacroRecording macro in MacroGraph.Instance.Vertices
			select macro.Name.ToLower(CultureInfo.InvariantCulture)).Contains(this.mScriptName.Text.ToLower(CultureInfo.InvariantCulture).Trim()) && !(this.mScriptName.Text.ToLower(CultureInfo.InvariantCulture).Trim() == this.mRecording.Name.ToLower(CultureInfo.InvariantCulture).Trim()))
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this.ParentWindow.MacroRecorderWindow, LocaleStrings.GetLocalizedString("STRING_MACRO_NOT_SAVED_MESSAGE"), 4.0, true);
				this.mScriptName.Text = this.mLastScriptName;
				return;
			}
			if (this.mScriptName.Text.Trim().IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
			{
				string message = string.Format(CultureInfo.InvariantCulture, "{0} {1} {2}", new object[]
				{
					LocaleStrings.GetLocalizedString("STRING_MACRO_NAME_ERROR"),
					Environment.NewLine,
					"\\ / : * ? \" < > |"
				});
				this.ParentWindow.mCommonHandler.AddToastPopup(this.ParentWindow.MacroRecorderWindow, message, 4.0, true);
				this.mScriptName.Text = this.mLastScriptName;
				return;
			}
			if (Constants.ReservedFileNamesList.Contains(this.mScriptName.Text.Trim().ToLower(CultureInfo.InvariantCulture)))
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this.ParentWindow.MacroRecorderWindow, LocaleStrings.GetLocalizedString("STRING_MACRO_FILE_NAME_ERROR"), 4.0, true);
				this.mScriptName.Text = this.mLastScriptName;
				return;
			}
			this.SaveScriptSettings();
		}

		// Token: 0x0600087D RID: 2173 RVA: 0x00031688 File Offset: 0x0002F888
		private void SaveScriptSettings()
		{
			try
			{
				if (!string.Equals(this.mRecording.Shortcut, this.mMacroShortcutTextBox.Tag.ToString(), StringComparison.InvariantCulture) || !string.Equals(this.mRecording.Name.Trim(), this.mScriptName.Text.Trim(), StringComparison.InvariantCultureIgnoreCase))
				{
					JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
					serializerSettings.Formatting = Formatting.Indented;
					string text = Path.Combine(RegistryStrings.MacroRecordingsFolderPath, this.mRecording.Name + ".json");
					if (this.mRecording.Shortcut != this.mMacroShortcutTextBox.Tag.ToString())
					{
						if (!string.IsNullOrEmpty(this.mRecording.Shortcut) && MainWindow.sMacroMapping.ContainsKey(this.mRecording.Shortcut))
						{
							MainWindow.sMacroMapping.Remove(this.mRecording.Shortcut);
						}
						if (this.mMacroShortcutTextBox.Tag != null && !string.IsNullOrEmpty(this.mMacroShortcutTextBox.Tag.ToString()))
						{
							MainWindow.sMacroMapping[this.mMacroShortcutTextBox.Tag.ToString()] = this.mScriptName.Text;
						}
						if (this.mRecording.Shortcut != null && this.mMacroShortcutTextBox.Tag != null && !string.Equals(this.mRecording.Shortcut, this.mMacroShortcutTextBox.Tag.ToString(), StringComparison.InvariantCulture))
						{
							ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_window_shortcutkey", null, this.mRecording.RecordingType.ToString(), null, null, null);
						}
						if (this.mMacroShortcutTextBox.Tag != null)
						{
							this.mRecording.Shortcut = this.mMacroShortcutTextBox.Tag.ToString();
						}
						if (this.mRecording.PlayOnStart)
						{
							this.ParentWindow.mAutoRunMacro = this.mRecording;
						}
						string contents = JsonConvert.SerializeObject(this.mRecording, serializerSettings);
						File.WriteAllText(text, contents);
					}
					if (!string.Equals(this.mRecording.Name.Trim(), this.mScriptName.Text.Trim(), StringComparison.InvariantCultureIgnoreCase))
					{
						string oldMacroName = this.mRecording.Name;
						MacroRecording macroRecording = (from MacroRecording macro in MacroGraph.Instance.Vertices
						where string.Equals(macro.Name, this.mRecording.Name, StringComparison.InvariantCultureIgnoreCase)
						select macro).FirstOrDefault<MacroRecording>();
						macroRecording.Name = this.mScriptName.Text.ToLower(CultureInfo.InvariantCulture).Trim();
						this.mRecording.Name = this.mScriptName.Text.Trim();
						if (this.mRecording.PlayOnStart)
						{
							this.ParentWindow.mAutoRunMacro = this.mRecording;
						}
						string contents2 = JsonConvert.SerializeObject(this.mRecording, serializerSettings);
						File.WriteAllText(text, contents2);
						string destFileName = Path.Combine(RegistryStrings.MacroRecordingsFolderPath, this.mScriptName.Text.Trim() + ".json");
						File.Move(text, destFileName);
						Func<string, string> <>9__1;
						foreach (MacroRecording macroRecording2 in macroRecording.Parents.Cast<MacroRecording>())
						{
							foreach (MergedMacroConfiguration mergedMacroConfiguration in macroRecording2.MergedMacroConfigurations)
							{
								List<string> list = new List<string>();
								IEnumerable<string> macrosToRun = mergedMacroConfiguration.MacrosToRun;
								Func<string, string> selector;
								if ((selector = <>9__1) == null)
								{
									selector = (<>9__1 = delegate(string macroToRun)
									{
										if (!string.Equals(oldMacroName, macroToRun, StringComparison.CurrentCultureIgnoreCase))
										{
											return macroToRun;
										}
										return macroToRun.Replace(macroToRun, this.mRecording.Name);
									});
								}
								foreach (string item in macrosToRun.Select(selector))
								{
									list.Add(item);
								}
								mergedMacroConfiguration.MacrosToRun.Clear();
								foreach (string item2 in list)
								{
									mergedMacroConfiguration.MacrosToRun.Add(item2);
								}
							}
							CommonHandlers.SaveMacroJson(macroRecording2, CommonHandlers.GetCompleteMacroRecordingPath(macroRecording2.Name));
							CommonHandlers.OnMacroSettingChanged(macroRecording2);
						}
						if (this.IsBookmarked)
						{
							SingleMacroControl.DeleteScriptNameFromBookmarkedScriptListIfPresent(oldMacroName);
							this.AddScriptNameToBookmarkedScriptListIfNotPresent(this.mRecording.Name);
						}
					}
					CommonHandlers.OnMacroSettingChanged(this.mRecording);
					CommonHandlers.RefreshAllMacroRecorderWindow();
					CommonHandlers.ReloadMacroShortcutsForAllInstances();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in saving macro settings: " + ex.ToString());
			}
		}

		// Token: 0x0600087E RID: 2174 RVA: 0x000077FF File Offset: 0x000059FF
		private void NoSelection_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.mScriptName.SelectionLength = 0;
		}

		// Token: 0x0600087F RID: 2175 RVA: 0x00031BB4 File Offset: 0x0002FDB4
		private bool Valid(Key key)
		{
			if (key == Key.Escape || key == Key.LeftAlt || key == Key.RightAlt || key == Key.LeftCtrl || key == Key.RightCtrl || key == Key.RightShift || key == Key.LeftShift || key == Key.Capital || key == Key.Return || key == Key.Space || key == Key.Delete)
			{
				return false;
			}
			if (this.ParentWindow.mCommonHandler.mShortcutsConfigInstance != null)
			{
				string b = string.Format(CultureInfo.InvariantCulture, "{0} + {1} + {2}", new object[]
				{
					IMAPKeys.GetStringForFile(Key.LeftCtrl),
					IMAPKeys.GetStringForFile(Key.LeftAlt),
					IMAPKeys.GetStringForFile(key)
				});
				using (List<ShortcutKeys>.Enumerator enumerator = this.ParentWindow.mCommonHandler.mShortcutsConfigInstance.Shortcut.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						if (string.Equals(enumerator.Current.ShortcutKey, b, StringComparison.InvariantCulture))
						{
							this.ParentWindow.mCommonHandler.AddToastPopup(this.ParentWindow.MacroRecorderWindow, LocaleStrings.GetLocalizedString("STRING_ALREADY_IN_USE_MESSAGE"), 4.0, true);
							return false;
						}
					}
				}
			}
			if (!MainWindow.sMacroMapping.ContainsKey(IMAPKeys.GetStringForFile(key)))
			{
				return true;
			}
			if (MainWindow.sMacroMapping[IMAPKeys.GetStringForFile(key)] != this.mRecording.Name)
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this.ParentWindow.MacroRecorderWindow, LocaleStrings.GetLocalizedString("STRING_ALREADY_IN_USE_MESSAGE"), 4.0, true);
				return false;
			}
			return true;
		}

		// Token: 0x06000880 RID: 2176 RVA: 0x00031D3C File Offset: 0x0002FF3C
		private void MacroShortcutPreviewKeyDown(object sender, KeyEventArgs e)
		{
			this.mMacroShortcutTextBox.Text = "";
			this.mMacroShortcutTextBox.Tag = "";
			Key key = (e.Key == Key.System) ? e.SystemKey : e.Key;
			if (IMAPKeys.mDictKeys.ContainsKey(key) && this.Valid(key))
			{
				this.mMacroShortcutTextBox.Text = IMAPKeys.GetStringForUI(key);
				this.mMacroShortcutTextBox.Tag = IMAPKeys.GetStringForFile(key);
			}
			else
			{
				this.mMacroShortcutTextBox.Text = "";
				this.mMacroShortcutTextBox.Tag = "";
			}
			e.Handled = true;
			this.SaveScriptSettings();
		}

		// Token: 0x06000881 RID: 2177 RVA: 0x0000780D File Offset: 0x00005A0D
		private void ScriptName_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Return)
			{
				this.PerformSaveMacroNameOperations();
			}
		}

		// Token: 0x06000882 RID: 2178 RVA: 0x0000781E File Offset: 0x00005A1E
		private void ScriptName_LostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
		{
			this.PerformSaveMacroNameOperations();
		}

		// Token: 0x06000883 RID: 2179 RVA: 0x0000781E File Offset: 0x00005A1E
		private void ScriptName_LostFocus(object sender, RoutedEventArgs e)
		{
			this.PerformSaveMacroNameOperations();
		}

		// Token: 0x06000884 RID: 2180 RVA: 0x00007826 File Offset: 0x00005A26
		private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
		{
			this.mMacroRecorderWindow.OpenCommunityAndCloseMacroWindow(this.mRecording.AuthorPageUrl.ToString());
			e.Handled = true;
		}

		// Token: 0x06000885 RID: 2181 RVA: 0x00031DEC File Offset: 0x0002FFEC
		private void UserNameHyperlink_Loaded(object sender, RoutedEventArgs e)
		{
			if (!string.IsNullOrEmpty(this.mRecording.User))
			{
				this.mUserNameHyperlink.Inlines.Clear();
				this.mUserNameHyperlink.Inlines.Add(this.mRecording.User);
				if (this.mRecording.AuthorPageUrl != null && !string.IsNullOrEmpty(this.mRecording.AuthorPageUrl.ToString()))
				{
					this.mUserNameHyperlink.NavigateUri = this.mRecording.AuthorPageUrl;
				}
				this.mScriptName.FontSize = 13.0;
				this.mUserNameTextblock.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x06000886 RID: 2182 RVA: 0x0000784A File Offset: 0x00005A4A
		private void CommunityMacroPage_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mMacroRecorderWindow.OpenCommunityAndCloseMacroWindow(this.mRecording.MacroPageUrl.ToString());
		}

		// Token: 0x06000887 RID: 2183 RVA: 0x00007867 File Offset: 0x00005A67
		private void ScriptControl_Loaded(object sender, RoutedEventArgs e)
		{
			if (!string.IsNullOrEmpty(this.mRecording.User))
			{
				this.mCommunityMacroImage.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x06000888 RID: 2184 RVA: 0x00031E9C File Offset: 0x0003009C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/singlemacrocontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000889 RID: 2185 RVA: 0x00031ECC File Offset: 0x000300CC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((SingleMacroControl)target).MouseEnter += this.SingleMacroControl_MouseEnter;
				((SingleMacroControl)target).MouseLeave += this.SingleMacroControl_MouseLeave;
				((SingleMacroControl)target).Loaded += this.ScriptControl_Loaded;
				return;
			case 2:
				this.mGrid = (Grid)target;
				return;
			case 3:
				this.mBookmarkImg = (CustomPictureBox)target;
				this.mBookmarkImg.PreviewMouseLeftButtonUp += this.BookMarkScriptImg_PreviewMouseLeftButtonUp;
				return;
			case 4:
				this.mScriptNameGrid = (Grid)target;
				return;
			case 5:
				this.mScriptName = (CustomTextBox)target;
				this.mScriptName.PreviewLostKeyboardFocus += this.ScriptName_LostKeyboardFocus;
				this.mScriptName.LostFocus += this.ScriptName_LostFocus;
				this.mScriptName.MouseLeftButtonUp += this.NoSelection_MouseUp;
				this.mScriptName.KeyDown += this.ScriptName_KeyDown;
				return;
			case 6:
				this.mUserNameTextblock = (TextBlock)target;
				return;
			case 7:
				this.mUserNameHyperlink = (Hyperlink)target;
				this.mUserNameHyperlink.RequestNavigate += this.Hyperlink_RequestNavigate;
				this.mUserNameHyperlink.Loaded += this.UserNameHyperlink_Loaded;
				return;
			case 8:
				this.mEditNameImg = (CustomPictureBox)target;
				this.mEditNameImg.MouseLeftButtonDown += this.EditMacroName_MouseDown;
				return;
			case 9:
				this.mTimestamp = (TextBlock)target;
				return;
			case 10:
				this.mPrefix = (TextBlock)target;
				return;
			case 11:
				this.mMacroShortcutTextBox = (CustomTextBox)target;
				this.mMacroShortcutTextBox.PreviewKeyDown += this.MacroShortcutPreviewKeyDown;
				return;
			case 12:
				this.mScriptPlayPanel = (StackPanel)target;
				return;
			case 13:
				this.mAutorunImage = (CustomPictureBox)target;
				this.mAutorunImage.PreviewMouseLeftButtonUp += this.BookMarkScriptImg_PreviewMouseLeftButtonUp;
				return;
			case 14:
				this.mCommunityMacroImage = (CustomPictureBox)target;
				this.mCommunityMacroImage.PreviewMouseLeftButtonUp += this.CommunityMacroPage_PreviewMouseLeftButtonUp;
				return;
			case 15:
				this.mPlayScriptImg = (CustomPictureBox)target;
				this.mPlayScriptImg.PreviewMouseLeftButtonUp += this.PlayScriptImg_PreviewMouseLeftButtonUp;
				return;
			case 16:
				this.mScriptSettingsImg = (CustomPictureBox)target;
				this.mScriptSettingsImg.PreviewMouseLeftButtonUp += this.ScriptSettingsImg_PreviewMouseLeftButtonUp;
				return;
			case 17:
				this.mMergeScriptSettingsImg = (CustomPictureBox)target;
				this.mMergeScriptSettingsImg.PreviewMouseLeftButtonUp += this.ScriptSettingsImg_PreviewMouseLeftButtonUp;
				return;
			case 18:
				this.mDeleteScriptImg = (CustomPictureBox)target;
				this.mDeleteScriptImg.PreviewMouseLeftButtonUp += this.DeleteScriptImg_PreviewMouseLeftButtonUp;
				return;
			case 19:
				this.mScriptRunningPanel = (StackPanel)target;
				return;
			case 20:
				this.mStopScriptImg = (CustomPictureBox)target;
				this.mStopScriptImg.PreviewMouseLeftButtonUp += this.StopScriptImg_PreviewMouseLeftButtonUp;
				return;
			case 21:
				this.mRunning = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000523 RID: 1315
		private MainWindow ParentWindow;

		// Token: 0x04000524 RID: 1316
		internal MacroRecorderWindow mMacroRecorderWindow;

		// Token: 0x04000525 RID: 1317
		internal MacroRecording mRecording;

		// Token: 0x04000526 RID: 1318
		internal MacroSettingsWindow mMacroSettingsWindow;

		// Token: 0x04000527 RID: 1319
		private CustomMessageWindow mDeleteScriptMessageWindow;

		// Token: 0x04000528 RID: 1320
		private bool mIsBookmarked;

		// Token: 0x04000529 RID: 1321
		private string mLastScriptName;

		// Token: 0x0400052A RID: 1322
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mGrid;

		// Token: 0x0400052B RID: 1323
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mBookmarkImg;

		// Token: 0x0400052C RID: 1324
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mScriptNameGrid;

		// Token: 0x0400052D RID: 1325
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mScriptName;

		// Token: 0x0400052E RID: 1326
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mUserNameTextblock;

		// Token: 0x0400052F RID: 1327
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Hyperlink mUserNameHyperlink;

		// Token: 0x04000530 RID: 1328
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mEditNameImg;

		// Token: 0x04000531 RID: 1329
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mTimestamp;

		// Token: 0x04000532 RID: 1330
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mPrefix;

		// Token: 0x04000533 RID: 1331
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mMacroShortcutTextBox;

		// Token: 0x04000534 RID: 1332
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mScriptPlayPanel;

		// Token: 0x04000535 RID: 1333
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mAutorunImage;

		// Token: 0x04000536 RID: 1334
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCommunityMacroImage;

		// Token: 0x04000537 RID: 1335
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mPlayScriptImg;

		// Token: 0x04000538 RID: 1336
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mScriptSettingsImg;

		// Token: 0x04000539 RID: 1337
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mMergeScriptSettingsImg;

		// Token: 0x0400053A RID: 1338
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mDeleteScriptImg;

		// Token: 0x0400053B RID: 1339
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mScriptRunningPanel;

		// Token: 0x0400053C RID: 1340
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mStopScriptImg;

		// Token: 0x0400053D RID: 1341
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mRunning;

		// Token: 0x0400053E RID: 1342
		private bool _contentLoaded;
	}
}
