﻿using System;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200017A RID: 378
	public class AppIconPromotionObject
	{
		// Token: 0x1700024C RID: 588
		// (get) Token: 0x06000EAF RID: 3759 RVA: 0x0000ABCE File Offset: 0x00008DCE
		// (set) Token: 0x06000EB0 RID: 3760 RVA: 0x0000ABD6 File Offset: 0x00008DD6
		public string AppPromotionID { get; set; } = string.Empty;

		// Token: 0x1700024D RID: 589
		// (get) Token: 0x06000EB1 RID: 3761 RVA: 0x0000ABDF File Offset: 0x00008DDF
		// (set) Token: 0x06000EB2 RID: 3762 RVA: 0x0000ABE7 File Offset: 0x00008DE7
		public GenericAction AppPromotionAction { get; set; } = GenericAction.InstallPlay;

		// Token: 0x1700024E RID: 590
		// (get) Token: 0x06000EB3 RID: 3763 RVA: 0x0000ABF0 File Offset: 0x00008DF0
		// (set) Token: 0x06000EB4 RID: 3764 RVA: 0x0000ABF8 File Offset: 0x00008DF8
		public string AppPromotionPackage { get; set; } = string.Empty;

		// Token: 0x1700024F RID: 591
		// (get) Token: 0x06000EB5 RID: 3765 RVA: 0x0000AC01 File Offset: 0x00008E01
		// (set) Token: 0x06000EB6 RID: 3766 RVA: 0x0000AC09 File Offset: 0x00008E09
		public string AppPromotionName { get; set; } = string.Empty;

		// Token: 0x17000250 RID: 592
		// (get) Token: 0x06000EB7 RID: 3767 RVA: 0x0000AC12 File Offset: 0x00008E12
		// (set) Token: 0x06000EB8 RID: 3768 RVA: 0x0000AC1A File Offset: 0x00008E1A
		public string AppPromotionActionParam { get; set; } = string.Empty;

		// Token: 0x17000251 RID: 593
		// (get) Token: 0x06000EB9 RID: 3769 RVA: 0x0000AC23 File Offset: 0x00008E23
		// (set) Token: 0x06000EBA RID: 3770 RVA: 0x0000AC2B File Offset: 0x00008E2B
		public string AppPromotionImagePath { get; set; } = string.Empty;
	}
}
