﻿using System;
using System.Windows;
using System.Windows.Interactivity;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000034 RID: 52
	public class ResizeBlurbBehaviour : Behavior<OnBoardingPopupWindow>
	{
		// Token: 0x060002EA RID: 746 RVA: 0x00016D4C File Offset: 0x00014F4C
		protected override void OnAttached()
		{
			base.OnAttached();
			base.AssociatedObject.Owner.SizeChanged += new SizeChangedEventHandler(ResizeBlurbBehaviour.Owner_SizeChanged);
			base.AssociatedObject.Owner.LocationChanged += ResizeBlurbBehaviour.Owner_SizeChanged;
			base.AssociatedObject.Owner.StateChanged += ResizeBlurbBehaviour.Owner_SizeChanged;
		}

		// Token: 0x060002EB RID: 747 RVA: 0x00016DB4 File Offset: 0x00014FB4
		private static void Owner_SizeChanged(object sender, EventArgs e)
		{
			OnBoardingPopupWindow lastOpenedWindow = ((MainWindow)sender).LastOpenedWindow;
			if (lastOpenedWindow != null && lastOpenedWindow.PlacementTarget != null && lastOpenedWindow.PlacementTarget.IsVisible)
			{
				lastOpenedWindow.SetValue(Window.LeftProperty, lastOpenedWindow.PlacementTarget.PointToScreen(new Point(0.0, 0.0)).X / MainWindow.sScalingFactor - (double)lastOpenedWindow.LeftMargin);
				lastOpenedWindow.SetValue(Window.TopProperty, lastOpenedWindow.PlacementTarget.PointToScreen(new Point(0.0, 0.0)).Y / MainWindow.sScalingFactor + (double)lastOpenedWindow.TopMargin);
			}
		}

		// Token: 0x060002EC RID: 748 RVA: 0x00016E80 File Offset: 0x00015080
		protected override void OnDetaching()
		{
			base.OnDetaching();
			if (base.AssociatedObject != null && base.AssociatedObject.Owner != null)
			{
				base.AssociatedObject.Owner.SizeChanged -= new SizeChangedEventHandler(ResizeBlurbBehaviour.Owner_SizeChanged);
				base.AssociatedObject.Owner.LocationChanged -= ResizeBlurbBehaviour.Owner_SizeChanged;
				base.AssociatedObject.Owner.StateChanged -= ResizeBlurbBehaviour.Owner_SizeChanged;
			}
		}
	}
}
