﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Timers;
using BlueStacks.Common;
using DiscordRPC;
using DiscordRPC.Message;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200010A RID: 266
	public class Discord : IDisposable
	{
		// Token: 0x06000A67 RID: 2663 RVA: 0x0000896B File Offset: 0x00006B6B
		public Discord(MainWindow window)
		{
			this.ParentWindow = window;
		}

		// Token: 0x06000A68 RID: 2664 RVA: 0x0000899B File Offset: 0x00006B9B
		internal void Init()
		{
			this.SetSystemAppsAndClientID();
			this.InitDiscordClient();
		}

		// Token: 0x06000A69 RID: 2665 RVA: 0x000089A9 File Offset: 0x00006BA9
		private void AssignTabChangeEventOnOpenedTabs()
		{
			if (this.ParentWindow != null)
			{
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					foreach (AppTabButton appTabButton in this.ParentWindow.mTopBar.mAppTabButtons.mDictTabs.Values.ToList<AppTabButton>())
					{
						if (appTabButton.EventOnTabChanged == null)
						{
							Logger.Info("discord attaching tab change event on tab.." + appTabButton.PackageName);
							this.AssignTabChangeEvent(appTabButton);
							if (appTabButton.IsSelected)
							{
								this.Tab_ChangeOrCreateEvent(null, new TabChangeEventArgs(appTabButton.AppName, appTabButton.PackageName, appTabButton.mTabType));
							}
						}
						else if (appTabButton.IsSelected)
						{
							this.Tab_ChangeOrCreateEvent(null, new TabChangeEventArgs(appTabButton.AppName, appTabButton.PackageName, appTabButton.mTabType));
						}
					}
				}), new object[0]);
			}
		}

		// Token: 0x06000A6A RID: 2666 RVA: 0x000089D6 File Offset: 0x00006BD6
		private void RemoveTabChangeEventFromOpenedTabs()
		{
			if (this.ParentWindow != null)
			{
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					foreach (AppTabButton appTabButton in this.ParentWindow.mTopBar.mAppTabButtons.mDictTabs.Values.ToList<AppTabButton>())
					{
						if (appTabButton.EventOnTabChanged != null)
						{
							AppTabButton appTabButton2 = appTabButton;
							appTabButton2.EventOnTabChanged = (EventHandler<TabChangeEventArgs>)Delegate.Remove(appTabButton2.EventOnTabChanged, new EventHandler<TabChangeEventArgs>(this.Tab_ChangeOrCreateEvent));
						}
					}
				}), new object[0]);
			}
		}

		// Token: 0x06000A6B RID: 2667 RVA: 0x0003C4C4 File Offset: 0x0003A6C4
		private void SetSystemAppsAndClientID()
		{
			if (PromotionObject.Instance != null)
			{
				this.mDiscordClientID = PromotionObject.Instance.DiscordClientID;
				this.mSystemApps = (from x in PromotionObject.Instance.AppSuggestionList
				where string.Equals(x.AppLocation, "more_apps", StringComparison.InvariantCulture)
				select x).ToList<AppSuggestionPromotion>();
			}
		}

		// Token: 0x06000A6C RID: 2668 RVA: 0x00008A03 File Offset: 0x00006C03
		internal void RemoveAppFromTimestampList(string package)
		{
			if (this.mAppStartTimestamp.ContainsKey(package))
			{
				this.mAppStartTimestamp.Remove(package);
			}
		}

		// Token: 0x06000A6D RID: 2669 RVA: 0x00008A20 File Offset: 0x00006C20
		internal bool IsDiscordClientReady()
		{
			return this.mDiscordClient != null && this.mDiscordClient.IsInitialized && this.mIsDiscordConnected;
		}

		// Token: 0x06000A6E RID: 2670 RVA: 0x0003C524 File Offset: 0x0003A724
		private void Tab_ChangeOrCreateEvent(object sender, TabChangeEventArgs e)
		{
			try
			{
				if (!string.Equals(this.mPreviousAppPackage, e.PackageName, StringComparison.InvariantCulture) && this.IsDiscordClientReady())
				{
					Logger.Info("Discord tab changed event. PkgName: {0}, AppName: {1}", new object[]
					{
						e.PackageName,
						e.AppName
					});
					RichPresence richPresence = new RichPresence();
					TabType tabType = e.TabType;
					if (tabType != TabType.AppTab)
					{
						if (tabType - TabType.WebTab <= 1)
						{
							if (e.PackageName.Contains("bluestacks") && e.PackageName.Contains("appcenter"))
							{
								richPresence.State = "Searching";
								richPresence.Details = "Google Play Store";
								richPresence.Assets = new DiscordRPC.Assets
								{
									LargeImageKey = "bstk-logo",
									LargeImageText = "BlueStacks",
									SmallImageKey = "com_android_vending",
									SmallImageText = "Google Play"
								};
							}
							else
							{
								richPresence.State = "In Lobby";
								richPresence.Details = "About to start a game";
								richPresence.Assets = new DiscordRPC.Assets
								{
									LargeImageKey = "bstk-logo",
									LargeImageText = "BlueStacks",
									SmallImageKey = "",
									SmallImageText = ""
								};
							}
						}
					}
					else if (this.mSystemApps.Any((AppSuggestionPromotion _) => object.Equals(_.AppPackage == e.PackageName, StringComparison.InvariantCulture)))
					{
						richPresence.State = "In Lobby";
						richPresence.Details = "About to start a game";
						richPresence.Assets = new DiscordRPC.Assets
						{
							LargeImageKey = "bstk-logo",
							LargeImageText = "BlueStacks",
							SmallImageKey = "",
							SmallImageText = ""
						};
					}
					else if (e.PackageName.Contains("android.vending"))
					{
						richPresence.State = "Searching";
						richPresence.Details = "Google Play Store";
						richPresence.Assets = new DiscordRPC.Assets
						{
							LargeImageKey = "bstk-logo",
							LargeImageText = "BlueStacks",
							SmallImageKey = "com_android_vending",
							SmallImageText = "Google Play"
						};
					}
					else
					{
						if (this.mAppStartTimestamp.ContainsKey(e.PackageName))
						{
							richPresence.Timestamps = this.mAppStartTimestamp[e.PackageName];
						}
						else
						{
							richPresence.Timestamps = Timestamps.Now;
							this.mAppStartTimestamp.Add(e.PackageName, Timestamps.Now);
						}
						richPresence.State = "Playing";
						richPresence.Details = e.AppName;
						richPresence.Assets = new DiscordRPC.Assets
						{
							LargeImageKey = this.GetMD5HashFromPackageName(e.PackageName),
							LargeImageText = e.AppName,
							SmallImageKey = "bstk-logo",
							SmallImageText = "BlueStacks"
						};
					}
					this.SetPresence(richPresence);
					this.mPreviousAppPackage = e.PackageName;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error while setting presence in discord with exception : {0}", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x06000A6F RID: 2671 RVA: 0x0003C86C File Offset: 0x0003AA6C
		private string GetMD5HashFromPackageName(string package)
		{
			string text = new _MD5
			{
				Value = package
			}.FingerPrint.ToLower(CultureInfo.InvariantCulture);
			Logger.Info("Md5 hash for package name: {0}..is {1}", new object[]
			{
				package,
				text
			});
			return text;
		}

		// Token: 0x06000A70 RID: 2672 RVA: 0x00008A3F File Offset: 0x00006C3F
		internal void AssignTabChangeEvent(AppTabButton button)
		{
			if (button.EventOnTabChanged == null)
			{
				button.EventOnTabChanged = (EventHandler<TabChangeEventArgs>)Delegate.Combine(button.EventOnTabChanged, new EventHandler<TabChangeEventArgs>(this.Tab_ChangeOrCreateEvent));
			}
		}

		// Token: 0x06000A71 RID: 2673 RVA: 0x0003C8B0 File Offset: 0x0003AAB0
		private void InitDiscordClient()
		{
			try
			{
				if (this.mDiscordClient == null)
				{
					Logger.Info("Initing discord");
					this.mDiscordClient = new DiscordRpcClient(this.mDiscordClientID);
					this.mDiscordClient.OnReady += delegate(object sender, ReadyMessage msg)
					{
						Logger.Info("Connected to discord with user {0}", new object[]
						{
							msg.User.Username
						});
					};
					this.mDiscordClient.OnPresenceUpdate += this.Client_OnPresenceUpdate;
					this.mDiscordClient.OnError += this.Client_OnError;
					this.mDiscordClient.OnConnectionFailed += this.Client_OnConnectionFailed;
					this.mDiscordClient.OnConnectionEstablished += this.Client_OnConnectionEstablished;
					this.mDiscordClientInvokeTimer = new Timer(150.0);
					this.mDiscordClientInvokeTimer.Elapsed += delegate(object sender, ElapsedEventArgs evt)
					{
						this.mDiscordClient.Invoke();
					};
					this.mDiscordClientInvokeTimer.Start();
					bool flag = this.mDiscordClient.Initialize();
					Logger.Info("Discord client init: {0}", new object[]
					{
						flag
					});
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Exception in Discord init. ex:  " + ex.ToString());
			}
		}

		// Token: 0x06000A72 RID: 2674 RVA: 0x0003C9FC File Offset: 0x0003ABFC
		private void Client_OnPresenceUpdate(object sender, PresenceMessage args)
		{
			string str = "Discord presence has been updated with details.";
			string str2;
			if (args == null)
			{
				str2 = null;
			}
			else
			{
				RichPresence presence = args.Presence;
				str2 = ((presence != null) ? presence.Details : null);
			}
			Logger.Info(str + str2);
			if (args.Presence.Assets.LargeImageKey == null)
			{
				RichPresence richPresence = args.Presence.Clone();
				richPresence.Assets.LargeImageKey = "bstk-logo";
				richPresence.Assets.SmallImageKey = "";
				richPresence.Assets.SmallImageText = "";
				this.SetPresence(richPresence);
			}
		}

		// Token: 0x06000A73 RID: 2675 RVA: 0x00008A6B File Offset: 0x00006C6B
		private void SetPresence(RichPresence presence)
		{
			if (this.mDiscordClient != null && this.mDiscordClient.IsInitialized)
			{
				this.mDiscordClient.SetPresence(presence);
				return;
			}
			Logger.Warning("SetPresence called without a client being inited");
		}

		// Token: 0x06000A74 RID: 2676 RVA: 0x0003CA88 File Offset: 0x0003AC88
		private void Client_OnConnectionEstablished(object sender, ConnectionEstablishedMessage args)
		{
			Logger.Info("Discord connection Established");
			this.mIsDiscordConnected = true;
			this.AssignTabChangeEventOnOpenedTabs();
			ClientStats.SendMiscellaneousStatsAsync("DiscordConnected", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.RegisteredEmail, Oem.Instance.OEM, null, null, null, null);
		}

		// Token: 0x06000A75 RID: 2677 RVA: 0x0003CAE4 File Offset: 0x0003ACE4
		private void Client_OnConnectionFailed(object sender, ConnectionFailedMessage args)
		{
			Logger.Info("Discord connection failed. ErrorCode: {0}", new object[]
			{
				args.Type
			});
			this.mIsDiscordConnected = false;
			this.Dispose();
			ClientStats.SendMiscellaneousStatsAsync("DiscordNotConnected", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.RegisteredEmail, Oem.Instance.OEM, null, null, null, null);
		}

		// Token: 0x06000A76 RID: 2678 RVA: 0x00008A99 File Offset: 0x00006C99
		private void Client_OnError(object sender, ErrorMessage args)
		{
			Logger.Info("Discord client error. ErrorCode: {0}, Message: {1}", new object[]
			{
				args.Code,
				args.Message
			});
		}

		// Token: 0x06000A77 RID: 2679 RVA: 0x00008AC2 File Offset: 0x00006CC2
		internal void ToggleDiscordState(bool state)
		{
			if (state)
			{
				if (this.mDiscordClient == null)
				{
					this.Init();
					return;
				}
			}
			else
			{
				this.Dispose();
			}
		}

		// Token: 0x06000A78 RID: 2680 RVA: 0x0003CB54 File Offset: 0x0003AD54
		protected virtual void Dispose(bool disposing)
		{
			if (!this.disposedValue)
			{
				if (this.mDiscordClient != null)
				{
					this.mDiscordClient.OnPresenceUpdate -= this.Client_OnPresenceUpdate;
					this.mDiscordClient.OnError -= this.Client_OnError;
					this.mDiscordClient.OnConnectionFailed -= this.Client_OnConnectionFailed;
					this.mDiscordClient.OnConnectionEstablished -= this.Client_OnConnectionEstablished;
					this.mDiscordClient.Dispose();
					this.RemoveTabChangeEventFromOpenedTabs();
				}
				if (this.mDiscordClientInvokeTimer != null)
				{
					this.mDiscordClientInvokeTimer.Elapsed -= delegate(object sender, ElapsedEventArgs evt)
					{
						this.mDiscordClient.Invoke();
					};
					this.mDiscordClientInvokeTimer.Dispose();
				}
				this.disposedValue = true;
			}
		}

		// Token: 0x06000A79 RID: 2681 RVA: 0x0003CC14 File Offset: 0x0003AE14
		~Discord()
		{
			this.Dispose(false);
		}

		// Token: 0x06000A7A RID: 2682 RVA: 0x00008ADC File Offset: 0x00006CDC
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x0400069E RID: 1694
		private DiscordRpcClient mDiscordClient;

		// Token: 0x0400069F RID: 1695
		private Timer mDiscordClientInvokeTimer;

		// Token: 0x040006A0 RID: 1696
		private string mPreviousAppPackage;

		// Token: 0x040006A1 RID: 1697
		private List<AppSuggestionPromotion> mSystemApps = new List<AppSuggestionPromotion>();

		// Token: 0x040006A2 RID: 1698
		private string mDiscordClientID = string.Empty;

		// Token: 0x040006A3 RID: 1699
		private Dictionary<string, Timestamps> mAppStartTimestamp = new Dictionary<string, Timestamps>();

		// Token: 0x040006A4 RID: 1700
		private MainWindow ParentWindow;

		// Token: 0x040006A5 RID: 1701
		private bool mIsDiscordConnected;

		// Token: 0x040006A6 RID: 1702
		private bool disposedValue;
	}
}
