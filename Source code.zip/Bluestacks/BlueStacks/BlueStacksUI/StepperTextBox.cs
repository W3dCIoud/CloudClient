﻿using System;
using System.CodeDom.Compiler;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200004B RID: 75
	public class StepperTextBox : XTextBox, IComponentConnector, IStyleConnector
	{
		// Token: 0x06000375 RID: 885 RVA: 0x00004557 File Offset: 0x00002757
		public StepperTextBox()
		{
			this.InitializeComponent();
			base.ClearValue(StepperTextBox.IMActionItemsProperty);
			InputMethod.SetIsInputMethodEnabled(this, false);
		}

		// Token: 0x1700013C RID: 316
		// (get) Token: 0x06000376 RID: 886 RVA: 0x00004587 File Offset: 0x00002787
		// (set) Token: 0x06000377 RID: 887 RVA: 0x00004599 File Offset: 0x00002799
		public Type PropertyType
		{
			get
			{
				return (Type)base.GetValue(StepperTextBox.PropertyTypeProperty);
			}
			set
			{
				base.SetValue(StepperTextBox.PropertyTypeProperty, value);
			}
		}

		// Token: 0x1700013D RID: 317
		// (get) Token: 0x06000378 RID: 888 RVA: 0x000045A7 File Offset: 0x000027A7
		// (set) Token: 0x06000379 RID: 889 RVA: 0x000045AF File Offset: 0x000027AF
		public double MinValue { get; set; }

		// Token: 0x1700013E RID: 318
		// (get) Token: 0x0600037A RID: 890 RVA: 0x000045B8 File Offset: 0x000027B8
		// (set) Token: 0x0600037B RID: 891 RVA: 0x000045C0 File Offset: 0x000027C0
		public double MaxValue { get; set; }

		// Token: 0x1700013F RID: 319
		// (get) Token: 0x0600037C RID: 892 RVA: 0x000045C9 File Offset: 0x000027C9
		// (set) Token: 0x0600037D RID: 893 RVA: 0x000045DB File Offset: 0x000027DB
		public ObservableCollection<IMActionItem> IMActionItems
		{
			get
			{
				return (ObservableCollection<IMActionItem>)base.GetValue(StepperTextBox.IMActionItemsProperty);
			}
			set
			{
				if (value == null)
				{
					base.ClearValue(StepperTextBox.IMActionItemsProperty);
					return;
				}
				base.SetValue(StepperTextBox.IMActionItemsProperty, value);
			}
		}

		// Token: 0x0600037E RID: 894 RVA: 0x00019658 File Offset: 0x00017858
		protected override void OnPreviewTextInput(TextCompositionEventArgs args)
		{
			if (args != null)
			{
				string text = base.Text.Insert(base.SelectionStart, args.Text);
				if (this.PropertyType == typeof(int))
				{
					int num;
					args.Handled = int.TryParse(text, out num);
				}
				else if (this.PropertyType == typeof(double))
				{
					double num2;
					if (double.TryParse(text, NumberStyles.AllowLeadingWhite | NumberStyles.AllowTrailingWhite | NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands | NumberStyles.AllowExponent, NumberFormatInfo.InvariantInfo, out num2))
					{
						args.Handled = (!this.decimalRegex.IsMatch(text) || this.MinValue > num2 || num2 > this.MaxValue);
					}
					else
					{
						if (string.Equals(text, ".", StringComparison.InvariantCultureIgnoreCase))
						{
							base.Text = "0.";
							KMManager.CheckAndCreateNewScheme();
							if (this.IMActionItems != null && this.IMActionItems.Any<IMActionItem>())
							{
								foreach (IMActionItem valueHandling in this.IMActionItems)
								{
									this.SetValueHandling(valueHandling);
								}
							}
							base.CaretIndex = base.Text.Length;
						}
						args.Handled = true;
					}
				}
			}
			base.OnPreviewTextInput(args);
		}

		// Token: 0x0600037F RID: 895 RVA: 0x000045F8 File Offset: 0x000027F8
		private void OnPreviewExecuted(object sender, ExecutedRoutedEventArgs e)
		{
			e.Handled = (e.Command == ApplicationCommands.Copy || e.Command == ApplicationCommands.Cut || e.Command == ApplicationCommands.Paste);
		}

		// Token: 0x06000380 RID: 896 RVA: 0x00019794 File Offset: 0x00017994
		private void OnIncrease(object sender, RoutedEventArgs e)
		{
			double num;
			int num2;
			if (this.PropertyType == typeof(double) && double.TryParse(base.Text, NumberStyles.AllowLeadingWhite | NumberStyles.AllowTrailingWhite | NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands | NumberStyles.AllowExponent, NumberFormatInfo.InvariantInfo, out num))
			{
				if (this.CanIncrease(num, 0.05))
				{
					num += 0.05;
					base.Text = num.ToString(CultureInfo.InvariantCulture);
					KMManager.CheckAndCreateNewScheme();
				}
			}
			else if (this.PropertyType == typeof(int) && int.TryParse(base.Text, out num2) && this.CanIncrease((double)num2, 1.0))
			{
				num2++;
				base.Text = num2.ToString(CultureInfo.InvariantCulture);
				KMManager.CheckAndCreateNewScheme();
			}
			foreach (IMActionItem valueHandling in this.IMActionItems)
			{
				this.SetValueHandling(valueHandling);
			}
		}

		// Token: 0x06000381 RID: 897 RVA: 0x0000462A File Offset: 0x0000282A
		private bool CanIncrease(double doubleVal, double val)
		{
			return doubleVal + val <= this.MaxValue;
		}

		// Token: 0x06000382 RID: 898 RVA: 0x0000463A File Offset: 0x0000283A
		private bool CanDecrease(double doubleVal, double val)
		{
			return doubleVal - val >= this.MinValue;
		}

		// Token: 0x06000383 RID: 899 RVA: 0x00019894 File Offset: 0x00017A94
		private void OnDecrease(object sender, RoutedEventArgs e)
		{
			double num;
			int num2;
			if (this.PropertyType == typeof(double) && double.TryParse(base.Text, NumberStyles.AllowLeadingWhite | NumberStyles.AllowTrailingWhite | NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands | NumberStyles.AllowExponent, NumberFormatInfo.InvariantInfo, out num) && num > 0.0)
			{
				if (this.CanDecrease(num, 0.05))
				{
					num -= 0.05;
					base.Text = num.ToString(CultureInfo.InvariantCulture);
					KMManager.CheckAndCreateNewScheme();
				}
			}
			else if (this.PropertyType == typeof(int) && int.TryParse(base.Text, out num2) && num2 > 0 && this.CanDecrease((double)num2, 1.0))
			{
				num2--;
				base.Text = num2.ToString(CultureInfo.InvariantCulture);
				KMManager.CheckAndCreateNewScheme();
			}
			foreach (IMActionItem valueHandling in this.IMActionItems)
			{
				this.SetValueHandling(valueHandling);
			}
		}

		// Token: 0x06000384 RID: 900 RVA: 0x0000464A File Offset: 0x0000284A
		protected override void OnPreviewKeyDown(KeyEventArgs args)
		{
			if (args != null)
			{
				if (args.Key == Key.Space)
				{
					args.Handled = true;
				}
				else
				{
					if (args.Key == Key.Escape)
					{
						return;
					}
					base.Focus();
				}
			}
			base.OnPreviewKeyDown(args);
		}

		// Token: 0x06000385 RID: 901 RVA: 0x0000467B File Offset: 0x0000287B
		protected override void OnGotFocus(RoutedEventArgs e)
		{
			base.TextChanged -= this.IMapTextBox_TextChanged;
			base.TextChanged += this.IMapTextBox_TextChanged;
			base.CaretIndex = base.Text.Length;
		}

		// Token: 0x06000386 RID: 902 RVA: 0x000199A4 File Offset: 0x00017BA4
		private void IMapTextBox_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (this.IMActionItems != null && this.IMActionItems.Any<IMActionItem>())
			{
				foreach (IMActionItem valueHandling in this.IMActionItems)
				{
					this.SetValueHandling(valueHandling);
				}
				KMManager.CheckAndCreateNewScheme();
			}
		}

		// Token: 0x06000387 RID: 903 RVA: 0x000046B2 File Offset: 0x000028B2
		protected override void OnLostFocus(RoutedEventArgs e)
		{
			base.TextChanged -= this.IMapTextBox_TextChanged;
			base.OnLostFocus(e);
		}

		// Token: 0x06000388 RID: 904 RVA: 0x00019A0C File Offset: 0x00017C0C
		private void SetValueHandling(IMActionItem item)
		{
			string text = item.IMAction[item.ActionItem].ToString();
			if (this.PropertyType.Equals(typeof(double)))
			{
				double num;
				if (double.TryParse(base.Text, NumberStyles.AllowLeadingWhite | NumberStyles.AllowTrailingWhite | NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint | NumberStyles.AllowThousands | NumberStyles.AllowExponent, NumberFormatInfo.InvariantInfo, out num))
				{
					text = base.Text;
				}
				else if (!string.IsNullOrEmpty(base.Text))
				{
					base.Text = text;
				}
			}
			else if (this.PropertyType.Equals(typeof(decimal)))
			{
				decimal num2;
				if (decimal.TryParse(base.Text, out num2))
				{
					text = base.Text;
				}
				else if (!string.IsNullOrEmpty(base.Text))
				{
					base.Text = text;
				}
			}
			else if (this.PropertyType.Equals(typeof(int)))
			{
				int num3;
				if (int.TryParse(base.Text, out num3))
				{
					text = base.Text;
				}
				else if (!string.IsNullOrEmpty(base.Text))
				{
					base.Text = text;
				}
			}
			this.Setvalue(item, text);
		}

		// Token: 0x06000389 RID: 905 RVA: 0x00019B18 File Offset: 0x00017D18
		internal void Setvalue(IMActionItem item, string value)
		{
			if (!string.Equals(item.IMAction[item.ActionItem].ToString(), value, StringComparison.InvariantCulture))
			{
				item.IMAction[item.ActionItem] = value;
			}
			if (item.ActionItem.StartsWith("Key", StringComparison.InvariantCulture))
			{
				base.Text = base.Text.ToUpper(CultureInfo.InvariantCulture);
			}
			if (item.ActionItem.Contains("Gamepad", StringComparison.InvariantCultureIgnoreCase))
			{
				base.Text = base.Text.ToUpper(CultureInfo.InvariantCulture);
			}
			Logger.Debug("GUIDANCE: " + item.IMAction.Type.ToString());
		}

		// Token: 0x0600038A RID: 906 RVA: 0x000046CD File Offset: 0x000028CD
		private void Path_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Path, Shape.FillProperty, "SettingsWindowTabMenuItemLegendForeground");
		}

		// Token: 0x0600038B RID: 907 RVA: 0x000046E4 File Offset: 0x000028E4
		private void Path_MouseLeave(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Path, Shape.FillProperty, "SettingsWindowForegroundDimColor");
		}

		// Token: 0x0600038C RID: 908 RVA: 0x00019BD0 File Offset: 0x00017DD0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/guidancemodels/steppertextbox.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600038D RID: 909 RVA: 0x000046FB File Offset: 0x000028FB
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				((StepperTextBox)target).AddHandler(CommandManager.PreviewExecutedEvent, new ExecutedRoutedEventHandler(this.OnPreviewExecuted));
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x0600038E RID: 910 RVA: 0x00019C00 File Offset: 0x00017E00
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 2:
				((RepeatButton)target).Click += this.OnIncrease;
				return;
			case 3:
				((Path)target).MouseEnter += this.Path_MouseEnter;
				((Path)target).MouseLeave += this.Path_MouseLeave;
				return;
			case 4:
				((RepeatButton)target).Click += this.OnDecrease;
				return;
			case 5:
				((Path)target).MouseEnter += this.Path_MouseEnter;
				((Path)target).MouseLeave += this.Path_MouseLeave;
				return;
			default:
				return;
			}
		}

		// Token: 0x040001DC RID: 476
		private Regex decimalRegex = new Regex("^[0-9]*(\\.)?[0-9]*$");

		// Token: 0x040001DF RID: 479
		public static readonly DependencyProperty PropertyTypeProperty = DependencyProperty.Register("PropertyType", typeof(Type), typeof(StepperTextBox), new PropertyMetadata());

		// Token: 0x040001E0 RID: 480
		public static readonly DependencyProperty IMActionItemsProperty = DependencyProperty.Register("IMActionItems", typeof(ObservableCollection<IMActionItem>), typeof(StepperTextBox), new PropertyMetadata());

		// Token: 0x040001E1 RID: 481
		private bool _contentLoaded;
	}
}
