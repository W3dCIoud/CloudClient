﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media.Animation;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200022A RID: 554
	public class WidgetIcon : Button, IComponentConnector, IStyleConnector
	{
		// Token: 0x170002A9 RID: 681
		// (get) Token: 0x060013B1 RID: 5041 RVA: 0x0000D799 File Offset: 0x0000B999
		// (set) Token: 0x060013B2 RID: 5042 RVA: 0x00077F2C File Offset: 0x0007612C
		public string ImageName
		{
			get
			{
				return this.mImageName;
			}
			set
			{
				this.mImageName = value;
				if (this.mImage != null)
				{
					this.mImage.ImageName = this.mImageName;
				}
				if (this.mBusyImage != null)
				{
					this.mBusyImage.ImageName = this.mImageName + this.mBusyImageNamePostFix;
				}
			}
		}

		// Token: 0x170002AA RID: 682
		// (get) Token: 0x060013B3 RID: 5043 RVA: 0x0000D7A1 File Offset: 0x0000B9A1
		// (set) Token: 0x060013B4 RID: 5044 RVA: 0x0000D7B3 File Offset: 0x0000B9B3
		public string FooterText
		{
			get
			{
				return base.GetValue(WidgetIcon.MyFooterTextProperty) as string;
			}
			set
			{
				base.SetValue(WidgetIcon.MyFooterTextProperty, value);
			}
		}

		// Token: 0x060013B5 RID: 5045 RVA: 0x0000D7C1 File Offset: 0x0000B9C1
		public WidgetIcon()
		{
			this.InitializeComponent();
		}

		// Token: 0x060013B6 RID: 5046 RVA: 0x0000D7DA File Offset: 0x0000B9DA
		internal void ShowBusyIcon(Visibility visibility)
		{
			this.mBusyImage.Visibility = visibility;
		}

		// Token: 0x060013B7 RID: 5047 RVA: 0x0000D7E8 File Offset: 0x0000B9E8
		private void Image_Initialized(object sender, EventArgs e)
		{
			if (this.mImage == null)
			{
				this.mImage = (sender as CustomPictureBox);
			}
			if (!string.IsNullOrEmpty(this.mImageName))
			{
				this.mImage.ImageName = this.mImageName;
			}
		}

		// Token: 0x060013B8 RID: 5048 RVA: 0x0000D81C File Offset: 0x0000BA1C
		private void BusyImage_Initialized(object sender, EventArgs e)
		{
			if (this.mBusyImage == null)
			{
				this.mBusyImage = (sender as CustomPictureBox);
			}
			if (!string.IsNullOrEmpty(this.mImageName))
			{
				this.mBusyImage.ImageName = this.mImageName + this.mBusyImageNamePostFix;
			}
		}

		// Token: 0x060013B9 RID: 5049 RVA: 0x00077F80 File Offset: 0x00076180
		private void CustomPictureBox_IsVisibleChanged(object _1, DependencyPropertyChangedEventArgs _2)
		{
			if (this.mBusyImage.IsVisible)
			{
				if (this.mBusyIconStoryBoard == null)
				{
					this.mBusyIconStoryBoard = new Storyboard();
					DoubleAnimation doubleAnimation = new DoubleAnimation
					{
						From = new double?(0.0),
						To = new double?((double)360),
						RepeatBehavior = RepeatBehavior.Forever,
						Duration = new Duration(new TimeSpan(0, 0, 1))
					};
					Storyboard.SetTarget(doubleAnimation, this.mBusyImage);
					Storyboard.SetTargetProperty(doubleAnimation, new PropertyPath("(UIElement.RenderTransform).(RotateTransform.Angle)", new object[0]));
					this.mBusyIconStoryBoard.Children.Add(doubleAnimation);
				}
				this.mBusyIconStoryBoard.Begin();
				return;
			}
			this.mBusyIconStoryBoard.Pause();
		}

		// Token: 0x060013BA RID: 5050 RVA: 0x00078048 File Offset: 0x00076248
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/widgeticon.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060013BB RID: 5051 RVA: 0x0000D85B File Offset: 0x0000BA5B
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mWidgetIcon = (WidgetIcon)target;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x060013BC RID: 5052 RVA: 0x00078078 File Offset: 0x00076278
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 2)
			{
				((CustomPictureBox)target).Initialized += this.Image_Initialized;
				return;
			}
			if (connectionId != 3)
			{
				return;
			}
			((CustomPictureBox)target).Initialized += this.BusyImage_Initialized;
			((CustomPictureBox)target).IsVisibleChanged += this.CustomPictureBox_IsVisibleChanged;
		}

		// Token: 0x04000C6A RID: 3178
		private CustomPictureBox mImage;

		// Token: 0x04000C6B RID: 3179
		private CustomPictureBox mBusyImage;

		// Token: 0x04000C6C RID: 3180
		private string mBusyImageNamePostFix = "_busy";

		// Token: 0x04000C6D RID: 3181
		private Storyboard mBusyIconStoryBoard;

		// Token: 0x04000C6E RID: 3182
		private string mImageName;

		// Token: 0x04000C6F RID: 3183
		public static readonly DependencyProperty MyFooterTextProperty = DependencyProperty.Register("FooterText", typeof(string), typeof(WidgetIcon));

		// Token: 0x04000C70 RID: 3184
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal WidgetIcon mWidgetIcon;

		// Token: 0x04000C71 RID: 3185
		private bool _contentLoaded;
	}
}
