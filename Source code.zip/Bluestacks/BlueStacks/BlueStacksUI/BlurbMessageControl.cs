﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Markup;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200003B RID: 59
	public class BlurbMessageControl : UserControl, IComponentConnector
	{
		// Token: 0x0600030A RID: 778 RVA: 0x00004098 File Offset: 0x00002298
		public BlurbMessageControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600030B RID: 779 RVA: 0x00017A90 File Offset: 0x00015C90
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/blurbmessagecontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600030C RID: 780 RVA: 0x00017AC0 File Offset: 0x00015CC0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.FirstMessage = (Run)target;
				return;
			case 2:
				this.KeyMessage = (TextBlock)target;
				return;
			case 3:
				this.SecondMessage = (Run)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040001A9 RID: 425
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Run FirstMessage;

		// Token: 0x040001AA RID: 426
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock KeyMessage;

		// Token: 0x040001AB RID: 427
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Run SecondMessage;

		// Token: 0x040001AC RID: 428
		private bool _contentLoaded;
	}
}
