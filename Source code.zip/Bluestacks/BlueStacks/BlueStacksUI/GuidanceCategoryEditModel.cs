﻿using System;
using System.Collections.ObjectModel;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200003F RID: 63
	[Serializable]
	public class GuidanceCategoryEditModel : ViewModelBase
	{
		// Token: 0x17000126 RID: 294
		// (get) Token: 0x06000321 RID: 801 RVA: 0x0000410E File Offset: 0x0000230E
		// (set) Token: 0x06000322 RID: 802 RVA: 0x00004116 File Offset: 0x00002316
		public ObservableCollection<GuidanceEditModel> GuidanceEditModels
		{
			get
			{
				return this.mGuidanceEditModels;
			}
			set
			{
				base.SetProperty<ObservableCollection<GuidanceEditModel>>(ref this.mGuidanceEditModels, value, null);
			}
		}

		// Token: 0x17000127 RID: 295
		// (get) Token: 0x06000323 RID: 803 RVA: 0x00004127 File Offset: 0x00002327
		// (set) Token: 0x06000324 RID: 804 RVA: 0x0000412F File Offset: 0x0000232F
		public string Category
		{
			get
			{
				return this.mCategory;
			}
			set
			{
				base.SetProperty<string>(ref this.mCategory, value, null);
			}
		}

		// Token: 0x040001B6 RID: 438
		private ObservableCollection<GuidanceEditModel> mGuidanceEditModels = new ObservableCollection<GuidanceEditModel>();

		// Token: 0x040001B7 RID: 439
		private string mCategory;
	}
}
