﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000109 RID: 265
	public class TabChangeEventArgs : EventArgs
	{
		// Token: 0x170001F4 RID: 500
		// (get) Token: 0x06000A60 RID: 2656 RVA: 0x00008905 File Offset: 0x00006B05
		// (set) Token: 0x06000A61 RID: 2657 RVA: 0x0000890D File Offset: 0x00006B0D
		public string AppName { get; set; } = string.Empty;

		// Token: 0x170001F5 RID: 501
		// (get) Token: 0x06000A62 RID: 2658 RVA: 0x00008916 File Offset: 0x00006B16
		// (set) Token: 0x06000A63 RID: 2659 RVA: 0x0000891E File Offset: 0x00006B1E
		public string PackageName { get; set; } = string.Empty;

		// Token: 0x170001F6 RID: 502
		// (get) Token: 0x06000A64 RID: 2660 RVA: 0x00008927 File Offset: 0x00006B27
		// (set) Token: 0x06000A65 RID: 2661 RVA: 0x0000892F File Offset: 0x00006B2F
		public TabType TabType { get; set; }

		// Token: 0x06000A66 RID: 2662 RVA: 0x00008938 File Offset: 0x00006B38
		public TabChangeEventArgs(string appName, string packageName, TabType tabType)
		{
			this.AppName = appName;
			this.PackageName = packageName;
			this.TabType = tabType;
		}
	}
}
