﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000095 RID: 149
	public class ImportMacroScriptsControl : UserControl, IComponentConnector
	{
		// Token: 0x060005CD RID: 1485 RVA: 0x00005CD4 File Offset: 0x00003ED4
		public ImportMacroScriptsControl(ImportMacroWindow importMacroWindow, MainWindow window)
		{
			this.InitializeComponent();
			this.mImportMacroWindow = importMacroWindow;
			this.ParentWindow = window;
			ImportMacroScriptsControl.mIdCount++;
		}

		// Token: 0x060005CE RID: 1486 RVA: 0x00005CFC File Offset: 0x00003EFC
		private void Box_Checked(object sender, RoutedEventArgs e)
		{
			this.mImportMacroWindow.Box_Checked(sender, e);
		}

		// Token: 0x060005CF RID: 1487 RVA: 0x00005D0B File Offset: 0x00003F0B
		private void Box_Unchecked(object sender, RoutedEventArgs e)
		{
			this.mImportMacroWindow.Box_Unchecked(sender, e);
		}

		// Token: 0x060005D0 RID: 1488 RVA: 0x00005D1A File Offset: 0x00003F1A
		private void ImportName_TextChanged(object sender, TextChangedEventArgs e)
		{
			this.mImportMacroWindow.TextChanged(sender, e);
		}

		// Token: 0x060005D1 RID: 1489 RVA: 0x000224C0 File Offset: 0x000206C0
		internal void Init(string macroName, bool isSingleRecording)
		{
			this.mRenameBtn.ApplyTemplate();
			this.mReplaceExistingBtn.ApplyTemplate();
			this.mRenameBtn.RadioBtnImage.Width = 14.0;
			this.mRenameBtn.RadioBtnImage.Height = 14.0;
			this.mRenameBtn.GroupName = string.Format("MacroConflictAction_{0}{1}", macroName, ImportMacroScriptsControl.mIdCount);
			this.mReplaceExistingBtn.RadioBtnImage.Width = 14.0;
			this.mReplaceExistingBtn.RadioBtnImage.Height = 14.0;
			this.mReplaceExistingBtn.GroupName = string.Format("MacroConflictAction_{0}{1}", macroName, ImportMacroScriptsControl.mIdCount);
			this.mReplaceExistingBtn.IsChecked = new bool?(true);
			this.mReplaceExistingBtn.Checked += this.ConflictingMacroHandlingRadioBtn_Checked;
			this.mContent.Content = macroName;
			if (isSingleRecording)
			{
				this.mContent.Visibility = Visibility.Collapsed;
				this.mBlock.Margin = new Thickness(0.0);
				this.mMainGrid.Margin = new Thickness(0.0, 0.0, 0.0, 5.0);
				this.mSingleMacroRecordTextblock.Visibility = Visibility.Visible;
				this.mSingleMacroRecordTextblock.Text = macroName;
				this.mWarningMsg.Margin = new Thickness(0.0, 1.0, 0.0, 1.0);
				return;
			}
			this.mMainGrid.Margin = new Thickness(0.0, 5.0, 0.0, 5.0);
		}

		// Token: 0x060005D2 RID: 1490 RVA: 0x000226A0 File Offset: 0x000208A0
		private void ConflictingMacroHandlingRadioBtn_Checked(object sender, RoutedEventArgs e)
		{
			CustomRadioButton customRadioButton = sender as CustomRadioButton;
			if (customRadioButton != null && this.mImportName != null)
			{
				if (customRadioButton == this.mRenameBtn)
				{
					this.mImportName.Visibility = Visibility.Visible;
					return;
				}
				this.mImportName.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x060005D3 RID: 1491 RVA: 0x000226E4 File Offset: 0x000208E4
		internal bool IsScriptInRenameMode()
		{
			return this.mRenameBtn.IsChecked != null && this.mRenameBtn.IsChecked.Value;
		}

		// Token: 0x060005D4 RID: 1492 RVA: 0x00022720 File Offset: 0x00020920
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/importmacroscriptscontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060005D5 RID: 1493 RVA: 0x00022750 File Offset: 0x00020950
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMainGrid = (Grid)target;
				return;
			case 2:
				this.mContent = (CustomCheckbox)target;
				this.mContent.Checked += this.Box_Checked;
				this.mContent.Unchecked += this.Box_Unchecked;
				return;
			case 3:
				this.mSingleMacroRecordTextblock = (TextBlock)target;
				return;
			case 4:
				this.mBlock = (Grid)target;
				return;
			case 5:
				this.mMacroImportedAsTextBlock = (TextBlock)target;
				return;
			case 6:
				this.mConflictingMacroOptionsPanel = (StackPanel)target;
				return;
			case 7:
				this.mReplaceExistingBtn = (CustomRadioButton)target;
				return;
			case 8:
				this.mRenameBtn = (CustomRadioButton)target;
				this.mRenameBtn.Checked += this.ConflictingMacroHandlingRadioBtn_Checked;
				return;
			case 9:
				this.mImportName = (CustomTextBox)target;
				this.mImportName.TextChanged += this.ImportName_TextChanged;
				return;
			case 10:
				this.mWarningMsg = (TextBlock)target;
				return;
			case 11:
				this.mDependentScriptsMsg = (TextBlock)target;
				return;
			case 12:
				this.mDependentScriptsPanel = (StackPanel)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400032A RID: 810
		internal ImportMacroWindow mImportMacroWindow;

		// Token: 0x0400032B RID: 811
		internal MainWindow ParentWindow;

		// Token: 0x0400032C RID: 812
		private static int mIdCount;

		// Token: 0x0400032D RID: 813
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mMainGrid;

		// Token: 0x0400032E RID: 814
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mContent;

		// Token: 0x0400032F RID: 815
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mSingleMacroRecordTextblock;

		// Token: 0x04000330 RID: 816
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mBlock;

		// Token: 0x04000331 RID: 817
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mMacroImportedAsTextBlock;

		// Token: 0x04000332 RID: 818
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mConflictingMacroOptionsPanel;

		// Token: 0x04000333 RID: 819
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mReplaceExistingBtn;

		// Token: 0x04000334 RID: 820
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mRenameBtn;

		// Token: 0x04000335 RID: 821
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mImportName;

		// Token: 0x04000336 RID: 822
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mWarningMsg;

		// Token: 0x04000337 RID: 823
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mDependentScriptsMsg;

		// Token: 0x04000338 RID: 824
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mDependentScriptsPanel;

		// Token: 0x04000339 RID: 825
		private bool _contentLoaded;
	}
}
