﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows.Data;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000059 RID: 89
	public class GuidanceListToStringConverter : IValueConverter
	{
		// Token: 0x06000413 RID: 1043 RVA: 0x0001B8B0 File Offset: 0x00019AB0
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			IEnumerable<string> enumerable = value as IEnumerable<string>;
			if (enumerable != null)
			{
				List<string> list = new List<string>();
				foreach (string text in enumerable)
				{
					list.Add(KMManager.GetKeyUIValue(text));
				}
				return string.Join(" / ", list.ToArray());
			}
			return string.Empty;
		}

		// Token: 0x06000414 RID: 1044 RVA: 0x00004D06 File Offset: 0x00002F06
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return Binding.DoNothing;
		}
	}
}
