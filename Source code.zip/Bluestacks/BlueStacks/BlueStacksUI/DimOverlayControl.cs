﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000090 RID: 144
	public class DimOverlayControl : CustomWindow, IComponentConnector
	{
		// Token: 0x170001AF RID: 431
		// (get) Token: 0x0600059D RID: 1437 RVA: 0x00005B5D File Offset: 0x00003D5D
		// (set) Token: 0x0600059E RID: 1438 RVA: 0x00021488 File Offset: 0x0001F688
		public new MainWindow Owner
		{
			get
			{
				return (MainWindow)base.Owner;
			}
			set
			{
				if (value != null)
				{
					if (value != base.Owner)
					{
						value.LocationChanged += this.ParentWindow_LocationChanged;
						value.SizeChanged += this.ParentWindow_SizeChanged;
					}
				}
				else if (base.Owner != null)
				{
					base.Owner.LocationChanged -= this.ParentWindow_LocationChanged;
					base.Owner.SizeChanged -= this.ParentWindow_SizeChanged;
				}
				base.Owner = value;
			}
		}

		// Token: 0x170001B0 RID: 432
		// (get) Token: 0x0600059F RID: 1439 RVA: 0x00005B6A File Offset: 0x00003D6A
		// (set) Token: 0x060005A0 RID: 1440 RVA: 0x00005B72 File Offset: 0x00003D72
		internal IDimOverlayControl Control
		{
			get
			{
				return this.mControl;
			}
			set
			{
				if (value != null)
				{
					this.AddControl(value);
				}
				this.mControl = value;
			}
		}

		// Token: 0x170001B1 RID: 433
		// (get) Token: 0x060005A1 RID: 1441 RVA: 0x00005B85 File Offset: 0x00003D85
		// (set) Token: 0x060005A2 RID: 1442 RVA: 0x00005B8D File Offset: 0x00003D8D
		public bool IsWindowVisible { get; set; }

		// Token: 0x060005A3 RID: 1443 RVA: 0x00005B96 File Offset: 0x00003D96
		private void ParentWindow_LocationChanged(object sender, EventArgs e)
		{
			this.UpadteSizeLocation();
		}

		// Token: 0x060005A4 RID: 1444 RVA: 0x00005B96 File Offset: 0x00003D96
		private void ParentWindow_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			this.UpadteSizeLocation();
		}

		// Token: 0x060005A5 RID: 1445 RVA: 0x00005B9E File Offset: 0x00003D9E
		public DimOverlayControl(MainWindow owner)
		{
			this.Owner = owner;
			this.InitializeComponent();
			base.IsShowGLWindow = true;
		}

		// Token: 0x060005A6 RID: 1446 RVA: 0x00021504 File Offset: 0x0001F704
		internal void AddControl(IDimOverlayControl el)
		{
			if (!el.ShowControlInSeparateWindow)
			{
				if (!this.mGrid.Children.Contains(el as UIElement))
				{
					this.mGrid.Children.Add(el as UIElement);
					return;
				}
				(el as UIElement).Visibility = Visibility.Visible;
			}
		}

		// Token: 0x060005A7 RID: 1447 RVA: 0x00021558 File Offset: 0x0001F758
		internal void RemoveControl()
		{
			if (!this.Control.ShowControlInSeparateWindow)
			{
				if (this.mGrid.Children.Contains(this.Control as UIElement))
				{
					this.mGrid.Children.Remove(this.Control as UIElement);
					this.Control.Close();
					return;
				}
			}
			else
			{
				if (this.Control != null)
				{
					BlueStacksUIUtils.RemoveChildFromParent((UIElement)this.Control);
					this.Control.Close();
				}
				if (this.cw != null)
				{
					this.cw.Close();
				}
			}
		}

		// Token: 0x060005A8 RID: 1448 RVA: 0x000215F0 File Offset: 0x0001F7F0
		internal void UpadteSizeLocation()
		{
			if (this.Owner != null && PresentationSource.FromVisual(this.Owner) != null)
			{
				Point point = this.Owner.PointToScreen(new Point(0.0, 0.0));
				Point point2 = PresentationSource.FromVisual(this.Owner).CompositionTarget.TransformFromDevice.Transform(point);
				base.Left = point2.X;
				base.Top = point2.Y;
				base.Width = this.Owner.ActualWidth;
				base.Height = this.Owner.ActualHeight;
			}
		}

		// Token: 0x060005A9 RID: 1449 RVA: 0x00021694 File Offset: 0x0001F894
		internal void ShowWindow()
		{
			if (!this.IsWindowVisible)
			{
				this.IsWindowVisible = true;
				base.Show();
				if (this.Control != null)
				{
					if (!this.Control.ShowControlInSeparateWindow)
					{
						this.Control.Show();
						return;
					}
					this.Control.Show();
					this.cw = new ContainerWindow(this.Owner, (UserControl)this.Control, this.Control.Width, this.Control.Height, false, false);
					this.cw.Show();
				}
			}
		}

		// Token: 0x060005AA RID: 1450 RVA: 0x00021724 File Offset: 0x0001F924
		internal void HideWindow(bool isFromOverlayClick)
		{
			if (this.IsWindowVisible)
			{
				if (this.Control != null)
				{
					if (!isFromOverlayClick)
					{
						this.IsWindowVisible = false;
						this.RemoveControl();
						this.Hide();
						return;
					}
					if (this.Control.IsCloseOnOverLayClick)
					{
						this.IsWindowVisible = false;
						this.RemoveControl();
						this.Hide();
						return;
					}
					if (this.cw != null)
					{
						this.cw.Focus();
						return;
					}
				}
				else
				{
					this.IsWindowVisible = false;
					this.Hide();
				}
			}
		}

		// Token: 0x060005AB RID: 1451 RVA: 0x00005BBA File Offset: 0x00003DBA
		private void mGrid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			this.HideWindow(true);
		}

		// Token: 0x060005AC RID: 1452 RVA: 0x00005BC3 File Offset: 0x00003DC3
		public new void Hide()
		{
			if (!this.IsWindowVisible)
			{
				base.Dispatcher.Invoke(new Action(delegate()
				{
					base.Hide();
				}), new object[0]);
			}
		}

		// Token: 0x060005AD RID: 1453 RVA: 0x0002179C File Offset: 0x0001F99C
		private void DimWindow_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.System && e.SystemKey == Key.F4 && this.Control != null && FeatureManager.Instance.IsCustomUIForNCSoft && this.Control.GetType() == BlueStacksUIUtils.DictWindows[Strings.CurrentDefaultVmName].ScreenLockInstance.GetType() && BlueStacksUIUtils.DictWindows[Strings.CurrentDefaultVmName].ScreenLockInstance.IsVisible)
			{
				e.Handled = true;
			}
		}

		// Token: 0x060005AE RID: 1454 RVA: 0x0002181C File Offset: 0x0001FA1C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/dimoverlaycontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060005AF RID: 1455 RVA: 0x0002184C File Offset: 0x0001FA4C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((DimOverlayControl)target).KeyDown += this.DimWindow_KeyDown;
				return;
			case 2:
				this.mGrid = (Grid)target;
				return;
			case 3:
				((Grid)target).MouseDown += this.mGrid_MouseLeftButtonDown;
				((Grid)target).MouseLeftButtonDown += this.mGrid_MouseLeftButtonDown;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400030C RID: 780
		private IDimOverlayControl mControl;

		// Token: 0x0400030E RID: 782
		private ContainerWindow cw;

		// Token: 0x0400030F RID: 783
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mGrid;

		// Token: 0x04000310 RID: 784
		private bool _contentLoaded;
	}
}
