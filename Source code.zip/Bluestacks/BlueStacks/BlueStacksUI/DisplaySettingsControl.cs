﻿using System;
using System.Windows;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000FD RID: 253
	public class DisplaySettingsControl : DisplaySettingsBase
	{
		// Token: 0x170001E8 RID: 488
		// (get) Token: 0x060009E9 RID: 2537 RVA: 0x000083E5 File Offset: 0x000065E5
		// (set) Token: 0x060009EA RID: 2538 RVA: 0x000083ED File Offset: 0x000065ED
		public MainWindow ParentWindow { get; private set; }

		// Token: 0x060009EB RID: 2539 RVA: 0x000083F6 File Offset: 0x000065F6
		public DisplaySettingsControl(MainWindow window) : base(window, (window != null) ? window.mVmName : null)
		{
			this.ParentWindow = window;
		}

		// Token: 0x060009EC RID: 2540 RVA: 0x00039DE8 File Offset: 0x00037FE8
		protected override void Save(object param)
		{
			if (base.IsDirty())
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.Owner = this.ParentWindow;
				customMessageWindow.WindowStartupLocation = WindowStartupLocation.CenterOwner;
				customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_RESTART_BLUESTACKS");
				customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_RESTART_BLUESTACKS_MESSAGE");
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_RESTART_NOW", delegate(object o, EventArgs e)
				{
					base.SaveDisplaySetting();
					if (BlueStacksUIUtils.DictWindows.Count == 1)
					{
						App.defaultResolution = new Fraction((long)RegistryManager.Instance.Guest[Strings.CurrentDefaultVmName].GuestWidth, (long)RegistryManager.Instance.Guest[Strings.CurrentDefaultVmName].GuestHeight);
						PromotionManager.ReloadPromotionsAsync();
					}
					BlueStacksUIUtils.CloseContainerWindow(this);
					BlueStacksUIUtils.RestartInstance(base.VmName);
				}, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, "STRING_DISCARD_CHANGES", delegate(object o, EventArgs e)
				{
					base.DiscardCurrentChangingModel();
				}, null, false, null);
				customMessageWindow.ShowDialog();
			}
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				BlueStacksUIUtils.CloseContainerWindow(this);
				this.ParentWindow.Close();
			}
		}
	}
}
