﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x02000298 RID: 664
	public class StreamManager : IDisposable
	{
		// Token: 0x170002FF RID: 767
		// (get) Token: 0x060017B9 RID: 6073 RVA: 0x000103F0 File Offset: 0x0000E5F0
		// (set) Token: 0x060017BA RID: 6074 RVA: 0x000103F7 File Offset: 0x0000E5F7
		public static string ObsServerBaseURL { get; set; } = "http://localhost";

		// Token: 0x17000300 RID: 768
		// (get) Token: 0x060017BB RID: 6075 RVA: 0x000103FF File Offset: 0x0000E5FF
		// (set) Token: 0x060017BC RID: 6076 RVA: 0x00010406 File Offset: 0x0000E606
		public static int ObsServerPort { get; set; } = 2851;

		// Token: 0x17000301 RID: 769
		// (get) Token: 0x060017BD RID: 6077 RVA: 0x0001040E File Offset: 0x0000E60E
		// (set) Token: 0x060017BE RID: 6078 RVA: 0x00010415 File Offset: 0x0000E615
		public static string DEFAULT_NETWORK { get; set; } = "twitch";

		// Token: 0x17000302 RID: 770
		// (get) Token: 0x060017BF RID: 6079 RVA: 0x0001041D File Offset: 0x0000E61D
		// (set) Token: 0x060017C0 RID: 6080 RVA: 0x00010424 File Offset: 0x0000E624
		public static bool DEFAULT_ENABLE_FILTER { get; set; } = true;

		// Token: 0x17000303 RID: 771
		// (get) Token: 0x060017C1 RID: 6081 RVA: 0x0001042C File Offset: 0x0000E62C
		// (set) Token: 0x060017C2 RID: 6082 RVA: 0x00010433 File Offset: 0x0000E633
		public static bool DEFAULT_SQUARE_THEME { get; set; } = false;

		// Token: 0x17000304 RID: 772
		// (get) Token: 0x060017C3 RID: 6083 RVA: 0x0001043B File Offset: 0x0000E63B
		// (set) Token: 0x060017C4 RID: 6084 RVA: 0x00010442 File Offset: 0x0000E642
		public static string DEFAULT_LAYOUT_THEME { get; set; } = null;

		// Token: 0x17000305 RID: 773
		// (get) Token: 0x060017C5 RID: 6085 RVA: 0x0001044A File Offset: 0x0000E64A
		// (set) Token: 0x060017C6 RID: 6086 RVA: 0x00010451 File Offset: 0x0000E651
		public static bool sStopInitOBSQueue { get; set; } = false;

		// Token: 0x17000306 RID: 774
		// (get) Token: 0x060017C7 RID: 6087 RVA: 0x00010459 File Offset: 0x0000E659
		// (set) Token: 0x060017C8 RID: 6088 RVA: 0x00010461 File Offset: 0x0000E661
		public string mCallbackStreamStatus { get; set; }

		// Token: 0x17000307 RID: 775
		// (get) Token: 0x060017C9 RID: 6089 RVA: 0x0001046A File Offset: 0x0000E66A
		// (set) Token: 0x060017CA RID: 6090 RVA: 0x00010472 File Offset: 0x0000E672
		public string mCallbackAppInfo { get; set; }

		// Token: 0x17000308 RID: 776
		// (get) Token: 0x060017CB RID: 6091 RVA: 0x0001047B File Offset: 0x0000E67B
		// (set) Token: 0x060017CC RID: 6092 RVA: 0x00010483 File Offset: 0x0000E683
		public bool mIsObsRunning { get; set; }

		// Token: 0x17000309 RID: 777
		// (get) Token: 0x060017CD RID: 6093 RVA: 0x0001048C File Offset: 0x0000E68C
		// (set) Token: 0x060017CE RID: 6094 RVA: 0x00010494 File Offset: 0x0000E694
		public bool mIsInitCalled { get; set; }

		// Token: 0x1700030A RID: 778
		// (get) Token: 0x060017CF RID: 6095 RVA: 0x0001049D File Offset: 0x0000E69D
		// (set) Token: 0x060017D0 RID: 6096 RVA: 0x000104A5 File Offset: 0x0000E6A5
		public bool mIsStreaming { get; set; }

		// Token: 0x1700030B RID: 779
		// (get) Token: 0x060017D1 RID: 6097 RVA: 0x000104AE File Offset: 0x0000E6AE
		// (set) Token: 0x060017D2 RID: 6098 RVA: 0x000104B6 File Offset: 0x0000E6B6
		public bool mStoppingOBS { get; set; }

		// Token: 0x1700030C RID: 780
		// (get) Token: 0x060017D3 RID: 6099 RVA: 0x000104BF File Offset: 0x0000E6BF
		// (set) Token: 0x060017D4 RID: 6100 RVA: 0x000104C7 File Offset: 0x0000E6C7
		public bool mIsReconnecting { get; set; }

		// Token: 0x1700030D RID: 781
		// (get) Token: 0x060017D5 RID: 6101 RVA: 0x000104D0 File Offset: 0x0000E6D0
		// (set) Token: 0x060017D6 RID: 6102 RVA: 0x000104D8 File Offset: 0x0000E6D8
		public string mNetwork { get; set; } = StreamManager.DEFAULT_NETWORK;

		// Token: 0x1700030E RID: 782
		// (get) Token: 0x060017D7 RID: 6103 RVA: 0x000104E1 File Offset: 0x0000E6E1
		// (set) Token: 0x060017D8 RID: 6104 RVA: 0x000104E9 File Offset: 0x0000E6E9
		public bool mSquareTheme { get; set; } = StreamManager.DEFAULT_SQUARE_THEME;

		// Token: 0x1700030F RID: 783
		// (get) Token: 0x060017D9 RID: 6105 RVA: 0x000104F2 File Offset: 0x0000E6F2
		// (set) Token: 0x060017DA RID: 6106 RVA: 0x000104FA File Offset: 0x0000E6FA
		public string mLayoutTheme { get; set; } = StreamManager.DEFAULT_LAYOUT_THEME;

		// Token: 0x17000310 RID: 784
		// (get) Token: 0x060017DB RID: 6107 RVA: 0x00010503 File Offset: 0x0000E703
		// (set) Token: 0x060017DC RID: 6108 RVA: 0x0001050B File Offset: 0x0000E70B
		public string mLastCameraLayoutTheme { get; set; } = StreamManager.DEFAULT_LAYOUT_THEME;

		// Token: 0x17000311 RID: 785
		// (get) Token: 0x060017DD RID: 6109 RVA: 0x00010514 File Offset: 0x0000E714
		// (set) Token: 0x060017DE RID: 6110 RVA: 0x0001051C File Offset: 0x0000E71C
		public bool mAppViewLayout { get; set; }

		// Token: 0x17000312 RID: 786
		// (get) Token: 0x060017DF RID: 6111 RVA: 0x00010525 File Offset: 0x0000E725
		// (set) Token: 0x060017E0 RID: 6112 RVA: 0x0001052D File Offset: 0x0000E72D
		public bool mEnableFilter { get; set; } = StreamManager.DEFAULT_ENABLE_FILTER;

		// Token: 0x17000313 RID: 787
		// (get) Token: 0x060017E1 RID: 6113 RVA: 0x00010536 File Offset: 0x0000E736
		// (set) Token: 0x060017E2 RID: 6114 RVA: 0x0001053D File Offset: 0x0000E73D
		public static string CamStatus { get; set; }

		// Token: 0x17000314 RID: 788
		// (get) Token: 0x060017E3 RID: 6115 RVA: 0x00010545 File Offset: 0x0000E745
		// (set) Token: 0x060017E4 RID: 6116 RVA: 0x0001054D File Offset: 0x0000E74D
		public bool mReplayBufferEnabled { get; set; }

		// Token: 0x17000315 RID: 789
		// (get) Token: 0x060017E5 RID: 6117 RVA: 0x00010556 File Offset: 0x0000E756
		// (set) Token: 0x060017E6 RID: 6118 RVA: 0x0001055E File Offset: 0x0000E75E
		public bool mCLRBrowserRunning { get; set; }

		// Token: 0x17000316 RID: 790
		// (get) Token: 0x060017E7 RID: 6119 RVA: 0x00010567 File Offset: 0x0000E767
		// (set) Token: 0x060017E8 RID: 6120 RVA: 0x0001056F File Offset: 0x0000E76F
		public string mCurrentFilterAppPkg { get; set; }

		// Token: 0x17000317 RID: 791
		// (get) Token: 0x060017E9 RID: 6121 RVA: 0x00010578 File Offset: 0x0000E778
		// (set) Token: 0x060017EA RID: 6122 RVA: 0x0001057F File Offset: 0x0000E77F
		public static StreamManager Instance { get; set; } = null;

		// Token: 0x14000038 RID: 56
		// (add) Token: 0x060017EB RID: 6123 RVA: 0x0008D65C File Offset: 0x0008B85C
		// (remove) Token: 0x060017EC RID: 6124 RVA: 0x0008D694 File Offset: 0x0008B894
		public event EventHandler<CustomVolumeEventArgs> EventGetSystemVolume;

		// Token: 0x14000039 RID: 57
		// (add) Token: 0x060017ED RID: 6125 RVA: 0x0008D6CC File Offset: 0x0008B8CC
		// (remove) Token: 0x060017EE RID: 6126 RVA: 0x0008D704 File Offset: 0x0008B904
		public event EventHandler<CustomVolumeEventArgs> EventGetMicVolume;

		// Token: 0x1400003A RID: 58
		// (add) Token: 0x060017EF RID: 6127 RVA: 0x0008D73C File Offset: 0x0008B93C
		// (remove) Token: 0x060017F0 RID: 6128 RVA: 0x0008D774 File Offset: 0x0008B974
		public event EventHandler<CustomVolumeEventArgs> EventGetCameraDetails;

		// Token: 0x1400003B RID: 59
		// (add) Token: 0x060017F1 RID: 6129 RVA: 0x0008D7AC File Offset: 0x0008B9AC
		// (remove) Token: 0x060017F2 RID: 6130 RVA: 0x0008D7E4 File Offset: 0x0008B9E4
		public event EventHandler<CustomVolumeEventArgs> EventGetMicDetails;

		// Token: 0x17000318 RID: 792
		// (get) Token: 0x060017F3 RID: 6131 RVA: 0x00010587 File Offset: 0x0000E787
		// (set) Token: 0x060017F4 RID: 6132 RVA: 0x0001058F File Offset: 0x0000E78F
		public bool isWindowCaptureActive { get; set; }

		// Token: 0x060017F5 RID: 6133 RVA: 0x0008D81C File Offset: 0x0008BA1C
		public StreamManager(Browser browser)
		{
			StreamManager.Instance = this;
			this.mBrowser = browser;
			this.mReplayBufferEnabled = (RegistryManager.Instance.ReplayBufferEnabled == 1);
			if (RegistryManager.Instance.CamStatus == 1)
			{
				StreamManager.CamStatus = "true";
			}
			else
			{
				StreamManager.CamStatus = "false";
			}
			StreamManager.mSelectedCamera = RegistryManager.Instance.SelectedCam;
			this.mObsCommandEventHandle = new EventWaitHandle(false, EventResetMode.AutoReset);
			MainWindow mainWindow = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				mainWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			this.mWindow = mainWindow;
			this.CopySceneConfigFile(this.mWindow, false);
		}

		// Token: 0x060017F6 RID: 6134 RVA: 0x0008D968 File Offset: 0x0008BB68
		public StreamManager(MainWindow window)
		{
			StreamManager.Instance = this;
			this.mReplayBufferEnabled = true;
			if (RegistryManager.Instance.CamStatus == 1)
			{
				StreamManager.CamStatus = "true";
			}
			else
			{
				StreamManager.CamStatus = "false";
			}
			StreamManager.mSelectedCamera = RegistryManager.Instance.SelectedCam;
			this.mObsCommandEventHandle = new EventWaitHandle(false, EventResetMode.AutoReset);
			this.mWindow = window;
			this.CopySceneConfigFile(this.mWindow, !RegistryManager.Instance.IsGameCaptureSupportedInMachine);
		}

		// Token: 0x060017F7 RID: 6135 RVA: 0x0008DA8C File Offset: 0x0008BC8C
		public void CopySceneConfigFile(MainWindow activatedWindow, bool forceWindowCaptureMode = false)
		{
			Logger.Debug("In Scene config file copy method with glmode: {0}", new object[]
			{
				(activatedWindow != null) ? new int?(activatedWindow.EngineInstanceRegistry.GlRenderMode) : null
			});
			string path = Path.Combine(RegistryStrings.ObsDir, "sceneCollection");
			try
			{
				if (!Directory.Exists(path))
				{
					Directory.CreateDirectory(path);
				}
				if (activatedWindow.EngineInstanceRegistry.GlRenderMode != 1 || forceWindowCaptureMode)
				{
					string sourceFileName = Path.Combine(RegistryStrings.ObsDir, "SceneConfigFiles\\scenes_window.xconfig");
					string destFileName = Path.Combine(RegistryStrings.ObsDir, "scenes.xconfig");
					string destFileName2 = Path.Combine(RegistryStrings.ObsDir, "sceneCollection\\scenes.xconfig");
					File.Copy(sourceFileName, destFileName, true);
					File.Copy(sourceFileName, destFileName2, true);
					this.isWindowCaptureActive = true;
				}
				else
				{
					string sourceFileName2 = Path.Combine(RegistryStrings.ObsDir, "SceneConfigFiles\\scenes_graphics.xconfig");
					string destFileName3 = Path.Combine(RegistryStrings.ObsDir, "scenes.xconfig");
					string destFileName4 = Path.Combine(RegistryStrings.ObsDir, "sceneCollection\\scenes.xconfig");
					File.Copy(sourceFileName2, destFileName3, true);
					File.Copy(sourceFileName2, destFileName4, true);
					this.isWindowCaptureActive = false;
				}
				Logger.Debug("Is window capture active..: {0}", new object[]
				{
					this.isWindowCaptureActive
				});
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in obs scene config file : {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x060017F8 RID: 6136 RVA: 0x0008DBDC File Offset: 0x0008BDDC
		internal void OrientationChangeHandler()
		{
			try
			{
				if (this.isWindowCaptureActive)
				{
					this.SetCaptureSize();
				}
				this.RefreshCapture();
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in OrientationChangeHandler : " + ex.ToString());
			}
		}

		// Token: 0x060017F9 RID: 6137 RVA: 0x00010598 File Offset: 0x0000E798
		private void RefreshCapture()
		{
			this.SendObsRequest("refreshCapture", null, null, null, 0, false);
		}

		// Token: 0x060017FA RID: 6138 RVA: 0x0008DC28 File Offset: 0x0008BE28
		public void SendCurrentAppInfoAtTabChange()
		{
			try
			{
				if (this.mBrowser != null)
				{
					if (!string.IsNullOrEmpty(this.mBrowser.getURL()))
					{
						AppTabButton selectedTab = this.mWindow.mTopBar.mAppTabButtons.SelectedTab;
						if (selectedTab != null)
						{
							selectedTab.mTabType.ToString();
							string appName = selectedTab.AppName;
							string packageName = selectedTab.PackageName;
							string text = new JObject
							{
								{
									"type",
									"app"
								},
								{
									"name",
									appName
								},
								{
									"data",
									packageName
								}
							}.ToString(Formatting.None, new JsonConverter[0]);
							string code = "getCurrentAppInfo('" + text.Replace("'", "&#39;").Replace("%27", "&#39;") + "')";
							this.mBrowser.ExecuteJavaScript(code, this.mBrowser.getURL(), 0);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in send current app status on tab changed " + ex.ToString());
			}
		}

		// Token: 0x060017FB RID: 6139 RVA: 0x000105AA File Offset: 0x0000E7AA
		public void StartObs()
		{
			if (!this.mIsInitCalled)
			{
				this.InitObs();
			}
		}

		// Token: 0x060017FC RID: 6140 RVA: 0x0008DD58 File Offset: 0x0008BF58
		private void InitObs()
		{
			this.mIsInitCalled = true;
			Utils.KillCurrentOemProcessByName("HD-OBS", null);
			if (!ProcessUtils.FindProcessByName("HD-OBS") && !StreamManager.sStopInitOBSQueue)
			{
				StreamManager.StartOBS();
			}
			if (StreamManager.sStopInitOBSQueue)
			{
				return;
			}
			try
			{
				string text = this.SendObsRequestInternal("ping", null);
				Logger.Info("response for ping is {0}", new object[]
				{
					text
				});
				this.mIsObsRunning = true;
			}
			catch (Exception ex)
			{
				if (StreamManager.sStopInitOBSQueue || StreamManager.Instance == null)
				{
					return;
				}
				Logger.Error("Exception in InitObs. err: " + ex.ToString());
				Thread.Sleep(100);
				if (this.mObsRetryCount <= 0)
				{
					this.ShutDownForcefully();
					throw new Exception("Could not start OBS.");
				}
				this.mObsRetryCount--;
				this.InitObs();
			}
			this.mObsRetryCount = 2;
			new Thread(delegate()
			{
				this.ProcessObsCommandQueue();
			})
			{
				IsBackground = true
			}.Start();
			if (this.mReplayBufferEnabled)
			{
				this.SetReplayBufferSavePath();
			}
			this.GetParametersFromOBS();
			this.EnableSource("BlueStacks");
		}

		// Token: 0x060017FD RID: 6141 RVA: 0x0008DE78 File Offset: 0x0008C078
		private void SetBackGroundImagePath()
		{
			this.EnableSource("BackGroundImage");
			string value = Path.Combine(RegistryStrings.ObsDir, "backgrounds\\Background3.jpg");
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"path",
					value
				}
			};
			this.SendObsRequest("setBackground", data, null, null, 0);
		}

		// Token: 0x060017FE RID: 6142 RVA: 0x0008DEC4 File Offset: 0x0008C0C4
		public void SetSceneConfiguration(string layoutTheme)
		{
			this.mAppViewLayout = false;
			this.mLayoutTheme = layoutTheme;
			if (layoutTheme == null)
			{
				this.SendObsRequest("resettooriginalscene", null, null, null, 0, false);
				return;
			}
			this.SetCaptureSize();
			this.DisableSource("CLR Browser");
			try
			{
				JObject jobject = JObject.Parse(layoutTheme);
				Logger.Info(layoutTheme);
				bool flag = StreamManager.IsPortraitApp();
				if (jobject["isPortrait"] != null)
				{
					flag = jobject["isPortrait"].ToObject<bool>();
				}
				JObject jobject2;
				if (flag)
				{
					jobject2 = JObject.Parse(jobject["portrait"].ToString());
				}
				else
				{
					jobject2 = JObject.Parse(jobject["landscape"].ToString());
				}
				if (jobject2["BlueStacksWebcam"] != null)
				{
					bool flag2;
					if (bool.TryParse(jobject2["BlueStacksWebcam"]["enableWebCam"].ToString(), out flag2) && flag2)
					{
						this.SetCameraPosition(Convert.ToInt32(jobject2["BlueStacksWebcam"]["x"].ToString(), CultureInfo.InvariantCulture), Convert.ToInt32(jobject2["BlueStacksWebcam"]["y"].ToString(), CultureInfo.InvariantCulture), Convert.ToInt32(jobject2["BlueStacksWebcam"]["width"].ToString(), CultureInfo.InvariantCulture), Convert.ToInt32(jobject2["BlueStacksWebcam"]["height"].ToString(), CultureInfo.InvariantCulture), flag2 ? 1 : 0);
					}
					else
					{
						this.DisableWebcamAndClearDictionary();
					}
				}
				if (jobject2["BlueStacks"] != null)
				{
					string value = jobject2["BlueStacks"]["width"].ToString();
					string text = jobject2["BlueStacks"]["height"].ToString();
					string value2 = jobject2["BlueStacks"]["x"].ToString();
					string value3 = jobject2["BlueStacks"]["y"].ToString();
					if (!this.isWindowCaptureActive)
					{
						value = text;
						if (jobject["name"] != null)
						{
							string a = jobject["name"].ToString();
							if (string.Equals(a, "layout_2", StringComparison.InvariantCulture) || string.Equals(a, "layout_3", StringComparison.InvariantCulture))
							{
								value2 = "22";
								if (flag && string.Equals(a, "layout_3", StringComparison.InvariantCulture))
								{
									value2 = "0";
								}
							}
							else if (string.Equals(a, "layout_1", StringComparison.InvariantCulture))
							{
								value2 = "47";
							}
						}
					}
					this.SetFrontendPosition(0, 0, Convert.ToInt32(value, CultureInfo.InvariantCulture), Convert.ToInt32(text, CultureInfo.InvariantCulture));
					this.SetPosition(Convert.ToInt32(value2, CultureInfo.InvariantCulture), Convert.ToInt32(value3, CultureInfo.InvariantCulture));
					this.EnableSource("BlueStacks");
				}
				else
				{
					this.DisableSource("BlueStacks");
				}
				string text2 = jobject["order"].ToString();
				string value4 = jobject["logo"].ToString();
				text2 += ",BackGroundImage";
				string value5 = "watermarkFB,watermark,watermarkGif";
				if (jobject["allLogo"] != null)
				{
					value5 = jobject["allLogo"].ToString();
				}
				Dictionary<string, string> data = new Dictionary<string, string>
				{
					{
						"order",
						text2
					},
					{
						"logo",
						value4
					},
					{
						"allLogo",
						value5
					}
				};
				this.SendObsRequest("setorderandlogo", data, null, null, 0, false);
			}
			catch (Exception ex)
			{
				Logger.Error("SetSceneConfiguration: Error {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x060017FF RID: 6143 RVA: 0x0008E26C File Offset: 0x0008C46C
		public static bool IsPortraitApp()
		{
			int frontendWidth = RegistryManager.Instance.FrontendWidth;
			int frontendHeight = RegistryManager.Instance.FrontendHeight;
			return frontendWidth <= frontendHeight;
		}

		// Token: 0x06001800 RID: 6144 RVA: 0x0008E294 File Offset: 0x0008C494
		private static void StartOBS()
		{
			Logger.Info("starting obs");
			string obsBinaryPath = RegistryStrings.ObsBinaryPath;
			string text = "-port " + RegistryManager.Instance.PartnerServerPort.ToString();
			if (SystemUtils.IsOs64Bit())
			{
				text += " -64bit";
			}
			if (!string.IsNullOrEmpty(Strings.OEMTag))
			{
				text = text + " -oem " + Strings.OEMTag;
			}
			ProcessUtils.GetProcessObject(obsBinaryPath, text, false).Start();
			Logger.Info("OBS started");
			StreamManager.ObsServerPort = RegistryManager.Instance.OBSServerPort;
		}

		// Token: 0x06001801 RID: 6145 RVA: 0x0008E324 File Offset: 0x0008C524
		public void SetHwnd(string handle)
		{
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"hwnd",
					handle
				}
			};
			this.SendObsRequest("sethwnd", data, null, null, 0, false);
		}

		// Token: 0x06001802 RID: 6146 RVA: 0x0008E354 File Offset: 0x0008C554
		public void SetSavePath(string path = null)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			string value = path ?? Path.Combine(RegistryStrings.BtvDir, "stream.flv");
			this.mLastVideoFilePath = value;
			dictionary.Add("savepath", value);
			this.SendObsRequest("setsavepath", dictionary, null, "SetSaveFailed", 0, false);
		}

		// Token: 0x06001803 RID: 6147 RVA: 0x000105BA File Offset: 0x0000E7BA
		private void SetSaveFailed()
		{
			Logger.Error("Exception in SetSaveFailed");
		}

		// Token: 0x06001804 RID: 6148 RVA: 0x0008E3A4 File Offset: 0x0008C5A4
		private void SetReplayBufferSavePath()
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			string value = Path.Combine(RegistryStrings.BtvDir, "replay.flv");
			dictionary.Add("savepath", value);
			this.SendObsRequest("setreplaybuffersavepath", dictionary, null, null, 0, false);
		}

		// Token: 0x06001805 RID: 6149 RVA: 0x0008E3E4 File Offset: 0x0008C5E4
		public static void SetStreamDimension(out int startX, out int startY, out int width, out int height)
		{
			try
			{
				BTVManager.GetStreamDimensionInfo(out startX, out startY, out width, out height);
			}
			catch (Exception ex)
			{
				Logger.Error("Got Exception in getting stream dimension... Err : " + ex.ToString());
				startX = (startY = (width = (height = 0)));
			}
		}

		// Token: 0x06001806 RID: 6150 RVA: 0x0008E438 File Offset: 0x0008C638
		public void SetFrontendPosition()
		{
			int startX;
			int startY;
			int width;
			int num;
			StreamManager.SetStreamDimension(out startX, out startY, out width, out num);
			int @int = Utils.GetInt(RegistryManager.Instance.FrontendHeight, num);
			int frontendWidth;
			if (this.isWindowCaptureActive)
			{
				frontendWidth = RegistryManager.Instance.FrontendWidth;
			}
			else
			{
				frontendWidth = (int)this.GetWidthFromHeight((double)@int);
			}
			this.SetFrontendPosition(frontendWidth, @int, startX, startY, width, num);
		}

		// Token: 0x06001807 RID: 6151 RVA: 0x0008E494 File Offset: 0x0008C694
		public void SetFrontendPosition(int frontendWidth, int frontendHeight)
		{
			int startX;
			int startY;
			int width;
			int height;
			StreamManager.SetStreamDimension(out startX, out startY, out width, out height);
			this.SetFrontendPosition(frontendWidth, frontendHeight, startX, startY, width, height);
		}

		// Token: 0x06001808 RID: 6152 RVA: 0x0008E4BC File Offset: 0x0008C6BC
		public void SetFrontendPosition(int frontendWidth, int frontendHeight, int startX, int startY, int width, int height)
		{
			startY += (height - frontendHeight) / 2;
			startX += (width - frontendWidth) / 2;
			if (this.mEnableFilter)
			{
				int num = frontendWidth * 100 / (frontendHeight * 16 / 9);
				int startX2 = (100 - num) / 2;
				this.SetFrontendPosition(startX2, 0, num, 100);
				this.SetPosition(startX2, 0);
			}
			else
			{
				this.SetFrontendPosition(0, 0, 100, 100);
				if (!this.mSquareTheme)
				{
					this.SetPosition(0, 0);
				}
			}
			this.SetCaptureSize(startX, startY, frontendWidth, frontendHeight);
		}

		// Token: 0x06001809 RID: 6153 RVA: 0x0008E538 File Offset: 0x0008C738
		public void SetFrontendPosition(int startX, int startY, int width, int height)
		{
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"width",
					width.ToString(CultureInfo.InvariantCulture)
				},
				{
					"height",
					height.ToString(CultureInfo.InvariantCulture)
				},
				{
					"y",
					startY.ToString(CultureInfo.InvariantCulture)
				},
				{
					"x",
					startX.ToString(CultureInfo.InvariantCulture)
				},
				{
					"source",
					"BlueStacks"
				}
			};
			this.SendObsRequest("setsourceposition", data, null, null, 0, false);
		}

		// Token: 0x0600180A RID: 6154 RVA: 0x0008E5C8 File Offset: 0x0008C7C8
		public void SetPosition(int startX, int startY)
		{
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"y",
					startY.ToString(CultureInfo.InvariantCulture)
				},
				{
					"x",
					startX.ToString(CultureInfo.InvariantCulture)
				},
				{
					"source",
					"BlueStacks"
				}
			};
			this.SendObsRequest("setposition", data, null, null, 0, false);
		}

		// Token: 0x0600180B RID: 6155 RVA: 0x0008E62C File Offset: 0x0008C82C
		public void SetFrontEndCaptureSize(int width, int height)
		{
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"width",
					width.ToString(CultureInfo.InvariantCulture)
				},
				{
					"height",
					height.ToString(CultureInfo.InvariantCulture)
				},
				{
					"source",
					"BlueStacks"
				}
			};
			this.SendObsRequest("SetFrontendCaptureSize", data, null, null, 0, false);
		}

		// Token: 0x0600180C RID: 6156 RVA: 0x0008E690 File Offset: 0x0008C890
		public void SetCaptureSize()
		{
			int num;
			int num2;
			int num3;
			int num4;
			StreamManager.SetStreamDimension(out num, out num2, out num3, out num4);
			int @int = Utils.GetInt(RegistryManager.Instance.FrontendHeight, num4);
			num2 += (num4 - @int) / 2;
			int num5 = this.isWindowCaptureActive ? RegistryManager.Instance.FrontendWidth : ((int)this.GetWidthFromHeight((double)@int));
			num += (num3 - num5) / 2;
			Logger.Info("frontendWidth for set capture size : " + num5.ToString());
			Logger.Info("frontendHeight for set capture size : " + @int.ToString());
			this.SetCaptureSize(num, num2, num5, @int);
		}

		// Token: 0x0600180D RID: 6157 RVA: 0x0008E728 File Offset: 0x0008C928
		private void SetCaptureSize(int startX, int startY, int width, int height)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			Logger.Info("width for set capture size : " + width.ToString());
			Logger.Info("height for set capture size : " + height.ToString());
			dictionary.Add("width", width.ToString(CultureInfo.InvariantCulture));
			dictionary.Add("height", height.ToString(CultureInfo.InvariantCulture));
			dictionary.Add("x", startX.ToString(CultureInfo.InvariantCulture));
			dictionary.Add("y", startY.ToString(CultureInfo.InvariantCulture));
			dictionary.Add("source", "BlueStacks");
			this.SendObsRequest("setcapturesize", dictionary, null, null, 0);
			if (this.isWindowCaptureActive)
			{
				this.SetFrontEndCaptureSize(RegistryManager.Instance.FrontendWidth, RegistryManager.Instance.FrontendHeight);
				if (StreamManager.IsPortraitApp())
				{
					this.SetPosition(35, 0);
					return;
				}
				this.SetPosition(0, 0);
			}
		}

		// Token: 0x0600180E RID: 6158 RVA: 0x0008E820 File Offset: 0x0008CA20
		public void ResetCLRBrowser(bool isSetFrontEndPosition = true)
		{
			this.DisableSource("CLR Browser");
			if (isSetFrontEndPosition)
			{
				this.SetFrontendPosition();
			}
			if (string.Compare(StreamManager.CamStatus, "true", StringComparison.OrdinalIgnoreCase) == 0)
			{
				this.EnableWebcamInternal("320", "240", "3");
			}
			else
			{
				this.DisableWebcamAndClearDictionary();
			}
			this.mCLRBrowserRunning = false;
			this.mCurrentFilterAppPkg = null;
		}

		// Token: 0x0600180F RID: 6159 RVA: 0x0008E880 File Offset: 0x0008CA80
		internal void EnableVideoRecording(bool enable)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			if (enable)
			{
				dictionary.Add("Enable", "1");
			}
			else
			{
				dictionary.Add("Enable", "0");
			}
			this.SendObsRequest("EnableVideoRecording", dictionary, null, null, 0);
		}

		// Token: 0x06001810 RID: 6160 RVA: 0x0008E8C8 File Offset: 0x0008CAC8
		private void SetCameraPosition(int x, int y, int width, int height, int render)
		{
			Logger.Info("camera position width is : " + width.ToString() + " and height is :" + height.ToString());
			StreamManager.mIsWebcamDisabled = false;
			Dictionary<string, string> dictionary = new Dictionary<string, string>
			{
				{
					"source",
					"BlueStacksWebcam"
				},
				{
					"width",
					width.ToString(CultureInfo.InvariantCulture)
				},
				{
					"height",
					height.ToString(CultureInfo.InvariantCulture)
				},
				{
					"x",
					x.ToString(CultureInfo.InvariantCulture)
				},
				{
					"y",
					y.ToString(CultureInfo.InvariantCulture)
				},
				{
					"render",
					render.ToString(CultureInfo.InvariantCulture)
				}
			};
			if (StreamManager.mDictCameraDetails.ContainsKey(StreamManager.mSelectedCamera))
			{
				dictionary.Add("camera", StreamManager.mDictCameraDetails[StreamManager.mSelectedCamera]);
			}
			else
			{
				dictionary["camera"] = string.Empty;
			}
			StreamManager.mDictLastCameraPosition = dictionary;
			this.SendObsRequest("setcameraposition", dictionary, "WebcamConfigured", null, 0, false);
		}

		// Token: 0x06001811 RID: 6161 RVA: 0x0008E9E0 File Offset: 0x0008CBE0
		internal void UpdateCameraPosition(string camName)
		{
			this.DisableWebcam();
			if (!string.IsNullOrEmpty(camName))
			{
				StreamManager.mSelectedCamera = camName;
			}
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary["source"] = "BlueStacksWebcam";
			dictionary["width"] = "100";
			dictionary["height"] = "100";
			dictionary["x"] = "0";
			dictionary["y"] = "0";
			dictionary["render"] = "1";
			Dictionary<string, string> dictionary2 = dictionary;
			if (StreamManager.mDictCameraDetails.ContainsKey(StreamManager.mSelectedCamera))
			{
				dictionary2["camera"] = StreamManager.mDictCameraDetails[StreamManager.mSelectedCamera];
			}
			else
			{
				dictionary2["camera"] = string.Empty;
			}
			this.SendObsRequest("setcameraposition", dictionary2, "WebcamConfigured", null, 0, false);
		}

		// Token: 0x06001812 RID: 6162 RVA: 0x0008EAB8 File Offset: 0x0008CCB8
		internal void ChangeCamera()
		{
			this.DisableWebcam();
			if (!StreamManager.mIsWebcamDisabled)
			{
				if (StreamManager.mDictLastCameraPosition.Count == 0)
				{
					StreamManager.mDictLastCameraPosition["source"] = "BlueStacksWebcam";
					StreamManager.mDictLastCameraPosition["width"] = "17";
					StreamManager.mDictLastCameraPosition["height"] = "23";
					StreamManager.mDictLastCameraPosition["x"] = "0";
					StreamManager.mDictLastCameraPosition["y"] = "77";
					StreamManager.mDictLastCameraPosition["render"] = "1";
				}
				if (StreamManager.mDictCameraDetails.ContainsKey(StreamManager.mSelectedCamera))
				{
					StreamManager.mDictLastCameraPosition["camera"] = StreamManager.mDictCameraDetails[StreamManager.mSelectedCamera];
				}
				else
				{
					StreamManager.mDictLastCameraPosition["camera"] = string.Empty;
				}
				this.SendObsRequest("setcameraposition", StreamManager.mDictLastCameraPosition, "WebcamConfigured", null, 0, false);
			}
		}

		// Token: 0x06001813 RID: 6163 RVA: 0x0008EBB8 File Offset: 0x0008CDB8
		public void SetClrBrowserConfig(string width, string height, string url)
		{
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"width",
					width
				},
				{
					"height",
					height
				},
				{
					"url",
					url
				}
			};
			this.SendObsRequest("setclrbrowserconfig", data, null, null, 0);
		}

		// Token: 0x06001814 RID: 6164 RVA: 0x000105C6 File Offset: 0x0000E7C6
		public void ObsErrorStatus(string erroReason)
		{
			this.mIsStreaming = false;
			this.mFailureReason = "Error starting stream : " + erroReason;
			this.SendStreamStatus(false, false);
		}

		// Token: 0x06001815 RID: 6165 RVA: 0x0008EC00 File Offset: 0x0008CE00
		public void ReportObsError(string errorReason)
		{
			try
			{
				Logger.Info("error reason in obs :" + errorReason);
				string text = "stream_interrupted_error";
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				if (string.Equals(errorReason, "ConnectionSuccessfull", StringComparison.InvariantCultureIgnoreCase))
				{
					if (!this.mIsStreamStarted)
					{
						this.mIsStreamStarted = true;
						text = "obs_connected";
					}
					else
					{
						text = "stream_resumed";
					}
				}
				else if (!this.mIsStreamStarted)
				{
					text = "went_live_error";
				}
				if (string.Equals(errorReason, "OBSAlreadyRunning", StringComparison.InvariantCultureIgnoreCase))
				{
					text = "obs_already_running";
					this.ReportStreamStatsToCloud(text, errorReason);
					dictionary.Add("reason", text);
					StreamManager.ReportObsErrorHandler(text);
				}
				else if (string.Equals(errorReason, "capture_error", StringComparison.InvariantCultureIgnoreCase))
				{
					text = "capture_error";
					this.ReportStreamStatsToCloud(text, errorReason);
					StreamManager.sStopInitOBSQueue = true;
					dictionary.Add("reason", text);
					StreamManager.ReportObsErrorHandler(text);
				}
				else if (string.Equals(errorReason, "opengl_capture_error", StringComparison.InvariantCultureIgnoreCase))
				{
					text = "opengl_capture_error";
					this.ReportStreamStatsToCloud(text, errorReason);
					StreamManager.sStopInitOBSQueue = true;
					dictionary.Add("reason", text);
					StreamManager.ReportObsErrorHandler(text);
				}
				else if (string.Equals(errorReason, "AccessDenied", StringComparison.InvariantCultureIgnoreCase) || string.Equals(errorReason, "ConnectServerError", StringComparison.InvariantCultureIgnoreCase) || string.Equals(errorReason, "obs_error", StringComparison.InvariantCultureIgnoreCase))
				{
					errorReason = "Error starting stream : " + errorReason;
					this.ReportStreamStatsToCloud(text, errorReason);
					dictionary.Add("reason", "obs_error");
					StreamManager.ReportObsErrorHandler("obs_error");
				}
				else if (string.Equals(errorReason, "ConnectionSuccessfull", StringComparison.InvariantCultureIgnoreCase))
				{
					this.ReportStreamStatsToCloud(text, errorReason);
				}
				else
				{
					errorReason = "Error starting stream : " + errorReason;
					this.ReportStreamStatsToCloud(text, errorReason);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to report obs error.. Err : " + ex.ToString());
			}
		}

		// Token: 0x06001816 RID: 6166 RVA: 0x0008EDC8 File Offset: 0x0008CFC8
		public void RestartOBSInWindowCaptureMode()
		{
			try
			{
				this.ShutDownForcefully();
				this.CopySceneConfigFile(this.mWindow, true);
				Logger.Info("restarting obs in window capture mode");
				if (File.Exists(this.mLastVideoFilePath))
				{
					File.Delete(this.mLastVideoFilePath);
				}
				this.mWindow.mCommonHandler.RecordVideoOfApp();
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in restart obs in window capture mode: {0}", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x06001817 RID: 6167 RVA: 0x0008EE48 File Offset: 0x0008D048
		private static void ReportObsErrorHandler(string reason)
		{
			Logger.Error("Obs reported an error. " + reason);
			if (string.Equals(reason, "opengl_capture_error", StringComparison.OrdinalIgnoreCase))
			{
				RegistryManager.Instance.IsGameCaptureSupportedInMachine = false;
				StreamManager.Instance.RestartOBSInWindowCaptureMode();
				return;
			}
			StreamManager instance = StreamManager.Instance;
			if (instance == null)
			{
				return;
			}
			instance.mWindow.Dispatcher.Invoke(new Action(delegate()
			{
				StreamManager.Instance.mWindow.mCommonHandler.ShowErrorRecordingVideoPopup();
			}), new object[0]);
		}

		// Token: 0x06001818 RID: 6168 RVA: 0x0008EEC8 File Offset: 0x0008D0C8
		private void ReportStreamStatsToCloud(string eventType, string reason)
		{
			Logger.Info("StreamStats eventType: {0}, reason: {1}", new object[]
			{
				eventType,
				reason
			});
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary.Add("event_type", eventType);
			dictionary.Add("error_code", reason);
			dictionary.Add("guid", RegistryManager.Instance.UserGuid);
			dictionary.Add("streaming_platform", this.mNetwork);
			dictionary.Add("session_id", Stats.GetSessionId());
			dictionary.Add("prod_ver", "4.190.0.5002");
			dictionary.Add("created_at", DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.CurrentCulture));
		}

		// Token: 0x06001819 RID: 6169 RVA: 0x000105E8 File Offset: 0x0000E7E8
		internal void GetParametersFromOBS()
		{
			this.SendObsRequest("getmicvolume", null, "SetMicVolumeLocal", null, 0, false);
			this.SendObsRequest("getsystemvolume", null, "SetSystemVolumeLocal", null, 0, false);
		}

		// Token: 0x0600181A RID: 6170 RVA: 0x0008EF74 File Offset: 0x0008D174
		private void SetMicLocal(string response)
		{
			try
			{
				List<string> list = response.Split(new string[]
				{
					"@@"
				}, StringSplitOptions.RemoveEmptyEntries)[0].Split(new char[]
				{
					','
				}, StringSplitOptions.RemoveEmptyEntries).ToList<string>();
				List<string> list2 = response.Split(new string[]
				{
					"@@"
				}, StringSplitOptions.RemoveEmptyEntries)[1].Split(new char[]
				{
					','
				}, StringSplitOptions.RemoveEmptyEntries).ToList<string>();
				StreamManager.mSelectedMic = response.Split(new string[]
				{
					"@@"
				}, StringSplitOptions.RemoveEmptyEntries)[2];
				StreamManager.mDictMicDetails.Clear();
				StreamManager.mSelectedMic = Regex.Replace(StreamManager.mSelectedMic, "[^\\u0000-\\u007F]+", string.Empty);
				if (list2.Count == 0)
				{
					StreamManager.mSelectedMic = string.Empty;
					StreamManager.mIsMicDisabled = true;
				}
				else
				{
					for (int i = 0; i < list2.Count; i++)
					{
						if (!string.Equals(list2[i], "Default", StringComparison.InvariantCulture) && !string.Equals(list2[i], "Disable", StringComparison.InvariantCulture))
						{
							StreamManager.mDictMicDetails.Add(Regex.Replace(list[i], "[^\\u0000-\\u007F]+", string.Empty), list2[i]);
						}
					}
					if (StreamManager.mDictMicDetails.Count == 0)
					{
						StreamManager.mSelectedMic = string.Empty;
						StreamManager.mIsMicDisabled = true;
					}
					else if (!StreamManager.mDictMicDetails.ContainsKey(StreamManager.mSelectedMic))
					{
						StreamManager.mSelectedMic = StreamManager.mDictMicDetails.Keys.ToList<string>()[0];
					}
				}
				EventHandler<CustomVolumeEventArgs> eventGetMicDetails = this.EventGetMicDetails;
				if (eventGetMicDetails != null)
				{
					eventGetMicDetails(this, new CustomVolumeEventArgs(StreamManager.mDictMicDetails, StreamManager.mSelectedMic));
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in SetMicLocal. response: " + response);
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x0600181B RID: 6171 RVA: 0x0008F140 File Offset: 0x0008D340
		private void SetMicVolumeLocal(string volumeResponse)
		{
			try
			{
				StreamManager.mMicVolume = JObject.Parse(volumeResponse)["volume"].ToObject<int>();
				EventHandler<CustomVolumeEventArgs> eventGetMicVolume = this.EventGetMicVolume;
				if (eventGetMicVolume != null)
				{
					eventGetMicVolume(this, new CustomVolumeEventArgs(StreamManager.mMicVolume));
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in SetMicVolumeLocal. response: " + volumeResponse);
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x0600181C RID: 6172 RVA: 0x0008F1B4 File Offset: 0x0008D3B4
		private void SetCameraLocal(string cameraResponse)
		{
			try
			{
				List<string> list = cameraResponse.Split(new string[]
				{
					"@@"
				}, StringSplitOptions.RemoveEmptyEntries)[0].Split(new char[]
				{
					','
				}, StringSplitOptions.RemoveEmptyEntries).ToList<string>();
				List<string> list2 = cameraResponse.Split(new string[]
				{
					"@@"
				}, StringSplitOptions.RemoveEmptyEntries)[1].Split(new char[]
				{
					','
				}, StringSplitOptions.RemoveEmptyEntries).ToList<string>();
				StreamManager.mDictCameraDetails.Clear();
				if (list2.Count == 0)
				{
					StreamManager.mSelectedCamera = string.Empty;
					StreamManager.mIsWebcamDisabled = true;
				}
				else
				{
					for (int i = 0; i < list2.Count; i++)
					{
						StreamManager.mDictCameraDetails.Add(Regex.Replace(list[i], "[^\\u0000-\\u007F]+", string.Empty).Trim(), list2[i]);
					}
					if (!StreamManager.mDictCameraDetails.ContainsKey(StreamManager.mSelectedCamera))
					{
						StreamManager.mSelectedCamera = Regex.Replace(cameraResponse.Split(new string[]
						{
							"@@"
						}, StringSplitOptions.RemoveEmptyEntries)[2], "[^\\u0000-\\u007F]+", string.Empty);
					}
				}
				EventHandler<CustomVolumeEventArgs> eventGetCameraDetails = this.EventGetCameraDetails;
				if (eventGetCameraDetails != null)
				{
					eventGetCameraDetails(this, new CustomVolumeEventArgs(StreamManager.mDictCameraDetails, StreamManager.mSelectedCamera));
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in SetCameraLocal. response: " + cameraResponse);
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x0600181D RID: 6173 RVA: 0x0008F318 File Offset: 0x0008D518
		private void SetSystemVolumeLocal(string volumeResponse)
		{
			try
			{
				StreamManager.mSystemVolume = JObject.Parse(volumeResponse)["volume"].ToObject<int>();
				EventHandler<CustomVolumeEventArgs> eventGetSystemVolume = this.EventGetSystemVolume;
				if (eventGetSystemVolume != null)
				{
					eventGetSystemVolume(this, new CustomVolumeEventArgs(StreamManager.mSystemVolume));
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in SetSystemVolumeLocal. response: " + volumeResponse);
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x0600181E RID: 6174 RVA: 0x00005D29 File Offset: 0x00003F29
		public static void EnableWebcam(string _1, string _2, string _3)
		{
		}

		// Token: 0x0600181F RID: 6175 RVA: 0x0008F38C File Offset: 0x0008D58C
		public void DisableSource(string source)
		{
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"source",
					source
				},
				{
					"render",
					"0"
				}
			};
			this.SendObsRequest("setrender", data, null, null, 0, false);
		}

		// Token: 0x06001820 RID: 6176 RVA: 0x0008F3CC File Offset: 0x0008D5CC
		public void EnableSource(string source)
		{
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"source",
					source
				},
				{
					"render",
					"1"
				}
			};
			this.SendObsRequest("setrender", data, null, null, 0, false);
		}

		// Token: 0x06001821 RID: 6177 RVA: 0x0008F40C File Offset: 0x0008D60C
		public void EnableWebcamInternal(string widthStr, string heightStr, string position)
		{
			int num = Convert.ToInt32(widthStr, CultureInfo.InvariantCulture);
			int num2 = Convert.ToInt32(heightStr, CultureInfo.InvariantCulture);
			if (this.mStreamHeight == 0 || this.mStreamWidth == 0)
			{
				return;
			}
			num = num * 100 / this.mStreamWidth;
			num2 = num2 * 100 / this.mStreamHeight;
			new Dictionary<string, string>();
			int x = 0;
			int y = 0;
			if (string.Equals(position, "2", StringComparison.InvariantCultureIgnoreCase))
			{
				x = 100 - num;
			}
			else if (string.Equals(position, "3", StringComparison.InvariantCultureIgnoreCase))
			{
				y = 100 - num2;
			}
			else if (string.Equals(position, "4", StringComparison.InvariantCultureIgnoreCase))
			{
				x = 100 - num;
				y = 100 - num;
			}
			this.SetCameraPosition(x, y, num, num2, 1);
		}

		// Token: 0x06001822 RID: 6178 RVA: 0x00005D29 File Offset: 0x00003F29
		public void DisableWebcamV2(string _)
		{
		}

		// Token: 0x06001823 RID: 6179 RVA: 0x00010612 File Offset: 0x0000E812
		public void DisableWebcamAndClearDictionary()
		{
			StreamManager.mDictLastCameraPosition.Clear();
			StreamManager.mIsWebcamDisabled = true;
			this.DisableWebcam();
		}

		// Token: 0x06001824 RID: 6180 RVA: 0x0001062A File Offset: 0x0000E82A
		internal void DisableWebcam()
		{
			this.DisableSource("BlueStacksWebcam");
		}

		// Token: 0x06001825 RID: 6181 RVA: 0x0008F4B4 File Offset: 0x0008D6B4
		private void WebcamConfigured(string response)
		{
			try
			{
				JObject jobject = JObject.Parse(response);
				if (jobject["success"].ToObject<bool>())
				{
					StreamManager.CamStatus = jobject["webcam"].ToObject<bool>().ToString(CultureInfo.InvariantCulture);
					if (Convert.ToBoolean(StreamManager.CamStatus, CultureInfo.InvariantCulture))
					{
						RegistryManager.Instance.CamStatus = 1;
					}
					else
					{
						RegistryManager.Instance.CamStatus = 0;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Setting WebCamRegistry. response: {0} err : {1}", new object[]
				{
					response,
					ex.ToString()
				});
			}
		}

		// Token: 0x06001826 RID: 6182 RVA: 0x00010637 File Offset: 0x0000E837
		public void ResetFlvStream()
		{
			this.SendObsRequest("resetflvstream", null, null, null, 0);
		}

		// Token: 0x06001827 RID: 6183 RVA: 0x0008F558 File Offset: 0x0008D758
		public void SetSquareConfig(int startX, int startY, int width, int height)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			Logger.Info("Window size: ({0}, {1})", new object[]
			{
				width,
				height
			});
			this.widthDiff = 0;
			int num;
			int num2;
			MiscUtils.GetStreamWidthAndHeight(width, height, out num, out num2);
			int num3 = (int)this.GetWidthFromHeight((double)num2);
			Logger.Info("Stream size: ({0}, {1})", new object[]
			{
				num3,
				num2
			});
			width = num3;
			height = num2;
			height = width;
			string value;
			int num4;
			if (num2 <= 720)
			{
				value = "main";
				num4 = 2500;
			}
			else
			{
				value = "high";
				num4 = 3500;
			}
			float num5 = 1f;
			Logger.Info("x : " + startX.ToString());
			Logger.Info("y : " + startY.ToString());
			Logger.Info("width : " + width.ToString());
			Logger.Info("height : " + height.ToString());
			dictionary.Clear();
			dictionary.Add("startX", startX.ToString(CultureInfo.InvariantCulture));
			dictionary.Add("startY", startY.ToString(CultureInfo.InvariantCulture));
			dictionary.Add("width", width.ToString(CultureInfo.InvariantCulture));
			dictionary.Add("height", height.ToString(CultureInfo.InvariantCulture));
			dictionary.Add("x264Profile", value);
			dictionary.Add("maxBitrate", num4.ToString(CultureInfo.InvariantCulture));
			dictionary.Add("downscale", num5.ToString(CultureInfo.InvariantCulture));
			this.mStreamWidth = width;
			this.mStreamHeight = height;
			this.SendObsRequest("setconfig", dictionary, null, null, 0, false);
		}

		// Token: 0x06001828 RID: 6184 RVA: 0x00010648 File Offset: 0x0000E848
		public void SetConfig(int startX, int startY, int width, int height)
		{
			if (this.mSquareTheme)
			{
				this.SetSquareConfig(startX, startY, width, height);
				return;
			}
			this.SetDefaultConfig(startX, startY, width, height);
		}

		// Token: 0x06001829 RID: 6185 RVA: 0x00010669 File Offset: 0x0000E869
		public void RestartRecord()
		{
			this.StopRecord(true);
			this.StartRecord();
		}

		// Token: 0x0600182A RID: 6186 RVA: 0x0008F714 File Offset: 0x0008D914
		public void SetDefaultConfig(int startX, int startY, int width, int height)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			Logger.Info("Window size: ({0}, {1})", new object[]
			{
				width,
				height
			});
			this.widthDiff = 0;
			int num;
			int num2;
			MiscUtils.GetStreamWidthAndHeight(width, height, out num, out num2);
			int num3 = (int)this.GetWidthFromHeight((double)num2);
			width = num3;
			height = num2;
			int num4 = width * 9 / 16;
			Logger.Info("Stream size: ({0}, {1})", new object[]
			{
				num3,
				num2
			});
			string value;
			int num5;
			if (num2 == 540)
			{
				value = "main";
				num5 = 1200;
			}
			else if (num2 == 720)
			{
				value = "main";
				num5 = 2500;
			}
			else
			{
				value = "high";
				num5 = 3500;
			}
			float num6 = (float)height / (float)num2;
			Logger.Info("x : " + startX.ToString());
			Logger.Info("y : " + startY.ToString());
			Logger.Info("width : " + width.ToString());
			Logger.Info("height : " + height.ToString());
			dictionary.Clear();
			dictionary.Add("startX", startX.ToString(CultureInfo.InvariantCulture));
			dictionary.Add("startY", startY.ToString(CultureInfo.InvariantCulture));
			dictionary.Add("width", width.ToString(CultureInfo.InvariantCulture));
			dictionary.Add("height", height.ToString(CultureInfo.InvariantCulture));
			dictionary.Add("x264Profile", value);
			dictionary.Add("maxBitrate", num5.ToString(CultureInfo.InvariantCulture));
			dictionary.Add("downscale", num6.ToString(CultureInfo.InvariantCulture));
			this.mStreamWidth = width;
			this.mStreamHeight = height;
			this.SendObsRequest("setconfig", dictionary, null, null, 0, false);
		}

		// Token: 0x0600182B RID: 6187 RVA: 0x0008F8F0 File Offset: 0x0008DAF0
		public void StartStream(string key, string location, string callbackStreamStatus, string callbackAppInfo)
		{
			string service = "1";
			this.mCallbackStreamStatus = callbackStreamStatus;
			if (this.mCallbackAppInfo == null)
			{
				this.mCallbackAppInfo = callbackAppInfo;
			}
			this.SetStreamSettings(service, key, location);
			this.SendObsRequest("startstream", null, "StreamStarted", null, 0);
		}

		// Token: 0x0600182C RID: 6188 RVA: 0x0008F938 File Offset: 0x0008DB38
		public void StartStream(string jsonString, string callbackStreamStatus, string callbackAppInfo)
		{
			Logger.Info(jsonString);
			JObject jobject = JObject.Parse(jsonString);
			string playPath = jobject["key"].ToString();
			string service = jobject["service"].ToString();
			string url = jobject["streamUrl"].ToString();
			jobject["server"].ToString();
			this.mCallbackStreamStatus = callbackStreamStatus;
			this.mCallbackAppInfo = callbackAppInfo;
			this.SetStreamSettings(service, playPath, url);
			this.SendObsRequest("startstream", null, "StreamStarted", null, 0);
		}

		// Token: 0x0600182D RID: 6189 RVA: 0x00010678 File Offset: 0x0000E878
		public void StopStream()
		{
			this.SendObsRequest("stopstream", null, "StreamStopped", null, 0);
		}

		// Token: 0x0600182E RID: 6190 RVA: 0x0008F9C0 File Offset: 0x0008DBC0
		private void SendStatus(string path, Dictionary<string, string> data)
		{
			try
			{
				if (string.Equals(path, "streamstarted", StringComparison.InvariantCulture))
				{
					BTVManager.Instance.StreamStarted();
				}
				else if (string.Equals(path, "streamstopped", StringComparison.InvariantCulture))
				{
					BTVManager.Instance.StreamStopped();
				}
				else if (string.Equals(path, "recordstarted", StringComparison.InvariantCulture))
				{
					BTVManager.Instance.RecordStarted();
				}
				else if (string.Equals(path, "recordstopped", StringComparison.InvariantCulture))
				{
					BTVManager.Instance.RecordStopped();
					CommonHandlers.sIsRecordingVideo = false;
					if (BlueStacksUIUtils.DictWindows.ContainsKey(CommonHandlers.sRecordingInstance))
					{
						BlueStacksUIUtils.DictWindows[CommonHandlers.sRecordingInstance].mCommonHandler.RecordingStopped();
					}
					CommonHandlers.sRecordingInstance = "";
					this.ShutDownForcefully();
				}
				else if (string.Equals(path, "streamstatus", StringComparison.InvariantCulture))
				{
					if (string.Compare(data["isstreaming"], "true", StringComparison.OrdinalIgnoreCase) == 0)
					{
						BTVManager.Instance.sStreaming = true;
					}
					else
					{
						BTVManager.Instance.sStreaming = false;
					}
				}
				else if (string.Equals(path, "replaybuffersaved", StringComparison.InvariantCulture))
				{
					BTVManager.ReplayBufferSaved();
				}
				else if (string.Equals(path, "RecordStartedVideo", StringComparison.InvariantCulture) && BlueStacksUIUtils.DictWindows.ContainsKey(CommonHandlers.sRecordingInstance))
				{
					BlueStacksUIUtils.DictWindows[CommonHandlers.sRecordingInstance].mCommonHandler.RecordingStarted();
				}
				Logger.Info("Successfully sent status for {0}", new object[]
				{
					path
				});
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send post request for {0}... Err : {1}", new object[]
				{
					path,
					ex.ToString()
				});
			}
		}

		// Token: 0x0600182F RID: 6191 RVA: 0x0008FB60 File Offset: 0x0008DD60
		public void StartRecordForVideo()
		{
			if (this.mIsObsRunning)
			{
				int startX;
				int startY;
				int width;
				int height;
				StreamManager.SetStreamDimension(out startX, out startY, out width, out height);
				this.SetConfig(startX, startY, width, height);
				this.SetSceneConfiguration(this.mLayoutTheme);
				this.ResetCLRBrowser(true);
			}
			this.SendObsRequest("startrecord", null, "RecordStartedVideo", null, 0);
		}

		// Token: 0x06001830 RID: 6192 RVA: 0x0001068D File Offset: 0x0000E88D
		public void StartRecord()
		{
			this.StartRecord(this.mNetwork, this.mEnableFilter, this.mSquareTheme, this.mLayoutTheme, this.mCallbackAppInfo);
		}

		// Token: 0x06001831 RID: 6193 RVA: 0x000106B3 File Offset: 0x0000E8B3
		public void StartRecordInit(string network, bool enableFilter, bool squareTheme, string layoutTheme, string callbackAppInfo)
		{
			this.mNetwork = network;
			this.mEnableFilter = enableFilter;
			this.mSquareTheme = squareTheme;
			this.mLayoutTheme = layoutTheme;
			this.mCallbackAppInfo = callbackAppInfo;
		}

		// Token: 0x06001832 RID: 6194 RVA: 0x0008FBB4 File Offset: 0x0008DDB4
		public void StartRecord(string network, bool enableFilter, bool squareTheme, string layoutTheme, string callbackAppInfo)
		{
			object obj = this.stoppingOBSLock;
			lock (obj)
			{
				this.mEnableFilter = enableFilter;
				this.mSquareTheme = squareTheme;
				this.mCallbackAppInfo = callbackAppInfo;
				StreamManager.SendNetworkName(network);
				if (layoutTheme != null)
				{
					this.mLayoutTheme = Utils.GetString(RegistryManager.Instance.LayoutTheme, layoutTheme);
					this.mLastCameraLayoutTheme = RegistryManager.Instance.LastCameraLayoutTheme;
					this.mAppViewLayout = (RegistryManager.Instance.AppViewLayout == 1);
					if (string.IsNullOrEmpty(this.mLastCameraLayoutTheme))
					{
						this.mLastCameraLayoutTheme = layoutTheme;
					}
				}
				else
				{
					this.mLayoutTheme = layoutTheme;
				}
				this.mNetwork = network;
				if (this.mIsObsRunning)
				{
					int startX;
					int startY;
					int width;
					int height;
					StreamManager.SetStreamDimension(out startX, out startY, out width, out height);
					this.SetConfig(startX, startY, width, height);
					this.SetSceneConfiguration(this.mLayoutTheme);
				}
				this.EnableVideoRecording(false);
				this.SendObsRequest("startrecord", null, "RecordStarted", null, 0);
			}
		}

		// Token: 0x06001833 RID: 6195 RVA: 0x000106DA File Offset: 0x0000E8DA
		public void StopRecord()
		{
			this.StopRecord(false);
		}

		// Token: 0x06001834 RID: 6196 RVA: 0x0008FCB0 File Offset: 0x0008DEB0
		public void StopRecord(bool immediate)
		{
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"immediate",
					immediate ? "1" : "0"
				}
			};
			this.SendObsRequest("stoprecord", data, "RecordStopped", null, 0);
		}

		// Token: 0x06001835 RID: 6197 RVA: 0x0008FCF0 File Offset: 0x0008DEF0
		public void SendAppInfo(string type, string name, string data)
		{
			if (this.mCallbackAppInfo == null)
			{
				return;
			}
			JObject jobject = new JObject
			{
				{
					"type",
					type
				},
				{
					"name",
					name
				},
				{
					"data",
					data
				}
			};
			object[] args = new object[]
			{
				jobject.ToString(Formatting.None, new JsonConverter[0])
			};
			this.mBrowser.CallJs(this.mCallbackAppInfo, args);
		}

		// Token: 0x06001836 RID: 6198 RVA: 0x0008FD68 File Offset: 0x0008DF68
		public static string GetStreamConfig()
		{
			string streamName = RegistryManager.Instance.StreamName;
			string serverLocation = RegistryManager.Instance.ServerLocation;
			JObject jobject = new JObject
			{
				{
					"streamName",
					streamName
				},
				{
					"camStatus",
					Convert.ToBoolean(StreamManager.CamStatus, CultureInfo.InvariantCulture)
				},
				{
					"micVolume",
					StreamManager.mMicVolume
				},
				{
					"systemVolume",
					StreamManager.mSystemVolume
				},
				{
					"serverLocation",
					serverLocation
				}
			};
			Logger.Info("GetStreamConfig: " + jobject.ToString(Formatting.None, new JsonConverter[0]));
			return jobject.ToString();
		}

		// Token: 0x06001837 RID: 6199 RVA: 0x000106E3 File Offset: 0x0000E8E3
		private void StreamStarted(string _)
		{
			this.SendStatus("streamstarted", null);
			this.mIsStreaming = true;
		}

		// Token: 0x06001838 RID: 6200 RVA: 0x0008FE20 File Offset: 0x0008E020
		private void StreamStopped(string _)
		{
			this.SendStatus("streamstopped", null);
			this.mIsStreaming = false;
			this.mIsStreamStarted = false;
			this.SendObsRequest("close", null, null, null, 0);
			new Thread(delegate()
			{
				this.KillOBS();
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06001839 RID: 6201 RVA: 0x000106F8 File Offset: 0x0000E8F8
		public static void killOBSForcelly()
		{
			Utils.KillCurrentOemProcessByName("HD-OBS", null);
		}

		// Token: 0x0600183A RID: 6202 RVA: 0x0008FE74 File Offset: 0x0008E074
		public void KillOBS()
		{
			if (this.mStoppingOBS)
			{
				return;
			}
			object obj = this.stoppingOBSLock;
			lock (obj)
			{
				this.mStoppingOBS = true;
				try
				{
					int num = 0;
					int num2 = 20;
					while (num < num2 && Process.GetProcessesByName("HD-OBS").Length != 0)
					{
						num++;
						if (num < num2)
						{
							Logger.Info("Waiting for HD-OBS to quit gracefully, retry: {0}", new object[]
							{
								num
							});
							Thread.Sleep(200);
						}
					}
					if (num >= num2)
					{
						Utils.KillCurrentOemProcessByName("HD-OBS", null);
					}
					StreamManager.StartOBS();
				}
				catch (Exception ex)
				{
					Logger.Info("Failed to kill HD-OBS.exe...Err : " + ex.ToString());
				}
				this.mStoppingOBS = false;
			}
		}

		// Token: 0x0600183B RID: 6203 RVA: 0x00010705 File Offset: 0x0000E905
		private void RecordStarted(string _)
		{
			this.SendStatus("recordstarted", null);
		}

		// Token: 0x0600183C RID: 6204 RVA: 0x00010713 File Offset: 0x0000E913
		private void RecordStopped(string _)
		{
			this.SendStatus("recordstopped", null);
		}

		// Token: 0x0600183D RID: 6205 RVA: 0x00010721 File Offset: 0x0000E921
		private void RecordStartedVideo(string _)
		{
			this.SendStatus("RecordStartedVideo", null);
		}

		// Token: 0x0600183E RID: 6206 RVA: 0x0001072F File Offset: 0x0000E92F
		public void StartReplayBuffer()
		{
			this.SendObsRequest("startreplaybuffer", null, null, null, 0);
		}

		// Token: 0x0600183F RID: 6207 RVA: 0x00010740 File Offset: 0x0000E940
		public void StopReplayBuffer()
		{
			this.SendObsRequest("stopreplaybuffer", null, null, null, 2000);
		}

		// Token: 0x06001840 RID: 6208 RVA: 0x0008FF3C File Offset: 0x0008E13C
		private void SetStreamSettings(string service, string playPath, string url)
		{
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"service",
					service
				},
				{
					"playPath",
					playPath
				},
				{
					"url",
					url
				}
			};
			this.SendObsRequest("setstreamsettings", data, null, null, 0);
		}

		// Token: 0x06001841 RID: 6209 RVA: 0x0008FF84 File Offset: 0x0008E184
		public void SetSystemVolume(string level)
		{
			StreamManager.mSystemVolume = Convert.ToInt32(level, CultureInfo.InvariantCulture);
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"volume",
					level
				}
			};
			this.SendObsRequest("setsystemvolume", data, null, null, 0);
		}

		// Token: 0x06001842 RID: 6210 RVA: 0x0008FFC4 File Offset: 0x0008E1C4
		internal void SetMic(string micName)
		{
			micName = StreamManager.mDictMicDetails[micName];
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"micId",
					micName
				}
			};
			this.SendObsRequest("setmic", data, null, null, 0);
		}

		// Token: 0x06001843 RID: 6211 RVA: 0x00090000 File Offset: 0x0008E200
		public void SetMicVolume(string level)
		{
			StreamManager.mMicVolume = Convert.ToInt32(level, CultureInfo.InvariantCulture);
			if (StreamManager.mMicVolume > 0)
			{
				StreamManager.mIsMicDisabled = false;
			}
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"volume",
					level
				}
			};
			this.SendObsRequest("setmicvolume", data, null, null, 0);
		}

		// Token: 0x06001844 RID: 6212 RVA: 0x0009004C File Offset: 0x0008E24C
		private void StartPollingOBS()
		{
			while (this.mIsObsRunning)
			{
				try
				{
					JObject jobject = JObject.Parse(Regex.Replace(this.SendObsRequestInternal("getstatus", null), "\\r\\n?|\\n", ""));
					bool flag = jobject["streaming"].ToObject<bool>();
					bool flag2 = jobject["reconnecting"].ToObject<bool>();
					if (!flag)
					{
						try
						{
							this.mFailureReason = jobject["reason"].ToString();
						}
						catch
						{
						}
					}
					if (flag != this.mIsStreaming)
					{
						this.SendStreamStatus(flag, flag2);
					}
					this.mIsStreaming = flag;
					this.mIsReconnecting = flag2;
					Dictionary<string, string> data = new Dictionary<string, string>
					{
						{
							"isstreaming",
							this.mIsStreaming.ToString(CultureInfo.InvariantCulture)
						}
					};
					this.SendStatus("streamstatus", data);
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in StartPollingOBS err : " + ex.ToString());
					if (!ProcessUtils.FindProcessByName("HD-OBS"))
					{
						this.mIsObsRunning = false;
						this.mIsStreaming = false;
						this.mIsReconnecting = false;
						this.mCLRBrowserRunning = false;
						this.mIsStreamStarted = false;
						if (!this.mStoppingOBS)
						{
							this.UpdateFailureReason();
						}
						this.SendStreamStatus(false, false);
						this.InitObs();
						this.mStoppingOBS = false;
						break;
					}
				}
				Thread.Sleep(5000);
			}
		}

		// Token: 0x06001845 RID: 6213 RVA: 0x000901B4 File Offset: 0x0008E3B4
		private void UpdateFailureReason()
		{
			if (string.IsNullOrEmpty(this.mFailureReason))
			{
				string text = "";
				string format = "yyyy-MM-dd-HHmm-ss";
				DateTime t = DateTime.MinValue;
				string[] files = Directory.GetFiles(Path.Combine(RegistryStrings.BtvDir, "OBS\\Logs\\"));
				for (int i = 0; i < files.Length; i++)
				{
					text = Path.GetFileNameWithoutExtension(files[i]);
					DateTime dateTime;
					if (DateTime.TryParseExact(text, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out dateTime) && t < dateTime)
					{
						t = dateTime;
					}
				}
				if (!t.Equals(DateTime.MinValue))
				{
					text = File.ReadAllLines(Path.Combine(RegistryStrings.BtvDir, "OBS\\Logs\\") + t.ToString("yyyy-MM-dd-HHmm-ss", CultureInfo.InvariantCulture) + ".log").Last<string>();
				}
				this.mFailureReason = "OBS crashed: " + text;
			}
		}

		// Token: 0x06001846 RID: 6214 RVA: 0x00090288 File Offset: 0x0008E488
		private static void SendNetworkName(string network)
		{
			try
			{
				BTVManager.sNetwork = network;
				RegistryManager.Instance.BtvNetwork = network;
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send network name... Err : " + ex.ToString());
			}
		}

		// Token: 0x06001847 RID: 6215 RVA: 0x000902D0 File Offset: 0x0008E4D0
		private void SendStreamStatus(bool streaming, bool reconnecting)
		{
			Logger.Info(string.Concat(new string[]
			{
				"Sending stream status with data :: streaming : ",
				streaming.ToString(),
				", reconnecting : ",
				reconnecting.ToString(),
				", obsRunning : ",
				this.mIsObsRunning.ToString(),
				", failureReason : ",
				this.mFailureReason
			}));
			try
			{
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				dictionary.Add("obs", this.mIsObsRunning.ToString(CultureInfo.InvariantCulture));
				dictionary.Add("streaming", streaming.ToString(CultureInfo.InvariantCulture));
				dictionary.Add("reconnecting", reconnecting.ToString(CultureInfo.InvariantCulture));
				dictionary.Add("reason", this.mFailureReason.ToString(CultureInfo.InvariantCulture));
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send stream status... Err : " + ex.ToString());
			}
		}

		// Token: 0x06001848 RID: 6216 RVA: 0x000903D4 File Offset: 0x0008E5D4
		public void ResizeStream(string width, string height)
		{
			if (StreamManager.mObsCommandQueue != null)
			{
				Dictionary<string, string> data = new Dictionary<string, string>
				{
					{
						"width",
						width
					},
					{
						"height",
						height
					}
				};
				this.SendObsRequest("windowresized", data, null, null, 0);
			}
		}

		// Token: 0x06001849 RID: 6217 RVA: 0x00010755 File Offset: 0x0000E955
		public void ShowObs()
		{
			this.SendObsRequest("show", null, null, null, 0);
		}

		// Token: 0x0600184A RID: 6218 RVA: 0x00010766 File Offset: 0x0000E966
		public void HideObs()
		{
			this.SendObsRequest("hide", null, null, null, 0);
		}

		// Token: 0x0600184B RID: 6219 RVA: 0x00090418 File Offset: 0x0008E618
		public void MoveWebcam(string horizontal, string vertical)
		{
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"horizontal",
					horizontal
				},
				{
					"vertical",
					vertical
				}
			};
			this.SendObsRequest("movewebcam", data, null, null, 0);
		}

		// Token: 0x0600184C RID: 6220 RVA: 0x00010777 File Offset: 0x0000E977
		public void Shutdown()
		{
			if (this.mIsStreaming)
			{
				this.StopStream();
			}
			if (StreamManager.mObsCommandQueue != null)
			{
				this.mIsObsRunning = false;
				this.mIsStreamStarted = false;
				this.SendObsRequest("close", null, "CloseSuccess", "CloseFailed", 0);
			}
		}

		// Token: 0x0600184D RID: 6221 RVA: 0x000107B3 File Offset: 0x0000E9B3
		public static void CloseSuccess(string _)
		{
			StreamManager.Instance = null;
		}

		// Token: 0x0600184E RID: 6222 RVA: 0x000107BB File Offset: 0x0000E9BB
		public static void CloseFailed()
		{
			Utils.KillCurrentOemProcessByName("HD-OBS", null);
			StreamManager.Instance = null;
		}

		// Token: 0x0600184F RID: 6223 RVA: 0x00090454 File Offset: 0x0008E654
		public static void StopOBS()
		{
			StreamManager.Instance.mStoppingOBS = true;
			StreamManager.sStopInitOBSQueue = true;
			StreamManager.Instance.Shutdown();
			int num = 0;
			while (Process.GetProcessesByName("HD-OBS").Length != 0 && num < 20)
			{
				Thread.Sleep(500);
				num++;
			}
			if (num == 20)
			{
				Logger.Info("Killing hd-obs as normal close failed");
				StreamManager.CloseFailed();
			}
		}

		// Token: 0x06001850 RID: 6224 RVA: 0x000107CE File Offset: 0x0000E9CE
		public void SaveReplayBuffer()
		{
			this.SendObsRequest("savereplaybuffer", null, null, null, 0);
		}

		// Token: 0x06001851 RID: 6225 RVA: 0x000107DF File Offset: 0x0000E9DF
		public void ReplayBufferSaved()
		{
			this.SendStatus("replaybuffersaved", null);
		}

		// Token: 0x06001852 RID: 6226 RVA: 0x000107ED File Offset: 0x0000E9ED
		public void SendObsRequest(string request, Dictionary<string, string> data, string responseCallback, string failureCallback, int pauseTime)
		{
			this.SendObsRequest(request, data, responseCallback, failureCallback, pauseTime, true);
		}

		// Token: 0x06001853 RID: 6227 RVA: 0x000904B4 File Offset: 0x0008E6B4
		public void SendObsRequest(string request, Dictionary<string, string> data, string responseCallback, string failureCallback, int pauseTime, bool waitForInit)
		{
			Logger.Info("got obs request: " + request);
			if (data != null && !data.ContainsKey("randomVal"))
			{
				data.Add("randomVal", "0");
			}
			new Thread(delegate()
			{
				StreamManager.ObsCommand item = new StreamManager.ObsCommand(request, data, responseCallback, failureCallback, pauseTime);
				object obj = this.mInitOBSLock;
				lock (obj)
				{
					if (!this.mIsInitCalled)
					{
						this.InitObs();
					}
				}
				if (StreamManager.mObsCommandQueue == null)
				{
					StreamManager.mObsCommandQueue = new Queue<StreamManager.ObsCommand>();
				}
				if (waitForInit)
				{
					obj = this.mInitOBSLock;
					lock (obj)
					{
						object obj2 = this.mObsCommandQueueObject;
						lock (obj2)
						{
							StreamManager.mObsCommandQueue.Enqueue(item);
							this.mObsCommandEventHandle.Set();
							return;
						}
					}
				}
				obj = this.mObsCommandQueueObject;
				lock (obj)
				{
					StreamManager.mObsCommandQueue.Enqueue(item);
					this.mObsCommandEventHandle.Set();
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06001854 RID: 6228 RVA: 0x0009055C File Offset: 0x0008E75C
		private string SendObsRequestInternal(string request, Dictionary<string, string> data)
		{
			Logger.Info("waiting to send request: " + request);
			object obj = this.mObsSendRequestObject;
			string result;
			lock (obj)
			{
				string text = string.Empty;
				if (this.mIsObsRunning)
				{
					text = BstHttpClient.Post(string.Format(CultureInfo.InvariantCulture, "{0}:{1}/{2}", new object[]
					{
						StreamManager.ObsServerBaseURL,
						StreamManager.ObsServerPort,
						request
					}), data, null, false, "Android", 0, 1, 0, false);
				}
				result = text;
			}
			return result;
		}

		// Token: 0x06001855 RID: 6229 RVA: 0x000905F0 File Offset: 0x0008E7F0
		private void ProcessObsCommandQueue()
		{
			while (this.mIsObsRunning)
			{
				this.mObsCommandEventHandle.WaitOne();
				while (StreamManager.mObsCommandQueue.Count != 0)
				{
					object obj = this.mObsCommandQueueObject;
					StreamManager.ObsCommand obsCommand;
					lock (obj)
					{
						if (StreamManager.mObsCommandQueue.Count == 0)
						{
							break;
						}
						obsCommand = StreamManager.mObsCommandQueue.Dequeue();
					}
					string text = string.Empty;
					try
					{
						text = this.SendObsRequestInternal(obsCommand.mRequest, obsCommand.mData);
						Logger.Info("Got response {0} for {1}", new object[]
						{
							text,
							obsCommand.mRequest
						});
						if (obsCommand.mResponseCallback != null)
						{
							base.GetType().GetMethod(obsCommand.mResponseCallback, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).Invoke(this, new object[]
							{
								text
							});
						}
					}
					catch (Exception ex)
					{
						Logger.Error("Exception when sending " + obsCommand.mRequest);
						Logger.Error(ex.ToString());
						try
						{
							if (obsCommand.mFailureCallback != null)
							{
								base.GetType().GetMethod(obsCommand.mFailureCallback, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).Invoke(this, new object[0]);
							}
						}
						catch (Exception ex2)
						{
							Logger.Error("Error in failure call back for call {} and error {1}", new object[]
							{
								obsCommand.mFailureCallback,
								ex2
							});
						}
					}
					Thread.Sleep(obsCommand.mPauseTime);
				}
			}
		}

		// Token: 0x06001856 RID: 6230 RVA: 0x00090764 File Offset: 0x0008E964
		public void Init(string appHandle, string pid)
		{
			Logger.Info("App Handle : {0} and Process Id : {1}", new object[]
			{
				appHandle,
				pid
			});
			if (string.IsNullOrEmpty(this.mAppHandle) && string.IsNullOrEmpty(this.mAppPid))
			{
				this.mAppHandle = appHandle;
				this.mAppPid = pid;
			}
		}

		// Token: 0x06001857 RID: 6231 RVA: 0x000107FD File Offset: 0x0000E9FD
		private double GetWidthFromHeight(double height)
		{
			return (height - (double)this.heightDiff) * this.mAspectRatio.DoubleValue + (double)this.widthDiff;
		}

		// Token: 0x06001858 RID: 6232 RVA: 0x000907B4 File Offset: 0x0008E9B4
		public static void GetStreamConfig(out string handle, out string pid)
		{
			try
			{
				MainWindow activatedWindow = null;
				if (BlueStacksUIUtils.DictWindows.Count > 0)
				{
					activatedWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
				}
				handle = activatedWindow.mFrontendHandler.mFrontendHandle.ToString();
				activatedWindow.Dispatcher.Invoke(new Action(delegate()
				{
					activatedWindow.RestrictWindowResize(true);
				}), new object[0]);
				Process currentProcess = Process.GetCurrentProcess();
				pid = currentProcess.Id.ToString(CultureInfo.InvariantCulture);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to get window handle and process id... Err : " + ex.ToString());
				string text;
				pid = (text = null);
				handle = text;
			}
		}

		// Token: 0x06001859 RID: 6233 RVA: 0x0009087C File Offset: 0x0008EA7C
		public void ShutDownForcefully()
		{
			try
			{
				StreamManager.killOBSForcelly();
				this.mIsObsRunning = false;
				StreamManager.Instance.mStoppingOBS = true;
				StreamManager.mObsCommandQueue.Clear();
				StreamManager.Instance = null;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in shutdown obs : {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x0600185A RID: 6234 RVA: 0x0001081C File Offset: 0x0000EA1C
		protected virtual void Dispose(bool disposing)
		{
			if (!this.disposedValue)
			{
				Browser browser = this.mBrowser;
				if (browser != null)
				{
					browser.Dispose();
				}
				EventWaitHandle eventWaitHandle = this.mObsCommandEventHandle;
				if (eventWaitHandle != null)
				{
					eventWaitHandle.Close();
				}
				this.disposedValue = true;
			}
		}

		// Token: 0x0600185B RID: 6235 RVA: 0x000908DC File Offset: 0x0008EADC
		~StreamManager()
		{
			this.Dispose(false);
		}

		// Token: 0x0600185C RID: 6236 RVA: 0x00010851 File Offset: 0x0000EA51
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x04000F47 RID: 3911
		private static Queue<StreamManager.ObsCommand> mObsCommandQueue;

		// Token: 0x04000F48 RID: 3912
		private object mObsCommandQueueObject = new object();

		// Token: 0x04000F49 RID: 3913
		private object mObsSendRequestObject = new object();

		// Token: 0x04000F4A RID: 3914
		private object mInitOBSLock = new object();

		// Token: 0x04000F4B RID: 3915
		private EventWaitHandle mObsCommandEventHandle;

		// Token: 0x04000F54 RID: 3924
		private bool mIsStreamStarted;

		// Token: 0x04000F55 RID: 3925
		private string mFailureReason = "";

		// Token: 0x04000F56 RID: 3926
		private static int mMicVolume;

		// Token: 0x04000F57 RID: 3927
		internal static string mSelectedCamera;

		// Token: 0x04000F58 RID: 3928
		internal static string mSelectedMic = string.Empty;

		// Token: 0x04000F59 RID: 3929
		internal static bool mIsWebcamDisabled = true;

		// Token: 0x04000F5A RID: 3930
		internal static bool mIsMicDisabled = true;

		// Token: 0x04000F5B RID: 3931
		internal static Dictionary<string, string> mDictCameraDetails = new Dictionary<string, string>();

		// Token: 0x04000F5C RID: 3932
		internal static Dictionary<string, string> mDictMicDetails = new Dictionary<string, string>();

		// Token: 0x04000F5D RID: 3933
		internal static Dictionary<string, string> mDictLastCameraPosition = new Dictionary<string, string>();

		// Token: 0x04000F64 RID: 3940
		private static int mSystemVolume;

		// Token: 0x04000F67 RID: 3943
		private string mAppHandle = "";

		// Token: 0x04000F68 RID: 3944
		private string mAppPid = "";

		// Token: 0x04000F69 RID: 3945
		internal int mStreamWidth;

		// Token: 0x04000F6A RID: 3946
		internal int mStreamHeight;

		// Token: 0x04000F6D RID: 3949
		private object stoppingOBSLock = new object();

		// Token: 0x04000F6E RID: 3950
		private Browser mBrowser;

		// Token: 0x04000F74 RID: 3956
		private int heightDiff;

		// Token: 0x04000F75 RID: 3957
		private int widthDiff = 14;

		// Token: 0x04000F76 RID: 3958
		internal Fraction mAspectRatio = new Fraction(16L, 9L);

		// Token: 0x04000F77 RID: 3959
		private MainWindow mWindow;

		// Token: 0x04000F79 RID: 3961
		private string mLastVideoFilePath;

		// Token: 0x04000F7A RID: 3962
		private int mObsRetryCount = 2;

		// Token: 0x04000F7B RID: 3963
		private bool disposedValue;

		// Token: 0x02000299 RID: 665
		private class ObsCommand
		{
			// Token: 0x06001860 RID: 6240 RVA: 0x00010870 File Offset: 0x0000EA70
			public ObsCommand(string request, Dictionary<string, string> data, string responseCallback, string failureCallback, int pauseTime)
			{
				this.mRequest = request;
				this.mData = data;
				this.mResponseCallback = responseCallback;
				this.mFailureCallback = failureCallback;
				this.mPauseTime = pauseTime;
			}

			// Token: 0x04000F7C RID: 3964
			public string mRequest;

			// Token: 0x04000F7D RID: 3965
			public Dictionary<string, string> mData;

			// Token: 0x04000F7E RID: 3966
			public string mResponseCallback;

			// Token: 0x04000F7F RID: 3967
			public string mFailureCallback;

			// Token: 0x04000F80 RID: 3968
			public int mPauseTime;
		}
	}
}
