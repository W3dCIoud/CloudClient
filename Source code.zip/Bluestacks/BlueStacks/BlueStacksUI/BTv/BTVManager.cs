﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Threading;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI.BTv
{
	// Token: 0x0200028C RID: 652
	internal sealed class BTVManager : IDisposable
	{
		// Token: 0x06001771 RID: 6001 RVA: 0x000100C7 File Offset: 0x0000E2C7
		private BTVManager()
		{
		}

		// Token: 0x170002FD RID: 765
		// (get) Token: 0x06001772 RID: 6002 RVA: 0x0008C52C File Offset: 0x0008A72C
		public static BTVManager Instance
		{
			get
			{
				if (BTVManager.instance == null)
				{
					object obj = BTVManager.syncRoot;
					lock (obj)
					{
						if (BTVManager.instance == null)
						{
							BTVManager.instance = new BTVManager();
						}
					}
				}
				return BTVManager.instance;
			}
		}

		// Token: 0x170002FE RID: 766
		// (set) Token: 0x06001773 RID: 6003 RVA: 0x000100DA File Offset: 0x0000E2DA
		public static bool sWritingToFile
		{
			set
			{
				HTTPServer.FileWriteComplete = !value;
			}
		}

		// Token: 0x06001774 RID: 6004 RVA: 0x0008C584 File Offset: 0x0008A784
		public void StartBlueStacksTV()
		{
			using (Process process = new Process())
			{
				string installDir = RegistryStrings.InstallDir;
				process.StartInfo.FileName = Path.Combine(installDir, "BlueStacksTV.exe");
				process.StartInfo.Arguments = "-u";
				process.Start();
				Thread.Sleep(1000);
				new Thread(new ThreadStart(this.StartPingBTVThread))
				{
					IsBackground = true
				}.Start();
			}
		}

		// Token: 0x06001775 RID: 6005 RVA: 0x00005D29 File Offset: 0x00003F29
		private void BtvWindow_Closing(object sender, CancelEventArgs e)
		{
		}

		// Token: 0x06001776 RID: 6006 RVA: 0x0008C610 File Offset: 0x0008A810
		internal static void BringToFront(CustomWindow win)
		{
			try
			{
				win.Dispatcher.Invoke(new Action(delegate()
				{
					if (win.WindowState == WindowState.Minimized)
					{
						win.WindowState = WindowState.Normal;
					}
					win.Visibility = Visibility.Visible;
					win.Show();
					win.BringIntoView();
					if (!win.Topmost)
					{
						win.Topmost = true;
						win.Topmost = false;
					}
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Error("An error was triggered in bringing BTv downloader to front", new object[]
				{
					ex.Message
				});
			}
		}

		// Token: 0x06001777 RID: 6007 RVA: 0x0008C67C File Offset: 0x0008A87C
		public static void ReportObsErrorHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			Logger.Info("Got ReportObsErrorHandler");
			HTTPUtils.ParseRequest(req);
			try
			{
				StreamManager.Instance.ReportObsError("obs_error");
				StreamManager.Instance = null;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ReportObsHandler");
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x06001778 RID: 6008 RVA: 0x000100E5 File Offset: 0x0000E2E5
		private void CancelBTvDownload(object sender, EventArgs e)
		{
			Logger.Info("User cancelled BTV download");
			this.sDownloading = false;
			if (this.sDownloader != null)
			{
				this.sDownloader.AbortDownload();
				if (BTVManager.IsBTVInstalled())
				{
					Directory.Delete(RegistryStrings.ObsDir, true);
				}
			}
		}

		// Token: 0x06001779 RID: 6009 RVA: 0x0008C6D8 File Offset: 0x0008A8D8
		private void CancelDownloadConfirmation(object sender, EventArgs e)
		{
			MainWindow owner = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				owner = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_DOWNLOAD_IN_PROGRESS", "");
			BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_BTV_DOWNLOAD_CANCEL", "");
			customMessageWindow.AddButton(ButtonColors.Red, "STRING_CANCEL", new EventHandler(this.CancelBTvDownload), null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_CONTINUE", null, null, false, null);
			customMessageWindow.Owner = owner;
			customMessageWindow.ShowDialog();
		}

		// Token: 0x0600177A RID: 6010 RVA: 0x0001011D File Offset: 0x0000E31D
		internal static bool IsBTVInstalled()
		{
			return Directory.Exists(RegistryStrings.BtvDir) && Directory.Exists(RegistryStrings.ObsDir);
		}

		// Token: 0x0600177B RID: 6011 RVA: 0x0008C76C File Offset: 0x0008A96C
		internal static bool IsDirectXComponentsInstalled()
		{
			string systemDirectory = Environment.SystemDirectory;
			foreach (string path in new string[]
			{
				"D3DX10_43.DLL",
				"D3D10_1.DLL",
				"DXGI.DLL",
				"D3DCompiler_43.dll"
			})
			{
				if (!File.Exists(Path.Combine(systemDirectory, path)))
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x0600177C RID: 6012 RVA: 0x0008C7CC File Offset: 0x0008A9CC
		public void MaybeDownloadAndLaunchBTv(MainWindow parentWindow)
		{
			BTVManager.<>c__DisplayClass25_0 CS$<>8__locals1 = new BTVManager.<>c__DisplayClass25_0();
			CS$<>8__locals1.<>4__this = this;
			CS$<>8__locals1.parentWindow = parentWindow;
			if (BTVManager.IsBTVInstalled())
			{
				this.StartBlueStacksTV();
				return;
			}
			if (this.sDownloading && this.sWindow != null)
			{
				BTVManager.BringToFront(this.sWindow);
				return;
			}
			ExtensionPopupControl btvExtPopup = new ExtensionPopupControl();
			btvExtPopup.LoadExtensionPopupFromFolder("BTVExtensionPopup");
			btvExtPopup.DownloadClicked += delegate(object o, EventArgs e)
			{
				BlueStacksUIUtils.CloseContainerWindow(btvExtPopup);
				CS$<>8__locals1.<>4__this.sDownloading = true;
				CS$<>8__locals1.<>4__this.sWindow = new CustomMessageWindow();
				BlueStacksUIBinding.Bind(CS$<>8__locals1.<>4__this.sWindow.TitleTextBlock, "STRING_BTV_DOWNLOAD", "");
				BlueStacksUIBinding.Bind(CS$<>8__locals1.<>4__this.sWindow.BodyTextBlock, "STRING_BTV_INSTALL_WAIT", "");
				BlueStacksUIBinding.Bind(CS$<>8__locals1.<>4__this.sWindow.BodyWarningTextBlock, "STRING_BTV_WARNING", "");
				CS$<>8__locals1.<>4__this.sWindow.AddButton(ButtonColors.Blue, "STRING_CANCEL", new EventHandler(CS$<>8__locals1.<>4__this.CancelDownloadConfirmation), null, false, null);
				CS$<>8__locals1.<>4__this.sWindow.BodyWarningTextBlock.Visibility = Visibility.Visible;
				CS$<>8__locals1.<>4__this.sWindow.ProgressBarEnabled = true;
				CS$<>8__locals1.<>4__this.sWindow.IsWindowMinizable = true;
				CS$<>8__locals1.<>4__this.sWindow.IsWindowClosable = false;
				CS$<>8__locals1.<>4__this.sWindow.ImageName = "BTVTopBar";
				CS$<>8__locals1.<>4__this.sWindow.ShowInTaskbar = true;
				CS$<>8__locals1.<>4__this.sWindow.Owner = CS$<>8__locals1.parentWindow;
				CS$<>8__locals1.<>4__this.sWindow.IsShowGLWindow = true;
				CS$<>8__locals1.<>4__this.sWindow.Show();
				ThreadStart start;
				if ((start = CS$<>8__locals1.<>9__1) == null)
				{
					start = (CS$<>8__locals1.<>9__1 = delegate()
					{
						if (!string.IsNullOrEmpty(RegistryManager.Instance.BtvDevServer))
						{
							BTVManager.sBTvUrl = RegistryManager.Instance.BtvDevServer;
						}
						string redirectedUrl = BTVManager.GetRedirectedUrl(BTVManager.sBTvUrl);
						if (redirectedUrl == null)
						{
							Logger.Error("The download url was null");
							return;
						}
						string fileName = Path.GetFileName(new Uri(redirectedUrl).LocalPath);
						string downloadPath = Path.Combine(Path.GetTempPath(), fileName);
						CS$<>8__locals1.<>4__this.sDownloader = new LegacyDownloader(3, redirectedUrl, downloadPath);
						LegacyDownloader legacyDownloader = CS$<>8__locals1.<>4__this.sDownloader;
						LegacyDownloader.UpdateProgressCallback updateProgressCb;
						if ((updateProgressCb = CS$<>8__locals1.<>9__2) == null)
						{
							updateProgressCb = (CS$<>8__locals1.<>9__2 = delegate(int percent)
							{
								CS$<>8__locals1.<>4__this.sWindow.Dispatcher.Invoke(new Action(delegate()
								{
									CS$<>8__locals1.<>4__this.sWindow.CustomProgressBar.Value = (double)percent;
								}), new object[0]);
							});
						}
						legacyDownloader.Download(updateProgressCb, delegate(string filePath)
						{
							Dispatcher dispatcher = CS$<>8__locals1.<>4__this.sWindow.Dispatcher;
							Action method;
							if ((method = CS$<>8__locals1.<>9__6) == null)
							{
								method = (CS$<>8__locals1.<>9__6 = delegate()
								{
									CS$<>8__locals1.<>4__this.sWindow.CustomProgressBar.Value = 100.0;
									CS$<>8__locals1.<>4__this.sWindow.Close();
								});
							}
							dispatcher.Invoke(method, new object[0]);
							Logger.Info("Successfully downloaded BlueStacks TV");
							CS$<>8__locals1.<>4__this.sDownloading = false;
							BTVManager.ExtractBTv(downloadPath);
							Dispatcher dispatcher2 = CS$<>8__locals1.parentWindow.Dispatcher;
							Action method2;
							if ((method2 = CS$<>8__locals1.<>9__7) == null)
							{
								method2 = (CS$<>8__locals1.<>9__7 = delegate()
								{
									CS$<>8__locals1.parentWindow.mTopBar.mBtvButton.ImageName = "btv";
								});
							}
							dispatcher2.Invoke(method2, new object[0]);
						}, delegate(Exception ex)
						{
							Logger.Error("Failed to download file: {0}. err: {1}", new object[]
							{
								downloadPath,
								ex.Message
							});
						}, null, null, null);
					});
				}
				new Thread(start)
				{
					IsBackground = true
				}.Start();
			};
			btvExtPopup.Height = CS$<>8__locals1.parentWindow.ActualHeight * 0.8;
			btvExtPopup.Width = btvExtPopup.Height * 16.0 / 9.0;
			new ContainerWindow(CS$<>8__locals1.parentWindow, btvExtPopup, (double)((int)btvExtPopup.Width), (double)((int)btvExtPopup.Height), false, true);
		}

		// Token: 0x0600177D RID: 6013 RVA: 0x0008C8DC File Offset: 0x0008AADC
		internal static void ReportOpenGLCaptureError(HttpListenerRequest req, HttpListenerResponse res)
		{
			Logger.Info("Got open gl CaptureError");
			try
			{
				StreamManager.Instance.ReportObsError("opengl_capture_error");
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ReportObsHandler");
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x0600177E RID: 6014 RVA: 0x0008C92C File Offset: 0x0008AB2C
		internal static void ReportCaptureError(HttpListenerRequest req, HttpListenerResponse res)
		{
			Logger.Info("Got ReportCaptureError");
			HTTPUtils.ParseRequest(req);
			try
			{
				StreamManager.Instance.ReportObsError("capture_error");
				StreamManager.Instance = null;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ReportObsHandler");
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x0600177F RID: 6015 RVA: 0x0008C988 File Offset: 0x0008AB88
		internal static void ObsStatusHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			Logger.Info("Got ObsStatus {0} request from {1}", new object[]
			{
				req.HttpMethod,
				req.RemoteEndPoint.ToString()
			});
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (requestData.Data.Count > 0 && requestData.Data.AllKeys[0] == "Error")
				{
					if (!StreamManager.sStopInitOBSQueue)
					{
						if (string.Equals(requestData.Data[0], "OBSAlreadyRunning", StringComparison.InvariantCulture))
						{
							StreamManager.sStopInitOBSQueue = true;
						}
						if (StreamManager.Instance != null)
						{
							new Thread(delegate()
							{
								StreamManager.Instance.ReportObsError(requestData.Data[0]);
							})
							{
								IsBackground = true
							}.Start();
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ObsStatus");
				Logger.Error(ex.ToString());
			}
		}

		// Token: 0x06001780 RID: 6016 RVA: 0x0008CA78 File Offset: 0x0008AC78
		internal static string GetRedirectedUrl(string url)
		{
			HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
			httpWebRequest.Method = "GET";
			httpWebRequest.AllowAutoRedirect = true;
			string str = "Bluestacks/" + RegistryManager.Instance.ClientVersion;
			httpWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36 " + str;
			httpWebRequest.Headers.Add("x_oem", RegistryManager.Instance.Oem);
			httpWebRequest.Headers.Set("x_email", RegistryManager.Instance.RegisteredEmail);
			httpWebRequest.Headers.Add("x_guid", RegistryManager.Instance.UserGuid);
			httpWebRequest.Headers.Add("x_prod_ver", RegistryManager.Instance.Version);
			httpWebRequest.Headers.Add("x_home_app_ver", RegistryManager.Instance.ClientVersion);
			string result;
			try
			{
				using (HttpWebResponse httpWebResponse = httpWebRequest.GetResponse() as HttpWebResponse)
				{
					using (Stream responseStream = httpWebResponse.GetResponseStream())
					{
						using (StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8))
						{
							JObject jobject = JObject.Parse(streamReader.ReadToEnd());
							if (jobject["success"].ToObject<bool>())
							{
								result = jobject["file_url"].ToString();
							}
							else
							{
								result = null;
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in getting redirected url for BTV " + ex.ToString());
				result = null;
			}
			return result;
		}

		// Token: 0x06001781 RID: 6017 RVA: 0x0008CC1C File Offset: 0x0008AE1C
		internal static bool ExtractBTv(string downloadPath)
		{
			try
			{
				if (File.Exists(downloadPath))
				{
					if (MiscUtils.Extract7Zip(downloadPath, RegistryManager.Instance.UserDefinedDir) == 0)
					{
						return true;
					}
					Logger.Error("Could not extract BTv zip file.");
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Could not extract BTv zip file. Error: " + ex.ToString());
			}
			return false;
		}

		// Token: 0x06001782 RID: 6018 RVA: 0x0008CC80 File Offset: 0x0008AE80
		public void StartPingBTVThread()
		{
			object obj = this.sPingBTVLock;
			lock (obj)
			{
				Logger.Info("Starting btv ping thread");
				for (;;)
				{
					this.PingBTV();
					if (this.sStopPingBTVThread)
					{
						break;
					}
					Thread.Sleep(5000);
				}
			}
		}

		// Token: 0x06001783 RID: 6019 RVA: 0x0001013A File Offset: 0x0000E33A
		public void ShowStreamWindow()
		{
			if (!ProcessUtils.FindProcessByName("BlueStacksTV"))
			{
				this.StartBlueStacksTV();
				return;
			}
			BTVManager.SendBTVAsyncRequest("showstreamwindow", null);
		}

		// Token: 0x06001784 RID: 6020 RVA: 0x0001015A File Offset: 0x0000E35A
		public void HideStreamWindow()
		{
			if (ProcessUtils.FindProcessByName("BlueStacksTV"))
			{
				BTVManager.SendBTVAsyncRequest("hidestreamwindow", null);
			}
		}

		// Token: 0x06001785 RID: 6021 RVA: 0x00010173 File Offset: 0x0000E373
		public void HideStreamWindowFromTaskbar()
		{
			BTVManager.SendBTVAsyncRequest("hidestreamwindowfromtaskbar", null);
		}

		// Token: 0x06001786 RID: 6022 RVA: 0x0008CCD8 File Offset: 0x0008AED8
		public static void GetStreamDimensionInfo(out int startX, out int startY, out int width, out int height)
		{
			Point p = default(Point);
			MainWindow activatedWindow = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				activatedWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			activatedWindow.Dispatcher.Invoke(new Action(delegate()
			{
				p = activatedWindow.mFrontendGrid.TranslatePoint(new Point(0.0, 0.0), activatedWindow.mFrontendGrid);
			}), new object[0]);
			startX = Convert.ToInt32(p.X) * SystemUtils.GetDPI() / 96;
			startY = Convert.ToInt32(p.Y) * SystemUtils.GetDPI() / 96;
			width = (int)activatedWindow.mFrontendGrid.ActualWidth * SystemUtils.GetDPI() / 96;
			height = (int)activatedWindow.mFrontendGrid.ActualHeight * SystemUtils.GetDPI() / 96;
		}

		// Token: 0x06001787 RID: 6023 RVA: 0x0008CDB4 File Offset: 0x0008AFB4
		public void PingBTV()
		{
			bool flag = false;
			bool flag2 = false;
			try
			{
				string text = BTVManager.SendBTVRequest("ping", null);
				JArray.Parse(text);
				JObject jobject = JObject.Parse(text[0].ToString(CultureInfo.InvariantCulture));
				if (jobject["success"].ToObject<bool>())
				{
					flag = jobject["recording"].ToObject<bool>();
					flag2 = jobject["streaming"].ToObject<bool>();
				}
				Logger.Info("Ping BTV response recording: {0}, streaming: {1}", new object[]
				{
					flag,
					flag2
				});
				this.sStopPingBTVThread = false;
			}
			catch (Exception ex)
			{
				this.sStopPingBTVThread = true;
				Logger.Error("PingBTV : {0}", new object[]
				{
					ex.Message
				});
			}
			this.sRecording = flag;
			this.sStreaming = flag2;
		}

		// Token: 0x06001788 RID: 6024 RVA: 0x0008CE94 File Offset: 0x0008B094
		public void SetFrontendPosition(int width, int height, bool isPortrait)
		{
			if (ProcessUtils.FindProcessByName("BlueStacksTV"))
			{
				Dictionary<string, string> <<EMPTY_NAME>> = new Dictionary<string, string>
				{
					{
						"width",
						width.ToString(CultureInfo.InvariantCulture)
					},
					{
						"height",
						height.ToString(CultureInfo.InvariantCulture)
					},
					{
						"isPortrait",
						isPortrait.ToString(CultureInfo.InvariantCulture)
					}
				};
				BTVManager.SendBTVRequest("setfrontendposition", <<EMPTY_NAME>>);
			}
		}

		// Token: 0x06001789 RID: 6025 RVA: 0x0008CF04 File Offset: 0x0008B104
		public void WindowResized()
		{
			if (ProcessUtils.FindProcessByName("BlueStacksTV"))
			{
				try
				{
					BTVManager.SendBTVRequest("windowresized", null);
				}
				catch (Exception ex)
				{
					Logger.Error("{0}", new object[]
					{
						ex
					});
				}
			}
		}

		// Token: 0x0600178A RID: 6026 RVA: 0x00010180 File Offset: 0x0000E380
		public void StreamStarted()
		{
			BTVManager.sWritingToFile = true;
			this.sRecording = true;
			this.sStreaming = true;
		}

		// Token: 0x0600178B RID: 6027 RVA: 0x00010196 File Offset: 0x0000E396
		public void StreamStopped()
		{
			BTVManager.sWritingToFile = false;
			this.sStreaming = false;
			this.sRecording = false;
			BTVManager.RestrictWindowResize(false);
		}

		// Token: 0x0600178C RID: 6028 RVA: 0x000101B2 File Offset: 0x0000E3B2
		public void RecordStarted()
		{
			BTVManager.sWritingToFile = true;
			this.sRecording = true;
			this.sWasRecording = true;
		}

		// Token: 0x0600178D RID: 6029 RVA: 0x0008CF54 File Offset: 0x0008B154
		public void SetConfig()
		{
			int num;
			int num2;
			int num3;
			int num4;
			BTVManager.GetStreamDimensionInfo(out num, out num2, out num3, out num4);
			Dictionary<string, string> <<EMPTY_NAME>> = new Dictionary<string, string>
			{
				{
					"startX",
					num.ToString(CultureInfo.InvariantCulture)
				},
				{
					"startY",
					num2.ToString(CultureInfo.InvariantCulture)
				},
				{
					"width",
					num3.ToString(CultureInfo.InvariantCulture)
				},
				{
					"height",
					num4.ToString(CultureInfo.InvariantCulture)
				}
			};
			BTVManager.SendBTVRequest("setconfig", <<EMPTY_NAME>>);
		}

		// Token: 0x0600178E RID: 6030 RVA: 0x000101C8 File Offset: 0x0000E3C8
		public void RecordStopped()
		{
			BTVManager.sWritingToFile = false;
			this.sRecording = false;
			BTVManager.RestrictWindowResize(false);
		}

		// Token: 0x0600178F RID: 6031 RVA: 0x000101DD File Offset: 0x0000E3DD
		public void SendTabChangeData(string[] tabChangedData)
		{
			new Thread(delegate()
			{
				Dictionary<string, string> <<EMPTY_NAME>> = new Dictionary<string, string>
				{
					{
						"type",
						tabChangedData[0]
					},
					{
						"name",
						tabChangedData[1]
					},
					{
						"data",
						tabChangedData[2]
					}
				};
				BTVManager.SendBTVRequest("tabchangeddata", <<EMPTY_NAME>>);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06001790 RID: 6032 RVA: 0x0008CFE0 File Offset: 0x0008B1E0
		public static void ReplayBufferSaved()
		{
			MainWindow mainWindow = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				mainWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			mainWindow.Dispatcher.Invoke(new Action(delegate()
			{
				SaveFileDialog saveFileDialog = new SaveFileDialog
				{
					Filter = "Flash Video (*.flv)|*.flv",
					FilterIndex = 1,
					RestoreDirectory = true,
					FileName = "Replay"
				};
				if (saveFileDialog.ShowDialog() == DialogResult.OK)
				{
					string fileName = saveFileDialog.FileName;
					string path = "replay.flv";
					File.Copy(Path.Combine(RegistryManager.Instance.ClientInstallDir, path), fileName);
				}
			}), new object[0]);
		}

		// Token: 0x06001791 RID: 6033 RVA: 0x00010207 File Offset: 0x0000E407
		public void Stop()
		{
			if (this.sStreaming || this.sRecording)
			{
				BTVManager.SendBTVRequest("sessionswitch", null);
				this.sWasRecording = false;
			}
		}

		// Token: 0x06001792 RID: 6034 RVA: 0x0001022C File Offset: 0x0000E42C
		public void CloseBTV()
		{
			this.sWasRecording = false;
		}

		// Token: 0x06001793 RID: 6035 RVA: 0x00010235 File Offset: 0x0000E435
		public void CheckNewFiltersAvailable()
		{
			BTVManager.SendBTVRequest("checknewfilters", null);
		}

		// Token: 0x06001794 RID: 6036 RVA: 0x00010243 File Offset: 0x0000E443
		public static void SendBTVAsyncRequest(string request, Dictionary<string, string> data)
		{
			new Thread(delegate()
			{
				Logger.Info("Sending btv async request");
				BTVManager.SendBTVRequest(request, data);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06001795 RID: 6037 RVA: 0x00010274 File Offset: 0x0000E474
		public static string SendBTVRequest(string _1, Dictionary<string, string> _2)
		{
			return "";
		}

		// Token: 0x06001796 RID: 6038 RVA: 0x0008D040 File Offset: 0x0008B240
		public static void RestrictWindowResize(bool enable)
		{
			MainWindow activatedWindow = null;
			if (BlueStacksUIUtils.DictWindows.Count > 0)
			{
				activatedWindow = BlueStacksUIUtils.DictWindows.Values.First<MainWindow>();
			}
			activatedWindow.Dispatcher.Invoke(new Action(delegate()
			{
				activatedWindow.RestrictWindowResize(enable);
			}), new object[0]);
		}

		// Token: 0x06001797 RID: 6039 RVA: 0x0008D0A8 File Offset: 0x0008B2A8
		public void RecordVideoOfApp()
		{
			if (StreamManager.Instance == null)
			{
				StreamManager.Instance = new StreamManager(BlueStacksUIUtils.DictWindows.Values.First<MainWindow>());
			}
			string text;
			string pid;
			StreamManager.GetStreamConfig(out text, out pid);
			StreamManager.Instance.Init(text, pid);
			StreamManager.Instance.SetHwnd(text);
			StreamManager.Instance.EnableVideoRecording(true);
			StreamManager.Instance.StartObs();
			StreamManager.Instance.StartRecordForVideo();
		}

		// Token: 0x06001798 RID: 6040 RVA: 0x0001027B File Offset: 0x0000E47B
		private void StopRecordVideo()
		{
			StreamManager.Instance.StopRecord();
		}

		// Token: 0x06001799 RID: 6041 RVA: 0x00005D29 File Offset: 0x00003F29
		internal void RecordStartedVideo()
		{
		}

		// Token: 0x0600179A RID: 6042 RVA: 0x00010287 File Offset: 0x0000E487
		public void Dispose(bool disposing)
		{
			if (!this.disposedValue)
			{
				this.disposedValue = true;
			}
		}

		// Token: 0x0600179B RID: 6043 RVA: 0x0008D114 File Offset: 0x0008B314
		~BTVManager()
		{
			this.Dispose(false);
		}

		// Token: 0x0600179C RID: 6044 RVA: 0x0001029A File Offset: 0x0000E49A
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x04000F1D RID: 3869
		private static volatile BTVManager instance;

		// Token: 0x04000F1E RID: 3870
		private static object syncRoot = new object();

		// Token: 0x04000F1F RID: 3871
		public bool sStreaming;

		// Token: 0x04000F20 RID: 3872
		public static string sNetwork = "twitch";

		// Token: 0x04000F21 RID: 3873
		public bool sRecording;

		// Token: 0x04000F22 RID: 3874
		public bool sWasRecording;

		// Token: 0x04000F23 RID: 3875
		public bool sStopPingBTVThread;

		// Token: 0x04000F24 RID: 3876
		public object sPingBTVLock = new object();

		// Token: 0x04000F25 RID: 3877
		private CustomMessageWindow sWindow;

		// Token: 0x04000F26 RID: 3878
		private bool sDownloading;

		// Token: 0x04000F27 RID: 3879
		private LegacyDownloader sDownloader;

		// Token: 0x04000F28 RID: 3880
		private static string sBTvUrl = "https://cloud.bluestacks.com/bs4/btv/GetBTVFile";

		// Token: 0x04000F29 RID: 3881
		private bool disposedValue;
	}
}
