﻿using System;
using System.IO;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200007D RID: 125
	public class SearchRecommendation
	{
		// Token: 0x1700019D RID: 413
		// (get) Token: 0x0600051C RID: 1308 RVA: 0x00005639 File Offset: 0x00003839
		// (set) Token: 0x0600051D RID: 1309 RVA: 0x00005641 File Offset: 0x00003841
		public SerializableDictionary<string, string> ExtraPayload { get; set; } = new SerializableDictionary<string, string>();

		// Token: 0x1700019E RID: 414
		// (get) Token: 0x0600051E RID: 1310 RVA: 0x0000564A File Offset: 0x0000384A
		// (set) Token: 0x0600051F RID: 1311 RVA: 0x00005652 File Offset: 0x00003852
		public string IconId { get; set; }

		// Token: 0x1700019F RID: 415
		// (get) Token: 0x06000520 RID: 1312 RVA: 0x0000565B File Offset: 0x0000385B
		// (set) Token: 0x06000521 RID: 1313 RVA: 0x00005663 File Offset: 0x00003863
		public string ImagePath { get; set; } = string.Empty;

		// Token: 0x06000522 RID: 1314 RVA: 0x0001F494 File Offset: 0x0001D694
		internal void DeleteFile()
		{
			try
			{
				File.Delete(this.ImagePath);
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't delete SearchRecommendation file: " + this.ImagePath);
				Logger.Error(ex.ToString());
			}
		}
	}
}
