﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200010F RID: 271
	internal interface IControlFordimOverLay
	{
		// Token: 0x06000A98 RID: 2712
		bool Close();

		// Token: 0x170001F7 RID: 503
		// (get) Token: 0x06000A99 RID: 2713
		// (set) Token: 0x06000A9A RID: 2714
		bool IsCloseOnOverLayClick { get; set; }

		// Token: 0x06000A9B RID: 2715
		bool Show();
	}
}
