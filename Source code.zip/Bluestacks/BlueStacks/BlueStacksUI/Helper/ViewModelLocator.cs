﻿using System;
using GalaSoft.MvvmLight.Ioc;

namespace BlueStacks.BlueStacksUI.Helper
{
	// Token: 0x0200029D RID: 669
	public class ViewModelLocator
	{
		// Token: 0x06001868 RID: 6248 RVA: 0x000108CD File Offset: 0x0000EACD
		static ViewModelLocator()
		{
			SimpleIoc.Default.Register<MinimizeBlueStacksOnCloseView>();
		}
	}
}
