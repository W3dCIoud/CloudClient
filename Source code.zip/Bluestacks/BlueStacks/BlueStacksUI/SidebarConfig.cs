﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000085 RID: 133
	internal class SidebarConfig
	{
		// Token: 0x170001A2 RID: 418
		// (get) Token: 0x06000539 RID: 1337 RVA: 0x00005764 File Offset: 0x00003964
		public List<List<string>> GroupElements { get; } = new List<List<string>>();

		// Token: 0x170001A3 RID: 419
		// (get) Token: 0x0600053A RID: 1338 RVA: 0x0001FE20 File Offset: 0x0001E020
		// (set) Token: 0x0600053B RID: 1339 RVA: 0x0000576C File Offset: 0x0000396C
		public static SidebarConfig Instance
		{
			get
			{
				if (SidebarConfig.sInstance == null)
				{
					object obj = SidebarConfig.syncRoot;
					lock (obj)
					{
						if (SidebarConfig.sInstance == null)
						{
							SidebarConfig.sInstance = new SidebarConfig();
							SidebarConfig.sInstance.Init(SidebarConfig.sFilePath);
						}
					}
				}
				return SidebarConfig.sInstance;
			}
			set
			{
				SidebarConfig.sInstance = value;
			}
		}

		// Token: 0x0600053C RID: 1340 RVA: 0x0001FE88 File Offset: 0x0001E088
		private void Init(string filePath)
		{
			SidebarConfig.InitFile(filePath);
			JObject jobject = JObject.Parse(File.ReadAllText(filePath));
			int num = 0;
			foreach (JProperty jproperty in from x in jobject.Properties()
			orderby x.Name
			select x)
			{
				List<string> list = new List<string>();
				foreach (JProperty jproperty2 in jproperty.Value.ToObject<JObject>().Properties().OrderBy((JProperty x) => x.Name))
				{
					list.Add(jproperty2.Value.ToString());
				}
				this.GroupElements.Add(list);
				num++;
			}
		}

		// Token: 0x0600053D RID: 1341 RVA: 0x00005776 File Offset: 0x00003976
		private static void InitFile(string filePath)
		{
			if (!File.Exists(filePath))
			{
				SidebarConfig.InitNewFile(filePath);
			}
		}

		// Token: 0x0600053E RID: 1342 RVA: 0x00005786 File Offset: 0x00003986
		public static void InitNewFile(string filePath)
		{
			File.Copy(Path.Combine(RegistryStrings.GadgetDir, "sidebar_config.json"), filePath);
		}

		// Token: 0x040002CB RID: 715
		private static volatile SidebarConfig sInstance;

		// Token: 0x040002CC RID: 716
		private static object syncRoot = new object();

		// Token: 0x040002CD RID: 717
		public static string sFilePath = Path.Combine(RegistryStrings.GadgetDir, string.Format(CultureInfo.InvariantCulture, "SidebarConfig_{0}.json", new object[]
		{
			"Android"
		}));
	}
}
