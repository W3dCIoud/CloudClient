﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Timers;
using System.Xml;
using System.Xml.Serialization;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000170 RID: 368
	internal class PromotionManager
	{
		// Token: 0x06000E10 RID: 3600 RVA: 0x0005CAB0 File Offset: 0x0005ACB0
		internal static BootPromotion AddBootPromotion(JToken promoImage)
		{
			BootPromotion bootPromotion = new BootPromotion();
			string value = promoImage.GetValue("image_url");
			bootPromotion.Id = promoImage.GetValue("id");
			string text = string.Format(CultureInfo.InvariantCulture, "{0}_{1}", new object[]
			{
				"BootPromo",
				bootPromotion.Id
			});
			bootPromotion.Order = int.Parse(promoImage.GetValue("order"), CultureInfo.InvariantCulture);
			if (!JsonExtensions.IsNullOrEmptyBrackets(promoImage.GetValue("extra_payload")))
			{
				bootPromotion.ExtraPayload.ClearAddRange(promoImage["extra_payload"].ToSerializableDictionary<string>());
				PromotionManager.PopulateAndDownloadFavicon(bootPromotion.ExtraPayload, text + "_" + bootPromotion.Id, false);
			}
			bootPromotion.ButtonText = promoImage.GetValue("button_text");
			bootPromotion.ThemeEnabled = promoImage.GetValue("theme_enabled");
			bootPromotion.ThemeName = promoImage.GetValue("theme_name");
			bootPromotion.ImagePath = Utils.TinyDownloader(value, text, RegistryStrings.PromotionDirectory, false);
			bootPromotion.PromoBtnClickStatusText = promoImage.GetValue("promo_button_click_status_text");
			return bootPromotion;
		}

		// Token: 0x06000E11 RID: 3601 RVA: 0x0005CBC4 File Offset: 0x0005ADC4
		internal static SearchRecommendation AddSearchRecommendation(JToken searchItem)
		{
			SearchRecommendation searchRecommendation = new SearchRecommendation
			{
				IconId = searchItem.GetValue("app_icon_id")
			};
			string value = searchItem.GetValue("app_icon");
			string fileNameWithExtension = string.Format(CultureInfo.InvariantCulture, "{0}_{1}", new object[]
			{
				"recommendation",
				searchRecommendation.IconId
			});
			searchRecommendation.ImagePath = Utils.TinyDownloader(value, fileNameWithExtension, RegistryStrings.PromotionDirectory, false);
			if (!JsonExtensions.IsNullOrEmptyBrackets(searchItem.GetValue("extra_payload")))
			{
				searchRecommendation.ExtraPayload.ClearAddRange(searchItem["extra_payload"].ToSerializableDictionary<string>());
			}
			return searchRecommendation;
		}

		// Token: 0x06000E12 RID: 3602 RVA: 0x0005CC5C File Offset: 0x0005AE5C
		internal static void SendAppUsageStats()
		{
			string urlWithParams = WebHelper.GetUrlWithParams(RegistryManager.Instance.Host + "/bs3/stats/v4/usage");
			string value = AppUsageTimer.DecryptString(RegistryManager.Instance.AInfo);
			if (!string.IsNullOrEmpty(value))
			{
				Dictionary<string, string> data = new Dictionary<string, string>
				{
					{
						"usage",
						value
					}
				};
				try
				{
					BstHttpClient.Post(urlWithParams, data, null, false, string.Empty, 0, 1, 0, false);
					RegistryManager.Instance.AInfo = string.Empty;
				}
				catch (Exception ex)
				{
					Logger.Error(ex.ToString());
					Logger.Error("Post failed. url = {0}", new object[]
					{
						urlWithParams
					});
				}
			}
		}

		// Token: 0x06000E13 RID: 3603 RVA: 0x0005CD04 File Offset: 0x0005AF04
		internal static string AddDiscordClientVersionInUrl(string url)
		{
			string text = string.Empty;
			string regPath = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Discord";
			try
			{
				text = (string)Utils.GetRegistryHKCUValue(regPath, "DisplayVersion", string.Empty);
				if (string.IsNullOrEmpty(text))
				{
					text = (string)Utils.GetRegistryHKLMValue(regPath, "DisplayVersion", string.Empty);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("exception in getting discord client version.." + ex.ToString());
			}
			url += "&discord_version=";
			url += text;
			return url;
		}

		// Token: 0x06000E14 RID: 3604 RVA: 0x0005CD94 File Offset: 0x0005AF94
		private static Dictionary<string, string> GetPromotionCallData()
		{
			Dictionary<string, string> data = PromotionManager.GetInstalledAppsData();
			Dictionary<string, string> resolutionData = BlueStacksUIUtils.GetResolutionData();
			try
			{
				resolutionData.ToList<KeyValuePair<string, string>>().ForEach(delegate(KeyValuePair<string, string> kvp)
				{
					data[kvp.Key] = kvp.Value;
				});
				Logger.Info("RESOLUTION : " + data["resolution"]);
				Logger.Info("RESOLUTION TYPE : " + data["resolution_type"]);
			}
			catch (Exception ex)
			{
				Logger.Error("Merge dictionary failed. Ex : " + ex.ToString());
			}
			return data;
		}

		// Token: 0x06000E15 RID: 3605 RVA: 0x0005CE40 File Offset: 0x0005B040
		internal static Dictionary<string, string> GetInstalledAppsData()
		{
			List<AppInfo> list = new JsonParser("Android").GetAppList().ToList<AppInfo>();
			JArray jarray = new JArray();
			foreach (AppInfo appInfo in list)
			{
				JObject jobject = new JObject();
				string package = appInfo.Package;
				string name = appInfo.Name;
				jobject.Add(package, name);
				jarray.Add(jobject);
			}
			Dictionary<string, string> dictionary = new Dictionary<string, string>
			{
				{
					"installed_apps",
					jarray.ToString(Newtonsoft.Json.Formatting.None, new JsonConverter[0])
				}
			};
			dictionary.Add("all_installed_apps", Utils.GetInstalledAppDataFromAllVms());
			dictionary.Add("campaign_json", RegistryManager.Instance.CampaignJson);
			dictionary.Add("email", RegistryManager.Instance.RegisteredEmail);
			if (RegistryManager.Instance.IsClientFirstLaunch == 1)
			{
				if (RegistryManager.Instance.IsClientUpgraded)
				{
					dictionary.Add("first_boot_update", bool.TrueString);
				}
				else
				{
					dictionary.Add("first_boot", bool.TrueString);
				}
			}
			try
			{
				string path = Path.Combine(RegistryStrings.PromotionDirectory, "app_suggestion_removed");
				if (File.Exists(path))
				{
					string text = File.ReadAllText(path);
					List<string> list2 = new List<string>();
					if (!string.IsNullOrEmpty(text))
					{
						list2 = PromotionManager.DoDeserialize<List<string>>(text);
					}
					jarray = new JArray();
					foreach (string value in list2)
					{
						jarray.Add(value);
					}
					dictionary.Add("cross_promotion_closed_apps_list", jarray.ToString(Newtonsoft.Json.Formatting.None, new JsonConverter[0]));
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Error in adding cross promotion closed app list " + ex.ToString());
				if (!dictionary.ContainsKey("cross_promotion_closed_apps_list"))
				{
					dictionary.Add("cross_promotion_closed_apps_list", "[]");
				}
			}
			return dictionary;
		}

		// Token: 0x06000E16 RID: 3606 RVA: 0x0000A6B2 File Offset: 0x000088B2
		internal static void ReloadPromotionsAsync()
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				if (PromotionObject.Instance == null)
				{
					PromotionObject.LoadDataFromFile();
				}
				try
				{
					PromotionManager.SendAppUsageStats();
					PromotionManager.CheckIsUserPremium();
					JToken promotionData = PromotionManager.GetPromotionData();
					if (promotionData != null)
					{
						PromotionManager.SetBootPromotion(promotionData);
						PromotionManager.SetDiscordId(promotionData);
						PromotionManager.SetFeatures(promotionData);
						PromotionManager.SetMyAppsCrossPromotion(promotionData);
						PromotionManager.SetMyAppsBackgroundPromotion(promotionData);
						PromotionManager.SetSearchRecommendations(promotionData);
						PromotionManager.SetAppRecommendations(promotionData);
						PromotionManager.SetStartupTab(promotionData);
						PromotionManager.SetIconOrder(promotionData);
						PromotionManager.ReadQuests(promotionData, false);
						PromotionManager.PopulateAppSpecificRules(promotionData);
						PromotionManager.SetSecurityMetrics(promotionData);
						PromotionManager.SetCustomCursorRuleForApp(promotionData);
					}
					PromotionObject.Save();
					PromotionObject.Instance.PromotionLoaded();
				}
				catch (Exception ex)
				{
					Logger.Info("Error Loading Promotions" + ex.ToString());
				}
			});
		}

		// Token: 0x06000E17 RID: 3607 RVA: 0x0005D04C File Offset: 0x0005B24C
		private static JToken GetPromotionData()
		{
			JToken result = null;
			try
			{
				string text = WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
				{
					WebHelper.GetServerHost(),
					"promotions"
				}));
				text = PromotionManager.AddDiscordClientVersionInUrl(text);
				text = PromotionManager.AddSamsungStoreParamsIfPresent(text);
				string text2 = BstHttpClient.Post(text, PromotionManager.GetPromotionCallData(), null, false, Strings.CurrentDefaultVmName, 0, 1, 0, false);
				Logger.Debug("Promotion Url: " + text);
				Logger.Debug("Promotion Response: " + text2);
				result = JToken.Parse(text2);
			}
			catch (Exception ex)
			{
				Logger.Info("Error Getting PromotionData " + ex.ToString());
			}
			return result;
		}

		// Token: 0x06000E18 RID: 3608 RVA: 0x0005D100 File Offset: 0x0005B300
		private static void PopulateAppSpecificRules(JToken res)
		{
			try
			{
				if (!JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("macro_rules")))
				{
					foreach (JToken jtoken in JArray.Parse(res["macro_rules"].ToString()))
					{
						PromotionObject.Instance.AppSpecificRulesList.Add(jtoken.ToString());
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in PopulateAppSpecificRules: " + ex.ToString());
			}
		}

		// Token: 0x06000E19 RID: 3609 RVA: 0x0005D1A4 File Offset: 0x0005B3A4
		private static void SetSearchRecommendations(JToken res)
		{
			try
			{
				if (JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("search_recommendations")))
				{
					foreach (KeyValuePair<string, SearchRecommendation> keyValuePair in PromotionObject.Instance.SearchRecommendations)
					{
						keyValuePair.Value.DeleteFile();
					}
					PromotionObject.Instance.SearchRecommendations.ClearSync<string, SearchRecommendation>();
				}
				else
				{
					SerializableDictionary<string, SearchRecommendation> tempDict = new SerializableDictionary<string, SearchRecommendation>();
					foreach (JToken jtoken in JArray.Parse(res["search_recommendations"].ToString()).ToObject<List<JToken>>())
					{
						string value = jtoken.GetValue("app_icon_id");
						if (!JsonExtensions.IsNullOrEmptyBrackets(value))
						{
							SearchRecommendation searchRecommendation;
							if (PromotionObject.Instance.SearchRecommendations.ContainsKey(value))
							{
								searchRecommendation = PromotionObject.Instance.SearchRecommendations[value];
							}
							else
							{
								searchRecommendation = PromotionManager.AddSearchRecommendation(jtoken);
							}
							if (searchRecommendation != null)
							{
								tempDict[searchRecommendation.IconId] = searchRecommendation;
							}
						}
					}
					IEnumerable<string> source = from _ in PromotionObject.Instance.SearchRecommendations.Values
					select _.ImagePath;
					Func<string, bool> predicate;
					Func<string, bool> <>9__1;
					if ((predicate = <>9__1) == null)
					{
						predicate = (<>9__1 = ((string _) => !(from x in tempDict.Values
						select x.ImagePath).Contains(_)));
					}
					foreach (string path in source.Where(predicate))
					{
						try
						{
							File.Delete(path);
						}
						catch (Exception)
						{
						}
					}
					PromotionObject.Instance.SearchRecommendations.ClearAddRange(tempDict);
				}
			}
			catch (Exception ex)
			{
				PromotionObject.Instance.SearchRecommendations.ClearSync<string, SearchRecommendation>();
				Logger.Info("Error Loading Search Recommendations" + ex.ToString());
			}
		}

		// Token: 0x06000E1A RID: 3610 RVA: 0x0005D418 File Offset: 0x0005B618
		private static void SetAppRecommendations(JToken res)
		{
			try
			{
				if (JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("app_recommendations")))
				{
					foreach (AppRecommendation appRecommendation in PromotionObject.Instance.AppRecommendations.AppSuggestions)
					{
						appRecommendation.DeleteFile();
					}
					PromotionObject.Instance.AppRecommendations = new AppRecommendationSection();
				}
				else
				{
					List<AppRecommendationSection> list = JsonConvert.DeserializeObject<List<AppRecommendationSection>>(res["app_recommendations"].ToString(), Utils.GetSerializerSettings());
					if (list != null)
					{
						foreach (AppRecommendation appRecommendation2 in list[0].AppSuggestions)
						{
							if (!JsonExtensions.IsNullOrEmptyBrackets(appRecommendation2.IconId))
							{
								string icon = appRecommendation2.Icon;
								string fileNameWithExtension = string.Format(CultureInfo.InvariantCulture, "{0}_{1}", new object[]
								{
									"AppRecommendation",
									appRecommendation2.IconId
								});
								appRecommendation2.ImagePath = Utils.TinyDownloader(icon, fileNameWithExtension, RegistryStrings.PromotionDirectory, false);
							}
						}
					}
					PromotionObject.Instance.AppRecommendations = list[0];
				}
			}
			catch (Exception ex)
			{
				PromotionObject.Instance.AppRecommendations = new AppRecommendationSection();
				Logger.Info("Error Loading App Recommendations" + ex.ToString());
			}
		}

		// Token: 0x06000E1B RID: 3611 RVA: 0x0005D5B8 File Offset: 0x0005B7B8
		private static void SetStartupTab(JToken res)
		{
			try
			{
				if (JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("startup_tab")))
				{
					PromotionObject.Instance.StartupTab.ClearSync<string, string>();
				}
				else if (!JsonExtensions.IsNullOrEmptyBrackets(res["startup_tab"].GetValue("extra_payload")))
				{
					PromotionObject.Instance.StartupTab.ClearAddRange(res["startup_tab"]["extra_payload"].ToSerializableDictionary<string>());
					PromotionManager.PopulateAndDownloadFavicon(PromotionObject.Instance.StartupTab, "startup_favicon", false);
				}
			}
			catch (Exception ex)
			{
				PromotionObject.Instance.StartupTab.ClearSync<string, string>();
				Logger.Error("Exception while setting the startup tab. " + ex.ToString());
			}
		}

		// Token: 0x06000E1C RID: 3612 RVA: 0x0005D67C File Offset: 0x0005B87C
		public static void PopulateAndDownloadFavicon(IDictionary<string, string> payload, string id, bool redownload = false)
		{
			if (payload.ContainsKey("click_action_app_icon_id"))
			{
				id += payload["click_action_app_icon_id"];
			}
			if (payload.ContainsKey("click_action_app_icon_url"))
			{
				string value = Utils.TinyDownloader(payload["click_action_app_icon_url"], id, RegistryStrings.PromotionDirectory, redownload);
				if (!string.IsNullOrEmpty(value))
				{
					payload["icon_path"] = value;
				}
			}
		}

		// Token: 0x06000E1D RID: 3613 RVA: 0x0005D6E4 File Offset: 0x0005B8E4
		private static void SetIconOrder(JToken res)
		{
			try
			{
				if (JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("order")))
				{
					PromotionObject.Instance.SetDefaultOrder(true);
				}
				else
				{
					PromotionManager.SetMyAppsOrder(res["order"]);
					PromotionManager.SetDockOrder(res["order"]);
					PromotionManager.SetMoreAppsOrder(res["order"]);
				}
			}
			catch (Exception ex)
			{
				PromotionObject.Instance.SetDefaultOrder(false);
				Logger.Info("Error Loading icon order" + ex.ToString());
			}
		}

		// Token: 0x06000E1E RID: 3614 RVA: 0x0005D778 File Offset: 0x0005B978
		private static void SetMoreAppsOrder(JToken res)
		{
			try
			{
				if (JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("more_apps_order")))
				{
					PromotionObject.Instance.SetDefaultMoreAppsOrder(true);
				}
				else
				{
					PromotionObject.Instance.MoreAppsDockOrder.ClearSync<string, int>();
					foreach (KeyValuePair<string, int> keyValuePair in res["more_apps_order"].ToSerializableDictionary<int>())
					{
						PromotionObject.Instance.MoreAppsDockOrder[keyValuePair.Key] = keyValuePair.Value;
					}
				}
			}
			catch (Exception ex)
			{
				PromotionObject.Instance.SetDefaultMoreAppsOrder(true);
				Logger.Info("Error Loading more_apps_order" + ex.ToString());
			}
		}

		// Token: 0x06000E1F RID: 3615 RVA: 0x0005D84C File Offset: 0x0005BA4C
		private static void SetMyAppsOrder(JToken res)
		{
			try
			{
				if (JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("myapps_order")))
				{
					PromotionObject.Instance.SetDefaultMyAppsOrder(true);
				}
				else
				{
					PromotionObject.Instance.MyAppsOrder.ClearSync<string, int>();
					foreach (KeyValuePair<string, int> keyValuePair in res["myapps_order"].ToSerializableDictionary<int>())
					{
						PromotionObject.Instance.MyAppsOrder[keyValuePair.Key] = keyValuePair.Value;
					}
				}
			}
			catch (Exception ex)
			{
				PromotionObject.Instance.SetDefaultMyAppsOrder(true);
				Logger.Info("Error Loading My apps order" + ex.ToString());
			}
		}

		// Token: 0x06000E20 RID: 3616 RVA: 0x0005D920 File Offset: 0x0005BB20
		private static void SetDiscordId(JToken res)
		{
			try
			{
				if (!JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("discord_client_id")))
				{
					PromotionObject.Instance.DiscordClientID = res.GetValue("discord_client_id");
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error while getting discord id : {0}", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x06000E21 RID: 3617 RVA: 0x0005D984 File Offset: 0x0005BB84
		private static void SetFeatures(JToken res)
		{
			try
			{
				if (!JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("is_root_access_enabled")))
				{
					PromotionObject.Instance.IsRootAccessEnabled = res["is_root_access_enabled"].ToObject<bool>();
				}
				if (!JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("is_timeline_stats4_enabled")))
				{
					RegistryManager.Instance.IsTimelineStats4Enabled = res["is_timeline_stats4_enabled"].ToObject<bool>();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in SetFeatures: {0}", new object[]
				{
					ex
				});
			}
			try
			{
				if (!JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("geo")))
				{
					string text = res["geo"].ToString();
					if (!string.IsNullOrEmpty(text))
					{
						RegistryManager.Instance.Geo = text;
					}
				}
			}
			catch (Exception ex2)
			{
				Logger.Error("Error while getting geo feature: {0}", new object[]
				{
					ex2
				});
			}
		}

		// Token: 0x06000E22 RID: 3618 RVA: 0x0005DA70 File Offset: 0x0005BC70
		private static void SetDockOrder(JToken res)
		{
			try
			{
				if (JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("dock_order")))
				{
					PromotionObject.Instance.SetDefaultDockOrder(true);
				}
				else
				{
					PromotionObject.Instance.DockOrder.ClearSync<string, int>();
					JToken jtoken = res["dock_order"];
					SerializableDictionary<string, int> serializableDictionary = (jtoken != null) ? jtoken.ToSerializableDictionary<int>() : null;
					if (serializableDictionary != null && serializableDictionary.Count > 0)
					{
						using (Dictionary<string, int>.Enumerator enumerator = serializableDictionary.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								KeyValuePair<string, int> keyValuePair = enumerator.Current;
								PromotionObject.Instance.DockOrder[keyValuePair.Key] = keyValuePair.Value;
							}
							goto IL_A7;
						}
					}
					PromotionObject.Instance.SetDefaultDockOrder(true);
				}
				IL_A7:;
			}
			catch (Exception ex)
			{
				PromotionObject.Instance.SetDefaultDockOrder(true);
				Logger.Info("Error Loading dock order" + ex.ToString());
			}
		}

		// Token: 0x06000E23 RID: 3619 RVA: 0x0005DB68 File Offset: 0x0005BD68
		private static void SetBootPromotion(JToken res)
		{
			try
			{
				if (JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("boot_promotion_obj")))
				{
					foreach (KeyValuePair<string, BootPromotion> keyValuePair in PromotionObject.Instance.DictBootPromotions)
					{
						keyValuePair.Value.DeleteFile();
					}
					PromotionObject.Instance.DictBootPromotions.ClearSync<string, BootPromotion>();
				}
				else
				{
					JToken jtoken = JToken.Parse(res.GetValue("boot_promotion_obj"));
					if (jtoken["boot_promotion_display_time"] != null)
					{
						PromotionObject.Instance.BootPromoDisplaytime = jtoken["boot_promotion_display_time"].ToObject<int>();
					}
					SerializableDictionary<string, BootPromotion> serializableDictionary = new SerializableDictionary<string, BootPromotion>();
					foreach (JToken jtoken2 in JArray.Parse(jtoken["boot_promotion_images"].ToString()))
					{
						string value = jtoken2.GetValue("id");
						if (!JsonExtensions.IsNullOrEmptyBrackets(value))
						{
							BootPromotion bootPromotion;
							if (PromotionObject.Instance.DictBootPromotions.ContainsKey(value))
							{
								bootPromotion = PromotionObject.Instance.DictBootPromotions[value];
							}
							else
							{
								bootPromotion = PromotionManager.AddBootPromotion(jtoken2);
							}
							if (bootPromotion != null)
							{
								serializableDictionary[bootPromotion.Id] = bootPromotion;
							}
						}
					}
					PromotionObject.Instance.DictBootPromotions.ClearAddRange(serializableDictionary);
				}
			}
			catch (Exception ex)
			{
				PromotionObject.Instance.DictBootPromotions.ClearSync<string, BootPromotion>();
				Logger.Info("Error Loading Boot Promotions" + ex.ToString());
			}
			PromotionObject.mIsBootPromotionLoading = false;
			EventHandler bootPromotionHandler = PromotionObject.BootPromotionHandler;
			if (bootPromotionHandler != null)
			{
				bootPromotionHandler(PromotionObject.Instance, new EventArgs());
			}
			try
			{
				foreach (KeyValuePair<string, BootPromotion> keyValuePair2 in PromotionObject.Instance.DictOldBootPromotions)
				{
					if (!PromotionObject.Instance.DictBootPromotions.ContainsKey(keyValuePair2.Key))
					{
						keyValuePair2.Value.DeleteFile();
					}
				}
			}
			catch (Exception ex2)
			{
				Logger.Warning("Error Loading myapp cross Promotions" + ex2.ToString());
			}
		}

		// Token: 0x06000E24 RID: 3620 RVA: 0x0005DE00 File Offset: 0x0005C000
		private static void SetMyAppsBackgroundPromotion(JToken res)
		{
			bool flag = false;
			try
			{
				if (!JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("myapps_background_id")))
				{
					if (!string.Equals(PromotionObject.Instance.BackgroundPromotionID, res.GetValue("myapps_background_id"), StringComparison.InvariantCulture))
					{
						PromotionObject.Instance.BackgroundPromotionID = res.GetValue("myapps_background_id");
						PromotionObject.Instance.BackgroundPromotionImagePath = Utils.TinyDownloader(res.GetValue("myapps_background_url"), "BackPromo", RegistryStrings.PromotionDirectory, true);
					}
				}
				else
				{
					flag = true;
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Error Loading myapp background Promotions" + ex.ToString());
				flag = true;
			}
			if (flag)
			{
				PromotionObject.Instance.BackgroundPromotionID = "";
				PromotionObject.Instance.BackgroundPromotionImagePath = "";
				IOUtils.DeleteIfExists(new List<string>
				{
					Path.Combine(RegistryStrings.PromotionDirectory, "BackPromo")
				});
			}
		}

		// Token: 0x06000E25 RID: 3621 RVA: 0x0005DEE8 File Offset: 0x0005C0E8
		internal static void SetMyAppsCrossPromotion(JToken res)
		{
			bool flag = false;
			try
			{
				if (!JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("myapps_cross_promotion")))
				{
					List<AppSuggestionPromotion> list = res["myapps_cross_promotion"].ToObject<IEnumerable<AppSuggestionPromotion>>().ToList<AppSuggestionPromotion>();
					if (list == null)
					{
						list = new List<AppSuggestionPromotion>();
					}
					else
					{
						using (IEnumerator<JToken> enumerator = JArray.Parse(res["myapps_cross_promotion"].ToString()).GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								JToken x = enumerator.Current;
								if (x["extra_payload"] != null && x["app_icon_id"] != null)
								{
									(from _ in list
									where _.AppIconId == x["app_icon_id"].ToString()
									select _).First<AppSuggestionPromotion>().ExtraPayload.ClearAddRange(x["extra_payload"].ToSerializableDictionary<string>());
								}
							}
						}
					}
					object syncRoot = ((ICollection)PromotionObject.Instance.AppSuggestionList).SyncRoot;
					lock (syncRoot)
					{
						using (List<AppSuggestionPromotion>.Enumerator enumerator2 = PromotionObject.Instance.AppSuggestionList.GetEnumerator())
						{
							while (enumerator2.MoveNext())
							{
								AppSuggestionPromotion item = enumerator2.Current;
								if (!list.Any((AppSuggestionPromotion _) => string.Equals(_.AppIconId, item.AppIconId, StringComparison.InvariantCulture)))
								{
									IOUtils.DeleteIfExists(new List<string>
									{
										Path.Combine(RegistryStrings.PromotionDirectory, "AppSuggestion" + item.AppIconId)
									});
									PromotionManager.DeleteFavicon(item.ExtraPayload);
								}
								if (!list.Any((AppSuggestionPromotion _) => string.Equals(_.IconBorderId, item.IconBorderId, StringComparison.InvariantCulture)))
								{
									IOUtils.DeleteIfExists(new List<string>
									{
										Path.Combine(RegistryStrings.PromotionDirectory, item.IconBorderId + "app_suggestion_icon_border.png"),
										Path.Combine(RegistryStrings.PromotionDirectory, item.IconBorderId + "app_suggestion_icon_border_hover.png"),
										Path.Combine(RegistryStrings.PromotionDirectory, item.IconBorderId + "app_suggestion_icon_border_click.png")
									});
								}
							}
						}
						PromotionObject.Instance.AppSuggestionList.ClearAddRange(list);
						foreach (AppSuggestionPromotion appSuggestionPromotion in PromotionObject.Instance.AppSuggestionList)
						{
							appSuggestionPromotion.AppIconPath = Utils.TinyDownloader(appSuggestionPromotion.AppIcon, "AppSuggestion" + appSuggestionPromotion.AppIconId, RegistryStrings.PromotionDirectory, false);
							if (!string.IsNullOrEmpty(appSuggestionPromotion.IconBorderId) && appSuggestionPromotion.IsIconBorder)
							{
								Utils.TinyDownloader(appSuggestionPromotion.IconBorderUrl, appSuggestionPromotion.IconBorderId + "app_suggestion_icon_border.png", RegistryStrings.PromotionDirectory, false);
								Utils.TinyDownloader(appSuggestionPromotion.IconBorderHoverUrl, appSuggestionPromotion.IconBorderId + "app_suggestion_icon_border_hover.png", RegistryStrings.PromotionDirectory, false);
								Utils.TinyDownloader(appSuggestionPromotion.IconBorderClickUrl, appSuggestionPromotion.IconBorderId + "app_suggestion_icon_border_click.png", RegistryStrings.PromotionDirectory, false);
							}
						}
						goto IL_322;
					}
				}
				flag = true;
				IL_322:;
			}
			catch (Exception ex)
			{
				Logger.Info("Error Loading myapp cross Promotions" + ex.ToString());
				flag = true;
			}
			if (flag)
			{
				object syncRoot = ((ICollection)PromotionObject.Instance.AppSuggestionList).SyncRoot;
				lock (syncRoot)
				{
					PromotionObject.Instance.AppSuggestionList.ClearSync<AppSuggestionPromotion>();
				}
				flag = false;
			}
		}

		// Token: 0x06000E26 RID: 3622 RVA: 0x0000A6D9 File Offset: 0x000088D9
		private static void DeleteFavicon(IDictionary<string, string> payload)
		{
			if (payload.ContainsKey("favicon_path"))
			{
				IOUtils.DeleteIfExists(new List<string>
				{
					payload["favicon_path"]
				});
			}
		}

		// Token: 0x06000E27 RID: 3623 RVA: 0x0005E300 File Offset: 0x0005C500
		internal static void ReadQuests(JToken res, bool writePromo)
		{
			bool flag = false;
			SerializableDictionary<string, long[]> serializableDictionary = new SerializableDictionary<string, long[]>();
			SerializableDictionary<string, long> serializableDictionary2 = new SerializableDictionary<string, long>();
			try
			{
				if (!JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("quest")))
				{
					PromotionObject.Instance.QuestName = res["quest"].GetValue("quest_name");
					PromotionObject.Instance.QuestActionType = res["quest"].GetValue("action_type");
					List<QuestRule> list = res["quest"]["details"].ToObject<IEnumerable<QuestRule>>().ToList<QuestRule>();
					using (List<QuestRule>.Enumerator enumerator = list.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							QuestRule rule = enumerator.Current;
							if (PromotionObject.Instance.QuestRules.Any((QuestRule _) => string.Equals(_.RuleId, rule.RuleId, StringComparison.InvariantCulture)))
							{
								if (!serializableDictionary2.ContainsKey(rule.AppPackage.ToLower(CultureInfo.InvariantCulture)))
								{
									serializableDictionary2[rule.AppPackage.ToLower(CultureInfo.InvariantCulture)] = long.MaxValue;
								}
								if (PromotionObject.Instance.ResetQuestRules.ContainsKey(rule.RuleId))
								{
									serializableDictionary.Add(rule.RuleId, PromotionObject.Instance.ResetQuestRules[rule.RuleId]);
								}
							}
							else
							{
								serializableDictionary2[rule.AppPackage] = 0L;
								long totalTimeForPackageAcrossInstances = AppUsageTimer.GetTotalTimeForPackageAcrossInstances(rule.AppPackage);
								long num = 0L;
								if (PromotionManager.combinedPackages.ContainsKey(rule.AppPackage))
								{
									num = PromotionManager.combinedPackages[rule.AppPackage];
								}
								serializableDictionary.Add(rule.RuleId, new long[]
								{
									num,
									totalTimeForPackageAcrossInstances
								});
							}
						}
					}
					PromotionObject.Instance.QuestRules.ClearAddRange(list);
					PromotionObject.Instance.ResetQuestRules.ClearAddRange(serializableDictionary);
					PromotionObject.Instance.QuestHdPlayerRules.ClearAddRange(serializableDictionary2);
				}
				else
				{
					flag = true;
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Error Loading promotion quests" + ex.ToString());
				flag = true;
			}
			if (flag)
			{
				PromotionObject.Instance.QuestName = "";
				PromotionObject.Instance.QuestActionType = "";
				PromotionObject.Instance.QuestRules.ClearSync<QuestRule>();
				PromotionObject.Instance.QuestHdPlayerRules.ClearSync<string, long>();
				flag = false;
			}
			if (writePromo)
			{
				PromotionObject.Save();
				Action questHandler = PromotionObject.QuestHandler;
				if (questHandler == null)
				{
					return;
				}
				questHandler();
			}
		}

		// Token: 0x06000E28 RID: 3624 RVA: 0x00013374 File Offset: 0x00011574
		private static T DoDeserialize<T>(string data) where T : class
		{
			T result;
			using (XmlReader xmlReader = XmlReader.Create(new MemoryStream(Encoding.UTF8.GetBytes(data))))
			{
				result = (T)((object)new XmlSerializer(typeof(T)).Deserialize(xmlReader));
			}
			return result;
		}

		// Token: 0x06000E29 RID: 3625 RVA: 0x0005E5DC File Offset: 0x0005C7DC
		internal static void AddNewMyAppsCrossPromotion(JToken res)
		{
			try
			{
				AppSuggestionPromotion appSuggestionPromotion = res["myapps_cross_promotion"].ToObject<AppSuggestionPromotion>();
				if (appSuggestionPromotion != null && res["myapps_cross_promotion"]["extra_payload"] != null && res["myapps_cross_promotion"]["app_icon_id"] != null)
				{
					appSuggestionPromotion.ExtraPayload.ClearAddRange(res["myapps_cross_promotion"]["extra_payload"].ToSerializableDictionary<string>());
					PromotionManager.PopulateAndDownloadFavicon(appSuggestionPromotion.ExtraPayload, "AppSuggestion", false);
				}
				List<AppSuggestionPromotion> list = new List<AppSuggestionPromotion>();
				object syncRoot = ((ICollection)PromotionObject.Instance.AppSuggestionList).SyncRoot;
				lock (syncRoot)
				{
					foreach (AppSuggestionPromotion appSuggestionPromotion2 in PromotionObject.Instance.AppSuggestionList)
					{
						if (string.Equals(appSuggestionPromotion.AppIconId, appSuggestionPromotion2.AppIconId, StringComparison.InvariantCulture))
						{
							list.Add(appSuggestionPromotion2);
							IOUtils.DeleteIfExists(new List<string>
							{
								Path.Combine(RegistryStrings.PromotionDirectory, "AppSuggestion" + appSuggestionPromotion2.AppIconId)
							});
						}
					}
					foreach (AppSuggestionPromotion item in list)
					{
						PromotionObject.Instance.AppSuggestionList.Remove(item);
					}
					appSuggestionPromotion.AppIconPath = Utils.TinyDownloader(appSuggestionPromotion.AppIcon, "AppSuggestion" + appSuggestionPromotion.AppIconId, RegistryStrings.PromotionDirectory, false);
					if (!string.IsNullOrEmpty(appSuggestionPromotion.IconBorderId) && appSuggestionPromotion.IsIconBorder)
					{
						Utils.TinyDownloader(appSuggestionPromotion.IconBorderUrl, appSuggestionPromotion.IconBorderId + "app_suggestion_icon_border.png", RegistryStrings.PromotionDirectory, false);
						Utils.TinyDownloader(appSuggestionPromotion.IconBorderHoverUrl, appSuggestionPromotion.IconBorderId + "app_suggestion_icon_border_hover.png", RegistryStrings.PromotionDirectory, false);
						Utils.TinyDownloader(appSuggestionPromotion.IconBorderClickUrl, appSuggestionPromotion.IconBorderId + "app_suggestion_icon_border_click.png", RegistryStrings.PromotionDirectory, false);
					}
					PromotionObject.Instance.AppSuggestionList.Add(appSuggestionPromotion);
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Error Loading myapp cross Promotions by notification: " + ex.ToString());
			}
		}

		// Token: 0x06000E2A RID: 3626 RVA: 0x0005E874 File Offset: 0x0005CA74
		internal static void CheckIsUserPremium()
		{
			string registeredEmail = RegistryManager.Instance.RegisteredEmail;
			string token = RegistryManager.Instance.Token;
			string userGuid = RegistryManager.Instance.UserGuid;
			string version = RegistryManager.Instance.Version;
			string clientVersion = RegistryManager.Instance.ClientVersion;
			string text = "bgp";
			if (!string.IsNullOrEmpty(registeredEmail) && !string.IsNullOrEmpty(token))
			{
				string url = string.Format(CultureInfo.InvariantCulture, "{0}/bs-accounts/getuser?email={1}&guid={2}&token={3}&eng_ver={4}&client_ver={5}&oem={6}", new object[]
				{
					RegistryManager.Instance.Host,
					registeredEmail,
					userGuid,
					token,
					version,
					clientVersion,
					text
				});
				string text2;
				for (;;)
				{
					try
					{
						text2 = BstHttpClient.Get(url, null, false, "", 0, 1, 0, false);
					}
					catch
					{
						Thread.Sleep(20000);
						continue;
					}
					break;
				}
				Logger.Debug("Response string from cloud for bs-accounts/getuser : " + text2);
				try
				{
					JObject jobject = JObject.Parse(text2);
					if (string.Equals(jobject["status"].ToString().Trim(), "success", StringComparison.InvariantCulture))
					{
						RegistryManager.Instance.RegisteredEmail = jobject["message"]["email"].ToString().Trim();
						if (string.Compare(jobject["message"]["subscription_status"].ToString().Trim(), "PAID", StringComparison.OrdinalIgnoreCase) == 0)
						{
							RegistryManager.Instance.IsPremium = true;
						}
						else
						{
							RegistryManager.Instance.IsPremium = false;
						}
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Failed to parse string received from cloud... Err : " + ex.ToString());
				}
			}
		}

		// Token: 0x06000E2B RID: 3627 RVA: 0x0005EA1C File Offset: 0x0005CC1C
		internal static void StartQuestRulesProcessor()
		{
			foreach (QuestRule questRule in PromotionObject.Instance.QuestRules)
			{
				if (questRule.IsRecurring)
				{
					if (!PromotionManager.mDictRecurringCount.ContainsKey(questRule.RuleId))
					{
						PromotionManager.mDictRecurringCount.Add(questRule.RuleId, questRule.RecurringCount);
					}
					else
					{
						PromotionManager.mDictRecurringCount[questRule.RuleId] = questRule.RecurringCount;
					}
				}
			}
			if (PromotionManager.mQuestTimer.Enabled)
			{
				if (PromotionObject.Instance.QuestHdPlayerRules.Count == 0)
				{
					PromotionManager.mQuestTimer.Stop();
					return;
				}
			}
			else if (PromotionObject.Instance.QuestHdPlayerRules.Count > 0)
			{
				PromotionManager.mQuestTimer.Elapsed -= PromotionManager.QuestTimer_Elapsed;
				PromotionManager.mQuestTimer.Elapsed += PromotionManager.QuestTimer_Elapsed;
				PromotionManager.mQuestTimer.Start();
			}
		}

		// Token: 0x06000E2C RID: 3628 RVA: 0x0005EB24 File Offset: 0x0005CD24
		private static void QuestTimer_Elapsed(object sender, ElapsedEventArgs e)
		{
			try
			{
				PromotionManager.combinedPackages.Clear();
				foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>())
				{
					string text = mainWindow.mFrontendHandler.SendFrontendRequest("getInteractionForPackage", null);
					if (!string.IsNullOrEmpty(text))
					{
						Logger.Debug("Package interaction Json received from frontend: " + text);
						foreach (KeyValuePair<string, long> keyValuePair in (JToken.Parse(text).ToDictionary<long>() as Dictionary<string, long>))
						{
							if (PromotionManager.combinedPackages.ContainsKey(keyValuePair.Key))
							{
								Dictionary<string, long> dictionary = PromotionManager.combinedPackages;
								string key = keyValuePair.Key;
								dictionary[key] += keyValuePair.Value;
							}
							else
							{
								PromotionManager.combinedPackages.Add(keyValuePair.Key, keyValuePair.Value);
							}
						}
					}
				}
				List<QuestRuleState> list = new List<QuestRuleState>();
				Dictionary<string, long> dictionary2 = new Dictionary<string, long>();
				List<QuestRule> list2 = new List<QuestRule>();
				string packageName = string.Empty;
				foreach (QuestRule questRule in from _ in PromotionObject.Instance.QuestRules
				where !PromotionManager.mRuleIdAlreadyPassed.Contains(_.RuleId)
				select _)
				{
					if (PromotionManager.combinedPackages.ContainsKey(questRule.AppPackage.ToLower(CultureInfo.InvariantCulture)))
					{
						if (PromotionManager.combinedPackages.ContainsKey("?"))
						{
							foreach (KeyValuePair<string, long> keyValuePair2 in PromotionManager.combinedPackages)
							{
								if (!keyValuePair2.Key.ToString(CultureInfo.InvariantCulture).Equals("?", StringComparison.OrdinalIgnoreCase))
								{
									packageName = keyValuePair2.Key.ToString(CultureInfo.InvariantCulture);
								}
							}
						}
						if ((long)questRule.MinUserInteraction <= PromotionManager.combinedPackages[questRule.AppPackage.ToLower(CultureInfo.InvariantCulture)] - PromotionObject.Instance.ResetQuestRules[questRule.RuleId][0])
						{
							list2.Add(questRule);
							if (dictionary2.ContainsKey(questRule.AppPackage))
							{
								dictionary2[questRule.AppPackage] = PromotionManager.combinedPackages[questRule.AppPackage.ToLower(CultureInfo.InvariantCulture)];
							}
							else
							{
								dictionary2.Add(questRule.AppPackage, PromotionManager.combinedPackages[questRule.AppPackage.ToLower(CultureInfo.InvariantCulture)]);
							}
							Logger.Debug("Interaction rule passed for package " + questRule.AppPackage + PromotionManager.combinedPackages[questRule.AppPackage.ToLower(CultureInfo.InvariantCulture)].ToString());
						}
					}
				}
				foreach (QuestRule questRule2 in from _ in list2
				where !PromotionManager.mRuleIdAlreadyPassed.Contains(_.RuleId)
				select _)
				{
					QuestRuleState questRuleState = new QuestRuleState();
					if (string.Equals(questRule2.AppPackage, "*", StringComparison.InvariantCulture))
					{
						long totalTimeForAllPackages = AppUsageTimer.GetTotalTimeForAllPackages();
						if ((long)questRule2.AppUsageTime <= totalTimeForAllPackages - PromotionObject.Instance.ResetQuestRules[questRule2.RuleId][1])
						{
							questRuleState.TotalTime = totalTimeForAllPackages;
							questRuleState.QuestRules = questRule2;
							questRuleState.Interaction = dictionary2[questRule2.AppPackage];
							list.Add(questRuleState);
							if (PromotionManager.combinedPackages.ContainsKey(questRule2.AppPackage.ToLower(CultureInfo.InvariantCulture)))
							{
								PromotionObject.Instance.ResetQuestRules[questRule2.RuleId][0] = PromotionManager.combinedPackages[questRule2.AppPackage.ToLower(CultureInfo.InvariantCulture)];
								PromotionObject.Instance.ResetQuestRules[questRule2.RuleId][1] = questRuleState.TotalTime;
							}
						}
					}
					else if (string.Equals(questRule2.AppPackage, "?", StringComparison.InvariantCulture))
					{
						long totalTimeForPackageAfterReset = AppUsageTimer.GetTotalTimeForPackageAfterReset(packageName);
						if ((long)questRule2.AppUsageTime <= totalTimeForPackageAfterReset - PromotionObject.Instance.ResetQuestRules[questRule2.RuleId][1])
						{
							questRuleState.TotalTime = totalTimeForPackageAfterReset;
							questRuleState.QuestRules = questRule2;
							questRuleState.Interaction = dictionary2[questRule2.AppPackage];
							list.Add(questRuleState);
							if (PromotionManager.combinedPackages.ContainsKey(questRule2.AppPackage.ToLower(CultureInfo.InvariantCulture)))
							{
								PromotionObject.Instance.ResetQuestRules[questRule2.RuleId][0] = PromotionManager.combinedPackages[questRule2.AppPackage.ToLower(CultureInfo.InvariantCulture)];
								PromotionObject.Instance.ResetQuestRules[questRule2.RuleId][1] = questRuleState.TotalTime;
							}
						}
					}
					else
					{
						long totalTimeForPackageAfterReset2 = AppUsageTimer.GetTotalTimeForPackageAfterReset(questRule2.AppPackage.ToLower(CultureInfo.InvariantCulture));
						if ((long)questRule2.AppUsageTime <= totalTimeForPackageAfterReset2 - PromotionObject.Instance.ResetQuestRules[questRule2.RuleId][1])
						{
							questRuleState.TotalTime = totalTimeForPackageAfterReset2;
							questRuleState.QuestRules = questRule2;
							questRuleState.Interaction = dictionary2[questRule2.AppPackage];
							list.Add(questRuleState);
							if (PromotionManager.combinedPackages.ContainsKey(questRule2.AppPackage.ToLower(CultureInfo.InvariantCulture)))
							{
								PromotionObject.Instance.ResetQuestRules[questRule2.RuleId][0] = PromotionManager.combinedPackages[questRule2.AppPackage.ToLower(CultureInfo.InvariantCulture)];
								PromotionObject.Instance.ResetQuestRules[questRule2.RuleId][1] = questRuleState.TotalTime;
							}
						}
					}
				}
				if (list.Count > 0)
				{
					SerializableDictionary<string, long> serializableDictionary = new SerializableDictionary<string, long>();
					bool flag = false;
					foreach (QuestRule questRule3 in PromotionObject.Instance.QuestRules)
					{
						serializableDictionary[questRule3.AppPackage.ToLower(CultureInfo.InvariantCulture)] = long.MaxValue;
					}
					using (List<QuestRuleState>.Enumerator enumerator5 = list.GetEnumerator())
					{
						while (enumerator5.MoveNext())
						{
							QuestRuleState ruleState = enumerator5.Current;
							string text2 = ruleState.QuestRules.CloudHandler;
							string jsonobjectString = JSONUtils.GetJSONObjectString(AppUsageTimer.GetRealtimeDictionary());
							if (string.IsNullOrEmpty(text2))
							{
								text2 = "/pika_points/quest_rule_accomplished";
							}
							string text3 = WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}{1}", new object[]
							{
								WebHelper.GetServerHost(),
								text2
							}));
							text3 += string.Format(CultureInfo.InvariantCulture, "&email={5}&quest_name={0}&rule_id={1}&app_pkg={2}&usage_time={3}&user_interactions={4}&usage_data={6}", new object[]
							{
								PromotionObject.Instance.QuestName,
								ruleState.QuestRules.RuleId,
								ruleState.QuestRules.AppPackage,
								ruleState.TotalTime,
								ruleState.Interaction,
								RegistryManager.Instance.RegisteredEmail,
								jsonobjectString
							});
							int i = 3;
							while (i > 0)
							{
								try
								{
									string str = BstHttpClient.Get(text3, null, false, string.Empty, 5000, 1, 0, false);
									Logger.Info("Quest rule passed response from cloud " + str + " ruleId: " + ruleState.QuestRules.RuleId);
									break;
								}
								catch (Exception ex)
								{
									Logger.Warning("Exception while calling cloud for quest rule passed, RETRYING " + i.ToString() + Environment.NewLine + ex.ToString());
									i--;
									Thread.Sleep(1000);
								}
							}
							if (i == 0)
							{
								Logger.Error("Could not send quest rule passed, to cloud after retries.");
							}
							if (!ruleState.QuestRules.IsRecurring)
							{
								PromotionManager.mRuleIdAlreadyPassed.Add(ruleState.QuestRules.RuleId);
							}
							else if (PromotionManager.mDictRecurringCount[ruleState.QuestRules.RuleId] == -1)
							{
								if (string.Equals(ruleState.QuestRules.AppPackage, "*", StringComparison.InvariantCulture))
								{
									AppUsageTimer.GetTotalTimeForAllPackages();
								}
								else
								{
									AppUsageTimer.GetTotalTimeForPackageAfterReset(ruleState.QuestRules.AppPackage);
								}
								if (PromotionObject.Instance.QuestRules.Any((QuestRule _) => string.Equals(_.RuleId, ruleState.QuestRules.RuleId, StringComparison.InvariantCulture)) && serializableDictionary.ContainsKey(ruleState.QuestRules.AppPackage.ToLower(CultureInfo.InvariantCulture)))
								{
									if (ruleState.QuestRules.RecurringCount != -1)
									{
										QuestRule questRules = ruleState.QuestRules;
										int recurringCount = questRules.RecurringCount;
										questRules.RecurringCount = recurringCount - 1;
									}
									serializableDictionary[ruleState.QuestRules.AppPackage.ToLower(CultureInfo.InvariantCulture)] = 0L;
									flag = true;
								}
							}
							else
							{
								PromotionManager.mDictRecurringCount[ruleState.QuestRules.RuleId] = PromotionManager.mDictRecurringCount[ruleState.QuestRules.RuleId] - 1;
								if (PromotionManager.mDictRecurringCount[ruleState.QuestRules.RuleId] == 0)
								{
									PromotionManager.mRuleIdAlreadyPassed.Add(ruleState.QuestRules.RuleId);
								}
								else if (PromotionManager.mDictRecurringCount[ruleState.QuestRules.RuleId] > 0)
								{
									if (string.Equals(ruleState.QuestRules.AppPackage, "*", StringComparison.InvariantCulture))
									{
										long totalTimeForAllPackages2 = AppUsageTimer.GetTotalTimeForAllPackages();
										AppUsageTimer.AddPackageForReset("*", totalTimeForAllPackages2);
									}
									else
									{
										long totalTimeForPackageAfterReset3 = AppUsageTimer.GetTotalTimeForPackageAfterReset(ruleState.QuestRules.AppPackage);
										AppUsageTimer.AddPackageForReset(ruleState.QuestRules.AppPackage.ToLower(CultureInfo.InvariantCulture), totalTimeForPackageAfterReset3);
									}
									if (PromotionObject.Instance.QuestRules.Any((QuestRule _) => string.Equals(_.RuleId, ruleState.QuestRules.RuleId, StringComparison.InvariantCulture)) && serializableDictionary.ContainsKey(ruleState.QuestRules.AppPackage.ToLower(CultureInfo.InvariantCulture)))
									{
										if (ruleState.QuestRules.RecurringCount != -1)
										{
											QuestRule questRules2 = ruleState.QuestRules;
											int recurringCount = questRules2.RecurringCount;
											questRules2.RecurringCount = recurringCount - 1;
										}
										serializableDictionary[ruleState.QuestRules.AppPackage.ToLower(CultureInfo.InvariantCulture)] = 0L;
										flag = true;
									}
								}
							}
						}
					}
					if (flag)
					{
						PromotionObject.Instance.QuestHdPlayerRules.ClearAddRange(serializableDictionary);
						PromotionObject.Save();
						Action questHandler = PromotionObject.QuestHandler;
						if (questHandler != null)
						{
							questHandler();
						}
					}
				}
			}
			catch (Exception ex2)
			{
				Logger.Error("Exception in QuestTimer_Elapsed " + ex2.ToString());
			}
			try
			{
				List<GenericNotificationItem> list3 = new List<GenericNotificationItem>();
				foreach (KeyValuePair<GenericNotificationItem, long> keyValuePair3 in PromotionManager.sDeferredNotificationsList)
				{
					if (AppUsageTimer.GetTotalTimeForPackageAfterReset(keyValuePair3.Key.DeferredApp.ToLower(CultureInfo.InvariantCulture)) - keyValuePair3.Value >= keyValuePair3.Key.DeferredAppUsage)
					{
						if (string.Equals(BlueStacksUIUtils.DictWindows[Strings.CurrentDefaultVmName].mTopBar.mAppTabButtons.SelectedTab.PackageName, keyValuePair3.Key.DeferredApp, StringComparison.InvariantCulture))
						{
							BlueStacksUIUtils.DictWindows[Strings.CurrentDefaultVmName].HandleGenericNotificationPopup(keyValuePair3.Key);
							GenericNotificationManager.Instance.AddNewNotification(keyValuePair3.Key, false);
							BlueStacksUIUtils.DictWindows[Strings.CurrentDefaultVmName].Dispatcher.Invoke(new Action(delegate()
							{
								BlueStacksUIUtils.DictWindows[Strings.CurrentDefaultVmName].mTopBar.RefreshNotificationCentreButton();
							}), new object[0]);
							list3.Add(keyValuePair3.Key);
						}
						else
						{
							PromotionManager.sPassedDeferredNotificationsList.Add(keyValuePair3.Key);
						}
					}
				}
				foreach (GenericNotificationItem key2 in list3)
				{
					PromotionManager.sDeferredNotificationsList.Remove(key2);
				}
			}
			catch (Exception ex3)
			{
				Logger.Error("Exception in checking deferred notification: " + ex3.ToString());
			}
		}

		// Token: 0x06000E2D RID: 3629 RVA: 0x0005F924 File Offset: 0x0005DB24
		private static void SetSecurityMetrics(JToken res)
		{
			try
			{
				if (!JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("security_metrics_enable_user")))
				{
					PromotionObject.Instance.IsSecurityMetricsEnable = res["security_metrics_enable_user"].ToObject<bool>();
				}
				else
				{
					PromotionObject.Instance.IsSecurityMetricsEnable = false;
				}
				if (!JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("security_metrics_blacklisted_apps")))
				{
					PromotionObject.Instance.BlackListedApplicationsList.ClearSync<string>();
					using (IEnumerator<JToken> enumerator = JArray.Parse(res["security_metrics_blacklisted_apps"].ToString()).GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							JToken jtoken = enumerator.Current;
							PromotionObject.Instance.BlackListedApplicationsList.Add(jtoken.ToString());
						}
						goto IL_B6;
					}
				}
				PromotionObject.Instance.BlackListedApplicationsList.ClearSync<string>();
				IL_B6:;
			}
			catch (Exception ex)
			{
				Logger.Error("Error while getting security metrics info: {0}", new object[]
				{
					ex.ToString()
				});
				PromotionObject.Instance.IsSecurityMetricsEnable = false;
				PromotionObject.Instance.BlackListedApplicationsList.ClearSync<string>();
			}
		}

		// Token: 0x06000E2E RID: 3630 RVA: 0x0005FA3C File Offset: 0x0005DC3C
		private static void SetCustomCursorRuleForApp(JToken res)
		{
			try
			{
				if (!JsonExtensions.IsNullOrEmptyBrackets(res.GetValue("exclude_custom_cursor")))
				{
					PromotionObject.Instance.CustomCursorExcludedAppsList.ClearSync<string>();
					using (IEnumerator<JToken> enumerator = JArray.Parse(res["exclude_custom_cursor"].ToString()).GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							JToken jtoken = enumerator.Current;
							PromotionObject.Instance.CustomCursorExcludedAppsList.Add(jtoken.ToString());
						}
						goto IL_7D;
					}
				}
				PromotionObject.Instance.CustomCursorExcludedAppsList.ClearSync<string>();
				IL_7D:;
			}
			catch (Exception ex)
			{
				Logger.Error("Error while getting custom cursor exclude list of apps: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x06000E2F RID: 3631 RVA: 0x0005FAFC File Offset: 0x0005DCFC
		private static string AddSamsungStoreParamsIfPresent(string url)
		{
			try
			{
				url = url + "&samsung_store_present=" + RegistryManager.Instance.IsSamsungStorePresent.ToString(CultureInfo.InvariantCulture).ToLowerInvariant();
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to add samsung store parameter. Ex : " + ex.ToString());
			}
			return url;
		}

		// Token: 0x04000995 RID: 2453
		internal static Dictionary<string, long> combinedPackages = new Dictionary<string, long>();

		// Token: 0x04000996 RID: 2454
		private static System.Timers.Timer mQuestTimer = new System.Timers.Timer(15000.0);

		// Token: 0x04000997 RID: 2455
		private static Dictionary<string, int> mDictRecurringCount = new Dictionary<string, int>();

		// Token: 0x04000998 RID: 2456
		private static List<string> mRuleIdAlreadyPassed = new List<string>();

		// Token: 0x04000999 RID: 2457
		internal static Dictionary<GenericNotificationItem, long> sDeferredNotificationsList = new Dictionary<GenericNotificationItem, long>();

		// Token: 0x0400099A RID: 2458
		internal static List<GenericNotificationItem> sPassedDeferredNotificationsList = new List<GenericNotificationItem>();
	}
}
