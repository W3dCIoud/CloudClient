﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000D2 RID: 210
	public class MacroRecorderWindow : CustomWindow, IDisposable, IComponentConnector
	{
		// Token: 0x0600089D RID: 2205 RVA: 0x00032404 File Offset: 0x00030604
		public MacroRecorderWindow(MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			base.Owner = this.ParentWindow;
			base.IsShowGLWindow = true;
			this.mScriptsStackPanel = (this.mScriptsListScrollbar.Content as StackPanel);
			base.WindowStartupLocation = WindowStartupLocation.CenterOwner;
			if (window != null)
			{
				window.mCommonHandler.MacroSettingChangedEvent += this.ParentWindow_MacroSettingChangedEvent;
			}
			this.Init();
			if (this.ParentWindow != null)
			{
				if (FeatureManager.Instance.IsCustomUIForNCSoft)
				{
					this.ParentWindow.mNCTopBar.mMacroPlayControl.ScriptPlayEvent -= this.ParentWindow_ScriptPlayEvent;
					this.ParentWindow.mNCTopBar.mMacroPlayControl.ScriptStopEvent -= this.MacroPlayControl_ScriptStopEvent;
					this.ParentWindow.mNCTopBar.mMacroPlayControl.ScriptPlayEvent += this.ParentWindow_ScriptPlayEvent;
					this.ParentWindow.mNCTopBar.mMacroPlayControl.ScriptStopEvent += this.MacroPlayControl_ScriptStopEvent;
					return;
				}
				this.ParentWindow.mTopBar.mMacroPlayControl.ScriptPlayEvent -= this.ParentWindow_ScriptPlayEvent;
				this.ParentWindow.mTopBar.mMacroPlayControl.ScriptStopEvent -= this.MacroPlayControl_ScriptStopEvent;
				this.ParentWindow.mTopBar.mMacroPlayControl.ScriptPlayEvent += this.ParentWindow_ScriptPlayEvent;
				this.ParentWindow.mTopBar.mMacroPlayControl.ScriptStopEvent += this.MacroPlayControl_ScriptStopEvent;
			}
		}

		// Token: 0x0600089E RID: 2206 RVA: 0x000325B0 File Offset: 0x000307B0
		public void ShowAtCenter()
		{
			base.Show();
			RECT rect;
			NativeMethods.GetWindowRect((base.Owner as MainWindow).Handle, out rect);
			RECT rect2;
			NativeMethods.GetWindowRect(new WindowInteropHelper(this).Handle, out rect2);
			RECT placementRect = new RECT
			{
				Left = (rect.Right - rect.Left - rect2.Right + rect2.Left) / 2 + rect.Left,
				Top = (rect.Bottom - rect.Top - rect2.Bottom + rect2.Top) / 2 + rect.Top
			};
			placementRect.Right = placementRect.Left + rect2.Right - rect2.Left;
			placementRect.Bottom = placementRect.Top + rect2.Bottom - rect2.Top;
			WindowPlacement.SetPlacement(new WindowInteropHelper(this).Handle, placementRect);
		}

		// Token: 0x0600089F RID: 2207 RVA: 0x000326A8 File Offset: 0x000308A8
		private void ParentWindow_MacroSettingChangedEvent(MacroRecording record)
		{
			if (record.PlayOnStart)
			{
				foreach (object obj in this.mScriptsStackPanel.Children)
				{
					SingleMacroControl singleMacroControl = (SingleMacroControl)obj;
					if (singleMacroControl.mRecording.Name.ToLower(CultureInfo.InvariantCulture).Trim() == record.Name.ToLower(CultureInfo.InvariantCulture).Trim())
					{
						this.ChangeAutorunImageVisibility(singleMacroControl.mAutorunImage, Visibility.Visible);
					}
					else
					{
						this.ChangeAutorunImageVisibility(singleMacroControl.mAutorunImage, Visibility.Hidden);
						if (singleMacroControl.mRecording.PlayOnStart)
						{
							singleMacroControl.mRecording.PlayOnStart = false;
							if (singleMacroControl.mMacroSettingsWindow != null)
							{
								singleMacroControl.mMacroSettingsWindow.mPlayOnStartCheckBox.IsChecked = new bool?(false);
							}
							JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
							serializerSettings.Formatting = Formatting.Indented;
							string contents = JsonConvert.SerializeObject(singleMacroControl.mRecording, serializerSettings);
							File.WriteAllText(CommonHandlers.GetCompleteMacroRecordingPath(singleMacroControl.mRecording.Name), contents);
						}
					}
				}
			}
		}

		// Token: 0x060008A0 RID: 2208 RVA: 0x000327CC File Offset: 0x000309CC
		private void ChangeAutorunImageVisibility(CustomPictureBox cpb, Visibility visibility)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				cpb.Visibility = visibility;
			}), new object[0]);
		}

		// Token: 0x060008A1 RID: 2209 RVA: 0x0003280C File Offset: 0x00030A0C
		private void MacroPlayControl_ScriptStopEvent(string tag)
		{
			SingleMacroControl controlFromTag = this.GetControlFromTag(tag);
			if (controlFromTag != null)
			{
				controlFromTag.ToggleScriptPlayPauseUi(false);
			}
			if (!controlFromTag.mRecording.DonotShowWindowOnFinish && !this.ParentWindow.IsClosed)
			{
				this.ParentWindow.mCommonHandler.ShowMacroRecorderWindow();
			}
		}

		// Token: 0x060008A2 RID: 2210 RVA: 0x00032858 File Offset: 0x00030A58
		private void ParentWindow_ScriptPlayEvent(string tag)
		{
			SingleMacroControl controlFromTag = this.GetControlFromTag(tag);
			if (controlFromTag != null)
			{
				controlFromTag.ToggleScriptPlayPauseUi(true);
			}
		}

		// Token: 0x060008A3 RID: 2211 RVA: 0x00032878 File Offset: 0x00030A78
		public void Init()
		{
			this.ParentWindow.mIsScriptsPresent = false;
			this.mAlternateBackgroundColor = false;
			this.AddScriptsToStackPanel();
			if (!this.ParentWindow.mIsScriptsPresent)
			{
				this.mNoScriptsGrid.Visibility = Visibility.Visible;
				this.mExport.IsEnabled = false;
				this.mExport.Opacity = 0.4;
			}
			else
			{
				this.mNoScriptsGrid.Visibility = Visibility.Collapsed;
				this.mExport.IsEnabled = true;
				this.mExport.Opacity = 1.0;
			}
			if (this.ParentWindow.mIsMacroRecorderActive)
			{
				this.mStartMacroRecordingBtn.Visibility = Visibility.Collapsed;
				this.mStopMacroRecordingBtn.Visibility = Visibility.Visible;
			}
			else
			{
				this.mStartMacroRecordingBtn.Visibility = Visibility.Visible;
				this.mStopMacroRecordingBtn.Visibility = Visibility.Collapsed;
			}
			this.ToggleUI(this.ParentWindow.mIsMacroRecorderActive);
			if (this.ParentWindow.mIsMacroPlaying)
			{
				this.mStartMacroRecordingBtn.Visibility = Visibility.Hidden;
				this.mStopMacroRecordingBtn.Visibility = Visibility.Hidden;
			}
			this.ShowLoadingGrid(false);
		}

		// Token: 0x060008A4 RID: 2212 RVA: 0x00032984 File Offset: 0x00030B84
		private void AddScriptsToStackPanel()
		{
			foreach (MacroRecording macroRecording in from MacroRecording macro in MacroGraph.Instance.Vertices
			orderby DateTime.ParseExact(macro.TimeCreated, "yyyyMMddTHHmmss", CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal)
			select macro)
			{
				if (macroRecording != null && !string.IsNullOrEmpty(macroRecording.Name) && !string.IsNullOrEmpty(macroRecording.TimeCreated))
				{
					if (macroRecording.Events == null)
					{
						ObservableCollection<MergedMacroConfiguration> mergedMacroConfigurations = macroRecording.MergedMacroConfigurations;
						if (mergedMacroConfigurations == null || mergedMacroConfigurations.Count <= 0)
						{
							continue;
						}
					}
					this.ParentWindow.mIsScriptsPresent = true;
					SingleMacroControl singleMacroControl = new SingleMacroControl(this.ParentWindow, macroRecording, this)
					{
						Tag = macroRecording.Name
					};
					if (this.ParentWindow.mIsMacroPlaying && !string.Equals(this.ParentWindow.mMacroPlaying, macroRecording.Name, StringComparison.InvariantCulture))
					{
						CommonHandlers.DisableScriptControl(singleMacroControl);
					}
					else if (this.ParentWindow.mIsMacroPlaying)
					{
						singleMacroControl.mEditNameImg.IsEnabled = false;
					}
					else if (this.ParentWindow.mIsMacroRecorderActive)
					{
						CommonHandlers.DisableScriptControl(singleMacroControl);
					}
					if (macroRecording.PlayOnStart)
					{
						singleMacroControl.mAutorunImage.Visibility = Visibility.Visible;
					}
					if (this.mAlternateBackgroundColor)
					{
						BlueStacksUIBinding.BindColor(singleMacroControl, System.Windows.Controls.Control.BackgroundProperty, "DarkBandingColor");
					}
					else
					{
						BlueStacksUIBinding.BindColor(singleMacroControl, System.Windows.Controls.Control.BackgroundProperty, "LightBandingColor");
					}
					this.mAlternateBackgroundColor = !this.mAlternateBackgroundColor;
					this.mScriptsStackPanel.Children.Add(singleMacroControl);
				}
			}
		}

		// Token: 0x060008A5 RID: 2213 RVA: 0x00032B34 File Offset: 0x00030D34
		private SingleMacroControl GetControlFromTag(string tag)
		{
			foreach (object obj in this.mScriptsStackPanel.Children)
			{
				SingleMacroControl singleMacroControl = (SingleMacroControl)obj;
				if ((string)singleMacroControl.Tag == tag)
				{
					return singleMacroControl;
				}
			}
			return null;
		}

		// Token: 0x060008A6 RID: 2214 RVA: 0x00032BA8 File Offset: 0x00030DA8
		private void OpenScriptFolder_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (Directory.Exists(RegistryStrings.MacroRecordingsFolderPath))
			{
				using (Process process = new Process())
				{
					process.StartInfo.UseShellExecute = true;
					process.StartInfo.FileName = RegistryStrings.MacroRecordingsFolderPath;
					process.Start();
				}
			}
		}

		// Token: 0x060008A7 RID: 2215 RVA: 0x0000793E File Offset: 0x00005B3E
		private void Close_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.HideMacroRecorderWindow();
		}

		// Token: 0x060008A8 RID: 2216 RVA: 0x00032C08 File Offset: 0x00030E08
		private void mStartMacroRecordingBtn_Click(object sender, RoutedEventArgs e)
		{
			this.ParentWindow.mCommonHandler.StartMacroRecording();
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "new_macro_record", null, RecordingTypes.SingleRecording.ToString(), null, null, null);
		}

		// Token: 0x060008A9 RID: 2217 RVA: 0x00032C5C File Offset: 0x00030E5C
		private void mStopMacroRecordingBtn_Click(object sender, RoutedEventArgs e)
		{
			this.ParentWindow.mCommonHandler.StopMacroRecording();
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_record_stop", null, RecordingTypes.SingleRecording.ToString(), null, null, null);
		}

		// Token: 0x060008AA RID: 2218 RVA: 0x00007950 File Offset: 0x00005B50
		internal void PerformStopMacroAfterSave()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.ParentWindow.mTopBar.HideRecordingIcons();
				this.ParentWindow.mCommonHandler.ShowMacroRecorderWindow();
				this.mStartMacroRecordingBtn.Visibility = Visibility.Visible;
				this.mStopMacroRecordingBtn.Visibility = Visibility.Collapsed;
				this.ParentWindow.mIsMacroRecorderActive = false;
			}), new object[0]);
		}

		// Token: 0x060008AB RID: 2219 RVA: 0x00032CB0 File Offset: 0x00030EB0
		internal void SaveOperation(string events)
		{
			try
			{
				if (!string.Equals(events, "[]", StringComparison.InvariantCulture))
				{
					string macroRecordingsFolderPath = RegistryStrings.MacroRecordingsFolderPath;
					MacroRecording macroRecording = new MacroRecording();
					string timeCreated = DateTime.Now.ToString("yyyyMMddTHHmmss", CultureInfo.InvariantCulture);
					macroRecording.TimeCreated = timeCreated;
					macroRecording.Name = CommonHandlers.GetMacroName("Macro");
					macroRecording.Events = JsonConvert.DeserializeObject<List<MacroEvents>>(events, Utils.GetSerializerSettings());
					this.SaveMacroRecord(macroRecording);
				}
				else
				{
					this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_OPERATION_MESSAGE"), 4.0, true);
				}
				this.PerformStopMacroAfterSave();
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in SaveOperations. Exception: " + ex.ToString());
			}
		}

		// Token: 0x060008AC RID: 2220 RVA: 0x00032D78 File Offset: 0x00030F78
		internal void SaveMacroRecord(MacroRecording record)
		{
			CommonHandlers.SaveMacroJson(record, record.Name + ".json");
			MacroGraph.Instance.AddVertex(record);
			MacroGraph.LinkMacroChilds(record);
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.ParentWindow.mIsMacroRecorderActive = false;
				foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
				{
					if (keyValuePair.Value.MacroRecorderWindow != null)
					{
						new SingleMacroControl(keyValuePair.Value, record, this).Tag = record.Name;
						keyValuePair.Value.MacroRecorderWindow.mNoScriptsGrid.Visibility = Visibility.Collapsed;
						this.mExport.IsEnabled = true;
						this.mExport.Opacity = 1.0;
						if (!keyValuePair.Value.mIsScriptsPresent)
						{
							keyValuePair.Value.mIsScriptsPresent = true;
						}
						keyValuePair.Value.MacroRecorderWindow.mScriptsStackPanel.Children.Clear();
						keyValuePair.Value.MacroRecorderWindow.Init();
						keyValuePair.Value.MacroRecorderWindow.mScriptsListScrollbar.ScrollToEnd();
						int index = keyValuePair.Value.MacroRecorderWindow.mScriptsStackPanel.Children.Count - 1;
						SingleMacroControl singleMacroControl = keyValuePair.Value.MacroRecorderWindow.mScriptsStackPanel.Children[index] as SingleMacroControl;
						BlueStacksUIBinding.BindColor(singleMacroControl.mGrid, System.Windows.Controls.Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
						BlueStacksUIBinding.BindColor(singleMacroControl.mScriptName, TextBlock.ForegroundProperty, "WhiteMouseOutBorderBackground");
						BlueStacksUIBinding.BindColor(singleMacroControl.mMacroShortcutTextBox, TextBlock.ForegroundProperty, "DualTextBlockForeground");
					}
				}
			}), new object[0]);
		}

		// Token: 0x060008AD RID: 2221 RVA: 0x000260D8 File Offset: 0x000242D8
		private void Topbar_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!e.OriginalSource.GetType().Equals(typeof(CustomPictureBox)))
			{
				try
				{
					base.DragMove();
				}
				catch
				{
				}
			}
		}

		// Token: 0x060008AE RID: 2222 RVA: 0x00032DF4 File Offset: 0x00030FF4
		internal void ToggleUI(bool isRecording)
		{
			if (isRecording)
			{
				this.mStopMacroRecordingBtn.Visibility = Visibility.Visible;
				this.mStartMacroRecordingBtn.Visibility = Visibility.Collapsed;
				this.mNoScriptsGrid.Visibility = Visibility.Collapsed;
				this.mScriptsGrid.Visibility = Visibility.Visible;
				return;
			}
			this.mStopMacroRecordingBtn.Visibility = Visibility.Collapsed;
			this.mStartMacroRecordingBtn.Visibility = Visibility.Visible;
			if (this.ParentWindow.mIsScriptsPresent)
			{
				this.mNoScriptsGrid.Visibility = Visibility.Collapsed;
				this.mScriptsGrid.Visibility = Visibility.Visible;
				return;
			}
			this.mNoScriptsGrid.Visibility = Visibility.Visible;
			this.mScriptsGrid.Visibility = Visibility.Collapsed;
		}

		// Token: 0x060008AF RID: 2223 RVA: 0x00032E8C File Offset: 0x0003108C
		private void ShowLoadingGrid(bool isShow)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (isShow)
				{
					this.mLoadingGrid.Visibility = Visibility.Visible;
					return;
				}
				this.mLoadingGrid.Visibility = Visibility.Collapsed;
			}), new object[0]);
		}

		// Token: 0x060008B0 RID: 2224 RVA: 0x00032ECC File Offset: 0x000310CC
		private void ExportBtn_Click(object sender, MouseButtonEventArgs e)
		{
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_window_export", null, null, null, null, null);
			if (this.ParentWindow.mIsScriptsPresent)
			{
				this.mOverlayGrid.Visibility = Visibility.Visible;
				if (this.mExportMacroWindow == null)
				{
					this.mExportMacroWindow = new ExportMacroWindow(this, this.ParentWindow)
					{
						Owner = this
					};
					this.mExportMacroWindow.Init();
					this.mExportMacroWindow.ShowDialog();
					return;
				}
			}
			else
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_MACRO_AVAILABLE"), 4.0, true);
			}
		}

		// Token: 0x060008B1 RID: 2225 RVA: 0x00032F78 File Offset: 0x00031178
		private void MergeMacroBtn_Click(object sender, MouseButtonEventArgs e)
		{
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "merge_icon", null, null, null, null, null);
			if (this.ParentWindow.mIsScriptsPresent)
			{
				this.mOverlayGrid.Visibility = Visibility.Visible;
				if (this.mMergeMacroWindow == null)
				{
					this.mMergeMacroWindow = new MergeMacroWindow(this, this.ParentWindow)
					{
						Owner = this.ParentWindow
					};
					this.mMergeMacroWindow.Init(null, null);
					this.mMergeMacroWindow.Show();
					return;
				}
			}
			else
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_MACRO_AVAILABLE"), 4.0, true);
			}
		}

		// Token: 0x060008B2 RID: 2226 RVA: 0x0003302C File Offset: 0x0003122C
		private void ImportBtn_Click(object sender, MouseButtonEventArgs e)
		{
			try
			{
				if (this.ParentWindow.mIsMacroPlaying)
				{
					CustomMessageWindow customMessageWindow = new CustomMessageWindow();
					customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_IMPORT_MACRO_WARNING");
					customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_MACRO_WARNING");
					customMessageWindow.AddButton(ButtonColors.Blue, LocaleStrings.GetLocalizedString("STRING_STOP_IMPORT"), delegate(object o, EventArgs e)
					{
						this.ParentWindow.mTopBar.mMacroPlayControl.StopMacro();
						this.ImportMacro();
					}, null, false, null);
					customMessageWindow.Owner = this;
					customMessageWindow.ShowDialog();
				}
				else
				{
					this.ImportMacro();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Importing file. err: " + ex.ToString());
				this.ShowLoadingGrid(false);
			}
		}

		// Token: 0x060008B3 RID: 2227 RVA: 0x000330DC File Offset: 0x000312DC
		private void ImportMacro()
		{
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_window_import", null, null, null, null, null);
			using (OpenFileDialog openFileDialog = new OpenFileDialog
			{
				Multiselect = true,
				Filter = "Json files (*.json)|*.json"
			})
			{
				if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK && openFileDialog.FileNames.Length != 0)
				{
					if (string.Equals(Path.GetDirectoryName(openFileDialog.FileNames[0]), RegistryStrings.MacroRecordingsFolderPath, StringComparison.InvariantCultureIgnoreCase))
					{
						CustomMessageWindow customMessageWindow = new CustomMessageWindow();
						customMessageWindow.Owner = this;
						BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_SAME_MACRO_EXISTS", "");
						customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", delegate(object o, EventArgs evt)
						{
						}, null, false, null);
						customMessageWindow.ShowDialog();
					}
					else
					{
						this.RunImportMacroScriptBacgroundWorker(openFileDialog.FileNames.ToList<string>());
					}
				}
			}
		}

		// Token: 0x060008B4 RID: 2228 RVA: 0x000331E0 File Offset: 0x000313E0
		internal void RunImportMacroScriptBacgroundWorker(List<string> fileNames)
		{
			using (BackgroundWorker backgroundWorker = new BackgroundWorker())
			{
				backgroundWorker.DoWork += this.BgImport_DoWork;
				backgroundWorker.RunWorkerCompleted += this.BgImport_RunWorkerCompleted;
				this.ShowLoadingGrid(true);
				backgroundWorker.RunWorkerAsync(fileNames);
			}
		}

		// Token: 0x060008B5 RID: 2229 RVA: 0x00033244 File Offset: 0x00031444
		private void BgImport_DoWork(object sender, DoWorkEventArgs e)
		{
			try
			{
				e.Result = this.CopyMacroScriptIfFileFormatSupported(e.Argument as List<string>);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Importing file. err: " + ex.ToString());
				e.Result = true;
			}
		}

		// Token: 0x060008B6 RID: 2230 RVA: 0x00007970 File Offset: 0x00005B70
		private void BgImport_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			this.ValidateReturnCode((int)e.Result);
			if ((int)e.Result == 0)
			{
				CommonHandlers.RefreshAllMacroWindowWithScroll();
			}
		}

		// Token: 0x060008B7 RID: 2231 RVA: 0x000332A4 File Offset: 0x000314A4
		internal void ValidateReturnCode(int retCode)
		{
			this.ShowLoadingGrid(false);
			if (retCode == 2)
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_FILE_FORMAT_NOT_SUPPORTED"), 4.0, true);
				return;
			}
			if (retCode == 3)
			{
				this.ShowMacroImportWizard();
				if (this.mNewlyAddedMacrosList.Count > 0)
				{
					CommonHandlers.RefreshAllMacroWindowWithScroll();
					this.ShowMacroImportSuccessPopup();
					return;
				}
			}
			else
			{
				if (retCode == 1)
				{
					this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_IMPORTING_CANCELLED"), 4.0, true);
					return;
				}
				if (retCode == 0)
				{
					if (!Directory.Exists(RegistryStrings.MacroRecordingsFolderPath))
					{
						Directory.CreateDirectory(RegistryStrings.MacroRecordingsFolderPath);
					}
					this.ShowMacroImportSuccessPopup();
				}
			}
		}

		// Token: 0x060008B8 RID: 2232 RVA: 0x00033350 File Offset: 0x00031550
		internal int CopyMacroScriptIfFileFormatSupported(List<string> selectedFileNames)
		{
			int result;
			try
			{
				this.mRenamingMacrosList.Clear();
				bool flag = false;
				List<string> list = new List<string>();
				List<MacroRecording> list2 = new List<MacroRecording>();
				foreach (string path in selectedFileNames)
				{
					MacroRecording macroRecording = JsonConvert.DeserializeObject<MacroRecording>(File.ReadAllText(path), Utils.GetSerializerSettings());
					if (macroRecording == null || string.IsNullOrEmpty(macroRecording.Name) || string.IsNullOrEmpty(macroRecording.TimeCreated) || (macroRecording.RecordingType == RecordingTypes.MultiRecording && (macroRecording.SourceRecordings == null || !macroRecording.SourceRecordings.Any<string>())))
					{
						list.Add(Path.GetFileNameWithoutExtension(path));
					}
					else
					{
						list2.Add(macroRecording);
					}
				}
				if (list2.Any((MacroRecording x) => x.RecordingType == RecordingTypes.MultiRecording))
				{
					this.AskUserHowToImportMultiMacro();
					if (this.mImportMultiMacroAsUnified == null)
					{
						return 1;
					}
				}
				int num = this.ImportMacroRecordings(list2, ref flag);
				if (num != 0)
				{
					result = num;
				}
				else
				{
					if (list.Count > 0)
					{
						string message = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_INVALID_FILES_LIST"), new object[]
						{
							string.Join(", ", list.ToArray())
						});
						this.ParentWindow.mCommonHandler.AddToastPopup(this, message, 4.0, true);
						if (list2.Count <= 0)
						{
							return 4;
						}
					}
					if (flag)
					{
						result = 3;
					}
					else
					{
						result = 0;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Wrong file format wont import. err:" + ex.ToString());
				result = 2;
			}
			return result;
		}

		// Token: 0x060008B9 RID: 2233 RVA: 0x00033528 File Offset: 0x00031728
		internal int ImportMacroRecordings(List<MacroRecording> recordingsToImport, ref bool isShowRenameWizard)
		{
			try
			{
				this.mNewlyAddedMacrosList.Clear();
				foreach (MacroRecording macroRecording in recordingsToImport)
				{
					macroRecording.Shortcut = string.Empty;
					macroRecording.PlayOnStart = false;
					if (MacroRecorderWindow.CheckIfDuplicateMacroInImport(macroRecording.Name.ToLower(CultureInfo.InvariantCulture).Trim()))
					{
						isShowRenameWizard = true;
						this.mRenamingMacrosList.Add(macroRecording);
					}
					if (macroRecording.RecordingType == RecordingTypes.MultiRecording)
					{
						bool flag = false;
						bool? flag2 = this.mImportMultiMacroAsUnified;
						if ((flag == flag2.GetValueOrDefault() & flag2 != null) && !this.mRenamingMacrosList.Contains(macroRecording))
						{
							new List<string>();
							if (MacroRecorderWindow.CheckIfDuplicateMacroInImport(macroRecording.Name, macroRecording.MergedMacroConfigurations.SelectMany((MergedMacroConfiguration macro) => macro.MacrosToRun)))
							{
								isShowRenameWizard = true;
								this.mRenamingMacrosList.AddIfNotContain(macroRecording);
							}
						}
					}
					if (!this.mRenamingMacrosList.Contains(macroRecording))
					{
						macroRecording.Name = macroRecording.Name.Trim();
						if (macroRecording.RecordingType == RecordingTypes.SingleRecording)
						{
							MacroGraph.Instance.AddVertex(macroRecording);
							this.mNewlyAddedMacrosList.Add(macroRecording);
							CommonHandlers.SaveMacroJson(macroRecording, macroRecording.Name + ".json");
						}
						else
						{
							this.ImportMultiMacro(macroRecording, this.mImportMultiMacroAsUnified.Value, this.mNewlyAddedMacrosList, null);
						}
					}
				}
				foreach (MacroRecording macro2 in this.mNewlyAddedMacrosList)
				{
					MacroGraph.LinkMacroChilds(macro2);
				}
			}
			catch
			{
				throw;
			}
			return 0;
		}

		// Token: 0x060008BA RID: 2234 RVA: 0x00007995 File Offset: 0x00005B95
		private void AskUserHowToImportMultiMacro()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_IMPORT_DEPENDENT_MACRO", "");
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_IMPORT_ALL_MACROS", delegate(object o, EventArgs evt)
				{
					this.mImportMultiMacroAsUnified = new bool?(false);
					ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "merge_import_all", null, null, null, null, null);
				}, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, "STRING_IMPORT_UNIFIED", delegate(object o, EventArgs evt)
				{
					this.mImportMultiMacroAsUnified = new bool?(true);
					ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "merge_import_unify", null, null, null, null, null);
				}, null, false, null);
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_IMPORT_DEPENDENT_MACRO_UNIFIED", "");
				customMessageWindow.BodyWarningTextBlock.Visibility = Visibility.Visible;
				BlueStacksUIBinding.Bind(customMessageWindow.BodyWarningTextBlock, "STRING_UNIFIYING_LOSE_CONFIGURE", "");
				customMessageWindow.CloseButtonHandle(delegate(object o, EventArgs evt)
				{
					ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "merge_import_cancel", null, null, null, null, null);
					this.mImportMultiMacroAsUnified = null;
				}, null);
				customMessageWindow.Owner = this;
				customMessageWindow.ShowDialog();
			}), new object[0]);
		}

		// Token: 0x060008BB RID: 2235 RVA: 0x00033720 File Offset: 0x00031920
		private List<MacroEvents> GetFlattenedEventsFromMultiRecording(MacroRecording srcRecording, long initialTime, out long elapsedTime, bool isExternalMacro = false)
		{
			List<MacroEvents> list = new List<MacroEvents>();
			elapsedTime = initialTime;
			List<MacroRecording> list2 = MacroGraph.Instance.Vertices.Cast<MacroRecording>().ToList<MacroRecording>();
			if (isExternalMacro)
			{
				list2.Clear();
				foreach (string value in srcRecording.SourceRecordings)
				{
					MacroRecording item = JsonConvert.DeserializeObject<MacroRecording>(value, Utils.GetSerializerSettings());
					list2.Add(item);
				}
			}
			try
			{
				foreach (MergedMacroConfiguration mergedMacroConfiguration in srcRecording.MergedMacroConfigurations)
				{
					for (int i = 0; i < mergedMacroConfiguration.LoopCount; i++)
					{
						using (IEnumerator<string> enumerator3 = mergedMacroConfiguration.MacrosToRun.GetEnumerator())
						{
							while (enumerator3.MoveNext())
							{
								string gMacro = enumerator3.Current;
								MacroRecording macroRecording = (from macro in list2
								where string.Equals(gMacro, macro.Name, StringComparison.InvariantCultureIgnoreCase)
								select macro).FirstOrDefault<MacroRecording>();
								if (macroRecording.RecordingType == RecordingTypes.SingleRecording)
								{
									list.AddRange(MacroRecorderWindow.GetRecordingEventsFromSourceRecording(macroRecording, mergedMacroConfiguration.Acceleration, elapsedTime, ref elapsedTime));
								}
								else
								{
									list.AddRange(this.GetFlattenedEventsFromMultiRecording(macroRecording, elapsedTime, out elapsedTime, false));
								}
								elapsedTime += (long)(mergedMacroConfiguration.LoopInterval * 1000);
							}
						}
						elapsedTime += (long)(mergedMacroConfiguration.DelayNextScript * 1000);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't get flattened events. Ex: {0}", new object[]
				{
					ex
				});
			}
			return list;
		}

		// Token: 0x060008BC RID: 2236 RVA: 0x00033918 File Offset: 0x00031B18
		internal void FlattenRecording(MacroRecording srcRecording, bool isExternalMacro = false)
		{
			Logger.Info("Will attempt to flatten {0}", new object[]
			{
				srcRecording.Name
			});
			long num;
			srcRecording.Events = this.GetFlattenedEventsFromMultiRecording(srcRecording, 0L, out num, isExternalMacro);
			srcRecording.SourceRecordings = null;
			srcRecording.MergedMacroConfigurations = null;
		}

		// Token: 0x060008BD RID: 2237 RVA: 0x00033960 File Offset: 0x00031B60
		private static MacroRecording GetFixedMultiMacroSourceRecording(MacroRecording record, string baseChildRecordingName)
		{
			try
			{
				MacroRecording macroRecording = record.DeepCopy<MacroRecording>();
				macroRecording.Name = MacroRecorderWindow.GetDependentRecordingName(baseChildRecordingName, macroRecording.Name);
				macroRecording.MergedMacroConfigurations.Clear();
				foreach (MergedMacroConfiguration mergedMacroConfiguration in record.MergedMacroConfigurations)
				{
					MergedMacroConfiguration mergedMacroConfiguration2 = mergedMacroConfiguration.DeepCopy<MergedMacroConfiguration>();
					mergedMacroConfiguration2.MacrosToRun.Clear();
					foreach (string dependentMacroName in mergedMacroConfiguration.MacrosToRun)
					{
						mergedMacroConfiguration2.MacrosToRun.Add(MacroRecorderWindow.GetDependentRecordingName(baseChildRecordingName, dependentMacroName));
					}
					macroRecording.MergedMacroConfigurations.Add(mergedMacroConfiguration2);
				}
				record = macroRecording;
				record.SourceRecordings = null;
			}
			catch (Exception ex)
			{
				Logger.Error("Some error occured while fixing dependent source multi macro: Ex: {0}", new object[]
				{
					ex
				});
			}
			return record;
		}

		// Token: 0x060008BE RID: 2238 RVA: 0x00033A64 File Offset: 0x00031C64
		internal void ImportMultiMacro(MacroRecording record, bool flatten, List<MacroRecording> newlyAddedMacro, Dictionary<string, string> dependentMacroNewNamesDict = null)
		{
			if (flatten)
			{
				this.FlattenRecording(record, true);
				if (dependentMacroNewNamesDict != null && dependentMacroNewNamesDict.ContainsKey(record.Name))
				{
					record.Name = dependentMacroNewNamesDict[record.Name];
				}
			}
			else
			{
				try
				{
					MacroRecording macroRecording = record.DeepCopy<MacroRecording>();
					string text = record.Name;
					if (dependentMacroNewNamesDict != null && dependentMacroNewNamesDict.ContainsKey(record.Name))
					{
						text = dependentMacroNewNamesDict[record.Name];
						macroRecording.Name = text;
					}
					foreach (string value in record.SourceRecordings)
					{
						MacroRecording macroRecording2 = JsonConvert.DeserializeObject<MacroRecording>(value, Utils.GetSerializerSettings());
						if (macroRecording2.RecordingType == RecordingTypes.MultiRecording)
						{
							macroRecording2 = MacroRecorderWindow.GetFixedMultiMacroSourceRecording(macroRecording2, text);
						}
						else
						{
							string name = macroRecording2.Name;
							string name2 = MacroRecorderWindow.GetDependentRecordingName(text, name);
							if (dependentMacroNewNamesDict != null && dependentMacroNewNamesDict.ContainsKey(name))
							{
								name2 = dependentMacroNewNamesDict[name];
							}
							macroRecording2.Name = name2;
						}
						MacroGraph.Instance.AddVertex(macroRecording2);
						newlyAddedMacro.Add(macroRecording2);
						CommonHandlers.SaveMacroJson(macroRecording2, macroRecording2.Name + ".json");
					}
					macroRecording.MergedMacroConfigurations.Clear();
					foreach (MergedMacroConfiguration mergedMacroConfiguration in record.MergedMacroConfigurations)
					{
						MergedMacroConfiguration mergedMacroConfiguration2 = mergedMacroConfiguration.DeepCopy<MergedMacroConfiguration>();
						mergedMacroConfiguration2.MacrosToRun.Clear();
						new ObservableCollection<string>();
						foreach (string text2 in mergedMacroConfiguration.MacrosToRun)
						{
							string item = MacroRecorderWindow.GetDependentRecordingName(text, text2);
							if (dependentMacroNewNamesDict != null && dependentMacroNewNamesDict.ContainsKey(text2))
							{
								item = dependentMacroNewNamesDict[text2];
							}
							mergedMacroConfiguration2.MacrosToRun.Add(item);
						}
						macroRecording.MergedMacroConfigurations.Add(mergedMacroConfiguration2);
					}
					record = macroRecording;
				}
				catch (Exception ex)
				{
					Logger.Error("Some error occured: Ex: {0}", new object[]
					{
						ex
					});
				}
				record.SourceRecordings = null;
			}
			MacroGraph.Instance.AddVertex(record);
			newlyAddedMacro.Add(record);
			CommonHandlers.SaveMacroJson(record, record.Name + ".json");
		}

		// Token: 0x060008BF RID: 2239 RVA: 0x00033D08 File Offset: 0x00031F08
		private static List<MacroEvents> GetRecordingEventsFromSourceRecording(MacroRecording srcRecording, double acceleration, long initialTime, ref long elapsedTime)
		{
			if (srcRecording == null)
			{
				throw new Exception("Source recording now found in multiMacro");
			}
			List<MacroEvents> list = new List<MacroEvents>();
			foreach (MacroEvents macroEvents in srcRecording.Events)
			{
				MacroEvents macroEvents2 = macroEvents.DeepCopy<MacroEvents>();
				macroEvents2.Timestamp = (long)Math.Floor((double)macroEvents.Timestamp / acceleration);
				macroEvents2.Timestamp += initialTime;
				elapsedTime = macroEvents2.Timestamp;
				list.Add(macroEvents2);
			}
			return list;
		}

		// Token: 0x060008C0 RID: 2240 RVA: 0x00033DA4 File Offset: 0x00031FA4
		private static bool CheckIfDuplicateMacroInImport(string origMacroName, IEnumerable<string> lsMacros)
		{
			foreach (string originalMacroName in lsMacros)
			{
				string dependentRecordingName = MacroRecorderWindow.GetDependentRecordingName(originalMacroName, origMacroName);
				if ((from MacroRecording macro in MacroGraph.Instance.Vertices
				select macro.Name.ToLower(CultureInfo.InvariantCulture)).Contains(dependentRecordingName.ToLower(CultureInfo.InvariantCulture)))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x060008C1 RID: 2241 RVA: 0x000079B5 File Offset: 0x00005BB5
		internal static string GetDependentRecordingName(string originalMacroName, string dependentMacroName)
		{
			return originalMacroName + "-" + dependentMacroName;
		}

		// Token: 0x060008C2 RID: 2242 RVA: 0x00033E38 File Offset: 0x00032038
		private static bool CheckIfDuplicateMacroInImport(string macroName)
		{
			return (from MacroRecording macro in MacroGraph.Instance.Vertices
			select macro.Name.ToLower(CultureInfo.InvariantCulture)).Contains(macroName.ToLower(CultureInfo.InvariantCulture));
		}

		// Token: 0x060008C3 RID: 2243 RVA: 0x000079C3 File Offset: 0x00005BC3
		private void ShowMacroImportWizard()
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mOverlayGrid.Visibility = Visibility.Visible;
				if (this.mImportMacroWindow == null)
				{
					this.mImportMacroWindow = new ImportMacroWindow(this, this.ParentWindow)
					{
						Owner = this
					};
					this.mImportMacroWindow.Init();
					this.mImportMacroWindow.ShowDialog();
				}
			}), new object[0]);
		}

		// Token: 0x060008C4 RID: 2244 RVA: 0x000079E3 File Offset: 0x00005BE3
		private void MImportBtn_Click(object sender, RoutedEventArgs e)
		{
			CommonHandlers.RefreshAllMacroWindowWithScroll();
		}

		// Token: 0x060008C5 RID: 2245 RVA: 0x00033E90 File Offset: 0x00032090
		private void mBGMacroPlaybackWorker_DoWork(BackgroundWorker bg, MacroRecording record)
		{
			if (File.Exists(CommonHandlers.GetCompleteMacroRecordingPath(record.Name)) && !this.ParentWindow.mIsMacroPlaying)
			{
				Logger.Debug("Macro Playback started");
				this.ParentWindow.mIsMacroPlaying = true;
				this.ParentWindow.mFrontendHandler.SendFrontendRequest("initMacroPlayback", new Dictionary<string, string>
				{
					{
						"scriptFilePath",
						CommonHandlers.GetCompleteMacroRecordingPath(record.Name)
					}
				});
				switch (record.LoopType)
				{
				case OperationsLoopType.TillLoopNumber:
					this.HandleMacroPlaybackTillLoopNumber(bg, record);
					return;
				case OperationsLoopType.TillTime:
					this.HandleMacroPlaybackTillTime(bg, record);
					return;
				case OperationsLoopType.UntilStopped:
					this.HandleMacroPlaybackUntillStopped(bg, record);
					break;
				default:
					return;
				}
			}
		}

		// Token: 0x060008C6 RID: 2246 RVA: 0x00033F3C File Offset: 0x0003213C
		internal void RunMacroOperation(MacroRecording record)
		{
			BackgroundWorker bg = new BackgroundWorker
			{
				WorkerSupportsCancellation = true
			};
			bg.DoWork += delegate(object obj, DoWorkEventArgs e)
			{
				this.mBGMacroPlaybackWorker_DoWork(bg, record);
			};
			this.mBGMacroPlaybackWorker = bg;
			bg.RunWorkerAsync();
		}

		// Token: 0x060008C7 RID: 2247 RVA: 0x00033FA0 File Offset: 0x000321A0
		private void HandleMacroPlaybackUntillStopped(BackgroundWorker bg, MacroRecording record)
		{
			try
			{
				EventWaitHandle eventWaitHandle = null;
				string macroPlaybackEventName = BlueStacksUIUtils.GetMacroPlaybackEventName(this.ParentWindow.mVmName);
				this.ParentWindow.mCommonHandler.InitUiOnMacroPlayback(record);
				int num = 1;
				this.UpdateMacroPlayBackUI(num, record);
				while (this.ParentWindow.mIsMacroPlaying && !bg.CancellationPending)
				{
					this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("runMacroUnit", null);
					if (eventWaitHandle == null)
					{
						eventWaitHandle = new EventWaitHandle(false, EventResetMode.AutoReset, macroPlaybackEventName);
					}
					this.UpdateMacroPlayBackUI(num, record);
					num++;
					eventWaitHandle.WaitOne();
					Thread.Sleep(record.LoopInterval * 1000);
				}
				eventWaitHandle.Close();
			}
			catch (Exception ex)
			{
				Logger.Error("Error in macroplaybackuntil stopped. err:" + ex.ToString());
			}
		}

		// Token: 0x060008C8 RID: 2248 RVA: 0x00034068 File Offset: 0x00032268
		private void HandleMacroPlaybackTillTime(BackgroundWorker bg, MacroRecording record)
		{
			try
			{
				if (record.LoopTime > 0)
				{
					EventWaitHandle eventWaitHandle = null;
					string macroPlaybackEventName = BlueStacksUIUtils.GetMacroPlaybackEventName(this.ParentWindow.mVmName);
					this.mMacroLoopTimer = new System.Timers.Timer((double)record.LoopTime)
					{
						Interval = (double)(record.LoopTime * 1000)
					};
					this.mMacroLoopTimer.Elapsed += delegate(object sender, ElapsedEventArgs e)
					{
						this.MacroLoopTimer_Elapsed(record.Name);
					};
					DateTime now = DateTime.Now;
					TimeSpan timeSpan = DateTime.Now - now;
					this.ParentWindow.mCommonHandler.InitUiOnMacroPlayback(record);
					this.mMacroLoopTimer.Enabled = true;
					int i = 1;
					this.UpdateMacroPlayBackUI(i, record);
					while (timeSpan.TotalSeconds < (double)record.LoopTime && this.ParentWindow.mIsMacroPlaying && !bg.CancellationPending)
					{
						this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("runMacroUnit", null);
						if (eventWaitHandle == null)
						{
							eventWaitHandle = new EventWaitHandle(false, EventResetMode.AutoReset, macroPlaybackEventName);
						}
						eventWaitHandle.WaitOne();
						Thread.Sleep(record.LoopInterval * 1000);
						timeSpan = DateTime.Now - now;
					}
					eventWaitHandle.Close();
				}
				else
				{
					this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_TIMER_SET"), 4.0, true);
					Logger.Debug("Macro timer set to ZERO");
					this.SendStopMacroEventsAndUpdateUi(record.Name);
				}
				if (this.mMacroLoopTimer != null)
				{
					this.mMacroLoopTimer.Enabled = false;
					this.mMacroLoopTimer = null;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in MacroPlaybacktillTime. err:" + ex.ToString());
			}
		}

		// Token: 0x060008C9 RID: 2249 RVA: 0x000079EA File Offset: 0x00005BEA
		private void MacroLoopTimer_Elapsed(string fileName)
		{
			Logger.Debug("Macro timer finished");
			this.SendStopMacroEventsAndUpdateUi(fileName);
		}

		// Token: 0x060008CA RID: 2250 RVA: 0x0003424C File Offset: 0x0003244C
		private void SendStopMacroEventsAndUpdateUi(string fileName)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.ParentWindow.mCommonHandler.StopMacroScriptHandling();
				if (FeatureManager.Instance.IsCustomUIForNCSoft)
				{
					this.ParentWindow.mNCTopBar.mMacroPlayControl.OnScriptStopEvent(fileName);
					return;
				}
				this.ParentWindow.mTopBar.mMacroPlayControl.OnScriptStopEvent(fileName);
			}), new object[0]);
		}

		// Token: 0x060008CB RID: 2251 RVA: 0x00034290 File Offset: 0x00032490
		private void HandleMacroPlaybackTillLoopNumber(BackgroundWorker bg, MacroRecording record)
		{
			try
			{
				string macroPlaybackEventName = BlueStacksUIUtils.GetMacroPlaybackEventName(this.ParentWindow.mVmName);
				if (record.LoopNumber >= 1)
				{
					this.ParentWindow.mCommonHandler.InitUiOnMacroPlayback(record);
				}
				else
				{
					this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_LOOP_ITERATION_SET"), 4.0, true);
					Logger.Debug("Macro loop iterations set to ZERO");
				}
				EventWaitHandle eventWaitHandle = new EventWaitHandle(false, EventResetMode.AutoReset, macroPlaybackEventName);
				int num = 1;
				while (num <= record.LoopNumber && this.ParentWindow.mIsMacroPlaying && !bg.CancellationPending)
				{
					this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("runMacroUnit", null);
					this.UpdateMacroPlayBackUI(num, record);
					eventWaitHandle.WaitOne();
					if (num != record.LoopNumber)
					{
						Thread.Sleep(record.LoopInterval * 1000);
					}
					num++;
				}
				eventWaitHandle.Close();
				if (!bg.CancellationPending && this.ParentWindow.mIsMacroPlaying)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						this.ParentWindow.mCommonHandler.StopMacroPlaybackOperation();
						if (FeatureManager.Instance.IsCustomUIForNCSoft)
						{
							this.ParentWindow.mNCTopBar.mMacroPlayControl.OnScriptStopEvent(record.Name);
							return;
						}
						this.ParentWindow.mTopBar.mMacroPlayControl.OnScriptStopEvent(record.Name);
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception err: " + ex.ToString());
			}
		}

		// Token: 0x060008CC RID: 2252 RVA: 0x00034410 File Offset: 0x00032610
		private void UpdateMacroPlayBackUI(int i, MacroRecording record)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (record.LoopType == OperationsLoopType.TillLoopNumber)
				{
					if (FeatureManager.Instance.IsCustomUIForNCSoft)
					{
						this.ParentWindow.mNCTopBar.mMacroPlayControl.mTimerDisplay.Visibility = Visibility.Collapsed;
						this.ParentWindow.mNCTopBar.mMacroPlayControl.mRunningIterations.Visibility = Visibility.Visible;
						this.ParentWindow.mNCTopBar.mMacroPlayControl.IncreaseIteration(i);
						return;
					}
					this.ParentWindow.mTopBar.mMacroPlayControl.mTimerDisplay.Visibility = Visibility.Collapsed;
					this.ParentWindow.mTopBar.mMacroPlayControl.mRunningIterations.Visibility = Visibility.Visible;
					this.ParentWindow.mTopBar.mMacroPlayControl.IncreaseIteration(i);
					return;
				}
				else if (record.LoopType == OperationsLoopType.TillTime)
				{
					if (FeatureManager.Instance.IsCustomUIForNCSoft)
					{
						this.ParentWindow.mNCTopBar.mMacroPlayControl.UpdateUiForIterationTillTime();
						return;
					}
					this.ParentWindow.mTopBar.mMacroPlayControl.UpdateUiForIterationTillTime();
					return;
				}
				else
				{
					if (FeatureManager.Instance.IsCustomUIForNCSoft)
					{
						this.ParentWindow.mNCTopBar.mMacroPlayControl.UpdateUiMacroPlaybackForInfiniteTime(i);
						return;
					}
					this.ParentWindow.mTopBar.mMacroPlayControl.UpdateUiMacroPlaybackForInfiniteTime(i);
					return;
				}
			}), new object[0]);
		}

		// Token: 0x060008CD RID: 2253 RVA: 0x0003445C File Offset: 0x0003265C
		private void OpenFolder_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			try
			{
				if (!Directory.Exists(RegistryStrings.MacroRecordingsFolderPath))
				{
					Directory.CreateDirectory(RegistryStrings.MacroRecordingsFolderPath);
				}
				using (Process process = new Process())
				{
					process.StartInfo.UseShellExecute = true;
					process.StartInfo.FileName = RegistryStrings.MacroRecordingsFolderPath;
					process.Start();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Some error in Open folder err: " + ex.ToString());
			}
		}

		// Token: 0x060008CE RID: 2254 RVA: 0x000079FD File Offset: 0x00005BFD
		protected virtual void Dispose(bool disposing)
		{
			if (!this.disposedValue)
			{
				BackgroundWorker backgroundWorker = this.mBGMacroPlaybackWorker;
				if (backgroundWorker != null)
				{
					backgroundWorker.Dispose();
				}
				System.Timers.Timer timer = this.mMacroLoopTimer;
				if (timer != null)
				{
					timer.Dispose();
				}
				this.disposedValue = true;
			}
		}

		// Token: 0x060008CF RID: 2255 RVA: 0x000344EC File Offset: 0x000326EC
		~MacroRecorderWindow()
		{
			this.Dispose(false);
		}

		// Token: 0x060008D0 RID: 2256 RVA: 0x00007A32 File Offset: 0x00005C32
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x060008D1 RID: 2257 RVA: 0x0003451C File Offset: 0x0003271C
		private void OpenCommunityBtn_Click(object sender, RoutedEventArgs e)
		{
			if (string.Equals((sender as CustomButton).Name, "mOpenCommunityBtn", StringComparison.InvariantCultureIgnoreCase))
			{
				ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_community_opened", "Open_Community_Button", null, null, null, null);
			}
			else
			{
				ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_community_opened", "Get_Macro_Button", null, null, null, null);
			}
			AppTabButton selectedTab = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab;
			this.OpenCommunityAndCloseMacroWindow(BlueStacksUIUtils.GetMacroCommunityUrl((selectedTab != null) ? selectedTab.PackageName : null));
		}

		// Token: 0x060008D2 RID: 2258 RVA: 0x000345C8 File Offset: 0x000327C8
		internal void OpenCommunityAndCloseMacroWindow(string url)
		{
			AppTabButtons mAppTabButtons = this.ParentWindow.mTopBar.mAppTabButtons;
			string url2 = url;
			if (url == null)
			{
				AppTabButton selectedTab = this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab;
				url2 = BlueStacksUIUtils.GetMacroCommunityUrl((selectedTab != null) ? selectedTab.PackageName : null);
			}
			mAppTabButtons.AddWebTab(url2, "STRING_MACRO_COMMUNITY", "community_big", true, "STRING_MACRO_COMMUNITY", false);
			this.ParentWindow.mCommonHandler.HideMacroRecorderWindow();
			this.ParentWindow.Focus();
		}

		// Token: 0x060008D3 RID: 2259 RVA: 0x00007A41 File Offset: 0x00005C41
		internal void ShowMacroImportSuccessPopup()
		{
			this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_MACRO_IMPORT_SUCCESS"), 2.0, true);
		}

		// Token: 0x060008D4 RID: 2260 RVA: 0x00007A68 File Offset: 0x00005C68
		private void CustomWindow_Closing(object sender, CancelEventArgs e)
		{
			base.Visibility = Visibility.Hidden;
			e.Cancel = true;
		}

		// Token: 0x060008D5 RID: 2261 RVA: 0x00034644 File Offset: 0x00032844
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/macrorecorderwindow.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060008D6 RID: 2262 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060008D7 RID: 2263 RVA: 0x00034674 File Offset: 0x00032874
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((MacroRecorderWindow)target).Closing += this.CustomWindow_Closing;
				return;
			case 2:
				this.mOperationRecorderBorder = (Border)target;
				return;
			case 3:
				this.mMaskBorder = (Border)target;
				return;
			case 4:
				((Grid)target).MouseDown += this.Topbar_MouseDown;
				return;
			case 5:
				((CustomPictureBox)target).MouseLeftButtonUp += this.Close_MouseLeftButtonUp;
				return;
			case 6:
				this.mMerge = (CustomPictureBox)target;
				this.mMerge.MouseLeftButtonUp += this.MergeMacroBtn_Click;
				return;
			case 7:
				this.mImport = (CustomPictureBox)target;
				this.mImport.MouseLeftButtonUp += this.ImportBtn_Click;
				return;
			case 8:
				this.mExport = (CustomPictureBox)target;
				this.mExport.MouseLeftButtonUp += this.ExportBtn_Click;
				return;
			case 9:
				this.mOpenFolder = (CustomPictureBox)target;
				this.mOpenFolder.MouseLeftButtonUp += this.OpenFolder_MouseLeftButtonUp;
				return;
			case 10:
				this.mStartMacroRecordingBtn = (CustomButton)target;
				this.mStartMacroRecordingBtn.Click += this.mStartMacroRecordingBtn_Click;
				return;
			case 11:
				this.mStopMacroRecordingBtn = (CustomButton)target;
				this.mStopMacroRecordingBtn.Click += this.mStopMacroRecordingBtn_Click;
				return;
			case 12:
				this.mGetMacroBtn = (CustomButton)target;
				this.mGetMacroBtn.Click += this.OpenCommunityBtn_Click;
				return;
			case 13:
				this.mNoScriptsGrid = (Border)target;
				return;
			case 14:
				this.mScriptsGrid = (Grid)target;
				return;
			case 15:
				this.mScriptsListScrollbar = (ScrollViewer)target;
				return;
			case 16:
				this.mOpenCommunityBtn = (CustomButton)target;
				this.mOpenCommunityBtn.Click += this.OpenCommunityBtn_Click;
				return;
			case 17:
				this.mLoadingGrid = (BlueStacks.BlueStacksUI.ProgressBar)target;
				return;
			case 18:
				this.mOverlayGrid = (Grid)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400054C RID: 1356
		private MainWindow ParentWindow;

		// Token: 0x0400054D RID: 1357
		internal string mMacroOnRestart;

		// Token: 0x0400054E RID: 1358
		internal StackPanel mScriptsStackPanel;

		// Token: 0x0400054F RID: 1359
		private System.Timers.Timer mMacroLoopTimer;

		// Token: 0x04000550 RID: 1360
		internal ExportMacroWindow mExportMacroWindow;

		// Token: 0x04000551 RID: 1361
		internal MergeMacroWindow mMergeMacroWindow;

		// Token: 0x04000552 RID: 1362
		internal ImportMacroWindow mImportMacroWindow;

		// Token: 0x04000553 RID: 1363
		internal List<MacroRecording> mRenamingMacrosList = new List<MacroRecording>();

		// Token: 0x04000554 RID: 1364
		internal List<MacroRecording> mNewlyAddedMacrosList = new List<MacroRecording>();

		// Token: 0x04000555 RID: 1365
		internal bool? mImportMultiMacroAsUnified;

		// Token: 0x04000556 RID: 1366
		private bool mAlternateBackgroundColor;

		// Token: 0x04000557 RID: 1367
		internal BackgroundWorker mBGMacroPlaybackWorker;

		// Token: 0x04000558 RID: 1368
		private bool disposedValue;

		// Token: 0x04000559 RID: 1369
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mOperationRecorderBorder;

		// Token: 0x0400055A RID: 1370
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder;

		// Token: 0x0400055B RID: 1371
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mMerge;

		// Token: 0x0400055C RID: 1372
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mImport;

		// Token: 0x0400055D RID: 1373
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mExport;

		// Token: 0x0400055E RID: 1374
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mOpenFolder;

		// Token: 0x0400055F RID: 1375
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mStartMacroRecordingBtn;

		// Token: 0x04000560 RID: 1376
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mStopMacroRecordingBtn;

		// Token: 0x04000561 RID: 1377
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mGetMacroBtn;

		// Token: 0x04000562 RID: 1378
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mNoScriptsGrid;

		// Token: 0x04000563 RID: 1379
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mScriptsGrid;

		// Token: 0x04000564 RID: 1380
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ScrollViewer mScriptsListScrollbar;

		// Token: 0x04000565 RID: 1381
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mOpenCommunityBtn;

		// Token: 0x04000566 RID: 1382
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal BlueStacks.BlueStacksUI.ProgressBar mLoadingGrid;

		// Token: 0x04000567 RID: 1383
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mOverlayGrid;

		// Token: 0x04000568 RID: 1384
		private bool _contentLoaded;
	}
}
