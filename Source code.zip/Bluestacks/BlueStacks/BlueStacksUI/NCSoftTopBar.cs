﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000CB RID: 203
	public class NCSoftTopBar : UserControl, ITopBar, IComponentConnector
	{
		// Token: 0x170001CD RID: 461
		// (get) Token: 0x06000840 RID: 2112 RVA: 0x00007459 File Offset: 0x00005659
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x170001CE RID: 462
		// (get) Token: 0x06000841 RID: 2113 RVA: 0x0000747A File Offset: 0x0000567A
		// (set) Token: 0x06000842 RID: 2114 RVA: 0x00007487 File Offset: 0x00005687
		string ITopBar.AppName
		{
			get
			{
				return this.mAppName.Text;
			}
			set
			{
				this.mAppName.Text = value;
			}
		}

		// Token: 0x170001CF RID: 463
		// (get) Token: 0x06000843 RID: 2115 RVA: 0x00007495 File Offset: 0x00005695
		// (set) Token: 0x06000844 RID: 2116 RVA: 0x000074A2 File Offset: 0x000056A2
		string ITopBar.CharacterName
		{
			get
			{
				return this.mCharacterName.Text;
			}
			set
			{
				this.mCharacterName.Text = value;
			}
		}

		// Token: 0x06000845 RID: 2117 RVA: 0x000074B0 File Offset: 0x000056B0
		public NCSoftTopBar()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000846 RID: 2118 RVA: 0x000074BE File Offset: 0x000056BE
		public void ChangeTopBarColor(string color)
		{
			BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, color);
		}

		// Token: 0x06000847 RID: 2119 RVA: 0x000300E0 File Offset: 0x0002E2E0
		private void ParentWindow_GuestBootCompletedEvent(object sender, EventArgs args)
		{
			if (this.ParentWindow.EngineInstanceRegistry.IsSidebarVisible && base.Visibility == Visibility.Visible && this.ParentWindow.mSidebar.Visibility != Visibility.Visible && !FeatureManager.Instance.IsCustomUIForDMM)
			{
				this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					this.ParentWindow.mCommonHandler.FlipSidebarVisibility(this.mSidebarButtonImage, this.mSidebarButtonText);
				}), new object[0]);
			}
		}

		// Token: 0x06000848 RID: 2120 RVA: 0x00030148 File Offset: 0x0002E348
		private void NCSoftTopBar_Loaded(object sender, RoutedEventArgs e)
		{
			if (!this.ParentWindow.mGuestBootCompleted)
			{
				this.ParentWindow.mCommonHandler.SetSidebarImageProperties(false, this.mSidebarButtonImage, this.mSidebarButtonText);
				this.ParentWindow.GuestBootCompleted += this.ParentWindow_GuestBootCompletedEvent;
			}
			this.ParentWindow.mCommonHandler.ScreenRecordingStateChangedEvent += this.NCTopBar_ScreenRecordingStateChangedEvent;
			VideoRecordingStatus videoRecordingStatus = this.mVideoRecordStatusControl;
			videoRecordingStatus.RecordingStoppedEvent = (Action)Delegate.Combine(videoRecordingStatus.RecordingStoppedEvent, new Action(this.NCTopBar_RecordingStoppedEvent));
		}

		// Token: 0x06000849 RID: 2121 RVA: 0x000301DC File Offset: 0x0002E3DC
		private void NCTopBar_ScreenRecordingStateChangedEvent(bool isRecording)
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				if (isRecording)
				{
					if (this.mVideoRecordingStatusGrid.Visibility != Visibility.Visible && CommonHandlers.sIsRecordingVideo)
					{
						this.mVideoRecordStatusControl.Init(this.ParentWindow);
						this.mVideoRecordingStatusGrid.Visibility = Visibility.Visible;
						return;
					}
				}
				else
				{
					this.mVideoRecordStatusControl.ResetTimer();
					this.mVideoRecordingStatusGrid.Visibility = Visibility.Collapsed;
				}
			}), new object[0]);
		}

		// Token: 0x0600084A RID: 2122 RVA: 0x000074CC File Offset: 0x000056CC
		private void NCTopBar_RecordingStoppedEvent()
		{
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				this.mVideoRecordingStatusGrid.Visibility = Visibility.Collapsed;
			}), new object[0]);
		}

		// Token: 0x0600084B RID: 2123 RVA: 0x000074F1 File Offset: 0x000056F1
		private void MinimizeButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked minimize button");
			this.ParentWindow.MinimizeWindow();
		}

		// Token: 0x0600084C RID: 2124 RVA: 0x00007508 File Offset: 0x00005708
		internal void MaxmizeButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked Maximize\\Restore button");
			if (this.ParentWindow.WindowState == WindowState.Normal)
			{
				this.ParentWindow.MaximizeWindow();
				return;
			}
			this.ParentWindow.RestoreWindows(false);
		}

		// Token: 0x0600084D RID: 2125 RVA: 0x00007539 File Offset: 0x00005739
		private void CloseButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked close Bluestacks button");
			this.ParentWindow.CloseWindow();
		}

		// Token: 0x0600084E RID: 2126 RVA: 0x00030220 File Offset: 0x0002E420
		private void SettingsButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if ((sender as Grid).Children[0].Visibility == Visibility.Visible)
			{
				this.mSettingsDropDownControl.LateInit();
				this.mSettingsDropdownPopup.IsOpen = true;
				this.mSettingsButtonImage.ImageName = "cfgmenu_selected";
				return;
			}
			this.ParentWindow.mCommonHandler.LaunchSettingsWindow();
		}

		// Token: 0x0600084F RID: 2127 RVA: 0x00030280 File Offset: 0x0002E480
		private void PinOnTop_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (!this.ParentWindow.EngineInstanceRegistry.IsClientOnTop)
			{
				this.ParentWindow.EngineInstanceRegistry.IsClientOnTop = true;
				this.ParentWindow.Topmost = true;
				return;
			}
			this.ParentWindow.EngineInstanceRegistry.IsClientOnTop = false;
			this.ParentWindow.Topmost = false;
		}

		// Token: 0x06000850 RID: 2128 RVA: 0x00007550 File Offset: 0x00005750
		private void MSidebarButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.FlipSidebarVisibility(this.mSidebarButtonImage, this.mSidebarButtonText);
		}

		// Token: 0x06000851 RID: 2129 RVA: 0x0000756E File Offset: 0x0000576E
		internal void ShowMacroPlaybackOnTopBar(MacroRecording record)
		{
			if (this.ParentWindow.IsUIInPortraitMode)
			{
				this.mSettingsButton.Visibility = Visibility.Collapsed;
			}
			this.mMacroPlayControl.Init(this.ParentWindow, record);
			this.mMacroPlayGrid.Visibility = Visibility.Visible;
		}

		// Token: 0x06000852 RID: 2130 RVA: 0x000075A7 File Offset: 0x000057A7
		internal void HideMacroPlaybackFromTopBar()
		{
			this.mSettingsButton.Visibility = Visibility.Visible;
			this.mMacroPlayGrid.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000853 RID: 2131 RVA: 0x000302DC File Offset: 0x0002E4DC
		internal void ShowRecordingIcons()
		{
			if (this.ParentWindow.IsUIInPortraitMode)
			{
				this.mSettingsButton.Visibility = Visibility.Collapsed;
			}
			this.mMacroRecordControl.Init(this.ParentWindow);
			this.mMacroRecordGrid.Visibility = Visibility.Visible;
			this.mMacroRecordControl.StartTimer();
		}

		// Token: 0x06000854 RID: 2132 RVA: 0x000075C1 File Offset: 0x000057C1
		internal void HideRecordingIcons()
		{
			this.mSettingsButton.Visibility = Visibility.Visible;
			this.mMacroRecordGrid.Visibility = Visibility.Collapsed;
			this.mMacroRecorderToolTipPopup.IsOpen = false;
		}

		// Token: 0x06000855 RID: 2133 RVA: 0x000075E7 File Offset: 0x000057E7
		private void NCSoftTopBar_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			DesignerProperties.GetIsInDesignMode(this);
		}

		// Token: 0x06000856 RID: 2134 RVA: 0x00006BEE File Offset: 0x00004DEE
		private void SettingsDropDownControl_MouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x06000857 RID: 2135 RVA: 0x000075F0 File Offset: 0x000057F0
		private void SettingsPopup_Opened(object sender, EventArgs e)
		{
			this.mSettingsDropdownPopup.IsEnabled = false;
			this.mSettingsButtonImage.ImageName = "cfgmenu";
		}

		// Token: 0x06000858 RID: 2136 RVA: 0x0000760E File Offset: 0x0000580E
		private void SettingsPopup_Closed(object sender, EventArgs e)
		{
			this.mSettingsDropdownPopup.IsEnabled = true;
			this.mSettingsButtonImage.ImageName = "cfgmenu";
		}

		// Token: 0x06000859 RID: 2137 RVA: 0x0000762C File Offset: 0x0000582C
		void ITopBar.ShowSyncPanel(bool isSource)
		{
			this.mOperationsSyncGrid.Visibility = Visibility.Visible;
			if (isSource)
			{
				this.mStopSyncButton.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x0600085A RID: 2138 RVA: 0x00007649 File Offset: 0x00005849
		void ITopBar.HideSyncPanel()
		{
			this.mOperationsSyncGrid.Visibility = Visibility.Collapsed;
			this.mStopSyncButton.Visibility = Visibility.Collapsed;
			this.mSyncInstancesToolTipPopup.IsOpen = false;
		}

		// Token: 0x0600085B RID: 2139 RVA: 0x0003032C File Offset: 0x0002E52C
		private void PlayPauseSyncButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if ((sender as CustomPictureBox).ImageName.Equals("pause_title_bar", StringComparison.InvariantCultureIgnoreCase))
			{
				(sender as CustomPictureBox).ImageName = "play_title_bar";
				this.ParentWindow.mSynchronizerWindow.PauseAllSyncOperations();
				return;
			}
			(sender as CustomPictureBox).ImageName = "pause_title_bar";
			this.ParentWindow.mSynchronizerWindow.PlayAllSyncOperations();
		}

		// Token: 0x0600085C RID: 2140 RVA: 0x0000766F File Offset: 0x0000586F
		private void StopSyncButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			((ITopBar)this).HideSyncPanel();
			this.ParentWindow.mSynchronizerWindow.StopAllSyncOperations();
			if (RegistryManager.Instance.IsShowToastNotification)
			{
				this.ParentWindow.ShowGeneralToast(LocaleStrings.GetLocalizedString("STRING_SYNC_STOPPED"));
			}
		}

		// Token: 0x0600085D RID: 2141 RVA: 0x000076A8 File Offset: 0x000058A8
		private void OperationsSyncGrid_MouseEnter(object sender, MouseEventArgs e)
		{
			if (this.ParentWindow.mIsSynchronisationActive)
			{
				this.mSyncInstancesToolTipPopup.IsOpen = true;
			}
		}

		// Token: 0x0600085E RID: 2142 RVA: 0x000076C3 File Offset: 0x000058C3
		private void OperationsSyncGrid_MouseLeave(object sender, MouseEventArgs e)
		{
			if (this.ParentWindow.mIsSynchronisationActive && !this.mOperationsSyncGrid.IsMouseOver && !this.mSyncInstancesToolTipPopup.IsMouseOver)
			{
				this.mSyncInstancesToolTipPopup.IsOpen = false;
			}
		}

		// Token: 0x0600085F RID: 2143 RVA: 0x000076F8 File Offset: 0x000058F8
		private void SyncInstancesToolTip_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.mOperationsSyncGrid.IsMouseOver && !this.mSyncInstancesToolTipPopup.IsMouseOver)
			{
				this.mSyncInstancesToolTipPopup.IsOpen = false;
			}
		}

		// Token: 0x06000860 RID: 2144 RVA: 0x00030394 File Offset: 0x0002E594
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/ncsofttopbar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000861 RID: 2145 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000862 RID: 2146 RVA: 0x000303C4 File Offset: 0x0002E5C4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((NCSoftTopBar)target).Loaded += this.NCSoftTopBar_Loaded;
				((NCSoftTopBar)target).SizeChanged += this.NCSoftTopBar_SizeChanged;
				return;
			case 2:
				this.mMainGrid = (Grid)target;
				return;
			case 3:
				this.mTitleIcon = (CustomPictureBox)target;
				return;
			case 4:
				this.mWindowHeaderGrid = (StackPanel)target;
				return;
			case 5:
				this.mAppName = (TextBlock)target;
				return;
			case 6:
				this.mGamenameSeparator = (Line)target;
				return;
			case 7:
				this.mCharacterName = (TextBlock)target;
				return;
			case 8:
				this.mStreamingTopbarGrid = (Grid)target;
				return;
			case 9:
				this.mBorder = (Border)target;
				return;
			case 10:
				this.mNcTopBarControlGrid = (Grid)target;
				return;
			case 11:
				this.mMacroRecordGrid = (Grid)target;
				return;
			case 12:
				this.mMacroRecordControl = (MacroTopBarRecordControl)target;
				return;
			case 13:
				this.mMacroPlayGrid = (Grid)target;
				return;
			case 14:
				this.mMacroPlayControl = (MacroTopBarPlayControl)target;
				return;
			case 15:
				this.mVideoRecordingStatusGrid = (Grid)target;
				return;
			case 16:
				this.mVideoRecordStatusControl = (VideoRecordingStatus)target;
				return;
			case 17:
				this.mOperationsSyncGrid = (Grid)target;
				this.mOperationsSyncGrid.MouseEnter += this.OperationsSyncGrid_MouseEnter;
				this.mOperationsSyncGrid.MouseLeave += this.OperationsSyncGrid_MouseLeave;
				return;
			case 18:
				this.mSyncMaskBorder = (Border)target;
				return;
			case 19:
				this.mStopSyncButton = (CustomPictureBox)target;
				this.mStopSyncButton.PreviewMouseLeftButtonUp += this.StopSyncButton_PreviewMouseLeftButtonUp;
				return;
			case 20:
				this.mControlBtnPanel = (StackPanel)target;
				return;
			case 21:
				this.mSettingsButton = (Grid)target;
				this.mSettingsButton.PreviewMouseLeftButtonUp += this.SettingsButton_MouseLeftButtonUp;
				return;
			case 22:
				this.mSettingsButtonImage = (CustomPictureBox)target;
				return;
			case 23:
				this.mSettingsButtonText = (TextBlock)target;
				return;
			case 24:
				this.mMinimizeButton = (Grid)target;
				this.mMinimizeButton.PreviewMouseLeftButtonUp += this.MinimizeButton_MouseLeftButtonUp;
				return;
			case 25:
				this.mMinimizeButtonImage = (CustomPictureBox)target;
				return;
			case 26:
				this.mMinimizeButtonText = (TextBlock)target;
				return;
			case 27:
				this.mMaximizeButton = (Grid)target;
				this.mMaximizeButton.PreviewMouseLeftButtonUp += this.MaxmizeButton_MouseLeftButtonUp;
				return;
			case 28:
				this.mMaximizeButtonImage = (CustomPictureBox)target;
				return;
			case 29:
				this.mMaximizeButtonText = (TextBlock)target;
				return;
			case 30:
				this.mCloseButton = (Grid)target;
				this.mCloseButton.PreviewMouseLeftButtonUp += this.CloseButton_MouseLeftButtonUp;
				return;
			case 31:
				this.mCloseButtonImage = (CustomPictureBox)target;
				return;
			case 32:
				this.mCloseButtonText = (TextBlock)target;
				return;
			case 33:
				this.mSidebarButton = (Grid)target;
				this.mSidebarButton.PreviewMouseLeftButtonUp += this.MSidebarButton_MouseLeftButtonUp;
				return;
			case 34:
				this.mSidebarButtonImage = (CustomPictureBox)target;
				return;
			case 35:
				this.mSidebarButtonText = (TextBlock)target;
				return;
			case 36:
				this.mMacroRecorderToolTipPopup = (CustomPopUp)target;
				return;
			case 37:
				this.dummyGrid = (Grid)target;
				return;
			case 38:
				this.mMacroRecordingTooltip = (TextBlock)target;
				return;
			case 39:
				this.mUpArrow = (Path)target;
				return;
			case 40:
				this.mMacroRunningToolTipPopup = (CustomPopUp)target;
				return;
			case 41:
				this.grid = (Grid)target;
				return;
			case 42:
				this.mMacroRunningTooltip = (TextBlock)target;
				return;
			case 43:
				this.mSettingsDropdownPopup = (CustomPopUp)target;
				this.mSettingsDropdownPopup.Opened += this.SettingsPopup_Opened;
				this.mSettingsDropdownPopup.Closed += this.SettingsPopup_Closed;
				return;
			case 44:
				this.mSettingsDropdownBorder = (Border)target;
				return;
			case 45:
				this.mGrid = (Grid)target;
				return;
			case 46:
				this.mMaskBorder = (Border)target;
				return;
			case 47:
				this.mSettingsDropDownControl = (SettingsWindowDropdown)target;
				return;
			case 48:
				this.mSyncInstancesToolTipPopup = (CustomPopUp)target;
				return;
			case 49:
				this.mDummyGrid = (Grid)target;
				return;
			case 50:
				this.mUpwardArrow = (Path)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040004EE RID: 1262
		private MainWindow mMainWindow;

		// Token: 0x040004EF RID: 1263
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mMainGrid;

		// Token: 0x040004F0 RID: 1264
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mTitleIcon;

		// Token: 0x040004F1 RID: 1265
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mWindowHeaderGrid;

		// Token: 0x040004F2 RID: 1266
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mAppName;

		// Token: 0x040004F3 RID: 1267
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Line mGamenameSeparator;

		// Token: 0x040004F4 RID: 1268
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mCharacterName;

		// Token: 0x040004F5 RID: 1269
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mStreamingTopbarGrid;

		// Token: 0x040004F6 RID: 1270
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mBorder;

		// Token: 0x040004F7 RID: 1271
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mNcTopBarControlGrid;

		// Token: 0x040004F8 RID: 1272
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mMacroRecordGrid;

		// Token: 0x040004F9 RID: 1273
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal MacroTopBarRecordControl mMacroRecordControl;

		// Token: 0x040004FA RID: 1274
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mMacroPlayGrid;

		// Token: 0x040004FB RID: 1275
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal MacroTopBarPlayControl mMacroPlayControl;

		// Token: 0x040004FC RID: 1276
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mVideoRecordingStatusGrid;

		// Token: 0x040004FD RID: 1277
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal VideoRecordingStatus mVideoRecordStatusControl;

		// Token: 0x040004FE RID: 1278
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mOperationsSyncGrid;

		// Token: 0x040004FF RID: 1279
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mSyncMaskBorder;

		// Token: 0x04000500 RID: 1280
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mStopSyncButton;

		// Token: 0x04000501 RID: 1281
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mControlBtnPanel;

		// Token: 0x04000502 RID: 1282
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mSettingsButton;

		// Token: 0x04000503 RID: 1283
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mSettingsButtonImage;

		// Token: 0x04000504 RID: 1284
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mSettingsButtonText;

		// Token: 0x04000505 RID: 1285
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mMinimizeButton;

		// Token: 0x04000506 RID: 1286
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mMinimizeButtonImage;

		// Token: 0x04000507 RID: 1287
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mMinimizeButtonText;

		// Token: 0x04000508 RID: 1288
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mMaximizeButton;

		// Token: 0x04000509 RID: 1289
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mMaximizeButtonImage;

		// Token: 0x0400050A RID: 1290
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mMaximizeButtonText;

		// Token: 0x0400050B RID: 1291
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mCloseButton;

		// Token: 0x0400050C RID: 1292
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCloseButtonImage;

		// Token: 0x0400050D RID: 1293
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mCloseButtonText;

		// Token: 0x0400050E RID: 1294
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mSidebarButton;

		// Token: 0x0400050F RID: 1295
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mSidebarButtonImage;

		// Token: 0x04000510 RID: 1296
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mSidebarButtonText;

		// Token: 0x04000511 RID: 1297
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mMacroRecorderToolTipPopup;

		// Token: 0x04000512 RID: 1298
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid dummyGrid;

		// Token: 0x04000513 RID: 1299
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mMacroRecordingTooltip;

		// Token: 0x04000514 RID: 1300
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Path mUpArrow;

		// Token: 0x04000515 RID: 1301
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mMacroRunningToolTipPopup;

		// Token: 0x04000516 RID: 1302
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid grid;

		// Token: 0x04000517 RID: 1303
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mMacroRunningTooltip;

		// Token: 0x04000518 RID: 1304
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mSettingsDropdownPopup;

		// Token: 0x04000519 RID: 1305
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mSettingsDropdownBorder;

		// Token: 0x0400051A RID: 1306
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mGrid;

		// Token: 0x0400051B RID: 1307
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder;

		// Token: 0x0400051C RID: 1308
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal SettingsWindowDropdown mSettingsDropDownControl;

		// Token: 0x0400051D RID: 1309
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mSyncInstancesToolTipPopup;

		// Token: 0x0400051E RID: 1310
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mDummyGrid;

		// Token: 0x0400051F RID: 1311
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Path mUpwardArrow;

		// Token: 0x04000520 RID: 1312
		private bool _contentLoaded;
	}
}
