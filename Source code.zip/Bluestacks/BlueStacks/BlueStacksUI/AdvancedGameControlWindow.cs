﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000112 RID: 274
	public class AdvancedGameControlWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x06000AAC RID: 2732 RVA: 0x0003D4B8 File Offset: 0x0003B6B8
		internal AdvancedGameControlWindow(MainWindow window)
		{
			this.ParentWindow = window;
			this.InitializeComponent();
			if (KMManager.sIsDeveloperModeOn)
			{
				this.mStatePrimitive.Visibility = Visibility.Visible;
				this.mMouseZoomPrimitive.Visibility = Visibility.Visible;
			}
			else
			{
				this.mStatePrimitive.Visibility = Visibility.Collapsed;
				this.mMouseZoomPrimitive.Visibility = Visibility.Collapsed;
			}
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.mBrowserHelp.Visibility = Visibility.Collapsed;
			}
			base.Width = 0.0;
			base.Height = 0.0;
			BlueStacksUIBinding.Bind(this.mShowHelpHyperlink, "STRING_SCRIPT_GUIDE", "");
			AdvancedSettingsItemPanel advancedSettingsItemPanel = this.mTapPrimitive;
			advancedSettingsItemPanel.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel2 = this.mTapRepeatPrimitive;
			advancedSettingsItemPanel2.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel2.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel3 = this.mDpadPrimitive;
			advancedSettingsItemPanel3.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel3.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel4 = this.mZoomPrimitive;
			advancedSettingsItemPanel4.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel4.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel5 = this.mFreeLookPrimitive;
			advancedSettingsItemPanel5.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel5.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel6 = this.mPanPrimitive;
			advancedSettingsItemPanel6.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel6.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel7 = this.mMOBASkillPrimitive;
			advancedSettingsItemPanel7.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel7.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel8 = this.mSwipePrimitive;
			advancedSettingsItemPanel8.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel8.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel9 = this.mTiltPrimitive;
			advancedSettingsItemPanel9.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel9.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel10 = this.mStatePrimitive;
			advancedSettingsItemPanel10.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel10.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel11 = this.mScriptPrimitive;
			advancedSettingsItemPanel11.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel11.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel12 = this.mMouseZoomPrimitive;
			advancedSettingsItemPanel12.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel12.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel13 = this.mRotatePrimitive;
			advancedSettingsItemPanel13.MouseDragStart = (EventHandler)Delegate.Combine(advancedSettingsItemPanel13.MouseDragStart, new EventHandler(this.AdvancedSettingsItemPanel_MouseDragStart));
			AdvancedSettingsItemPanel advancedSettingsItemPanel14 = this.mTapPrimitive;
			advancedSettingsItemPanel14.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel14.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel15 = this.mTapRepeatPrimitive;
			advancedSettingsItemPanel15.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel15.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel16 = this.mDpadPrimitive;
			advancedSettingsItemPanel16.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel16.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel17 = this.mZoomPrimitive;
			advancedSettingsItemPanel17.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel17.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel18 = this.mFreeLookPrimitive;
			advancedSettingsItemPanel18.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel18.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel19 = this.mPanPrimitive;
			advancedSettingsItemPanel19.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel19.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel20 = this.mMOBASkillPrimitive;
			advancedSettingsItemPanel20.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel20.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel21 = this.mSwipePrimitive;
			advancedSettingsItemPanel21.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel21.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel22 = this.mTiltPrimitive;
			advancedSettingsItemPanel22.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel22.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel23 = this.mStatePrimitive;
			advancedSettingsItemPanel23.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel23.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel24 = this.mScriptPrimitive;
			advancedSettingsItemPanel24.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel24.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel25 = this.mMouseZoomPrimitive;
			advancedSettingsItemPanel25.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel25.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
			AdvancedSettingsItemPanel advancedSettingsItemPanel26 = this.mRotatePrimitive;
			advancedSettingsItemPanel26.Tap = (EventHandler)Delegate.Combine(advancedSettingsItemPanel26.Tap, new EventHandler(this.AdvancedSettingsItemPanel_Tap));
		}

		// Token: 0x06000AAD RID: 2733 RVA: 0x00008BED File Offset: 0x00006DED
		private void CloseButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.CloseWindow();
		}

		// Token: 0x06000AAE RID: 2734 RVA: 0x00008BF5 File Offset: 0x00006DF5
		private void CloseWindow()
		{
			KMManager.sIsDeveloperModeOn = false;
			base.Close();
		}

		// Token: 0x06000AAF RID: 2735 RVA: 0x0003D960 File Offset: 0x0003BB60
		internal void ToggleAGCWindowVisiblity(bool isScriptModeWindow)
		{
			KMManager.sIsInScriptEditingMode = isScriptModeWindow;
			this.mScriptModeDictionary["isInScriptMode"] = isScriptModeWindow.ToString(CultureInfo.InvariantCulture);
			this.BindOrUnbindMouseEvents(isScriptModeWindow);
			if (isScriptModeWindow)
			{
				this.PrimaryGrid.Visibility = Visibility.Collapsed;
				this.KeySequenceScriptGrid.Visibility = Visibility.Visible;
				base.Owner = this.ParentWindow;
				this.PopulateScriptTextBox();
				this.CanvasWindow.Hide();
				this.ParentWindow.Utils.ToggleTopBarSidebarEnabled(false);
			}
			else
			{
				this.PrimaryGrid.Visibility = Visibility.Visible;
				this.KeySequenceScriptGrid.Visibility = Visibility.Collapsed;
				this.CanvasWindow.Show();
				base.Owner = this.CanvasWindow;
				base.Activate();
				this.ParentWindow.Utils.ToggleTopBarSidebarEnabled(true);
			}
			HTTPUtils.SendRequestToEngineAsync("scriptEditingModeEntered", this.mScriptModeDictionary, this.ParentWindow.mVmName, 0, null, false, 1, 0);
		}

		// Token: 0x06000AB0 RID: 2736 RVA: 0x0003DA48 File Offset: 0x0003BC48
		private void BindOrUnbindMouseEvents(bool bind)
		{
			base.MouseEnter -= this.AdvancedGameControlWindow_MouseEnter;
			base.MouseLeave -= this.AdvancedGameControlWindow_MouseLeave;
			if (bind)
			{
				base.MouseEnter += this.AdvancedGameControlWindow_MouseEnter;
				base.MouseLeave += this.AdvancedGameControlWindow_MouseLeave;
			}
		}

		// Token: 0x06000AB1 RID: 2737 RVA: 0x00008C03 File Offset: 0x00006E03
		private void AdvancedGameControlWindow_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			if (this.ParentWindow.IsActive)
			{
				this.ParentWindow.mFrontendHandler.ShowGLWindow();
			}
		}

		// Token: 0x06000AB2 RID: 2738 RVA: 0x00005D29 File Offset: 0x00003F29
		private void AdvancedGameControlWindow_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
		}

		// Token: 0x06000AB3 RID: 2739 RVA: 0x0003DAA0 File Offset: 0x0003BCA0
		private void AdvancedGameControlWindow_Closing(object sender, CancelEventArgs evt)
		{
			if (KeymapCanvasWindow.sIsDirty)
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_BLUESTACKS_GAME_CONTROLS");
				customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_UNSAVED_CHANGES_CLOSE");
				customMessageWindow.AddButton(ButtonColors.Blue, LocaleStrings.GetLocalizedString("STRING_SAVE_CHANGES"), delegate(object o, EventArgs e)
				{
					KMManager.SaveIMActions(this.ParentWindow, false, false);
				}, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_DISCARD"), delegate(object o, EventArgs e)
				{
					KMManager.LoadIMActions(this.ParentWindow, KMManager.sPackageName);
					KeymapCanvasWindow.sIsDirty = false;
				}, null, false, null);
				customMessageWindow.CloseButtonHandle(delegate(object o, EventArgs e)
				{
					this.CanvasWindow.mIsClosing = false;
					evt.Cancel = true;
				}, null);
				customMessageWindow.Owner = this.CanvasWindow;
				customMessageWindow.ShowDialog();
			}
			this.CanvasWindow.SidebarWindowLeft = base.Left;
			this.CanvasWindow.SidebarWindowTop = base.Top;
			this.ParentWindow.Activate();
			this.ParentWindow.Utils.ToggleTopBarSidebarEnabled(true);
		}

		// Token: 0x06000AB4 RID: 2740 RVA: 0x0003DBA0 File Offset: 0x0003BDA0
		private void AdvancedGameControlWindow_Closed(object sender, EventArgs e)
		{
			this.CanvasWindow.SidebarWindow = null;
			if (KeymapCanvasWindow.sWasMaximized)
			{
				this.ParentWindow.MaximizeWindow();
			}
			else
			{
				this.ParentWindow.ChangeHeightWidthTopLeft(this.CanvasWindow.mParentWindowWidth, this.CanvasWindow.mParentWindowHeight, this.CanvasWindow.mParentWindowTop, this.CanvasWindow.mParentWindowLeft);
			}
			KeymapCanvasWindow.sWasMaximized = false;
			if (this.CanvasWindow.IsLoaded && !this.CanvasWindow.mIsClosing)
			{
				this.CanvasWindow.Close();
			}
			if (RegistryManager.Instance.ShowKeyControlsOverlay)
			{
				KMManager.ShowOverlayWindow(this.ParentWindow, true, true);
			}
		}

		// Token: 0x06000AB5 RID: 2741 RVA: 0x0003DC48 File Offset: 0x0003BE48
		internal void Init(KeymapCanvasWindow window)
		{
			this.CanvasWindow = window;
			if (FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.mNCTransSlider.Value = RegistryManager.Instance.TranslucentControlsTransparency;
				this.mLastSavedSliderValue = this.mNCTransSlider.Value;
				this.mNCTransparencyLevel.Text = ((int)(this.mNCTransSlider.Value * 100.0)).ToString(CultureInfo.InvariantCulture);
				if (RegistryManager.Instance.TranslucentControlsTransparency == 0.0)
				{
					this.mNCTranslucentControlsSliderButton.ImageName = "sidebar_overlay_inactive";
				}
				this.ParentWindow.mCommonHandler.OverlayStateChangedEvent += this.ParentWindow_OverlayStateChangedEvent;
			}
			else
			{
				this.mNCTransparencySlider.Visibility = Visibility.Collapsed;
			}
			this.FillProfileCombo();
			this.ProfileChanged();
			this.mSaveBtn.IsEnabled = false;
			this.mUndoBtn.IsEnabled = false;
		}

		// Token: 0x06000AB6 RID: 2742 RVA: 0x0003DD34 File Offset: 0x0003BF34
		internal void InsertXYInScript(double x, double y)
		{
			string text = " " + x.ToString("00.00", CultureInfo.InvariantCulture) + " " + y.ToString("00.00", CultureInfo.InvariantCulture);
			int selectionStart = this.mScriptText.SelectionStart + text.Length;
			this.mScriptText.Text = this.mScriptText.Text.Insert(this.mScriptText.SelectionStart, text);
			this.mScriptText.SelectionStart = selectionStart;
		}

		// Token: 0x06000AB7 RID: 2743 RVA: 0x0003DDBC File Offset: 0x0003BFBC
		internal void OrderingControlSchemes()
		{
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			this.ParentWindow.SelectedConfig.ControlSchemes.Sort(new Comparison<IMControlScheme>(this.CompareSchemesAlphabetically));
			foreach (IMControlScheme imcontrolScheme in new List<IMControlScheme>(this.ParentWindow.SelectedConfig.ControlSchemes))
			{
				if (imcontrolScheme.BuiltIn)
				{
					if (imcontrolScheme.IsBookMarked)
					{
						this.ParentWindow.SelectedConfig.ControlSchemes.Remove(imcontrolScheme);
						this.ParentWindow.SelectedConfig.ControlSchemes.Insert(num3, imcontrolScheme);
						num3++;
						num2++;
						num++;
					}
					else
					{
						this.ParentWindow.SelectedConfig.ControlSchemes.Remove(imcontrolScheme);
						this.ParentWindow.SelectedConfig.ControlSchemes.Insert(num2, imcontrolScheme);
						num2++;
						num++;
					}
				}
				else if (imcontrolScheme.IsBookMarked)
				{
					this.ParentWindow.SelectedConfig.ControlSchemes.Remove(imcontrolScheme);
					this.ParentWindow.SelectedConfig.ControlSchemes.Insert(num, imcontrolScheme);
					num++;
				}
			}
		}

		// Token: 0x06000AB8 RID: 2744 RVA: 0x0003DF10 File Offset: 0x0003C110
		private int CompareSchemesAlphabetically(IMControlScheme x, IMControlScheme y)
		{
			string text = x.Name.ToLower(CultureInfo.InvariantCulture).Trim();
			string text2 = y.Name.ToLower(CultureInfo.InvariantCulture).Trim();
			if (text.Contains(text2))
			{
				return 1;
			}
			if (text2.Contains(text))
			{
				return -1;
			}
			if (string.CompareOrdinal(text, text2) < 0)
			{
				return -1;
			}
			return 1;
		}

		// Token: 0x06000AB9 RID: 2745 RVA: 0x0003DF6C File Offset: 0x0003C16C
		public void FillProfileCombo()
		{
			this.OrderingControlSchemes();
			ComboBoxSchemeControl comboBoxSchemeControl = null;
			this.mSchemeComboBox.Items.Children.Clear();
			if (this.ParentWindow.SelectedConfig.ControlSchemes != null && this.ParentWindow.SelectedConfig.ControlSchemes.Count > 0)
			{
				this.mProfileHeader.Visibility = Visibility.Visible;
				using (Dictionary<string, IMControlScheme>.ValueCollection.Enumerator enumerator = this.ParentWindow.SelectedConfig.ControlSchemesDict.Values.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						IMControlScheme item = enumerator.Current;
						ComboBoxSchemeControl comboBoxSchemeControl2 = new ComboBoxSchemeControl(this.CanvasWindow, this.ParentWindow);
						comboBoxSchemeControl2.mSchemeName.Text = item.Name;
						comboBoxSchemeControl2.IsEnabled = true;
						if (item.Selected)
						{
							comboBoxSchemeControl = comboBoxSchemeControl2;
							BlueStacksUIBinding.BindColor(comboBoxSchemeControl2, System.Windows.Controls.Control.BackgroundProperty, "ContextMenuItemBackgroundSelectedColor");
						}
						if (item.BuiltIn || this.ParentWindow.SelectedConfig.ControlSchemes.Count((IMControlScheme x) => string.Equals(x.Name, item.Name, StringComparison.InvariantCulture)) == 2)
						{
							comboBoxSchemeControl2.mEditImg.Visibility = Visibility.Hidden;
							comboBoxSchemeControl2.mDeleteImg.Visibility = Visibility.Hidden;
						}
						if (item.IsBookMarked)
						{
							comboBoxSchemeControl2.mBookmarkImg.ImageName = "bookmarked";
						}
						this.mSchemeComboBox.Items.Children.Add(comboBoxSchemeControl2);
					}
				}
				if (comboBoxSchemeControl == null)
				{
					comboBoxSchemeControl = (this.mSchemeComboBox.Items.Children[0] as ComboBoxSchemeControl);
					this.ParentWindow.SelectedConfig.ControlSchemesDict[comboBoxSchemeControl.mSchemeName.Text].Selected = true;
				}
				else
				{
					this.mSchemeComboBox.SelectedItem = comboBoxSchemeControl.mSchemeName.Text.ToString(CultureInfo.InvariantCulture);
					this.ParentWindow.SelectedConfig.SelectedControlScheme = this.ParentWindow.SelectedConfig.ControlSchemesDict[this.mSchemeComboBox.SelectedItem];
					this.mSchemeComboBox.mName.Text = this.mSchemeComboBox.SelectedItem;
				}
			}
			else
			{
				BlueStacksUIBinding.Bind(this.CanvasWindow.SidebarWindow.mSchemeComboBox.mName, "Custom", "");
			}
			if (this.ParentWindow.OriginalLoadedConfig.ControlSchemes != null && this.ParentWindow.OriginalLoadedConfig.ControlSchemes.Count > 0)
			{
				this.mExport.IsEnabled = true;
			}
			else
			{
				this.mExport.IsEnabled = false;
			}
			this.mRevertBtn.IsEnabled = (this.ParentWindow.SelectedConfig.ControlSchemes.Count((IMControlScheme x) => string.Equals(x.Name, this.ParentWindow.SelectedConfig.SelectedControlScheme.Name, StringComparison.InvariantCulture)) == 2);
		}

		// Token: 0x06000ABA RID: 2746 RVA: 0x0003E24C File Offset: 0x0003C44C
		private void TopBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			try
			{
				base.DragMove();
			}
			catch
			{
			}
		}

		// Token: 0x06000ABB RID: 2747 RVA: 0x00006BEE File Offset: 0x00004DEE
		private void CustomPictureBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x06000ABC RID: 2748 RVA: 0x00008BED File Offset: 0x00006DED
		private void UndoButton_Click(object sender, RoutedEventArgs e)
		{
			this.CloseWindow();
		}

		// Token: 0x06000ABD RID: 2749 RVA: 0x00008C22 File Offset: 0x00006E22
		private void SaveButton_Click(object sender, RoutedEventArgs e)
		{
			KMManager.SaveIMActions(this.ParentWindow, false, false);
			this.mLastSavedSliderValue = this.mNCTransSlider.Value;
			this.FillProfileCombo();
			this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_CHANGES_SAVED"));
		}

		// Token: 0x06000ABE RID: 2750 RVA: 0x0003E274 File Offset: 0x0003C474
		internal void AddToastPopup(string message)
		{
			try
			{
				if (this.mToastPopup == null)
				{
					this.mToastPopup = new CustomToastPopupControl(this);
				}
				this.mToastPopup.Init(this, message, null, null, System.Windows.HorizontalAlignment.Center, VerticalAlignment.Bottom, null, 12, null, null, false);
				this.mToastPopup.ShowPopup(1.3);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in showing toast popup: " + ex.ToString());
			}
		}

		// Token: 0x06000ABF RID: 2751 RVA: 0x00008C58 File Offset: 0x00006E58
		private void AdvancedSettingsItemPanel_Tap(object sender, EventArgs e)
		{
			this.AddAdvancedControlToCanvas(sender as AdvancedSettingsItemPanel, true);
			KeymapCanvasWindow.sIsDirty = true;
		}

		// Token: 0x06000AC0 RID: 2752 RVA: 0x00008C6D File Offset: 0x00006E6D
		private void AdvancedSettingsItemPanel_MouseDragStart(object sender, EventArgs e)
		{
			this.AddAdvancedControlToCanvas(sender as AdvancedSettingsItemPanel, false);
			base.Cursor = System.Windows.Input.Cursors.Arrow;
		}

		// Token: 0x06000AC1 RID: 2753 RVA: 0x0003E2FC File Offset: 0x0003C4FC
		private void AddAdvancedControlToCanvas(AdvancedSettingsItemPanel sender, bool isTap = false)
		{
			if (this.ParentWindow.SelectedConfig.ControlSchemes.Count == 0)
			{
				KMManager.AddNewControlSchemeAndSelect(this.ParentWindow, null, false);
			}
			KMManager.CheckAndCreateNewScheme();
			if (!isTap)
			{
				base.Focus();
				base.Cursor = System.Windows.Input.Cursors.Hand;
			}
			KeyActionType actionType = sender.ActionType;
			IMAction action = Assembly.GetExecutingAssembly().CreateInstance(actionType.ToString()) as IMAction;
			KMManager.GetCanvasElement(this.ParentWindow, action, this.mCanvas, false);
			if (isTap)
			{
				List<IMAction> lstAction = KMManager.ClearElement();
				this.CanvasWindow.AddNewCanvasElement(lstAction, true);
				KMManager.ClearElement();
			}
			sender.ReatchedMouseMove();
		}

		// Token: 0x06000AC2 RID: 2754 RVA: 0x00008C87 File Offset: 0x00006E87
		private void mCanvas_PreviewMouseMove(object sender, System.Windows.Input.MouseEventArgs e)
		{
			KMManager.RepositionCanvasElement();
		}

		// Token: 0x06000AC3 RID: 2755 RVA: 0x00008C8E File Offset: 0x00006E8E
		private void mCanvas_MouseUp(object sender, MouseButtonEventArgs e)
		{
			base.Cursor = System.Windows.Input.Cursors.Arrow;
			KMManager.ClearElement();
		}

		// Token: 0x06000AC4 RID: 2756 RVA: 0x0003E3A0 File Offset: 0x0003C5A0
		private void mButtonsGrid_Loaded(object sender, RoutedEventArgs e)
		{
			base.MaxWidth = ((this.mButtonsGrid.ActualWidth < 320.0) ? 320.0 : this.mButtonsGrid.ActualWidth);
			base.MinWidth = base.MaxWidth;
			base.Left = ((this.CanvasWindow.SidebarWindowLeft == -1.0) ? (this.ParentWindow.Left + this.ParentWindow.ActualWidth - (double)(this.ParentWindow.EngineInstanceRegistry.IsSidebarVisible ? 60 : 0)) : this.CanvasWindow.SidebarWindowLeft);
			base.Top = ((this.CanvasWindow.SidebarWindowTop == -1.0) ? this.ParentWindow.Top : this.CanvasWindow.SidebarWindowTop);
			base.Height = this.ParentWindow.ActualHeight;
			Screen screen = Screen.FromHandle(new WindowInteropHelper(this).Handle);
			double sScalingFactor = MainWindow.sScalingFactor;
			Rectangle rectangle = new Rectangle((int)((double)screen.WorkingArea.X / sScalingFactor), (int)((double)screen.WorkingArea.Y / sScalingFactor), (int)((double)screen.WorkingArea.Width / sScalingFactor), (int)((double)screen.WorkingArea.Height / sScalingFactor));
			Rectangle rect = new Rectangle(new System.Drawing.Point((int)base.Left, (int)base.Top), new System.Drawing.Size((int)base.ActualWidth, (int)base.ActualHeight));
			if (!rectangle.Contains(rect))
			{
				base.Left = (double)rectangle.Width - base.Width;
			}
		}

		// Token: 0x06000AC5 RID: 2757 RVA: 0x0003E540 File Offset: 0x0003C740
		public void ProfileChanged()
		{
			if (this.mSchemeComboBox.SelectedItem != null)
			{
				string selectedItem = this.mSchemeComboBox.SelectedItem;
				if (this.ParentWindow.SelectedConfig.ControlSchemesDict.ContainsKey(selectedItem))
				{
					if (!this.ParentWindow.SelectedConfig.ControlSchemesDict[selectedItem].Selected)
					{
						this.ParentWindow.SelectedConfig.SelectedControlScheme.Selected = false;
						foreach (object obj in this.mSchemeComboBox.Items.Children)
						{
							ComboBoxSchemeControl comboBoxSchemeControl = (ComboBoxSchemeControl)obj;
							if (comboBoxSchemeControl.mSchemeName.Text == this.ParentWindow.SelectedConfig.SelectedControlScheme.Name)
							{
								BlueStacksUIBinding.BindColor(comboBoxSchemeControl, System.Windows.Controls.Control.BackgroundProperty, "ComboBoxBackgroundColor");
								break;
							}
						}
						this.ParentWindow.SelectedConfig.SelectedControlScheme = this.ParentWindow.SelectedConfig.ControlSchemesDict[selectedItem];
						this.ParentWindow.SelectedConfig.SelectedControlScheme.Selected = true;
						KeymapCanvasWindow.sIsDirty = true;
					}
					this.CanvasWindow.Init();
				}
				this.mRevertBtn.IsEnabled = (this.ParentWindow.SelectedConfig.ControlSchemes.Count((IMControlScheme x) => string.Equals(x.Name, this.ParentWindow.SelectedConfig.SelectedControlScheme.Name, StringComparison.InvariantCulture)) == 2);
			}
		}

		// Token: 0x06000AC6 RID: 2758 RVA: 0x00008CA1 File Offset: 0x00006EA1
		private void AdvancedGameControlWindow_Loaded(object sender, RoutedEventArgs e)
		{
			base.Activate();
		}

		// Token: 0x06000AC7 RID: 2759 RVA: 0x0003E6C0 File Offset: 0x0003C8C0
		private void AdvancedGameControlWindow_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			string text = string.Empty;
			if (e.Key != Key.None)
			{
				if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
				{
					text = IMAPKeys.GetStringForFile(Key.LeftCtrl) + " + ";
				}
				if (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt))
				{
					text = text + IMAPKeys.GetStringForFile(Key.LeftAlt) + " + ";
				}
				if (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift))
				{
					text = text + IMAPKeys.GetStringForFile(Key.LeftShift) + " + ";
				}
				text += IMAPKeys.GetStringForFile(e.Key);
			}
			Logger.Debug("SHORTCUT: KeyPressed.." + text);
			if (this.ParentWindow.mCommonHandler.mShortcutsConfigInstance != null)
			{
				foreach (ShortcutKeys shortcutKeys in this.ParentWindow.mCommonHandler.mShortcutsConfigInstance.Shortcut)
				{
					if (string.Equals(shortcutKeys.ShortcutKey, text, StringComparison.InvariantCulture) && string.Equals(shortcutKeys.ShortcutName, "STRING_CONTROLS_EDITOR", StringComparison.InvariantCulture))
					{
						KMManager.CloseWindows();
					}
				}
			}
		}

		// Token: 0x06000AC8 RID: 2760 RVA: 0x0003E7F8 File Offset: 0x0003C9F8
		private void OpenFolder_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			try
			{
				using (Process process = new Process())
				{
					process.StartInfo.UseShellExecute = true;
					if (!Directory.Exists(Path.Combine(RegistryStrings.InputMapperFolder, "UserFiles")))
					{
						process.StartInfo.FileName = RegistryStrings.InputMapperFolder;
					}
					else
					{
						process.StartInfo.FileName = Path.Combine(RegistryStrings.InputMapperFolder, "UserFiles");
					}
					process.Start();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Some error in Open folder err: " + ex.ToString());
			}
		}

		// Token: 0x06000AC9 RID: 2761 RVA: 0x0003E8A4 File Offset: 0x0003CAA4
		private void ExportBtn_Click(object sender, MouseButtonEventArgs e)
		{
			ClientStats.SendMiscellaneousStatsAsync("ExportKeymappingClicked", RegistryManager.Instance.UserGuid, KMManager.sPackageName, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, RegistryManager.Instance.RegisteredEmail, null, null);
			if (this.ParentWindow.OriginalLoadedConfig.ControlSchemes.Count > 0)
			{
				this.mOverlayGrid.Visibility = Visibility.Visible;
				if (this.mExportSchemesWindow == null)
				{
					this.mExportSchemesWindow = new ExportSchemesWindow(this.CanvasWindow, this.ParentWindow)
					{
						Owner = this
					};
					this.mExportSchemesWindow.Init();
					this.mExportSchemesWindow.Show();
					return;
				}
			}
			else
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_SCHEME_AVAILABLE"), 1.3, false);
			}
		}

		// Token: 0x06000ACA RID: 2762 RVA: 0x0003E97C File Offset: 0x0003CB7C
		private void ImportBtn_Click(object sender, MouseButtonEventArgs e)
		{
			ClientStats.SendMiscellaneousStatsAsync("ImportKeymappingClicked", RegistryManager.Instance.UserGuid, KMManager.sPackageName, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, RegistryManager.Instance.RegisteredEmail, null, null);
			this.mOverlayGrid.Visibility = Visibility.Visible;
			using (OpenFileDialog openFileDialog = new OpenFileDialog
			{
				Multiselect = true,
				Filter = "Cfg files (*.cfg)|*.cfg"
			})
			{
				if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
				{
					this.mImportSchemesWindow = new ImportSchemesWindow(this.CanvasWindow, this.ParentWindow)
					{
						Owner = this
					};
					this.mImportSchemesWindow.Init(openFileDialog.FileName);
					this.mImportSchemesWindow.Show();
				}
				else
				{
					this.mOverlayGrid.Visibility = Visibility.Hidden;
					this.mImportSchemesWindow = null;
					base.Focus();
				}
			}
		}

		// Token: 0x06000ACB RID: 2763 RVA: 0x00008CAA File Offset: 0x00006EAA
		private void mCloseScriptButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ToggleAGCWindowVisiblity(false);
			this.PopulateScriptTextBox();
			ClientStats.SendKeyMappingUIStatsAsync("button_clicked", KMManager.sPackageName, "script_close_click");
		}

		// Token: 0x06000ACC RID: 2764 RVA: 0x0003EA6C File Offset: 0x0003CC6C
		private void PopulateScriptTextBox()
		{
			if (this.mLastScriptActionItem != null)
			{
				IMAction imaction = this.mLastScriptActionItem.First<IMAction>();
				if (imaction.Type == KeyActionType.Script)
				{
					string text = string.Join(Environment.NewLine, (imaction as Script).Commands.ToArray());
					this.mScriptText.Text = text;
					KeymapCanvasWindow.sIsDirty = true;
				}
			}
		}

		// Token: 0x06000ACD RID: 2765 RVA: 0x00008CCD File Offset: 0x00006ECD
		private void ShowHelpHyperlink_Click(object sender, RoutedEventArgs e)
		{
			BlueStacksUIUtils.OpenUrl(WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/help_articles") + "&article=keymapping_script_faq");
		}

		// Token: 0x06000ACE RID: 2766 RVA: 0x0003EAC4 File Offset: 0x0003CCC4
		private void mDoneScriptButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mLastScriptActionItem != null)
			{
				IMAction imaction = this.mLastScriptActionItem.First<IMAction>();
				if (imaction.Type == KeyActionType.Script)
				{
					string[] array = this.mScriptText.Text.Split(new string[]
					{
						Environment.NewLine
					}, StringSplitOptions.None);
					if (!this.CheckIfScriptValid(array))
					{
						this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_INVALID_SCRIPT_COMMANDS"));
						return;
					}
					(imaction as Script).Commands.ClearAddRange(array.ToList<string>());
				}
			}
			this.ToggleAGCWindowVisiblity(false);
			ClientStats.SendKeyMappingUIStatsAsync("button_clicked", KMManager.sPackageName, "script_done_click");
		}

		// Token: 0x06000ACF RID: 2767 RVA: 0x0003EB5C File Offset: 0x0003CD5C
		private void NCTranslucentControlsSliderButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mNCTransSlider.Value == 0.0)
			{
				this.mNCTransSlider.Value = this.mLastSliderValue;
				this.mNCTransparencyLevel.Text = ((int)(this.mNCTransSlider.Value * 100.0)).ToString(CultureInfo.InvariantCulture);
				if (this.mLastSliderValue > 0.0)
				{
					this.mNCTranslucentControlsSliderButton.ImageName = "sidebar_overlay";
				}
				RegistryManager.Instance.ShowKeyControlsOverlay = true;
			}
			else
			{
				this.mNCTranslucentControlsSliderButton.ImageName = "sidebar_overlay_inactive";
				double value = this.mNCTransSlider.Value;
				this.mNCTransSlider.Value = 0.0;
				this.mNCTransparencyLevel.Text = ((int)(this.mNCTransSlider.Value * 100.0)).ToString(CultureInfo.InvariantCulture);
				this.mLastSliderValue = value;
				RegistryManager.Instance.ShowKeyControlsOverlay = false;
			}
			KeymapCanvasWindow.sIsDirty = true;
		}

		// Token: 0x06000AD0 RID: 2768 RVA: 0x0003EC64 File Offset: 0x0003CE64
		private void NCTransparencySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			KMManager.ChangeTransparency(this.ParentWindow, this.mNCTransSlider.Value);
			if (this.mNCTransSlider.Value == 0.0)
			{
				this.ParentWindow_OverlayStateChangedEvent(false);
			}
			else
			{
				this.ParentWindow_OverlayStateChangedEvent(true);
			}
			this.mLastSliderValue = this.mNCTransSlider.Value;
			this.mNCTransparencyLevel.Text = ((int)(this.mNCTransSlider.Value * 100.0)).ToString(CultureInfo.InvariantCulture);
			if (this.mNCTransSlider.Value != RegistryManager.Instance.TranslucentControlsTransparency)
			{
				KeymapCanvasWindow.sIsDirty = true;
			}
		}

		// Token: 0x06000AD1 RID: 2769 RVA: 0x0003ED0C File Offset: 0x0003CF0C
		public void ParentWindow_OverlayStateChangedEvent(bool isEnabled)
		{
			if (isEnabled)
			{
				this.mNCTranslucentControlsSliderButton.ImageName = "sidebar_overlay";
				if (RegistryManager.Instance.TranslucentControlsTransparency == 0.0 && this.mLastSliderValue == 0.0)
				{
					RegistryManager.Instance.TranslucentControlsTransparency = 0.5;
					this.mNCTransSlider.Value = 0.5;
					this.mNCTransparencyLevel.Text = ((int)(this.mNCTransSlider.Value * 100.0)).ToString(CultureInfo.InvariantCulture);
				}
				else if (this.mNCTransSlider.Value == 0.0)
				{
					RegistryManager.Instance.TranslucentControlsTransparency = this.mLastSliderValue;
				}
				else
				{
					RegistryManager.Instance.TranslucentControlsTransparency = this.mNCTransSlider.Value;
				}
				RegistryManager.Instance.ShowKeyControlsOverlay = true;
				return;
			}
			this.mNCTranslucentControlsSliderButton.ImageName = "sidebar_overlay_inactive";
			RegistryManager.Instance.TranslucentControlsTransparency = 0.0;
			double value = this.mNCTransSlider.Value;
			this.mNCTransSlider.Value = 0.0;
			this.mNCTransparencyLevel.Text = "0";
			this.mLastSliderValue = value;
			RegistryManager.Instance.ShowKeyControlsOverlay = false;
		}

		// Token: 0x06000AD2 RID: 2770 RVA: 0x00008CF2 File Offset: 0x00006EF2
		private void BrowserHelp_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			base.Cursor = System.Windows.Input.Cursors.Hand;
		}

		// Token: 0x06000AD3 RID: 2771 RVA: 0x00008CFF File Offset: 0x00006EFF
		private void BrowserHelp_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			base.Cursor = System.Windows.Input.Cursors.Arrow;
		}

		// Token: 0x06000AD4 RID: 2772 RVA: 0x00008D0C File Offset: 0x00006F0C
		private void Export_IsEnabledChanged(object _1, DependencyPropertyChangedEventArgs _2)
		{
			if (this.mExport.IsEnabled)
			{
				this.mExport.Opacity = 1.0;
				return;
			}
			this.mExport.Opacity = 0.4;
		}

		// Token: 0x06000AD5 RID: 2773 RVA: 0x00008D44 File Offset: 0x00006F44
		private void KeySequenceScriptGrid_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.KeySequenceScriptGrid.Visibility == Visibility.Visible && !this.mScriptText.IsMouseOver)
			{
				this.mAdvancedGameControlBorder.Focus();
			}
		}

		// Token: 0x06000AD6 RID: 2774 RVA: 0x00008D6C File Offset: 0x00006F6C
		private void BrowserHelp_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			BlueStacksUIUtils.OpenUrl(WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
			{
				WebHelper.GetServerHost(),
				"help_articles"
			})) + "&article=advanced_game_control");
		}

		// Token: 0x06000AD7 RID: 2775 RVA: 0x0003EE5C File Offset: 0x0003D05C
		private void RevertBtn_Click(object sender, RoutedEventArgs e)
		{
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;
			customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_RESET_TO_DEFAULT");
			customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_RESET_SCHEME_CHANGES");
			customMessageWindow.AddButton(ButtonColors.Red, "STRING_RESET", delegate(object o, EventArgs e)
			{
				string schemeName = this.ParentWindow.SelectedConfig.SelectedControlScheme.Name;
				bool isBookMarked = this.ParentWindow.SelectedConfig.SelectedControlScheme.IsBookMarked;
				this.ParentWindow.SelectedConfig.ControlSchemes.Remove(this.ParentWindow.SelectedConfig.SelectedControlScheme);
				IMControlScheme imcontrolScheme = (from scheme in this.ParentWindow.SelectedConfig.ControlSchemes
				where string.Equals(scheme.Name, schemeName, StringComparison.InvariantCulture)
				select scheme).FirstOrDefault<IMControlScheme>();
				if (imcontrolScheme != null)
				{
					imcontrolScheme.Selected = true;
					this.ParentWindow.SelectedConfig.SelectedControlScheme = imcontrolScheme;
					this.ParentWindow.SelectedConfig.ControlSchemesDict[imcontrolScheme.Name] = imcontrolScheme;
					imcontrolScheme.IsBookMarked = isBookMarked;
					this.FillProfileCombo();
					this.ProfileChanged();
					this.mSaveBtn.IsEnabled = false;
					this.mUndoBtn.IsEnabled = false;
					KeymapCanvasWindow.sIsDirty = true;
					KMManager.SaveIMActions(this.ParentWindow, false, false);
					ClientStats.SendKeyMappingUIStatsAsync("advancedcontrols_reset", KMManager.sPackageName, "");
				}
			}, null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", delegate(object o, EventArgs e)
			{
			}, null, false, null);
			customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
			customMessageWindow.ShowDialog();
		}

		// Token: 0x06000AD8 RID: 2776 RVA: 0x0003EF00 File Offset: 0x0003D100
		private bool CheckIfScriptValid(string[] scriptCmds)
		{
			bool result = false;
			try
			{
				JObject jobject = new JObject
				{
					{
						"Commands",
						JArray.FromObject(scriptCmds.ToList<string>())
					}
				};
				result = JObject.Parse((JToken.Parse(HTTPUtils.SendRequestToEngine("validateScriptCommands", new Dictionary<string, string>
				{
					{
						"script",
						jobject.ToString(Formatting.None, new JsonConverter[0])
					}
				}, this.ParentWindow.mVmName, 0, null, false, 1, 0, "")) as JArray)[0].ToString())["success"].ToObject<bool>();
			}
			catch
			{
			}
			return result;
		}

		// Token: 0x06000AD9 RID: 2777 RVA: 0x0003EFAC File Offset: 0x0003D1AC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/advancedgamecontrolwindow.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000ADA RID: 2778 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000ADB RID: 2779 RVA: 0x0003EFDC File Offset: 0x0003D1DC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((AdvancedGameControlWindow)target).Loaded += this.AdvancedGameControlWindow_Loaded;
				((AdvancedGameControlWindow)target).Closing += this.AdvancedGameControlWindow_Closing;
				((AdvancedGameControlWindow)target).Closed += this.AdvancedGameControlWindow_Closed;
				((AdvancedGameControlWindow)target).KeyDown += this.AdvancedGameControlWindow_KeyDown;
				return;
			case 2:
				this.mAdvancedGameControlBorder = (Border)target;
				this.mAdvancedGameControlBorder.PreviewMouseDown += this.KeySequenceScriptGrid_PreviewMouseDown;
				return;
			case 3:
				this.PrimaryGrid = (Grid)target;
				return;
			case 4:
				((Grid)target).MouseLeftButtonDown += this.TopBar_MouseLeftButtonDown;
				return;
			case 5:
				((TextBlock)target).MouseLeftButtonDown += this.TopBar_MouseLeftButtonDown;
				return;
			case 6:
				this.mCloseSideBarWindow = (CustomPictureBox)target;
				this.mCloseSideBarWindow.MouseDown += this.CustomPictureBox_MouseDown;
				this.mCloseSideBarWindow.MouseLeftButtonUp += this.CloseButton_MouseLeftButtonUp;
				return;
			case 7:
				this.mProfileHeader = (TextBlock)target;
				return;
			case 8:
				this.mImport = (CustomPictureBox)target;
				this.mImport.MouseLeftButtonUp += this.ImportBtn_Click;
				return;
			case 9:
				this.mExport = (CustomPictureBox)target;
				this.mExport.IsEnabledChanged += this.Export_IsEnabledChanged;
				this.mExport.MouseLeftButtonUp += this.ExportBtn_Click;
				return;
			case 10:
				this.mOpenFolder = (CustomPictureBox)target;
				this.mOpenFolder.MouseLeftButtonUp += this.OpenFolder_MouseLeftButtonUp;
				return;
			case 11:
				this.mSchemeComboBox = (SchemeComboBox)target;
				return;
			case 12:
				this.mBrowserHelp = (CustomPictureBox)target;
				this.mBrowserHelp.MouseEnter += this.BrowserHelp_MouseEnter;
				this.mBrowserHelp.MouseLeave += this.BrowserHelp_MouseLeave;
				this.mBrowserHelp.MouseLeftButtonUp += this.BrowserHelp_MouseLeftButtonUp;
				return;
			case 13:
				this.mPrimitivesPanel = (WrapPanel)target;
				return;
			case 14:
				this.mTapPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 15:
				this.mTapRepeatPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 16:
				this.mDpadPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 17:
				this.mPanPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 18:
				this.mZoomPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 19:
				this.mMOBASkillPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 20:
				this.mSwipePrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 21:
				this.mFreeLookPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 22:
				this.mTiltPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 23:
				this.mStatePrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 24:
				this.mScriptPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 25:
				this.mMouseZoomPrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 26:
				this.mRotatePrimitive = (AdvancedSettingsItemPanel)target;
				return;
			case 27:
				this.mNCTransparencySlider = (Grid)target;
				return;
			case 28:
				this.mNCTransparencyLevel = (CustomTextBox)target;
				return;
			case 29:
				this.mNCTranslucentControlsSliderButton = (CustomPictureBox)target;
				this.mNCTranslucentControlsSliderButton.PreviewMouseLeftButtonUp += this.NCTranslucentControlsSliderButton_PreviewMouseLeftButtonUp;
				return;
			case 30:
				this.mNCTransSlider = (Slider)target;
				this.mNCTransSlider.ValueChanged += this.NCTransparencySlider_ValueChanged;
				return;
			case 31:
				this.mButtonsGrid = (StackPanel)target;
				this.mButtonsGrid.Loaded += this.mButtonsGrid_Loaded;
				return;
			case 32:
				this.mRevertBtn = (CustomButton)target;
				this.mRevertBtn.Click += this.RevertBtn_Click;
				return;
			case 33:
				this.mUndoBtn = (CustomButton)target;
				this.mUndoBtn.Click += this.UndoButton_Click;
				return;
			case 34:
				this.mSaveBtn = (CustomButton)target;
				this.mSaveBtn.Click += this.SaveButton_Click;
				return;
			case 35:
				this.mCanvas = (Canvas)target;
				this.mCanvas.PreviewMouseMove += this.mCanvas_PreviewMouseMove;
				this.mCanvas.PreviewMouseUp += this.mCanvas_MouseUp;
				return;
			case 36:
				this.mOverlayGrid = (Grid)target;
				return;
			case 37:
				this.KeySequenceScriptGrid = (Grid)target;
				return;
			case 38:
				this.mScriptHeaderGrid = (Grid)target;
				this.mScriptHeaderGrid.MouseLeftButtonDown += this.TopBar_MouseLeftButtonDown;
				return;
			case 39:
				this.mHeaderText = (TextBlock)target;
				return;
			case 40:
				this.mCloseScriptWindow = (CustomPictureBox)target;
				this.mCloseScriptWindow.MouseDown += this.CustomPictureBox_MouseDown;
				this.mCloseScriptWindow.MouseLeftButtonUp += this.mCloseScriptButton_MouseLeftButtonUp;
				return;
			case 41:
				this.mSubheadingText = (TextBlock)target;
				return;
			case 42:
				this.mScriptText = (CustomTextBox)target;
				return;
			case 43:
				this.mXYCurrentCoordinatesText = (TextBlock)target;
				return;
			case 44:
				((Hyperlink)target).Click += this.ShowHelpHyperlink_Click;
				return;
			case 45:
				this.mShowHelpHyperlink = (TextBlock)target;
				return;
			case 46:
				this.mFooterGrid = (Grid)target;
				return;
			case 47:
				this.mFooterText = (TextBlock)target;
				return;
			case 48:
				this.mKeySeqDoneButton = (CustomButton)target;
				this.mKeySeqDoneButton.PreviewMouseLeftButtonUp += this.mDoneScriptButton_MouseLeftButtonUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040006B7 RID: 1719
		private MainWindow ParentWindow;

		// Token: 0x040006B8 RID: 1720
		internal KeymapCanvasWindow CanvasWindow;

		// Token: 0x040006B9 RID: 1721
		private CustomToastPopupControl mToastPopup;

		// Token: 0x040006BA RID: 1722
		internal ExportSchemesWindow mExportSchemesWindow;

		// Token: 0x040006BB RID: 1723
		internal ImportSchemesWindow mImportSchemesWindow;

		// Token: 0x040006BC RID: 1724
		internal double mLastSliderValue;

		// Token: 0x040006BD RID: 1725
		internal double mLastSavedSliderValue;

		// Token: 0x040006BE RID: 1726
		internal Dictionary<string, string> mScriptModeDictionary = new Dictionary<string, string>();

		// Token: 0x040006BF RID: 1727
		internal List<IMAction> mLastScriptActionItem;

		// Token: 0x040006C0 RID: 1728
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mAdvancedGameControlBorder;

		// Token: 0x040006C1 RID: 1729
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid PrimaryGrid;

		// Token: 0x040006C2 RID: 1730
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCloseSideBarWindow;

		// Token: 0x040006C3 RID: 1731
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mProfileHeader;

		// Token: 0x040006C4 RID: 1732
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mImport;

		// Token: 0x040006C5 RID: 1733
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mExport;

		// Token: 0x040006C6 RID: 1734
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mOpenFolder;

		// Token: 0x040006C7 RID: 1735
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal SchemeComboBox mSchemeComboBox;

		// Token: 0x040006C8 RID: 1736
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mBrowserHelp;

		// Token: 0x040006C9 RID: 1737
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal WrapPanel mPrimitivesPanel;

		// Token: 0x040006CA RID: 1738
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal AdvancedSettingsItemPanel mTapPrimitive;

		// Token: 0x040006CB RID: 1739
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal AdvancedSettingsItemPanel mTapRepeatPrimitive;

		// Token: 0x040006CC RID: 1740
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal AdvancedSettingsItemPanel mDpadPrimitive;

		// Token: 0x040006CD RID: 1741
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal AdvancedSettingsItemPanel mPanPrimitive;

		// Token: 0x040006CE RID: 1742
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal AdvancedSettingsItemPanel mZoomPrimitive;

		// Token: 0x040006CF RID: 1743
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal AdvancedSettingsItemPanel mMOBASkillPrimitive;

		// Token: 0x040006D0 RID: 1744
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal AdvancedSettingsItemPanel mSwipePrimitive;

		// Token: 0x040006D1 RID: 1745
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal AdvancedSettingsItemPanel mFreeLookPrimitive;

		// Token: 0x040006D2 RID: 1746
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal AdvancedSettingsItemPanel mTiltPrimitive;

		// Token: 0x040006D3 RID: 1747
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal AdvancedSettingsItemPanel mStatePrimitive;

		// Token: 0x040006D4 RID: 1748
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal AdvancedSettingsItemPanel mScriptPrimitive;

		// Token: 0x040006D5 RID: 1749
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal AdvancedSettingsItemPanel mMouseZoomPrimitive;

		// Token: 0x040006D6 RID: 1750
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal AdvancedSettingsItemPanel mRotatePrimitive;

		// Token: 0x040006D7 RID: 1751
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mNCTransparencySlider;

		// Token: 0x040006D8 RID: 1752
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mNCTransparencyLevel;

		// Token: 0x040006D9 RID: 1753
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mNCTranslucentControlsSliderButton;

		// Token: 0x040006DA RID: 1754
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Slider mNCTransSlider;

		// Token: 0x040006DB RID: 1755
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mButtonsGrid;

		// Token: 0x040006DC RID: 1756
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mRevertBtn;

		// Token: 0x040006DD RID: 1757
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mUndoBtn;

		// Token: 0x040006DE RID: 1758
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mSaveBtn;

		// Token: 0x040006DF RID: 1759
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Canvas mCanvas;

		// Token: 0x040006E0 RID: 1760
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mOverlayGrid;

		// Token: 0x040006E1 RID: 1761
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid KeySequenceScriptGrid;

		// Token: 0x040006E2 RID: 1762
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mScriptHeaderGrid;

		// Token: 0x040006E3 RID: 1763
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mHeaderText;

		// Token: 0x040006E4 RID: 1764
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCloseScriptWindow;

		// Token: 0x040006E5 RID: 1765
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mSubheadingText;

		// Token: 0x040006E6 RID: 1766
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mScriptText;

		// Token: 0x040006E7 RID: 1767
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mXYCurrentCoordinatesText;

		// Token: 0x040006E8 RID: 1768
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mShowHelpHyperlink;

		// Token: 0x040006E9 RID: 1769
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mFooterGrid;

		// Token: 0x040006EA RID: 1770
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mFooterText;

		// Token: 0x040006EB RID: 1771
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mKeySeqDoneButton;

		// Token: 0x040006EC RID: 1772
		private bool _contentLoaded;
	}
}
