﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Threading;
using System.Windows;
using System.Windows.Threading;
using BlueStacks.Common;
using BlueStacks.Common.Grm;
using BlueStacks.Common.Grm.Evaluators;
using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200005F RID: 95
	internal class GrmHandler
	{
		// Token: 0x06000423 RID: 1059 RVA: 0x0001B924 File Offset: 0x00019B24
		internal static void RequirementConfigUpdated(string vmName = "Android")
		{
			if (AppRequirementsParser.Instance.Requirements == null)
			{
				return;
			}
			foreach (AppInfo appInfo in new JsonParser(vmName).GetAppList().ToList<AppInfo>())
			{
				GrmHandler.RefreshGrmIndication(appInfo.Package, vmName);
			}
			GrmHandler.SendUpdateGrmPackagesToAndroid(vmName);
		}

		// Token: 0x06000424 RID: 1060 RVA: 0x0001B998 File Offset: 0x00019B98
		internal static void SendUpdateGrmPackagesToAndroid(string vmName)
		{
			try
			{
				if (GrmHandler.sDictAppRuleSet.ContainsKey(vmName) && GrmHandler.sDictAppRuleSet[vmName].Count != 0 && Utils.IsGuestBooted(vmName))
				{
					JObject jobject = new JObject
					{
						{
							"GrmPackageList",
							JArray.FromObject(GrmHandler.sDictAppRuleSet[vmName].Keys)
						}
					};
					Dictionary<string, string> data = new Dictionary<string, string>
					{
						{
							"data",
							jobject.ToString(Formatting.None, new JsonConverter[0])
						}
					};
					HTTPUtils.SendRequestToGuestAsync("grmPackages", data, vmName, 0, null, false, 1, 0);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in SendUpdateGrmPackagesToAndroid: " + ex.ToString());
			}
		}

		// Token: 0x06000425 RID: 1061 RVA: 0x0001BA50 File Offset: 0x00019C50
		internal static void RefreshGrmIndication(string package, string vmName = "Android")
		{
			try
			{
				List<AppRequirement> requirements = AppRequirementsParser.Instance.Requirements;
				if (requirements != null)
				{
					if (!GrmHandler.sDictAppRuleSet.ContainsKey(vmName))
					{
						GrmHandler.sDictAppRuleSet[vmName] = new Dictionary<string, GrmRuleSet>();
					}
					AppIcon appIcon = BlueStacksUIUtils.DictWindows[vmName].mWelcomeTab.mHomeApp.GetAppIcon(package);
					if (appIcon.IsAppIncompat && !requirements.Any((AppRequirement _) => string.Equals(_.PackageName, package, StringComparison.OrdinalIgnoreCase)))
					{
						GrmHandler.RemoveAppCompatError(appIcon, BlueStacksUIUtils.DictWindows[vmName]);
					}
					AppRequirement appRequirement = (from _ in requirements
					where string.Compare(_.PackageName, package, StringComparison.OrdinalIgnoreCase) == 0
					select _).FirstOrDefault<AppRequirement>();
					if (appRequirement == null)
					{
						appRequirement = (from _ in requirements
						where _.PackageName.EndsWith("*", StringComparison.InvariantCulture) && package.StartsWith(_.PackageName.Trim(new char[]
						{
							'*'
						}), StringComparison.InvariantCulture)
						select _).FirstOrDefault<AppRequirement>();
					}
					if (appRequirement != null)
					{
						GrmRuleSet grmRuleSet = appRequirement.EvaluateRequirement(package, vmName);
						if (grmRuleSet != null)
						{
							GrmHandler.AddGRMIndicationForIncompatibleApp(appIcon, BlueStacksUIUtils.DictWindows[vmName], grmRuleSet);
						}
						else
						{
							GrmHandler.RemoveAppCompatError(appIcon, BlueStacksUIUtils.DictWindows[vmName]);
						}
					}
				}
			}
			catch (Exception ex)
			{
				string str = "Exception in RefreshGrmIndication. Exception: ";
				Exception ex2 = ex;
				Logger.Error(str + ((ex2 != null) ? ex2.ToString() : null));
			}
		}

		// Token: 0x06000426 RID: 1062 RVA: 0x0001BB8C File Offset: 0x00019D8C
		internal static void HandleCompatibility(string package, string vmName)
		{
			try
			{
				GrmHandler.AppCompatErrorWindow = new CustomMessageWindow();
				GrmHandler.AppCompatErrorWindow.TitleTextBlock.Text = BlueStacksUIUtils.DictWindows[vmName].mWelcomeTab.mHomeApp.GetAppIcon(package).AppName;
				if (!string.IsNullOrEmpty(AppRequirementsParser.Instance.GetLocalizedString(GrmHandler.sDictAppRuleSet[vmName][package].MessageWindow.HeaderStringKey)))
				{
					GrmHandler.AppCompatErrorWindow.BodyTextBlockTitle.Text = AppRequirementsParser.Instance.GetLocalizedString(GrmHandler.sDictAppRuleSet[vmName][package].MessageWindow.HeaderStringKey);
					GrmHandler.AppCompatErrorWindow.BodyTextBlockTitle.Visibility = Visibility.Visible;
				}
				GrmHandler.AppCompatErrorWindow.BodyTextBlock.Text = AppRequirementsParser.Instance.GetLocalizedString(GrmHandler.sDictAppRuleSet[vmName][package].MessageWindow.MessageStringKey);
				if (GrmHandler.sDictAppRuleSet[vmName][package].MessageWindow.MessageType == MessageType.Info.ToString())
				{
					GrmHandler.AppCompatErrorWindow.MessageIcon.ImageName = "message_info";
				}
				else if (GrmHandler.sDictAppRuleSet[vmName][package].MessageWindow.MessageType == MessageType.Error.ToString())
				{
					GrmHandler.AppCompatErrorWindow.MessageIcon.ImageName = "message_error";
				}
				GrmHandler.AppCompatErrorWindow.MessageIcon.Visibility = Visibility.Visible;
				if (GrmHandler.sDictAppRuleSet[vmName][package].MessageWindow.DontShowOption)
				{
					GrmHandler.AppCompatErrorWindow.CheckBox.Content = LocaleStrings.GetLocalizedString("STRING_DOWNLOAD_GOOGLE_APP_POPUP_STRING_04");
					GrmHandler.AppCompatErrorWindow.CheckBox.Visibility = Visibility.Visible;
				}
				using (List<GrmMessageButton>.Enumerator enumerator = GrmHandler.sDictAppRuleSet[vmName][package].MessageWindow.Buttons.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						GrmMessageButton button = enumerator.Current;
						ButtonColors color = EnumHelper.Parse<ButtonColors>(button.ButtonColor, ButtonColors.Blue);
						GrmHandler.AppCompatErrorWindow.AddButton(color, AppRequirementsParser.Instance.GetLocalizedString(button.ButtonStringKey), delegate(object o, EventArgs e)
						{
							GrmHandler.PerformGrmActions(button.Actions, package, BlueStacksUIUtils.DictWindows[vmName]);
						}, null, false, null);
					}
				}
				GrmHandler.AppCompatErrorWindow.Owner = BlueStacksUIUtils.DictWindows[vmName];
				BlueStacksUIUtils.DictWindows[vmName].ShowDimOverlay(null);
				GrmHandler.AppCompatErrorWindow.ShowDialog();
				BlueStacksUIUtils.DictWindows[vmName].HideDimOverlay();
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while showing appcompat message to user. Exception: " + ex.ToString());
				BlueStacksUIUtils.DictWindows[vmName].mWelcomeTab.mHomeApp.GetAppIcon(package).OpenApp(false);
			}
		}

		// Token: 0x06000427 RID: 1063 RVA: 0x0001BF20 File Offset: 0x0001A120
		private static void PerformGrmActions(List<GrmAction> actions, string package, MainWindow ParentWindow)
		{
			using (BackgroundWorker backgroundWorker = new BackgroundWorker())
			{
				backgroundWorker.DoWork += delegate(object obj, DoWorkEventArgs e)
				{
					GrmHandler.PerformGrmActionsWorker_DoWork(e, actions, package, ParentWindow);
				};
				backgroundWorker.RunWorkerCompleted += delegate(object obj, RunWorkerCompletedEventArgs e)
				{
					GrmHandler.PerformGrmActionsWorker_RunWorkerCompleted(e, ParentWindow);
				};
				backgroundWorker.RunWorkerAsync();
			}
		}

		// Token: 0x06000428 RID: 1064 RVA: 0x0001BF94 File Offset: 0x0001A194
		private static void PerformGrmActionsWorker_DoWork(DoWorkEventArgs e, List<GrmAction> actions, string package, MainWindow ParentWindow)
		{
			try
			{
				ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					ParentWindow.mFrontendGrid.Visibility = Visibility.Hidden;
					ParentWindow.mExitProgressGrid.ProgressText = LocaleStrings.GetLocalizedString("STRING_PERFORMING_ACTIONS");
					ParentWindow.mExitProgressGrid.Visibility = Visibility.Visible;
				}), new object[0]);
				try
				{
					ClientStats.SendMiscellaneousStatsAsync("grm_action_clicked", RegistryManager.Instance.UserGuid, string.Join(",", (from _ in actions
					select _.ActionType.ToString(CultureInfo.InvariantCulture)).ToArray<string>()), RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, "bgp", package, null, null);
				}
				catch (Exception ex)
				{
					string str = "Exception while sending misc stat for grm. ";
					Exception ex2 = ex;
					Logger.Error(str + ((ex2 != null) ? ex2.ToString() : null));
				}
				e.Result = false;
				Action <>9__4;
				foreach (GrmAction grmAction in actions)
				{
					GrmActionType grmActionType = EnumHelper.Parse<GrmActionType>(grmAction.ActionType, GrmActionType.NoAction);
					bool? flag = new bool?(false);
					switch (grmActionType)
					{
					case GrmActionType.UpdateRam:
					{
						int num = int.Parse(grmAction.ActionDictionary["actionValue"], CultureInfo.InvariantCulture);
						int num2 = 4096;
						int num3;
						if (int.TryParse(PhysicalRamEvaluator.RAM, out num3))
						{
							num2 = (int)((double)num3 * 0.5);
						}
						if (RegistryManager.Instance.CurrentEngine == EngineState.raw.ToString() && num2 >= 3072)
						{
							num2 = 3072;
						}
						if (num2 < num)
						{
							num = num2;
						}
						RegistryManager.Instance.Guest[ParentWindow.mVmName].Memory = num;
						flag = new bool?(true);
						break;
					}
					case GrmActionType.UserBrowser:
						ParentWindow.Utils.HandleGenericActionFromDictionary(grmAction.ActionDictionary, "grm", "");
						flag = new bool?(false);
						break;
					case GrmActionType.DownloadFileAndExecute:
					{
						Random random = new Random();
						string text = grmAction.ActionDictionary["fileName"];
						text += " ";
						string text2 = text.Substring(0, text.IndexOf(' '));
						string text3 = text.Substring(text.IndexOf(' ') + 1);
						text2 = string.Format(CultureInfo.InvariantCulture, "{0}_{1}", new object[]
						{
							random.Next(),
							text2
						});
						text2 = Path.Combine(RegistryStrings.PromotionDirectory, text2);
						try
						{
							using (WebClient webClient = new WebClient())
							{
								webClient.DownloadFile(grmAction.ActionDictionary["url"], text2);
							}
							Thread.Sleep(2000);
							using (Process process = new Process())
							{
								process.StartInfo.UseShellExecute = true;
								process.StartInfo.CreateNoWindow = true;
								if ((text2.ToUpperInvariant().EndsWith(".msi", StringComparison.InvariantCultureIgnoreCase) || text2.ToUpperInvariant().EndsWith(".exe", StringComparison.InvariantCultureIgnoreCase)) && !BlueStacksUtils.IsSignedByBlueStacks(text2))
								{
									Logger.Info("Not executing unsigned binary " + text2);
									GrmHandler.GrmExceptionMessageBox(ParentWindow);
									return;
								}
								if (text2.ToUpperInvariant().EndsWith(".msi", StringComparison.InvariantCultureIgnoreCase))
								{
									process.StartInfo.FileName = "msiexec";
									text3 = string.Format(CultureInfo.InvariantCulture, "/i {0} {1}", new object[]
									{
										text2,
										text3
									});
									process.StartInfo.Arguments = text3;
								}
								else
								{
									process.StartInfo.FileName = text2;
									process.StartInfo.Arguments = text3;
								}
								Logger.Info("Starting process: {0} {1}", new object[]
								{
									process.StartInfo.FileName,
									text3
								});
								process.Start();
							}
						}
						catch (Exception ex3)
						{
							GrmHandler.GrmExceptionMessageBox(ParentWindow);
							string str2 = "Failed to download and execute. err: ";
							Exception ex4 = ex3;
							Logger.Error(str2 + ((ex4 != null) ? ex4.ToString() : null));
						}
						flag = new bool?(false);
						break;
					}
					case GrmActionType.NoAction:
						flag = new bool?(false);
						break;
					case GrmActionType.ContinueAnyway:
					{
						Dispatcher dispatcher = ParentWindow.Dispatcher;
						Action method;
						if ((method = <>9__4) == null)
						{
							method = (<>9__4 = delegate()
							{
								ParentWindow.mFrontendGrid.Visibility = Visibility.Visible;
								ParentWindow.mExitProgressGrid.Visibility = Visibility.Hidden;
								if (GrmHandler.sDictAppRuleSet[ParentWindow.mVmName][package].MessageWindow.DontShowOption)
								{
									GrmHandler.DonotShowCheckboxHandling(ParentWindow, package);
									GrmHandler.RefreshGrmIndication(package, ParentWindow.mVmName);
									GrmHandler.SendUpdateGrmPackagesToAndroid(ParentWindow.mVmName);
								}
								ParentWindow.mWelcomeTab.mHomeApp.GetAppIcon(package).OpenApp(false);
							});
						}
						dispatcher.Invoke(method, new object[0]);
						flag = null;
						break;
					}
					case GrmActionType.GlMode:
					{
						string text4 = grmAction.ActionDictionary["actionValue"];
						int glRenderMode = RegistryManager.Instance.Guest[ParentWindow.mVmName].GlRenderMode;
						int glMode = RegistryManager.Instance.Guest[ParentWindow.mVmName].GlMode;
						GlMode glMode2 = GlMode.PGA_GL;
						if (glRenderMode == 1 && glMode == 1)
						{
							glMode2 = GlMode.PGA_GL;
						}
						else if (glRenderMode == 1 && glMode == 2)
						{
							glMode2 = GlMode.AGA_GL;
						}
						else if (glMode == 1)
						{
							glMode2 = GlMode.PGA_DX;
						}
						else if (glMode == 2)
						{
							glMode2 = GlMode.AGA_DX;
						}
						List<string> list = (from _ in text4.Split(new char[]
						{
							','
						})
						select _.Trim()).ToList<string>();
						if (list.Contains(glMode2.ToString(), StringComparer.InvariantCultureIgnoreCase))
						{
							flag = new bool?(false);
						}
						else
						{
							text4 = list.RandomElement<string>();
							string text5 = "";
							int glRenderMode2;
							if (string.Compare(text4.Split(new char[]
							{
								'_'
							})[1].Trim(), "GL", StringComparison.OrdinalIgnoreCase) == 0)
							{
								glRenderMode2 = 1;
								text5 += "1";
							}
							else
							{
								glRenderMode2 = 4;
								text5 += "4";
							}
							int glMode3;
							if (string.Compare(text4.Split(new char[]
							{
								'_'
							})[0].Trim(), "PGA", StringComparison.OrdinalIgnoreCase) == 0)
							{
								glMode3 = 1;
								text5 += " 1";
							}
							else
							{
								glMode3 = 2;
								text5 += " 2";
							}
							if (RunCommand.RunCmd(Path.Combine(RegistryStrings.InstallDir, "HD-GlCheck"), text5, true, true, false, 0).ExitCode == 0)
							{
								RegistryManager.Instance.Guest[ParentWindow.mVmName].GlRenderMode = glRenderMode2;
								Utils.UpdateValueInBootParams("GlMode", glMode3.ToString(CultureInfo.InvariantCulture), ParentWindow.mVmName, true);
								RegistryManager.Instance.Guest[ParentWindow.mVmName].GlMode = glMode3;
							}
							else
							{
								GrmHandler.GrmExceptionMessageBox(ParentWindow);
								Logger.Info("GL check execution for the required combination failed.");
							}
							flag = new bool?(true);
						}
						break;
					}
					case GrmActionType.DeviceProfile:
					{
						string text6 = grmAction.ActionDictionary["pCode"];
						string text7 = string.Empty;
						if (string.Compare(text6, "custom", StringComparison.OrdinalIgnoreCase) == 0)
						{
							text7 = "{";
							text7 += string.Format(CultureInfo.InvariantCulture, "\"createcustomprofile\":\"{0}\",", new object[]
							{
								"true"
							});
							text7 += string.Format(CultureInfo.InvariantCulture, "\"model\":\"{0}\",", new object[]
							{
								grmAction.ActionDictionary["model"]
							});
							text7 += string.Format(CultureInfo.InvariantCulture, "\"brand\":\"{0}\",", new object[]
							{
								grmAction.ActionDictionary["brand"]
							});
							text7 += string.Format(CultureInfo.InvariantCulture, "\"manufacturer\":\"{0}\"", new object[]
							{
								grmAction.ActionDictionary["manufacturer"]
							});
							text7 += "}";
						}
						else
						{
							List<string> list2 = (from _ in text6.Split(new char[]
							{
								','
							})
							select _.Trim()).ToList<string>();
							string valueInBootParams = Utils.GetValueInBootParams("pcode", ParentWindow.mVmName, "");
							if (list2.Contains(valueInBootParams))
							{
								break;
							}
							text6 = list2.RandomElement<string>();
							text7 = "{";
							text7 += string.Format(CultureInfo.InvariantCulture, "\"createcustomprofile\":\"{0}\",", new object[]
							{
								"false"
							});
							text7 += string.Format(CultureInfo.InvariantCulture, "\"pcode\":\"{0}\"", new object[]
							{
								text6
							});
							text7 += "}";
						}
						if (string.Equals(VmCmdHandler.RunCommand(string.Format(CultureInfo.InvariantCulture, "{0} {1}", new object[]
						{
							"changeDeviceProfile",
							text7
						}), ParentWindow.mVmName), "ok", StringComparison.InvariantCulture))
						{
							Utils.UpdateValueInBootParams("pcode", text6, ParentWindow.mVmName, false);
							if (PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.Contains(package))
							{
								HTTPUtils.SendRequestToAgentAsync("clearAppData", new Dictionary<string, string>
								{
									{
										"package",
										package
									}
								}, ParentWindow.mVmName, 0, null, false, 1, 0);
							}
						}
						else
						{
							GrmHandler.GrmExceptionMessageBox(ParentWindow);
							Logger.Error("Setting device profile for the required combination failed.");
						}
						flag = new bool?(false);
						break;
					}
					case GrmActionType.BootParam:
					{
						string name = grmAction.ActionDictionary["param"].Trim();
						string value = grmAction.ActionDictionary["actionValue"].Trim();
						Utils.UpdateValueInBootParams(name, value, ParentWindow.mVmName, true);
						flag = new bool?(true);
						break;
					}
					case GrmActionType.DPI:
					{
						string updatedValue = grmAction.ActionDictionary["actionValue"];
						Utils.SetDPIInBootParameters(RegistryManager.Instance.Guest[ParentWindow.mVmName].BootParameters, updatedValue, ParentWindow.mVmName);
						flag = new bool?(true);
						break;
					}
					case GrmActionType.CpuCores:
					{
						int num4 = int.Parse(grmAction.ActionDictionary["actionValue"], CultureInfo.InvariantCulture);
						if (RegistryManager.Instance.CurrentEngine != EngineState.raw.ToString())
						{
							RegistryManager.Instance.Guest[ParentWindow.mVmName].VCPUs = ((num4 > 8) ? 8 : num4);
						}
						flag = new bool?(true);
						break;
					}
					case GrmActionType.Resolution:
					{
						string text8 = grmAction.ActionDictionary["actionValue"];
						List<string> list3 = (from _ in text8.Split(new char[]
						{
							','
						})
						select _.Replace(" ", string.Empty)).ToList<string>();
						int guestWidth = RegistryManager.Instance.Guest[ParentWindow.mVmName].GuestWidth;
						int guestHeight = RegistryManager.Instance.Guest[ParentWindow.mVmName].GuestHeight;
						string value2 = guestWidth.ToString(CultureInfo.InvariantCulture) + "x" + guestHeight.ToString(CultureInfo.InvariantCulture);
						if (!list3.Contains(value2, StringComparer.InvariantCultureIgnoreCase))
						{
							text8 = list3.RandomElement<string>();
							RegistryManager.Instance.Guest[ParentWindow.mVmName].GuestWidth = int.Parse(text8.Split(new char[]
							{
								'x'
							})[0].Trim(), CultureInfo.InvariantCulture);
							RegistryManager.Instance.Guest[ParentWindow.mVmName].GuestHeight = int.Parse(text8.Split(new char[]
							{
								'x'
							})[1].Trim(), CultureInfo.InvariantCulture);
							flag = new bool?(true);
						}
						break;
					}
					case GrmActionType.RestartBluestacks:
						flag = new bool?(true);
						break;
					case GrmActionType.RestartMachine:
						Process.Start("shutdown.exe", "-r -t 0");
						break;
					case GrmActionType.Fps:
					{
						int num5 = int.Parse(grmAction.ActionDictionary["actionValue"], CultureInfo.InvariantCulture);
						RegistryManager.Instance.Guest[ParentWindow.mVmName].FPS = num5;
						Utils.UpdateValueInBootParams("fps", num5.ToString(CultureInfo.InvariantCulture), ParentWindow.mVmName, true);
						Utils.SendChangeFPSToInstanceASync(ParentWindow.mVmName, num5);
						flag = new bool?(false);
						break;
					}
					case GrmActionType.EditRegistry:
					{
						string strA = grmAction.ActionDictionary["location"];
						if (string.Compare(strA, "registryManager", StringComparison.OrdinalIgnoreCase) == 0)
						{
							PropertyInfo property = typeof(RegistryManager).GetProperty(grmAction.ActionDictionary["propertyName"]);
							object value3 = Convert.ChangeType(grmAction.ActionDictionary["propertyValue"], Type.GetTypeCode(property.PropertyType), CultureInfo.InvariantCulture);
							property.SetValue(RegistryManager.Instance, value3, null);
						}
						else if (string.Compare(strA, "instanceManager", StringComparison.OrdinalIgnoreCase) == 0)
						{
							PropertyInfo property2 = typeof(InstanceRegistry).GetProperty(grmAction.ActionDictionary["propertyName"]);
							object value4 = Convert.ChangeType(grmAction.ActionDictionary["propertyValue"], Type.GetTypeCode(property2.PropertyType), CultureInfo.InvariantCulture);
							property2.SetValue(RegistryManager.Instance.Guest[ParentWindow.mVmName], value4, null);
						}
						else
						{
							string registryPath = string.Format(CultureInfo.InvariantCulture, "Software\\BlueStacks{0}\\{1}", new object[]
							{
								Strings.GetOemTag(),
								grmAction.ActionDictionary["propertyPath"].Replace("vmName", ParentWindow.mVmName)
							});
							object value5 = null;
							RegistryValueKind registryValueKind = EnumHelper.Parse<RegistryValueKind>(grmAction.ActionDictionary["propertyRegistryKind"], RegistryValueKind.String);
							if (registryValueKind != RegistryValueKind.String)
							{
								if (registryValueKind == RegistryValueKind.DWord)
								{
									value5 = int.Parse(grmAction.ActionDictionary["propertyValue"], CultureInfo.InvariantCulture);
								}
							}
							else
							{
								value5 = grmAction.ActionDictionary["propertyValue"];
							}
							RegistryUtils.SetRegistryValue(registryPath, grmAction.ActionDictionary["propertyName"], value5, registryValueKind, RegistryKeyKind.HKEY_LOCAL_MACHINE);
						}
						flag = new bool?(false);
						break;
					}
					case GrmActionType.ClearAppData:
						HTTPUtils.SendRequestToAgentAsync("clearAppData", new Dictionary<string, string>
						{
							{
								"package",
								package
							}
						}, ParentWindow.mVmName, 0, null, false, 1, 0);
						break;
					}
					bool? flag2 = flag;
					bool flag3 = true;
					if (flag2.GetValueOrDefault() == flag3 & flag2 != null)
					{
						e.Result = true;
					}
					else if (flag == null)
					{
						e.Result = null;
					}
				}
				Thread.Sleep(1000);
			}
			catch (Exception ex5)
			{
				Logger.Error("Exception in performing grm actions, ex: " + ex5.ToString());
				ClientStats.SendMiscellaneousStatsAsync("grm_action_error", RegistryManager.Instance.UserGuid, GrmHandler.sDictAppRuleSet[ParentWindow.mVmName][package].RuleId, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, "bgp", package, ex5.Message, null);
				GrmHandler.GrmExceptionMessageBox(ParentWindow);
				e.Result = null;
			}
		}

		// Token: 0x06000429 RID: 1065 RVA: 0x0001CF74 File Offset: 0x0001B174
		private static void PerformGrmActionsWorker_RunWorkerCompleted(RunWorkerCompletedEventArgs e, MainWindow ParentWindow)
		{
			if (e.Result == null)
			{
				return;
			}
			if (!(bool)e.Result)
			{
				ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					ParentWindow.mFrontendGrid.Visibility = Visibility.Visible;
					ParentWindow.mExitProgressGrid.Visibility = Visibility.Hidden;
				}), new object[0]);
				GrmHandler.RequirementConfigUpdated(ParentWindow.mVmName);
				return;
			}
			BlueStacksUIUtils.RestartInstance(ParentWindow.mVmName);
		}

		// Token: 0x0600042A RID: 1066 RVA: 0x0001CFE8 File Offset: 0x0001B1E8
		private static void GrmExceptionMessageBox(MainWindow ParentWindow)
		{
			ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				ParentWindow.mFrontendGrid.Visibility = Visibility.Visible;
				ParentWindow.mExitProgressGrid.Visibility = Visibility.Hidden;
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_ERROR");
				customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_GRM_EXCEPTION_MESSAGE");
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
				customMessageWindow.Owner = ParentWindow;
				ParentWindow.ShowDimOverlay(null);
				customMessageWindow.ShowDialog();
				ParentWindow.HideDimOverlay();
			}), new object[0]);
		}

		// Token: 0x0600042B RID: 1067 RVA: 0x0001D028 File Offset: 0x0001B228
		private static void DonotShowCheckboxHandling(MainWindow ParentWindow, string package)
		{
			bool? isChecked = GrmHandler.AppCompatErrorWindow.CheckBox.IsChecked;
			bool flag = true;
			if (isChecked.GetValueOrDefault() == flag & isChecked != null)
			{
				List<string> list = RegistryManager.Instance.Guest[ParentWindow.mVmName].GrmDonotShowRuleList.ToList<string>();
				if (!list.Contains(GrmHandler.sDictAppRuleSet[ParentWindow.mVmName][package].RuleId))
				{
					list.Add(GrmHandler.sDictAppRuleSet[ParentWindow.mVmName][package].RuleId);
				}
				RegistryManager.Instance.Guest[ParentWindow.mVmName].GrmDonotShowRuleList = list.ToArray();
			}
		}

		// Token: 0x0600042C RID: 1068 RVA: 0x0001D0E4 File Offset: 0x0001B2E4
		private static void AddGRMIndicationForIncompatibleApp(AppIcon appIcon, MainWindow ParentWindow, GrmRuleSet passedRuleSet)
		{
			ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				switch (EnumHelper.Parse<MessageType>(passedRuleSet.MessageWindow.MessageType, MessageType.None))
				{
				case MessageType.None:
					appIcon.IsAppIncompat = false;
					GrmHandler.sDictAppRuleSet[ParentWindow.mVmName].Remove(appIcon.PackageName);
					appIcon.mGl3ErrorIcon.Visibility = Visibility.Hidden;
					appIcon.mGl3InfoIcon.Visibility = Visibility.Hidden;
					return;
				case MessageType.Info:
					appIcon.IsAppIncompat = true;
					GrmHandler.sDictAppRuleSet[ParentWindow.mVmName][appIcon.PackageName] = passedRuleSet;
					appIcon.mGl3ErrorIcon.Visibility = Visibility.Hidden;
					appIcon.mGl3InfoIcon.Visibility = Visibility.Visible;
					return;
				case MessageType.Error:
					appIcon.IsAppIncompat = true;
					GrmHandler.sDictAppRuleSet[ParentWindow.mVmName][appIcon.PackageName] = passedRuleSet;
					appIcon.mGl3ErrorIcon.Visibility = Visibility.Visible;
					appIcon.mGl3InfoIcon.Visibility = Visibility.Hidden;
					return;
				default:
					return;
				}
			}), new object[0]);
		}

		// Token: 0x0600042D RID: 1069 RVA: 0x0001D130 File Offset: 0x0001B330
		private static void RemoveAppCompatError(AppIcon appIcon, MainWindow ParentWindow)
		{
			ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				appIcon.IsAppIncompat = false;
				GrmHandler.sDictAppRuleSet[ParentWindow.mVmName].Remove(appIcon.PackageName);
				appIcon.mGl3ErrorIcon.Visibility = Visibility.Hidden;
				appIcon.mGl3InfoIcon.Visibility = Visibility.Hidden;
			}), new object[0]);
		}

		// Token: 0x0400023D RID: 573
		private static Dictionary<string, Dictionary<string, GrmRuleSet>> sDictAppRuleSet = new Dictionary<string, Dictionary<string, GrmRuleSet>>();

		// Token: 0x0400023E RID: 574
		private static CustomMessageWindow AppCompatErrorWindow = null;
	}
}
