﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200018A RID: 394
	public class PreferencesSettingsControl : UserControl, IComponentConnector
	{
		// Token: 0x06000F57 RID: 3927 RVA: 0x00062744 File Offset: 0x00060944
		public PreferencesSettingsControl(MainWindow window)
		{
			this.InitializeComponent();
			this.mChangePrefGrid.Visibility = Visibility.Visible;
			this.mChangeLocaleGrid.Visibility = Visibility.Collapsed;
			this.ParentWindow = window;
			base.Visibility = Visibility.Hidden;
			this.InitSettings();
			this.AddLanguages();
			this.AddQuitOptions();
			if (!FeatureManager.Instance.IsShowLanguagePreference)
			{
				this.mLanguageSettingsGrid.Visibility = Visibility.Collapsed;
				this.mLanguagePreferencePaddingGrid.Visibility = Visibility.Collapsed;
			}
			if (!FeatureManager.Instance.IsShowDesktopShortcutPreference)
			{
				this.mAddDesktopShortcuts.Visibility = Visibility.Collapsed;
			}
			if (!FeatureManager.Instance.IsShowGamingSummaryPreference)
			{
				this.mShowGamingSummary.Visibility = Visibility.Collapsed;
			}
			if (!FeatureManager.Instance.IsShowPerformancePreference)
			{
				this.mPerformancePreference.Visibility = Visibility.Collapsed;
				this.mPerformancePreferencePaddingGrid.Visibility = Visibility.Collapsed;
			}
			if (!FeatureManager.Instance.IsShowDiscordPreference)
			{
				this.mDiscordCheckBox.Visibility = Visibility.Collapsed;
			}
			if (!FeatureManager.Instance.IsCustomCursorEnabled)
			{
				this.mCustomCursorCheckbox.Visibility = Visibility.Collapsed;
			}
			if (!FeatureManager.Instance.IsCustomUIForNCSoft)
			{
				this.mQuitOptionsGrid.Visibility = Visibility.Collapsed;
			}
			this.mScrollBar.ScrollChanged += BluestacksUIColor.ScrollBarScrollChanged;
		}

		// Token: 0x06000F58 RID: 3928 RVA: 0x00062878 File Offset: 0x00060A78
		private void AddQuitOptions()
		{
			ComboBoxItem comboBoxItem = null;
			foreach (string text in LocaleStringsConstants.ExitOptions)
			{
				ComboBoxItem comboBoxItem2 = new ComboBoxItem
				{
					Content = LocaleStrings.GetLocalizedString(text),
					Tag = text
				};
				this.mQuitOptionsComboBox.Items.Add(comboBoxItem2);
				if (text == RegistryManager.Instance.QuitDefaultOption)
				{
					comboBoxItem = comboBoxItem2;
				}
			}
			foreach (string text2 in LocaleStringsConstants.RestartOptions)
			{
				ComboBoxItem comboBoxItem3 = new ComboBoxItem
				{
					Content = LocaleStrings.GetLocalizedString(text2)
				};
				this.mQuitOptionsComboBox.Items.Add(comboBoxItem3);
				comboBoxItem3.Tag = text2;
				if (text2 == RegistryManager.Instance.QuitDefaultOption)
				{
					comboBoxItem = comboBoxItem3;
				}
			}
			if (comboBoxItem == null)
			{
				this.mQuitOptionsComboBox.SelectedIndex = 0;
				return;
			}
			this.mQuitOptionsComboBox.SelectedItem = comboBoxItem;
		}

		// Token: 0x06000F59 RID: 3929 RVA: 0x0006295C File Offset: 0x00060B5C
		private void AddLanguages()
		{
			foreach (string key in Globalization.sSupportedLocales.Keys)
			{
				ComboBoxItem comboBoxItem = new ComboBoxItem
				{
					Content = Globalization.sSupportedLocales[key].ToString(CultureInfo.InvariantCulture)
				};
				this.dictComboBoxItems.Add(comboBoxItem.Content.ToString(), comboBoxItem);
				this.mLanguageCombobox.Items.Add(comboBoxItem);
			}
			this.SelectDefaultValue();
		}

		// Token: 0x06000F5A RID: 3930 RVA: 0x000629FC File Offset: 0x00060BFC
		private void SelectDefaultValue()
		{
			this.mLanguageCombobox.SelectionChanged -= this.mLanguageCombobox_SelectionChanged;
			string text = RegistryManager.Instance.UserSelectedLocale;
			if (string.IsNullOrEmpty(text))
			{
				text = LocaleStrings.GetLocaleName("Android", false);
				RegistryManager.Instance.UserSelectedLocale = text;
			}
			else if (!Globalization.sSupportedLocales.ContainsKey(text))
			{
				string locale = text;
				text = "en-US";
				string text2 = Globalization.sSupportedLocales.Keys.FirstOrDefault((string x) => x.StartsWith(locale.Substring(0, 2), StringComparison.InvariantCulture));
				if (!string.IsNullOrEmpty(text2))
				{
					text = text2;
				}
			}
			this.mLanguageCombobox.SelectedItem = this.dictComboBoxItems[Globalization.sSupportedLocales[text].ToString(CultureInfo.InvariantCulture)];
			this.mLanguageCombobox.SelectionChanged += this.mLanguageCombobox_SelectionChanged;
		}

		// Token: 0x06000F5B RID: 3931 RVA: 0x00062AD4 File Offset: 0x00060CD4
		private void InitSettings()
		{
			if (!this.ParentWindow.IsDefaultVM)
			{
				this.mAddDesktopShortcuts.Visibility = Visibility.Collapsed;
			}
			if (RegistryManager.Instance.AddDesktopShortcuts)
			{
				this.mAddDesktopShortcuts.IsChecked = new bool?(true);
			}
			if (RegistryManager.Instance.SwitchToAndroidHome)
			{
				this.mSwitchToHome.IsChecked = new bool?(true);
			}
			else
			{
				this.mSwitchToHome.IsChecked = new bool?(false);
			}
			if (RegistryManager.Instance.SwitchKillWebTab)
			{
				this.mSwitchKillWebTab.IsChecked = new bool?(true);
			}
			else
			{
				this.mSwitchKillWebTab.IsChecked = new bool?(false);
			}
			if (RegistryManager.Instance.ShowGamingSummary)
			{
				this.mShowGamingSummary.IsChecked = new bool?(true);
			}
			else
			{
				this.mShowGamingSummary.IsChecked = new bool?(false);
			}
			if (FeatureManager.Instance.IsMacroRecorderEnabled)
			{
				this.mShowMacroDeleteWarning.IsChecked = new bool?(this.ParentWindow.EngineInstanceRegistry.ShowMacroDeletePopup);
			}
			else
			{
				this.mShowMacroDeleteWarning.Visibility = Visibility.Collapsed;
			}
			this.mShowSchemeDeleteWarning.IsChecked = new bool?(this.ParentWindow.EngineInstanceRegistry.ShowSchemeDeletePopup);
			if (PromotionObject.Instance != null && !string.IsNullOrEmpty(PromotionObject.Instance.DiscordClientID) && this.ParentWindow.IsDefaultVM)
			{
				this.mDiscordCheckBox.Visibility = Visibility.Visible;
				if (RegistryManager.Instance.DiscordEnabled)
				{
					this.mDiscordCheckBox.IsChecked = new bool?(true);
				}
				else
				{
					this.mDiscordCheckBox.IsChecked = new bool?(false);
				}
			}
			else
			{
				this.mDiscordCheckBox.Visibility = Visibility.Collapsed;
			}
			this.mEnableGamePadCheckbox.IsChecked = new bool?(RegistryManager.Instance.GamepadDetectionEnabled);
			bool? isChecked = this.mEnableGamePadCheckbox.IsChecked;
			bool flag = true;
			if (isChecked.GetValueOrDefault() == flag & isChecked != null)
			{
				this.mEnableNativeGamepad.IsEnabled = true;
			}
			else
			{
				this.mEnableNativeGamepad.IsEnabled = false;
			}
			this.mEnableNativeGamepad.IsChecked = new bool?(this.ParentWindow.EngineInstanceRegistry.IsNativeGamepadEnabled);
			isChecked = this.mEnableNativeGamepad.IsChecked;
			flag = true;
			if (isChecked.GetValueOrDefault() == flag & isChecked != null)
			{
				this.mNativeGamepadInfo.Visibility = Visibility.Visible;
			}
			else
			{
				this.mNativeGamepadInfo.Visibility = Visibility.Collapsed;
			}
			if (FeatureManager.Instance.AllowADBSettingToggle)
			{
				try
				{
					if (this.ParentWindow.mGuestBootCompleted)
					{
						this.CheckIfAdbIsEnabled();
					}
					else
					{
						this.mEnableAdbCheckBox.Visibility = Visibility.Collapsed;
						this.mEnableAdbWarning.Visibility = Visibility.Collapsed;
					}
					goto IL_2C4;
				}
				catch (Exception ex)
				{
					Logger.Error("Exception when initialising adb checkbox " + ex.ToString());
					this.mEnableAdbCheckBox.Visibility = Visibility.Collapsed;
					this.mEnableAdbWarning.Visibility = Visibility.Collapsed;
					goto IL_2C4;
				}
			}
			this.mEnableAdbCheckBox.Visibility = Visibility.Collapsed;
			this.mEnableAdbWarning.Visibility = Visibility.Collapsed;
			IL_2C4:
			if (FeatureManager.Instance.IsShowAndroidInputDebugSetting)
			{
				try
				{
					if (this.ParentWindow.mGuestBootCompleted)
					{
						this.CheckIfAndroidTouchPointsEnabled();
					}
					else
					{
						this.HideAndroidInputDebugSettingsCheckbox();
					}
					goto IL_311;
				}
				catch (Exception ex2)
				{
					Logger.Error("Exception when initialising android input debugging checkbox " + ex2.ToString());
					this.HideAndroidInputDebugSettingsCheckbox();
					goto IL_311;
				}
			}
			this.HideAndroidInputDebugSettingsCheckbox();
			IL_311:
			if (StringExtensions.IsValidPath(RegistryManager.Instance.ScreenShotsPath))
			{
				this.mScreenShotPathLable.Text = RegistryManager.Instance.ScreenShotsPath;
			}
			else
			{
				string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), Strings.ProductTopBarDisplayName);
				if (!Directory.Exists(text))
				{
					Directory.CreateDirectory(text);
				}
				RegistryManager.Instance.ScreenShotsPath = text;
				this.mScreenShotPathLable.Text = text;
			}
			if (!RegistryManager.Instance.Guest[this.ParentWindow.mVmName].IsGoogleSigninDone)
			{
				this.mLanguageSettingsGrid.Visibility = Visibility.Collapsed;
				this.mLanguagePreferencePaddingGrid.Visibility = Visibility.Collapsed;
			}
			if (!this.ParentWindow.mGuestBootCompleted)
			{
				this.mCustomCursorCheckbox.Visibility = Visibility.Collapsed;
			}
			else
			{
				this.mCustomCursorCheckbox.Visibility = Visibility.Visible;
				this.mCustomCursorCheckbox.IsChecked = new bool?(RegistryManager.Instance.CustomCursorEnabled);
			}
			this.mMinimzeOnCloseCheckBox.IsChecked = new bool?(this.ParentWindow.EngineInstanceRegistry.IsShowMinimizeBlueStacksPopupOnClose);
			this.mShowOnExitCheckbox.IsChecked = new bool?(!RegistryManager.Instance.IsQuitOptionSaved);
		}

		// Token: 0x06000F5C RID: 3932 RVA: 0x0000B335 File Offset: 0x00009535
		private void HideAndroidInputDebugSettingsCheckbox()
		{
			this.mEnableDevSettingsCheckBox.Visibility = Visibility.Collapsed;
			this.mEnableDevSettingsWarning.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000F5D RID: 3933 RVA: 0x00062F2C File Offset: 0x0006112C
		private void CheckIfAdbIsEnabled()
		{
			string text = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_ADB_CONNECTED_PORT_0"), new object[]
			{
				this.ParentWindow.EngineInstanceRegistry.BstAdbPort
			});
			this.mEnableAdbWarning.Text = string.Format(CultureInfo.InvariantCulture, "{0} {1}", new object[]
			{
				LocaleStrings.GetLocalizedString("STRING_ENABLE_ADB_WARNING"),
				text
			});
			JObject jobject = JsonConvert.DeserializeObject(HTTPUtils.SendRequestToGuest("checkADBStatus", null, this.ParentWindow.mVmName, 0, null, false, 1, 0), Utils.GetSerializerSettings()) as JObject;
			if (string.Compare("ok", jobject["result"].Value<string>(), StringComparison.OrdinalIgnoreCase) == 0)
			{
				this.mEnableAdbCheckBox.IsChecked = new bool?(true);
			}
			else
			{
				this.mEnableAdbCheckBox.IsChecked = new bool?(false);
			}
			this.mEnableAdbCheckBox.Visibility = Visibility.Visible;
			this.mEnableAdbWarning.Visibility = Visibility.Visible;
		}

		// Token: 0x06000F5E RID: 3934 RVA: 0x00063024 File Offset: 0x00061224
		private void CheckIfAndroidTouchPointsEnabled()
		{
			JObject jobject = JObject.Parse(HTTPUtils.SendRequestToGuest("checkTouchPointState", null, this.ParentWindow.mVmName, 0, null, false, 1, 0));
			string b = jobject["touchPoint"].ToString().Trim();
			string b2 = jobject["pointerLocation"].ToString().Trim();
			this.mEnableDevSettingsCheckBox.IsChecked = new bool?(string.Equals("enabled", b, StringComparison.InvariantCultureIgnoreCase) || string.Equals("enabled", b2, StringComparison.InvariantCultureIgnoreCase));
			this.mEnableDevSettingsCheckBox.Visibility = Visibility.Visible;
			this.mEnableDevSettingsWarning.Visibility = Visibility.Visible;
		}

		// Token: 0x06000F5F RID: 3935 RVA: 0x000630C4 File Offset: 0x000612C4
		private void CheckBox_Click(object sender, RoutedEventArgs e)
		{
			this.mChangeLocaleGrid.Visibility = Visibility.Collapsed;
			this.mChangePrefGrid.Visibility = Visibility.Visible;
			CustomCheckbox customCheckbox = sender as CustomCheckbox;
			if (customCheckbox == this.mAddDesktopShortcuts)
			{
				bool flag = true;
				bool? isChecked = this.mAddDesktopShortcuts.IsChecked;
				if (flag == isChecked.GetValueOrDefault() & isChecked != null)
				{
					RegistryManager.Instance.AddDesktopShortcuts = true;
					return;
				}
				RegistryManager.Instance.AddDesktopShortcuts = false;
				return;
			}
			else
			{
				bool? isChecked;
				bool flag2;
				if (customCheckbox != this.mShowGamingSummary)
				{
					if (customCheckbox == this.mDiscordCheckBox)
					{
						isChecked = this.mDiscordCheckBox.IsChecked;
						flag2 = true;
						if (!(isChecked.GetValueOrDefault() == flag2 & isChecked != null))
						{
							RegistryManager.Instance.DiscordEnabled = false;
							if (this.ParentWindow.mDiscordhandler != null)
							{
								this.ParentWindow.mDiscordhandler.ToggleDiscordState(false);
							}
							this.ParentWindow.mDiscordhandler = null;
							return;
						}
						RegistryManager.Instance.DiscordEnabled = true;
						if (this.ParentWindow.mAppHandler.IsOneTimeSetupCompleted && this.ParentWindow.mGuestBootCompleted)
						{
							if (this.ParentWindow.mDiscordhandler == null)
							{
								this.ParentWindow.InitDiscord();
								return;
							}
							this.ParentWindow.mDiscordhandler.ToggleDiscordState(true);
							return;
						}
					}
					else if (customCheckbox == this.mEnableAdbCheckBox)
					{
						isChecked = this.mEnableAdbCheckBox.IsChecked;
						flag2 = true;
						HTTPUtils.SendRequestToGuestAsync((isChecked.GetValueOrDefault() == flag2 & isChecked != null) ? "connectHost?d=permanent" : "disconnectHost?d=permanent", null, this.ParentWindow.mVmName, 0, null, false, 1, 0);
						isChecked = this.mEnableAdbCheckBox.IsChecked;
						flag2 = true;
						if ((isChecked.GetValueOrDefault() == flag2 & isChecked != null) && SecurityMetrics.SecurityMetricsInstanceList.ContainsKey(this.ParentWindow.mVmName))
						{
							SecurityMetrics.SecurityMetricsInstanceList[this.ParentWindow.mVmName].AddSecurityBreach(SecurityBreach.DEVICE_PROBED, "");
							return;
						}
					}
					else
					{
						if (customCheckbox == this.mEnableDevSettingsCheckBox)
						{
							isChecked = this.mEnableDevSettingsCheckBox.IsChecked;
							flag2 = true;
							string text = (isChecked.GetValueOrDefault() == flag2 & isChecked != null) ? "enable" : "disable";
							string text2 = "{";
							text2 += string.Format(CultureInfo.InvariantCulture, "\"touchPoint\":\"{0}\",", new object[]
							{
								text
							});
							text2 += string.Format(CultureInfo.InvariantCulture, "\"pointerLocation\":\"{0}\"", new object[]
							{
								text
							});
							text2 += "}";
							Dictionary<string, string> data = new Dictionary<string, string>
							{
								{
									"data",
									text2
								}
							};
							HTTPUtils.SendRequestToGuest("showTouchPoints", data, this.ParentWindow.mVmName, 0, null, false, 1, 0);
							return;
						}
						if (customCheckbox == this.mCustomCursorCheckbox)
						{
							try
							{
								isChecked = this.mCustomCursorCheckbox.IsChecked;
								flag2 = true;
								if (isChecked.GetValueOrDefault() == flag2 & isChecked != null)
								{
									RegistryManager.Instance.CustomCursorEnabled = true;
								}
								else
								{
									RegistryManager.Instance.CustomCursorEnabled = false;
								}
								foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values)
								{
									mainWindow.mCommonHandler.SetCustomCursorForApp(mainWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName);
								}
								return;
							}
							catch (Exception ex)
							{
								Logger.Error("Exception in custom cursor setting change: {0}", new object[]
								{
									ex
								});
								return;
							}
						}
						if (customCheckbox == this.mShowMacroDeleteWarning)
						{
							this.ParentWindow.EngineInstanceRegistry.ShowMacroDeletePopup = this.mShowMacroDeleteWarning.IsChecked.Value;
							return;
						}
						if (customCheckbox == this.mShowSchemeDeleteWarning)
						{
							this.ParentWindow.EngineInstanceRegistry.ShowSchemeDeletePopup = this.mShowSchemeDeleteWarning.IsChecked.Value;
							return;
						}
						if (customCheckbox == this.mEnableGamePadCheckbox)
						{
							isChecked = this.mEnableGamePadCheckbox.IsChecked;
							flag2 = true;
							if (isChecked.GetValueOrDefault() == flag2 & isChecked != null)
							{
								RegistryManager.Instance.GamepadDetectionEnabled = true;
								this.mEnableNativeGamepad.IsEnabled = true;
								if (this.ParentWindow.EngineInstanceRegistry.IsNativeGamepadEnabled)
								{
									Dictionary<string, string> data2 = new Dictionary<string, string>
									{
										{
											"isEnabled",
											RegistryManager.Instance.GamepadDetectionEnabled.ToString(CultureInfo.InvariantCulture)
										}
									};
									this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("enableNativeGamepad", data2);
									KMManager.ShowOverlayWindow(this.ParentWindow, false, false);
								}
							}
							else
							{
								RegistryManager.Instance.GamepadDetectionEnabled = false;
								Dictionary<string, string> data3 = new Dictionary<string, string>
								{
									{
										"isEnabled",
										RegistryManager.Instance.GamepadDetectionEnabled.ToString(CultureInfo.InvariantCulture)
									}
								};
								this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("enableNativeGamepad", data3);
								this.mEnableNativeGamepad.IsEnabled = false;
							}
							Dictionary<string, string> data4 = new Dictionary<string, string>
							{
								{
									"enable",
									RegistryManager.Instance.GamepadDetectionEnabled.ToString(CultureInfo.InvariantCulture)
								}
							};
							this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("enableGamepad", data4);
							return;
						}
						if (customCheckbox == this.mEnableNativeGamepad)
						{
							isChecked = this.mEnableNativeGamepad.IsChecked;
							flag2 = true;
							if (isChecked.GetValueOrDefault() == flag2 & isChecked != null)
							{
								this.ParentWindow.EngineInstanceRegistry.IsNativeGamepadEnabled = true;
								this.mNativeGamepadInfo.Visibility = Visibility.Visible;
								ClientStats.SendMiscellaneousStatsAsync("GamepadModeChanged", RegistryManager.Instance.UserGuid, "Bluestacks", "SettingsWindow", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
							}
							else
							{
								this.ParentWindow.EngineInstanceRegistry.IsNativeGamepadEnabled = false;
								this.mNativeGamepadInfo.Visibility = Visibility.Collapsed;
								ClientStats.SendMiscellaneousStatsAsync("GamepadModeChanged", RegistryManager.Instance.UserGuid, "Native", "SettingsWindow", RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null, null);
							}
							Dictionary<string, string> data5 = new Dictionary<string, string>
							{
								{
									"isEnabled",
									this.ParentWindow.EngineInstanceRegistry.IsNativeGamepadEnabled.ToString(CultureInfo.InvariantCulture)
								}
							};
							this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("enableNativeGamepad", data5);
							return;
						}
						if (customCheckbox == this.mMinimzeOnCloseCheckBox)
						{
							isChecked = this.mMinimzeOnCloseCheckBox.IsChecked;
							flag2 = true;
							if (isChecked.GetValueOrDefault() == flag2 & isChecked != null)
							{
								this.ParentWindow.EngineInstanceRegistry.IsShowMinimizeBlueStacksPopupOnClose = true;
								return;
							}
							this.ParentWindow.EngineInstanceRegistry.IsShowMinimizeBlueStacksPopupOnClose = false;
						}
					}
					return;
				}
				ClientStats.SendMiscellaneousStatsAsync("gamingSummaryCheckboxClicked", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "checked" + this.mShowGamingSummary.IsChecked.ToString(), null, null, null, null, null);
				isChecked = this.mShowGamingSummary.IsChecked;
				flag2 = true;
				if (isChecked.GetValueOrDefault() == flag2 & isChecked != null)
				{
					RegistryManager.Instance.ShowGamingSummary = true;
					return;
				}
				RegistryManager.Instance.ShowGamingSummary = false;
				return;
			}
		}

		// Token: 0x06000F60 RID: 3936 RVA: 0x000637E4 File Offset: 0x000619E4
		private void mLanguageCombobox_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			try
			{
				string selectedLocale = (this.mLanguageCombobox.SelectedItem as ComboBoxItem).Content.ToString();
				if (selectedLocale != null)
				{
					this.mChangePrefGrid.Visibility = Visibility.Visible;
					string key = Globalization.sSupportedLocales.FirstOrDefault((KeyValuePair<string, string> x) => x.Value == selectedLocale).Key;
					if (!string.Equals(RegistryManager.Instance.UserSelectedLocale, key, StringComparison.InvariantCultureIgnoreCase))
					{
						RegistryManager.Instance.UserSelectedLocale = key;
						BlueStacksUIUtils.UpdateLocale(key, "");
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in set locale" + ex.ToString());
			}
		}

		// Token: 0x06000F61 RID: 3937 RVA: 0x000638A0 File Offset: 0x00061AA0
		private void mSwitchToHome_Click(object sender, RoutedEventArgs e)
		{
			bool? isChecked = this.mSwitchToHome.IsChecked;
			bool flag = true;
			if (isChecked.GetValueOrDefault() == flag & isChecked != null)
			{
				RegistryManager.Instance.SwitchToAndroidHome = true;
				return;
			}
			RegistryManager.Instance.SwitchToAndroidHome = false;
		}

		// Token: 0x06000F62 RID: 3938 RVA: 0x000638E8 File Offset: 0x00061AE8
		private void SwitchKillWebTab_Click(object sender, RoutedEventArgs e)
		{
			bool? isChecked = this.mSwitchKillWebTab.IsChecked;
			bool flag = true;
			if (isChecked.GetValueOrDefault() == flag & isChecked != null)
			{
				RegistryManager.Instance.SwitchKillWebTab = true;
				return;
			}
			RegistryManager.Instance.SwitchKillWebTab = false;
		}

		// Token: 0x06000F63 RID: 3939 RVA: 0x00063930 File Offset: 0x00061B30
		private void mChangePathBtn_Click(object sender, RoutedEventArgs e)
		{
			string text = this.mScreenShotPathLable.Text;
			this.ParentWindow.mCommonHandler.ShowFolderBrowserDialog(text);
			this.mScreenShotPathLable.Text = RegistryManager.Instance.ScreenShotsPath;
			ClientStats.SendMiscellaneousStatsAsync("MediaFilesPathSet", RegistryManager.Instance.UserGuid, "PathChangeFromPreferences", text, RegistryManager.Instance.ScreenShotsPath, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, RegistryManager.Instance.Oem, null);
		}

		// Token: 0x06000F64 RID: 3940 RVA: 0x0000B34F File Offset: 0x0000954F
		private void MQuitOptionsComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			RegistryManager.Instance.QuitDefaultOption = (this.mQuitOptionsComboBox.SelectedItem as ComboBoxItem).Tag.ToString();
		}

		// Token: 0x06000F65 RID: 3941 RVA: 0x000639B4 File Offset: 0x00061BB4
		private void MShowOnExitCheckbox_Click(object sender, RoutedEventArgs e)
		{
			CustomCheckbox customCheckbox = sender as CustomCheckbox;
			RegistryManager.Instance.IsQuitOptionSaved = !customCheckbox.IsChecked.Value;
		}

		// Token: 0x06000F66 RID: 3942 RVA: 0x0000B375 File Offset: 0x00009575
		private void HelpIconPreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Utils.OpenUrl(WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
			{
				WebHelper.GetServerHost(),
				"help_articles"
			})) + "&article=native_gamepad_help");
		}

		// Token: 0x06000F67 RID: 3943 RVA: 0x000639E4 File Offset: 0x00061BE4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/preferencessettingscontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000F68 RID: 3944 RVA: 0x00063A14 File Offset: 0x00061C14
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mScrollBar = (ScrollViewer)target;
				return;
			case 2:
				this.mMainGrid = (Grid)target;
				return;
			case 3:
				this.mLanguageSettingsGrid = (Grid)target;
				return;
			case 4:
				this.mLanguageCombobox = (CustomComboBox)target;
				this.mLanguageCombobox.SelectionChanged += this.mLanguageCombobox_SelectionChanged;
				return;
			case 5:
				this.mLanguagePreferencePaddingGrid = (Grid)target;
				return;
			case 6:
				this.mPerformancePreference = (Grid)target;
				return;
			case 7:
				this.mPerformanceSettingsLabel = (Label)target;
				return;
			case 8:
				this.mSwitchToHome = (CustomCheckbox)target;
				this.mSwitchToHome.Click += this.mSwitchToHome_Click;
				return;
			case 9:
				this.mSwitchKillWebTab = (CustomCheckbox)target;
				this.mSwitchKillWebTab.Click += this.SwitchKillWebTab_Click;
				return;
			case 10:
				this.mGameControlPreferencePaddingGrid = (Grid)target;
				return;
			case 11:
				this.mGameControlsSettingsGrid = (Grid)target;
				return;
			case 12:
				this.mGameControlSettingsLabel = (Label)target;
				return;
			case 13:
				this.mGameControlsStackPanel = (StackPanel)target;
				return;
			case 14:
				this.mEnableGamePadCheckbox = (CustomCheckbox)target;
				this.mEnableGamePadCheckbox.Click += this.CheckBox_Click;
				return;
			case 15:
				this.mEnableNativeGamepad = (CustomCheckbox)target;
				this.mEnableNativeGamepad.Click += this.CheckBox_Click;
				return;
			case 16:
				this.mHelpIcon = (CustomPictureBox)target;
				this.mHelpIcon.PreviewMouseLeftButtonUp += this.HelpIconPreviewMouseLeftButtonUp;
				return;
			case 17:
				this.mNativeGamepadInfo = (Grid)target;
				return;
			case 18:
				this.mShowSchemeDeleteWarning = (CustomCheckbox)target;
				this.mShowSchemeDeleteWarning.Click += this.CheckBox_Click;
				return;
			case 19:
				this.mCustomCursorCheckbox = (CustomCheckbox)target;
				this.mCustomCursorCheckbox.Click += this.CheckBox_Click;
				return;
			case 20:
				this.mPerformancePreferencePaddingGrid = (Grid)target;
				return;
			case 21:
				this.mPlatformStackPanel = (StackPanel)target;
				return;
			case 22:
				this.mAddDesktopShortcuts = (CustomCheckbox)target;
				this.mAddDesktopShortcuts.Click += this.CheckBox_Click;
				return;
			case 23:
				this.mShowGamingSummary = (CustomCheckbox)target;
				this.mShowGamingSummary.Click += this.CheckBox_Click;
				return;
			case 24:
				this.mShowMacroDeleteWarning = (CustomCheckbox)target;
				this.mShowMacroDeleteWarning.Click += this.CheckBox_Click;
				return;
			case 25:
				this.mDiscordCheckBox = (CustomCheckbox)target;
				this.mDiscordCheckBox.Click += this.CheckBox_Click;
				return;
			case 26:
				this.mMinimzeOnCloseCheckBox = (CustomCheckbox)target;
				this.mMinimzeOnCloseCheckBox.Click += this.CheckBox_Click;
				return;
			case 27:
				this.mEnableAdbCheckBox = (CustomCheckbox)target;
				this.mEnableAdbCheckBox.Click += this.CheckBox_Click;
				return;
			case 28:
				this.mEnableAdbWarning = (TextBlock)target;
				return;
			case 29:
				this.mEnableDevSettingsCheckBox = (CustomCheckbox)target;
				this.mEnableDevSettingsCheckBox.Click += this.CheckBox_Click;
				return;
			case 30:
				this.mEnableDevSettingsWarning = (TextBlock)target;
				return;
			case 31:
				this.mQuitOptionsGrid = (Grid)target;
				return;
			case 32:
				this.mQuitOptionsComboBox = (CustomComboBox)target;
				this.mQuitOptionsComboBox.SelectionChanged += this.MQuitOptionsComboBox_SelectionChanged;
				return;
			case 33:
				this.mShowOnExitCheckbox = (CustomCheckbox)target;
				this.mShowOnExitCheckbox.Click += this.MShowOnExitCheckbox_Click;
				return;
			case 34:
				this.mScreenshotGrid = (Grid)target;
				return;
			case 35:
				this.mScreenShotPathLable = (TextBlock)target;
				return;
			case 36:
				this.mChangePathBtn = (CustomButton)target;
				this.mChangePathBtn.Click += this.mChangePathBtn_Click;
				return;
			case 37:
				this.mChangeLocaleGrid = (Grid)target;
				return;
			case 38:
				this.mInfoIconLocale = (CustomPictureBox)target;
				return;
			case 39:
				this.mChangePrefGrid = (Grid)target;
				return;
			case 40:
				this.mInfoIcon = (CustomPictureBox)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000A53 RID: 2643
		private Dictionary<string, ComboBoxItem> dictComboBoxItems = new Dictionary<string, ComboBoxItem>();

		// Token: 0x04000A54 RID: 2644
		private MainWindow ParentWindow;

		// Token: 0x04000A55 RID: 2645
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ScrollViewer mScrollBar;

		// Token: 0x04000A56 RID: 2646
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mMainGrid;

		// Token: 0x04000A57 RID: 2647
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mLanguageSettingsGrid;

		// Token: 0x04000A58 RID: 2648
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomComboBox mLanguageCombobox;

		// Token: 0x04000A59 RID: 2649
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mLanguagePreferencePaddingGrid;

		// Token: 0x04000A5A RID: 2650
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mPerformancePreference;

		// Token: 0x04000A5B RID: 2651
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Label mPerformanceSettingsLabel;

		// Token: 0x04000A5C RID: 2652
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mSwitchToHome;

		// Token: 0x04000A5D RID: 2653
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mSwitchKillWebTab;

		// Token: 0x04000A5E RID: 2654
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mGameControlPreferencePaddingGrid;

		// Token: 0x04000A5F RID: 2655
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mGameControlsSettingsGrid;

		// Token: 0x04000A60 RID: 2656
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Label mGameControlSettingsLabel;

		// Token: 0x04000A61 RID: 2657
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mGameControlsStackPanel;

		// Token: 0x04000A62 RID: 2658
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mEnableGamePadCheckbox;

		// Token: 0x04000A63 RID: 2659
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mEnableNativeGamepad;

		// Token: 0x04000A64 RID: 2660
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mHelpIcon;

		// Token: 0x04000A65 RID: 2661
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mNativeGamepadInfo;

		// Token: 0x04000A66 RID: 2662
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mShowSchemeDeleteWarning;

		// Token: 0x04000A67 RID: 2663
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mCustomCursorCheckbox;

		// Token: 0x04000A68 RID: 2664
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mPerformancePreferencePaddingGrid;

		// Token: 0x04000A69 RID: 2665
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mPlatformStackPanel;

		// Token: 0x04000A6A RID: 2666
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mAddDesktopShortcuts;

		// Token: 0x04000A6B RID: 2667
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mShowGamingSummary;

		// Token: 0x04000A6C RID: 2668
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mShowMacroDeleteWarning;

		// Token: 0x04000A6D RID: 2669
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mDiscordCheckBox;

		// Token: 0x04000A6E RID: 2670
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mMinimzeOnCloseCheckBox;

		// Token: 0x04000A6F RID: 2671
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mEnableAdbCheckBox;

		// Token: 0x04000A70 RID: 2672
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mEnableAdbWarning;

		// Token: 0x04000A71 RID: 2673
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mEnableDevSettingsCheckBox;

		// Token: 0x04000A72 RID: 2674
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mEnableDevSettingsWarning;

		// Token: 0x04000A73 RID: 2675
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mQuitOptionsGrid;

		// Token: 0x04000A74 RID: 2676
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomComboBox mQuitOptionsComboBox;

		// Token: 0x04000A75 RID: 2677
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mShowOnExitCheckbox;

		// Token: 0x04000A76 RID: 2678
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mScreenshotGrid;

		// Token: 0x04000A77 RID: 2679
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mScreenShotPathLable;

		// Token: 0x04000A78 RID: 2680
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mChangePathBtn;

		// Token: 0x04000A79 RID: 2681
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mChangeLocaleGrid;

		// Token: 0x04000A7A RID: 2682
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mInfoIconLocale;

		// Token: 0x04000A7B RID: 2683
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mChangePrefGrid;

		// Token: 0x04000A7C RID: 2684
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mInfoIcon;

		// Token: 0x04000A7D RID: 2685
		private bool _contentLoaded;
	}
}
