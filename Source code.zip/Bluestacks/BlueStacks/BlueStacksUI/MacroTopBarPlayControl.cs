﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000A0 RID: 160
	public class MacroTopBarPlayControl : UserControl, IComponentConnector
	{
		// Token: 0x170001B3 RID: 435
		// (get) Token: 0x06000625 RID: 1573 RVA: 0x00005F51 File Offset: 0x00004151
		// (set) Token: 0x06000626 RID: 1574 RVA: 0x00005F59 File Offset: 0x00004159
		public DateTime mStartTime { get; set; }

		// Token: 0x14000006 RID: 6
		// (add) Token: 0x06000627 RID: 1575 RVA: 0x00024ED4 File Offset: 0x000230D4
		// (remove) Token: 0x06000628 RID: 1576 RVA: 0x00024F0C File Offset: 0x0002310C
		internal event MacroTopBarPlayControl.ScriptPlayDelegate ScriptPlayEvent;

		// Token: 0x14000007 RID: 7
		// (add) Token: 0x06000629 RID: 1577 RVA: 0x00024F44 File Offset: 0x00023144
		// (remove) Token: 0x0600062A RID: 1578 RVA: 0x00024F7C File Offset: 0x0002317C
		internal event MacroTopBarPlayControl.ScriptStopDelegate ScriptStopEvent;

		// Token: 0x0600062B RID: 1579 RVA: 0x00005F62 File Offset: 0x00004162
		public MacroTopBarPlayControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600062C RID: 1580 RVA: 0x00005F77 File Offset: 0x00004177
		internal void OnScriptPlayEvent(string tag)
		{
			MacroTopBarPlayControl.ScriptPlayDelegate scriptPlayEvent = this.ScriptPlayEvent;
			if (scriptPlayEvent == null)
			{
				return;
			}
			scriptPlayEvent(tag);
		}

		// Token: 0x0600062D RID: 1581 RVA: 0x00005F8A File Offset: 0x0000418A
		private void BlinkPlayingIcon_Tick(object sender, EventArgs e)
		{
			this.ToggleRecordingIcon();
		}

		// Token: 0x0600062E RID: 1582 RVA: 0x00005F92 File Offset: 0x00004192
		internal void StopTimer()
		{
			this.mBlinkPlayingIconTimer.Stop();
			this.mTimer.Stop();
		}

		// Token: 0x0600062F RID: 1583 RVA: 0x00005FAA File Offset: 0x000041AA
		internal void StartTimer()
		{
			this.mBlinkPlayingIconTimer.Start();
			this.mTimer.Start();
		}

		// Token: 0x06000630 RID: 1584 RVA: 0x00005FC2 File Offset: 0x000041C2
		private void ToggleRecordingIcon()
		{
			if (this.mShowPlayingIcon)
			{
				this.RecordingImage.ImageName = "recording_macro_title_play";
				this.mShowPlayingIcon = false;
				return;
			}
			this.RecordingImage.ImageName = "recording_macro";
			this.mShowPlayingIcon = true;
		}

		// Token: 0x06000631 RID: 1585 RVA: 0x00005FFB File Offset: 0x000041FB
		internal void OnScriptStopEvent(string tag)
		{
			MacroTopBarPlayControl.ScriptStopDelegate scriptStopEvent = this.ScriptStopEvent;
			if (scriptStopEvent == null)
			{
				return;
			}
			scriptStopEvent(tag);
		}

		// Token: 0x06000632 RID: 1586 RVA: 0x00024FB4 File Offset: 0x000231B4
		internal void Init(MainWindow parentWindow, MacroRecording record)
		{
			this.ParentWindow = parentWindow;
			this.mOperationsRecord = record;
			this.mRunningScript.Text = this.mOperationsRecord.Name;
			this.mRunningIterations.Visibility = Visibility.Visible;
			this.mRunningScript.ToolTip = string.Format(CultureInfo.InvariantCulture, "{0} {1}", new object[]
			{
				LocaleStrings.GetLocalizedString("STRING_PLAYING"),
				this.mRunningScript.Text
			});
			if (this.mBlinkPlayingIconTimer == null)
			{
				this.mBlinkPlayingIconTimer = new DispatcherTimer(new TimeSpan(0, 0, 0, 0, 500), DispatcherPriority.Render, new EventHandler(this.BlinkPlayingIcon_Tick), Dispatcher.CurrentDispatcher);
				this.mTimer = new DispatcherTimer(new TimeSpan(0, 0, 0, 0, 50), DispatcherPriority.Render, new EventHandler(this.T_Tick), Dispatcher.CurrentDispatcher);
				this.StartTimer();
			}
		}

		// Token: 0x06000633 RID: 1587 RVA: 0x00025090 File Offset: 0x00023290
		private void T_Tick(object sender, EventArgs e)
		{
			TimeSpan timeSpan = DateTime.Now - this.mStartTime;
			string text = string.Format(CultureInfo.InvariantCulture, "{0:00}:{1:00}:{2:00}", new object[]
			{
				timeSpan.Minutes,
				timeSpan.Seconds,
				timeSpan.Milliseconds / 10
			});
			this.mTimerDisplay.Text = text;
		}

		// Token: 0x06000634 RID: 1588 RVA: 0x0000600E File Offset: 0x0000420E
		internal void IncreaseIteration(int iteration)
		{
			this.mRunningIterations.Text = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_RUNNING_X_TIME"), new object[]
			{
				Strings.AddOrdinal(iteration)
			});
		}

		// Token: 0x06000635 RID: 1589 RVA: 0x00005D29 File Offset: 0x00003F29
		private void PauseMacro_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
		}

		// Token: 0x06000636 RID: 1590 RVA: 0x0000603E File Offset: 0x0000423E
		private void PlayMacro_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.OnScriptPlayEvent(this.mOperationsRecord.Name);
		}

		// Token: 0x06000637 RID: 1591 RVA: 0x00006051 File Offset: 0x00004251
		private void StopMacro_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.StopMacro();
		}

		// Token: 0x06000638 RID: 1592 RVA: 0x00025100 File Offset: 0x00023300
		public void StopMacro()
		{
			this.StopTimer();
			this.mBlinkPlayingIconTimer = null;
			this.ParentWindow.mCommonHandler.StopMacroScriptHandling();
			MacroTopBarPlayControl.ScriptStopDelegate scriptStopEvent = this.ScriptStopEvent;
			if (scriptStopEvent != null)
			{
				scriptStopEvent(this.mOperationsRecord.Name);
			}
			ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_stop", null, this.mOperationsRecord.RecordingType.ToString(), null, null, null);
		}

		// Token: 0x06000639 RID: 1593 RVA: 0x00025188 File Offset: 0x00023388
		internal void UpdateUiForIterationTillTime()
		{
			this.mRunningIterations.Visibility = Visibility.Collapsed;
			this.mTimerDisplay.Visibility = Visibility.Visible;
			this.mRunningScript.ToolTip = string.Format(CultureInfo.InvariantCulture, "{0}-{1}sec", new object[]
			{
				this.mOperationsRecord.Name,
				this.mOperationsRecord.LoopTime
			});
		}

		// Token: 0x0600063A RID: 1594 RVA: 0x000251F0 File Offset: 0x000233F0
		internal void UpdateUiMacroPlaybackForInfiniteTime(int iteration)
		{
			this.mTimerDisplay.Visibility = Visibility.Collapsed;
			this.mRunningIterations.Visibility = Visibility.Visible;
			this.mRunningIterations.Text = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_RUNNING_X_TIME"), new object[]
			{
				Strings.AddOrdinal(iteration)
			});
			this.mRunningScript.ToolTip = string.Format(CultureInfo.InvariantCulture, "{0}", new object[]
			{
				this.mOperationsRecord.Name
			});
		}

		// Token: 0x0600063B RID: 1595 RVA: 0x00025274 File Offset: 0x00023474
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/macrotopbarplaycontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600063C RID: 1596 RVA: 0x000252A4 File Offset: 0x000234A4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				this.RecordingImage = (CustomPictureBox)target;
				return;
			case 3:
				this.mDescriptionPanel = (StackPanel)target;
				return;
			case 4:
				this.mRunningScript = (TextBlock)target;
				return;
			case 5:
				this.mRunningIterations = (TextBlock)target;
				return;
			case 6:
				this.mTimerDisplay = (TextBlock)target;
				return;
			case 7:
				this.StopMacroImg = (CustomPictureBox)target;
				this.StopMacroImg.PreviewMouseLeftButtonUp += this.StopMacro_PreviewMouseLeftButtonUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000360 RID: 864
		private MainWindow ParentWindow;

		// Token: 0x04000361 RID: 865
		internal MacroRecording mOperationsRecord;

		// Token: 0x04000362 RID: 866
		private DispatcherTimer mBlinkPlayingIconTimer;

		// Token: 0x04000363 RID: 867
		private DispatcherTimer mTimer;

		// Token: 0x04000365 RID: 869
		private bool mShowPlayingIcon = true;

		// Token: 0x04000368 RID: 872
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder;

		// Token: 0x04000369 RID: 873
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox RecordingImage;

		// Token: 0x0400036A RID: 874
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mDescriptionPanel;

		// Token: 0x0400036B RID: 875
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mRunningScript;

		// Token: 0x0400036C RID: 876
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mRunningIterations;

		// Token: 0x0400036D RID: 877
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mTimerDisplay;

		// Token: 0x0400036E RID: 878
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox StopMacroImg;

		// Token: 0x0400036F RID: 879
		private bool _contentLoaded;

		// Token: 0x020000A1 RID: 161
		// (Invoke) Token: 0x0600063E RID: 1598
		internal delegate void ScriptPlayDelegate(string tag);

		// Token: 0x020000A2 RID: 162
		// (Invoke) Token: 0x06000642 RID: 1602
		internal delegate void ScriptStopDelegate(string tag);
	}
}
