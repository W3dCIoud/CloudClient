﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000BD RID: 189
	public class SidebarElement : UserControl, IComponentConnector
	{
		// Token: 0x170001C1 RID: 449
		// (get) Token: 0x060007C3 RID: 1987 RVA: 0x00006FB4 File Offset: 0x000051B4
		public CustomPictureBox Image
		{
			get
			{
				return this.mImage;
			}
		}

		// Token: 0x170001C2 RID: 450
		// (get) Token: 0x060007C4 RID: 1988 RVA: 0x00006FBC File Offset: 0x000051BC
		// (set) Token: 0x060007C5 RID: 1989 RVA: 0x00006FC4 File Offset: 0x000051C4
		public bool IsLastElementOfGroup { get; set; }

		// Token: 0x170001C3 RID: 451
		// (get) Token: 0x060007C6 RID: 1990 RVA: 0x00006FCD File Offset: 0x000051CD
		// (set) Token: 0x060007C7 RID: 1991 RVA: 0x00006FD5 File Offset: 0x000051D5
		public bool IsCurrentLastElementOfGroup { get; set; }

		// Token: 0x170001C4 RID: 452
		// (get) Token: 0x060007C8 RID: 1992 RVA: 0x00006FDE File Offset: 0x000051DE
		// (set) Token: 0x060007C9 RID: 1993 RVA: 0x00006FE6 File Offset: 0x000051E6
		public bool IsInMainSidebar { get; set; } = true;

		// Token: 0x170001C5 RID: 453
		// (get) Token: 0x060007CA RID: 1994 RVA: 0x00006FEF File Offset: 0x000051EF
		// (set) Token: 0x060007CB RID: 1995 RVA: 0x00006FF7 File Offset: 0x000051F7
		public string mSidebarElementTooltipKey { get; set; } = string.Empty;

		// Token: 0x060007CC RID: 1996 RVA: 0x00007000 File Offset: 0x00005200
		public SidebarElement()
		{
			this.InitializeComponent();
		}

		// Token: 0x060007CD RID: 1997 RVA: 0x00007020 File Offset: 0x00005220
		private void SidebarElement_Loaded(object sender, RoutedEventArgs e)
		{
			this.SetColor(false);
		}

		// Token: 0x060007CE RID: 1998 RVA: 0x00007029 File Offset: 0x00005229
		private void MImage_Loaded(object sender, RoutedEventArgs e)
		{
			this.mImage = (sender as CustomPictureBox);
		}

		// Token: 0x060007CF RID: 1999 RVA: 0x0002E644 File Offset: 0x0002C844
		private void SetColor(bool isPressed = false)
		{
			if (isPressed)
			{
				BlueStacksUIBinding.BindColor(this.mBorder, Control.BorderBrushProperty, "SidebarElementClick");
				BlueStacksUIBinding.BindColor(this.mBorder, Control.BackgroundProperty, "SidebarElementClick");
				BlueStacksUIBinding.BindColor(this, Control.ForegroundProperty, "SidebarElementClick");
				return;
			}
			if (base.IsMouseOver)
			{
				BlueStacksUIBinding.BindColor(this.mBorder, Control.BorderBrushProperty, "SidebarElementHover");
				BlueStacksUIBinding.BindColor(this.mBorder, Control.BackgroundProperty, "SidebarElementHover");
				BlueStacksUIBinding.BindColor(this, Control.ForegroundProperty, "SidebarElementHover");
				return;
			}
			BlueStacksUIBinding.BindColor(this.mBorder, Control.BorderBrushProperty, "SidebarElementNormal");
			BlueStacksUIBinding.BindColor(this.mBorder, Control.BackgroundProperty, "SidebarElementNormal");
			BlueStacksUIBinding.BindColor(this, Control.ForegroundProperty, "SidebarElementNormal");
		}

		// Token: 0x060007D0 RID: 2000 RVA: 0x00007020 File Offset: 0x00005220
		private void SidebarElement_MouseEnter(object sender, MouseEventArgs e)
		{
			this.SetColor(false);
		}

		// Token: 0x060007D1 RID: 2001 RVA: 0x00007020 File Offset: 0x00005220
		private void SidebarElement_MouseLeave(object sender, MouseEventArgs e)
		{
			this.SetColor(false);
		}

		// Token: 0x060007D2 RID: 2002 RVA: 0x00007037 File Offset: 0x00005237
		private void SidebarElement_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			this.SetColor(true);
		}

		// Token: 0x060007D3 RID: 2003 RVA: 0x00007040 File Offset: 0x00005240
		private void SidebarElement_IsEnabledChanged(object _, DependencyPropertyChangedEventArgs e)
		{
			if ((bool)e.NewValue)
			{
				base.Opacity = 1.0;
				return;
			}
			base.Opacity = 0.5;
		}

		// Token: 0x060007D4 RID: 2004 RVA: 0x00007020 File Offset: 0x00005220
		private void SidebarElement_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			this.SetColor(false);
		}

		// Token: 0x060007D5 RID: 2005 RVA: 0x0002E70C File Offset: 0x0002C90C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/sidebarelement.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060007D6 RID: 2006 RVA: 0x0002E73C File Offset: 0x0002C93C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mSidebarElement = (SidebarElement)target;
				this.mSidebarElement.MouseEnter += this.SidebarElement_MouseEnter;
				this.mSidebarElement.MouseLeave += this.SidebarElement_MouseLeave;
				this.mSidebarElement.PreviewMouseDown += this.SidebarElement_PreviewMouseDown;
				this.mSidebarElement.PreviewMouseUp += this.SidebarElement_PreviewMouseUp;
				this.mSidebarElement.Loaded += this.SidebarElement_Loaded;
				this.mSidebarElement.IsEnabledChanged += this.SidebarElement_IsEnabledChanged;
				return;
			case 2:
				this.mBorder = (Border)target;
				return;
			case 3:
				this.mGrid = (Grid)target;
				return;
			case 4:
				this.mImage = (CustomPictureBox)target;
				this.mImage.Loaded += this.MImage_Loaded;
				return;
			case 5:
				this.mElementNotification = (Ellipse)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400049B RID: 1179
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal SidebarElement mSidebarElement;

		// Token: 0x0400049C RID: 1180
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mBorder;

		// Token: 0x0400049D RID: 1181
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mGrid;

		// Token: 0x0400049E RID: 1182
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mImage;

		// Token: 0x0400049F RID: 1183
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Ellipse mElementNotification;

		// Token: 0x040004A0 RID: 1184
		private bool _contentLoaded;
	}
}
