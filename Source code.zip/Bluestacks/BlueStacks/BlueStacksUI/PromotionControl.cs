﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200017E RID: 382
	public class PromotionControl : System.Windows.Controls.UserControl, IDisposable, IComponentConnector
	{
		// Token: 0x1700026A RID: 618
		// (get) Token: 0x06000EF2 RID: 3826 RVA: 0x0000AE47 File Offset: 0x00009047
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x06000EF3 RID: 3827 RVA: 0x000604B8 File Offset: 0x0005E6B8
		public PromotionControl()
		{
			this.InitializeComponent();
			this.PromoControl = this;
			if (!DesignerProperties.GetIsInDesignMode(this.PromoControl))
			{
				if (!string.IsNullOrEmpty(RegistryManager.Instance.PromotionId) || FeatureManager.Instance.IsPromotionFixed)
				{
					this.mPromotionImage.ImageName = Path.Combine(RegistryManager.Instance.ClientInstallDir, "Promotions/promotion.jpg");
					this.mPromotionImageGrid.Background = new SolidColorBrush(Color.FromArgb(byte.MaxValue, 0, 0, 0));
				}
				if (RegistryManager.Instance.NoOfBootCompleted > 0)
				{
					BlueStacksUIBinding.Bind(this.BootText, "STRING_BOOT_TIME", "");
				}
				else
				{
					BlueStacksUIBinding.Bind(this.BootText, "STRING_FIRST_BOOT", "");
				}
				int num = RegistryManager.Instance.LastBootTime / 400;
				if (num <= 0)
				{
					RegistryManager.Instance.LastBootTime = 120000;
					RegistryManager.Instance.NoOfBootCompleted = 0;
					num = 1000;
				}
				this.progressTimer.Tick += this.ProgressTimer_Tick;
				this.progressTimer.Interval = num;
				this.progressTimer.Start();
				if (PromotionObject.Instance == null)
				{
					PromotionObject.LoadDataFromFile();
				}
				PromotionObject.BootPromotionHandler = (EventHandler)Delegate.Combine(PromotionObject.BootPromotionHandler, new EventHandler(this.PromotionControl_BootPromotionHandler));
			}
		}

		// Token: 0x06000EF4 RID: 3828 RVA: 0x0000AE68 File Offset: 0x00009068
		private void PromotionControl_BootPromotionHandler(object sender, EventArgs e)
		{
			this.PromoControl.Dispatcher.Invoke(new Action(delegate()
			{
				Fraction frac = new Fraction((long)RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GuestWidth, (long)RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GuestHeight);
				if (App.defaultResolution == frac && (!this.dictRunningPromotions.Keys.All(new Func<string, bool>(PromotionObject.Instance.DictBootPromotions.Keys.Contains<string>)) || PromotionObject.Instance.DictBootPromotions.Count != this.dictRunningPromotions.Count))
				{
					this.StopSlider();
					this.StartAnimation(PromotionObject.Instance.DictBootPromotions);
				}
			}), new object[0]);
		}

		// Token: 0x06000EF5 RID: 3829 RVA: 0x0006064C File Offset: 0x0005E84C
		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			Fraction frac = new Fraction((long)RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GuestWidth, (long)RegistryManager.Instance.Guest[this.ParentWindow.mVmName].GuestHeight);
			if (App.defaultResolution != frac)
			{
				this.StartAnimation(new SerializableDictionary<string, BootPromotion>());
				return;
			}
			this.StartAnimation(PromotionObject.Instance.DictBootPromotions);
		}

		// Token: 0x06000EF6 RID: 3830 RVA: 0x000606C8 File Offset: 0x0005E8C8
		private void StartAnimation(SerializableDictionary<string, BootPromotion> dict)
		{
			this.PromoControl.Dispatcher.Invoke(new Action(delegate()
			{
				this.dictRunningPromotions = dict.DeepCopy<SerializableDictionary<string, BootPromotion>>();
				if (dict.Count > 0)
				{
					List<KeyValuePair<string, BootPromotion>> myList = dict.ToList<KeyValuePair<string, BootPromotion>>();
					myList.Sort((KeyValuePair<string, BootPromotion> pair1, KeyValuePair<string, BootPromotion> pair2) => pair1.Value.Order.CompareTo(pair2.Value.Order));
					this.mPromotionImageGrid.Background = new SolidColorBrush(Color.FromArgb(byte.MaxValue, 0, 0, 0));
					this.mRunPromotion = true;
					this.mSliderAnimationThread = new Thread(delegate()
					{
						this.mThreadId = this.mSliderAnimationThread.ManagedThreadId;
						while (this.mRunPromotion && this.mThreadId == Thread.CurrentThread.ManagedThreadId)
						{
							try
							{
								using (List<KeyValuePair<string, BootPromotion>>.Enumerator enumerator = myList.GetEnumerator())
								{
									while (enumerator.MoveNext())
									{
										KeyValuePair<string, BootPromotion> item = enumerator.Current;
										if (!this.mRunPromotion || this.mThreadId != Thread.CurrentThread.ManagedThreadId)
										{
											break;
										}
										if (this.currentBootPromotion == null)
										{
											this.currentBootPromotion = item.Value;
										}
										this.PromoControl.Dispatcher.Invoke(new Action(delegate()
										{
											this.HandleAnimation(item.Value);
											this.currentBootPromotion = item.Value;
											this.SetLoadingText(item.Value.ButtonText);
										}), new object[0]);
										this.mBootPromotionImageTimeout = PromotionObject.Instance.BootPromoDisplaytime;
										Thread.Sleep(this.mBootPromotionImageTimeout);
									}
								}
							}
							catch (Exception ex)
							{
								Logger.Error(ex.ToString());
							}
						}
					})
					{
						IsBackground = true
					};
					this.mSliderAnimationThread.Start();
				}
			}), new object[0]);
		}

		// Token: 0x06000EF7 RID: 3831 RVA: 0x0006070C File Offset: 0x0005E90C
		private void ProgressTimer_Tick(object sender, EventArgs e)
		{
			try
			{
				MainWindow parentWindow = this.ParentWindow;
				bool flag;
				if (parentWindow == null)
				{
					flag = (null != null);
				}
				else
				{
					WelcomeTab mWelcomeTab = parentWindow.mWelcomeTab;
					flag = (((mWelcomeTab != null) ? mWelcomeTab.mHomeApp : null) != null);
				}
				if (flag && !this.ParentWindow.mWelcomeTab.mHomeApp.SideHtmlBrowserInited)
				{
					this.ParentWindow.mWelcomeTab.mHomeApp.InitiateSideHtmlBrowser();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while creating HTML sidepanel .Exception: " + ex.ToString());
			}
			if (this.mProgress >= 99.0 && !this.mForceComplete)
			{
				this.mProgressBar.Value = this.mProgress;
				this.mProgress += 0.0;
				return;
			}
			if (this.mProgress >= 95.0 && !this.mForceComplete)
			{
				this.progressTimer.Interval = this.progressTimer.Interval;
				this.mProgressBar.Value = this.mProgress;
				this.mProgress += 0.025;
				return;
			}
			this.mProgressBar.Value = this.mProgress;
			this.mProgress += 0.25;
		}

		// Token: 0x06000EF8 RID: 3832 RVA: 0x00060850 File Offset: 0x0005EA50
		private void mPromoButton_Click(object sender, RoutedEventArgs e)
		{
			this.StopSlider();
			ClientStats.SendMiscellaneousStatsAsync("BootPromotion", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, JsonConvert.SerializeObject(this.currentBootPromotion.ExtraPayload), null, null, null, null, null);
			GenericAction genericAction = GenericAction.None;
			if (this.currentBootPromotion.ExtraPayload.ContainsKey("click_generic_action"))
			{
				genericAction = EnumHelper.Parse<GenericAction>(this.currentBootPromotion.ExtraPayload["click_generic_action"], GenericAction.None);
			}
			if (genericAction <= GenericAction.UserBrowser)
			{
				if (genericAction - GenericAction.InstallPlay <= 1)
				{
					goto IL_B6;
				}
				if (genericAction != GenericAction.ApplicationBrowser && genericAction != GenericAction.UserBrowser)
				{
					goto IL_B6;
				}
			}
			else if (genericAction <= GenericAction.SettingsMenu)
			{
				if (genericAction != GenericAction.HomeAppTab && genericAction != GenericAction.SettingsMenu)
				{
					goto IL_B6;
				}
			}
			else
			{
				if (genericAction != GenericAction.KeyBasedPopup && genericAction != GenericAction.OpenSystemApp)
				{
					goto IL_B6;
				}
				goto IL_B6;
			}
			this.isPerformActionOnClose = false;
			goto IL_BD;
			IL_B6:
			this.isPerformActionOnClose = true;
			IL_BD:
			if (this.isPerformActionOnClose)
			{
				this.mPromotionInfoBorder.Visibility = Visibility.Visible;
				this.mPromoButton.Visibility = Visibility.Hidden;
				this.mPromoInfoText.Text = this.currentBootPromotion.PromoBtnClickStatusText.ToString(CultureInfo.InvariantCulture);
				if (string.Equals(this.currentBootPromotion.ThemeEnabled, "true", StringComparison.InvariantCultureIgnoreCase))
				{
					this.ParentWindow.Utils.ApplyTheme(this.currentBootPromotion.ThemeName);
				}
				return;
			}
			this.mExtraPayloadClicked = this.currentBootPromotion.ExtraPayload;
			this.ParentWindow.Utils.HandleGenericActionFromDictionary(this.currentBootPromotion.ExtraPayload, "boot_promo", "");
		}

		// Token: 0x06000EF9 RID: 3833 RVA: 0x000609C4 File Offset: 0x0005EBC4
		private void StopSlider()
		{
			try
			{
				this.mRunPromotion = false;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception aborting thread" + ex.ToString());
			}
		}

		// Token: 0x06000EFA RID: 3834 RVA: 0x00060A04 File Offset: 0x0005EC04
		private void SetLoadingText(string text)
		{
			if (!string.IsNullOrEmpty(text))
			{
				this.mPromoButton.Content = text;
				this.mPromoButton.Visibility = Visibility.Visible;
			}
			else
			{
				this.mPromoButton.Visibility = Visibility.Hidden;
			}
			this.isPerformActionOnClose = false;
			this.mPromotionInfoBorder.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000EFB RID: 3835 RVA: 0x0000AE8D File Offset: 0x0000908D
		internal void Stop()
		{
			this.progressTimer.Stop();
			this.progressTimer.Dispose();
			this.StopSlider();
		}

		// Token: 0x06000EFC RID: 3836 RVA: 0x0000AEAB File Offset: 0x000090AB
		internal void HandlePromotionEventAfterBoot()
		{
			if (this.isPerformActionOnClose)
			{
				this.ParentWindow.Utils.HandleGenericActionFromDictionary(this.currentBootPromotion.ExtraPayload, "boot_promo", "");
				this.isPerformActionOnClose = false;
			}
		}

		// Token: 0x06000EFD RID: 3837 RVA: 0x0000AEE1 File Offset: 0x000090E1
		private void HandleAnimation(BootPromotion promo)
		{
			PromotionControl.AnimateImage(this.mPromotionImage, promo.ImagePath);
			if (!string.IsNullOrEmpty(promo.ButtonText))
			{
				this.mPromoButton.Visibility = Visibility.Visible;
				this.mPromoButton.Content = promo.ButtonText;
			}
		}

		// Token: 0x06000EFE RID: 3838 RVA: 0x00060A54 File Offset: 0x0005EC54
		private static void AnimateImage(CustomPictureBox image, string imagePath)
		{
			TimeSpan timeSpan = TimeSpan.FromSeconds(0.6);
			TimeSpan timeSpan2 = TimeSpan.FromSeconds(0.6);
			DoubleAnimation fadeInAnimation = new DoubleAnimation(1.0, timeSpan);
			if (image.Source == null)
			{
				image.Opacity = 1.0;
				image.IsFullImagePath = true;
				image.ImageName = imagePath;
				return;
			}
			if (image.ImageName != imagePath)
			{
				DoubleAnimation doubleAnimation = new DoubleAnimation(0.0, timeSpan2);
				doubleAnimation.Completed += delegate(object o, EventArgs e)
				{
					image.IsFullImagePath = true;
					image.ImageName = imagePath;
					image.BeginAnimation(UIElement.OpacityProperty, fadeInAnimation);
				};
				image.BeginAnimation(UIElement.OpacityProperty, doubleAnimation);
			}
		}

		// Token: 0x06000EFF RID: 3839 RVA: 0x0000AF1E File Offset: 0x0000911E
		private void CloseButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mPromotionInfoBorder.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000F00 RID: 3840 RVA: 0x0000AF2C File Offset: 0x0000912C
		protected virtual void Dispose(bool disposing)
		{
			if (!this.disposedValue)
			{
				if (this.progressTimer != null)
				{
					this.progressTimer.Tick -= this.ProgressTimer_Tick;
					this.progressTimer.Dispose();
				}
				this.disposedValue = true;
			}
		}

		// Token: 0x06000F01 RID: 3841 RVA: 0x00060B3C File Offset: 0x0005ED3C
		~PromotionControl()
		{
			this.Dispose(false);
		}

		// Token: 0x06000F02 RID: 3842 RVA: 0x0000AF69 File Offset: 0x00009169
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x06000F03 RID: 3843 RVA: 0x00060B6C File Offset: 0x0005ED6C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/promotioncontrol.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000F04 RID: 3844 RVA: 0x00060B9C File Offset: 0x0005ED9C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((PromotionControl)target).Loaded += this.UserControl_Loaded;
				return;
			case 2:
				this.mPromotionImageGrid = (Grid)target;
				return;
			case 3:
				this.mPromotionImage = (CustomPictureBox)target;
				return;
			case 4:
				this.mPromoButton = (CustomButton)target;
				this.mPromoButton.Click += this.mPromoButton_Click;
				return;
			case 5:
				this.mPromotionInfoBorder = (Border)target;
				return;
			case 6:
				this.mPromoInfoText = (TextBlock)target;
				return;
			case 7:
				this.mCloseButton = (CustomPictureBox)target;
				this.mCloseButton.PreviewMouseLeftButtonUp += this.CloseButton_PreviewMouseLeftButtonUp;
				return;
			case 8:
				this.mProgressBar = (BlueProgressBar)target;
				return;
			case 9:
				this.BootText = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040009FA RID: 2554
		private bool isPerformActionOnClose;

		// Token: 0x040009FB RID: 2555
		private bool mRunPromotion = true;

		// Token: 0x040009FC RID: 2556
		private double mProgress = 0.1;

		// Token: 0x040009FD RID: 2557
		private System.Windows.Forms.Timer progressTimer = new System.Windows.Forms.Timer();

		// Token: 0x040009FE RID: 2558
		private bool mForceComplete;

		// Token: 0x040009FF RID: 2559
		internal string mActionValue;

		// Token: 0x04000A00 RID: 2560
		internal string mTextOnActionBtn;

		// Token: 0x04000A01 RID: 2561
		internal bool mIsActionButtonToShow;

		// Token: 0x04000A02 RID: 2562
		internal PromotionControl PromoControl;

		// Token: 0x04000A03 RID: 2563
		private int mBootPromotionImageTimeout = 4000;

		// Token: 0x04000A04 RID: 2564
		internal BootPromotion currentBootPromotion;

		// Token: 0x04000A05 RID: 2565
		private Thread mSliderAnimationThread;

		// Token: 0x04000A06 RID: 2566
		private int mThreadId;

		// Token: 0x04000A07 RID: 2567
		private SerializableDictionary<string, BootPromotion> dictRunningPromotions = new SerializableDictionary<string, BootPromotion>();

		// Token: 0x04000A08 RID: 2568
		private MainWindow mMainWindow;

		// Token: 0x04000A09 RID: 2569
		internal SerializableDictionary<string, string> mExtraPayloadClicked = new SerializableDictionary<string, string>();

		// Token: 0x04000A0A RID: 2570
		private bool disposedValue;

		// Token: 0x04000A0B RID: 2571
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mPromotionImageGrid;

		// Token: 0x04000A0C RID: 2572
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mPromotionImage;

		// Token: 0x04000A0D RID: 2573
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mPromoButton;

		// Token: 0x04000A0E RID: 2574
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mPromotionInfoBorder;

		// Token: 0x04000A0F RID: 2575
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mPromoInfoText;

		// Token: 0x04000A10 RID: 2576
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCloseButton;

		// Token: 0x04000A11 RID: 2577
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal BlueProgressBar mProgressBar;

		// Token: 0x04000A12 RID: 2578
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock BootText;

		// Token: 0x04000A13 RID: 2579
		private bool _contentLoaded;
	}
}
