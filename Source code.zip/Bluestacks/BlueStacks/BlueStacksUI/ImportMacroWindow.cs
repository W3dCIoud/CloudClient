﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000096 RID: 150
	public class ImportMacroWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x060005D7 RID: 1495 RVA: 0x0002289C File Offset: 0x00020A9C
		public ImportMacroWindow(MacroRecorderWindow window, MainWindow mainWindow)
		{
			this.InitializeComponent();
			this.mOperationWindow = window;
			this.ParentWindow = mainWindow;
			this.mScriptsStackPanel = (this.mScriptsListScrollbar.Content as StackPanel);
		}

		// Token: 0x060005D8 RID: 1496 RVA: 0x000228F0 File Offset: 0x00020AF0
		internal void TextChanged(object sender, TextChangedEventArgs e)
		{
			if (this.mInited)
			{
				ImportMacroScriptsControl scriptControlFromMacroItemGrandchild = this.GetScriptControlFromMacroItemGrandchild((sender as FrameworkElement).Parent);
				string text = (sender as CustomTextBox).Text;
				foreach (object obj in scriptControlFromMacroItemGrandchild.mDependentScriptsPanel.Children)
				{
					CustomTextBox customTextBox = ((UIElement)obj) as CustomTextBox;
					customTextBox.Text = MacroRecorderWindow.GetDependentRecordingName(text, this.mDependentRecordingDict[customTextBox].Name);
				}
			}
		}

		// Token: 0x060005D9 RID: 1497 RVA: 0x00005D2B File Offset: 0x00003F2B
		private void ImportMacroWindow_Closing(object sender, CancelEventArgs e)
		{
			this.CloseWindow();
		}

		// Token: 0x060005DA RID: 1498 RVA: 0x00004956 File Offset: 0x00002B56
		private void Close_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			base.Close();
		}

		// Token: 0x060005DB RID: 1499 RVA: 0x00005D33 File Offset: 0x00003F33
		private void CloseWindow()
		{
			this.mOperationWindow.mImportMacroWindow = null;
			this.mOperationWindow.mOverlayGrid.Visibility = Visibility.Hidden;
			this.mOperationWindow.Focus();
		}

		// Token: 0x060005DC RID: 1500 RVA: 0x00022990 File Offset: 0x00020B90
		private ImportMacroScriptsControl AddRecordingToStackPanelAndDict(MacroRecording record, bool isSingleRecording, out string suggestedName)
		{
			ImportMacroScriptsControl importMacroScriptsControl = new ImportMacroScriptsControl(this, this.ParentWindow);
			importMacroScriptsControl.Init(record.Name, isSingleRecording);
			suggestedName = ((!(from MacroRecording macro in MacroGraph.Instance.Vertices
			select macro.Name.ToLower(CultureInfo.InvariantCulture)).Contains(record.Name.ToLower(CultureInfo.InvariantCulture).Trim())) ? record.Name : CommonHandlers.GetMacroName(record.Name));
			importMacroScriptsControl.mImportName.Text = this.ValidateSuggestedName(suggestedName);
			this.mScriptsStackPanel.Children.Add(importMacroScriptsControl);
			this.mBoxToRecordingDict[importMacroScriptsControl] = record;
			return importMacroScriptsControl;
		}

		// Token: 0x060005DD RID: 1501 RVA: 0x00022A50 File Offset: 0x00020C50
		internal void Init()
		{
			bool flag = this.ParentWindow.MacroRecorderWindow.mRenamingMacrosList.Count == 1;
			try
			{
				this.mInited = false;
				this.mScriptsStackPanel.Children.Clear();
				foreach (MacroRecording macroRecording in this.ParentWindow.MacroRecorderWindow.mRenamingMacrosList)
				{
					string originalMacroName;
					ImportMacroScriptsControl importMacroScriptsControl = this.AddRecordingToStackPanelAndDict(macroRecording, flag, out originalMacroName);
					if (macroRecording.RecordingType == RecordingTypes.MultiRecording)
					{
						bool flag2 = false;
						bool? mImportMultiMacroAsUnified = this.mOperationWindow.mImportMultiMacroAsUnified;
						if (flag2 == mImportMultiMacroAsUnified.GetValueOrDefault() & mImportMultiMacroAsUnified != null)
						{
							importMacroScriptsControl.mDependentScriptsMsg.Visibility = Visibility.Visible;
							importMacroScriptsControl.mDependentScriptsPanel.Visibility = Visibility.Visible;
							importMacroScriptsControl.mDependentScriptsPanel.Children.Clear();
							foreach (string value in macroRecording.SourceRecordings)
							{
								MacroRecording macroRecording2 = JsonConvert.DeserializeObject<MacroRecording>(value, Utils.GetSerializerSettings());
								string dependentRecordingName = MacroRecorderWindow.GetDependentRecordingName(originalMacroName, macroRecording2.Name);
								string suggestedName = (!(from MacroRecording macro in MacroGraph.Instance.Vertices
								select macro.Name).Contains(dependentRecordingName.ToLower(CultureInfo.InvariantCulture).Trim())) ? dependentRecordingName : CommonHandlers.GetMacroName(dependentRecordingName);
								CustomTextBox customTextBox = new CustomTextBox
								{
									Height = 24.0,
									HorizontalAlignment = HorizontalAlignment.Left,
									Margin = new Thickness(0.0, 5.0, 0.0, 0.0),
									Text = this.ValidateSuggestedName(suggestedName),
									Visibility = Visibility.Visible,
									IsEnabled = false
								};
								importMacroScriptsControl.mDependentScriptsPanel.Children.Add(customTextBox);
								this.mDependentRecordingDict[customTextBox] = macroRecording2;
							}
						}
					}
				}
				this.mNumberOfFilesSelectedForImport = 0;
			}
			catch (Exception ex)
			{
				Logger.Error("Error in import window init err: " + ex.ToString());
			}
			this.mInited = true;
			if (flag)
			{
				this.mSelectAllBtn.Visibility = Visibility.Hidden;
			}
			this.mSelectAllBtn.IsChecked = new bool?(true);
			this.SelectAllBtn_Click(null, null);
		}

		// Token: 0x060005DE RID: 1502 RVA: 0x00022D00 File Offset: 0x00020F00
		private string ValidateSuggestedName(string suggestedName)
		{
			if (this.mBoxToRecordingDict.Keys.Any((ImportMacroScriptsControl box) => string.Equals(box.mImportName.Text.Trim(), suggestedName, StringComparison.InvariantCultureIgnoreCase)))
			{
				int num = suggestedName.LastIndexOf('(') + 1;
				int num2 = suggestedName.LastIndexOf(')');
				int num3;
				if (int.TryParse(suggestedName.Substring(num, num2 - num), out num3))
				{
					suggestedName = suggestedName.Remove(num, num2 - num).Insert(num, (num3 + 1).ToString(CultureInfo.InvariantCulture));
					return this.ValidateSuggestedName(suggestedName);
				}
				Logger.Error("Error in ValidateSuggestedName: Could not get integer part in suggested name '{0}'", new object[]
				{
					suggestedName
				});
			}
			return suggestedName;
		}

		// Token: 0x060005DF RID: 1503 RVA: 0x00022DCC File Offset: 0x00020FCC
		private bool CheckIfEditedMacroNameIsAllowed(string text, ImportMacroScriptsControl item)
		{
			if (string.IsNullOrEmpty(text.Trim()))
			{
				BlueStacksUIBinding.Bind(item.mWarningMsg, LocaleStrings.GetLocalizedString("STRING_MACRO_NAME_NULL_MESSAGE"), "");
				return false;
			}
			using (IEnumerator<BiDirectionalVertex<MacroRecording>> enumerator = MacroGraph.Instance.Vertices.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (((MacroRecording)enumerator.Current).Name.ToLower(CultureInfo.InvariantCulture).Trim() == text.ToLower(CultureInfo.InvariantCulture).Trim())
					{
						return false;
					}
				}
			}
			foreach (object obj in this.mScriptsStackPanel.Children)
			{
				ImportMacroScriptsControl importMacroScriptsControl = (ImportMacroScriptsControl)obj;
				if (item != importMacroScriptsControl)
				{
					bool? isChecked = importMacroScriptsControl.mContent.IsChecked;
					bool flag = true;
					if ((isChecked.GetValueOrDefault() == flag & isChecked != null) && importMacroScriptsControl.IsScriptInRenameMode() && importMacroScriptsControl.mImportName.Text.ToLower(CultureInfo.InvariantCulture).Trim() == text.ToLower(CultureInfo.InvariantCulture).Trim())
					{
						return false;
					}
				}
			}
			return true;
		}

		// Token: 0x060005E0 RID: 1504 RVA: 0x00005D5E File Offset: 0x00003F5E
		private bool IsMacroItemDependentOfParent(ImportMacroScriptsControl item, string name)
		{
			return item.Tag != null && item.Tag.ToString().Equals(name, StringComparison.InvariantCultureIgnoreCase);
		}

		// Token: 0x060005E1 RID: 1505 RVA: 0x00022F28 File Offset: 0x00021128
		private ImportMacroScriptsControl GetScriptControlFromMacroItemGrandchild(object grandchild)
		{
			while (grandchild != null)
			{
				DependencyObject parent = (grandchild as FrameworkElement).Parent;
				if (parent != null && parent is ImportMacroScriptsControl)
				{
					return parent as ImportMacroScriptsControl;
				}
				grandchild = parent;
			}
			return null;
		}

		// Token: 0x060005E2 RID: 1506 RVA: 0x00022F5C File Offset: 0x0002115C
		internal void Box_Unchecked(object sender, RoutedEventArgs e)
		{
			if (!this.mIsInDependentFileFindingMode)
			{
				this.mIsInDependentFileFindingMode = true;
				this.mNumberOfFilesSelectedForImport--;
				if (this.mNumberOfFilesSelectedForImport == 0)
				{
					this.mImportBtn.IsEnabled = false;
				}
				if (this.mNumberOfFilesSelectedForImport < this.mScriptsStackPanel.Children.Count)
				{
					this.mSelectAllBtn.IsChecked = new bool?(false);
				}
				this.mIsInDependentFileFindingMode = false;
			}
		}

		// Token: 0x060005E3 RID: 1507 RVA: 0x00022FCC File Offset: 0x000211CC
		internal void Box_Checked(object sender, RoutedEventArgs e)
		{
			if (!this.mIsInDependentFileFindingMode)
			{
				this.mIsInDependentFileFindingMode = true;
				this.mNumberOfFilesSelectedForImport++;
				if (this.mNumberOfFilesSelectedForImport > 0)
				{
					this.mImportBtn.IsEnabled = true;
				}
				if (this.mNumberOfFilesSelectedForImport == this.mScriptsStackPanel.Children.Count)
				{
					this.mSelectAllBtn.IsChecked = new bool?(true);
				}
				this.mIsInDependentFileFindingMode = false;
			}
		}

		// Token: 0x060005E4 RID: 1508 RVA: 0x0002303C File Offset: 0x0002123C
		private static List<MacroEvents> GetRecordingEventsFromSourceRecording(MacroRecording srcRecording, double acceleration, long initialTime, ref long elapsedTime)
		{
			if (srcRecording == null)
			{
				throw new Exception("Source recording now found in multiMacro");
			}
			List<MacroEvents> result = new List<MacroEvents>();
			foreach (MacroEvents macroEvents in srcRecording.Events)
			{
				MacroEvents macroEvents2 = macroEvents;
				macroEvents2.Timestamp = (long)Math.Floor((double)macroEvents.Timestamp / acceleration);
				macroEvents2.Timestamp += initialTime;
				elapsedTime = macroEvents2.Timestamp;
			}
			return result;
		}

		// Token: 0x060005E5 RID: 1509 RVA: 0x000230CC File Offset: 0x000212CC
		private ImportMacroScriptsControl GetMacroItemFromTag(string tag)
		{
			foreach (object obj in this.mScriptsStackPanel.Children)
			{
				ImportMacroScriptsControl importMacroScriptsControl = (ImportMacroScriptsControl)obj;
				if (this.mBoxToRecordingDict[importMacroScriptsControl].Name == tag)
				{
					return importMacroScriptsControl;
				}
			}
			return null;
		}

		// Token: 0x060005E6 RID: 1510 RVA: 0x00023144 File Offset: 0x00021344
		private void ImportBtn_Click(object sender, RoutedEventArgs e)
		{
			int num = 0;
			bool flag = false;
			bool flag2 = true;
			List<MacroRecording> list = new List<MacroRecording>();
			foreach (object obj in this.mScriptsStackPanel.Children)
			{
				ImportMacroScriptsControl importMacroScriptsControl = (ImportMacroScriptsControl)obj;
				bool? isChecked = importMacroScriptsControl.mContent.IsChecked;
				bool flag3 = true;
				if (isChecked.GetValueOrDefault() == flag3 & isChecked != null)
				{
					if (importMacroScriptsControl.mImportName.Text.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
					{
						string path = string.Format(CultureInfo.InvariantCulture, "{0} {1} {2}", new object[]
						{
							LocaleStrings.GetLocalizedString("STRING_MACRO_NAME_ERROR"),
							Environment.NewLine,
							"\\ / : * ? \" < > |"
						});
						BlueStacksUIBinding.Bind(importMacroScriptsControl.mWarningMsg, path, "");
						importMacroScriptsControl.mImportName.InputTextValidity = TextValidityOptions.Error;
						if (importMacroScriptsControl.mImportName.IsEnabled)
						{
							importMacroScriptsControl.mWarningMsg.Visibility = Visibility.Visible;
						}
						flag2 = false;
					}
					else if (Constants.ReservedFileNamesList.Contains(importMacroScriptsControl.mImportName.Text.Trim().ToLower(CultureInfo.InvariantCulture)))
					{
						BlueStacksUIBinding.Bind(importMacroScriptsControl.mWarningMsg, "STRING_MACRO_FILE_NAME_ERROR", "");
						importMacroScriptsControl.mImportName.InputTextValidity = TextValidityOptions.Error;
						if (importMacroScriptsControl.mImportName.IsEnabled)
						{
							importMacroScriptsControl.mWarningMsg.Visibility = Visibility.Visible;
						}
						flag2 = false;
					}
					else if (!this.CheckIfEditedMacroNameIsAllowed(importMacroScriptsControl.mImportName.Text, importMacroScriptsControl) && importMacroScriptsControl.IsScriptInRenameMode())
					{
						if (!string.IsNullOrEmpty(importMacroScriptsControl.mImportName.Text.Trim()))
						{
							BlueStacksUIBinding.Bind(importMacroScriptsControl.mWarningMsg, LocaleStrings.GetLocalizedString("STRING_DUPLICATE_MACRO_NAME_WARNING"), "");
						}
						importMacroScriptsControl.mImportName.InputTextValidity = TextValidityOptions.Error;
						if (importMacroScriptsControl.mImportName.IsEnabled)
						{
							importMacroScriptsControl.mWarningMsg.Visibility = Visibility.Visible;
						}
						flag2 = false;
					}
					else if (importMacroScriptsControl.mDependentScriptsPanel.Visibility == Visibility.Visible && importMacroScriptsControl.mDependentScriptsPanel.Children.Count > 0)
					{
						string text = this.CheckIfDependentScriptsHaveInvalidName(importMacroScriptsControl);
						if (text != "TEXT_VALID")
						{
							BlueStacksUIBinding.Bind(importMacroScriptsControl.mWarningMsg, text, "");
							importMacroScriptsControl.mImportName.InputTextValidity = TextValidityOptions.Error;
							flag2 = false;
						}
						else
						{
							importMacroScriptsControl.mImportName.InputTextValidity = TextValidityOptions.Success;
							importMacroScriptsControl.mWarningMsg.Visibility = Visibility.Collapsed;
						}
					}
					else
					{
						importMacroScriptsControl.mImportName.InputTextValidity = TextValidityOptions.Success;
						importMacroScriptsControl.mWarningMsg.Visibility = Visibility.Collapsed;
					}
					flag = true;
				}
				num++;
			}
			if (!flag)
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_IMPORT_MACRO_SELECTED"), 4.0, true);
				return;
			}
			if (flag2)
			{
				if (!Directory.Exists(RegistryStrings.MacroRecordingsFolderPath))
				{
					Directory.CreateDirectory(RegistryStrings.MacroRecordingsFolderPath);
				}
				foreach (object obj2 in this.mScriptsStackPanel.Children)
				{
					ImportMacroScriptsControl importMacroScriptsControl2 = (ImportMacroScriptsControl)obj2;
					if (importMacroScriptsControl2.mContent.IsChecked.GetValueOrDefault())
					{
						MacroRecording macroRecording = this.mBoxToRecordingDict[importMacroScriptsControl2];
						string newScript = (importMacroScriptsControl2.mReplaceExistingBtn.IsChecked != null && importMacroScriptsControl2.mReplaceExistingBtn.IsChecked.Value) ? importMacroScriptsControl2.mContent.Content.ToString() : importMacroScriptsControl2.mImportName.Text.Trim();
						MacroRecording existingMacro = (from MacroRecording m in MacroGraph.Instance.Vertices
						where string.Equals(m.Name, newScript, StringComparison.InvariantCultureIgnoreCase)
						select m).FirstOrDefault<MacroRecording>();
						if (existingMacro != null)
						{
							if (existingMacro.Parents.Count > 0)
							{
								int index2;
								int index;
								for (index = existingMacro.Parents.Count - 1; index >= 0; index = index2 - 1)
								{
									MacroRecording macroRecording2 = (from MacroRecording macro in MacroGraph.Instance.Vertices
									where macro.Equals(existingMacro.Parents[index])
									select macro).FirstOrDefault<MacroRecording>();
									this.mOperationWindow.FlattenRecording(existingMacro.Parents[index] as MacroRecording, false);
									CommonHandlers.SaveMacroJson(existingMacro.Parents[index] as MacroRecording, (existingMacro.Parents[index] as MacroRecording).Name + ".json");
									foreach (object obj3 in this.mOperationWindow.mScriptsStackPanel.Children)
									{
										SingleMacroControl singleMacroControl = (SingleMacroControl)obj3;
										if (singleMacroControl.mRecording.Name.ToLower(CultureInfo.InvariantCulture).Trim() == macroRecording2.Name.ToLower(CultureInfo.InvariantCulture).Trim())
										{
											singleMacroControl.mScriptSettingsImg.ImageName = "macro_settings";
										}
									}
									MacroGraph.Instance.DeLinkMacroChild(existingMacro.Parents[index] as MacroRecording);
									index2 = index;
								}
							}
							this.DeleteMacroScript(existingMacro);
						}
						macroRecording.Name = newScript;
						if (macroRecording.RecordingType == RecordingTypes.MultiRecording)
						{
							this.mOperationWindow.ImportMultiMacro(macroRecording, this.mOperationWindow.mImportMultiMacroAsUnified.Value, list, this.GetDictionaryOfNewNamesForDependentRecordings(macroRecording.Name));
						}
						else
						{
							CommonHandlers.SaveMacroJson(macroRecording, macroRecording.Name.ToLower(CultureInfo.InvariantCulture).Trim() + ".json");
							MacroGraph.Instance.AddVertex(macroRecording);
							list.Add(macroRecording);
						}
					}
				}
				foreach (MacroRecording macro2 in list)
				{
					MacroGraph.LinkMacroChilds(macro2);
				}
				this.mOperationWindow.mNewlyAddedMacrosList.AddRange(list);
				this.ParentWindow.MacroRecorderWindow.mRenamingMacrosList.Clear();
				base.Close();
			}
		}

		// Token: 0x060005E7 RID: 1511 RVA: 0x00023858 File Offset: 0x00021A58
		private void DeleteMacroScript(MacroRecording mRecording)
		{
			string path = Path.Combine(RegistryStrings.MacroRecordingsFolderPath, mRecording.Name + ".json");
			if (File.Exists(path))
			{
				File.Delete(path);
			}
			if (mRecording.Shortcut != null && MainWindow.sMacroMapping.ContainsKey(mRecording.Shortcut))
			{
				MainWindow.sMacroMapping.Remove(mRecording.Shortcut);
			}
			ImportMacroWindow.DeleteScriptNameFromBookmarkedScriptListIfPresent(mRecording.Name);
			MacroRecording vertex = (from MacroRecording macro in MacroGraph.Instance.Vertices
			where string.Equals(macro.Name, mRecording.Name, StringComparison.InvariantCultureIgnoreCase)
			select macro).FirstOrDefault<MacroRecording>();
			MacroGraph.Instance.RemoveVertex(vertex);
			if (this.ParentWindow.mAutoRunMacro != null && this.ParentWindow.mAutoRunMacro.Name.ToLower(CultureInfo.InvariantCulture).Trim() == mRecording.Name.ToLower(CultureInfo.InvariantCulture).Trim())
			{
				this.ParentWindow.mAutoRunMacro = null;
			}
			CommonHandlers.OnMacroDeleted(mRecording.Name);
		}

		// Token: 0x060005E8 RID: 1512 RVA: 0x00023988 File Offset: 0x00021B88
		public static bool DeleteScriptNameFromBookmarkedScriptListIfPresent(string fileName)
		{
			if (RegistryManager.Instance.BookmarkedScriptList.Contains(fileName))
			{
				List<string> list = new List<string>(RegistryManager.Instance.BookmarkedScriptList);
				list.Remove(fileName);
				RegistryManager.Instance.BookmarkedScriptList = list.ToArray();
				return true;
			}
			return false;
		}

		// Token: 0x060005E9 RID: 1513 RVA: 0x000239D4 File Offset: 0x00021BD4
		private string CheckIfDependentScriptsHaveInvalidName(ImportMacroScriptsControl scriptControl)
		{
			string result = "TEXT_VALID";
			foreach (object obj in scriptControl.mDependentScriptsPanel.Children)
			{
				CustomTextBox customTextBox = ((UIElement)obj) as CustomTextBox;
				string text = customTextBox.Text;
				if (text.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
				{
					customTextBox.InputTextValidity = TextValidityOptions.Error;
					result = string.Format(CultureInfo.InvariantCulture, "{0} {1} {2}", new object[]
					{
						LocaleStrings.GetLocalizedString("STRING_MACRO_NAME_ERROR"),
						Environment.NewLine,
						"\\ / : * ? \" < > |"
					});
				}
				else if (Constants.ReservedFileNamesList.Contains(text.Trim().ToLower(CultureInfo.InvariantCulture)))
				{
					customTextBox.InputTextValidity = TextValidityOptions.Error;
					result = LocaleStrings.GetLocalizedString("STRING_MACRO_FILE_NAME_ERROR");
				}
				else if (scriptControl.IsScriptInRenameMode())
				{
					using (IEnumerator<BiDirectionalVertex<MacroRecording>> enumerator2 = MacroGraph.Instance.Vertices.GetEnumerator())
					{
						while (enumerator2.MoveNext())
						{
							if (((MacroRecording)enumerator2.Current).Name.ToLower(CultureInfo.InvariantCulture).Trim() == text.ToLower(CultureInfo.InvariantCulture).Trim())
							{
								customTextBox.InputTextValidity = TextValidityOptions.Error;
								return LocaleStrings.GetLocalizedString("STRING_DUPLICATE_MACRO_NAME_WARNING");
							}
						}
					}
					foreach (object obj2 in this.mScriptsStackPanel.Children)
					{
						ImportMacroScriptsControl importMacroScriptsControl = (ImportMacroScriptsControl)obj2;
						if (importMacroScriptsControl != scriptControl && scriptControl.IsScriptInRenameMode())
						{
							bool? isChecked = importMacroScriptsControl.mContent.IsChecked;
							bool flag = true;
							if (isChecked.GetValueOrDefault() == flag & isChecked != null)
							{
								if (importMacroScriptsControl.mImportName.Text.ToLower(CultureInfo.InvariantCulture).Trim() == text.ToLower(CultureInfo.InvariantCulture).Trim())
								{
									customTextBox.InputTextValidity = TextValidityOptions.Error;
									result = LocaleStrings.GetLocalizedString("STRING_DUPLICATE_MACRO_NAME_WARNING");
								}
								else
								{
									using (IEnumerator enumerator4 = importMacroScriptsControl.mDependentScriptsPanel.Children.GetEnumerator())
									{
										while (enumerator4.MoveNext())
										{
											if ((((UIElement)enumerator4.Current) as CustomTextBox).Text.ToLower(CultureInfo.InvariantCulture).Trim() == text.ToLower(CultureInfo.InvariantCulture).Trim())
											{
												customTextBox.InputTextValidity = TextValidityOptions.Error;
												result = LocaleStrings.GetLocalizedString("STRING_DUPLICATE_MACRO_NAME_WARNING");
												break;
											}
										}
									}
								}
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x060005EA RID: 1514 RVA: 0x00023CF4 File Offset: 0x00021EF4
		private Dictionary<string, string> GetDictionaryOfNewNamesForDependentRecordings(string parentMacroName)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			foreach (object obj in this.mScriptsStackPanel.Children)
			{
				ImportMacroScriptsControl importMacroScriptsControl = (ImportMacroScriptsControl)obj;
				if ((importMacroScriptsControl.Tag != null && importMacroScriptsControl.Tag.ToString().Equals(parentMacroName, StringComparison.InvariantCultureIgnoreCase)) || (importMacroScriptsControl.mContent.Content.ToString().Equals(parentMacroName, StringComparison.InvariantCultureIgnoreCase) && !importMacroScriptsControl.mReplaceExistingBtn.IsChecked.GetValueOrDefault()))
				{
					dictionary.Add(importMacroScriptsControl.mContent.Content.ToString(), importMacroScriptsControl.mImportName.Text);
				}
			}
			return dictionary;
		}

		// Token: 0x060005EB RID: 1515 RVA: 0x00023DC0 File Offset: 0x00021FC0
		private void ShowLoadingGrid(bool isShow)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				if (isShow)
				{
					this.mLoadingGrid.Visibility = Visibility.Visible;
					return;
				}
				this.mLoadingGrid.Visibility = Visibility.Hidden;
			}), new object[0]);
		}

		// Token: 0x060005EC RID: 1516 RVA: 0x00023E00 File Offset: 0x00022000
		private void SelectAllBtn_Click(object sender, RoutedEventArgs e)
		{
			if (this.mSelectAllBtn.IsChecked.Value)
			{
				using (IEnumerator enumerator = this.mScriptsStackPanel.Children.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						object obj = enumerator.Current;
						(obj as ImportMacroScriptsControl).mContent.IsChecked = new bool?(true);
					}
					return;
				}
			}
			foreach (object obj2 in this.mScriptsStackPanel.Children)
			{
				(obj2 as ImportMacroScriptsControl).mContent.IsChecked = new bool?(false);
			}
		}

		// Token: 0x060005ED RID: 1517 RVA: 0x00023ED0 File Offset: 0x000220D0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/importmacrowindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060005EE RID: 1518 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060005EF RID: 1519 RVA: 0x00023F00 File Offset: 0x00022100
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((ImportMacroWindow)target).Closing += this.ImportMacroWindow_Closing;
				return;
			case 2:
				this.mMaskBorder = (Border)target;
				return;
			case 3:
				((CustomPictureBox)target).MouseLeftButtonUp += this.Close_MouseLeftButtonUp;
				return;
			case 4:
				this.mScriptsListScrollbar = (ScrollViewer)target;
				return;
			case 5:
				this.mSelectAllBtn = (CustomCheckbox)target;
				this.mSelectAllBtn.Click += this.SelectAllBtn_Click;
				return;
			case 6:
				this.mImportBtn = (CustomButton)target;
				this.mImportBtn.Click += this.ImportBtn_Click;
				return;
			case 7:
				this.mLoadingGrid = (ProgressBar)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400033A RID: 826
		private MacroRecorderWindow mOperationWindow;

		// Token: 0x0400033B RID: 827
		private MainWindow ParentWindow;

		// Token: 0x0400033C RID: 828
		internal StackPanel mScriptsStackPanel;

		// Token: 0x0400033D RID: 829
		internal int mNumberOfFilesSelectedForImport;

		// Token: 0x0400033E RID: 830
		private Dictionary<ImportMacroScriptsControl, MacroRecording> mBoxToRecordingDict = new Dictionary<ImportMacroScriptsControl, MacroRecording>();

		// Token: 0x0400033F RID: 831
		private Dictionary<CustomTextBox, MacroRecording> mDependentRecordingDict = new Dictionary<CustomTextBox, MacroRecording>();

		// Token: 0x04000340 RID: 832
		private bool mInited;

		// Token: 0x04000341 RID: 833
		internal bool mIsInDependentFileFindingMode;

		// Token: 0x04000342 RID: 834
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder;

		// Token: 0x04000343 RID: 835
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ScrollViewer mScriptsListScrollbar;

		// Token: 0x04000344 RID: 836
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mSelectAllBtn;

		// Token: 0x04000345 RID: 837
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mImportBtn;

		// Token: 0x04000346 RID: 838
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ProgressBar mLoadingGrid;

		// Token: 0x04000347 RID: 839
		private bool _contentLoaded;
	}
}
