﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000A6 RID: 166
	public class DMMBottomBar : UserControl, IComponentConnector
	{
		// Token: 0x170001B9 RID: 441
		// (get) Token: 0x06000684 RID: 1668 RVA: 0x00006315 File Offset: 0x00004515
		// (set) Token: 0x06000685 RID: 1669 RVA: 0x00026E64 File Offset: 0x00025064
		internal double CurrentTransparency
		{
			get
			{
				return DMMBottomBar.sCurrentTransparency;
			}
			set
			{
				DMMBottomBar.sCurrentTransparency = value;
				this.transSlider.ValueChanged -= this.TransparencySlider_ValueChanged;
				if (this.ParentWindow.mDMMFST != null)
				{
					this.ParentWindow.mDMMFST.transSlider.ValueChanged -= this.ParentWindow.mDMMFST.TransparencySlider_ValueChanged;
				}
				this.transSlider.Value = DMMBottomBar.sCurrentTransparency;
				if (this.ParentWindow.mDMMFST != null)
				{
					this.ParentWindow.mDMMFST.transSlider.Value = DMMBottomBar.sCurrentTransparency;
				}
				this.transSlider.ValueChanged += this.TransparencySlider_ValueChanged;
				if (this.ParentWindow.mDMMFST != null)
				{
					this.ParentWindow.mDMMFST.transSlider.ValueChanged += this.ParentWindow.mDMMFST.TransparencySlider_ValueChanged;
				}
			}
		}

		// Token: 0x170001BA RID: 442
		// (get) Token: 0x06000686 RID: 1670 RVA: 0x0000631C File Offset: 0x0000451C
		// (set) Token: 0x06000687 RID: 1671 RVA: 0x00026F4C File Offset: 0x0002514C
		internal int CurrentVolume
		{
			get
			{
				return DMMBottomBar.sCurrentVolume;
			}
			set
			{
				DMMBottomBar.sCurrentVolume = value;
				this.mVolumeSlider.Value = (double)DMMBottomBar.sCurrentVolume;
				if (this.ParentWindow.mDMMFST != null && this.ParentWindow.mDMMFST.mVolumeSlider != null)
				{
					this.ParentWindow.mDMMFST.mVolumeSlider.Value = (double)DMMBottomBar.sCurrentVolume;
				}
				if (DMMBottomBar.sCurrentVolume < 1)
				{
					this.VolumeImageName = "volume_mute";
					return;
				}
				if (DMMBottomBar.sCurrentVolume <= 50)
				{
					this.VolumeImageName = "volume_small";
					return;
				}
				this.VolumeImageName = "volume_large";
			}
		}

		// Token: 0x170001BB RID: 443
		// (get) Token: 0x06000688 RID: 1672 RVA: 0x00006323 File Offset: 0x00004523
		// (set) Token: 0x06000689 RID: 1673 RVA: 0x00006335 File Offset: 0x00004535
		public string VolumeImageName
		{
			get
			{
				return (string)base.GetValue(DMMBottomBar.VolumeImageNameProperty);
			}
			set
			{
				base.SetValue(DMMBottomBar.VolumeImageNameProperty, value);
			}
		}

		// Token: 0x0600068A RID: 1674 RVA: 0x00026FE0 File Offset: 0x000251E0
		private static void OnVolumeImageNameChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			(d as DMMBottomBar).ParentWindow.mDmmBottomBar.mVolumeBtn.ImageName = e.NewValue.ToString();
			(d as DMMBottomBar).ParentWindow.mDmmBottomBar.volumesSliderImage.ImageName = e.NewValue.ToString();
			(d as DMMBottomBar).ParentWindow.mDMMFST.mVolumeBtn.ImageName = e.NewValue.ToString();
			(d as DMMBottomBar).ParentWindow.mDMMFST.volumeSliderImage.ImageName = e.NewValue.ToString();
		}

		// Token: 0x0600068B RID: 1675 RVA: 0x00006343 File Offset: 0x00004543
		public DMMBottomBar()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600068C RID: 1676 RVA: 0x00027088 File Offset: 0x00025288
		public void Init(MainWindow window)
		{
			this.ParentWindow = window;
			this.VolumeImageName = "volume_small";
			this.mVolumeBtn.ImageName = "volume_small";
			this.CurrentTransparency = (DMMBottomBar.sPreviousTransparency = RegistryManager.Instance.TranslucentControlsTransparency);
			if (this.ParentWindow != null)
			{
				this.ParentWindow.mCommonHandler.VolumeChangedEvent += this.DMMBottomBar_VolumeChangedEvent;
				this.ParentWindow.mCommonHandler.VolumeMutedEvent += this.DMMBottomBar_VolumeMutedEvent;
			}
		}

		// Token: 0x0600068D RID: 1677 RVA: 0x00006351 File Offset: 0x00004551
		private void DMMBottomBar_VolumeMutedEvent(bool muted)
		{
			if (muted)
			{
				this.VolumeImageName = "volume_mute";
				return;
			}
			this.CurrentVolume = (int)this.mVolumeSlider.Value;
		}

		// Token: 0x0600068E RID: 1678 RVA: 0x00027110 File Offset: 0x00025310
		private void DMMBottomBar_VolumeChangedEvent(int volumeLevel)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.CurrentVolume = volumeLevel;
			}), new object[0]);
		}

		// Token: 0x0600068F RID: 1679 RVA: 0x00006374 File Offset: 0x00004574
		internal void Tab_Changed(object sender, EventArgs e)
		{
			this.ParentWindow.mCommonHandler.SetDMMKeymapButtonsAndTransparency();
		}

		// Token: 0x06000690 RID: 1680 RVA: 0x00006386 File Offset: 0x00004586
		private void FullScreenBtn_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.FullScreenButtonHandler("bottombarDmm", "MouseClick");
		}

		// Token: 0x06000691 RID: 1681 RVA: 0x000063A2 File Offset: 0x000045A2
		private void ScreenshotBtn_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.ScreenShotButtonHandler();
		}

		// Token: 0x06000692 RID: 1682 RVA: 0x000063B4 File Offset: 0x000045B4
		private void VolumeBtn_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.mVolumePopup.IsOpen = !this.mVolumePopup.IsOpen;
		}

		// Token: 0x06000693 RID: 1683 RVA: 0x000063CF File Offset: 0x000045CF
		private void SettingsBtn_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.LaunchSettingsWindow();
		}

		// Token: 0x06000694 RID: 1684 RVA: 0x00027150 File Offset: 0x00025350
		private void RecommendedWindowBtn_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow.WindowState == WindowState.Normal)
			{
				if (this.ParentWindow.mDMMRecommendedWindow == null)
				{
					this.ParentWindow.mDMMRecommendedWindow = new DMMRecommendedWindow(this.ParentWindow);
					this.ParentWindow.mDMMRecommendedWindow.Init(RegistryManager.Instance.DMMRecommendedWindowUrl);
				}
				if (this.ParentWindow.mDMMRecommendedWindow.Visibility != Visibility.Visible)
				{
					this.ParentWindow.mDMMRecommendedWindow.Visibility = Visibility.Visible;
					this.ParentWindow.mIsDMMRecommendedWindowOpen = true;
				}
				else
				{
					this.ParentWindow.mDMMRecommendedWindow.Visibility = Visibility.Hidden;
					this.ParentWindow.mIsDMMRecommendedWindowOpen = false;
				}
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					Thread.Sleep(500);
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						this.ParentWindow.Activate();
					}), new object[0]);
				});
			}
		}

		// Token: 0x06000695 RID: 1685 RVA: 0x0002720C File Offset: 0x0002540C
		private void DoNotPromptManageGP_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (string.Equals(this.mDoNotPromptChkBx.ImageName, "bgpcheckbox", StringComparison.InvariantCulture))
			{
				this.mDoNotPromptChkBx.ImageName = "bgpcheckbox_checked";
				RegistryManager.Instance.KeyMappingAvailablePromptEnabled = false;
			}
			else
			{
				this.mDoNotPromptChkBx.ImageName = "bgpcheckbox";
				RegistryManager.Instance.KeyMappingAvailablePromptEnabled = true;
			}
			e.Handled = true;
		}

		// Token: 0x06000696 RID: 1686 RVA: 0x000063E1 File Offset: 0x000045E1
		private void ClosePopup_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mKeyMapPopup.IsOpen = false;
			e.Handled = true;
		}

		// Token: 0x06000697 RID: 1687 RVA: 0x000063F6 File Offset: 0x000045F6
		private void KeyMapPopup_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mKeyMapPopup.IsOpen = false;
			this.ParentWindow.mCommonHandler.KeyMapButtonHandler("MouseClick", "bottombarpopup");
		}

		// Token: 0x06000698 RID: 1688 RVA: 0x0000641E File Offset: 0x0000461E
		private void SwitchKeyMapButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.DMMSwitchKeyMapButtonHandler();
		}

		// Token: 0x06000699 RID: 1689 RVA: 0x00027270 File Offset: 0x00025470
		private void KeyMapButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab != null && this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName != null)
			{
				this.ParentWindow.mCommonHandler.KeyMapButtonHandler("MouseClick", "bottombar");
			}
		}

		// Token: 0x0600069A RID: 1690 RVA: 0x00006430 File Offset: 0x00004630
		private void TranslucentControlsButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.transSlider.Value = RegistryManager.Instance.TranslucentControlsTransparency;
			this.mChangeTransparencyPopup.PlacementTarget = this.mTranslucentControlsButton;
			this.mChangeTransparencyPopup.IsOpen = true;
		}

		// Token: 0x0600069B RID: 1691 RVA: 0x00006464 File Offset: 0x00004664
		private void UserControl_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (!DesignerProperties.GetIsInDesignMode(this))
			{
				this.UpdateLayoutAndBounds();
			}
		}

		// Token: 0x0600069C RID: 1692 RVA: 0x00006474 File Offset: 0x00004674
		internal void UpdateLayoutAndBounds()
		{
			if (this.mKeyMapPopup.IsOpen)
			{
				this.ShowKeyMapPopup(true);
			}
		}

		// Token: 0x0600069D RID: 1693 RVA: 0x000272CC File Offset: 0x000254CC
		internal void ShowKeyMapPopup(bool isShow)
		{
			if (isShow)
			{
				new Thread(delegate()
				{
					Thread.Sleep(500);
					base.Dispatcher.Invoke(new Action(delegate()
					{
						this.mKeyMapPopup.IsOpen = false;
						this.mKeyMapPopup.PlacementTarget = this.mKeyMapButton;
						if (!Array.Exists<string>(RegistryManager.Instance.DisabledGuidancePackages, (string element) => element == this.ParentWindow.StaticComponents.mSelectedTabButton.PackageName) && RegistryManager.Instance.IsAutoShowGuidance && !this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.mIsKeyMappingTipDisplayed)
						{
							this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.mIsKeyMappingTipDisplayed = true;
							KMManager.HandleInputMapperWindow(this.ParentWindow, "");
							return;
						}
						if (RegistryManager.Instance.KeyMappingAvailablePromptEnabled)
						{
							this.mKeyMapPopup.IsOpen = true;
						}
					}), new object[0]);
				})
				{
					IsBackground = true
				}.Start();
				return;
			}
			base.Dispatcher.Invoke(new Action(delegate()
			{
				this.mKeyMapPopup.IsOpen = false;
			}), new object[0]);
		}

		// Token: 0x0600069E RID: 1694 RVA: 0x0000648A File Offset: 0x0000468A
		internal void TransparencySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			this.CurrentTransparency = e.NewValue;
			DMMBottomBar.sPreviousTransparency = e.NewValue;
			this.ChangeTransparency();
		}

		// Token: 0x0600069F RID: 1695 RVA: 0x00027318 File Offset: 0x00025518
		private void ChangeTransparency()
		{
			KMManager.ChangeTransparency(this.ParentWindow, this.CurrentTransparency);
			if (this.CurrentTransparency == 0.0)
			{
				KMManager.ShowOverlayWindow(this.ParentWindow, false, false);
				this.ParentWindow.mCommonHandler.SetTranslucentControlsBtnImageForDMM("eye_off");
				return;
			}
			KMManager.ShowOverlayWindow(this.ParentWindow, true, false);
			this.ParentWindow.mCommonHandler.SetTranslucentControlsBtnImageForDMM("eye");
		}

		// Token: 0x060006A0 RID: 1696 RVA: 0x0002738C File Offset: 0x0002558C
		internal void VolumeSlider_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Slider slider = (Slider)sender;
			if (this.ParentWindow != null)
			{
				this.ParentWindow.Utils.SetVolumeInFrontendAsync((int)slider.Value);
			}
		}

		// Token: 0x060006A1 RID: 1697 RVA: 0x000064A9 File Offset: 0x000046A9
		internal void mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.CurrentTransparency = ((this.CurrentTransparency == 0.0) ? DMMBottomBar.sPreviousTransparency : 0.0);
			this.ChangeTransparency();
		}

		// Token: 0x060006A2 RID: 1698 RVA: 0x000064D8 File Offset: 0x000046D8
		internal void VolumeSliderImage_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow != null)
			{
				if (this.ParentWindow.EngineInstanceRegistry.IsMuted)
				{
					this.ParentWindow.Utils.UnmuteApplication(false);
					return;
				}
				this.ParentWindow.Utils.MuteApplication(false);
			}
		}

		// Token: 0x060006A3 RID: 1699 RVA: 0x000273C0 File Offset: 0x000255C0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/dmmbottombar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060006A4 RID: 1700 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060006A5 RID: 1701 RVA: 0x000273F0 File Offset: 0x000255F0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((DMMBottomBar)target).SizeChanged += this.UserControl_SizeChanged;
				return;
			case 2:
				this.DMMBottomGrid = (Grid)target;
				return;
			case 3:
				this.mKeyMapSwitch = (CustomPictureBox)target;
				this.mKeyMapSwitch.PreviewMouseLeftButtonUp += this.SwitchKeyMapButton_PreviewMouseLeftButtonUp;
				return;
			case 4:
				this.mKeyMapButton = (CustomPictureBox)target;
				this.mKeyMapButton.PreviewMouseLeftButtonUp += this.KeyMapButton_PreviewMouseLeftButtonUp;
				return;
			case 5:
				this.mTranslucentControlsButton = (CustomPictureBox)target;
				this.mTranslucentControlsButton.PreviewMouseLeftButtonUp += this.TranslucentControlsButton_PreviewMouseLeftButtonUp;
				return;
			case 6:
				this.mScreenshotBtn = (CustomPictureBox)target;
				this.mScreenshotBtn.PreviewMouseLeftButtonUp += this.ScreenshotBtn_MouseUp;
				return;
			case 7:
				this.mVolumeBtn = (CustomPictureBox)target;
				this.mVolumeBtn.PreviewMouseLeftButtonUp += this.VolumeBtn_MouseUp;
				return;
			case 8:
				this.mFullscreenBtn = (CustomPictureBox)target;
				this.mFullscreenBtn.PreviewMouseLeftButtonUp += this.FullScreenBtn_MouseUp;
				return;
			case 9:
				this.mSettingsBtn = (CustomPictureBox)target;
				this.mSettingsBtn.PreviewMouseLeftButtonUp += this.SettingsBtn_MouseUp;
				return;
			case 10:
				this.mRecommendedWindowBtn = (CustomPictureBox)target;
				this.mRecommendedWindowBtn.PreviewMouseLeftButtonUp += this.RecommendedWindowBtn_PreviewMouseLeftButtonUp;
				return;
			case 11:
				this.mVolumePopup = (CustomPopUp)target;
				return;
			case 12:
				this.volumesSliderImage = (CustomPictureBox)target;
				this.volumesSliderImage.PreviewMouseLeftButtonUp += this.VolumeSliderImage_PreviewMouseLeftButtonUp;
				return;
			case 13:
				this.mVolumeSlider = (Slider)target;
				this.mVolumeSlider.PreviewMouseLeftButtonUp += this.VolumeSlider_PreviewMouseLeftButtonUp;
				return;
			case 14:
				this.mKeyMapPopup = (CustomPopUp)target;
				return;
			case 15:
				((Border)target).MouseLeftButtonUp += this.KeyMapPopup_PreviewMouseLeftButtonUp;
				return;
			case 16:
				((CustomPictureBox)target).MouseLeftButtonUp += this.ClosePopup_MouseLeftButtonUp;
				return;
			case 17:
				this.mKeyMappingPopUp1 = (TextBlock)target;
				return;
			case 18:
				this.mKeyMappingPopUp3 = (TextBlock)target;
				return;
			case 19:
				this.mDoNotPromptChkBx = (CustomPictureBox)target;
				this.mDoNotPromptChkBx.MouseLeftButtonUp += this.DoNotPromptManageGP_MouseLeftButtonUp;
				return;
			case 20:
				this.mKeyMappingDontShowPopUp = (TextBlock)target;
				this.mKeyMappingDontShowPopUp.MouseLeftButtonUp += this.DoNotPromptManageGP_MouseLeftButtonUp;
				return;
			case 21:
				this.DownArrow = (Path)target;
				return;
			case 22:
				this.mChangeTransparencyPopup = (CustomPopUp)target;
				return;
			case 23:
				this.mTranslucentControlsSliderButton = (CustomPictureBox)target;
				this.mTranslucentControlsSliderButton.PreviewMouseLeftButtonUp += this.mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp;
				return;
			case 24:
				this.transSlider = (Slider)target;
				this.transSlider.ValueChanged += this.TransparencySlider_ValueChanged;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040003A9 RID: 937
		private MainWindow ParentWindow;

		// Token: 0x040003AA RID: 938
		private static double sCurrentTransparency = 0.0;

		// Token: 0x040003AB RID: 939
		private static double sPreviousTransparency = 0.0;

		// Token: 0x040003AC RID: 940
		private static int sCurrentVolume = 33;

		// Token: 0x040003AD RID: 941
		public static readonly DependencyProperty VolumeImageNameProperty = DependencyProperty.Register("VolumeImageName", typeof(string), typeof(DMMBottomBar), new FrameworkPropertyMetadata("volume_small", new PropertyChangedCallback(DMMBottomBar.OnVolumeImageNameChanged)));

		// Token: 0x040003AE RID: 942
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid DMMBottomGrid;

		// Token: 0x040003AF RID: 943
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mKeyMapSwitch;

		// Token: 0x040003B0 RID: 944
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mKeyMapButton;

		// Token: 0x040003B1 RID: 945
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mTranslucentControlsButton;

		// Token: 0x040003B2 RID: 946
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mScreenshotBtn;

		// Token: 0x040003B3 RID: 947
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mVolumeBtn;

		// Token: 0x040003B4 RID: 948
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mFullscreenBtn;

		// Token: 0x040003B5 RID: 949
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mSettingsBtn;

		// Token: 0x040003B6 RID: 950
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mRecommendedWindowBtn;

		// Token: 0x040003B7 RID: 951
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mVolumePopup;

		// Token: 0x040003B8 RID: 952
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox volumesSliderImage;

		// Token: 0x040003B9 RID: 953
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Slider mVolumeSlider;

		// Token: 0x040003BA RID: 954
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mKeyMapPopup;

		// Token: 0x040003BB RID: 955
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mKeyMappingPopUp1;

		// Token: 0x040003BC RID: 956
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mKeyMappingPopUp3;

		// Token: 0x040003BD RID: 957
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mDoNotPromptChkBx;

		// Token: 0x040003BE RID: 958
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mKeyMappingDontShowPopUp;

		// Token: 0x040003BF RID: 959
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Path DownArrow;

		// Token: 0x040003C0 RID: 960
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mChangeTransparencyPopup;

		// Token: 0x040003C1 RID: 961
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mTranslucentControlsSliderButton;

		// Token: 0x040003C2 RID: 962
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Slider transSlider;

		// Token: 0x040003C3 RID: 963
		private bool _contentLoaded;
	}
}
