﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Threading;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001FD RID: 509
	internal class HTTPHandler
	{
		// Token: 0x060012EB RID: 4843 RVA: 0x0000D34B File Offset: 0x0000B54B
		private static void WriteSuccessJsonArray(HttpListenerResponse res)
		{
			HTTPUtils.Write(new JArray
			{
				new JObject
				{
					new JProperty("success", true)
				}
			}.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x060012EC RID: 4844 RVA: 0x00072CD4 File Offset: 0x00070ED4
		private static void WriteErrorJsonArray(string reason, HttpListenerResponse res)
		{
			HTTPUtils.Write(new JArray
			{
				new JObject
				{
					new JProperty("success", false),
					new JProperty("reason", reason)
				}
			}.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x060012ED RID: 4845 RVA: 0x0000D385 File Offset: 0x0000B585
		private static void WriteErrorJSONObjectWithoutReason(HttpListenerResponse res)
		{
			HTTPUtils.Write(new JObject
			{
				{
					"success",
					false
				}
			}.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x060012EE RID: 4846 RVA: 0x0000D3AF File Offset: 0x0000B5AF
		public static void PingHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			HTTPHandler.WriteSuccessJsonWithVmName(HTTPUtils.ParseRequest(req).RequestVmName, res);
		}

		// Token: 0x060012EF RID: 4847 RVA: 0x00072D2C File Offset: 0x00070F2C
		internal static void EnableWndProcLogging(HttpListenerRequest _1, HttpListenerResponse _2)
		{
			try
			{
				WindowWndProcHandler.isLogWndProc = !WindowWndProcHandler.isLogWndProc;
				Logger.Info("Got request for EnableWndProcLogging" + WindowWndProcHandler.isLogWndProc.ToString());
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in set EnableWndProcLogging... Err : " + ex.ToString());
			}
		}

		// Token: 0x060012F0 RID: 4848 RVA: 0x00072D8C File Offset: 0x00070F8C
		internal static void EnableKeyboardHookLogging(HttpListenerRequest _1, HttpListenerResponse _2)
		{
			try
			{
				GlobalKeyBoardMouseHooks.sIsEnableKeyboardHookLogging = !GlobalKeyBoardMouseHooks.sIsEnableKeyboardHookLogging;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in set EnableKeyboardHookLogging... Err : " + ex.ToString());
			}
		}

		// Token: 0x060012F1 RID: 4849 RVA: 0x00072DD0 File Offset: 0x00070FD0
		internal static void EnableDebugLogs(HttpListenerRequest _1, HttpListenerResponse res)
		{
			try
			{
				Logger.EnableDebugLogs();
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in EnableDebugLogs... Err : " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x060012F2 RID: 4850 RVA: 0x00072E18 File Offset: 0x00071018
		public static void SendAppDisplayed(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				JObject jobject = new JObject();
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					jobject.Add("success", BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mAppHandler.mAppDisplayedOccured);
				}
				HTTPUtils.Write(jobject.ToString(Formatting.None, new JsonConverter[0]), res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server SendAppDisplayed. Err : " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x060012F3 RID: 4851 RVA: 0x00072EB4 File Offset: 0x000710B4
		internal static void RestartFrontend(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].RestartFrontend();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server RestartFrontend. Err : " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x060012F4 RID: 4852 RVA: 0x00072F20 File Offset: 0x00071120
		internal static void GCCollect(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				GC.Collect();
				GC.WaitForPendingFinalizers();
				GC.Collect();
				HTTPHandler.WriteSuccessJsonWithVmName(requestData.RequestVmName, res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server GCCollect. Err : " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x060012F5 RID: 4853 RVA: 0x00072F80 File Offset: 0x00071180
		public static void IsBlueStacksUIVisible(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				JObject jobject = new JObject();
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					jobject.Add("success", BlueStacksUIUtils.DictWindows[requestData.RequestVmName].IsVisible);
				}
				HTTPUtils.Write(jobject.ToString(Formatting.None, new JsonConverter[0]), res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server IsBlueStacksUIVisible. Err : " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x060012F6 RID: 4854 RVA: 0x00073014 File Offset: 0x00071214
		internal static void ToggleFarmMode(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				CommonHandlers.ToggleFarmMode(bool.Parse(requestData.Data["state"]));
				HTTPHandler.WriteSuccessJsonWithVmName(requestData.RequestVmName, res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server ToggleFarmMode. Err : " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x060012F7 RID: 4855 RVA: 0x0007307C File Offset: 0x0007127C
		internal static void ToggleStreamingMode(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				bool state = bool.Parse(requestData.Data["state"]);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					MainWindow mWindow = BlueStacksUIUtils.DictWindows[requestData.RequestVmName];
					mWindow.Dispatcher.Invoke(new Action(delegate()
					{
						mWindow.mTopBar.mPreferenceDropDownControl.ToggleStreamingMode(state);
						mWindow.mFrontendHandler.ToggleStreamingMode(state);
					}), new object[0]);
				}
				HTTPHandler.WriteSuccessJsonWithVmName(requestData.RequestVmName, res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server ToggleStreamingMode. Err : " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x060012F8 RID: 4856 RVA: 0x00073138 File Offset: 0x00071338
		internal static void GamepadGuidanceButtonHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					MainWindow mWindow = BlueStacksUIUtils.DictWindows[requestData.RequestVmName];
					if (mWindow != BlueStacksUIUtils.LastActivatedWindow || (mWindow.EngineInstanceRegistry.IsNativeGamepadEnabled && RegistryManager.Instance.GamepadDetectionEnabled && mWindow.IsGamepadConnected))
					{
						return;
					}
					mWindow.Dispatcher.Invoke(new Action(delegate()
					{
						if (KMManager.CheckIfKeymappingWindowVisible(true))
						{
							KMManager.CloseWindows();
							mWindow.mSidebar.UpdateImage("sidebar_gameguide", "sidebar_gameguide");
							return;
						}
						if (!KeymapCanvasWindow.sIsDirty)
						{
							KMManager.HandleInputMapperWindow(mWindow, "gamepad");
						}
					}), new object[0]);
				}
				HTTPHandler.WriteSuccessJsonWithVmName(requestData.RequestVmName, res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GamepadGuidanceButtonHandler. Err : " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x060012F9 RID: 4857 RVA: 0x00073214 File Offset: 0x00071414
		internal static void SetCurrentVolumeFromAndroidHandler(HttpListenerRequest req, HttpListenerResponse _)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.RequestVmName;
				int volumeLevelFromAndroid = Convert.ToInt32(requestData.Data["volume"], CultureInfo.InvariantCulture);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestVmName].Utils.SetVolumeLevelFromAndroid(volumeLevelFromAndroid);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to set volume level. Er : " + ex.ToString());
			}
		}

		// Token: 0x060012FA RID: 4858 RVA: 0x00073298 File Offset: 0x00071498
		internal static void ReinitRegistry(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RegistryManager.ClearRegistryMangerInstance();
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to reinit registry. Err : " + ex.ToString());
			}
		}

		// Token: 0x060012FB RID: 4859 RVA: 0x000732D4 File Offset: 0x000714D4
		internal static void UpdateCrc(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.RequestVmName;
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						uint num;
						float num2;
						float num3;
						if (uint.TryParse(requestData.Data["Crc"], out num) && float.TryParse(requestData.Data["X"], out num2) && float.TryParse(requestData.Data["Y"], out num3))
						{
							string text = string.Format(CultureInfo.InvariantCulture, "X: {0}   Y: {1}   Crc: {2}", new object[]
							{
								num2.ToString(CultureInfo.InvariantCulture),
								num3.ToString(CultureInfo.InvariantCulture),
								num.ToString("X", CultureInfo.InvariantCulture)
							});
							Logger.Info("IMAGEPICKER: " + text);
							System.Windows.Forms.MessageBox.Show(text);
							System.Windows.Forms.Clipboard.SetText(text);
						}
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed in UpdateCrc. Err : " + ex.ToString());
			}
		}

		// Token: 0x060012FC RID: 4860 RVA: 0x00073360 File Offset: 0x00071560
		internal static void NCSetGameInfoOnTopBarHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.RequestVmName;
				string gameName = requestData.Data["game"];
				string characterName = requestData.Data["character"];
				MainWindow mWindow = BlueStacksUIUtils.DictWindows[requestVmName];
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestVmName))
				{
					mWindow.Dispatcher.Invoke(new Action(delegate()
					{
						mWindow.mNCTopBar.mAppName.Text = gameName;
						mWindow.mNCTopBar.mAppName.ToolTip = gameName;
						mWindow.mNCTopBar.mGamenameSeparator.Visibility = Visibility.Visible;
						mWindow.mNCTopBar.mCharacterName.Text = characterName;
						mWindow.mNCTopBar.mCharacterName.ToolTip = characterName;
					}), new object[0]);
					HTTPHandler.WriteSuccessJsonWithVmName(requestVmName, res);
				}
				else
				{
					HTTPHandler.WriteErrorJsonArray("Client Instance not running", res);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to set GameInfo err : " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x060012FD RID: 4861 RVA: 0x00073438 File Offset: 0x00071638
		internal static void OpenCFGReorderTool(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>()[0].Dispatcher.Invoke(new Action(delegate()
				{
					CFGReorderWindow.Instance.Show();
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't open cfg reorder window. Ex: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x060012FE RID: 4862 RVA: 0x000734B4 File Offset: 0x000716B4
		internal static void OpenThemeEditor(HttpListenerRequest _1, HttpListenerResponse _2)
		{
			try
			{
				if (RegistryManager.Instance.OpenThemeEditor)
				{
					BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>()[0].Dispatcher.Invoke(new Action(delegate()
					{
						ThemeEditorWindow.Instance.Show();
					}), new object[0]);
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x060012FF RID: 4863 RVA: 0x00073528 File Offset: 0x00071728
		internal static void MuteAllInstancesHandler(HttpListenerRequest req, HttpListenerResponse _)
		{
			bool flag = Convert.ToBoolean(HTTPUtils.ParseRequest(req).Data["muteInstance"], CultureInfo.InvariantCulture);
			foreach (MainWindow mainWindow in BlueStacksUIUtils.DictWindows.Values)
			{
				if (flag)
				{
					mainWindow.Utils.MuteApplication(true);
				}
				else
				{
					mainWindow.Utils.UnmuteApplication(true);
				}
			}
		}

		// Token: 0x06001300 RID: 4864 RVA: 0x000735B8 File Offset: 0x000717B8
		internal static void AccountSetupCompleted(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.RequestVmName;
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName) && FeatureManager.Instance.IsCustomUIForNCSoft)
				{
					NCSoftUtils.Instance.SendGoogleLoginEventAsync(requestVmName);
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in AccountSetupCompleted Handler: " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06001301 RID: 4865 RVA: 0x00073634 File Offset: 0x00071834
		internal static void GetHeightWidth(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.RequestVmName;
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName) && BlueStacksUIUtils.DictWindows[vmName] != null)
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						try
						{
							MainWindow mainWindow = BlueStacksUIUtils.DictWindows[vmName];
							JArray jarray = new JArray();
							JObject item = new JObject
							{
								new JProperty("success", true)
							};
							JObject content = new JObject
							{
								new JProperty("cHeight", mainWindow.ActualHeight),
								new JProperty("cWidth", mainWindow.ActualWidth),
								new JProperty("gHeight", mainWindow.mContentGrid.ActualHeight),
								new JProperty("gWidth", mainWindow.mContentGrid.ActualWidth)
							};
							jarray.Add(item);
							jarray.Add(new JObject
							{
								new JProperty("result", content)
							});
							HTTPUtils.Write(jarray.ToString(Formatting.None, new JsonConverter[0]), res);
						}
						catch (Exception ex2)
						{
							Logger.Error("Some error in finding MainWindow instance err: " + ex2.ToString());
							HTTPHandler.WriteErrorJsonArray(ex2.Message, res);
						}
					}), new object[0]);
				}
				else
				{
					HTTPHandler.WriteErrorJsonArray("Client Instance not running", res);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to GetHeightWidth err : " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x06001302 RID: 4866 RVA: 0x00073700 File Offset: 0x00071900
		internal static void ScreenLock(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.RequestVmName;
				bool lockScreen = Convert.ToBoolean(requestData.Data["lock"], CultureInfo.InvariantCulture);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						if (lockScreen)
						{
							BlueStacksUIUtils.DictWindows[vmName].ShowLockScreen();
							return;
						}
						BlueStacksUIUtils.DictWindows[vmName].HideLockScreen();
					}), new object[0]);
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to lock screen err : " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x06001303 RID: 4867 RVA: 0x000737C4 File Offset: 0x000719C4
		internal static void SetStreamingStatus(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.RequestVmName;
				string status = requestData.Data["status"];
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[vmName].mCommonHandler.SetNcSoftStreamingStatus(status);
					}), new object[0]);
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to SetStreamingStatus err : " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x06001304 RID: 4868 RVA: 0x0007387C File Offset: 0x00071A7C
		internal static void PlayerScriptModifierKeyUp(HttpListenerRequest req, HttpListenerResponse _)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.RequestVmName;
				double x = Convert.ToDouble(requestData.Data["X"], CultureInfo.InvariantCulture);
				double y = Convert.ToDouble(requestData.Data["Y"], CultureInfo.InvariantCulture);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[vmName].mCommonHandler.AddCoordinatesToScriptText(x, y);
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to handle player script modifier key up: " + ex.ToString());
			}
		}

		// Token: 0x06001305 RID: 4869 RVA: 0x0007394C File Offset: 0x00071B4C
		internal static void LaunchPlay(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string key = requestData.Data["vmname"];
				string package = requestData.Data["package"];
				if (BlueStacksUIUtils.DictWindows.ContainsKey(key))
				{
					BlueStacksUIUtils.DictWindows[key].Utils.HandleLaunchPlay(package);
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to launch play store err : " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x06001306 RID: 4870 RVA: 0x000739E0 File Offset: 0x00071BE0
		internal static void FullScreenSidebarHandler(HttpListenerRequest req, HttpListenerResponse _)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.RequestVmName;
				bool isVisible = Convert.ToBoolean(requestData.Data["visible"], CultureInfo.InvariantCulture);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestVmName))
				{
					MainWindow window = BlueStacksUIUtils.ActivatedWindow;
					if (window != null && window.mIsFullScreen && !window.mFrontendHandler.IsShootingModeActivated)
					{
						window.Dispatcher.Invoke(new Action(delegate()
						{
							window.mSidebar.ToggleSidebarVisibilityInFullscreen(isVisible);
						}), new object[0]);
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06001307 RID: 4871 RVA: 0x00073A98 File Offset: 0x00071C98
		internal static void FullScreenTopbarHandler(HttpListenerRequest req, HttpListenerResponse _)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.RequestVmName;
				bool isVisible = Convert.ToBoolean(requestData.Data["visible"], CultureInfo.InvariantCulture);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestVmName))
				{
					MainWindow window = BlueStacksUIUtils.DictWindows[requestVmName];
					if (window != null && window.mIsFullScreen && !window.mFrontendHandler.IsShootingModeActivated)
					{
						window.Dispatcher.Invoke(new Action(delegate()
						{
							if (!window.mTopBarPopup.IsOpen & isVisible)
							{
								window.mTopBarPopup.IsOpen = true;
								return;
							}
							window.mTopBarPopup.IsOpen = false;
						}), new object[0]);
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06001308 RID: 4872 RVA: 0x00073B58 File Offset: 0x00071D58
		internal static void HandleGamepadConnection(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				bool isGamepadConnected = bool.Parse(requestData.Data["status"]);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].IsGamepadConnected = isGamepadConnected;
					if (!HTTPHandler.mSendGamepadStats)
					{
						ClientStats.SendMiscellaneousStatsAsync("GamePadConnectedStats", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, null, null, null, null, null, null);
						HTTPHandler.mSendGamepadStats = true;
					}
				}
				HTTPHandler.WriteSuccessJsonWithVmName(requestData.RequestVmName, res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in HandleGamepadConnection. Err : " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06001309 RID: 4873 RVA: 0x00073C18 File Offset: 0x00071E18
		internal static void TileWindow(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				HTTPUtils.ParseRequest(req);
				CommonHandlers.ArrangeWindowInTiles();
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in tiling window. Err : " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x0600130A RID: 4874 RVA: 0x00073C68 File Offset: 0x00071E68
		internal static void CascadeWindow(HttpListenerRequest _, HttpListenerResponse res)
		{
			try
			{
				CommonHandlers.ArrangeWindowInCascade();
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Cascading window. Err : " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x0600130B RID: 4875 RVA: 0x00073CB8 File Offset: 0x00071EB8
		internal static void UpdateLocale(HttpListenerRequest req, HttpListenerResponse res)
		{
			Logger.Info("Got UpdateLocale {0} request from {1}", new object[]
			{
				req.HttpMethod,
				req.RemoteEndPoint.ToString()
			});
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.RequestVmName;
				string text = requestData.Data["locale"].ToString(CultureInfo.InvariantCulture);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestVmName))
				{
					RegistryManager.Instance.UserSelectedLocale = text;
					Utils.UpdateValueInBootParams("LANG", text, requestVmName, false);
					BlueStacksUIUtils.DictWindows[requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						LocaleStrings.InitLocalization(null, "Android", false);
					}), new object[0]);
					HTTPUtils.SendRequestToAgentAsync("reinitlocalization", null, "Android", 0, null, false, 1, 0);
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in UpdateLocale: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x0600130C RID: 4876 RVA: 0x00073DC4 File Offset: 0x00071FC4
		internal static void ScreenshotCaptured(HttpListenerRequest req, HttpListenerResponse res)
		{
			Logger.Info("Got ScreenshotCaptured {0} request from {1}", new object[]
			{
				req.HttpMethod,
				req.RemoteEndPoint.ToString()
			});
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.RequestVmName;
				string path = requestData.Data["path"].ToString(CultureInfo.InvariantCulture);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[vmName].mCommonHandler.PostScreenShotWork(path);
					}), new object[0]);
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ScreenshotCaptured: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x0600130D RID: 4877 RVA: 0x00073EAC File Offset: 0x000720AC
		internal static void ClientHotkeyHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.RequestVmName;
				string value = requestData.Data["keyevent"].ToString(CultureInfo.InvariantCulture);
				ClientHotKeys clientHotKey = (ClientHotKeys)Enum.Parse(typeof(ClientHotKeys), value);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[vmName].HandleClientHotKey(clientHotKey);
					}), new object[0]);
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ClientHotkeyHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x0600130E RID: 4878 RVA: 0x00073F84 File Offset: 0x00072184
		internal static void AndroidLocaleChanged(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				BlueStacksUIUtils.UpdateLocale(RegistryManager.Instance.UserSelectedLocale, requestData.RequestVmName);
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in AndroidLocaleChanged. Err : " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x0600130F RID: 4879 RVA: 0x00073FE4 File Offset: 0x000721E4
		internal static void HandleClientOperation(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					string operationString = requestData.Data["data"];
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mCommonHandler.HandleClientOperation(operationString);
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in HandleClientOperation. Err : " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06001310 RID: 4880 RVA: 0x0007406C File Offset: 0x0007226C
		internal static void MacroPlaybackCompleteHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[requestData.RequestVmName].SetMacroPlayBackEventHandle();
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in MacroPlaybackCompleteHandler. Err : " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06001311 RID: 4881 RVA: 0x00074104 File Offset: 0x00072304
		internal static void HandleClientGamepadButtonHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						string text = requestData.Data["data"];
						bool isDown;
						if (bool.TryParse(requestData.Data["isDown"], out isDown))
						{
							KMManager.UpdateUIForGamepadEvent(text, isDown);
							return;
						}
						Logger.Error("Error in HandleClientGamepadButtonHandler: Could not parse gamepad event isDown:'{0}'", new object[]
						{
							requestData.Data["isDown"]
						});
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in HandleClientGamepadButtonHandler. Err : " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06001312 RID: 4882 RVA: 0x0007419C File Offset: 0x0007239C
		internal static void SaveComboEvents(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string events = requestData.Data["events"];
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					if (BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mIsMacroRecorderActive)
					{
						BlueStacksUIUtils.DictWindows[requestData.RequestVmName].MacroRecorderWindow.SaveOperation(events);
					}
					else
					{
						BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
						{
							KMManager.mComboEvents = events;
						}), new object[0]);
					}
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in SaveComboEvents. Err : " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06001313 RID: 4883 RVA: 0x0007427C File Offset: 0x0007247C
		internal static void MacroCompleted(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[requestData.RequestVmName].MacroOverlayControl.ShowPromptAndHideOverlay();
					}), new object[0]);
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in MacroCompleted. Err : " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06001314 RID: 4884 RVA: 0x0007431C File Offset: 0x0007251C
		internal static void ShowMaintenanceWarning(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.RequestVmName;
				string message = requestData.Data["message"];
				HTTPHandler.WriteJSON(new Dictionary<string, string>
				{
					{
						"result_code",
						"0"
					}
				}, res);
				BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
				{
					CustomMessageWindow customMessageWindow = new CustomMessageWindow();
					customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("BlueStacks") + " " + LocaleStrings.GetLocalizedString("STRING_WARNING");
					customMessageWindow.BodyTextBlock.Text = message;
					customMessageWindow.AddButton(ButtonColors.Blue, LocaleStrings.GetLocalizedString("STRING_OK"), null, null, false, null);
					customMessageWindow.Owner = BlueStacksUIUtils.DictWindows[vmName];
					BlueStacksUIUtils.DictWindows[vmName].ShowDimOverlay(null);
					customMessageWindow.ShowDialog();
					BlueStacksUIUtils.DictWindows[vmName].HideDimOverlay();
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to ShowMaintenanceWarning app... Err : " + ex.ToString());
				HTTPHandler.WriteJSON(new Dictionary<string, string>
				{
					{
						"result_code",
						"-1"
					}
				}, res);
			}
		}

		// Token: 0x06001315 RID: 4885 RVA: 0x0000D3C2 File Offset: 0x0000B5C2
		internal static void WriteJSON(Dictionary<string, string> data, HttpListenerResponse res)
		{
			HTTPUtils.Write(JSONUtils.GetJSONArrayString(data), res);
		}

		// Token: 0x06001316 RID: 4886 RVA: 0x000743E8 File Offset: 0x000725E8
		internal static void LaunchDefaultWebApp(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string text = requestData.Data["action"];
				Logger.Info("Action : " + text);
				if (text != null)
				{
					if (!(text == "browser"))
					{
						if (!(text == "email"))
						{
							goto IL_23A;
						}
					}
					else
					{
						string text2 = requestData.Data["url"];
						Logger.Info("Url : " + text2);
						try
						{
							Process.Start(text2);
							HTTPHandler.WriteSuccessJsonArray(res);
							goto IL_245;
						}
						catch
						{
							HTTPHandler.WriteErrorJsonArray("Invalid or empty url", res);
							goto IL_245;
						}
					}
					string text3 = "";
					string text4 = "";
					string text5 = "";
					string text6 = "";
					string text7 = "";
					string text8 = "";
					try
					{
						text3 = requestData.Data["to"];
						text4 = requestData.Data["cc"];
						text5 = requestData.Data["bcc"];
						text6 = requestData.Data["message"];
						text7 = requestData.Data["subject"];
						text8 = requestData.Data["mailto"];
					}
					catch
					{
					}
					bool flag = false;
					if (!string.IsNullOrEmpty(text3))
					{
						flag = (text3.Split(new char[]
						{
							'@'
						}).Length > 1);
					}
					Logger.Info(string.Concat(new string[]
					{
						"to : ",
						text3,
						", cc : ",
						text4,
						", bcc : ",
						text5,
						", subject = ",
						text7
					}));
					Logger.Info("mailto : " + text8);
					string text9;
					if (flag)
					{
						text9 = string.Concat(new string[]
						{
							"mailto:",
							text3,
							"?cc=",
							text4,
							"&bcc=",
							text5,
							"&subject=",
							text7,
							"&body=",
							text6
						});
					}
					else
					{
						if (string.IsNullOrEmpty(text8))
						{
							HTTPHandler.WriteErrorJsonArray("to and mailto field cannot be empty", res);
							goto IL_245;
						}
						text9 = text8;
					}
					Logger.Info("mail to request : " + text9);
					Process.Start(text9);
					HTTPHandler.WriteSuccessJsonArray(res);
					goto IL_245;
				}
				IL_23A:
				HTTPHandler.WriteErrorJsonArray("wrong or empty action", res);
				IL_245:;
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to LaunchDefaultWebApp app... Err : " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x06001317 RID: 4887 RVA: 0x000746B0 File Offset: 0x000728B0
		public static void GetRunningInstances(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				List<string> list = new List<string>(BlueStacksUIUtils.DictWindows.Keys);
				HTTPUtils.ParseRequest(req);
				JObject jobject = new JObject();
				string text = string.Join(",", list.ToArray());
				Logger.Info("Running instances: " + text);
				jobject.Add("success", true);
				jobject.Add("vmname", text);
				HTTPUtils.Write(jobject.ToString(Formatting.None, new JsonConverter[0]), res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GetRunningInstances");
				Logger.Error(ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06001318 RID: 4888 RVA: 0x0007475C File Offset: 0x0007295C
		internal static void IsAnyAppRunning(HttpListenerRequest _1, HttpListenerResponse res)
		{
			try
			{
				JObject jobject = new JObject
				{
					{
						"success",
						true
					}
				};
				bool isAppRunning = false;
				if (BlueStacksUIUtils.DictWindows.Count > 0)
				{
					MainWindow window = BlueStacksUIUtils.DictWindows[BlueStacksUIUtils.DictWindows.Keys.ToList<string>()[0]];
					window.Dispatcher.Invoke(new Action(delegate()
					{
						isAppRunning = window.mTopBar.mAppTabButtons.IsAppRunning();
					}), new object[0]);
					jobject.Add("isanyapprunning", isAppRunning);
				}
				HTTPUtils.Write(jobject.ToString(Formatting.None, new JsonConverter[0]), res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in IsAnyAppRunning: {0}", new object[]
				{
					ex
				});
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06001319 RID: 4889 RVA: 0x00074840 File Offset: 0x00072A40
		internal static void GetCurrentAppDetails(HttpListenerRequest _1, HttpListenerResponse res)
		{
			try
			{
				JObject jobject = new JObject
				{
					{
						"success",
						true
					}
				};
				if (BlueStacksUIUtils.DictWindows.Count > 0)
				{
					MainWindow window = BlueStacksUIUtils.DictWindows[BlueStacksUIUtils.DictWindows.Keys.ToList<string>()[0]];
					string pkg = string.Empty;
					string appName = string.Empty;
					string tabType = string.Empty;
					window.Dispatcher.Invoke(new Action(delegate()
					{
						pkg = window.mTopBar.mAppTabButtons.SelectedTab.PackageName;
						appName = (string)window.mTopBar.mAppTabButtons.SelectedTab.mTabLabel.Content;
						tabType = window.mTopBar.mAppTabButtons.SelectedTab.mTabType.ToString();
					}), new object[0]);
					jobject.Add("pkgname", pkg);
					jobject.Add("appname", appName);
					jobject.Add("tabtype", tabType);
				}
				HTTPUtils.Write(jobject.ToString(Formatting.None, new JsonConverter[0]), res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GetCurrentAppDetails: {0}", new object[]
				{
					ex
				});
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x0600131A RID: 4890 RVA: 0x00074970 File Offset: 0x00072B70
		internal static void ShowSettingWindow(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					MainWindow window = BlueStacksUIUtils.DictWindows[requestData.RequestVmName];
					window.Dispatcher.Invoke(new Action(delegate()
					{
						MainWindow.OpenSettingsWindow(window, "STRING_NOTIFICATION");
					}), new object[0]);
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server ShowSettingWindow: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x0600131B RID: 4891 RVA: 0x00074A14 File Offset: 0x00072C14
		internal static void LaunchWebTab(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					MainWindow window = BlueStacksUIUtils.DictWindows[requestData.RequestVmName];
					window.Dispatcher.Invoke(new Action(delegate()
					{
						window.mTopBar.mAppTabButtons.AddWebTab(requestData.Data["url"], requestData.Data["name"], requestData.Data["image"], true, "", false);
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server OneTimeSetupCompletedHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x0600131C RID: 4892 RVA: 0x00074AC0 File Offset: 0x00072CC0
		internal static void OneTimeSetupCompletedHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				MainWindow mainWindow = BlueStacksUIUtils.DictWindows[requestData.RequestVmName];
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					ClientStats.SendMiscellaneousStatsAsync("OTSActivityDisplayed", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "OTS Completed", "OTS Completed", null, RegistryManager.Instance.CurrentEngine, mainWindow.EngineInstanceRegistry.GlMode.ToString(CultureInfo.InvariantCulture), mainWindow.EngineInstanceRegistry.GlRenderMode.ToString(CultureInfo.InvariantCulture));
					mainWindow.mAppHandler.IsOneTimeSetupCompleted = true;
					ClientStats.SendMiscellaneousStatsAsync("OTSActivityDisplayed", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "OTS Completed", "OTS Completed", RegistryManager.Instance.InstallID, RegistryManager.Instance.CurrentEngine, mainWindow.EngineInstanceRegistry.GlMode.ToString(CultureInfo.InvariantCulture), mainWindow.EngineInstanceRegistry.GlRenderMode.ToString(CultureInfo.InvariantCulture));
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server OneTimeSetupCompletedHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x0600131D RID: 4893 RVA: 0x00074C18 File Offset: 0x00072E18
		internal static void AppJsonChangedHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mWelcomeTab.mHomeApp.ReInitAppJson();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in AppjsonChangedHabdler " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x0600131E RID: 4894 RVA: 0x00074C94 File Offset: 0x00072E94
		internal static void StartInstanceHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				string requestVmName = HTTPUtils.ParseRequest(req).RequestVmName;
				Logger.Info("start instance vm name :" + requestVmName);
				RegistryManager.ClearRegistryMangerInstance();
				BlueStacksUIUtils.RunInstance(requestVmName, false);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server StartInstanceHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x0600131F RID: 4895 RVA: 0x00074D00 File Offset: 0x00072F00
		internal static void StopInstanceHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				string requestVmName = HTTPUtils.ParseRequest(req).RequestVmName;
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestVmName].ForceCloseWindow();
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server StopInstanceHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06001320 RID: 4896 RVA: 0x00074D74 File Offset: 0x00072F74
		internal static void HideBluestacksHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				HTTPUtils.ParseRequest(req);
				Logger.Info("Hide Bluestacks received");
				BlueStacksUIUtils.HideUnhideBlueStacks(true);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server HideBluestacksHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06001321 RID: 4897 RVA: 0x00074DD0 File Offset: 0x00072FD0
		internal static void OpenOrInstallPackageHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.RequestVmName;
				string text = requestData.Data["json"].ToString(CultureInfo.InvariantCulture);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					HTTPHandler.ShowWindowHandler(req, res);
					if (!string.IsNullOrEmpty(text))
					{
						if (BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mAppHandler.IsOneTimeSetupCompleted)
						{
							new DownloadInstallApk(BlueStacksUIUtils.DictWindows[requestVmName]).DownloadAndInstallAppFromJson(text);
						}
						else
						{
							Opt.Instance.Json = text;
						}
					}
				}
				else
				{
					Opt.Instance.Json = text;
					HTTPHandler.ShowWindowHandler(req, res);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in OpenOrInstallPackageHandler. Err : " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06001322 RID: 4898 RVA: 0x00074EAC File Offset: 0x000730AC
		internal static void GuestBootCompleted(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					bool isGuestReady = BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mAppHandler.IsGuestReady;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in server GuestBootCompleted: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06001323 RID: 4899 RVA: 0x00074F24 File Offset: 0x00073124
		public static void AppDisplayedHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.Data.AllKeys)
				{
					Logger.Debug("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.Data[text]
					});
				}
				string text2 = requestData.Data["packageName"];
				string text3 = requestData.Data["appDisplayed"];
				object obj = HTTPHandler.sLockObject;
				lock (obj)
				{
					if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
					{
						MainWindow mainWindow = BlueStacksUIUtils.DictWindows[requestData.RequestVmName];
						if (FeatureManager.Instance.IsCustomUIForDMM)
						{
							mainWindow.mAppHandler.HandleAppDisplayed(text2);
						}
						if (!mainWindow.EngineInstanceRegistry.IsOneTimeSetupDone && text2 != "com.bluestacks.appmart" && !mainWindow.mGuestBootCompleted)
						{
							int num = 20;
							while (!mainWindow.mAppHandler.IsGuestReady && num > 0)
							{
								num--;
								Thread.Sleep(1000);
							}
							if (text2 == mainWindow.mAppHandler.GetDefaultLauncher())
							{
								if (!FeatureManager.Instance.IsCustomUIForNCSoft)
								{
									Logger.Info("BOOT_STAGE: Calling guestboot_completed from AppDisplayedHandler");
									mainWindow.GuestBoot_Completed();
								}
								else
								{
									mainWindow.Utils.sBootCheckTimer.Enabled = false;
									mainWindow.mEnableLaunchPlayForNCSoft = true;
								}
							}
						}
					}
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server AppDisplayedHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06001324 RID: 4900 RVA: 0x000750F8 File Offset: 0x000732F8
		public static void AppLaunchedHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.Data.AllKeys)
				{
					Logger.Debug("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.Data[text]
					});
				}
				string text2 = requestData.Data["package"];
				string text3 = requestData.Data["activity"];
				string text4 = requestData.Data["callingPackage"];
				Logger.Info("Package: {0}, activity: {1}, callingPackage: {2}", new object[]
				{
					text2,
					text3,
					text4
				});
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					MainWindow mainWindow = BlueStacksUIUtils.DictWindows[requestData.RequestVmName];
					if (!RegistryManager.Instance.Guest[requestData.RequestVmName].IsGoogleSigninDone)
					{
						object obj = HTTPHandler.syncRoot;
						lock (obj)
						{
							if (string.Compare(HTTPHandler.mPreviousActivityReported.Replace("/", ""), text3.Replace("/", ""), StringComparison.OrdinalIgnoreCase) != 0)
							{
								HTTPHandler.mPreviousActivityReported = text3;
								ClientStats.SendMiscellaneousStatsAsync("OTSActivityDisplayed", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, text2, text3, RegistryManager.Instance.InstallID, RegistryManager.Instance.CurrentEngine, mainWindow.EngineInstanceRegistry.GlMode.ToString(CultureInfo.InvariantCulture), mainWindow.EngineInstanceRegistry.GlRenderMode.ToString(CultureInfo.InvariantCulture));
							}
						}
					}
					if (FeatureManager.Instance.IsCustomUIForNCSoft && !mainWindow.mGuestBootCompleted && !text2.Equals("com.bluestacks.appmart", StringComparison.OrdinalIgnoreCase) && !text2.Equals("com.android.provision", StringComparison.OrdinalIgnoreCase))
					{
						mainWindow.GuestBoot_Completed();
					}
					if (mainWindow.mGuestBootCompleted)
					{
						mainWindow.mAppHandler.AppLaunched(text2, false);
					}
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server AppLaunchedHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06001325 RID: 4901 RVA: 0x00075354 File Offset: 0x00073554
		public static void AppCrashedHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.Data.AllKeys)
				{
					Logger.Debug("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.Data[text]
					});
				}
				string vmName = requestData.RequestVmName;
				string package = requestData.Data["package"];
				Logger.Info("package: " + package);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[vmName].mTopBar.mAppTabButtons.CloseTab("app:" + package, false, false, true, false, "");
					}), new object[0]);
					if (FeatureManager.Instance.IsCustomUIForNCSoft && !NCSoftUtils.Instance.BlackListedApps.Any((string pkg) => package.StartsWith(pkg, StringComparison.InvariantCulture)))
					{
						NCSoftUtils.Instance.SendAppCrashEvent("check android logs", vmName);
					}
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server AppCrashedHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06001326 RID: 4902 RVA: 0x000754B4 File Offset: 0x000736B4
		internal static void AppInfoUpdated(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string package = requestData.Data["packageName"];
				if (!string.IsNullOrEmpty(requestData.Data["macro"]) && requestData.Data["macro"].Equals("true", StringComparison.InvariantCultureIgnoreCase))
				{
					foreach (string text in requestData.Data.AllKeys)
					{
						Logger.Debug("Key: {0}, Value: {1}", new object[]
						{
							text,
							requestData.Data[text]
						});
					}
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						foreach (KeyValuePair<string, MainWindow> keyValuePair in BlueStacksUIUtils.DictWindows)
						{
							if (keyValuePair.Value.mWelcomeTab.mHomeApp.GetAppIcon(package) != null && keyValuePair.Value.mWelcomeTab.mHomeApp.GetMacroAppIcon(package) == null)
							{
								keyValuePair.Value.mWelcomeTab.mHomeApp.AddMacroAppIcon(package);
							}
						}
					}), new object[0]);
					HTTPHandler.WriteSuccessJsonArray(res);
				}
				if (!string.IsNullOrEmpty(requestData.Data["videoPresent"]) && BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					string value = requestData.Data["videoPresent"].ToString(CultureInfo.InvariantCulture);
					Dictionary<string, string> data = new Dictionary<string, string>
					{
						{
							"packageName",
							package
						},
						{
							"videoPresent",
							value
						}
					};
					HTTPUtils.SendRequestToAgentAsync("appJsonUpdatedForVideo", data, requestData.RequestVmName, 0, null, true, 1, 0);
				}
				KMManager.ControlSchemesHandlingWhileCfgUpdateFromCloud(package);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server AppInfoDownload: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06001327 RID: 4903 RVA: 0x0007566C File Offset: 0x0007386C
		public static void CloseTabHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.Data.AllKeys)
				{
					Logger.Debug("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.Data[text]
					});
				}
				string package = requestData.Data["package"];
				Logger.Info("package: " + package);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						try
						{
							BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mTopBar.mAppTabButtons.CloseTab(package, false, false, true, false, "");
						}
						catch (Exception ex2)
						{
							Logger.Error("Exception in closing tab. Err : ", new object[]
							{
								ex2.ToString()
							});
						}
					}), new object[0]);
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server TabCloseHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06001328 RID: 4904 RVA: 0x00075790 File Offset: 0x00073990
		public static void ShowAppHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.Data.AllKeys)
				{
					Logger.Debug("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.Data[text]
					});
				}
				string package = requestData.Data["package"];
				string activity = requestData.Data["activity"];
				string str = requestData.Data["title"];
				Logger.Info("package: " + package);
				Logger.Info("activity: " + activity);
				Logger.Info("title : " + str);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					new Thread(delegate()
					{
						BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
						{
							if (!string.IsNullOrEmpty(package) && !string.IsNullOrEmpty(activity))
							{
								BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mAppHandler.SendRunAppRequestAsync(package, activity, false);
							}
						}), new object[0]);
					})
					{
						IsBackground = true
					}.Start();
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server ShowAppHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x06001329 RID: 4905 RVA: 0x00075904 File Offset: 0x00073B04
		public static void ShowWindowHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string text = requestData.RequestVmName;
				if (requestData.Data.AllKeys.Contains("all"))
				{
					using (Dictionary<string, MainWindow>.Enumerator enumerator = BlueStacksUIUtils.DictWindows.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							KeyValuePair<string, MainWindow> keyValuePair = enumerator.Current;
							keyValuePair.Value.ShowWindow(false);
						}
						goto IL_ED;
					}
				}
				if (requestData.Data.AllKeys.Contains("vmname"))
				{
					text = requestData.Data["vmname"];
				}
				bool flag = requestData.Data["hidden"] != null && Convert.ToBoolean(requestData.Data["hidden"], CultureInfo.InvariantCulture);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(text))
				{
					if (!flag)
					{
						BlueStacksUIUtils.DictWindows[text].ShowWindow(false);
					}
				}
				else
				{
					RegistryManager.ClearRegistryMangerInstance();
					BlueStacksUIUtils.RunInstance(text, flag);
				}
				IL_ED:
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server ShowWindowHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x0600132A RID: 4906 RVA: 0x00075A4C File Offset: 0x00073C4C
		public static void ShowWindowAndAppHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						HTTPHandler.ShowWindowHandler(req, res);
						HTTPHandler.ShowAppHandler(req, res);
					}), new object[0]);
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server ShowWindowAndAppHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x0600132B RID: 4907 RVA: 0x00075B00 File Offset: 0x00073D00
		public static void IsVisibleHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					if (BlueStacksUIUtils.DictWindows[requestData.RequestVmName].IsVisible)
					{
						HTTPHandler.WriteSuccessJsonArray(res);
					}
					else
					{
						HTTPHandler.WriteErrorJsonArray("unused", res);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server IsVisibleHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x0600132C RID: 4908 RVA: 0x00075B88 File Offset: 0x00073D88
		public static void AppUninstalledHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.Data.AllKeys)
				{
					Logger.Debug("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.Data[text]
					});
				}
				string package = requestData.Data["package"];
				string title = requestData.Data["name"];
				Logger.Info("package: " + package);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mAppHandler.AppUninstalled(package);
					}), new object[0]);
				}
				NotificationManager.Instance.RemoveNotificationItem(title);
				Publisher.PublishMessage(BrowserControlTags.appUninstalled, package, requestData.RequestVmName);
				ClientStats.SendClientStatsAsync("uninstall", "success", "app_install", package, "", "");
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server AppUninstalledHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x0600132D RID: 4909 RVA: 0x00075D18 File Offset: 0x00073F18
		public static void AppInstalledHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.Data.AllKeys)
				{
					Logger.Info("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.Data[text]
					});
				}
				string package = requestData.Data["package"];
				Logger.Info("package: " + package);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mAppHandler.AppInstalled(package);
					}), new object[0]);
				}
				Publisher.PublishMessage(BrowserControlTags.appInstalled, package, requestData.RequestVmName);
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server AppInstalledHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.ToString(), res);
			}
		}

		// Token: 0x0600132E RID: 4910 RVA: 0x00075E54 File Offset: 0x00074054
		public static void ShowHomeTabHandler(HttpListenerRequest req, HttpListenerResponse _)
		{
			RequestData requestData = HTTPUtils.ParseRequest(req);
			if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
			{
				BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
				{
					Logger.Info("Switching to Welcome tab");
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mTopBar.mAppTabButtons.GoToTab("Home", true, false);
				}), new object[0]);
			}
		}

		// Token: 0x0600132F RID: 4911 RVA: 0x00075EBC File Offset: 0x000740BC
		public static void ShowWebPageHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string title = requestData.Data["title"].ToString(CultureInfo.InvariantCulture);
				string webUrl = requestData.Data["url"].ToString(CultureInfo.InvariantCulture);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						HTTPHandler.ShowWindowHandler(req, res);
						BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mTopBar.mAppTabButtons.AddWebTab(webUrl, title, "cef_tab", true, "", false);
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server ShowWebPageHandler : " + ex.ToString());
			}
		}

		// Token: 0x06001330 RID: 4912 RVA: 0x00075FAC File Offset: 0x000741AC
		public static void ForceQuitHandler(HttpListenerRequest req, HttpListenerResponse _)
		{
			Logger.Info("Quiting BlueStacksUI");
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				bool flag = false;
				try
				{
					flag = Convert.ToBoolean(requestData.Data["softclose"], CultureInfo.InvariantCulture);
				}
				catch
				{
				}
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					if (flag)
					{
						BlueStacksUIUtils.DictWindows[requestData.RequestVmName].CloseWindow();
					}
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						App.ExitApplication();
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ForceQuit... Err : " + ex.ToString());
			}
		}

		// Token: 0x06001331 RID: 4913 RVA: 0x0007608C File Offset: 0x0007428C
		public static void OpenGoogleHandler(HttpListenerRequest req, HttpListenerResponse _)
		{
			RequestData requestData = HTTPUtils.ParseRequest(req);
			string tabName = "tab_" + (new Random().Next(100) + 1).ToString();
			if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
			{
				BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mTopBar.mAppTabButtons.AddWebTab("http://www.google.com", tabName, "cef_tab", true, "", false);
				}), new object[0]);
			}
		}

		// Token: 0x06001332 RID: 4914 RVA: 0x0007611C File Offset: 0x0007431C
		private static void WriteSuccessJsonWithVmName(string vmName, HttpListenerResponse res)
		{
			HTTPUtils.Write(new JArray
			{
				new JObject
				{
					new JProperty("success", true),
					new JProperty("vmname", vmName)
				}
			}.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x06001333 RID: 4915 RVA: 0x00076174 File Offset: 0x00074374
		public static void UnsupportedCPUError(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string reason = requestData.Data["PlusFailureReason"];
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						string localizedString = LocaleStrings.GetLocalizedString("STRING_INCOMPATIBLE_FRONTEND_QUIT_CAPTION");
						if (System.Windows.Forms.MessageBox.Show(LocaleStrings.GetLocalizedString("STRING_INCOMPATIBLE_FRONTEND_QUIT"), localizedString, MessageBoxButtons.OK) == DialogResult.OK)
						{
							Logger.Info("Quit BlueStacksUI End with reason {0}", new object[]
							{
								reason
							});
							HTTPHandler.WriteSuccessJsonArray(res);
							BlueStacksUIUtils.DictWindows[requestData.RequestVmName].ForceCloseWindow();
						}
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in QuitBlueStacksUI: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x06001334 RID: 4916 RVA: 0x0007623C File Offset: 0x0007443C
		public static void UpdateUserInfoHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string text = requestData.Data["result"].Trim();
				if (BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mPostOtsWelcomeWindow != null)
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mPostOtsWelcomeWindow.ChangeBasedonTokenReceived(text);
				}
				if (text.Equals("true", StringComparison.InvariantCultureIgnoreCase) && BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mTopBar.ChangeUserPremiumButton(RegistryManager.Instance.IsPremium);
					}), new object[0]);
					PromotionManager.CheckIsUserPremium();
					Action<bool> appRecommendationHandler = PromotionObject.AppRecommendationHandler;
					if (appRecommendationHandler != null)
					{
						appRecommendationHandler(false);
					}
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						if (BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mLaunchStartupTabWhenTokenReceived && PromotionObject.Instance.StartupTab.Count > 0)
						{
							BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Utils.HandleGenericActionFromDictionary(PromotionObject.Instance.StartupTab, "startup_action", "");
						}
					}), new object[0]);
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in UpdateUserInfoHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x06001335 RID: 4917 RVA: 0x0007639C File Offset: 0x0007459C
		internal static void AppInstallStarted(HttpListenerRequest req, HttpListenerResponse _)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.Data.AllKeys)
				{
					Logger.Info("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.Data[text]
					});
				}
				string apkPath = requestData.Data["filePath"];
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					string package = string.Empty;
					string appName = string.Empty;
					DownloadInstallApk downloader = new DownloadInstallApk(BlueStacksUIUtils.DictWindows[requestData.RequestVmName]);
					if (string.Equals(Path.GetExtension(apkPath), ".xapk", StringComparison.InvariantCultureIgnoreCase))
					{
						JToken jtoken = Utils.ExtractInfoFromXapk(apkPath);
						if (jtoken != null)
						{
							package = jtoken.GetValue("package_name");
							appName = jtoken.GetValue("name");
							Logger.Debug("Package name from manifest.json.." + package);
						}
					}
					else
					{
						AppInfoExtractor apkInfo = AppInfoExtractor.GetApkInfo(apkPath);
						appName = apkInfo.AppName;
						package = apkInfo.PackageName;
					}
					HTTPHandler.dictFileNamesPackageName[apkPath] = package;
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mWelcomeTab.mHomeApp.AddAppIcon(package, appName, string.Empty, downloader);
						BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mWelcomeTab.mHomeApp.ApkInstallStart(package, apkPath);
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GetUserInfo: " + ex.ToString());
			}
		}

		// Token: 0x06001336 RID: 4918 RVA: 0x0007657C File Offset: 0x0007477C
		public static void AppInstallFailed(HttpListenerRequest req, HttpListenerResponse _)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.Data.AllKeys)
				{
					Logger.Debug("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.Data[text]
					});
				}
				string apkPath = requestData.Data["filePath"];
				int errorCode = Convert.ToInt32(requestData.Data["errorCode"], CultureInfo.InvariantCulture);
				string vmName = requestData.RequestVmName;
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
				{
					BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
					{
						try
						{
							BlueStacksUIUtils.DictWindows[vmName].mWelcomeTab.mHomeApp.ApkInstallFailed(HTTPHandler.dictFileNamesPackageName[apkPath]);
							HTTPHandler.ShowErrorPromptIfNeeded(vmName, errorCode);
						}
						catch (Exception ex2)
						{
							Logger.Error("error in install failed http call: {0}", new object[]
							{
								ex2
							});
						}
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in AppInstallFailed. Err : " + ex.ToString());
			}
		}

		// Token: 0x06001337 RID: 4919 RVA: 0x00076688 File Offset: 0x00074888
		private static void ShowErrorPromptIfNeeded(string vmName, int errorCode)
		{
			string text = string.Empty;
			if (errorCode == 10)
			{
				text = LocaleStrings.GetLocalizedString("STRING_INVALID_APK_BLACKLISTED_ERROR");
			}
			else
			{
				text = LocaleStrings.GetLocalizedString("STRING_INVALID_APK_BLACKLISTED_ERROR");
			}
			if (!string.IsNullOrEmpty(text))
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_INSTALLATION_ERROR");
				customMessageWindow.BodyTextBlock.Text = text;
				customMessageWindow.AddButton(ButtonColors.Blue, LocaleStrings.GetLocalizedString("STRING_OK"), null, null, false, null);
				customMessageWindow.Owner = BlueStacksUIUtils.DictWindows[vmName];
				BlueStacksUIUtils.DictWindows[vmName].ShowDimOverlay(null);
				customMessageWindow.ShowDialog();
				BlueStacksUIUtils.DictWindows[vmName].HideDimOverlay();
			}
		}

		// Token: 0x06001338 RID: 4920 RVA: 0x00076734 File Offset: 0x00074934
		public static void GooglePlayAppInstall(HttpListenerRequest req, HttpListenerResponse _)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				foreach (string text in requestData.Data.AllKeys)
				{
					Logger.Info("Key: {0}, Value: {1}", new object[]
					{
						text,
						requestData.Data[text]
					});
				}
				string packageName = requestData.Data["packageName"];
				string appName = requestData.Data["appName"];
				string isAdditionalFile = requestData.Data["isAdditionalFile"];
				string status = requestData.Data["status"];
				if (!string.IsNullOrEmpty(status) && BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						AppIcon appIcon = BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mWelcomeTab.mHomeApp.GetAppIcon(packageName);
						if (appIcon == null || !appIcon.mIsAppInstalled)
						{
							if (status.Equals("STARTED", StringComparison.InvariantCultureIgnoreCase))
							{
								BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mWelcomeTab.mHomeApp.AddAppIcon(packageName, appName, string.Empty, null);
								BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mWelcomeTab.mHomeApp.ApkInstallStart(packageName, string.Empty);
							}
							if (status.Equals("SUCCESS", StringComparison.InvariantCultureIgnoreCase) && isAdditionalFile.Equals("false", StringComparison.OrdinalIgnoreCase))
							{
								BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mWelcomeTab.mHomeApp.ApkInstallCompleted(packageName);
								return;
							}
							if (status.Equals("CANCELED", StringComparison.InvariantCultureIgnoreCase))
							{
								BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mWelcomeTab.mHomeApp.RemoveAppIcon(packageName, null);
							}
						}
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GooglePlayAppInstall: " + ex.ToString());
			}
		}

		// Token: 0x06001339 RID: 4921 RVA: 0x00076898 File Offset: 0x00074A98
		internal static void ChangeTextOTSHandler(HttpListenerRequest req, HttpListenerResponse _)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIBinding.Bind(BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mFrontendOTSControl.mBaseControl.mTitleLabel, "STRING_WELCOME_TO_BLUESTACKS");
						string str = "string set after change text OTS ..";
						object content = BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mFrontendOTSControl.mBaseControl.mTitleLabel.Content;
						Logger.Info(str + ((content != null) ? content.ToString() : null));
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("error in change ots text." + ex.ToString());
			}
		}

		// Token: 0x0600133A RID: 4922 RVA: 0x0007692C File Offset: 0x00074B2C
		internal static void ShootingModeChanged(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mFrontendHandler.IsShootingModeActivated = Convert.ToBoolean(requestData.Data["IsShootingModeActivated"], CultureInfo.InvariantCulture);
						if (BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mFrontendHandler.IsShootingModeActivated)
						{
							BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mFullscreenSidebarPopup.IsOpen = false;
							return;
						}
						BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mCommonHandler.ClipMouseCursorHandler(false, false, "", "");
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Shooting Mode Changed: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x0600133B RID: 4923 RVA: 0x000769CC File Offset: 0x00074BCC
		internal static void ChangeOrientaionHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string packagename = requestData.Data["package"].ToString(CultureInfo.InvariantCulture);
				bool isPortrait = Convert.ToBoolean(requestData.Data["is_portrait"], CultureInfo.InvariantCulture);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Frontend_OrientationChanged(packagename, isPortrait);
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ChangeOrientaionHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x0600133C RID: 4924 RVA: 0x00076A78 File Offset: 0x00074C78
		internal static void ShowGrmAndLaunchAppHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string packageName = requestData.Data["package"].ToString(CultureInfo.InvariantCulture);
				string vmName = requestData.RequestVmName;
				BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
				{
					if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName) && BlueStacksUIUtils.DictWindows[vmName].mWelcomeTab.mHomeApp.GetAppIcon(packageName) != null)
					{
						BlueStacksUIUtils.DictWindows[vmName].mWelcomeTab.mHomeApp.GetAppIcon(packageName).OpenApp(true);
					}
				}), new object[0]);
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ShowGrmAndLaunchAppHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x0600133D RID: 4925 RVA: 0x00076B24 File Offset: 0x00074D24
		internal static void UpdateSizeOfOverlay(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						try
						{
							IntPtr mLastMappableWindowHandle = new IntPtr(Convert.ToInt32(requestData.Data["handle"], CultureInfo.InvariantCulture));
							BlueStacksUIUtils.DictWindows[requestData.RequestVmName].StaticComponents.mLastMappableWindowHandle = mLastMappableWindowHandle;
							if (KMManager.dictOverlayWindow.ContainsKey(BlueStacksUIUtils.DictWindows[requestData.RequestVmName]))
							{
								KMManager.dictOverlayWindow[BlueStacksUIUtils.DictWindows[requestData.RequestVmName]].UpdateSize();
							}
						}
						catch (Exception ex2)
						{
							Logger.Error("Exception in UpdateSizeOfOverlay: " + ex2.ToString());
							HTTPHandler.WriteErrorJsonArray(ex2.Message, res);
						}
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in UpdateSizeOfOverlay: " + ex.ToString());
				HTTPHandler.WriteErrorJsonArray(ex.Message, res);
			}
		}

		// Token: 0x0600133E RID: 4926 RVA: 0x00076BD0 File Offset: 0x00074DD0
		internal static void BootFailedPopupHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].Utils.SendGuestBootFailureStats("com exception");
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in BootFailedPopupHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x0600133F RID: 4927 RVA: 0x00076C4C File Offset: 0x00074E4C
		internal static void DragDropInstallHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.RequestVmName;
				string apkPath = requestData.Data["filePath"].ToString(CultureInfo.InvariantCulture);
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					new DownloadInstallApk(BlueStacksUIUtils.DictWindows[requestVmName]).InstallApk(apkPath, true);
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in DragDropInstallHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06001340 RID: 4928 RVA: 0x00076CE4 File Offset: 0x00074EE4
		internal static void DeviceProvisionedHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.RequestVmName;
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].mAppHandler.IsOneTimeSetupCompleted = true;
					Stats.SendUnifiedInstallStatsAsync("device_provisioned", "");
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in DeviceProvisionedHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06001341 RID: 4929 RVA: 0x00076D74 File Offset: 0x00074F74
		internal static void GoogleSigninHandler(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string requestVmName = requestData.RequestVmName;
				string email = requestData.Data["email"].ToString(CultureInfo.InvariantCulture).Trim();
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestData.RequestVmName))
				{
					RegistryManager.Instance.Guest[requestData.RequestVmName].IsGoogleSigninDone = true;
					Stats.SendUnifiedInstallStatsAsync("google_login_completed", email);
					BlueStacksUIUtils.DictWindows[requestData.RequestVmName].PostGoogleSigninCompleteTask();
					Publisher.PublishMessage(BrowserControlTags.googleSigninComplete, string.Empty, requestData.RequestVmName);
				}
				HTTPHandler.WriteSuccessJsonArray(res);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in GoogleSigninHandler: " + ex.ToString());
				HTTPHandler.WriteErrorJSONObjectWithoutReason(res);
			}
		}

		// Token: 0x06001342 RID: 4930 RVA: 0x00076E44 File Offset: 0x00075044
		internal static void SetDMMKeymapping(HttpListenerRequest req, HttpListenerResponse _)
		{
			Logger.Info("Got SetKeymapping {0} request from {1}", new object[]
			{
				req.HttpMethod,
				req.RemoteEndPoint.ToString()
			});
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.RequestVmName;
				string package = requestData.Data["package"].ToString(CultureInfo.InvariantCulture);
				bool isKeymapEnabled = Convert.ToBoolean(requestData.Data["enablekeymap"], CultureInfo.InvariantCulture);
				Logger.Info("package : " + package + " enablekeymap : " + isKeymapEnabled.ToString());
				if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
				{
					int retries = 3;
					Action <>9__0;
					while (retries > 0)
					{
						Dispatcher dispatcher = BlueStacksUIUtils.DictWindows[vmName].Dispatcher;
						Action method;
						if ((method = <>9__0) == null)
						{
							method = (<>9__0 = delegate()
							{
								if (BlueStacksUIUtils.DictWindows[vmName].Visibility == Visibility.Visible && BlueStacksUIUtils.DictWindows[vmName].mTopBar.mAppTabButtons.mDictTabs.ContainsKey(package))
								{
									retries = 0;
									BlueStacksUIUtils.DictWindows[vmName].mTopBar.mAppTabButtons.mDictTabs[package].IsDMMKeymapEnabled = isKeymapEnabled;
								}
							});
						}
						dispatcher.Invoke(method, new object[0]);
						if (retries > 0)
						{
							int retries2 = retries;
							retries = retries2 - 1;
							Thread.Sleep(1000);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in Server SetKeymapping: " + ex.ToString());
			}
		}

		// Token: 0x06001343 RID: 4931 RVA: 0x00076FB8 File Offset: 0x000751B8
		internal static void ReloadShortcuts(HttpListenerRequest req, HttpListenerResponse _)
		{
			try
			{
				string requestVmName = HTTPUtils.ParseRequest(req).RequestVmName;
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestVmName))
				{
					BlueStacksUIUtils.DictWindows[requestVmName].Dispatcher.Invoke(new Action(delegate()
					{
						CommonHandlers.ReloadShortcutsForAllInstances();
					}), new object[0]);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ReloadShortcuts: " + ex.ToString());
			}
		}

		// Token: 0x06001344 RID: 4932 RVA: 0x00077044 File Offset: 0x00075244
		internal static void ReloadPromotions(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				string requestVmName = HTTPUtils.ParseRequest(req).RequestVmName;
				if (BlueStacksUIUtils.DictWindows.ContainsKey(requestVmName))
				{
					PromotionManager.ReloadPromotionsAsync();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in ReloadPromotions: " + ex.ToString());
			}
		}

		// Token: 0x06001345 RID: 4933 RVA: 0x0007709C File Offset: 0x0007529C
		internal static void HandleOverlayControlsVisibility(HttpListenerRequest req, HttpListenerResponse res)
		{
			try
			{
				RequestData requestData = HTTPUtils.ParseRequest(req);
				string vmName = requestData.RequestVmName;
				BlueStacksUIUtils.DictWindows[vmName].Dispatcher.Invoke(new Action(delegate()
				{
					if (BlueStacksUIUtils.DictWindows.ContainsKey(vmName))
					{
						KMManager.sOldGameControlsEnabledDisabledArray = KMManager.sGameControlsEnabledDisabledArray;
						KMManager.sGameControlsEnabledDisabledArray = requestData.Data["data"].ToString(CultureInfo.InvariantCulture);
						KMManager.ShowOverlayWindow(BlueStacksUIUtils.DictWindows[vmName], true, false);
					}
				}), new object[0]);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in HandleOverlayControlsVisibility: " + ex.ToString());
			}
		}

		// Token: 0x04000BFF RID: 3071
		private static object sLockObject = new object();

		// Token: 0x04000C00 RID: 3072
		internal static string lastPackage = string.Empty;

		// Token: 0x04000C01 RID: 3073
		private static Dictionary<string, string> dictFileNamesPackageName = new Dictionary<string, string>();

		// Token: 0x04000C02 RID: 3074
		private static bool mSendGamepadStats = false;

		// Token: 0x04000C03 RID: 3075
		private static object syncRoot = new object();

		// Token: 0x04000C04 RID: 3076
		private static string mPreviousActivityReported = "";
	}
}
