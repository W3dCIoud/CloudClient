﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000E9 RID: 233
	public class RecommendedAppItem : UserControl, IComponentConnector
	{
		// Token: 0x06000982 RID: 2434 RVA: 0x00008131 File Offset: 0x00006331
		public RecommendedAppItem()
		{
			this.InitializeComponent();
		}

		// Token: 0x170001E2 RID: 482
		// (get) Token: 0x06000983 RID: 2435 RVA: 0x0000813F File Offset: 0x0000633F
		// (set) Token: 0x06000984 RID: 2436 RVA: 0x00008147 File Offset: 0x00006347
		internal SearchRecommendation SearchRecomendation { get; set; }

		// Token: 0x170001E3 RID: 483
		// (get) Token: 0x06000985 RID: 2437 RVA: 0x00008150 File Offset: 0x00006350
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x06000986 RID: 2438 RVA: 0x0003737C File Offset: 0x0003557C
		internal void Populate(MainWindow parentWindow, SearchRecommendation recom)
		{
			this.mMainWindow = parentWindow;
			this.recomIcon.IsFullImagePath = true;
			this.recomIcon.ImageName = recom.ImagePath;
			this.installButton.ButtonColor = ButtonColors.Green;
			this.installButton.Content = (this.ParentWindow.mAppHandler.IsAppInstalled(recom.ExtraPayload["click_action_packagename"]) ? LocaleStrings.GetLocalizedString("STRING_PLAY") : LocaleStrings.GetLocalizedString("STRING_INSTALL"));
			this.appNameTextBlock.Text = recom.ExtraPayload["click_action_title"];
			this.SearchRecomendation = recom;
		}

		// Token: 0x06000987 RID: 2439 RVA: 0x00037420 File Offset: 0x00035620
		private void Recommendation_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				ClientStats.SendFrontendClickStats("search_suggestion_click", "", (this.SearchRecomendation.ExtraPayload["click_generic_action"] == "InstallCDN") ? "cdn" : "gplay", this.SearchRecomendation.ExtraPayload["click_action_packagename"], this.ParentWindow.mAppHandler.IsAppInstalled(this.SearchRecomendation.ExtraPayload["click_action_packagename"]) ? "true" : "false", null, null, null);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while sending stats to cloud for search_suggestion_click " + ex.ToString());
			}
			this.ParentWindow.Utils.HandleGenericActionFromDictionary(this.SearchRecomendation.ExtraPayload, "search_suggestion", "");
		}

		// Token: 0x06000988 RID: 2440 RVA: 0x00008171 File Offset: 0x00006371
		private void UserControl_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "SearchGridBackgroundHoverColor");
		}

		// Token: 0x06000989 RID: 2441 RVA: 0x000073CB File Offset: 0x000055CB
		private void UserControl_MouseLeave(object sender, MouseEventArgs e)
		{
			base.Background = Brushes.Transparent;
		}

		// Token: 0x0600098A RID: 2442 RVA: 0x00037504 File Offset: 0x00035704
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/recommendedappitem.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600098B RID: 2443 RVA: 0x00037534 File Offset: 0x00035734
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((RecommendedAppItem)target).MouseUp += new MouseButtonEventHandler(this.Recommendation_Click);
				((RecommendedAppItem)target).MouseEnter += this.UserControl_MouseEnter;
				((RecommendedAppItem)target).MouseLeave += this.UserControl_MouseLeave;
				return;
			case 2:
				this.recomIcon = (CustomPictureBox)target;
				return;
			case 3:
				this.appNameTextBlock = (TextBlock)target;
				return;
			case 4:
				this.installButton = (CustomButton)target;
				this.installButton.Click += this.Recommendation_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040005EF RID: 1519
		private MainWindow mMainWindow;

		// Token: 0x040005F0 RID: 1520
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox recomIcon;

		// Token: 0x040005F1 RID: 1521
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock appNameTextBlock;

		// Token: 0x040005F2 RID: 1522
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton installButton;

		// Token: 0x040005F3 RID: 1523
		private bool _contentLoaded;
	}
}
