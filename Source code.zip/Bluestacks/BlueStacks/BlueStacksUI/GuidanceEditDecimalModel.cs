﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000047 RID: 71
	[Serializable]
	public class GuidanceEditDecimalModel : GuidanceEditModel
	{
	}
}
