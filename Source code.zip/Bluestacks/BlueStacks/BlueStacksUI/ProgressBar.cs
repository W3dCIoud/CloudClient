﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000229 RID: 553
	public class ProgressBar : UserControl, IDimOverlayControl, IComponentConnector
	{
		// Token: 0x170002A6 RID: 678
		// (get) Token: 0x060013A6 RID: 5030 RVA: 0x0000D74D File Offset: 0x0000B94D
		// (set) Token: 0x060013A7 RID: 5031 RVA: 0x0000D75A File Offset: 0x0000B95A
		public string ProgressText
		{
			get
			{
				return this.mLabel.Text;
			}
			set
			{
				BlueStacksUIBinding.Bind(this.mLabel, value, "");
				if (string.IsNullOrEmpty(this.mLabel.Text))
				{
					this.mLabel.Visibility = Visibility.Collapsed;
				}
			}
		}

		// Token: 0x170002A7 RID: 679
		// (get) Token: 0x060013A8 RID: 5032 RVA: 0x00006230 File Offset: 0x00004430
		// (set) Token: 0x060013A9 RID: 5033 RVA: 0x00005D29 File Offset: 0x00003F29
		public bool IsCloseOnOverLayClick
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		// Token: 0x170002A8 RID: 680
		// (get) Token: 0x060013AA RID: 5034 RVA: 0x00006230 File Offset: 0x00004430
		// (set) Token: 0x060013AB RID: 5035 RVA: 0x00005D29 File Offset: 0x00003F29
		public bool ShowControlInSeparateWindow
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		// Token: 0x060013AC RID: 5036 RVA: 0x0000D78B File Offset: 0x0000B98B
		public ProgressBar()
		{
			this.InitializeComponent();
		}

		// Token: 0x060013AD RID: 5037 RVA: 0x0000681D File Offset: 0x00004A1D
		public bool Close()
		{
			base.Visibility = Visibility.Hidden;
			return true;
		}

		// Token: 0x060013AE RID: 5038 RVA: 0x0000624E File Offset: 0x0000444E
		public bool Show()
		{
			base.Visibility = Visibility.Visible;
			return true;
		}

		// Token: 0x060013AF RID: 5039 RVA: 0x00077EA8 File Offset: 0x000760A8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/progressbar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060013B0 RID: 5040 RVA: 0x00077ED8 File Offset: 0x000760D8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mProgressBar = (ProgressBar)target;
				return;
			case 2:
				this.mLoadingImage = (CustomPictureBox)target;
				return;
			case 3:
				this.mLabel = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000C66 RID: 3174
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ProgressBar mProgressBar;

		// Token: 0x04000C67 RID: 3175
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mLoadingImage;

		// Token: 0x04000C68 RID: 3176
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mLabel;

		// Token: 0x04000C69 RID: 3177
		private bool _contentLoaded;
	}
}
