﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000140 RID: 320
	[Flags]
	public enum RawMouseFlags : ushort
	{
		// Token: 0x040008A6 RID: 2214
		MoveRelative = 0,
		// Token: 0x040008A7 RID: 2215
		MoveAbsolute = 1,
		// Token: 0x040008A8 RID: 2216
		VirtualDesktop = 2,
		// Token: 0x040008A9 RID: 2217
		AttributesChanged = 4
	}
}
