﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000A5 RID: 165
	public class BlueStacksAdvancedExit : UserControl, IDimOverlayControl, IComponentConnector
	{
		// Token: 0x170001B4 RID: 436
		// (get) Token: 0x0600066D RID: 1645 RVA: 0x00006230 File Offset: 0x00004430
		// (set) Token: 0x0600066E RID: 1646 RVA: 0x00005D29 File Offset: 0x00003F29
		bool IDimOverlayControl.IsCloseOnOverLayClick
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		// Token: 0x170001B5 RID: 437
		// (get) Token: 0x0600066F RID: 1647 RVA: 0x00006233 File Offset: 0x00004433
		// (set) Token: 0x06000670 RID: 1648 RVA: 0x0000623B File Offset: 0x0000443B
		public bool ShowControlInSeparateWindow { get; set; } = true;

		// Token: 0x06000671 RID: 1649 RVA: 0x00006244 File Offset: 0x00004444
		bool IDimOverlayControl.Close()
		{
			this.Close();
			return true;
		}

		// Token: 0x06000672 RID: 1650 RVA: 0x0000624E File Offset: 0x0000444E
		bool IDimOverlayControl.Show()
		{
			base.Visibility = Visibility.Visible;
			return true;
		}

		// Token: 0x06000673 RID: 1651 RVA: 0x00006258 File Offset: 0x00004458
		public BlueStacksAdvancedExit(MainWindow window)
		{
			this.ParentWindow = window;
			this.InitializeComponent();
			this.AddOptions();
		}

		// Token: 0x06000674 RID: 1652 RVA: 0x0000628A File Offset: 0x0000448A
		private void AddOptions()
		{
			this.GenerateOptions("STRING_QUIT_BLUESTACKS", LocaleStringsConstants.ExitOptions);
			this.AddLineSeperator();
			this.GenerateOptions("STRING_RESTART", LocaleStringsConstants.RestartOptions);
			this.AddLineSeperator();
			this.GenerateCheckBox();
		}

		// Token: 0x06000675 RID: 1653 RVA: 0x00026A34 File Offset: 0x00024C34
		private void AddLineSeperator()
		{
			Border border = new Border
			{
				Opacity = 0.5,
				Height = 1.0,
				Margin = new Thickness(0.0, 10.0, 0.0, 0.0)
			};
			BlueStacksUIBinding.BindColor(border, Border.BackgroundProperty, "SettingsWindowTabMenuItemForeground");
			this.mOptionsStackPanel.Children.Add(border);
		}

		// Token: 0x06000676 RID: 1654 RVA: 0x00026AB8 File Offset: 0x00024CB8
		private void GenerateCheckBox()
		{
			CustomCheckbox customCheckbox = new CustomCheckbox();
			BlueStacksUIBinding.Bind(customCheckbox, "STRING_DOWNLOAD_GOOGLE_APP_POPUP_STRING_04");
			if (customCheckbox.Image != null)
			{
				customCheckbox.Image.Height = 14.0;
				customCheckbox.Image.Width = 14.0;
			}
			customCheckbox.Height = 20.0;
			customCheckbox.Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
			customCheckbox.IsChecked = new bool?(false);
			customCheckbox.Checked += this.DontShowAgainCB_Checked;
			customCheckbox.Unchecked += this.DontShowAgainCB_Unchecked;
			this.mOptionsStackPanel.Children.Add(customCheckbox);
		}

		// Token: 0x06000677 RID: 1655 RVA: 0x000062BE File Offset: 0x000044BE
		private void DontShowAgainCB_Checked(object sender, RoutedEventArgs e)
		{
			RegistryManager.Instance.IsQuitOptionSaved = true;
		}

		// Token: 0x06000678 RID: 1656 RVA: 0x000062CB File Offset: 0x000044CB
		private void DontShowAgainCB_Unchecked(object sender, RoutedEventArgs e)
		{
			RegistryManager.Instance.IsQuitOptionSaved = false;
		}

		// Token: 0x06000679 RID: 1657 RVA: 0x00026B88 File Offset: 0x00024D88
		private void GenerateOptions(string title, string[] childrenKeys)
		{
			TextBlock textBlock = new TextBlock();
			BlueStacksUIBinding.Bind(textBlock, title, "");
			textBlock.Padding = new Thickness(0.0);
			textBlock.FontSize = 16.0;
			textBlock.Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
			BlueStacksUIBinding.BindColor(textBlock, Control.ForegroundProperty, "SettingsWindowTabMenuItemSelectedForeground");
			textBlock.FontWeight = FontWeights.Normal;
			textBlock.HorizontalAlignment = HorizontalAlignment.Left;
			textBlock.VerticalAlignment = VerticalAlignment.Center;
			this.mOptionsStackPanel.Children.Add(textBlock);
			foreach (string text in childrenKeys)
			{
				CustomRadioButton customRadioButton = new CustomRadioButton();
				customRadioButton.Checked += this.Btn_Checked;
				customRadioButton.HorizontalAlignment = HorizontalAlignment.Left;
				BlueStacksUIBinding.Bind(customRadioButton, text);
				customRadioButton.Tag = text;
				customRadioButton.Margin = new Thickness(0.0, 10.0, 0.0, 5.0);
				this.mOptionsStackPanel.Children.Add(customRadioButton);
				if (text == this.mCurrentGlobalDefault)
				{
					customRadioButton.IsChecked = new bool?(true);
				}
			}
		}

		// Token: 0x0600067A RID: 1658 RVA: 0x000062D8 File Offset: 0x000044D8
		private void Btn_Checked(object sender, RoutedEventArgs e)
		{
			RegistryManager.Instance.QuitDefaultOption = (sender as CustomRadioButton).Tag.ToString();
		}

		// Token: 0x170001B6 RID: 438
		// (get) Token: 0x0600067B RID: 1659 RVA: 0x000062F4 File Offset: 0x000044F4
		public CustomButton YesButton
		{
			get
			{
				return this.mYesButton;
			}
		}

		// Token: 0x170001B7 RID: 439
		// (get) Token: 0x0600067C RID: 1660 RVA: 0x000062FC File Offset: 0x000044FC
		public CustomButton NoButton
		{
			get
			{
				return this.mNoButton;
			}
		}

		// Token: 0x170001B8 RID: 440
		// (get) Token: 0x0600067D RID: 1661 RVA: 0x00006304 File Offset: 0x00004504
		public CustomPictureBox CrossButton
		{
			get
			{
				return this.mCrossButtonPictureBox;
			}
		}

		// Token: 0x0600067E RID: 1662 RVA: 0x00026CE0 File Offset: 0x00024EE0
		internal bool Close()
		{
			try
			{
				BlueStacksUIUtils.CloseContainerWindow(this);
				this.ParentWindow.HideDimOverlay();
				base.Visibility = Visibility.Hidden;
				return true;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while trying to close the advanced exit from dimoverlay " + ex.ToString());
			}
			return false;
		}

		// Token: 0x0600067F RID: 1663 RVA: 0x0000630C File Offset: 0x0000450C
		private void Close_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.Close();
		}

		// Token: 0x06000680 RID: 1664 RVA: 0x0000630C File Offset: 0x0000450C
		private void MYesButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.Close();
		}

		// Token: 0x06000681 RID: 1665 RVA: 0x0000630C File Offset: 0x0000450C
		private void MNoButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.Close();
		}

		// Token: 0x06000682 RID: 1666 RVA: 0x00026D34 File Offset: 0x00024F34
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/bluestacksadvancedexit.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000683 RID: 1667 RVA: 0x00026D64 File Offset: 0x00024F64
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mCrossButtonPictureBox = (CustomPictureBox)target;
				this.mCrossButtonPictureBox.PreviewMouseLeftButtonUp += this.Close_PreviewMouseLeftButtonUp;
				return;
			case 2:
				this.mParentGrid = (Grid)target;
				return;
			case 3:
				this.mTitleGrid = (Grid)target;
				return;
			case 4:
				this.mTitleText = (TextBlock)target;
				return;
			case 5:
				this.mOptionsGrid = (Grid)target;
				return;
			case 6:
				this.mOptionsStackPanel = (StackPanel)target;
				return;
			case 7:
				this.mFooterGrid = (Grid)target;
				return;
			case 8:
				this.mNoButton = (CustomButton)target;
				this.mNoButton.PreviewMouseLeftButtonUp += this.MNoButton_PreviewMouseLeftButtonUp;
				return;
			case 9:
				this.mYesButton = (CustomButton)target;
				this.mYesButton.PreviewMouseLeftButtonUp += this.MYesButton_PreviewMouseLeftButtonUp;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400039D RID: 925
		private MainWindow ParentWindow;

		// Token: 0x0400039E RID: 926
		private string mCurrentGlobalDefault = RegistryManager.Instance.QuitDefaultOption;

		// Token: 0x0400039F RID: 927
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCrossButtonPictureBox;

		// Token: 0x040003A0 RID: 928
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mParentGrid;

		// Token: 0x040003A1 RID: 929
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mTitleGrid;

		// Token: 0x040003A2 RID: 930
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mTitleText;

		// Token: 0x040003A3 RID: 931
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mOptionsGrid;

		// Token: 0x040003A4 RID: 932
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mOptionsStackPanel;

		// Token: 0x040003A5 RID: 933
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mFooterGrid;

		// Token: 0x040003A6 RID: 934
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mNoButton;

		// Token: 0x040003A7 RID: 935
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mYesButton;

		// Token: 0x040003A8 RID: 936
		private bool _contentLoaded;
	}
}
