﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000E7 RID: 231
	public class QuitPopupBrowserControl : UserControl, IDimOverlayControl, IComponentConnector
	{
		// Token: 0x170001D4 RID: 468
		// (get) Token: 0x06000956 RID: 2390 RVA: 0x00007F80 File Offset: 0x00006180
		// (set) Token: 0x06000957 RID: 2391 RVA: 0x00007F88 File Offset: 0x00006188
		public string mPackage { get; set; } = "";

		// Token: 0x170001D5 RID: 469
		// (get) Token: 0x06000958 RID: 2392 RVA: 0x00007F91 File Offset: 0x00006191
		// (set) Token: 0x06000959 RID: 2393 RVA: 0x00007F99 File Offset: 0x00006199
		public string mUrl { get; set; } = string.Empty;

		// Token: 0x170001D6 RID: 470
		// (get) Token: 0x0600095A RID: 2394 RVA: 0x00007FA2 File Offset: 0x000061A2
		// (set) Token: 0x0600095B RID: 2395 RVA: 0x00007FAA File Offset: 0x000061AA
		public bool mForceReload { get; set; }

		// Token: 0x170001D7 RID: 471
		// (get) Token: 0x0600095C RID: 2396 RVA: 0x00007FB3 File Offset: 0x000061B3
		// (set) Token: 0x0600095D RID: 2397 RVA: 0x00007FBB File Offset: 0x000061BB
		public bool ShowOnQuit { get; set; }

		// Token: 0x0600095E RID: 2398 RVA: 0x00007FC4 File Offset: 0x000061C4
		public QuitPopupBrowserControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x170001D8 RID: 472
		// (get) Token: 0x0600095F RID: 2399 RVA: 0x00006230 File Offset: 0x00004430
		// (set) Token: 0x06000960 RID: 2400 RVA: 0x00005D29 File Offset: 0x00003F29
		bool IDimOverlayControl.IsCloseOnOverLayClick
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		// Token: 0x170001D9 RID: 473
		// (get) Token: 0x06000961 RID: 2401 RVA: 0x00007FEF File Offset: 0x000061EF
		// (set) Token: 0x06000962 RID: 2402 RVA: 0x00007FF7 File Offset: 0x000061F7
		public bool ShowControlInSeparateWindow { get; set; } = true;

		// Token: 0x06000963 RID: 2403 RVA: 0x00036D40 File Offset: 0x00034F40
		public void CloseControl()
		{
			ClientStats.SendMiscellaneousStatsAsync("quitpopupclosed", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, WebHelper.GetUrlWithParams(this.mUrl), this.mPackage, null, null, null, null);
			Logger.Info("Is mFirebaseBrowserControl null : " + ((this.ParentWindow.FirebaseBrowserControlGrid == null) ? "true" : "false"));
			this.mGrid.Children.Remove(this.ParentWindow.FirebaseBrowserControlGrid);
			Logger.Info("Is mFirebaseBrowserControl null : " + ((this.ParentWindow.FirebaseBrowserControlGrid == null) ? "true" : "false"));
			this.ParentWindow.mContentGrid.Children.Add(this.ParentWindow.FirebaseBrowserControlGrid);
			this.ParentWindow.FirebaseBrowserControlGrid.Visibility = Visibility.Hidden;
			foreach (object obj in this.ParentWindow.FirebaseBrowserControlGrid.Children)
			{
				BrowserControl browserControl = obj as BrowserControl;
				if (browserControl != null)
				{
					object[] args = new object[]
					{
						false
					};
					browserControl.CefBrowser.CallJs("onBrowserVisibilityChange", args);
					break;
				}
			}
			if (!this.mCloseClicked)
			{
				this.ParentWindow.mTopBar.mAppTabButtons.mLastPackageForQuitPopupDisplayed = "";
			}
			base.Visibility = Visibility.Hidden;
		}

		// Token: 0x06000964 RID: 2404 RVA: 0x00036EBC File Offset: 0x000350BC
		bool IDimOverlayControl.Close()
		{
			try
			{
				base.Visibility = Visibility.Hidden;
				this.CloseControl();
				return true;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while trying to close quitpopup from dimoverlay " + ex.ToString());
			}
			return false;
		}

		// Token: 0x06000965 RID: 2405 RVA: 0x00008000 File Offset: 0x00006200
		public void SetQuitPopParams(string url, string package, bool isForceReload, bool showOnQuit)
		{
			this.mUrl = url;
			this.mForceReload = isForceReload;
			this.mPackage = package;
			this.ShowOnQuit = showOnQuit;
		}

		// Token: 0x06000966 RID: 2406 RVA: 0x00036F08 File Offset: 0x00035108
		public void Init(MainWindow window, string appPackage)
		{
			this.ParentWindow = window;
			this.mPackage = appPackage;
			if (window != null)
			{
				Logger.Info("Is mFirebaseBrowserControl null : " + ((window.FirebaseBrowserControlGrid == null) ? "true" : "false"));
				window.mContentGrid.Children.Remove(window.FirebaseBrowserControlGrid);
				Logger.Info("Is mFirebaseBrowserControl null : " + ((window.FirebaseBrowserControlGrid == null) ? "true" : "false"));
				this.mGrid.Children.Add(window.FirebaseBrowserControlGrid);
				window.FirebaseBrowserControlGrid.Visibility = Visibility.Visible;
				foreach (object obj in this.ParentWindow.FirebaseBrowserControlGrid.Children)
				{
					BrowserControl browserControl = obj as BrowserControl;
					if (browserControl != null)
					{
						object[] args = new object[]
						{
							true
						};
						browserControl.CefBrowser.CallJs("onBrowserVisibilityChange", args);
						break;
					}
				}
			}
			if (string.IsNullOrEmpty(appPackage))
			{
				this.mCloseButton.Content = LocaleStrings.GetLocalizedString("STRING_CLOSE_BLUESTACKS");
			}
			else
			{
				this.mCloseButton.Content = LocaleStrings.GetLocalizedString("STRING_CLOSE_GAME");
			}
			this.mCloseClicked = false;
		}

		// Token: 0x06000967 RID: 2407 RVA: 0x0000624E File Offset: 0x0000444E
		bool IDimOverlayControl.Show()
		{
			base.Visibility = Visibility.Visible;
			return true;
		}

		// Token: 0x06000968 RID: 2408 RVA: 0x0000801F File Offset: 0x0000621F
		private void CloseButton_Click(object sender, RoutedEventArgs e)
		{
			this.Close();
		}

		// Token: 0x06000969 RID: 2409 RVA: 0x0003705C File Offset: 0x0003525C
		public void Close()
		{
			try
			{
				this.mCloseClicked = true;
				this.ParentWindow.HideDimOverlay();
				if (string.IsNullOrEmpty(this.mPackage))
				{
					this.ParentWindow.ForceCloseWindow();
				}
				else
				{
					this.ParentWindow.mTopBar.mAppTabButtons.CloseTab(this.mPackage, true, false, false, false, "");
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception when trying to close quit popup. " + ex.ToString());
			}
		}

		// Token: 0x0600096A RID: 2410 RVA: 0x000370E4 File Offset: 0x000352E4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/quitpopupbrowsercontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600096B RID: 2411 RVA: 0x00037114 File Offset: 0x00035314
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mGrid = (Grid)target;
				return;
			}
			if (connectionId != 2)
			{
				this._contentLoaded = true;
				return;
			}
			this.mCloseButton = (CustomButton)target;
			this.mCloseButton.Click += this.CloseButton_Click;
		}

		// Token: 0x040005D6 RID: 1494
		private MainWindow ParentWindow;

		// Token: 0x040005D8 RID: 1496
		private bool mCloseClicked;

		// Token: 0x040005DD RID: 1501
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mGrid;

		// Token: 0x040005DE RID: 1502
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mCloseButton;

		// Token: 0x040005DF RID: 1503
		private bool _contentLoaded;
	}
}
