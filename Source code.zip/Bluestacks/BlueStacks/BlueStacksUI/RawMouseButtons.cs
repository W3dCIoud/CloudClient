﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000141 RID: 321
	[Flags]
	public enum RawMouseButtons : ushort
	{
		// Token: 0x040008AB RID: 2219
		None = 0,
		// Token: 0x040008AC RID: 2220
		LeftDown = 1,
		// Token: 0x040008AD RID: 2221
		LeftUp = 2,
		// Token: 0x040008AE RID: 2222
		RightDown = 4,
		// Token: 0x040008AF RID: 2223
		RightUp = 8,
		// Token: 0x040008B0 RID: 2224
		MiddleDown = 16,
		// Token: 0x040008B1 RID: 2225
		MiddleUp = 32,
		// Token: 0x040008B2 RID: 2226
		Button4Down = 64,
		// Token: 0x040008B3 RID: 2227
		Button4Up = 128,
		// Token: 0x040008B4 RID: 2228
		Button5Down = 256,
		// Token: 0x040008B5 RID: 2229
		Button5Up = 512,
		// Token: 0x040008B6 RID: 2230
		MouseWheel = 1024
	}
}
