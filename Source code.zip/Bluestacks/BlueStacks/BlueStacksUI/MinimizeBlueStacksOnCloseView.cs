﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200004F RID: 79
	public class MinimizeBlueStacksOnCloseView : UserControl, IComponentConnector
	{
		// Token: 0x060003B3 RID: 947 RVA: 0x00004889 File Offset: 0x00002A89
		public MinimizeBlueStacksOnCloseView(MainWindow window)
		{
			this.InitializeComponent();
			base.DataContext = new MinimizeBlueStacksOnCloseViewModel(window);
		}

		// Token: 0x060003B4 RID: 948 RVA: 0x0001A050 File Offset: 0x00018250
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/minimizebluestacksonclose/view/minimizebluestacksoncloseview.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060003B5 RID: 949 RVA: 0x0001A080 File Offset: 0x00018280
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mTitleGrid = (Grid)target;
				return;
			case 2:
				this.mCrossButtonPictureBox = (CustomPictureBox)target;
				return;
			case 3:
				this.mTitleText = (TextBlock)target;
				return;
			case 4:
				this.mHeaderText = (TextBlock)target;
				return;
			case 5:
				this.mMinimizeRadioBtn = (CustomRadioButton)target;
				return;
			case 6:
				this.mMinimizeBtnBodyText = (TextBlock)target;
				return;
			case 7:
				this.mQuitRadioBtn = (CustomRadioButton)target;
				return;
			case 8:
				this.mQuitBtnBodyText = (TextBlock)target;
				return;
			case 9:
				this.mDoNotShowChkBox = (CustomCheckbox)target;
				return;
			case 10:
				this.mBtnActionPanel = (StackPanel)target;
				return;
			case 11:
				this.mCancelBtn = (CustomButton)target;
				return;
			case 12:
				this.mMinimizeBtn = (CustomButton)target;
				return;
			case 13:
				this.mQuitBtn = (CustomButton)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040001ED RID: 493
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mTitleGrid;

		// Token: 0x040001EE RID: 494
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCrossButtonPictureBox;

		// Token: 0x040001EF RID: 495
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mTitleText;

		// Token: 0x040001F0 RID: 496
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mHeaderText;

		// Token: 0x040001F1 RID: 497
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mMinimizeRadioBtn;

		// Token: 0x040001F2 RID: 498
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mMinimizeBtnBodyText;

		// Token: 0x040001F3 RID: 499
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mQuitRadioBtn;

		// Token: 0x040001F4 RID: 500
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mQuitBtnBodyText;

		// Token: 0x040001F5 RID: 501
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mDoNotShowChkBox;

		// Token: 0x040001F6 RID: 502
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mBtnActionPanel;

		// Token: 0x040001F7 RID: 503
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mCancelBtn;

		// Token: 0x040001F8 RID: 504
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mMinimizeBtn;

		// Token: 0x040001F9 RID: 505
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mQuitBtn;

		// Token: 0x040001FA RID: 506
		private bool _contentLoaded;
	}
}
