﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media.Imaging;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000188 RID: 392
	public class CustomToggleButton : UserControl, IComponentConnector
	{
		// Token: 0x1700026B RID: 619
		// (set) Token: 0x06000F32 RID: 3890 RVA: 0x0000B0CB File Offset: 0x000092CB
		public bool HideIcon
		{
			set
			{
				if (value)
				{
					this.mIconColDef.Width = new GridLength(0.0);
				}
			}
		}

		// Token: 0x1700026C RID: 620
		// (get) Token: 0x06000F33 RID: 3891 RVA: 0x0000B0E9 File Offset: 0x000092E9
		// (set) Token: 0x06000F34 RID: 3892 RVA: 0x0000B0F6 File Offset: 0x000092F6
		public string AppLabel
		{
			get
			{
				return this.mAppLabel.Text;
			}
			set
			{
				BlueStacksUIBinding.Bind(this.mAppLabel, value, "");
			}
		}

		// Token: 0x1700026D RID: 621
		// (set) Token: 0x06000F35 RID: 3893 RVA: 0x0000B109 File Offset: 0x00009309
		public Orientation CheckBoxOrientation
		{
			set
			{
				this.mMuteCheckBox.Orientation = value;
				this.mAutoHideCheckBox.Orientation = value;
				Grid.SetRow(this.mAppLabel, 1);
				Grid.SetRowSpan(this.mAppLabel, 1);
			}
		}

		// Token: 0x1700026E RID: 622
		// (set) Token: 0x06000F36 RID: 3894 RVA: 0x0000B13B File Offset: 0x0000933B
		public bool IsThreeStateCheckBox
		{
			set
			{
				this.mMuteCheckBox.IsThreeState = value;
				this.mAutoHideCheckBox.IsThreeState = value;
			}
		}

		// Token: 0x1700026F RID: 623
		// (set) Token: 0x06000F37 RID: 3895 RVA: 0x0000B155 File Offset: 0x00009355
		public Visibility CheckBoxLabelVisibility
		{
			set
			{
				this.mMuteCheckBox.LabelVisibility = value;
				this.mAutoHideCheckBox.LabelVisibility = value;
			}
		}

		// Token: 0x17000270 RID: 624
		// (set) Token: 0x06000F38 RID: 3896 RVA: 0x0000B16F File Offset: 0x0000936F
		public BitmapImage Image
		{
			set
			{
				this.mAppImage.Source = value;
				if (value != null)
				{
					this.mAppImage.ImageName = string.Empty;
				}
			}
		}

		// Token: 0x17000271 RID: 625
		// (get) Token: 0x06000F39 RID: 3897 RVA: 0x0000B190 File Offset: 0x00009390
		public bool? IsMuted
		{
			get
			{
				return this.mMuteCheckBox.IsChecked;
			}
		}

		// Token: 0x17000272 RID: 626
		// (get) Token: 0x06000F3A RID: 3898 RVA: 0x0000B19D File Offset: 0x0000939D
		public bool? IsAutoHide
		{
			get
			{
				return this.mAutoHideCheckBox.IsChecked;
			}
		}

		// Token: 0x06000F3B RID: 3899 RVA: 0x0000B1AA File Offset: 0x000093AA
		public void HideAppLable()
		{
			this.mAppLableColDef.Width = new GridLength(0.0);
			this.mIconColDef.Width = new GridLength(0.0);
		}

		// Token: 0x06000F3C RID: 3900 RVA: 0x0000B1DE File Offset: 0x000093DE
		public void HideShowButton()
		{
			this.mShowColDef.Width = new GridLength(0.0);
			this.mIconColDef.Width = new GridLength(0.0);
		}

		// Token: 0x06000F3D RID: 3901 RVA: 0x0000B212 File Offset: 0x00009412
		public CustomToggleButton()
		{
			this.InitializeComponent();
			this.SetProperties();
		}

		// Token: 0x06000F3E RID: 3902 RVA: 0x0000B226 File Offset: 0x00009426
		private void SetProperties()
		{
			BlueStacksUIBinding.Bind(this.mMuteCheckBox, "STRING_SHOW");
			BlueStacksUIBinding.Bind(this.mAutoHideCheckBox, "STRING_AUTO_HIDE");
		}

		// Token: 0x06000F3F RID: 3903 RVA: 0x00062044 File Offset: 0x00060244
		private void MuteButton_Checked(object sender, RoutedEventArgs e)
		{
			if (this.mAutoHideCheckBox.IsChecked != null && !this.mAutoHideCheckBox.IsChecked.Value && base.IsLoaded)
			{
				NotificationManager.Instance.UpdateMuteState(MuteState.NotMuted, this.AppLabel);
			}
		}

		// Token: 0x06000F40 RID: 3904 RVA: 0x0000B248 File Offset: 0x00009448
		private void MuteButton_Unchecked(object sender, RoutedEventArgs e)
		{
			this.mAutoHideCheckBox.IsChecked = new bool?(false);
			if (base.IsLoaded)
			{
				NotificationManager.Instance.UpdateMuteState(MuteState.MutedForever, this.AppLabel);
			}
		}

		// Token: 0x06000F41 RID: 3905 RVA: 0x0000B274 File Offset: 0x00009474
		private void MuteCheckBox_Indeterminate(object sender, RoutedEventArgs e)
		{
			if (base.IsLoaded)
			{
				NotificationManager.Instance.UpdateMuteState(MuteState.MutedForever, this.AppLabel);
			}
		}

		// Token: 0x06000F42 RID: 3906 RVA: 0x0000B28F File Offset: 0x0000948F
		private void AutoHideButton_Checked(object sender, RoutedEventArgs e)
		{
			this.mMuteCheckBox.IsChecked = new bool?(true);
			if (base.IsLoaded)
			{
				NotificationManager.Instance.UpdateMuteState(MuteState.AutoHide, this.AppLabel);
			}
		}

		// Token: 0x06000F43 RID: 3907 RVA: 0x0000B2BB File Offset: 0x000094BB
		private void AutoHideButton_Unchecked(object sender, RoutedEventArgs e)
		{
			if (base.IsLoaded)
			{
				NotificationManager.Instance.UpdateMuteState(MuteState.NotMuted, this.AppLabel);
			}
		}

		// Token: 0x06000F44 RID: 3908 RVA: 0x0000B274 File Offset: 0x00009474
		private void AutoHideCheckBox_Indeterminate(object sender, RoutedEventArgs e)
		{
			if (base.IsLoaded)
			{
				NotificationManager.Instance.UpdateMuteState(MuteState.MutedForever, this.AppLabel);
			}
		}

		// Token: 0x06000F45 RID: 3909 RVA: 0x00062094 File Offset: 0x00060294
		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			if (NotificationManager.Instance.IsNotificationMutedForKey(this.AppLabel) == MuteState.AutoHide)
			{
				this.mAutoHideCheckBox.IsChecked = new bool?(true);
				return;
			}
			if (NotificationManager.Instance.IsNotificationMutedForKey(this.AppLabel) == MuteState.NotMuted)
			{
				this.mMuteCheckBox.IsChecked = new bool?(true);
				return;
			}
			this.mMuteCheckBox.IsChecked = new bool?(false);
			this.mAutoHideCheckBox.IsChecked = new bool?(false);
		}

		// Token: 0x06000F46 RID: 3910 RVA: 0x0006210C File Offset: 0x0006030C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/settingswindows/customtogglebutton.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000F47 RID: 3911 RVA: 0x0006213C File Offset: 0x0006033C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((CustomToggleButton)target).Loaded += this.UserControl_Loaded;
				return;
			case 2:
				this.mIconColDef = (ColumnDefinition)target;
				return;
			case 3:
				this.mAppLableColDef = (ColumnDefinition)target;
				return;
			case 4:
				this.mShowColDef = (ColumnDefinition)target;
				return;
			case 5:
				this.mAppImage = (CustomPictureBox)target;
				return;
			case 6:
				this.mAppLabel = (TextBlock)target;
				return;
			case 7:
				this.mMuteCheckBox = (CustomCheckbox)target;
				this.mMuteCheckBox.Checked += this.MuteButton_Checked;
				this.mMuteCheckBox.Unchecked += this.MuteButton_Unchecked;
				this.mMuteCheckBox.Indeterminate += this.MuteCheckBox_Indeterminate;
				return;
			case 8:
				this.mAutoHideCheckBox = (CustomCheckbox)target;
				this.mAutoHideCheckBox.Checked += this.AutoHideButton_Checked;
				this.mAutoHideCheckBox.Unchecked += this.AutoHideButton_Unchecked;
				this.mAutoHideCheckBox.Indeterminate += this.AutoHideCheckBox_Indeterminate;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000A40 RID: 2624
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ColumnDefinition mIconColDef;

		// Token: 0x04000A41 RID: 2625
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ColumnDefinition mAppLableColDef;

		// Token: 0x04000A42 RID: 2626
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ColumnDefinition mShowColDef;

		// Token: 0x04000A43 RID: 2627
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mAppImage;

		// Token: 0x04000A44 RID: 2628
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mAppLabel;

		// Token: 0x04000A45 RID: 2629
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mMuteCheckBox;

		// Token: 0x04000A46 RID: 2630
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mAutoHideCheckBox;

		// Token: 0x04000A47 RID: 2631
		private bool _contentLoaded;
	}
}
