﻿using System;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000046 RID: 70
	[Serializable]
	public class GuidanceEditTextModel : GuidanceEditModel
	{
		// Token: 0x17000135 RID: 309
		// (get) Token: 0x06000350 RID: 848 RVA: 0x000043A3 File Offset: 0x000025A3
		// (set) Token: 0x06000351 RID: 849 RVA: 0x000043AB File Offset: 0x000025AB
		public TextValidityOptions TextValidityOption
		{
			get
			{
				return this.mTextValidityOption;
			}
			set
			{
				base.SetProperty<TextValidityOptions>(ref this.mTextValidityOption, value, null);
			}
		}

		// Token: 0x040001CF RID: 463
		private TextValidityOptions mTextValidityOption = TextValidityOptions.Success;
	}
}
