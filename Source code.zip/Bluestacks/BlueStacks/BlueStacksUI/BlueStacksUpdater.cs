﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Net;
using System.Threading;
using System.Windows;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200016A RID: 362
	internal class BlueStacksUpdater
	{
		// Token: 0x17000220 RID: 544
		// (get) Token: 0x06000DE4 RID: 3556 RVA: 0x0000A4E1 File Offset: 0x000086E1
		// (set) Token: 0x06000DE5 RID: 3557 RVA: 0x0000A4E8 File Offset: 0x000086E8
		internal static bool IsDownloadingInHiddenMode { get; set; } = true;

		// Token: 0x17000221 RID: 545
		// (get) Token: 0x06000DE6 RID: 3558 RVA: 0x0000A4F0 File Offset: 0x000086F0
		// (set) Token: 0x06000DE7 RID: 3559 RVA: 0x0000A4F7 File Offset: 0x000086F7
		internal static BlueStacksUpdater.UpdateState SUpdateState
		{
			get
			{
				return BlueStacksUpdater.sUpdateState;
			}
			set
			{
				BlueStacksUpdater.sUpdateState = value;
				Action stateChanged = BlueStacksUpdater.StateChanged;
				if (stateChanged == null)
				{
					return;
				}
				stateChanged();
			}
		}

		// Token: 0x1400000A RID: 10
		// (add) Token: 0x06000DE8 RID: 3560 RVA: 0x0005BE68 File Offset: 0x0005A068
		// (remove) Token: 0x06000DE9 RID: 3561 RVA: 0x0005BE9C File Offset: 0x0005A09C
		internal static event Action<Tuple<BlueStacksUpdateData, bool>> DownloadCompleted;

		// Token: 0x1400000B RID: 11
		// (add) Token: 0x06000DEA RID: 3562 RVA: 0x0005BED0 File Offset: 0x0005A0D0
		// (remove) Token: 0x06000DEB RID: 3563 RVA: 0x0005BF04 File Offset: 0x0005A104
		internal static event Action StateChanged;

		// Token: 0x06000DEC RID: 3564 RVA: 0x0005BF38 File Offset: 0x0005A138
		public static void SetupBlueStacksUpdater(MainWindow window, bool isStartup)
		{
			BlueStacksUpdater.ParentWindow = window;
			if (BlueStacksUpdater.sCheckUpdateBackgroundWorker == null)
			{
				BlueStacksUpdater.sCheckUpdateBackgroundWorker = new BackgroundWorker();
				BlueStacksUpdater.sCheckUpdateBackgroundWorker.DoWork += delegate(object sender, DoWorkEventArgs e)
				{
					bool flag = (bool)e.Argument;
					BlueStacksUpdateData item = BlueStacksUpdater.CheckForUpdate(!flag);
					BlueStacksUpdater.sBstUpdateData = item;
					e.Result = new Tuple<BlueStacksUpdateData, bool>(item, flag);
				};
				BlueStacksUpdater.sCheckUpdateBackgroundWorker.RunWorkerCompleted += BlueStacksUpdater.CheckUpdateBackgroundWorker_RunWorkerCompleted;
			}
			if (!BlueStacksUpdater.sCheckUpdateBackgroundWorker.IsBusy)
			{
				BlueStacksUpdater.sCheckUpdateBackgroundWorker.RunWorkerAsync(isStartup);
				return;
			}
			Logger.Info("Not launching update checking thread, since already running");
		}

		// Token: 0x06000DED RID: 3565 RVA: 0x0005BFC4 File Offset: 0x0005A1C4
		private static void CheckUpdateBackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			Tuple<BlueStacksUpdateData, bool> tuple = (Tuple<BlueStacksUpdateData, bool>)e.Result;
			BlueStacksUpdateData item = tuple.Item1;
			bool item2 = tuple.Item2;
			if (item.IsUpdateAvailble)
			{
				BlueStacksUpdater.ParentWindow.mTopBar.mConfigButton.ImageName = "cfgmenu_update";
				BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpgradeBluestacksStatus.Visibility = Visibility.Visible;
				BlueStacksUIBinding.Bind(BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpgradeBluestacksStatusTextBlock, "STRING_DOWNLOAD_UPDATE", "");
				BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpdateDownloadProgressPercentage.Visibility = Visibility.Collapsed;
				if (!item.IsFullInstaller)
				{
					Logger.Info("Only client installer update, starting download.");
					BlueStacksUpdater.DownloadNow(item, true);
					return;
				}
				if (item2)
				{
					if (item.UpdateType.Equals("hard", StringComparison.InvariantCultureIgnoreCase))
					{
						Logger.Info("Forced full installer update, starting download.");
						BlueStacksUpdater.DownloadNow(item, true);
						return;
					}
					if (item.UpdateType.Equals("soft", StringComparison.InvariantCultureIgnoreCase) && string.Compare(item.EngineVersion.Trim(), RegistryManager.Instance.LastUpdateSkippedVersion.Trim(), StringComparison.OrdinalIgnoreCase) != 0)
					{
						ClientStats.SendBluestacksUpdaterUIStatsAsync(ClientStatsEvent.UpgradePopup, "");
						UpdatePrompt updatePrompt = new UpdatePrompt(item)
						{
							Height = 215.0,
							Width = 400.0
						};
						new ContainerWindow(BlueStacksUpdater.ParentWindow, updatePrompt, (double)((int)updatePrompt.Width), (double)((int)updatePrompt.Height), false, true);
						return;
					}
				}
			}
			else
			{
				BlueStacksUpdater.SUpdateState = BlueStacksUpdater.UpdateState.NO_UPDATE;
			}
		}

		// Token: 0x06000DEE RID: 3566 RVA: 0x0005C140 File Offset: 0x0005A340
		private static BlueStacksUpdateData CheckForUpdate(bool isManualCheck)
		{
			BlueStacksUpdateData blueStacksUpdateData = new BlueStacksUpdateData();
			BlueStacksUpdateData result;
			try
			{
				string urlWithParams = WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/check_upgrade");
				Logger.Debug("The URL for checking upgrade: {0}", new object[]
				{
					urlWithParams
				});
				string value;
				string text;
				string text2;
				SystemUtils.GetOSInfo(out value, out text, out text2);
				string value2 = InstallerArchitectures.AMD64;
				if (!SystemUtils.IsOs64Bit())
				{
					value2 = InstallerArchitectures.X86;
				}
				Dictionary<string, string> data = new Dictionary<string, string>
				{
					{
						"installer_arch",
						value2
					},
					{
						"os",
						value
					},
					{
						"manual_check",
						isManualCheck.ToString(CultureInfo.InvariantCulture)
					}
				};
				string text3 = BstHttpClient.Post(urlWithParams, data, null, false, string.Empty, 5000, 1, 0, false);
				Logger.Info("Response received for check for update: " + Environment.NewLine + text3);
				JObject jobject = JObject.Parse(text3);
				if (jobject["update_available"].ToString().Equals("true", StringComparison.InvariantCultureIgnoreCase) && RegistryManager.Instance.FailedUpgradeVersion != jobject["update_details"]["client_version"].ToString())
				{
					blueStacksUpdateData.IsUpdateAvailble = true;
					blueStacksUpdateData.UpdateType = jobject["update_details"]["upgrade_type"].ToString();
					blueStacksUpdateData.IsFullInstaller = jobject["update_details"]["is_full_installer"].ToObject<bool>();
					blueStacksUpdateData.Md5 = jobject["update_details"]["md5"].ToString();
					blueStacksUpdateData.ClientVersion = jobject["update_details"]["client_version"].ToString();
					blueStacksUpdateData.EngineVersion = jobject["update_details"]["engine_version"].ToString();
					blueStacksUpdateData.DownloadUrl = jobject["update_details"]["download_url"].ToString();
					blueStacksUpdateData.DetailedChangeLogsUrl = jobject["update_details"]["detailed_changelogs_url"].ToString();
					if (!Directory.Exists(RegistryManager.Instance.SetupFolder))
					{
						Directory.CreateDirectory(RegistryManager.Instance.SetupFolder);
					}
					if (blueStacksUpdateData.IsFullInstaller)
					{
						blueStacksUpdateData.UpdateDownloadLocation = Path.Combine(RegistryManager.Instance.SetupFolder, "BlueStacksInstaller_" + blueStacksUpdateData.ClientVersion + "_full.exe");
					}
					else
					{
						blueStacksUpdateData.UpdateDownloadLocation = Path.Combine(RegistryManager.Instance.SetupFolder, "BlueStacksInstaller_" + blueStacksUpdateData.ClientVersion + "_client.zip");
					}
					RegistryManager.Instance.DownloadedUpdateFile = blueStacksUpdateData.UpdateDownloadLocation;
					BlueStacksUpdater.sBstUpdateData = blueStacksUpdateData;
					BlueStacksUpdater.SUpdateState = BlueStacksUpdater.UpdateState.UPDATE_AVAILABLE;
				}
				result = blueStacksUpdateData;
			}
			catch (Exception ex)
			{
				Logger.Warning("Got error in checking for upgrade: {0}", new object[]
				{
					ex.ToString()
				});
				blueStacksUpdateData = new BlueStacksUpdateData
				{
					IsTryAgain = true
				};
				result = blueStacksUpdateData;
			}
			return result;
		}

		// Token: 0x06000DEF RID: 3567 RVA: 0x0005C438 File Offset: 0x0005A638
		private static void DownloadUpdate(BlueStacksUpdateData bluestacksUpdateData)
		{
			BlueStacksUpdater.sDownloader = new Downloader();
			BlueStacksUpdater.sDownloader.DownloadException += BlueStacksUpdater.Downloader_DownloadException;
			BlueStacksUpdater.sDownloader.DownloadProgressPercentChanged += BlueStacksUpdater.Downloader_DownloadProgressPercentChanged;
			BlueStacksUpdater.sDownloader.DownloadFileCompleted += BlueStacksUpdater.Downloader_DownloadFileCompleted;
			BlueStacksUpdater.sDownloader.UnsupportedResume += BlueStacksUpdater.Downloader_UnsupportedResume;
			BlueStacksUpdater.sDownloader.DownloadFile(bluestacksUpdateData.DownloadUrl, bluestacksUpdateData.UpdateDownloadLocation);
		}

		// Token: 0x06000DF0 RID: 3568 RVA: 0x0005C4C0 File Offset: 0x0005A6C0
		private static void Downloader_DownloadProgressPercentChanged(double percentDouble)
		{
			Logger.Info("File downloaded {0}%", new object[]
			{
				percentDouble
			});
			int percent = Convert.ToInt32(Math.Floor(percentDouble));
			BlueStacksUpdater.ParentWindow.mTopBar.ChangeDownloadPercent(percent);
			if (BlueStacksUpdater.sUpdateDownloadProgress != null)
			{
				BlueStacksUpdater.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					BlueStacksUpdater.sUpdateDownloadProgress.mUpdateDownloadProgressPercentage.Content = percent.ToString() + "%";
					BlueStacksUpdater.sUpdateDownloadProgress.mUpdateDownloadProgressBar.Value = (double)percent;
					BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpdateDownloadProgressPercentage.Content = percent.ToString() + "%";
				}), new object[0]);
			}
		}

		// Token: 0x06000DF1 RID: 3569 RVA: 0x0005C53C File Offset: 0x0005A73C
		private static void Downloader_UnsupportedResume(HttpStatusCode sc)
		{
			Logger.Error("UnsupportedResume, HTTPStatusCode: {0}", new object[]
			{
				sc
			});
			File.Delete(BlueStacksUpdater.sBstUpdateData.UpdateDownloadLocation);
			BlueStacksUpdater.sDownloader.DownloadFile(BlueStacksUpdater.sBstUpdateData.DownloadUrl, BlueStacksUpdater.sBstUpdateData.UpdateDownloadLocation);
		}

		// Token: 0x06000DF2 RID: 3570 RVA: 0x0000A50E File Offset: 0x0000870E
		private static void Downloader_DownloadFileCompleted(object sender, EventArgs args)
		{
			string fmt = "File downloaded successfully at {0}";
			object[] array = new object[1];
			int num = 0;
			BlueStacksUpdateData blueStacksUpdateData = BlueStacksUpdater.sBstUpdateData;
			array[num] = ((blueStacksUpdateData != null) ? blueStacksUpdateData.UpdateDownloadLocation : null);
			Logger.Info(fmt, array);
			BlueStacksUpdater.DownloadComplete();
		}

		// Token: 0x06000DF3 RID: 3571 RVA: 0x0005C590 File Offset: 0x0005A790
		private static void Downloader_DownloadException(Exception e)
		{
			Logger.Error("Failed to download file: {0}. err: {1}", new object[]
			{
				BlueStacksUpdater.sBstUpdateData.DownloadUrl,
				e.Message
			});
			BlueStacksUpdater.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_UPGRADE_FAILED", "");
				BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_SOME_ERROR_OCCURED_DOWNLOAD", "");
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_RETRY", new EventHandler(BlueStacksUpdater.RetryDownload), null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", new EventHandler(BlueStacksUpdater.DownloadCancelled), null, false, null);
				BlueStacksUpdater.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.Owner = BlueStacksUpdater.ParentWindow.mDimOverlay;
				customMessageWindow.ShowDialog();
				BlueStacksUpdater.ParentWindow.HideDimOverlay();
				BlueStacksUpdater.sUpdateDownloadProgress.Hide();
			}), new object[0]);
		}

		// Token: 0x06000DF4 RID: 3572 RVA: 0x0000A539 File Offset: 0x00008739
		private static void DownloadCancelled(object sender, EventArgs e)
		{
			BlueStacksUpdater.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpgradeBluestacksStatus.Visibility = Visibility.Collapsed;
			}), new object[0]);
		}

		// Token: 0x06000DF5 RID: 3573 RVA: 0x0000A570 File Offset: 0x00008770
		private static void RetryDownload(object sender, EventArgs e)
		{
			new Thread(delegate()
			{
				BlueStacksUpdater.sDownloader.DownloadFile(BlueStacksUpdater.sBstUpdateData.DownloadUrl, BlueStacksUpdater.sBstUpdateData.UpdateDownloadLocation);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000DF6 RID: 3574 RVA: 0x0005C5F8 File Offset: 0x0005A7F8
		private static void DownloadComplete()
		{
			Logger.Info("Installer download completed");
			BlueStacksUpdater.SUpdateState = BlueStacksUpdater.UpdateState.DOWNLOADED;
			BlueStacksUpdater.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				BlueStacksUIBinding.Bind(BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpgradeBluestacksStatusTextBlock, "STRING_INSTALL_UPDATE", "");
				BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpdateDownloadProgressPercentage.Visibility = Visibility.Collapsed;
				if (BlueStacksUpdater.sUpdateDownloadProgress != null)
				{
					BlueStacksUpdater.sUpdateDownloadProgress.Close();
				}
			}), new object[0]);
			BlueStacksUpdater.DownloadCompleted(new Tuple<BlueStacksUpdateData, bool>(BlueStacksUpdater.sBstUpdateData, BlueStacksUpdater.IsDownloadingInHiddenMode));
		}

		// Token: 0x06000DF7 RID: 3575 RVA: 0x0000A5A2 File Offset: 0x000087A2
		internal static void DownloadNow(BlueStacksUpdateData bstUpdateData, bool hiddenMode)
		{
			new Thread(delegate()
			{
				BlueStacksUpdater.IsDownloadingInHiddenMode = hiddenMode;
				BlueStacksUpdater.SUpdateState = BlueStacksUpdater.UpdateState.DOWNLOADING;
				if (File.Exists(bstUpdateData.UpdateDownloadLocation))
				{
					BlueStacksUpdater.DownloadComplete();
					return;
				}
				BlueStacksUpdater.ParentWindow.Dispatcher.Invoke(new Action(delegate()
				{
					BlueStacksUIBinding.Bind(BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpgradeBluestacksStatusTextBlock, "STRING_DOWNLOADING_UPDATE", "");
					BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpdateDownloadProgressPercentage.Visibility = Visibility.Visible;
					BlueStacksUpdater.ParentWindow.mTopBar.mPreferenceDropDownControl.mUpdateDownloadProgressPercentage.Content = "0%";
					BlueStacksUpdater.sUpdateDownloadProgress = new UpdateDownloadProgress();
					BlueStacksUpdater.sUpdateDownloadProgress.mUpdateDownloadProgressPercentage.Content = "0%";
					BlueStacksUpdater.sUpdateDownloadProgress.Owner = BlueStacksUpdater.ParentWindow;
					if (!hiddenMode)
					{
						BlueStacksUpdater.sUpdateDownloadProgress.Show();
					}
				}), new object[0]);
				BlueStacksUpdater.DownloadUpdate(bstUpdateData);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000DF8 RID: 3576 RVA: 0x0000A5D3 File Offset: 0x000087D3
		internal static void ShowDownloadProgress()
		{
			if (BlueStacksUpdater.sUpdateDownloadProgress != null)
			{
				BlueStacksUpdater.sUpdateDownloadProgress.Show();
			}
		}

		// Token: 0x06000DF9 RID: 3577 RVA: 0x0005C664 File Offset: 0x0005A864
		internal static void CheckDownloadedUpdateFileAndUpdate()
		{
			using (BackgroundWorker backgroundWorker = new BackgroundWorker())
			{
				backgroundWorker.DoWork += delegate(object sender, DoWorkEventArgs args)
				{
					BlueStacksUpdater.HandleUpgrade(RegistryManager.Instance.DownloadedUpdateFile);
				};
				backgroundWorker.RunWorkerCompleted += delegate(object sender, RunWorkerCompletedEventArgs args2)
				{
					App.ExitApplication();
				};
				backgroundWorker.RunWorkerAsync();
			}
		}

		// Token: 0x06000DFA RID: 3578 RVA: 0x0000A5E6 File Offset: 0x000087E6
		internal static void HandleUpgrade(string downloadedFilePath)
		{
			if (BlueStacksUpdater.CheckIfUpdateIsFullOrClientOnly(downloadedFilePath) == BlueStacksUpdater.UpdateType.ClientOnly)
			{
				BlueStacksUpdater.HandleClientOnlyUpgrade(downloadedFilePath);
			}
			else
			{
				BlueStacksUpdater.HandleFullUpgrade(downloadedFilePath);
			}
			RegistryManager.Instance.DownloadedUpdateFile = "";
		}

		// Token: 0x06000DFB RID: 3579 RVA: 0x0000A60E File Offset: 0x0000880E
		private static void HandleFullUpgrade(string downloadedFilePath)
		{
			Logger.Info("In HandleFullUpgrade");
			BluestacksProcessHelper.RunUpdateInstaller(downloadedFilePath, "-u -upgradesourcepath BluestacksUI", false);
		}

		// Token: 0x06000DFC RID: 3580 RVA: 0x0005C6E4 File Offset: 0x0005A8E4
		private static void HandleClientOnlyUpgrade(string downloadedFilePath)
		{
			Logger.Info("In HandleClientOnlyUpgrade");
			try
			{
				int num = BlueStacksUpdater.ExtractingClientInstaller(downloadedFilePath);
				if (num == 0)
				{
					BluestacksProcessHelper.RunUpdateInstaller(Path.Combine(Path.Combine(RegistryManager.Instance.SetupFolder, Path.GetFileNameWithoutExtension(downloadedFilePath)), "Bootstrapper.exe"), "", false);
				}
				else
				{
					Logger.Warning("Update extraction failed, ExitCode: {0}", new object[]
					{
						num
					});
					File.Delete(downloadedFilePath);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Some Error in Client Upgrade err: ", new object[]
				{
					ex.ToString()
				});
			}
		}

		// Token: 0x06000DFD RID: 3581 RVA: 0x0005C780 File Offset: 0x0005A980
		internal static bool CheckIfDownloadedFileExist()
		{
			string downloadedUpdateFile = RegistryManager.Instance.DownloadedUpdateFile;
			return !string.IsNullOrEmpty(downloadedUpdateFile) && File.Exists(downloadedUpdateFile);
		}

		// Token: 0x06000DFE RID: 3582 RVA: 0x0000A626 File Offset: 0x00008826
		private static BlueStacksUpdater.UpdateType CheckIfUpdateIsFullOrClientOnly(string downloadedFilePath)
		{
			if (string.Equals(Path.GetExtension(downloadedFilePath), ".zip", StringComparison.InvariantCultureIgnoreCase))
			{
				return BlueStacksUpdater.UpdateType.ClientOnly;
			}
			return BlueStacksUpdater.UpdateType.FullUpdate;
		}

		// Token: 0x06000DFF RID: 3583 RVA: 0x0005C7AC File Offset: 0x0005A9AC
		private static int ExtractingClientInstaller(string updateFile)
		{
			string text = Path.Combine(RegistryManager.Instance.SetupFolder, Path.GetFileNameWithoutExtension(updateFile));
			Logger.Info("Extracting Zip file {0} at {1}", new object[]
			{
				updateFile,
				text
			});
			return MiscUtils.Extract7Zip(updateFile, text);
		}

		// Token: 0x04000979 RID: 2425
		private static MainWindow ParentWindow;

		// Token: 0x0400097A RID: 2426
		internal static BackgroundWorker sCheckUpdateBackgroundWorker;

		// Token: 0x0400097B RID: 2427
		private static UpdateDownloadProgress sUpdateDownloadProgress;

		// Token: 0x0400097C RID: 2428
		internal static BlueStacksUpdateData sBstUpdateData = null;

		// Token: 0x0400097D RID: 2429
		internal static Downloader sDownloader;

		// Token: 0x0400097F RID: 2431
		private static BlueStacksUpdater.UpdateState sUpdateState = BlueStacksUpdater.UpdateState.NO_UPDATE;

		// Token: 0x0200016B RID: 363
		internal enum UpdateState
		{
			// Token: 0x04000983 RID: 2435
			NO_UPDATE,
			// Token: 0x04000984 RID: 2436
			UPDATE_AVAILABLE,
			// Token: 0x04000985 RID: 2437
			DOWNLOADING,
			// Token: 0x04000986 RID: 2438
			DOWNLOADED
		}

		// Token: 0x0200016C RID: 364
		internal enum UpdateType
		{
			// Token: 0x04000988 RID: 2440
			FullUpdate,
			// Token: 0x04000989 RID: 2441
			ClientOnly
		}
	}
}
