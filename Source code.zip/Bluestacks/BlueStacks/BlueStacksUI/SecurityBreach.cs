﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000082 RID: 130
	public enum SecurityBreach
	{
		// Token: 0x040002BF RID: 703
		SCRIPT_TOOLS,
		// Token: 0x040002C0 RID: 704
		DEVICE_PROBED,
		// Token: 0x040002C1 RID: 705
		DEVICE_ROOTED,
		// Token: 0x040002C2 RID: 706
		DEVICE_PROFILE_CHANGED,
		// Token: 0x040002C3 RID: 707
		SYNTHETIC_INPUT
	}
}
