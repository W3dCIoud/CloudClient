﻿using System;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Interop;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200008F RID: 143
	public class CustomPopUp : Popup
	{
		// Token: 0x170001AD RID: 429
		// (get) Token: 0x0600058D RID: 1421 RVA: 0x00005A93 File Offset: 0x00003C93
		// (set) Token: 0x0600058E RID: 1422 RVA: 0x00005A9B File Offset: 0x00003C9B
		public bool IsFocusOnMouseClick { get; set; }

		// Token: 0x0600058F RID: 1423 RVA: 0x00005AA4 File Offset: 0x00003CA4
		private void CustomPopUp_Initialized(object sender, EventArgs e)
		{
			RenderHelper.ChangeRenderModeToSoftware(sender);
		}

		// Token: 0x170001AE RID: 430
		// (get) Token: 0x06000590 RID: 1424 RVA: 0x00005AAC File Offset: 0x00003CAC
		// (set) Token: 0x06000591 RID: 1425 RVA: 0x00005ABE File Offset: 0x00003CBE
		public bool IsTopmost
		{
			get
			{
				return (bool)base.GetValue(CustomPopUp.IsTopmostProperty);
			}
			set
			{
				base.SetValue(CustomPopUp.IsTopmostProperty, value);
			}
		}

		// Token: 0x06000592 RID: 1426 RVA: 0x000210D0 File Offset: 0x0001F2D0
		public CustomPopUp()
		{
			base.Loaded += this.OnPopupLoaded;
			base.Unloaded += this.OnPopupUnloaded;
			base.Opened += this.CustomPopUp_Initialized;
			base.PreviewMouseDown += this.CustomPopUp_PreviewMouseDown;
		}

		// Token: 0x06000593 RID: 1427 RVA: 0x0002112C File Offset: 0x0001F32C
		private void CustomPopUp_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.IsFocusOnMouseClick)
			{
				try
				{
					HwndSource hwndSource = PresentationSource.FromVisual(base.Child) as HwndSource;
					if (hwndSource != null)
					{
						InteropWindow.SetForegroundWindow(hwndSource.Handle);
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception in setting popup as foreground window: {0}", new object[]
					{
						ex
					});
				}
			}
		}

		// Token: 0x06000594 RID: 1428 RVA: 0x0002118C File Offset: 0x0001F38C
		private void OnPopupLoaded(object sender, RoutedEventArgs e)
		{
			if (this.mAlreadyLoaded)
			{
				return;
			}
			this.mAlreadyLoaded = true;
			UIElement child = base.Child;
			if (child != null)
			{
				child.AddHandler(UIElement.PreviewMouseLeftButtonDownEvent, new MouseButtonEventHandler(this.OnChildPreviewMouseLeftButtonDown), true);
			}
			this.mParentWindow = Window.GetWindow(this);
			if (this.mParentWindow == null)
			{
				return;
			}
			this.mParentWindow.Activated += this.OnParentWindowActivated;
			this.mParentWindow.Deactivated += this.OnParentWindowDeactivated;
		}

		// Token: 0x06000595 RID: 1429 RVA: 0x00005AD1 File Offset: 0x00003CD1
		private void OnPopupUnloaded(object sender, RoutedEventArgs e)
		{
			if (this.mParentWindow == null)
			{
				return;
			}
			this.mParentWindow.Activated -= this.OnParentWindowActivated;
			this.mParentWindow.Deactivated -= this.OnParentWindowDeactivated;
		}

		// Token: 0x06000596 RID: 1430 RVA: 0x00005B0A File Offset: 0x00003D0A
		private void OnParentWindowActivated(object sender, EventArgs e)
		{
			this.SetTopmostState(true);
		}

		// Token: 0x06000597 RID: 1431 RVA: 0x00005B13 File Offset: 0x00003D13
		private void OnParentWindowDeactivated(object sender, EventArgs e)
		{
			if (!this.IsTopmost)
			{
				this.SetTopmostState(this.IsTopmost);
			}
		}

		// Token: 0x06000598 RID: 1432 RVA: 0x00021210 File Offset: 0x0001F410
		private void OnChildPreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			Logger.Debug("Child Mouse Left Button Down");
			this.SetTopmostState(true);
			if (this.mParentWindow != null && !this.mParentWindow.IsActive && !this.IsTopmost)
			{
				this.mParentWindow.Activate();
				Logger.Debug("Activating Parent from child Left Button Down");
			}
		}

		// Token: 0x06000599 RID: 1433 RVA: 0x00005B29 File Offset: 0x00003D29
		private static void OnIsTopmostChanged(DependencyObject obj, DependencyPropertyChangedEventArgs _)
		{
			CustomPopUp customPopUp = (CustomPopUp)obj;
			customPopUp.SetTopmostState(customPopUp.IsTopmost);
		}

		// Token: 0x0600059A RID: 1434 RVA: 0x00005B3C File Offset: 0x00003D3C
		protected override void OnOpened(EventArgs e)
		{
			this.mParentWindow = Window.GetWindow(this);
			this.SetTopmostState(this.IsTopmost);
			base.OnOpened(e);
		}

		// Token: 0x0600059B RID: 1435 RVA: 0x00021264 File Offset: 0x0001F464
		private void SetTopmostState(bool isTop)
		{
			try
			{
				if (this.mParentWindow != null && !isTop && InteropWindow.GetTopmostOwnerWindow(this.mParentWindow).Topmost)
				{
					isTop = true;
				}
				if (this.mAppliedTopMost != null)
				{
					bool? flag = this.mAppliedTopMost;
					bool flag2 = isTop;
					if (flag.GetValueOrDefault() == flag2 & flag != null)
					{
						return;
					}
				}
				if (base.Child != null)
				{
					HwndSource hwndSource = PresentationSource.FromVisual(base.Child) as HwndSource;
					if (hwndSource != null)
					{
						IntPtr handle = hwndSource.Handle;
						RECT rect;
						if (NativeMethods.GetWindowRect(handle, out rect))
						{
							Logger.Debug("setting z-order " + isTop.ToString());
							if (isTop)
							{
								NativeMethods.SetWindowPos(handle, CustomPopUp.HWND_TOPMOST, rect.Left, rect.Top, (int)base.Width, (int)base.Height, 1563U);
							}
							else
							{
								NativeMethods.SetWindowPos(handle, CustomPopUp.HWND_BOTTOM, rect.Left, rect.Top, (int)base.Width, (int)base.Height, 1563U);
								NativeMethods.SetWindowPos(handle, CustomPopUp.HWND_TOP, rect.Left, rect.Top, (int)base.Width, (int)base.Height, 1563U);
								NativeMethods.SetWindowPos(handle, CustomPopUp.HWND_NOTOPMOST, rect.Left, rect.Top, (int)base.Width, (int)base.Height, 1563U);
							}
							this.mAppliedTopMost = new bool?(isTop);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in set topmost state in custom popup: {0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x040002FD RID: 765
		public static readonly DependencyProperty IsTopmostProperty = DependencyProperty.Register("IsTopmost", typeof(bool), typeof(CustomPopUp), new FrameworkPropertyMetadata(false, new PropertyChangedCallback(CustomPopUp.OnIsTopmostChanged)));

		// Token: 0x040002FE RID: 766
		private bool? mAppliedTopMost;

		// Token: 0x040002FF RID: 767
		private bool mAlreadyLoaded;

		// Token: 0x04000300 RID: 768
		private Window mParentWindow;

		// Token: 0x04000301 RID: 769
		private static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);

		// Token: 0x04000302 RID: 770
		private static readonly IntPtr HWND_NOTOPMOST = new IntPtr(-2);

		// Token: 0x04000303 RID: 771
		private static readonly IntPtr HWND_TOP = new IntPtr(0);

		// Token: 0x04000304 RID: 772
		private static readonly IntPtr HWND_BOTTOM = new IntPtr(1);

		// Token: 0x04000305 RID: 773
		private const uint SWP_NOSIZE = 1U;

		// Token: 0x04000306 RID: 774
		private const uint SWP_NOMOVE = 2U;

		// Token: 0x04000307 RID: 775
		private const uint SWP_NOREDRAW = 8U;

		// Token: 0x04000308 RID: 776
		private const uint SWP_NOACTIVATE = 16U;

		// Token: 0x04000309 RID: 777
		private const uint SWP_NOOWNERZORDER = 512U;

		// Token: 0x0400030A RID: 778
		private const uint SWP_NOSENDCHANGING = 1024U;

		// Token: 0x0400030B RID: 779
		private const uint TOPMOST_FLAGS = 1563U;
	}
}
