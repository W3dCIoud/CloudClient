﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200017D RID: 381
	public class NoInternetControl : UserControl, IComponentConnector
	{
		// Token: 0x06000EEE RID: 3822 RVA: 0x0000ADF5 File Offset: 0x00008FF5
		public NoInternetControl(BrowserControl browserControl)
		{
			this.InitializeComponent();
			this.AssociatedControl = browserControl;
			BlueStacksUIBinding.Bind(this.mFailureTextBox, "STRING_NAVIGATE_FAILED", "");
			BlueStacksUIBinding.Bind(this.mBlueButton, "STRING_RETRY_CONNECTION_ISSUE_TEXT1");
		}

		// Token: 0x06000EEF RID: 3823 RVA: 0x0000AE2F File Offset: 0x0000902F
		private void mBlueButton_Click(object sender, RoutedEventArgs e)
		{
			this.AssociatedControl.NavigateTo(this.AssociatedControl.mFailedUrl);
		}

		// Token: 0x06000EF0 RID: 3824 RVA: 0x0006040C File Offset: 0x0005E60C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/nointernetcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000EF1 RID: 3825 RVA: 0x0006043C File Offset: 0x0005E63C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mFailureTextBox = (TextBlock)target;
				return;
			case 2:
				this.mErrorLine1 = (TextBlock)target;
				return;
			case 3:
				this.mErrorLine2 = (TextBlock)target;
				return;
			case 4:
				this.mBlueButton = (CustomButton)target;
				this.mBlueButton.Click += this.mBlueButton_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040009F4 RID: 2548
		private BrowserControl AssociatedControl;

		// Token: 0x040009F5 RID: 2549
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mFailureTextBox;

		// Token: 0x040009F6 RID: 2550
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mErrorLine1;

		// Token: 0x040009F7 RID: 2551
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mErrorLine2;

		// Token: 0x040009F8 RID: 2552
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mBlueButton;

		// Token: 0x040009F9 RID: 2553
		private bool _contentLoaded;
	}
}
