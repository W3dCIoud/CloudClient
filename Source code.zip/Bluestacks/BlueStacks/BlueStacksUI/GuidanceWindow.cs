﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000117 RID: 279
	public class GuidanceWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x170001FE RID: 510
		// (get) Token: 0x06000AEA RID: 2794 RVA: 0x00008E53 File Offset: 0x00007053
		// (set) Token: 0x06000AEB RID: 2795 RVA: 0x0003F6B8 File Offset: 0x0003D8B8
		private bool IsViewState
		{
			get
			{
				return this.isViewState;
			}
			set
			{
				this.isViewState = value;
				this.mSchemesComboBox.IsEnabled = this.isViewState;
				if (this.isViewState)
				{
					this.mEditKeysGrid.Visibility = Visibility.Collapsed;
					this.mControlsTab.Visibility = Visibility.Visible;
					this.mSchemeTextBlock.Visibility = Visibility.Visible;
					this.mSchemesComboBox.Visibility = Visibility.Visible;
					if (PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.Contains(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName) || PackageActivityNames.ThirdParty.AllPUBGPackageNames.Contains(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName) || "com.dts.freefireth".Contains(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName) || PackageActivityNames.ThirdParty.AllSevenDeadlySinsPackageNames.Contains(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName))
					{
						this.mSettingsTab.Visibility = Visibility.Visible;
						return;
					}
				}
				else
				{
					this.mEditKeysGrid.Visibility = Visibility.Visible;
					this.mControlsTab.Visibility = Visibility.Collapsed;
					this.mSettingsTab.Visibility = Visibility.Collapsed;
					this.mSchemeTextBlock.Visibility = Visibility.Collapsed;
					this.mSchemesComboBox.Visibility = Visibility.Collapsed;
					this.mVideoGrid.Visibility = Visibility.Collapsed;
					this.mReadArticlePanel.Visibility = Visibility.Collapsed;
				}
			}
		}

		// Token: 0x170001FF RID: 511
		// (get) Token: 0x06000AEC RID: 2796 RVA: 0x00008E5B File Offset: 0x0000705B
		// (set) Token: 0x06000AED RID: 2797 RVA: 0x00008E62 File Offset: 0x00007062
		public static bool sIsDirty
		{
			get
			{
				return GuidanceWindow.IsDirty;
			}
			set
			{
				GuidanceWindow.IsDirty = value;
			}
		}

		// Token: 0x06000AEE RID: 2798 RVA: 0x0003F814 File Offset: 0x0003DA14
		internal GuidanceWindow(MainWindow window)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			base.Owner = window;
			base.IsShowGLWindow = true;
			this.mIsOnboardingPopupToBeShownOnGuidanceClose = false;
			this.ShowWithParentWindow = true;
			if (window.WindowState != WindowState.Normal)
			{
				window.RestoreWindows(false);
			}
			KMManager.CloseWindows();
			this.ResizeGuidanceWindow();
			this.mGuidanceHasBeenMoved = false;
			this.ResetGuidanceTab();
			this.Init();
			GuidanceWindow.HideOnNextLaunch(false);
		}

		// Token: 0x06000AEF RID: 2799 RVA: 0x0003F8E0 File Offset: 0x0003DAE0
		internal void CheckAndShowGeneralOnboarding()
		{
			if (!AppConfigurationManager.Instance.CheckIfTrueInAnyVm(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName, (AppSettings appSettings) => appSettings.IsGeneralAppOnBoardingCompleted))
			{
				this.InitGeneralGuidanceOnboarding();
				this.ParentWindow.HideDimOverlay();
				Sidebar mSidebar = this.ParentWindow.mSidebar;
				if (mSidebar != null)
				{
					mSidebar.ShowFullscreenOnboardingPopup();
				}
				Dictionary<string, AppSettings> dictionary = AppConfigurationManager.Instance.VmAppConfig[this.ParentWindow.mVmName];
				AppTabButtons mAppTabButtons = this.ParentWindow.mTopBar.mAppTabButtons;
				string key;
				if (mAppTabButtons == null)
				{
					key = null;
				}
				else
				{
					AppTabButton selectedTab = mAppTabButtons.SelectedTab;
					key = ((selectedTab != null) ? selectedTab.PackageName : null);
				}
				if (dictionary.ContainsKey(key))
				{
					AppConfigurationManager.Instance.VmAppConfig[this.ParentWindow.mVmName][this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName].IsGeneralAppOnBoardingCompleted = true;
					AppConfigurationManager.Instance.VmAppConfig[this.ParentWindow.mVmName][this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName].IsCloseGuidanceOnboardingCompleted = false;
				}
			}
		}

		// Token: 0x06000AF0 RID: 2800 RVA: 0x0003FA24 File Offset: 0x0003DC24
		internal void Init()
		{
			if (PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.Contains(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName) || PackageActivityNames.ThirdParty.AllPUBGPackageNames.Contains(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName) || "com.dts.freefireth".Contains(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName) || PackageActivityNames.ThirdParty.AllSevenDeadlySinsPackageNames.Contains(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName))
			{
				this.mSettingsTab.Visibility = Visibility.Visible;
				this.mGuidanceWindowSettings.Init(this.ParentWindow);
			}
			else
			{
				this.mSettingsTab.Visibility = Visibility.Collapsed;
			}
			this.FillProfileComboBox();
		}

		// Token: 0x06000AF1 RID: 2801 RVA: 0x0003FAFC File Offset: 0x0003DCFC
		internal void InitUI()
		{
			GuidanceWindow.IsDirty = false;
			this.mGuidanceData.Clear();
			foreach (IMAction imaction in this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls)
			{
				if (imaction.Type == KeyActionType.Pan)
				{
					this.lstPanTags.Add(this.ParentWindow.SelectedConfig.SelectedControlScheme.Name);
				}
				else if (imaction.Type == KeyActionType.MOBADpad)
				{
					this.lstMOBATags.Add(this.ParentWindow.SelectedConfig.SelectedControlScheme.Name);
				}
				string category = string.Empty;
				if (this.ParentWindow.SelectedConfig.SelectedControlScheme.IsCategoryVisible)
				{
					category = (string.Equals(imaction.GuidanceCategory.Trim(), "MISC", StringComparison.InvariantCulture) ? LocaleStrings.GetLocalizedString("STRING_" + imaction.GuidanceCategory.Trim()) : this.ParentWindow.SelectedConfig.GetUIString(imaction.GuidanceCategory.Trim()));
				}
				Dictionary<string, string> dictionary = imaction.Guidance.DeepCopy<Dictionary<string, string>>();
				if (imaction.Type == KeyActionType.Dpad)
				{
					dictionary.Clear();
					foreach (object obj in Enum.GetValues(typeof(DPadControls)))
					{
						DPadControls dpadControls = (DPadControls)obj;
						if (imaction.Guidance.ContainsKey(dpadControls.ToString()))
						{
							dictionary.Add(dpadControls.ToString(), imaction.Guidance[dpadControls.ToString()]);
						}
					}
				}
				foreach (KeyValuePair<string, string> keyValuePair in dictionary)
				{
					string str = string.Empty;
					MOBASkill mobaskill = imaction as MOBASkill;
					if (mobaskill != null && keyValuePair.Key.Contains("KeyActivate"))
					{
						str = GuidanceWindow.AppendMOBASkillModeInGuidance(mobaskill);
					}
					bool flag = keyValuePair.Key.Contains("Gamepad", StringComparison.InvariantCultureIgnoreCase);
					if (!flag && IMAction.DictPropertyInfo[imaction.Type].ContainsKey(keyValuePair.Key))
					{
						this.mGuidanceData.AddGuidance(false, category, this.ParentWindow.SelectedConfig.GetUIString(imaction.Guidance[keyValuePair.Key]) + str, imaction[keyValuePair.Key].ToString(), keyValuePair.Key, imaction);
					}
					string text = flag ? keyValuePair.Key : (keyValuePair.Key + "_alt1");
					if (IMAction.DictPropertyInfo[imaction.Type].ContainsKey(text))
					{
						this.mGuidanceData.AddGuidance(true, category, this.ParentWindow.SelectedConfig.GetUIString(imaction.Guidance[keyValuePair.Key]) + str, imaction[text].ToString(), text, imaction);
					}
				}
			}
			this.mGamepadIcon.Visibility = ((this.mGuidanceData.GamepadViewGuidance.Count > 0) ? Visibility.Visible : Visibility.Collapsed);
			this.mGuidanceData.SaveOriginalData();
			if (this.mGuidanceData.GamepadViewGuidance.Count > 0 || this.mGuidanceData.KeymapViewGuidance.Count > 0)
			{
				this.mKeyboardIcon.Visibility = Visibility.Visible;
				this.separator.Visibility = Visibility.Visible;
				this.noGameGuidePanel.Visibility = Visibility.Collapsed;
				this.AddVideoElementInUI();
			}
			else
			{
				this.mKeyboardIcon.Visibility = Visibility.Collapsed;
				this.separator.Visibility = Visibility.Collapsed;
				this.noGameGuidePanel.Visibility = Visibility.Visible;
			}
			this.ShowGuidance();
		}

		// Token: 0x06000AF2 RID: 2802 RVA: 0x0003FF24 File Offset: 0x0003E124
		private static string AppendMOBASkillModeInGuidance(MOBASkill mobaSkill)
		{
			string result = string.Empty;
			if (!mobaSkill.AdvancedMode && !mobaSkill.AutocastEnabled)
			{
				result = string.Format(CultureInfo.InvariantCulture, " (" + LocaleStrings.GetLocalizedString("STRING_MANUAL_MODE") + ")", new object[0]);
			}
			else if (mobaSkill.AdvancedMode && !mobaSkill.AutocastEnabled)
			{
				result = string.Format(CultureInfo.InvariantCulture, " (" + LocaleStrings.GetLocalizedString("STRING_AUTOCAST") + ")", new object[0]);
			}
			else if (mobaSkill.AdvancedMode && mobaSkill.AutocastEnabled)
			{
				result = string.Format(CultureInfo.InvariantCulture, " (" + LocaleStrings.GetLocalizedString("STRING_QUICK_CAST") + ")", new object[0]);
			}
			return result;
		}

		// Token: 0x06000AF3 RID: 2803 RVA: 0x0003FFEC File Offset: 0x0003E1EC
		private void ResetGuidanceTab()
		{
			this.mIsGamePadTabSelected = false;
			this.mGamepadIconImage.ImageName = "guidance_gamepad";
			BlueStacksUIBinding.BindColor(this.mGamepadIconSeparator, Panel.BackgroundProperty, "HorizontalSeparator");
			this.mKeyboardIconImage.ImageName = "guidance_controls_hover";
			BlueStacksUIBinding.BindColor(this.mKeyboardIconSeparator, Panel.BackgroundProperty, "SettingsWindowTabMenuItemUnderline");
		}

		// Token: 0x06000AF4 RID: 2804 RVA: 0x0003DF10 File Offset: 0x0003C110
		private int CompareSchemesAlphabetically(IMControlScheme x, IMControlScheme y)
		{
			string text = x.Name.ToLower(CultureInfo.InvariantCulture).Trim();
			string text2 = y.Name.ToLower(CultureInfo.InvariantCulture).Trim();
			if (text.Contains(text2))
			{
				return 1;
			}
			if (text2.Contains(text))
			{
				return -1;
			}
			if (string.CompareOrdinal(text, text2) < 0)
			{
				return -1;
			}
			return 1;
		}

		// Token: 0x06000AF5 RID: 2805 RVA: 0x0004004C File Offset: 0x0003E24C
		internal void OrderingControlSchemes()
		{
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			this.ParentWindow.SelectedConfig.ControlSchemes.Sort(new Comparison<IMControlScheme>(this.CompareSchemesAlphabetically));
			foreach (IMControlScheme imcontrolScheme in new List<IMControlScheme>(this.ParentWindow.SelectedConfig.ControlSchemes))
			{
				if (imcontrolScheme.BuiltIn)
				{
					if (imcontrolScheme.IsBookMarked)
					{
						this.ParentWindow.SelectedConfig.ControlSchemes.Remove(imcontrolScheme);
						this.ParentWindow.SelectedConfig.ControlSchemes.Insert(num3, imcontrolScheme);
						num3++;
						num2++;
						num++;
					}
					else
					{
						this.ParentWindow.SelectedConfig.ControlSchemes.Remove(imcontrolScheme);
						this.ParentWindow.SelectedConfig.ControlSchemes.Insert(num2, imcontrolScheme);
						num2++;
						num++;
					}
				}
				else if (imcontrolScheme.IsBookMarked)
				{
					this.ParentWindow.SelectedConfig.ControlSchemes.Remove(imcontrolScheme);
					this.ParentWindow.SelectedConfig.ControlSchemes.Insert(num, imcontrolScheme);
					num++;
				}
			}
		}

		// Token: 0x06000AF6 RID: 2806 RVA: 0x000401A0 File Offset: 0x0003E3A0
		internal void FillProfileComboBox()
		{
			this.OrderingControlSchemes();
			this.mSchemesComboBox.Items.Clear();
			if (this.ParentWindow.SelectedConfig.ControlSchemes != null && this.ParentWindow.SelectedConfig.ControlSchemes.Count > 0)
			{
				bool flag = false;
				foreach (IMControlScheme imcontrolScheme in this.ParentWindow.SelectedConfig.ControlSchemesDict.Values)
				{
					ComboBoxItem comboBoxItem = new ComboBoxItem
					{
						Content = imcontrolScheme.Name
					};
					if (string.Equals(imcontrolScheme.Name, this.ParentWindow.SelectedConfig.SelectedControlScheme.Name, StringComparison.InvariantCulture))
					{
						comboBoxItem.IsSelected = true;
						flag = true;
					}
					comboBoxItem.ToolTip = comboBoxItem.Content;
					this.mSchemesComboBox.Items.Add(comboBoxItem);
				}
				if (!flag)
				{
					((ComboBoxItem)this.mSchemesComboBox.Items[0]).IsSelected = true;
				}
				this.mSchemePanel.Visibility = ((this.ParentWindow.SelectedConfig.ControlSchemesDict.Count == 1) ? Visibility.Collapsed : Visibility.Visible);
				this.InitUI();
			}
		}

		// Token: 0x06000AF7 RID: 2807 RVA: 0x000402EC File Offset: 0x0003E4EC
		private void AddVideoElementInUI()
		{
			foreach (AppInfo appInfo in new JsonParser(Strings.CurrentDefaultVmName).GetAppList().ToList<AppInfo>())
			{
				if (string.Equals(appInfo.Package, KMManager.sPackageName, StringComparison.InvariantCulture))
				{
					this.mIsGuidanceVideoPresent = appInfo.VideoPresent;
				}
			}
			this.UpdateVideoElement(this.mIsGamePadTabSelected);
		}

		// Token: 0x06000AF8 RID: 2808 RVA: 0x00040374 File Offset: 0x0003E574
		private void UpdateVideoElement(bool isGamepadTabSelected = false)
		{
			if (isGamepadTabSelected)
			{
				KMManager.sVideoMode = GuidanceVideoType.Gamepad;
			}
			else if (this.lstMOBATags.Contains(this.ParentWindow.SelectedConfig.SelectedControlScheme.Name) || this.lstMOBATags.Contains("GlobalValidTag"))
			{
				KMManager.sVideoMode = GuidanceVideoType.Moba;
			}
			else if (this.lstPanTags.Contains(this.ParentWindow.SelectedConfig.SelectedControlScheme.Name) || this.lstPanTags.Contains("GlobalValidTag"))
			{
				KMManager.sVideoMode = GuidanceVideoType.Pan;
			}
			else
			{
				KMManager.sVideoMode = GuidanceVideoType.Default;
			}
			this.UpdateTutorialGrid();
			this.UpdateReadArticleGrid();
		}

		// Token: 0x06000AF9 RID: 2809 RVA: 0x00040418 File Offset: 0x0003E618
		private void UpdateTutorialGrid()
		{
			string text = "";
			try
			{
				Dictionary<string, CustomThumbnail> customThumbnails = GuidanceCloudInfoManager.Instance.mGuidanceCloudInfo.CustomThumbnails;
				Dictionary<GuidanceVideoType, VideoThumbnailInfo> defaultThumbnails = GuidanceCloudInfoManager.Instance.mGuidanceCloudInfo.DefaultThumbnails;
				if (customThumbnails.ContainsKey(KMManager.sPackageName))
				{
					if (KMManager.sVideoMode == GuidanceVideoType.Gamepad && customThumbnails[KMManager.sPackageName][KMManager.sVideoMode.ToString()] != null)
					{
						text = ((VideoThumbnailInfo)customThumbnails[KMManager.sPackageName][KMManager.sVideoMode.ToString()]).ImagePath;
					}
					else if (customThumbnails[KMManager.sPackageName][GuidanceVideoType.SchemeSpecific.ToString()] != null && ((Dictionary<string, VideoThumbnailInfo>)customThumbnails[KMManager.sPackageName][GuidanceVideoType.SchemeSpecific.ToString()]).ContainsKey(this.ParentWindow.SelectedConfig.SelectedControlScheme.Name))
					{
						string name = this.ParentWindow.SelectedConfig.SelectedControlScheme.Name;
						text = ((Dictionary<string, VideoThumbnailInfo>)customThumbnails[KMManager.sPackageName][GuidanceVideoType.SchemeSpecific.ToString()])[name].ImagePath;
						KMManager.sVideoMode = GuidanceVideoType.SchemeSpecific;
					}
					else if (customThumbnails[KMManager.sPackageName][GuidanceVideoType.Special.ToString()] != null)
					{
						text = ((VideoThumbnailInfo)customThumbnails[KMManager.sPackageName][GuidanceVideoType.Special.ToString()]).ImagePath;
						KMManager.sVideoMode = GuidanceVideoType.Special;
					}
					else if (customThumbnails[KMManager.sPackageName][KMManager.sVideoMode.ToString()] != null)
					{
						text = ((VideoThumbnailInfo)customThumbnails[KMManager.sPackageName][KMManager.sVideoMode.ToString()]).ImagePath;
					}
				}
				else if (defaultThumbnails.ContainsKey(KMManager.sVideoMode))
				{
					text = defaultThumbnails[KMManager.sVideoMode].ImagePath;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in evaluating tutorial grid : " + ex.ToString());
			}
			this.mVideoThumbnail.ImageName = text;
			this.mVideoGrid.Visibility = (string.IsNullOrEmpty(text) ? Visibility.Collapsed : Visibility.Visible);
		}

		// Token: 0x06000AFA RID: 2810 RVA: 0x00040688 File Offset: 0x0003E888
		private void UpdateReadArticleGrid()
		{
			try
			{
				Dictionary<string, HelpArticle> helpArticles = GuidanceCloudInfoManager.Instance.mGuidanceCloudInfo.HelpArticles;
				if (helpArticles.ContainsKey(KMManager.sPackageName) && helpArticles[KMManager.sPackageName][KMManager.sVideoMode.ToString()] != null)
				{
					string name = this.ParentWindow.SelectedConfig.SelectedControlScheme.Name;
					Dictionary<string, HelpArticleInfo> dictionary = (Dictionary<string, HelpArticleInfo>)helpArticles[KMManager.sPackageName][GuidanceVideoType.SchemeSpecific.ToString()];
					if (KMManager.sVideoMode == GuidanceVideoType.SchemeSpecific && dictionary.ContainsKey(name))
					{
						this.mHelpArticleUrl = dictionary[name].HelpArticleUrl;
					}
					else
					{
						this.mHelpArticleUrl = ((HelpArticleInfo)helpArticles[KMManager.sPackageName][KMManager.sVideoMode.ToString()]).HelpArticleUrl;
					}
				}
				else if (helpArticles.ContainsKey("default") && helpArticles["default"][KMManager.sVideoMode.ToString()] != null)
				{
					this.mHelpArticleUrl = ((HelpArticleInfo)helpArticles["default"][KMManager.sVideoMode.ToString()]).HelpArticleUrl;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in evaluating read article : " + ex.ToString());
			}
			this.mReadArticlePanel.Visibility = (string.IsNullOrEmpty(this.mHelpArticleUrl) ? Visibility.Collapsed : Visibility.Visible);
		}

		// Token: 0x06000AFB RID: 2811 RVA: 0x00008CA1 File Offset: 0x00006EA1
		private void GuidanceWindow_Loaded(object sender, RoutedEventArgs e)
		{
			base.Activate();
		}

		// Token: 0x06000AFC RID: 2812 RVA: 0x00040824 File Offset: 0x0003EA24
		internal void ResizeGuidanceWindow()
		{
			bool flag = false;
			IntereopRect fullscreenMonitorSize = WindowWndProcHandler.GetFullscreenMonitorSize(this.ParentWindow.Handle, true);
			double num = this.ParentWindow.Width * MainWindow.sScalingFactor;
			double num2 = this.ParentWindow.Height * MainWindow.sScalingFactor;
			if (num + (double)this.mSidebarWidth * MainWindow.sScalingFactor + this.ParentWindow.mSidebar.Width * MainWindow.sScalingFactor > (double)fullscreenMonitorSize.Width)
			{
				num = (double)fullscreenMonitorSize.Width - (double)this.mSidebarWidth * MainWindow.sScalingFactor - this.ParentWindow.mSidebar.Width * MainWindow.sScalingFactor;
				num2 = this.ParentWindow.GetHeightFromWidth(num, true, false);
				flag = true;
			}
			if (num2 > (double)fullscreenMonitorSize.Height)
			{
				num2 = (double)fullscreenMonitorSize.Height;
				num = this.ParentWindow.GetWidthFromHeight(num2, true, false);
				flag = true;
			}
			double top;
			if (this.ParentWindow.Top * MainWindow.sScalingFactor + num2 > (double)(fullscreenMonitorSize.Height + fullscreenMonitorSize.Y))
			{
				top = (double)(fullscreenMonitorSize.Y + fullscreenMonitorSize.Height) - num2;
				flag = true;
			}
			else
			{
				top = this.ParentWindow.Top * MainWindow.sScalingFactor;
			}
			double left;
			if (this.ParentWindow.Left * MainWindow.sScalingFactor + num + ((double)this.mSidebarWidth + this.ParentWindow.mSidebar.Width) * MainWindow.sScalingFactor > (double)(fullscreenMonitorSize.Width + fullscreenMonitorSize.X))
			{
				left = (double)(fullscreenMonitorSize.X + fullscreenMonitorSize.Width) - num - ((double)this.mSidebarWidth + this.ParentWindow.mSidebar.Width) * MainWindow.sScalingFactor;
				flag = true;
			}
			else
			{
				left = this.ParentWindow.Left * MainWindow.sScalingFactor;
			}
			if (flag)
			{
				this.ParentWindow.ChangeHeightWidthTopLeft(num, num2, top, left);
			}
			base.Left = ((this.mGuidanceWindowLeft == -1.0) ? (this.ParentWindow.Left + this.ParentWindow.ActualWidth) : this.mGuidanceWindowLeft);
			base.Top = ((this.mGuidanceWindowTop == -1.0) ? this.ParentWindow.Top : this.mGuidanceWindowTop);
			base.Height = this.ParentWindow.ActualHeight;
		}

		// Token: 0x06000AFD RID: 2813 RVA: 0x00008E6A File Offset: 0x0000706A
		internal void DimOverLayVisibility(Visibility visible)
		{
			this.mOverlayGrid.Visibility = visible;
		}

		// Token: 0x06000AFE RID: 2814 RVA: 0x00040A64 File Offset: 0x0003EC64
		private void GuidanceWindow_Closing(object sender, CancelEventArgs e)
		{
			if (!this.IsViewState && (GuidanceWindow.sIsDirty || this.DataModificationTracker.HasChanged(this.mGuidanceData)))
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_BLUESTACKS_GAME_CONTROLS");
				customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_CANCEL_CONFIG_CHANGES");
				customMessageWindow.AddButton(ButtonColors.Red, LocaleStrings.GetLocalizedString("STRING_DISCARD"), delegate(object o, EventArgs e)
				{
					KMManager.LoadIMActions(this.ParentWindow, KMManager.sPackageName);
					GuidanceWindow.sIsDirty = false;
				}, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_CANCEL"), delegate(object o, EventArgs evt)
				{
					e2.Cancel = true;
				}, null, false, null);
				customMessageWindow.CloseButtonHandle(delegate(object o, EventArgs evt)
				{
					e2.Cancel = true;
				}, null);
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
			}
			this.mGuidanceWindowLeft = base.Left;
			this.mGuidanceWindowTop = base.Top;
		}

		// Token: 0x06000AFF RID: 2815 RVA: 0x00040B78 File Offset: 0x0003ED78
		private void GuidanceWindow_Closed(object sender, EventArgs e)
		{
			MainWindow parentWindow = this.ParentWindow;
			if (parentWindow != null && !parentWindow.mTopBar.mAppTabButtons.SelectedTab.IsClosingApp)
			{
				if (!AppConfigurationManager.Instance.CheckIfTrueInAnyVm(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName, (AppSettings appSettings) => appSettings.IsCloseGuidanceOnboardingCompleted) && this.mIsOnboardingPopupToBeShownOnGuidanceClose)
				{
					Sidebar mSidebar = this.ParentWindow.mSidebar;
					if (mSidebar != null)
					{
						mSidebar.ShowGuidanceOnboardingPopup();
					}
					AppConfigurationManager.Instance.VmAppConfig[this.ParentWindow.mVmName][this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName].IsCloseGuidanceOnboardingCompleted = true;
				}
			}
			KMManager.sGuidanceWindow = null;
			this.ParentWindow.mSidebar.UpdateImage("sidebar_gameguide", "sidebar_gameguide");
			this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.mIsAnyOperationPendingForTab = false;
		}

		// Token: 0x06000B00 RID: 2816 RVA: 0x00040C8C File Offset: 0x0003EE8C
		private void ProfileComboBox_ProfileChanged(object sender, SelectionChangedEventArgs e)
		{
			if (!this.mSchemesComboBox.IsDropDownOpen)
			{
				return;
			}
			this.mSchemesComboBox.IsDropDownOpen = false;
			if (this.mSchemesComboBox.SelectedItem != null)
			{
				string text = ((ComboBoxItem)this.mSchemesComboBox.SelectedItem).Content.ToString();
				if (this.SelectControlScheme(text))
				{
					this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_USING_SCHEME") + " : " + text);
					KMManager.SendSchemeChangedStats(this.ParentWindow, "game_guide");
					KMManager.ShowShootingModeTooltip(this.ParentWindow, this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName);
				}
			}
		}

		// Token: 0x06000B01 RID: 2817 RVA: 0x00040D34 File Offset: 0x0003EF34
		internal void ShowGuidanceOnboardingBlubs(JToken res)
		{
			if (res["is_show_blurbs"].ToObject<bool>())
			{
				this.DimOverLayVisibility(Visibility.Collapsed);
				IMConfig selectedConfig = this.ParentWindow.SelectedConfig;
				bool flag;
				if (selectedConfig == null)
				{
					flag = false;
				}
				else
				{
					Dictionary<string, IMControlScheme> controlSchemesDict = selectedConfig.ControlSchemesDict;
					int? num = (controlSchemesDict != null) ? new int?(controlSchemesDict.Count) : null;
					int num2 = 1;
					flag = (num.GetValueOrDefault() > num2 & num != null);
				}
				if (flag)
				{
					this.StartGuidanceOnboarding();
				}
				this.CheckAndShowGeneralOnboarding();
			}
		}

		// Token: 0x06000B02 RID: 2818 RVA: 0x00040DB0 File Offset: 0x0003EFB0
		internal bool SelectControlScheme(string schemeSelected)
		{
			if (this.ParentWindow.SelectedConfig.ControlSchemesDict.ContainsKey(schemeSelected))
			{
				if (!this.ParentWindow.SelectedConfig.ControlSchemesDict[schemeSelected].Selected)
				{
					this.ParentWindow.SelectedConfig.SelectedControlScheme.Selected = false;
					this.ParentWindow.SelectedConfig.SelectedControlScheme = this.ParentWindow.SelectedConfig.ControlSchemesDict[schemeSelected];
					this.ParentWindow.SelectedConfig.SelectedControlScheme.Selected = true;
					if (!GuidanceWindow.sIsDirty)
					{
						GuidanceWindow.sIsDirty = true;
						this.SaveGuidanceChanges();
					}
					else
					{
						GuidanceWindow.sIsDirty = false;
					}
					this.mSchemesComboBox.SelectedValue = schemeSelected;
					return true;
				}
				this.InitUI();
			}
			return false;
		}

		// Token: 0x06000B03 RID: 2819 RVA: 0x00040E78 File Offset: 0x0003F078
		private void AddToastPopup(string message)
		{
			try
			{
				if (this.mToastPopup == null)
				{
					this.mToastPopup = new CustomToastPopupControl(this);
				}
				this.mToastPopup.Init(this, message, null, null, HorizontalAlignment.Center, VerticalAlignment.Bottom, null, 12, null, null, false);
				this.mToastPopup.ShowPopup(1.3);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in showing toast popup: " + ex.ToString());
			}
		}

		// Token: 0x06000B04 RID: 2820 RVA: 0x0003E24C File Offset: 0x0003C44C
		private void TopBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			try
			{
				base.DragMove();
			}
			catch
			{
			}
		}

		// Token: 0x06000B05 RID: 2821 RVA: 0x00006BEE File Offset: 0x00004DEE
		private void CustomPictureBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
			e.Handled = true;
		}

		// Token: 0x06000B06 RID: 2822 RVA: 0x00040F00 File Offset: 0x0003F100
		private void CloseButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mGuidanceWindowSettings.mRestartRequired)
			{
				bool flag = false;
				string path = string.Empty;
				string path2 = string.Empty;
				if (PackageActivityNames.ThirdParty.AllPUBGPackageNames.Contains(this.ParentWindow.StaticComponents.mSelectedTabButton.PackageName, StringComparer.InvariantCultureIgnoreCase))
				{
					path = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_RESTART_OBJECT"), new object[]
					{
						"PUBG Mobile"
					});
					path2 = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_SAVE_AND_RESTART_INFO"), new object[]
					{
						"PUBG Mobile"
					});
					flag = true;
				}
				else if (PackageActivityNames.ThirdParty.AllSevenDeadlySinsPackageNames.Contains(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName))
				{
					path = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_RESTART_OBJECT"), new object[]
					{
						this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.AppName
					});
					path2 = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_SAVE_AND_RESTART_INFO"), new object[]
					{
						this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.AppName
					});
					flag = true;
				}
				else if (PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.Contains(this.ParentWindow.StaticComponents.mSelectedTabButton.PackageName, StringComparer.InvariantCultureIgnoreCase))
				{
					path = string.Format(CultureInfo.InvariantCulture, "{0} {1}", new object[]
					{
						LocaleStrings.GetLocalizedString("STRING_RESTART"),
						"Call of Duty: Mobile"
					});
					path2 = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_SAVE_AND_RESTART_INFO"), new object[]
					{
						"Call of Duty: Mobile"
					});
					flag = true;
				}
				if (flag)
				{
					CustomMessageWindow customMessageWindow = new CustomMessageWindow();
					BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, path, "");
					BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, path2, "");
					customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
					customMessageWindow.AddButton(ButtonColors.Blue, "STRING_SAVE_AND_RESTART", new EventHandler(this.RestartConfirmationAcceptedHandler), null, false, null);
					customMessageWindow.Owner = this.ParentWindow;
					customMessageWindow.ShowDialog();
				}
			}
			this.mIsOnboardingPopupToBeShownOnGuidanceClose = true;
			this.ShowWithParentWindow = false;
			base.Close();
			GuidanceWindow.HideOnNextLaunch(true);
			this.ParentWindow.StaticComponents.mSelectedTabButton.mGuidanceWindowOpen = false;
			if (this.ParentWindow != null)
			{
				this.ParentWindow.Focus();
			}
		}

		// Token: 0x06000B07 RID: 2823 RVA: 0x00008E78 File Offset: 0x00007078
		internal void RestartConfirmationAcceptedHandler(object sender, EventArgs e)
		{
			Logger.Info("Restarting Game Tab.");
			this.mGuidanceWindowSettings.SaveChangesBtn_Click(this.mGuidanceWindowSettings.mSaveChangesBtn, null);
			new Thread(delegate()
			{
				this.ParentWindow.mTopBar.mAppTabButtons.RestartTab(this.ParentWindow.StaticComponents.mSelectedTabButton.PackageName);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000B08 RID: 2824 RVA: 0x0004115C File Offset: 0x0003F35C
		public static void HideOnNextLaunch(bool updatedFlag)
		{
			List<string> list = new List<string>(RegistryManager.Instance.DisabledGuidancePackages);
			if (updatedFlag)
			{
				list.AddIfNotContain(KMManager.sPackageName);
			}
			else if (list.Contains(KMManager.sPackageName))
			{
				list.Remove(KMManager.sPackageName);
			}
			RegistryManager.Instance.DisabledGuidancePackages = list.ToArray();
		}

		// Token: 0x06000B09 RID: 2825 RVA: 0x000411B4 File Offset: 0x0003F3B4
		private void InitGuidanceOnboardingList()
		{
			OnBoardingPopupWindow onBoardingPopupWindow = new OnBoardingPopupWindow(this.ParentWindow, this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName);
			this.ParentWindow.LastOpenedWindow = onBoardingPopupWindow;
			onBoardingPopupWindow.Owner = this.ParentWindow;
			onBoardingPopupWindow.Title = "SelectedGameSchemeBlurb";
			onBoardingPopupWindow.PlacementTarget = this.mSchemesComboBox;
			onBoardingPopupWindow.LeftMargin = 50;
			onBoardingPopupWindow.TopMargin = 4;
			onBoardingPopupWindow.Startevent += delegate()
			{
				this.mSchemesComboBox.Highlight = true;
			};
			onBoardingPopupWindow.Endevent += delegate()
			{
				this.mSchemesComboBox.Highlight = false;
			};
			onBoardingPopupWindow.IsLastPopup = true;
			onBoardingPopupWindow.HeaderContent = LocaleStrings.GetLocalizedString("STRING_SELECTED_MODE");
			onBoardingPopupWindow.BodyContent = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_SELECTED_MODE_MESSAGE"), new object[]
			{
				this.ParentWindow.SelectedConfig.SelectedControlScheme.Name
			});
			onBoardingPopupWindow.Left = this.mSchemesComboBox.PointToScreen(new Point(0.0, 0.0)).X / MainWindow.sScalingFactor - (double)onBoardingPopupWindow.LeftMargin;
			onBoardingPopupWindow.Top = this.mSchemesComboBox.PointToScreen(new Point(0.0, 0.0)).Y / MainWindow.sScalingFactor - (double)onBoardingPopupWindow.TopMargin;
			KMManager.onBoardingPopupWindows.Add(onBoardingPopupWindow);
		}

		// Token: 0x06000B0A RID: 2826 RVA: 0x00041320 File Offset: 0x0003F520
		private void StartGuidanceOnboarding()
		{
			this.InitGuidanceOnboardingList();
			OnBoardingPopupWindow onBoardingPopupWindow = KMManager.onBoardingPopupWindows.First<OnBoardingPopupWindow>();
			KMManager.onBoardingPopupWindows.Remove(onBoardingPopupWindow);
			onBoardingPopupWindow.ShowDialog();
		}

		// Token: 0x06000B0B RID: 2827 RVA: 0x00041354 File Offset: 0x0003F554
		private void InitGeneralGuidanceOnboarding()
		{
			if (this.mGuidanceKeysGrid.ActualHeight < 1.0)
			{
				return;
			}
			OnBoardingPopupWindow onBoardingPopupWindow = new OnBoardingPopupWindow(this.ParentWindow, this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName);
			this.ParentWindow.LastOpenedWindow = onBoardingPopupWindow;
			onBoardingPopupWindow.Owner = this.ParentWindow;
			onBoardingPopupWindow.PlacementTarget = this.mGuidanceKeysGrid;
			onBoardingPopupWindow.Title = "GameControlBlurb";
			onBoardingPopupWindow.LeftMargin = 320;
			onBoardingPopupWindow.TopMargin = ((int)this.mGuidanceKeysGrid.ActualHeight - 230) / 2;
			onBoardingPopupWindow.Startevent += delegate()
			{
				this.mGuidanceKeyBorder.BorderThickness = new Thickness(2.0);
			};
			onBoardingPopupWindow.Endevent += delegate()
			{
				this.mGuidanceKeyBorder.BorderThickness = new Thickness(0.0);
			};
			onBoardingPopupWindow.IsLastPopup = true;
			onBoardingPopupWindow.HeaderContent = LocaleStrings.GetLocalizedString("STRING_GAME_CONTROLS_HEADER");
			onBoardingPopupWindow.BodyContent = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_GAME_CONTROLS_MESSAGE"), new object[0]);
			onBoardingPopupWindow.PopArrowAlignment = PopupArrowAlignment.Right;
			onBoardingPopupWindow.SetValue(Window.LeftProperty, this.mGuidanceKeysGrid.PointToScreen(new Point(0.0, 0.0)).X / MainWindow.sScalingFactor - (double)onBoardingPopupWindow.LeftMargin);
			onBoardingPopupWindow.SetValue(Window.TopProperty, this.mGuidanceKeysGrid.PointToScreen(new Point(0.0, 0.0)).Y / MainWindow.sScalingFactor + (double)onBoardingPopupWindow.TopMargin);
			onBoardingPopupWindow.ShowDialog();
		}

		// Token: 0x06000B0C RID: 2828 RVA: 0x000414EC File Offset: 0x0003F6EC
		private void ControlsTabMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mControlsGrid.Visibility = Visibility.Visible;
			this.mGuidanceWindowSettings.Visibility = Visibility.Collapsed;
			BlueStacksUIBinding.BindColor(this.mSettingsTabSeparator, Panel.BackgroundProperty, "HorizontalSeparator");
			BlueStacksUIBinding.BindColor(this.mSettingsTabTextBlock, TextBlock.ForegroundProperty, "SettingsWindowForegroundDimColor");
			BlueStacksUIBinding.BindColor(this.mControlsTabSeparator, Panel.BackgroundProperty, "SettingsWindowTabMenuItemUnderline");
			BlueStacksUIBinding.BindColor(this.mControlsTabTextBlock, TextBlock.ForegroundProperty, "SettingsWindowTabMenuItemLegendForeground");
		}

		// Token: 0x06000B0D RID: 2829 RVA: 0x00041568 File Offset: 0x0003F768
		private void SettingsTabMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mControlsGrid.Visibility = Visibility.Collapsed;
			this.mGuidanceWindowSettings.Visibility = Visibility.Visible;
			if (PackageActivityNames.ThirdParty.AllCallOfDutyPackageNames.Contains(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName))
			{
				this.ParentWindow.mCommonHandler.ToggleSettingsBtnNotification(false);
				this.ParentWindow.EngineInstanceRegistry.CODNotificationShown = true;
			}
			if (PackageActivityNames.ThirdParty.AllPUBGPackageNames.Contains(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName))
			{
				this.ParentWindow.mCommonHandler.ToggleSettingsBtnNotification(false);
				this.ParentWindow.EngineInstanceRegistry.PUBGNotificationShown = true;
			}
			if ("com.dts.freefireth".Contains(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName))
			{
				this.ParentWindow.mCommonHandler.ToggleSettingsBtnNotification(false);
				this.ParentWindow.EngineInstanceRegistry.FreeFireNotificationShown = true;
			}
			if (PackageActivityNames.ThirdParty.AllSevenDeadlySinsPackageNames.Contains(this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName))
			{
				this.ParentWindow.mCommonHandler.ToggleSettingsBtnNotification(false);
				this.ParentWindow.EngineInstanceRegistry.SevenDeadlySinsNotificationShown = true;
			}
			BlueStacksUIBinding.BindColor(this.mControlsTabSeparator, Panel.BackgroundProperty, "HorizontalSeparator");
			BlueStacksUIBinding.BindColor(this.mControlsTabTextBlock, TextBlock.ForegroundProperty, "SettingsWindowForegroundDimColor");
			BlueStacksUIBinding.BindColor(this.mSettingsTabSeparator, Panel.BackgroundProperty, "SettingsWindowTabMenuItemUnderline");
			BlueStacksUIBinding.BindColor(this.mSettingsTabTextBlock, TextBlock.ForegroundProperty, "SettingsWindowTabMenuItemLegendForeground");
		}

		// Token: 0x06000B0E RID: 2830 RVA: 0x00041704 File Offset: 0x0003F904
		private void CustomPictureBox_MouseUp(object sender, MouseButtonEventArgs e)
		{
			using (GuidanceVideoWindow guidanceVideoWindow = new GuidanceVideoWindow(this.ParentWindow))
			{
				guidanceVideoWindow.Owner = this.ParentWindow;
				guidanceVideoWindow.Width = Math.Max(this.ParentWindow.ActualWidth * 0.7, 700.0);
				guidanceVideoWindow.Height = Math.Max(this.ParentWindow.ActualHeight * 0.7, 450.0);
				guidanceVideoWindow.Loaded += this.Window_Loaded;
				guidanceVideoWindow.ShowDialog();
			}
		}

		// Token: 0x06000B0F RID: 2831 RVA: 0x000417B0 File Offset: 0x0003F9B0
		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			try
			{
				if (KMManager.sGuidanceWindow != null && !KMManager.sGuidanceWindow.mGuidanceHasBeenMoved)
				{
					CustomWindow customWindow = sender as CustomWindow;
					customWindow.Left = this.ParentWindow.Left + (this.ParentWindow.Width + KMManager.sGuidanceWindow.ActualWidth - customWindow.ActualWidth) / 2.0;
					customWindow.Top = this.ParentWindow.Top + (this.ParentWindow.Height - customWindow.ActualHeight) / 2.0;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in setting position guidance video window: " + ex.ToString());
			}
		}

		// Token: 0x06000B10 RID: 2832 RVA: 0x00041868 File Offset: 0x0003FA68
		private void GamepadIconPreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mKeyboardIconImage.ImageName = "guidance_controls";
			BlueStacksUIBinding.BindColor(this.mKeyboardIconSeparator, Panel.BackgroundProperty, "HorizontalSeparator");
			this.mGamepadIconImage.ImageName = "guidance_gamepad_hover";
			BlueStacksUIBinding.BindColor(this.mGamepadIconSeparator, Panel.BackgroundProperty, "SettingsWindowTabMenuItemUnderline");
			this.mIsGamePadTabSelected = true;
			this.ShowGuidance();
		}

		// Token: 0x06000B11 RID: 2833 RVA: 0x000418CC File Offset: 0x0003FACC
		private void KeyboardIconPreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.mGamepadIconImage.ImageName = "guidance_gamepad";
			BlueStacksUIBinding.BindColor(this.mGamepadIconSeparator, Panel.BackgroundProperty, "HorizontalSeparator");
			this.mKeyboardIconImage.ImageName = "guidance_controls_hover";
			BlueStacksUIBinding.BindColor(this.mKeyboardIconSeparator, Panel.BackgroundProperty, "SettingsWindowTabMenuItemUnderline");
			this.mIsGamePadTabSelected = false;
			this.ShowGuidance();
		}

		// Token: 0x06000B12 RID: 2834 RVA: 0x00008EB8 File Offset: 0x000070B8
		private void ReadMoreLinkMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mHelpArticleUrl != null)
			{
				Utils.OpenUrl(this.mHelpArticleUrl);
			}
			e.Handled = true;
		}

		// Token: 0x06000B13 RID: 2835 RVA: 0x00041930 File Offset: 0x0003FB30
		private void Grid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			try
			{
				if (this.mHeaderGrid.IsMouseOver && !e.OriginalSource.GetType().Equals(typeof(TextBlock)) && !this.mControlsTab.IsMouseOver && !this.mSettingsTab.IsMouseOver)
				{
					base.DragMove();
					this.mGuidanceHasBeenMoved = true;
					base.ResizeMode = ResizeMode.CanResizeWithGrip;
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000B14 RID: 2836 RVA: 0x000419AC File Offset: 0x0003FBAC
		internal void GuidanceWindowTabSelected(string mSelectedTab)
		{
			mSelectedTab = (string.IsNullOrEmpty(mSelectedTab) ? ((this.mGuidanceData.GamepadViewGuidance.Count > 0 && this.ParentWindow.IsGamepadConnected) ? "gamepad" : "default") : mSelectedTab);
			if (mSelectedTab == "gamepad")
			{
				if (this.mGamepadIcon.Visibility == Visibility.Visible)
				{
					this.GamepadIconPreviewMouseLeftButtonUp(null, null);
					return;
				}
			}
			else if (this.mKeyboardIcon.Visibility == Visibility.Visible)
			{
				this.KeyboardIconPreviewMouseLeftButtonUp(null, null);
			}
		}

		// Token: 0x06000B15 RID: 2837 RVA: 0x00041A2C File Offset: 0x0003FC2C
		private void GuidanceWindow_KeyDown(object sender, KeyEventArgs e)
		{
			string text = string.Empty;
			if (e.Key != Key.None)
			{
				if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
				{
					text = IMAPKeys.GetStringForFile(Key.LeftCtrl) + " + ";
				}
				if (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt))
				{
					text = text + IMAPKeys.GetStringForFile(Key.LeftAlt) + " + ";
				}
				if (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift))
				{
					text = text + IMAPKeys.GetStringForFile(Key.LeftShift) + " + ";
				}
				text += IMAPKeys.GetStringForFile(e.Key);
			}
			Logger.Debug("SHORTCUT: KeyPressed.." + text);
			if (this.ParentWindow.mCommonHandler.mShortcutsConfigInstance != null)
			{
				foreach (ShortcutKeys shortcutKeys in this.ParentWindow.mCommonHandler.mShortcutsConfigInstance.Shortcut)
				{
					if (string.Equals(shortcutKeys.ShortcutKey, text, StringComparison.InvariantCulture))
					{
						if (string.Equals(shortcutKeys.ShortcutName, "STRING_TOGGLE_KEYMAP_WINDOW", StringComparison.InvariantCulture))
						{
							this.ParentWindow.mCommonHandler.ToggleGamepadAndKeyboardGuidance("default");
						}
						else if (string.Equals(shortcutKeys.ShortcutName, "STRING_GAMEPAD_CONTROLS", StringComparison.InvariantCulture))
						{
							this.ParentWindow.mCommonHandler.ToggleGamepadAndKeyboardGuidance("gamepad");
						}
					}
				}
			}
		}

		// Token: 0x06000B16 RID: 2838 RVA: 0x00041BA0 File Offset: 0x0003FDA0
		internal void UpdateSize()
		{
			if (!this.mGuidanceHasBeenMoved)
			{
				base.Left = ((this.mGuidanceWindowLeft == -1.0) ? (this.ParentWindow.Left + this.ParentWindow.ActualWidth) : this.mGuidanceWindowLeft);
				base.Top = ((this.mGuidanceWindowTop == -1.0) ? this.ParentWindow.Top : this.mGuidanceWindowTop);
				base.Height = this.ParentWindow.ActualHeight;
			}
		}

		// Token: 0x06000B17 RID: 2839 RVA: 0x00008ED4 File Offset: 0x000070D4
		private void CustomWindow_StateChanged(object sender, EventArgs e)
		{
			base.WindowState = WindowState.Normal;
		}

		// Token: 0x06000B18 RID: 2840 RVA: 0x00041C28 File Offset: 0x0003FE28
		private void GuidanceWindow_Activated(object sender, EventArgs e)
		{
			try
			{
				if (RegistryManager.Instance.ShowKeyControlsOverlay && KMManager.dictOverlayWindow.ContainsKey(this.ParentWindow))
				{
					KeymapCanvasWindow keymapCanvasWindow = KMManager.dictOverlayWindow[this.ParentWindow];
					if (keymapCanvasWindow != null)
					{
						keymapCanvasWindow.Show();
					}
				}
			}
			catch (Exception arg)
			{
				Logger.Error(string.Format("Exception in GuidanceWindow_Activated {0}", arg));
			}
		}

		// Token: 0x06000B19 RID: 2841 RVA: 0x00041C94 File Offset: 0x0003FE94
		private void GuidanceWindow_Deactivated(object sender, EventArgs e)
		{
			try
			{
				if (!this.ParentWindow.IsActive && KMManager.dictOverlayWindow.ContainsKey(this.ParentWindow))
				{
					KMManager.dictOverlayWindow[this.ParentWindow].Hide();
				}
			}
			catch (Exception arg)
			{
				Logger.Error(string.Format("Exception in GuidanceWindow_Deactivated {0}", arg));
			}
		}

		// Token: 0x06000B1A RID: 2842 RVA: 0x00041CFC File Offset: 0x0003FEFC
		private void GuidanceKeyTextChanged(object sender, TextChangedEventArgs e)
		{
			IEnumerable<GuidanceCategoryEditModel> source = this.mGuidanceData.KeymapEditGuidance.Union(this.mGuidanceData.GamepadEditGuidance);
			source.SelectMany((GuidanceCategoryEditModel cgem) => cgem.GuidanceEditModels).OfType<GuidanceEditTextModel>().ToList<GuidanceEditTextModel>().ForEach(delegate(GuidanceEditTextModel gem)
			{
				gem.TextValidityOption = TextValidityOptions.Success;
			});
			IMapTextBox mapTextBox = sender as IMapTextBox;
			if (mapTextBox != null)
			{
				object dataContext = mapTextBox.DataContext;
				GuidanceEditTextModel guidanceEditTextModel = dataContext as GuidanceEditTextModel;
				if (guidanceEditTextModel != null && !string.Equals(guidanceEditTextModel.OriginalGuidanceKey, guidanceEditTextModel.GuidanceKey, StringComparison.OrdinalIgnoreCase))
				{
					GuidanceWindow.sIsDirty = true;
					ToolTip toolTip = mapTextBox.ToolTip as ToolTip;
					if (toolTip != null)
					{
						toolTip.PlacementTarget = mapTextBox;
					}
					if ((from gem in source.SelectMany((GuidanceCategoryEditModel cgem) => cgem.GuidanceEditModels).OfType<GuidanceEditTextModel>()
					where !string.IsNullOrEmpty(gem.GuidanceKey) && gem.PropertyType == typeof(string) && string.Equals(guidanceEditTextModel.GuidanceKey, gem.GuidanceKey, StringComparison.OrdinalIgnoreCase)
					select gem).Count<GuidanceEditTextModel>() > 1)
					{
						mapTextBox.InputTextValidity = TextValidityOptions.Warning;
						if (toolTip != null)
						{
							toolTip.IsOpen = true;
						}
					}
				}
			}
			this.mSaveBtn.IsEnabled = (GuidanceWindow.sIsDirty || this.DataModificationTracker.HasChanged(this.mGuidanceData));
		}

		// Token: 0x06000B1B RID: 2843 RVA: 0x00041E64 File Offset: 0x00040064
		private void StepperTextChanged(object sender, TextChangedEventArgs e)
		{
			StepperTextBox stepperTextBox = sender as StepperTextBox;
			if (stepperTextBox != null)
			{
				GuidanceEditDecimalModel guidanceEditDecimalModel = stepperTextBox.DataContext as GuidanceEditDecimalModel;
				if (guidanceEditDecimalModel != null && !string.Equals(guidanceEditDecimalModel.OriginalGuidanceKey, guidanceEditDecimalModel.GuidanceKey, StringComparison.OrdinalIgnoreCase))
				{
					GuidanceWindow.sIsDirty = true;
				}
			}
			this.mSaveBtn.IsEnabled = (GuidanceWindow.sIsDirty || this.DataModificationTracker.HasChanged(this.mGuidanceData));
		}

		// Token: 0x06000B1C RID: 2844 RVA: 0x00041ECC File Offset: 0x000400CC
		private void EditBtn_Click(object sender, RoutedEventArgs e)
		{
			this.ShowEditGuidance();
			this.DataModificationTracker.Lock(this.mGuidanceData.DeepCopy<GuidanceData>(), new List<string>
			{
				"KeymapViewGuidance",
				"GamepadViewGuidance",
				"Item",
				"TextValidityOption",
				"GuidanceText",
				"OriginalGuidanceKey",
				"IMActionItems",
				"PropertyType",
				"ActionType"
			}, true);
			ClientStats.SendKeyMappingUIStatsAsync("guide_edit", KMManager.sPackageName, "");
		}

		// Token: 0x06000B1D RID: 2845 RVA: 0x00008EDD File Offset: 0x000070DD
		private void SaveBtn_Click(object sender, RoutedEventArgs e)
		{
			this.SaveGuidanceChanges();
			this.AddToastPopup(LocaleStrings.GetLocalizedString("STRING_CHANGES_SAVED"));
			ClientStats.SendKeyMappingUIStatsAsync("guide_save", KMManager.sPackageName, "");
		}

		// Token: 0x06000B1E RID: 2846 RVA: 0x00041F74 File Offset: 0x00040174
		private void SaveGuidanceChanges()
		{
			Logger.Debug(string.Format("ExtraLog: SaveGuidanceChanges, VmName:{0}, Scheme:{1}, SchemeCount:{2}", this.ParentWindow.mVmName, this.ParentWindow.SelectedConfig.SelectedControlScheme.Name, this.ParentWindow.SelectedConfig.ControlSchemes.Count));
			bool flag = false;
			if (this.ParentWindow.OriginalLoadedConfig.ControlSchemes.Count != this.ParentWindow.SelectedConfig.ControlSchemes.Count)
			{
				flag = true;
			}
			if (GuidanceWindow.sIsDirty || this.DataModificationTracker.HasChanged(this.mGuidanceData))
			{
				GuidanceWindow.sIsDirty = true;
				KMManager.SaveIMActions(this.ParentWindow, true, false);
			}
			if (flag)
			{
				this.FillProfileComboBox();
			}
			else
			{
				this.InitUI();
			}
			if (KMManager.dictOverlayWindow.ContainsKey(this.ParentWindow) && KMManager.dictOverlayWindow[this.ParentWindow] != null)
			{
				KMManager.dictOverlayWindow[this.ParentWindow].Init();
				if (RegistryManager.Instance.ShowKeyControlsOverlay)
				{
					KMManager.dictOverlayWindow[this.ParentWindow].Show();
					Application.Current.Dispatcher.BeginInvoke(new Action(delegate()
					{
						KMManager.dictOverlayWindow[this.ParentWindow].Focus();
					}), new object[0]);
				}
			}
			this.ShowViewGuidance();
		}

		// Token: 0x06000B1F RID: 2847 RVA: 0x000420BC File Offset: 0x000402BC
		private void DiscardBtn_Click(object sender, RoutedEventArgs e)
		{
			if (GuidanceWindow.sIsDirty || this.DataModificationTracker.HasChanged(this.mGuidanceData))
			{
				CustomMessageWindow customMessageWindow = new CustomMessageWindow();
				customMessageWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;
				customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_DISCARD_CHANGES");
				customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_DISCARD_GUIDANCE_CHANGES");
				customMessageWindow.AddButton(ButtonColors.Blue, "STRING_DISCARD", delegate(object o, EventArgs e)
				{
					string schemeName = this.ParentWindow.SelectedConfig.SelectedControlScheme.Name;
					IEnumerable<IMControlScheme> source = from scheme_ in this.ParentWindow.OriginalLoadedConfig.ControlSchemes
					where string.Equals(scheme_.Name, schemeName, StringComparison.InvariantCultureIgnoreCase)
					select scheme_;
					if (source.Any<IMControlScheme>())
					{
						this.mGuidanceData.Reset();
						IMControlScheme imcontrolScheme;
						if (source.Count<IMControlScheme>() != 1)
						{
							imcontrolScheme = (from scheme_ in source
							where !scheme_.BuiltIn
							select scheme_).First<IMControlScheme>();
						}
						else
						{
							imcontrolScheme = source.First<IMControlScheme>();
						}
						IMControlScheme imcontrolScheme2 = imcontrolScheme;
						if (imcontrolScheme2.BuiltIn)
						{
							this.ParentWindow.SelectedConfig.ControlSchemes.Remove(this.ParentWindow.SelectedConfig.SelectedControlScheme);
							IMControlScheme imcontrolScheme3 = (from scheme in this.ParentWindow.SelectedConfig.ControlSchemes
							where string.Equals(scheme.Name, schemeName, StringComparison.InvariantCulture)
							select scheme).FirstOrDefault<IMControlScheme>();
							if (imcontrolScheme3 != null)
							{
								imcontrolScheme3.Selected = true;
								this.ParentWindow.SelectedConfig.SelectedControlScheme = imcontrolScheme3;
								this.ParentWindow.SelectedConfig.ControlSchemesDict[imcontrolScheme3.Name] = imcontrolScheme3;
								GuidanceWindow.sIsDirty = true;
							}
						}
						else
						{
							this.ParentWindow.SelectedConfig.ControlSchemes.Remove(this.ParentWindow.SelectedConfig.SelectedControlScheme);
							this.ParentWindow.SelectedConfig.SelectedControlScheme = imcontrolScheme2.DeepCopy();
							this.ParentWindow.SelectedConfig.ControlSchemesDict[schemeName] = this.ParentWindow.SelectedConfig.SelectedControlScheme;
							this.ParentWindow.SelectedConfig.ControlSchemes.Add(this.ParentWindow.SelectedConfig.SelectedControlScheme);
							this.InitUI();
						}
						this.ShowViewGuidance();
					}
				}, null, false, null);
				customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", delegate(object o, EventArgs e)
				{
				}, null, false, null);
				this.ParentWindow.ShowDimOverlay(null);
				customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
				customMessageWindow.ShowDialog();
				this.ParentWindow.HideDimOverlay();
				return;
			}
			this.ShowViewGuidance();
		}

		// Token: 0x06000B20 RID: 2848 RVA: 0x00008F09 File Offset: 0x00007109
		private void ShowGuidance()
		{
			if (this.IsViewState)
			{
				this.ShowViewGuidance();
				return;
			}
			this.ShowEditGuidance();
		}

		// Token: 0x06000B21 RID: 2849 RVA: 0x0004219C File Offset: 0x0004039C
		private void ShowViewGuidance()
		{
			this.IsViewState = true;
			this.mViewDock.Visibility = Visibility.Visible;
			this.mEditDock.Visibility = Visibility.Collapsed;
			if (this.mGuidanceData.GamepadViewGuidance.Count == 0)
			{
				this.mIsGamePadTabSelected = false;
			}
			ObservableCollection<GuidanceCategoryViewModel> observableCollection = this.mIsGamePadTabSelected ? this.mGuidanceData.GamepadViewGuidance : this.mGuidanceData.KeymapViewGuidance;
			if (observableCollection != null)
			{
				if (observableCollection.Count == 1)
				{
					this.mGuidanceListBox.DataContext = observableCollection[0].GuidanceViewModels;
					this.mGuidanceListBox.AlternationCount = 2;
				}
				else
				{
					this.mGuidanceListBox.DataContext = observableCollection;
					this.mGuidanceListBox.AlternationCount = 0;
				}
			}
			UIElement uielement = this.mEditBtn;
			Visibility visibility;
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme != null && this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.Any<IMAction>())
			{
				if (this.ParentWindow.SelectedConfig.SelectedControlScheme.GameControls.SelectMany((IMAction action) => action.Guidance).Any<KeyValuePair<string, string>>())
				{
					visibility = Visibility.Visible;
					goto IL_11A;
				}
			}
			visibility = Visibility.Collapsed;
			IL_11A:
			uielement.Visibility = visibility;
			this.mRevertBtn.Visibility = ((this.ParentWindow.SelectedConfig.ControlSchemes.Count((IMControlScheme x) => string.Equals(x.Name, this.ParentWindow.SelectedConfig.SelectedControlScheme.Name, StringComparison.InvariantCulture)) == 2) ? Visibility.Visible : Visibility.Collapsed);
			this.UpdateVideoElement(this.mIsGamePadTabSelected);
			GuidanceWindow.sIsDirty = false;
			this.mSaveBtn.IsEnabled = false;
		}

		// Token: 0x06000B22 RID: 2850 RVA: 0x0004231C File Offset: 0x0004051C
		private void ShowEditGuidance()
		{
			this.IsViewState = false;
			this.mViewDock.Visibility = Visibility.Collapsed;
			this.mEditDock.Visibility = Visibility.Visible;
			ObservableCollection<GuidanceCategoryEditModel> observableCollection = this.mIsGamePadTabSelected ? this.mGuidanceData.GamepadEditGuidance : this.mGuidanceData.KeymapEditGuidance;
			if (observableCollection != null)
			{
				if (observableCollection.Count == 1)
				{
					this.mGuidanceListBox.DataContext = observableCollection[0].GuidanceEditModels;
					this.mGuidanceListBox.AlternationCount = 2;
					return;
				}
				this.mGuidanceListBox.DataContext = observableCollection;
				this.mGuidanceListBox.AlternationCount = 0;
			}
		}

		// Token: 0x06000B23 RID: 2851 RVA: 0x000423B4 File Offset: 0x000405B4
		private void RevertBtn_Click(object sender, RoutedEventArgs e)
		{
			if (this.ParentWindow.SelectedConfig.SelectedControlScheme.BuiltIn)
			{
				return;
			}
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;
			customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_RESET_TO_DEFAULT");
			customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_RESET_SCHEME_CHANGES");
			customMessageWindow.AddButton(ButtonColors.Red, "STRING_RESET", delegate(object o, EventArgs e)
			{
				Logger.Debug(string.Format("ExtraLog: Revert Clicked, VmName:{0}, Scheme:{1}, SchemeCount:{2}", this.ParentWindow.mVmName, this.ParentWindow.SelectedConfig.SelectedControlScheme.Name, this.ParentWindow.SelectedConfig.ControlSchemes.Count));
				string schemeName = this.ParentWindow.SelectedConfig.SelectedControlScheme.Name;
				bool isBookMarked = this.ParentWindow.SelectedConfig.SelectedControlScheme.IsBookMarked;
				this.ParentWindow.SelectedConfig.ControlSchemes.Remove(this.ParentWindow.SelectedConfig.SelectedControlScheme);
				IMControlScheme imcontrolScheme = (from scheme in this.ParentWindow.SelectedConfig.ControlSchemes
				where string.Equals(scheme.Name, schemeName, StringComparison.InvariantCulture) && scheme.BuiltIn
				select scheme).FirstOrDefault<IMControlScheme>();
				if (imcontrolScheme != null)
				{
					Logger.Debug(string.Format("ExtraLog: Updating scheme dictionary, VmName:{0}, Scheme:{1}, SchemeCount:{2}", this.ParentWindow.mVmName, this.ParentWindow.SelectedConfig.SelectedControlScheme.Name, this.ParentWindow.SelectedConfig.ControlSchemes.Count));
					imcontrolScheme.Selected = true;
					imcontrolScheme.IsBookMarked = isBookMarked;
					this.ParentWindow.SelectedConfig.SelectedControlScheme = imcontrolScheme;
					this.ParentWindow.SelectedConfig.ControlSchemesDict[imcontrolScheme.Name] = imcontrolScheme;
					GuidanceWindow.sIsDirty = true;
					this.SaveGuidanceChanges();
					ClientStats.SendKeyMappingUIStatsAsync("guide_reset", KMManager.sPackageName, "");
				}
			}, null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", delegate(object o, EventArgs e)
			{
			}, null, false, null);
			this.ParentWindow.ShowDimOverlay(null);
			customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
			customMessageWindow.ShowDialog();
			this.ParentWindow.HideDimOverlay();
		}

		// Token: 0x06000B24 RID: 2852 RVA: 0x00042488 File Offset: 0x00040688
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/guidancewindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000B25 RID: 2853 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000B26 RID: 2854 RVA: 0x000424B8 File Offset: 0x000406B8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((GuidanceWindow)target).StateChanged += this.CustomWindow_StateChanged;
				((GuidanceWindow)target).Closing += this.GuidanceWindow_Closing;
				((GuidanceWindow)target).Closed += this.GuidanceWindow_Closed;
				((GuidanceWindow)target).Loaded += this.GuidanceWindow_Loaded;
				((GuidanceWindow)target).KeyDown += this.GuidanceWindow_KeyDown;
				((GuidanceWindow)target).Activated += this.GuidanceWindow_Activated;
				((GuidanceWindow)target).Deactivated += this.GuidanceWindow_Deactivated;
				return;
			case 2:
				this.mGameControlBorder = (Border)target;
				return;
			case 3:
				this.mHeaderGrid = (DockPanel)target;
				this.mHeaderGrid.MouseLeftButtonDown += this.Grid_MouseLeftButtonDown;
				return;
			case 4:
				this.mControlsTab = (Grid)target;
				this.mControlsTab.MouseLeftButtonUp += this.ControlsTabMouseLeftButtonUp;
				return;
			case 5:
				this.mControlsTabTextBlock = (TextBlock)target;
				return;
			case 6:
				this.mControlsTabSeparator = (Grid)target;
				return;
			case 7:
				this.mSettingsTab = (Grid)target;
				this.mSettingsTab.MouseLeftButtonUp += this.SettingsTabMouseLeftButtonUp;
				return;
			case 8:
				this.mSettingsTabTextBlock = (TextBlock)target;
				return;
			case 9:
				this.mSettingsBtnNotification = (Ellipse)target;
				return;
			case 10:
				this.mSettingsTabSeparator = (Grid)target;
				return;
			case 11:
				this.mEditKeysGrid = (Grid)target;
				return;
			case 12:
				this.mEditKeysGridTextBlock = (TextBlock)target;
				return;
			case 13:
				this.mEditKeysGridSeparator = (Grid)target;
				return;
			case 14:
				this.mCloseSideBarWindow = (CustomPictureBox)target;
				this.mCloseSideBarWindow.MouseDown += this.CustomPictureBox_MouseDown;
				this.mCloseSideBarWindow.MouseLeftButtonUp += this.CloseButton_MouseLeftButtonUp;
				return;
			case 15:
				this.mControlsGrid = (Grid)target;
				return;
			case 16:
				this.mSchemePanel = (StackPanel)target;
				return;
			case 17:
				this.mSchemeTextBlock = (TextBlock)target;
				return;
			case 18:
				this.mSchemesComboBox = (CustomComboBox)target;
				this.mSchemesComboBox.SelectionChanged += this.ProfileComboBox_ProfileChanged;
				return;
			case 19:
				this.mVideoGrid = (Grid)target;
				this.mVideoGrid.MouseUp += this.CustomPictureBox_MouseUp;
				return;
			case 20:
				this.mVideoThumbnail = (CustomPictureBox)target;
				return;
			case 21:
				this.mKeysIconGrid = (DockPanel)target;
				return;
			case 22:
				this.mKeyboardIcon = (Grid)target;
				return;
			case 23:
				this.mKeyboardIconImage = (CustomPictureBox)target;
				this.mKeyboardIconImage.PreviewMouseLeftButtonUp += this.KeyboardIconPreviewMouseLeftButtonUp;
				return;
			case 24:
				this.mKeyboardIconSeparator = (Grid)target;
				return;
			case 25:
				this.mGamepadIcon = (Grid)target;
				return;
			case 26:
				this.mGamepadIconImage = (CustomPictureBox)target;
				this.mGamepadIconImage.PreviewMouseLeftButtonUp += this.GamepadIconPreviewMouseLeftButtonUp;
				return;
			case 27:
				this.mGamepadIconSeparator = (Grid)target;
				return;
			case 28:
				this.mReadArticlePanel = (StackPanel)target;
				return;
			case 29:
				((TextBlock)target).MouseLeftButtonDown += this.ReadMoreLinkMouseLeftButtonUp;
				return;
			case 30:
				((CustomPictureBox)target).MouseLeftButtonDown += this.ReadMoreLinkMouseLeftButtonUp;
				return;
			case 31:
				this.separator = (Grid)target;
				return;
			case 32:
				this.mGuidanceKeyBorder = (Border)target;
				return;
			case 33:
				this.mGuidanceKeysGrid = (Grid)target;
				return;
			case 34:
				this.mGuidanceListBox = (ListBox)target;
				return;
			case 35:
				this.noGameGuidePanel = (StackPanel)target;
				return;
			case 36:
				this.mViewDock = (DockPanel)target;
				return;
			case 37:
				this.mEditBtn = (CustomButton)target;
				this.mEditBtn.Click += this.EditBtn_Click;
				return;
			case 38:
				this.mRevertBtn = (CustomButton)target;
				this.mRevertBtn.Click += this.RevertBtn_Click;
				return;
			case 39:
				this.mEditDock = (Grid)target;
				return;
			case 40:
				this.mDiscardBtn = (CustomButton)target;
				this.mDiscardBtn.Click += this.DiscardBtn_Click;
				return;
			case 41:
				this.mSaveBtn = (CustomButton)target;
				this.mSaveBtn.Click += this.SaveBtn_Click;
				return;
			case 42:
				this.mGuidanceWindowSettings = (GuidanceWindowSettings)target;
				return;
			case 43:
				this.mOverlayGrid = (Grid)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040006F3 RID: 1779
		internal MainWindow ParentWindow;

		// Token: 0x040006F4 RID: 1780
		private bool mIsGuidanceVideoPresent;

		// Token: 0x040006F5 RID: 1781
		private CustomToastPopupControl mToastPopup;

		// Token: 0x040006F6 RID: 1782
		private List<string> lstPanTags = new List<string>();

		// Token: 0x040006F7 RID: 1783
		private List<string> lstMOBATags = new List<string>();

		// Token: 0x040006F8 RID: 1784
		internal bool mIsGamePadTabSelected;

		// Token: 0x040006F9 RID: 1785
		internal bool mIsOnboardingPopupToBeShownOnGuidanceClose;

		// Token: 0x040006FA RID: 1786
		private int mSidebarWidth = 220;

		// Token: 0x040006FB RID: 1787
		internal double mGuidanceWindowLeft = -1.0;

		// Token: 0x040006FC RID: 1788
		internal double mGuidanceWindowTop = -1.0;

		// Token: 0x040006FD RID: 1789
		internal bool mGuidanceHasBeenMoved;

		// Token: 0x040006FE RID: 1790
		internal static bool IsDirty;

		// Token: 0x040006FF RID: 1791
		private GuidanceData mGuidanceData = new GuidanceData();

		// Token: 0x04000700 RID: 1792
		private string mHelpArticleUrl;

		// Token: 0x04000701 RID: 1793
		private bool isViewState = true;

		// Token: 0x04000702 RID: 1794
		private readonly DataModificationTracker DataModificationTracker = new DataModificationTracker();

		// Token: 0x04000703 RID: 1795
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mGameControlBorder;

		// Token: 0x04000704 RID: 1796
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal DockPanel mHeaderGrid;

		// Token: 0x04000705 RID: 1797
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mControlsTab;

		// Token: 0x04000706 RID: 1798
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mControlsTabTextBlock;

		// Token: 0x04000707 RID: 1799
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mControlsTabSeparator;

		// Token: 0x04000708 RID: 1800
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mSettingsTab;

		// Token: 0x04000709 RID: 1801
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mSettingsTabTextBlock;

		// Token: 0x0400070A RID: 1802
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Ellipse mSettingsBtnNotification;

		// Token: 0x0400070B RID: 1803
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mSettingsTabSeparator;

		// Token: 0x0400070C RID: 1804
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mEditKeysGrid;

		// Token: 0x0400070D RID: 1805
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mEditKeysGridTextBlock;

		// Token: 0x0400070E RID: 1806
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mEditKeysGridSeparator;

		// Token: 0x0400070F RID: 1807
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCloseSideBarWindow;

		// Token: 0x04000710 RID: 1808
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mControlsGrid;

		// Token: 0x04000711 RID: 1809
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mSchemePanel;

		// Token: 0x04000712 RID: 1810
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mSchemeTextBlock;

		// Token: 0x04000713 RID: 1811
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomComboBox mSchemesComboBox;

		// Token: 0x04000714 RID: 1812
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mVideoGrid;

		// Token: 0x04000715 RID: 1813
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mVideoThumbnail;

		// Token: 0x04000716 RID: 1814
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal DockPanel mKeysIconGrid;

		// Token: 0x04000717 RID: 1815
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mKeyboardIcon;

		// Token: 0x04000718 RID: 1816
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mKeyboardIconImage;

		// Token: 0x04000719 RID: 1817
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mKeyboardIconSeparator;

		// Token: 0x0400071A RID: 1818
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mGamepadIcon;

		// Token: 0x0400071B RID: 1819
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mGamepadIconImage;

		// Token: 0x0400071C RID: 1820
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mGamepadIconSeparator;

		// Token: 0x0400071D RID: 1821
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mReadArticlePanel;

		// Token: 0x0400071E RID: 1822
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid separator;

		// Token: 0x0400071F RID: 1823
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mGuidanceKeyBorder;

		// Token: 0x04000720 RID: 1824
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mGuidanceKeysGrid;

		// Token: 0x04000721 RID: 1825
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ListBox mGuidanceListBox;

		// Token: 0x04000722 RID: 1826
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel noGameGuidePanel;

		// Token: 0x04000723 RID: 1827
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal DockPanel mViewDock;

		// Token: 0x04000724 RID: 1828
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mEditBtn;

		// Token: 0x04000725 RID: 1829
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mRevertBtn;

		// Token: 0x04000726 RID: 1830
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mEditDock;

		// Token: 0x04000727 RID: 1831
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mDiscardBtn;

		// Token: 0x04000728 RID: 1832
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mSaveBtn;

		// Token: 0x04000729 RID: 1833
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal GuidanceWindowSettings mGuidanceWindowSettings;

		// Token: 0x0400072A RID: 1834
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mOverlayGrid;

		// Token: 0x0400072B RID: 1835
		private bool _contentLoaded;
	}
}
