﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Threading;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200003D RID: 61
	internal class PostBootCloudInfoManager
	{
		// Token: 0x17000123 RID: 291
		// (get) Token: 0x06000311 RID: 785 RVA: 0x000040C7 File Offset: 0x000022C7
		private static string BstPostBootFilePath
		{
			get
			{
				return Path.Combine(RegistryStrings.PromotionDirectory, "bst_postboot");
			}
		}

		// Token: 0x06000312 RID: 786 RVA: 0x000040D8 File Offset: 0x000022D8
		private PostBootCloudInfoManager()
		{
		}

		// Token: 0x17000124 RID: 292
		// (get) Token: 0x06000313 RID: 787 RVA: 0x00017CA4 File Offset: 0x00015EA4
		// (set) Token: 0x06000314 RID: 788 RVA: 0x000040EB File Offset: 0x000022EB
		internal static PostBootCloudInfoManager Instance
		{
			get
			{
				if (PostBootCloudInfoManager.sInstance == null)
				{
					object obj = PostBootCloudInfoManager.sLock;
					lock (obj)
					{
						if (PostBootCloudInfoManager.sInstance == null)
						{
							PostBootCloudInfoManager.sInstance = new PostBootCloudInfoManager();
						}
					}
				}
				return PostBootCloudInfoManager.sInstance;
			}
			set
			{
				PostBootCloudInfoManager.sInstance = value;
			}
		}

		// Token: 0x17000125 RID: 293
		// (get) Token: 0x06000315 RID: 789 RVA: 0x00017CF4 File Offset: 0x00015EF4
		// (set) Token: 0x06000316 RID: 790 RVA: 0x000040F3 File Offset: 0x000022F3
		internal string Url
		{
			get
			{
				if (string.IsNullOrEmpty(this.mUrl))
				{
					this.mUrl = WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
					{
						RegistryManager.Instance.Host,
						"/bs4/post_boot"
					}));
				}
				return this.mUrl;
			}
			private set
			{
				this.mUrl = value;
			}
		}

		// Token: 0x06000317 RID: 791 RVA: 0x00017D4C File Offset: 0x00015F4C
		internal JToken GetPostBootData()
		{
			JToken result = null;
			try
			{
				string json = BstHttpClient.Get(this.Url, null, false, "Android", 0, 1, 0, false);
				Logger.Debug("Postboot data Url: " + this.Url);
				result = JToken.Parse(json);
			}
			catch (Exception ex)
			{
				Logger.Error("Error Getting Post Boot Data err: " + ex.ToString());
			}
			return result;
		}

		// Token: 0x06000318 RID: 792 RVA: 0x00017DB8 File Offset: 0x00015FB8
		internal void GetPostBootDataAsync(MainWindow mainWindow)
		{
			if (this.mPostBootCloudInfo == null)
			{
				new Thread(delegate()
				{
					this.mPostBootCloudInfo = new PostBootCloudInfo();
					if (File.Exists(PostBootCloudInfoManager.BstPostBootFilePath))
					{
						this.mPostBootCloudInfo = JsonConvert.DeserializeObject<PostBootCloudInfo>(File.ReadAllText(PostBootCloudInfoManager.BstPostBootFilePath));
					}
					JToken postBootData = this.GetPostBootData();
					if (postBootData != null)
					{
						PostBootCloudInfo postBootCloudInfo = new PostBootCloudInfo();
						PostBootCloudInfoManager.SetMinimizeGameNotificationsPackages(postBootCloudInfo, postBootData);
						PostBootCloudInfoManager.SetOnBoardingGamePackages(postBootCloudInfo, postBootData);
						PostBootCloudInfoManager.SetCustomCursorGamePackages(postBootCloudInfo, postBootData);
						PostBootCloudInfoManager.SaveToFile(postBootCloudInfo);
						this.mPostBootCloudInfo = postBootCloudInfo;
						PostBootCloudInfoManager.SendCustomCursorAppsListToPlayer(mainWindow);
					}
				})
				{
					IsBackground = true
				}.Start();
				return;
			}
			PostBootCloudInfoManager.SendCustomCursorAppsListToPlayer(mainWindow);
		}

		// Token: 0x06000319 RID: 793 RVA: 0x00017E0C File Offset: 0x0001600C
		private static void SendCustomCursorAppsListToPlayer(MainWindow mainWindow)
		{
			try
			{
				string text = string.Empty;
				foreach (string text2 in PostBootCloudInfoManager.Instance.mPostBootCloudInfo.AppSpecificCustomCursorInfo.CustomCursorAppPackages.CloudPackageList)
				{
					text += string.Format(CultureInfo.InvariantCulture, "{0} ", new object[]
					{
						text2
					});
				}
				mainWindow.mFrontendHandler.SendFrontendRequestAsync("sendCustomCursorEnabledApps", new Dictionary<string, string>
				{
					{
						"packages",
						text.Trim()
					}
				});
				Logger.Debug("CURSOR: vmName:{0} packages: {1} ", new object[]
				{
					mainWindow.mVmName,
					text.Trim()
				});
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in SendCustomCursorAppsListToPlayer: " + ex.ToString());
			}
		}

		// Token: 0x0600031A RID: 794 RVA: 0x00017F00 File Offset: 0x00016100
		private static void SaveToFile(PostBootCloudInfo postBootCloudInfo)
		{
			try
			{
				string contents = JsonConvert.SerializeObject(postBootCloudInfo, Formatting.Indented, Utils.GetSerializerSettings());
				if (!Directory.Exists(RegistryStrings.PromotionDirectory))
				{
					Directory.CreateDirectory(RegistryStrings.PromotionDirectory);
				}
				File.WriteAllText(PostBootCloudInfoManager.BstPostBootFilePath, contents);
			}
			catch (Exception)
			{
				Logger.Warning("Error in saving PostBootCloudInfo to file");
			}
		}

		// Token: 0x0600031B RID: 795 RVA: 0x00017F5C File Offset: 0x0001615C
		private static void SetMinimizeGameNotificationsPackages(PostBootCloudInfo mCurrentPostBootCloudInfo, JToken res)
		{
			try
			{
				JToken jtoken = JToken.Parse(res.GetValue("minimize_game_notification_apps"));
				if (jtoken["app_pkg_list"] != null)
				{
					JArray jarray = jtoken["app_pkg_list"] as JArray;
					if (jarray != null)
					{
						mCurrentPostBootCloudInfo.GameNotificationAppPackages = new AppPackageListObject(jarray.ToObject<List<string>>());
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Exception in parsing game notification packages: " + ex.ToString());
			}
		}

		// Token: 0x0600031C RID: 796 RVA: 0x00017FD8 File Offset: 0x000161D8
		private static void SetOnBoardingGamePackages(PostBootCloudInfo mCurrentPostBootCloudInfo, JToken res)
		{
			try
			{
				JToken jtoken = JToken.Parse(res.GetValue("onboarding_tutorial_apps"));
				if (jtoken["app_pkg_list"] != null)
				{
					JArray jarray = jtoken["app_pkg_list"] as JArray;
					if (jarray != null)
					{
						mCurrentPostBootCloudInfo.OnBoardingInfo.OnBoardingAppPackages = new AppPackageListObject(jarray.ToObject<List<string>>());
					}
				}
				if (jtoken["skip_button_timer"] != null)
				{
					mCurrentPostBootCloudInfo.OnBoardingInfo.OnBoardingSkipTimer = int.Parse(jtoken["skip_button_timer"].ToString(), CultureInfo.InvariantCulture);
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Exception in parsing onboarding packages: " + ex.ToString());
			}
		}

		// Token: 0x0600031D RID: 797 RVA: 0x0001808C File Offset: 0x0001628C
		private static void SetCustomCursorGamePackages(PostBootCloudInfo mCurrentPostBootCloudInfo, JToken res)
		{
			try
			{
				JToken jtoken = JToken.Parse(res.GetValue("custom_cursor_apps"));
				jtoken = JToken.Parse(jtoken.GetValue("moba"));
				if (jtoken["app_pkg_list"] != null)
				{
					JArray jarray = jtoken["app_pkg_list"] as JArray;
					if (jarray != null)
					{
						mCurrentPostBootCloudInfo.AppSpecificCustomCursorInfo.CustomCursorAppPackages = new AppPackageListObject(jarray.ToObject<List<string>>());
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Exception in parsing SetCustomCursorGamePackages: " + ex.ToString());
			}
		}

		// Token: 0x040001AF RID: 431
		private static PostBootCloudInfoManager sInstance = null;

		// Token: 0x040001B0 RID: 432
		private static readonly object sLock = new object();

		// Token: 0x040001B1 RID: 433
		private const string sPostBootCloudInfoFilename = "bst_postboot";

		// Token: 0x040001B2 RID: 434
		internal PostBootCloudInfo mPostBootCloudInfo;

		// Token: 0x040001B3 RID: 435
		private string mUrl = string.Empty;
	}
}
