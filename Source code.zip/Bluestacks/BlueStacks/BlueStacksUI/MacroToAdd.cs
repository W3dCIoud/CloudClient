﻿using System;
using System.CodeDom.Compiler;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200009F RID: 159
	public class MacroToAdd : UserControl, IComponentConnector
	{
		// Token: 0x06000620 RID: 1568 RVA: 0x00005F29 File Offset: 0x00004129
		public MacroToAdd(MergeMacroWindow window, string macroName)
		{
			this.InitializeComponent();
			this.mMergeMacroWindow = window;
			base.Tag = macroName;
			this.mMacroName.Text = macroName;
		}

		// Token: 0x06000621 RID: 1569 RVA: 0x00024DB8 File Offset: 0x00022FB8
		private void AddMacro_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			MergedMacroConfiguration mergedMacroConfiguration = new MergedMacroConfiguration();
			mergedMacroConfiguration.MacrosToRun.Add(this.mMacroName.Text);
			MergedMacroConfiguration mergedMacroConfiguration2 = mergedMacroConfiguration;
			MergeMacroWindow mergeMacroWindow = this.mMergeMacroWindow;
			int mAddedMacroTag = mergeMacroWindow.mAddedMacroTag;
			mergeMacroWindow.mAddedMacroTag = mAddedMacroTag + 1;
			mergedMacroConfiguration2.Tag = mAddedMacroTag;
			if (this.mMergeMacroWindow.MergedMacroRecording.MergedMacroConfigurations == null)
			{
				this.mMergeMacroWindow.MergedMacroRecording.MergedMacroConfigurations = new ObservableCollection<MergedMacroConfiguration>();
			}
			this.mMergeMacroWindow.MergedMacroRecording.MergedMacroConfigurations.Add(mergedMacroConfiguration);
		}

		// Token: 0x06000622 RID: 1570 RVA: 0x00005F09 File Offset: 0x00004109
		private void MacroName_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			(sender as TextBlock).SetTextblockTooltip();
		}

		// Token: 0x06000623 RID: 1571 RVA: 0x00024E3C File Offset: 0x0002303C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/macrotoadd.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000624 RID: 1572 RVA: 0x00024E6C File Offset: 0x0002306C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mMacroName = (TextBlock)target;
				this.mMacroName.SizeChanged += this.MacroName_SizeChanged;
				return;
			}
			if (connectionId != 2)
			{
				this._contentLoaded = true;
				return;
			}
			this.mAddMacro = (CustomPictureBox)target;
			this.mAddMacro.MouseLeftButtonUp += this.AddMacro_MouseLeftButtonUp;
		}

		// Token: 0x0400035C RID: 860
		private MergeMacroWindow mMergeMacroWindow;

		// Token: 0x0400035D RID: 861
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mMacroName;

		// Token: 0x0400035E RID: 862
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mAddMacro;

		// Token: 0x0400035F RID: 863
		private bool _contentLoaded;
	}
}
