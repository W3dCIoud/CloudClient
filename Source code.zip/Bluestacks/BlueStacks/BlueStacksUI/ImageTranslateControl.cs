﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media.Imaging;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000C3 RID: 195
	public class ImageTranslateControl : UserControl, IDimOverlayControl, IComponentConnector
	{
		// Token: 0x170001C7 RID: 455
		// (get) Token: 0x06000802 RID: 2050 RVA: 0x00007246 File Offset: 0x00005446
		// (set) Token: 0x06000803 RID: 2051 RVA: 0x0000724D File Offset: 0x0000544D
		public static ImageTranslateControl Instance { get; private set; }

		// Token: 0x06000804 RID: 2052 RVA: 0x0002F364 File Offset: 0x0002D564
		public ImageTranslateControl(MainWindow parentWindow)
		{
			this.InitializeComponent();
			ImageTranslateControl.Instance = this;
			this.ParentWindow = parentWindow;
			if (this.ParentWindow != null)
			{
				this.mGrid.Width = parentWindow.FrontendParentGrid.ActualWidth;
				this.mGrid.Height = parentWindow.FrontendParentGrid.ActualHeight + 40.0;
			}
			this.mLoadingImage.Visibility = Visibility.Visible;
			this.mFrontEndImage.Visibility = Visibility.Collapsed;
			this.mBootText.Visibility = Visibility.Visible;
			this.mBootText.Text = LocaleStrings.GetLocalizedString("STRING_LOADING_MESSAGE");
		}

		// Token: 0x06000805 RID: 2053 RVA: 0x0002F404 File Offset: 0x0002D604
		public void GetTranslateImage(Bitmap bitmap)
		{
			if (bitmap != null)
			{
				this.httpBackGroundThread = new Thread(delegate()
				{
					using (MemoryStream memoryStream = new MemoryStream())
					{
						bitmap.Save(memoryStream, ImageFormat.Jpeg);
						memoryStream.Position = 0L;
						Dictionary<string, object> dictionary = new Dictionary<string, object>();
						string text = RegistryManager.Instance.UserSelectedLocale;
						text = text.Substring(0, 2);
						if (string.Equals(text, "zh-CN", StringComparison.InvariantCulture) || string.Equals(text, "zh-TW", StringComparison.InvariantCulture))
						{
							text = RegistryManager.Instance.UserSelectedLocale;
						}
						if (!string.IsNullOrEmpty(RegistryManager.Instance.TargetLocale))
						{
							text = RegistryManager.Instance.TargetLocale;
						}
						dictionary.Add("locale", text);
						dictionary.Add("inputImage", new FormFile
						{
							Name = "image.jpg",
							ContentType = "image/jpeg",
							Stream = memoryStream
						});
						dictionary.Add("oem", RegistryManager.Instance.Oem);
						dictionary.Add("guid", RegistryManager.Instance.UserGuid);
						dictionary.Add("prod_ver", RegistryManager.Instance.ClientVersion);
						string text2 = Convert.ToBase64String(memoryStream.ToArray());
						text2 = text2 + RegistryManager.Instance.UserGuid + "BstTranslate";
						_MD5 md = new _MD5
						{
							Value = text2
						};
						dictionary.Add("token", md.FingerPrint);
						string url = string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
						{
							RegistryManager.Instance.Host,
							"/translate/postimage"
						});
						if (!string.IsNullOrEmpty(RegistryManager.Instance.TargetLocaleUrl))
						{
							url = RegistryManager.Instance.TargetLocaleUrl;
						}
						string text3 = string.Empty;
						byte[] dataArray = null;
						try
						{
							text3 = BstHttpClient.PostMultipart(url, dictionary, out dataArray);
						}
						catch (Exception ex)
						{
							Logger.Error("error while downloading translated image.." + ex.ToString());
							text3 = "error";
						}
						if (text3.Contains("error"))
						{
							this.Dispatcher.Invoke(new Action(delegate()
							{
								this.mLoadingImage.Visibility = Visibility.Collapsed;
								this.mBootText.Text = LocaleStrings.GetLocalizedString("STRING_SOME_ERROR_OCCURED");
							}), new object[0]);
						}
						else
						{
							this.Dispatcher.Invoke(new Action(delegate()
							{
								BitmapImage source = ImageTranslateControl.ByteArrayToImage(dataArray);
								this.mFrontEndImage.Source = source;
								this.mFrontEndImage.ReloadImages();
								this.mFrontEndImage.Visibility = Visibility.Visible;
								this.mLoadingImage.Visibility = Visibility.Collapsed;
								this.mBootText.Visibility = Visibility.Collapsed;
							}), new object[0]);
						}
					}
				})
				{
					IsBackground = true
				};
				this.httpBackGroundThread.Start();
			}
		}

		// Token: 0x06000806 RID: 2054 RVA: 0x0002F458 File Offset: 0x0002D658
		public static BitmapImage ByteArrayToImage(byte[] dataArray)
		{
			BitmapImage result;
			using (MemoryStream memoryStream = new MemoryStream(dataArray))
			{
				BitmapImage bitmapImage = new BitmapImage();
				bitmapImage.BeginInit();
				bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
				bitmapImage.StreamSource = memoryStream;
				bitmapImage.EndInit();
				result = bitmapImage;
			}
			return result;
		}

		// Token: 0x06000807 RID: 2055 RVA: 0x0002F4AC File Offset: 0x0002D6AC
		public static byte[] ImageToByteArray(string filePath)
		{
			System.Drawing.Image image = System.Drawing.Image.FromFile(filePath);
			byte[] result;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				image.Save(memoryStream, ImageFormat.Png);
				result = memoryStream.ToArray();
			}
			return result;
		}

		// Token: 0x170001C8 RID: 456
		// (get) Token: 0x06000808 RID: 2056 RVA: 0x00007255 File Offset: 0x00005455
		// (set) Token: 0x06000809 RID: 2057 RVA: 0x00005D29 File Offset: 0x00003F29
		public bool IsCloseOnOverLayClick
		{
			get
			{
				return true;
			}
			set
			{
			}
		}

		// Token: 0x170001C9 RID: 457
		// (get) Token: 0x0600080A RID: 2058 RVA: 0x00006230 File Offset: 0x00004430
		// (set) Token: 0x0600080B RID: 2059 RVA: 0x00005D29 File Offset: 0x00003F29
		public bool ShowControlInSeparateWindow
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		// Token: 0x0600080C RID: 2060 RVA: 0x00007258 File Offset: 0x00005458
		public bool Close()
		{
			if (this.httpBackGroundThread != null)
			{
				this.httpBackGroundThread.Abort();
			}
			if (this.ParentWindow != null)
			{
				this.ParentWindow.HideDimOverlay();
			}
			base.Visibility = Visibility.Hidden;
			ImageTranslateControl.Instance = null;
			return true;
		}

		// Token: 0x0600080D RID: 2061 RVA: 0x0000624E File Offset: 0x0000444E
		public bool Show()
		{
			base.Visibility = Visibility.Visible;
			return true;
		}

		// Token: 0x0600080E RID: 2062 RVA: 0x0000728E File Offset: 0x0000548E
		public bool Hide()
		{
			if (this.ParentWindow != null)
			{
				this.ParentWindow.HideDimOverlay();
			}
			base.Visibility = Visibility.Hidden;
			return true;
		}

		// Token: 0x0600080F RID: 2063 RVA: 0x000072AB File Offset: 0x000054AB
		private void mCloseButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.Close();
		}

		// Token: 0x06000810 RID: 2064 RVA: 0x0002F4F8 File Offset: 0x0002D6F8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/imagetranslatecontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000811 RID: 2065 RVA: 0x0002F528 File Offset: 0x0002D728
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mGrid = (Grid)target;
				return;
			case 2:
				this.mCloseButton = (CustomPictureBox)target;
				this.mCloseButton.MouseLeftButtonUp += this.mCloseButton_MouseLeftButtonUp;
				return;
			case 3:
				this.mFrontEndImage = (CustomPictureBox)target;
				return;
			case 4:
				this.mLoadingImage = (CustomPictureBox)target;
				return;
			case 5:
				this.mBootText = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040004C7 RID: 1223
		private MainWindow ParentWindow;

		// Token: 0x040004C8 RID: 1224
		private Thread httpBackGroundThread;

		// Token: 0x040004CA RID: 1226
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mGrid;

		// Token: 0x040004CB RID: 1227
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCloseButton;

		// Token: 0x040004CC RID: 1228
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mFrontEndImage;

		// Token: 0x040004CD RID: 1229
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mLoadingImage;

		// Token: 0x040004CE RID: 1230
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mBootText;

		// Token: 0x040004CF RID: 1231
		private bool _contentLoaded;
	}
}
