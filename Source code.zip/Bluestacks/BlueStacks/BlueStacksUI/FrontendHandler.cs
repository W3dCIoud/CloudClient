﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200018F RID: 399
	internal class FrontendHandler
	{
		// Token: 0x14000013 RID: 19
		// (add) Token: 0x06000F88 RID: 3976 RVA: 0x000640B4 File Offset: 0x000622B4
		// (remove) Token: 0x06000F89 RID: 3977 RVA: 0x000640EC File Offset: 0x000622EC
		internal event EventHandler mEventOnFrontendClosed;

		// Token: 0x06000F8A RID: 3978 RVA: 0x00064124 File Offset: 0x00062324
		internal FrontendHandler(MainWindow window)
		{
			this.ParentWindow = window;
			this.mWindowTitle = Oem.Instance.CommonAppTitleText + this.ParentWindow.mVmName;
			this.StartFrontendAfterRAMCheck();
		}

		// Token: 0x06000F8B RID: 3979 RVA: 0x0000B510 File Offset: 0x00009710
		internal void StartFrontendAfterRAMCheck()
		{
			if (!FeatureManager.Instance.IsCustomUIForDMM && !this.ParentWindow.Utils.IsRequiredFreeRAMAvailable())
			{
				this.mIsSufficientRAMAvailable = false;
				return;
			}
			this.StartFrontend();
		}

		// Token: 0x06000F8C RID: 3980 RVA: 0x00064184 File Offset: 0x00062384
		internal void FrontendHandler_ShowLowRAMMessage()
		{
			CustomMessageWindow cmw = new CustomMessageWindow();
			cmw.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_PERF_WARNING");
			cmw.AddWarning(LocaleStrings.GetLocalizedString("STRING_LOW_AVAILABLE_RAM_TITLE"), "message_error");
			cmw.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_LOW_AVAILABLE_RAM_TEXT1") + Environment.NewLine + LocaleStrings.GetLocalizedString("STRING_LOW_AVAILABLE_RAM_TEXT2");
			cmw.AddButton(ButtonColors.Red, LocaleStrings.GetLocalizedString("STRING_CONTINUE_ANYWAY"), delegate(object o, EventArgs args)
			{
				cmw.Close();
				this.StartFrontend();
			}, null, false, null);
			cmw.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_CLOSE_BLUESTACKS"), delegate(object o, EventArgs args)
			{
				this.ParentWindow.Close();
			}, null, false, null);
			cmw.Owner = this.ParentWindow;
			cmw.ShowDialog();
		}

		// Token: 0x06000F8D RID: 3981 RVA: 0x0000B53E File Offset: 0x0000973E
		internal void StartFrontend()
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				Logger.Info("BOOT_STAGE: Starting player");
				if (ProcessUtils.IsLockInUse(Strings.GetPlayerLockName(this.ParentWindow.mVmName)))
				{
					this.KillFrontend();
				}
				this.mEventOnFrontendClosed = null;
				this.mIsSufficientRAMAvailable = true;
				this.mIsRestartFrontendWhenClosed = true;
				this.ParentWindow.Utils.CheckGuestFailedAsync();
				this.mFrontendStartTime = DateTime.Now;
				int num = BluestacksProcessHelper.StartFrontend(this.ParentWindow.mVmName);
				if (num == -5)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						Logger.Error("Hyper v enabled on this machine");
						CustomMessageWindow customMessageWindow = new CustomMessageWindow();
						BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_RESTART_UTILITY_CANNOT_START", "");
						customMessageWindow.AddWarning(LocaleStrings.GetLocalizedString("STRING_HYPERV_ENABLED_WARNING"), "message_error");
						BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_HYPERV_ENABLED_MESSAGE", "");
						customMessageWindow.AddButton(ButtonColors.Blue, "STRING_CHECK_FAQ", delegate(object sender1, EventArgs e1)
						{
							BlueStacksUIUtils.OpenUrl(WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
							{
								WebHelper.GetServerHost(),
								"help_articles"
							})) + "&article=disable_hypervisor");
						}, null, false, null);
						customMessageWindow.ShowDialog();
						App.ExitApplication();
					}), new object[0]);
					return;
				}
				if (num == -2)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						Logger.Error("Android File Integrity check failed");
						CustomMessageWindow customMessageWindow = new CustomMessageWindow();
						BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_CORRUPT_INSTALLATION", "");
						BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_CORRUPT_INSTALLATION_MESSAGE", "");
						customMessageWindow.AddButton(ButtonColors.Blue, "STRING_EXIT", null, null, false, null);
						customMessageWindow.ShowDialog();
						App.ExitApplication();
					}), new object[0]);
					return;
				}
				if (num == -7)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						Logger.Error("VBox couldn't detect driver");
						CustomMessageWindow customMessageWindow = new CustomMessageWindow();
						BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_ENGINE_FAIL_HEADER", "");
						BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_COULDNT_BOOT_TRY_RESTART", "");
						customMessageWindow.AddButton(ButtonColors.Blue, "STRING_RESTART_PC", new EventHandler(this.RestartPCEvent), null, false, null);
						customMessageWindow.AddButton(ButtonColors.White, "STRING_EXIT", null, null, false, null);
						customMessageWindow.ShowDialog();
						App.ExitApplication();
					}), new object[0]);
					return;
				}
				if (num == -6)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						Logger.Error("Unable to initialise audio on this machine");
						CustomMessageWindow customMessageWindow = new CustomMessageWindow();
						customMessageWindow.ImageName = "sound_error";
						BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_AUDIO_SERVICE_FAILURE", "");
						BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlockTitle, "STRING_AUDIO_SERVICE_FAILUE_FIX", "");
						customMessageWindow.BodyTextBlockTitle.Visibility = Visibility.Visible;
						BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_AUDIO_SERVICE_FAILURE_ALTERNATE_FIX", "");
						customMessageWindow.AddButton(ButtonColors.Blue, "STRING_READ_MORE", delegate(object sender1, EventArgs e1)
						{
							BlueStacksUIUtils.OpenUrl(WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
							{
								WebHelper.GetServerHost(),
								"help_articles"
							})) + "&article=audio_service_issue");
						}, "external_link", true, null);
						customMessageWindow.ShowDialog();
						App.ExitApplication();
					}), new object[0]);
					return;
				}
				if (num == -10)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						string url = null;
						url = WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
						{
							WebHelper.GetServerHost(),
							"help_articles"
						}));
						url = string.Format(CultureInfo.InvariantCulture, "{0}&article={1}", new object[]
						{
							url,
							"enable_virtualization"
						});
						string path = "STRING_VTX_DISABLED_ENABLEIT_BODY";
						CustomMessageWindow customMessageWindow = new CustomMessageWindow();
						BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_RESTART_UTILITY_CANNOT_START", "");
						customMessageWindow.AddAboveBodyWarning(LocaleStrings.GetLocalizedString("STRING_VTX_DISABLED_WARNING"));
						customMessageWindow.AboveBodyWarningTextBlock.Visibility = Visibility.Visible;
						customMessageWindow.MessageIcon.VerticalAlignment = VerticalAlignment.Center;
						BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, path, "");
						customMessageWindow.AddButton(ButtonColors.Blue, "STRING_CHECK_FAQ", delegate(object sender1, EventArgs e1)
						{
							BlueStacksUIUtils.OpenUrl(url);
						}, null, false, null);
						customMessageWindow.AddButton(ButtonColors.White, "STRING_EXIT", null, null, false, null);
						customMessageWindow.ShowDialog();
						Process.GetCurrentProcess().Kill();
					}), new object[0]);
					return;
				}
				if (this.mIsRestartFrontendWhenClosed)
				{
					this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
					{
						if (this.frontendRestartAttempts < 2)
						{
							this.frontendRestartAttempts++;
							this.ParentWindow.RestartFrontend();
						}
					}), new object[0]);
				}
			});
		}

		// Token: 0x06000F8E RID: 3982 RVA: 0x0000B552 File Offset: 0x00009752
		private void RestartPCEvent(object sender, EventArgs e)
		{
			Process.Start("shutdown.exe", "/r /t 0");
		}

		// Token: 0x06000F8F RID: 3983 RVA: 0x0000B564 File Offset: 0x00009764
		internal void KillFrontendAsync()
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				this.KillFrontend();
			});
		}

		// Token: 0x06000F90 RID: 3984 RVA: 0x00064274 File Offset: 0x00062474
		internal void KillFrontend()
		{
			try
			{
				this.mIsRestartFrontendWhenClosed = false;
				HTTPUtils.SendRequestToEngine("shutdown", null, "Android", 0, null, false, 1, 0, this.ParentWindow.mVmName);
			}
			catch
			{
			}
			finally
			{
				EventHandler eventHandler = this.mEventOnFrontendClosed;
				if (eventHandler != null)
				{
					eventHandler(this.ParentWindow.mVmName, null);
				}
			}
		}

		// Token: 0x06000F91 RID: 3985 RVA: 0x000642E8 File Offset: 0x000624E8
		internal void EnableKeyMapping(bool isEnabled)
		{
			try
			{
				this.SendFrontendRequestAsync("setKeymappingState", new Dictionary<string, string>
				{
					{
						"keymapping",
						isEnabled.ToString(CultureInfo.InvariantCulture)
					}
				});
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send EnableKeyMapping to frontend... Err : " + ex.ToString());
			}
		}

		// Token: 0x06000F92 RID: 3986 RVA: 0x00064348 File Offset: 0x00062548
		internal void GetScreenShot(string filePath)
		{
			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{
					"path",
					filePath
				}
			};
			this.SendFrontendRequestAsync("getScreenshot", data);
		}

		// Token: 0x06000F93 RID: 3987 RVA: 0x00064374 File Offset: 0x00062574
		internal void FrontendVisibleChanged(bool value)
		{
			try
			{
				Dictionary<string, string> dictionary = new Dictionary<string, string>
				{
					{
						"new_value",
						Convert.ToString(value, CultureInfo.InvariantCulture)
					}
				};
				if (RegistryManager.Instance.AreAllInstancesMuted || this.ParentWindow.EngineInstanceRegistry.IsMuted)
				{
					dictionary.Add("is_mute", Convert.ToString(true, CultureInfo.InvariantCulture));
				}
				else
				{
					dictionary.Add("is_mute", Convert.ToString(false, CultureInfo.InvariantCulture));
				}
				this.SendFrontendRequestAsync("frontendVisibleChanged", dictionary);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send refresh keymap to frontend... Err : " + ex.ToString());
			}
		}

		// Token: 0x06000F94 RID: 3988 RVA: 0x00064420 File Offset: 0x00062620
		internal void RefreshKeyMap(string packageName)
		{
			try
			{
				Dictionary<string, string> data = new Dictionary<string, string>
				{
					{
						"package",
						packageName
					}
				};
				this.SendFrontendRequestAsync("refreshKeymap", data);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send refresh keymap to frontend... Err : " + ex.ToString());
			}
		}

		// Token: 0x06000F95 RID: 3989 RVA: 0x00064478 File Offset: 0x00062678
		internal void DeactivateFrontend()
		{
			try
			{
				if (this.mFrontendHandle != IntPtr.Zero)
				{
					Logger.Debug("KMP deactivateFrontend");
					this.SendFrontendRequestAsync("deactivateFrontend", null);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to send deactivate to frontend.. Err : " + ex.ToString());
			}
		}

		// Token: 0x06000F96 RID: 3990 RVA: 0x000644D8 File Offset: 0x000626D8
		internal void ToggleStreamingMode(bool state)
		{
			this.ParentWindow.mTopBar.mSettingsMenuPopup.IsOpen = false;
			Action <>9__2;
			this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
			{
				Logger.Info("Streaming mode toggle called with state.." + state.ToString());
				this.ParentWindow.mStreamingModeEnabled = state;
				string value = this.ParentWindow.Handle.ToString();
				if (state)
				{
					value = "0";
				}
				Rectangle windowRectangle = this.GetWindowRectangle();
				if (windowRectangle.Width == 0 && windowRectangle.Height == 0)
				{
					windowRectangle.Width = (int)this.ParentWindow.Width;
					windowRectangle.Height = (int)this.ParentWindow.Height;
				}
				Dictionary<string, string> dict = new Dictionary<string, string>
				{
					{
						"ParentHandle",
						value
					},
					{
						"X",
						windowRectangle.X.ToString(CultureInfo.InvariantCulture)
					},
					{
						"Y",
						windowRectangle.Y.ToString(CultureInfo.InvariantCulture)
					},
					{
						"Width",
						windowRectangle.Width.ToString(CultureInfo.InvariantCulture)
					},
					{
						"Height",
						windowRectangle.Height.ToString(CultureInfo.InvariantCulture)
					}
				};
				ThreadPool.QueueUserWorkItem(delegate(object obj1)
				{
					try
					{
						JObject jobject = JObject.Parse(JArray.Parse(this.SendFrontendRequest("setparent", dict))[0].ToString());
						if (jobject["success"].ToObject<bool>())
						{
							this.mFrontendHandle = new IntPtr(jobject["frontendhandle"].ToObject<int>());
							Dispatcher dispatcher = this.ParentWindow.Dispatcher;
							Action method;
							if ((method = <>9__2) == null)
							{
								method = (<>9__2 = delegate()
								{
									this.ShowGLWindow();
								});
							}
							dispatcher.Invoke(method, new object[0]);
						}
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to send Show event to engine... err : " + ex.ToString());
					}
				});
			}), new object[0]);
		}

		// Token: 0x06000F97 RID: 3991 RVA: 0x00064534 File Offset: 0x00062734
		internal void ShowGLWindow()
		{
			if (this.CanfrontendBeResizedAndFocused())
			{
				this.ResizeWindow();
				return;
			}
			if (this.ParentWindow.mFrontendGrid.IsVisible)
			{
				if (!this.ParentWindow.Handle.ToString().Equals("0", StringComparison.OrdinalIgnoreCase))
				{
					this.sIsfrontendAlreadyVisible = true;
					if (this.mFrontendHandle == IntPtr.Zero)
					{
						ThreadPool.QueueUserWorkItem(delegate(object obj)
						{
							try
							{
								this.ParentWindow.Dispatcher.Invoke(new Action(delegate()
								{
									Rectangle windowRectangle = this.GetWindowRectangle();
									Dictionary<string, string> dict = new Dictionary<string, string>
									{
										{
											"ParentHandle",
											(!this.ParentWindow.mStreamingModeEnabled) ? this.ParentWindow.Handle.ToString() : "0"
										},
										{
											"X",
											windowRectangle.X.ToString(CultureInfo.InvariantCulture)
										},
										{
											"Y",
											windowRectangle.Y.ToString(CultureInfo.InvariantCulture)
										},
										{
											"Width",
											windowRectangle.Width.ToString(CultureInfo.InvariantCulture)
										},
										{
											"Height",
											windowRectangle.Height.ToString(CultureInfo.InvariantCulture)
										}
									};
									if (windowRectangle.Width == 0 || windowRectangle.Height == 0)
									{
										this.sIsfrontendAlreadyVisible = false;
										return;
									}
									ThreadPool.QueueUserWorkItem(delegate(object obj1)
									{
										try
										{
											object obj2 = this.mLockObject;
											lock (obj2)
											{
												if (this.mFrontendHandle == IntPtr.Zero)
												{
													JObject jobject = JObject.Parse(JArray.Parse(this.SendFrontendRequest("setParent", dict))[0].ToString());
													if (jobject["success"].ToObject<bool>())
													{
														this.mFrontendHandle = new IntPtr(jobject["frontendhandle"].ToObject<int>());
													}
													Action<MainWindow> reparentingCompletedAction = this.ReparentingCompletedAction;
													if (reparentingCompletedAction != null)
													{
														reparentingCompletedAction(this.ParentWindow);
													}
													Logger.Debug("Set parent call completed. handle: " + this.mFrontendHandle.ToString());
												}
											}
										}
										catch (Exception ex2)
										{
											Logger.Error("Failed to send Show event to engine... err : " + ex2.ToString());
										}
									});
								}), new object[0]);
							}
							catch (Exception ex)
							{
								Logger.Error("Failed to send Show event to engine... err : " + ex.ToString());
							}
						});
						return;
					}
					this.ResizeWindow();
					return;
				}
			}
			else
			{
				this.sIsfrontendAlreadyVisible = false;
				if (this.mFrontendHandle != IntPtr.Zero)
				{
					InteropWindow.ShowWindow(this.mFrontendHandle, 0);
					if (KMManager.dictOverlayWindow.ContainsKey(this.ParentWindow) && this.ParentWindow.WindowState != WindowState.Maximized)
					{
						KMManager.ShowOverlayWindow(this.ParentWindow, false, false);
					}
				}
			}
		}

		// Token: 0x06000F98 RID: 3992 RVA: 0x0000B578 File Offset: 0x00009778
		private bool CanfrontendBeResizedAndFocused()
		{
			return (this.ParentWindow.mDimOverlay == null || !this.ParentWindow.mDimOverlay.IsWindowVisible) && this.ParentWindow.mFrontendGrid.IsVisible && this.sIsfrontendAlreadyVisible;
		}

		// Token: 0x06000F99 RID: 3993 RVA: 0x00064608 File Offset: 0x00062808
		internal void ResizeWindow()
		{
			Rectangle windowRectangle = this.GetWindowRectangle();
			if (this.ParentWindow.mStreamingModeEnabled)
			{
				InteropWindow.ShowWindow(this.mFrontendHandle, 5);
			}
			else
			{
				InteropWindow.SetWindowPos(this.mFrontendHandle, (IntPtr)0, windowRectangle.X, windowRectangle.Y, windowRectangle.Width, windowRectangle.Height, 16448U);
			}
			if (KMManager.dictOverlayWindow.ContainsKey(this.ParentWindow))
			{
				if (this.ParentWindow.StaticComponents.mLastMappableWindowHandle == IntPtr.Zero)
				{
					this.ParentWindow.StaticComponents.mLastMappableWindowHandle = this.mFrontendHandle;
				}
				KMManager.dictOverlayWindow[this.ParentWindow].UpdateSize();
			}
			this.FocusFrontend();
			RegistryManager.Instance.FrontendHeight = windowRectangle.Height;
			RegistryManager.Instance.FrontendWidth = windowRectangle.Width;
		}

		// Token: 0x06000F9A RID: 3994 RVA: 0x000646EC File Offset: 0x000628EC
		internal Rectangle GetWindowRectangle()
		{
			Grid mFrontendGrid = this.ParentWindow.mFrontendGrid;
			System.Windows.Point point = mFrontendGrid.TranslatePoint(new System.Windows.Point(0.0, 0.0), this.ParentWindow);
			System.Drawing.Point location = new System.Drawing.Point((int)(MainWindow.sScalingFactor * point.X), (int)(MainWindow.sScalingFactor * point.Y));
			System.Drawing.Size size = new System.Drawing.Size((int)(mFrontendGrid.ActualWidth * MainWindow.sScalingFactor), (int)(mFrontendGrid.ActualHeight * MainWindow.sScalingFactor));
			return new Rectangle(location, size);
		}

		// Token: 0x06000F9B RID: 3995 RVA: 0x00064774 File Offset: 0x00062974
		internal void ChangeFrontendToPortraitMode()
		{
			Rectangle windowRectangle = this.GetWindowRectangle();
			InteropWindow.SetWindowPos(this.mFrontendHandle, (IntPtr)0, windowRectangle.X, windowRectangle.Y, windowRectangle.Width, windowRectangle.Height, 16448U);
		}

		// Token: 0x06000F9C RID: 3996 RVA: 0x000647BC File Offset: 0x000629BC
		internal void FocusFrontend()
		{
			if (this.CanfrontendBeResizedAndFocused() && !this.ParentWindow.mStreamingModeEnabled && !this.ParentWindow.mIsFocusComeFromImap && this.ParentWindow.IsActive)
			{
				InteropWindow.SetFocus(this.mFrontendHandle);
				Logger.Debug("KMP REFRESH Frontend...." + Environment.StackTrace);
				this.SendFrontendRequestAsync("refreshWindow", null);
				return;
			}
			Logger.Debug("KMP CanfrontendBeResizedAndFocused false " + this.ParentWindow.mFrontendGrid.IsVisible.ToString() + this.sIsfrontendAlreadyVisible.ToString());
		}

		// Token: 0x06000F9D RID: 3997 RVA: 0x0000B5B5 File Offset: 0x000097B5
		internal void SendFrontendRequestAsync(string path, Dictionary<string, string> data = null)
		{
			ThreadPool.QueueUserWorkItem(delegate(object obj)
			{
				this.SendFrontendRequest(path, data);
			});
		}

		// Token: 0x06000F9E RID: 3998 RVA: 0x00064858 File Offset: 0x00062A58
		internal string SendFrontendRequest(string path, Dictionary<string, string> data = null)
		{
			string result = string.Empty;
			try
			{
				result = HTTPUtils.SendRequestToEngine(path, data, this.ParentWindow.mVmName, 0, null, false, 1, 0, "");
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in SendFrontendRequest: " + ex.ToString());
			}
			return result;
		}

		// Token: 0x06000F9F RID: 3999 RVA: 0x000648B4 File Offset: 0x00062AB4
		internal static void UpdateBootTimeInregistry(DateTime time)
		{
			try
			{
				int lastBootTime = (int)(DateTime.Now - time).TotalSeconds * 1000;
				int noOfBootCompleted = RegistryManager.Instance.NoOfBootCompleted;
				RegistryManager.Instance.LastBootTime = lastBootTime;
				RegistryManager.Instance.NoOfBootCompleted = noOfBootCompleted + 1;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in UpdateBootTimeInregistry: " + ex.ToString());
			}
		}

		// Token: 0x06000FA0 RID: 4000 RVA: 0x0006492C File Offset: 0x00062B2C
		internal void UpdateOverlaySizeStatus()
		{
			this.SendFrontendRequestAsync("sendGlWindowSize", new Dictionary<string, string>
			{
				{
					"updateSize",
					(this.ParentWindow.WindowState == WindowState.Maximized).ToString(CultureInfo.InvariantCulture)
				}
			});
		}

		// Token: 0x04000A93 RID: 2707
		private int frontendRestartAttempts;

		// Token: 0x04000A94 RID: 2708
		private MainWindow ParentWindow;

		// Token: 0x04000A95 RID: 2709
		internal string mWindowTitle;

		// Token: 0x04000A96 RID: 2710
		private bool sIsfrontendAlreadyVisible;

		// Token: 0x04000A97 RID: 2711
		internal IntPtr mFrontendHandle;

		// Token: 0x04000A98 RID: 2712
		private bool mIsRestartFrontendWhenClosed;

		// Token: 0x04000A99 RID: 2713
		internal DateTime mFrontendStartTime = DateTime.Now;

		// Token: 0x04000A9B RID: 2715
		internal bool mIsSufficientRAMAvailable = true;

		// Token: 0x04000A9C RID: 2716
		public bool IsShootingModeActivated;

		// Token: 0x04000A9D RID: 2717
		private object mLockObject = new object();

		// Token: 0x04000A9E RID: 2718
		internal Action<MainWindow> ReparentingCompletedAction;
	}
}
