﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200025D RID: 605
	public class PercentageChangedEventArgs : EventArgs
	{
		// Token: 0x170002D6 RID: 726
		// (get) Token: 0x0600156D RID: 5485 RVA: 0x0000E9B8 File Offset: 0x0000CBB8
		// (set) Token: 0x0600156E RID: 5486 RVA: 0x0000E9C0 File Offset: 0x0000CBC0
		public int Percentage { get; set; }
	}
}
