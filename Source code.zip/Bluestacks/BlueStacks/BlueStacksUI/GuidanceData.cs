﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000041 RID: 65
	[Serializable]
	public class GuidanceData
	{
		// Token: 0x1700012A RID: 298
		// (get) Token: 0x0600032B RID: 811 RVA: 0x00004198 File Offset: 0x00002398
		// (set) Token: 0x0600032C RID: 812 RVA: 0x000041A0 File Offset: 0x000023A0
		public ObservableCollection<GuidanceCategoryViewModel> KeymapViewGuidance { get; private set; } = new ObservableCollection<GuidanceCategoryViewModel>();

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x0600032D RID: 813 RVA: 0x000041A9 File Offset: 0x000023A9
		// (set) Token: 0x0600032E RID: 814 RVA: 0x000041B1 File Offset: 0x000023B1
		public ObservableCollection<GuidanceCategoryViewModel> GamepadViewGuidance { get; private set; } = new ObservableCollection<GuidanceCategoryViewModel>();

		// Token: 0x1700012C RID: 300
		// (get) Token: 0x0600032F RID: 815 RVA: 0x000041BA File Offset: 0x000023BA
		// (set) Token: 0x06000330 RID: 816 RVA: 0x000041C2 File Offset: 0x000023C2
		public ObservableCollection<GuidanceCategoryEditModel> KeymapEditGuidance { get; private set; } = new ObservableCollection<GuidanceCategoryEditModel>();

		// Token: 0x1700012D RID: 301
		// (get) Token: 0x06000331 RID: 817 RVA: 0x000041CB File Offset: 0x000023CB
		// (set) Token: 0x06000332 RID: 818 RVA: 0x000041D3 File Offset: 0x000023D3
		public ObservableCollection<GuidanceCategoryEditModel> GamepadEditGuidance { get; private set; } = new ObservableCollection<GuidanceCategoryEditModel>();

		// Token: 0x06000333 RID: 819 RVA: 0x000041DC File Offset: 0x000023DC
		public void Clear()
		{
			this.KeymapViewGuidance.Clear();
			this.GamepadViewGuidance.Clear();
			this.KeymapEditGuidance.Clear();
			this.GamepadEditGuidance.Clear();
			this.mKeymapEditGuidanceCloned = null;
			this.mGamepadEditGuidanceCloned = null;
		}

		// Token: 0x06000334 RID: 820 RVA: 0x00004218 File Offset: 0x00002418
		public void SaveOriginalData()
		{
			this.mKeymapEditGuidanceCloned = this.KeymapEditGuidance.DeepCopy<ObservableCollection<GuidanceCategoryEditModel>>();
			this.mGamepadEditGuidanceCloned = this.GamepadEditGuidance.DeepCopy<ObservableCollection<GuidanceCategoryEditModel>>();
		}

		// Token: 0x06000335 RID: 821 RVA: 0x0000423C File Offset: 0x0000243C
		public void Reset()
		{
			this.KeymapEditGuidance = this.mKeymapEditGuidanceCloned.DeepCopy<ObservableCollection<GuidanceCategoryEditModel>>();
			this.GamepadEditGuidance = this.mGamepadEditGuidanceCloned.DeepCopy<ObservableCollection<GuidanceCategoryEditModel>>();
		}

		// Token: 0x06000336 RID: 822 RVA: 0x000181A8 File Offset: 0x000163A8
		public void AddGuidance(bool isGamePad, string category, string guidanceText, string guidanceKey, string actionItem, IMAction imAction)
		{
			if (imAction != null && !string.IsNullOrEmpty(guidanceKey) && !string.IsNullOrEmpty(actionItem))
			{
				Type propertyType = IMAction.DictPropertyInfo[imAction.Type][actionItem].PropertyType;
				double num;
				if (propertyType == typeof(double) && double.TryParse(guidanceKey, out num))
				{
					guidanceKey = num.ToString(CultureInfo.InvariantCulture);
				}
				string key = isGamePad ? "GamePad" : "KeyMap";
				if (!this.mViewIgnoreList[key].ContainsKey(imAction.GetType()) || !this.mViewIgnoreList[key][imAction.GetType()].ContainsKey(actionItem) || !imAction.Guidance.ContainsKey(this.mViewIgnoreList[key][imAction.GetType()][actionItem]))
				{
					ObservableCollection<GuidanceCategoryViewModel> observableCollection = isGamePad ? this.GamepadViewGuidance : this.KeymapViewGuidance;
					GuidanceCategoryViewModel guidanceCategoryViewModel = (from guide in observableCollection
					where string.Equals(guide.Category, category, StringComparison.InvariantCulture)
					select guide).FirstOrDefault<GuidanceCategoryViewModel>();
					if (guidanceCategoryViewModel == null)
					{
						GuidanceViewModel guidanceViewModel = new GuidanceViewModel();
						guidanceViewModel.GuidanceTexts.Add(guidanceText);
						guidanceViewModel.GuidanceKeys.Add(guidanceKey);
						guidanceCategoryViewModel = new GuidanceCategoryViewModel
						{
							Category = category
						};
						guidanceCategoryViewModel.GuidanceViewModels.Add(guidanceViewModel);
						observableCollection.Add(guidanceCategoryViewModel);
					}
					else
					{
						GuidanceViewModel guidanceViewModel2 = (from guide in guidanceCategoryViewModel.GuidanceViewModels
						where guide.GuidanceTexts.Count == 1 && guide.GuidanceTexts.Contains(guidanceText)
						select guide).FirstOrDefault<GuidanceViewModel>();
						if (guidanceViewModel2 != null)
						{
							guidanceViewModel2.GuidanceKeys.AddIfNotContain(guidanceKey);
						}
						else
						{
							GuidanceViewModel guidanceViewModel3 = (from guide in guidanceCategoryViewModel.GuidanceViewModels
							where guide.GuidanceKeys.Count == 1 && guide.GuidanceKeys.Contains(guidanceKey)
							select guide).FirstOrDefault<GuidanceViewModel>();
							if (guidanceViewModel3 != null)
							{
								guidanceViewModel3.GuidanceTexts.AddIfNotContain(guidanceText);
							}
							else
							{
								GuidanceViewModel guidanceViewModel4 = new GuidanceViewModel();
								guidanceViewModel4.GuidanceTexts.Add(guidanceText);
								guidanceViewModel4.GuidanceKeys.Add(guidanceKey);
								guidanceCategoryViewModel.GuidanceViewModels.Add(guidanceViewModel4);
							}
						}
					}
				}
				if (!this.mEditIgnoreList[key].ContainsKey(imAction.GetType()) || !this.mEditIgnoreList[key][imAction.GetType()].Contains(actionItem))
				{
					ObservableCollection<GuidanceCategoryEditModel> observableCollection2 = isGamePad ? this.GamepadEditGuidance : this.KeymapEditGuidance;
					GuidanceCategoryEditModel guidanceCategoryEditModel = (from guide in observableCollection2
					where string.Equals(guide.Category, category, StringComparison.InvariantCulture)
					select guide).FirstOrDefault<GuidanceCategoryEditModel>();
					if (guidanceCategoryEditModel == null)
					{
						guidanceCategoryEditModel = new GuidanceCategoryEditModel
						{
							Category = category
						};
						observableCollection2.Add(guidanceCategoryEditModel);
					}
					GuidanceEditModel guidanceEditModel = null;
					if (propertyType == typeof(string))
					{
						guidanceEditModel = (from gem in guidanceCategoryEditModel.GuidanceEditModels
						where gem.ActionType == imAction.Type && gem.PropertyType == propertyType && string.Equals(gem.GuidanceText, guidanceText, StringComparison.InvariantCultureIgnoreCase) && string.Equals(gem.GuidanceKey, guidanceKey, StringComparison.InvariantCultureIgnoreCase)
						select gem).FirstOrDefault<GuidanceEditModel>();
					}
					if (guidanceEditModel == null)
					{
						guidanceEditModel = ((propertyType == typeof(string) || propertyType == typeof(bool)) ? new GuidanceEditTextModel() : new GuidanceEditDecimalModel());
						guidanceEditModel.GuidanceText = guidanceText;
						guidanceEditModel.OriginalGuidanceKey = guidanceKey;
						guidanceEditModel.ActionType = imAction.Type;
						guidanceEditModel.PropertyType = propertyType;
						guidanceEditModel.IsEnabled = (!string.Equals(actionItem, "KeyAction", StringComparison.InvariantCultureIgnoreCase) && !string.Equals(actionItem, "KeyMove", StringComparison.InvariantCultureIgnoreCase));
						guidanceCategoryEditModel.GuidanceEditModels.Add(guidanceEditModel);
					}
					guidanceEditModel.IMActionItems.Add(new IMActionItem
					{
						ActionItem = actionItem,
						IMAction = imAction
					});
				}
			}
		}

		// Token: 0x040001BE RID: 446
		private ObservableCollection<GuidanceCategoryEditModel> mKeymapEditGuidanceCloned;

		// Token: 0x040001BF RID: 447
		private ObservableCollection<GuidanceCategoryEditModel> mGamepadEditGuidanceCloned;

		// Token: 0x040001C0 RID: 448
		private Dictionary<string, Dictionary<Type, Dictionary<string, string>>> mViewIgnoreList = new Dictionary<string, Dictionary<Type, Dictionary<string, string>>>
		{
			{
				"KeyMap",
				new Dictionary<Type, Dictionary<string, string>>
				{
					{
						typeof(Dpad),
						new Dictionary<string, string>
						{
							{
								"KeyUp",
								"DpadTitle"
							},
							{
								"KeyLeft",
								"DpadTitle"
							},
							{
								"KeyDown",
								"DpadTitle"
							},
							{
								"KeyRight",
								"DpadTitle"
							}
						}
					}
				}
			},
			{
				"GamePad",
				new Dictionary<Type, Dictionary<string, string>>()
			}
		};

		// Token: 0x040001C1 RID: 449
		private Dictionary<string, Dictionary<Type, List<string>>> mEditIgnoreList = new Dictionary<string, Dictionary<Type, List<string>>>
		{
			{
				"KeyMap",
				new Dictionary<Type, List<string>>
				{
					{
						typeof(Dpad),
						new List<string>
						{
							"DpadTitle"
						}
					}
				}
			},
			{
				"GamePad",
				new Dictionary<Type, List<string>>()
			}
		};
	}
}
