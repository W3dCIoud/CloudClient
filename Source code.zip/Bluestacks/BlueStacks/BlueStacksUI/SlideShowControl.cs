﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media.Animation;
using BlueStacks.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000FF RID: 255
	public class SlideShowControl : System.Windows.Controls.UserControl, IDisposable, IComponentConnector
	{
		// Token: 0x060009F3 RID: 2547 RVA: 0x000084AA File Offset: 0x000066AA
		public SlideShowControl()
		{
			this.InitializeComponent();
			this.image1_MouseEnter(null, null);
		}

		// Token: 0x060009F4 RID: 2548 RVA: 0x00039F3C File Offset: 0x0003813C
		internal void AddOrUpdateSlide(SlideShowControl.SlideShowContext slideContext)
		{
			if (this.mSlideShowDict.ContainsKey(slideContext.Key))
			{
				this.mSlideShowDict[slideContext.Key] = slideContext;
				return;
			}
			this.mSlideShowDict.Add((slideContext.Key == 0) ? this.mSlideShowDict.Count : slideContext.Key, slideContext);
		}

		// Token: 0x170001E9 RID: 489
		// (get) Token: 0x060009F5 RID: 2549 RVA: 0x000084CB File Offset: 0x000066CB
		// (set) Token: 0x060009F6 RID: 2550 RVA: 0x000084DD File Offset: 0x000066DD
		public System.Windows.HorizontalAlignment TextHorizontalAlignment
		{
			get
			{
				return (System.Windows.HorizontalAlignment)base.GetValue(SlideShowControl.TextHorizontalAlignmentProperty);
			}
			set
			{
				base.SetValue(SlideShowControl.TextHorizontalAlignmentProperty, value);
			}
		}

		// Token: 0x170001EA RID: 490
		// (get) Token: 0x060009F7 RID: 2551 RVA: 0x000084F0 File Offset: 0x000066F0
		// (set) Token: 0x060009F8 RID: 2552 RVA: 0x00008502 File Offset: 0x00006702
		public VerticalAlignment TextVerticalAlignment
		{
			get
			{
				return (VerticalAlignment)base.GetValue(SlideShowControl.TextVerticalAlignmentProperty);
			}
			set
			{
				base.SetValue(SlideShowControl.TextVerticalAlignmentProperty, value);
			}
		}

		// Token: 0x170001EB RID: 491
		// (get) Token: 0x060009F9 RID: 2553 RVA: 0x00008515 File Offset: 0x00006715
		// (set) Token: 0x060009FA RID: 2554 RVA: 0x00008527 File Offset: 0x00006727
		public string ImagesFolderPath
		{
			get
			{
				return (string)base.GetValue(SlideShowControl.ImagesFolderPathProperty);
			}
			set
			{
				base.SetValue(SlideShowControl.ImagesFolderPathProperty, value);
			}
		}

		// Token: 0x170001EC RID: 492
		// (get) Token: 0x060009FB RID: 2555 RVA: 0x00008535 File Offset: 0x00006735
		// (set) Token: 0x060009FC RID: 2556 RVA: 0x00008547 File Offset: 0x00006747
		public bool IsArrowVisible
		{
			get
			{
				return (bool)base.GetValue(SlideShowControl.IsArrowVisibleProperty);
			}
			set
			{
				base.SetValue(SlideShowControl.IsArrowVisibleProperty, value);
			}
		}

		// Token: 0x170001ED RID: 493
		// (get) Token: 0x060009FD RID: 2557 RVA: 0x0000855A File Offset: 0x0000675A
		// (set) Token: 0x060009FE RID: 2558 RVA: 0x0000856C File Offset: 0x0000676C
		public bool HideArrowOnLeave
		{
			get
			{
				return (bool)base.GetValue(SlideShowControl.HideArrowOnLeaveProperty);
			}
			set
			{
				base.SetValue(SlideShowControl.HideArrowOnLeaveProperty, value);
			}
		}

		// Token: 0x170001EE RID: 494
		// (get) Token: 0x060009FF RID: 2559 RVA: 0x0000857F File Offset: 0x0000677F
		// (set) Token: 0x06000A00 RID: 2560 RVA: 0x00008591 File Offset: 0x00006791
		public bool IsAutoPlay
		{
			get
			{
				return (bool)base.GetValue(SlideShowControl.IsAutoPlayProperty);
			}
			set
			{
				base.SetValue(SlideShowControl.IsAutoPlayProperty, value);
			}
		}

		// Token: 0x170001EF RID: 495
		// (get) Token: 0x06000A01 RID: 2561 RVA: 0x000085A4 File Offset: 0x000067A4
		// (set) Token: 0x06000A02 RID: 2562 RVA: 0x000085B6 File Offset: 0x000067B6
		public int SlideDelay
		{
			get
			{
				return (int)base.GetValue(SlideShowControl.SlideDelayProperty);
			}
			set
			{
				base.SetValue(SlideShowControl.SlideDelayProperty, value);
			}
		}

		// Token: 0x170001F0 RID: 496
		// (get) Token: 0x06000A03 RID: 2563 RVA: 0x000085C9 File Offset: 0x000067C9
		// (set) Token: 0x06000A04 RID: 2564 RVA: 0x000085DB File Offset: 0x000067DB
		public SlideShowControl.SlideAnimationType TransitionType
		{
			get
			{
				return (SlideShowControl.SlideAnimationType)base.GetValue(SlideShowControl.TransitionTypeProperty);
			}
			set
			{
				base.SetValue(SlideShowControl.TransitionTypeProperty, value);
			}
		}

		// Token: 0x06000A05 RID: 2565 RVA: 0x000085EE File Offset: 0x000067EE
		internal void PlaySlideShow()
		{
			this.IsAutoPlay = true;
			this.SlideShowLoop(false);
			this.StartImageTransition(this._slide + 1);
		}

		// Token: 0x06000A06 RID: 2566 RVA: 0x0000860C File Offset: 0x0000680C
		internal void StopSlideShow()
		{
			this.IsAutoPlay = false;
		}

		// Token: 0x06000A07 RID: 2567 RVA: 0x00039F98 File Offset: 0x00038198
		internal void LoadImagesFromFolder(string folderPath)
		{
			if (!Path.IsPathRooted(folderPath))
			{
				folderPath = Path.Combine(CustomPictureBox.AssetsDir, folderPath);
			}
			if (Directory.Exists(folderPath))
			{
				try
				{
					string path = Path.Combine(folderPath, "slides.json");
					if (File.Exists(path))
					{
						IEnumerable<SlideShowControl.SlideShowContext> enumerable = JObject.Parse(File.ReadAllText(path)).ToObject<IEnumerable<SlideShowControl.SlideShowContext>>();
						if (enumerable != null)
						{
							foreach (SlideShowControl.SlideShowContext slideShowContext in enumerable)
							{
								if (!string.IsNullOrEmpty(slideShowContext.Description))
								{
									slideShowContext.Description = LocaleStrings.GetLocalizedString(slideShowContext.Description);
								}
								this.AddOrUpdateSlide(slideShowContext);
							}
						}
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Error while trying to read slides.json from " + folderPath + "." + ex.ToString());
					this.mSlideShowDict.Clear();
				}
				if (this.mSlideShowDict.Count == 0)
				{
					FileInfo[] files = new DirectoryInfo(folderPath).GetFiles();
					int num = 0;
					for (int i = 0; i < files.Length; i++)
					{
						if (SlideShowControl.ValidImageExtensions.Contains(files[i].Extension, StringComparer.InvariantCultureIgnoreCase))
						{
							this.AddOrUpdateSlide(new SlideShowControl.SlideShowContext
							{
								Key = num,
								ImageName = files[i].FullName
							});
							num++;
						}
					}
				}
				this.StartImageTransition(0);
			}
		}

		// Token: 0x06000A08 RID: 2568 RVA: 0x0003A0FC File Offset: 0x000382FC
		private void SlideShowLoop(bool forceStart = false)
		{
			if (forceStart && this.timer != null)
			{
				this.timer.Enabled = false;
			}
			if (this.timer != null && !this.timer.Enabled)
			{
				this.timer.Dispose();
			}
			if (this.IsAutoPlay && this.mSlideShowDict.Count > 1)
			{
				this.timer = new Timer
				{
					Interval = this.SlideDelay * 1000
				};
				this.timer.Tick += this.Timer_Tick;
				this.timer.Start();
			}
		}

		// Token: 0x06000A09 RID: 2569 RVA: 0x0003A198 File Offset: 0x00038398
		private void Timer_Tick(object sender, EventArgs e)
		{
			if (this.timer.Enabled && this.IsAutoPlay && this.mSlideShowDict.Count > 1 && sender == this.timer)
			{
				this.StartImageTransition(this._slide + 1);
				return;
			}
			((Timer)sender).Enabled = false;
		}

		// Token: 0x06000A0A RID: 2570 RVA: 0x0003A1EC File Offset: 0x000383EC
		private void StartImageTransition(int i)
		{
			if (this.mSlideShowDict.Count > 0)
			{
				if (this._slide == i)
				{
					this.image1.ImageName = this.mSlideShowDict[this._slide].ImageName;
					this.SlideshowName.Text = this.mSlideShowDict[this._slide].Description;
					this.SlideShowLoop(false);
					return;
				}
				if (i >= this.mSlideShowDict.Count)
				{
					this.UnloadImage(0);
					return;
				}
				if (i < 0)
				{
					this.UnloadImage(this.mSlideShowDict.Count - 1);
					return;
				}
				this.UnloadImage(i);
			}
		}

		// Token: 0x06000A0B RID: 2571 RVA: 0x0003A294 File Offset: 0x00038494
		private void UnloadImage(int imageToShow)
		{
			Storyboard storyboard = (base.Resources[string.Format(CultureInfo.InvariantCulture, "{0}Out", new object[]
			{
				this.TransitionType.ToString()
			})] as Storyboard).Clone();
			storyboard.Completed += delegate(object o, EventArgs e)
			{
				this.image1.ImageName = this.mSlideShowDict[imageToShow].ImageName;
				this.LoadImage(imageToShow);
			};
			Storyboard.SetTarget(storyboard, this.SlideshowGrid);
			storyboard.Begin();
		}

		// Token: 0x06000A0C RID: 2572 RVA: 0x0003A31C File Offset: 0x0003851C
		private void LoadImage(int imageToShow)
		{
			this._slide = imageToShow;
			this.SlideshowName.Text = this.mSlideShowDict[imageToShow].Description;
			Storyboard storyboard = base.Resources[string.Format(CultureInfo.InvariantCulture, "{0}In", new object[]
			{
				this.TransitionType.ToString()
			})] as Storyboard;
			Storyboard.SetTarget(storyboard, this.SlideshowGrid);
			storyboard.Begin();
		}

		// Token: 0x06000A0D RID: 2573 RVA: 0x00008615 File Offset: 0x00006815
		private void mPrevBtn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.SlideShowLoop(true);
			this.StartImageTransition(this._slide - 1);
		}

		// Token: 0x06000A0E RID: 2574 RVA: 0x0000862C File Offset: 0x0000682C
		private void mNextBtn_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.SlideShowLoop(true);
			this.StartImageTransition(this._slide + 1);
		}

		// Token: 0x06000A0F RID: 2575 RVA: 0x00008643 File Offset: 0x00006843
		private void SlideShowControl_Loaded(object sender, RoutedEventArgs e)
		{
			if (!string.IsNullOrEmpty(this.ImagesFolderPath))
			{
				this.LoadImagesFromFolder(this.ImagesFolderPath);
			}
		}

		// Token: 0x06000A10 RID: 2576 RVA: 0x0003A39C File Offset: 0x0003859C
		private void image1_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
		{
			if (!this.IsArrowVisible || this.mSlideShowDict.Count < 2)
			{
				this.image1_MouseLeave(sender, e);
				return;
			}
			if (!this.HideArrowOnLeave)
			{
				return;
			}
			if (this.image1.IsMouseOver)
			{
				this.mPrevBtn.Visibility = Visibility.Visible;
				this.mNextBtn.Visibility = Visibility.Visible;
				return;
			}
			this.image1_MouseLeave(sender, e);
		}

		// Token: 0x06000A11 RID: 2577 RVA: 0x0003A400 File Offset: 0x00038600
		private void image1_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
		{
			if (!this.IsArrowVisible || this.mSlideShowDict.Count < 2)
			{
				this.mPrevBtn.Visibility = Visibility.Hidden;
				this.mNextBtn.Visibility = Visibility.Hidden;
				return;
			}
			if (!this.HideArrowOnLeave)
			{
				return;
			}
			if (!this.mPrevBtn.IsMouseOver && !this.mNextBtn.IsMouseOver && !this.image1.IsMouseOver)
			{
				this.mPrevBtn.Visibility = Visibility.Hidden;
				this.mNextBtn.Visibility = Visibility.Hidden;
			}
		}

		// Token: 0x06000A12 RID: 2578 RVA: 0x0000865E File Offset: 0x0000685E
		protected virtual void Dispose(bool disposing)
		{
			if (!this.disposedValue)
			{
				if (this.timer != null)
				{
					this.timer.Tick += this.Timer_Tick;
					this.timer.Dispose();
				}
				this.disposedValue = true;
			}
		}

		// Token: 0x06000A13 RID: 2579 RVA: 0x0003A484 File Offset: 0x00038684
		~SlideShowControl()
		{
			this.Dispose(false);
		}

		// Token: 0x06000A14 RID: 2580 RVA: 0x0000869B File Offset: 0x0000689B
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x06000A15 RID: 2581 RVA: 0x0003A4B4 File Offset: 0x000386B4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/slideshowcontrol.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000A16 RID: 2582 RVA: 0x0003A4E4 File Offset: 0x000386E4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.slideControl = (SlideShowControl)target;
				this.slideControl.Loaded += this.SlideShowControl_Loaded;
				return;
			case 2:
				this.SlideshowGrid = (Grid)target;
				return;
			case 3:
				this.image1 = (CustomPictureBox)target;
				this.image1.MouseEnter += this.image1_MouseEnter;
				this.image1.MouseLeave += this.image1_MouseLeave;
				return;
			case 4:
				this.mPrevBtn = (CustomPictureBox)target;
				this.mPrevBtn.MouseLeftButtonUp += this.mPrevBtn_MouseLeftButtonUp;
				this.mPrevBtn.MouseLeave += this.image1_MouseLeave;
				return;
			case 5:
				this.mNextBtn = (CustomPictureBox)target;
				this.mNextBtn.MouseLeftButtonUp += this.mNextBtn_MouseLeftButtonUp;
				this.mNextBtn.MouseLeave += this.image1_MouseLeave;
				return;
			case 6:
				this.SlideshowName = (TextBlock)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000648 RID: 1608
		private SortedDictionary<int, SlideShowControl.SlideShowContext> mSlideShowDict = new SortedDictionary<int, SlideShowControl.SlideShowContext>();

		// Token: 0x04000649 RID: 1609
		private static string[] ValidImageExtensions = new string[]
		{
			".png",
			".jpg",
			".jpeg",
			".bmp",
			".gif"
		};

		// Token: 0x0400064A RID: 1610
		public static readonly DependencyProperty TransitionTypeProperty = DependencyProperty.Register("TransitionType", typeof(SlideShowControl.SlideAnimationType), typeof(SlideShowControl), new PropertyMetadata(SlideShowControl.SlideAnimationType.Fade));

		// Token: 0x0400064B RID: 1611
		public static readonly DependencyProperty TextVerticalAlignmentProperty = DependencyProperty.Register("TextVerticalAlignment", typeof(VerticalAlignment), typeof(SlideShowControl), new PropertyMetadata(VerticalAlignment.Bottom));

		// Token: 0x0400064C RID: 1612
		public static readonly DependencyProperty TextHorizontalAlignmentProperty = DependencyProperty.Register("TextHorizontalAlignment", typeof(System.Windows.HorizontalAlignment), typeof(SlideShowControl), new PropertyMetadata(System.Windows.HorizontalAlignment.Center));

		// Token: 0x0400064D RID: 1613
		public static readonly DependencyProperty IsAutoPlayProperty = DependencyProperty.Register("IsAutoPlay", typeof(bool), typeof(SlideShowControl), new PropertyMetadata(false));

		// Token: 0x0400064E RID: 1614
		public static readonly DependencyProperty HideArrowOnLeaveProperty = DependencyProperty.Register("HideArrowOnLeave", typeof(bool), typeof(SlideShowControl), new PropertyMetadata(true));

		// Token: 0x0400064F RID: 1615
		public static readonly DependencyProperty IsArrowVisibleProperty = DependencyProperty.Register("IsArrowVisible", typeof(bool), typeof(SlideShowControl), new PropertyMetadata(true));

		// Token: 0x04000650 RID: 1616
		public static readonly DependencyProperty SlideDelayProperty = DependencyProperty.Register("SlideDelay", typeof(int), typeof(SlideShowControl), new PropertyMetadata(5));

		// Token: 0x04000651 RID: 1617
		public static readonly DependencyProperty ImagesFolderPathProperty = DependencyProperty.Register("ImagesFolderPath", typeof(string), typeof(SlideShowControl), new PropertyMetadata(""));

		// Token: 0x04000652 RID: 1618
		private int _slide;

		// Token: 0x04000653 RID: 1619
		private Timer timer;

		// Token: 0x04000654 RID: 1620
		private bool disposedValue;

		// Token: 0x04000655 RID: 1621
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal SlideShowControl slideControl;

		// Token: 0x04000656 RID: 1622
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid SlideshowGrid;

		// Token: 0x04000657 RID: 1623
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox image1;

		// Token: 0x04000658 RID: 1624
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mPrevBtn;

		// Token: 0x04000659 RID: 1625
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mNextBtn;

		// Token: 0x0400065A RID: 1626
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock SlideshowName;

		// Token: 0x0400065B RID: 1627
		private bool _contentLoaded;

		// Token: 0x02000100 RID: 256
		[JsonObject(MemberSerialization.OptIn)]
		internal class SlideShowContext
		{
			// Token: 0x0400065C RID: 1628
			[JsonProperty("key")]
			internal int Key;

			// Token: 0x0400065D RID: 1629
			[JsonProperty("imagename")]
			internal string ImageName;

			// Token: 0x0400065E RID: 1630
			[JsonProperty("description")]
			internal string Description;
		}

		// Token: 0x02000101 RID: 257
		public enum SlideAnimationType
		{
			// Token: 0x04000660 RID: 1632
			Fade,
			// Token: 0x04000661 RID: 1633
			Slide
		}
	}
}
