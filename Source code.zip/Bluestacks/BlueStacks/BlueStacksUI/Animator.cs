﻿using System;
using System.Windows;
using System.Windows.Media.Animation;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000156 RID: 342
	public static class Animator
	{
		// Token: 0x06000D5B RID: 3419 RVA: 0x000580B0 File Offset: 0x000562B0
		public static AnimationClock AnimatePenner(DependencyObject element, DependencyProperty prop, PennerDoubleAnimation.Equations type, double to, int durationMS, EventHandler callbackFunc)
		{
			return Animator.AnimatePenner(element, prop, type, null, to, durationMS, callbackFunc);
		}

		// Token: 0x06000D5C RID: 3420 RVA: 0x000580D4 File Offset: 0x000562D4
		public static AnimationClock AnimatePenner(DependencyObject element, DependencyProperty prop, PennerDoubleAnimation.Equations type, double? from, double to, int durationMS, EventHandler callbackFunc)
		{
			double defaultValue = double.IsNaN((double)((element != null) ? element.GetValue(prop) : null)) ? 0.0 : ((double)element.GetValue(prop));
			PennerDoubleAnimation anim = new PennerDoubleAnimation(type, from.GetValueOrDefault(defaultValue), to);
			return Animator.Animate(element, prop, anim, durationMS, null, null, callbackFunc);
		}

		// Token: 0x06000D5D RID: 3421 RVA: 0x00058144 File Offset: 0x00056344
		public static AnimationClock AnimateDouble(DependencyObject element, DependencyProperty prop, double? from, double to, int durationMS, double? accel, double? decel, EventHandler callbackFunc)
		{
			double defaultValue = double.IsNaN((double)((element != null) ? element.GetValue(prop) : null)) ? 0.0 : ((double)element.GetValue(prop));
			DoubleAnimation anim = new DoubleAnimation
			{
				From = new double?(from.GetValueOrDefault(defaultValue)),
				To = new double?(to)
			};
			return Animator.Animate(element, prop, anim, durationMS, accel, decel, callbackFunc);
		}

		// Token: 0x06000D5E RID: 3422 RVA: 0x00009FA0 File Offset: 0x000081A0
		public static void ClearAnimation(DependencyObject animatable, DependencyProperty property)
		{
			if (animatable != null)
			{
				animatable.SetValue(property, animatable.GetValue(property));
				((IAnimatable)animatable).ApplyAnimationClock(property, null);
			}
		}

		// Token: 0x06000D5F RID: 3423 RVA: 0x000581B8 File Offset: 0x000563B8
		private static AnimationClock Animate(DependencyObject animatable, DependencyProperty prop, AnimationTimeline anim, int duration, double? accel, double? decel, EventHandler func)
		{
			Animator.<>c__DisplayClass4_0 CS$<>8__locals1 = new Animator.<>c__DisplayClass4_0();
			CS$<>8__locals1.animatable = animatable;
			CS$<>8__locals1.prop = prop;
			anim.AccelerationRatio = accel.GetValueOrDefault(0.0);
			anim.DecelerationRatio = decel.GetValueOrDefault(0.0);
			anim.Duration = TimeSpan.FromMilliseconds((double)duration);
			anim.Freeze();
			CS$<>8__locals1.animClock = anim.CreateClock();
			CS$<>8__locals1.animClock.Completed += CS$<>8__locals1.<Animate>g__animClock_Completed|0;
			if (func != null)
			{
				CS$<>8__locals1.animClock.Completed += func;
			}
			CS$<>8__locals1.animClock.Controller.Begin();
			Animator.ClearAnimation(CS$<>8__locals1.animatable, CS$<>8__locals1.prop);
			((IAnimatable)CS$<>8__locals1.animatable).ApplyAnimationClock(CS$<>8__locals1.prop, CS$<>8__locals1.animClock);
			return CS$<>8__locals1.animClock;
		}
	}
}
