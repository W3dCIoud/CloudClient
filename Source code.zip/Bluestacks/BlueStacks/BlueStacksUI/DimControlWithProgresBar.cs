﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000233 RID: 563
	public class DimControlWithProgresBar : UserControl, IComponentConnector
	{
		// Token: 0x170002BC RID: 700
		// (get) Token: 0x06001416 RID: 5142 RVA: 0x0000DBF9 File Offset: 0x0000BDF9
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x170002BD RID: 701
		// (get) Token: 0x06001417 RID: 5143 RVA: 0x0000DC1A File Offset: 0x0000BE1A
		// (set) Token: 0x06001418 RID: 5144 RVA: 0x0000DC22 File Offset: 0x0000BE22
		public Control ParentControl { get; set; }

		// Token: 0x170002BE RID: 702
		// (get) Token: 0x06001419 RID: 5145 RVA: 0x0000DC2B File Offset: 0x0000BE2B
		// (set) Token: 0x0600141A RID: 5146 RVA: 0x0000DC33 File Offset: 0x0000BE33
		public Panel ChildControl { get; set; }

		// Token: 0x0600141B RID: 5147 RVA: 0x0000DC3C File Offset: 0x0000BE3C
		public DimControlWithProgresBar()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600141C RID: 5148 RVA: 0x000798C4 File Offset: 0x00077AC4
		internal void Init(Control parentControl, Panel childControl, bool isWindowForced, bool _)
		{
			this.ParentControl = parentControl;
			this.ChildControl = childControl;
			this.FixUpUILayout();
			if (isWindowForced)
			{
				this.mBackButton.Visibility = Visibility.Hidden;
				this.mCloseButton.Visibility = Visibility.Hidden;
			}
			this.ParentWindow.SizeChanged += this.MainWindow_SizeChanged;
		}

		// Token: 0x0600141D RID: 5149 RVA: 0x0000DC4A File Offset: 0x0000BE4A
		private void MainWindow_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			this.FixUpUILayout();
		}

		// Token: 0x0600141E RID: 5150 RVA: 0x00079918 File Offset: 0x00077B18
		private void FixUpUILayout()
		{
			this.mControlGrid.Height = (double)((long)((int)(this.ParentWindow.mWelcomeTab.ActualHeight * 0.8 / (double)this.ParentWindow.mAspectRatio.Denominator)) * this.ParentWindow.mAspectRatio.Denominator);
			if (this.ParentWindow.mWelcomeTab.ActualHeight * 0.9 - this.mControlGrid.Height > 10.0)
			{
				this.mControlGrid.Height = this.ParentWindow.mWelcomeTab.ActualHeight * 0.8;
			}
			this.mControlGrid.Height += 50.0;
			this.mControlGrid.Width = (this.mControlGrid.Height - 50.0) * this.ParentWindow.mAspectRatio.DoubleValue + 10.0;
		}

		// Token: 0x0600141F RID: 5151 RVA: 0x00079A1C File Offset: 0x00077C1C
		internal void ShowContent()
		{
			this.DimBackground();
			if (this.ChildControl != null)
			{
				if (this.ChildControl.Parent != null)
				{
					(this.ChildControl.Parent as Panel).Children.Remove(this.ChildControl);
				}
				this.mControlParentGrid.Children.Add(this.ChildControl);
			}
			this.mControlGrid.Visibility = Visibility.Visible;
		}

		// Token: 0x06001420 RID: 5152 RVA: 0x0000DC52 File Offset: 0x0000BE52
		private void CloseButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Cicked DimControl close button");
			this.HideWindow();
		}

		// Token: 0x06001421 RID: 5153 RVA: 0x0000DC64 File Offset: 0x0000BE64
		internal void DimBackground()
		{
			Logger.Info("Diming popup window");
			if (this.ParentControl != null)
			{
				this.ParentControl.Visibility = Visibility.Visible;
			}
			base.Visibility = Visibility.Visible;
		}

		// Token: 0x06001422 RID: 5154 RVA: 0x0000DC8B File Offset: 0x0000BE8B
		private void BackButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			Logger.Info("Clicked Back Button");
			this.ParentWindow.mCommonHandler.BackButtonHandler(false);
		}

		// Token: 0x06001423 RID: 5155 RVA: 0x0000DCA8 File Offset: 0x0000BEA8
		internal void HideWindow()
		{
			Logger.Debug("Hiding popup window");
			base.Visibility = Visibility.Hidden;
			this.mControlGrid.Visibility = Visibility.Hidden;
			if (this.ParentControl != null)
			{
				this.ParentControl.Visibility = Visibility.Hidden;
			}
		}

		// Token: 0x06001424 RID: 5156 RVA: 0x00079A88 File Offset: 0x00077C88
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/dimcontrolwithprogresbar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06001425 RID: 5157 RVA: 0x00079AB8 File Offset: 0x00077CB8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mControlGrid = (Grid)target;
				return;
			case 2:
				this.mTopBar = (Grid)target;
				return;
			case 3:
				this.mBackButton = (CustomPictureBox)target;
				this.mBackButton.PreviewMouseLeftButtonUp += this.BackButton_PreviewMouseLeftButtonUp;
				return;
			case 4:
				this.mTitleLabel = (Label)target;
				return;
			case 5:
				this.mCloseButton = (CustomPictureBox)target;
				this.mCloseButton.PreviewMouseLeftButtonUp += this.CloseButton_PreviewMouseLeftButtonUp;
				return;
			case 6:
				this.mControlParentGrid = (Grid)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000CA1 RID: 3233
		private MainWindow mMainWindow;

		// Token: 0x04000CA4 RID: 3236
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mControlGrid;

		// Token: 0x04000CA5 RID: 3237
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mTopBar;

		// Token: 0x04000CA6 RID: 3238
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mBackButton;

		// Token: 0x04000CA7 RID: 3239
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Label mTitleLabel;

		// Token: 0x04000CA8 RID: 3240
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCloseButton;

		// Token: 0x04000CA9 RID: 3241
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mControlParentGrid;

		// Token: 0x04000CAA RID: 3242
		private bool _contentLoaded;
	}
}
