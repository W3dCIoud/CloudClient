﻿using System;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000179 RID: 377
	[JsonObject(MemberSerialization.OptIn)]
	public class QuestRule
	{
		// Token: 0x17000245 RID: 581
		// (get) Token: 0x06000EA0 RID: 3744 RVA: 0x0000AB44 File Offset: 0x00008D44
		// (set) Token: 0x06000EA1 RID: 3745 RVA: 0x0000AB4C File Offset: 0x00008D4C
		[JsonProperty("rule_id")]
		public string RuleId { get; set; }

		// Token: 0x17000246 RID: 582
		// (get) Token: 0x06000EA2 RID: 3746 RVA: 0x0000AB55 File Offset: 0x00008D55
		// (set) Token: 0x06000EA3 RID: 3747 RVA: 0x0000AB5D File Offset: 0x00008D5D
		[JsonProperty("app_pkg", NullValueHandling = NullValueHandling.Ignore)]
		public string AppPackage { get; set; } = string.Empty;

		// Token: 0x17000247 RID: 583
		// (get) Token: 0x06000EA4 RID: 3748 RVA: 0x0000AB66 File Offset: 0x00008D66
		// (set) Token: 0x06000EA5 RID: 3749 RVA: 0x0000AB6E File Offset: 0x00008D6E
		[JsonProperty("usage_time", NullValueHandling = NullValueHandling.Ignore)]
		public int AppUsageTime { get; set; }

		// Token: 0x17000248 RID: 584
		// (get) Token: 0x06000EA6 RID: 3750 RVA: 0x0000AB77 File Offset: 0x00008D77
		// (set) Token: 0x06000EA7 RID: 3751 RVA: 0x0000AB7F File Offset: 0x00008D7F
		[JsonProperty("user_interactions", NullValueHandling = NullValueHandling.Ignore)]
		public int MinUserInteraction { get; set; }

		// Token: 0x17000249 RID: 585
		// (get) Token: 0x06000EA8 RID: 3752 RVA: 0x0000AB88 File Offset: 0x00008D88
		// (set) Token: 0x06000EA9 RID: 3753 RVA: 0x0000AB90 File Offset: 0x00008D90
		[JsonProperty("recurring", NullValueHandling = NullValueHandling.Ignore)]
		public bool IsRecurring { get; set; }

		// Token: 0x1700024A RID: 586
		// (get) Token: 0x06000EAA RID: 3754 RVA: 0x0000AB99 File Offset: 0x00008D99
		// (set) Token: 0x06000EAB RID: 3755 RVA: 0x0000ABA1 File Offset: 0x00008DA1
		[JsonProperty("num_of_occurances", NullValueHandling = NullValueHandling.Ignore)]
		public int RecurringCount { get; set; }

		// Token: 0x1700024B RID: 587
		// (get) Token: 0x06000EAC RID: 3756 RVA: 0x0000ABAA File Offset: 0x00008DAA
		// (set) Token: 0x06000EAD RID: 3757 RVA: 0x0000ABB2 File Offset: 0x00008DB2
		[JsonProperty("cloud_handler", NullValueHandling = NullValueHandling.Ignore)]
		public string CloudHandler { get; set; }
	}
}
