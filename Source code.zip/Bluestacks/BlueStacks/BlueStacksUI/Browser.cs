﻿using System;
using System.Globalization;
using System.Threading;
using System.Windows;
using System.Windows.Media;
using BlueStacks.Common;
using Xilium.CefGlue.WPF;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000087 RID: 135
	public class Browser : WpfCefBrowser
	{
		// Token: 0x170001A4 RID: 420
		// (get) Token: 0x06000545 RID: 1349 RVA: 0x000057FC File Offset: 0x000039FC
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x06000546 RID: 1350 RVA: 0x0001FF94 File Offset: 0x0001E194
		public Browser(float zoomLevel = 0f)
		{
			base.Loaded += this.Browser_Loaded;
			base.OnBeforePopup += this.Browser_OnBeforePopup;
			base.LoadingStateChange += this.Browser_LoadingStateChange;
			this.mCustomZoomLevel = zoomLevel;
			if (RegistryManager.Instance.CefDevEnv == 1)
			{
				base.mAllowDevTool = true;
				base.mDevToolHeader = base.StartUrl;
			}
		}

		// Token: 0x06000547 RID: 1351 RVA: 0x0000581D File Offset: 0x00003A1D
		private bool Browser_OnBeforePopup(string url)
		{
			if (FeatureManager.Instance.IsCustomUIForDMM)
			{
				BlueStacksUIUtils.OpenUrl(url);
				return true;
			}
			return false;
		}

		// Token: 0x06000548 RID: 1352 RVA: 0x00005834 File Offset: 0x00003A34
		public Browser(string url)
		{
			this.url = url;
		}

		// Token: 0x06000549 RID: 1353 RVA: 0x00020004 File Offset: 0x0001E204
		private void Browser_Loaded(object sender, RoutedEventArgs e)
		{
			try
			{
				this.isLoaded = true;
				Matrix transformToDevice = PresentationSource.FromVisual((Visual)sender).CompositionTarget.TransformToDevice;
				ScaleTransform scaleTransform = new ScaleTransform(1.0 / transformToDevice.M11, 1.0 / transformToDevice.M22);
				if (scaleTransform.CanFreeze)
				{
					scaleTransform.Freeze();
				}
				base.LayoutTransform = scaleTransform;
				this.zoomLevel = Math.Log(transformToDevice.M11) / Math.Log(1.2);
				if (this.mCustomZoomLevel != 0f)
				{
					double num = Math.Log10((double)this.mCustomZoomLevel) / Math.Log10(1.2);
					this.zoomLevel += num;
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Failed to get zoom factor of browser with url {0} and error :{1}", new object[]
				{
					this.url,
					ex.ToString()
				});
			}
		}

		// Token: 0x0600054A RID: 1354 RVA: 0x000200FC File Offset: 0x0001E2FC
		private void Browser_LoadingStateChange(object sender, LoadingStateChangeEventArgs e)
		{
			base.Dispatcher.Invoke(new Action(delegate()
			{
				try
				{
					string text = base.getURL();
					if (!string.IsNullOrEmpty(text))
					{
						string packageName = text.Substring(text.LastIndexOf("=", StringComparison.InvariantCulture) + 1);
						if (text.Contains("play.google.com"))
						{
							this.ParentWindow.mAppHandler.LaunchPlayRequestAsync(packageName);
						}
					}
				}
				catch (Exception)
				{
				}
			}), new object[0]);
			if (!e.IsLoading)
			{
				try
				{
					base.SetZoomLevel(this.zoomLevel);
				}
				catch (Exception ex)
				{
					Logger.Error("Error while setting zoom in browser with url {0} and error :{1}", new object[]
					{
						this.url,
						ex.ToString()
					});
				}
			}
		}

		// Token: 0x0600054B RID: 1355 RVA: 0x00020174 File Offset: 0x0001E374
		public void CallJs(string methodName, object[] args)
		{
			if (this.isLoaded)
			{
				new Thread(delegate()
				{
					try
					{
						if (args.Length == 1)
						{
							string text = args[0].ToString();
							text = text.Replace("%27", "&#39;").Replace("'", "&#39;");
							string code = string.Format(CultureInfo.InvariantCulture, "javascript:{0}('{1}')", new object[]
							{
								methodName,
								text
							});
							Logger.Info("calling " + methodName);
							this.ExecuteJavaScript(code, this.getURL(), 0);
						}
						else if (args.Length == 0)
						{
							string code2 = string.Format(CultureInfo.InvariantCulture, "javascript:{0}()", new object[]
							{
								methodName
							});
							Logger.Info("calling " + methodName);
							this.ExecuteJavaScript(code2, this.getURL(), 0);
						}
						else
						{
							Logger.Error("Error: function supported for one length array object to be changed later");
						}
					}
					catch (Exception ex)
					{
						Logger.Error(ex.ToString());
					}
				})
				{
					IsBackground = true
				}.Start();
			}
		}

		// Token: 0x040002D2 RID: 722
		private bool isLoaded;

		// Token: 0x040002D3 RID: 723
		private string url;

		// Token: 0x040002D4 RID: 724
		private double zoomLevel;

		// Token: 0x040002D5 RID: 725
		private float mCustomZoomLevel;

		// Token: 0x040002D6 RID: 726
		private MainWindow mMainWindow;
	}
}
