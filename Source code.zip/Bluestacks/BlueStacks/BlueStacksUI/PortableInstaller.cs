﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000057 RID: 87
	internal class PortableInstaller
	{
		// Token: 0x0600040A RID: 1034 RVA: 0x0001AF80 File Offset: 0x00019180
		internal static void CheckAndRunPortableInstaller()
		{
			try
			{
				if (Oem.Instance.IsPortableInstaller)
				{
					string value = (string)RegistryUtils.GetRegistryValue(Strings.RegistryBaseKeyPath, "Version", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
					string fullName = Directory.GetParent(AppDomain.CurrentDomain.BaseDirectory.Trim(new char[]
					{
						'\\'
					})).FullName;
					Logger.InitLogAtPath(Path.Combine(fullName, "Logs\\PortableInstaller.log"), "PortableInstaller", true);
					if (string.IsNullOrEmpty(value) || (string)RegistryUtils.GetRegistryValue(Strings.RegistryBaseKeyPath, "InstallDir", "", RegistryKeyKind.HKEY_LOCAL_MACHINE) != Path.Combine(fullName, "BlueStacksPF") || Opt.Instance.isForceInstall)
					{
						PortableInstaller.InstallPortableBlueStacks(AppDomain.CurrentDomain.BaseDirectory);
					}
				}
			}
			catch (Exception ex)
			{
				string str = "Error in CheckAndRunPortableInstaller";
				Exception ex2 = ex;
				Logger.Info(str + ((ex2 != null) ? ex2.ToString() : null));
			}
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x0001B074 File Offset: 0x00019274
		private static void InstallPortableBlueStacks(string cwd)
		{
			try
			{
				string fullName = Directory.GetParent(cwd.Trim(new char[]
				{
					'\\'
				})).FullName;
				string text = Path.Combine(fullName, "Engine");
				string installDir = Path.Combine(fullName, "BlueStacksPF");
				string path = Path.Combine(Path.Combine(text, "Android"), "Android.bstk");
				string path2 = Path.Combine(Path.Combine(text, "Manager"), "BstkGlobal.xml");
				if (File.Exists(path))
				{
					File.Delete(path);
				}
				if (File.Exists(path2))
				{
					File.Delete(path2);
				}
				CommonInstallUtils.ModifyDirectoryPermissionsForEveryone(fullName);
				if (File.Exists(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "install.bat")))
				{
					if (PortableInstaller.RunInstallBat(installDir, text) == 0)
					{
						PortableInstaller.FixRegistries(fullName, installDir);
						PortableInstaller.DoComRegistration(installDir);
						CommonInstallUtils.InstallVirtualBoxConfig(text, false);
						CommonInstallUtils.InstallVmConfig(installDir, text);
					}
				}
				else
				{
					Logger.Error("Install.bat file missing");
				}
			}
			catch (Exception ex)
			{
				string str = "Exception in InstallPortableBlueStacks ";
				Exception ex2 = ex;
				Logger.Error(str + ((ex2 != null) ? ex2.ToString() : null));
			}
		}

		// Token: 0x0600040C RID: 1036 RVA: 0x0001B188 File Offset: 0x00019388
		private static void FixRegistries(string userDefinedDir, string installDir)
		{
			string text = Path.Combine(userDefinedDir, "Engine");
			string text2 = "Android";
			int csidl = 46;
			int csidl2 = 54;
			RegistryManager.Instance.SetAccessPermissions();
			RegistryManager.Instance.UserDefinedDir = userDefinedDir.Trim(new char[]
			{
				'\\'
			});
			RegistryManager.Instance.DataDir = text.Trim(new char[]
			{
				'\\'
			}) + "\\";
			RegistryManager.Instance.LogDir = Path.Combine(userDefinedDir, "Logs").Trim(new char[]
			{
				'\\'
			}) + "\\";
			RegistryManager.Instance.InstallDir = installDir.Trim(new char[]
			{
				'\\'
			}) + "\\";
			RegistryManager.Instance.EngineDataDir = Path.Combine(userDefinedDir, "Engine");
			RegistryManager.Instance.ClientInstallDir = Path.Combine(userDefinedDir, "Client");
			RegistryManager.Instance.CefDataPath = Path.Combine(userDefinedDir, "CefData");
			RegistryManager.Instance.SetupFolder = Path.Combine(Directory.GetParent(userDefinedDir).ToString(), "BlueStacksSetup");
			RegistryManager.Instance.PartnerExePath = Path.Combine(RegistryManager.Instance.ClientInstallDir, "BlueStacks.exe");
			RegistryManager.Instance.SystemGuid = Guid.NewGuid().ToString();
			RegistryManager.Instance.UserGuid = Guid.NewGuid().ToString();
			Utils.UpdateValueInBootParams("GUID", RegistryManager.Instance.UserGuid, text2, true);
			string str = Path.Combine(text, text2);
			str += "\\";
			RegistryManager.Instance.Guest[text2].BlockDevice0Name = "sda1";
			RegistryManager.Instance.Guest[text2].BlockDevice0Path = str + "Root.vdi";
			RegistryManager.Instance.Guest[text2].BlockDevice1Name = "sdb1";
			RegistryManager.Instance.Guest[text2].BlockDevice1Path = str + "Data.vdi";
			RegistryManager.Instance.Guest[text2].BlockDevice2Name = "sdc1";
			RegistryManager.Instance.Guest[text2].BlockDevice2Path = str + "SDCard.vdi";
			RegistryManager.Instance.Guest[text2].BlockDevice3Name = "sdd1";
			RegistryManager.Instance.Guest[text2].BlockDevice3Path = str + "Prebundled.vdi";
			string sharedFolder0Path = Path.Combine(text, "UserData\\SharedFolder\\");
			RegistryManager.Instance.Guest[text2].SharedFolder0Name = "BstSharedFolder";
			RegistryManager.Instance.Guest[text2].SharedFolder0Path = sharedFolder0Path;
			RegistryManager.Instance.Guest[text2].SharedFolder0Writable = 1;
			string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
			RegistryManager.Instance.Guest[text2].SharedFolder1Name = "Pictures";
			RegistryManager.Instance.Guest[text2].SharedFolder1Path = folderPath;
			RegistryManager.Instance.Guest[text2].SharedFolder1Writable = 1;
			string folderPath2 = CommonInstallUtils.GetFolderPath(csidl2);
			RegistryManager.Instance.Guest[text2].SharedFolder2Name = "PublicPictures";
			RegistryManager.Instance.Guest[text2].SharedFolder2Path = folderPath2;
			RegistryManager.Instance.Guest[text2].SharedFolder2Writable = 1;
			string folderPath3 = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
			RegistryManager.Instance.Guest[text2].SharedFolder3Name = "Documents";
			RegistryManager.Instance.Guest[text2].SharedFolder3Path = folderPath3;
			RegistryManager.Instance.Guest[text2].SharedFolder3Writable = 1;
			string folderPath4 = CommonInstallUtils.GetFolderPath(csidl);
			RegistryManager.Instance.Guest[text2].SharedFolder4Name = "PublicDocuments";
			RegistryManager.Instance.Guest[text2].SharedFolder4Path = folderPath4;
			RegistryManager.Instance.Guest[text2].SharedFolder4Writable = 1;
			string sharedFolder5Path = Path.Combine(text, "UserData\\InputMapper");
			RegistryManager.Instance.Guest[text2].SharedFolder5Name = "InputMapper";
			RegistryManager.Instance.Guest[text2].SharedFolder5Path = sharedFolder5Path;
			RegistryManager.Instance.Guest[text2].SharedFolder5Writable = 1;
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x0001B604 File Offset: 0x00019804
		private static int RunInstallBat(string installDir, string dataDir)
		{
			Process process = new Process();
			process.StartInfo.WorkingDirectory = AppDomain.CurrentDomain.BaseDirectory;
			process.StartInfo.FileName = "install.bat";
			process.StartInfo.Arguments = string.Concat(new string[]
			{
				"\"",
				installDir,
				"\" \"",
				dataDir,
				"\""
			});
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.CreateNoWindow = true;
			process.StartInfo.RedirectStandardOutput = true;
			process.StartInfo.RedirectStandardError = true;
			Countdown countDown = new Countdown(2);
			StringBuilder sb = new StringBuilder();
			process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs outLine)
			{
				if (outLine.Data != null)
				{
					try
					{
						string data = outLine.Data;
						sb.AppendLine(data);
						Logger.Info(data);
						return;
					}
					catch (Exception ex)
					{
						Console.WriteLine("Exception in RunInstallBat");
						Console.WriteLine(ex.ToString());
						return;
					}
				}
				countDown.Signal();
			};
			process.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs outLine)
			{
				if (outLine.Data != null)
				{
					try
					{
						string data = outLine.Data;
						sb.AppendLine(data);
						Logger.Info(data);
						return;
					}
					catch (Exception ex)
					{
						Console.WriteLine("A crash occured in RunInstallBat");
						Console.WriteLine(ex.ToString());
						return;
					}
				}
				countDown.Signal();
			};
			process.Start();
			process.BeginOutputReadLine();
			process.BeginErrorReadLine();
			int milliseconds = 200000;
			process.WaitForExit(milliseconds);
			Logger.Info("Exit Code for InstallBat " + process.ExitCode.ToString());
			countDown.Wait();
			return process.ExitCode;
		}

		// Token: 0x0600040E RID: 1038 RVA: 0x0001B734 File Offset: 0x00019934
		private static void DoComRegistration(string installDir)
		{
			string text = "HD-ComRegistrar.exe";
			try
			{
				Logger.Info("Starting registration of COM process with: {0}", new object[]
				{
					text
				});
				Process process = new Process();
				process.StartInfo.FileName = Path.Combine(installDir, text);
				process.StartInfo.UseShellExecute = false;
				process.StartInfo.CreateNoWindow = true;
				process.Start();
				process.WaitForExit();
				Logger.Info("ExitCode: {0}", new object[]
				{
					process.ExitCode
				});
			}
			catch (Exception ex)
			{
				Logger.Warning("Failed to execute process {0}. Err: {1}", new object[]
				{
					text,
					ex.ToString()
				});
			}
		}
	}
}
