﻿using System;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200004D RID: 77
	public class HelpArticleInfo
	{
		// Token: 0x17000142 RID: 322
		// (get) Token: 0x06000395 RID: 917 RVA: 0x00004775 File Offset: 0x00002975
		// (set) Token: 0x06000396 RID: 918 RVA: 0x0000477D File Offset: 0x0000297D
		[JsonProperty(PropertyName = "url")]
		public string HelpArticleUrl { get; set; }
	}
}
