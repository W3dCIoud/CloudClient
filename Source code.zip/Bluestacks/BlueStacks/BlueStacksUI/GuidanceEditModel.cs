﻿using System;
using System.Collections.ObjectModel;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000045 RID: 69
	[Serializable]
	public abstract class GuidanceEditModel : ViewModelBase
	{
		// Token: 0x1700012E RID: 302
		// (get) Token: 0x06000341 RID: 833 RVA: 0x000042D6 File Offset: 0x000024D6
		// (set) Token: 0x06000342 RID: 834 RVA: 0x000042DE File Offset: 0x000024DE
		public string GuidanceText
		{
			get
			{
				return this.mGuidanceText;
			}
			set
			{
				base.SetProperty<string>(ref this.mGuidanceText, value, null);
			}
		}

		// Token: 0x1700012F RID: 303
		// (get) Token: 0x06000343 RID: 835 RVA: 0x000042EF File Offset: 0x000024EF
		// (set) Token: 0x06000344 RID: 836 RVA: 0x000042F7 File Offset: 0x000024F7
		public bool IsEnabled
		{
			get
			{
				return this.mIsEnabled;
			}
			set
			{
				base.SetProperty<bool>(ref this.mIsEnabled, value, null);
			}
		}

		// Token: 0x17000130 RID: 304
		// (get) Token: 0x06000345 RID: 837 RVA: 0x00004308 File Offset: 0x00002508
		// (set) Token: 0x06000346 RID: 838 RVA: 0x00004310 File Offset: 0x00002510
		public string OriginalGuidanceKey
		{
			get
			{
				return this.mOriginalGuidanceKey;
			}
			set
			{
				this.mOriginalGuidanceKey = value;
				this.GuidanceKey = this.mOriginalGuidanceKey;
			}
		}

		// Token: 0x17000131 RID: 305
		// (get) Token: 0x06000347 RID: 839 RVA: 0x00004325 File Offset: 0x00002525
		// (set) Token: 0x06000348 RID: 840 RVA: 0x0000432D File Offset: 0x0000252D
		public string GuidanceKey
		{
			get
			{
				return this.mGuidanceKey;
			}
			set
			{
				base.SetProperty<string>(ref this.mGuidanceKey, value, null);
			}
		}

		// Token: 0x17000132 RID: 306
		// (get) Token: 0x06000349 RID: 841 RVA: 0x0000433E File Offset: 0x0000253E
		// (set) Token: 0x0600034A RID: 842 RVA: 0x00004346 File Offset: 0x00002546
		public Type PropertyType
		{
			get
			{
				return this.mPropertyType;
			}
			set
			{
				base.SetProperty<Type>(ref this.mPropertyType, value, null);
			}
		}

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x0600034B RID: 843 RVA: 0x00004357 File Offset: 0x00002557
		// (set) Token: 0x0600034C RID: 844 RVA: 0x0000435F File Offset: 0x0000255F
		public KeyActionType ActionType
		{
			get
			{
				return this.mActionType;
			}
			set
			{
				base.SetProperty<KeyActionType>(ref this.mActionType, value, null);
			}
		}

		// Token: 0x17000134 RID: 308
		// (get) Token: 0x0600034D RID: 845 RVA: 0x00004370 File Offset: 0x00002570
		// (set) Token: 0x0600034E RID: 846 RVA: 0x00004378 File Offset: 0x00002578
		public ObservableCollection<IMActionItem> IMActionItems
		{
			get
			{
				return this.mIMActionItems;
			}
			set
			{
				base.SetProperty<ObservableCollection<IMActionItem>>(ref this.mIMActionItems, value, null);
			}
		}

		// Token: 0x040001C8 RID: 456
		private string mGuidanceText;

		// Token: 0x040001C9 RID: 457
		private bool mIsEnabled = true;

		// Token: 0x040001CA RID: 458
		private string mOriginalGuidanceKey;

		// Token: 0x040001CB RID: 459
		private string mGuidanceKey;

		// Token: 0x040001CC RID: 460
		private Type mPropertyType;

		// Token: 0x040001CD RID: 461
		private KeyActionType mActionType;

		// Token: 0x040001CE RID: 462
		private ObservableCollection<IMActionItem> mIMActionItems = new ObservableCollection<IMActionItem>();
	}
}
