﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000A4 RID: 164
	public class MacroSettingsWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x06000653 RID: 1619 RVA: 0x000256D0 File Offset: 0x000238D0
		internal MacroSettingsWindow(MainWindow window, MacroRecording record, MacroRecorderWindow singleMacroControl)
		{
			this.InitializeComponent();
			this.ParentWindow = window;
			base.Owner = this.ParentWindow;
			this.mMacroRecorderWindow = singleMacroControl;
			this.mRecording = record;
			InputMethod.SetIsInputMethodEnabled(this.mLoopCountTextBox, false);
			InputMethod.SetIsInputMethodEnabled(this.mLoopHours, false);
			InputMethod.SetIsInputMethodEnabled(this.mLoopMinutes, false);
			InputMethod.SetIsInputMethodEnabled(this.mLoopSeconds, false);
			InputMethod.SetIsInputMethodEnabled(this.mLoopIntervalMinsTextBox, false);
			InputMethod.SetIsInputMethodEnabled(this.mRestartPlayerIntervalTextBox, false);
			InputMethod.SetIsInputMethodEnabled(this.mLoopIntervalSecondsTextBox, false);
			this.InitSettings();
		}

		// Token: 0x06000654 RID: 1620 RVA: 0x00025764 File Offset: 0x00023964
		private void InitSettings()
		{
			this.mSettingsHeaderText.Text = string.Format(CultureInfo.InvariantCulture, "{0} {1}", new object[]
			{
				this.mRecording.Name,
				LocaleStrings.GetLocalizedString("STRING_SETTINGS").ToLower(CultureInfo.InvariantCulture)
			});
			this.mLoopCountTextBox.Text = this.mRecording.LoopNumber.ToString(CultureInfo.InvariantCulture);
			this.mLoopHours.Text = (this.mRecording.LoopTime / 3600).ToString(CultureInfo.InvariantCulture);
			this.mLoopMinutes.Text = (this.mRecording.LoopTime / 60 % 60).ToString(CultureInfo.InvariantCulture);
			this.mLoopSeconds.Text = (this.mRecording.LoopTime % 60).ToString(CultureInfo.InvariantCulture);
			this.mLoopIntervalMinsTextBox.Text = (this.mRecording.LoopInterval / 60).ToString(CultureInfo.InvariantCulture);
			this.mLoopIntervalSecondsTextBox.Text = (this.mRecording.LoopInterval % 60).ToString(CultureInfo.InvariantCulture);
			this.mRestartPlayerCheckBox.IsChecked = new bool?(this.mRecording.RestartPlayer);
			this.mPlayOnStartCheckBox.IsChecked = new bool?(this.mRecording.PlayOnStart);
			this.mDonotShowWindowOnFinishCheckBox.IsChecked = new bool?(this.mRecording.DonotShowWindowOnFinish);
			this.mRestartPlayerIntervalTextBox.Text = this.mRecording.RestartPlayerAfterMinutes.ToString(CultureInfo.InvariantCulture);
			this.mAccelerationCombobox.Items.Clear();
			for (int i = 0; i <= 8; i++)
			{
				ComboBoxItem comboBoxItem = new ComboBoxItem();
				comboBoxItem.Content = ((double)(i + 2) * 0.5).ToString(CultureInfo.InvariantCulture) + "x";
				this.mAccelerationCombobox.Items.Add(comboBoxItem);
			}
			if (this.mRecording.Acceleration == 0.0)
			{
				this.mAccelerationCombobox.SelectedIndex = 0;
			}
			else
			{
				this.mAccelerationCombobox.SelectedIndex = (int)(this.mRecording.Acceleration / 0.5 - 2.0);
			}
			this.mRestartTextBlock.ToolTip = string.Format(CultureInfo.InvariantCulture, string.Concat(new string[]
			{
				LocaleStrings.GetLocalizedString("STRING_AFTER"),
				" ",
				this.mRestartPlayerIntervalTextBox.Text,
				" ",
				LocaleStrings.GetLocalizedString("STRING_RESTART_PLAYER_AFTER")
			}), new object[0]);
			this.SelectRepeatExecutionSetting();
			this.mLoopCountTextBox.TextChanged += this.LoopCountTextBox_TextChanged;
		}

		// Token: 0x06000655 RID: 1621 RVA: 0x00025A3C File Offset: 0x00023C3C
		private void SelectRepeatExecutionSetting()
		{
			switch (this.mRecording.LoopType)
			{
			case OperationsLoopType.TillLoopNumber:
				this.mRepeatActionTimePanelGrid.IsEnabled = false;
				this.mRepeatActionInSession.IsChecked = new bool?(true);
				return;
			case OperationsLoopType.TillTime:
				this.mRepeatActionInSessionGrid.IsEnabled = false;
				this.mRepeatActionTime.IsChecked = new bool?(true);
				return;
			case OperationsLoopType.UntilStopped:
				this.mRepeatActionTimePanelGrid.IsEnabled = false;
				this.mRepeatActionInSessionGrid.IsEnabled = false;
				this.mRepeatSessionInfinite.IsChecked = new bool?(true);
				return;
			default:
				return;
			}
		}

		// Token: 0x06000656 RID: 1622 RVA: 0x0000615C File Offset: 0x0000435C
		private void Close_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.IsMacroSettingsChanged())
			{
				this.GetUnsavedChangesWindow().ShowDialog();
			}
			this.CloseWindow();
		}

		// Token: 0x06000657 RID: 1623 RVA: 0x00025AD0 File Offset: 0x00023CD0
		private void SaveButton_Click(object sender, RoutedEventArgs e)
		{
			if (string.IsNullOrEmpty(this.mLoopHours.Text))
			{
				this.mLoopHours.Text = "0";
			}
			if (string.IsNullOrEmpty(this.mLoopMinutes.Text))
			{
				this.mLoopMinutes.Text = "0";
			}
			if (string.IsNullOrEmpty(this.mLoopSeconds.Text))
			{
				this.mLoopSeconds.Text = "0";
			}
			if (string.IsNullOrEmpty(this.mLoopCountTextBox.Text))
			{
				this.mLoopCountTextBox.Text = "0";
			}
			if (string.IsNullOrEmpty(this.mLoopIntervalMinsTextBox.Text))
			{
				this.mLoopIntervalMinsTextBox.Text = "0";
			}
			if (string.IsNullOrEmpty(this.mLoopIntervalSecondsTextBox.Text))
			{
				this.mLoopIntervalSecondsTextBox.Text = "0";
			}
			if (string.IsNullOrEmpty(this.mRestartPlayerIntervalTextBox.Text))
			{
				this.mRestartPlayerIntervalTextBox.Text = "0";
			}
			bool flag = this.IsMacroSettingsChanged();
			if (!string.IsNullOrEmpty(this.mRestartPlayerIntervalTextBox.Text) && int.Parse(this.mRestartPlayerIntervalTextBox.Text, CultureInfo.InvariantCulture) > 0)
			{
				if (!flag)
				{
					this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_NO_CHANGES_SAVE"), 4.0, true);
					return;
				}
				this.SaveScriptSettings();
				if (sender != null)
				{
					this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_CHANGES_SAVED"), 4.0, true);
					return;
				}
			}
			else
			{
				this.ParentWindow.mCommonHandler.AddToastPopup(this, LocaleStrings.GetLocalizedString("STRING_MACRO_RESTART_INTERVAL_NULL"), 4.0, true);
				this.mRestartPlayerIntervalTextBox.Text = this.mRecording.RestartPlayerAfterMinutes.ToString(CultureInfo.InvariantCulture);
			}
		}

		// Token: 0x06000658 RID: 1624 RVA: 0x00025CA0 File Offset: 0x00023EA0
		private CustomMessageWindow GetUnsavedChangesWindow()
		{
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_MACRO_TOOL");
			customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_UNSAVED_CHANGES_CLOSE_WINDOW");
			customMessageWindow.IsWindowClosable = false;
			customMessageWindow.AddButton(ButtonColors.Blue, LocaleStrings.GetLocalizedString("STRING_SAVE_CHANGES"), delegate(object s, EventArgs e)
			{
				this.SaveAndCloseWindow();
			}, null, false, null);
			customMessageWindow.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_CLOSE"), null, null, false, null);
			customMessageWindow.Owner = this.ParentWindow;
			return customMessageWindow;
		}

		// Token: 0x06000659 RID: 1625 RVA: 0x00006178 File Offset: 0x00004378
		protected override void OnClosed(EventArgs e)
		{
			base.OnClosed(e);
		}

		// Token: 0x0600065A RID: 1626 RVA: 0x00006181 File Offset: 0x00004381
		private void CloseWindow()
		{
			base.Close();
			this.mMacroRecorderWindow.mOverlayGrid.Visibility = Visibility.Hidden;
		}

		// Token: 0x0600065B RID: 1627 RVA: 0x0000619A File Offset: 0x0000439A
		private void SaveAndCloseWindow()
		{
			this.SaveButton_Click(null, null);
			this.ParentWindow.mCommonHandler.AddToastPopup(this.mMacroRecorderWindow, LocaleStrings.GetLocalizedString("STRING_CHANGES_SAVED"), 4.0, true);
		}

		// Token: 0x0600065C RID: 1628 RVA: 0x0000615C File Offset: 0x0000435C
		private void CancelButton_Click(object sender, RoutedEventArgs e)
		{
			if (this.IsMacroSettingsChanged())
			{
				this.GetUnsavedChangesWindow().ShowDialog();
			}
			this.CloseWindow();
		}

		// Token: 0x0600065D RID: 1629 RVA: 0x00025D24 File Offset: 0x00023F24
		private void SaveScriptSettings()
		{
			try
			{
				this.mRecording.LoopType = this.FindLoopType();
				if ((double)this.mAccelerationCombobox.SelectedIndex < 0.0)
				{
					this.mRecording.Acceleration = 1.0;
				}
				else
				{
					this.mRecording.Acceleration = (double)(this.mAccelerationCombobox.SelectedIndex + 2) * 0.5;
				}
				bool? isChecked = this.mPlayOnStartCheckBox.IsChecked;
				bool flag = true;
				if (isChecked.GetValueOrDefault() == flag & isChecked != null)
				{
					if (this.ParentWindow.mAutoRunMacro != null)
					{
						this.ParentWindow.mAutoRunMacro.PlayOnStart = false;
						CommonHandlers.SaveMacroJson(this.ParentWindow.mAutoRunMacro, this.ParentWindow.mAutoRunMacro.Name + ".json");
					}
					foreach (object obj in this.ParentWindow.MacroRecorderWindow.mScriptsStackPanel.Children)
					{
						SingleMacroControl singleMacroControl = (SingleMacroControl)obj;
						if (this.ParentWindow.mAutoRunMacro != null && singleMacroControl.mScriptName.Text == this.ParentWindow.mAutoRunMacro.Name)
						{
							singleMacroControl.mAutorunImage.Visibility = Visibility.Hidden;
						}
						if (singleMacroControl.mScriptName.Text == this.mRecording.Name)
						{
							singleMacroControl.mAutorunImage.Visibility = Visibility.Visible;
						}
					}
					this.ParentWindow.mAutoRunMacro = this.mRecording;
				}
				this.mRecording.LoopTime = Convert.ToInt32(this.mLoopHours.Text, CultureInfo.InvariantCulture) * 3600 + Convert.ToInt32(this.mLoopMinutes.Text, CultureInfo.InvariantCulture) * 60 + Convert.ToInt32(this.mLoopSeconds.Text, CultureInfo.InvariantCulture);
				if (this.mLoopCountTextBox.InputTextValidity == TextValidityOptions.Success)
				{
					this.mRecording.LoopNumber = Convert.ToInt32(this.mLoopCountTextBox.Text, CultureInfo.InvariantCulture);
				}
				this.mRecording.LoopInterval = Convert.ToInt32(this.mLoopIntervalMinsTextBox.Text, CultureInfo.InvariantCulture) * 60 + Convert.ToInt32(this.mLoopIntervalSecondsTextBox.Text, CultureInfo.InvariantCulture);
				this.mRecording.PlayOnStart = Convert.ToBoolean(this.mPlayOnStartCheckBox.IsChecked, CultureInfo.InvariantCulture);
				this.mRecording.DonotShowWindowOnFinish = Convert.ToBoolean(this.mDonotShowWindowOnFinishCheckBox.IsChecked, CultureInfo.InvariantCulture);
				this.mRecording.RestartPlayer = Convert.ToBoolean(this.mRestartPlayerCheckBox.IsChecked, CultureInfo.InvariantCulture);
				this.mRecording.RestartPlayerAfterMinutes = Convert.ToInt32(this.mRestartPlayerIntervalTextBox.Text, CultureInfo.InvariantCulture);
				if (this.mRecording.RecordingType == RecordingTypes.SingleRecording)
				{
					CommonHandlers.SaveMacroJson(this.mRecording, this.mRecording.Name + ".json");
				}
				CommonHandlers.RefreshAllMacroRecorderWindow();
				CommonHandlers.OnMacroSettingChanged(this.mRecording);
				this.InitSettings();
			}
			catch (Exception ex)
			{
				Logger.Error("Error in saving macro settings: " + ex.ToString());
			}
		}

		// Token: 0x0600065E RID: 1630 RVA: 0x0002609C File Offset: 0x0002429C
		private OperationsLoopType FindLoopType()
		{
			if (this.mRepeatActionInSession.IsChecked.Value)
			{
				return OperationsLoopType.TillLoopNumber;
			}
			if (this.mRepeatActionTime.IsChecked.Value)
			{
				return OperationsLoopType.TillTime;
			}
			return OperationsLoopType.UntilStopped;
		}

		// Token: 0x0600065F RID: 1631 RVA: 0x000260D8 File Offset: 0x000242D8
		private void TopBar_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!e.OriginalSource.GetType().Equals(typeof(CustomPictureBox)))
			{
				try
				{
					base.DragMove();
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000660 RID: 1632 RVA: 0x000061CE File Offset: 0x000043CE
		private void NumericTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
		{
			e.Handled = !this.IsTextAllowed(e.Text);
		}

		// Token: 0x06000661 RID: 1633 RVA: 0x00005ECB File Offset: 0x000040CB
		private bool IsTextAllowed(string text)
		{
			return new Regex("^[0-9]+$").IsMatch(text) && text.IndexOf(' ') == -1;
		}

		// Token: 0x06000662 RID: 1634 RVA: 0x0002611C File Offset: 0x0002431C
		private void NumericTextBox_Pasting(object sender, DataObjectPastingEventArgs e)
		{
			if (e.DataObject.GetDataPresent(typeof(string)))
			{
				string text = (string)e.DataObject.GetData(typeof(string));
				if (!this.IsTextAllowed(text))
				{
					e.CancelCommand();
					return;
				}
			}
			else
			{
				e.CancelCommand();
			}
		}

		// Token: 0x06000663 RID: 1635 RVA: 0x00005EB8 File Offset: 0x000040B8
		private void NumericTextBox_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Space)
			{
				e.Handled = true;
			}
		}

		// Token: 0x06000664 RID: 1636 RVA: 0x00026174 File Offset: 0x00024374
		private bool IsMacroSettingsChanged()
		{
			if (this.mLoopHours.Text != (this.mRecording.LoopTime / 3600).ToString(CultureInfo.InvariantCulture))
			{
				return true;
			}
			if (this.mLoopMinutes.Text != (this.mRecording.LoopTime / 60 % 60).ToString(CultureInfo.InvariantCulture))
			{
				return true;
			}
			if (this.mLoopSeconds.Text != (this.mRecording.LoopTime % 60).ToString(CultureInfo.InvariantCulture))
			{
				return true;
			}
			if (this.mLoopCountTextBox.Text != this.mRecording.LoopNumber.ToString(CultureInfo.InvariantCulture))
			{
				return true;
			}
			if (this.mLoopIntervalMinsTextBox.Text != (this.mRecording.LoopInterval / 60).ToString(CultureInfo.InvariantCulture))
			{
				return true;
			}
			if (this.mLoopIntervalSecondsTextBox.Text != (this.mRecording.LoopInterval % 60).ToString(CultureInfo.InvariantCulture))
			{
				return true;
			}
			bool? isChecked = this.mRestartPlayerCheckBox.IsChecked;
			bool flag = this.mRecording.RestartPlayer;
			if (!(isChecked.GetValueOrDefault() == flag & isChecked != null))
			{
				return true;
			}
			isChecked = this.mPlayOnStartCheckBox.IsChecked;
			flag = this.mRecording.PlayOnStart;
			if (!(isChecked.GetValueOrDefault() == flag & isChecked != null))
			{
				return true;
			}
			isChecked = this.mDonotShowWindowOnFinishCheckBox.IsChecked;
			flag = this.mRecording.DonotShowWindowOnFinish;
			return !(isChecked.GetValueOrDefault() == flag & isChecked != null) || this.mRestartPlayerIntervalTextBox.Text != this.mRecording.RestartPlayerAfterMinutes.ToString(CultureInfo.InvariantCulture) || this.FindLoopType() != this.mRecording.LoopType || (this.mAccelerationCombobox.SelectedIndex != 0 && this.mRecording.Acceleration == 0.0) || this.mAccelerationCombobox.SelectedIndex != (int)(this.mRecording.Acceleration / 0.5 - 2.0);
		}

		// Token: 0x06000665 RID: 1637 RVA: 0x000263C0 File Offset: 0x000245C0
		private void RestartTextBlock_ToolTipOpening(object sender, ToolTipEventArgs e)
		{
			this.mRestartTextBlock.ToolTip = string.Format(CultureInfo.InvariantCulture, string.Concat(new string[]
			{
				LocaleStrings.GetLocalizedString("STRING_AFTER"),
				" ",
				this.mRestartPlayerIntervalTextBox.Text,
				" ",
				LocaleStrings.GetLocalizedString("STRING_RESTART_PLAYER_AFTER")
			}), new object[0]);
		}

		// Token: 0x06000666 RID: 1638 RVA: 0x0002642C File Offset: 0x0002462C
		private void RepeatAction_Checked(object sender, RoutedEventArgs e)
		{
			switch (this.FindLoopType())
			{
			case OperationsLoopType.TillLoopNumber:
				this.mRepeatActionTimePanelGrid.IsEnabled = false;
				this.mRepeatActionInSessionGrid.IsEnabled = true;
				this.mRepeatActionInSession.IsChecked = new bool?(true);
				return;
			case OperationsLoopType.TillTime:
				this.mRepeatActionInSessionGrid.IsEnabled = false;
				this.mRepeatActionTimePanelGrid.IsEnabled = true;
				this.mRepeatActionTime.IsChecked = new bool?(true);
				return;
			case OperationsLoopType.UntilStopped:
				this.mRepeatActionTimePanelGrid.IsEnabled = false;
				this.mRepeatActionInSessionGrid.IsEnabled = false;
				this.mRepeatSessionInfinite.IsChecked = new bool?(true);
				return;
			default:
				return;
			}
		}

		// Token: 0x06000667 RID: 1639 RVA: 0x000264D0 File Offset: 0x000246D0
		private void LoopCountTextBox_TextChanged(object sender, TextChangedEventArgs e)
		{
			CustomTextBox customTextBox = sender as CustomTextBox;
			customTextBox.InputTextValidity = ((string.IsNullOrEmpty(customTextBox.Text) || Convert.ToInt32(this.mLoopCountTextBox.Text, CultureInfo.InvariantCulture) == 0) ? TextValidityOptions.Error : TextValidityOptions.Success);
			this.mErrorNamePopup.IsOpen = (customTextBox.InputTextValidity == TextValidityOptions.Error);
			this.mSaveButton.IsEnabled = (customTextBox.InputTextValidity == TextValidityOptions.Success);
		}

		// Token: 0x06000668 RID: 1640 RVA: 0x000061E5 File Offset: 0x000043E5
		private void LoopCountTextBox_MouseEnter(object sender, MouseEventArgs e)
		{
			if (this.mLoopCountTextBox.InputTextValidity == TextValidityOptions.Error)
			{
				this.mErrorNamePopup.IsOpen = true;
				this.mErrorNamePopup.StaysOpen = true;
				return;
			}
			this.mErrorNamePopup.IsOpen = false;
		}

		// Token: 0x06000669 RID: 1641 RVA: 0x0000621A File Offset: 0x0000441A
		private void LoopCountTextBox_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mErrorNamePopup.IsOpen = false;
		}

		// Token: 0x0600066A RID: 1642 RVA: 0x0002653C File Offset: 0x0002473C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/macrosettingswindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600066B RID: 1643 RVA: 0x0002656C File Offset: 0x0002476C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				this.mSettingsHeaderText = (TextBlock)target;
				this.mSettingsHeaderText.MouseDown += this.TopBar_MouseDown;
				return;
			case 3:
				((CustomPictureBox)target).MouseLeftButtonUp += this.Close_MouseLeftButtonUp;
				return;
			case 4:
				this.mRepeactActionPanel = (StackPanel)target;
				return;
			case 5:
				this.mRepeatActionInSession = (CustomRadioButton)target;
				this.mRepeatActionInSession.Checked += this.RepeatAction_Checked;
				return;
			case 6:
				this.mRepeatActionInSessionGrid = (Grid)target;
				return;
			case 7:
				this.mLoopCountTextBox = (CustomTextBox)target;
				this.mLoopCountTextBox.PreviewTextInput += this.NumericTextBox_PreviewTextInput;
				this.mLoopCountTextBox.AddHandler(DataObject.PastingEvent, new DataObjectPastingEventHandler(this.NumericTextBox_Pasting));
				this.mLoopCountTextBox.PreviewKeyDown += this.NumericTextBox_KeyDown;
				this.mLoopCountTextBox.MouseEnter += this.LoopCountTextBox_MouseEnter;
				this.mLoopCountTextBox.MouseLeave += this.LoopCountTextBox_MouseLeave;
				return;
			case 8:
				this.mErrorNamePopup = (CustomPopUp)target;
				return;
			case 9:
				this.mMaskBorder1 = (Border)target;
				return;
			case 10:
				this.mErrorText = (TextBlock)target;
				return;
			case 11:
				this.mDownArrow = (Path)target;
				return;
			case 12:
				this.mRepeatActionTimePanel = (StackPanel)target;
				return;
			case 13:
				this.mRepeatActionTime = (CustomRadioButton)target;
				this.mRepeatActionTime.Checked += this.RepeatAction_Checked;
				return;
			case 14:
				this.mRepeatActionTimePanelGrid = (Grid)target;
				return;
			case 15:
				this.mLoopHours = (CustomTextBox)target;
				this.mLoopHours.PreviewTextInput += this.NumericTextBox_PreviewTextInput;
				this.mLoopHours.AddHandler(DataObject.PastingEvent, new DataObjectPastingEventHandler(this.NumericTextBox_Pasting));
				this.mLoopHours.PreviewKeyDown += this.NumericTextBox_KeyDown;
				return;
			case 16:
				this.mLoopMinutes = (CustomTextBox)target;
				this.mLoopMinutes.PreviewTextInput += this.NumericTextBox_PreviewTextInput;
				this.mLoopMinutes.AddHandler(DataObject.PastingEvent, new DataObjectPastingEventHandler(this.NumericTextBox_Pasting));
				this.mLoopMinutes.PreviewKeyDown += this.NumericTextBox_KeyDown;
				return;
			case 17:
				this.mLoopSeconds = (CustomTextBox)target;
				this.mLoopSeconds.PreviewTextInput += this.NumericTextBox_PreviewTextInput;
				this.mLoopSeconds.AddHandler(DataObject.PastingEvent, new DataObjectPastingEventHandler(this.NumericTextBox_Pasting));
				this.mLoopSeconds.PreviewKeyDown += this.NumericTextBox_KeyDown;
				return;
			case 18:
				this.mRepeatSessionInfinitePanel = (StackPanel)target;
				return;
			case 19:
				this.mRepeatSessionInfinite = (CustomRadioButton)target;
				this.mRepeatSessionInfinite.Checked += this.RepeatAction_Checked;
				return;
			case 20:
				this.mLoopIntervalMinsTextBox = (CustomTextBox)target;
				this.mLoopIntervalMinsTextBox.PreviewTextInput += this.NumericTextBox_PreviewTextInput;
				this.mLoopIntervalMinsTextBox.AddHandler(DataObject.PastingEvent, new DataObjectPastingEventHandler(this.NumericTextBox_Pasting));
				this.mLoopIntervalMinsTextBox.PreviewKeyDown += this.NumericTextBox_KeyDown;
				return;
			case 21:
				this.mLoopIntervalSecondsTextBox = (CustomTextBox)target;
				this.mLoopIntervalSecondsTextBox.PreviewTextInput += this.NumericTextBox_PreviewTextInput;
				this.mLoopIntervalSecondsTextBox.AddHandler(DataObject.PastingEvent, new DataObjectPastingEventHandler(this.NumericTextBox_Pasting));
				this.mLoopIntervalSecondsTextBox.PreviewKeyDown += this.NumericTextBox_KeyDown;
				return;
			case 22:
				this.mAccelerationCombobox = (CustomComboBox)target;
				return;
			case 23:
				this.mPlayOnStartCheckBox = (CustomCheckbox)target;
				return;
			case 24:
				this.mRestartPlayerCheckBox = (CustomCheckbox)target;
				return;
			case 25:
				this.mRestartPlayerIntervalTextBox = (CustomTextBox)target;
				this.mRestartPlayerIntervalTextBox.PreviewTextInput += this.NumericTextBox_PreviewTextInput;
				this.mRestartPlayerIntervalTextBox.AddHandler(DataObject.PastingEvent, new DataObjectPastingEventHandler(this.NumericTextBox_Pasting));
				this.mRestartPlayerIntervalTextBox.PreviewKeyDown += this.NumericTextBox_KeyDown;
				return;
			case 26:
				this.mRestartTextBlock = (TextBlock)target;
				this.mRestartTextBlock.ToolTipOpening += this.RestartTextBlock_ToolTipOpening;
				return;
			case 27:
				this.mDonotShowWindowOnFinishCheckBox = (CustomCheckbox)target;
				return;
			case 28:
				this.mSaveButton = (CustomButton)target;
				this.mSaveButton.Click += this.SaveButton_Click;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400037D RID: 893
		private MainWindow ParentWindow;

		// Token: 0x0400037E RID: 894
		private MacroRecorderWindow mMacroRecorderWindow;

		// Token: 0x0400037F RID: 895
		private MacroRecording mRecording;

		// Token: 0x04000380 RID: 896
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder;

		// Token: 0x04000381 RID: 897
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mSettingsHeaderText;

		// Token: 0x04000382 RID: 898
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mRepeactActionPanel;

		// Token: 0x04000383 RID: 899
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mRepeatActionInSession;

		// Token: 0x04000384 RID: 900
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mRepeatActionInSessionGrid;

		// Token: 0x04000385 RID: 901
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mLoopCountTextBox;

		// Token: 0x04000386 RID: 902
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mErrorNamePopup;

		// Token: 0x04000387 RID: 903
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder1;

		// Token: 0x04000388 RID: 904
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mErrorText;

		// Token: 0x04000389 RID: 905
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Path mDownArrow;

		// Token: 0x0400038A RID: 906
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mRepeatActionTimePanel;

		// Token: 0x0400038B RID: 907
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mRepeatActionTime;

		// Token: 0x0400038C RID: 908
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mRepeatActionTimePanelGrid;

		// Token: 0x0400038D RID: 909
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mLoopHours;

		// Token: 0x0400038E RID: 910
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mLoopMinutes;

		// Token: 0x0400038F RID: 911
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mLoopSeconds;

		// Token: 0x04000390 RID: 912
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mRepeatSessionInfinitePanel;

		// Token: 0x04000391 RID: 913
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mRepeatSessionInfinite;

		// Token: 0x04000392 RID: 914
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mLoopIntervalMinsTextBox;

		// Token: 0x04000393 RID: 915
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mLoopIntervalSecondsTextBox;

		// Token: 0x04000394 RID: 916
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomComboBox mAccelerationCombobox;

		// Token: 0x04000395 RID: 917
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mPlayOnStartCheckBox;

		// Token: 0x04000396 RID: 918
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mRestartPlayerCheckBox;

		// Token: 0x04000397 RID: 919
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mRestartPlayerIntervalTextBox;

		// Token: 0x04000398 RID: 920
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mRestartTextBlock;

		// Token: 0x04000399 RID: 921
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mDonotShowWindowOnFinishCheckBox;

		// Token: 0x0400039A RID: 922
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mSaveButton;

		// Token: 0x0400039B RID: 923
		private bool _contentLoaded;
	}
}
