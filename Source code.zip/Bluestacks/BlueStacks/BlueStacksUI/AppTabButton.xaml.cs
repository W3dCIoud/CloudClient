﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200002B RID: 43
	public partial class AppTabButton : Button
	{
		// Token: 0x17000104 RID: 260
		// (get) Token: 0x06000273 RID: 627 RVA: 0x00003A69 File Offset: 0x00001C69
		public MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x17000105 RID: 261
		// (get) Token: 0x06000274 RID: 628 RVA: 0x00003A8A File Offset: 0x00001C8A
		// (set) Token: 0x06000275 RID: 629 RVA: 0x00003A92 File Offset: 0x00001C92
		public EventHandler<TabChangeEventArgs> EventOnTabChanged { get; set; }

		// Token: 0x17000106 RID: 262
		// (get) Token: 0x06000276 RID: 630 RVA: 0x00003A9B File Offset: 0x00001C9B
		// (set) Token: 0x06000277 RID: 631 RVA: 0x00003AA3 File Offset: 0x00001CA3
		internal bool IsCursorClipped { get; set; }

		// Token: 0x17000107 RID: 263
		// (get) Token: 0x06000278 RID: 632 RVA: 0x00003AAC File Offset: 0x00001CAC
		// (set) Token: 0x06000279 RID: 633 RVA: 0x00003AB4 File Offset: 0x00001CB4
		internal GameOnboardingWindow OnboardingWindow { get; set; }

		// Token: 0x17000108 RID: 264
		// (get) Token: 0x0600027A RID: 634 RVA: 0x00003ABD File Offset: 0x00001CBD
		// (set) Token: 0x0600027B RID: 635 RVA: 0x00003AC5 File Offset: 0x00001CC5
		public bool IsPortraitModeTab
		{
			get
			{
				return this.mIsPortraitModeTab;
			}
			set
			{
				this.mIsPortraitModeTab = value;
				if (this.IsSelected && this.ParentWindow.IsUIInPortraitMode != this.mIsPortraitModeTab)
				{
					this.ParentWindow.SwitchToPortraitMode(this.mIsPortraitModeTab);
				}
			}
		}

		// Token: 0x17000109 RID: 265
		// (get) Token: 0x0600027C RID: 636 RVA: 0x00003AFA File Offset: 0x00001CFA
		// (set) Token: 0x0600027D RID: 637 RVA: 0x00003B02 File Offset: 0x00001D02
		public bool IsMoreTabsButton
		{
			get
			{
				return this.mIsMoreTabsButton;
			}
			set
			{
				this.mIsMoreTabsButton = value;
				this.mAppTabIcon.IsEnabled = false;
			}
		}

		// Token: 0x1700010A RID: 266
		// (get) Token: 0x0600027E RID: 638 RVA: 0x00003B17 File Offset: 0x00001D17
		// (set) Token: 0x0600027F RID: 639 RVA: 0x00003B1F File Offset: 0x00001D1F
		public bool IsButtonInDropDown { get; set; }

		// Token: 0x1700010B RID: 267
		// (get) Token: 0x06000280 RID: 640 RVA: 0x00003B28 File Offset: 0x00001D28
		// (set) Token: 0x06000281 RID: 641 RVA: 0x00003B30 File Offset: 0x00001D30
		public bool IsSelected { get; private set; }

		// Token: 0x1700010C RID: 268
		// (get) Token: 0x06000282 RID: 642 RVA: 0x00003B39 File Offset: 0x00001D39
		// (set) Token: 0x06000283 RID: 643 RVA: 0x00003B41 File Offset: 0x00001D41
		public bool IsShootingModeTooltipEnabled { get; set; } = true;

		// Token: 0x1700010D RID: 269
		// (get) Token: 0x06000284 RID: 644 RVA: 0x00003B4A File Offset: 0x00001D4A
		public bool IsClosingApp
		{
			get
			{
				return this.CloseTabButtonLandScape.IsMouseOver || this.CloseTabButtonPortrait.IsMouseOver || this.CloseTabButtonDropDown.IsMouseOver;
			}
		}

		// Token: 0x06000285 RID: 645 RVA: 0x00013D04 File Offset: 0x00011F04
		internal void Select(bool value, bool receivedFromImap = false)
		{
			if (this.ParentWindow.StaticComponents.mSelectedTabButton != this || !value)
			{
				if (this.ParentWindow.StaticComponents.mSelectedTabButton != null)
				{
					if (!string.Equals(KMManager.sPackageName, this.PackageName, StringComparison.InvariantCulture))
					{
						KMManager.CloseWindows();
						if (KMManager.sGuidanceWindow != null)
						{
							return;
						}
					}
					AppTabButton mSelectedTabButton = this.ParentWindow.StaticComponents.mSelectedTabButton;
					if (mSelectedTabButton.mTabType == TabType.HomeTab)
					{
						this.mIsSwitchedBackFromHomeTab = true;
					}
					else
					{
						this.mIsSwitchedBackFromHomeTab = false;
					}
					this.ParentWindow.StaticComponents.mSelectedTabButton = null;
					mSelectedTabButton.Select(false, false);
					if (mSelectedTabButton.IsCursorClipped && this.mTabType == TabType.AppTab)
					{
						this.IsCursorClipped = true;
					}
					mSelectedTabButton.IsCursorClipped = false;
					this.ParentWindow.StaticComponents.mPreviousSelectedTabWeb = (mSelectedTabButton.mTabType == TabType.WebTab);
				}
				this.ParentWindow.ToggleFullScreenToastVisibility(false, "", "", "");
				this.IsSelected = value;
				if (this.IsSelected)
				{
					Publisher.PublishMessage(BrowserControlTags.tabSwitched, this.PackageName, this.ParentWindow.mVmName);
					this.ParentWindow.mTopBar.mAppTabButtons.ListTabHistory.RemoveAll((string n) => n.Equals(this.TabKey, StringComparison.OrdinalIgnoreCase));
					this.ParentWindow.mTopBar.mAppTabButtons.ListTabHistory.Add(this.TabKey);
					this.ParentWindow.StaticComponents.mSelectedTabButton = this;
					this.ParentWindow.Utils.ResetPendingUIOperations();
					if (this.mTabType == TabType.WebTab)
					{
						if (this.ParentWindow.mIsFullScreen)
						{
							this.ParentWindow.RestoreWindows(false);
						}
						BrowserControl browserControl = this.GetBrowserControl();
						if (browserControl == null)
						{
							this.mControlGrid = this.ParentWindow.AddBrowser(this.PackageName);
							this.Init(this.AppName, this.PackageName, this.mAppTabIcon.ImageName, this.mControlGrid, this.TabKey);
						}
						else
						{
							try
							{
								object[] args = new object[0];
								if (browserControl.CefBrowser != null)
								{
									browserControl.CefBrowser.CallJs("webtabselected", args);
								}
							}
							catch (Exception ex)
							{
								Logger.Warning("Ignoring webtabselected exception. " + ex.Message);
							}
						}
						this.ParentWindow.ChangeWindowOrientaion(this, new ChangeOrientationEventArgs(this.ParentWindow.mAspectRatio < 1L));
					}
					this.ParentWindow.ShowControlGrid(this.mControlGrid);
					if (this.mTabType == TabType.AppTab || this.mTabType == TabType.HomeTab)
					{
						if (this.ParentWindow.AppForcedOrientationDict.ContainsKey(this.PackageName))
						{
							this.ParentWindow.ChangeOrientationFromClient(this.ParentWindow.AppForcedOrientationDict[this.PackageName], true);
						}
						else
						{
							this.ParentWindow.ChangeOrientationFromClient(false, false);
						}
					}
					if (this.mTabType == TabType.HomeTab)
					{
						if (this.ParentWindow.mWelcomeTab.mHomeApp.mSearchTextBox.IsFocused)
						{
							MiscUtils.SetFocusAsync(this.ParentWindow.mWelcomeTab.mHomeApp.mSearchTextBox, 100);
						}
						if (this.ParentWindow.mIsFullScreen)
						{
							this.ParentWindow.RestoreWindows(false);
						}
						this.ParentWindow.mWelcomeTab.mHomeApp.StartGif();
					}
					else if (!FeatureManager.Instance.IsCustomUIForDMM && this.mTabType == TabType.AppTab && !this.ParentWindow.mSidebar.mIsOverlayTooltipClosed && !this.mIsOverlayTooltipDisplayed && KMManager.KeyMappingFilesAvailable(this.PackageName))
					{
						this.mIsOverlayTooltipDisplayed = true;
						this.ParentWindow.mSidebar.ShowOverlayTooltip(true, false);
					}
					if (this.mTabType != TabType.HomeTab)
					{
						this.ParentWindow.mWelcomeTab.mHomeApp.StopGif();
					}
					AppUsageTimer.StartTimer(this.ParentWindow.mVmName, this.TabKey);
					if (this.IsLaunchOnSelection)
					{
						this.LaunchApp();
					}
					else
					{
						this.IsLaunchOnSelection = true;
					}
					BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "SelectedTabBackgroundColor");
					BlueStacksUIBinding.BindColor(this.mTabLabel, Control.ForegroundProperty, "SelectedTabForegroundColor");
					BlueStacksUIBinding.BindColor(this.mBorder, Border.BorderBrushProperty, "SelectedTabBorderColor");
					if (!FeatureManager.Instance.IsCustomUIForDMM)
					{
						if (this.mTabType == TabType.AppTab)
						{
							this.ParentWindow.mTopBar.mAppTabButtons.KillWebTabs();
							if (KMManager.CheckGamepadCompatible(this.PackageName))
							{
								this.ParentWindow.mCommonHandler.OnGamepadButtonVisibilityChanged(true);
							}
							else
							{
								this.ParentWindow.mCommonHandler.OnGamepadButtonVisibilityChanged(false);
							}
							KMManager.LoadIMActions(this.ParentWindow, this.PackageName);
							if (this.mTabType == TabType.AppTab && !this.mIsKeyMappingTipDisplayed && !this.ParentWindow.SendClientActions && !receivedFromImap && KMManager.KeyMappingFilesAvailable(this.PackageName))
							{
								this.mIsKeyMappingTipDisplayed = true;
								this.ParentWindow.mSidebar.ShowKeyMapPopup(true);
							}
							else if (this.mGuidanceWindowOpen)
							{
								KMManager.HandleInputMapperWindow(this.ParentWindow, "");
							}
							if (RegistryManager.Instance.ShowKeyControlsOverlay && !KMManager.CheckIfKeymappingWindowVisible(false))
							{
								KMManager.ShowOverlayWindow(this.ParentWindow, true, true);
							}
							if (this.mIsSwitchedBackFromHomeTab && KMManager.KeyMappingFilesAvailable(this.PackageName))
							{
								this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("handleLoadConfigOnTabSwitch", new Dictionary<string, string>
								{
									{
										"package",
										this.PackageName
									}
								});
							}
							this.ParentWindow.mCommonHandler.HandlingForGameSettingsRedDotForSelectedGamePackges(this.PackageName, true);
							KMManager.ShowShootingModeTooltip(this.ParentWindow, this.PackageName);
							this.ParentWindow.mCommonHandler.ToggleMacroAndSyncVisibility();
							this.ParentWindow.mCommonHandler.SetCustomCursorForApp(this.PackageName);
						}
						else
						{
							KMManager.ShowOverlayWindow(this.ParentWindow, false, false);
							if (this.ParentWindow.mCommonHandler != null)
							{
								this.ParentWindow.mCommonHandler.ClipMouseCursorHandler(true, true, "", "");
							}
						}
						if (this.mTabType == TabType.HomeTab)
						{
							this.ParentWindow.mCommonHandler.ToggleMacroAndSyncVisibility();
							this.ParentWindow.mCommonHandler.ToggleSettingsBtnNotification(false);
						}
						else
						{
							this.ParentWindow.mWelcomeTab.mHomeApp.CloseAppSuggestionPopup();
						}
						List<GenericNotificationItem> list = new List<GenericNotificationItem>();
						foreach (GenericNotificationItem genericNotificationItem in from _ in PromotionManager.sPassedDeferredNotificationsList
						where string.Compare(_.DeferredApp, this.PackageName, StringComparison.OrdinalIgnoreCase) == 0
						select _)
						{
							BlueStacksUIUtils.DictWindows[Strings.CurrentDefaultVmName].HandleGenericNotificationPopup(genericNotificationItem);
							GenericNotificationManager.Instance.AddNewNotification(genericNotificationItem, false);
							BlueStacksUIUtils.DictWindows[Strings.CurrentDefaultVmName].mTopBar.RefreshNotificationCentreButton();
							list.Add(genericNotificationItem);
						}
						foreach (GenericNotificationItem item in list)
						{
							PromotionManager.sPassedDeferredNotificationsList.Remove(item);
						}
						if (this.ParentWindow.SendClientActions && !receivedFromImap)
						{
							Dictionary<string, string> dictionary = new Dictionary<string, string>();
							Dictionary<string, string> value2 = new Dictionary<string, string>
							{
								{
									"EventAction",
									"TabSelected"
								},
								{
									"tabKey",
									this.TabKey
								}
							};
							JsonSerializerSettings serializerSettings = Utils.GetSerializerSettings();
							serializerSettings.Formatting = Formatting.None;
							dictionary.Add("operationData", JsonConvert.SerializeObject(value2, serializerSettings));
							this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("handleClientOperation", dictionary);
						}
					}
					if (this.mTabType == TabType.AppTab && KMManager.KeyMappingFilesAvailable(this.PackageName) && this.ParentWindow.SelectedConfig.ControlSchemes != null && this.ParentWindow.SelectedConfig.ControlSchemes.Count > 0)
					{
						this.ParentWindow.mCommonHandler.OnGameGuideButtonVisibilityChanged(true);
					}
					else
					{
						this.ParentWindow.mCommonHandler.OnGameGuideButtonVisibilityChanged(false);
					}
					EventHandler<EventArgs> eventOnTabChanged = this.ParentWindow.mTopBar.mAppTabButtons.EventOnTabChanged;
					if (eventOnTabChanged != null)
					{
						eventOnTabChanged(null, null);
					}
					if (this.mRestartPubgTab)
					{
						base.Dispatcher.Invoke(new Action(delegate()
						{
							CustomMessageWindow customMessageWindow = new CustomMessageWindow();
							string path = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_RESTART_OBJECT"), new object[]
							{
								"PUBG Mobile"
							});
							BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, path, "");
							string path2 = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_SETTING_CHANGED_RESTART_APP_MESSAGE"), new object[]
							{
								"PUBG Mobile"
							});
							BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, path2, "");
							customMessageWindow.AddButton(ButtonColors.Blue, "STRING_RESTART_BLUESTACKS", new EventHandler(this.RestartConfirmationAcceptedHandler), null, false, null);
							customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
							this.ParentWindow.ShowDimOverlay(null);
							customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
							customMessageWindow.ShowDialog();
							this.ParentWindow.HideDimOverlay();
						}), new object[0]);
						this.mRestartPubgTab = false;
					}
					if (this.mRestartCODTab)
					{
						base.Dispatcher.Invoke(new Action(delegate()
						{
							CustomMessageWindow customMessageWindow = new CustomMessageWindow();
							string path = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_RESTART_OBJECT"), new object[]
							{
								"Call of Duty: Mobile"
							});
							BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, path, "");
							string path2 = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_SETTING_CHANGED_RESTART_APP_MESSAGE"), new object[]
							{
								"Call of Duty: Mobile"
							});
							BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, path2, "");
							customMessageWindow.AddButton(ButtonColors.Blue, "STRING_RESTART_BLUESTACKS", new EventHandler(this.RestartConfirmationAcceptedHandler), null, false, null);
							customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
							this.ParentWindow.ShowDimOverlay(null);
							customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
							customMessageWindow.ShowDialog();
							this.ParentWindow.HideDimOverlay();
						}), new object[0]);
						this.mRestartCODTab = false;
					}
					if (this.mTabType == TabType.AppTab && !File.Exists(KMManager.GetInputmapperUserFilePath(this.PackageName)))
					{
						PostBootCloudInfo mPostBootCloudInfo = PostBootCloudInfoManager.Instance.mPostBootCloudInfo;
						bool? flag;
						if (mPostBootCloudInfo == null)
						{
							flag = null;
						}
						else
						{
							AppPackageListObject onBoardingAppPackages = mPostBootCloudInfo.OnBoardingInfo.OnBoardingAppPackages;
							flag = ((onBoardingAppPackages != null) ? new bool?(onBoardingAppPackages.IsPackageAvailable(this.PackageName)) : null);
						}
						bool? flag2 = flag;
						if (flag2.GetValueOrDefault())
						{
							if (!AppConfigurationManager.Instance.CheckIfTrueInAnyVm(this.PackageName, (AppSettings appSetting) => appSetting.IsAppOnboardingCompleted))
							{
								this.OnboardingWindow = new GameOnboardingWindow(this.ParentWindow, this.PackageName);
								this.ParentWindow.ShowDimOverlay(null);
								GuidanceWindow sGuidanceWindow = KMManager.sGuidanceWindow;
								if (sGuidanceWindow != null)
								{
									sGuidanceWindow.DimOverLayVisibility(Visibility.Visible);
								}
								this.OnboardingWindow.Owner = this.ParentWindow;
								this.OnboardingWindow.ShowDialog();
								goto IL_935;
							}
						}
						this.ParentWindow.ShowDimOverlay(null);
						GuidanceWindow sGuidanceWindow2 = KMManager.sGuidanceWindow;
						if (sGuidanceWindow2 != null)
						{
							sGuidanceWindow2.CheckAndShowGeneralOnboarding();
						}
						this.ParentWindow.HideDimOverlay();
					}
					IL_935:
					if (this.ParentWindow.mTopBar.mAppTabButtons.mMoreTabButton.Visibility == Visibility.Visible)
					{
						this.MoreTabsButtonHandling();
						return;
					}
				}
				else
				{
					BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundColor");
					BlueStacksUIBinding.BindColor(this.mTabLabel, Control.ForegroundProperty, "TabForegroundColor");
					BlueStacksUIBinding.BindColor(this.mBorder, Border.BorderBrushProperty, "AppTabBorderBrush");
				}
			}
		}

		// Token: 0x06000286 RID: 646 RVA: 0x00003B73 File Offset: 0x00001D73
		private void RestartConfirmationAcceptedHandler(object sender, EventArgs e)
		{
			Logger.Info("Restarting Pubg/COD Tab.");
			new Thread(delegate()
			{
				this.ParentWindow.mTopBar.mAppTabButtons.RestartTab(this.PackageName);
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x1700010E RID: 270
		// (get) Token: 0x06000287 RID: 647 RVA: 0x00003B9C File Offset: 0x00001D9C
		// (set) Token: 0x06000288 RID: 648 RVA: 0x00003BA4 File Offset: 0x00001DA4
		public string PackageName { get; set; } = string.Empty;

		// Token: 0x1700010F RID: 271
		// (get) Token: 0x06000289 RID: 649 RVA: 0x00003BAD File Offset: 0x00001DAD
		// (set) Token: 0x0600028A RID: 650 RVA: 0x00003BB5 File Offset: 0x00001DB5
		public string TabKey { get; set; }

		// Token: 0x17000110 RID: 272
		// (get) Token: 0x0600028B RID: 651 RVA: 0x00003BBE File Offset: 0x00001DBE
		// (set) Token: 0x0600028C RID: 652 RVA: 0x00003BC6 File Offset: 0x00001DC6
		public string AppName { get; set; } = string.Empty;

		// Token: 0x17000111 RID: 273
		// (get) Token: 0x0600028D RID: 653 RVA: 0x00003BCF File Offset: 0x00001DCF
		// (set) Token: 0x0600028E RID: 654 RVA: 0x00003BD7 File Offset: 0x00001DD7
		public bool IsDMMKeymapEnabled
		{
			get
			{
				return this.mIsDMMKeyMapEnabled;
			}
			set
			{
				this.mIsDMMKeyMapEnabled = value;
				this.IsDMMKeymapUIVisible = value;
				this.ParentWindow.mCommonHandler.SetDMMKeymapButtonsAndTransparency();
			}
		}

		// Token: 0x17000112 RID: 274
		// (get) Token: 0x0600028F RID: 655 RVA: 0x00003BF7 File Offset: 0x00001DF7
		// (set) Token: 0x06000290 RID: 656 RVA: 0x00003BFF File Offset: 0x00001DFF
		public bool IsDMMKeymapUIVisible { get; set; }

		// Token: 0x17000113 RID: 275
		// (get) Token: 0x06000291 RID: 657 RVA: 0x00003C08 File Offset: 0x00001E08
		public string AppLabel
		{
			get
			{
				return this.mTabLabel.Content.ToString();
			}
		}

		// Token: 0x17000114 RID: 276
		// (get) Token: 0x06000292 RID: 658 RVA: 0x00003C1A File Offset: 0x00001E1A
		// (set) Token: 0x06000293 RID: 659 RVA: 0x00003C22 File Offset: 0x00001E22
		public bool IsLaunchOnSelection { get; set; }

		// Token: 0x17000115 RID: 277
		// (get) Token: 0x06000294 RID: 660 RVA: 0x00003C2B File Offset: 0x00001E2B
		// (set) Token: 0x06000295 RID: 661 RVA: 0x00003C33 File Offset: 0x00001E33
		public Grid mControlGrid { get; set; }

		// Token: 0x06000296 RID: 662 RVA: 0x00003C3C File Offset: 0x00001E3C
		public AppTabButton()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000297 RID: 663 RVA: 0x000146D0 File Offset: 0x000128D0
		internal void Init(string appName, string packageName, string activityName, string imageName, Grid controlGrid, string tabKey)
		{
			bool flag = false;
			if (!string.IsNullOrEmpty(tabKey))
			{
				flag = true;
			}
			this.Init(appName, packageName, imageName, controlGrid, flag ? tabKey : packageName);
			this.mActivityName = activityName;
			this.mTabType = TabType.AppTab;
			if (string.Equals(packageName, "Home", StringComparison.InvariantCulture) || string.Equals(packageName, "Setup", StringComparison.InvariantCulture))
			{
				this.mTabType = TabType.HomeTab;
				BlueStacksUIBinding.BindCornerRadius(this, FrameworkElement.MarginProperty, "TabMarginLandScape");
			}
		}

		// Token: 0x06000298 RID: 664 RVA: 0x00014740 File Offset: 0x00012940
		internal void Init(string title, string url, string imageName, Grid controlGrid, string tabKey)
		{
			BlueStacksUIBinding.Bind(this, title, FrameworkElement.ToolTipProperty);
			BlueStacksUIBinding.Bind(this.mTabLabel, title);
			this.AppName = title;
			this.PackageName = url;
			this.TabKey = tabKey;
			this.mTabType = TabType.WebTab;
			this.mControlGrid = controlGrid;
			if (!this.IsSelected)
			{
				this.mControlGrid.Visibility = Visibility.Hidden;
			}
			if (string.IsNullOrEmpty(imageName))
			{
				this.mImageColumn.Width = new GridLength(0.0);
				return;
			}
			this.mAppTabIcon.ImageName = imageName;
		}

		// Token: 0x06000299 RID: 665 RVA: 0x000147CC File Offset: 0x000129CC
		internal void ResizeButton(double tabWidth)
		{
			if (this.ParentWindow.IsUIInPortraitMode)
			{
				this.MakeTabParallelogram(false);
			}
			else
			{
				this.MakeTabParallelogram(true);
			}
			if (tabWidth != base.ActualWidth)
			{
				DoubleAnimation animation = new DoubleAnimation
				{
					From = new double?(base.ActualWidth),
					To = new double?(tabWidth),
					Duration = new Duration(TimeSpan.FromMilliseconds(200.0))
				};
				base.BeginAnimation(FrameworkElement.WidthProperty, animation);
			}
		}

		// Token: 0x0600029A RID: 666 RVA: 0x00014848 File Offset: 0x00012A48
		internal void MakeTabParallelogram(bool isSkewTab)
		{
			if (isSkewTab)
			{
				BlueStacksUIBinding.BindCornerRadius(this, FrameworkElement.MarginProperty, "TabMarginLandScape");
			}
			else
			{
				BlueStacksUIBinding.BindCornerRadius(this, FrameworkElement.MarginProperty, "TabMarginPortrait");
			}
			if (isSkewTab != this.mIsTabsSkewed)
			{
				if (isSkewTab)
				{
					this.mIsTabsSkewed = true;
					this.CloseTabButtonPortrait.Visibility = Visibility.Hidden;
					this.ParallelogramGrid.RenderTransform = new SkewTransform(BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleX, BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleY);
					DoubleAnimation animation = new DoubleAnimation(BlueStacksUIColorManager.AppliedTheme.TabTransformPortrait.AngleX, BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleX, TimeSpan.FromMilliseconds(200.0));
					DoubleAnimation doubleAnimation = new DoubleAnimation(BlueStacksUIColorManager.AppliedTheme.TabTransformPortrait.AngleY, BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleY, TimeSpan.FromMilliseconds(200.0));
					doubleAnimation.Completed += this.SkewY_Completed;
					this.ParallelogramGrid.RenderTransform.BeginAnimation(SkewTransform.AngleXProperty, animation);
					this.ParallelogramGrid.RenderTransform.BeginAnimation(SkewTransform.AngleYProperty, doubleAnimation);
					BlueStacksUIBinding.BindCornerRadius(this, FrameworkElement.MarginProperty, "TabMarginLandScape");
				}
				else
				{
					this.mIsTabsSkewed = false;
					this.CloseTabButtonLandScape.Visibility = Visibility.Hidden;
					this.ParallelogramGrid.RenderTransform = new SkewTransform(BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleX, BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleY);
					DoubleAnimation animation2 = new DoubleAnimation(BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleX, BlueStacksUIColorManager.AppliedTheme.TabTransformPortrait.AngleX, TimeSpan.FromMilliseconds(200.0));
					DoubleAnimation doubleAnimation2 = new DoubleAnimation(BlueStacksUIColorManager.AppliedTheme.TabTransformPortrait.AngleY, BlueStacksUIColorManager.AppliedTheme.TabTransform.AngleY, TimeSpan.FromMilliseconds(200.0));
					this.ParallelogramGrid.RenderTransform.BeginAnimation(SkewTransform.AngleXProperty, animation2);
					this.ParallelogramGrid.RenderTransform.BeginAnimation(SkewTransform.AngleYProperty, doubleAnimation2);
					doubleAnimation2.Completed += this.SkewY_Completed;
					BlueStacksUIBinding.BindCornerRadius(this, FrameworkElement.MarginProperty, "TabMarginPortrait");
				}
				if (this.mIsMoreTabsButton)
				{
					this.mBorder.Visibility = Visibility.Visible;
					BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundColor");
				}
			}
		}

		// Token: 0x0600029B RID: 667 RVA: 0x00003C79 File Offset: 0x00001E79
		private void SkewY_Completed(object sender, EventArgs e)
		{
			if (this.mIsTabsSkewed)
			{
				BlueStacksUIBinding.BindTransform(this.ParallelogramGrid, UIElement.RenderTransformProperty, "TabTransform");
				return;
			}
			BlueStacksUIBinding.BindTransform(this.ParallelogramGrid, UIElement.RenderTransformProperty, "TabTransformPortrait");
		}

		// Token: 0x0600029C RID: 668 RVA: 0x00014AB4 File Offset: 0x00012CB4
		private void Button_Click(object sender, RoutedEventArgs e)
		{
			if (!this.IsMoreTabsButton)
			{
				bool flag = sender.GetHashCode() == this.ParentWindow.StaticComponents.mSelectedTabButton.GetHashCode();
				bool flag2 = this.CloseTabButtonLandScape.IsMouseOver || this.CloseTabButtonPortrait.IsMouseOver || this.CloseTabButtonDropDown.IsMouseOver;
				if (flag)
				{
					if (flag2)
					{
						if (KMManager.sGuidanceWindow != null && !KMManager.sGuidanceWindow.IsClosed)
						{
							this.HandlePendingOperationsForTab("guidance");
						}
						if (KMManager.sGuidanceWindow == null)
						{
							this.ParentWindow.mTopBar.mAppTabButtons.CloseTab(this.TabKey, true, false, false, false, "");
							return;
						}
					}
				}
				else
				{
					if (flag2)
					{
						this.ParentWindow.mTopBar.mAppTabButtons.CloseTab(this.TabKey, true, false, false, false, "");
						return;
					}
					if (KMManager.sGuidanceWindow != null && !KMManager.sGuidanceWindow.IsClosed)
					{
						this.HandlePendingOperationsForTab("guidance");
					}
					if (KMManager.sGuidanceWindow == null)
					{
						this.Select(true, false);
						this.Button_PreviewMouseUp(null, null);
						EventHandler<TabChangeEventArgs> eventOnTabChanged = this.EventOnTabChanged;
						if (eventOnTabChanged == null)
						{
							return;
						}
						eventOnTabChanged(this, new TabChangeEventArgs(this.AppName, this.PackageName, this.mTabType));
					}
				}
			}
		}

		// Token: 0x0600029D RID: 669 RVA: 0x00003CAE File Offset: 0x00001EAE
		private void HandlePendingOperationsForTab(string pendingOperation)
		{
			if (pendingOperation != null && pendingOperation == "guidance")
			{
				KMManager.CloseWindows();
			}
		}

		// Token: 0x0600029E RID: 670 RVA: 0x00014BEC File Offset: 0x00012DEC
		internal void UpdateUIForDropDown(bool isInDropDown)
		{
			if (isInDropDown)
			{
				this.IsButtonInDropDown = true;
				this.MakeTabParallelogram(false);
				base.MinWidth = 150.0;
				this.mTabLabel.Margin = new Thickness(3.0, 1.0, 3.0, 1.0);
				if (!this.IsSelected)
				{
					this.mBorder.Background = Brushes.Transparent;
				}
				this.mBorder.BorderThickness = new Thickness(0.0);
				return;
			}
			this.IsButtonInDropDown = false;
			this.mBorder.BorderThickness = new Thickness(1.0);
			base.MinWidth = 0.0;
			this.mTabLabel.Margin = new Thickness(3.0, 1.0, 24.0, 1.0);
			if (this.IsSelected)
			{
				BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "SelectedTabBackgroundColor");
				BlueStacksUIBinding.BindColor(this.mBorder, Border.BorderBrushProperty, "SelectedTabBorderColor");
				return;
			}
			BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundColor");
			BlueStacksUIBinding.BindColor(this.mBorder, Border.BorderBrushProperty, "AppTabBorderBrush");
		}

		// Token: 0x0600029F RID: 671 RVA: 0x00014D44 File Offset: 0x00012F44
		internal void LaunchApp()
		{
			if (!string.IsNullOrEmpty(this.PackageName) && this.mTabType == TabType.AppTab)
			{
				this.ParentWindow.mAppHandler.SendRunAppRequestAsync(this.PackageName, this.mActivityName, false);
				return;
			}
			if ((this.mTabType == TabType.HomeTab || this.mTabType == TabType.WebTab) && RegistryManager.Instance.SwitchToAndroidHome)
			{
				this.ParentWindow.mAppHandler.GoHome();
			}
		}

		// Token: 0x060002A0 RID: 672 RVA: 0x00014DB4 File Offset: 0x00012FB4
		private void Button_MouseEnter(object sender, MouseEventArgs e)
		{
			if (!this.IsSelected)
			{
				BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundHoverColor");
			}
			if (this.IsButtonInDropDown)
			{
				if (this.mTabType != TabType.HomeTab)
				{
					this.CloseTabButtonDropDown.Visibility = Visibility.Visible;
				}
			}
			else if (this.mTabType != TabType.HomeTab && !this.mIsMoreTabsButton)
			{
				this.CloseTabButtonLandScape.Visibility = Visibility.Visible;
				if (!this.mIsTabsSkewed)
				{
					this.CloseTabButtonPortrait.Visibility = Visibility.Visible;
				}
			}
			if (this.IsMoreTabsButton)
			{
				this.mAppTabIcon.SetHoverImage();
				BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundHoverColor");
			}
		}

		// Token: 0x060002A1 RID: 673 RVA: 0x00014E58 File Offset: 0x00013058
		private void Button_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.IsSelected)
			{
				BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundColor");
			}
			if (this.IsMoreTabsButton)
			{
				this.mAppTabIcon.SetDefaultImage();
				BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundColor");
			}
			this.CloseTabButtonLandScape.Visibility = Visibility.Hidden;
			this.CloseTabButtonPortrait.Visibility = Visibility.Hidden;
			this.CloseTabButtonDropDown.Visibility = Visibility.Hidden;
		}

		// Token: 0x060002A2 RID: 674 RVA: 0x00014ED0 File Offset: 0x000130D0
		private void Button_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (!this.IsButtonInDropDown)
			{
				if (this.IsMoreTabsButton)
				{
					this.mAppTabIcon.SetClickedImage();
					BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "SelectedTabBackgroundColor");
					return;
				}
				if (!this.IsSelected)
				{
					BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundColor");
					BlueStacksUIBinding.BindColor(this.mBorder, Border.BorderBrushProperty, "AppTabBorderBrush");
				}
			}
		}

		// Token: 0x060002A3 RID: 675 RVA: 0x00014F40 File Offset: 0x00013140
		private void Button_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			if (!this.IsButtonInDropDown)
			{
				if (!this.IsSelected)
				{
					BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundColor");
				}
				if (this.mIsMoreTabsButton)
				{
					if (base.IsMouseOver)
					{
						this.mAppTabIcon.SetHoverImage();
						BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundHoverColor");
						return;
					}
					this.mAppTabIcon.SetDefaultImage();
					BlueStacksUIBinding.BindColor(this.mBorder, Panel.BackgroundProperty, "TabBackgroundColor");
				}
			}
		}

		// Token: 0x060002A4 RID: 676 RVA: 0x00003CC5 File Offset: 0x00001EC5
		private void Button_IsEnabledChanged(object _1, DependencyPropertyChangedEventArgs _2)
		{
			if (base.IsEnabled)
			{
				base.Opacity = 1.0;
				return;
			}
			base.Opacity = 0.3;
		}

		// Token: 0x060002A5 RID: 677 RVA: 0x00014FC4 File Offset: 0x000131C4
		internal BrowserControl GetBrowserControl()
		{
			BrowserControl result;
			try
			{
				result = (this.mControlGrid.Children[0] as BrowserControl);
			}
			catch (Exception ex)
			{
				Logger.Warning("No BrowserControl associated with tabkey: " + this.TabKey + " Error: " + ex.ToString());
				result = null;
			}
			return result;
		}

		// Token: 0x060002A6 RID: 678 RVA: 0x00003CEE File Offset: 0x00001EEE
		internal void EnableKeymapForDMM(bool enable)
		{
			this.mIsDMMKeyMapEnabled = enable;
		}

		// Token: 0x060002A7 RID: 679 RVA: 0x00015020 File Offset: 0x00013220
		internal void MoreTabsButtonHandling()
		{
			AppTabButton mMoreTabButton = this.ParentWindow.mTopBar.mAppTabButtons.mMoreTabButton;
			mMoreTabButton.mTabLabel.Visibility = Visibility.Collapsed;
			mMoreTabButton.mDownArrowGrid.Visibility = Visibility.Visible;
			if (this.ParentWindow.mTopBar.mAppTabButtons.mHiddenButtons.Children.Contains(this.ParentWindow.StaticComponents.mSelectedTabButton))
			{
				mMoreTabButton.mAppTabIcon.ImageName = this.ParentWindow.StaticComponents.mSelectedTabButton.mAppTabIcon.ImageName;
				return;
			}
			mMoreTabButton.mAppTabIcon.ImageName = (this.ParentWindow.mTopBar.mAppTabButtons.mHiddenButtons.Children[0] as AppTabButton).mAppTabIcon.ImageName;
		}

		// Token: 0x04000155 RID: 341
		private MainWindow mMainWindow;

		// Token: 0x04000156 RID: 342
		internal const int IconModeMinWidth = 38;

		// Token: 0x04000157 RID: 343
		internal const int ParallelogramModeMinWidth = 48;

		// Token: 0x04000158 RID: 344
		private bool mIsPortraitModeTab;

		// Token: 0x04000159 RID: 345
		internal TabType mTabType;

		// Token: 0x0400015B RID: 347
		internal bool mRestartPubgTab;

		// Token: 0x0400015C RID: 348
		internal bool mRestartCODTab;

		// Token: 0x0400015D RID: 349
		internal bool mIsKeyMappingTipDisplayed;

		// Token: 0x0400015E RID: 350
		internal bool mIsOverlayTooltipDisplayed;

		// Token: 0x0400015F RID: 351
		internal bool mIsShootingModeToastDisplayed;

		// Token: 0x04000160 RID: 352
		internal bool mGuidanceWindowOpen;

		// Token: 0x04000161 RID: 353
		internal bool mIsAnyOperationPendingForTab;

		// Token: 0x04000162 RID: 354
		internal bool mIsSwitchedBackFromHomeTab;

		// Token: 0x04000165 RID: 357
		private bool mIsMoreTabsButton;

		// Token: 0x0400016C RID: 364
		private bool mIsDMMKeyMapEnabled;

		// Token: 0x0400016F RID: 367
		private string mActivityName = string.Empty;

		// Token: 0x04000170 RID: 368
		private bool mIsTabsSkewed = true;
	}
}
