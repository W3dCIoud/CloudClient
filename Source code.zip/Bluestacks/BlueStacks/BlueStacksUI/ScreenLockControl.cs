﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000B0 RID: 176
	public class ScreenLockControl : UserControl, IDimOverlayControl, IComponentConnector
	{
		// Token: 0x060006F8 RID: 1784 RVA: 0x000067FE File Offset: 0x000049FE
		public ScreenLockControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x170001BE RID: 446
		// (get) Token: 0x060006F9 RID: 1785 RVA: 0x00006230 File Offset: 0x00004430
		// (set) Token: 0x060006FA RID: 1786 RVA: 0x00005D29 File Offset: 0x00003F29
		bool IDimOverlayControl.IsCloseOnOverLayClick
		{
			get
			{
				return false;
			}
			set
			{
			}
		}

		// Token: 0x170001BF RID: 447
		// (get) Token: 0x060006FB RID: 1787 RVA: 0x0000680C File Offset: 0x00004A0C
		// (set) Token: 0x060006FC RID: 1788 RVA: 0x00006814 File Offset: 0x00004A14
		public bool ShowControlInSeparateWindow { get; set; }

		// Token: 0x060006FD RID: 1789 RVA: 0x0000681D File Offset: 0x00004A1D
		public bool Close()
		{
			base.Visibility = Visibility.Hidden;
			return true;
		}

		// Token: 0x060006FE RID: 1790 RVA: 0x0000624E File Offset: 0x0000444E
		public bool Show()
		{
			base.Visibility = Visibility.Visible;
			return true;
		}

		// Token: 0x060006FF RID: 1791 RVA: 0x00029B70 File Offset: 0x00027D70
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/screenlockcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000700 RID: 1792 RVA: 0x00006827 File Offset: 0x00004A27
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mScreenLockImage = (CustomPictureBox)target;
				return;
			}
			if (connectionId != 2)
			{
				this._contentLoaded = true;
				return;
			}
			this.mScreenLockText = (TextBlock)target;
		}

		// Token: 0x0400040C RID: 1036
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mScreenLockImage;

		// Token: 0x0400040D RID: 1037
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mScreenLockText;

		// Token: 0x0400040E RID: 1038
		private bool _contentLoaded;
	}
}
