﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;
using Xilium.CefGlue.WPF;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200014B RID: 331
	public partial class DMMRecommendedWindow : CustomWindow
	{
		// Token: 0x06000CE0 RID: 3296 RVA: 0x00054D8C File Offset: 0x00052F8C
		public DMMRecommendedWindow(MainWindow window)
		{
			this.InitializeComponent();
			base.IsShowGLWindow = true;
			this.ParentWindow = window;
			base.Owner = this.ParentWindow;
			base.Topmost = false;
			base.Left = ((this.ParentWindow != null) ? this.ParentWindow.Left : 0.0) + ((this.ParentWindow != null) ? this.ParentWindow.ActualWidth : 0.0);
			base.Top = ((this.ParentWindow != null) ? this.ParentWindow.Top : 0.0);
			base.Height = ((this.ParentWindow != null) ? this.ParentWindow.Height : 0.0);
			base.Width = (base.Height - (double)(((this.ParentWindow != null) ? this.ParentWindow.ParentWindowHeightDiff : 0) * 9)) / 16.0 + (double)((this.ParentWindow != null) ? this.ParentWindow.ParentWindowWidthDiff : 0);
			base.Closing += this.RecommendedWindow_Closing;
			base.IsVisibleChanged += this.RecommendedWindow_IsVisibleChanged;
		}

		// Token: 0x06000CE1 RID: 3297 RVA: 0x00054EC0 File Offset: 0x000530C0
		private void RecommendedWindow_IsVisibleChanged(object _1, DependencyPropertyChangedEventArgs _2)
		{
			if (base.Visibility == Visibility.Visible)
			{
				this.ParentWindow.mDmmBottomBar.mRecommendedWindowBtn.ImageName = "recommend_click";
			}
			else
			{
				this.ParentWindow.mDmmBottomBar.mRecommendedWindowBtn.ImageName = "recommend";
			}
			this.UpdateSize();
		}

		// Token: 0x06000CE2 RID: 3298 RVA: 0x00009CE6 File Offset: 0x00007EE6
		private void RecommendedWindow_Closing(object sender, CancelEventArgs e)
		{
			this.ParentWindow.mDMMRecommendedWindow.mRecommendedBrowserControl.DisposeBrowser();
			this.ParentWindow.mDMMRecommendedWindow = null;
		}

		// Token: 0x06000CE3 RID: 3299 RVA: 0x00054F14 File Offset: 0x00053114
		public void Init(string url)
		{
			this.mRecommendedBrowserControl.mUrl = url;
			this.mRecommendedBrowserControl.mGrid = new Grid();
			this.mRecommendedBrowserControl.Content = this.mRecommendedBrowserControl.mGrid;
			this.mRecommendedBrowserControl.CreateNewBrowser();
			this.mRecommendedBrowserControl.ProcessMessageRecieved += this.MRecommendedBrowserControl_ProcessMessageRecieved;
		}

		// Token: 0x06000CE4 RID: 3300 RVA: 0x00054F78 File Offset: 0x00053178
		public void UpdateSize()
		{
			base.Top = this.ParentWindow.Top;
			base.Left = this.ParentWindow.Left + this.ParentWindow.Width;
			base.Height = this.ParentWindow.Height;
			base.Width = (this.ParentWindow.Height - (double)this.ParentWindow.ParentWindowHeightDiff) * 9.0 / 16.0 + (double)this.ParentWindow.ParentWindowWidthDiff;
		}

		// Token: 0x06000CE5 RID: 3301 RVA: 0x00009D09 File Offset: 0x00007F09
		public void UpdateLocation()
		{
			base.Top = this.ParentWindow.Top;
			base.Left = this.ParentWindow.Left + this.ParentWindow.Width;
		}

		// Token: 0x06000CE6 RID: 3302 RVA: 0x00005D29 File Offset: 0x00003F29
		private void MRecommendedBrowserControl_ProcessMessageRecieved(object sender, ProcessMessageEventArgs e)
		{
		}

		// Token: 0x06000CE7 RID: 3303 RVA: 0x00055004 File Offset: 0x00053204
		private void mCloseBtn_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mIsDMMRecommendedWindowOpen = false;
			base.Hide();
			InteropWindow.ShowWindow(this.ParentWindow.Handle, 9);
			if (!this.ParentWindow.Topmost)
			{
				this.ParentWindow.Topmost = true;
				this.ParentWindow.Topmost = false;
			}
		}

		// Token: 0x040008D9 RID: 2265
		private MainWindow ParentWindow;
	}
}
