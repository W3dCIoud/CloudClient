﻿using System;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000197 RID: 407
	internal class MainWindowsStaticComponents
	{
		// Token: 0x14000014 RID: 20
		// (add) Token: 0x06000FBD RID: 4029 RVA: 0x00065324 File Offset: 0x00063524
		// (remove) Token: 0x06000FBE RID: 4030 RVA: 0x0006535C File Offset: 0x0006355C
		internal event EventHandler ShowAllUninstallButtons;

		// Token: 0x14000015 RID: 21
		// (add) Token: 0x06000FBF RID: 4031 RVA: 0x00065394 File Offset: 0x00063594
		// (remove) Token: 0x06000FC0 RID: 4032 RVA: 0x000653CC File Offset: 0x000635CC
		internal event EventHandler HideAllUninstallButtons;

		// Token: 0x06000FC1 RID: 4033 RVA: 0x0000B6EE File Offset: 0x000098EE
		internal void ShowUninstallButtons(bool isShow)
		{
			this.IsDeleteButtonVisible = isShow;
			if (isShow)
			{
				EventHandler showAllUninstallButtons = this.ShowAllUninstallButtons;
				if (showAllUninstallButtons == null)
				{
					return;
				}
				showAllUninstallButtons(null, new EventArgs());
				return;
			}
			else
			{
				EventHandler hideAllUninstallButtons = this.HideAllUninstallButtons;
				if (hideAllUninstallButtons == null)
				{
					return;
				}
				hideAllUninstallButtons(null, new EventArgs());
				return;
			}
		}

		// Token: 0x04000AB5 RID: 2741
		internal AppTabButton mSelectedTabButton;

		// Token: 0x04000AB6 RID: 2742
		internal bool mPreviousSelectedTabWeb;

		// Token: 0x04000AB7 RID: 2743
		internal HomeAppTabButton mSelectedHomeAppTabButton;

		// Token: 0x04000AB8 RID: 2744
		internal bool IsDeleteButtonVisible;

		// Token: 0x04000AB9 RID: 2745
		internal IntPtr mLastMappableWindowHandle = IntPtr.Zero;
	}
}
