﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000BE RID: 190
	public class MacroBookmarksPopup : UserControl, IComponentConnector
	{
		// Token: 0x170001C6 RID: 454
		// (get) Token: 0x060007D7 RID: 2007 RVA: 0x0000706F File Offset: 0x0000526F
		// (set) Token: 0x060007D8 RID: 2008 RVA: 0x00007077 File Offset: 0x00005277
		private MainWindow ParentWindow { get; set; }

		// Token: 0x060007D9 RID: 2009 RVA: 0x00007080 File Offset: 0x00005280
		public MacroBookmarksPopup()
		{
			this.InitializeComponent();
			this.InitList();
		}

		// Token: 0x060007DA RID: 2010 RVA: 0x0002E854 File Offset: 0x0002CA54
		public void SetParentWindowAndBindEvents(MainWindow window)
		{
			this.ParentWindow = window;
			if (this.ParentWindow != null)
			{
				this.ParentWindow.mCommonHandler.MacroBookmarkChangedEvent += this.ParentWindow_MacroBookmarkChanged;
				this.ParentWindow.mCommonHandler.MacroSettingChangedEvent += this.ParentWindow_MacroSettingChangedEvent;
				this.ParentWindow.mCommonHandler.MacroDeletedEvent += this.ParentWindow_MacroDeletedEvent;
			}
		}

		// Token: 0x060007DB RID: 2011 RVA: 0x0002E8C4 File Offset: 0x0002CAC4
		private void ParentWindow_MacroDeletedEvent(string fileName)
		{
			Grid gridByTag = this.GetGridByTag(fileName);
			if (gridByTag != null)
			{
				this.mMainStackPanel.Children.Remove(gridByTag);
			}
		}

		// Token: 0x060007DC RID: 2012 RVA: 0x0002E8F0 File Offset: 0x0002CAF0
		private void ParentWindow_MacroSettingChangedEvent(MacroRecording record)
		{
			try
			{
				this.mMainStackPanel.Children.Clear();
				this.InitList();
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't update name: {0}", new object[]
				{
					ex.Message
				});
			}
		}

		// Token: 0x060007DD RID: 2013 RVA: 0x0002E944 File Offset: 0x0002CB44
		private void ParentWindow_MacroBookmarkChanged(string fileName, bool wasBookmarked)
		{
			if (wasBookmarked)
			{
				this.mMainStackPanel.Children.Add(this.CreateGrid(fileName));
				return;
			}
			foreach (object obj in this.mMainStackPanel.Children)
			{
				Grid grid = (Grid)obj;
				if ((string)grid.Tag == fileName)
				{
					this.mMainStackPanel.Children.Remove(grid);
					break;
				}
			}
		}

		// Token: 0x060007DE RID: 2014 RVA: 0x0002E9E0 File Offset: 0x0002CBE0
		private Grid GetGridByTag(string tag)
		{
			foreach (object obj in this.mMainStackPanel.Children)
			{
				Grid grid = (Grid)obj;
				if ((string)grid.Tag == tag)
				{
					return grid;
				}
			}
			return null;
		}

		// Token: 0x060007DF RID: 2015 RVA: 0x0002EA54 File Offset: 0x0002CC54
		private void InitList()
		{
			foreach (string text in RegistryManager.Instance.BookmarkedScriptList)
			{
				if (!string.IsNullOrEmpty(text))
				{
					Grid element = this.CreateGrid(text);
					this.mMainStackPanel.Children.Add(element);
				}
			}
		}

		// Token: 0x060007E0 RID: 2016 RVA: 0x00005D29 File Offset: 0x00003F29
		private void MMacroBookmarksPopup_Loaded(object sender, RoutedEventArgs e)
		{
		}

		// Token: 0x060007E1 RID: 2017 RVA: 0x0002EAA0 File Offset: 0x0002CCA0
		private Grid CreateGrid(string fileName)
		{
			Grid grid = new Grid();
			grid.MouseEnter += this.GridElement_MouseEnter;
			grid.MouseLeave += this.GridElement_MouseLeave;
			grid.MouseLeftButtonUp += this.GridElement_MouseLeftButtonUp;
			grid.Background = Brushes.Transparent;
			grid.Tag = fileName;
			TextBlock textBlock = new TextBlock
			{
				FontSize = 12.0,
				TextTrimming = TextTrimming.CharacterEllipsis,
				Margin = new Thickness(10.0, 5.0, 10.0, 5.0)
			};
			BlueStacksUIBinding.BindColor(textBlock, TextBlock.ForegroundProperty, "GuidanceTextColorForeground");
			string path = Path.Combine(RegistryStrings.MacroRecordingsFolderPath, fileName);
			if (File.Exists(path))
			{
				try
				{
					MacroRecording macroRecording = JsonConvert.DeserializeObject<MacroRecording>(File.ReadAllText(path), Utils.GetSerializerSettings());
					textBlock.Text = macroRecording.Name;
					textBlock.ToolTip = macroRecording.Name;
					goto IL_F9;
				}
				catch
				{
					goto IL_F9;
				}
			}
			textBlock.Text = fileName;
			textBlock.ToolTip = fileName;
			IL_F9:
			grid.Children.Add(textBlock);
			return grid;
		}

		// Token: 0x060007E2 RID: 2018 RVA: 0x0002EBC4 File Offset: 0x0002CDC4
		private void GridElement_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow.mIsMacroRecorderActive)
			{
				return;
			}
			string macroFileName = (string)(sender as Grid).Tag;
			MacroRecording macroRecording = (from MacroRecording macro in MacroGraph.Instance.Vertices
			where string.Equals(macro.Name, macroFileName, StringComparison.InvariantCultureIgnoreCase)
			select macro).FirstOrDefault<MacroRecording>();
			if (macroRecording == null)
			{
				this.mMainStackPanel.Children.Remove(sender as Grid);
				return;
			}
			try
			{
				if (!this.ParentWindow.mIsMacroPlaying)
				{
					this.ParentWindow.mCommonHandler.FullMacroScriptPlayHandler(macroRecording);
					ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_play", "bookmark", macroRecording.RecordingType.ToString(), string.IsNullOrEmpty(macroRecording.MacroId) ? "local" : "community", null, null);
				}
				else
				{
					CustomMessageWindow customMessageWindow = new CustomMessageWindow();
					BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_CANNOT_RUN_MACRO", "");
					BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_STOP_MACRO_SCRIPT", "");
					customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
					customMessageWindow.Owner = this.ParentWindow;
					customMessageWindow.ShowDialog();
				}
				if (this.ParentWindow.mSidebar != null)
				{
					this.ParentWindow.mSidebar.mMacroButtonPopup.IsOpen = false;
					this.ParentWindow.mSidebar.ToggleSidebarVisibilityInFullscreen(false);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
		}

		// Token: 0x060007E3 RID: 2019 RVA: 0x00006C7E File Offset: 0x00004E7E
		private void GridElement_MouseEnter(object sender, MouseEventArgs e)
		{
			BlueStacksUIBinding.BindColor(sender as Grid, Panel.BackgroundProperty, "ContextMenuItemBackgroundHoverColor");
		}

		// Token: 0x060007E4 RID: 2020 RVA: 0x00005A31 File Offset: 0x00003C31
		private void GridElement_MouseLeave(object sender, MouseEventArgs e)
		{
			(sender as Grid).Background = Brushes.Transparent;
		}

		// Token: 0x060007E5 RID: 2021 RVA: 0x0002ED58 File Offset: 0x0002CF58
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/macrobookmarkspopup.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060007E6 RID: 2022 RVA: 0x0002ED88 File Offset: 0x0002CF88
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMacroBookmarksPopup = (MacroBookmarksPopup)target;
				this.mMacroBookmarksPopup.Loaded += this.MMacroBookmarksPopup_Loaded;
				return;
			case 2:
				this.mGrid = (Grid)target;
				return;
			case 3:
				this.mMainStackPanel = (StackPanel)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040004A2 RID: 1186
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal MacroBookmarksPopup mMacroBookmarksPopup;

		// Token: 0x040004A3 RID: 1187
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mGrid;

		// Token: 0x040004A4 RID: 1188
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mMainStackPanel;

		// Token: 0x040004A5 RID: 1189
		private bool _contentLoaded;
	}
}
