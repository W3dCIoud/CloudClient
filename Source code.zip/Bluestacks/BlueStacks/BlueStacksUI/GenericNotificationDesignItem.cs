﻿using System;
using System.Collections.Generic;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000078 RID: 120
	public class GenericNotificationDesignItem
	{
		// Token: 0x17000187 RID: 391
		// (get) Token: 0x060004E7 RID: 1255 RVA: 0x00005458 File Offset: 0x00003658
		// (set) Token: 0x060004E8 RID: 1256 RVA: 0x00005460 File Offset: 0x00003660
		public double AutoHideTime { get; set; } = 3500.0;

		// Token: 0x17000188 RID: 392
		// (get) Token: 0x060004E9 RID: 1257 RVA: 0x00005469 File Offset: 0x00003669
		// (set) Token: 0x060004EA RID: 1258 RVA: 0x00005471 File Offset: 0x00003671
		public string LeftGifName { get; set; }

		// Token: 0x17000189 RID: 393
		// (get) Token: 0x060004EB RID: 1259 RVA: 0x0000547A File Offset: 0x0000367A
		// (set) Token: 0x060004EC RID: 1260 RVA: 0x00005482 File Offset: 0x00003682
		public string LeftGifUrl { get; set; }

		// Token: 0x1700018A RID: 394
		// (get) Token: 0x060004ED RID: 1261 RVA: 0x0000548B File Offset: 0x0000368B
		// (set) Token: 0x060004EE RID: 1262 RVA: 0x00005493 File Offset: 0x00003693
		public string TitleForeGroundColor { get; set; }

		// Token: 0x1700018B RID: 395
		// (get) Token: 0x060004EF RID: 1263 RVA: 0x0000549C File Offset: 0x0000369C
		// (set) Token: 0x060004F0 RID: 1264 RVA: 0x000054A4 File Offset: 0x000036A4
		public string MessageForeGroundColor { get; set; }

		// Token: 0x1700018C RID: 396
		// (get) Token: 0x060004F1 RID: 1265 RVA: 0x000054AD File Offset: 0x000036AD
		// (set) Token: 0x060004F2 RID: 1266 RVA: 0x000054B5 File Offset: 0x000036B5
		public string BorderColor { get; set; }

		// Token: 0x1700018D RID: 397
		// (get) Token: 0x060004F3 RID: 1267 RVA: 0x000054BE File Offset: 0x000036BE
		// (set) Token: 0x060004F4 RID: 1268 RVA: 0x000054C6 File Offset: 0x000036C6
		public string Ribboncolor { get; set; }

		// Token: 0x1700018E RID: 398
		// (get) Token: 0x060004F5 RID: 1269 RVA: 0x000054CF File Offset: 0x000036CF
		// (set) Token: 0x060004F6 RID: 1270 RVA: 0x000054D7 File Offset: 0x000036D7
		public string HoverBorderColor { get; set; }

		// Token: 0x1700018F RID: 399
		// (get) Token: 0x060004F7 RID: 1271 RVA: 0x000054E0 File Offset: 0x000036E0
		// (set) Token: 0x060004F8 RID: 1272 RVA: 0x000054E8 File Offset: 0x000036E8
		public string HoverRibboncolor { get; set; }

		// Token: 0x17000190 RID: 400
		// (get) Token: 0x060004F9 RID: 1273 RVA: 0x000054F1 File Offset: 0x000036F1
		public List<SerializableKeyValuePair<string, double>> BackgroundGradient { get; } = new List<SerializableKeyValuePair<string, double>>();

		// Token: 0x17000191 RID: 401
		// (get) Token: 0x060004FA RID: 1274 RVA: 0x000054F9 File Offset: 0x000036F9
		public List<SerializableKeyValuePair<string, double>> HoverBackGroundGradient { get; } = new List<SerializableKeyValuePair<string, double>>();
	}
}
