﻿using System;
using System.Globalization;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200019A RID: 410
	public class Fraction
	{
		// Token: 0x06000FCB RID: 4043 RVA: 0x0000B7C2 File Offset: 0x000099C2
		public Fraction()
		{
			this.Initialize(0L, 1L);
		}

		// Token: 0x06000FCC RID: 4044 RVA: 0x0000B7D4 File Offset: 0x000099D4
		public Fraction(long iWholeNumber)
		{
			this.Initialize(iWholeNumber, 1L);
		}

		// Token: 0x06000FCD RID: 4045 RVA: 0x00065878 File Offset: 0x00063A78
		public Fraction(double dDecimalValue)
		{
			Fraction fraction = Fraction.ToFraction(dDecimalValue);
			this.Initialize(fraction.Numerator, fraction.Denominator);
		}

		// Token: 0x06000FCE RID: 4046 RVA: 0x000658A4 File Offset: 0x00063AA4
		public Fraction(string strValue)
		{
			Fraction fraction = Fraction.ToFraction(strValue);
			this.Initialize(fraction.Numerator, fraction.Denominator);
		}

		// Token: 0x06000FCF RID: 4047 RVA: 0x0000B7E5 File Offset: 0x000099E5
		public Fraction(long iNumerator, long iDenominator)
		{
			this.Initialize(iNumerator, iDenominator);
		}

		// Token: 0x06000FD0 RID: 4048 RVA: 0x0000B7F5 File Offset: 0x000099F5
		private void Initialize(long iNumerator, long iDenominator)
		{
			this.Numerator = iNumerator;
			this.Denominator = iDenominator;
			Fraction.ReduceFraction(this);
		}

		// Token: 0x1700027E RID: 638
		// (get) Token: 0x06000FD1 RID: 4049 RVA: 0x0000B80B File Offset: 0x00009A0B
		// (set) Token: 0x06000FD2 RID: 4050 RVA: 0x0000B813 File Offset: 0x00009A13
		public long Denominator
		{
			get
			{
				return this.m_iDenominator;
			}
			set
			{
				if (value != 0L)
				{
					this.m_iDenominator = value;
					this.CalculateDoubleValue();
					return;
				}
				throw new FractionException("Denominator cannot be assigned a ZERO Value");
			}
		}

		// Token: 0x1700027F RID: 639
		// (get) Token: 0x06000FD3 RID: 4051 RVA: 0x0000B830 File Offset: 0x00009A30
		// (set) Token: 0x06000FD4 RID: 4052 RVA: 0x0000B838 File Offset: 0x00009A38
		public long Numerator
		{
			get
			{
				return this.m_iNumerator;
			}
			set
			{
				this.m_iNumerator = value;
				this.CalculateDoubleValue();
			}
		}

		// Token: 0x17000280 RID: 640
		// (get) Token: 0x06000FD5 RID: 4053 RVA: 0x0000B847 File Offset: 0x00009A47
		// (set) Token: 0x06000FD6 RID: 4054 RVA: 0x0000B84F File Offset: 0x00009A4F
		public double DoubleValue
		{
			get
			{
				return this.m_iDoubleValue;
			}
			set
			{
				this.m_iDoubleValue = value;
			}
		}

		// Token: 0x06000FD7 RID: 4055 RVA: 0x0000B858 File Offset: 0x00009A58
		private void CalculateDoubleValue()
		{
			this.m_iDoubleValue = (double)this.m_iNumerator / (double)this.m_iDenominator;
		}

		// Token: 0x06000FD8 RID: 4056 RVA: 0x0000B86F File Offset: 0x00009A6F
		public double ToDouble()
		{
			return (double)this.Numerator / (double)this.Denominator;
		}

		// Token: 0x06000FD9 RID: 4057 RVA: 0x000658D0 File Offset: 0x00063AD0
		public override string ToString()
		{
			string result;
			if (this.Denominator == 1L)
			{
				result = this.Numerator.ToString(CultureInfo.InvariantCulture);
			}
			else
			{
				result = this.Numerator.ToString() + "/" + this.Denominator.ToString();
			}
			return result;
		}

		// Token: 0x06000FDA RID: 4058 RVA: 0x00065928 File Offset: 0x00063B28
		public static Fraction ToFraction(string strValue)
		{
			if (string.IsNullOrEmpty(strValue))
			{
				return null;
			}
			int num = 0;
			while (num < strValue.Length && strValue[num] != '/')
			{
				num++;
			}
			if (num == strValue.Length)
			{
				return Convert.ToDouble(strValue, CultureInfo.InvariantCulture);
			}
			long iNumerator = Convert.ToInt64(strValue.Substring(0, num), CultureInfo.InvariantCulture);
			long iDenominator = Convert.ToInt64(strValue.Substring(num + 1), CultureInfo.InvariantCulture);
			return new Fraction(iNumerator, iDenominator);
		}

		// Token: 0x06000FDB RID: 4059 RVA: 0x000659A4 File Offset: 0x00063BA4
		public static Fraction ToFraction(double dValue)
		{
			checked
			{
				Fraction result;
				try
				{
					Fraction fraction;
					if (dValue % 1.0 == 0.0)
					{
						fraction = new Fraction((long)dValue);
					}
					else
					{
						double num = dValue;
						long num2 = 1L;
						string text = dValue.ToString(CultureInfo.InvariantCulture);
						while (text.IndexOf("E", StringComparison.InvariantCulture) > 0)
						{
							unchecked
							{
								num *= 10.0;
							}
							num2 *= 10L;
							text = num.ToString(CultureInfo.InvariantCulture);
						}
						int num3 = 0;
						while (text[num3] != '.')
						{
							num3++;
						}
						for (int i = text.Length - num3 - 1; i > 0; i--)
						{
							unchecked
							{
								num *= 10.0;
							}
							num2 *= 10L;
						}
						fraction = new Fraction(unchecked((long)(checked((int)Math.Round(num)))), num2);
					}
					result = fraction;
				}
				catch (OverflowException)
				{
					throw new FractionException("Conversion not possible due to overflow");
				}
				catch (Exception)
				{
					throw new FractionException("Conversion not possible");
				}
				return result;
			}
		}

		// Token: 0x06000FDC RID: 4060 RVA: 0x0000B880 File Offset: 0x00009A80
		public Fraction Duplicate()
		{
			return new Fraction
			{
				Numerator = this.Numerator,
				Denominator = this.Denominator
			};
		}

		// Token: 0x06000FDD RID: 4061 RVA: 0x00065AA4 File Offset: 0x00063CA4
		public static Fraction Inverse(Fraction frac1)
		{
			if (null == frac1 || frac1.Numerator == 0L)
			{
				throw new FractionException("Operation not possible (Denominator cannot be assigned a ZERO Value)");
			}
			long denominator = frac1.Denominator;
			long numerator = frac1.Numerator;
			return new Fraction(denominator, numerator);
		}

		// Token: 0x06000FDE RID: 4062 RVA: 0x0000B89F File Offset: 0x00009A9F
		public static Fraction operator -(Fraction frac1)
		{
			if (!(null != frac1))
			{
				return null;
			}
			return Fraction.Negate(frac1);
		}

		// Token: 0x06000FDF RID: 4063 RVA: 0x0000B8B2 File Offset: 0x00009AB2
		public static Fraction operator +(Fraction frac1, Fraction frac2)
		{
			if (!(null != frac1) || !(null != frac2))
			{
				return null;
			}
			return Fraction.Add(frac1, frac2);
		}

		// Token: 0x06000FE0 RID: 4064 RVA: 0x0000B8CF File Offset: 0x00009ACF
		public static Fraction operator +(int iNo, Fraction frac1)
		{
			if (!(null != frac1))
			{
				return null;
			}
			return Fraction.Add(frac1, new Fraction((long)iNo));
		}

		// Token: 0x06000FE1 RID: 4065 RVA: 0x0000B8E9 File Offset: 0x00009AE9
		public static Fraction operator +(Fraction frac1, int iNo)
		{
			if (!(null != frac1))
			{
				return null;
			}
			return Fraction.Add(frac1, new Fraction((long)iNo));
		}

		// Token: 0x06000FE2 RID: 4066 RVA: 0x0000B903 File Offset: 0x00009B03
		public static Fraction operator +(double dbl, Fraction frac1)
		{
			if (!(null != frac1))
			{
				return null;
			}
			return Fraction.Add(frac1, Fraction.ToFraction(dbl));
		}

		// Token: 0x06000FE3 RID: 4067 RVA: 0x0000B91C File Offset: 0x00009B1C
		public static Fraction operator +(Fraction frac1, double dbl)
		{
			if (!(null != frac1))
			{
				return null;
			}
			return Fraction.Add(frac1, Fraction.ToFraction(dbl));
		}

		// Token: 0x06000FE4 RID: 4068 RVA: 0x0000B935 File Offset: 0x00009B35
		public static Fraction operator -(Fraction frac1, Fraction frac2)
		{
			if (!(null != frac1) || !(null != frac2))
			{
				return null;
			}
			return Fraction.Add(frac1, -frac2);
		}

		// Token: 0x06000FE5 RID: 4069 RVA: 0x0000B957 File Offset: 0x00009B57
		public static Fraction operator -(int iNo, Fraction frac1)
		{
			if (!(null != frac1))
			{
				return null;
			}
			return Fraction.Add(-frac1, new Fraction((long)iNo));
		}

		// Token: 0x06000FE6 RID: 4070 RVA: 0x0000B976 File Offset: 0x00009B76
		public static Fraction operator -(Fraction frac1, int iNo)
		{
			if (!(null != frac1))
			{
				return null;
			}
			return Fraction.Add(frac1, -new Fraction((long)iNo));
		}

		// Token: 0x06000FE7 RID: 4071 RVA: 0x0000B995 File Offset: 0x00009B95
		public static Fraction operator -(double dbl, Fraction frac1)
		{
			if (!(null != frac1))
			{
				return null;
			}
			return Fraction.Add(-frac1, Fraction.ToFraction(dbl));
		}

		// Token: 0x06000FE8 RID: 4072 RVA: 0x0000B9B3 File Offset: 0x00009BB3
		public static Fraction operator -(Fraction frac1, double dbl)
		{
			if (!(null != frac1))
			{
				return null;
			}
			return Fraction.Add(frac1, -Fraction.ToFraction(dbl));
		}

		// Token: 0x06000FE9 RID: 4073 RVA: 0x0000B9D1 File Offset: 0x00009BD1
		public static Fraction operator *(Fraction frac1, Fraction frac2)
		{
			if (!(null != frac1) || !(null != frac2))
			{
				return null;
			}
			return Fraction.Multiply(frac1, frac2);
		}

		// Token: 0x06000FEA RID: 4074 RVA: 0x0000B9EE File Offset: 0x00009BEE
		public static Fraction operator *(int iNo, Fraction frac1)
		{
			if (!(null != frac1))
			{
				return null;
			}
			return Fraction.Multiply(frac1, new Fraction((long)iNo));
		}

		// Token: 0x06000FEB RID: 4075 RVA: 0x0000BA08 File Offset: 0x00009C08
		public static Fraction operator *(Fraction frac1, int iNo)
		{
			if (!(null != frac1))
			{
				return null;
			}
			return Fraction.Multiply(frac1, new Fraction((long)iNo));
		}

		// Token: 0x06000FEC RID: 4076 RVA: 0x0000BA22 File Offset: 0x00009C22
		public static Fraction operator *(double dbl, Fraction frac1)
		{
			if (!(null != frac1))
			{
				return null;
			}
			return Fraction.Multiply(frac1, Fraction.ToFraction(dbl));
		}

		// Token: 0x06000FED RID: 4077 RVA: 0x0000BA3B File Offset: 0x00009C3B
		public static Fraction operator *(Fraction frac1, double dbl)
		{
			if (!(null != frac1))
			{
				return null;
			}
			return Fraction.Multiply(frac1, Fraction.ToFraction(dbl));
		}

		// Token: 0x06000FEE RID: 4078 RVA: 0x0000BA54 File Offset: 0x00009C54
		public static Fraction operator /(Fraction frac1, Fraction frac2)
		{
			if (!(null != frac1) || !(null != frac2))
			{
				return null;
			}
			return Fraction.Multiply(frac1, Fraction.Inverse(frac2));
		}

		// Token: 0x06000FEF RID: 4079 RVA: 0x0000BA76 File Offset: 0x00009C76
		public static Fraction operator /(int iNo, Fraction frac1)
		{
			if (!(null != frac1))
			{
				return null;
			}
			return Fraction.Multiply(Fraction.Inverse(frac1), new Fraction((long)iNo));
		}

		// Token: 0x06000FF0 RID: 4080 RVA: 0x0000BA95 File Offset: 0x00009C95
		public static Fraction operator /(Fraction frac1, int iNo)
		{
			if (!(null != frac1))
			{
				return null;
			}
			return Fraction.Multiply(frac1, Fraction.Inverse(new Fraction((long)iNo)));
		}

		// Token: 0x06000FF1 RID: 4081 RVA: 0x0000BAB4 File Offset: 0x00009CB4
		public static Fraction operator /(double dbl, Fraction frac1)
		{
			if (!(null != frac1))
			{
				return null;
			}
			return Fraction.Multiply(Fraction.Inverse(frac1), Fraction.ToFraction(dbl));
		}

		// Token: 0x06000FF2 RID: 4082 RVA: 0x0000BAD2 File Offset: 0x00009CD2
		public static Fraction operator /(Fraction frac1, double dbl)
		{
			if (!(null != frac1))
			{
				return null;
			}
			return Fraction.Multiply(frac1, Fraction.Inverse(Fraction.ToFraction(dbl)));
		}

		// Token: 0x06000FF3 RID: 4083 RVA: 0x0000BAF0 File Offset: 0x00009CF0
		public static bool operator ==(Fraction frac1, Fraction frac2)
		{
			if (frac1 == null)
			{
				return frac2 == null;
			}
			return frac1.Equals(frac2);
		}

		// Token: 0x06000FF4 RID: 4084 RVA: 0x0000BB01 File Offset: 0x00009D01
		public static bool operator !=(Fraction frac1, Fraction frac2)
		{
			return !(frac1 == frac2);
		}

		// Token: 0x06000FF5 RID: 4085 RVA: 0x0000BB0D File Offset: 0x00009D0D
		public static bool operator ==(Fraction frac1, int iNo)
		{
			return frac1 != null && frac1.Equals(new Fraction((long)iNo));
		}

		// Token: 0x06000FF6 RID: 4086 RVA: 0x0000BB21 File Offset: 0x00009D21
		public static bool operator !=(Fraction frac1, int iNo)
		{
			return !(frac1 == iNo);
		}

		// Token: 0x06000FF7 RID: 4087 RVA: 0x0000BB2D File Offset: 0x00009D2D
		public static bool operator ==(Fraction frac1, double dbl)
		{
			return frac1 != null && frac1.Equals(new Fraction(dbl));
		}

		// Token: 0x06000FF8 RID: 4088 RVA: 0x0000BB40 File Offset: 0x00009D40
		public static bool operator !=(Fraction frac1, double dbl)
		{
			return !(frac1 == dbl);
		}

		// Token: 0x06000FF9 RID: 4089 RVA: 0x0000BB4C File Offset: 0x00009D4C
		public static bool operator <(Fraction frac1, Fraction frac2)
		{
			return null != frac1 && null != frac2 && frac1.Numerator * frac2.Denominator < frac2.Numerator * frac1.Denominator;
		}

		// Token: 0x06000FFA RID: 4090 RVA: 0x0000BB7E File Offset: 0x00009D7E
		public static bool operator >(Fraction frac1, Fraction frac2)
		{
			return null != frac1 && null != frac2 && frac1.Numerator * frac2.Denominator > frac2.Numerator * frac1.Denominator;
		}

		// Token: 0x06000FFB RID: 4091 RVA: 0x00065AE0 File Offset: 0x00063CE0
		public static bool operator <=(Fraction frac1, Fraction frac2)
		{
			if (!(null != frac1) || !(null != frac2))
			{
				return null == frac1 && null == frac2;
			}
			return frac1.Numerator * frac2.Denominator <= frac2.Numerator * frac1.Denominator;
		}

		// Token: 0x06000FFC RID: 4092 RVA: 0x00065B34 File Offset: 0x00063D34
		public static bool operator >=(Fraction frac1, Fraction frac2)
		{
			if (!(null != frac1) || !(null != frac2))
			{
				return null == frac1 && null == frac2;
			}
			return frac1.Numerator * frac2.Denominator >= frac2.Numerator * frac1.Denominator;
		}

		// Token: 0x06000FFD RID: 4093 RVA: 0x0000BBB0 File Offset: 0x00009DB0
		public static implicit operator Fraction(long lNo)
		{
			return new Fraction(lNo);
		}

		// Token: 0x06000FFE RID: 4094 RVA: 0x0000BBB8 File Offset: 0x00009DB8
		public static implicit operator Fraction(double dNo)
		{
			return new Fraction(dNo);
		}

		// Token: 0x06000FFF RID: 4095 RVA: 0x0000BBC0 File Offset: 0x00009DC0
		public static implicit operator Fraction(string strNo)
		{
			return new Fraction(strNo);
		}

		// Token: 0x06001000 RID: 4096 RVA: 0x0000BBC8 File Offset: 0x00009DC8
		public static explicit operator double(Fraction frac)
		{
			if (!(null != frac))
			{
				return 0.0;
			}
			return frac.ToDouble();
		}

		// Token: 0x06001001 RID: 4097 RVA: 0x0000BBE3 File Offset: 0x00009DE3
		public static implicit operator string(Fraction frac)
		{
			if (!(null != frac))
			{
				return string.Empty;
			}
			return frac.ToString();
		}

		// Token: 0x06001002 RID: 4098 RVA: 0x00065B88 File Offset: 0x00063D88
		public override bool Equals(object obj)
		{
			Fraction fraction = (Fraction)obj;
			long numerator = this.Numerator;
			long? num = (fraction != null) ? new long?(fraction.Numerator) : null;
			if (numerator == num.GetValueOrDefault() & num != null)
			{
				long denominator = this.Denominator;
				num = ((fraction != null) ? new long?(fraction.Denominator) : null);
				return denominator == num.GetValueOrDefault() & num != null;
			}
			return false;
		}

		// Token: 0x06001003 RID: 4099 RVA: 0x0000BBFA File Offset: 0x00009DFA
		public override int GetHashCode()
		{
			return Convert.ToInt32((this.Numerator ^ this.Denominator) & (long)((ulong)-1));
		}

		// Token: 0x06001004 RID: 4100 RVA: 0x00065C04 File Offset: 0x00063E04
		public static Fraction Negate(Fraction frac1)
		{
			if (frac1 != null)
			{
				long iNumerator = -frac1.Numerator;
				long denominator = frac1.Denominator;
				return new Fraction(iNumerator, denominator);
			}
			return null;
		}

		// Token: 0x06001005 RID: 4101 RVA: 0x00065C2C File Offset: 0x00063E2C
		public static Fraction Add(Fraction frac1, Fraction frac2)
		{
			checked
			{
				Fraction result;
				try
				{
					if (frac1 != null && frac2 != null)
					{
						long iNumerator = frac1.Numerator * frac2.Denominator + frac2.Numerator * frac1.Denominator;
						long iDenominator = frac1.Denominator * frac2.Denominator;
						result = new Fraction(iNumerator, iDenominator);
					}
					else if (frac1 != null)
					{
						result = frac1;
					}
					else
					{
						result = frac2;
					}
				}
				catch (OverflowException)
				{
					throw new FractionException("Overflow occurred while performing arithemetic operation");
				}
				catch (Exception)
				{
					throw new FractionException("An error occurred while performing arithemetic operation");
				}
				return result;
			}
		}

		// Token: 0x06001006 RID: 4102 RVA: 0x00065CB4 File Offset: 0x00063EB4
		public static Fraction Multiply(Fraction frac1, Fraction frac2)
		{
			checked
			{
				Fraction result;
				try
				{
					if (frac1 != null && frac2 != null)
					{
						long iNumerator = frac1.Numerator * frac2.Numerator;
						long iDenominator = frac1.Denominator * frac2.Denominator;
						result = new Fraction(iNumerator, iDenominator);
					}
					else
					{
						result = null;
					}
				}
				catch (OverflowException)
				{
					throw new FractionException("Overflow occurred while performing arithemetic operation");
				}
				catch (Exception)
				{
					throw new FractionException("An error occurred while performing arithemetic operation");
				}
				return result;
			}
		}

		// Token: 0x06001007 RID: 4103 RVA: 0x0000BC11 File Offset: 0x00009E11
		private static long GCD(long iNo1, long iNo2)
		{
			if (iNo1 < 0L)
			{
				iNo1 = -iNo1;
			}
			if (iNo2 < 0L)
			{
				iNo2 = -iNo2;
			}
			do
			{
				if (iNo1 < iNo2)
				{
					long num = iNo1;
					iNo1 = iNo2;
					iNo2 = num;
				}
				iNo1 %= iNo2;
			}
			while (iNo1 != 0L);
			return iNo2;
		}

		// Token: 0x06001008 RID: 4104 RVA: 0x00065D24 File Offset: 0x00063F24
		public static void ReduceFraction(Fraction frac)
		{
			try
			{
				if (null != frac)
				{
					if (frac.Numerator == 0L)
					{
						frac.Denominator = 1L;
					}
					else
					{
						long num = Fraction.GCD(frac.Numerator, frac.Denominator);
						frac.Numerator /= num;
						frac.Denominator /= num;
						if (frac.Denominator < 0L)
						{
							frac.Numerator *= -1L;
							frac.Denominator *= -1L;
						}
					}
				}
			}
			catch (Exception ex)
			{
				throw new FractionException("Cannot reduce Fraction: " + ex.Message);
			}
		}

		// Token: 0x06001009 RID: 4105 RVA: 0x0000B935 File Offset: 0x00009B35
		public static Fraction Subtract(Fraction frac1, Fraction frac2)
		{
			if (!(null != frac1) || !(null != frac2))
			{
				return null;
			}
			return Fraction.Add(frac1, -frac2);
		}

		// Token: 0x0600100A RID: 4106 RVA: 0x0000BA54 File Offset: 0x00009C54
		public static Fraction Divide(Fraction frac1, Fraction frac2)
		{
			if (!(null != frac1) || !(null != frac2))
			{
				return null;
			}
			return Fraction.Multiply(frac1, Fraction.Inverse(frac2));
		}

		// Token: 0x0600100B RID: 4107 RVA: 0x00065DCC File Offset: 0x00063FCC
		public int CompareTo(Fraction frac)
		{
			if (frac == null)
			{
				return 1;
			}
			if (this.Numerator * this.Denominator == frac.Numerator * frac.Denominator)
			{
				return 0;
			}
			if (this.Numerator * this.Denominator < frac.Numerator * frac.Denominator)
			{
				return 1;
			}
			return -1;
		}

		// Token: 0x04000ABC RID: 2748
		private long m_iNumerator;

		// Token: 0x04000ABD RID: 2749
		private long m_iDenominator;

		// Token: 0x04000ABE RID: 2750
		private double m_iDoubleValue;
	}
}
