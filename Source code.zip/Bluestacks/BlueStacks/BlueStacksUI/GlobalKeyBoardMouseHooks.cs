﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Threading;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000245 RID: 581
	internal class GlobalKeyBoardMouseHooks
	{
		// Token: 0x060014DB RID: 5339 RVA: 0x0007D9FC File Offset: 0x0007BBFC
		private static IntPtr SetHook(GlobalKeyBoardMouseHooks.LowLevelMouseProc proc)
		{
			IntPtr result;
			using (Process currentProcess = Process.GetCurrentProcess())
			{
				using (ProcessModule mainModule = currentProcess.MainModule)
				{
					result = NativeMethods.SetWindowsHookEx(14, proc, NativeMethods.GetModuleHandle(mainModule.ModuleName), 0U);
				}
			}
			return result;
		}

		// Token: 0x060014DC RID: 5340 RVA: 0x0007DA60 File Offset: 0x0007BC60
		private static IntPtr SetHook(GlobalKeyBoardMouseHooks.LowLevelKeyboardProc proc)
		{
			IntPtr result;
			using (Process currentProcess = Process.GetCurrentProcess())
			{
				using (ProcessModule mainModule = currentProcess.MainModule)
				{
					result = NativeMethods.SetWindowsHookEx(13, proc, NativeMethods.GetModuleHandle(mainModule.ModuleName), 0U);
				}
			}
			return result;
		}

		// Token: 0x060014DD RID: 5341 RVA: 0x0007DAC4 File Offset: 0x0007BCC4
		internal static void SetMouseMoveHook()
		{
			try
			{
				if (GlobalKeyBoardMouseHooks.mMouseHookId == IntPtr.Zero)
				{
					GlobalKeyBoardMouseHooks.mMouseHookId = GlobalKeyBoardMouseHooks.SetHook(GlobalKeyBoardMouseHooks.mMouseProc);
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Exception setting global mouse hook" + ex.ToString());
			}
		}

		// Token: 0x060014DE RID: 5342 RVA: 0x0007DB1C File Offset: 0x0007BD1C
		internal static void SetBossKeyHook()
		{
			try
			{
				GlobalKeyBoardMouseHooks.SetKey(RegistryManager.Instance.BossKey);
				if (GlobalKeyBoardMouseHooks.mKeyboardHookID == IntPtr.Zero)
				{
					GlobalKeyBoardMouseHooks.mKeyboardHookID = GlobalKeyBoardMouseHooks.SetHook(GlobalKeyBoardMouseHooks.mKeyboardProc);
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Exception setting global hook" + ex.ToString());
			}
		}

		// Token: 0x060014DF RID: 5343 RVA: 0x0007DB84 File Offset: 0x0007BD84
		internal static void SetKey(string key)
		{
			if (string.IsNullOrEmpty(key))
			{
				Logger.Warning("Cannot set an empty key");
				return;
			}
			string[] array = key.Split(new char[]
			{
				'+',
				' '
			}, StringSplitOptions.RemoveEmptyEntries);
			string bossKey = array[array.Length - 1];
			GlobalKeyBoardMouseHooks.sKey = IMAPKeys.mDictKeys.First((KeyValuePair<Key, string> x) => x.Value == bossKey).Key.ToString();
			GlobalKeyBoardMouseHooks.sIsControlUsedInBossKey = (GlobalKeyBoardMouseHooks.sIsAltUsedInBossKey = (GlobalKeyBoardMouseHooks.sIsShiftUsedInBossKey = false));
			foreach (string a in array)
			{
				if (string.Equals(a, "Ctrl", StringComparison.InvariantCulture))
				{
					GlobalKeyBoardMouseHooks.sIsControlUsedInBossKey = true;
				}
				else if (string.Equals(a, "Alt", StringComparison.InvariantCulture))
				{
					GlobalKeyBoardMouseHooks.sIsAltUsedInBossKey = true;
				}
				else if (string.Equals(a, "Shift", StringComparison.InvariantCulture))
				{
					GlobalKeyBoardMouseHooks.sIsShiftUsedInBossKey = true;
				}
			}
		}

		// Token: 0x060014E0 RID: 5344 RVA: 0x0000E3CA File Offset: 0x0000C5CA
		internal static void UnsetKey()
		{
			GlobalKeyBoardMouseHooks.sKey = string.Empty;
			GlobalKeyBoardMouseHooks.sIsControlUsedInBossKey = false;
			GlobalKeyBoardMouseHooks.sIsAltUsedInBossKey = false;
			GlobalKeyBoardMouseHooks.sIsShiftUsedInBossKey = false;
		}

		// Token: 0x060014E1 RID: 5345 RVA: 0x0000E3E8 File Offset: 0x0000C5E8
		internal static void UnHookGlobalHooks()
		{
			NativeMethods.UnhookWindowsHookEx(GlobalKeyBoardMouseHooks.mKeyboardHookID);
			GlobalKeyBoardMouseHooks.mKeyboardHookID = IntPtr.Zero;
			GlobalKeyBoardMouseHooks.UnhookGlobalMouseHooks();
		}

		// Token: 0x060014E2 RID: 5346 RVA: 0x0000E404 File Offset: 0x0000C604
		internal static void UnhookGlobalMouseHooks()
		{
			if (GlobalKeyBoardMouseHooks.mMouseHookId != IntPtr.Zero)
			{
				NativeMethods.UnhookWindowsHookEx(GlobalKeyBoardMouseHooks.mMouseHookId);
				GlobalKeyBoardMouseHooks.mMouseHookId = IntPtr.Zero;
			}
		}

		// Token: 0x060014E3 RID: 5347 RVA: 0x0007DC74 File Offset: 0x0007BE74
		private static IntPtr KeyboardHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
		{
			try
			{
				if (GlobalKeyBoardMouseHooks.sIsEnableKeyboardHookLogging)
				{
					Logger.Info(string.Concat(new string[]
					{
						"Keyboard hook ..",
						nCode.ToString(),
						"..",
						wParam.ToString(),
						"..",
						lParam.ToString()
					}));
				}
				MainWindow window = BlueStacksUIUtils.ActivatedWindow;
				if (nCode >= 0 && (wParam == (IntPtr)256 || wParam == (IntPtr)260 || wParam == (IntPtr)257))
				{
					int num = Marshal.ReadInt32(lParam);
					Logger.Debug("Keyboard hook .." + num.ToString() + ".." + GlobalKeyBoardMouseHooks.sKey);
					if (wParam == (IntPtr)256 || wParam == (IntPtr)260)
					{
						if (!string.IsNullOrEmpty(GlobalKeyBoardMouseHooks.sKey) && num == (int)((Keys)Enum.Parse(typeof(Keys), GlobalKeyBoardMouseHooks.sKey, false)) && GlobalKeyBoardMouseHooks.sIsControlUsedInBossKey == (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl)) && GlobalKeyBoardMouseHooks.sIsAltUsedInBossKey == (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt)) && GlobalKeyBoardMouseHooks.sIsShiftUsedInBossKey == (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift)))
						{
							ThreadPool.QueueUserWorkItem(delegate(object obj)
							{
								if (BlueStacksUIUtils.DictWindows.Values.Count > 0)
								{
									MainWindow mainWindow = BlueStacksUIUtils.DictWindows.Values.ToList<MainWindow>()[0];
									mainWindow.Dispatcher.Invoke(new Action(delegate()
									{
										try
										{
											if (!mainWindow.OwnedWindows.OfType<OnBoardingPopupWindow>().Any<OnBoardingPopupWindow>() && !mainWindow.OwnedWindows.OfType<GameOnboardingWindow>().Any<GameOnboardingWindow>())
											{
												GlobalKeyBoardMouseHooks.mIsHidden = !GlobalKeyBoardMouseHooks.mIsHidden;
												BlueStacksUIUtils.HideUnhideBlueStacks(GlobalKeyBoardMouseHooks.mIsHidden);
											}
										}
										catch
										{
										}
									}), new object[0]);
								}
							});
							return (IntPtr)1;
						}
						if (window != null && (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl)) && (Keyboard.IsKeyDown(Key.LeftAlt) || Keyboard.IsKeyDown(Key.RightAlt)))
						{
							if (num >= 96 && num <= 105)
							{
								num -= 48;
							}
							Key key = KeyInterop.KeyFromVirtualKey(num);
							string vkString = IMAPKeys.GetStringForFile(key);
							if (MainWindow.sMacroMapping.Keys.Contains(vkString))
							{
								Action <>9__3;
								ThreadPool.QueueUserWorkItem(delegate(object obj)
								{
									try
									{
										Dispatcher dispatcher = window.Dispatcher;
										Action method;
										if ((method = <>9__3) == null)
										{
											method = (<>9__3 = delegate()
											{
												if (window.mSidebar.GetElementFromTag("sidebar_macro") != null && window.mSidebar.GetElementFromTag("sidebar_macro").Visibility == Visibility.Visible && window.mSidebar.GetElementFromTag("sidebar_macro").IsEnabled)
												{
													if (window.mIsMacroRecorderActive)
													{
														window.ShowToast(LocaleStrings.GetLocalizedString("STRING_STOP_RECORDING_FIRST"), "", "", false);
														return;
													}
													if (window.mIsMacroPlaying)
													{
														CustomMessageWindow customMessageWindow = new CustomMessageWindow();
														BlueStacksUIBinding.Bind(customMessageWindow.TitleTextBlock, "STRING_CANNOT_RUN_MACRO", "");
														BlueStacksUIBinding.Bind(customMessageWindow.BodyTextBlock, "STRING_STOP_MACRO_SCRIPT", "");
														customMessageWindow.AddButton(ButtonColors.Blue, "STRING_OK", null, null, false, null);
														customMessageWindow.Owner = window;
														customMessageWindow.ShowDialog();
														return;
													}
													try
													{
														string path = Path.Combine(RegistryStrings.MacroRecordingsFolderPath, MainWindow.sMacroMapping[vkString] + ".json");
														if (File.Exists(path))
														{
															MacroRecording macroRecording = JsonConvert.DeserializeObject<MacroRecording>(File.ReadAllText(path), Utils.GetSerializerSettings());
															macroRecording.Name = MainWindow.sMacroMapping[vkString];
															window.mCommonHandler.FullMacroScriptPlayHandler(macroRecording);
															ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "macro_play", "shortcut_keys", macroRecording.RecordingType.ToString(), string.IsNullOrEmpty(macroRecording.MacroId) ? "local" : "community", null, null);
														}
														return;
													}
													catch (Exception ex)
													{
														Logger.Error("Exception in macro play with shortcut: " + ex.ToString());
														return;
													}
												}
												Logger.Info("Macro not enabled for the current package: " + window.StaticComponents.mSelectedTabButton.PackageName);
											});
										}
										dispatcher.Invoke(method, new object[0]);
									}
									catch
									{
									}
								});
							}
						}
					}
				}
			}
			catch
			{
			}
			return NativeMethods.CallNextHookEx(GlobalKeyBoardMouseHooks.mKeyboardHookID, nCode, wParam, lParam);
		}

		// Token: 0x060014E4 RID: 5348 RVA: 0x0000E42C File Offset: 0x0000C62C
		private static IntPtr MouseHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
		{
			return NativeMethods.CallNextHookEx(GlobalKeyBoardMouseHooks.mMouseHookId, nCode, wParam, lParam);
		}

		// Token: 0x04000D2A RID: 3370
		private static bool mIsHidden = false;

		// Token: 0x04000D2B RID: 3371
		private const int WH_KEYBOARD_LL = 13;

		// Token: 0x04000D2C RID: 3372
		private const int WM_KEYDOWN = 256;

		// Token: 0x04000D2D RID: 3373
		private const int WM_KEYUP = 257;

		// Token: 0x04000D2E RID: 3374
		private const int WM_SYSKEYDOWN = 260;

		// Token: 0x04000D2F RID: 3375
		private static readonly GlobalKeyBoardMouseHooks.LowLevelKeyboardProc mKeyboardProc = new GlobalKeyBoardMouseHooks.LowLevelKeyboardProc(GlobalKeyBoardMouseHooks.KeyboardHookCallback);

		// Token: 0x04000D30 RID: 3376
		private static IntPtr mKeyboardHookID = IntPtr.Zero;

		// Token: 0x04000D31 RID: 3377
		private static string sKey = null;

		// Token: 0x04000D32 RID: 3378
		private static bool sIsControlUsedInBossKey = false;

		// Token: 0x04000D33 RID: 3379
		private static bool sIsAltUsedInBossKey = false;

		// Token: 0x04000D34 RID: 3380
		private static bool sIsShiftUsedInBossKey = false;

		// Token: 0x04000D35 RID: 3381
		internal static bool sIsEnableKeyboardHookLogging = false;

		// Token: 0x04000D36 RID: 3382
		private static GlobalKeyBoardMouseHooks.LowLevelMouseProc mMouseProc = new GlobalKeyBoardMouseHooks.LowLevelMouseProc(GlobalKeyBoardMouseHooks.MouseHookCallback);

		// Token: 0x04000D37 RID: 3383
		private static IntPtr mMouseHookId = IntPtr.Zero;

		// Token: 0x04000D38 RID: 3384
		private const int WH_MOUSE_LL = 14;

		// Token: 0x02000246 RID: 582
		// (Invoke) Token: 0x060014E8 RID: 5352
		internal delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);

		// Token: 0x02000247 RID: 583
		// (Invoke) Token: 0x060014EC RID: 5356
		internal delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

		// Token: 0x02000248 RID: 584
		private enum MouseMessages
		{
			// Token: 0x04000D3A RID: 3386
			WM_LBUTTONDOWN = 513,
			// Token: 0x04000D3B RID: 3387
			WM_LBUTTONUP,
			// Token: 0x04000D3C RID: 3388
			WM_MOUSEMOVE = 512,
			// Token: 0x04000D3D RID: 3389
			WM_MOUSEWHEEL = 522,
			// Token: 0x04000D3E RID: 3390
			WM_RBUTTONDOWN = 516,
			// Token: 0x04000D3F RID: 3391
			WM_RBUTTONUP
		}

		// Token: 0x02000249 RID: 585
		private struct MSLLHOOKSTRUCT
		{
			// Token: 0x04000D40 RID: 3392
			public POINT pt;

			// Token: 0x04000D41 RID: 3393
			public uint mouseData;

			// Token: 0x04000D42 RID: 3394
			public uint flags;

			// Token: 0x04000D43 RID: 3395
			public uint time;

			// Token: 0x04000D44 RID: 3396
			public IntPtr dwExtraInfo;
		}
	}
}
