﻿using System;
using System.Collections.Generic;
using System.Reflection;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200006D RID: 109
	public class CustomThumbnail
	{
		// Token: 0x1700015F RID: 351
		// (get) Token: 0x0600045C RID: 1116 RVA: 0x00004F62 File Offset: 0x00003162
		// (set) Token: 0x0600045D RID: 1117 RVA: 0x00004F6A File Offset: 0x0000316A
		[JsonProperty(PropertyName = "pan", DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate, NullValueHandling = NullValueHandling.Include)]
		public VideoThumbnailInfo Pan { get; set; }

		// Token: 0x17000160 RID: 352
		// (get) Token: 0x0600045E RID: 1118 RVA: 0x00004F73 File Offset: 0x00003173
		// (set) Token: 0x0600045F RID: 1119 RVA: 0x00004F7B File Offset: 0x0000317B
		[JsonProperty(PropertyName = "moba", DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate, NullValueHandling = NullValueHandling.Include)]
		public VideoThumbnailInfo Moba { get; set; }

		// Token: 0x17000161 RID: 353
		// (get) Token: 0x06000460 RID: 1120 RVA: 0x00004F84 File Offset: 0x00003184
		// (set) Token: 0x06000461 RID: 1121 RVA: 0x00004F8C File Offset: 0x0000318C
		[JsonProperty(PropertyName = "gamepad", DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate, NullValueHandling = NullValueHandling.Include)]
		public VideoThumbnailInfo Gamepad { get; set; }

		// Token: 0x17000162 RID: 354
		// (get) Token: 0x06000462 RID: 1122 RVA: 0x00004F95 File Offset: 0x00003195
		// (set) Token: 0x06000463 RID: 1123 RVA: 0x00004F9D File Offset: 0x0000319D
		[JsonProperty(PropertyName = "special", DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate, NullValueHandling = NullValueHandling.Include)]
		public VideoThumbnailInfo Special { get; set; }

		// Token: 0x17000163 RID: 355
		// (get) Token: 0x06000464 RID: 1124 RVA: 0x00004FA6 File Offset: 0x000031A6
		// (set) Token: 0x06000465 RID: 1125 RVA: 0x00004FAE File Offset: 0x000031AE
		[JsonProperty(PropertyName = "package")]
		public string Package { get; set; }

		// Token: 0x17000164 RID: 356
		// (get) Token: 0x06000466 RID: 1126 RVA: 0x00004FB7 File Offset: 0x000031B7
		// (set) Token: 0x06000467 RID: 1127 RVA: 0x00004FBF File Offset: 0x000031BF
		[JsonProperty(PropertyName = "schemespecific")]
		public Dictionary<string, VideoThumbnailInfo> SchemeSpecific { get; set; } = new Dictionary<string, VideoThumbnailInfo>();

		// Token: 0x17000165 RID: 357
		public object this[string propertyName]
		{
			get
			{
				PropertyInfo property = typeof(CustomThumbnail).GetProperty(propertyName, BindingFlags.IgnoreCase | BindingFlags.Instance | BindingFlags.Public);
				if (property == null)
				{
					return null;
				}
				return property.GetValue(this, null);
			}
		}
	}
}
