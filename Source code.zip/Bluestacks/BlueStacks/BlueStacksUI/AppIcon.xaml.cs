﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Xml;
using System.Xml.Serialization;
using BlueStacks.Common;
using Newtonsoft.Json;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000027 RID: 39
	public partial class AppIcon : Button
	{
		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x0600021B RID: 539 RVA: 0x00003617 File Offset: 0x00001817
		private MainWindow ParentWindow
		{
			get
			{
				if (this.mMainWindow == null)
				{
					this.mMainWindow = (Window.GetWindow(this) as MainWindow);
				}
				return this.mMainWindow;
			}
		}

		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x0600021C RID: 540 RVA: 0x00003638 File Offset: 0x00001838
		// (set) Token: 0x0600021D RID: 541 RVA: 0x00003640 File Offset: 0x00001840
		public bool mIsAppRemovable { get; set; } = true;

		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x0600021E RID: 542 RVA: 0x00003649 File Offset: 0x00001849
		// (set) Token: 0x0600021F RID: 543 RVA: 0x00003651 File Offset: 0x00001851
		public bool IsGl3App { get; set; }

		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x06000220 RID: 544 RVA: 0x0000365A File Offset: 0x0000185A
		// (set) Token: 0x06000221 RID: 545 RVA: 0x00003662 File Offset: 0x00001862
		public bool IsAppIncompat { get; set; }

		// Token: 0x14000001 RID: 1
		// (add) Token: 0x06000222 RID: 546 RVA: 0x000123FC File Offset: 0x000105FC
		// (remove) Token: 0x06000223 RID: 547 RVA: 0x00012434 File Offset: 0x00010634
		private event EventHandler UninstallConfirmationClicked;

		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x06000224 RID: 548 RVA: 0x0000366B File Offset: 0x0000186B
		// (set) Token: 0x06000225 RID: 549 RVA: 0x00003673 File Offset: 0x00001873
		internal bool IsInstalledApp { get; set; } = true;

		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x06000226 RID: 550 RVA: 0x0000367C File Offset: 0x0000187C
		// (set) Token: 0x06000227 RID: 551 RVA: 0x00003684 File Offset: 0x00001884
		public int MyAppPriority { get; set; } = 999;

		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x06000228 RID: 552 RVA: 0x0000368D File Offset: 0x0000188D
		// (set) Token: 0x06000229 RID: 553 RVA: 0x0000369A File Offset: 0x0000189A
		public string ImageName
		{
			get
			{
				return this.mAppImage.ImageName;
			}
			set
			{
				this.mAppImage.IsFullImagePath = true;
				this.mAppImage.ImageName = value;
			}
		}

		// Token: 0x170000FA RID: 250
		// (get) Token: 0x0600022A RID: 554 RVA: 0x000036B4 File Offset: 0x000018B4
		// (set) Token: 0x0600022B RID: 555 RVA: 0x000036BC File Offset: 0x000018BC
		public string PackageName
		{
			get
			{
				return this.mPackageName;
			}
			set
			{
				this.mPackageName = value;
				this.LoadDownloadAppIcon();
			}
		}

		// Token: 0x170000FB RID: 251
		// (get) Token: 0x0600022C RID: 556 RVA: 0x000036CB File Offset: 0x000018CB
		// (set) Token: 0x0600022D RID: 557 RVA: 0x000036D3 File Offset: 0x000018D3
		public string ActivityName { get; set; } = string.Empty;

		// Token: 0x170000FC RID: 252
		// (get) Token: 0x0600022E RID: 558 RVA: 0x000036DC File Offset: 0x000018DC
		// (set) Token: 0x0600022F RID: 559 RVA: 0x000036E9 File Offset: 0x000018E9
		public string AppName
		{
			get
			{
				return this.AppNameTextBox.Text;
			}
			set
			{
				BlueStacksUIBinding.Bind(this, value, FrameworkElement.ToolTipProperty);
				BlueStacksUIBinding.Bind(this.AppNameTextBox, value, "");
			}
		}

		// Token: 0x170000FD RID: 253
		// (get) Token: 0x06000230 RID: 560 RVA: 0x00003708 File Offset: 0x00001908
		// (set) Token: 0x06000231 RID: 561 RVA: 0x00003710 File Offset: 0x00001910
		internal bool IsGamepadCompatible { get; set; }

		// Token: 0x170000FE RID: 254
		// (get) Token: 0x06000232 RID: 562 RVA: 0x00003719 File Offset: 0x00001919
		// (set) Token: 0x06000233 RID: 563 RVA: 0x00003721 File Offset: 0x00001921
		public string ApkUrl { get; set; } = string.Empty;

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x06000234 RID: 564 RVA: 0x0000372A File Offset: 0x0000192A
		// (set) Token: 0x06000235 RID: 565 RVA: 0x00003732 File Offset: 0x00001932
		public bool IsDownloading { get; set; }

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x06000236 RID: 566 RVA: 0x0000373B File Offset: 0x0000193B
		// (set) Token: 0x06000237 RID: 567 RVA: 0x00003743 File Offset: 0x00001943
		public bool IsGifIcon { get; set; }

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x06000238 RID: 568 RVA: 0x0000374C File Offset: 0x0000194C
		// (set) Token: 0x06000239 RID: 569 RVA: 0x00003754 File Offset: 0x00001954
		public bool IsAppSuggestionActive { get; set; }

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x0600023A RID: 570 RVA: 0x0000375D File Offset: 0x0000195D
		// (set) Token: 0x0600023B RID: 571 RVA: 0x00003765 File Offset: 0x00001965
		public bool IsDockLocation { get; set; }

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x0600023C RID: 572 RVA: 0x0000376E File Offset: 0x0000196E
		// (set) Token: 0x0600023D RID: 573 RVA: 0x00003776 File Offset: 0x00001976
		public bool IsInstaling { get; set; }

		// Token: 0x0600023E RID: 574 RVA: 0x0001246C File Offset: 0x0001066C
		public AppIcon()
		{
			this.InitializeComponent();
			this.UninstallConfirmationClicked += this.AppIcon_UninstallConfirmationClicked;
		}

		// Token: 0x0600023F RID: 575 RVA: 0x000124E4 File Offset: 0x000106E4
		private void Init(string package, string appName)
		{
			if (AppHandler.ListIgnoredApps.Contains(package, StringComparer.InvariantCultureIgnoreCase))
			{
				base.Visibility = Visibility.Collapsed;
			}
			this.PackageName = package;
			this.AppName = appName;
			base.ToolTip = appName;
			if (RegistryManager.Instance.IsShowIconBorder)
			{
				this.ApplyBorder("appFrameIcon");
			}
			this.IsGamepadCompatible = KMManager.CheckGamepadCompatible(package);
			if (this.IsGamepadCompatible)
			{
				this.AppNameTextBox.TextWrapping = TextWrapping.NoWrap;
				this.mGamePadGrid.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x06000240 RID: 576 RVA: 0x0000377F File Offset: 0x0000197F
		internal void ApplyBorder(string path)
		{
			if (this.mPromotionId == null)
			{
				this.mSuggestedAppPromotionImage.ImageName = path;
				this.mSuggestedAppPromotionImage.Visibility = Visibility.Visible;
				this.mSuggestedAppPromotionImage.Clip = null;
			}
		}

		// Token: 0x06000241 RID: 577 RVA: 0x00012564 File Offset: 0x00010764
		internal void AddToDock(double height = 50.0, double width = 50.0)
		{
			if (width > 68.0)
			{
				this.mMainGrid.ColumnDefinitions[3].Width = new GridLength(width - 68.0);
			}
			else
			{
				this.mMainGrid.ColumnDefinitions[2].Width = new GridLength(width);
			}
			if (height < 68.0)
			{
				this.mMainGrid.RowDefinitions[1].Height = new GridLength(height);
			}
			GridLength width2 = new GridLength(0.0);
			this.mMainGrid.ColumnDefinitions[1].Width = width2;
			this.mMainGrid.ColumnDefinitions[4].Width = width2;
			base.Margin = new Thickness(0.0, 43.0 - height, 0.0, 0.0);
			this.mAppImage.Height = height;
			this.mAppImage.Width = width;
			RectangleGeometry clip = new RectangleGeometry(new Rect(new Point(0.0, 0.0), new Point(width, height)), 10.0, 10.0);
			this.mAppImage.Clip = clip;
			this.AppNameTextBox.Visibility = Visibility.Collapsed;
			this.mIsAppRemovable = false;
			base.ToolTip = null;
			this.IsDockLocation = true;
		}

		// Token: 0x06000242 RID: 578 RVA: 0x000126D8 File Offset: 0x000108D8
		internal void AddToMoreAppsDock(double height = 55.0, double width = 55.0)
		{
			if (width > 68.0)
			{
				this.mMainGrid.ColumnDefinitions[3].Width = new GridLength(width - 68.0);
			}
			else
			{
				this.mMainGrid.ColumnDefinitions[2].Width = new GridLength(width);
			}
			if (height < 68.0)
			{
				this.mMainGrid.RowDefinitions[1].Height = new GridLength(height);
			}
			GridLength gridLength = new GridLength(0.0);
			this.mMainGrid.ColumnDefinitions[1].Width = gridLength;
			this.mMainGrid.ColumnDefinitions[4].Width = gridLength;
			this.mMainGrid.RowDefinitions[3].Height = gridLength;
			this.mMainGrid.RowDefinitions[5].Height = gridLength;
			base.Margin = new Thickness(0.0, 43.0 - height, 0.0, 0.0);
			this.mAppImage.Height = height;
			this.mAppImage.Width = width;
			RectangleGeometry clip = new RectangleGeometry(new Rect(new Point(0.0, 0.0), new Point(width, height)), 10.0, 10.0);
			this.mAppImage.Clip = clip;
			this.AppNameTextBox.Visibility = Visibility.Collapsed;
			this.mIsAppRemovable = false;
			base.ToolTip = null;
			this.IsDockLocation = true;
		}

		// Token: 0x06000243 RID: 579 RVA: 0x000037AD File Offset: 0x000019AD
		internal void Init(AppInfo item)
		{
			this.Init(item.Package, item.Name);
			this.mAppInfoItem = item;
			this.ActivityName = item.Activity;
			if (item.Gl3Required)
			{
				this.IsGl3App = true;
			}
		}

		// Token: 0x06000244 RID: 580 RVA: 0x000037E3 File Offset: 0x000019E3
		internal void InitRerollIcon(string package, string appname)
		{
			this.Init(package, appname);
			this.IsRerollIcon = true;
		}

		// Token: 0x06000245 RID: 581 RVA: 0x000037F4 File Offset: 0x000019F4
		internal void Init(string package, string appName, string apkUrl, DownloadInstallApk downloader)
		{
			this.Init(package, appName);
			this.ApkUrl = apkUrl;
			this.mDownloader = downloader;
		}

		// Token: 0x06000246 RID: 582 RVA: 0x0001287C File Offset: 0x00010A7C
		internal void Init(AppSuggestionPromotion appSuggestionInfo)
		{
			this.AppSuggestionInfo = appSuggestionInfo;
			this.AppName = appSuggestionInfo.AppName;
			this.ActivityName = appSuggestionInfo.AppActivity;
			this.IsAppSuggestionActive = true;
			if (string.IsNullOrEmpty(this.AppSuggestionInfo.ToolTip))
			{
				base.ToolTip = this.AppName;
			}
			else
			{
				base.ToolTip = null;
			}
			this.AppNameTextBox.TextWrapping = TextWrapping.Wrap;
			this.AppNameTextBox.TextTrimming = TextTrimming.CharacterEllipsis;
			if (this.AppSuggestionInfo.ExtraPayload.ContainsKey("click_generic_action") && (EnumHelper.Parse<GenericAction>(this.AppSuggestionInfo.ExtraPayload["click_generic_action"], GenericAction.None) & (GenericAction)448) != (GenericAction)0)
			{
				this.mIsAppRemovable = false;
				this.AppNameTextBox.TextWrapping = TextWrapping.NoWrap;
				this.AppNameTextBox.TextTrimming = TextTrimming.None;
			}
			BlueStacksUIBinding.ClearBind(this, FrameworkElement.ToolTipProperty);
			this.mIsAppInstalled = false;
			this.mPromotionId = this.AppSuggestionInfo.AppIconId;
			if (this.AppSuggestionInfo.AppIcon.EndsWith(".gif", StringComparison.InvariantCulture))
			{
				this.IsGifIcon = true;
			}
			this.ImageName = this.AppSuggestionInfo.AppIconPath;
			if (this.AppSuggestionInfo.IsIconBorder)
			{
				this.mSuggestedAppPromotionImage.ImageName = System.IO.Path.Combine(RegistryStrings.PromotionDirectory, string.Format(CultureInfo.InvariantCulture, "{0}{1}.png", new object[]
				{
					this.AppSuggestionInfo.IconBorderId,
					"app_suggestion_icon_border"
				}));
				this.mSuggestedAppPromotionImage.Visibility = Visibility.Visible;
				this.mSuggestedAppPromotionImage.Clip = null;
			}
		}

		// Token: 0x06000247 RID: 583 RVA: 0x00012A04 File Offset: 0x00010C04
		internal void AddPromotionBorderInstalledApp(AppSuggestionPromotion appSuggestionInfo)
		{
			this.AppSuggestionInfo = appSuggestionInfo;
			BlueStacksUIBinding.ClearBind(this, FrameworkElement.ToolTipProperty);
			if (this.AppSuggestionInfo.IsIconBorder)
			{
				this.mSuggestedAppPromotionImage.ImageName = this.AppSuggestionInfo.IconBorderId + "app_suggestion_icon_border";
				this.mSuggestedAppPromotionImage.Visibility = Visibility.Visible;
				this.mSuggestedAppPromotionImage.Clip = null;
			}
		}

		// Token: 0x06000248 RID: 584 RVA: 0x0000380D File Offset: 0x00001A0D
		internal void RemovePromotionBorderInstalledApp()
		{
			this.IsAppSuggestionActive = false;
			this.mSuggestedAppPromotionImage.ImageName = "";
			this.mSuggestedAppPromotionImage.Visibility = Visibility.Collapsed;
			this.mSuggestedAppPromotionImage.Clip = null;
		}

		// Token: 0x06000249 RID: 585 RVA: 0x00012A68 File Offset: 0x00010C68
		private void LoadDownloadAppIcon()
		{
			if (!string.IsNullOrEmpty(this.PackageName) && !this.IsAppSuggestionActive)
			{
				string path = Regex.Replace(this.PackageName + ".png", "[\\x22\\\\\\/:*?|<>]", " ");
				string filePath = System.IO.Path.Combine(RegistryStrings.GadgetDir, path);
				if (File.Exists(filePath))
				{
					this.ImageName = filePath;
					return;
				}
				if (!AppHandler.ListIgnoredApps.Contains(this.PackageName, StringComparer.InvariantCultureIgnoreCase))
				{
					Action <>9__1;
					ThreadPool.QueueUserWorkItem(delegate(object obj)
					{
						filePath = DownloadInstallApk.DownloadIcon(this.PackageName);
						Dispatcher dispatcher = this.Dispatcher;
						Action method;
						if ((method = <>9__1) == null)
						{
							method = (<>9__1 = delegate()
							{
								if (string.IsNullOrEmpty(filePath) || !File.Exists(filePath))
								{
									if (this.mAppInfoItem != null && !string.IsNullOrEmpty(this.mAppInfoItem.Img))
									{
										filePath = System.IO.Path.Combine(RegistryStrings.GadgetDir, this.mAppInfoItem.Img);
										if (File.Exists(filePath))
										{
											this.ImageName = filePath;
											return;
										}
									}
								}
								else if (File.Exists(filePath))
								{
									this.ImageName = filePath;
								}
							});
						}
						dispatcher.Invoke(method, new object[0]);
					});
				}
			}
		}

		// Token: 0x0600024A RID: 586 RVA: 0x00012B0C File Offset: 0x00010D0C
		private void Button_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			if (this.threadShowingUninstallButton == null)
			{
				this.threadShowingUninstallButton = new Thread(delegate()
				{
					Thread.Sleep(1000);
					if (this.threadShowingUninstallButton != null)
					{
						this.Dispatcher.Invoke(new Action(delegate()
						{
							(sender as UIElement).ReleaseMouseCapture();
							this.ShowUninstallButtons();
							this.threadShowingUninstallButton = null;
						}), new object[0]);
					}
				})
				{
					IsBackground = true
				};
				this.threadShowingUninstallButton.Start();
			}
		}

		// Token: 0x0600024B RID: 587 RVA: 0x0000383E File Offset: 0x00001A3E
		private void Button_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.threadShowingUninstallButton != null && this.threadShowingUninstallButton.IsAlive)
			{
				this.threadShowingUninstallButton = null;
			}
		}

		// Token: 0x0600024C RID: 588 RVA: 0x0000385C File Offset: 0x00001A5C
		private void Button_MouseHoldAction(object sender, EventArgs e)
		{
			this.ShowAppUninstallButton(true);
		}

		// Token: 0x0600024D RID: 589 RVA: 0x00003865 File Offset: 0x00001A65
		private void AppIcon_HideUninstallButton(object sender, EventArgs e)
		{
			this.ShowAppUninstallButton(false);
		}

		// Token: 0x0600024E RID: 590 RVA: 0x0000386E File Offset: 0x00001A6E
		private void ShowAppUninstallButton(bool isShow)
		{
			if (isShow)
			{
				if (this.mIsAppRemovable && (!this.IsInstaling || this.mIsInstallingFailed))
				{
					this.mUnInstallTabButton.Visibility = Visibility.Visible;
					return;
				}
			}
			else
			{
				this.mUnInstallTabButton.Visibility = Visibility.Hidden;
			}
		}

		// Token: 0x0600024F RID: 591 RVA: 0x00012B60 File Offset: 0x00010D60
		private void Button_Click(object sender, RoutedEventArgs e)
		{
			Logger.Info("Clicked app icon, package name {0}", new object[]
			{
				this.PackageName
			});
			if (this.mUnInstallTabButton.IsMouseOver)
			{
				this.UninstallButtonClicked();
				return;
			}
			if (this.mErrorGrid.IsVisible)
			{
				this.mErrorGrid.Visibility = Visibility.Hidden;
				if (this.mIsDownLoadingFailed)
				{
					this.mDownloader.DownloadApk(this.ApkUrl, this.PackageName, false, false, "");
					return;
				}
				if (this.mIsInstallingFailed)
				{
					this.mDownloader.InstallApk(this.PackageName, this.mApkFilePath, false, false, "");
					return;
				}
			}
			else if (!this.IsDownloading)
			{
				if (this.IsInstaling)
				{
					if (this.mDownloader == null)
					{
						this.ParentWindow.mWelcomeTab.mFrontendPopupControl.Init(this.PackageName, this.AppName, PlayStoreAction.OpenApp, false);
						return;
					}
				}
				else
				{
					if (this.IsRerollIcon)
					{
						this.HandleRerollClick();
						return;
					}
					if (this.IsAppSuggestionActive)
					{
						this.HandleAppSuggestionClick();
						if (this.mRedDotNotifIcon.Visibility == Visibility.Visible)
						{
							this.mRedDotNotifIcon.Visibility = Visibility.Hidden;
							HomeApp.AddPackageInRedDotShownRegistry(this.PackageName);
							return;
						}
					}
					else if (!string.IsNullOrEmpty(this.PackageName))
					{
						if (string.Equals(this.PackageName, "help_center", StringComparison.InvariantCulture))
						{
							this.ParentWindow.mTopBar.mAppTabButtons.AddWebTab(BlueStacksUIUtils.GetHelpCenterUrl(), "STRING_FEEDBACK", "help_center", true, "STRING_FEEDBACK", false);
							return;
						}
						if (string.Equals(this.PackageName, "instance_manager", StringComparison.InvariantCulture))
						{
							BlueStacksUIUtils.LaunchMultiInstanceManager();
							return;
						}
						if (string.Equals(this.PackageName, "macro_recorder", StringComparison.InvariantCulture))
						{
							this.ParentWindow.mCommonHandler.ShowMacroRecorderWindow();
							return;
						}
						this.OpenApp(true);
					}
				}
			}
		}

		// Token: 0x06000250 RID: 592 RVA: 0x000038A4 File Offset: 0x00001AA4
		private void HandleAppSuggestionClick()
		{
			this.ParentWindow.Utils.HandleGenericActionFromDictionary(this.AppSuggestionInfo.ExtraPayload, "my_apps", this.ImageName);
			this.SendAppSuggestionIconClickStats();
		}

		// Token: 0x06000251 RID: 593 RVA: 0x00012D20 File Offset: 0x00010F20
		internal void OpenApp(bool isCheckForGrm = true)
		{
			if (this.IsAppIncompat && isCheckForGrm)
			{
				GrmHandler.HandleCompatibility(this.PackageName, this.ParentWindow.mVmName);
				return;
			}
			this.ParentWindow.mTopBar.mAppTabButtons.AddAppTab(this.AppName, this.PackageName, this.ActivityName, this.ImageName, false, true, false);
			this.ParentWindow.mAppHandler.SwitchWhenPackageNameRecieved = this.PackageName;
			this.ParentWindow.mAppHandler.SendRunAppRequestAsync(this.PackageName, "", false);
			if (this.mRedDotNotifIcon.Visibility == Visibility.Visible)
			{
				this.mRedDotNotifIcon.Visibility = Visibility.Hidden;
				HomeApp.AddPackageInRedDotShownRegistry(this.PackageName);
			}
			this.SendStats();
		}

		// Token: 0x06000252 RID: 594 RVA: 0x00012DDC File Offset: 0x00010FDC
		private void SendStats()
		{
			if (this.PackageName == "com.android.vending")
			{
				ClientStats.SendGPlayClickStats(new Dictionary<string, string>
				{
					{
						"source",
						"bs3_myapps"
					}
				});
			}
			ClientStats.SendClientStatsAsync("init", "success", "app_activity", this.PackageName, "", "");
		}

		// Token: 0x06000253 RID: 595 RVA: 0x00012E3C File Offset: 0x0001103C
		private void HandleRerollClick()
		{
			CustomMessageWindow customMessageWindow = new CustomMessageWindow();
			customMessageWindow.TitleTextBlock.Text = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_REROLL_0"), new object[]
			{
				this.AppName
			});
			customMessageWindow.BodyTextBlock.Text = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_START_REROLL"), new object[]
			{
				this.AppName
			});
			customMessageWindow.AddButton(ButtonColors.White, "STRING_CANCEL", null, null, false, null);
			customMessageWindow.AddButton(ButtonColors.Blue, "STRING_REROLL_APP_PREFIX", new EventHandler(this.StartRerollAccepted), null, false, null);
			this.ParentWindow.ShowDimOverlay(null);
			customMessageWindow.Owner = this.ParentWindow.mDimOverlay;
			customMessageWindow.ShowDialog();
			if (customMessageWindow.ClickedButton != ButtonColors.White)
			{
				this.ParentWindow.HideDimOverlay();
			}
		}

		// Token: 0x06000254 RID: 596 RVA: 0x00012F10 File Offset: 0x00011110
		private void StartRerollAccepted(object sender, EventArgs e)
		{
			this.ParentWindow.ShowRerollOverlay();
			this.ParentWindow.mFrontendHandler.SendFrontendRequestAsync("startReroll", new Dictionary<string, string>
			{
				{
					"packageName",
					this.PackageName
				},
				{
					"rerollName",
					""
				}
			});
		}

		// Token: 0x06000255 RID: 597 RVA: 0x00012F64 File Offset: 0x00011164
		private void SendAppSuggestionIconClickStats()
		{
			ClientStats.SendPromotionAppClickStatsAsync(new Dictionary<string, string>
			{
				{
					"op",
					"init"
				},
				{
					"status",
					"success"
				},
				{
					"app_pkg",
					this.PackageName
				},
				{
					"extraPayload",
					JsonConvert.SerializeObject(this.AppSuggestionInfo.ExtraPayload)
				},
				{
					"app_name",
					this.AppName
				},
				{
					"app_promotion_id",
					this.mPromotionId
				},
				{
					"promotion_type",
					"cross_promotion"
				}
			}, "app_activity");
		}

		// Token: 0x06000256 RID: 598 RVA: 0x00013000 File Offset: 0x00011200
		private void UninstallButtonClicked()
		{
			try
			{
				if (this.IsDownloading)
				{
					if (this.mDownloader != null)
					{
						this.mDownloader.AbortApkDownload(this.PackageName);
						this.ParentWindow.mWelcomeTab.mHomeApp.RemoveAppIcon(this.PackageName, null);
					}
				}
				else if (this.IsInstaling)
				{
					if (this.mIsInstallingFailed)
					{
						this.ParentWindow.mWelcomeTab.mHomeApp.RemoveAppIcon(this.PackageName, null);
					}
				}
				else if (this.IsAppSuggestionActive)
				{
					CustomMessageWindow customMessageWindow = new CustomMessageWindow();
					customMessageWindow.TitleTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_REMOVE_ICON");
					customMessageWindow.BodyTextBlock.Text = LocaleStrings.GetLocalizedString("STRING_ICON_REMOVE");
					customMessageWindow.AddButton(ButtonColors.Red, LocaleStrings.GetLocalizedString("STRING_REMOVE"), new EventHandler(this.RemoveAppSuggestion), null, false, null);
					customMessageWindow.AddButton(ButtonColors.White, LocaleStrings.GetLocalizedString("STRING_KEEP"), null, null, false, null);
					customMessageWindow.Owner = this.ParentWindow;
					this.ParentWindow.ShowDimOverlay(null);
					customMessageWindow.ShowDialog();
					this.ParentWindow.HideDimOverlay();
				}
				else
				{
					CustomMessageWindow customMessageWindow2 = new CustomMessageWindow();
					customMessageWindow2.TitleTextBlock.Text = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_UNINSTALL_0"), new object[]
					{
						this.AppName
					});
					customMessageWindow2.BodyTextBlock.Text = string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_UNINSTALL_0_BS"), new object[]
					{
						this.AppName
					});
					customMessageWindow2.AddButton(ButtonColors.Red, "STRING_UNINSTALL", this.UninstallConfirmationClicked, null, false, null);
					customMessageWindow2.AddButton(ButtonColors.White, "STRING_NO", null, null, false, null);
					this.ParentWindow.ShowDimOverlay(null);
					customMessageWindow2.Owner = this.ParentWindow.mDimOverlay;
					customMessageWindow2.ShowDialog();
					this.ParentWindow.HideDimOverlay();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in UninstallButtonClicked. Err : " + ex.ToString());
			}
		}

		// Token: 0x06000257 RID: 599 RVA: 0x00013210 File Offset: 0x00011410
		private void RemoveAppSuggestion(object sender, EventArgs e)
		{
			this.ParentWindow.mWelcomeTab.mHomeApp.RemoveAppIcon(this.PackageName, null);
			ClientStats.SendMiscellaneousStatsAsync("cross_promotion_icon_removed", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, this.mPackageName, "bgp", null, null, null);
			try
			{
				XmlWriterSettings settings = new XmlWriterSettings
				{
					OmitXmlDeclaration = true,
					Indent = true
				};
				XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces(new XmlQualifiedName[]
				{
					new XmlQualifiedName("", "")
				});
				string text = System.IO.Path.Combine(RegistryStrings.PromotionDirectory, "app_suggestion_removed");
				string text2 = "";
				if (File.Exists(text))
				{
					text2 = File.ReadAllText(text);
				}
				List<string> list = new List<string>();
				if (!string.IsNullOrEmpty(text2))
				{
					list = AppIcon.DoDeserialize<List<string>>(text2);
				}
				if (!list.Contains(this.PackageName))
				{
					if (list.Count >= 20)
					{
						list.RemoveAt(0);
					}
					list.Add(this.PackageName);
				}
				using (XmlWriter xmlWriter = XmlWriter.Create(text, settings))
				{
					new XmlSerializer(typeof(List<string>)).Serialize(xmlWriter, list, namespaces);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in writing removed suggested app icon package name in file " + ex.ToString());
			}
		}

		// Token: 0x06000258 RID: 600 RVA: 0x00013374 File Offset: 0x00011574
		private static T DoDeserialize<T>(string data) where T : class
		{
			T result;
			using (XmlReader xmlReader = XmlReader.Create(new MemoryStream(Encoding.UTF8.GetBytes(data))))
			{
				result = (T)((object)new XmlSerializer(typeof(T)).Deserialize(xmlReader));
			}
			return result;
		}

		// Token: 0x06000259 RID: 601 RVA: 0x000133D0 File Offset: 0x000115D0
		private void AppIcon_UninstallConfirmationClicked(object sender, EventArgs e)
		{
			Logger.Info("Clicked app icon uninstall popup package name {0}", new object[]
			{
				this.PackageName
			});
			this.ParentWindow.mAppInstaller.UninstallApp(this.PackageName);
			this.ParentWindow.mWelcomeTab.mHomeApp.RemoveAppIcon(this.PackageName, null);
		}

		// Token: 0x0600025A RID: 602 RVA: 0x000038D2 File Offset: 0x00001AD2
		internal void HideUninstallButtons()
		{
			this.ParentWindow.StaticComponents.ShowUninstallButtons(false);
		}

		// Token: 0x0600025B RID: 603 RVA: 0x000038E5 File Offset: 0x00001AE5
		internal void ShowUninstallButtons()
		{
			this.ParentWindow.StaticComponents.ShowUninstallButtons(true);
		}

		// Token: 0x0600025C RID: 604 RVA: 0x00013428 File Offset: 0x00011628
		private void Button_MouseEnter(object sender, MouseEventArgs e)
		{
			if (this.IsDownloading)
			{
				this.ShowAppUninstallButton(true);
			}
			if (this.mIsDownLoadingFailed || this.mIsInstallingFailed)
			{
				this.mRetryGrid.Visibility = Visibility.Visible;
			}
			if (this.mBusyGrid.Visibility == Visibility.Visible)
			{
				return;
			}
			DropShadowEffect dropShadowEffect = new DropShadowEffect();
			BlueStacksUIBinding.BindColor(dropShadowEffect, DropShadowEffect.ColorProperty, "AppIconDropShadowBrush");
			dropShadowEffect.Direction = 270.0;
			dropShadowEffect.ShadowDepth = 1.0;
			dropShadowEffect.BlurRadius = 20.0;
			dropShadowEffect.Opacity = 1.0;
			this.mAppImageBorder.Effect = dropShadowEffect;
			ScaleTransform renderTransform = new ScaleTransform(1.02, 1.02);
			this.mAppImage.RenderTransformOrigin = new Point(0.5, 0.5);
			this.mAppImage.RenderTransform = renderTransform;
			this.AppNameTextBox.RenderTransformOrigin = new Point(0.5, 0.5);
			this.AppNameTextBox.RenderTransform = renderTransform;
			if (this.IsDockLocation)
			{
				this.ParentWindow.mWelcomeTab.mHomeApp.mDockIconText.Text = this.AppName;
				this.ParentWindow.mWelcomeTab.mHomeApp.mDockAppIconToolTipPopup.PlacementTarget = this.mAppImage;
				this.ParentWindow.mWelcomeTab.mHomeApp.mDockAppIconToolTipPopup.IsOpen = true;
				this.ParentWindow.mWelcomeTab.mHomeApp.mDockAppIconToolTipPopup.StaysOpen = true;
				dropShadowEffect.BlurRadius = 12.0;
				this.mAppImageBorder.Effect = dropShadowEffect;
			}
			if (this.IsAppSuggestionActive)
			{
				this.ParentWindow.mWelcomeTab.mHomeApp.OpenAppSuggestionPopup(this.AppSuggestionInfo, this.AppNameTextBox, true);
			}
		}

		// Token: 0x0600025D RID: 605 RVA: 0x00013608 File Offset: 0x00011808
		private void Button_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.ParentWindow.StaticComponents.IsDeleteButtonVisible)
			{
				this.ShowAppUninstallButton(false);
			}
			this.mRetryGrid.Visibility = Visibility.Hidden;
			ScaleTransform renderTransform = new ScaleTransform(1.0, 1.0);
			this.mAppImage.RenderTransformOrigin = new Point(0.0, 0.0);
			this.mAppImage.RenderTransform = renderTransform;
			this.AppNameTextBox.RenderTransformOrigin = new Point(0.0, 0.0);
			this.AppNameTextBox.RenderTransform = renderTransform;
			DropShadowEffect effect = new DropShadowEffect
			{
				Color = Colors.Black,
				Direction = 270.0,
				ShadowDepth = 1.0,
				BlurRadius = 6.0,
				Opacity = 0.3
			};
			this.mAppImageBorder.Effect = effect;
			if (this.IsAppSuggestionActive)
			{
				this.ParentWindow.mWelcomeTab.mHomeApp.CloseAppSuggestionPopup();
			}
			if (this.IsDockLocation)
			{
				this.ParentWindow.mWelcomeTab.mHomeApp.mDockAppIconToolTipPopup.IsOpen = false;
			}
		}

		// Token: 0x0600025E RID: 606 RVA: 0x00013748 File Offset: 0x00011948
		internal void DownloadStarted()
		{
			this.mIsAppInstalled = false;
			this.mIsDownLoadingFailed = false;
			this.IsDownloading = true;
			this.ParentWindow.mTopBar.mAppTabButtons.GoToTab("Home", true, false);
			this.mErrorGrid.Visibility = Visibility.Hidden;
			this.mProgressGrid.Visibility = Visibility.Visible;
		}

		// Token: 0x0600025F RID: 607 RVA: 0x000038F8 File Offset: 0x00001AF8
		internal void DownloadFailed()
		{
			this.mIsDownLoadingFailed = true;
			this.mErrorGrid.Visibility = Visibility.Visible;
		}

		// Token: 0x06000260 RID: 608 RVA: 0x0000390D File Offset: 0x00001B0D
		internal void UpdateAppDownloadProgress(int percent)
		{
			this.mProgressGrid.Visibility = Visibility.Visible;
			this.CustomProgressBar.Value = (double)percent;
		}

		// Token: 0x06000261 RID: 609 RVA: 0x00003928 File Offset: 0x00001B28
		internal void DownloadCompleted(string filePath)
		{
			this.mApkFilePath = filePath;
			this.IsDownloading = false;
			this.IsInstaling = true;
			this.mProgressGrid.Visibility = Visibility.Hidden;
			this.mBusyGrid.Visibility = Visibility.Visible;
		}

		// Token: 0x06000262 RID: 610 RVA: 0x00003957 File Offset: 0x00001B57
		internal void ApkInstallStart(string filePath)
		{
			this.ShowAppUninstallButton(false);
			this.mIsAppInstalled = false;
			this.IsInstaling = true;
			this.mApkFilePath = filePath;
			this.mIsInstallingFailed = false;
			this.mErrorGrid.Visibility = Visibility.Hidden;
			this.mBusyGrid.Visibility = Visibility.Visible;
		}

		// Token: 0x06000263 RID: 611 RVA: 0x00003994 File Offset: 0x00001B94
		internal void ApkInstallFailed()
		{
			if (!this.mIsAppInstalled)
			{
				this.mIsInstallingFailed = true;
				this.mBusyGrid.Visibility = Visibility.Hidden;
				this.mErrorGrid.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x06000264 RID: 612 RVA: 0x000039BD File Offset: 0x00001BBD
		internal void ApkInstallCompleted()
		{
			this.mIsAppInstalled = true;
			this.IsInstaling = false;
			this.mDownloader = null;
			this.mBusyGrid.Visibility = Visibility.Hidden;
		}

		// Token: 0x06000265 RID: 613 RVA: 0x000137A0 File Offset: 0x000119A0
		private void Button_Loaded(object sender, RoutedEventArgs e)
		{
			if (!DesignerProperties.GetIsInDesignMode(this))
			{
				base.Loaded -= this.Button_Loaded;
				this.ParentWindow.StaticComponents.ShowAllUninstallButtons += this.Button_MouseHoldAction;
				this.ParentWindow.StaticComponents.HideAllUninstallButtons += this.AppIcon_HideUninstallButton;
				if (this.IsGamepadCompatible)
				{
					this.mGamepadIcon.ImageName = (this.ParentWindow.IsGamepadConnected ? "apps_connected_icon" : "apps_disconnected_icon");
				}
			}
		}

		// Token: 0x06000266 RID: 614 RVA: 0x0001382C File Offset: 0x00011A2C
		internal void GifAppIconPlay()
		{
			try
			{
				this.mGifController = ImageBehavior.GetAnimationController(this.mAppImage);
				if (this.mGifController != null)
				{
					this.mGifController.Play();
				}
				else if (this.ImageName != null)
				{
					ImageSource value = new BitmapImage(new Uri(this.ImageName));
					ImageBehavior.SetAnimatedSource(this.mAppImage, value);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in animating appicon for package " + this.mPackageName + Environment.NewLine + ex.ToString());
			}
		}

		// Token: 0x06000267 RID: 615 RVA: 0x000138BC File Offset: 0x00011ABC
		internal void GifAppIconPause()
		{
			try
			{
				this.mGifController = ImageBehavior.GetAnimationController(this.mAppImage);
				this.mGifController.Pause();
			}
			catch (Exception ex)
			{
				Logger.Warning("Failed to pause gif. Err : " + ex.Message);
			}
		}

		// Token: 0x06000268 RID: 616 RVA: 0x00013910 File Offset: 0x00011B10
		private void GamepadIcon_MouseEnter(object sender, MouseEventArgs e)
		{
			this.mIconText.Text = (this.ParentWindow.IsGamepadConnected ? LocaleStrings.GetLocalizedString("STRING_GAMEPAD_CONNECTED") : LocaleStrings.GetLocalizedString("STRING_GAMEPAD_DISCONNECTED"));
			base.ToolTip = null;
			this.mGamePadToolTipPopup.PlacementTarget = this.mGamepadIcon;
			this.mGamePadToolTipPopup.IsOpen = true;
			this.mGamePadToolTipPopup.StaysOpen = true;
		}

		// Token: 0x06000269 RID: 617 RVA: 0x000039E0 File Offset: 0x00001BE0
		private void GamepadIcon_MouseLeave(object sender, MouseEventArgs e)
		{
			this.mGamePadToolTipPopup.IsOpen = false;
			base.ToolTip = this.AppName;
		}

		// Token: 0x04000119 RID: 281
		private MainWindow mMainWindow;

		// Token: 0x0400011A RID: 282
		private bool IsRerollIcon;

		// Token: 0x0400011E RID: 286
		private Thread threadShowingUninstallButton;

		// Token: 0x0400011F RID: 287
		internal bool mIsAppInstalled = true;

		// Token: 0x04000120 RID: 288
		private DownloadInstallApk mDownloader;

		// Token: 0x04000121 RID: 289
		private bool mIsDownLoadingFailed;

		// Token: 0x04000122 RID: 290
		private bool mIsInstallingFailed;

		// Token: 0x04000123 RID: 291
		private string mApkFilePath = string.Empty;

		// Token: 0x04000124 RID: 292
		private ImageAnimationController mGifController;

		// Token: 0x04000128 RID: 296
		internal bool mCustomPopup;

		// Token: 0x04000129 RID: 297
		private string mPackageName = string.Empty;

		// Token: 0x04000132 RID: 306
		private AppInfo mAppInfoItem;

		// Token: 0x04000133 RID: 307
		private string mPromotionId;

		// Token: 0x04000134 RID: 308
		internal AppSuggestionPromotion AppSuggestionInfo;
	}
}
