﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020000C0 RID: 192
	public class DMMFullScreenTopBar : UserControl, IComponentConnector
	{
		// Token: 0x060007E9 RID: 2025 RVA: 0x000070A8 File Offset: 0x000052A8
		public DMMFullScreenTopBar()
		{
			this.InitializeComponent();
		}

		// Token: 0x060007EA RID: 2026 RVA: 0x000070B6 File Offset: 0x000052B6
		internal void Init(MainWindow window)
		{
			this.ParentWindow = window;
			if (!DesignerProperties.GetIsInDesignMode(this) && !RegistryManager.Instance.UseEscapeToExitFullScreen)
			{
				this.mEscCheckbox.ImageName = "checkbox_new";
			}
			this.mVolumeBtn.ImageName = "volume_small";
		}

		// Token: 0x060007EB RID: 2027 RVA: 0x0002EDF0 File Offset: 0x0002CFF0
		private void mEscCheckbox_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (RegistryManager.Instance.UseEscapeToExitFullScreen)
			{
				this.mEscCheckbox.ImageName = "checkbox_new";
				RegistryManager.Instance.UseEscapeToExitFullScreen = false;
				return;
			}
			this.mEscCheckbox.ImageName = "checkbox_new_checked";
			RegistryManager.Instance.UseEscapeToExitFullScreen = true;
		}

		// Token: 0x060007EC RID: 2028 RVA: 0x000070F3 File Offset: 0x000052F3
		private void ScreenshotBtn_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mTopBarPopup.IsOpen = false;
			this.ParentWindow.mCommonHandler.ScreenShotButtonHandler();
		}

		// Token: 0x060007ED RID: 2029 RVA: 0x00007116 File Offset: 0x00005316
		private void VolumeBtn_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.mVolumePopup.IsOpen = !this.mVolumePopup.IsOpen;
		}

		// Token: 0x060007EE RID: 2030 RVA: 0x00007131 File Offset: 0x00005331
		private void WindowedBtn_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.FullScreenButtonHandler("fullscreentopbarDmm", "MouseClick");
		}

		// Token: 0x060007EF RID: 2031 RVA: 0x0000714D File Offset: 0x0000534D
		private void SettingsBtn_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.LaunchSettingsWindow();
		}

		// Token: 0x060007F0 RID: 2032 RVA: 0x0000715F File Offset: 0x0000535F
		internal void VolumeSlider_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow != null)
			{
				this.ParentWindow.mDmmBottomBar.VolumeSlider_PreviewMouseLeftButtonUp(sender, e);
			}
		}

		// Token: 0x060007F1 RID: 2033 RVA: 0x0000717B File Offset: 0x0000537B
		private void VolumeSliderImage_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.ParentWindow != null)
			{
				this.ParentWindow.mDmmBottomBar.VolumeSliderImage_PreviewMouseLeftButtonUp(sender, e);
			}
		}

		// Token: 0x060007F2 RID: 2034 RVA: 0x00007197 File Offset: 0x00005397
		private void SwitchKeyMapButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mCommonHandler.DMMSwitchKeyMapButtonHandler();
		}

		// Token: 0x060007F3 RID: 2035 RVA: 0x0002EE40 File Offset: 0x0002D040
		private void KeyMapButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mTopBarPopup.IsOpen = false;
			if (this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab != null && this.ParentWindow.mTopBar.mAppTabButtons.SelectedTab.PackageName != null)
			{
				this.ParentWindow.mCommonHandler.KeyMapButtonHandler("MouseClick", "fullscreentopbar");
			}
		}

		// Token: 0x060007F4 RID: 2036 RVA: 0x000071A9 File Offset: 0x000053A9
		private void TranslucentControlsButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.transSlider.Value = RegistryManager.Instance.TranslucentControlsTransparency;
			this.mChangeTransparencyPopup.PlacementTarget = this.mTranslucentControlsButton;
			this.mChangeTransparencyPopup.IsOpen = true;
		}

		// Token: 0x060007F5 RID: 2037 RVA: 0x000071DD File Offset: 0x000053DD
		internal void mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.ParentWindow.mDmmBottomBar.mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp(sender, e);
		}

		// Token: 0x060007F6 RID: 2038 RVA: 0x000071F1 File Offset: 0x000053F1
		internal void TransparencySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			this.ParentWindow.mDmmBottomBar.TransparencySlider_ValueChanged(sender, e);
		}

		// Token: 0x060007F7 RID: 2039 RVA: 0x0002EEAC File Offset: 0x0002D0AC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/dmmfullscreentopbar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060007F8 RID: 2040 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060007F9 RID: 2041 RVA: 0x0002EEDC File Offset: 0x0002D0DC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mEscCheckbox = (CustomPictureBox)target;
				this.mEscCheckbox.MouseLeftButtonUp += this.mEscCheckbox_MouseLeftButtonUp;
				return;
			case 2:
				this.mKeyMapSwitch = (CustomPictureBox)target;
				this.mKeyMapSwitch.PreviewMouseLeftButtonUp += this.SwitchKeyMapButton_PreviewMouseLeftButtonUp;
				return;
			case 3:
				this.mKeyMapButton = (CustomPictureBox)target;
				this.mKeyMapButton.PreviewMouseLeftButtonUp += this.KeyMapButton_PreviewMouseLeftButtonUp;
				return;
			case 4:
				this.mTranslucentControlsButton = (CustomPictureBox)target;
				this.mTranslucentControlsButton.PreviewMouseLeftButtonUp += this.TranslucentControlsButton_PreviewMouseLeftButtonUp;
				return;
			case 5:
				this.mScreenshotBtn = (CustomPictureBox)target;
				this.mScreenshotBtn.PreviewMouseLeftButtonUp += this.ScreenshotBtn_MouseUp;
				return;
			case 6:
				this.mVolumeBtn = (CustomPictureBox)target;
				this.mVolumeBtn.PreviewMouseLeftButtonUp += this.VolumeBtn_MouseUp;
				return;
			case 7:
				this.mWindowedBtn = (CustomPictureBox)target;
				this.mWindowedBtn.PreviewMouseLeftButtonUp += this.WindowedBtn_MouseUp;
				return;
			case 8:
				this.mSettingsBtn = (CustomPictureBox)target;
				this.mSettingsBtn.PreviewMouseLeftButtonUp += this.SettingsBtn_MouseUp;
				return;
			case 9:
				this.mVolumePopup = (CustomPopUp)target;
				return;
			case 10:
				this.volumeSliderImage = (CustomPictureBox)target;
				this.volumeSliderImage.PreviewMouseLeftButtonUp += this.VolumeSliderImage_PreviewMouseLeftButtonUp;
				return;
			case 11:
				this.mVolumeSlider = (Slider)target;
				this.mVolumeSlider.PreviewMouseLeftButtonUp += this.VolumeSlider_PreviewMouseLeftButtonUp;
				return;
			case 12:
				this.mChangeTransparencyPopup = (CustomPopUp)target;
				return;
			case 13:
				this.mTranslucentControlsSliderButton = (CustomPictureBox)target;
				this.mTranslucentControlsSliderButton.PreviewMouseLeftButtonUp += this.mTranslucentControlsSliderButton_PreviewMouseLeftButtonUp;
				return;
			case 14:
				this.transSlider = (Slider)target;
				this.transSlider.ValueChanged += this.TransparencySlider_ValueChanged;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x040004A7 RID: 1191
		private MainWindow ParentWindow;

		// Token: 0x040004A8 RID: 1192
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mEscCheckbox;

		// Token: 0x040004A9 RID: 1193
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mKeyMapSwitch;

		// Token: 0x040004AA RID: 1194
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mKeyMapButton;

		// Token: 0x040004AB RID: 1195
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mTranslucentControlsButton;

		// Token: 0x040004AC RID: 1196
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mScreenshotBtn;

		// Token: 0x040004AD RID: 1197
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mVolumeBtn;

		// Token: 0x040004AE RID: 1198
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mWindowedBtn;

		// Token: 0x040004AF RID: 1199
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mSettingsBtn;

		// Token: 0x040004B0 RID: 1200
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mVolumePopup;

		// Token: 0x040004B1 RID: 1201
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox volumeSliderImage;

		// Token: 0x040004B2 RID: 1202
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Slider mVolumeSlider;

		// Token: 0x040004B3 RID: 1203
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPopUp mChangeTransparencyPopup;

		// Token: 0x040004B4 RID: 1204
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mTranslucentControlsSliderButton;

		// Token: 0x040004B5 RID: 1205
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Slider transSlider;

		// Token: 0x040004B6 RID: 1206
		private bool _contentLoaded;
	}
}
