﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Markup;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x02000053 RID: 83
	public class MOBAOtherSettingsMoreInfoPopup : CustomPopUp, IComponentConnector
	{
		// Token: 0x060003F0 RID: 1008 RVA: 0x00004B67 File Offset: 0x00002D67
		public MOBAOtherSettingsMoreInfoPopup(CanvasElement canvasElement)
		{
			this.mCanvasElement = canvasElement;
			this.InitializeComponent();
			CanvasElement canvasElement2 = this.mCanvasElement;
			base.PlacementTarget = ((canvasElement2 != null) ? canvasElement2.MOBASkillSettingsPopup.mOtherSettingsHelpIcon : null);
		}

		// Token: 0x060003F1 RID: 1009 RVA: 0x0001A994 File Offset: 0x00018B94
		private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
		{
			try
			{
				Logger.Info("Opening url: " + e.Uri.AbsoluteUri);
				this.mCanvasElement.SendMOBAStats("read_more_clicked", "");
				BlueStacksUIUtils.OpenUrl(e.Uri.AbsoluteUri);
				e.Handled = true;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in opening url" + ex.ToString());
			}
		}

		// Token: 0x060003F2 RID: 1010 RVA: 0x0001AA14 File Offset: 0x00018C14
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/keymap/uielement/mobaothersettingsmoreinfopopup.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x060003F3 RID: 1011 RVA: 0x000039FA File Offset: 0x00001BFA
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x060003F4 RID: 1012 RVA: 0x0001AA44 File Offset: 0x00018C44
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder5 = (Border)target;
				return;
			case 2:
				this.mSettingsHyperLink = (Hyperlink)target;
				this.mSettingsHyperLink.RequestNavigate += this.Hyperlink_RequestNavigate;
				return;
			case 3:
				this.LeftArrowPath = (Path)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400021A RID: 538
		private CanvasElement mCanvasElement;

		// Token: 0x0400021B RID: 539
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder5;

		// Token: 0x0400021C RID: 540
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Hyperlink mSettingsHyperLink;

		// Token: 0x0400021D RID: 541
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Path LeftArrowPath;

		// Token: 0x0400021E RID: 542
		private bool _contentLoaded;
	}
}
