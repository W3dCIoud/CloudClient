﻿using System;
using Xilium.CefGlue;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x020001F9 RID: 505
	internal sealed class RenderProcessHandler : CefRenderProcessHandler
	{
		// Token: 0x06001277 RID: 4727 RVA: 0x00070E20 File Offset: 0x0006F020
		protected override void OnWebKitInitialized()
		{
			string javascriptCode = "var gmApi = function(jsonArg) {\r\n                    native function MyNativeFunction(jsonArg);\r\n                    return MyNativeFunction(jsonArg);\r\n                };";
			CefRuntime.RegisterExtension("MessageEvent", javascriptCode, this.myCefV8Handler);
			base.OnWebKitInitialized();
		}

		// Token: 0x04000BF4 RID: 3060
		private MyCustomCefV8Handler myCefV8Handler = new MyCustomCefV8Handler();
	}
}
