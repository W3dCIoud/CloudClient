﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using BlueStacks.Common;

namespace BlueStacks.BlueStacksUI
{
	// Token: 0x0200009D RID: 157
	public class MacroAddedDragControl : UserControl, IComponentConnector, IStyleConnector
	{
		// Token: 0x170001B2 RID: 434
		// (get) Token: 0x060005FE RID: 1534 RVA: 0x00005E3D File Offset: 0x0000403D
		public MergeMacroWindow MergeMacroWindow
		{
			get
			{
				if (this.mMergeMacroWindow == null)
				{
					this.mMergeMacroWindow = (Window.GetWindow(this) as MergeMacroWindow);
				}
				return this.mMergeMacroWindow;
			}
		}

		// Token: 0x060005FF RID: 1535 RVA: 0x00005E5E File Offset: 0x0000405E
		public MacroAddedDragControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000600 RID: 1536 RVA: 0x00023FDC File Offset: 0x000221DC
		internal void Init()
		{
			this.mListBox.DataContext = this.MergeMacroWindow.MergedMacroRecording.MergedMacroConfigurations;
			this.MergeMacroWindow.MergedMacroRecording.MergedMacroConfigurations.CollectionChanged -= this.Items_CollectionChanged;
			this.MergeMacroWindow.MergedMacroRecording.MergedMacroConfigurations.CollectionChanged += this.Items_CollectionChanged;
			this.Items_CollectionChanged(null, null);
		}

		// Token: 0x06000601 RID: 1537 RVA: 0x00024050 File Offset: 0x00022250
		private void Items_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
		{
			if (this.MergeMacroWindow.MergedMacroRecording.MergedMacroConfigurations.Count > 0)
			{
				this.mNoMergeMacroGrid.Visibility = Visibility.Collapsed;
				this.mListBox.Visibility = Visibility.Visible;
				return;
			}
			this.mNoMergeMacroGrid.Visibility = Visibility.Visible;
			this.mListBox.Visibility = Visibility.Collapsed;
		}

		// Token: 0x06000602 RID: 1538 RVA: 0x000240A8 File Offset: 0x000222A8
		private void ListBox_PreviewMouseMove(object sender, MouseEventArgs e)
		{
			Point position = e.GetPosition(null);
			Vector vector = this._dragStartPoint - position;
			if (e.LeftButton == MouseButtonState.Pressed && (Math.Abs(vector.X) > SystemParameters.MinimumHorizontalDragDistance || Math.Abs(vector.Y) > SystemParameters.MinimumVerticalDragDistance))
			{
				ListBoxItem listBoxItem = WpfUtils.FindVisualParent<ListBoxItem>((DependencyObject)e.OriginalSource);
				if (listBoxItem != null)
				{
					DragDrop.DoDragDrop(listBoxItem, listBoxItem.DataContext, DragDropEffects.Move);
				}
			}
		}

		// Token: 0x06000603 RID: 1539 RVA: 0x00005E6C File Offset: 0x0000406C
		private void ListBoxItem_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			this._dragStartPoint = e.GetPosition(null);
		}

		// Token: 0x06000604 RID: 1540 RVA: 0x0002411C File Offset: 0x0002231C
		private void ListBoxItem_Drop(object sender, DragEventArgs e)
		{
			this.UnsetMarginDuringDrag(null);
			if (sender is ListBoxItem)
			{
				MergedMacroConfiguration mergedMacroConfiguration = e.Data.GetData(typeof(MergedMacroConfiguration)) as MergedMacroConfiguration;
				MergedMacroConfiguration item = ((ListBoxItem)sender).DataContext as MergedMacroConfiguration;
				int sourceIndex = this.mListBox.Items.IndexOf(mergedMacroConfiguration);
				int targetIndex = this.mListBox.Items.IndexOf(item);
				this.Move(mergedMacroConfiguration, sourceIndex, targetIndex);
			}
		}

		// Token: 0x06000605 RID: 1541 RVA: 0x00024194 File Offset: 0x00022394
		private void ListBoxItem_DragOver(object sender, DragEventArgs e)
		{
			if (sender is ListBoxItem)
			{
				MergedMacroConfiguration item = e.Data.GetData(typeof(MergedMacroConfiguration)) as MergedMacroConfiguration;
				ListBoxItem listBoxItem = (ListBoxItem)sender;
				MergedMacroConfiguration item2 = ((ListBoxItem)sender).DataContext as MergedMacroConfiguration;
				int num = this.mListBox.Items.IndexOf(item);
				int num2 = this.mListBox.Items.IndexOf(item2);
				if (num2 < num)
				{
					(listBoxItem.Template.FindName("mMainGrid", listBoxItem) as Grid).Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
				}
				else if (num2 > num)
				{
					(listBoxItem.Template.FindName("mMainGrid", listBoxItem) as Grid).Margin = new Thickness(0.0, -1.0, 0.0, 10.0);
				}
				else
				{
					(listBoxItem.Template.FindName("mMainGrid", listBoxItem) as Grid).Margin = new Thickness(0.0, -1.0, 0.0, 0.0);
				}
				this.UnsetMarginDuringDrag(listBoxItem);
			}
		}

		// Token: 0x06000606 RID: 1542 RVA: 0x000242E8 File Offset: 0x000224E8
		private void UnsetMarginDuringDrag(ListBoxItem neglectItem = null)
		{
			foreach (object item in ((IEnumerable)this.mListBox.Items))
			{
				ListBoxItem listBoxItem = this.mListBox.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
				if (neglectItem == null || listBoxItem != neglectItem)
				{
					(listBoxItem.Template.FindName("mMainGrid", listBoxItem) as Grid).Margin = new Thickness(0.0, -1.0, 0.0, 0.0);
				}
			}
		}

		// Token: 0x06000607 RID: 1543 RVA: 0x0002439C File Offset: 0x0002259C
		private void Move(MergedMacroConfiguration source, int sourceIndex, int targetIndex)
		{
			if (sourceIndex < targetIndex)
			{
				ObservableCollection<MergedMacroConfiguration> observableCollection = this.mListBox.DataContext as ObservableCollection<MergedMacroConfiguration>;
				if (observableCollection != null)
				{
					observableCollection.Insert(targetIndex + 1, source);
					observableCollection.RemoveAt(sourceIndex);
					return;
				}
			}
			else
			{
				ObservableCollection<MergedMacroConfiguration> observableCollection2 = this.mListBox.DataContext as ObservableCollection<MergedMacroConfiguration>;
				if (observableCollection2 != null)
				{
					int num = sourceIndex + 1;
					if (observableCollection2.Count + 1 > num)
					{
						observableCollection2.Insert(targetIndex, source);
						observableCollection2.RemoveAt(num);
					}
				}
			}
		}

		// Token: 0x06000608 RID: 1544 RVA: 0x00024408 File Offset: 0x00022608
		private void ListBox_DragOver(object sender, DragEventArgs e)
		{
			ListBox listBox = sender as ListBox;
			ScrollViewer scrollViewer = WpfUtils.FindVisualChild<ScrollViewer>(listBox);
			double num = 15.0;
			double y = e.GetPosition(listBox).Y;
			double num2 = 10.0;
			if (y < num)
			{
				scrollViewer.ScrollToVerticalOffset(scrollViewer.VerticalOffset - num2);
				return;
			}
			if (y > listBox.ActualHeight - num)
			{
				scrollViewer.ScrollToVerticalOffset(scrollViewer.VerticalOffset + num2);
			}
		}

		// Token: 0x06000609 RID: 1545 RVA: 0x00024478 File Offset: 0x00022678
		private void Group_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			CustomPictureBox customPictureBox = sender as CustomPictureBox;
			if (customPictureBox != null)
			{
				ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "merge_group", null, null, null, null, null);
				MergedMacroConfiguration item = customPictureBox.DataContext as MergedMacroConfiguration;
				int num = this.mListBox.Items.IndexOf(item);
				this.Merge(num, num - 1);
			}
		}

		// Token: 0x0600060A RID: 1546 RVA: 0x000244E0 File Offset: 0x000226E0
		private void Merge(int sourceIndex, int targetIndex)
		{
			ObservableCollection<MergedMacroConfiguration> observableCollection = this.mListBox.DataContext as ObservableCollection<MergedMacroConfiguration>;
			if (observableCollection != null)
			{
				foreach (string item in observableCollection[sourceIndex].MacrosToRun)
				{
					observableCollection[targetIndex].MacrosToRun.Add(item);
				}
				observableCollection.RemoveAt(sourceIndex);
				MacroAddedDragControl.SetDefaultPropertiesForMergedMacroConfig(observableCollection[targetIndex]);
			}
		}

		// Token: 0x0600060B RID: 1547 RVA: 0x00024568 File Offset: 0x00022768
		private void UnGroup_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			CustomPictureBox customPictureBox = sender as CustomPictureBox;
			if (customPictureBox != null)
			{
				MergedMacroConfiguration mergedMacroConfiguration = customPictureBox.DataContext as MergedMacroConfiguration;
				int sourceIndex = this.mListBox.Items.IndexOf(mergedMacroConfiguration);
				this.UnMerge(mergedMacroConfiguration, sourceIndex);
			}
		}

		// Token: 0x0600060C RID: 1548 RVA: 0x00005E7B File Offset: 0x0000407B
		private static void SetDefaultPropertiesForMergedMacroConfig(MergedMacroConfiguration config)
		{
			config.LoopCount = 1;
			config.LoopInterval = 0;
			config.Acceleration = 1.0;
			config.DelayNextScript = 0;
		}

		// Token: 0x0600060D RID: 1549 RVA: 0x000245A8 File Offset: 0x000227A8
		private void UnMerge(MergedMacroConfiguration source, int sourceIndex)
		{
			ObservableCollection<MergedMacroConfiguration> observableCollection = this.mListBox.DataContext as ObservableCollection<MergedMacroConfiguration>;
			if (observableCollection != null)
			{
				MacroAddedDragControl.SetDefaultPropertiesForMergedMacroConfig(source);
				for (int i = 0; i < source.MacrosToRun.Count; i++)
				{
					string item = source.MacrosToRun[i];
					MergedMacroConfiguration mergedMacroConfiguration = new MergedMacroConfiguration();
					MergeMacroWindow mergeMacroWindow = this.MergeMacroWindow;
					int mAddedMacroTag = mergeMacroWindow.mAddedMacroTag;
					mergeMacroWindow.mAddedMacroTag = mAddedMacroTag + 1;
					mergedMacroConfiguration.Tag = mAddedMacroTag;
					MergedMacroConfiguration mergedMacroConfiguration2 = mergedMacroConfiguration;
					mergedMacroConfiguration2.MacrosToRun.Add(item);
					observableCollection.Insert(sourceIndex + i + 1, mergedMacroConfiguration2);
				}
				observableCollection.RemoveAt(sourceIndex);
			}
		}

		// Token: 0x0600060E RID: 1550 RVA: 0x00024638 File Offset: 0x00022838
		private void Remove_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			CustomPictureBox customPictureBox = sender as CustomPictureBox;
			if (customPictureBox != null)
			{
				MergedMacroConfiguration item = customPictureBox.DataContext as MergedMacroConfiguration;
				int index = this.mListBox.Items.IndexOf(item);
				(this.mListBox.DataContext as ObservableCollection<MergedMacroConfiguration>).RemoveAt(index);
				this.MergeMacroWindow.MergedMacroRecording.MergedMacroConfigurations.Remove(item);
			}
		}

		// Token: 0x0600060F RID: 1551 RVA: 0x0002469C File Offset: 0x0002289C
		private void Settings_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			CustomPictureBox customPictureBox = sender as CustomPictureBox;
			if (customPictureBox != null)
			{
				ListBoxItem listBoxItem = WpfUtils.FindVisualParent<ListBoxItem>(customPictureBox);
				MergedMacroConfiguration mergedMacroConfiguration = listBoxItem.DataContext as MergedMacroConfiguration;
				mergedMacroConfiguration.IsSettingsVisible = !mergedMacroConfiguration.IsSettingsVisible;
				(listBoxItem.Template.FindName("mMacroSettingsImage", listBoxItem) as CustomPictureBox).ImageName = (mergedMacroConfiguration.IsSettingsVisible ? "outline_settings_collapse" : "outline_settings_expand");
				ClientStats.SendMiscellaneousStatsAsync("MacroOperations", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, mergedMacroConfiguration.IsSettingsVisible ? "merge_dropdown_expand" : "merge_dropdown_collapse", null, null, null, null, null);
				foreach (object item in ((IEnumerable)this.mListBox.Items))
				{
					ListBoxItem listBoxItem2 = this.mListBox.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
					if (listBoxItem2 != listBoxItem)
					{
						(listBoxItem2.DataContext as MergedMacroConfiguration).IsSettingsVisible = false;
						(listBoxItem2.Template.FindName("mMacroSettingsImage", listBoxItem2) as CustomPictureBox).ImageName = "outline_settings_expand";
					}
				}
			}
		}

		// Token: 0x06000610 RID: 1552 RVA: 0x00005EA1 File Offset: 0x000040A1
		private void NumericTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
		{
			e.Handled = !this.IsTextAllowed(e.Text);
		}

		// Token: 0x06000611 RID: 1553 RVA: 0x000247DC File Offset: 0x000229DC
		private void NumericTextBox_Pasting(object sender, DataObjectPastingEventArgs e)
		{
			if (e.DataObject.GetDataPresent(typeof(string)))
			{
				string text = (string)e.DataObject.GetData(typeof(string));
				if (!this.IsTextAllowed(text))
				{
					e.CancelCommand();
					return;
				}
			}
			else
			{
				e.CancelCommand();
			}
		}

		// Token: 0x06000612 RID: 1554 RVA: 0x00005EB8 File Offset: 0x000040B8
		private void NumericTextBox_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Space)
			{
				e.Handled = true;
			}
		}

		// Token: 0x06000613 RID: 1555 RVA: 0x00005ECB File Offset: 0x000040CB
		private bool IsTextAllowed(string text)
		{
			return new Regex("^[0-9]+$").IsMatch(text) && text.IndexOf(' ') == -1;
		}

		// Token: 0x06000614 RID: 1556 RVA: 0x00005EEC File Offset: 0x000040EC
		private void MacroAddDragControl_Loaded(object sender, RoutedEventArgs e)
		{
			this.mListBox.DataContext = this.MergeMacroWindow.MergedMacroRecording.MergedMacroConfigurations;
		}

		// Token: 0x06000615 RID: 1557 RVA: 0x00024834 File Offset: 0x00022A34
		private void LoopCountTextBox_TextChanged(object sender, TextChangedEventArgs e)
		{
			CustomTextBox customTextBox = sender as CustomTextBox;
			customTextBox.InputTextValidity = ((string.IsNullOrEmpty(customTextBox.Text) || customTextBox.Text == "0") ? TextValidityOptions.Error : TextValidityOptions.Success);
		}

		// Token: 0x06000616 RID: 1558 RVA: 0x00005F09 File Offset: 0x00004109
		private void MacroName_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			(sender as TextBlock).SetTextblockTooltip();
		}

		// Token: 0x06000617 RID: 1559 RVA: 0x00024874 File Offset: 0x00022A74
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/Bluestacks;component/controls/macroaddeddragcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000618 RID: 1560 RVA: 0x000248A4 File Offset: 0x00022AA4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				((MacroAddedDragControl)target).Loaded += this.MacroAddDragControl_Loaded;
				return;
			}
			if (connectionId == 12)
			{
				this.mNoMergeMacroGrid = (Border)target;
				return;
			}
			if (connectionId != 13)
			{
				this._contentLoaded = true;
				return;
			}
			this.mListBox = (ListBox)target;
			this.mListBox.DragOver += this.ListBox_DragOver;
		}

		// Token: 0x06000619 RID: 1561 RVA: 0x00024914 File Offset: 0x00022B14
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 2:
				((TextBlock)target).SizeChanged += this.MacroName_SizeChanged;
				return;
			case 3:
			{
				EventSetter eventSetter = new EventSetter();
				eventSetter.Event = UIElement.DragOverEvent;
				eventSetter.Handler = new DragEventHandler(this.ListBoxItem_DragOver);
				((Style)target).Setters.Add(eventSetter);
				eventSetter = new EventSetter();
				eventSetter.Event = UIElement.DropEvent;
				eventSetter.Handler = new DragEventHandler(this.ListBoxItem_Drop);
				((Style)target).Setters.Add(eventSetter);
				return;
			}
			case 4:
				((CustomPictureBox)target).PreviewMouseLeftButtonDown += this.ListBoxItem_PreviewMouseLeftButtonDown;
				((CustomPictureBox)target).PreviewMouseMove += this.ListBox_PreviewMouseMove;
				return;
			case 5:
				((CustomPictureBox)target).PreviewMouseLeftButtonUp += this.UnGroup_PreviewMouseLeftButtonUp;
				return;
			case 6:
				((CustomPictureBox)target).PreviewMouseLeftButtonUp += this.Settings_PreviewMouseLeftButtonUp;
				return;
			case 7:
				((CustomPictureBox)target).PreviewMouseLeftButtonUp += this.Remove_PreviewMouseLeftButtonUp;
				return;
			case 8:
				((CustomTextBox)target).PreviewTextInput += this.NumericTextBox_PreviewTextInput;
				((CustomTextBox)target).AddHandler(DataObject.PastingEvent, new DataObjectPastingEventHandler(this.NumericTextBox_Pasting));
				((CustomTextBox)target).PreviewKeyDown += this.NumericTextBox_KeyDown;
				((CustomTextBox)target).TextChanged += this.LoopCountTextBox_TextChanged;
				return;
			case 9:
				((CustomTextBox)target).PreviewTextInput += this.NumericTextBox_PreviewTextInput;
				((CustomTextBox)target).AddHandler(DataObject.PastingEvent, new DataObjectPastingEventHandler(this.NumericTextBox_Pasting));
				((CustomTextBox)target).PreviewKeyDown += this.NumericTextBox_KeyDown;
				return;
			case 10:
				((CustomTextBox)target).PreviewTextInput += this.NumericTextBox_PreviewTextInput;
				((CustomTextBox)target).AddHandler(DataObject.PastingEvent, new DataObjectPastingEventHandler(this.NumericTextBox_Pasting));
				((CustomTextBox)target).PreviewKeyDown += this.NumericTextBox_KeyDown;
				return;
			case 11:
				((CustomPictureBox)target).PreviewMouseLeftButtonUp += this.Group_PreviewMouseLeftButtonUp;
				return;
			default:
				return;
			}
		}

		// Token: 0x04000353 RID: 851
		private MergeMacroWindow mMergeMacroWindow;

		// Token: 0x04000354 RID: 852
		private Point _dragStartPoint;

		// Token: 0x04000355 RID: 853
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mNoMergeMacroGrid;

		// Token: 0x04000356 RID: 854
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal ListBox mListBox;

		// Token: 0x04000357 RID: 855
		private bool _contentLoaded;
	}
}
