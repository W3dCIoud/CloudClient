﻿using System;

// Token: 0x0200000B RID: 11
[Serializable]
public class DontForwardKeys : IMAction
{
}
