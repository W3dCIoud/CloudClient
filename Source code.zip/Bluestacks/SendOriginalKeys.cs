﻿using System;

// Token: 0x02000011 RID: 17
[Serializable]
public class SendOriginalKeys : IMAction
{
	// Token: 0x17000094 RID: 148
	// (get) Token: 0x06000138 RID: 312 RVA: 0x00002CBC File Offset: 0x00000EBC
	// (set) Token: 0x06000139 RID: 313 RVA: 0x00002CC4 File Offset: 0x00000EC4
	public string Comments
	{
		get
		{
			return this.mComments;
		}
		set
		{
			this.mComments = value;
		}
	}

	// Token: 0x04000094 RID: 148
	private string mComments;
}
