﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

// Token: 0x02000009 RID: 9
[Description("Independent")]
[Serializable]
public class MOBADpad : IMAction
{
	// Token: 0x0600009D RID: 157 RVA: 0x00011428 File Offset: 0x0000F628
	public MOBADpad()
	{
		this.IsChildAction = true;
		base.Type = KeyActionType.MOBADpad;
		MOBADpad.sListMOBADpad.Add(this);
	}

	// Token: 0x0600009E RID: 158 RVA: 0x0001149C File Offset: 0x0000F69C
	public MOBADpad(Dpad action)
	{
		this.IsChildAction = true;
		base.Type = KeyActionType.MOBADpad;
		MOBADpad.sListMOBADpad.Add(this);
		this.mDpad = action;
		this.ParentAction = action;
	}

	// Token: 0x1700004A RID: 74
	// (get) Token: 0x0600009F RID: 159 RVA: 0x0000268F File Offset: 0x0000088F
	// (set) Token: 0x060000A0 RID: 160 RVA: 0x00002697 File Offset: 0x00000897
	public double X { get; set; } = -1.0;

	// Token: 0x1700004B RID: 75
	// (get) Token: 0x060000A1 RID: 161 RVA: 0x000026A0 File Offset: 0x000008A0
	// (set) Token: 0x060000A2 RID: 162 RVA: 0x000026A8 File Offset: 0x000008A8
	public double Y { get; set; } = -1.0;

	// Token: 0x1700004C RID: 76
	// (get) Token: 0x060000A3 RID: 163 RVA: 0x000026B1 File Offset: 0x000008B1
	// (set) Token: 0x060000A4 RID: 164 RVA: 0x000026B9 File Offset: 0x000008B9
	[Description("IMAP_CanvasElementY")]
	public double OriginX { get; set; } = -1.0;

	// Token: 0x1700004D RID: 77
	// (get) Token: 0x060000A5 RID: 165 RVA: 0x000026C2 File Offset: 0x000008C2
	// (set) Token: 0x060000A6 RID: 166 RVA: 0x000026CA File Offset: 0x000008CA
	[Description("IMAP_CanvasElementX")]
	public double OriginY { get; set; }

	// Token: 0x1700004E RID: 78
	// (get) Token: 0x060000A7 RID: 167 RVA: 0x000026D3 File Offset: 0x000008D3
	internal string KeyMove { get; } = "MouseRButton";

	// Token: 0x1700004F RID: 79
	// (get) Token: 0x060000A8 RID: 168 RVA: 0x000026DB File Offset: 0x000008DB
	// (set) Token: 0x060000A9 RID: 169 RVA: 0x000026FA File Offset: 0x000008FA
	public double XRadius
	{
		get
		{
			if (this.mDpad == null)
			{
				return -1.0;
			}
			return this.mDpad.XRadius;
		}
		set
		{
			if (this.mDpad != null)
			{
				this.mDpad.XRadius = value;
			}
		}
	}

	// Token: 0x17000050 RID: 80
	// (get) Token: 0x060000AA RID: 170 RVA: 0x00002710 File Offset: 0x00000910
	// (set) Token: 0x060000AB RID: 171 RVA: 0x0000272F File Offset: 0x0000092F
	public double DpadSpeed
	{
		get
		{
			if (this.mDpad == null)
			{
				return -1.0;
			}
			return this.mDpad.Speed;
		}
		set
		{
			if (this.mDpad != null)
			{
				this.mDpad.Speed = value;
			}
		}
	}

	// Token: 0x17000051 RID: 81
	// (get) Token: 0x060000AC RID: 172 RVA: 0x00002745 File Offset: 0x00000945
	// (set) Token: 0x060000AD RID: 173 RVA: 0x0000274D File Offset: 0x0000094D
	public double CharSpeed { get; set; } = 10.0;

	// Token: 0x0400004D RID: 77
	internal Dpad mDpad;

	// Token: 0x0400004E RID: 78
	internal static List<MOBADpad> sListMOBADpad = new List<MOBADpad>();
}
