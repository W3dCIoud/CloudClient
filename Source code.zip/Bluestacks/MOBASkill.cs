﻿using System;
using System.ComponentModel;
using System.Windows.Input;

// Token: 0x0200000A RID: 10
[Description("ParentElement")]
[Serializable]
public class MOBASkill : IMAction
{
	// Token: 0x17000052 RID: 82
	// (get) Token: 0x060000AF RID: 175 RVA: 0x00011520 File Offset: 0x0000F720
	internal static MOBADpad MOBADpad
	{
		get
		{
			foreach (MOBADpad mobadpad in MOBADpad.sListMOBADpad)
			{
				if (mobadpad.OriginX != -1.0 && mobadpad.OriginY != -1.0)
				{
					return mobadpad;
				}
			}
			return null;
		}
	}

	// Token: 0x17000053 RID: 83
	// (get) Token: 0x060000B0 RID: 176 RVA: 0x00002762 File Offset: 0x00000962
	// (set) Token: 0x060000B1 RID: 177 RVA: 0x0000276A File Offset: 0x0000096A
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X { get; set; } = -1.0;

	// Token: 0x17000054 RID: 84
	// (get) Token: 0x060000B2 RID: 178 RVA: 0x00002773 File Offset: 0x00000973
	// (set) Token: 0x060000B3 RID: 179 RVA: 0x0000277B File Offset: 0x0000097B
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y { get; set; } = -1.0;

	// Token: 0x17000055 RID: 85
	// (get) Token: 0x060000B4 RID: 180 RVA: 0x00002784 File Offset: 0x00000984
	// (set) Token: 0x060000B5 RID: 181 RVA: 0x0000278C File Offset: 0x0000098C
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyActivate { get; set; }

	// Token: 0x17000056 RID: 86
	// (get) Token: 0x060000B6 RID: 182 RVA: 0x00002795 File Offset: 0x00000995
	// (set) Token: 0x060000B7 RID: 183 RVA: 0x0000279D File Offset: 0x0000099D
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyActivate_alt1 { get; set; }

	// Token: 0x17000057 RID: 87
	// (get) Token: 0x060000B8 RID: 184 RVA: 0x000027A6 File Offset: 0x000009A6
	// (set) Token: 0x060000B9 RID: 185 RVA: 0x000027AE File Offset: 0x000009AE
	[Description("IMAP_DeveloperModeUIElemnt")]
	[Category("Fields")]
	public string KeyAutocastToggle { get; set; }

	// Token: 0x17000058 RID: 88
	// (get) Token: 0x060000BA RID: 186 RVA: 0x000027B7 File Offset: 0x000009B7
	// (set) Token: 0x060000BB RID: 187 RVA: 0x000027BF File Offset: 0x000009BF
	[Description("IMAP_DeveloperModeUIElemnt")]
	[Category("Fields")]
	public string KeyAutocastToggle_alt1 { get; set; }

	// Token: 0x17000059 RID: 89
	// (get) Token: 0x060000BC RID: 188 RVA: 0x000027C8 File Offset: 0x000009C8
	// (set) Token: 0x060000BD RID: 189 RVA: 0x000027D0 File Offset: 0x000009D0
	[Description("IMAP_DeveloperModeUIElemnt")]
	[Category("Fields")]
	public double YAxisRatio { get; set; }

	// Token: 0x1700005A RID: 90
	// (get) Token: 0x060000BE RID: 190 RVA: 0x000027D9 File Offset: 0x000009D9
	// (set) Token: 0x060000BF RID: 191 RVA: 0x000027E1 File Offset: 0x000009E1
	public string KeyCancel { get; set; } = IMAPKeys.GetStringForFile(Key.Space);

	// Token: 0x1700005B RID: 91
	// (get) Token: 0x060000C0 RID: 192 RVA: 0x000027EA File Offset: 0x000009EA
	// (set) Token: 0x060000C1 RID: 193 RVA: 0x000027F2 File Offset: 0x000009F2
	public string KeyCancel_alt1 { get; set; } = string.Empty;

	// Token: 0x1700005C RID: 92
	// (get) Token: 0x060000C2 RID: 194 RVA: 0x000027FB File Offset: 0x000009FB
	// (set) Token: 0x060000C3 RID: 195 RVA: 0x00002803 File Offset: 0x00000A03
	public double CancelX
	{
		get
		{
			return this.mCancelX;
		}
		set
		{
			this.mCancelX = value;
			this.CheckSkillCancel();
		}
	}

	// Token: 0x1700005D RID: 93
	// (get) Token: 0x060000C4 RID: 196 RVA: 0x00002812 File Offset: 0x00000A12
	// (set) Token: 0x060000C5 RID: 197 RVA: 0x0000281A File Offset: 0x00000A1A
	public double CancelY
	{
		get
		{
			return this.mCancelY;
		}
		set
		{
			this.mCancelY = value;
			this.CheckSkillCancel();
		}
	}

	// Token: 0x1700005E RID: 94
	// (get) Token: 0x060000C6 RID: 198 RVA: 0x00002829 File Offset: 0x00000A29
	// (set) Token: 0x060000C7 RID: 199 RVA: 0x00002846 File Offset: 0x00000A46
	public static double OriginX
	{
		get
		{
			if (MOBASkill.MOBADpad == null)
			{
				return -1.0;
			}
			return MOBASkill.MOBADpad.OriginX;
		}
		set
		{
			if (MOBASkill.MOBADpad != null)
			{
				MOBASkill.MOBADpad.OriginX = value;
			}
		}
	}

	// Token: 0x1700005F RID: 95
	// (get) Token: 0x060000C8 RID: 200 RVA: 0x0000285A File Offset: 0x00000A5A
	// (set) Token: 0x060000C9 RID: 201 RVA: 0x00002877 File Offset: 0x00000A77
	public static double OriginY
	{
		get
		{
			if (MOBASkill.MOBADpad == null)
			{
				return -1.0;
			}
			return MOBASkill.MOBADpad.OriginY;
		}
		set
		{
			if (MOBASkill.MOBADpad != null)
			{
				MOBASkill.MOBADpad.OriginY = value;
			}
		}
	}

	// Token: 0x17000060 RID: 96
	// (get) Token: 0x060000CA RID: 202 RVA: 0x0000288B File Offset: 0x00000A8B
	// (set) Token: 0x060000CB RID: 203 RVA: 0x00002893 File Offset: 0x00000A93
	[Description("IMAP_CanvasElementRadiusIMAP_PopupUIElement")]
	[Category("Fields")]
	public double XRadius { get; set; } = 5.0;

	// Token: 0x17000061 RID: 97
	// (get) Token: 0x060000CC RID: 204 RVA: 0x0000289C File Offset: 0x00000A9C
	// (set) Token: 0x060000CD RID: 205 RVA: 0x000028A4 File Offset: 0x00000AA4
	[Description("IMAP_DeveloperModeUIElemnt")]
	[Category("Fields")]
	public double DeadZoneRadius { get; set; }

	// Token: 0x17000062 RID: 98
	// (get) Token: 0x060000CE RID: 206 RVA: 0x000028AD File Offset: 0x00000AAD
	// (set) Token: 0x060000CF RID: 207 RVA: 0x000028B5 File Offset: 0x00000AB5
	[Description("IMAP_DeveloperModeUIElemnt")]
	[Category("Fields")]
	public double CancelSpeed { get; set; } = 500.0;

	// Token: 0x17000063 RID: 99
	// (get) Token: 0x060000D0 RID: 208 RVA: 0x000028BE File Offset: 0x00000ABE
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	internal bool IsCancelSkillEnabled
	{
		get
		{
			return this.mMOBASkillCancel != null;
		}
	}

	// Token: 0x060000D1 RID: 209 RVA: 0x000028C9 File Offset: 0x00000AC9
	private void CheckSkillCancel()
	{
		if (this.mCancelX == -1.0 && this.mCancelY == -1.0)
		{
			this.mMOBASkillCancel = null;
			return;
		}
		if (this.mMOBASkillCancel == null)
		{
			this.mMOBASkillCancel = new MOBASkillCancel(this);
		}
	}

	// Token: 0x17000064 RID: 100
	// (get) Token: 0x060000D2 RID: 210 RVA: 0x00002909 File Offset: 0x00000B09
	// (set) Token: 0x060000D3 RID: 211 RVA: 0x00002911 File Offset: 0x00000B11
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool ShowOnOverlay
	{
		get
		{
			return this.mShowOnOverlay;
		}
		set
		{
			this.mShowOnOverlay = value;
		}
	}

	// Token: 0x17000065 RID: 101
	// (get) Token: 0x060000D4 RID: 212 RVA: 0x0000291A File Offset: 0x00000B1A
	// (set) Token: 0x060000D5 RID: 213 RVA: 0x00002922 File Offset: 0x00000B22
	[Description("IMAP_DeveloperModeUIElemnt")]
	[Category("Fields")]
	public int NoCancelOnSwitch { get; set; }

	// Token: 0x17000066 RID: 102
	// (get) Token: 0x060000D6 RID: 214 RVA: 0x0000292B File Offset: 0x00000B2B
	// (set) Token: 0x060000D7 RID: 215 RVA: 0x00002933 File Offset: 0x00000B33
	[Description("IMAP_DeveloperModeUIElemnt")]
	[Category("Fields")]
	public int NoCancelTime { get; set; }

	// Token: 0x17000067 RID: 103
	// (get) Token: 0x060000D8 RID: 216 RVA: 0x0000293C File Offset: 0x00000B3C
	// (set) Token: 0x060000D9 RID: 217 RVA: 0x00002944 File Offset: 0x00000B44
	[Description("IMAP_DeveloperModeUIElemnt")]
	[Category("Fields")]
	public bool AutoAttack { get; set; }

	// Token: 0x17000068 RID: 104
	// (get) Token: 0x060000DA RID: 218 RVA: 0x0000294D File Offset: 0x00000B4D
	// (set) Token: 0x060000DB RID: 219 RVA: 0x00002955 File Offset: 0x00000B55
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool StopMOBADpad { get; set; }

	// Token: 0x17000069 RID: 105
	// (get) Token: 0x060000DC RID: 220 RVA: 0x0000295E File Offset: 0x00000B5E
	// (set) Token: 0x060000DD RID: 221 RVA: 0x00002966 File Offset: 0x00000B66
	[Description("IMAP_DeveloperModeUIElemnt")]
	[Category("Fields")]
	public bool AdvancedMode { get; set; } = true;

	// Token: 0x1700006A RID: 106
	// (get) Token: 0x060000DE RID: 222 RVA: 0x0000296F File Offset: 0x00000B6F
	// (set) Token: 0x060000DF RID: 223 RVA: 0x00002977 File Offset: 0x00000B77
	[Description("IMAP_DeveloperModeUIElemnt")]
	[Category("Fields")]
	public bool AutocastEnabled { get; set; } = true;

	// Token: 0x04000055 RID: 85
	internal MOBASkillCancel mMOBASkillCancel;

	// Token: 0x0400005F RID: 95
	private double mCancelX = -1.0;

	// Token: 0x04000060 RID: 96
	private double mCancelY = -1.0;

	// Token: 0x04000064 RID: 100
	internal bool mShowOnOverlay = true;
}
