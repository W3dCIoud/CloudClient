﻿using System;
using System.Collections.Generic;
using BlueStacks.Common;
using Newtonsoft.Json.Linq;

// Token: 0x0200001E RID: 30
[Serializable]
public class IMControlScheme
{
	// Token: 0x170000E8 RID: 232
	// (get) Token: 0x060001F6 RID: 502 RVA: 0x00003489 File Offset: 0x00001689
	// (set) Token: 0x060001F7 RID: 503 RVA: 0x00003491 File Offset: 0x00001691
	public List<IMAction> GameControls { get; private set; } = new List<IMAction>();

	// Token: 0x170000E9 RID: 233
	// (get) Token: 0x060001F8 RID: 504 RVA: 0x0000349A File Offset: 0x0000169A
	// (set) Token: 0x060001F9 RID: 505 RVA: 0x000034A2 File Offset: 0x000016A2
	public List<JObject> Images { get; private set; } = new List<JObject>();

	// Token: 0x170000EA RID: 234
	// (get) Token: 0x060001FA RID: 506 RVA: 0x000034AB File Offset: 0x000016AB
	// (set) Token: 0x060001FB RID: 507 RVA: 0x000034B3 File Offset: 0x000016B3
	public string Name { get; set; }

	// Token: 0x170000EB RID: 235
	// (get) Token: 0x060001FC RID: 508 RVA: 0x000034BC File Offset: 0x000016BC
	// (set) Token: 0x060001FD RID: 509 RVA: 0x000034C4 File Offset: 0x000016C4
	public bool BuiltIn { get; set; }

	// Token: 0x170000EC RID: 236
	// (get) Token: 0x060001FE RID: 510 RVA: 0x000034CD File Offset: 0x000016CD
	// (set) Token: 0x060001FF RID: 511 RVA: 0x000034D5 File Offset: 0x000016D5
	public bool Selected { get; set; }

	// Token: 0x170000ED RID: 237
	// (get) Token: 0x06000200 RID: 512 RVA: 0x000034DE File Offset: 0x000016DE
	// (set) Token: 0x06000201 RID: 513 RVA: 0x000034E6 File Offset: 0x000016E6
	public bool IsBookMarked { get; set; }

	// Token: 0x170000EE RID: 238
	// (get) Token: 0x06000202 RID: 514 RVA: 0x000034EF File Offset: 0x000016EF
	// (set) Token: 0x06000203 RID: 515 RVA: 0x000034F7 File Offset: 0x000016F7
	public bool IsCategoryVisible { get; set; } = true;

	// Token: 0x170000EF RID: 239
	// (get) Token: 0x06000204 RID: 516 RVA: 0x00003500 File Offset: 0x00001700
	// (set) Token: 0x06000205 RID: 517 RVA: 0x00003508 File Offset: 0x00001708
	public string KeyboardLayout { get; set; } = InteropWindow.MapLayoutName(null);

	// Token: 0x06000206 RID: 518 RVA: 0x000122D4 File Offset: 0x000104D4
	public IMControlScheme DeepCopy()
	{
		IMControlScheme imcontrolScheme = (IMControlScheme)base.MemberwiseClone();
		List<IMAction> gameControls = this.GameControls;
		imcontrolScheme.SetGameControls((gameControls != null) ? gameControls.DeepCopy<List<IMAction>>() : null);
		imcontrolScheme.SetImages(this.Images.ConvertAll<JObject>((JObject jt) => (JObject)((jt != null) ? jt.DeepClone() : null)));
		return imcontrolScheme;
	}

	// Token: 0x06000207 RID: 519 RVA: 0x00003511 File Offset: 0x00001711
	public void SetGameControls(List<IMAction> gameControls)
	{
		this.GameControls = gameControls;
	}

	// Token: 0x06000208 RID: 520 RVA: 0x0000351A File Offset: 0x0000171A
	public void SetImages(List<JObject> images)
	{
		List<JObject> images2;
		if (images == null)
		{
			images2 = null;
		}
		else
		{
			images2 = images.ConvertAll<JObject>((JObject jt) => (JObject)((jt != null) ? jt.DeepClone() : null));
		}
		this.Images = images2;
	}
}
