﻿using System;

// Token: 0x02000024 RID: 36
public enum DeviceType
{
	// Token: 0x04000116 RID: 278
	Keyboard,
	// Token: 0x04000117 RID: 279
	Mouse
}
