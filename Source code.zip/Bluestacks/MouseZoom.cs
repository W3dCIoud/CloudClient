﻿using System;
using System.ComponentModel;
using System.Windows.Input;

// Token: 0x02000004 RID: 4
[Description("Independent")]
[Serializable]
public class MouseZoom : IMAction
{
	// Token: 0x17000001 RID: 1
	// (get) Token: 0x06000003 RID: 3 RVA: 0x000108DC File Offset: 0x0000EADC
	// (set) Token: 0x06000004 RID: 4 RVA: 0x00010958 File Offset: 0x0000EB58
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	internal double X
	{
		get
		{
			if (this.mX1 == -1.0 && this.mX2 == -1.0)
			{
				this.mX = -1.0;
			}
			else if (this.Direction == Direction.Left || this.Direction == Direction.Right)
			{
				this.mX = this.mX1 + this.mRadius;
			}
			else
			{
				this.mX = this.mX1;
			}
			return this.mX;
		}
		set
		{
			this.mX = value;
			if (this.Direction == Direction.Right)
			{
				this.mX2 = Math.Round(this.mX + this.mRadius, 2);
				this.mX1 = Math.Round(this.mX - this.mRadius, 2);
				return;
			}
			if (this.Direction == Direction.Up)
			{
				this.mX1 = Math.Round(this.mX, 2);
				this.mX2 = this.X1;
			}
		}
	}

	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000005 RID: 5 RVA: 0x000109D0 File Offset: 0x0000EBD0
	// (set) Token: 0x06000006 RID: 6 RVA: 0x00010A48 File Offset: 0x0000EC48
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	internal double Y
	{
		get
		{
			if (this.mY1 == -1.0 && this.mY2 == -1.0)
			{
				this.mY = -1.0;
			}
			else if (this.Direction == Direction.Up || this.Direction == Direction.Down)
			{
				this.mY = this.mY1 + this.mRadius;
			}
			else
			{
				this.mY = this.mY1;
			}
			return this.mY;
		}
		set
		{
			this.mY = value;
			if (this.Direction == Direction.Right)
			{
				this.mY1 = Math.Round(this.mY, 2);
				this.mY2 = this.Y1;
				return;
			}
			if (this.Direction == Direction.Up)
			{
				this.mY2 = Math.Round(this.mY + this.mRadius, 2);
				this.mY1 = Math.Round(this.mY - this.mRadius, 2);
			}
		}
	}

	// Token: 0x17000003 RID: 3
	// (get) Token: 0x06000007 RID: 7 RVA: 0x00002080 File Offset: 0x00000280
	// (set) Token: 0x06000008 RID: 8 RVA: 0x00002088 File Offset: 0x00000288
	public double X1
	{
		get
		{
			return this.mX1;
		}
		set
		{
			this.mX1 = value;
			this.CheckDirection();
			if (this.Direction == Direction.Up || this.Direction == Direction.Down)
			{
				this.mX2 = this.X1;
			}
		}
	}

	// Token: 0x17000004 RID: 4
	// (get) Token: 0x06000009 RID: 9 RVA: 0x000020B4 File Offset: 0x000002B4
	// (set) Token: 0x0600000A RID: 10 RVA: 0x000020BC File Offset: 0x000002BC
	public double Y1
	{
		get
		{
			return this.mY1;
		}
		set
		{
			this.mY1 = value;
			this.CheckDirection();
			if (this.Direction == Direction.Left || this.Direction == Direction.Right)
			{
				this.mY2 = this.Y1;
			}
		}
	}

	// Token: 0x17000005 RID: 5
	// (get) Token: 0x0600000B RID: 11 RVA: 0x000020E9 File Offset: 0x000002E9
	// (set) Token: 0x0600000C RID: 12 RVA: 0x000020FB File Offset: 0x000002FB
	[Category("Fields")]
	internal double Size
	{
		get
		{
			return this.Radius * 2.0;
		}
		set
		{
			this.Radius = value / 2.0;
		}
	}

	// Token: 0x17000006 RID: 6
	// (get) Token: 0x0600000D RID: 13 RVA: 0x0000210E File Offset: 0x0000030E
	// (set) Token: 0x0600000E RID: 14 RVA: 0x00002116 File Offset: 0x00000316
	public double X2
	{
		get
		{
			return this.mX2;
		}
		set
		{
			this.mX2 = value;
			this.CheckDirection();
		}
	}

	// Token: 0x17000007 RID: 7
	// (get) Token: 0x0600000F RID: 15 RVA: 0x00002125 File Offset: 0x00000325
	// (set) Token: 0x06000010 RID: 16 RVA: 0x0000212D File Offset: 0x0000032D
	public double Y2
	{
		get
		{
			return this.mY2;
		}
		set
		{
			this.mY2 = value;
			this.CheckDirection();
		}
	}

	// Token: 0x17000008 RID: 8
	// (get) Token: 0x06000011 RID: 17 RVA: 0x0000213C File Offset: 0x0000033C
	// (set) Token: 0x06000012 RID: 18 RVA: 0x00010AC0 File Offset: 0x0000ECC0
	[Description("IMAP_CanvasElementRadius")]
	[Category("Fields")]
	internal double Radius
	{
		get
		{
			return this.mRadius;
		}
		set
		{
			this.mRadius = value;
			if (this.Direction == Direction.Right)
			{
				this.mX2 = Math.Round(this.mX + this.mRadius, 2);
				this.mX1 = Math.Round(this.mX - this.mRadius, 2);
				this.mY1 = Math.Round(this.mY, 2);
				this.mY2 = this.Y1;
				return;
			}
			if (this.Direction == Direction.Up)
			{
				this.mY2 = Math.Round(this.mY + this.mRadius, 2);
				this.mY1 = Math.Round(this.mY - this.mRadius, 2);
				this.mX1 = Math.Round(this.mX, 2);
				this.mX2 = this.X1;
			}
		}
	}

	// Token: 0x17000009 RID: 9
	// (get) Token: 0x06000013 RID: 19 RVA: 0x00002144 File Offset: 0x00000344
	// (set) Token: 0x06000014 RID: 20 RVA: 0x0000214C File Offset: 0x0000034C
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key
	{
		get
		{
			return this.mKey;
		}
		set
		{
			this.mKey = value;
		}
	}

	// Token: 0x1700000A RID: 10
	// (get) Token: 0x06000015 RID: 21 RVA: 0x00002155 File Offset: 0x00000355
	// (set) Token: 0x06000016 RID: 22 RVA: 0x0000215D File Offset: 0x0000035D
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key_alt1
	{
		get
		{
			return this.mKey_1;
		}
		set
		{
			this.mKey_1 = value;
		}
	}

	// Token: 0x1700000B RID: 11
	// (get) Token: 0x06000017 RID: 23 RVA: 0x00002166 File Offset: 0x00000366
	// (set) Token: 0x06000018 RID: 24 RVA: 0x0000216E File Offset: 0x0000036E
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyModifier
	{
		get
		{
			return this.mKeyModifier;
		}
		set
		{
			this.mKeyModifier = value;
		}
	}

	// Token: 0x1700000C RID: 12
	// (get) Token: 0x06000019 RID: 25 RVA: 0x00002177 File Offset: 0x00000377
	// (set) Token: 0x0600001A RID: 26 RVA: 0x0000217F File Offset: 0x0000037F
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyModifier_alt1
	{
		get
		{
			return this.mKeyModifier_1;
		}
		set
		{
			this.mKeyModifier_1 = value;
		}
	}

	// Token: 0x1700000D RID: 13
	// (get) Token: 0x0600001B RID: 27 RVA: 0x00002188 File Offset: 0x00000388
	// (set) Token: 0x0600001C RID: 28 RVA: 0x00002190 File Offset: 0x00000390
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Speed
	{
		get
		{
			return this.mSpeed;
		}
		set
		{
			this.mSpeed = value;
		}
	}

	// Token: 0x1700000E RID: 14
	// (get) Token: 0x0600001D RID: 29 RVA: 0x00002199 File Offset: 0x00000399
	// (set) Token: 0x0600001E RID: 30 RVA: 0x000021A1 File Offset: 0x000003A1
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Amplitude
	{
		get
		{
			return this.mAmplitude;
		}
		set
		{
			this.mAmplitude = value;
		}
	}

	// Token: 0x1700000F RID: 15
	// (get) Token: 0x0600001F RID: 31 RVA: 0x000021AA File Offset: 0x000003AA
	// (set) Token: 0x06000020 RID: 32 RVA: 0x000021B2 File Offset: 0x000003B2
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Acceleration
	{
		get
		{
			return this.mAcceleration;
		}
		set
		{
			this.mAcceleration = value;
		}
	}

	// Token: 0x17000010 RID: 16
	// (get) Token: 0x06000021 RID: 33 RVA: 0x000021BB File Offset: 0x000003BB
	// (set) Token: 0x06000022 RID: 34 RVA: 0x000021C3 File Offset: 0x000003C3
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int Mode
	{
		get
		{
			return this.mMode;
		}
		set
		{
			this.mMode = value;
		}
	}

	// Token: 0x17000011 RID: 17
	// (get) Token: 0x06000023 RID: 35 RVA: 0x000021CC File Offset: 0x000003CC
	// (set) Token: 0x06000024 RID: 36 RVA: 0x000021D4 File Offset: 0x000003D4
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool Override
	{
		get
		{
			return this.mOverride;
		}
		set
		{
			this.mOverride = value;
		}
	}

	// Token: 0x06000025 RID: 37 RVA: 0x00010B88 File Offset: 0x0000ED88
	private void CheckDirection()
	{
		if (this.X1 == this.X2)
		{
			this.Direction = Direction.Up;
			this.mRadius = Math.Round(Math.Abs(this.Y2 - this.Y1) / 2.0, 2);
			return;
		}
		if (this.Y1 == this.Y2)
		{
			this.Direction = Direction.Right;
			this.mRadius = Math.Round(Math.Abs(this.X2 - this.X1) / 2.0, 2);
		}
	}

	// Token: 0x04000001 RID: 1
	private double mX = -1.0;

	// Token: 0x04000002 RID: 2
	private double mY = -1.0;

	// Token: 0x04000003 RID: 3
	private double mX1 = -1.0;

	// Token: 0x04000004 RID: 4
	private double mY1 = -1.0;

	// Token: 0x04000005 RID: 5
	private double mX2 = -1.0;

	// Token: 0x04000006 RID: 6
	private double mY2 = -1.0;

	// Token: 0x04000007 RID: 7
	private double mRadius = 20.0;

	// Token: 0x04000008 RID: 8
	private string mKey;

	// Token: 0x04000009 RID: 9
	private string mKey_1 = string.Empty;

	// Token: 0x0400000A RID: 10
	private string mKeyModifier = IMAPKeys.GetStringForFile(System.Windows.Input.Key.LeftCtrl);

	// Token: 0x0400000B RID: 11
	private string mKeyModifier_1;

	// Token: 0x0400000C RID: 12
	private double mSpeed = 40.0;

	// Token: 0x0400000D RID: 13
	private double mAmplitude = 25.0;

	// Token: 0x0400000E RID: 14
	private double mAcceleration = 1.0;

	// Token: 0x0400000F RID: 15
	private int mMode;

	// Token: 0x04000010 RID: 16
	private bool mOverride = true;
}
