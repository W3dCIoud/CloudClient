﻿using System;

// Token: 0x02000022 RID: 34
public enum Direction
{
	// Token: 0x0400010B RID: 267
	Up,
	// Token: 0x0400010C RID: 268
	Down,
	// Token: 0x0400010D RID: 269
	Left,
	// Token: 0x0400010E RID: 270
	Right
}
