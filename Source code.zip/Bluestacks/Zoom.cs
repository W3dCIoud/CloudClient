﻿using System;
using System.ComponentModel;
using System.Windows.Input;

// Token: 0x0200001B RID: 27
[Description("Independent")]
[Serializable]
public class Zoom : IMAction
{
	// Token: 0x170000D0 RID: 208
	// (get) Token: 0x060001B9 RID: 441 RVA: 0x00011CB0 File Offset: 0x0000FEB0
	// (set) Token: 0x060001BA RID: 442 RVA: 0x00011D2C File Offset: 0x0000FF2C
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	internal double X
	{
		get
		{
			if (this.mX1 == -1.0 && this.mX2 == -1.0)
			{
				this.mX = -1.0;
			}
			else if (this.Direction == Direction.Left || this.Direction == Direction.Right)
			{
				this.mX = this.mX1 + this.mRadius;
			}
			else
			{
				this.mX = this.mX1;
			}
			return this.mX;
		}
		set
		{
			this.mX = value;
			if (this.Direction == Direction.Right)
			{
				this.mX2 = Math.Round(this.mX + this.mRadius, 2);
				this.mX1 = Math.Round(this.mX - this.mRadius, 2);
				return;
			}
			if (this.Direction == Direction.Up)
			{
				this.mX1 = Math.Round(this.mX, 2);
				this.mX2 = this.X1;
			}
		}
	}

	// Token: 0x170000D1 RID: 209
	// (get) Token: 0x060001BB RID: 443 RVA: 0x00011DA4 File Offset: 0x0000FFA4
	// (set) Token: 0x060001BC RID: 444 RVA: 0x00011E1C File Offset: 0x0001001C
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	internal double Y
	{
		get
		{
			if (this.mY1 == -1.0 && this.mY2 == -1.0)
			{
				this.mY = -1.0;
			}
			else if (this.Direction == Direction.Up || this.Direction == Direction.Down)
			{
				this.mY = this.mY1 + this.mRadius;
			}
			else
			{
				this.mY = this.mY1;
			}
			return this.mY;
		}
		set
		{
			this.mY = value;
			if (this.Direction == Direction.Right)
			{
				this.mY1 = Math.Round(this.mY, 2);
				this.mY2 = this.Y1;
				return;
			}
			if (this.Direction == Direction.Up)
			{
				this.mY2 = Math.Round(this.mY + this.mRadius, 2);
				this.mY1 = Math.Round(this.mY - this.mRadius, 2);
			}
		}
	}

	// Token: 0x170000D2 RID: 210
	// (get) Token: 0x060001BD RID: 445 RVA: 0x000031E6 File Offset: 0x000013E6
	// (set) Token: 0x060001BE RID: 446 RVA: 0x000031EE File Offset: 0x000013EE
	public double X1
	{
		get
		{
			return this.mX1;
		}
		set
		{
			this.mX1 = value;
			this.CheckDirection();
			if (this.Direction == Direction.Up || this.Direction == Direction.Down)
			{
				this.mX2 = this.X1;
			}
		}
	}

	// Token: 0x170000D3 RID: 211
	// (get) Token: 0x060001BF RID: 447 RVA: 0x0000321A File Offset: 0x0000141A
	// (set) Token: 0x060001C0 RID: 448 RVA: 0x00003222 File Offset: 0x00001422
	public double Y1
	{
		get
		{
			return this.mY1;
		}
		set
		{
			this.mY1 = value;
			this.CheckDirection();
			if (this.Direction == Direction.Left || this.Direction == Direction.Right)
			{
				this.mY2 = this.Y1;
			}
		}
	}

	// Token: 0x170000D4 RID: 212
	// (get) Token: 0x060001C1 RID: 449 RVA: 0x0000324F File Offset: 0x0000144F
	// (set) Token: 0x060001C2 RID: 450 RVA: 0x00003261 File Offset: 0x00001461
	[Category("Fields")]
	internal double Size
	{
		get
		{
			return this.Radius * 2.0;
		}
		set
		{
			this.Radius = value / 2.0;
		}
	}

	// Token: 0x170000D5 RID: 213
	// (get) Token: 0x060001C3 RID: 451 RVA: 0x00003274 File Offset: 0x00001474
	// (set) Token: 0x060001C4 RID: 452 RVA: 0x0000327C File Offset: 0x0000147C
	public double X2
	{
		get
		{
			return this.mX2;
		}
		set
		{
			this.mX2 = value;
			this.CheckDirection();
		}
	}

	// Token: 0x170000D6 RID: 214
	// (get) Token: 0x060001C5 RID: 453 RVA: 0x0000328B File Offset: 0x0000148B
	// (set) Token: 0x060001C6 RID: 454 RVA: 0x00003293 File Offset: 0x00001493
	public double Y2
	{
		get
		{
			return this.mY2;
		}
		set
		{
			this.mY2 = value;
			this.CheckDirection();
		}
	}

	// Token: 0x170000D7 RID: 215
	// (get) Token: 0x060001C7 RID: 455 RVA: 0x000032A2 File Offset: 0x000014A2
	// (set) Token: 0x060001C8 RID: 456 RVA: 0x00011E94 File Offset: 0x00010094
	[Description("IMAP_CanvasElementRadius")]
	[Category("Fields")]
	internal double Radius
	{
		get
		{
			return this.mRadius;
		}
		set
		{
			this.mRadius = value;
			if (this.Direction == Direction.Right)
			{
				this.mX2 = Math.Round(this.mX + this.mRadius, 2);
				this.mX1 = Math.Round(this.mX - this.mRadius, 2);
				this.mY1 = Math.Round(this.mY, 2);
				this.mY2 = this.Y1;
				return;
			}
			if (this.Direction == Direction.Up)
			{
				this.mY2 = Math.Round(this.mY + this.mRadius, 2);
				this.mY1 = Math.Round(this.mY - this.mRadius, 2);
				this.mX1 = Math.Round(this.mX, 2);
				this.mX2 = this.X1;
			}
		}
	}

	// Token: 0x170000D8 RID: 216
	// (get) Token: 0x060001C9 RID: 457 RVA: 0x000032AA File Offset: 0x000014AA
	// (set) Token: 0x060001CA RID: 458 RVA: 0x000032B2 File Offset: 0x000014B2
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyIn
	{
		get
		{
			return this.mKeyIn;
		}
		set
		{
			this.mKeyIn = value;
		}
	}

	// Token: 0x170000D9 RID: 217
	// (get) Token: 0x060001CB RID: 459 RVA: 0x000032BB File Offset: 0x000014BB
	// (set) Token: 0x060001CC RID: 460 RVA: 0x000032C3 File Offset: 0x000014C3
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyIn_alt1
	{
		get
		{
			return this.mKeyIn_1;
		}
		set
		{
			this.mKeyIn_1 = value;
		}
	}

	// Token: 0x170000DA RID: 218
	// (get) Token: 0x060001CD RID: 461 RVA: 0x000032CC File Offset: 0x000014CC
	// (set) Token: 0x060001CE RID: 462 RVA: 0x000032D4 File Offset: 0x000014D4
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyOut
	{
		get
		{
			return this.mKeyOut;
		}
		set
		{
			this.mKeyOut = value;
		}
	}

	// Token: 0x170000DB RID: 219
	// (get) Token: 0x060001CF RID: 463 RVA: 0x000032DD File Offset: 0x000014DD
	// (set) Token: 0x060001D0 RID: 464 RVA: 0x000032E5 File Offset: 0x000014E5
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyOut_alt1
	{
		get
		{
			return this.mKeyOut_1;
		}
		set
		{
			this.mKeyOut_1 = value;
		}
	}

	// Token: 0x170000DC RID: 220
	// (get) Token: 0x060001D1 RID: 465 RVA: 0x000032EE File Offset: 0x000014EE
	// (set) Token: 0x060001D2 RID: 466 RVA: 0x000032F6 File Offset: 0x000014F6
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyModifier
	{
		get
		{
			return this.mKeyModifier;
		}
		set
		{
			this.mKeyModifier = value;
		}
	}

	// Token: 0x170000DD RID: 221
	// (get) Token: 0x060001D3 RID: 467 RVA: 0x000032FF File Offset: 0x000014FF
	// (set) Token: 0x060001D4 RID: 468 RVA: 0x00003307 File Offset: 0x00001507
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyModifier_alt1
	{
		get
		{
			return this.mKeyModifier_1;
		}
		set
		{
			this.mKeyModifier_1 = value;
		}
	}

	// Token: 0x170000DE RID: 222
	// (get) Token: 0x060001D5 RID: 469 RVA: 0x00003310 File Offset: 0x00001510
	// (set) Token: 0x060001D6 RID: 470 RVA: 0x00003318 File Offset: 0x00001518
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Speed
	{
		get
		{
			return this.mSpeed;
		}
		set
		{
			this.mSpeed = value;
		}
	}

	// Token: 0x170000DF RID: 223
	// (get) Token: 0x060001D7 RID: 471 RVA: 0x00003321 File Offset: 0x00001521
	// (set) Token: 0x060001D8 RID: 472 RVA: 0x00003329 File Offset: 0x00001529
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Amplitude
	{
		get
		{
			return this.mAmplitude;
		}
		set
		{
			this.mAmplitude = value;
		}
	}

	// Token: 0x170000E0 RID: 224
	// (get) Token: 0x060001D9 RID: 473 RVA: 0x00003332 File Offset: 0x00001532
	// (set) Token: 0x060001DA RID: 474 RVA: 0x0000333A File Offset: 0x0000153A
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Acceleration
	{
		get
		{
			return this.mAcceleration;
		}
		set
		{
			this.mAcceleration = value;
		}
	}

	// Token: 0x170000E1 RID: 225
	// (get) Token: 0x060001DB RID: 475 RVA: 0x00003343 File Offset: 0x00001543
	// (set) Token: 0x060001DC RID: 476 RVA: 0x0000334B File Offset: 0x0000154B
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int Mode
	{
		get
		{
			return this.mMode;
		}
		set
		{
			this.mMode = value;
		}
	}

	// Token: 0x170000E2 RID: 226
	// (get) Token: 0x060001DD RID: 477 RVA: 0x00003354 File Offset: 0x00001554
	// (set) Token: 0x060001DE RID: 478 RVA: 0x0000335C File Offset: 0x0000155C
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool Override
	{
		get
		{
			return this.mOverride;
		}
		set
		{
			this.mOverride = value;
		}
	}

	// Token: 0x060001DF RID: 479 RVA: 0x00011F5C File Offset: 0x0001015C
	private void CheckDirection()
	{
		if (this.X1 == this.X2)
		{
			this.Direction = Direction.Up;
			this.mRadius = Math.Round(Math.Abs(this.Y2 - this.Y1) / 2.0, 2);
			return;
		}
		if (this.Y1 == this.Y2)
		{
			this.Direction = Direction.Right;
			this.mRadius = Math.Round(Math.Abs(this.X2 - this.X1) / 2.0, 2);
		}
	}

	// Token: 0x040000C9 RID: 201
	private double mX = -1.0;

	// Token: 0x040000CA RID: 202
	private double mY = -1.0;

	// Token: 0x040000CB RID: 203
	private double mX1 = -1.0;

	// Token: 0x040000CC RID: 204
	private double mY1 = -1.0;

	// Token: 0x040000CD RID: 205
	private double mX2 = -1.0;

	// Token: 0x040000CE RID: 206
	private double mY2 = -1.0;

	// Token: 0x040000CF RID: 207
	private double mRadius = 20.0;

	// Token: 0x040000D0 RID: 208
	private string mKeyIn = IMAPKeys.GetStringForFile(Key.OemPlus);

	// Token: 0x040000D1 RID: 209
	private string mKeyIn_1 = string.Empty;

	// Token: 0x040000D2 RID: 210
	private string mKeyOut = IMAPKeys.GetStringForFile(Key.OemMinus);

	// Token: 0x040000D3 RID: 211
	private string mKeyOut_1 = string.Empty;

	// Token: 0x040000D4 RID: 212
	private string mKeyModifier;

	// Token: 0x040000D5 RID: 213
	private string mKeyModifier_1;

	// Token: 0x040000D6 RID: 214
	private double mSpeed = 1.0;

	// Token: 0x040000D7 RID: 215
	private double mAmplitude = 20.0;

	// Token: 0x040000D8 RID: 216
	private double mAcceleration = 1.0;

	// Token: 0x040000D9 RID: 217
	private int mMode;

	// Token: 0x040000DA RID: 218
	private bool mOverride = true;
}
