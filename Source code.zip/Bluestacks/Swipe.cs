﻿using System;
using System.ComponentModel;
using BlueStacks.Common;

// Token: 0x02000018 RID: 24
[Description("Dependent")]
[Serializable]
public class Swipe : IMAction
{
	// Token: 0x170000B4 RID: 180
	// (get) Token: 0x0600017D RID: 381 RVA: 0x00002FE1 File Offset: 0x000011E1
	// (set) Token: 0x0600017E RID: 382 RVA: 0x00011864 File Offset: 0x0000FA64
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X1
	{
		get
		{
			return this.mX1;
		}
		set
		{
			this.mX1 = value;
			if (this.Direction == Direction.Up || this.Direction == Direction.Down)
			{
				this.mX2 = this.X1;
				return;
			}
			if (this.Direction == Direction.Left)
			{
				this.mX2 = Math.Round(this.X1 - this.mRadius, 2);
				return;
			}
			if (this.Direction == Direction.Right)
			{
				this.mX2 = Math.Round(this.X1 + this.mRadius, 2);
			}
		}
	}

	// Token: 0x170000B5 RID: 181
	// (get) Token: 0x0600017F RID: 383 RVA: 0x00002FE9 File Offset: 0x000011E9
	// (set) Token: 0x06000180 RID: 384 RVA: 0x000118DC File Offset: 0x0000FADC
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y1
	{
		get
		{
			return this.mY1;
		}
		set
		{
			this.mY1 = value;
			if (this.Direction == Direction.Left || this.Direction == Direction.Right)
			{
				this.mY2 = this.Y1;
				return;
			}
			if (this.Direction == Direction.Up)
			{
				this.mY2 = Math.Round(this.Y1 - this.mRadius, 2);
				return;
			}
			if (this.Direction == Direction.Down)
			{
				this.mY2 = Math.Round(this.Y1 + this.mRadius, 2);
			}
		}
	}

	// Token: 0x170000B6 RID: 182
	// (get) Token: 0x06000181 RID: 385 RVA: 0x00002FF1 File Offset: 0x000011F1
	// (set) Token: 0x06000182 RID: 386 RVA: 0x00002FF9 File Offset: 0x000011F9
	public double X2
	{
		get
		{
			return this.mX2;
		}
		set
		{
			this.mX2 = value;
			this.CheckDirection();
		}
	}

	// Token: 0x170000B7 RID: 183
	// (get) Token: 0x06000183 RID: 387 RVA: 0x00003008 File Offset: 0x00001208
	// (set) Token: 0x06000184 RID: 388 RVA: 0x00003010 File Offset: 0x00001210
	public double Y2
	{
		get
		{
			return this.mY2;
		}
		set
		{
			this.mY2 = value;
			this.CheckDirection();
		}
	}

	// Token: 0x170000B8 RID: 184
	// (get) Token: 0x06000185 RID: 389 RVA: 0x0000301F File Offset: 0x0000121F
	// (set) Token: 0x06000186 RID: 390 RVA: 0x00011954 File Offset: 0x0000FB54
	[Description("IMAP_CanvasElementRadiusIMAP_PopupUIElement")]
	[Category("Fields")]
	internal double Radius
	{
		get
		{
			return this.mRadius;
		}
		set
		{
			this.mRadius = value;
			if (this.Direction == Direction.Left)
			{
				this.Y2 = this.Y1;
				this.X2 = Math.Round(this.X1 - value, 2);
				Logger.Debug("SWIPE_L: X2: " + this.X2.ToString() + "...............Y2: " + this.Y2.ToString());
				return;
			}
			if (this.Direction == Direction.Right)
			{
				this.Y2 = this.Y1;
				this.X2 = Math.Round(this.X1 + value, 2);
				Logger.Debug("SWIPE_R: X2: " + this.X2.ToString() + "...............Y2: " + this.Y2.ToString());
				return;
			}
			if (this.Direction == Direction.Up)
			{
				this.X2 = this.X1;
				this.Y2 = Math.Round(this.Y1 - value, 2);
				Logger.Debug("SWIPE_U: X2: " + this.X2.ToString() + "...............Y2: " + this.Y2.ToString());
				return;
			}
			if (this.Direction == Direction.Down)
			{
				this.X2 = this.X1;
				this.Y2 = Math.Round(this.Y1 + value, 2);
				Logger.Debug("SWIPE_D: X2: " + this.X2.ToString() + "...............Y2: " + this.Y2.ToString());
			}
		}
	}

	// Token: 0x170000B9 RID: 185
	// (get) Token: 0x06000187 RID: 391 RVA: 0x00003027 File Offset: 0x00001227
	// (set) Token: 0x06000188 RID: 392 RVA: 0x0000302F File Offset: 0x0000122F
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Speed
	{
		get
		{
			return this.mSpeed;
		}
		set
		{
			this.mSpeed = value;
		}
	}

	// Token: 0x170000BA RID: 186
	// (get) Token: 0x06000189 RID: 393 RVA: 0x00003038 File Offset: 0x00001238
	// (set) Token: 0x0600018A RID: 394 RVA: 0x00003040 File Offset: 0x00001240
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool Hold
	{
		get
		{
			return this.mHold;
		}
		set
		{
			this.mHold = value;
		}
	}

	// Token: 0x170000BB RID: 187
	// (get) Token: 0x0600018B RID: 395 RVA: 0x00003049 File Offset: 0x00001249
	// (set) Token: 0x0600018C RID: 396 RVA: 0x00003051 File Offset: 0x00001251
	[Description("IMAP_PopupUIElementNotCommon")]
	[Category("Fields")]
	public string Key
	{
		get
		{
			return this.mKey;
		}
		set
		{
			this.mKey = value;
		}
	}

	// Token: 0x170000BC RID: 188
	// (get) Token: 0x0600018D RID: 397 RVA: 0x0000305A File Offset: 0x0000125A
	// (set) Token: 0x0600018E RID: 398 RVA: 0x00003062 File Offset: 0x00001262
	[Description("IMAP_PopupUIElementNotCommon")]
	[Category("Fields")]
	public string Key_alt1
	{
		get
		{
			return this.mKey_1;
		}
		set
		{
			this.mKey_1 = value;
		}
	}

	// Token: 0x0600018F RID: 399 RVA: 0x00011AD0 File Offset: 0x0000FCD0
	private void CheckDirection()
	{
		if (this.X1 != this.X2)
		{
			if (this.Y1 == this.Y2)
			{
				if (this.X1 > this.X2)
				{
					this.Direction = Direction.Left;
					this.mRadius = Math.Round(this.X1 - this.X2, 2);
					return;
				}
				this.Direction = Direction.Right;
				this.mRadius = Math.Round(this.X2 - this.X1, 2);
			}
			return;
		}
		if (this.Y1 > this.Y2)
		{
			this.Direction = Direction.Up;
			this.mRadius = Math.Round(this.Y1 - this.Y2, 2);
			return;
		}
		this.Direction = Direction.Down;
		this.mRadius = Math.Round(this.Y2 - this.Y1, 2);
	}

	// Token: 0x040000AD RID: 173
	private double mX1 = -1.0;

	// Token: 0x040000AE RID: 174
	private double mY1 = -1.0;

	// Token: 0x040000AF RID: 175
	private double mX2;

	// Token: 0x040000B0 RID: 176
	private double mY2;

	// Token: 0x040000B1 RID: 177
	private double mRadius = 10.0;

	// Token: 0x040000B2 RID: 178
	private double mSpeed = 200.0;

	// Token: 0x040000B3 RID: 179
	private bool mHold;

	// Token: 0x040000B4 RID: 180
	private string mKey;

	// Token: 0x040000B5 RID: 181
	private string mKey_1;
}
