﻿using System;

// Token: 0x0200000C RID: 12
[Serializable]
public class KeyEvent : IMAction
{
	// Token: 0x1700006B RID: 107
	// (get) Token: 0x060000E2 RID: 226 RVA: 0x00002980 File Offset: 0x00000B80
	// (set) Token: 0x060000E3 RID: 227 RVA: 0x00002988 File Offset: 0x00000B88
	public string Key
	{
		get
		{
			return this.mKey;
		}
		set
		{
			this.mKey = value;
		}
	}

	// Token: 0x1700006C RID: 108
	// (get) Token: 0x060000E4 RID: 228 RVA: 0x00002991 File Offset: 0x00000B91
	// (set) Token: 0x060000E5 RID: 229 RVA: 0x00002999 File Offset: 0x00000B99
	public int HoldTime
	{
		get
		{
			return this.mHoldTime;
		}
		set
		{
			this.mHoldTime = value;
		}
	}

	// Token: 0x1700006D RID: 109
	// (get) Token: 0x060000E6 RID: 230 RVA: 0x000029A2 File Offset: 0x00000BA2
	// (set) Token: 0x060000E7 RID: 231 RVA: 0x000029AA File Offset: 0x00000BAA
	public object KeyDownEvents
	{
		get
		{
			return this.mKeyDownEvents;
		}
		set
		{
			this.mKeyDownEvents = value;
		}
	}

	// Token: 0x1700006E RID: 110
	// (get) Token: 0x060000E8 RID: 232 RVA: 0x000029B3 File Offset: 0x00000BB3
	// (set) Token: 0x060000E9 RID: 233 RVA: 0x000029BB File Offset: 0x00000BBB
	public object KeyUpEvents
	{
		get
		{
			return this.mKeyUpEvents;
		}
		set
		{
			this.mKeyUpEvents = value;
		}
	}

	// Token: 0x0400006B RID: 107
	private string mKey;

	// Token: 0x0400006C RID: 108
	private int mHoldTime;

	// Token: 0x0400006D RID: 109
	private object mKeyDownEvents;

	// Token: 0x0400006E RID: 110
	private object mKeyUpEvents;
}
