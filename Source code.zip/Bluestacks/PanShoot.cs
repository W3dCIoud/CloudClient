﻿using System;
using System.ComponentModel;

// Token: 0x02000016 RID: 22
[Description("SubElement")]
[Serializable]
internal class PanShoot : IMAction
{
	// Token: 0x170000A9 RID: 169
	// (get) Token: 0x06000166 RID: 358 RVA: 0x00002EE4 File Offset: 0x000010E4
	public string Key
	{
		get
		{
			return this.mPan.KeyAction;
		}
	}

	// Token: 0x170000AA RID: 170
	// (get) Token: 0x06000167 RID: 359 RVA: 0x00002EF1 File Offset: 0x000010F1
	// (set) Token: 0x06000168 RID: 360 RVA: 0x00002EFE File Offset: 0x000010FE
	[Description("IMAP_CanvasElementY")]
	public double X
	{
		get
		{
			return this.mPan.LButtonX;
		}
		set
		{
			this.mPan.LButtonX = value;
		}
	}

	// Token: 0x170000AB RID: 171
	// (get) Token: 0x06000169 RID: 361 RVA: 0x00002F0C File Offset: 0x0000110C
	// (set) Token: 0x0600016A RID: 362 RVA: 0x00002F19 File Offset: 0x00001119
	[Description("IMAP_CanvasElementX")]
	public double Y
	{
		get
		{
			return this.mPan.LButtonY;
		}
		set
		{
			this.mPan.LButtonY = value;
		}
	}

	// Token: 0x0600016B RID: 363 RVA: 0x00002F27 File Offset: 0x00001127
	internal PanShoot(Pan action)
	{
		this.IsChildAction = true;
		base.Type = KeyActionType.PanShoot;
		this.mPan = action;
		this.ParentAction = action;
	}

	// Token: 0x040000A4 RID: 164
	private Pan mPan;
}
