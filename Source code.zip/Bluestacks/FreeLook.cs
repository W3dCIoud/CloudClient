﻿using System;
using System.ComponentModel;
using System.Windows.Input;

// Token: 0x02000006 RID: 6
[Description("Independent")]
[Serializable]
public class FreeLook : IMAction
{
	// Token: 0x1700001E RID: 30
	// (get) Token: 0x06000043 RID: 67 RVA: 0x00002356 File Offset: 0x00000556
	// (set) Token: 0x06000044 RID: 68 RVA: 0x0000235E File Offset: 0x0000055E
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X { get; set; } = -1.0;

	// Token: 0x1700001F RID: 31
	// (get) Token: 0x06000045 RID: 69 RVA: 0x00002367 File Offset: 0x00000567
	// (set) Token: 0x06000046 RID: 70 RVA: 0x0000236F File Offset: 0x0000056F
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y { get; set; } = -1.0;

	// Token: 0x17000020 RID: 32
	// (get) Token: 0x06000047 RID: 71 RVA: 0x00002378 File Offset: 0x00000578
	// (set) Token: 0x06000048 RID: 72 RVA: 0x00002380 File Offset: 0x00000580
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key { get; set; } = IMAPKeys.GetStringForFile(System.Windows.Input.Key.V);

	// Token: 0x17000021 RID: 33
	// (get) Token: 0x06000049 RID: 73 RVA: 0x00002389 File Offset: 0x00000589
	// (set) Token: 0x0600004A RID: 74 RVA: 0x00002391 File Offset: 0x00000591
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key_alt1 { get; set; } = string.Empty;

	// Token: 0x17000022 RID: 34
	// (get) Token: 0x0600004B RID: 75 RVA: 0x0000239A File Offset: 0x0000059A
	// (set) Token: 0x0600004C RID: 76 RVA: 0x000023A2 File Offset: 0x000005A2
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyLeft { get; set; } = IMAPKeys.GetStringForFile(System.Windows.Input.Key.Left);

	// Token: 0x17000023 RID: 35
	// (get) Token: 0x0600004D RID: 77 RVA: 0x000023AB File Offset: 0x000005AB
	// (set) Token: 0x0600004E RID: 78 RVA: 0x000023B3 File Offset: 0x000005B3
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyLeft_alt1 { get; set; } = string.Empty;

	// Token: 0x17000024 RID: 36
	// (get) Token: 0x0600004F RID: 79 RVA: 0x000023BC File Offset: 0x000005BC
	// (set) Token: 0x06000050 RID: 80 RVA: 0x000023C4 File Offset: 0x000005C4
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyRight { get; set; } = IMAPKeys.GetStringForFile(System.Windows.Input.Key.Right);

	// Token: 0x17000025 RID: 37
	// (get) Token: 0x06000051 RID: 81 RVA: 0x000023CD File Offset: 0x000005CD
	// (set) Token: 0x06000052 RID: 82 RVA: 0x000023D5 File Offset: 0x000005D5
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyRight_alt1 { get; set; } = string.Empty;

	// Token: 0x17000026 RID: 38
	// (get) Token: 0x06000053 RID: 83 RVA: 0x000023DE File Offset: 0x000005DE
	// (set) Token: 0x06000054 RID: 84 RVA: 0x000023E6 File Offset: 0x000005E6
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyUp { get; set; } = IMAPKeys.GetStringForFile(System.Windows.Input.Key.Up);

	// Token: 0x17000027 RID: 39
	// (get) Token: 0x06000055 RID: 85 RVA: 0x000023EF File Offset: 0x000005EF
	// (set) Token: 0x06000056 RID: 86 RVA: 0x000023F7 File Offset: 0x000005F7
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyUp_alt1 { get; set; } = string.Empty;

	// Token: 0x17000028 RID: 40
	// (get) Token: 0x06000057 RID: 87 RVA: 0x00002400 File Offset: 0x00000600
	// (set) Token: 0x06000058 RID: 88 RVA: 0x00002408 File Offset: 0x00000608
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyDown { get; set; } = IMAPKeys.GetStringForFile(System.Windows.Input.Key.Down);

	// Token: 0x17000029 RID: 41
	// (get) Token: 0x06000059 RID: 89 RVA: 0x00002411 File Offset: 0x00000611
	// (set) Token: 0x0600005A RID: 90 RVA: 0x00002419 File Offset: 0x00000619
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyDown_alt1 { get; set; } = string.Empty;

	// Token: 0x1700002A RID: 42
	// (get) Token: 0x0600005B RID: 91 RVA: 0x00002422 File Offset: 0x00000622
	// (set) Token: 0x0600005C RID: 92 RVA: 0x0000242A File Offset: 0x0000062A
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int DeviceType { get; set; }

	// Token: 0x1700002B RID: 43
	// (get) Token: 0x0600005D RID: 93 RVA: 0x00002433 File Offset: 0x00000633
	// (set) Token: 0x0600005E RID: 94 RVA: 0x0000243B File Offset: 0x0000063B
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool ShowOnOverlay
	{
		get
		{
			return this.mShowOnOverlay;
		}
		set
		{
			this.mShowOnOverlay = value;
		}
	}

	// Token: 0x1700002C RID: 44
	// (get) Token: 0x0600005F RID: 95 RVA: 0x00002444 File Offset: 0x00000644
	// (set) Token: 0x06000060 RID: 96 RVA: 0x0000244C File Offset: 0x0000064C
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Sensitivity { get; set; } = 1.0;

	// Token: 0x1700002D RID: 45
	// (get) Token: 0x06000061 RID: 97 RVA: 0x00002455 File Offset: 0x00000655
	// (set) Token: 0x06000062 RID: 98 RVA: 0x0000245D File Offset: 0x0000065D
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Speed { get; set; } = 20.0;

	// Token: 0x1700002E RID: 46
	// (get) Token: 0x06000063 RID: 99 RVA: 0x00002466 File Offset: 0x00000666
	// (set) Token: 0x06000064 RID: 100 RVA: 0x0000246E File Offset: 0x0000066E
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool MouseAcceleration { get; set; }

	// Token: 0x1700002F RID: 47
	// (get) Token: 0x06000065 RID: 101 RVA: 0x00002477 File Offset: 0x00000677
	// (set) Token: 0x06000066 RID: 102 RVA: 0x0000247F File Offset: 0x0000067F
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int Delay { get; set; } = 50;

	// Token: 0x0400002E RID: 46
	internal bool mShowOnOverlay = true;
}
