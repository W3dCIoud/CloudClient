﻿using System;
using System.ComponentModel;

// Token: 0x02000013 RID: 19
[Description("Independent")]
[Serializable]
public class State : IMAction
{
	// Token: 0x1700009B RID: 155
	// (get) Token: 0x06000147 RID: 327 RVA: 0x00002D2A File Offset: 0x00000F2A
	// (set) Token: 0x06000148 RID: 328 RVA: 0x00002D32 File Offset: 0x00000F32
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X
	{
		get
		{
			return this.mX;
		}
		set
		{
			this.mX = value;
		}
	}

	// Token: 0x1700009C RID: 156
	// (get) Token: 0x06000149 RID: 329 RVA: 0x00002D3B File Offset: 0x00000F3B
	// (set) Token: 0x0600014A RID: 330 RVA: 0x00002D43 File Offset: 0x00000F43
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y
	{
		get
		{
			return this.mY;
		}
		set
		{
			this.mY = value;
		}
	}

	// Token: 0x1700009D RID: 157
	// (get) Token: 0x0600014B RID: 331 RVA: 0x00002D4C File Offset: 0x00000F4C
	// (set) Token: 0x0600014C RID: 332 RVA: 0x00002D54 File Offset: 0x00000F54
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Name
	{
		get
		{
			return this.mName;
		}
		set
		{
			this.mName = value;
		}
	}

	// Token: 0x1700009E RID: 158
	// (get) Token: 0x0600014D RID: 333 RVA: 0x00002D5D File Offset: 0x00000F5D
	// (set) Token: 0x0600014E RID: 334 RVA: 0x00002D65 File Offset: 0x00000F65
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key
	{
		get
		{
			return this.mKey;
		}
		set
		{
			this.mKey = value;
		}
	}

	// Token: 0x1700009F RID: 159
	// (get) Token: 0x0600014F RID: 335 RVA: 0x00002D6E File Offset: 0x00000F6E
	// (set) Token: 0x06000150 RID: 336 RVA: 0x00002D76 File Offset: 0x00000F76
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Key_alt1
	{
		get
		{
			return this.mKey_alt1;
		}
		set
		{
			this.mKey_alt1 = value;
		}
	}

	// Token: 0x170000A0 RID: 160
	// (get) Token: 0x06000151 RID: 337 RVA: 0x00002D7F File Offset: 0x00000F7F
	// (set) Token: 0x06000152 RID: 338 RVA: 0x00002D87 File Offset: 0x00000F87
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string Model
	{
		get
		{
			return this.mModel;
		}
		set
		{
			this.mModel = value;
		}
	}

	// Token: 0x170000A1 RID: 161
	// (get) Token: 0x06000153 RID: 339 RVA: 0x00002D90 File Offset: 0x00000F90
	// (set) Token: 0x06000154 RID: 340 RVA: 0x00002D98 File Offset: 0x00000F98
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int Delay
	{
		get
		{
			return this.mDelay;
		}
		set
		{
			this.mDelay = value;
		}
	}

	// Token: 0x0400009B RID: 155
	private double mX = -1.0;

	// Token: 0x0400009C RID: 156
	private double mY = -1.0;

	// Token: 0x0400009D RID: 157
	private string mName = string.Empty;

	// Token: 0x0400009E RID: 158
	private string mKey;

	// Token: 0x0400009F RID: 159
	private string mKey_alt1;

	// Token: 0x040000A0 RID: 160
	private string mModel = string.Empty;

	// Token: 0x040000A1 RID: 161
	private int mDelay;
}
