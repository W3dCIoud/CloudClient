﻿using System;
using System.ComponentModel;

// Token: 0x02000014 RID: 20
[Description("SubElement")]
[Serializable]
internal class LookAround : IMAction
{
	// Token: 0x170000A2 RID: 162
	// (get) Token: 0x06000156 RID: 342 RVA: 0x00002DDD File Offset: 0x00000FDD
	// (set) Token: 0x06000157 RID: 343 RVA: 0x00002DEA File Offset: 0x00000FEA
	public string Key
	{
		get
		{
			return this.mPan.KeyLookAround;
		}
		set
		{
			this.mPan.KeyLookAround = value;
		}
	}

	// Token: 0x170000A3 RID: 163
	// (get) Token: 0x06000158 RID: 344 RVA: 0x00002DF8 File Offset: 0x00000FF8
	// (set) Token: 0x06000159 RID: 345 RVA: 0x00002E05 File Offset: 0x00001005
	[Description("IMAP_CanvasElementY")]
	public double X
	{
		get
		{
			return this.mPan.LookAroundX;
		}
		set
		{
			this.mPan.LookAroundX = value;
		}
	}

	// Token: 0x170000A4 RID: 164
	// (get) Token: 0x0600015A RID: 346 RVA: 0x00002E13 File Offset: 0x00001013
	// (set) Token: 0x0600015B RID: 347 RVA: 0x00002E20 File Offset: 0x00001020
	[Description("IMAP_CanvasElementX")]
	public double Y
	{
		get
		{
			return this.mPan.LookAroundY;
		}
		set
		{
			this.mPan.LookAroundY = value;
		}
	}

	// Token: 0x0600015C RID: 348 RVA: 0x00002E2E File Offset: 0x0000102E
	internal LookAround(Pan action)
	{
		this.IsChildAction = true;
		base.Type = KeyActionType.LookAround;
		this.mPan = action;
		this.ParentAction = action;
	}

	// Token: 0x040000A2 RID: 162
	private Pan mPan;
}
