﻿using System;
using System.ComponentModel;

// Token: 0x02000015 RID: 21
[Description("SubElementDependent")]
[Serializable]
internal class MOBASkillCancel : IMAction
{
	// Token: 0x170000A5 RID: 165
	// (get) Token: 0x0600015D RID: 349 RVA: 0x00002E53 File Offset: 0x00001053
	// (set) Token: 0x0600015E RID: 350 RVA: 0x00002E60 File Offset: 0x00001060
	public string Key
	{
		get
		{
			return this.mMOBASkill.KeyCancel;
		}
		set
		{
			this.mMOBASkill.KeyCancel = value;
		}
	}

	// Token: 0x170000A6 RID: 166
	// (get) Token: 0x0600015F RID: 351 RVA: 0x00002E6E File Offset: 0x0000106E
	// (set) Token: 0x06000160 RID: 352 RVA: 0x00002E7B File Offset: 0x0000107B
	public string Key_alt1
	{
		get
		{
			return this.mMOBASkill.KeyCancel_alt1;
		}
		set
		{
			this.mMOBASkill.KeyCancel_alt1 = value;
		}
	}

	// Token: 0x170000A7 RID: 167
	// (get) Token: 0x06000161 RID: 353 RVA: 0x00002E89 File Offset: 0x00001089
	// (set) Token: 0x06000162 RID: 354 RVA: 0x00002E96 File Offset: 0x00001096
	[Description("IMAP_CanvasElementY")]
	public double X
	{
		get
		{
			return this.mMOBASkill.CancelX;
		}
		set
		{
			this.mMOBASkill.CancelX = value;
		}
	}

	// Token: 0x170000A8 RID: 168
	// (get) Token: 0x06000163 RID: 355 RVA: 0x00002EA4 File Offset: 0x000010A4
	// (set) Token: 0x06000164 RID: 356 RVA: 0x00002EB1 File Offset: 0x000010B1
	[Description("IMAP_CanvasElementX")]
	public double Y
	{
		get
		{
			return this.mMOBASkill.CancelY;
		}
		set
		{
			this.mMOBASkill.CancelY = value;
		}
	}

	// Token: 0x06000165 RID: 357 RVA: 0x00002EBF File Offset: 0x000010BF
	internal MOBASkillCancel(MOBASkill action)
	{
		this.IsChildAction = true;
		base.Type = KeyActionType.MOBASkillCancel;
		this.mMOBASkill = action;
		this.ParentAction = action;
	}

	// Token: 0x040000A3 RID: 163
	internal MOBASkill mMOBASkill;
}
