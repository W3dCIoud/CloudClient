﻿using System;
using BlueStacks.BlueStacksUI;

// Token: 0x02000020 RID: 32
[Serializable]
public class MetaData
{
	// Token: 0x170000F0 RID: 240
	// (get) Token: 0x0600020E RID: 526 RVA: 0x0000359D File Offset: 0x0000179D
	// (set) Token: 0x0600020F RID: 527 RVA: 0x000035A5 File Offset: 0x000017A5
	public string ParserVersion { get; set; } = KMManager.ParserVersion;

	// Token: 0x170000F1 RID: 241
	// (get) Token: 0x06000210 RID: 528 RVA: 0x000035AE File Offset: 0x000017AE
	// (set) Token: 0x06000211 RID: 529 RVA: 0x000035B6 File Offset: 0x000017B6
	public string Comment { get; set; }
}
