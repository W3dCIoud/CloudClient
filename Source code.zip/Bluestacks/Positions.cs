﻿using System;

// Token: 0x02000023 RID: 35
public enum Positions
{
	// Token: 0x04000110 RID: 272
	Up,
	// Token: 0x04000111 RID: 273
	Down,
	// Token: 0x04000112 RID: 274
	Left,
	// Token: 0x04000113 RID: 275
	Right,
	// Token: 0x04000114 RID: 276
	Center
}
