﻿using System;
using System.ComponentModel;
using System.Windows.Input;

// Token: 0x0200000D RID: 13
[Description("Independent")]
[Serializable]
public class Rotate : IMAction
{
	// Token: 0x1700006F RID: 111
	// (get) Token: 0x060000EB RID: 235 RVA: 0x000029C4 File Offset: 0x00000BC4
	// (set) Token: 0x060000EC RID: 236 RVA: 0x000029CC File Offset: 0x00000BCC
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double OriginX { get; set; } = -1.0;

	// Token: 0x17000070 RID: 112
	// (get) Token: 0x060000ED RID: 237 RVA: 0x000029D5 File Offset: 0x00000BD5
	// (set) Token: 0x060000EE RID: 238 RVA: 0x000029DD File Offset: 0x00000BDD
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double OriginY { get; set; } = -1.0;

	// Token: 0x17000071 RID: 113
	// (get) Token: 0x060000EF RID: 239 RVA: 0x000029E6 File Offset: 0x00000BE6
	// (set) Token: 0x060000F0 RID: 240 RVA: 0x000029EE File Offset: 0x00000BEE
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyClock { get; set; } = IMAPKeys.GetStringForFile(Key.X);

	// Token: 0x17000072 RID: 114
	// (get) Token: 0x060000F1 RID: 241 RVA: 0x000029F7 File Offset: 0x00000BF7
	// (set) Token: 0x060000F2 RID: 242 RVA: 0x000029FF File Offset: 0x00000BFF
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyAntiClock { get; set; } = IMAPKeys.GetStringForFile(Key.Z);

	// Token: 0x17000073 RID: 115
	// (get) Token: 0x060000F3 RID: 243 RVA: 0x00002A08 File Offset: 0x00000C08
	// (set) Token: 0x060000F4 RID: 244 RVA: 0x00002A10 File Offset: 0x00000C10
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyClock_alt1 { get; set; } = string.Empty;

	// Token: 0x17000074 RID: 116
	// (get) Token: 0x060000F5 RID: 245 RVA: 0x00002A19 File Offset: 0x00000C19
	// (set) Token: 0x060000F6 RID: 246 RVA: 0x00002A21 File Offset: 0x00000C21
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyAntiClock_alt1 { get; set; } = string.Empty;

	// Token: 0x17000075 RID: 117
	// (get) Token: 0x060000F7 RID: 247 RVA: 0x00002A2A File Offset: 0x00000C2A
	// (set) Token: 0x060000F8 RID: 248 RVA: 0x00002A32 File Offset: 0x00000C32
	[Description("IMAP_CanvasElementRadiusIMAP_PopupUIElement")]
	[Category("Fields")]
	public double XRadius { get; set; } = 6.0;

	// Token: 0x17000076 RID: 118
	// (get) Token: 0x060000F9 RID: 249 RVA: 0x00002A3B File Offset: 0x00000C3B
	// (set) Token: 0x060000FA RID: 250 RVA: 0x00002A43 File Offset: 0x00000C43
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int Speed { get; set; } = 60;

	// Token: 0x17000077 RID: 119
	// (get) Token: 0x060000FB RID: 251 RVA: 0x00002A4C File Offset: 0x00000C4C
	// (set) Token: 0x060000FC RID: 252 RVA: 0x00002A54 File Offset: 0x00000C54
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int ActivationTime { get; set; } = 100;

	// Token: 0x17000078 RID: 120
	// (get) Token: 0x060000FD RID: 253 RVA: 0x00002A5D File Offset: 0x00000C5D
	// (set) Token: 0x060000FE RID: 254 RVA: 0x00002A65 File Offset: 0x00000C65
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int Tweaks { get; set; } = 1;

	// Token: 0x17000079 RID: 121
	// (get) Token: 0x060000FF RID: 255 RVA: 0x00002A6E File Offset: 0x00000C6E
	// (set) Token: 0x06000100 RID: 256 RVA: 0x00002A76 File Offset: 0x00000C76
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double StartingAngle { get; set; } = 90.0;

	// Token: 0x1700007A RID: 122
	// (get) Token: 0x06000101 RID: 257 RVA: 0x00002A7F File Offset: 0x00000C7F
	// (set) Token: 0x06000102 RID: 258 RVA: 0x00002A87 File Offset: 0x00000C87
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool ShowOnOverlay
	{
		get
		{
			return this.mShowOnOverlay;
		}
		set
		{
			this.mShowOnOverlay = value;
		}
	}

	// Token: 0x0400007A RID: 122
	internal bool mShowOnOverlay = true;
}
