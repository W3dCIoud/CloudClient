﻿using System;
using System.ComponentModel;
using System.Windows.Input;

// Token: 0x0200001A RID: 26
[Description("Independent")]
[Serializable]
public class Tilt : IMAction
{
	// Token: 0x170000C2 RID: 194
	// (get) Token: 0x0600019C RID: 412 RVA: 0x000030F8 File Offset: 0x000012F8
	// (set) Token: 0x0600019D RID: 413 RVA: 0x00003100 File Offset: 0x00001300
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X
	{
		get
		{
			return this.mX;
		}
		set
		{
			this.mX = value;
		}
	}

	// Token: 0x170000C3 RID: 195
	// (get) Token: 0x0600019E RID: 414 RVA: 0x00003109 File Offset: 0x00001309
	// (set) Token: 0x0600019F RID: 415 RVA: 0x00003111 File Offset: 0x00001311
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y
	{
		get
		{
			return this.mY;
		}
		set
		{
			this.mY = value;
		}
	}

	// Token: 0x170000C4 RID: 196
	// (get) Token: 0x060001A0 RID: 416 RVA: 0x0000311A File Offset: 0x0000131A
	// (set) Token: 0x060001A1 RID: 417 RVA: 0x00003122 File Offset: 0x00001322
	[Description("IMAP_CanvasElementRadiusIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Radius
	{
		get
		{
			return this.mRadius;
		}
		set
		{
			this.mRadius = value;
		}
	}

	// Token: 0x170000C5 RID: 197
	// (get) Token: 0x060001A2 RID: 418 RVA: 0x0000312B File Offset: 0x0000132B
	// (set) Token: 0x060001A3 RID: 419 RVA: 0x00003133 File Offset: 0x00001333
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyUp
	{
		get
		{
			return this.mKeyUp;
		}
		set
		{
			this.mKeyUp = value;
		}
	}

	// Token: 0x170000C6 RID: 198
	// (get) Token: 0x060001A4 RID: 420 RVA: 0x0000313C File Offset: 0x0000133C
	// (set) Token: 0x060001A5 RID: 421 RVA: 0x00003144 File Offset: 0x00001344
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyUp_alt1
	{
		get
		{
			return this.mKeyUp_1;
		}
		set
		{
			this.mKeyUp_1 = value;
		}
	}

	// Token: 0x170000C7 RID: 199
	// (get) Token: 0x060001A6 RID: 422 RVA: 0x0000314D File Offset: 0x0000134D
	// (set) Token: 0x060001A7 RID: 423 RVA: 0x00003155 File Offset: 0x00001355
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyDown
	{
		get
		{
			return this.mKeyDown;
		}
		set
		{
			this.mKeyDown = value;
		}
	}

	// Token: 0x170000C8 RID: 200
	// (get) Token: 0x060001A8 RID: 424 RVA: 0x0000315E File Offset: 0x0000135E
	// (set) Token: 0x060001A9 RID: 425 RVA: 0x00003166 File Offset: 0x00001366
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyDown_alt1
	{
		get
		{
			return this.mKeyDown_1;
		}
		set
		{
			this.mKeyDown_1 = value;
		}
	}

	// Token: 0x170000C9 RID: 201
	// (get) Token: 0x060001AA RID: 426 RVA: 0x0000316F File Offset: 0x0000136F
	// (set) Token: 0x060001AB RID: 427 RVA: 0x00003177 File Offset: 0x00001377
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyLeft
	{
		get
		{
			return this.mKeyLeft;
		}
		set
		{
			this.mKeyLeft = value;
		}
	}

	// Token: 0x170000CA RID: 202
	// (get) Token: 0x060001AC RID: 428 RVA: 0x00003180 File Offset: 0x00001380
	// (set) Token: 0x060001AD RID: 429 RVA: 0x00003188 File Offset: 0x00001388
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyLeft_alt1
	{
		get
		{
			return this.mKeyLeft_1;
		}
		set
		{
			this.mKeyLeft_1 = value;
		}
	}

	// Token: 0x170000CB RID: 203
	// (get) Token: 0x060001AE RID: 430 RVA: 0x00003191 File Offset: 0x00001391
	// (set) Token: 0x060001AF RID: 431 RVA: 0x00003199 File Offset: 0x00001399
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyRight
	{
		get
		{
			return this.mKeyRight;
		}
		set
		{
			this.mKeyRight = value;
		}
	}

	// Token: 0x170000CC RID: 204
	// (get) Token: 0x060001B0 RID: 432 RVA: 0x000031A2 File Offset: 0x000013A2
	// (set) Token: 0x060001B1 RID: 433 RVA: 0x000031AA File Offset: 0x000013AA
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyRight_alt1
	{
		get
		{
			return this.mKeyRight_1;
		}
		set
		{
			this.mKeyRight_1 = value;
		}
	}

	// Token: 0x170000CD RID: 205
	// (get) Token: 0x060001B2 RID: 434 RVA: 0x000031B3 File Offset: 0x000013B3
	// (set) Token: 0x060001B3 RID: 435 RVA: 0x000031BB File Offset: 0x000013BB
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double MaxAngle
	{
		get
		{
			return this.mMaxAngle;
		}
		set
		{
			this.mMaxAngle = value;
		}
	}

	// Token: 0x170000CE RID: 206
	// (get) Token: 0x060001B4 RID: 436 RVA: 0x000031C4 File Offset: 0x000013C4
	// (set) Token: 0x060001B5 RID: 437 RVA: 0x000031CC File Offset: 0x000013CC
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Speed
	{
		get
		{
			return this.mSpeed;
		}
		set
		{
			this.mSpeed = value;
		}
	}

	// Token: 0x170000CF RID: 207
	// (get) Token: 0x060001B6 RID: 438 RVA: 0x000031D5 File Offset: 0x000013D5
	// (set) Token: 0x060001B7 RID: 439 RVA: 0x000031DD File Offset: 0x000013DD
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool AutoReset
	{
		get
		{
			return this.mAutoReset;
		}
		set
		{
			this.mAutoReset = value;
		}
	}

	// Token: 0x040000BB RID: 187
	private double mX = -1.0;

	// Token: 0x040000BC RID: 188
	private double mY = -1.0;

	// Token: 0x040000BD RID: 189
	private double mRadius = 10.0;

	// Token: 0x040000BE RID: 190
	private string mKeyUp = IMAPKeys.GetStringForFile(Key.Up);

	// Token: 0x040000BF RID: 191
	private string mKeyUp_1 = string.Empty;

	// Token: 0x040000C0 RID: 192
	private string mKeyDown = IMAPKeys.GetStringForFile(Key.Down);

	// Token: 0x040000C1 RID: 193
	private string mKeyDown_1 = string.Empty;

	// Token: 0x040000C2 RID: 194
	private string mKeyLeft = IMAPKeys.GetStringForFile(Key.Left);

	// Token: 0x040000C3 RID: 195
	private string mKeyLeft_1 = string.Empty;

	// Token: 0x040000C4 RID: 196
	private string mKeyRight = IMAPKeys.GetStringForFile(Key.Right);

	// Token: 0x040000C5 RID: 197
	private string mKeyRight_1 = string.Empty;

	// Token: 0x040000C6 RID: 198
	private double mMaxAngle = 20.0;

	// Token: 0x040000C7 RID: 199
	private double mSpeed = 90.0;

	// Token: 0x040000C8 RID: 200
	private bool mAutoReset = true;
}
