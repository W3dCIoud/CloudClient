﻿using System;
using System.ComponentModel;
using System.Windows.Input;

// Token: 0x0200000E RID: 14
[Description("ParentElement")]
[Serializable]
public class Pan : IMAction
{
	// Token: 0x1700007B RID: 123
	// (get) Token: 0x06000104 RID: 260 RVA: 0x00002A90 File Offset: 0x00000C90
	// (set) Token: 0x06000105 RID: 261 RVA: 0x00002A98 File Offset: 0x00000C98
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X
	{
		get
		{
			return this.mX;
		}
		set
		{
			this.mX = value;
		}
	}

	// Token: 0x1700007C RID: 124
	// (get) Token: 0x06000106 RID: 262 RVA: 0x00002AA1 File Offset: 0x00000CA1
	// (set) Token: 0x06000107 RID: 263 RVA: 0x00002AA9 File Offset: 0x00000CA9
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y
	{
		get
		{
			return this.mY;
		}
		set
		{
			this.mY = value;
		}
	}

	// Token: 0x1700007D RID: 125
	// (get) Token: 0x06000108 RID: 264 RVA: 0x00002AB2 File Offset: 0x00000CB2
	// (set) Token: 0x06000109 RID: 265 RVA: 0x00002ABA File Offset: 0x00000CBA
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyStartStop
	{
		get
		{
			return this.mKeyStartStop;
		}
		set
		{
			this.mKeyStartStop = value;
		}
	}

	// Token: 0x1700007E RID: 126
	// (get) Token: 0x0600010A RID: 266 RVA: 0x00002AC3 File Offset: 0x00000CC3
	// (set) Token: 0x0600010B RID: 267 RVA: 0x00002ACB File Offset: 0x00000CCB
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyStartStop_alt1
	{
		get
		{
			return this.mKeyStartStop_1;
		}
		set
		{
			this.mKeyStartStop_1 = value;
		}
	}

	// Token: 0x1700007F RID: 127
	// (get) Token: 0x0600010C RID: 268 RVA: 0x00002AD4 File Offset: 0x00000CD4
	// (set) Token: 0x0600010D RID: 269 RVA: 0x00002ADC File Offset: 0x00000CDC
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeySuspend
	{
		get
		{
			return this.mKeySuspend;
		}
		set
		{
			this.mKeySuspend = value;
		}
	}

	// Token: 0x17000080 RID: 128
	// (get) Token: 0x0600010E RID: 270 RVA: 0x00002AE5 File Offset: 0x00000CE5
	// (set) Token: 0x0600010F RID: 271 RVA: 0x00002AED File Offset: 0x00000CED
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeySuspend_alt1
	{
		get
		{
			return this.mKeySuspend_1;
		}
		set
		{
			this.mKeySuspend_1 = value;
		}
	}

	// Token: 0x17000081 RID: 129
	// (get) Token: 0x06000110 RID: 272 RVA: 0x00002AF6 File Offset: 0x00000CF6
	// (set) Token: 0x06000111 RID: 273 RVA: 0x00002AFE File Offset: 0x00000CFE
	public double LookAroundX
	{
		get
		{
			return this.mLookAroundX;
		}
		set
		{
			this.mLookAroundX = value;
			this.CheckLookAround();
		}
	}

	// Token: 0x17000082 RID: 130
	// (get) Token: 0x06000112 RID: 274 RVA: 0x00002B0D File Offset: 0x00000D0D
	// (set) Token: 0x06000113 RID: 275 RVA: 0x00002B15 File Offset: 0x00000D15
	public double LookAroundY
	{
		get
		{
			return this.mLookAroundY;
		}
		set
		{
			this.mLookAroundY = value;
			this.CheckLookAround();
		}
	}

	// Token: 0x17000083 RID: 131
	// (get) Token: 0x06000114 RID: 276 RVA: 0x00002B24 File Offset: 0x00000D24
	// (set) Token: 0x06000115 RID: 277 RVA: 0x00002B2C File Offset: 0x00000D2C
	public string KeyLookAround
	{
		get
		{
			return this.mKeyLookAround;
		}
		set
		{
			this.mKeyLookAround = value;
		}
	}

	// Token: 0x17000084 RID: 132
	// (get) Token: 0x06000116 RID: 278 RVA: 0x00002B35 File Offset: 0x00000D35
	// (set) Token: 0x06000117 RID: 279 RVA: 0x00002B3D File Offset: 0x00000D3D
	public double LButtonX
	{
		get
		{
			return this.mLButtonX;
		}
		set
		{
			this.mLButtonX = value;
			this.CheckShootOnClick();
		}
	}

	// Token: 0x17000085 RID: 133
	// (get) Token: 0x06000118 RID: 280 RVA: 0x00002B4C File Offset: 0x00000D4C
	// (set) Token: 0x06000119 RID: 281 RVA: 0x00002B54 File Offset: 0x00000D54
	public double LButtonY
	{
		get
		{
			return this.mLButtonY;
		}
		set
		{
			this.mLButtonY = value;
			this.CheckShootOnClick();
		}
	}

	// Token: 0x17000086 RID: 134
	// (get) Token: 0x0600011A RID: 282 RVA: 0x00002B63 File Offset: 0x00000D63
	internal string KeyAction
	{
		get
		{
			return this.mKeyAction;
		}
	}

	// Token: 0x17000087 RID: 135
	// (get) Token: 0x0600011B RID: 283 RVA: 0x00002B6B File Offset: 0x00000D6B
	// (set) Token: 0x0600011C RID: 284 RVA: 0x00002B73 File Offset: 0x00000D73
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Sensitivity
	{
		get
		{
			return this.mSensitivity;
		}
		set
		{
			this.mSensitivity = value;
		}
	}

	// Token: 0x17000088 RID: 136
	// (get) Token: 0x0600011D RID: 285 RVA: 0x00002B7C File Offset: 0x00000D7C
	// (set) Token: 0x0600011E RID: 286 RVA: 0x00002B84 File Offset: 0x00000D84
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int Tweaks
	{
		get
		{
			return this.mTweaks;
		}
		set
		{
			this.mTweaks = value;
		}
	}

	// Token: 0x17000089 RID: 137
	// (get) Token: 0x0600011F RID: 287 RVA: 0x00002B8D File Offset: 0x00000D8D
	// (set) Token: 0x06000120 RID: 288 RVA: 0x00002B95 File Offset: 0x00000D95
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double SensitivityRatioY
	{
		get
		{
			return this.mSensitivityRatioY;
		}
		set
		{
			this.mSensitivityRatioY = value;
		}
	}

	// Token: 0x1700008A RID: 138
	// (get) Token: 0x06000121 RID: 289 RVA: 0x00002B9E File Offset: 0x00000D9E
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	internal bool IsLookAroundEnabled
	{
		get
		{
			return this.mLookAround != null;
		}
	}

	// Token: 0x1700008B RID: 139
	// (get) Token: 0x06000122 RID: 290 RVA: 0x00002BA9 File Offset: 0x00000DA9
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	internal bool IsShootOnClickEnabled
	{
		get
		{
			return this.mPanShoot != null;
		}
	}

	// Token: 0x06000123 RID: 291 RVA: 0x00002BB4 File Offset: 0x00000DB4
	private void CheckLookAround()
	{
		if (this.mLookAroundX == -1.0 && this.mLookAroundY == -1.0)
		{
			this.mLookAround = null;
			return;
		}
		if (this.mLookAround == null)
		{
			this.mLookAround = new LookAround(this);
		}
	}

	// Token: 0x06000124 RID: 292 RVA: 0x00002BF4 File Offset: 0x00000DF4
	private void CheckShootOnClick()
	{
		if (this.mLButtonX == -1.0 && this.mLButtonY == -1.0)
		{
			this.mPanShoot = null;
			return;
		}
		if (this.mPanShoot == null)
		{
			this.mPanShoot = new PanShoot(this);
		}
	}

	// Token: 0x1700008C RID: 140
	// (get) Token: 0x06000125 RID: 293 RVA: 0x00002C34 File Offset: 0x00000E34
	// (set) Token: 0x06000126 RID: 294 RVA: 0x00002C3C File Offset: 0x00000E3C
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool ShowOnOverlay
	{
		get
		{
			return this.mShowOnOverlay;
		}
		set
		{
			this.mShowOnOverlay = value;
		}
	}

	// Token: 0x1700008D RID: 141
	// (get) Token: 0x06000127 RID: 295 RVA: 0x00002C45 File Offset: 0x00000E45
	// (set) Token: 0x06000128 RID: 296 RVA: 0x00002C4D File Offset: 0x00000E4D
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool MouseAcceleration
	{
		get
		{
			return this.mMouseAcceleration;
		}
		set
		{
			this.mMouseAcceleration = value;
		}
	}

	// Token: 0x1700008E RID: 142
	// (get) Token: 0x06000129 RID: 297 RVA: 0x00002C56 File Offset: 0x00000E56
	// (set) Token: 0x0600012A RID: 298 RVA: 0x00002C5E File Offset: 0x00000E5E
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string GamepadStick
	{
		get
		{
			return this.mGamepadStick;
		}
		set
		{
			this.mGamepadStick = value;
		}
	}

	// Token: 0x1700008F RID: 143
	// (get) Token: 0x0600012B RID: 299 RVA: 0x00002C67 File Offset: 0x00000E67
	// (set) Token: 0x0600012C RID: 300 RVA: 0x00002C6F File Offset: 0x00000E6F
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double GamepadSensitivity
	{
		get
		{
			return this.mGamepadSensitivity;
		}
		set
		{
			this.mGamepadSensitivity = value;
		}
	}

	// Token: 0x0400007B RID: 123
	internal LookAround mLookAround;

	// Token: 0x0400007C RID: 124
	internal PanShoot mPanShoot;

	// Token: 0x0400007D RID: 125
	private double mX = -1.0;

	// Token: 0x0400007E RID: 126
	private double mY = -1.0;

	// Token: 0x0400007F RID: 127
	private string mKeyStartStop = IMAPKeys.GetStringForFile(Key.F1);

	// Token: 0x04000080 RID: 128
	private string mKeyStartStop_1 = string.Empty;

	// Token: 0x04000081 RID: 129
	private string mKeySuspend = IMAPKeys.GetStringForFile(Key.LeftAlt);

	// Token: 0x04000082 RID: 130
	private string mKeySuspend_1 = string.Empty;

	// Token: 0x04000083 RID: 131
	private double mLookAroundX = -1.0;

	// Token: 0x04000084 RID: 132
	private double mLookAroundY = -1.0;

	// Token: 0x04000085 RID: 133
	private string mKeyLookAround = IMAPKeys.GetStringForFile(Key.V);

	// Token: 0x04000086 RID: 134
	private double mLButtonX = -1.0;

	// Token: 0x04000087 RID: 135
	private double mLButtonY = -1.0;

	// Token: 0x04000088 RID: 136
	private string mKeyAction = "MouseLButton";

	// Token: 0x04000089 RID: 137
	private double mSensitivity = 1.0;

	// Token: 0x0400008A RID: 138
	private int mTweaks;

	// Token: 0x0400008B RID: 139
	private double mSensitivityRatioY = 1.0;

	// Token: 0x0400008C RID: 140
	internal bool mShowOnOverlay = true;

	// Token: 0x0400008D RID: 141
	private bool mMouseAcceleration;

	// Token: 0x0400008E RID: 142
	private string mGamepadStick = "";

	// Token: 0x0400008F RID: 143
	private double mGamepadSensitivity = 1.0;
}
