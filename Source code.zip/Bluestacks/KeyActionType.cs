﻿using System;

// Token: 0x02000021 RID: 33
public enum KeyActionType
{
	// Token: 0x040000F4 RID: 244
	Alias,
	// Token: 0x040000F5 RID: 245
	Tap,
	// Token: 0x040000F6 RID: 246
	Swipe,
	// Token: 0x040000F7 RID: 247
	Dpad,
	// Token: 0x040000F8 RID: 248
	Zoom,
	// Token: 0x040000F9 RID: 249
	Tilt,
	// Token: 0x040000FA RID: 250
	Pan,
	// Token: 0x040000FB RID: 251
	MOBADpad,
	// Token: 0x040000FC RID: 252
	MOBASkill,
	// Token: 0x040000FD RID: 253
	Raw,
	// Token: 0x040000FE RID: 254
	KeyInput,
	// Token: 0x040000FF RID: 255
	SendOriginalKeys,
	// Token: 0x04000100 RID: 256
	Script,
	// Token: 0x04000101 RID: 257
	TapRepeat,
	// Token: 0x04000102 RID: 258
	Rotate,
	// Token: 0x04000103 RID: 259
	State,
	// Token: 0x04000104 RID: 260
	FreeLook,
	// Token: 0x04000105 RID: 261
	DontForwardKeys,
	// Token: 0x04000106 RID: 262
	MouseZoom,
	// Token: 0x04000107 RID: 263
	LookAround = 100,
	// Token: 0x04000108 RID: 264
	PanShoot,
	// Token: 0x04000109 RID: 265
	MOBASkillCancel
}
