﻿using System;
using System.Collections.Generic;

// Token: 0x02000025 RID: 37
public static class ShowImagesOnOverlay
{
	// Token: 0x170000F2 RID: 242
	// (get) Token: 0x06000213 RID: 531 RVA: 0x000035D2 File Offset: 0x000017D2
	public static List<string> ListShowImagesForKeys { get; } = new List<string>
	{
		"MouseLButton",
		"MouseRButton",
		"MouseMButton",
		"Left",
		"Up",
		"Right",
		"Down",
		"GamepadDpadUp",
		"GamepadDpadDown",
		"GamepadDpadLeft",
		"GamepadDpadRight"
	};
}
