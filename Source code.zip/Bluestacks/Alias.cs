﻿using System;

// Token: 0x02000007 RID: 7
[Serializable]
public class Alias : IMAction
{
	// Token: 0x17000030 RID: 48
	// (get) Token: 0x06000068 RID: 104 RVA: 0x00002488 File Offset: 0x00000688
	// (set) Token: 0x06000069 RID: 105 RVA: 0x00002490 File Offset: 0x00000690
	public string KeyIn
	{
		get
		{
			return this.mKeyIn;
		}
		set
		{
			this.mKeyIn = value;
		}
	}

	// Token: 0x17000031 RID: 49
	// (get) Token: 0x0600006A RID: 106 RVA: 0x00002499 File Offset: 0x00000699
	// (set) Token: 0x0600006B RID: 107 RVA: 0x000024A1 File Offset: 0x000006A1
	public string KeyOut
	{
		get
		{
			return this.mKeyOut;
		}
		set
		{
			this.mKeyOut = value;
		}
	}

	// Token: 0x04000033 RID: 51
	private string mKeyIn;

	// Token: 0x04000034 RID: 52
	private string mKeyOut;
}
