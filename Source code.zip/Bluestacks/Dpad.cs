﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Windows.Input;
using BlueStacks.BlueStacksUI;
using BlueStacks.Common;
using Newtonsoft.Json;

// Token: 0x02000008 RID: 8
[Description("Independent")]
[Serializable]
public class Dpad : IMAction
{
	// Token: 0x0600006D RID: 109 RVA: 0x0001129C File Offset: 0x0000F49C
	public Dpad()
	{
		base.Type = KeyActionType.Dpad;
		Dpad.sListDpad.Add(this);
	}

	// Token: 0x17000032 RID: 50
	// (get) Token: 0x0600006E RID: 110 RVA: 0x000024B2 File Offset: 0x000006B2
	// (set) Token: 0x0600006F RID: 111 RVA: 0x000024BA File Offset: 0x000006BA
	[Description("IMAP_CanvasElementYIMAP_PopupUIElement")]
	[Category("Fields")]
	public double X
	{
		get
		{
			return this.mX;
		}
		set
		{
			this.mX = value;
			if (this.IsMOBADpadEnabled)
			{
				this.mMOBADpad.X = value;
			}
		}
	}

	// Token: 0x17000033 RID: 51
	// (get) Token: 0x06000070 RID: 112 RVA: 0x000024D7 File Offset: 0x000006D7
	// (set) Token: 0x06000071 RID: 113 RVA: 0x000024DF File Offset: 0x000006DF
	[Description("IMAP_CanvasElementXIMAP_PopupUIElement")]
	[Category("Fields")]
	public double Y
	{
		get
		{
			return this.mY;
		}
		set
		{
			this.mY = value;
			if (this.IsMOBADpadEnabled)
			{
				this.mMOBADpad.Y = value;
			}
		}
	}

	// Token: 0x17000034 RID: 52
	// (get) Token: 0x06000072 RID: 114 RVA: 0x000024FC File Offset: 0x000006FC
	// (set) Token: 0x06000073 RID: 115 RVA: 0x00002504 File Offset: 0x00000704
	[Description("IMAP_CanvasElementRadiusIMAP_PopupUIElement")]
	[Category("Fields")]
	public double XRadius { get; set; } = 6.0;

	// Token: 0x17000035 RID: 53
	// (get) Token: 0x06000074 RID: 116 RVA: 0x0001137C File Offset: 0x0000F57C
	[JsonIgnore]
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string DpadTitle
	{
		get
		{
			return string.Concat(new string[]
			{
				LocaleStrings.GetLocalizedString(KMManager.GetStringsToShowInUI(this.KeyUp.ToString(CultureInfo.InvariantCulture))),
				" ",
				LocaleStrings.GetLocalizedString(KMManager.GetStringsToShowInUI(this.KeyLeft.ToString(CultureInfo.InvariantCulture))),
				" ",
				LocaleStrings.GetLocalizedString(KMManager.GetStringsToShowInUI(this.KeyDown.ToString(CultureInfo.InvariantCulture))),
				" ",
				LocaleStrings.GetLocalizedString(KMManager.GetStringsToShowInUI(this.KeyRight.ToString(CultureInfo.InvariantCulture)))
			}).Trim();
		}
	}

	// Token: 0x17000036 RID: 54
	// (get) Token: 0x06000075 RID: 117 RVA: 0x0000250D File Offset: 0x0000070D
	// (set) Token: 0x06000076 RID: 118 RVA: 0x00002515 File Offset: 0x00000715
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyUp { get; set; } = IMAPKeys.GetStringForFile(Key.W);

	// Token: 0x17000037 RID: 55
	// (get) Token: 0x06000077 RID: 119 RVA: 0x0000251E File Offset: 0x0000071E
	// (set) Token: 0x06000078 RID: 120 RVA: 0x00002526 File Offset: 0x00000726
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyUp_alt1 { get; set; } = string.Empty;

	// Token: 0x17000038 RID: 56
	// (get) Token: 0x06000079 RID: 121 RVA: 0x0000252F File Offset: 0x0000072F
	// (set) Token: 0x0600007A RID: 122 RVA: 0x00002537 File Offset: 0x00000737
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyLeft { get; set; } = IMAPKeys.GetStringForFile(Key.A);

	// Token: 0x17000039 RID: 57
	// (get) Token: 0x0600007B RID: 123 RVA: 0x00002540 File Offset: 0x00000740
	// (set) Token: 0x0600007C RID: 124 RVA: 0x00002548 File Offset: 0x00000748
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyLeft_alt1 { get; set; } = string.Empty;

	// Token: 0x1700003A RID: 58
	// (get) Token: 0x0600007D RID: 125 RVA: 0x00002551 File Offset: 0x00000751
	// (set) Token: 0x0600007E RID: 126 RVA: 0x00002559 File Offset: 0x00000759
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyDown { get; set; } = IMAPKeys.GetStringForFile(Key.S);

	// Token: 0x1700003B RID: 59
	// (get) Token: 0x0600007F RID: 127 RVA: 0x00002562 File Offset: 0x00000762
	// (set) Token: 0x06000080 RID: 128 RVA: 0x0000256A File Offset: 0x0000076A
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyDown_alt1 { get; set; } = string.Empty;

	// Token: 0x1700003C RID: 60
	// (get) Token: 0x06000081 RID: 129 RVA: 0x00002573 File Offset: 0x00000773
	// (set) Token: 0x06000082 RID: 130 RVA: 0x0000257B File Offset: 0x0000077B
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyRight { get; set; } = IMAPKeys.GetStringForFile(Key.D);

	// Token: 0x1700003D RID: 61
	// (get) Token: 0x06000083 RID: 131 RVA: 0x00002584 File Offset: 0x00000784
	// (set) Token: 0x06000084 RID: 132 RVA: 0x0000258C File Offset: 0x0000078C
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeyRight_alt1 { get; set; } = string.Empty;

	// Token: 0x1700003E RID: 62
	// (get) Token: 0x06000085 RID: 133 RVA: 0x00002595 File Offset: 0x00000795
	// (set) Token: 0x06000086 RID: 134 RVA: 0x0000259D File Offset: 0x0000079D
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string GamepadStick { get; set; } = "";

	// Token: 0x1700003F RID: 63
	// (get) Token: 0x06000087 RID: 135 RVA: 0x000025A6 File Offset: 0x000007A6
	// (set) Token: 0x06000088 RID: 136 RVA: 0x000025AE File Offset: 0x000007AE
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeySpeedModifier1 { get; set; }

	// Token: 0x17000040 RID: 64
	// (get) Token: 0x06000089 RID: 137 RVA: 0x000025B7 File Offset: 0x000007B7
	// (set) Token: 0x0600008A RID: 138 RVA: 0x000025BF File Offset: 0x000007BF
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeySpeedModifier1_alt1 { get; set; }

	// Token: 0x17000041 RID: 65
	// (get) Token: 0x0600008B RID: 139 RVA: 0x000025C8 File Offset: 0x000007C8
	// (set) Token: 0x0600008C RID: 140 RVA: 0x000025D0 File Offset: 0x000007D0
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double XRadius1 { get; set; }

	// Token: 0x17000042 RID: 66
	// (get) Token: 0x0600008D RID: 141 RVA: 0x000025D9 File Offset: 0x000007D9
	// (set) Token: 0x0600008E RID: 142 RVA: 0x000025E1 File Offset: 0x000007E1
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeySpeedModifier2 { get; set; }

	// Token: 0x17000043 RID: 67
	// (get) Token: 0x0600008F RID: 143 RVA: 0x000025EA File Offset: 0x000007EA
	// (set) Token: 0x06000090 RID: 144 RVA: 0x000025F2 File Offset: 0x000007F2
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public string KeySpeedModifier2_alt1 { get; set; }

	// Token: 0x17000044 RID: 68
	// (get) Token: 0x06000091 RID: 145 RVA: 0x000025FB File Offset: 0x000007FB
	// (set) Token: 0x06000092 RID: 146 RVA: 0x00002603 File Offset: 0x00000803
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double XRadius2 { get; set; }

	// Token: 0x17000045 RID: 69
	// (get) Token: 0x06000093 RID: 147 RVA: 0x0000260C File Offset: 0x0000080C
	// (set) Token: 0x06000094 RID: 148 RVA: 0x00002614 File Offset: 0x00000814
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double Speed { get; set; } = 200.0;

	// Token: 0x17000046 RID: 70
	// (get) Token: 0x06000095 RID: 149 RVA: 0x0000261D File Offset: 0x0000081D
	// (set) Token: 0x06000096 RID: 150 RVA: 0x00002625 File Offset: 0x00000825
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public int ActivationTime { get; set; }

	// Token: 0x17000047 RID: 71
	// (get) Token: 0x06000097 RID: 151 RVA: 0x0000262E File Offset: 0x0000082E
	// (set) Token: 0x06000098 RID: 152 RVA: 0x00002636 File Offset: 0x00000836
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public double ActivationSpeed { get; set; }

	// Token: 0x17000048 RID: 72
	// (get) Token: 0x06000099 RID: 153 RVA: 0x0000263F File Offset: 0x0000083F
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	internal bool IsMOBADpadEnabled
	{
		get
		{
			return this.mMOBADpad.OriginX != -1.0 && this.mMOBADpad.OriginY != -1.0;
		}
	}

	// Token: 0x17000049 RID: 73
	// (get) Token: 0x0600009A RID: 154 RVA: 0x00002672 File Offset: 0x00000872
	// (set) Token: 0x0600009B RID: 155 RVA: 0x0000267A File Offset: 0x0000087A
	[Description("IMAP_PopupUIElement")]
	[Category("Fields")]
	public bool ShowOnOverlay
	{
		get
		{
			return this.mShowOnOverlay;
		}
		set
		{
			this.mShowOnOverlay = value;
		}
	}

	// Token: 0x04000035 RID: 53
	internal static List<Dpad> sListDpad = new List<Dpad>();

	// Token: 0x04000036 RID: 54
	internal MOBADpad mMOBADpad = new MOBADpad();

	// Token: 0x04000037 RID: 55
	private double mX = -1.0;

	// Token: 0x04000038 RID: 56
	private double mY = -1.0;

	// Token: 0x0400004C RID: 76
	internal bool mShowOnOverlay = true;
}
