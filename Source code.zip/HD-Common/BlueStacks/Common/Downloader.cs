﻿using System;
using System.Globalization;
using System.IO;
using System.Net;
using System.Reflection;
using System.Threading;

namespace BlueStacks.Common
{
	// Token: 0x02000196 RID: 406
	public class Downloader
	{
		// Token: 0x1400000F RID: 15
		// (add) Token: 0x06000DBE RID: 3518 RVA: 0x0003627C File Offset: 0x0003447C
		// (remove) Token: 0x06000DBF RID: 3519 RVA: 0x000362B4 File Offset: 0x000344B4
		public event Downloader.DownloadRetryEventHandler DownloadRetry;

		// Token: 0x14000010 RID: 16
		// (add) Token: 0x06000DC0 RID: 3520 RVA: 0x000362EC File Offset: 0x000344EC
		// (remove) Token: 0x06000DC1 RID: 3521 RVA: 0x00036324 File Offset: 0x00034524
		public event Downloader.DownloadExceptionEventHandler DownloadException;

		// Token: 0x14000011 RID: 17
		// (add) Token: 0x06000DC2 RID: 3522 RVA: 0x0003635C File Offset: 0x0003455C
		// (remove) Token: 0x06000DC3 RID: 3523 RVA: 0x00036394 File Offset: 0x00034594
		public event Downloader.UnsupportedResumeEventHandler UnsupportedResume;

		// Token: 0x14000012 RID: 18
		// (add) Token: 0x06000DC4 RID: 3524 RVA: 0x000363CC File Offset: 0x000345CC
		// (remove) Token: 0x06000DC5 RID: 3525 RVA: 0x00036404 File Offset: 0x00034604
		public event Downloader.FilePayloadInfoReceivedHandler FilePayloadInfoReceived;

		// Token: 0x14000013 RID: 19
		// (add) Token: 0x06000DC6 RID: 3526 RVA: 0x0003643C File Offset: 0x0003463C
		// (remove) Token: 0x06000DC7 RID: 3527 RVA: 0x00036474 File Offset: 0x00034674
		public event Downloader.DownloadFileCompletedEventHandler DownloadFileCompleted;

		// Token: 0x14000014 RID: 20
		// (add) Token: 0x06000DC8 RID: 3528 RVA: 0x000364AC File Offset: 0x000346AC
		// (remove) Token: 0x06000DC9 RID: 3529 RVA: 0x000364E4 File Offset: 0x000346E4
		public event Downloader.DownloadProgressChangedEventHandler DownloadProgressChanged;

		// Token: 0x14000015 RID: 21
		// (add) Token: 0x06000DCA RID: 3530 RVA: 0x0003651C File Offset: 0x0003471C
		// (remove) Token: 0x06000DCB RID: 3531 RVA: 0x00036554 File Offset: 0x00034754
		public event Downloader.DownloadProgressPercentChangedEventHandler DownloadProgressPercentChanged;

		// Token: 0x06000DCC RID: 3532 RVA: 0x0000C79D File Offset: 0x0000A99D
		protected virtual void OnDownloadProgressChanged(long bytes)
		{
			Downloader.DownloadProgressChangedEventHandler downloadProgressChanged = this.DownloadProgressChanged;
			if (downloadProgressChanged == null)
			{
				return;
			}
			downloadProgressChanged(bytes);
		}

		// Token: 0x06000DCD RID: 3533 RVA: 0x0000C7B0 File Offset: 0x0000A9B0
		protected virtual void OnDownloadPercentProgressChanged(double percent)
		{
			Downloader.DownloadProgressPercentChangedEventHandler downloadProgressPercentChanged = this.DownloadProgressPercentChanged;
			if (downloadProgressPercentChanged == null)
			{
				return;
			}
			downloadProgressPercentChanged(percent);
		}

		// Token: 0x06000DCE RID: 3534 RVA: 0x0000C7C3 File Offset: 0x0000A9C3
		protected virtual void OnDownloadException(Exception e)
		{
			Downloader.DownloadExceptionEventHandler downloadException = this.DownloadException;
			if (downloadException == null)
			{
				return;
			}
			downloadException(e);
		}

		// Token: 0x06000DCF RID: 3535 RVA: 0x0000C7D6 File Offset: 0x0000A9D6
		protected virtual void OnDownloadFileCompleted()
		{
			Downloader.DownloadFileCompletedEventHandler downloadFileCompleted = this.DownloadFileCompleted;
			if (downloadFileCompleted == null)
			{
				return;
			}
			downloadFileCompleted(this, new EventArgs());
		}

		// Token: 0x06000DD0 RID: 3536 RVA: 0x0000C7EE File Offset: 0x0000A9EE
		protected virtual void OnFilePayloadInfoReceived(long size)
		{
			Downloader.FilePayloadInfoReceivedHandler filePayloadInfoReceived = this.FilePayloadInfoReceived;
			if (filePayloadInfoReceived == null)
			{
				return;
			}
			filePayloadInfoReceived(size);
		}

		// Token: 0x06000DD1 RID: 3537 RVA: 0x0000C801 File Offset: 0x0000AA01
		protected virtual void OnUnsupportedResume(HttpStatusCode code)
		{
			Downloader.UnsupportedResumeEventHandler unsupportedResume = this.UnsupportedResume;
			if (unsupportedResume == null)
			{
				return;
			}
			unsupportedResume(code);
		}

		// Token: 0x06000DD2 RID: 3538 RVA: 0x0000C814 File Offset: 0x0000AA14
		protected virtual void OnDownloadRetryEvent()
		{
			Downloader.DownloadRetryEventHandler downloadRetry = this.DownloadRetry;
			if (downloadRetry == null)
			{
				return;
			}
			downloadRetry(this, new EventArgs());
		}

		// Token: 0x06000DD3 RID: 3539 RVA: 0x0003658C File Offset: 0x0003478C
		public void DownloadFile(string url, string fileDestination)
		{
			FileStream fileStream = null;
			HttpWebRequest httpWebRequest = null;
			HttpWebResponse httpWebResponse = null;
			try
			{
				if (File.Exists(fileDestination))
				{
					Logger.Info("{0} already downloaded to {1}", new object[]
					{
						url,
						fileDestination
					});
					this.OnDownloadFileCompleted();
				}
				else
				{
					string text = fileDestination + ".tmp";
					try
					{
						fileStream = new FileStream(text, FileMode.Append, FileAccess.Write, FileShare.None);
					}
					catch (Exception e)
					{
						this.OnDownloadException(e);
						return;
					}
					long num = fileStream.Length;
					int num2 = 0;
					for (;;)
					{
						long num3 = num;
						try
						{
							httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
							Downloader.AddRangeToRequest(httpWebRequest, string.Format(CultureInfo.InvariantCulture, "{0}-", new object[]
							{
								num
							}), "bytes");
							httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
						}
						catch (WebException ex)
						{
							HttpStatusCode statusCode = ((HttpWebResponse)ex.Response).StatusCode;
							if (statusCode == HttpStatusCode.RequestedRangeNotSatisfiable)
							{
								Logger.Warning("Unsupported resume! {0}", new object[]
								{
									statusCode
								});
								if (fileStream != null)
								{
									fileStream.Close();
								}
								this.OnUnsupportedResume(statusCode);
								return;
							}
							Logger.Warning("An error occured while creating a request. WebEx: {0}", new object[]
							{
								ex.Message
							});
							goto IL_30D;
						}
						catch (Exception ex2)
						{
							Logger.Warning("An error occured while creating a request. Ex: {0}", new object[]
							{
								ex2.Message
							});
							goto IL_30D;
						}
						goto IL_13C;
						IL_30D:
						this.OnDownloadRetryEvent();
						if (num3 == num)
						{
							num2++;
						}
						if (num2 == 20)
						{
							this.OnDownloadException(new UnknownErrorException());
						}
						if (httpWebRequest != null)
						{
							httpWebRequest.Abort();
						}
						httpWebRequest = null;
						if (httpWebResponse != null)
						{
							httpWebResponse.Close();
						}
						httpWebResponse = null;
						int num4;
						if (num2 > 10)
						{
							num4 = 1800;
						}
						else
						{
							num4 = Convert.ToInt32(Math.Pow(2.0, (double)num2));
						}
						Logger.Info("Will retry after {0}s", new object[]
						{
							num4
						});
						Thread.Sleep(num4 * 1000);
						continue;
						IL_13C:
						if (httpWebResponse.StatusCode != HttpStatusCode.PartialContent && httpWebResponse.StatusCode != HttpStatusCode.OK)
						{
							Logger.Warning("Got an unexpected status code: {0}", new object[]
							{
								httpWebResponse.StatusCode
							});
							goto IL_30D;
						}
						if (num != 0L && httpWebResponse.StatusCode != HttpStatusCode.PartialContent)
						{
							break;
						}
						long num5 = httpWebResponse.ContentLength + num;
						this.OnFilePayloadInfoReceived(num5);
						Stream responseStream;
						try
						{
							responseStream = httpWebResponse.GetResponseStream();
						}
						catch (Exception ex3)
						{
							Logger.Warning("An error occured while getting a response stream: {0}", new object[]
							{
								ex3.Message
							});
							goto IL_30D;
						}
						byte[] buffer = new byte[10485760];
						for (;;)
						{
							int num6;
							try
							{
								num6 = responseStream.Read(buffer, 0, 10485760);
							}
							catch (Exception ex4)
							{
								Logger.Warning("Some error while reading from the stream. Ex: {0}", new object[]
								{
									ex4.Message
								});
								goto IL_30D;
							}
							if (num6 == 0)
							{
								break;
							}
							try
							{
								fileStream.Write(buffer, 0, num6);
							}
							catch (Exception ex5)
							{
								Logger.Warning("Some error while writing the stream to file. Ex: {0}", new object[]
								{
									ex5.Message
								});
								this.OnDownloadException(ex5);
								return;
							}
							num += (long)num6;
							this.OnDownloadProgressChanged(num);
							this.OnDownloadPercentProgressChanged((double)Math.Round(decimal.Divide(num, num5) * 100m, 2));
						}
						if (num != num5)
						{
							Logger.Error("Stream does not have more bytes to read. {0} != {1}", new object[]
							{
								num,
								num5
							});
							goto IL_30D;
						}
						goto IL_24D;
					}
					this.OnUnsupportedResume(httpWebResponse.StatusCode);
					return;
					IL_24D:
					try
					{
						fileStream.Close();
						fileStream = null;
						File.Move(text, fileDestination);
						this.OnDownloadFileCompleted();
					}
					catch (Exception ex6)
					{
						Logger.Warning("Could not move file to destination. Ex: {0}", new object[]
						{
							ex6.Message
						});
						this.OnDownloadException(ex6);
					}
				}
			}
			catch (Exception ex7)
			{
				Logger.Error("Unable to download the file: {0}", new object[]
				{
					ex7.Message
				});
				Downloader.ThrowOnFatalException(ex7);
				this.OnDownloadException(ex7);
			}
			finally
			{
				if (fileStream != null)
				{
					fileStream.Close();
				}
				if (httpWebRequest != null)
				{
					httpWebRequest.Abort();
				}
				if (httpWebResponse != null)
				{
					httpWebResponse.Close();
				}
			}
		}

		// Token: 0x06000DD4 RID: 3540 RVA: 0x0000C82C File Offset: 0x0000AA2C
		private long GetSizeFromResponseHeaders(WebHeaderCollection headers)
		{
			return Convert.ToInt64(headers["Content-Range"].Split(new char[]
			{
				'/'
			})[1], CultureInfo.InvariantCulture);
		}

		// Token: 0x06000DD5 RID: 3541 RVA: 0x0000C855 File Offset: 0x0000AA55
		private static void ThrowOnFatalException(Exception e)
		{
			if (e is ThreadAbortException || e is StackOverflowException || e is OutOfMemoryException)
			{
				throw e;
			}
		}

		// Token: 0x06000DD6 RID: 3542 RVA: 0x00036A58 File Offset: 0x00034C58
		private static void AddRangeToRequest(WebRequest req, string range, string rangeSpecifier = "bytes")
		{
			MethodInfo method = typeof(WebHeaderCollection).GetMethod("AddWithoutValidate", BindingFlags.Instance | BindingFlags.NonPublic);
			string text = "Range";
			string text2 = string.Format(CultureInfo.InvariantCulture, "{0}={1}", new object[]
			{
				rangeSpecifier,
				range
			});
			method.Invoke(req.Headers, new object[]
			{
				text,
				text2
			});
		}

		// Token: 0x06000DD7 RID: 3543 RVA: 0x00036ABC File Offset: 0x00034CBC
		private long GetSizeFromContentRange(HttpWebResponse webResponse)
		{
			string text = webResponse.Headers["Content-Range"];
			char[] separator = new char[]
			{
				'/'
			};
			string[] array = text.Split(separator);
			return Convert.ToInt64(array[array.Length - 1], CultureInfo.InvariantCulture);
		}

		// Token: 0x0400078B RID: 1931
		private const int DEFAULT_BUFFER_LENGTH = 10485760;

		// Token: 0x02000197 RID: 407
		// (Invoke) Token: 0x06000DDA RID: 3546
		public delegate void DownloadRetryEventHandler(object sender, EventArgs args);

		// Token: 0x02000198 RID: 408
		// (Invoke) Token: 0x06000DDE RID: 3550
		public delegate void DownloadFileCompletedEventHandler(object sender, EventArgs args);

		// Token: 0x02000199 RID: 409
		// (Invoke) Token: 0x06000DE2 RID: 3554
		public delegate void FilePayloadInfoReceivedHandler(long size);

		// Token: 0x0200019A RID: 410
		// (Invoke) Token: 0x06000DE6 RID: 3558
		public delegate void DownloadExceptionEventHandler(Exception e);

		// Token: 0x0200019B RID: 411
		// (Invoke) Token: 0x06000DEA RID: 3562
		public delegate void DownloadProgressChangedEventHandler(long bytes);

		// Token: 0x0200019C RID: 412
		// (Invoke) Token: 0x06000DEE RID: 3566
		public delegate void UnsupportedResumeEventHandler(HttpStatusCode sc);

		// Token: 0x0200019D RID: 413
		// (Invoke) Token: 0x06000DF2 RID: 3570
		public delegate void DownloadProgressPercentChangedEventHandler(double percent);
	}
}
