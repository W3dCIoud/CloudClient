﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000F1 RID: 241
	public static class Features
	{
		// Token: 0x06000709 RID: 1801 RVA: 0x000224D0 File Offset: 0x000206D0
		public static ulong GetEnabledFeatures()
		{
			ulong num = (ulong)Convert.ToUInt32(RegistryManager.Instance.Features);
			return (ulong)Convert.ToUInt32(RegistryManager.Instance.FeaturesHigh) << 32 | num;
		}

		// Token: 0x0600070A RID: 1802 RVA: 0x00022504 File Offset: 0x00020704
		public static void SetEnabledFeatures(ulong feature)
		{
			uint featuresHigh;
			uint features;
			Features.GetHighLowFeatures(feature, out featuresHigh, out features);
			RegistryManager.Instance.Features = (int)features;
			RegistryManager.Instance.FeaturesHigh = (int)featuresHigh;
		}

		// Token: 0x0600070B RID: 1803 RVA: 0x000063F2 File Offset: 0x000045F2
		public static void GetHighLowFeatures(ulong features, out uint featuresHigh, out uint featuresLow)
		{
			featuresLow = (uint)(features & (ulong)-1);
			featuresHigh = (uint)(features >> 32);
		}

		// Token: 0x0600070C RID: 1804 RVA: 0x00022534 File Offset: 0x00020734
		public static bool IsFeatureEnabled(ulong featureMask)
		{
			ulong num = Features.GetEnabledFeatures();
			if (num == 0UL)
			{
				num = Oem.Instance.WindowsOEMFeatures;
			}
			return Features.IsFeatureEnabled(featureMask, num);
		}

		// Token: 0x0600070D RID: 1805 RVA: 0x00006402 File Offset: 0x00004602
		public static bool IsFeatureEnabled(ulong featureMask, ulong features)
		{
			return (features & featureMask) != 0UL;
		}

		// Token: 0x0600070E RID: 1806 RVA: 0x0002255C File Offset: 0x0002075C
		public static void DisableFeature(ulong featureMask)
		{
			ulong enabledFeatures = Features.GetEnabledFeatures();
			if ((enabledFeatures & featureMask) == 0UL)
			{
				return;
			}
			Features.SetEnabledFeatures(enabledFeatures & ~featureMask);
		}

		// Token: 0x0600070F RID: 1807 RVA: 0x00022580 File Offset: 0x00020780
		public static void EnableFeature(ulong featureMask)
		{
			ulong enabledFeatures = Features.GetEnabledFeatures();
			if ((enabledFeatures & featureMask) != 0UL)
			{
				return;
			}
			Features.SetEnabledFeatures(enabledFeatures | featureMask);
		}

		// Token: 0x06000710 RID: 1808 RVA: 0x0000640C File Offset: 0x0000460C
		public static void EnableAllFeatures()
		{
			Features.SetEnabledFeatures(9223372034707292159UL);
		}

		// Token: 0x06000711 RID: 1809 RVA: 0x0000641C File Offset: 0x0000461C
		public static void EnableFeaturesOfOem()
		{
			Features.SetEnabledFeatures(Oem.Instance.WindowsOEMFeatures);
		}

		// Token: 0x06000712 RID: 1810 RVA: 0x0000642D File Offset: 0x0000462D
		public static bool IsFullScreenToggleEnabled()
		{
			return Features.IsFeatureEnabled(2097152UL);
		}

		// Token: 0x06000713 RID: 1811 RVA: 0x0000643A File Offset: 0x0000463A
		public static bool IsHomeButtonEnabled()
		{
			return Features.IsFeatureEnabled(32768UL);
		}

		// Token: 0x06000714 RID: 1812 RVA: 0x00006447 File Offset: 0x00004647
		public static bool IsShareButtonEnabled()
		{
			return false;
		}

		// Token: 0x06000715 RID: 1813 RVA: 0x0000644A File Offset: 0x0000464A
		public static bool IsGraphicsDriverReminderEnabled()
		{
			return Features.IsFeatureEnabled(65536UL);
		}

		// Token: 0x06000716 RID: 1814 RVA: 0x00006447 File Offset: 0x00004647
		public static bool IsSettingsButtonEnabled()
		{
			return false;
		}

		// Token: 0x06000717 RID: 1815 RVA: 0x00006447 File Offset: 0x00004647
		public static bool IsBackButtonEnabled()
		{
			return false;
		}

		// Token: 0x06000718 RID: 1816 RVA: 0x00006447 File Offset: 0x00004647
		public static bool IsMenuButtonEnabled()
		{
			return false;
		}

		// Token: 0x06000719 RID: 1817 RVA: 0x00006457 File Offset: 0x00004657
		public static bool ExitOnHome()
		{
			return Features.IsFeatureEnabled(131072UL);
		}

		// Token: 0x0600071A RID: 1818 RVA: 0x00006464 File Offset: 0x00004664
		public static bool UpdateFrontendAppTitle()
		{
			return Features.IsFeatureEnabled(524288UL);
		}

		// Token: 0x0600071B RID: 1819 RVA: 0x00006471 File Offset: 0x00004671
		public static bool UseDefaultNetworkText()
		{
			return Features.IsFeatureEnabled(1048576UL);
		}

		// Token: 0x040003BF RID: 959
		public const ulong BROADCAST_MESSAGES = 1UL;

		// Token: 0x040003C0 RID: 960
		public const ulong INSTALL_NOTIFICATIONS = 2UL;

		// Token: 0x040003C1 RID: 961
		public const ulong UNINSTALL_NOTIFICATIONS = 4UL;

		// Token: 0x040003C2 RID: 962
		public const ulong CREATE_APP_SHORTCUTS = 8UL;

		// Token: 0x040003C3 RID: 963
		public const ulong LAUNCH_SETUP_APP = 16UL;

		// Token: 0x040003C4 RID: 964
		public const ulong SHOW_USAGE_STATS = 32UL;

		// Token: 0x040003C5 RID: 965
		public const ulong SYS_TRAY_SUPPORT = 64UL;

		// Token: 0x040003C6 RID: 966
		public const ulong SUGGESTED_APPS_SUPPORT = 128UL;

		// Token: 0x040003C7 RID: 967
		public const ulong OTA_SUPPORT = 256UL;

		// Token: 0x040003C8 RID: 968
		public const ulong SHOW_RESTART = 512UL;

		// Token: 0x040003C9 RID: 969
		public const ulong ANDROID_NOTIFICATIONS = 1024UL;

		// Token: 0x040003CA RID: 970
		public const ulong RIGHT_ALIGN_PORTRAIT_MODE = 2048UL;

		// Token: 0x040003CB RID: 971
		public const ulong LAUNCH_FRONTEND_AFTER_INSTALLTION = 4096UL;

		// Token: 0x040003CC RID: 972
		public const ulong CREATE_LIBRARY = 8192UL;

		// Token: 0x040003CD RID: 973
		public const ulong SHOW_AGENT_ICON_IN_SYSTRAY = 16384UL;

		// Token: 0x040003CE RID: 974
		public const ulong IS_HOME_BUTTON_ENABLED = 32768UL;

		// Token: 0x040003CF RID: 975
		public const ulong IS_GRAPHICS_DRIVER_REMINDER_ENABLED = 65536UL;

		// Token: 0x040003D0 RID: 976
		public const ulong EXIT_ON_HOME = 131072UL;

		// Token: 0x040003D1 RID: 977
		public const ulong MULTI_INSTANCE_SUPPORT = 262144UL;

		// Token: 0x040003D2 RID: 978
		public const ulong UPDATE_FRONTEND_APP_TITLE = 524288UL;

		// Token: 0x040003D3 RID: 979
		public const ulong USE_DEFAULT_NETWORK_TEXT = 1048576UL;

		// Token: 0x040003D4 RID: 980
		public const ulong IS_FULL_SCREEN_TOGGLE_ENABLED = 2097152UL;

		// Token: 0x040003D5 RID: 981
		public const ulong SET_CHINA_LOCALE_AND_TIMEZONE = 4194304UL;

		// Token: 0x040003D6 RID: 982
		public const ulong SHOW_TOGGLE_BUTTON_IN_LOADING_SCREEN = 8388608UL;

		// Token: 0x040003D7 RID: 983
		public const ulong ENABLE_ALT_CTRL_I_SHORTCUTS = 16777216UL;

		// Token: 0x040003D8 RID: 984
		public const ulong CREATE_LIBRARY_SHORTCUT_AT_DESKTOP = 33554432UL;

		// Token: 0x040003D9 RID: 985
		public const ulong CREATE_START_LAUNCHER_SHORTCUT = 67108864UL;

		// Token: 0x040003DA RID: 986
		public const ulong WRITE_APP_CRASH_LOGS = 268435456UL;

		// Token: 0x040003DB RID: 987
		public const ulong CHINA_CLOUD = 536870912UL;

		// Token: 0x040003DC RID: 988
		public const ulong FORCE_DESKTOP_MODE = 1073741824UL;

		// Token: 0x040003DD RID: 989
		public const ulong NOT_TO_BE_USED = 2147483648UL;

		// Token: 0x040003DE RID: 990
		public const ulong ENABLE_ALT_CTRL_M_SHORTCUTS = 4294967296UL;

		// Token: 0x040003DF RID: 991
		public const ulong COLLECT_APK_HANDLER_LOGS = 8589934592UL;

		// Token: 0x040003E0 RID: 992
		public const ulong SHOW_FRONTEND_FULL_SCREEN_TOAST = 17179869184UL;

		// Token: 0x040003E1 RID: 993
		public const ulong IS_CHINA_UI = 34359738368UL;

		// Token: 0x040003E2 RID: 994
		public const ulong NOT_TO_BE_USED_2 = 9223372036854775808UL;

		// Token: 0x040003E3 RID: 995
		public const ulong ALL_FEATURES = 9223372034707292159UL;

		// Token: 0x040003E4 RID: 996
		public const uint BST_HIDE_NAVIGATIONBAR = 1U;

		// Token: 0x040003E5 RID: 997
		public const uint BST_HIDE_STATUSBAR = 2U;

		// Token: 0x040003E6 RID: 998
		public const uint BST_HIDE_BACKBUTTON = 4U;

		// Token: 0x040003E7 RID: 999
		public const uint BST_HIDE_HOMEBUTTON = 8U;

		// Token: 0x040003E8 RID: 1000
		public const uint BST_HIDE_RECENTSBUTTON = 16U;

		// Token: 0x040003E9 RID: 1001
		public const uint BST_HIDE_SCREENSHOTBUTTON = 32U;

		// Token: 0x040003EA RID: 1002
		public const uint BST_HIDE_TOGGLEBUTTON = 64U;

		// Token: 0x040003EB RID: 1003
		public const uint BST_HIDE_CLOSEBUTTON = 128U;

		// Token: 0x040003EC RID: 1004
		public const uint BST_HIDE_GPS = 512U;

		// Token: 0x040003ED RID: 1005
		public const uint BST_SHOW_APKINSTALLBUTTON = 2048U;

		// Token: 0x040003EE RID: 1006
		public const uint BST_HIDE_HOMEAPPNEWLOADER = 65536U;

		// Token: 0x040003EF RID: 1007
		public const uint BST_SENDLETSGOS2PCLICKREPORT = 131072U;

		// Token: 0x040003F0 RID: 1008
		public const uint BST_DISABLE_P2DM = 262144U;

		// Token: 0x040003F1 RID: 1009
		public const uint BST_DISABLE_ARMTIPS = 524288U;

		// Token: 0x040003F2 RID: 1010
		public const uint BST_DISABLE_S2P = 1048576U;

		// Token: 0x040003F3 RID: 1011
		public const uint BST_SOGOUIME = 268435456U;

		// Token: 0x040003F4 RID: 1012
		public const uint BST_BAIDUIME = 1073741824U;

		// Token: 0x040003F5 RID: 1013
		public const uint BST_QQIME = 2147483648U;

		// Token: 0x040003F6 RID: 1014
		public const uint BST_QEMU_3BT_COEXISTENCE_BIT = 536870912U;

		// Token: 0x040003F7 RID: 1015
		public const uint BST_HIDE_S2P_SEARCH_BAIDU_IN_HOMEAPPNEW = 4194304U;

		// Token: 0x040003F8 RID: 1016
		public const uint BST_NEW_TASK_ON_HOME = 2097152U;

		// Token: 0x040003F9 RID: 1017
		public const uint BST_NO_REINSTALL = 67108864U;

		// Token: 0x040003FA RID: 1018
		public const int BST_HIDE_GUIDANCESCREEN = 1024;

		// Token: 0x040003FB RID: 1019
		public const int BST_USE_CHINESE_CDN = 4096;

		// Token: 0x040003FC RID: 1020
		public const int BST_ENALBE_ABOUT_PHONE_OPTION = 16777216;

		// Token: 0x040003FD RID: 1021
		public const int BST_ENABLE_SECURITY_OPTION = 33554432;

		// Token: 0x040003FE RID: 1022
		public const uint BST_SKIP_S2P_WHILE_LAUNCHING_APP = 2048U;

		// Token: 0x040003FF RID: 1023
		internal static string ConfigFeature = "net.";
	}
}
