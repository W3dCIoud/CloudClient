﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200019E RID: 414
	public static class ErrorCodes
	{
		// Token: 0x0400078C RID: 1932
		public const int Success = 0;

		// Token: 0x0400078D RID: 1933
		public const int ConnectFailure = 1;

		// Token: 0x0400078E RID: 1934
		public const int ReceiveFailure = 2;

		// Token: 0x0400078F RID: 1935
		public const int Timeout = 3;

		// Token: 0x04000790 RID: 1936
		public const int UnexpectedHttpStatusCode = 4;

		// Token: 0x04000791 RID: 1937
		public const int ResumeNotSupported = 5;

		// Token: 0x04000792 RID: 1938
		public const int UnknownError = 99;
	}
}
