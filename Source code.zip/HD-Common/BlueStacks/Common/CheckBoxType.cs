﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000155 RID: 341
	public enum CheckBoxType
	{
		// Token: 0x04000663 RID: 1635
		Gray,
		// Token: 0x04000664 RID: 1636
		White
	}
}
