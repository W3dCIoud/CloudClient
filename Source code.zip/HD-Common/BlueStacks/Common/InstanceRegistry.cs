﻿using System;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Win32;

namespace BlueStacks.Common
{
	// Token: 0x020000F2 RID: 242
	public class InstanceRegistry
	{
		// Token: 0x0600071D RID: 1821 RVA: 0x000225A4 File Offset: 0x000207A4
		public InstanceRegistry(string vmId)
		{
			this.mVmId = vmId;
			this.Init();
		}

		// Token: 0x0600071E RID: 1822 RVA: 0x000226AC File Offset: 0x000208AC
		private void Init()
		{
			this.mBaseKeyPath = RegistryStrings.RegistryBaseKeyPath + RegistryManager.UPGRADE_TAG;
			this.AndroidKeyPath = this.mBaseKeyPath + "\\Guests\\" + this.mVmId;
			this.mBlockDeviceKeyPath = this.AndroidKeyPath + "\\BlockDevice";
			this.mBlockDevice0KeyPath = this.AndroidKeyPath + "\\BlockDevice\\0";
			this.mBlockDevice1KeyPath = this.AndroidKeyPath + "\\BlockDevice\\1";
			this.mBlockDevice2KeyPath = this.AndroidKeyPath + "\\BlockDevice\\2";
			this.mBlockDevice3KeyPath = this.AndroidKeyPath + "\\BlockDevice\\3";
			this.mBlockDevice4KeyPath = this.AndroidKeyPath + "\\BlockDevice\\4";
			this.mVmConfigKeyPath = this.AndroidKeyPath + "\\Config";
			this.mFrameBufferKeyPath = this.AndroidKeyPath + "\\FrameBuffer";
			this.mFrameBuffer0KeyPath = this.AndroidKeyPath + "\\FrameBuffer\\0";
			this.mNetworkKeyPath = this.AndroidKeyPath + "\\Network";
			this.mNetwork0KeyPath = this.AndroidKeyPath + "\\Network\\0";
			this.mNetworkRedirectKeyPath = this.AndroidKeyPath + "\\Network\\Redirect";
			this.mSharedFolderKeyPath = this.AndroidKeyPath + "\\SharedFolder";
			this.mSharedFolder0KeyPath = this.AndroidKeyPath + "\\SharedFolder\\0";
			this.mSharedFolder1KeyPath = this.AndroidKeyPath + "\\SharedFolder\\1";
			this.mSharedFolder2KeyPath = this.AndroidKeyPath + "\\SharedFolder\\2";
			this.mSharedFolder3KeyPath = this.AndroidKeyPath + "\\SharedFolder\\3";
			this.mSharedFolder4KeyPath = this.AndroidKeyPath + "\\SharedFolder\\4";
			this.mSharedFolder5KeyPath = this.AndroidKeyPath + "\\SharedFolder\\5";
			RegistryUtils.InitKey(this.mBlockDevice0KeyPath);
			RegistryUtils.InitKey(this.mBlockDevice1KeyPath);
			RegistryUtils.InitKey(this.mBlockDevice2KeyPath);
			RegistryUtils.InitKey(this.mBlockDevice3KeyPath);
			RegistryUtils.InitKey(this.mBlockDevice4KeyPath);
			RegistryUtils.InitKey(this.mVmConfigKeyPath);
			RegistryUtils.InitKey(this.mFrameBuffer0KeyPath);
			RegistryUtils.InitKey(this.mNetwork0KeyPath);
			RegistryUtils.InitKey(this.mNetworkRedirectKeyPath);
			RegistryUtils.InitKey(this.mSharedFolder0KeyPath);
			RegistryUtils.InitKey(this.mSharedFolder1KeyPath);
			RegistryUtils.InitKey(this.mSharedFolder2KeyPath);
			RegistryUtils.InitKey(this.mSharedFolder3KeyPath);
			RegistryUtils.InitKey(this.mSharedFolder4KeyPath);
			RegistryUtils.InitKey(this.mSharedFolder5KeyPath);
		}

		// Token: 0x170001E5 RID: 485
		// (get) Token: 0x0600071F RID: 1823 RVA: 0x0000648A File Offset: 0x0000468A
		// (set) Token: 0x06000720 RID: 1824 RVA: 0x00006492 File Offset: 0x00004692
		public string AndroidKeyPath { get; private set; } = "";

		// Token: 0x170001E6 RID: 486
		// (get) Token: 0x06000721 RID: 1825 RVA: 0x0000649B File Offset: 0x0000469B
		// (set) Token: 0x06000722 RID: 1826 RVA: 0x000064B9 File Offset: 0x000046B9
		public int EmulatePortraitMode
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mFrameBuffer0KeyPath, "EmulatePortraitMode", -1, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mFrameBuffer0KeyPath, "EmulatePortraitMode", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001E7 RID: 487
		// (get) Token: 0x06000723 RID: 1827 RVA: 0x000064D4 File Offset: 0x000046D4
		// (set) Token: 0x06000724 RID: 1828 RVA: 0x000064F2 File Offset: 0x000046F2
		public int Depth
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mFrameBuffer0KeyPath, "Depth", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mFrameBuffer0KeyPath, "Depth", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001E8 RID: 488
		// (get) Token: 0x06000725 RID: 1829 RVA: 0x0000650D File Offset: 0x0000470D
		// (set) Token: 0x06000726 RID: 1830 RVA: 0x0000652B File Offset: 0x0000472B
		public int HideBootProgress
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mFrameBuffer0KeyPath, "HideBootProgress", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mFrameBuffer0KeyPath, "HideBootProgress", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001E9 RID: 489
		// (get) Token: 0x06000727 RID: 1831 RVA: 0x00006546 File Offset: 0x00004746
		// (set) Token: 0x06000728 RID: 1832 RVA: 0x00006564 File Offset: 0x00004764
		public int WindowWidth
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mFrameBuffer0KeyPath, "WindowWidth", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mFrameBuffer0KeyPath, "WindowWidth", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001EA RID: 490
		// (get) Token: 0x06000729 RID: 1833 RVA: 0x0000657F File Offset: 0x0000477F
		// (set) Token: 0x0600072A RID: 1834 RVA: 0x0000659D File Offset: 0x0000479D
		public int WindowHeight
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mFrameBuffer0KeyPath, "WindowHeight", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mFrameBuffer0KeyPath, "WindowHeight", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001EB RID: 491
		// (get) Token: 0x0600072B RID: 1835 RVA: 0x000065B8 File Offset: 0x000047B8
		// (set) Token: 0x0600072C RID: 1836 RVA: 0x000065D6 File Offset: 0x000047D6
		public int GuestWidth
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mFrameBuffer0KeyPath, "GuestWidth", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mFrameBuffer0KeyPath, "GuestWidth", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001EC RID: 492
		// (get) Token: 0x0600072D RID: 1837 RVA: 0x000065F1 File Offset: 0x000047F1
		// (set) Token: 0x0600072E RID: 1838 RVA: 0x0000660F File Offset: 0x0000480F
		public int GuestHeight
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mFrameBuffer0KeyPath, "GuestHeight", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mFrameBuffer0KeyPath, "GuestHeight", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001ED RID: 493
		// (get) Token: 0x0600072F RID: 1839 RVA: 0x0000662A File Offset: 0x0000482A
		// (set) Token: 0x06000730 RID: 1840 RVA: 0x00006648 File Offset: 0x00004848
		public int Memory
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.AndroidKeyPath, "Memory", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.AndroidKeyPath, "Memory", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001EE RID: 494
		// (get) Token: 0x06000731 RID: 1841 RVA: 0x00006663 File Offset: 0x00004863
		// (set) Token: 0x06000732 RID: 1842 RVA: 0x00006686 File Offset: 0x00004886
		public bool IsSidebarVisible
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.AndroidKeyPath, "IsSidebarVisible", 1, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.AndroidKeyPath, "IsSidebarVisible", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001EF RID: 495
		// (get) Token: 0x06000733 RID: 1843 RVA: 0x000066A7 File Offset: 0x000048A7
		// (set) Token: 0x06000734 RID: 1844 RVA: 0x000066CA File Offset: 0x000048CA
		public bool IsSidebarInDefaultState
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.AndroidKeyPath, "IsSidebarInDefaultState", 1, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.AndroidKeyPath, "IsSidebarInDefaultState", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001F0 RID: 496
		// (get) Token: 0x06000735 RID: 1845 RVA: 0x000066EB File Offset: 0x000048EB
		// (set) Token: 0x06000736 RID: 1846 RVA: 0x00006704 File Offset: 0x00004904
		public string Kernel
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.AndroidKeyPath, "Kernel", null, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.AndroidKeyPath, "Kernel", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001F1 RID: 497
		// (get) Token: 0x06000737 RID: 1847 RVA: 0x0000671A File Offset: 0x0000491A
		// (set) Token: 0x06000738 RID: 1848 RVA: 0x00006733 File Offset: 0x00004933
		public string Initrd
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.AndroidKeyPath, "Initrd", null, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.AndroidKeyPath, "Initrd", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001F2 RID: 498
		// (get) Token: 0x06000739 RID: 1849 RVA: 0x00006749 File Offset: 0x00004949
		// (set) Token: 0x0600073A RID: 1850 RVA: 0x00006767 File Offset: 0x00004967
		public int DisableRobustness
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.AndroidKeyPath, "DisableRobustness", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.AndroidKeyPath, "DisableRobustness", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001F3 RID: 499
		// (get) Token: 0x0600073B RID: 1851 RVA: 0x00006782 File Offset: 0x00004982
		// (set) Token: 0x0600073C RID: 1852 RVA: 0x0000679F File Offset: 0x0000499F
		public string VirtType
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.AndroidKeyPath, "VirtType", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.AndroidKeyPath, "VirtType", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001F4 RID: 500
		// (get) Token: 0x0600073D RID: 1853 RVA: 0x000067B5 File Offset: 0x000049B5
		// (set) Token: 0x0600073E RID: 1854 RVA: 0x000067D2 File Offset: 0x000049D2
		public string BootParameters
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.AndroidKeyPath, "BootParameters", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.AndroidKeyPath, "BootParameters", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001F5 RID: 501
		// (get) Token: 0x0600073F RID: 1855 RVA: 0x000067E8 File Offset: 0x000049E8
		// (set) Token: 0x06000740 RID: 1856 RVA: 0x0000680B File Offset: 0x00004A0B
		public bool ShowSidebarInFullScreen
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "ShowSidebarInFullScreen", 1, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "ShowSidebarInFullScreen", (!value) ? 0 : 1, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001F6 RID: 502
		// (get) Token: 0x06000741 RID: 1857 RVA: 0x0000682C File Offset: 0x00004A2C
		// (set) Token: 0x06000742 RID: 1858 RVA: 0x00006849 File Offset: 0x00004A49
		public string BlockDevice0Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice0KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice0KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001F7 RID: 503
		// (get) Token: 0x06000743 RID: 1859 RVA: 0x0000685F File Offset: 0x00004A5F
		// (set) Token: 0x06000744 RID: 1860 RVA: 0x0000687C File Offset: 0x00004A7C
		public string BlockDevice0Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice0KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice0KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001F8 RID: 504
		// (get) Token: 0x06000745 RID: 1861 RVA: 0x00006892 File Offset: 0x00004A92
		// (set) Token: 0x06000746 RID: 1862 RVA: 0x000068AF File Offset: 0x00004AAF
		public string BlockDevice1Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice1KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice1KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001F9 RID: 505
		// (get) Token: 0x06000747 RID: 1863 RVA: 0x000068C5 File Offset: 0x00004AC5
		// (set) Token: 0x06000748 RID: 1864 RVA: 0x000068E2 File Offset: 0x00004AE2
		public string BlockDevice1Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice1KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice1KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001FA RID: 506
		// (get) Token: 0x06000749 RID: 1865 RVA: 0x000068F8 File Offset: 0x00004AF8
		// (set) Token: 0x0600074A RID: 1866 RVA: 0x00006915 File Offset: 0x00004B15
		public string BlockDevice2Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice2KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice2KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001FB RID: 507
		// (get) Token: 0x0600074B RID: 1867 RVA: 0x0000692B File Offset: 0x00004B2B
		// (set) Token: 0x0600074C RID: 1868 RVA: 0x00006948 File Offset: 0x00004B48
		public string BlockDevice2Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice2KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice2KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001FC RID: 508
		// (get) Token: 0x0600074D RID: 1869 RVA: 0x0000695E File Offset: 0x00004B5E
		// (set) Token: 0x0600074E RID: 1870 RVA: 0x0000697B File Offset: 0x00004B7B
		public string BlockDevice3Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice3KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice3KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001FD RID: 509
		// (get) Token: 0x0600074F RID: 1871 RVA: 0x00006991 File Offset: 0x00004B91
		// (set) Token: 0x06000750 RID: 1872 RVA: 0x000069AE File Offset: 0x00004BAE
		public string BlockDevice3Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice3KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice3KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001FE RID: 510
		// (get) Token: 0x06000751 RID: 1873 RVA: 0x000069C4 File Offset: 0x00004BC4
		// (set) Token: 0x06000752 RID: 1874 RVA: 0x000069E1 File Offset: 0x00004BE1
		public string BlockDevice4Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice4KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice4KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x170001FF RID: 511
		// (get) Token: 0x06000753 RID: 1875 RVA: 0x000069F7 File Offset: 0x00004BF7
		// (set) Token: 0x06000754 RID: 1876 RVA: 0x00006A14 File Offset: 0x00004C14
		public string BlockDevice4Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mBlockDevice4KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mBlockDevice4KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000200 RID: 512
		// (get) Token: 0x06000755 RID: 1877 RVA: 0x00006A2A File Offset: 0x00004C2A
		// (set) Token: 0x06000756 RID: 1878 RVA: 0x00006A47 File Offset: 0x00004C47
		public string Locale
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "Locale", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "Locale", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000201 RID: 513
		// (get) Token: 0x06000757 RID: 1879 RVA: 0x00006A5D File Offset: 0x00004C5D
		// (set) Token: 0x06000758 RID: 1880 RVA: 0x00006A95 File Offset: 0x00004C95
		public int VCPUs
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "VCPUs", Utils.GetRecommendedVCPUCount(this.mVmId == "Android"), RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "VCPUs", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000202 RID: 514
		// (get) Token: 0x06000759 RID: 1881 RVA: 0x00006AB0 File Offset: 0x00004CB0
		// (set) Token: 0x0600075A RID: 1882 RVA: 0x00006ACD File Offset: 0x00004CCD
		public string EnableConsoleAccess
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "EnableConsoleAccess", string.Empty, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "EnableConsoleAccess", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000203 RID: 515
		// (get) Token: 0x0600075B RID: 1883 RVA: 0x00006AE3 File Offset: 0x00004CE3
		// (set) Token: 0x0600075C RID: 1884 RVA: 0x00006B01 File Offset: 0x00004D01
		public int GlRenderMode
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GlRenderMode", -1, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GlRenderMode", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000204 RID: 516
		// (get) Token: 0x0600075D RID: 1885 RVA: 0x00006B1C File Offset: 0x00004D1C
		// (set) Token: 0x0600075E RID: 1886 RVA: 0x00006B3B File Offset: 0x00004D3B
		public int FPS
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "FPS", 60, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "FPS", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000205 RID: 517
		// (get) Token: 0x0600075F RID: 1887 RVA: 0x00006B56 File Offset: 0x00004D56
		// (set) Token: 0x06000760 RID: 1888 RVA: 0x00006B74 File Offset: 0x00004D74
		public int ShowFPS
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "ShowFPS", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "ShowFPS", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000206 RID: 518
		// (get) Token: 0x06000761 RID: 1889 RVA: 0x00006B8F File Offset: 0x00004D8F
		// (set) Token: 0x06000762 RID: 1890 RVA: 0x00006BAD File Offset: 0x00004DAD
		public int EnableHighFPS
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "EnableHighFPS", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "EnableHighFPS", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000207 RID: 519
		// (get) Token: 0x06000763 RID: 1891 RVA: 0x00006BC8 File Offset: 0x00004DC8
		// (set) Token: 0x06000764 RID: 1892 RVA: 0x00006BE6 File Offset: 0x00004DE6
		public int GlMode
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GlMode", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GlMode", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000208 RID: 520
		// (get) Token: 0x06000765 RID: 1893 RVA: 0x00006C01 File Offset: 0x00004E01
		// (set) Token: 0x06000766 RID: 1894 RVA: 0x00006C1F File Offset: 0x00004E1F
		public int Camera
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "Camera", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "Camera", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000209 RID: 521
		// (get) Token: 0x06000767 RID: 1895 RVA: 0x00006C3A File Offset: 0x00004E3A
		// (set) Token: 0x06000768 RID: 1896 RVA: 0x00006C58 File Offset: 0x00004E58
		public int ConfigSynced
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "ConfigSynced", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "ConfigSynced", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700020A RID: 522
		// (get) Token: 0x06000769 RID: 1897 RVA: 0x00006C73 File Offset: 0x00004E73
		// (set) Token: 0x0600076A RID: 1898 RVA: 0x00006C91 File Offset: 0x00004E91
		public int HScroll
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "HScroll", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "HScroll", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700020B RID: 523
		// (get) Token: 0x0600076B RID: 1899 RVA: 0x00006CAC File Offset: 0x00004EAC
		// (set) Token: 0x0600076C RID: 1900 RVA: 0x00006CCA File Offset: 0x00004ECA
		public int GpsMode
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GpsMode", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GpsMode", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700020C RID: 524
		// (get) Token: 0x0600076D RID: 1901 RVA: 0x00006CE5 File Offset: 0x00004EE5
		// (set) Token: 0x0600076E RID: 1902 RVA: 0x00006D03 File Offset: 0x00004F03
		public int FileSystem
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "FileSystem", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "FileSystem", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700020D RID: 525
		// (get) Token: 0x0600076F RID: 1903 RVA: 0x00006D1E File Offset: 0x00004F1E
		// (set) Token: 0x06000770 RID: 1904 RVA: 0x00006D3C File Offset: 0x00004F3C
		public int StopZygoteOnClose
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "StopZygoteOnClose", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "StopZygoteOnClose", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700020E RID: 526
		// (get) Token: 0x06000771 RID: 1905 RVA: 0x00006D57 File Offset: 0x00004F57
		// (set) Token: 0x06000772 RID: 1906 RVA: 0x00006D75 File Offset: 0x00004F75
		public int FenceSyncType
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "FenceSyncType", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "FenceSyncType", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700020F RID: 527
		// (get) Token: 0x06000773 RID: 1907 RVA: 0x00006D90 File Offset: 0x00004F90
		// (set) Token: 0x06000774 RID: 1908 RVA: 0x00006DAE File Offset: 0x00004FAE
		public int FrontendNoClose
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "FrontendNoClose", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "FrontendNoClose", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000210 RID: 528
		// (get) Token: 0x06000775 RID: 1909 RVA: 0x00006DC9 File Offset: 0x00004FC9
		// (set) Token: 0x06000776 RID: 1910 RVA: 0x00006DE7 File Offset: 0x00004FE7
		public int GpsSource
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GpsSource", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GpsSource", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000211 RID: 529
		// (get) Token: 0x06000777 RID: 1911 RVA: 0x00006E02 File Offset: 0x00005002
		// (set) Token: 0x06000778 RID: 1912 RVA: 0x00006E1F File Offset: 0x0000501F
		public string GpsLatitude
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GpsLatitude", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GpsLatitude", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000212 RID: 530
		// (get) Token: 0x06000779 RID: 1913 RVA: 0x00006E35 File Offset: 0x00005035
		// (set) Token: 0x0600077A RID: 1914 RVA: 0x00006E52 File Offset: 0x00005052
		public string GpsLongitude
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GpsLongitude", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GpsLongitude", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000213 RID: 531
		// (get) Token: 0x0600077B RID: 1915 RVA: 0x00006E68 File Offset: 0x00005068
		// (set) Token: 0x0600077C RID: 1916 RVA: 0x00006E86 File Offset: 0x00005086
		public int GlPort
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GlPort", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GlPort", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000214 RID: 532
		// (get) Token: 0x0600077D RID: 1917 RVA: 0x00006EA1 File Offset: 0x000050A1
		// (set) Token: 0x0600077E RID: 1918 RVA: 0x00006EBE File Offset: 0x000050BE
		public string GamingResolutionPubg
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GamingResolutionPubg", "1", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GamingResolutionPubg", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000215 RID: 533
		// (get) Token: 0x0600077F RID: 1919 RVA: 0x00006ED4 File Offset: 0x000050D4
		// (set) Token: 0x06000780 RID: 1920 RVA: 0x00006EF1 File Offset: 0x000050F1
		public string DisplayQualityPubg
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "DisplayQualityPubg", "-1", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "DisplayQualityPubg", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000216 RID: 534
		// (get) Token: 0x06000781 RID: 1921 RVA: 0x00006F07 File Offset: 0x00005107
		// (set) Token: 0x06000782 RID: 1922 RVA: 0x00006F24 File Offset: 0x00005124
		public string GamingResolutionCOD
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GamingResolutionCOD", "720", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GamingResolutionCOD", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000217 RID: 535
		// (get) Token: 0x06000783 RID: 1923 RVA: 0x00006F3A File Offset: 0x0000513A
		// (set) Token: 0x06000784 RID: 1924 RVA: 0x00006F57 File Offset: 0x00005157
		public string DisplayQualityCOD
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "DisplayQualityCOD", "-1", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "DisplayQualityCOD", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000218 RID: 536
		// (get) Token: 0x06000785 RID: 1925 RVA: 0x00006F6D File Offset: 0x0000516D
		// (set) Token: 0x06000786 RID: 1926 RVA: 0x00006F8B File Offset: 0x0000518B
		public int HostSensorPort
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "HostSensorPort", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "HostSensorPort", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000219 RID: 537
		// (get) Token: 0x06000787 RID: 1927 RVA: 0x00006FA6 File Offset: 0x000051A6
		// (set) Token: 0x06000788 RID: 1928 RVA: 0x00006FC4 File Offset: 0x000051C4
		public int SoftControlBarHeightLandscape
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "SoftControlBarHeightLandscape", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "SoftControlBarHeightLandscape", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700021A RID: 538
		// (get) Token: 0x06000789 RID: 1929 RVA: 0x00006FDF File Offset: 0x000051DF
		// (set) Token: 0x0600078A RID: 1930 RVA: 0x00006FFD File Offset: 0x000051FD
		public int SoftControlBarHeightPortrait
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "SoftControlBarHeightPortrait", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "SoftControlBarHeightPortrait", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700021B RID: 539
		// (get) Token: 0x0600078B RID: 1931 RVA: 0x00007018 File Offset: 0x00005218
		// (set) Token: 0x0600078C RID: 1932 RVA: 0x00007036 File Offset: 0x00005236
		public int GrabKeyboard
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GrabKeyboard", 1, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GrabKeyboard", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700021C RID: 540
		// (get) Token: 0x0600078D RID: 1933 RVA: 0x00007051 File Offset: 0x00005251
		// (set) Token: 0x0600078E RID: 1934 RVA: 0x0000706F File Offset: 0x0000526F
		public int DisableDWM
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "DisableDWM", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "DisableDWM", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700021D RID: 541
		// (get) Token: 0x0600078F RID: 1935 RVA: 0x0000708A File Offset: 0x0000528A
		// (set) Token: 0x06000790 RID: 1936 RVA: 0x000070A8 File Offset: 0x000052A8
		public int DisablePcIme
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "DisablePcIme", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "DisablePcIme", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700021E RID: 542
		// (get) Token: 0x06000791 RID: 1937 RVA: 0x000070C3 File Offset: 0x000052C3
		// (set) Token: 0x06000792 RID: 1938 RVA: 0x000070E1 File Offset: 0x000052E1
		public int EnableBSTVC
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "EnableBSTVC", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "EnableBSTVC", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700021F RID: 543
		// (get) Token: 0x06000793 RID: 1939 RVA: 0x000070FC File Offset: 0x000052FC
		// (set) Token: 0x06000794 RID: 1940 RVA: 0x0000711A File Offset: 0x0000531A
		public int ForceVMLegacyMode
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "ForceVMLegacyMode", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "ForceVMLegacyMode", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000220 RID: 544
		// (get) Token: 0x06000795 RID: 1941 RVA: 0x00007135 File Offset: 0x00005335
		// (set) Token: 0x06000796 RID: 1942 RVA: 0x00007157 File Offset: 0x00005357
		public int FrontendServerPort
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "FrontendServerPort", 2881, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "FrontendServerPort", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000221 RID: 545
		// (get) Token: 0x06000797 RID: 1943 RVA: 0x00007172 File Offset: 0x00005372
		// (set) Token: 0x06000798 RID: 1944 RVA: 0x00007194 File Offset: 0x00005394
		public int BstAndroidPort
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "BstAndroidPort", 9999, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "BstAndroidPort", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000222 RID: 546
		// (get) Token: 0x06000799 RID: 1945 RVA: 0x000071AF File Offset: 0x000053AF
		// (set) Token: 0x0600079A RID: 1946 RVA: 0x000071D1 File Offset: 0x000053D1
		public int BstAdbPort
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "BstAdbPort", 5555, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "BstAdbPort", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000223 RID: 547
		// (get) Token: 0x0600079B RID: 1947 RVA: 0x000071EC File Offset: 0x000053EC
		// (set) Token: 0x0600079C RID: 1948 RVA: 0x0000720E File Offset: 0x0000540E
		public int TriggerMemoryTrimThreshold
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "TriggerMemoryTrimThreshold", 700, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "TriggerMemoryTrimThreshold", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000224 RID: 548
		// (get) Token: 0x0600079D RID: 1949 RVA: 0x00007229 File Offset: 0x00005429
		// (set) Token: 0x0600079E RID: 1950 RVA: 0x0000724B File Offset: 0x0000544B
		public int TriggerMemoryTrimTimerInterval
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "TriggerMemoryTrimTimerInterval", 60000, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "TriggerMemoryTrimTimerInterval", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000225 RID: 549
		// (get) Token: 0x0600079F RID: 1951 RVA: 0x00007266 File Offset: 0x00005466
		// (set) Token: 0x060007A0 RID: 1952 RVA: 0x00007284 File Offset: 0x00005484
		public int UpdatedVersion
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "UpdatedVersion", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "UpdatedVersion", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000226 RID: 550
		// (get) Token: 0x060007A1 RID: 1953 RVA: 0x0000729F File Offset: 0x0000549F
		// (set) Token: 0x060007A2 RID: 1954 RVA: 0x000072BD File Offset: 0x000054BD
		public int GPSAvailable
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GPSAvailable", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GPSAvailable", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000227 RID: 551
		// (get) Token: 0x060007A3 RID: 1955 RVA: 0x000072D8 File Offset: 0x000054D8
		// (set) Token: 0x060007A4 RID: 1956 RVA: 0x000072F5 File Offset: 0x000054F5
		public string OpenSensorDeviceId
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "OpenSensorDeviceId", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "OpenSensorDeviceId", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000228 RID: 552
		// (get) Token: 0x060007A5 RID: 1957 RVA: 0x0000730B File Offset: 0x0000550B
		// (set) Token: 0x060007A6 RID: 1958 RVA: 0x00007329 File Offset: 0x00005529
		public int HostForwardSensorPort
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "HostForwardSensorPort", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "HostForwardSensorPort", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000229 RID: 553
		// (get) Token: 0x060007A7 RID: 1959 RVA: 0x00007344 File Offset: 0x00005544
		// (set) Token: 0x060007A8 RID: 1960 RVA: 0x00007361 File Offset: 0x00005561
		public string ImeSelected
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "ImeSelected", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "ImeSelected", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700022A RID: 554
		// (get) Token: 0x060007A9 RID: 1961 RVA: 0x00007377 File Offset: 0x00005577
		// (set) Token: 0x060007AA RID: 1962 RVA: 0x00007395 File Offset: 0x00005595
		public int RunAppProcessId
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "RunAppProcessId", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "RunAppProcessId", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700022B RID: 555
		// (get) Token: 0x060007AB RID: 1963 RVA: 0x000073B0 File Offset: 0x000055B0
		// (set) Token: 0x060007AC RID: 1964 RVA: 0x000073CD File Offset: 0x000055CD
		public string DisplayName
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "DisplayName", string.Empty, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "DisplayName", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700022C RID: 556
		// (get) Token: 0x060007AD RID: 1965 RVA: 0x00022940 File Offset: 0x00020B40
		// (set) Token: 0x060007AE RID: 1966 RVA: 0x000073E3 File Offset: 0x000055E3
		public string LastBootDate
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "LastBootDate", DateTime.Now.Date.ToShortDateString(), RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "LastBootDate", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700022D RID: 557
		// (get) Token: 0x060007AF RID: 1967 RVA: 0x000073F9 File Offset: 0x000055F9
		// (set) Token: 0x060007B0 RID: 1968 RVA: 0x0000741C File Offset: 0x0000561C
		public bool IsOneTimeSetupDone
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "IsOneTimeSetupDone", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "IsOneTimeSetupDone", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700022E RID: 558
		// (get) Token: 0x060007B1 RID: 1969 RVA: 0x0000743D File Offset: 0x0000563D
		// (set) Token: 0x060007B2 RID: 1970 RVA: 0x00007460 File Offset: 0x00005660
		public bool IsMuted
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "IsMuted", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "IsMuted", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700022F RID: 559
		// (get) Token: 0x060007B3 RID: 1971 RVA: 0x00007481 File Offset: 0x00005681
		// (set) Token: 0x060007B4 RID: 1972 RVA: 0x0000749F File Offset: 0x0000569F
		public int Volume
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "Volume", 5, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "Volume", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000230 RID: 560
		// (get) Token: 0x060007B5 RID: 1973 RVA: 0x000074BA File Offset: 0x000056BA
		// (set) Token: 0x060007B6 RID: 1974 RVA: 0x000074DD File Offset: 0x000056DD
		public bool FixVboxConfig
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "FixVboxConfig", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "FixVboxConfig", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000231 RID: 561
		// (get) Token: 0x060007B7 RID: 1975 RVA: 0x000074FE File Offset: 0x000056FE
		// (set) Token: 0x060007B8 RID: 1976 RVA: 0x0000751B File Offset: 0x0000571B
		public string WindowPlacement
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "WindowPlacement", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "WindowPlacement", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000232 RID: 562
		// (get) Token: 0x060007B9 RID: 1977 RVA: 0x00007531 File Offset: 0x00005731
		// (set) Token: 0x060007BA RID: 1978 RVA: 0x00007554 File Offset: 0x00005754
		public bool IsGoogleSigninDone
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "IsGoogleSigninDone", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "IsGoogleSigninDone", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000233 RID: 563
		// (get) Token: 0x060007BB RID: 1979 RVA: 0x00007575 File Offset: 0x00005775
		// (set) Token: 0x060007BC RID: 1980 RVA: 0x00007598 File Offset: 0x00005798
		public bool IsGoogleSigninPopupShown
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "IsGoogleSigninPopupShown", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "IsGoogleSigninPopupShown", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000234 RID: 564
		// (get) Token: 0x060007BD RID: 1981 RVA: 0x000075B9 File Offset: 0x000057B9
		// (set) Token: 0x060007BE RID: 1982 RVA: 0x000075D7 File Offset: 0x000057D7
		[SuppressMessage("Performance", "CA1819:Properties should not return arrays", Justification = "<Pending>")]
		public string[] GrmDonotShowRuleList
		{
			get
			{
				return (string[])RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "GrmDonotShowRuleList", new string[0], RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "GrmDonotShowRuleList", value, RegistryValueKind.MultiString, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000235 RID: 565
		// (get) Token: 0x060007BF RID: 1983 RVA: 0x000075ED File Offset: 0x000057ED
		// (set) Token: 0x060007C0 RID: 1984 RVA: 0x0000760A File Offset: 0x0000580A
		public string GoogleAId
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "BstVmAId", string.Empty, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "BstVmAId", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000236 RID: 566
		// (get) Token: 0x060007C1 RID: 1985 RVA: 0x00007620 File Offset: 0x00005820
		// (set) Token: 0x060007C2 RID: 1986 RVA: 0x0000763D File Offset: 0x0000583D
		public string AndroidId
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "BstVmId", string.Empty, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "BstVmId", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000237 RID: 567
		// (get) Token: 0x060007C3 RID: 1987 RVA: 0x00007653 File Offset: 0x00005853
		// (set) Token: 0x060007C4 RID: 1988 RVA: 0x00007671 File Offset: 0x00005871
		public int PUBGLaunchedCount
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "PUBGLaunchedCount", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "PUBGLaunchedCount", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000238 RID: 568
		// (get) Token: 0x060007C5 RID: 1989 RVA: 0x0000768C File Offset: 0x0000588C
		// (set) Token: 0x060007C6 RID: 1990 RVA: 0x000076AF File Offset: 0x000058AF
		public bool PUBGNotificationShown
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "PUBGNotificationShown", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "PUBGNotificationShown", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000239 RID: 569
		// (get) Token: 0x060007C7 RID: 1991 RVA: 0x000076D0 File Offset: 0x000058D0
		// (set) Token: 0x060007C8 RID: 1992 RVA: 0x000076F3 File Offset: 0x000058F3
		public bool CODNotificationShown
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "CODNotificationShown", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "CODNotificationShown", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700023A RID: 570
		// (get) Token: 0x060007C9 RID: 1993 RVA: 0x00007714 File Offset: 0x00005914
		// (set) Token: 0x060007CA RID: 1994 RVA: 0x00007737 File Offset: 0x00005937
		public bool FreeFireNotificationShown
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "FreeFireNotificationShown", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "FreeFireNotificationShown", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700023B RID: 571
		// (get) Token: 0x060007CB RID: 1995 RVA: 0x00007758 File Offset: 0x00005958
		// (set) Token: 0x060007CC RID: 1996 RVA: 0x0000777B File Offset: 0x0000597B
		public bool SevenDeadlySinsNotificationShown
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "SevenDeadlySinsNotificationShown", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "SevenDeadlySinsNotificationShown", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700023C RID: 572
		// (get) Token: 0x060007CD RID: 1997 RVA: 0x0000779C File Offset: 0x0000599C
		// (set) Token: 0x060007CE RID: 1998 RVA: 0x000077BF File Offset: 0x000059BF
		public bool ShowMacroDeletePopup
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "ShowMacroDeletePopup", 1, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "ShowMacroDeletePopup", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700023D RID: 573
		// (get) Token: 0x060007CF RID: 1999 RVA: 0x000077E0 File Offset: 0x000059E0
		// (set) Token: 0x060007D0 RID: 2000 RVA: 0x00007803 File Offset: 0x00005A03
		public bool ShowSchemeDeletePopup
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "ShowSchemeDeletePopup", 1, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "ShowSchemeDeletePopup", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700023E RID: 574
		// (get) Token: 0x060007D1 RID: 2001 RVA: 0x00007824 File Offset: 0x00005A24
		// (set) Token: 0x060007D2 RID: 2002 RVA: 0x00007847 File Offset: 0x00005A47
		public bool IsFreeFireInGameSettingsCustomized
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "IsFreeFireInGameSettingsCustomized", 1, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "IsFreeFireInGameSettingsCustomized", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700023F RID: 575
		// (get) Token: 0x060007D3 RID: 2003 RVA: 0x00007868 File Offset: 0x00005A68
		// (set) Token: 0x060007D4 RID: 2004 RVA: 0x0000788B File Offset: 0x00005A8B
		public bool SevenDeadlySinsLandscape
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "SevenDeadlySinsLandscape", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "SevenDeadlySinsLandscape", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000240 RID: 576
		// (get) Token: 0x060007D5 RID: 2005 RVA: 0x000078AC File Offset: 0x00005AAC
		// (set) Token: 0x060007D6 RID: 2006 RVA: 0x000078CF File Offset: 0x00005ACF
		public bool IsClientOnTop
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "IsClientOnTop", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "IsClientOnTop", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000241 RID: 577
		// (get) Token: 0x060007D7 RID: 2007 RVA: 0x000078F0 File Offset: 0x00005AF0
		// (set) Token: 0x060007D8 RID: 2008 RVA: 0x0000791D File Offset: 0x00005B1D
		public ASTCOption ASTCOption
		{
			get
			{
				return (ASTCOption)RegistryUtils.GetRegistryValue(this.AndroidKeyPath, "ASTCOption", FeatureManager.Instance.IsCustomUIForNCSoft ? ASTCOption.SoftwareDecodingCache : ASTCOption.Disabled, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.AndroidKeyPath, "ASTCOption", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000242 RID: 578
		// (get) Token: 0x060007D9 RID: 2009 RVA: 0x00007938 File Offset: 0x00005B38
		// (set) Token: 0x060007DA RID: 2010 RVA: 0x0000795B File Offset: 0x00005B5B
		public bool IsHardwareAstcSupported
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.AndroidKeyPath, "IsHardwareAstcSupported", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.AndroidKeyPath, "IsHardwareAstcSupported", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000243 RID: 579
		// (get) Token: 0x060007DB RID: 2011 RVA: 0x0000797C File Offset: 0x00005B7C
		// (set) Token: 0x060007DC RID: 2012 RVA: 0x0000799F File Offset: 0x00005B9F
		public bool IsNativeGamepadEnabled
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "IsNativeGamepadEnabled", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "IsNativeGamepadEnabled", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000244 RID: 580
		// (get) Token: 0x060007DD RID: 2013 RVA: 0x000079C0 File Offset: 0x00005BC0
		// (set) Token: 0x060007DE RID: 2014 RVA: 0x000079E3 File Offset: 0x00005BE3
		public bool IsShowMinimizeBlueStacksPopupOnClose
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "IsShowMinimizeBlueStacksPopupOnClose", 1, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "IsShowMinimizeBlueStacksPopupOnClose", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000245 RID: 581
		// (get) Token: 0x060007DF RID: 2015 RVA: 0x00007A04 File Offset: 0x00005C04
		// (set) Token: 0x060007E0 RID: 2016 RVA: 0x00007A27 File Offset: 0x00005C27
		public bool IsMinimizeSelectedOnReceiveGameNotificationPopup
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mVmConfigKeyPath, "IsMinimizeSelectedOnReceiveGameNotificationPopup", 1, RegistryKeyKind.HKEY_LOCAL_MACHINE) != 0;
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mVmConfigKeyPath, "IsMinimizeSelectedOnReceiveGameNotificationPopup", value ? 1 : 0, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000246 RID: 582
		// (get) Token: 0x060007E1 RID: 2017 RVA: 0x00007A48 File Offset: 0x00005C48
		// (set) Token: 0x060007E2 RID: 2018 RVA: 0x00007A61 File Offset: 0x00005C61
		[SuppressMessage("Performance", "CA1819:Properties should not return arrays", Justification = "<Pending>")]
		public string[] NetworkInboundRules
		{
			get
			{
				return (string[])RegistryUtils.GetRegistryValue(this.mNetwork0KeyPath, "InboundRules", null, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mNetwork0KeyPath, "InboundRules", value, RegistryValueKind.MultiString, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000247 RID: 583
		// (get) Token: 0x060007E3 RID: 2019 RVA: 0x00007A77 File Offset: 0x00005C77
		// (set) Token: 0x060007E4 RID: 2020 RVA: 0x00007A90 File Offset: 0x00005C90
		public string AllowRemoteAccess
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mNetwork0KeyPath, "AllowRemoteAccess", null, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mNetwork0KeyPath, "AllowRemoteAccess", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000248 RID: 584
		// (get) Token: 0x060007E5 RID: 2021 RVA: 0x00007AA6 File Offset: 0x00005CA6
		// (set) Token: 0x060007E6 RID: 2022 RVA: 0x00007AC8 File Offset: 0x00005CC8
		public int NetworkRedirectTcp5555
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mNetworkRedirectKeyPath, "tcp/5555", 5555, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mNetworkRedirectKeyPath, "tcp/5555", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000249 RID: 585
		// (get) Token: 0x060007E7 RID: 2023 RVA: 0x00007AE3 File Offset: 0x00005CE3
		// (set) Token: 0x060007E8 RID: 2024 RVA: 0x00007B05 File Offset: 0x00005D05
		public int NetworkRedirectTcp6666
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mNetworkRedirectKeyPath, "tcp/6666", 6666, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mNetworkRedirectKeyPath, "tcp/6666", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700024A RID: 586
		// (get) Token: 0x060007E9 RID: 2025 RVA: 0x00007B20 File Offset: 0x00005D20
		// (set) Token: 0x060007EA RID: 2026 RVA: 0x00007B42 File Offset: 0x00005D42
		public int NetworkRedirectTcp7777
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mNetworkRedirectKeyPath, "tcp/7777", 7777, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mNetworkRedirectKeyPath, "tcp/7777", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700024B RID: 587
		// (get) Token: 0x060007EB RID: 2027 RVA: 0x00007B5D File Offset: 0x00005D5D
		// (set) Token: 0x060007EC RID: 2028 RVA: 0x00007B7F File Offset: 0x00005D7F
		public int NetworkRedirectTcp9999
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mNetworkRedirectKeyPath, "tcp/9999", 8888, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mNetworkRedirectKeyPath, "tcp/9999", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700024C RID: 588
		// (get) Token: 0x060007ED RID: 2029 RVA: 0x00007B9A File Offset: 0x00005D9A
		// (set) Token: 0x060007EE RID: 2030 RVA: 0x00007BBC File Offset: 0x00005DBC
		public int NetworkRedirectUdp12000
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mNetworkRedirectKeyPath, "udp/12000", 12000, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mNetworkRedirectKeyPath, "udp/12000", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700024D RID: 589
		// (get) Token: 0x060007EF RID: 2031 RVA: 0x00007BD7 File Offset: 0x00005DD7
		// (set) Token: 0x060007F0 RID: 2032 RVA: 0x00007BF4 File Offset: 0x00005DF4
		public string SharedFolder0Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder0KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder0KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700024E RID: 590
		// (get) Token: 0x060007F1 RID: 2033 RVA: 0x00007C0A File Offset: 0x00005E0A
		// (set) Token: 0x060007F2 RID: 2034 RVA: 0x00007C27 File Offset: 0x00005E27
		public string SharedFolder0Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder0KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder0KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700024F RID: 591
		// (get) Token: 0x060007F3 RID: 2035 RVA: 0x00007C3D File Offset: 0x00005E3D
		// (set) Token: 0x060007F4 RID: 2036 RVA: 0x00007C5B File Offset: 0x00005E5B
		public int SharedFolder0Writable
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mSharedFolder0KeyPath, "Writable", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder0KeyPath, "Writable", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000250 RID: 592
		// (get) Token: 0x060007F5 RID: 2037 RVA: 0x00007C76 File Offset: 0x00005E76
		// (set) Token: 0x060007F6 RID: 2038 RVA: 0x00007C93 File Offset: 0x00005E93
		public string SharedFolder1Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder1KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder1KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000251 RID: 593
		// (get) Token: 0x060007F7 RID: 2039 RVA: 0x00007CA9 File Offset: 0x00005EA9
		// (set) Token: 0x060007F8 RID: 2040 RVA: 0x00007CC6 File Offset: 0x00005EC6
		public string SharedFolder1Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder1KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder1KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000252 RID: 594
		// (get) Token: 0x060007F9 RID: 2041 RVA: 0x00007CDC File Offset: 0x00005EDC
		// (set) Token: 0x060007FA RID: 2042 RVA: 0x00007CFA File Offset: 0x00005EFA
		public int SharedFolder1Writable
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mSharedFolder1KeyPath, "Writable", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder1KeyPath, "Writable", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000253 RID: 595
		// (get) Token: 0x060007FB RID: 2043 RVA: 0x00007D15 File Offset: 0x00005F15
		// (set) Token: 0x060007FC RID: 2044 RVA: 0x00007D32 File Offset: 0x00005F32
		public string SharedFolder2Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder2KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder2KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000254 RID: 596
		// (get) Token: 0x060007FD RID: 2045 RVA: 0x00007D48 File Offset: 0x00005F48
		// (set) Token: 0x060007FE RID: 2046 RVA: 0x00007D65 File Offset: 0x00005F65
		public string SharedFolder2Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder2KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder2KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000255 RID: 597
		// (get) Token: 0x060007FF RID: 2047 RVA: 0x00007D7B File Offset: 0x00005F7B
		// (set) Token: 0x06000800 RID: 2048 RVA: 0x00007D99 File Offset: 0x00005F99
		public int SharedFolder2Writable
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mSharedFolder2KeyPath, "Writable", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder2KeyPath, "Writable", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000256 RID: 598
		// (get) Token: 0x06000801 RID: 2049 RVA: 0x00007DB4 File Offset: 0x00005FB4
		// (set) Token: 0x06000802 RID: 2050 RVA: 0x00007DD1 File Offset: 0x00005FD1
		public string SharedFolder3Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder3KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder3KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000257 RID: 599
		// (get) Token: 0x06000803 RID: 2051 RVA: 0x00007DE7 File Offset: 0x00005FE7
		// (set) Token: 0x06000804 RID: 2052 RVA: 0x00007E04 File Offset: 0x00006004
		public string SharedFolder3Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder3KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder3KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000258 RID: 600
		// (get) Token: 0x06000805 RID: 2053 RVA: 0x00007E1A File Offset: 0x0000601A
		// (set) Token: 0x06000806 RID: 2054 RVA: 0x00007E38 File Offset: 0x00006038
		public int SharedFolder3Writable
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mSharedFolder3KeyPath, "Writable", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder3KeyPath, "Writable", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x17000259 RID: 601
		// (get) Token: 0x06000807 RID: 2055 RVA: 0x00007E53 File Offset: 0x00006053
		// (set) Token: 0x06000808 RID: 2056 RVA: 0x00007E70 File Offset: 0x00006070
		public string SharedFolder4Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder4KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder4KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700025A RID: 602
		// (get) Token: 0x06000809 RID: 2057 RVA: 0x00007E86 File Offset: 0x00006086
		// (set) Token: 0x0600080A RID: 2058 RVA: 0x00007EA3 File Offset: 0x000060A3
		public string SharedFolder4Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder4KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder4KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700025B RID: 603
		// (get) Token: 0x0600080B RID: 2059 RVA: 0x00007EB9 File Offset: 0x000060B9
		// (set) Token: 0x0600080C RID: 2060 RVA: 0x00007ED7 File Offset: 0x000060D7
		public int SharedFolder4Writable
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mSharedFolder4KeyPath, "Writable", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder4KeyPath, "Writable", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700025C RID: 604
		// (get) Token: 0x0600080D RID: 2061 RVA: 0x00007EF2 File Offset: 0x000060F2
		// (set) Token: 0x0600080E RID: 2062 RVA: 0x00007F0F File Offset: 0x0000610F
		public string SharedFolder5Name
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder5KeyPath, "Name", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder5KeyPath, "Name", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700025D RID: 605
		// (get) Token: 0x0600080F RID: 2063 RVA: 0x00007F25 File Offset: 0x00006125
		// (set) Token: 0x06000810 RID: 2064 RVA: 0x00007F42 File Offset: 0x00006142
		public string SharedFolder5Path
		{
			get
			{
				return (string)RegistryUtils.GetRegistryValue(this.mSharedFolder5KeyPath, "Path", "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder5KeyPath, "Path", value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x1700025E RID: 606
		// (get) Token: 0x06000811 RID: 2065 RVA: 0x00007F58 File Offset: 0x00006158
		// (set) Token: 0x06000812 RID: 2066 RVA: 0x00007F76 File Offset: 0x00006176
		public int SharedFolder5Writable
		{
			get
			{
				return (int)RegistryUtils.GetRegistryValue(this.mSharedFolder5KeyPath, "Writable", 0, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
			set
			{
				RegistryUtils.SetRegistryValue(this.mSharedFolder5KeyPath, "Writable", value, RegistryValueKind.DWord, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			}
		}

		// Token: 0x04000400 RID: 1024
		private string mVmId;

		// Token: 0x04000401 RID: 1025
		private string mBaseKeyPath = "";

		// Token: 0x04000402 RID: 1026
		private string mBlockDeviceKeyPath = "";

		// Token: 0x04000403 RID: 1027
		private string mBlockDevice0KeyPath = "";

		// Token: 0x04000404 RID: 1028
		private string mBlockDevice1KeyPath = "";

		// Token: 0x04000405 RID: 1029
		private string mBlockDevice2KeyPath = "";

		// Token: 0x04000406 RID: 1030
		private string mBlockDevice3KeyPath = "";

		// Token: 0x04000407 RID: 1031
		private string mBlockDevice4KeyPath = "";

		// Token: 0x04000408 RID: 1032
		private string mVmConfigKeyPath = "";

		// Token: 0x04000409 RID: 1033
		private string mFrameBufferKeyPath = "";

		// Token: 0x0400040A RID: 1034
		private string mFrameBuffer0KeyPath = "";

		// Token: 0x0400040B RID: 1035
		private string mNetworkKeyPath = "";

		// Token: 0x0400040C RID: 1036
		private string mNetwork0KeyPath = "";

		// Token: 0x0400040D RID: 1037
		private string mNetworkRedirectKeyPath = "";

		// Token: 0x0400040E RID: 1038
		private string mSharedFolderKeyPath = "";

		// Token: 0x0400040F RID: 1039
		private string mSharedFolder0KeyPath = "";

		// Token: 0x04000410 RID: 1040
		private string mSharedFolder1KeyPath = "";

		// Token: 0x04000411 RID: 1041
		private string mSharedFolder2KeyPath = "";

		// Token: 0x04000412 RID: 1042
		private string mSharedFolder3KeyPath = "";

		// Token: 0x04000413 RID: 1043
		private string mSharedFolder4KeyPath = "";

		// Token: 0x04000414 RID: 1044
		private string mSharedFolder5KeyPath = "";
	}
}
