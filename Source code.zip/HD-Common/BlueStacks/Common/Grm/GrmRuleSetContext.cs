﻿using System;

namespace BlueStacks.Common.Grm
{
	// Token: 0x0200022C RID: 556
	public class GrmRuleSetContext
	{
		// Token: 0x1700047C RID: 1148
		// (get) Token: 0x06001138 RID: 4408 RVA: 0x0000E49B File Offset: 0x0000C69B
		// (set) Token: 0x06001139 RID: 4409 RVA: 0x0000E4A3 File Offset: 0x0000C6A3
		public string PackageName { get; set; }

		// Token: 0x1700047D RID: 1149
		// (get) Token: 0x0600113A RID: 4410 RVA: 0x0000E4AC File Offset: 0x0000C6AC
		// (set) Token: 0x0600113B RID: 4411 RVA: 0x0000E4B4 File Offset: 0x0000C6B4
		public string VmName { get; set; }

		// Token: 0x1700047E RID: 1150
		// (get) Token: 0x0600113C RID: 4412 RVA: 0x0000E4BD File Offset: 0x0000C6BD
		// (set) Token: 0x0600113D RID: 4413 RVA: 0x0000E4C5 File Offset: 0x0000C6C5
		public string RuleSetId { get; set; }

		// Token: 0x1700047F RID: 1151
		// (get) Token: 0x0600113E RID: 4414 RVA: 0x0000E4CE File Offset: 0x0000C6CE
		// (set) Token: 0x0600113F RID: 4415 RVA: 0x0000E4D6 File Offset: 0x0000C6D6
		public string ContextJson { get; set; }
	}
}
