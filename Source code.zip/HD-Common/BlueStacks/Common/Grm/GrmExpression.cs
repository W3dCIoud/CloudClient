﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace BlueStacks.Common.Grm
{
	// Token: 0x02000220 RID: 544
	public class GrmExpression
	{
		// Token: 0x1700046B RID: 1131
		// (get) Token: 0x06001104 RID: 4356 RVA: 0x0000E2B7 File Offset: 0x0000C4B7
		// (set) Token: 0x06001105 RID: 4357 RVA: 0x0000E2BF File Offset: 0x0000C4BF
		[JsonProperty(PropertyName = "leftOperand")]
		public string LeftOperand { get; set; } = string.Empty;

		// Token: 0x1700046C RID: 1132
		// (get) Token: 0x06001106 RID: 4358 RVA: 0x0000E2C8 File Offset: 0x0000C4C8
		// (set) Token: 0x06001107 RID: 4359 RVA: 0x0000E2D0 File Offset: 0x0000C4D0
		[JsonProperty(PropertyName = "operator")]
		public string Operator { get; set; } = string.Empty;

		// Token: 0x1700046D RID: 1133
		// (get) Token: 0x06001108 RID: 4360 RVA: 0x0000E2D9 File Offset: 0x0000C4D9
		// (set) Token: 0x06001109 RID: 4361 RVA: 0x0000E2E1 File Offset: 0x0000C4E1
		[JsonProperty(PropertyName = "rightOperand")]
		public string RightOperand { get; set; } = string.Empty;

		// Token: 0x1700046E RID: 1134
		// (get) Token: 0x0600110A RID: 4362 RVA: 0x0000E2EA File Offset: 0x0000C4EA
		// (set) Token: 0x0600110B RID: 4363 RVA: 0x0000E2F2 File Offset: 0x0000C4F2
		[JsonProperty(PropertyName = "contextJson")]
		public string ContextJson { get; set; } = string.Empty;

		// Token: 0x0600110C RID: 4364 RVA: 0x00040644 File Offset: 0x0003E844
		public bool EvaluateExpression(GrmRuleSetContext context)
		{
			bool result;
			try
			{
				if (context != null)
				{
					context.ContextJson = this.ContextJson;
				}
				GrmOperand operand = (GrmOperand)Enum.Parse(typeof(GrmOperand), this.LeftOperand, true);
				GrmOperator grmOperator = (GrmOperator)Enum.Parse(typeof(GrmOperator), this.Operator, true);
				result = EvaluatorFactory.CreateandReturnEvaluator(operand).Evaluate(context, grmOperator, this.RightOperand);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception while parsing operand for grmrule. operand: {0} operator: {1} rulesetid:{2} exception: {3}", new object[]
				{
					this.LeftOperand,
					this.Operator,
					(context != null) ? context.RuleSetId : null,
					ex.Message
				});
				if (!GrmExpression._rulesetsWithException.Contains((context != null) ? context.RuleSetId : null))
				{
					GrmExpression._rulesetsWithException.Add((context != null) ? context.RuleSetId : null);
					Stats.SendMiscellaneousStatsAsync("grm_evaluation_error", RegistryManager.Instance.UserGuid, (context != null) ? context.RuleSetId : null, RegistryManager.Instance.ClientVersion, RegistryManager.Instance.Version, "bgp", (context != null) ? context.PackageName : null, ex.Message, null, (context != null) ? context.VmName : null, 0);
				}
				result = false;
			}
			return result;
		}

		// Token: 0x04000D0E RID: 3342
		private static List<string> _rulesetsWithException = new List<string>();
	}
}
