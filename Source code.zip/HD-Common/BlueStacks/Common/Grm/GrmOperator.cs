﻿using System;

namespace BlueStacks.Common.Grm
{
	// Token: 0x02000229 RID: 553
	public enum GrmOperator
	{
		// Token: 0x04000D4E RID: 3406
		LessThan,
		// Token: 0x04000D4F RID: 3407
		GreaterThan,
		// Token: 0x04000D50 RID: 3408
		Equal,
		// Token: 0x04000D51 RID: 3409
		NotEqual,
		// Token: 0x04000D52 RID: 3410
		LessThanEqual,
		// Token: 0x04000D53 RID: 3411
		GreaterThanEqual,
		// Token: 0x04000D54 RID: 3412
		StartsWith,
		// Token: 0x04000D55 RID: 3413
		Contains,
		// Token: 0x04000D56 RID: 3414
		LikeRegex,
		// Token: 0x04000D57 RID: 3415
		In,
		// Token: 0x04000D58 RID: 3416
		NotIn
	}
}
