﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace BlueStacks.Common.Grm
{
	// Token: 0x0200021D RID: 541
	public class GrmAction
	{
		// Token: 0x17000469 RID: 1129
		// (get) Token: 0x060010FB RID: 4347 RVA: 0x0000E277 File Offset: 0x0000C477
		// (set) Token: 0x060010FC RID: 4348 RVA: 0x0000E27F File Offset: 0x0000C47F
		[JsonProperty(PropertyName = "actionType")]
		public string ActionType { get; set; } = string.Empty;

		// Token: 0x1700046A RID: 1130
		// (get) Token: 0x060010FD RID: 4349 RVA: 0x0000E288 File Offset: 0x0000C488
		// (set) Token: 0x060010FE RID: 4350 RVA: 0x0000E290 File Offset: 0x0000C490
		[JsonProperty(PropertyName = "actionDictionary")]
		public Dictionary<string, string> ActionDictionary { get; set; } = new Dictionary<string, string>();
	}
}
