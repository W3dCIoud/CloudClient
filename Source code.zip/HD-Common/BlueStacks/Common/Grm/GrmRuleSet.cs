﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace BlueStacks.Common.Grm
{
	// Token: 0x02000224 RID: 548
	public class GrmRuleSet
	{
		// Token: 0x17000478 RID: 1144
		// (get) Token: 0x06001124 RID: 4388 RVA: 0x0000E444 File Offset: 0x0000C644
		// (set) Token: 0x06001125 RID: 4389 RVA: 0x0000E44C File Offset: 0x0000C64C
		public string RuleId { get; set; }

		// Token: 0x17000479 RID: 1145
		// (get) Token: 0x06001126 RID: 4390 RVA: 0x0000E455 File Offset: 0x0000C655
		// (set) Token: 0x06001127 RID: 4391 RVA: 0x0000E45D File Offset: 0x0000C65D
		public string Description { get; set; }

		// Token: 0x1700047A RID: 1146
		// (get) Token: 0x06001128 RID: 4392 RVA: 0x0000E466 File Offset: 0x0000C666
		// (set) Token: 0x06001129 RID: 4393 RVA: 0x0000E46E File Offset: 0x0000C66E
		[JsonProperty(PropertyName = "rules")]
		public List<GrmRule> Rules { get; set; } = new List<GrmRule>();

		// Token: 0x1700047B RID: 1147
		// (get) Token: 0x0600112A RID: 4394 RVA: 0x0000E477 File Offset: 0x0000C677
		// (set) Token: 0x0600112B RID: 4395 RVA: 0x0000E47F File Offset: 0x0000C67F
		[JsonProperty(PropertyName = "messageWindow")]
		public GrmMessageWindow MessageWindow { get; set; }
	}
}
