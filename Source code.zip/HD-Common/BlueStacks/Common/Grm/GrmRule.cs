﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace BlueStacks.Common.Grm
{
	// Token: 0x02000223 RID: 547
	public class GrmRule
	{
		// Token: 0x17000477 RID: 1143
		// (get) Token: 0x06001121 RID: 4385 RVA: 0x0000E420 File Offset: 0x0000C620
		// (set) Token: 0x06001122 RID: 4386 RVA: 0x0000E428 File Offset: 0x0000C628
		[JsonProperty(PropertyName = "expressions")]
		public List<GrmExpression> Expressions { get; set; } = new List<GrmExpression>();
	}
}
