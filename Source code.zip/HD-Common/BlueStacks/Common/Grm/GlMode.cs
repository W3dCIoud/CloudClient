﻿using System;

namespace BlueStacks.Common.Grm
{
	// Token: 0x0200022A RID: 554
	public enum GlMode
	{
		// Token: 0x04000D5A RID: 3418
		PGA_DX,
		// Token: 0x04000D5B RID: 3419
		AGA_DX,
		// Token: 0x04000D5C RID: 3420
		PGA_GL,
		// Token: 0x04000D5D RID: 3421
		AGA_GL
	}
}
