﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace BlueStacks.Common.Grm
{
	// Token: 0x0200021B RID: 539
	public class AppRequirement
	{
		// Token: 0x17000467 RID: 1127
		// (get) Token: 0x060010F3 RID: 4339 RVA: 0x0000E242 File Offset: 0x0000C442
		// (set) Token: 0x060010F4 RID: 4340 RVA: 0x0000E24A File Offset: 0x0000C44A
		[JsonProperty(PropertyName = "pkgName")]
		public string PackageName { get; set; }

		// Token: 0x17000468 RID: 1128
		// (get) Token: 0x060010F5 RID: 4341 RVA: 0x0000E253 File Offset: 0x0000C453
		// (set) Token: 0x060010F6 RID: 4342 RVA: 0x0000E25B File Offset: 0x0000C45B
		[JsonProperty(PropertyName = "RuleSets")]
		public List<GrmRuleSet> GrmRuleSets { get; set; } = new List<GrmRuleSet>();

		// Token: 0x060010F7 RID: 4343 RVA: 0x00040110 File Offset: 0x0003E310
		public GrmRuleSet EvaluateRequirement(string packageName, string vmName)
		{
			GrmRuleSetContext grmRuleSetContext = new GrmRuleSetContext
			{
				PackageName = packageName,
				VmName = vmName
			};
			foreach (GrmRuleSet grmRuleSet in this.GrmRuleSets)
			{
				if (!RegistryManager.Instance.Guest[vmName].GrmDonotShowRuleList.Contains(grmRuleSet.RuleId))
				{
					grmRuleSetContext.RuleSetId = grmRuleSet.RuleId;
					bool flag = false;
					foreach (GrmRule grmRule in grmRuleSet.Rules)
					{
						bool flag2 = true;
						foreach (GrmExpression grmExpression in grmRule.Expressions)
						{
							flag2 = (flag2 && grmExpression.EvaluateExpression(grmRuleSetContext));
							if (!flag2)
							{
								break;
							}
						}
						if (flag2)
						{
							flag = true;
							break;
						}
					}
					if (flag)
					{
						return grmRuleSet;
					}
				}
			}
			return null;
		}
	}
}
