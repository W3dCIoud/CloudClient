﻿using System;

namespace BlueStacks.Common.Grm
{
	// Token: 0x0200022B RID: 555
	public enum GuestOS
	{
		// Token: 0x04000D5F RID: 3423
		Kitkat,
		// Token: 0x04000D60 RID: 3424
		Nougat
	}
}
