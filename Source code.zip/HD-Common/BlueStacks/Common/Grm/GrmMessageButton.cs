﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace BlueStacks.Common.Grm
{
	// Token: 0x02000221 RID: 545
	public class GrmMessageButton
	{
		// Token: 0x1700046F RID: 1135
		// (get) Token: 0x0600110F RID: 4367 RVA: 0x0000E33B File Offset: 0x0000C53B
		// (set) Token: 0x06001110 RID: 4368 RVA: 0x0000E343 File Offset: 0x0000C543
		[JsonProperty(PropertyName = "buttonColor")]
		public string ButtonColor { get; set; } = "Blue";

		// Token: 0x17000470 RID: 1136
		// (get) Token: 0x06001111 RID: 4369 RVA: 0x0000E34C File Offset: 0x0000C54C
		// (set) Token: 0x06001112 RID: 4370 RVA: 0x0000E354 File Offset: 0x0000C554
		[JsonProperty(PropertyName = "buttonStringKey")]
		public string ButtonStringKey { get; set; } = string.Empty;

		// Token: 0x17000471 RID: 1137
		// (get) Token: 0x06001113 RID: 4371 RVA: 0x0000E35D File Offset: 0x0000C55D
		// (set) Token: 0x06001114 RID: 4372 RVA: 0x0000E365 File Offset: 0x0000C565
		[JsonProperty(PropertyName = "actions")]
		public List<GrmAction> Actions { get; set; } = new List<GrmAction>();
	}
}
