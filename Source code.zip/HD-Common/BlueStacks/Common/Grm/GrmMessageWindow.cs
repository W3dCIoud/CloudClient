﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace BlueStacks.Common.Grm
{
	// Token: 0x02000222 RID: 546
	public class GrmMessageWindow
	{
		// Token: 0x17000472 RID: 1138
		// (get) Token: 0x06001116 RID: 4374 RVA: 0x0000E397 File Offset: 0x0000C597
		// (set) Token: 0x06001117 RID: 4375 RVA: 0x0000E39F File Offset: 0x0000C59F
		[JsonProperty(PropertyName = "messageType")]
		public string MessageType { get; set; } = "None";

		// Token: 0x17000473 RID: 1139
		// (get) Token: 0x06001118 RID: 4376 RVA: 0x0000E3A8 File Offset: 0x0000C5A8
		// (set) Token: 0x06001119 RID: 4377 RVA: 0x0000E3B0 File Offset: 0x0000C5B0
		[JsonProperty(PropertyName = "headerStringKey")]
		public string HeaderStringKey { get; set; } = string.Empty;

		// Token: 0x17000474 RID: 1140
		// (get) Token: 0x0600111A RID: 4378 RVA: 0x0000E3B9 File Offset: 0x0000C5B9
		// (set) Token: 0x0600111B RID: 4379 RVA: 0x0000E3C1 File Offset: 0x0000C5C1
		[JsonProperty(PropertyName = "messageStringKey")]
		public string MessageStringKey { get; set; } = string.Empty;

		// Token: 0x17000475 RID: 1141
		// (get) Token: 0x0600111C RID: 4380 RVA: 0x0000E3CA File Offset: 0x0000C5CA
		// (set) Token: 0x0600111D RID: 4381 RVA: 0x0000E3D2 File Offset: 0x0000C5D2
		[JsonProperty(PropertyName = "dontShowOption")]
		public bool DontShowOption { get; set; }

		// Token: 0x17000476 RID: 1142
		// (get) Token: 0x0600111E RID: 4382 RVA: 0x0000E3DB File Offset: 0x0000C5DB
		// (set) Token: 0x0600111F RID: 4383 RVA: 0x0000E3E3 File Offset: 0x0000C5E3
		[JsonProperty(PropertyName = "buttons")]
		public List<GrmMessageButton> Buttons { get; set; } = new List<GrmMessageButton>();
	}
}
