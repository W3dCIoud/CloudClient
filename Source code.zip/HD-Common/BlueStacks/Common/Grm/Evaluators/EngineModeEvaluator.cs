﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x02000231 RID: 561
	internal class EngineModeEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000484 RID: 1156
		// (get) Token: 0x0600114D RID: 4429 RVA: 0x0000E4EF File Offset: 0x0000C6EF
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.EngineMode;
			}
		}

		// Token: 0x0600114E RID: 4430 RVA: 0x000408EC File Offset: 0x0003EAEC
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			EngineState engineState = EngineState.plus;
			if (RegistryManager.Instance.CurrentEngine == "raw")
			{
				engineState = EngineState.raw;
			}
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, engineState.ToString(), rightOperand, context);
		}
	}
}
