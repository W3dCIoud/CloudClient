﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Win32;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x0200023B RID: 571
	internal class InstalledOemEvaluator : IRequirementEvaluator
	{
		// Token: 0x1700048E RID: 1166
		// (get) Token: 0x0600116C RID: 4460 RVA: 0x0000E515 File Offset: 0x0000C715
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.InstalledOems;
			}
		}

		// Token: 0x0600116D RID: 4461 RVA: 0x00040C40 File Offset: 0x0003EE40
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			List<string> list = new List<string>();
			try
			{
				foreach (string text in Registry.LocalMachine.OpenSubKey("Software").GetSubKeyNames())
				{
					if (text.StartsWith("BlueStacks", StringComparison.OrdinalIgnoreCase) && !text.StartsWith("BlueStacksGP", StringComparison.OrdinalIgnoreCase) && !text.StartsWith("BlueStacksInstaller", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrEmpty((string)Utils.GetRegistryHKLMValue("Software\\" + text, "Version", "")))
					{
						if (text.Split(new char[]
						{
							'_'
						}).Length > 1)
						{
							list.Add(text.Split(new char[]
							{
								'_'
							}).ToList<string>()[1]);
						}
						else
						{
							list.Add("bgp");
						}
					}
				}
				list = list.Distinct<string>().ToList<string>();
			}
			catch (Exception ex)
			{
				Logger.Info("Error in finding installed oems " + ex.ToString());
			}
			return GrmComparer<List<string>>.Evaluate(this.EvaluatorForOperandType, grmOperator, list, rightOperand, context);
		}
	}
}
