﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x02000236 RID: 566
	internal class GlModeEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000489 RID: 1161
		// (get) Token: 0x0600115C RID: 4444 RVA: 0x0000E4FE File Offset: 0x0000C6FE
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.GlMode;
			}
		}

		// Token: 0x0600115D RID: 4445 RVA: 0x00040A3C File Offset: 0x0003EC3C
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			int glRenderMode = RegistryManager.Instance.Guest[context.VmName].GlRenderMode;
			int glMode = RegistryManager.Instance.Guest[context.VmName].GlMode;
			GlMode glMode2;
			if (glRenderMode == 1 && glMode == 1)
			{
				glMode2 = GlMode.PGA_GL;
			}
			else if (glRenderMode == 1 && glMode == 2)
			{
				glMode2 = GlMode.AGA_GL;
			}
			else if (glMode == 1)
			{
				glMode2 = GlMode.PGA_DX;
			}
			else
			{
				if (glMode != 2)
				{
					throw new Exception("Could not determine the engine mode for current build.");
				}
				glMode2 = GlMode.AGA_DX;
			}
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, glMode2.ToString(), rightOperand, context);
		}
	}
}
