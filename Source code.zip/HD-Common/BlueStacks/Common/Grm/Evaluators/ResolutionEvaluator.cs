﻿using System;
using System.Globalization;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x02000244 RID: 580
	internal class ResolutionEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000498 RID: 1176
		// (get) Token: 0x06001187 RID: 4487 RVA: 0x0000E543 File Offset: 0x0000C743
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.Resolution;
			}
		}

		// Token: 0x06001188 RID: 4488 RVA: 0x00041190 File Offset: 0x0003F390
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			int guestWidth = RegistryManager.Instance.Guest[context.VmName].GuestWidth;
			int guestHeight = RegistryManager.Instance.Guest[context.VmName].GuestHeight;
			string left = guestWidth.ToString(CultureInfo.InvariantCulture) + "x" + guestHeight.ToString(CultureInfo.InvariantCulture);
			rightOperand = rightOperand.Replace(" ", string.Empty);
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, left, rightOperand, context);
		}
	}
}
