﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x02000230 RID: 560
	internal class DeviceProfileEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000483 RID: 1155
		// (get) Token: 0x0600114A RID: 4426 RVA: 0x0000E4EB File Offset: 0x0000C6EB
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.DeviceProfile;
			}
		}

		// Token: 0x0600114B RID: 4427 RVA: 0x000408B8 File Offset: 0x0003EAB8
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			string valueInBootParams = Utils.GetValueInBootParams("pcode", context.VmName, "");
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, valueInBootParams, rightOperand, context);
		}
	}
}
