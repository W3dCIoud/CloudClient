﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x02000238 RID: 568
	internal class GeoEvaluator : IRequirementEvaluator
	{
		// Token: 0x1700048B RID: 1163
		// (get) Token: 0x06001162 RID: 4450 RVA: 0x0000DC39 File Offset: 0x0000BE39
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.Geo;
			}
		}

		// Token: 0x06001163 RID: 4451 RVA: 0x00040B08 File Offset: 0x0003ED08
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			string geo = RegistryManager.Instance.Geo;
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, geo, rightOperand, context);
		}
	}
}
