﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x0200023C RID: 572
	internal interface IRequirementEvaluator
	{
		// Token: 0x1700048F RID: 1167
		// (get) Token: 0x0600116F RID: 4463
		GrmOperand EvaluatorForOperandType { get; }

		// Token: 0x06001170 RID: 4464
		bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand);
	}
}
