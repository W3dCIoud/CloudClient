﻿using System;
using System.Globalization;
using Microsoft.VisualBasic.Devices;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x02000240 RID: 576
	public class PhysicalRamEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000493 RID: 1171
		// (get) Token: 0x0600117A RID: 4474 RVA: 0x0000E539 File Offset: 0x0000C739
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.PhysicalRam;
			}
		}

		// Token: 0x17000494 RID: 1172
		// (get) Token: 0x0600117B RID: 4475 RVA: 0x00040DCC File Offset: 0x0003EFCC
		public static string RAM
		{
			get
			{
				int num = 0;
				try
				{
					num = (int)(new ComputerInfo().TotalPhysicalMemory / 1048576UL);
				}
				catch (Exception ex)
				{
					Logger.Error("Exception when finding ram");
					Logger.Error(ex.ToString());
				}
				return num.ToString(CultureInfo.InvariantCulture);
			}
		}

		// Token: 0x0600117C RID: 4476 RVA: 0x00040E24 File Offset: 0x0003F024
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			int num;
			int.TryParse(PhysicalRamEvaluator.RAM, out num);
			int num2 = (int)((double)num * 0.5);
			if (num2 >= 4096)
			{
				num2 = 4096;
			}
			if (RegistryManager.Instance.CurrentEngine == "raw" && num2 >= 3072)
			{
				num2 = 3072;
			}
			return GrmComparer<int>.Evaluate(this.EvaluatorForOperandType, grmOperator, num2, rightOperand, context);
		}
	}
}
