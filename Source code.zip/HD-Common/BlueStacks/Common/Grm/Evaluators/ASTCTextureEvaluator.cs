﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x0200022E RID: 558
	internal class ASTCTextureEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000481 RID: 1153
		// (get) Token: 0x06001144 RID: 4420 RVA: 0x0000E4E3 File Offset: 0x0000C6E3
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.ASTCTexture;
			}
		}

		// Token: 0x06001145 RID: 4421 RVA: 0x00040804 File Offset: 0x0003EA04
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			ASTCOption astcoption = RegistryManager.Instance.Guest[context.VmName].ASTCOption;
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, astcoption.ToString(), rightOperand, context);
		}
	}
}
