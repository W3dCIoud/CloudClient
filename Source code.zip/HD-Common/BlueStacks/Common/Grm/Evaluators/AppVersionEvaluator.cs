﻿using System;
using System.Globalization;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x02000232 RID: 562
	internal class AppVersionEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000485 RID: 1157
		// (get) Token: 0x06001150 RID: 4432 RVA: 0x00006447 File Offset: 0x00004647
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.AppVersionCode;
			}
		}

		// Token: 0x06001151 RID: 4433 RVA: 0x00040930 File Offset: 0x0003EB30
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			int left = int.Parse(new JsonParser(context.VmName).GetAppInfoFromPackageName(context.PackageName).Version, CultureInfo.InvariantCulture);
			return GrmComparer<int>.Evaluate(this.EvaluatorForOperandType, grmOperator, left, rightOperand, context);
		}
	}
}
