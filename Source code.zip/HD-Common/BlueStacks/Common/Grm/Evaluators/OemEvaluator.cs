﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x0200023E RID: 574
	internal class OemEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000491 RID: 1169
		// (get) Token: 0x06001174 RID: 4468 RVA: 0x0000E51C File Offset: 0x0000C71C
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.Oem;
			}
		}

		// Token: 0x06001175 RID: 4469 RVA: 0x0000E520 File Offset: 0x0000C720
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, "bgp", rightOperand, context);
		}
	}
}
