﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x0200023D RID: 573
	internal class Is64BitEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000490 RID: 1168
		// (get) Token: 0x06001171 RID: 4465 RVA: 0x0000E519 File Offset: 0x0000C719
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.Is64Bit;
			}
		}

		// Token: 0x06001172 RID: 4466 RVA: 0x00040D60 File Offset: 0x0003EF60
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			bool is64BitOperatingSystem = CommonInstallUtils.is64BitOperatingSystem;
			return GrmComparer<bool>.Evaluate(this.EvaluatorForOperandType, grmOperator, is64BitOperatingSystem, rightOperand, context);
		}
	}
}
