﻿using System;
using System.IO;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x02000234 RID: 564
	internal class CustomKeyMappingExistsEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000487 RID: 1159
		// (get) Token: 0x06001156 RID: 4438 RVA: 0x0000E4F6 File Offset: 0x0000C6F6
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.CustomKeyMappingExists;
			}
		}

		// Token: 0x06001157 RID: 4439 RVA: 0x000409AC File Offset: 0x0003EBAC
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			bool left = File.Exists(Path.Combine(Path.Combine(RegistryStrings.InputMapperFolder, "UserFiles"), context.PackageName + ".cfg"));
			return GrmComparer<bool>.Evaluate(this.EvaluatorForOperandType, grmOperator, left, rightOperand, context);
		}
	}
}
