﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x02000233 RID: 563
	internal class CpuCoresAllocatedEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000486 RID: 1158
		// (get) Token: 0x06001153 RID: 4435 RVA: 0x0000E4F2 File Offset: 0x0000C6F2
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.CpuCoresAllocated;
			}
		}

		// Token: 0x06001154 RID: 4436 RVA: 0x00040974 File Offset: 0x0003EB74
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			int vcpus = RegistryManager.Instance.Guest[context.VmName].VCPUs;
			return GrmComparer<int>.Evaluate(this.EvaluatorForOperandType, grmOperator, vcpus, rightOperand, context);
		}
	}
}
