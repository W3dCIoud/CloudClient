﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x02000241 RID: 577
	internal class ProductVersionEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000495 RID: 1173
		// (get) Token: 0x0600117E RID: 4478 RVA: 0x0000323B File Offset: 0x0000143B
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.ProductVersion;
			}
		}

		// Token: 0x0600117F RID: 4479 RVA: 0x00040E90 File Offset: 0x0003F090
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			Version left = new Version(RegistryManager.Instance.Version);
			return GrmComparer<Version>.Evaluate(this.EvaluatorForOperandType, grmOperator, left, rightOperand, context);
		}
	}
}
