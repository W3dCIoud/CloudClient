﻿using System;
using System.Collections.Generic;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x02000239 RID: 569
	internal class GpuEvaluator : IRequirementEvaluator
	{
		// Token: 0x1700048C RID: 1164
		// (get) Token: 0x06001165 RID: 4453 RVA: 0x0000DDE7 File Offset: 0x0000BFE7
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.Gpu;
			}
		}

		// Token: 0x06001166 RID: 4454 RVA: 0x00040B30 File Offset: 0x0003ED30
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			if (!GpuEvaluator.mVmNameGpu.ContainsKey(context.VmName) || string.IsNullOrEmpty(GpuEvaluator.mVmNameGpu[context.VmName]))
			{
				string str;
				string str2;
				string text;
				Utils.GetCurrentGraphicsInfo(RegistryManager.Instance.Guest[context.VmName].GlRenderMode.ToString() + " " + RegistryManager.Instance.Guest[context.VmName].GlMode.ToString(), out str, out str2, out text);
				string text2 = str + " " + str2;
				GpuEvaluator.mVmNameGpu[context.VmName] = text2;
				Logger.Info("GpuEvaluator " + text2);
			}
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, GpuEvaluator.mVmNameGpu[context.VmName], rightOperand, context);
		}

		// Token: 0x04000D65 RID: 3429
		private static Dictionary<string, string> mVmNameGpu = new Dictionary<string, string>();
	}
}
