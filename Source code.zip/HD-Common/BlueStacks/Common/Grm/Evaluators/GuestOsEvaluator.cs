﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x0200023A RID: 570
	internal class GuestOsEvaluator : IRequirementEvaluator
	{
		// Token: 0x1700048D RID: 1165
		// (get) Token: 0x06001169 RID: 4457 RVA: 0x0000E511 File Offset: 0x0000C711
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.GuestOs;
			}
		}

		// Token: 0x0600116A RID: 4458 RVA: 0x00040C14 File Offset: 0x0003EE14
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			GuestOS guestOS = GuestOS.Nougat;
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, guestOS.ToString(), rightOperand, context);
		}
	}
}
