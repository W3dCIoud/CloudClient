﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x0200022F RID: 559
	internal class BootParamEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000482 RID: 1154
		// (get) Token: 0x06001147 RID: 4423 RVA: 0x0000E4E7 File Offset: 0x0000C6E7
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.BootParam;
			}
		}

		// Token: 0x06001148 RID: 4424 RVA: 0x00040848 File Offset: 0x0003EA48
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			JObject jobject = JsonConvert.DeserializeObject(context.ContextJson, Utils.GetSerializerSettings()) as JObject;
			if (jobject == null || !jobject.ContainsKey("param"))
			{
				throw new ArgumentException("BootParamEvaluator requires contextjson with param key.");
			}
			string valueInBootParams = Utils.GetValueInBootParams(jobject["param"].Value<string>(), context.VmName, "");
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, valueInBootParams, rightOperand, context);
		}
	}
}
