﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x02000237 RID: 567
	internal class FpsEvaluator : IRequirementEvaluator
	{
		// Token: 0x1700048A RID: 1162
		// (get) Token: 0x0600115F RID: 4447 RVA: 0x0000E501 File Offset: 0x0000C701
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.Fps;
			}
		}

		// Token: 0x06001160 RID: 4448 RVA: 0x00040AD0 File Offset: 0x0003ECD0
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			int fps = RegistryManager.Instance.Guest[context.VmName].FPS;
			return GrmComparer<int>.Evaluate(this.EvaluatorForOperandType, grmOperator, fps, rightOperand, context);
		}
	}
}
