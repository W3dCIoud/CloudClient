﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x0200023F RID: 575
	internal class PhysicalCoresAvailableEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000492 RID: 1170
		// (get) Token: 0x06001177 RID: 4471 RVA: 0x0000E535 File Offset: 0x0000C735
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.PhysicalCoresAvailable;
			}
		}

		// Token: 0x06001178 RID: 4472 RVA: 0x00040D84 File Offset: 0x0003EF84
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			int left = 1;
			if (RegistryManager.Instance.CurrentEngine != "raw")
			{
				left = ((Environment.ProcessorCount > 8) ? 8 : Environment.ProcessorCount);
			}
			return GrmComparer<int>.Evaluate(this.EvaluatorForOperandType, grmOperator, left, rightOperand, context);
		}
	}
}
