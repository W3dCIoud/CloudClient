﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x0200022D RID: 557
	internal class ABIModeEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000480 RID: 1152
		// (get) Token: 0x06001141 RID: 4417 RVA: 0x0000E4DF File Offset: 0x0000C6DF
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.ABIMode;
			}
		}

		// Token: 0x06001142 RID: 4418 RVA: 0x00040788 File Offset: 0x0003E988
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			string text = Utils.GetValueInBootParams("abivalue", context.VmName, "");
			if (string.IsNullOrEmpty(text))
			{
				text = ABISetting.Auto.ToString("D");
			}
			return GrmComparer<string>.Evaluate(this.EvaluatorForOperandType, grmOperator, (text == "15") ? ABISetting.Auto.ToString() : ABISetting.ARM.ToString(), rightOperand, context);
		}
	}
}
