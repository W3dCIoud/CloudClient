﻿using System;
using System.Globalization;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x02000235 RID: 565
	internal class DpiEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000488 RID: 1160
		// (get) Token: 0x06001159 RID: 4441 RVA: 0x0000E4FA File Offset: 0x0000C6FA
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.Dpi;
			}
		}

		// Token: 0x0600115A RID: 4442 RVA: 0x000409F4 File Offset: 0x0003EBF4
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			string dpiFromBootParameters = Utils.GetDpiFromBootParameters(RegistryManager.Instance.Guest[context.VmName].BootParameters);
			return GrmComparer<int>.Evaluate(this.EvaluatorForOperandType, grmOperator, Convert.ToInt32(dpiFromBootParameters, CultureInfo.InvariantCulture), rightOperand, context);
		}
	}
}
