﻿using System;

namespace BlueStacks.Common.Grm.Evaluators
{
	// Token: 0x02000242 RID: 578
	internal class RamEvaluator : IRequirementEvaluator
	{
		// Token: 0x17000496 RID: 1174
		// (get) Token: 0x06001181 RID: 4481 RVA: 0x0000E53C File Offset: 0x0000C73C
		public GrmOperand EvaluatorForOperandType
		{
			get
			{
				return GrmOperand.Ram;
			}
		}

		// Token: 0x06001182 RID: 4482 RVA: 0x00040EBC File Offset: 0x0003F0BC
		public bool Evaluate(GrmRuleSetContext context, GrmOperator grmOperator, string rightOperand)
		{
			int memory = RegistryManager.Instance.Guest[context.VmName].Memory;
			return GrmComparer<int>.Evaluate(this.EvaluatorForOperandType, grmOperator, memory, rightOperand, context);
		}
	}
}
