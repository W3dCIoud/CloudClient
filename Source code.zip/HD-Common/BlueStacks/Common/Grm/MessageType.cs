﻿using System;

namespace BlueStacks.Common.Grm
{
	// Token: 0x02000226 RID: 550
	public enum MessageType
	{
		// Token: 0x04000D21 RID: 3361
		None,
		// Token: 0x04000D22 RID: 3362
		Info,
		// Token: 0x04000D23 RID: 3363
		Error
	}
}
