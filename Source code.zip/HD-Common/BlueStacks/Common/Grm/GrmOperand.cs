﻿using System;

namespace BlueStacks.Common.Grm
{
	// Token: 0x02000228 RID: 552
	public enum GrmOperand
	{
		// Token: 0x04000D36 RID: 3382
		AppVersionCode,
		// Token: 0x04000D37 RID: 3383
		ProductVersion,
		// Token: 0x04000D38 RID: 3384
		Geo,
		// Token: 0x04000D39 RID: 3385
		Gpu,
		// Token: 0x04000D3A RID: 3386
		Ram,
		// Token: 0x04000D3B RID: 3387
		PhysicalRam,
		// Token: 0x04000D3C RID: 3388
		GlMode,
		// Token: 0x04000D3D RID: 3389
		EngineMode,
		// Token: 0x04000D3E RID: 3390
		Is64Bit,
		// Token: 0x04000D3F RID: 3391
		CpuCoresAllocated,
		// Token: 0x04000D40 RID: 3392
		PhysicalCoresAvailable,
		// Token: 0x04000D41 RID: 3393
		Dpi,
		// Token: 0x04000D42 RID: 3394
		Fps,
		// Token: 0x04000D43 RID: 3395
		Resolution,
		// Token: 0x04000D44 RID: 3396
		GuestOs,
		// Token: 0x04000D45 RID: 3397
		Oem,
		// Token: 0x04000D46 RID: 3398
		InstalledOems,
		// Token: 0x04000D47 RID: 3399
		CustomKeyMappingExists,
		// Token: 0x04000D48 RID: 3400
		RegistryKeyValue,
		// Token: 0x04000D49 RID: 3401
		BootParam,
		// Token: 0x04000D4A RID: 3402
		DeviceProfile,
		// Token: 0x04000D4B RID: 3403
		ASTCTexture,
		// Token: 0x04000D4C RID: 3404
		ABIMode
	}
}
