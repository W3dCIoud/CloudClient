﻿using System;

namespace BlueStacks.Common.Grm
{
	// Token: 0x02000227 RID: 551
	public enum GrmActionType
	{
		// Token: 0x04000D25 RID: 3365
		UpdateRam,
		// Token: 0x04000D26 RID: 3366
		UserBrowser,
		// Token: 0x04000D27 RID: 3367
		DownloadFileAndExecute,
		// Token: 0x04000D28 RID: 3368
		NoAction,
		// Token: 0x04000D29 RID: 3369
		ContinueAnyway,
		// Token: 0x04000D2A RID: 3370
		GlMode,
		// Token: 0x04000D2B RID: 3371
		DeviceProfile,
		// Token: 0x04000D2C RID: 3372
		BootParam,
		// Token: 0x04000D2D RID: 3373
		DPI,
		// Token: 0x04000D2E RID: 3374
		CpuCores,
		// Token: 0x04000D2F RID: 3375
		Resolution,
		// Token: 0x04000D30 RID: 3376
		RestartBluestacks,
		// Token: 0x04000D31 RID: 3377
		RestartMachine,
		// Token: 0x04000D32 RID: 3378
		Fps,
		// Token: 0x04000D33 RID: 3379
		EditRegistry,
		// Token: 0x04000D34 RID: 3380
		ClearAppData
	}
}
