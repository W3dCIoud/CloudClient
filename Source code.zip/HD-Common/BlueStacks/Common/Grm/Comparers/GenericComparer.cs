﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common.Grm.Comparers
{
	// Token: 0x02000246 RID: 582
	internal class GenericComparer<T> : IGrmOperatorComparer<T> where T : IComparable<T>, IConvertible
	{
		// Token: 0x06001196 RID: 4502 RVA: 0x0000E5BC File Offset: 0x0000C7BC
		public bool Contains(T left, string right)
		{
			return left.ToString().Contains(right, StringComparison.InvariantCultureIgnoreCase);
		}

		// Token: 0x06001197 RID: 4503 RVA: 0x00041258 File Offset: 0x0003F458
		public bool Equal(T left, string right)
		{
			T y = (T)((object)Convert.ChangeType(right, typeof(T), CultureInfo.InvariantCulture));
			return EqualityComparer<T>.Default.Equals(left, y);
		}

		// Token: 0x06001198 RID: 4504 RVA: 0x0004128C File Offset: 0x0003F48C
		public bool GreaterThan(T left, string right)
		{
			T other = (T)((object)Convert.ChangeType(right, typeof(T), CultureInfo.InvariantCulture));
			return left.CompareTo(other) > 0;
		}

		// Token: 0x06001199 RID: 4505 RVA: 0x000412C8 File Offset: 0x0003F4C8
		public bool GreaterThanEqual(T left, string right)
		{
			T other = (T)((object)Convert.ChangeType(right, typeof(T), CultureInfo.InvariantCulture));
			return left.CompareTo(other) >= 0;
		}

		// Token: 0x0600119A RID: 4506 RVA: 0x00041304 File Offset: 0x0003F504
		public bool In(T left, string right)
		{
			return (from element in right.Split(new char[]
			{
				','
			})
			select (T)((object)Convert.ChangeType(element.Trim(), typeof(T), CultureInfo.InvariantCulture))).ToList<T>().Contains(left);
		}

		// Token: 0x0600119B RID: 4507 RVA: 0x00041354 File Offset: 0x0003F554
		public bool LessThan(T left, string right)
		{
			T other = (T)((object)Convert.ChangeType(right, typeof(T), CultureInfo.InvariantCulture));
			return left.CompareTo(other) < 0;
		}

		// Token: 0x0600119C RID: 4508 RVA: 0x00041390 File Offset: 0x0003F590
		public bool LessThanEqual(T left, string right)
		{
			T other = (T)((object)Convert.ChangeType(right, typeof(T), CultureInfo.InvariantCulture));
			return left.CompareTo(other) <= 0;
		}

		// Token: 0x0600119D RID: 4509 RVA: 0x000413CC File Offset: 0x0003F5CC
		public bool LikeRegex(T left, string right, string contextJson)
		{
			JObject jobject = JsonConvert.DeserializeObject(contextJson, Utils.GetSerializerSettings()) as JObject;
			int options = 1;
			if (jobject != null && jobject.ContainsKey("regexOptions") && !string.IsNullOrEmpty(jobject["regexOptions"].Value<string>()))
			{
				options = int.Parse(jobject["regexOptions"].Value<string>(), CultureInfo.InvariantCulture);
			}
			return new Regex(right, (RegexOptions)options).IsMatch(left.ToString());
		}

		// Token: 0x0600119E RID: 4510 RVA: 0x00041448 File Offset: 0x0003F648
		public bool NotEqual(T left, string right)
		{
			T y = (T)((object)Convert.ChangeType(right, typeof(T), CultureInfo.InvariantCulture));
			return !EqualityComparer<T>.Default.Equals(left, y);
		}

		// Token: 0x0600119F RID: 4511 RVA: 0x00041480 File Offset: 0x0003F680
		public bool NotIn(T left, string right)
		{
			return !(from element in right.Split(new char[]
			{
				','
			})
			select (T)((object)Convert.ChangeType(element.Trim(), typeof(T), CultureInfo.InvariantCulture))).ToList<T>().Contains(left);
		}

		// Token: 0x060011A0 RID: 4512 RVA: 0x000414D0 File Offset: 0x0003F6D0
		public bool StartsWith(T left, string right, string contextJson)
		{
			JObject jobject = JsonConvert.DeserializeObject(contextJson, Utils.GetSerializerSettings()) as JObject;
			int comparisonType = 3;
			if (jobject != null && jobject.ContainsKey("stringComparison") && !string.IsNullOrEmpty(jobject["stringComparison"].Value<string>()))
			{
				comparisonType = int.Parse(jobject["stringComparison"].Value<string>(), CultureInfo.InvariantCulture);
			}
			return left.ToString().StartsWith(right, (StringComparison)comparisonType);
		}
	}
}
