﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common.Grm.Comparers
{
	// Token: 0x0200024A RID: 586
	internal class StringListComparer : IGrmOperatorComparer<List<string>>
	{
		// Token: 0x060011B6 RID: 4534 RVA: 0x000416D8 File Offset: 0x0003F8D8
		public bool Contains(List<string> left, string right)
		{
			using (List<string>.Enumerator enumerator = left.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.Contains(right, StringComparison.InvariantCultureIgnoreCase))
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x060011B7 RID: 4535 RVA: 0x00041730 File Offset: 0x0003F930
		public bool Equal(List<string> left, string right)
		{
			using (List<string>.Enumerator enumerator = left.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.Equals(right, StringComparison.InvariantCultureIgnoreCase))
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x060011B8 RID: 4536 RVA: 0x0000E65F File Offset: 0x0000C85F
		public bool GreaterThan(List<string> left, string right)
		{
			throw new ArgumentException("Operator GreaterThan is not supported with list of string expression");
		}

		// Token: 0x060011B9 RID: 4537 RVA: 0x0000E66B File Offset: 0x0000C86B
		public bool GreaterThanEqual(List<string> left, string right)
		{
			throw new ArgumentException("Operator GreaterThanEqual is not supported with list of string expression");
		}

		// Token: 0x060011BA RID: 4538 RVA: 0x00041788 File Offset: 0x0003F988
		public bool In(List<string> left, string right)
		{
			return (from _ in right.Split(new char[]
			{
				','
			})
			select _.Trim()).ToList<string>().Intersect(left).Any<string>();
		}

		// Token: 0x060011BB RID: 4539 RVA: 0x0000E677 File Offset: 0x0000C877
		public bool LessThan(List<string> left, string right)
		{
			throw new ArgumentException("Operator LessThan is not supported with list of string expression");
		}

		// Token: 0x060011BC RID: 4540 RVA: 0x0000E683 File Offset: 0x0000C883
		public bool LessThanEqual(List<string> left, string right)
		{
			throw new ArgumentException("Operator LessThanEqual is not supported with list of string expression");
		}

		// Token: 0x060011BD RID: 4541 RVA: 0x000417DC File Offset: 0x0003F9DC
		public bool LikeRegex(List<string> left, string right, string contextJson)
		{
			JObject jobject = JsonConvert.DeserializeObject(contextJson, Utils.GetSerializerSettings()) as JObject;
			int options = 1;
			if (jobject != null && jobject.ContainsKey("regexOptions") && !string.IsNullOrEmpty(jobject["regexOptions"].Value<string>()))
			{
				options = int.Parse(jobject["regexOptions"].Value<string>(), CultureInfo.InvariantCulture);
			}
			Regex regex = new Regex(right, (RegexOptions)options);
			foreach (string input in left)
			{
				if (regex.IsMatch(input))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x060011BE RID: 4542 RVA: 0x00041894 File Offset: 0x0003FA94
		public bool NotEqual(List<string> left, string right)
		{
			using (List<string>.Enumerator enumerator = left.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.Equals(right, StringComparison.InvariantCultureIgnoreCase))
					{
						return false;
					}
				}
			}
			return true;
		}

		// Token: 0x060011BF RID: 4543 RVA: 0x000418EC File Offset: 0x0003FAEC
		public bool NotIn(List<string> left, string right)
		{
			return !(from _ in right.Split(new char[]
			{
				','
			})
			select _.Trim()).ToList<string>().Intersect(left).Any<string>();
		}

		// Token: 0x060011C0 RID: 4544 RVA: 0x00041944 File Offset: 0x0003FB44
		public bool StartsWith(List<string> left, string right, string contextJson)
		{
			JObject jobject = JsonConvert.DeserializeObject(contextJson, Utils.GetSerializerSettings()) as JObject;
			int comparisonType = 3;
			if (jobject != null && jobject.ContainsKey("stringComparison") && !string.IsNullOrEmpty(jobject["stringComparison"].Value<string>()))
			{
				comparisonType = int.Parse(jobject["stringComparison"].Value<string>(), CultureInfo.InvariantCulture);
			}
			using (List<string>.Enumerator enumerator = left.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.StartsWith(right, (StringComparison)comparisonType))
					{
						return true;
					}
				}
			}
			return false;
		}
	}
}
