﻿using System;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common.Grm.Comparers
{
	// Token: 0x02000248 RID: 584
	internal class GrmStringComparer : IGrmOperatorComparer<string>
	{
		// Token: 0x060011A6 RID: 4518 RVA: 0x0000E5FF File Offset: 0x0000C7FF
		public bool Contains(string left, string right)
		{
			return left.Contains(right, StringComparison.InvariantCultureIgnoreCase);
		}

		// Token: 0x060011A7 RID: 4519 RVA: 0x0000E609 File Offset: 0x0000C809
		public bool Equal(string left, string right)
		{
			return left == right;
		}

		// Token: 0x060011A8 RID: 4520 RVA: 0x0000E612 File Offset: 0x0000C812
		public bool GreaterThan(string left, string right)
		{
			throw new ArgumentException("Operator GreaterThan is not supported with string expression");
		}

		// Token: 0x060011A9 RID: 4521 RVA: 0x0000E61E File Offset: 0x0000C81E
		public bool GreaterThanEqual(string left, string right)
		{
			throw new ArgumentException("Operator GreaterThanEqual is not supported with string expression");
		}

		// Token: 0x060011AA RID: 4522 RVA: 0x00041548 File Offset: 0x0003F748
		public bool In(string left, string right)
		{
			return (from _ in right.Split(new char[]
			{
				','
			})
			select _.Trim()).ToList<string>().Contains(left.Trim(), StringComparer.InvariantCultureIgnoreCase);
		}

		// Token: 0x060011AB RID: 4523 RVA: 0x0000E62A File Offset: 0x0000C82A
		public bool LessThan(string left, string right)
		{
			throw new ArgumentException("Operator LessThan is not supported with string expression");
		}

		// Token: 0x060011AC RID: 4524 RVA: 0x0000E636 File Offset: 0x0000C836
		public bool LessThanEqual(string left, string right)
		{
			throw new ArgumentException("Operator LessThanEqual is not supported with string expression");
		}

		// Token: 0x060011AD RID: 4525 RVA: 0x000415A0 File Offset: 0x0003F7A0
		public bool LikeRegex(string left, string right, string contextJson)
		{
			JObject jobject = JsonConvert.DeserializeObject(contextJson, Utils.GetSerializerSettings()) as JObject;
			int options = 1;
			if (jobject != null && jobject.ContainsKey("regexOptions") && !string.IsNullOrEmpty(jobject["regexOptions"].Value<string>()))
			{
				options = int.Parse(jobject["regexOptions"].Value<string>(), CultureInfo.InvariantCulture);
			}
			return new Regex(right, (RegexOptions)options).IsMatch(left);
		}

		// Token: 0x060011AE RID: 4526 RVA: 0x0000E642 File Offset: 0x0000C842
		public bool NotEqual(string left, string right)
		{
			return left != right;
		}

		// Token: 0x060011AF RID: 4527 RVA: 0x00041610 File Offset: 0x0003F810
		public bool NotIn(string left, string right)
		{
			return !(from _ in right.Split(new char[]
			{
				','
			})
			select _.Trim()).ToList<string>().Contains(left.Trim(), StringComparer.InvariantCultureIgnoreCase);
		}

		// Token: 0x060011B0 RID: 4528 RVA: 0x0004166C File Offset: 0x0003F86C
		public bool StartsWith(string left, string right, string contextJson)
		{
			JObject jobject = JsonConvert.DeserializeObject(contextJson, Utils.GetSerializerSettings()) as JObject;
			int comparisonType = 3;
			if (jobject != null && jobject.ContainsKey("stringComparison") && !string.IsNullOrEmpty(jobject["stringComparison"].Value<string>()))
			{
				comparisonType = int.Parse(jobject["stringComparison"].Value<string>(), CultureInfo.InvariantCulture);
			}
			return left.StartsWith(right, (StringComparison)comparisonType);
		}
	}
}
