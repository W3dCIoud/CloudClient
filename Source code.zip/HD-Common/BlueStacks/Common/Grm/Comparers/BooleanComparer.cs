﻿using System;
using System.Globalization;

namespace BlueStacks.Common.Grm.Comparers
{
	// Token: 0x02000245 RID: 581
	internal class BooleanComparer : IGrmOperatorComparer<bool>
	{
		// Token: 0x0600118A RID: 4490 RVA: 0x0000E547 File Offset: 0x0000C747
		public bool Contains(bool left, string right)
		{
			return left.ToString(CultureInfo.InvariantCulture).Contains(right, StringComparison.InvariantCultureIgnoreCase);
		}

		// Token: 0x0600118B RID: 4491 RVA: 0x00041218 File Offset: 0x0003F418
		public bool Equal(bool left, string right)
		{
			bool flag = Convert.ToBoolean(right, CultureInfo.InvariantCulture);
			return left == flag;
		}

		// Token: 0x0600118C RID: 4492 RVA: 0x0000E55C File Offset: 0x0000C75C
		public bool GreaterThan(bool left, string right)
		{
			throw new ArgumentException("Operator GreaterThan is not supported with boolean expression");
		}

		// Token: 0x0600118D RID: 4493 RVA: 0x0000E568 File Offset: 0x0000C768
		public bool GreaterThanEqual(bool left, string right)
		{
			throw new ArgumentException("Operator GreaterThanEqual is not supported with boolean expression");
		}

		// Token: 0x0600118E RID: 4494 RVA: 0x0000E574 File Offset: 0x0000C774
		public bool In(bool left, string right)
		{
			throw new ArgumentException("Operator In is not supported with boolean expression");
		}

		// Token: 0x0600118F RID: 4495 RVA: 0x0000E580 File Offset: 0x0000C780
		public bool LessThan(bool left, string right)
		{
			throw new ArgumentException("Operator LessThan is not supported with boolean expression");
		}

		// Token: 0x06001190 RID: 4496 RVA: 0x0000E58C File Offset: 0x0000C78C
		public bool LessThanEqual(bool left, string right)
		{
			throw new ArgumentException("Operator LessThanEqual is not supported with boolean expression");
		}

		// Token: 0x06001191 RID: 4497 RVA: 0x0000E598 File Offset: 0x0000C798
		public bool LikeRegex(bool left, string right, string contextJson)
		{
			throw new ArgumentException("Operator LikeRegex is not supported with boolean expression");
		}

		// Token: 0x06001192 RID: 4498 RVA: 0x00041238 File Offset: 0x0003F438
		public bool NotEqual(bool left, string right)
		{
			bool flag = Convert.ToBoolean(right, CultureInfo.InvariantCulture);
			return left != flag;
		}

		// Token: 0x06001193 RID: 4499 RVA: 0x0000E5A4 File Offset: 0x0000C7A4
		public bool NotIn(bool left, string right)
		{
			throw new ArgumentException("Operator notin is not supported with boolean expression");
		}

		// Token: 0x06001194 RID: 4500 RVA: 0x0000E5B0 File Offset: 0x0000C7B0
		public bool StartsWith(bool left, string right, string contextJson)
		{
			throw new ArgumentException("Operator StartsWith is not supported with boolean expression");
		}
	}
}
