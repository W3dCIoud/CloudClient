﻿using System;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common.Grm.Comparers
{
	// Token: 0x0200024C RID: 588
	internal class VersionComparer : IGrmOperatorComparer<Version>
	{
		// Token: 0x060011C6 RID: 4550 RVA: 0x0000E69B File Offset: 0x0000C89B
		public bool Contains(Version left, string right)
		{
			return left.ToString().Contains(right, StringComparison.InvariantCultureIgnoreCase);
		}

		// Token: 0x060011C7 RID: 4551 RVA: 0x000419F0 File Offset: 0x0003FBF0
		public bool Equal(Version left, string right)
		{
			Version v = new Version(right);
			return left == v;
		}

		// Token: 0x060011C8 RID: 4552 RVA: 0x00041A0C File Offset: 0x0003FC0C
		public bool GreaterThan(Version left, string right)
		{
			Version v = new Version(right);
			return left > v;
		}

		// Token: 0x060011C9 RID: 4553 RVA: 0x00041A28 File Offset: 0x0003FC28
		public bool GreaterThanEqual(Version left, string right)
		{
			Version v = new Version(right);
			return left >= v;
		}

		// Token: 0x060011CA RID: 4554 RVA: 0x00041A44 File Offset: 0x0003FC44
		public bool In(Version left, string right)
		{
			return (from _ in right.Split(new char[]
			{
				','
			})
			select new Version(_.Trim())).ToList<Version>().Contains(left);
		}

		// Token: 0x060011CB RID: 4555 RVA: 0x00041A94 File Offset: 0x0003FC94
		public bool LessThan(Version left, string right)
		{
			Version v = new Version(right);
			return left < v;
		}

		// Token: 0x060011CC RID: 4556 RVA: 0x00041AB0 File Offset: 0x0003FCB0
		public bool LessThanEqual(Version left, string right)
		{
			Version v = new Version(right);
			return left <= v;
		}

		// Token: 0x060011CD RID: 4557 RVA: 0x00041ACC File Offset: 0x0003FCCC
		public bool LikeRegex(Version left, string right, string contextJson)
		{
			JObject jobject = JsonConvert.DeserializeObject(contextJson, Utils.GetSerializerSettings()) as JObject;
			int options = 1;
			if (jobject != null && jobject.ContainsKey("regexOptions") && !string.IsNullOrEmpty(jobject["regexOptions"].Value<string>()))
			{
				options = int.Parse(jobject["regexOptions"].Value<string>(), CultureInfo.InvariantCulture);
			}
			return new Regex(right, (RegexOptions)options).IsMatch(left.ToString());
		}

		// Token: 0x060011CE RID: 4558 RVA: 0x00041B40 File Offset: 0x0003FD40
		public bool NotEqual(Version left, string right)
		{
			Version v = new Version(right);
			return left != v;
		}

		// Token: 0x060011CF RID: 4559 RVA: 0x00041B5C File Offset: 0x0003FD5C
		public bool NotIn(Version left, string right)
		{
			return !(from _ in right.Split(new char[]
			{
				','
			})
			select new Version(_.Trim())).ToList<Version>().Contains(left);
		}

		// Token: 0x060011D0 RID: 4560 RVA: 0x00041BAC File Offset: 0x0003FDAC
		public bool StartsWith(Version left, string right, string contextJson)
		{
			JObject jobject = JsonConvert.DeserializeObject(contextJson, Utils.GetSerializerSettings()) as JObject;
			int comparisonType = 3;
			if (jobject != null && jobject.ContainsKey("stringComparison") && !string.IsNullOrEmpty(jobject["stringComparison"].Value<string>()))
			{
				comparisonType = int.Parse(jobject["stringComparison"].Value<string>(), CultureInfo.InvariantCulture);
			}
			return left.ToString().StartsWith(right, (StringComparison)comparisonType);
		}
	}
}
