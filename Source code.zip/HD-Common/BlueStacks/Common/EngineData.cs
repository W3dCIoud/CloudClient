﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200007E RID: 126
	public class EngineData
	{
		// Token: 0x170000DC RID: 220
		// (get) Token: 0x06000310 RID: 784 RVA: 0x00003A8A File Offset: 0x00001C8A
		// (set) Token: 0x06000311 RID: 785 RVA: 0x00003A92 File Offset: 0x00001C92
		public GraphicsMode GraphicsMode { get; set; }

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x06000312 RID: 786 RVA: 0x00003A9B File Offset: 0x00001C9B
		// (set) Token: 0x06000313 RID: 787 RVA: 0x00003AA3 File Offset: 0x00001CA3
		public bool UseAdvancedGraphicEngine { get; set; }

		// Token: 0x170000DE RID: 222
		// (get) Token: 0x06000314 RID: 788 RVA: 0x00003AAC File Offset: 0x00001CAC
		// (set) Token: 0x06000315 RID: 789 RVA: 0x00003AB4 File Offset: 0x00001CB4
		public bool UseDedicatedGPU { get; set; }

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x06000316 RID: 790 RVA: 0x00003ABD File Offset: 0x00001CBD
		// (set) Token: 0x06000317 RID: 791 RVA: 0x00003AC5 File Offset: 0x00001CC5
		public ASTCOption ASTCOption { get; set; }

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x06000318 RID: 792 RVA: 0x00003ACE File Offset: 0x00001CCE
		// (set) Token: 0x06000319 RID: 793 RVA: 0x00003AD6 File Offset: 0x00001CD6
		public int Ram { get; set; }

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x0600031A RID: 794 RVA: 0x00003ADF File Offset: 0x00001CDF
		// (set) Token: 0x0600031B RID: 795 RVA: 0x00003AE7 File Offset: 0x00001CE7
		public int CpuCores { get; set; }

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x0600031C RID: 796 RVA: 0x00003AF0 File Offset: 0x00001CF0
		// (set) Token: 0x0600031D RID: 797 RVA: 0x00003AF8 File Offset: 0x00001CF8
		public int FrameRate { get; set; }

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x0600031E RID: 798 RVA: 0x00003B01 File Offset: 0x00001D01
		// (set) Token: 0x0600031F RID: 799 RVA: 0x00003B09 File Offset: 0x00001D09
		public bool EnableHighFrameRates { get; set; }

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x06000320 RID: 800 RVA: 0x00003B12 File Offset: 0x00001D12
		// (set) Token: 0x06000321 RID: 801 RVA: 0x00003B1A File Offset: 0x00001D1A
		public bool DisplayFPS { get; set; }

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x06000322 RID: 802 RVA: 0x00003B23 File Offset: 0x00001D23
		// (set) Token: 0x06000323 RID: 803 RVA: 0x00003B2B File Offset: 0x00001D2B
		public ABISetting ABISetting { get; set; }
	}
}
