﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200010A RID: 266
	public enum ButtonStates
	{
		// Token: 0x0400049B RID: 1179
		MouseIn,
		// Token: 0x0400049C RID: 1180
		MouseOut,
		// Token: 0x0400049D RID: 1181
		MouseDown
	}
}
