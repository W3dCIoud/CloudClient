﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x020000E2 RID: 226
	public class CustomCheckbox : CheckBox, IComponentConnector, IStyleConnector
	{
		// Token: 0x17000188 RID: 392
		// (get) Token: 0x0600060D RID: 1549 RVA: 0x0000590C File Offset: 0x00003B0C
		// (set) Token: 0x0600060E RID: 1550 RVA: 0x00020B34 File Offset: 0x0001ED34
		public string Group
		{
			get
			{
				return this.mGroup;
			}
			set
			{
				this.mGroup = value;
				if (base.IsThreeState)
				{
					CustomCheckbox.dictInterminentTags[this.mGroup] = new Tuple<CustomCheckbox, List<CustomCheckbox>, List<CustomCheckbox>>(this, new List<CustomCheckbox>(), new List<CustomCheckbox>());
					return;
				}
				CustomCheckbox.dictInterminentTags[this.Group].Item3.Add(this);
			}
		}

		// Token: 0x0600060F RID: 1551 RVA: 0x00020B8C File Offset: 0x0001ED8C
		public void SetInterminate()
		{
			if (base.IsChecked != null)
			{
				this._mSetInterminate = true;
				base.IsChecked = null;
			}
		}

		// Token: 0x17000189 RID: 393
		// (get) Token: 0x06000610 RID: 1552 RVA: 0x00005914 File Offset: 0x00003B14
		public Image Image
		{
			get
			{
				if (this.mImage == null)
				{
					this.mImage = (Image)base.Template.FindName("mImage", this);
				}
				return this.mImage;
			}
		}

		// Token: 0x1700018A RID: 394
		// (get) Token: 0x06000611 RID: 1553 RVA: 0x00005940 File Offset: 0x00003B40
		public ColumnDefinition colDefMargin
		{
			get
			{
				return (ColumnDefinition)base.Template.FindName("colDefMargin", this);
			}
		}

		// Token: 0x1700018B RID: 395
		// (get) Token: 0x06000612 RID: 1554 RVA: 0x00005958 File Offset: 0x00003B58
		public ColumnDefinition colDefHorizontalLabel
		{
			get
			{
				return (ColumnDefinition)base.Template.FindName("colDefHorizontalLabel", this);
			}
		}

		// Token: 0x1700018C RID: 396
		// (get) Token: 0x06000613 RID: 1555 RVA: 0x00005970 File Offset: 0x00003B70
		public TextBlock BottomLabel
		{
			get
			{
				return (TextBlock)base.Template.FindName("VerticalTextBlock", this);
			}
		}

		// Token: 0x1700018D RID: 397
		// (get) Token: 0x06000614 RID: 1556 RVA: 0x00005988 File Offset: 0x00003B88
		public TextBlock CheckboxText
		{
			get
			{
				return (TextBlock)base.Template.FindName("HorizontalTextBlock", this);
			}
		}

		// Token: 0x1700018E RID: 398
		// (set) Token: 0x06000615 RID: 1557 RVA: 0x000059A0 File Offset: 0x00003BA0
		public Orientation Orientation
		{
			set
			{
				this.mOrientaion = value;
			}
		}

		// Token: 0x1700018F RID: 399
		// (set) Token: 0x06000616 RID: 1558 RVA: 0x000059A9 File Offset: 0x00003BA9
		public Visibility LabelVisibility
		{
			set
			{
				this.mLabelVisibility = value;
			}
		}

		// Token: 0x06000617 RID: 1559 RVA: 0x000059B2 File Offset: 0x00003BB2
		public CustomCheckbox()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000618 RID: 1560 RVA: 0x00020BC0 File Offset: 0x0001EDC0
		private void CheckBox_MouseEnter(object sender, MouseEventArgs e)
		{
			if (base.IsChecked != null && !base.IsChecked.Value)
			{
				CustomPictureBox.SetBitmapImage(this.Image, "check_box_hover", false);
			}
		}

		// Token: 0x06000619 RID: 1561 RVA: 0x00020C00 File Offset: 0x0001EE00
		private void CheckBox_MouseLeave(object sender, MouseEventArgs e)
		{
			if (base.IsChecked == null)
			{
				CustomPictureBox.SetBitmapImage(this.Image, "check_box_Indeterminate", false);
				return;
			}
			if (base.IsChecked.Value)
			{
				CustomPictureBox.SetBitmapImage(this.Image, "check_box_checked", false);
				return;
			}
			CustomPictureBox.SetBitmapImage(this.Image, "check_box", false);
		}

		// Token: 0x0600061A RID: 1562 RVA: 0x00020C64 File Offset: 0x0001EE64
		private void CheckBox_Checked(object sender, RoutedEventArgs e)
		{
			if (!string.IsNullOrEmpty(this.mGroup))
			{
				if (base.IsThreeState)
				{
					if (CustomCheckbox.dictInterminentTags[this.mGroup].Item3.Count > 0)
					{
						CustomCheckbox[] array = CustomCheckbox.dictInterminentTags[this.mGroup].Item3.ToArray();
						for (int i = 0; i < array.Length; i++)
						{
							array[i].IsChecked = new bool?(true);
						}
					}
				}
				else
				{
					CustomCheckbox.dictInterminentTags[this.mGroup].Item2.Add(this);
					CustomCheckbox.dictInterminentTags[this.mGroup].Item3.Remove(this);
					if (CustomCheckbox.dictInterminentTags[this.mGroup].Item3.Count == 0)
					{
						CustomCheckbox.dictInterminentTags[this.mGroup].Item1.IsChecked = new bool?(true);
					}
					else
					{
						CustomCheckbox.dictInterminentTags[this.mGroup].Item1.SetInterminate();
					}
				}
			}
			if (this.Image != null)
			{
				CustomPictureBox.SetBitmapImage(this.Image, "check_box_checked", false);
			}
		}

		// Token: 0x0600061B RID: 1563 RVA: 0x000059CB File Offset: 0x00003BCB
		private void CheckBox_Indeterminate(object sender, RoutedEventArgs e)
		{
			if (!this._mSetInterminate)
			{
				base.IsChecked = new bool?(false);
				return;
			}
			this._mSetInterminate = false;
			if (this.Image != null)
			{
				CustomPictureBox.SetBitmapImage(this.Image, "check_box_Indeterminate", false);
			}
		}

		// Token: 0x0600061C RID: 1564 RVA: 0x00020D90 File Offset: 0x0001EF90
		private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
		{
			if (!string.IsNullOrEmpty(this.mGroup))
			{
				if (base.IsThreeState)
				{
					if (CustomCheckbox.dictInterminentTags[this.mGroup].Item2.Count > 0)
					{
						CustomCheckbox[] array = CustomCheckbox.dictInterminentTags[this.mGroup].Item2.ToArray();
						for (int i = 0; i < array.Length; i++)
						{
							array[i].IsChecked = new bool?(false);
						}
					}
				}
				else
				{
					CustomCheckbox.dictInterminentTags[this.mGroup].Item2.Remove(this);
					CustomCheckbox.dictInterminentTags[this.mGroup].Item3.Add(this);
					if (CustomCheckbox.dictInterminentTags[this.mGroup].Item2.Count == 0)
					{
						CustomCheckbox.dictInterminentTags[this.mGroup].Item1.IsChecked = new bool?(false);
					}
					else
					{
						CustomCheckbox.dictInterminentTags[this.mGroup].Item1.SetInterminate();
					}
				}
			}
			if (base.IsMouseOver)
			{
				if (this.Image != null)
				{
					CustomPictureBox.SetBitmapImage(this.Image, "check_box_hover", false);
					return;
				}
			}
			else if (this.Image != null)
			{
				CustomPictureBox.SetBitmapImage(this.Image, "check_box", false);
			}
		}

		// Token: 0x0600061D RID: 1565 RVA: 0x00020EDC File Offset: 0x0001F0DC
		private void CheckBox_Loaded(object sender, RoutedEventArgs e)
		{
			if (!DesignerProperties.GetIsInDesignMode(this))
			{
				if (this.mOrientaion == Orientation.Vertical)
				{
					Grid.SetRowSpan(this.Image, 1);
					this.colDefHorizontalLabel.Width = new GridLength(0.0);
					this.BottomLabel.Visibility = Visibility.Visible;
				}
				if (this.mLabelVisibility == Visibility.Hidden)
				{
					this.CheckboxText.Visibility = Visibility.Hidden;
					this.BottomLabel.Visibility = Visibility.Hidden;
				}
				if (this.Image != null)
				{
					if (base.IsChecked == null)
					{
						CustomPictureBox.SetBitmapImage(this.Image, "check_box__Indeterminate", false);
						return;
					}
					if (base.IsChecked != null && base.IsChecked.Value)
					{
						CustomPictureBox.SetBitmapImage(this.Image, "check_box_checked", false);
						return;
					}
					CustomPictureBox.SetBitmapImage(this.Image, "check_box", false);
				}
			}
		}

		// Token: 0x17000190 RID: 400
		// (get) Token: 0x0600061E RID: 1566 RVA: 0x00005A02 File Offset: 0x00003C02
		// (set) Token: 0x0600061F RID: 1567 RVA: 0x00005A14 File Offset: 0x00003C14
		public Thickness ImageMargin
		{
			get
			{
				return (Thickness)base.GetValue(CustomCheckbox.ImageMarginProperty);
			}
			set
			{
				base.SetValue(CustomCheckbox.ImageMarginProperty, value);
			}
		}

		// Token: 0x17000191 RID: 401
		// (get) Token: 0x06000620 RID: 1568 RVA: 0x00005A27 File Offset: 0x00003C27
		// (set) Token: 0x06000621 RID: 1569 RVA: 0x00005A39 File Offset: 0x00003C39
		public double TextFontSize
		{
			get
			{
				return (double)base.GetValue(CustomCheckbox.TextFontSizeProperty);
			}
			set
			{
				base.SetValue(CustomCheckbox.TextFontSizeProperty, value);
			}
		}

		// Token: 0x06000622 RID: 1570 RVA: 0x00020FBC File Offset: 0x0001F1BC
		private void CheckBoxText_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			ContentPresenter contentPresenter = WpfUtils.FindVisualChild<ContentPresenter>(this);
			if (contentPresenter != null)
			{
				TextBlock textBlock = contentPresenter.ContentTemplate.FindName("HorizontalTextBlock", contentPresenter) as TextBlock;
				if (textBlock != null && textBlock.IsTextTrimmed())
				{
					ToolTipService.SetIsEnabled(this, true);
					return;
				}
				ToolTipService.SetIsEnabled(this, false);
			}
		}

		// Token: 0x06000623 RID: 1571 RVA: 0x00021004 File Offset: 0x0001F204
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/customcheckbox.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000624 RID: 1572 RVA: 0x00021034 File Offset: 0x0001F234
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				((CustomCheckbox)target).MouseEnter += this.CheckBox_MouseEnter;
				((CustomCheckbox)target).MouseLeave += this.CheckBox_MouseLeave;
				((CustomCheckbox)target).Checked += this.CheckBox_Checked;
				((CustomCheckbox)target).Unchecked += this.CheckBox_Unchecked;
				((CustomCheckbox)target).Indeterminate += this.CheckBox_Indeterminate;
				((CustomCheckbox)target).Loaded += this.CheckBox_Loaded;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x06000625 RID: 1573 RVA: 0x00005A4C File Offset: 0x00003C4C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 2)
			{
				((TextBlock)target).SizeChanged += this.CheckBoxText_SizeChanged;
			}
		}

		// Token: 0x04000346 RID: 838
		public static readonly Dictionary<string, Tuple<CustomCheckbox, List<CustomCheckbox>, List<CustomCheckbox>>> dictInterminentTags = new Dictionary<string, Tuple<CustomCheckbox, List<CustomCheckbox>, List<CustomCheckbox>>>();

		// Token: 0x04000347 RID: 839
		private string mGroup = string.Empty;

		// Token: 0x04000348 RID: 840
		private bool _mSetInterminate;

		// Token: 0x04000349 RID: 841
		private Image mImage;

		// Token: 0x0400034A RID: 842
		private Orientation mOrientaion;

		// Token: 0x0400034B RID: 843
		private Visibility mLabelVisibility;

		// Token: 0x0400034C RID: 844
		public static readonly DependencyProperty ImageMarginProperty = DependencyProperty.Register("ImageMargin", typeof(Thickness), typeof(CustomCheckbox), new PropertyMetadata(new Thickness(0.0)));

		// Token: 0x0400034D RID: 845
		public static readonly DependencyProperty TextFontSizeProperty = DependencyProperty.Register("TextFontSize", typeof(double), typeof(CustomCheckbox), new PropertyMetadata(16.0));

		// Token: 0x0400034E RID: 846
		private bool _contentLoaded;
	}
}
