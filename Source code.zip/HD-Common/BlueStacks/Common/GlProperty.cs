﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001A9 RID: 425
	public class GlProperty
	{
		// Token: 0x170003DB RID: 987
		// (get) Token: 0x06000E39 RID: 3641 RVA: 0x0000CC53 File Offset: 0x0000AE53
		// (set) Token: 0x06000E3A RID: 3642 RVA: 0x0000CC5B File Offset: 0x0000AE5B
		public GLMode Gl_mode { get; set; }

		// Token: 0x170003DC RID: 988
		// (get) Token: 0x06000E3B RID: 3643 RVA: 0x0000CC64 File Offset: 0x0000AE64
		// (set) Token: 0x06000E3C RID: 3644 RVA: 0x0000CC6C File Offset: 0x0000AE6C
		public GLRenderer Gl_renderer { get; set; }
	}
}
