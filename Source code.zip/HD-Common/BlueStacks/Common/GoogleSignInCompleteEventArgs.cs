﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000069 RID: 105
	public class GoogleSignInCompleteEventArgs : BrowserEventArgs
	{
		// Token: 0x06000238 RID: 568 RVA: 0x000032A4 File Offset: 0x000014A4
		public GoogleSignInCompleteEventArgs(BrowserControlTags tag, string packageName, string vmName) : base(tag, packageName, vmName)
		{
		}
	}
}
