﻿using System;
using System.Drawing;

namespace BlueStacks.Common
{
	// Token: 0x020001EF RID: 495
	public struct COMPOSITIONFORM
	{
		// Token: 0x17000411 RID: 1041
		// (get) Token: 0x06000F70 RID: 3952 RVA: 0x0000D7E5 File Offset: 0x0000B9E5
		// (set) Token: 0x06000F71 RID: 3953 RVA: 0x0000D7ED File Offset: 0x0000B9ED
		public int dwStyle { readonly get; set; }

		// Token: 0x17000412 RID: 1042
		// (get) Token: 0x06000F72 RID: 3954 RVA: 0x0000D7F6 File Offset: 0x0000B9F6
		// (set) Token: 0x06000F73 RID: 3955 RVA: 0x0000D7FE File Offset: 0x0000B9FE
		public Point ptCurrentPos { readonly get; set; }

		// Token: 0x17000413 RID: 1043
		// (get) Token: 0x06000F74 RID: 3956 RVA: 0x0000D807 File Offset: 0x0000BA07
		// (set) Token: 0x06000F75 RID: 3957 RVA: 0x0000D80F File Offset: 0x0000BA0F
		public RECT rcArea { readonly get; set; }
	}
}
