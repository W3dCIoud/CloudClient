﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200011C RID: 284
	public enum ASTCOption
	{
		// Token: 0x0400050C RID: 1292
		Disabled,
		// Token: 0x0400050D RID: 1293
		SoftwareDecoding,
		// Token: 0x0400050E RID: 1294
		SoftwareDecodingCache,
		// Token: 0x0400050F RID: 1295
		HardwareDecoding
	}
}
