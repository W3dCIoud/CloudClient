﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Markup;
using System.Windows.Media;

namespace BlueStacks.Common
{
	// Token: 0x020000CF RID: 207
	public class BrushToColorConvertor : MarkupExtension, IValueConverter
	{
		// Token: 0x0600056E RID: 1390 RVA: 0x00005482 File Offset: 0x00003682
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return BrushToColorConvertor.Convert(value, targetType);
		}

		// Token: 0x0600056F RID: 1391 RVA: 0x00005482 File Offset: 0x00003682
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return BrushToColorConvertor.Convert(value, targetType);
		}

		// Token: 0x06000570 RID: 1392 RVA: 0x0000548B File Offset: 0x0000368B
		public static object Convert(object value, Type targetType)
		{
			if (typeof(SolidColorBrush).IsSubclassOf(targetType))
			{
				return value;
			}
			if (value != null)
			{
				return (value as SolidColorBrush).Color;
			}
			return value;
		}

		// Token: 0x06000571 RID: 1393 RVA: 0x000054B6 File Offset: 0x000036B6
		public override object ProvideValue(IServiceProvider serviceProvider)
		{
			return this;
		}
	}
}
