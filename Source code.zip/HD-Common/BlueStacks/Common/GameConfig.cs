﻿using System;
using System.IO;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x020000A0 RID: 160
	public class GameConfig
	{
		// Token: 0x170000FC RID: 252
		// (get) Token: 0x060003D1 RID: 977 RVA: 0x00016194 File Offset: 0x00014394
		public static GameConfig Instance
		{
			get
			{
				if (GameConfig.sInstance == null)
				{
					object obj = GameConfig.syncRoot;
					lock (obj)
					{
						GameConfig.sInstance = new GameConfig();
						GameConfig.Init();
					}
				}
				return GameConfig.sInstance;
			}
		}

		// Token: 0x060003D2 RID: 978 RVA: 0x000161E8 File Offset: 0x000143E8
		private static void Init()
		{
			GameConfig.sFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "game_config.json");
			if (File.Exists(GameConfig.sFilePath))
			{
				Logger.Info("Loading cfg from : " + GameConfig.sFilePath);
				GameConfig.LoadFile(GameConfig.sFilePath);
			}
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x00016238 File Offset: 0x00014438
		private static void LoadFile(string sFilePath)
		{
			try
			{
				JObject obj = JObject.Parse(File.ReadAllText(sFilePath));
				GameConfig.Instance.AppName = GameConfig.GetJsonStringValue(obj, "app_name");
				GameConfig.Instance.PkgName = GameConfig.GetJsonStringValue(obj, "pkg_name");
				GameConfig.Instance.ActivityName = GameConfig.GetJsonStringValue(obj, "activity_name");
				GameConfig.Instance.ControlPanelEntryName = GameConfig.GetJsonStringValue(obj, "control_panel_name");
				GameConfig.Instance.ControlPanelPublisher = GameConfig.GetJsonStringValue(obj, "control_panel_publisher");
				GameConfig.Instance.InstallerCopyrightText = GameConfig.GetJsonStringValue(obj, "installer_copyright");
				GameConfig.Instance.AppGenericAction = (GenericAction)Enum.Parse(typeof(GenericAction), GameConfig.GetJsonStringValue(obj, "app_generic_action"));
				GameConfig.Instance.AppCDNURL = GameConfig.GetJsonStringValue(obj, "app_cdn_url");
			}
			catch (Exception ex)
			{
				Logger.Error("Some error while parsing config, maybe an invalid file. Ex: {0}", new object[]
				{
					ex.Message
				});
			}
		}

		// Token: 0x060003D4 RID: 980 RVA: 0x0001633C File Offset: 0x0001453C
		private static string GetJsonStringValue(JObject obj, string keyName)
		{
			string empty = string.Empty;
			if (obj.ContainsKey(keyName))
			{
				return obj[keyName].ToString().Trim();
			}
			return empty;
		}

		// Token: 0x170000FD RID: 253
		// (get) Token: 0x060003D5 RID: 981 RVA: 0x00004288 File Offset: 0x00002488
		// (set) Token: 0x060003D6 RID: 982 RVA: 0x00004290 File Offset: 0x00002490
		public string ControlPanelEntryName { get; private set; } = string.Empty;

		// Token: 0x170000FE RID: 254
		// (get) Token: 0x060003D7 RID: 983 RVA: 0x00004299 File Offset: 0x00002499
		// (set) Token: 0x060003D8 RID: 984 RVA: 0x000042A1 File Offset: 0x000024A1
		public string ControlPanelPublisher { get; private set; } = string.Empty;

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x060003D9 RID: 985 RVA: 0x000042AA File Offset: 0x000024AA
		// (set) Token: 0x060003DA RID: 986 RVA: 0x000042B2 File Offset: 0x000024B2
		public string InstallerCopyrightText { get; private set; } = string.Empty;

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x060003DB RID: 987 RVA: 0x000042BB File Offset: 0x000024BB
		// (set) Token: 0x060003DC RID: 988 RVA: 0x000042C3 File Offset: 0x000024C3
		public string AppName { get; private set; } = string.Empty;

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x060003DD RID: 989 RVA: 0x000042CC File Offset: 0x000024CC
		// (set) Token: 0x060003DE RID: 990 RVA: 0x000042D4 File Offset: 0x000024D4
		public string PkgName { get; private set; } = string.Empty;

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x060003DF RID: 991 RVA: 0x000042DD File Offset: 0x000024DD
		// (set) Token: 0x060003E0 RID: 992 RVA: 0x000042E5 File Offset: 0x000024E5
		public string ActivityName { get; private set; } = string.Empty;

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x060003E1 RID: 993 RVA: 0x000042EE File Offset: 0x000024EE
		// (set) Token: 0x060003E2 RID: 994 RVA: 0x000042F6 File Offset: 0x000024F6
		public GenericAction AppGenericAction { get; private set; } = GenericAction.InstallPlay;

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x060003E3 RID: 995 RVA: 0x000042FF File Offset: 0x000024FF
		// (set) Token: 0x060003E4 RID: 996 RVA: 0x00004307 File Offset: 0x00002507
		public string AppCDNURL { get; private set; } = string.Empty;

		// Token: 0x040001BB RID: 443
		public const string sConfigFilename = "game_config.json";

		// Token: 0x040001BC RID: 444
		private static string sFilePath = string.Empty;

		// Token: 0x040001BD RID: 445
		private static volatile GameConfig sInstance;

		// Token: 0x040001BE RID: 446
		private static object syncRoot = new object();
	}
}
