﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000106 RID: 262
	public enum GamePadEventType
	{
		// Token: 0x0400047A RID: 1146
		TYPE_GAMEPAD_ATTACH,
		// Token: 0x0400047B RID: 1147
		TYPE_GAMEPAD_DETACH,
		// Token: 0x0400047C RID: 1148
		TYPE_GAMEPAD_UPDATE
	}
}
