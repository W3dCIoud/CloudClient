﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x020000D0 RID: 208
	public class CornerRadiusToThicknessConvertor : MarkupExtension, IValueConverter
	{
		// Token: 0x06000573 RID: 1395 RVA: 0x000054C1 File Offset: 0x000036C1
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return CornerRadiusToThicknessConvertor.Convert(value, targetType);
		}

		// Token: 0x06000574 RID: 1396 RVA: 0x000054C1 File Offset: 0x000036C1
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return CornerRadiusToThicknessConvertor.Convert(value, targetType);
		}

		// Token: 0x06000575 RID: 1397 RVA: 0x0001D6C4 File Offset: 0x0001B8C4
		public static object Convert(object value, Type targetType)
		{
			if (typeof(Thickness).Equals(targetType))
			{
				CornerRadius cornerRadius = (CornerRadius)value;
				return new Thickness(cornerRadius.TopLeft, cornerRadius.TopRight, cornerRadius.BottomRight, cornerRadius.BottomLeft);
			}
			return value;
		}

		// Token: 0x06000576 RID: 1398 RVA: 0x000054B6 File Offset: 0x000036B6
		public override object ProvideValue(IServiceProvider serviceProvider)
		{
			return this;
		}
	}
}
