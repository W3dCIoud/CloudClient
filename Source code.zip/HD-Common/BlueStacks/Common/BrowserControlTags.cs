﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000125 RID: 293
	public enum BrowserControlTags
	{
		// Token: 0x04000545 RID: 1349
		bootComplete,
		// Token: 0x04000546 RID: 1350
		googleSigninComplete,
		// Token: 0x04000547 RID: 1351
		appPlayerClosing,
		// Token: 0x04000548 RID: 1352
		tabClosing,
		// Token: 0x04000549 RID: 1353
		tabSwitched,
		// Token: 0x0400054A RID: 1354
		appInstalled,
		// Token: 0x0400054B RID: 1355
		appUninstalled
	}
}
