﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using Microsoft.VisualBasic.Devices;

namespace BlueStacks.Common
{
	// Token: 0x0200007C RID: 124
	public abstract class EngineSettingBaseViewModel : ViewModelBase
	{
		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x06000298 RID: 664 RVA: 0x00003618 File Offset: 0x00001818
		// (set) Token: 0x06000299 RID: 665 RVA: 0x00003620 File Offset: 0x00001820
		public int MinRam
		{
			get
			{
				return this._MinRam;
			}
			set
			{
				base.SetProperty<int>(ref this._MinRam, value, null);
			}
		}

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x0600029A RID: 666 RVA: 0x00003631 File Offset: 0x00001831
		// (set) Token: 0x0600029B RID: 667 RVA: 0x00003620 File Offset: 0x00001820
		public int MaxRam
		{
			get
			{
				return this._MaxRam;
			}
			set
			{
				base.SetProperty<int>(ref this._MinRam, value, null);
			}
		}

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x0600029C RID: 668 RVA: 0x00012DC0 File Offset: 0x00010FC0
		public static int UserMachineRAM
		{
			get
			{
				if (EngineSettingBaseViewModel._RamInMB == null)
				{
					try
					{
						ulong totalPhysicalMemory = new ComputerInfo().TotalPhysicalMemory;
						EngineSettingBaseViewModel._RamInMB = new int?((int)(totalPhysicalMemory / 1048576UL));
					}
					catch (Exception ex)
					{
						Logger.Error("Exception when finding ram " + ex.ToString());
					}
				}
				return EngineSettingBaseViewModel._RamInMB.GetValueOrDefault();
			}
		}

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x0600029D RID: 669 RVA: 0x00003639 File Offset: 0x00001839
		// (set) Token: 0x0600029E RID: 670 RVA: 0x00003641 File Offset: 0x00001841
		public int UserMachineCpuCores
		{
			get
			{
				return this._UserMachineCpuCores;
			}
			set
			{
				base.SetProperty<int>(ref this._UserMachineCpuCores, value, null);
			}
		}

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x0600029F RID: 671 RVA: 0x00003652 File Offset: 0x00001852
		// (set) Token: 0x060002A0 RID: 672 RVA: 0x0000365A File Offset: 0x0000185A
		public int MaxFPS
		{
			get
			{
				return this._MaxFPS;
			}
			set
			{
				base.SetProperty<int>(ref this._MaxFPS, value, null);
			}
		}

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x060002A1 RID: 673 RVA: 0x0000366B File Offset: 0x0000186B
		// (set) Token: 0x060002A2 RID: 674 RVA: 0x00003673 File Offset: 0x00001873
		public Status Status
		{
			get
			{
				return this._Status;
			}
			set
			{
				base.SetProperty<Status>(ref this._Status, value, null);
			}
		}

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x060002A3 RID: 675 RVA: 0x00003684 File Offset: 0x00001884
		// (set) Token: 0x060002A4 RID: 676 RVA: 0x0000368C File Offset: 0x0000188C
		public bool IsGraphicModeEnabled
		{
			get
			{
				return this._IsGraphicModeEnabled;
			}
			set
			{
				base.SetProperty<bool>(ref this._IsGraphicModeEnabled, value, null);
			}
		}

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x060002A5 RID: 677 RVA: 0x0000369D File Offset: 0x0000189D
		// (set) Token: 0x060002A6 RID: 678 RVA: 0x000036A5 File Offset: 0x000018A5
		public GraphicsMode GraphicsMode
		{
			get
			{
				return this._GraphicsMode;
			}
			set
			{
				if (this._GraphicsMode != value)
				{
					this.ValidateGraphicMode(this._GraphicsMode, value);
				}
				base.NotifyPropertyChanged("GraphicsMode");
			}
		}

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x060002A7 RID: 679 RVA: 0x000036C8 File Offset: 0x000018C8
		// (set) Token: 0x060002A8 RID: 680 RVA: 0x000036D0 File Offset: 0x000018D0
		public Uri DirectXUri
		{
			get
			{
				return this._DirectXUri;
			}
			set
			{
				base.SetProperty<Uri>(ref this._DirectXUri, value, null);
			}
		}

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x060002A9 RID: 681 RVA: 0x000036E1 File Offset: 0x000018E1
		// (set) Token: 0x060002AA RID: 682 RVA: 0x000036E9 File Offset: 0x000018E9
		public string WarningMessage
		{
			get
			{
				return this._WarningMessage;
			}
			set
			{
				base.SetProperty<string>(ref this._WarningMessage, value, null);
			}
		}

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x060002AB RID: 683 RVA: 0x000036FA File Offset: 0x000018FA
		// (set) Token: 0x060002AC RID: 684 RVA: 0x00003702 File Offset: 0x00001902
		public string ProgressMessage
		{
			get
			{
				return this._ProgressMessage;
			}
			set
			{
				base.SetProperty<string>(ref this._ProgressMessage, value, null);
			}
		}

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x060002AD RID: 685 RVA: 0x00003713 File Offset: 0x00001913
		// (set) Token: 0x060002AE RID: 686 RVA: 0x0000371B File Offset: 0x0000191B
		public string ErrorMessage
		{
			get
			{
				return this._ErrorMessage;
			}
			set
			{
				base.SetProperty<string>(ref this._ErrorMessage, value, null);
			}
		}

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x060002AF RID: 687 RVA: 0x0000372C File Offset: 0x0000192C
		// (set) Token: 0x060002B0 RID: 688 RVA: 0x00003734 File Offset: 0x00001934
		public bool UseAdvancedGraphicEngine
		{
			get
			{
				return this._UseAdvancedGraphicEngine;
			}
			set
			{
				if (this._UseAdvancedGraphicEngine != value)
				{
					this.ValidateGraphicEngine(value);
					return;
				}
				base.NotifyPropertyChanged("UseAdvancedGraphicEngine");
			}
		}

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x060002B1 RID: 689 RVA: 0x00003752 File Offset: 0x00001952
		// (set) Token: 0x060002B2 RID: 690 RVA: 0x0000375A File Offset: 0x0000195A
		public bool UseDedicatedGPU
		{
			get
			{
				return this._UseDedicatedGPU;
			}
			set
			{
				if (this._UseDedicatedGPU != value)
				{
					this.ValidateGPU(this._UseDedicatedGPU, value);
					return;
				}
				base.NotifyPropertyChanged("UseDedicatedGPU");
			}
		}

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x060002B3 RID: 691 RVA: 0x0000377E File Offset: 0x0000197E
		// (set) Token: 0x060002B4 RID: 692 RVA: 0x00003786 File Offset: 0x00001986
		public string PreferDedicatedGPUText
		{
			get
			{
				return this._PreferDedicatedGPUText;
			}
			set
			{
				base.SetProperty<string>(ref this._PreferDedicatedGPUText, value, null);
			}
		}

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x060002B5 RID: 693 RVA: 0x00003797 File Offset: 0x00001997
		// (set) Token: 0x060002B6 RID: 694 RVA: 0x0000379F File Offset: 0x0000199F
		public string UseDedicatedGPUText
		{
			get
			{
				return this._UseDedicatedGPUText;
			}
			set
			{
				base.SetProperty<string>(ref this._UseDedicatedGPUText, value, null);
			}
		}

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x060002B7 RID: 695 RVA: 0x000037B0 File Offset: 0x000019B0
		// (set) Token: 0x060002B8 RID: 696 RVA: 0x000037B8 File Offset: 0x000019B8
		public bool IsGPUAvailable
		{
			get
			{
				return this._IsGPUAvailable;
			}
			set
			{
				base.SetProperty<bool>(ref this._IsGPUAvailable, value, null);
			}
		}

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x060002B9 RID: 697 RVA: 0x000037C9 File Offset: 0x000019C9
		// (set) Token: 0x060002BA RID: 698 RVA: 0x000037D1 File Offset: 0x000019D1
		public ASTCTexture ASTCTexture
		{
			get
			{
				return this._ASTCTexture;
			}
			set
			{
				if (base.SetProperty<ASTCTexture>(ref this._ASTCTexture, value, null))
				{
					this.SetASTCOption();
				}
			}
		}

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x060002BB RID: 699 RVA: 0x000037E9 File Offset: 0x000019E9
		// (set) Token: 0x060002BC RID: 700 RVA: 0x000037F1 File Offset: 0x000019F1
		public bool EnableHardwareDecoding
		{
			get
			{
				return this._EnableHardwareDecoding;
			}
			set
			{
				base.SetProperty<bool>(ref this._EnableHardwareDecoding, value, null);
			}
		}

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x060002BD RID: 701 RVA: 0x00003802 File Offset: 0x00001A02
		// (set) Token: 0x060002BE RID: 702 RVA: 0x0000380A File Offset: 0x00001A0A
		public bool EnableCaching
		{
			get
			{
				return this._EnableCaching;
			}
			set
			{
				if (base.SetProperty<bool>(ref this._EnableCaching, value, null))
				{
					this.SetASTCOption();
				}
			}
		}

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x060002BF RID: 703 RVA: 0x00003822 File Offset: 0x00001A22
		// (set) Token: 0x060002C0 RID: 704 RVA: 0x00012E2C File Offset: 0x0001102C
		public int PerformanceSettingIndex
		{
			get
			{
				return this._PerformanceSettingIndex;
			}
			set
			{
				if (this._PerformanceSettingIndex != value)
				{
					base.SetProperty<int>(ref this._PerformanceSettingIndex, value, null);
					switch (this._PerformanceSettingIndex)
					{
					case 0:
						this.PerformanceSetting = PerformanceSetting.High;
						return;
					case 1:
						this.PerformanceSetting = PerformanceSetting.Medium;
						return;
					case 2:
						this.PerformanceSetting = PerformanceSetting.Low;
						return;
					case 3:
						this.PerformanceSetting = PerformanceSetting.Custom;
						break;
					default:
						return;
					}
				}
			}
		}

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x060002C1 RID: 705 RVA: 0x0000382A File Offset: 0x00001A2A
		// (set) Token: 0x060002C2 RID: 706 RVA: 0x00012E90 File Offset: 0x00011090
		public PerformanceSetting PerformanceSetting
		{
			get
			{
				return this._PerformanceSetting;
			}
			set
			{
				this._PerformanceSetting = value;
				switch (this._PerformanceSetting)
				{
				case PerformanceSetting.High:
					this.CpuCores = Math.Min(this._UserSupportedVCPU, 4);
					this.Ram = (this._HighEndMachine ? 4096 : 3072);
					this.PerformanceSettingIndex = 0;
					this.CpuMemoryVisibility = Visibility.Collapsed;
					return;
				case PerformanceSetting.Medium:
					this.CpuCores = Math.Min(this._UserSupportedVCPU, 2);
					this.Ram = 2048;
					this.PerformanceSettingIndex = 1;
					this.CpuMemoryVisibility = Visibility.Collapsed;
					return;
				case PerformanceSetting.Low:
					this.CpuCores = Math.Min(this._UserSupportedVCPU, 1);
					this.Ram = 1024;
					this.PerformanceSettingIndex = 2;
					this.CpuMemoryVisibility = Visibility.Collapsed;
					return;
				case PerformanceSetting.Custom:
					this.PerformanceSettingIndex = 3;
					this.CpuMemoryVisibility = Visibility.Visible;
					return;
				default:
					return;
				}
			}
		}

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x060002C3 RID: 707 RVA: 0x00003832 File Offset: 0x00001A32
		// (set) Token: 0x060002C4 RID: 708 RVA: 0x0000383A File Offset: 0x00001A3A
		public Visibility CpuMemoryVisibility
		{
			get
			{
				return this._CpuMemoryVisibility;
			}
			set
			{
				base.SetProperty<Visibility>(ref this._CpuMemoryVisibility, value, null);
			}
		}

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x060002C5 RID: 709 RVA: 0x0000384B File Offset: 0x00001A4B
		// (set) Token: 0x060002C6 RID: 710 RVA: 0x00003853 File Offset: 0x00001A53
		public ObservableCollection<string> PerformanceSettingList
		{
			get
			{
				return this._PerformanceSettingList;
			}
			set
			{
				base.SetProperty<ObservableCollection<string>>(ref this._PerformanceSettingList, value, null);
			}
		}

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x060002C7 RID: 711 RVA: 0x00003864 File Offset: 0x00001A64
		// (set) Token: 0x060002C8 RID: 712 RVA: 0x0000386C File Offset: 0x00001A6C
		public int CpuCores
		{
			get
			{
				return this._CpuCores;
			}
			set
			{
				base.SetProperty<int>(ref this._CpuCores, value, null);
			}
		}

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x060002C9 RID: 713 RVA: 0x0000387D File Offset: 0x00001A7D
		// (set) Token: 0x060002CA RID: 714 RVA: 0x00003885 File Offset: 0x00001A85
		public ObservableCollection<int> CpuCoresList
		{
			get
			{
				return this._CpuCoresList;
			}
			set
			{
				base.SetProperty<ObservableCollection<int>>(ref this._CpuCoresList, value, null);
			}
		}

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x060002CB RID: 715 RVA: 0x00003896 File Offset: 0x00001A96
		// (set) Token: 0x060002CC RID: 716 RVA: 0x0000389E File Offset: 0x00001A9E
		public int Ram
		{
			get
			{
				return this._Ram;
			}
			set
			{
				base.SetProperty<int>(ref this._Ram, value, null);
			}
		}

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x060002CD RID: 717 RVA: 0x000038AF File Offset: 0x00001AAF
		// (set) Token: 0x060002CE RID: 718 RVA: 0x000038B7 File Offset: 0x00001AB7
		public bool IsRamSliderEnabled
		{
			get
			{
				return this._IsRamSliderEnabled;
			}
			set
			{
				base.SetProperty<bool>(ref this._IsRamSliderEnabled, value, null);
			}
		}

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x060002CF RID: 719 RVA: 0x000038C8 File Offset: 0x00001AC8
		// (set) Token: 0x060002D0 RID: 720 RVA: 0x000038D0 File Offset: 0x00001AD0
		public string RecommendedRamText
		{
			get
			{
				return this._RecommendedRamText;
			}
			set
			{
				base.SetProperty<string>(ref this._RecommendedRamText, value, null);
			}
		}

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x060002D1 RID: 721 RVA: 0x000038E1 File Offset: 0x00001AE1
		// (set) Token: 0x060002D2 RID: 722 RVA: 0x000038E9 File Offset: 0x00001AE9
		public int FrameRate
		{
			get
			{
				return this._FrameRate;
			}
			set
			{
				base.SetProperty<int>(ref this._FrameRate, value, null);
			}
		}

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x060002D3 RID: 723 RVA: 0x000038FA File Offset: 0x00001AFA
		// (set) Token: 0x060002D4 RID: 724 RVA: 0x00003902 File Offset: 0x00001B02
		public bool IsFrameRateEnabled
		{
			get
			{
				return this._IsFrameRateEnabled;
			}
			set
			{
				base.SetProperty<bool>(ref this._IsFrameRateEnabled, value, null);
			}
		}

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x060002D5 RID: 725 RVA: 0x00003913 File Offset: 0x00001B13
		// (set) Token: 0x060002D6 RID: 726 RVA: 0x0000391B File Offset: 0x00001B1B
		public bool EnableHighFrameRates
		{
			get
			{
				return this._EnableHighFrameRates;
			}
			set
			{
				base.SetProperty<bool>(ref this._EnableHighFrameRates, value, null);
				if (this.EnableHighFrameRates)
				{
					this.MaxFPS = 1000;
					return;
				}
				this.MaxFPS = 120;
				if (this.FrameRate > 120)
				{
					this.FrameRate = 120;
				}
			}
		}

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x060002D7 RID: 727 RVA: 0x0000395A File Offset: 0x00001B5A
		// (set) Token: 0x060002D8 RID: 728 RVA: 0x00003962 File Offset: 0x00001B62
		public bool DisplayFPS
		{
			get
			{
				return this._DisplayFPS;
			}
			set
			{
				base.SetProperty<bool>(ref this._DisplayFPS, value, null);
			}
		}

		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x060002D9 RID: 729 RVA: 0x00003973 File Offset: 0x00001B73
		// (set) Token: 0x060002DA RID: 730 RVA: 0x0000397B File Offset: 0x00001B7B
		public bool IsAndroidBooted
		{
			get
			{
				return this._IsAndroidBooted;
			}
			set
			{
				base.SetProperty<bool>(ref this._IsAndroidBooted, value, null);
			}
		}

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x060002DB RID: 731 RVA: 0x0000398C File Offset: 0x00001B8C
		// (set) Token: 0x060002DC RID: 732 RVA: 0x00003994 File Offset: 0x00001B94
		public ABISetting ABISetting
		{
			get
			{
				return this._ABISetting;
			}
			set
			{
				base.SetProperty<ABISetting>(ref this._ABISetting, value, null);
			}
		}

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x060002DD RID: 733 RVA: 0x000039A5 File Offset: 0x00001BA5
		// (set) Token: 0x060002DE RID: 734 RVA: 0x000039AD File Offset: 0x00001BAD
		public bool IsOpenedFromMultiInstane
		{
			get
			{
				return this._IsOpenedFromMultiInstane;
			}
			set
			{
				base.SetProperty<bool>(ref this._IsOpenedFromMultiInstane, value, null);
			}
		}

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x060002DF RID: 735 RVA: 0x000039BE File Offset: 0x00001BBE
		// (set) Token: 0x060002E0 RID: 736 RVA: 0x000039C6 File Offset: 0x00001BC6
		public ICommand SaveCommand { get; set; }

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x060002E1 RID: 737 RVA: 0x000039CF File Offset: 0x00001BCF
		public EngineData EngineData { get; } = new EngineData();

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x060002E2 RID: 738 RVA: 0x000039D7 File Offset: 0x00001BD7
		// (set) Token: 0x060002E3 RID: 739 RVA: 0x000039DF File Offset: 0x00001BDF
		public Window Owner { get; private set; }

		// Token: 0x060002E4 RID: 740 RVA: 0x00012F64 File Offset: 0x00011164
		public EngineSettingBaseViewModel(Window owner, string vmName, bool isOpenedFromMultiInstane = false)
		{
			if ((double)EngineSettingBaseViewModel.UserMachineRAM >= 7782.4 && Environment.ProcessorCount >= 8)
			{
				this._HighEndMachine = true;
			}
			this.Owner = owner;
			this._VmName = vmName;
			this._IsOpenedFromMultiInstane = isOpenedFromMultiInstane;
			this.SaveCommand = new RelayCommand2(new Func<object, bool>(this.CanSave), new Action<object>(this.Save));
		}

		// Token: 0x060002E5 RID: 741 RVA: 0x000039E8 File Offset: 0x00001BE8
		private bool CanSave(object obj)
		{
			return this.IsDirty();
		}

		// Token: 0x060002E6 RID: 742 RVA: 0x000130A4 File Offset: 0x000112A4
		public void Init()
		{
			this.Status = Status.None;
			this.CpuCoresList.Clear();
			this.PreferDedicatedGPUText = LocaleStrings.GetLocalizedString("STRING_USE_DEDICATED_GPU") + " " + LocaleStrings.GetLocalizedString("STRING_NVIDIA_ONLY");
			this.Ram = RegistryManager.Instance.Guest[this._VmName].Memory;
			this._UseDedicatedGPU = RegistryManager.Instance.ForceDedicatedGPU;
			this._GraphicsMode = (GraphicsMode)RegistryManager.Instance.Guest[this._VmName].GlRenderMode;
			this._GlMode = RegistryManager.Instance.Guest[this._VmName].GlMode;
			if (!string.Equals(RegistryManager.Instance.CurrentEngine, "raw", StringComparison.InvariantCulture))
			{
				this._UserSupportedVCPU = ((Environment.ProcessorCount > 8) ? 8 : Environment.ProcessorCount);
			}
			this.CpuCoresList = new ObservableCollection<int>(Enumerable.Range(1, this._UserSupportedVCPU));
			this.CpuCores = RegistryManager.Instance.Guest[this._VmName].VCPUs;
			this.SetRam();
			this.SetPerformanceSettingCollection();
			this.SetPerformance();
			this._UseAdvancedGraphicEngine = (Utils.GetValueInBootParams("GlMode", this._VmName, "") == "2");
			this.EnableHighFrameRates = (RegistryManager.Instance.Guest[this._VmName].EnableHighFPS != 0);
			this.FrameRate = RegistryManager.Instance.Guest[this._VmName].FPS;
			this.IsFrameRateEnabled = (!RegistryManager.Instance.CurrentFarmModeStatus || !Utils.GetRunningInstancesList().Contains(this._VmName));
			this.DisplayFPS = (RegistryManager.Instance.Guest[this._VmName].ShowFPS == 1);
			this.IsAndroidBooted = Utils.IsGuestBooted(this._VmName);
			this.SetASTCTexture();
			string valueInBootParams = Utils.GetValueInBootParams("abivalue", this._VmName, "");
			if (!string.IsNullOrEmpty(valueInBootParams))
			{
				this.ABISetting = ((valueInBootParams == ABISetting.ARM.ToString("D")) ? ABISetting.ARM : ABISetting.Auto);
			}
			else
			{
				Utils.UpdateValueInBootParams("abivalue", ABISetting.Auto.ToString("D"), this._VmName, true);
			}
			if (!string.IsNullOrEmpty(RegistryManager.Instance.AvailableGPUDetails))
			{
				this.IsGPUAvailable = true;
				this.UseDedicatedGPUText = RegistryManager.Instance.AvailableGPUDetails;
			}
			this._CurrentGraphicsBitPattern = EngineSettingBaseViewModel.GenerateGraphicsBitPattern(this._GlMode, (int)this.GraphicsMode);
			base.NotifyPropertyChanged(string.Empty);
			this.LockForModification();
		}

		// Token: 0x060002E7 RID: 743 RVA: 0x0001334C File Offset: 0x0001154C
		private void SetASTCTexture()
		{
			this._ASTCOption = RegistryManager.Instance.Guest[this._VmName].ASTCOption;
			this.EnableHardwareDecoding = RegistryManager.Instance.Guest[this._VmName].IsHardwareAstcSupported;
			switch (this._ASTCOption)
			{
			case ASTCOption.Disabled:
				this.ASTCTexture = ASTCTexture.Disabled;
				return;
			case ASTCOption.SoftwareDecoding:
				this.ASTCTexture = ASTCTexture.Software;
				this.EnableCaching = false;
				return;
			case ASTCOption.SoftwareDecodingCache:
				this.ASTCTexture = ASTCTexture.Software;
				this.EnableCaching = true;
				return;
			case ASTCOption.HardwareDecoding:
				this.ASTCTexture = (this.EnableHardwareDecoding ? ASTCTexture.Hardware : ASTCTexture.Disabled);
				return;
			default:
				return;
			}
		}

		// Token: 0x060002E8 RID: 744 RVA: 0x000133F0 File Offset: 0x000115F0
		private void SetASTCOption()
		{
			switch (this.ASTCTexture)
			{
			case ASTCTexture.Disabled:
				this._ASTCOption = ASTCOption.Disabled;
				this.EnableCaching = false;
				return;
			case ASTCTexture.Software:
				this._ASTCOption = (this.EnableCaching ? ASTCOption.SoftwareDecodingCache : ASTCOption.SoftwareDecoding);
				return;
			case ASTCTexture.Hardware:
				this._ASTCOption = ASTCOption.HardwareDecoding;
				this.EnableCaching = false;
				return;
			default:
				return;
			}
		}

		// Token: 0x060002E9 RID: 745 RVA: 0x00013448 File Offset: 0x00011648
		private void SetPerformanceSettingCollection()
		{
			this.PerformanceSettingList.Clear();
			using (IEnumerator enumerator = Enum.GetValues(typeof(PerformanceSetting)).GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					switch ((PerformanceSetting)enumerator.Current)
					{
					case PerformanceSetting.High:
					{
						string localizedString = LocaleStrings.GetLocalizedString("STRING_HIGH");
						string text = string.Format("{0} {1}", Math.Min(this._UserSupportedVCPU, 4), LocaleStrings.GetLocalizedString("STRING_CPU_CORES"));
						string text2 = string.Format("{0} {1}", Math.Min(this.MaxRam, this._HighEndMachine ? 4096 : 3072), LocaleStrings.GetLocalizedString("STRING_MEMORY_LOWERCASE"));
						this.PerformanceSettingList.Add(localizedString + " " + string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_BRACKETS_0_COMMA_1"), new object[]
						{
							text,
							text2
						}));
						break;
					}
					case PerformanceSetting.Medium:
					{
						string localizedString = LocaleStrings.GetLocalizedString("STRING_MEDIUM");
						string text = string.Format("{0} {1}", Math.Min(this._UserSupportedVCPU, 2), LocaleStrings.GetLocalizedString("STRING_CPU_CORES"));
						string text2 = string.Format("{0} {1}", Math.Min(this.MaxRam, 2048), LocaleStrings.GetLocalizedString("STRING_MEMORY_LOWERCASE"));
						this.PerformanceSettingList.Add(localizedString + " " + string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_BRACKETS_0_COMMA_1"), new object[]
						{
							text,
							text2
						}));
						break;
					}
					case PerformanceSetting.Low:
					{
						string localizedString = LocaleStrings.GetLocalizedString("STRING_LOW");
						string text = string.Format("{0} {1}", Math.Min(this._UserSupportedVCPU, 1), LocaleStrings.GetLocalizedString("STRING_CPU_CORES"));
						string text2 = string.Format("{0} {1}", Math.Min(this.MaxRam, 1024), LocaleStrings.GetLocalizedString("STRING_MEMORY_LOWERCASE"));
						this.PerformanceSettingList.Add(localizedString + " " + string.Format(CultureInfo.InvariantCulture, LocaleStrings.GetLocalizedString("STRING_BRACKETS_0_COMMA_1"), new object[]
						{
							text,
							text2
						}));
						break;
					}
					case PerformanceSetting.Custom:
						this.PerformanceSettingList.Add(LocaleStrings.GetLocalizedString("STRING_CUSTOM1"));
						break;
					}
				}
			}
		}

		// Token: 0x060002EA RID: 746 RVA: 0x000136D0 File Offset: 0x000118D0
		private void SetPerformance()
		{
			if (this.CpuCores == Math.Min(this._UserSupportedVCPU, 4) && this.Ram == Math.Min(this.MaxRam, this._HighEndMachine ? 4096 : 3072))
			{
				this.PerformanceSetting = PerformanceSetting.High;
				return;
			}
			if (this.CpuCores == Math.Min(this._UserSupportedVCPU, 2) && this.Ram == Math.Min(this.MaxRam, 2048))
			{
				this.PerformanceSetting = PerformanceSetting.Medium;
				return;
			}
			if (this.CpuCores == Math.Min(this._UserSupportedVCPU, 1) && this.Ram == Math.Min(this.MaxRam, 1024))
			{
				this.PerformanceSetting = PerformanceSetting.Low;
				return;
			}
			this.PerformanceSetting = PerformanceSetting.Custom;
		}

		// Token: 0x060002EB RID: 747 RVA: 0x00013790 File Offset: 0x00011990
		private void SetRam()
		{
			this._MaxRam = (int)((double)EngineSettingBaseViewModel.UserMachineRAM * 0.75);
			if (this._MaxRam <= this._MinRam)
			{
				this.IsRamSliderEnabled = false;
			}
			else if (this._MaxRam >= 4096 && !Oem.Instance.IsAndroid64Bit)
			{
				this._MaxRam = 4096;
			}
			if (string.Equals(RegistryManager.Instance.CurrentEngine, "raw", StringComparison.InvariantCulture) && this._MaxRam >= 3072)
			{
				this._MaxRam = 3072;
			}
			string str;
			if (string.Equals(this._VmName, Strings.CurrentDefaultVmName, StringComparison.OrdinalIgnoreCase))
			{
				if (EngineSettingBaseViewModel.UserMachineRAM < 3072)
				{
					str = "600";
				}
				else if (SystemUtils.IsOs64Bit())
				{
					if (EngineSettingBaseViewModel.UserMachineRAM <= 4 * this._OneGB)
					{
						str = "900";
					}
					else if (EngineSettingBaseViewModel.UserMachineRAM <= 5 * this._OneGB)
					{
						str = "1200";
					}
					else if (EngineSettingBaseViewModel.UserMachineRAM <= 6 * this._OneGB)
					{
						str = "1500";
					}
					else if (EngineSettingBaseViewModel.UserMachineRAM < 8 * this._OneGB)
					{
						str = "1800";
					}
					else if (RegistryManager.Instance.CurrentEngine == "raw")
					{
						str = "3072";
					}
					else
					{
						str = "4096";
					}
				}
				else
				{
					str = "900";
				}
			}
			else
			{
				str = (SystemUtils.IsOs64Bit() ? ((EngineSettingBaseViewModel.UserMachineRAM < 4 * this._OneGB) ? "800" : "1100") : "600");
			}
			this.RecommendedRamText = LocaleStrings.GetLocalizedString("STRING_REC_MEM") + " " + str + " MB";
		}

		// Token: 0x060002EC RID: 748 RVA: 0x00013930 File Offset: 0x00011B30
		private void CreateGraphicsCompatibilityDictionary()
		{
			string text = "";
			for (int i = 0; i < 4; i++)
			{
				if ((i & 1) == 0)
				{
					text += "4";
				}
				else
				{
					text += "1";
				}
				if ((i & 2) == 2)
				{
					text += " 2";
				}
				if (RunCommand.RunCmd(Path.Combine(RegistryStrings.InstallDir, "HD-GlCheck"), text, true, true, false, 10000).ExitCode == 0)
				{
					this._DictForGraphicsCompatibility.Add(i, true);
				}
				else
				{
					this._DictForGraphicsCompatibility.Add(i, false);
				}
				text = "";
			}
		}

		// Token: 0x060002ED RID: 749 RVA: 0x000139C8 File Offset: 0x00011BC8
		private static int GenerateGraphicsBitPattern(int glMode, int glRenderMode)
		{
			int num = 0;
			if (glMode == 0)
			{
				num |= 0;
			}
			else if (glMode == 2)
			{
				num |= 2;
			}
			if (glRenderMode == 1)
			{
				num |= 1;
			}
			else if (glRenderMode == 4)
			{
				num |= 0;
			}
			return num;
		}

		// Token: 0x060002EE RID: 750 RVA: 0x000139FC File Offset: 0x00011BFC
		private void ValidateGraphicMode(GraphicsMode oldMode_, GraphicsMode newMode_)
		{
			this._oldMode = oldMode_;
			this._newMode = newMode_;
			if (this._DictForGraphicsCompatibility == null)
			{
				this._DictForGraphicsCompatibility = new Dictionary<int, bool>();
				using (BackgroundWorker backgroundWorker = new BackgroundWorker())
				{
					this.ProgressMessage = string.Format(CultureInfo.CurrentCulture, LocaleStrings.GetLocalizedString("STRING_CHECKING_GRAPHICS_COMPATIBILITY"), new object[]
					{
						newMode_
					});
					backgroundWorker.DoWork += this.BcwWorker_DoWork;
					backgroundWorker.RunWorkerCompleted += this.BcwWorker_RunWorkerCompleted;
					backgroundWorker.RunWorkerAsync();
					return;
				}
			}
			this.HandleChangesForGlRenderModeValueChange();
		}

		// Token: 0x060002EF RID: 751 RVA: 0x000039F0 File Offset: 0x00001BF0
		private void BcwWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			Dispatcher.CurrentDispatcher.BeginInvoke(new Action(delegate()
			{
				this.IsGraphicModeEnabled = true;
				this.HandleChangesForGlRenderModeValueChange();
			}), new object[0]);
		}

		// Token: 0x060002F0 RID: 752 RVA: 0x00003A0F File Offset: 0x00001C0F
		private void BcwWorker_DoWork(object sender, DoWorkEventArgs e)
		{
			this.IsGraphicModeEnabled = false;
			this.Status = Status.Progress;
			this.CreateGraphicsCompatibilityDictionary();
		}

		// Token: 0x060002F1 RID: 753 RVA: 0x00013AA8 File Offset: 0x00011CA8
		private void HandleChangesForGlRenderModeValueChange()
		{
			int key = EngineSettingBaseViewModel.GenerateGraphicsBitPattern(this._GlMode, (int)this._GraphicsMode);
			if (this._DictForGraphicsCompatibility.ContainsKey(key) && this._DictForGraphicsCompatibility[key])
			{
				this.SetGraphicMode(this._newMode);
				return;
			}
			this.ErrorMessage = string.Format(CultureInfo.CurrentCulture, LocaleStrings.GetLocalizedString("STRING_GRAPHICS_NOT_SUPPORTED_ON_MACHINE"), new object[]
			{
				this._newMode
			});
			this.Status = Status.Error;
			this.SetGraphicMode(this._oldMode);
		}

		// Token: 0x060002F2 RID: 754 RVA: 0x00013B34 File Offset: 0x00011D34
		private void ValidateGraphicEngine(bool newEngine_)
		{
			this._newEngine = newEngine_;
			int num = EngineSettingBaseViewModel.GenerateGraphicsBitPattern(newEngine_ ? 2 : 0, (int)this.GraphicsMode);
			if (this._CurrentGraphicsBitPattern != num)
			{
				if (this._DictForGraphicsCompatibility == null)
				{
					this._DictForGraphicsCompatibility = new Dictionary<int, bool>();
					using (BackgroundWorker backgroundWorker = new BackgroundWorker())
					{
						backgroundWorker.DoWork += this.BcwForGlMode_DoWork;
						backgroundWorker.RunWorkerCompleted += this.BcwForGlMode_RunWorkerCompleted;
						backgroundWorker.RunWorkerAsync();
						return;
					}
				}
				this.ChangesForGlMode();
				return;
			}
			this.RevertToOriginalGlMode(this._CurrentGraphicsBitPattern);
		}

		// Token: 0x060002F3 RID: 755 RVA: 0x00013BD8 File Offset: 0x00011DD8
		private void RevertToOriginalGlMode(int mGraphicsBitPattern)
		{
			if (mGraphicsBitPattern == 0 || mGraphicsBitPattern == 1)
			{
				Utils.UpdateValueInBootParams("GlMode", "1", this._VmName, true);
				this._UseAdvancedGraphicEngine = false;
				base.NotifyPropertyChanged("UseAdvancedGraphicEngine");
				return;
			}
			Utils.UpdateValueInBootParams("GlMode", "2", this._VmName, true);
			this._UseAdvancedGraphicEngine = true;
			base.NotifyPropertyChanged("UseAdvancedGraphicEngine");
		}

		// Token: 0x060002F4 RID: 756 RVA: 0x00003A25 File Offset: 0x00001C25
		private void BcwForGlMode_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			Dispatcher.CurrentDispatcher.BeginInvoke(new Action(delegate()
			{
				this.IsGraphicModeEnabled = true;
				this.Status = Status.None;
				this.ChangesForGlMode();
			}), new object[0]);
		}

		// Token: 0x060002F5 RID: 757 RVA: 0x00013C40 File Offset: 0x00011E40
		private void ChangesForGlMode()
		{
			int key = EngineSettingBaseViewModel.GenerateGraphicsBitPattern(this._newEngine ? 2 : 0, (int)this.GraphicsMode);
			this._UseAdvancedGraphicEngine = (this.UseAdvancedGraphicEngine ? (this._DictForGraphicsCompatibility[key] && this._newEngine) : (!this._DictForGraphicsCompatibility[key] || this._newEngine));
			base.NotifyPropertyChanged("UseAdvancedGraphicEngine");
			Logger.Info(string.Format("Setting GlMode to {0}", this.UseAdvancedGraphicEngine ? 2 : 1));
		}

		// Token: 0x060002F6 RID: 758 RVA: 0x00003A0F File Offset: 0x00001C0F
		private void BcwForGlMode_DoWork(object sender, DoWorkEventArgs e)
		{
			this.IsGraphicModeEnabled = false;
			this.Status = Status.Progress;
			this.CreateGraphicsCompatibilityDictionary();
		}

		// Token: 0x060002F7 RID: 759 RVA: 0x00013CD0 File Offset: 0x00011ED0
		private void ValidateGPU(bool oldGPU_, bool newGPU_)
		{
			this._oldGPU = oldGPU_;
			this._newGPU = newGPU_;
			using (BackgroundWorker backgroundWorker = new BackgroundWorker())
			{
				backgroundWorker.DoWork += this.AddDedicatedGPUProfile_DoWork;
				backgroundWorker.RunWorkerCompleted += this.AddDedicatedGPUProfile_RunWorkerCompleted;
				backgroundWorker.RunWorkerAsync(this._newGPU);
			}
		}

		// Token: 0x060002F8 RID: 760 RVA: 0x00013D44 File Offset: 0x00011F44
		private void AddDedicatedGPUProfile_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			Dispatcher.CurrentDispatcher.BeginInvoke(new Action(delegate()
			{
				this.Status = Status.None;
				this._UseDedicatedGPU = (this._newGPU && (bool)e.Result);
				this.NotifyPropertyChanged("UseDedicatedGPU");
			}), new object[0]);
		}

		// Token: 0x060002F9 RID: 761 RVA: 0x00013D84 File Offset: 0x00011F84
		public void SetGraphicMode(GraphicsMode newMode)
		{
			this._GraphicsMode = newMode;
			base.NotifyPropertyChanged("GraphicsMode");
			this.Status = ((this.EngineData.GraphicsMode == this.GraphicsMode) ? Status.None : Status.Warning);
			this.WarningMessage = string.Format(CultureInfo.CurrentCulture, LocaleStrings.GetLocalizedString(this.IsOpenedFromMultiInstane ? "STRING_LAUNCH_BLUESTACKS_AFTER_GRAPHICS_CHANGE" : "STRING_RESTART_BLUESTACKS_AFTER_GRAPHICS_CHANGE"), new object[]
			{
				(this.GraphicsMode == GraphicsMode.DirectX) ? "DirectX" : "OpenGL"
			});
		}

		// Token: 0x060002FA RID: 762 RVA: 0x00013E08 File Offset: 0x00012008
		private void AddDedicatedGPUProfile_DoWork(object sender, DoWorkEventArgs e)
		{
			this.Status = Status.Progress;
			bool flag = ForceDedicatedGPU.ToggleDedicatedGPU((bool)e.Argument, null);
			e.Result = flag;
		}

		// Token: 0x060002FB RID: 763 RVA: 0x0000358C File Offset: 0x0000178C
		protected virtual void Save(object param)
		{
		}

		// Token: 0x060002FC RID: 764 RVA: 0x00003A44 File Offset: 0x00001C44
		public void NotifyPropertyChangedAllProperties()
		{
			base.NotifyPropertyChanged(string.Empty);
		}

		// Token: 0x060002FD RID: 765 RVA: 0x00013E3C File Offset: 0x0001203C
		public void LockForModification()
		{
			this.EngineData.GraphicsMode = this.GraphicsMode;
			this.EngineData.UseAdvancedGraphicEngine = this.UseAdvancedGraphicEngine;
			this.EngineData.UseDedicatedGPU = this.UseDedicatedGPU;
			this.EngineData.ASTCOption = this._ASTCOption;
			this.EngineData.Ram = this.Ram;
			this.EngineData.CpuCores = this.CpuCores;
			this.EngineData.FrameRate = this.FrameRate;
			this.EngineData.EnableHighFrameRates = this.EnableHighFrameRates;
			this.EngineData.DisplayFPS = this.DisplayFPS;
			this.EngineData.ABISetting = this.ABISetting;
		}

		// Token: 0x060002FE RID: 766 RVA: 0x00013EF4 File Offset: 0x000120F4
		public bool IsDirty()
		{
			return this.IsRestartRequired() || this.EngineData.ASTCOption != this._ASTCOption || this.EngineData.FrameRate != this.FrameRate || this.EngineData.EnableHighFrameRates != this.EnableHighFrameRates || this.EngineData.DisplayFPS != this.DisplayFPS;
		}

		// Token: 0x060002FF RID: 767 RVA: 0x00013F5C File Offset: 0x0001215C
		public bool IsRestartRequired()
		{
			return this.EngineData.GraphicsMode != this.GraphicsMode || this.EngineData.UseAdvancedGraphicEngine != this.UseAdvancedGraphicEngine || this.EngineData.UseDedicatedGPU != this.UseDedicatedGPU || this.EngineData.Ram != this.Ram || this.EngineData.CpuCores != this.CpuCores || this.EngineData.ABISetting != this.ABISetting;
		}

		// Token: 0x06000300 RID: 768 RVA: 0x00013FE0 File Offset: 0x000121E0
		public void SaveEngineSettings()
		{
			RegistryManager.Instance.Guest[this._VmName].GlRenderMode = (int)this.GraphicsMode;
			RegistryManager.Instance.Guest[this._VmName].GlMode = (this.UseAdvancedGraphicEngine ? 2 : 1);
			Utils.UpdateValueInBootParams("GlMode", RegistryManager.Instance.Guest[this._VmName].GlMode.ToString(CultureInfo.InvariantCulture), this._VmName, true);
			RegistryManager.Instance.ForceDedicatedGPU = this.UseDedicatedGPU;
			Utils.SetAstcOption(this._VmName, this._ASTCOption);
			RegistryManager.Instance.Guest[this._VmName].Memory = this.Ram;
			RegistryManager.Instance.Guest[this._VmName].VCPUs = this.CpuCores;
			RegistryManager.Instance.Guest[this._VmName].EnableHighFPS = (this.EnableHighFrameRates ? 1 : 0);
			RegistryManager.Instance.Guest[this._VmName].ShowFPS = (this.DisplayFPS ? 1 : 0);
			Utils.SendShowFPSToInstanceASync(this._VmName, RegistryManager.Instance.Guest[this._VmName].ShowFPS);
			if (!RegistryManager.Instance.CurrentFarmModeStatus || !Utils.GetRunningInstancesList().Contains(this._VmName))
			{
				RegistryManager.Instance.Guest[this._VmName].FPS = this.FrameRate;
				Utils.UpdateValueInBootParams("fps", RegistryManager.Instance.Guest[this._VmName].FPS.ToString(CultureInfo.InvariantCulture), this._VmName, true);
			}
			Utils.UpdateValueInBootParams("abivalue", this.ABISetting.ToString("D"), this._VmName, true);
			Utils.SendChangeFPSToInstanceASync(this._VmName, int.MaxValue);
			Stats.SendMiscellaneousStatsAsync("ABIChanged", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, this.ABISetting.ToString(), "bgp", null, null, null, null, "Android", 0);
			Stats.SendMiscellaneousStatsAsync("DisplayFPSCheckboxClicked", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "enginesettings", this.DisplayFPS ? "checked" : "unchecked", null, this._VmName, null, null, "Android", 0);
			this.LockForModification();
			Stats.SendMiscellaneousStatsAsync("Setting-save", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "Engine-Settings", "", null, this._VmName, null, null, "Android", 0);
		}

		// Token: 0x06000301 RID: 769 RVA: 0x000142B0 File Offset: 0x000124B0
		protected void AddToastPopup(string message)
		{
			try
			{
				if (this.mToastPopup == null)
				{
					this.mToastPopup = new CustomToastPopupControl(this.Owner);
				}
				this.mToastPopup.Init(this.Owner, message, null, null, HorizontalAlignment.Center, VerticalAlignment.Bottom, null, 12, null, null, false);
				this.mToastPopup.ShowPopup(1.3);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in showing toast popup: " + ex.ToString());
			}
		}

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x06000302 RID: 770 RVA: 0x00003A51 File Offset: 0x00001C51
		// (set) Token: 0x06000303 RID: 771 RVA: 0x00003A59 File Offset: 0x00001C59
		public UserControl ParentView { get; set; }

		// Token: 0x06000304 RID: 772 RVA: 0x00014340 File Offset: 0x00012540
		protected void AddToastPopupUserControl(string message)
		{
			try
			{
				if (this.mToastPopup == null)
				{
					this.mToastPopup = new CustomToastPopupControl(this.ParentView);
				}
				this.mToastPopup.Init(this.Owner, message, null, null, HorizontalAlignment.Center, VerticalAlignment.Bottom, null, 12, null, null, false);
				this.mToastPopup.ShowPopup(1.3);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in showing toast popup: " + ex.ToString());
			}
		}

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x06000308 RID: 776 RVA: 0x00003A87 File Offset: 0x00001C87
		// (set) Token: 0x06000309 RID: 777 RVA: 0x0000358C File Offset: 0x0000178C
		public ObservableCollection<string> PerformanceSettingList
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x0600030A RID: 778 RVA: 0x00003A87 File Offset: 0x00001C87
		// (set) Token: 0x0600030B RID: 779 RVA: 0x0000358C File Offset: 0x0000178C
		public ObservableCollection<int> CpuCoresList
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x0600030C RID: 780 RVA: 0x00003A87 File Offset: 0x00001C87
		// (set) Token: 0x0600030D RID: 781 RVA: 0x0000358C File Offset: 0x0000178C
		public ICommand SaveCommand
		{
			[CompilerGenerated]
			get
			{
				return null;
			}
			[CompilerGenerated]
			set
			{
			}
		}

		// Token: 0x04000145 RID: 325
		private int _MinRam = 600;

		// Token: 0x04000146 RID: 326
		private int _MaxRam = 4096;

		// Token: 0x04000147 RID: 327
		private static int? _RamInMB;

		// Token: 0x04000148 RID: 328
		private int _UserMachineCpuCores = Environment.ProcessorCount;

		// Token: 0x04000149 RID: 329
		private int _UserSupportedVCPU = 1;

		// Token: 0x0400014A RID: 330
		private int _MaxFPS = 60;

		// Token: 0x0400014B RID: 331
		private Status _Status;

		// Token: 0x0400014C RID: 332
		private bool _IsGraphicModeEnabled = true;

		// Token: 0x0400014D RID: 333
		private int _GlMode;

		// Token: 0x0400014E RID: 334
		private int _CurrentGraphicsBitPattern;

		// Token: 0x0400014F RID: 335
		private GraphicsMode _GraphicsMode;

		// Token: 0x04000150 RID: 336
		private Uri _DirectXUri = new Uri(WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
		{
			WebHelper.GetServerHost(),
			"help_articles"
		})) + "&article=bgp_kk_compat_version");

		// Token: 0x04000151 RID: 337
		private string _WarningMessage;

		// Token: 0x04000152 RID: 338
		private string _ProgressMessage;

		// Token: 0x04000153 RID: 339
		private string _ErrorMessage;

		// Token: 0x04000154 RID: 340
		private bool _UseAdvancedGraphicEngine;

		// Token: 0x04000155 RID: 341
		private bool _UseDedicatedGPU;

		// Token: 0x04000156 RID: 342
		private string _PreferDedicatedGPUText;

		// Token: 0x04000157 RID: 343
		private string _UseDedicatedGPUText;

		// Token: 0x04000158 RID: 344
		private bool _IsGPUAvailable;

		// Token: 0x04000159 RID: 345
		private ASTCTexture _ASTCTexture;

		// Token: 0x0400015A RID: 346
		private ASTCOption _ASTCOption;

		// Token: 0x0400015B RID: 347
		private bool _EnableHardwareDecoding;

		// Token: 0x0400015C RID: 348
		private bool _EnableCaching;

		// Token: 0x0400015D RID: 349
		private int _PerformanceSettingIndex;

		// Token: 0x0400015E RID: 350
		private PerformanceSetting _PerformanceSetting;

		// Token: 0x0400015F RID: 351
		private Visibility _CpuMemoryVisibility = Visibility.Collapsed;

		// Token: 0x04000160 RID: 352
		private ObservableCollection<string> _PerformanceSettingList = new ObservableCollection<string>();

		// Token: 0x04000161 RID: 353
		private int _CpuCores = 2;

		// Token: 0x04000162 RID: 354
		private ObservableCollection<int> _CpuCoresList = new ObservableCollection<int>();

		// Token: 0x04000163 RID: 355
		private int _Ram = 1100;

		// Token: 0x04000164 RID: 356
		private bool _IsRamSliderEnabled = true;

		// Token: 0x04000165 RID: 357
		private string _RecommendedRamText;

		// Token: 0x04000166 RID: 358
		private int _FrameRate = 60;

		// Token: 0x04000167 RID: 359
		private bool _IsFrameRateEnabled;

		// Token: 0x04000168 RID: 360
		private bool _EnableHighFrameRates;

		// Token: 0x04000169 RID: 361
		private bool _DisplayFPS;

		// Token: 0x0400016A RID: 362
		private bool _IsAndroidBooted;

		// Token: 0x0400016B RID: 363
		private ABISetting _ABISetting = ABISetting.Auto;

		// Token: 0x0400016C RID: 364
		private bool _IsOpenedFromMultiInstane;

		// Token: 0x0400016D RID: 365
		private readonly string _VmName;

		// Token: 0x0400016E RID: 366
		private readonly int _OneGB = 1024;

		// Token: 0x0400016F RID: 367
		private Dictionary<int, bool> _DictForGraphicsCompatibility;

		// Token: 0x04000173 RID: 371
		private bool _HighEndMachine;

		// Token: 0x04000174 RID: 372
		private GraphicsMode _newMode;

		// Token: 0x04000175 RID: 373
		private GraphicsMode _oldMode;

		// Token: 0x04000176 RID: 374
		private bool _newEngine;

		// Token: 0x04000177 RID: 375
		private bool _oldGPU;

		// Token: 0x04000178 RID: 376
		private bool _newGPU;

		// Token: 0x04000179 RID: 377
		private CustomToastPopupControl mToastPopup;

		// Token: 0x0400017B RID: 379
		private ObservableCollection<string> _PerformanceSettingList;

		// Token: 0x0400017C RID: 380
		private ObservableCollection<int> _CpuCoresList;
	}
}
