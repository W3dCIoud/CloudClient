﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001EB RID: 491
	public enum InstallerWrapperCodes
	{
		// Token: 0x04000BF6 RID: 3062
		NO_INSTALLER_FOUND = -1
	}
}
