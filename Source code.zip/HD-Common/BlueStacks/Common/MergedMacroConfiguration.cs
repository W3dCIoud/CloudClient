﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using Newtonsoft.Json;

namespace BlueStacks.Common
{
	// Token: 0x020000B0 RID: 176
	[Serializable]
	public class MergedMacroConfiguration : INotifyPropertyChanged
	{
		// Token: 0x14000006 RID: 6
		// (add) Token: 0x06000483 RID: 1155 RVA: 0x000180CC File Offset: 0x000162CC
		// (remove) Token: 0x06000484 RID: 1156 RVA: 0x00018104 File Offset: 0x00016304
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06000485 RID: 1157 RVA: 0x00004942 File Offset: 0x00002B42
		protected void OnPropertyChanged(string property)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged == null)
			{
				return;
			}
			propertyChanged(this, new PropertyChangedEventArgs(property));
		}

		// Token: 0x1700012C RID: 300
		// (get) Token: 0x06000486 RID: 1158 RVA: 0x0000495B File Offset: 0x00002B5B
		// (set) Token: 0x06000487 RID: 1159 RVA: 0x00004963 File Offset: 0x00002B63
		[JsonIgnore]
		public int Tag { get; set; }

		// Token: 0x1700012D RID: 301
		// (get) Token: 0x06000488 RID: 1160 RVA: 0x0000496C File Offset: 0x00002B6C
		[JsonProperty("MacrosToRun")]
		public ObservableCollection<string> MacrosToRun { get; } = new ObservableCollection<string>();

		// Token: 0x1700012E RID: 302
		// (get) Token: 0x06000489 RID: 1161 RVA: 0x00004974 File Offset: 0x00002B74
		// (set) Token: 0x0600048A RID: 1162 RVA: 0x0000497C File Offset: 0x00002B7C
		[JsonProperty("LoopCount")]
		public int LoopCount
		{
			get
			{
				return this.mLoopCount;
			}
			set
			{
				this.mLoopCount = value;
				this.OnPropertyChanged("LoopCount");
			}
		}

		// Token: 0x1700012F RID: 303
		// (get) Token: 0x0600048B RID: 1163 RVA: 0x00004990 File Offset: 0x00002B90
		// (set) Token: 0x0600048C RID: 1164 RVA: 0x00004998 File Offset: 0x00002B98
		[JsonProperty("LoopInterval")]
		public int LoopInterval
		{
			get
			{
				return this.mLoopInterval;
			}
			set
			{
				this.mLoopInterval = value;
				this.OnPropertyChanged("LoopInterval");
			}
		}

		// Token: 0x17000130 RID: 304
		// (get) Token: 0x0600048D RID: 1165 RVA: 0x000049AC File Offset: 0x00002BAC
		// (set) Token: 0x0600048E RID: 1166 RVA: 0x000049B4 File Offset: 0x00002BB4
		[JsonProperty("DelayNextScript")]
		public int DelayNextScript
		{
			get
			{
				return this.mDelayNextScript;
			}
			set
			{
				this.mDelayNextScript = value;
				this.OnPropertyChanged("DelayNextScript");
			}
		}

		// Token: 0x17000131 RID: 305
		// (get) Token: 0x0600048F RID: 1167 RVA: 0x000049C8 File Offset: 0x00002BC8
		// (set) Token: 0x06000490 RID: 1168 RVA: 0x000049D0 File Offset: 0x00002BD0
		[JsonProperty("Acceleration")]
		public double Acceleration
		{
			get
			{
				return this.mAcceleration;
			}
			set
			{
				this.mAcceleration = value;
				this.OnPropertyChanged("Acceleration");
			}
		}

		// Token: 0x17000132 RID: 306
		// (get) Token: 0x06000491 RID: 1169 RVA: 0x000049E4 File Offset: 0x00002BE4
		// (set) Token: 0x06000492 RID: 1170 RVA: 0x000049EC File Offset: 0x00002BEC
		[JsonIgnore]
		public bool IsGroupButtonVisible
		{
			get
			{
				return this.mIsGroupButtonVisible;
			}
			set
			{
				this.mIsGroupButtonVisible = value;
				this.OnPropertyChanged("IsGroupButtonVisible");
			}
		}

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x06000493 RID: 1171 RVA: 0x00004A00 File Offset: 0x00002C00
		// (set) Token: 0x06000494 RID: 1172 RVA: 0x00004A08 File Offset: 0x00002C08
		[JsonIgnore]
		public bool IsUnGroupButtonVisible
		{
			get
			{
				return this.mIsUnGroupButtonVisible;
			}
			set
			{
				this.mIsUnGroupButtonVisible = value;
				this.OnPropertyChanged("IsUnGroupButtonVisible");
			}
		}

		// Token: 0x17000134 RID: 308
		// (get) Token: 0x06000495 RID: 1173 RVA: 0x00004A1C File Offset: 0x00002C1C
		// (set) Token: 0x06000496 RID: 1174 RVA: 0x00004A24 File Offset: 0x00002C24
		[JsonIgnore]
		public bool IsSettingsVisible
		{
			get
			{
				return this.mIsSettingsVisible;
			}
			set
			{
				this.mIsSettingsVisible = value;
				this.OnPropertyChanged("IsSettingsVisible");
			}
		}

		// Token: 0x17000135 RID: 309
		// (get) Token: 0x06000497 RID: 1175 RVA: 0x00004A38 File Offset: 0x00002C38
		// (set) Token: 0x06000498 RID: 1176 RVA: 0x00004A40 File Offset: 0x00002C40
		[JsonIgnore]
		public bool IsFirstListBoxItem
		{
			get
			{
				return this.mIsFirstListBoxItem;
			}
			set
			{
				this.mIsFirstListBoxItem = value;
				this.OnPropertyChanged("IsFirstListBoxItem");
			}
		}

		// Token: 0x17000136 RID: 310
		// (get) Token: 0x06000499 RID: 1177 RVA: 0x00004A54 File Offset: 0x00002C54
		// (set) Token: 0x0600049A RID: 1178 RVA: 0x00004A5C File Offset: 0x00002C5C
		[JsonIgnore]
		public bool IsLastListBoxItem
		{
			get
			{
				return this.mIsLastListBoxItem;
			}
			set
			{
				this.mIsLastListBoxItem = value;
				this.OnPropertyChanged("IsLastListBoxItem");
			}
		}

		// Token: 0x17000137 RID: 311
		// (get) Token: 0x0600049B RID: 1179 RVA: 0x00004A70 File Offset: 0x00002C70
		[JsonIgnore]
		public IEnumerable<string> AccelerationOptions
		{
			get
			{
				int num;
				for (int i = 0; i <= 8; i = num + 1)
				{
					yield return ((double)(i + 2) * 0.5).ToString(CultureInfo.InvariantCulture) + "x";
					num = i;
				}
				yield break;
			}
		}

		// Token: 0x04000247 RID: 583
		private int mLoopCount = 1;

		// Token: 0x04000248 RID: 584
		private int mLoopInterval;

		// Token: 0x04000249 RID: 585
		private int mDelayNextScript;

		// Token: 0x0400024A RID: 586
		private double mAcceleration = 1.0;

		// Token: 0x0400024B RID: 587
		private bool mIsGroupButtonVisible;

		// Token: 0x0400024C RID: 588
		private bool mIsUnGroupButtonVisible;

		// Token: 0x0400024D RID: 589
		private bool mIsSettingsVisible;

		// Token: 0x0400024E RID: 590
		private bool mIsFirstListBoxItem;

		// Token: 0x0400024F RID: 591
		private bool mIsLastListBoxItem;
	}
}
