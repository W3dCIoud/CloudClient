﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000128 RID: 296
	public enum AlignmentType
	{
		// Token: 0x04000554 RID: 1364
		Spread,
		// Token: 0x04000555 RID: 1365
		Overlay
	}
}
