﻿using System;
using System.IO;

namespace BlueStacks.Common
{
	// Token: 0x020000D4 RID: 212
	public static class Constants
	{
		// Token: 0x17000172 RID: 370
		// (get) Token: 0x06000584 RID: 1412 RVA: 0x000054E9 File Offset: 0x000036E9
		public static string MOBACursorPath
		{
			get
			{
				return Path.Combine(Path.Combine(RegistryManager.Instance.ClientInstallDir, RegistryManager.Instance.GetClientThemeNameFromRegistry()), "Mouse_cursor_MOBA.cur");
			}
		}

		// Token: 0x17000173 RID: 371
		// (get) Token: 0x06000585 RID: 1413 RVA: 0x0000550E File Offset: 0x0000370E
		public static string CustomCursorPath
		{
			get
			{
				return Path.Combine(Path.Combine(RegistryManager.Instance.ClientInstallDir, RegistryManager.Instance.GetClientThemeNameFromRegistry()), "Mouse_cursor.cur");
			}
		}

		// Token: 0x040002DD RID: 733
		public const string MacroPostFix = "_macro";

		// Token: 0x040002DE RID: 734
		public const string dateFormat = "yyyy-MM-dd HH:mm";

		// Token: 0x040002DF RID: 735
		public static readonly Version win8version = new Version(6, 2, 9200, 0);

		// Token: 0x040002E0 RID: 736
		public const int IDENTITY_OFFSET = 16;

		// Token: 0x040002E1 RID: 737
		public const int GUEST_ABS_MAX_X = 32768;

		// Token: 0x040002E2 RID: 738
		public const int GUEST_ABS_MAX_Y = 32768;

		// Token: 0x040002E3 RID: 739
		public const int MaxAllowedCPUCores = 8;

		// Token: 0x040002E4 RID: 740
		public const int TOUCH_POINTS_MAX = 16;

		// Token: 0x040002E5 RID: 741
		public const int SWIPE_TOUCH_POINTS_MAX = 1;

		// Token: 0x040002E6 RID: 742
		public const long LWIN_TIMEOUT_TICKS = 1000000L;

		// Token: 0x040002E7 RID: 743
		public const int CURSOR_HIDE_CLIP_LEN = 15;

		// Token: 0x040002E8 RID: 744
		public static readonly string LocaleStringsConstant = "STRING_";

		// Token: 0x040002E9 RID: 745
		public static readonly string ImapLocaleStringsConstant = "IMAP_" + Constants.LocaleStringsConstant;

		// Token: 0x040002EA RID: 746
		public const string ImapDependent = "Dependent";

		// Token: 0x040002EB RID: 747
		public const string ImapIndependent = "Independent";

		// Token: 0x040002EC RID: 748
		public const string ImapSubElement = "SubElement";

		// Token: 0x040002ED RID: 749
		public const string ImapParentElement = "ParentElement";

		// Token: 0x040002EE RID: 750
		public const string ImapNotCommon = "NotCommon";

		// Token: 0x040002EF RID: 751
		public const string ImapLinked = "Linked";

		// Token: 0x040002F0 RID: 752
		public const string ImapCanvasElementY = "IMAP_CanvasElementX";

		// Token: 0x040002F1 RID: 753
		public const string ImapCanvasElementX = "IMAP_CanvasElementY";

		// Token: 0x040002F2 RID: 754
		public const string ImapCanvasElementRadius = "IMAP_CanvasElementRadius";

		// Token: 0x040002F3 RID: 755
		public const string IMAPPopupUIElement = "IMAP_PopupUIElement";

		// Token: 0x040002F4 RID: 756
		public const string IMAPKeypropertyPrefix = "Key";

		// Token: 0x040002F5 RID: 757
		public const string IMAPUserDefined = "User-Defined";

		// Token: 0x040002F6 RID: 758
		public const string ImapVideoHeaderConstant = "AAVideo";

		// Token: 0x040002F7 RID: 759
		public const string ImapMiscHeaderConstant = "MISC";

		// Token: 0x040002F8 RID: 760
		public const string ImapGlobalValid = "GlobalValidTag";

		// Token: 0x040002F9 RID: 761
		public const string ImapDeveloperModeUIElemnt = "IMAP_DeveloperModeUIElemnt";

		// Token: 0x040002FA RID: 762
		public const string ImapGamepadStartKey = "GamepadStart";

		// Token: 0x040002FB RID: 763
		public const string ImapGamepadBackKey = "GamepadBack";

		// Token: 0x040002FC RID: 764
		public static readonly string[] ImapGamepadEvents = new string[]
		{
			"GamepadDpadUp",
			"GamepadDpadDown",
			"GamepadDpadLeft",
			"GamepadDpadRight",
			"GamepadStart",
			"GamepadStop",
			"GamepadLeftThumb",
			"GamepadRightThumb",
			"GamepadLeftShoulder",
			"GamepadRightShoulder",
			"GamepadA",
			"GamepadB",
			"GamepadX",
			"GamepadY",
			"GamepadLStickUp",
			"GamepadLStickDown",
			"GamepadLStickLeft",
			"GamepadLStickRight",
			"GamepadRtickUp",
			"GamepadRStickDown",
			"GamepadRStickLeft",
			"GamepadRStickRight",
			"GamepadLTrigger",
			"GamepadRTrigger"
		};

		// Token: 0x040002FD RID: 765
		public static readonly string[] ImapShootingModeAppsList = new string[]
		{
			"com.dts.freefireth",
			"com.netease.mrzhna",
			"com.tencent.ig",
			"com.titan.cd.gb",
			"com.critical.strike2",
			"com.gameloft.android.ANMP.GloftM5HM",
			"com.axlebolt.standoff2",
			"com.netease.chiji",
			"com.netease.ko",
			"com.tencent.tmgp.kr.codm",
			"com.garena.game.codm",
			"com.activision.callofduty.shooter",
			"com.pixonic.wwr",
			"com.my.warface.online.fps.pvp.action.shooter"
		};

		// Token: 0x040002FE RID: 766
		public static readonly string[] ReservedFileNamesList = new string[]
		{
			"con",
			"prn",
			"aux",
			"nul",
			"clock$",
			"com1",
			"com2",
			"com3",
			"com4",
			"com5",
			"com6",
			"com7",
			"com8",
			"com9",
			"lpt1",
			"lpt3",
			"lpt3",
			"lpt4",
			"lpt5",
			"lpt6",
			"lpt7",
			"lpt8",
			"lpt9"
		};
	}
}
