﻿using System;
using System.Collections;
using System.Globalization;
using System.Reflection;
using System.Text;

namespace BlueStacks.Common
{
	// Token: 0x020001BB RID: 443
	public class GetOpt
	{
		// Token: 0x06000E66 RID: 3686 RVA: 0x000377C0 File Offset: 0x000359C0
		public void Parse(string[] args)
		{
			int i = 0;
			if (args == null)
			{
				return;
			}
			while (i < args.Length)
			{
				int num = this.OptionPos(args[i]);
				if (num > 0)
				{
					if (this.GetOption(args, ref i, num))
					{
						int count = this.Count;
						this.Count = count + 1;
					}
					else
					{
						this.InvalidOption(args[Math.Min(i, args.Length - 1)]);
					}
				}
				else
				{
					if (this.Args == null)
					{
						this.Args = new ArrayList();
					}
					this.Args.Add(args[i]);
					if (!this.IsValidArg(args[i]))
					{
						this.InvalidOption(args[i]);
					}
				}
				i++;
			}
		}

		// Token: 0x170003E1 RID: 993
		// (get) Token: 0x06000E67 RID: 3687 RVA: 0x0000CDB6 File Offset: 0x0000AFB6
		public IList InvalidArgs
		{
			get
			{
				return this.mInvalidArgs;
			}
		}

		// Token: 0x170003E2 RID: 994
		// (get) Token: 0x06000E68 RID: 3688 RVA: 0x0000CDBE File Offset: 0x0000AFBE
		public bool NoArgs
		{
			get
			{
				return this.ArgCount == 0 && this.Count == 0;
			}
		}

		// Token: 0x170003E3 RID: 995
		// (get) Token: 0x06000E69 RID: 3689 RVA: 0x0000CDD3 File Offset: 0x0000AFD3
		public int ArgCount
		{
			get
			{
				if (this.Args != null)
				{
					return this.Args.Count;
				}
				return 0;
			}
		}

		// Token: 0x170003E4 RID: 996
		// (get) Token: 0x06000E6A RID: 3690 RVA: 0x0000CDEA File Offset: 0x0000AFEA
		public bool IsInValid
		{
			get
			{
				return this.IsInvalid;
			}
		}

		// Token: 0x06000E6B RID: 3691 RVA: 0x00037858 File Offset: 0x00035A58
		protected virtual int OptionPos(string opt)
		{
			if (opt == null || opt.Length < 2)
			{
				return 0;
			}
			char[] array;
			if (opt.Length > 2)
			{
				array = opt.ToCharArray(0, 3);
				if (array[0] == '-' && array[1] == '-' && this.IsOptionNameChar(array[2]))
				{
					return 2;
				}
			}
			else
			{
				array = opt.ToCharArray(0, 2);
			}
			if (array[0] == '-' && this.IsOptionNameChar(array[1]))
			{
				return 1;
			}
			return 0;
		}

		// Token: 0x06000E6C RID: 3692 RVA: 0x0000CDF2 File Offset: 0x0000AFF2
		protected virtual bool IsOptionNameChar(char c)
		{
			return char.IsLetterOrDigit(c) || c == '?';
		}

		// Token: 0x06000E6D RID: 3693 RVA: 0x0000CE03 File Offset: 0x0000B003
		protected virtual void InvalidOption(string name)
		{
			this.mInvalidArgs.Add(name);
			this.IsInvalid = true;
		}

		// Token: 0x06000E6E RID: 3694 RVA: 0x0000323B File Offset: 0x0000143B
		protected virtual bool IsValidArg(string arg)
		{
			return true;
		}

		// Token: 0x06000E6F RID: 3695 RVA: 0x000378C0 File Offset: 0x00035AC0
		protected virtual bool MatchName(MemberInfo field, string name)
		{
			object[] array = (field != null) ? field.GetCustomAttributes(typeof(ArgAttribute), true) : null;
			for (int i = 0; i < array.Length; i++)
			{
				if (string.Compare(((ArgAttribute)array[i]).Name, name, StringComparison.OrdinalIgnoreCase) == 0)
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x06000E70 RID: 3696 RVA: 0x0003790C File Offset: 0x00035B0C
		protected virtual PropertyInfo GetMemberProperty(string name)
		{
			foreach (PropertyInfo propertyInfo in base.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public))
			{
				if (string.Compare(propertyInfo.Name, name, StringComparison.OrdinalIgnoreCase) == 0)
				{
					return propertyInfo;
				}
				if (this.MatchName(propertyInfo, name))
				{
					return propertyInfo;
				}
			}
			return null;
		}

		// Token: 0x06000E71 RID: 3697 RVA: 0x00037958 File Offset: 0x00035B58
		protected virtual FieldInfo GetMemberField(string name)
		{
			foreach (FieldInfo fieldInfo in base.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public))
			{
				if (string.Compare(fieldInfo.Name, name, StringComparison.OrdinalIgnoreCase) == 0)
				{
					return fieldInfo;
				}
				if (this.MatchName(fieldInfo, name))
				{
					return fieldInfo;
				}
			}
			return null;
		}

		// Token: 0x06000E72 RID: 3698 RVA: 0x000379A4 File Offset: 0x00035BA4
		protected virtual object GetOptionValue(MemberInfo field)
		{
			object[] array = (field != null) ? field.GetCustomAttributes(typeof(ArgAttribute), true) : null;
			object[] array2 = array;
			for (int i = 0; i < array2.Length; i++)
			{
				Console.WriteLine(array2[i]);
			}
			if (array.Length != 0)
			{
				return ((ArgAttribute)array[0]).Value;
			}
			return null;
		}

		// Token: 0x06000E73 RID: 3699 RVA: 0x000379F4 File Offset: 0x00035BF4
		protected virtual bool GetOption(string[] args, ref int index, int pos)
		{
			try
			{
				object obj = null;
				string text;
				if (args == null)
				{
					text = null;
				}
				else
				{
					string text2 = args[index];
					text = ((text2 != null) ? text2.Substring(pos, args[index].Length - pos) : null);
				}
				string name = text;
				this.SplitOptionAndValue(ref name, ref obj);
				FieldInfo memberField = this.GetMemberField(name);
				if (memberField != null)
				{
					object obj2 = this.GetOptionValue(memberField);
					if (obj2 == null)
					{
						if (memberField.FieldType == typeof(bool))
						{
							obj2 = true;
						}
						else if (memberField.FieldType == typeof(string))
						{
							object obj3;
							if (obj == null)
							{
								int num = index + 1;
								index = num;
								obj3 = args[num];
							}
							else
							{
								obj3 = obj;
							}
							obj2 = obj3;
							memberField.SetValue(this, Convert.ChangeType(obj2, memberField.FieldType, CultureInfo.InvariantCulture));
							string text3 = (string)obj2;
							if (text3 == null || text3.Length == 0)
							{
								return false;
							}
							return true;
						}
						else if (memberField.FieldType.IsEnum)
						{
							obj2 = Enum.Parse(memberField.FieldType, (string)obj, true);
						}
						else
						{
							object obj4;
							if (obj == null)
							{
								int num = index + 1;
								index = num;
								obj4 = args[num];
							}
							else
							{
								obj4 = obj;
							}
							obj2 = obj4;
						}
					}
					memberField.SetValue(this, Convert.ChangeType(obj2, memberField.FieldType, CultureInfo.InvariantCulture));
					return true;
				}
				PropertyInfo memberProperty = this.GetMemberProperty(name);
				if (memberProperty != null)
				{
					object obj5 = this.GetOptionValue(memberProperty);
					if (obj5 == null)
					{
						if (memberProperty.PropertyType == typeof(bool))
						{
							obj5 = true;
						}
						else if (memberProperty.PropertyType == typeof(string))
						{
							object obj6;
							if (obj == null)
							{
								int num = index + 1;
								index = num;
								obj6 = args[num];
							}
							else
							{
								obj6 = obj;
							}
							obj5 = obj6;
							memberProperty.SetValue(this, Convert.ChangeType(obj5, memberProperty.PropertyType, CultureInfo.InvariantCulture), null);
							string text4 = (string)obj5;
							if (text4 == null || text4.Length == 0)
							{
								return false;
							}
							return true;
						}
						else if (memberProperty.PropertyType.IsEnum)
						{
							obj5 = Enum.Parse(memberProperty.PropertyType, (string)obj, true);
						}
						else
						{
							object obj7;
							if (obj == null)
							{
								int num = index + 1;
								index = num;
								obj7 = args[num];
							}
							else
							{
								obj7 = obj;
							}
							obj5 = obj7;
						}
					}
					memberProperty.SetValue(this, Convert.ChangeType(obj5, memberProperty.PropertyType, CultureInfo.InvariantCulture), null);
					return true;
				}
			}
			catch (Exception)
			{
			}
			return false;
		}

		// Token: 0x06000E74 RID: 3700 RVA: 0x00037C4C File Offset: 0x00035E4C
		protected virtual void SplitOptionAndValue(ref string opt, ref object val)
		{
			int num = -1;
			if (opt != null)
			{
				num = opt.IndexOfAny(new char[]
				{
					':',
					'='
				});
			}
			if (num < 1)
			{
				return;
			}
			val = opt.Substring(num + 1);
			opt = opt.Substring(0, num);
		}

		// Token: 0x06000E75 RID: 3701 RVA: 0x0000CE19 File Offset: 0x0000B019
		public virtual void Help()
		{
			Console.WriteLine(this.GetHelpText());
		}

		// Token: 0x06000E76 RID: 3702 RVA: 0x00037C94 File Offset: 0x00035E94
		public virtual string GetHelpText()
		{
			StringBuilder stringBuilder = new StringBuilder();
			FieldInfo[] fields = base.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public);
			char c = '-';
			foreach (FieldInfo fieldInfo in fields)
			{
				object[] customAttributes = fieldInfo.GetCustomAttributes(typeof(ArgAttribute), true);
				if (customAttributes.Length != 0)
				{
					ArgAttribute argAttribute = (ArgAttribute)customAttributes[0];
					if (argAttribute.Description != null)
					{
						string text = "";
						if (argAttribute.Value == null)
						{
							if (fieldInfo.FieldType == typeof(int))
							{
								text = "[Integer]";
							}
							else if (fieldInfo.FieldType == typeof(float))
							{
								text = "[Float]";
							}
							else if (fieldInfo.FieldType == typeof(string))
							{
								text = "[String]";
							}
							else if (fieldInfo.FieldType == typeof(bool))
							{
								text = "[Boolean]";
							}
						}
						stringBuilder.AppendFormat("{0}{1,-20}\n\t{2}", c, fieldInfo.Name + text, argAttribute.Description);
						if (argAttribute.Name != null)
						{
							stringBuilder.AppendFormat(" (Name format: {0}{1}{2})", c, argAttribute.Name, text);
						}
						stringBuilder.Append(Environment.NewLine);
					}
				}
			}
			return stringBuilder.ToString();
		}

		// Token: 0x170003E5 RID: 997
		// (get) Token: 0x06000E77 RID: 3703 RVA: 0x0000CE26 File Offset: 0x0000B026
		// (set) Token: 0x06000E78 RID: 3704 RVA: 0x0000CE2E File Offset: 0x0000B02E
		protected ArrayList Args { get; set; }

		// Token: 0x170003E6 RID: 998
		// (get) Token: 0x06000E79 RID: 3705 RVA: 0x0000CE37 File Offset: 0x0000B037
		// (set) Token: 0x06000E7A RID: 3706 RVA: 0x0000CE3F File Offset: 0x0000B03F
		protected bool IsInvalid { get; set; }

		// Token: 0x170003E7 RID: 999
		// (get) Token: 0x06000E7B RID: 3707 RVA: 0x0000CE48 File Offset: 0x0000B048
		// (set) Token: 0x06000E7C RID: 3708 RVA: 0x0000CE50 File Offset: 0x0000B050
		public int Count { get; set; }

		// Token: 0x04000944 RID: 2372
		private ArrayList mInvalidArgs = new ArrayList();
	}
}
