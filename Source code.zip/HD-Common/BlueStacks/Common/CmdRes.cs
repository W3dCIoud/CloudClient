﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000135 RID: 309
	public class CmdRes
	{
		// Token: 0x17000361 RID: 865
		// (get) Token: 0x06000A9A RID: 2714 RVA: 0x0000AFD7 File Offset: 0x000091D7
		// (set) Token: 0x06000A9B RID: 2715 RVA: 0x0000AFDF File Offset: 0x000091DF
		public string StdOut { get; set; } = string.Empty;

		// Token: 0x17000362 RID: 866
		// (get) Token: 0x06000A9C RID: 2716 RVA: 0x0000AFE8 File Offset: 0x000091E8
		// (set) Token: 0x06000A9D RID: 2717 RVA: 0x0000AFF0 File Offset: 0x000091F0
		public string StdErr { get; set; } = string.Empty;

		// Token: 0x17000363 RID: 867
		// (get) Token: 0x06000A9E RID: 2718 RVA: 0x0000AFF9 File Offset: 0x000091F9
		// (set) Token: 0x06000A9F RID: 2719 RVA: 0x0000B001 File Offset: 0x00009201
		public int ExitCode { get; set; }
	}
}
