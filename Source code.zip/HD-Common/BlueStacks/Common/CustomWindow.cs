﻿using System;
using System.Windows;
using System.Windows.Interop;

namespace BlueStacks.Common
{
	// Token: 0x020001D8 RID: 472
	public class CustomWindow : Window
	{
		// Token: 0x170003F5 RID: 1013
		// (get) Token: 0x06000F21 RID: 3873 RVA: 0x0000D3A2 File Offset: 0x0000B5A2
		// (set) Token: 0x06000F22 RID: 3874 RVA: 0x0000D3AA File Offset: 0x0000B5AA
		public bool IsClosed { get; private set; }

		// Token: 0x170003F6 RID: 1014
		// (get) Token: 0x06000F23 RID: 3875 RVA: 0x0000D3B3 File Offset: 0x0000B5B3
		// (set) Token: 0x06000F24 RID: 3876 RVA: 0x0000D3BB File Offset: 0x0000B5BB
		public virtual bool ShowWithParentWindow
		{
			get
			{
				return this.mShowWithParentWindow;
			}
			set
			{
				this.mShowWithParentWindow = value;
			}
		}

		// Token: 0x170003F7 RID: 1015
		// (get) Token: 0x06000F25 RID: 3877 RVA: 0x0000D3C4 File Offset: 0x0000B5C4
		// (set) Token: 0x06000F26 RID: 3878 RVA: 0x0000D3CC File Offset: 0x0000B5CC
		public bool IsShowGLWindow { get; set; }

		// Token: 0x06000F27 RID: 3879 RVA: 0x0000D3D5 File Offset: 0x0000B5D5
		public CustomWindow()
		{
			this.SetWindowTitle();
			base.SourceInitialized += this.CustomWindow_SourceInitialized;
		}

		// Token: 0x06000F28 RID: 3880 RVA: 0x0000D3F5 File Offset: 0x0000B5F5
		private void SetWindowTitle()
		{
			base.Title = base.GetType().Name;
		}

		// Token: 0x06000F29 RID: 3881 RVA: 0x00005ECD File Offset: 0x000040CD
		private void CustomWindow_SourceInitialized(object sender, EventArgs e)
		{
			RenderHelper.ChangeRenderModeToSoftware(sender);
		}

		// Token: 0x06000F2A RID: 3882 RVA: 0x0003A7D0 File Offset: 0x000389D0
		protected override void OnSourceInitialized(EventArgs e)
		{
			base.OnSourceInitialized(e);
			HwndSource hwndSource = PresentationSource.FromVisual(this) as HwndSource;
			if (hwndSource != null)
			{
				hwndSource.AddHook(new HwndSourceHook(CustomWindow.WndProc));
			}
		}

		// Token: 0x06000F2B RID: 3883 RVA: 0x0003A808 File Offset: 0x00038A08
		private static IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
		{
			if (msg == 260 && (wParam == (IntPtr)18 || wParam == (IntPtr)121))
			{
				handled = true;
			}
			if (msg == 262 && wParam == (IntPtr)32)
			{
				handled = true;
			}
			return IntPtr.Zero;
		}

		// Token: 0x06000F2C RID: 3884 RVA: 0x0000D408 File Offset: 0x0000B608
		protected override void OnClosed(EventArgs e)
		{
			this.IsClosed = true;
			base.OnClosed(e);
		}

		// Token: 0x040009E0 RID: 2528
		private bool mShowWithParentWindow;
	}
}
