﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000E5 RID: 229
	public class ChangeOrientationEventArgs : EventArgs
	{
		// Token: 0x17000195 RID: 405
		// (get) Token: 0x06000634 RID: 1588 RVA: 0x00005B34 File Offset: 0x00003D34
		// (set) Token: 0x06000635 RID: 1589 RVA: 0x00005B3C File Offset: 0x00003D3C
		public bool IsPotrait { get; set; }

		// Token: 0x06000636 RID: 1590 RVA: 0x00005B45 File Offset: 0x00003D45
		public ChangeOrientationEventArgs(bool isPotrait)
		{
			this.IsPotrait = isPotrait;
		}
	}
}
