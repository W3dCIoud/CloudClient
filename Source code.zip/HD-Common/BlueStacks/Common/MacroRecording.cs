﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using Newtonsoft.Json;

namespace BlueStacks.Common
{
	// Token: 0x020000AF RID: 175
	[Serializable]
	public class MacroRecording : BiDirectionalVertex<MacroRecording>, INotifyPropertyChanged, IEquatable<MacroRecording>
	{
		// Token: 0x14000005 RID: 5
		// (add) Token: 0x06000452 RID: 1106 RVA: 0x00017EFC File Offset: 0x000160FC
		// (remove) Token: 0x06000453 RID: 1107 RVA: 0x00017F34 File Offset: 0x00016134
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06000454 RID: 1108 RVA: 0x00004794 File Offset: 0x00002994
		protected void OnPropertyChanged(string property)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged == null)
			{
				return;
			}
			propertyChanged(this, new PropertyChangedEventArgs(property));
		}

		// Token: 0x17000117 RID: 279
		// (get) Token: 0x06000455 RID: 1109 RVA: 0x000047AD File Offset: 0x000029AD
		// (set) Token: 0x06000456 RID: 1110 RVA: 0x000047B5 File Offset: 0x000029B5
		[JsonProperty("TimeCreated")]
		public string TimeCreated { get; set; }

		// Token: 0x17000118 RID: 280
		// (get) Token: 0x06000457 RID: 1111 RVA: 0x000047BE File Offset: 0x000029BE
		// (set) Token: 0x06000458 RID: 1112 RVA: 0x000047C6 File Offset: 0x000029C6
		[JsonProperty("FileName")]
		public string FileName { get; set; }

		// Token: 0x17000119 RID: 281
		// (get) Token: 0x06000459 RID: 1113 RVA: 0x000047CF File Offset: 0x000029CF
		// (set) Token: 0x0600045A RID: 1114 RVA: 0x000047D7 File Offset: 0x000029D7
		[JsonProperty("Name")]
		public string Name { get; set; } = string.Empty;

		// Token: 0x1700011A RID: 282
		// (get) Token: 0x0600045B RID: 1115 RVA: 0x000047E0 File Offset: 0x000029E0
		// (set) Token: 0x0600045C RID: 1116 RVA: 0x000047E8 File Offset: 0x000029E8
		[JsonProperty("Events", DefaultValueHandling = DefaultValueHandling.IgnoreAndPopulate, NullValueHandling = NullValueHandling.Include)]
		public List<MacroEvents> Events { get; set; }

		// Token: 0x1700011B RID: 283
		// (get) Token: 0x0600045D RID: 1117 RVA: 0x000047F1 File Offset: 0x000029F1
		// (set) Token: 0x0600045E RID: 1118 RVA: 0x000047F9 File Offset: 0x000029F9
		[JsonProperty("SourceRecordings", NullValueHandling = NullValueHandling.Ignore)]
		public List<string> SourceRecordings { get; set; }

		// Token: 0x1700011C RID: 284
		// (get) Token: 0x0600045F RID: 1119 RVA: 0x00004802 File Offset: 0x00002A02
		// (set) Token: 0x06000460 RID: 1120 RVA: 0x0000480A File Offset: 0x00002A0A
		[JsonProperty("MergedMacroConfigurations", NullValueHandling = NullValueHandling.Ignore)]
		public ObservableCollection<MergedMacroConfiguration> MergedMacroConfigurations { get; set; }

		// Token: 0x1700011D RID: 285
		// (get) Token: 0x06000461 RID: 1121 RVA: 0x00004813 File Offset: 0x00002A13
		// (set) Token: 0x06000462 RID: 1122 RVA: 0x0000481B File Offset: 0x00002A1B
		[JsonProperty("LoopType")]
		public OperationsLoopType LoopType { get; set; }

		// Token: 0x1700011E RID: 286
		// (get) Token: 0x06000463 RID: 1123 RVA: 0x00004824 File Offset: 0x00002A24
		[JsonIgnore]
		public RecordingTypes RecordingType
		{
			get
			{
				if (this.Events != null)
				{
					return RecordingTypes.SingleRecording;
				}
				return RecordingTypes.MultiRecording;
			}
		}

		// Token: 0x1700011F RID: 287
		// (get) Token: 0x06000464 RID: 1124 RVA: 0x00004831 File Offset: 0x00002A31
		// (set) Token: 0x06000465 RID: 1125 RVA: 0x00004839 File Offset: 0x00002A39
		[JsonProperty("LoopNumber")]
		public int LoopNumber { get; set; } = 1;

		// Token: 0x17000120 RID: 288
		// (get) Token: 0x06000466 RID: 1126 RVA: 0x00004842 File Offset: 0x00002A42
		// (set) Token: 0x06000467 RID: 1127 RVA: 0x0000484A File Offset: 0x00002A4A
		[JsonProperty("LoopTime")]
		public int LoopTime { get; set; }

		// Token: 0x17000121 RID: 289
		// (get) Token: 0x06000468 RID: 1128 RVA: 0x00004853 File Offset: 0x00002A53
		// (set) Token: 0x06000469 RID: 1129 RVA: 0x0000485B File Offset: 0x00002A5B
		[JsonProperty("LoopInterval")]
		public int LoopInterval { get; set; }

		// Token: 0x17000122 RID: 290
		// (get) Token: 0x0600046A RID: 1130 RVA: 0x00004864 File Offset: 0x00002A64
		// (set) Token: 0x0600046B RID: 1131 RVA: 0x0000486C File Offset: 0x00002A6C
		[JsonProperty("Acceleration")]
		public double Acceleration { get; set; } = 1.0;

		// Token: 0x17000123 RID: 291
		// (get) Token: 0x0600046C RID: 1132 RVA: 0x00004875 File Offset: 0x00002A75
		// (set) Token: 0x0600046D RID: 1133 RVA: 0x0000487D File Offset: 0x00002A7D
		[JsonProperty("PlayOnStart")]
		public bool PlayOnStart { get; set; }

		// Token: 0x17000124 RID: 292
		// (get) Token: 0x0600046E RID: 1134 RVA: 0x00004886 File Offset: 0x00002A86
		// (set) Token: 0x0600046F RID: 1135 RVA: 0x0000488E File Offset: 0x00002A8E
		[JsonProperty("DonotShowWindowOnFinish")]
		public bool DonotShowWindowOnFinish { get; set; }

		// Token: 0x17000125 RID: 293
		// (get) Token: 0x06000470 RID: 1136 RVA: 0x00004897 File Offset: 0x00002A97
		// (set) Token: 0x06000471 RID: 1137 RVA: 0x0000489F File Offset: 0x00002A9F
		[JsonProperty("RestartPlayer")]
		public bool RestartPlayer { get; set; }

		// Token: 0x17000126 RID: 294
		// (get) Token: 0x06000472 RID: 1138 RVA: 0x000048A8 File Offset: 0x00002AA8
		// (set) Token: 0x06000473 RID: 1139 RVA: 0x000048B0 File Offset: 0x00002AB0
		[JsonProperty("RestartPlayerAfterMinutes")]
		public int RestartPlayerAfterMinutes { get; set; } = 60;

		// Token: 0x17000127 RID: 295
		// (get) Token: 0x06000474 RID: 1140 RVA: 0x000048B9 File Offset: 0x00002AB9
		// (set) Token: 0x06000475 RID: 1141 RVA: 0x000048C1 File Offset: 0x00002AC1
		[JsonProperty("ShortCut")]
		public string Shortcut { get; set; } = string.Empty;

		// Token: 0x17000128 RID: 296
		// (get) Token: 0x06000476 RID: 1142 RVA: 0x000048CA File Offset: 0x00002ACA
		// (set) Token: 0x06000477 RID: 1143 RVA: 0x000048D2 File Offset: 0x00002AD2
		[JsonProperty("UserName", NullValueHandling = NullValueHandling.Ignore)]
		public string User { get; set; } = string.Empty;

		// Token: 0x17000129 RID: 297
		// (get) Token: 0x06000478 RID: 1144 RVA: 0x000048DB File Offset: 0x00002ADB
		// (set) Token: 0x06000479 RID: 1145 RVA: 0x000048E3 File Offset: 0x00002AE3
		[JsonProperty("AuthorPageUrl", NullValueHandling = NullValueHandling.Ignore)]
		public Uri AuthorPageUrl { get; set; }

		// Token: 0x1700012A RID: 298
		// (get) Token: 0x0600047A RID: 1146 RVA: 0x000048EC File Offset: 0x00002AEC
		// (set) Token: 0x0600047B RID: 1147 RVA: 0x000048F4 File Offset: 0x00002AF4
		[JsonProperty("MacroId", NullValueHandling = NullValueHandling.Ignore)]
		public string MacroId { get; set; } = string.Empty;

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x0600047C RID: 1148 RVA: 0x000048FD File Offset: 0x00002AFD
		// (set) Token: 0x0600047D RID: 1149 RVA: 0x00004905 File Offset: 0x00002B05
		[JsonProperty("MacroPageUrl", NullValueHandling = NullValueHandling.Ignore)]
		public Uri MacroPageUrl { get; set; }

		// Token: 0x0600047E RID: 1150 RVA: 0x0000490E File Offset: 0x00002B0E
		public bool Equals(MacroRecording other)
		{
			return other != null && string.Equals(this.Name, other.Name, StringComparison.InvariantCultureIgnoreCase);
		}

		// Token: 0x0600047F RID: 1151 RVA: 0x00004927 File Offset: 0x00002B27
		public override bool Equals(object obj)
		{
			return this.Equals(obj as MacroRecording);
		}

		// Token: 0x06000480 RID: 1152 RVA: 0x00004935 File Offset: 0x00002B35
		public override int GetHashCode()
		{
			return this.Name.GetHashCode();
		}

		// Token: 0x06000481 RID: 1153 RVA: 0x00017F6C File Offset: 0x0001616C
		public void CopyFrom(MacroRecording previous)
		{
			if (previous != null)
			{
				this.TimeCreated = previous.TimeCreated;
				this.Name = previous.Name;
				List<MacroEvents> events = previous.Events;
				this.Events = ((events != null) ? events.DeepCopy<List<MacroEvents>>() : null);
				List<string> sourceRecordings = previous.SourceRecordings;
				this.SourceRecordings = ((sourceRecordings != null) ? sourceRecordings.DeepCopy<List<string>>() : null);
				this.MergedMacroConfigurations = JsonConvert.DeserializeObject<ObservableCollection<MergedMacroConfiguration>>(JsonConvert.SerializeObject(previous.MergedMacroConfigurations, Utils.GetSerializerSettings()), Utils.GetSerializerSettings());
				this.LoopType = previous.LoopType;
				this.LoopNumber = previous.LoopNumber;
				this.LoopTime = previous.LoopTime;
				this.LoopInterval = previous.LoopInterval;
				this.Acceleration = previous.Acceleration;
				this.PlayOnStart = previous.PlayOnStart;
				this.RestartPlayer = previous.RestartPlayer;
				this.RestartPlayerAfterMinutes = previous.RestartPlayerAfterMinutes;
				this.DonotShowWindowOnFinish = previous.DonotShowWindowOnFinish;
				this.Shortcut = previous.Shortcut;
				MacroGraph.Instance.DeLinkMacroChild(this);
			}
		}
	}
}
