﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace BlueStacks.Common
{
	// Token: 0x020000C7 RID: 199
	public class InverseBooleanConverter : IValueConverter
	{
		// Token: 0x060004E6 RID: 1254 RVA: 0x00004E99 File Offset: 0x00003099
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			if (value is bool)
			{
				return !(bool)value;
			}
			return false;
		}

		// Token: 0x060004E7 RID: 1255 RVA: 0x00004EB8 File Offset: 0x000030B8
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			throw new NotImplementedException("ConvertBack() of BoolToInvertedBoolConverter is not implemented");
		}
	}
}
