﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001C6 RID: 454
	public static class InstallerArchitectures
	{
		// Token: 0x170003F1 RID: 1009
		// (get) Token: 0x06000EB7 RID: 3767 RVA: 0x0000CF7F File Offset: 0x0000B17F
		public static string AMD64
		{
			get
			{
				return "amd64";
			}
		}

		// Token: 0x170003F2 RID: 1010
		// (get) Token: 0x06000EB8 RID: 3768 RVA: 0x0000CF86 File Offset: 0x0000B186
		public static string X86
		{
			get
			{
				return "x86";
			}
		}
	}
}
