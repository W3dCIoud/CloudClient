﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000108 RID: 264
	public enum InstanceType
	{
		// Token: 0x04000486 RID: 1158
		engg,
		// Token: 0x04000487 RID: 1159
		preprod,
		// Token: 0x04000488 RID: 1160
		dev,
		// Token: 0x04000489 RID: 1161
		qa,
		// Token: 0x0400048A RID: 1162
		prod
	}
}
