﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace BlueStacks.Common
{
	// Token: 0x020000B2 RID: 178
	[Serializable]
	public class MacroEvents
	{
		// Token: 0x1700013A RID: 314
		// (get) Token: 0x060004A5 RID: 1189 RVA: 0x00004AD8 File Offset: 0x00002CD8
		// (set) Token: 0x060004A6 RID: 1190 RVA: 0x00004AE0 File Offset: 0x00002CE0
		[JsonProperty("Timestamp", NullValueHandling = NullValueHandling.Ignore)]
		public long Timestamp { get; set; }

		// Token: 0x1700013B RID: 315
		// (get) Token: 0x060004A7 RID: 1191 RVA: 0x00004AE9 File Offset: 0x00002CE9
		// (set) Token: 0x060004A8 RID: 1192 RVA: 0x00004AF1 File Offset: 0x00002CF1
		[JsonExtensionData]
		public IDictionary<string, object> ExtraData { get; set; }
	}
}
