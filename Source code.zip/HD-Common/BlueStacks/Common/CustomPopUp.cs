﻿using System;
using System.Windows.Controls.Primitives;

namespace BlueStacks.Common
{
	// Token: 0x020000EA RID: 234
	public class CustomPopUp : Popup
	{
		// Token: 0x06000675 RID: 1653 RVA: 0x00005EB3 File Offset: 0x000040B3
		public CustomPopUp()
		{
			base.Opened += this.CustomPopUp_Initialized;
		}

		// Token: 0x06000676 RID: 1654 RVA: 0x00005ECD File Offset: 0x000040CD
		private void CustomPopUp_Initialized(object sender, EventArgs e)
		{
			RenderHelper.ChangeRenderModeToSoftware(sender);
		}
	}
}
