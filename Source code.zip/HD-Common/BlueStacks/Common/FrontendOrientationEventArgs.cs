﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000E4 RID: 228
	public class FrontendOrientationEventArgs : EventArgs
	{
		// Token: 0x17000193 RID: 403
		// (get) Token: 0x0600062F RID: 1583 RVA: 0x00005AF1 File Offset: 0x00003CF1
		// (set) Token: 0x06000630 RID: 1584 RVA: 0x00005AF9 File Offset: 0x00003CF9
		public bool IsPotrait { get; set; }

		// Token: 0x17000194 RID: 404
		// (get) Token: 0x06000631 RID: 1585 RVA: 0x00005B02 File Offset: 0x00003D02
		// (set) Token: 0x06000632 RID: 1586 RVA: 0x00005B0A File Offset: 0x00003D0A
		public string PackageName { get; set; } = string.Empty;

		// Token: 0x06000633 RID: 1587 RVA: 0x00005B13 File Offset: 0x00003D13
		public FrontendOrientationEventArgs(bool isPotrait, string packageName)
		{
			this.IsPotrait = isPotrait;
			this.PackageName = packageName;
		}
	}
}
