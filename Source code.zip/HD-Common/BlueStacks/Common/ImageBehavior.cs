﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Resources;
using BlueStacks.Common.Decoding;

namespace BlueStacks.Common
{
	// Token: 0x02000185 RID: 389
	public static class ImageBehavior
	{
		// Token: 0x06000D5C RID: 3420 RVA: 0x0000C388 File Offset: 0x0000A588
		[AttachedPropertyBrowsableForType(typeof(Image))]
		public static ImageSource GetAnimatedSource(Image obj)
		{
			return (ImageSource)((obj != null) ? obj.GetValue(ImageBehavior.AnimatedSourceProperty) : null);
		}

		// Token: 0x06000D5D RID: 3421 RVA: 0x0000C3A0 File Offset: 0x0000A5A0
		public static void SetAnimatedSource(Image obj, ImageSource value)
		{
			if (obj != null)
			{
				obj.SetValue(ImageBehavior.AnimatedSourceProperty, value);
			}
		}

		// Token: 0x06000D5E RID: 3422 RVA: 0x0000C3B1 File Offset: 0x0000A5B1
		[AttachedPropertyBrowsableForType(typeof(Image))]
		public static RepeatBehavior GetRepeatBehavior(Image obj)
		{
			return (RepeatBehavior)((obj != null) ? obj.GetValue(ImageBehavior.RepeatBehaviorProperty) : null);
		}

		// Token: 0x06000D5F RID: 3423 RVA: 0x0000C3C9 File Offset: 0x0000A5C9
		public static void SetRepeatBehavior(Image obj, RepeatBehavior value)
		{
			if (obj != null)
			{
				obj.SetValue(ImageBehavior.RepeatBehaviorProperty, value);
			}
		}

		// Token: 0x06000D60 RID: 3424 RVA: 0x0000C3DF File Offset: 0x0000A5DF
		public static bool GetAnimateInDesignMode(DependencyObject obj)
		{
			return (bool)((obj != null) ? obj.GetValue(ImageBehavior.AnimateInDesignModeProperty) : null);
		}

		// Token: 0x06000D61 RID: 3425 RVA: 0x0000C3F7 File Offset: 0x0000A5F7
		public static void SetAnimateInDesignMode(DependencyObject obj, bool value)
		{
			if (obj != null)
			{
				obj.SetValue(ImageBehavior.AnimateInDesignModeProperty, value);
			}
		}

		// Token: 0x06000D62 RID: 3426 RVA: 0x0000C40D File Offset: 0x0000A60D
		[AttachedPropertyBrowsableForType(typeof(Image))]
		public static bool GetAutoStart(Image obj)
		{
			return (bool)((obj != null) ? obj.GetValue(ImageBehavior.AutoStartProperty) : null);
		}

		// Token: 0x06000D63 RID: 3427 RVA: 0x0000C425 File Offset: 0x0000A625
		public static void SetAutoStart(Image obj, bool value)
		{
			if (obj != null)
			{
				obj.SetValue(ImageBehavior.AutoStartProperty, value);
			}
		}

		// Token: 0x06000D64 RID: 3428 RVA: 0x0000C43B File Offset: 0x0000A63B
		public static ImageAnimationController GetAnimationController(Image imageControl)
		{
			return (ImageAnimationController)((imageControl != null) ? imageControl.GetValue(ImageBehavior.AnimationControllerPropertyKey.DependencyProperty) : null);
		}

		// Token: 0x06000D65 RID: 3429 RVA: 0x0000C458 File Offset: 0x0000A658
		private static void SetAnimationController(DependencyObject obj, ImageAnimationController value)
		{
			if (obj != null)
			{
				obj.SetValue(ImageBehavior.AnimationControllerPropertyKey, value);
			}
		}

		// Token: 0x06000D66 RID: 3430 RVA: 0x0000C469 File Offset: 0x0000A669
		public static bool GetIsAnimationLoaded(Image image)
		{
			return (bool)((image != null) ? image.GetValue(ImageBehavior.IsAnimationLoadedProperty) : null);
		}

		// Token: 0x06000D67 RID: 3431 RVA: 0x0000C481 File Offset: 0x0000A681
		private static void SetIsAnimationLoaded(Image image, bool value)
		{
			image.SetValue(ImageBehavior.IsAnimationLoadedPropertyKey, value);
		}

		// Token: 0x06000D68 RID: 3432 RVA: 0x0000C494 File Offset: 0x0000A694
		public static void AddAnimationLoadedHandler(Image image, RoutedEventHandler handler)
		{
			if (image == null)
			{
				throw new ArgumentNullException("image");
			}
			if (handler == null)
			{
				throw new ArgumentNullException("handler");
			}
			image.AddHandler(ImageBehavior.AnimationLoadedEvent, handler);
		}

		// Token: 0x06000D69 RID: 3433 RVA: 0x0000C4BE File Offset: 0x0000A6BE
		public static void RemoveAnimationLoadedHandler(Image image, RoutedEventHandler handler)
		{
			if (image == null)
			{
				throw new ArgumentNullException("image");
			}
			if (handler == null)
			{
				throw new ArgumentNullException("handler");
			}
			image.RemoveHandler(ImageBehavior.AnimationLoadedEvent, handler);
		}

		// Token: 0x06000D6A RID: 3434 RVA: 0x000348F8 File Offset: 0x00032AF8
		public static void AddAnimationCompletedHandler(Image d, RoutedEventHandler handler)
		{
			if (d == null)
			{
				return;
			}
			d.AddHandler(ImageBehavior.AnimationCompletedEvent, handler);
		}

		// Token: 0x06000D6B RID: 3435 RVA: 0x00034918 File Offset: 0x00032B18
		public static void RemoveAnimationCompletedHandler(Image d, RoutedEventHandler handler)
		{
			if (d == null)
			{
				return;
			}
			d.RemoveHandler(ImageBehavior.AnimationCompletedEvent, handler);
		}

		// Token: 0x06000D6C RID: 3436 RVA: 0x00034938 File Offset: 0x00032B38
		private static void AnimatedSourceChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
		{
			Image image = o as Image;
			if (image == null)
			{
				return;
			}
			ImageSource imageSource = e.OldValue as ImageSource;
			ImageSource imageSource2 = e.NewValue as ImageSource;
			if (imageSource == imageSource2)
			{
				return;
			}
			if (imageSource != null)
			{
				image.Loaded -= ImageBehavior.ImageControlLoaded;
				image.Unloaded -= ImageBehavior.ImageControlUnloaded;
				AnimationCache.DecrementReferenceCount(imageSource, ImageBehavior.GetRepeatBehavior(image));
				ImageAnimationController animationController = ImageBehavior.GetAnimationController(image);
				if (animationController != null)
				{
					animationController.Dispose();
				}
				image.Source = null;
			}
			if (imageSource2 != null)
			{
				image.Loaded += ImageBehavior.ImageControlLoaded;
				image.Unloaded += ImageBehavior.ImageControlUnloaded;
				if (image.IsLoaded)
				{
					ImageBehavior.InitAnimationOrImage(image);
				}
			}
		}

		// Token: 0x06000D6D RID: 3437 RVA: 0x000349F0 File Offset: 0x00032BF0
		private static void ImageControlLoaded(object sender, RoutedEventArgs e)
		{
			Image image = sender as Image;
			if (image == null)
			{
				return;
			}
			ImageBehavior.InitAnimationOrImage(image);
		}

		// Token: 0x06000D6E RID: 3438 RVA: 0x00034A10 File Offset: 0x00032C10
		private static void ImageControlUnloaded(object sender, RoutedEventArgs e)
		{
			Image image = sender as Image;
			if (image == null)
			{
				return;
			}
			ImageSource animatedSource = ImageBehavior.GetAnimatedSource(image);
			if (animatedSource != null)
			{
				AnimationCache.DecrementReferenceCount(animatedSource, ImageBehavior.GetRepeatBehavior(image));
			}
			ImageAnimationController animationController = ImageBehavior.GetAnimationController(image);
			if (animationController != null)
			{
				animationController.Dispose();
			}
		}

		// Token: 0x06000D6F RID: 3439 RVA: 0x00034A50 File Offset: 0x00032C50
		private static void RepeatBehaviorChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
		{
			Image image = o as Image;
			if (image == null)
			{
				return;
			}
			ImageSource animatedSource = ImageBehavior.GetAnimatedSource(image);
			if (animatedSource != null)
			{
				if (!object.Equals(e.OldValue, e.NewValue))
				{
					AnimationCache.DecrementReferenceCount(animatedSource, (RepeatBehavior)e.OldValue);
				}
				if (image.IsLoaded)
				{
					ImageBehavior.InitAnimationOrImage(image);
				}
			}
		}

		// Token: 0x06000D70 RID: 3440 RVA: 0x00034AA8 File Offset: 0x00032CA8
		private static void AnimateInDesignModeChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
		{
			Image image = o as Image;
			if (image == null)
			{
				return;
			}
			bool flag = (bool)e.NewValue;
			if (ImageBehavior.GetAnimatedSource(image) != null && image.IsLoaded)
			{
				if (flag)
				{
					ImageBehavior.InitAnimationOrImage(image);
					return;
				}
				image.BeginAnimation(Image.SourceProperty, null);
			}
		}

		// Token: 0x06000D71 RID: 3441 RVA: 0x00034AF4 File Offset: 0x00032CF4
		private static void InitAnimationOrImage(Image imageControl)
		{
			ImageBehavior.SetAnimationController(imageControl, null);
			ImageBehavior.SetIsAnimationLoaded(imageControl, false);
			BitmapSource source = ImageBehavior.GetAnimatedSource(imageControl) as BitmapSource;
			int isInDesignMode = DesignerProperties.GetIsInDesignMode(imageControl) ? 1 : 0;
			bool animateInDesignMode = ImageBehavior.GetAnimateInDesignMode(imageControl);
			bool flag = isInDesignMode == 0 || animateInDesignMode;
			bool flag2 = ImageBehavior.IsLoadingDeferred(source);
			if (source != null && flag && !flag2)
			{
				if (source.IsDownloading)
				{
					EventHandler handler = null;
					handler = delegate(object sender, EventArgs args)
					{
						source.DownloadCompleted -= handler;
						ImageBehavior.InitAnimationOrImage(imageControl);
					};
					source.DownloadCompleted += handler;
					imageControl.Source = source;
					return;
				}
				ObjectAnimationUsingKeyFrames animation = ImageBehavior.GetAnimation(imageControl, source);
				if (animation != null)
				{
					if (animation.KeyFrames.Count > 0)
					{
						ImageBehavior.TryTwice(delegate
						{
							imageControl.Source = (ImageSource)animation.KeyFrames[0].Value;
						});
					}
					else
					{
						imageControl.Source = source;
					}
					ImageAnimationController value = new ImageAnimationController(imageControl, animation, ImageBehavior.GetAutoStart(imageControl));
					ImageBehavior.SetAnimationController(imageControl, value);
					ImageBehavior.SetIsAnimationLoaded(imageControl, true);
					imageControl.RaiseEvent(new RoutedEventArgs(ImageBehavior.AnimationLoadedEvent, imageControl));
					return;
				}
			}
			imageControl.Source = source;
			if (source != null)
			{
				ImageBehavior.SetIsAnimationLoaded(imageControl, true);
				imageControl.RaiseEvent(new RoutedEventArgs(ImageBehavior.AnimationLoadedEvent, imageControl));
			}
		}

		// Token: 0x06000D72 RID: 3442 RVA: 0x00034CD8 File Offset: 0x00032ED8
		private static ObjectAnimationUsingKeyFrames GetAnimation(Image imageControl, BitmapSource source)
		{
			ObjectAnimationUsingKeyFrames objectAnimationUsingKeyFrames = AnimationCache.GetAnimation(source, ImageBehavior.GetRepeatBehavior(imageControl));
			if (objectAnimationUsingKeyFrames != null)
			{
				return objectAnimationUsingKeyFrames;
			}
			GifFile gifMetadata;
			GifBitmapDecoder gifBitmapDecoder = ImageBehavior.GetDecoder(source, out gifMetadata) as GifBitmapDecoder;
			if (gifBitmapDecoder != null && gifBitmapDecoder.Frames.Count > 1)
			{
				ImageBehavior.Int32Size fullSize = ImageBehavior.GetFullSize(gifBitmapDecoder, gifMetadata);
				int num = 0;
				objectAnimationUsingKeyFrames = new ObjectAnimationUsingKeyFrames();
				TimeSpan timeSpan = TimeSpan.Zero;
				BitmapSource baseFrame = null;
				foreach (BitmapFrame rawFrame in gifBitmapDecoder.Frames)
				{
					ImageBehavior.FrameMetadata frameMetadata = ImageBehavior.GetFrameMetadata(gifBitmapDecoder, gifMetadata, num);
					BitmapSource bitmapSource = ImageBehavior.MakeFrame(fullSize, rawFrame, frameMetadata, baseFrame);
					DiscreteObjectKeyFrame keyFrame = new DiscreteObjectKeyFrame(bitmapSource, timeSpan);
					objectAnimationUsingKeyFrames.KeyFrames.Add(keyFrame);
					timeSpan += frameMetadata.Delay;
					switch (frameMetadata.DisposalMethod)
					{
					case ImageBehavior.FrameDisposalMethod.None:
					case ImageBehavior.FrameDisposalMethod.DoNotDispose:
						baseFrame = bitmapSource;
						break;
					case ImageBehavior.FrameDisposalMethod.RestoreBackground:
						if (ImageBehavior.IsFullFrame(frameMetadata, fullSize))
						{
							baseFrame = null;
						}
						else
						{
							baseFrame = ImageBehavior.ClearArea(bitmapSource, frameMetadata);
						}
						break;
					}
					num++;
				}
				objectAnimationUsingKeyFrames.Duration = timeSpan;
				objectAnimationUsingKeyFrames.RepeatBehavior = ImageBehavior.GetActualRepeatBehavior(imageControl, gifBitmapDecoder, gifMetadata);
				AnimationCache.AddAnimation(source, ImageBehavior.GetRepeatBehavior(imageControl), objectAnimationUsingKeyFrames);
				AnimationCache.IncrementReferenceCount(source, ImageBehavior.GetRepeatBehavior(imageControl));
				return objectAnimationUsingKeyFrames;
			}
			return null;
		}

		// Token: 0x06000D73 RID: 3443 RVA: 0x00034E44 File Offset: 0x00033044
		private static BitmapSource ClearArea(BitmapSource frame, ImageBehavior.FrameMetadata metadata)
		{
			DrawingVisual drawingVisual = new DrawingVisual();
			using (DrawingContext drawingContext = drawingVisual.RenderOpen())
			{
				Rect rect = new Rect(0.0, 0.0, (double)frame.PixelWidth, (double)frame.PixelHeight);
				Rect rect2 = new Rect((double)metadata.Left, (double)metadata.Top, (double)metadata.Width, (double)metadata.Height);
				PathGeometry clipGeometry = Geometry.Combine(new RectangleGeometry(rect), new RectangleGeometry(rect2), GeometryCombineMode.Exclude, null);
				drawingContext.PushClip(clipGeometry);
				drawingContext.DrawImage(frame, rect);
			}
			RenderTargetBitmap renderTargetBitmap = new RenderTargetBitmap(frame.PixelWidth, frame.PixelHeight, frame.DpiX, frame.DpiY, PixelFormats.Pbgra32);
			renderTargetBitmap.Render(drawingVisual);
			if (renderTargetBitmap.CanFreeze && !renderTargetBitmap.IsFrozen)
			{
				renderTargetBitmap.Freeze();
			}
			return renderTargetBitmap;
		}

		// Token: 0x06000D74 RID: 3444 RVA: 0x00034F2C File Offset: 0x0003312C
		private static void TryTwice(Action action)
		{
			try
			{
				action();
			}
			catch (Exception)
			{
				action();
			}
		}

		// Token: 0x06000D75 RID: 3445 RVA: 0x00034F5C File Offset: 0x0003315C
		private static bool IsLoadingDeferred(BitmapSource source)
		{
			BitmapImage bitmapImage = source as BitmapImage;
			return bitmapImage != null && (bitmapImage.UriSource != null && !bitmapImage.UriSource.IsAbsoluteUri) && bitmapImage.BaseUri == null;
		}

		// Token: 0x06000D76 RID: 3446 RVA: 0x00034FA0 File Offset: 0x000331A0
		private static BitmapDecoder GetDecoder(BitmapSource image, out GifFile gifFile)
		{
			gifFile = null;
			BitmapDecoder bitmapDecoder = null;
			Stream stream = null;
			Uri uri = null;
			BitmapCreateOptions createOptions = BitmapCreateOptions.None;
			BitmapImage bitmapImage = image as BitmapImage;
			if (bitmapImage != null)
			{
				createOptions = bitmapImage.CreateOptions;
				if (bitmapImage.StreamSource != null)
				{
					stream = bitmapImage.StreamSource;
				}
				else if (bitmapImage.UriSource != null)
				{
					uri = bitmapImage.UriSource;
					if (bitmapImage.BaseUri != null && !uri.IsAbsoluteUri)
					{
						uri = new Uri(bitmapImage.BaseUri, uri);
					}
				}
			}
			else
			{
				BitmapFrame bitmapFrame = image as BitmapFrame;
				if (bitmapFrame != null)
				{
					bitmapDecoder = bitmapFrame.Decoder;
					Uri.TryCreate(bitmapFrame.BaseUri, bitmapFrame.ToString(CultureInfo.InvariantCulture), out uri);
				}
			}
			if (bitmapDecoder == null)
			{
				if (stream != null)
				{
					stream.Position = 0L;
					bitmapDecoder = BitmapDecoder.Create(stream, createOptions, BitmapCacheOption.OnLoad);
				}
				else if (uri != null && uri.IsAbsoluteUri)
				{
					bitmapDecoder = BitmapDecoder.Create(uri, createOptions, BitmapCacheOption.OnLoad);
				}
			}
			if (bitmapDecoder is GifBitmapDecoder && !ImageBehavior.CanReadNativeMetadata(bitmapDecoder))
			{
				if (stream != null)
				{
					stream.Position = 0L;
					gifFile = GifFile.ReadGifFile(stream, true);
				}
				else
				{
					if (!(uri != null))
					{
						throw new InvalidOperationException("Can't get URI or Stream from the source. AnimatedSource should be either a BitmapImage, or a BitmapFrame constructed from a URI.");
					}
					gifFile = ImageBehavior.DecodeGifFile(uri);
				}
			}
			if (bitmapDecoder == null)
			{
				throw new InvalidOperationException("Can't get a decoder from the source. AnimatedSource should be either a BitmapImage or a BitmapFrame.");
			}
			return bitmapDecoder;
		}

		// Token: 0x06000D77 RID: 3447 RVA: 0x000350D4 File Offset: 0x000332D4
		private static bool CanReadNativeMetadata(BitmapDecoder decoder)
		{
			bool result;
			try
			{
				result = (decoder.Metadata != null);
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000D78 RID: 3448 RVA: 0x00035104 File Offset: 0x00033304
		private static GifFile DecodeGifFile(Uri uri)
		{
			Stream stream = null;
			if (uri.Scheme == PackUriHelper.UriSchemePack)
			{
				StreamResourceInfo streamResourceInfo;
				if (uri.Authority == "siteoforigin:,,,")
				{
					streamResourceInfo = Application.GetRemoteStream(uri);
				}
				else
				{
					streamResourceInfo = Application.GetResourceStream(uri);
				}
				if (streamResourceInfo != null)
				{
					stream = streamResourceInfo.Stream;
				}
			}
			else
			{
				using (WebClient webClient = new WebClient())
				{
					stream = webClient.OpenRead(uri);
				}
			}
			if (stream != null)
			{
				using (stream)
				{
					return GifFile.ReadGifFile(stream, true);
				}
			}
			return null;
		}

		// Token: 0x06000D79 RID: 3449 RVA: 0x0000C4E8 File Offset: 0x0000A6E8
		private static bool IsFullFrame(ImageBehavior.FrameMetadata metadata, ImageBehavior.Int32Size fullSize)
		{
			return metadata.Left == 0 && metadata.Top == 0 && metadata.Width == fullSize.Width && metadata.Height == fullSize.Height;
		}

		// Token: 0x06000D7A RID: 3450 RVA: 0x000351A8 File Offset: 0x000333A8
		private static BitmapSource MakeFrame(ImageBehavior.Int32Size fullSize, BitmapSource rawFrame, ImageBehavior.FrameMetadata metadata, BitmapSource baseFrame)
		{
			if (baseFrame == null && ImageBehavior.IsFullFrame(metadata, fullSize))
			{
				return rawFrame;
			}
			DrawingVisual drawingVisual = new DrawingVisual();
			using (DrawingContext drawingContext = drawingVisual.RenderOpen())
			{
				if (baseFrame != null)
				{
					Rect rectangle = new Rect(0.0, 0.0, (double)fullSize.Width, (double)fullSize.Height);
					drawingContext.DrawImage(baseFrame, rectangle);
				}
				Rect rectangle2 = new Rect((double)metadata.Left, (double)metadata.Top, (double)metadata.Width, (double)metadata.Height);
				drawingContext.DrawImage(rawFrame, rectangle2);
			}
			RenderTargetBitmap renderTargetBitmap = new RenderTargetBitmap(fullSize.Width, fullSize.Height, 96.0, 96.0, PixelFormats.Pbgra32);
			renderTargetBitmap.Render(drawingVisual);
			if (renderTargetBitmap.CanFreeze && !renderTargetBitmap.IsFrozen)
			{
				renderTargetBitmap.Freeze();
			}
			return renderTargetBitmap;
		}

		// Token: 0x06000D7B RID: 3451 RVA: 0x00035298 File Offset: 0x00033498
		private static RepeatBehavior GetActualRepeatBehavior(Image imageControl, BitmapDecoder decoder, GifFile gifMetadata)
		{
			RepeatBehavior repeatBehavior = ImageBehavior.GetRepeatBehavior(imageControl);
			if (repeatBehavior != default(RepeatBehavior))
			{
				return repeatBehavior;
			}
			int repeatCount;
			if (gifMetadata != null)
			{
				repeatCount = (int)gifMetadata.RepeatCount;
			}
			else
			{
				repeatCount = ImageBehavior.GetRepeatCount(decoder);
			}
			if (repeatCount == 0)
			{
				return RepeatBehavior.Forever;
			}
			return new RepeatBehavior((double)repeatCount);
		}

		// Token: 0x06000D7C RID: 3452 RVA: 0x000352E4 File Offset: 0x000334E4
		private static int GetRepeatCount(BitmapDecoder decoder)
		{
			BitmapMetadata applicationExtension = ImageBehavior.GetApplicationExtension(decoder, "NETSCAPE2.0");
			if (applicationExtension != null)
			{
				byte[] queryOrNull = applicationExtension.GetQueryOrNull("/Data");
				if (queryOrNull != null && queryOrNull.Length >= 4)
				{
					return (int)BitConverter.ToUInt16(queryOrNull, 2);
				}
			}
			return 1;
		}

		// Token: 0x06000D7D RID: 3453 RVA: 0x00035320 File Offset: 0x00033520
		private static BitmapMetadata GetApplicationExtension(BitmapDecoder decoder, string application)
		{
			int num = 0;
			string query = "/appext";
			for (BitmapMetadata queryOrNull = decoder.Metadata.GetQueryOrNull(query); queryOrNull != null; queryOrNull = decoder.Metadata.GetQueryOrNull(query))
			{
				byte[] queryOrNull2 = queryOrNull.GetQueryOrNull("/Application");
				if (queryOrNull2 != null && Encoding.ASCII.GetString(queryOrNull2) == application)
				{
					return queryOrNull;
				}
				query = string.Format(CultureInfo.InvariantCulture, "/[{0}]appext", new object[]
				{
					++num
				});
			}
			return null;
		}

		// Token: 0x06000D7E RID: 3454 RVA: 0x0000C51A File Offset: 0x0000A71A
		private static ImageBehavior.FrameMetadata GetFrameMetadata(BitmapDecoder decoder, GifFile gifMetadata, int frameIndex)
		{
			if (gifMetadata != null && gifMetadata.Frames.Count > frameIndex)
			{
				return ImageBehavior.GetFrameMetadata(gifMetadata.Frames[frameIndex]);
			}
			return ImageBehavior.GetFrameMetadata(decoder.Frames[frameIndex]);
		}

		// Token: 0x06000D7F RID: 3455 RVA: 0x0003539C File Offset: 0x0003359C
		private static ImageBehavior.FrameMetadata GetFrameMetadata(BitmapFrame frame)
		{
			BitmapMetadata metadata = (BitmapMetadata)frame.Metadata;
			TimeSpan delay = TimeSpan.FromMilliseconds(100.0);
			int queryOrDefault = metadata.GetQueryOrDefault("/grctlext/Delay", 10);
			if (queryOrDefault != 0)
			{
				delay = TimeSpan.FromMilliseconds((double)(queryOrDefault * 10));
			}
			ImageBehavior.FrameDisposalMethod queryOrDefault2 = (ImageBehavior.FrameDisposalMethod)metadata.GetQueryOrDefault("/grctlext/Disposal", 0);
			return new ImageBehavior.FrameMetadata
			{
				Left = metadata.GetQueryOrDefault("/imgdesc/Left", 0),
				Top = metadata.GetQueryOrDefault("/imgdesc/Top", 0),
				Width = metadata.GetQueryOrDefault("/imgdesc/Width", frame.PixelWidth),
				Height = metadata.GetQueryOrDefault("/imgdesc/Height", frame.PixelHeight),
				Delay = delay,
				DisposalMethod = queryOrDefault2
			};
		}

		// Token: 0x06000D80 RID: 3456 RVA: 0x00035454 File Offset: 0x00033654
		private static ImageBehavior.FrameMetadata GetFrameMetadata(GifFrame gifMetadata)
		{
			GifImageDescriptor descriptor = gifMetadata.Descriptor;
			ImageBehavior.FrameMetadata frameMetadata = new ImageBehavior.FrameMetadata
			{
				Left = descriptor.Left,
				Top = descriptor.Top,
				Width = descriptor.Width,
				Height = descriptor.Height,
				Delay = TimeSpan.FromMilliseconds(100.0),
				DisposalMethod = ImageBehavior.FrameDisposalMethod.None
			};
			GifGraphicControlExtension gifGraphicControlExtension = gifMetadata.Extensions.OfType<GifGraphicControlExtension>().FirstOrDefault<GifGraphicControlExtension>();
			if (gifGraphicControlExtension != null)
			{
				if (gifGraphicControlExtension.Delay != 0)
				{
					frameMetadata.Delay = TimeSpan.FromMilliseconds((double)gifGraphicControlExtension.Delay);
				}
				frameMetadata.DisposalMethod = (ImageBehavior.FrameDisposalMethod)gifGraphicControlExtension.DisposalMethod;
			}
			return frameMetadata;
		}

		// Token: 0x06000D81 RID: 3457 RVA: 0x000354F4 File Offset: 0x000336F4
		private static ImageBehavior.Int32Size GetFullSize(BitmapDecoder decoder, GifFile gifMetadata)
		{
			if (gifMetadata != null)
			{
				GifLogicalScreenDescriptor logicalScreenDescriptor = gifMetadata.Header.LogicalScreenDescriptor;
				return new ImageBehavior.Int32Size(logicalScreenDescriptor.Width, logicalScreenDescriptor.Height);
			}
			int queryOrDefault = decoder.Metadata.GetQueryOrDefault("/logscrdesc/Width", 0);
			int queryOrDefault2 = decoder.Metadata.GetQueryOrDefault("/logscrdesc/Height", 0);
			return new ImageBehavior.Int32Size(queryOrDefault, queryOrDefault2);
		}

		// Token: 0x06000D82 RID: 3458 RVA: 0x0000C550 File Offset: 0x0000A750
		private static T GetQueryOrDefault<T>(this BitmapMetadata metadata, string query, T defaultValue)
		{
			if (metadata.ContainsQuery(query))
			{
				return (T)((object)Convert.ChangeType(metadata.GetQuery(query), typeof(T), CultureInfo.InvariantCulture));
			}
			return defaultValue;
		}

		// Token: 0x06000D83 RID: 3459 RVA: 0x0003554C File Offset: 0x0003374C
		private static T GetQueryOrNull<T>(this BitmapMetadata metadata, string query) where T : class
		{
			if (metadata.ContainsQuery(query))
			{
				return metadata.GetQuery(query) as T;
			}
			return default(T);
		}

		// Token: 0x0400071C RID: 1820
		public static readonly DependencyProperty AnimatedSourceProperty = DependencyProperty.RegisterAttached("AnimatedSource", typeof(ImageSource), typeof(ImageBehavior), new UIPropertyMetadata(null, new PropertyChangedCallback(ImageBehavior.AnimatedSourceChanged)));

		// Token: 0x0400071D RID: 1821
		public static readonly DependencyProperty RepeatBehaviorProperty = DependencyProperty.RegisterAttached("RepeatBehavior", typeof(RepeatBehavior), typeof(ImageBehavior), new UIPropertyMetadata(default(RepeatBehavior), new PropertyChangedCallback(ImageBehavior.RepeatBehaviorChanged)));

		// Token: 0x0400071E RID: 1822
		public static readonly DependencyProperty AnimateInDesignModeProperty = DependencyProperty.RegisterAttached("AnimateInDesignMode", typeof(bool), typeof(ImageBehavior), new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.Inherits, new PropertyChangedCallback(ImageBehavior.AnimateInDesignModeChanged)));

		// Token: 0x0400071F RID: 1823
		public static readonly DependencyProperty AutoStartProperty = DependencyProperty.RegisterAttached("AutoStart", typeof(bool), typeof(ImageBehavior), new PropertyMetadata(true));

		// Token: 0x04000720 RID: 1824
		private static readonly DependencyPropertyKey AnimationControllerPropertyKey = DependencyProperty.RegisterAttachedReadOnly("AnimationController", typeof(ImageAnimationController), typeof(ImageBehavior), new PropertyMetadata(null));

		// Token: 0x04000721 RID: 1825
		private static readonly DependencyPropertyKey IsAnimationLoadedPropertyKey = DependencyProperty.RegisterAttachedReadOnly("IsAnimationLoaded", typeof(bool), typeof(ImageBehavior), new PropertyMetadata(false));

		// Token: 0x04000722 RID: 1826
		public static readonly DependencyProperty IsAnimationLoadedProperty = ImageBehavior.IsAnimationLoadedPropertyKey.DependencyProperty;

		// Token: 0x04000723 RID: 1827
		public static readonly RoutedEvent AnimationLoadedEvent = EventManager.RegisterRoutedEvent("AnimationLoaded", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(ImageBehavior));

		// Token: 0x04000724 RID: 1828
		public static readonly RoutedEvent AnimationCompletedEvent = EventManager.RegisterRoutedEvent("AnimationCompleted", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(ImageBehavior));

		// Token: 0x02000186 RID: 390
		private struct Int32Size
		{
			// Token: 0x06000D85 RID: 3461 RVA: 0x0000C57D File Offset: 0x0000A77D
			public Int32Size(int width, int height)
			{
				this = default(ImageBehavior.Int32Size);
				this.Width = width;
				this.Height = height;
			}

			// Token: 0x170003B4 RID: 948
			// (get) Token: 0x06000D86 RID: 3462 RVA: 0x0000C594 File Offset: 0x0000A794
			// (set) Token: 0x06000D87 RID: 3463 RVA: 0x0000C59C File Offset: 0x0000A79C
			public int Width { readonly get; private set; }

			// Token: 0x170003B5 RID: 949
			// (get) Token: 0x06000D88 RID: 3464 RVA: 0x0000C5A5 File Offset: 0x0000A7A5
			// (set) Token: 0x06000D89 RID: 3465 RVA: 0x0000C5AD File Offset: 0x0000A7AD
			public int Height { readonly get; private set; }
		}

		// Token: 0x02000187 RID: 391
		private class FrameMetadata
		{
			// Token: 0x170003B6 RID: 950
			// (get) Token: 0x06000D8A RID: 3466 RVA: 0x0000C5B6 File Offset: 0x0000A7B6
			// (set) Token: 0x06000D8B RID: 3467 RVA: 0x0000C5BE File Offset: 0x0000A7BE
			public int Left { get; set; }

			// Token: 0x170003B7 RID: 951
			// (get) Token: 0x06000D8C RID: 3468 RVA: 0x0000C5C7 File Offset: 0x0000A7C7
			// (set) Token: 0x06000D8D RID: 3469 RVA: 0x0000C5CF File Offset: 0x0000A7CF
			public int Top { get; set; }

			// Token: 0x170003B8 RID: 952
			// (get) Token: 0x06000D8E RID: 3470 RVA: 0x0000C5D8 File Offset: 0x0000A7D8
			// (set) Token: 0x06000D8F RID: 3471 RVA: 0x0000C5E0 File Offset: 0x0000A7E0
			public int Width { get; set; }

			// Token: 0x170003B9 RID: 953
			// (get) Token: 0x06000D90 RID: 3472 RVA: 0x0000C5E9 File Offset: 0x0000A7E9
			// (set) Token: 0x06000D91 RID: 3473 RVA: 0x0000C5F1 File Offset: 0x0000A7F1
			public int Height { get; set; }

			// Token: 0x170003BA RID: 954
			// (get) Token: 0x06000D92 RID: 3474 RVA: 0x0000C5FA File Offset: 0x0000A7FA
			// (set) Token: 0x06000D93 RID: 3475 RVA: 0x0000C602 File Offset: 0x0000A802
			public TimeSpan Delay { get; set; }

			// Token: 0x170003BB RID: 955
			// (get) Token: 0x06000D94 RID: 3476 RVA: 0x0000C60B File Offset: 0x0000A80B
			// (set) Token: 0x06000D95 RID: 3477 RVA: 0x0000C613 File Offset: 0x0000A813
			public ImageBehavior.FrameDisposalMethod DisposalMethod { get; set; }
		}

		// Token: 0x02000188 RID: 392
		private enum FrameDisposalMethod
		{
			// Token: 0x0400072E RID: 1838
			None,
			// Token: 0x0400072F RID: 1839
			DoNotDispose,
			// Token: 0x04000730 RID: 1840
			RestoreBackground,
			// Token: 0x04000731 RID: 1841
			RestorePrevious
		}
	}
}
