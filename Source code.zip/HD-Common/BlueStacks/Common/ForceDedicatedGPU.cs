﻿using System;
using System.IO;

namespace BlueStacks.Common
{
	// Token: 0x02000096 RID: 150
	public static class ForceDedicatedGPU
	{
		// Token: 0x060003A2 RID: 930 RVA: 0x0001554C File Offset: 0x0001374C
		public static bool ToggleDedicatedGPU(bool enable, string binPath = null)
		{
			try
			{
				if (binPath == null)
				{
					binPath = Path.Combine(RegistryStrings.InstallDir, "HD-ForceGPU.exe");
				}
				string args = enable ? "1" : "0";
				return RunCommand.RunCmd(binPath, args, true, true, false, 0).ExitCode == 0;
			}
			catch (Exception ex)
			{
				Logger.Error("An error occured while running {0}, Ex: {1}", new object[]
				{
					binPath,
					ex
				});
			}
			return false;
		}

		// Token: 0x040001A8 RID: 424
		private const string ENABLE_ARG = "1";

		// Token: 0x040001A9 RID: 425
		private const string DISABLE_ARG = "0";
	}
}
