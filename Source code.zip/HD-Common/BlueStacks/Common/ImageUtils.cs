﻿using System;
using System.IO;
using System.Windows.Media.Imaging;

namespace BlueStacks.Common
{
	// Token: 0x020001AC RID: 428
	public static class ImageUtils
	{
		// Token: 0x06000E45 RID: 3653 RVA: 0x00029D40 File Offset: 0x00027F40
		public static BitmapImage BitmapFromPath(string path)
		{
			BitmapImage bitmapImage = null;
			if (File.Exists(path))
			{
				bitmapImage = new BitmapImage();
				FileStream fileStream = File.OpenRead(path);
				bitmapImage.BeginInit();
				bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
				bitmapImage.StreamSource = fileStream;
				bitmapImage.EndInit();
				fileStream.Close();
				fileStream.Dispose();
			}
			return bitmapImage;
		}

		// Token: 0x06000E46 RID: 3654 RVA: 0x00036F20 File Offset: 0x00035120
		public static BitmapImage BitmapFromUri(string uri)
		{
			BitmapImage bitmapImage = null;
			try
			{
				bitmapImage = new BitmapImage();
				bitmapImage.BeginInit();
				bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
				bitmapImage.UriSource = new Uri(uri);
				bitmapImage.EndInit();
			}
			catch
			{
			}
			return bitmapImage;
		}
	}
}
