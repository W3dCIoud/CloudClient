﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200018D RID: 397
	public static class ErrorStrings
	{
		// Token: 0x0400073E RID: 1854
		public const string INVALID_VMNAME = "Invalid vmname";

		// Token: 0x0400073F RID: 1855
		public const string CLIENT_PROCESS_NOT_RUNNING = "Client process is not running";

		// Token: 0x04000740 RID: 1856
		public const string CLIENT_INSTANCE_NOT_RUNNING = "Client Instance not running";

		// Token: 0x04000741 RID: 1857
		public const string GUEST_NOT_READY = "Guest not ready";

		// Token: 0x04000742 RID: 1858
		public const string PACKAGE_NAME_EMPTY = "Package name cannot be empty";

		// Token: 0x04000743 RID: 1859
		public const string CLIENT_NOT_RESPONDING = "Client not responding";

		// Token: 0x04000744 RID: 1860
		public const string MODEL_NAME_EMPTY = "Model cannot be empty";

		// Token: 0x04000745 RID: 1861
		public const string BRAND_NAME_EMPTY = "Brand cannot be empty";

		// Token: 0x04000746 RID: 1862
		public const string MANUFACTURER_NAME_EMPTY = "Manufacturer cannot be empty";

		// Token: 0x04000747 RID: 1863
		public const string INVALID_DEVICE_PROFILE = "Invalid parameters in device profile";

		// Token: 0x04000748 RID: 1864
		public const string SUBDIR_EMPTY = "Subdir cannot be empty";

		// Token: 0x04000749 RID: 1865
		public const string DEVICE_PROFILE_IN_USE = "Device profile already in use";

		// Token: 0x0400074A RID: 1866
		public const string OLD_DEVICE_PROFILE_NOT_FOUND = "Cannot get old device profile from Android";

		// Token: 0x0400074B RID: 1867
		public const string SHARED_FOLDER_NOT_MOUNTED = "Shared folder not mounted";

		// Token: 0x0400074C RID: 1868
		public const string SHORTCUT_JSON_EMPTY = "Shortcut json cannot be empty";

		// Token: 0x0400074D RID: 1869
		public const string INVALID_SHORTCUT_JSON = "Invalid shortcut json";

		// Token: 0x0400074E RID: 1870
		public const string SHORTCUT_JSON_DOESNT_EXIST = "Shortcut json does not exist.";

		// Token: 0x0400074F RID: 1871
		public const string ERROR_IN_OVERRIDING_NOTIFICATION_SETTINGS = "Error in overriding notification settings";
	}
}
