﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001A6 RID: 422
	public static class FeatureBitHelper
	{
		// Token: 0x06000E34 RID: 3636 RVA: 0x00006402 File Offset: 0x00004602
		public static bool IsFeatureEnabled(ulong featureMask, ulong feature)
		{
			return (feature & featureMask) != 0UL;
		}

		// Token: 0x06000E35 RID: 3637 RVA: 0x0000CC1E File Offset: 0x0000AE1E
		public static ulong EnableFeature(ulong featureMask, ulong feature)
		{
			if ((feature & featureMask) != 0UL)
			{
				return feature;
			}
			return feature |= featureMask;
		}

		// Token: 0x06000E36 RID: 3638 RVA: 0x0000CC2D File Offset: 0x0000AE2D
		public static ulong DisableFeature(ulong featureMask, ulong feature)
		{
			if ((feature & featureMask) == 0UL)
			{
				return feature;
			}
			return feature & ~featureMask;
		}

		// Token: 0x06000E37 RID: 3639 RVA: 0x00036B00 File Offset: 0x00034D00
		public static ulong ToggleFeature(ulong featureMask, ulong feature)
		{
			ulong result;
			if (FeatureBitHelper.IsFeatureEnabled(featureMask, feature))
			{
				result = FeatureBitHelper.DisableFeature(featureMask, feature);
			}
			else
			{
				result = FeatureBitHelper.EnableFeature(featureMask, feature);
			}
			return result;
		}

		// Token: 0x06000E38 RID: 3640 RVA: 0x0000CC3A File Offset: 0x0000AE3A
		public static bool WasFeatureChanged(ulong featureMask, ulong newFeature, ulong originalFeature, out bool isEnabled)
		{
			bool flag = FeatureBitHelper.IsFeatureEnabled(featureMask, originalFeature);
			isEnabled = FeatureBitHelper.IsFeatureEnabled(featureMask, newFeature);
			return flag != isEnabled;
		}
	}
}
