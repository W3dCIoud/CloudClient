﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000100 RID: 256
	public enum ActionType
	{
		// Token: 0x0400045A RID: 1114
		KeyDown,
		// Token: 0x0400045B RID: 1115
		KeyUp,
		// Token: 0x0400045C RID: 1116
		MouseDown,
		// Token: 0x0400045D RID: 1117
		MouseUp
	}
}
