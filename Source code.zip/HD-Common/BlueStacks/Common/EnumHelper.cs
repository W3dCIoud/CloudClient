﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000104 RID: 260
	public static class EnumHelper
	{
		// Token: 0x06000865 RID: 2149 RVA: 0x00008173 File Offset: 0x00006373
		public static TEnum Parse<TEnum>(string value, TEnum defaultValue)
		{
			if (value == null || !Enum.IsDefined(typeof(TEnum), value))
			{
				return defaultValue;
			}
			return (TEnum)((object)Enum.Parse(typeof(TEnum), value));
		}

		// Token: 0x06000866 RID: 2150 RVA: 0x000250A4 File Offset: 0x000232A4
		public static bool TryParse<TEnum>(string value, out TEnum result) where TEnum : struct, IConvertible
		{
			bool flag = value != null && Enum.IsDefined(typeof(TEnum), value);
			result = (flag ? ((TEnum)((object)Enum.Parse(typeof(TEnum), value))) : default(TEnum));
			return flag;
		}
	}
}
