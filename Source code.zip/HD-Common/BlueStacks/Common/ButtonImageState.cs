﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000122 RID: 290
	public enum ButtonImageState
	{
		// Token: 0x04000534 RID: 1332
		hover,
		// Token: 0x04000535 RID: 1333
		click
	}
}
