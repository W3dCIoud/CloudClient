﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Newtonsoft.Json;

namespace BlueStacks.Common
{
	// Token: 0x0200009D RID: 157
	public static class JSONUtils
	{
		// Token: 0x060003C7 RID: 967 RVA: 0x00015EB4 File Offset: 0x000140B4
		public static string GetJSONArrayString(Dictionary<string, string> dict)
		{
			StringBuilder stringBuilder = new StringBuilder();
			using (JsonWriter jsonWriter = new JsonTextWriter(new StringWriter(stringBuilder)))
			{
				jsonWriter.WriteStartArray();
				jsonWriter.WriteStartObject();
				if (dict != null)
				{
					foreach (KeyValuePair<string, string> keyValuePair in dict)
					{
						jsonWriter.WritePropertyName(keyValuePair.Key);
						jsonWriter.WriteValue(keyValuePair.Value);
					}
				}
				jsonWriter.WriteEndObject();
				jsonWriter.WriteEndArray();
			}
			return stringBuilder.ToString();
		}

		// Token: 0x060003C8 RID: 968 RVA: 0x00015F60 File Offset: 0x00014160
		public static string GetJSONObjectString<T>(Dictionary<string, T> dict)
		{
			StringBuilder stringBuilder = new StringBuilder();
			using (JsonWriter jsonWriter = new JsonTextWriter(new StringWriter(stringBuilder)))
			{
				jsonWriter.WriteStartObject();
				if (dict != null)
				{
					foreach (KeyValuePair<string, T> keyValuePair in dict)
					{
						jsonWriter.WritePropertyName(keyValuePair.Key);
						jsonWriter.WriteValue(keyValuePair.Value);
					}
				}
				jsonWriter.WriteEndObject();
			}
			return stringBuilder.ToString();
		}

		// Token: 0x060003C9 RID: 969 RVA: 0x00016008 File Offset: 0x00014208
		public static string GetJSONObjectString(Dictionary<string, Dictionary<string, long>> dict)
		{
			StringBuilder stringBuilder = new StringBuilder();
			using (JsonWriter jsonWriter = new JsonTextWriter(new StringWriter(stringBuilder)))
			{
				jsonWriter.WriteStartObject();
				if (dict != null)
				{
					foreach (KeyValuePair<string, Dictionary<string, long>> keyValuePair in dict)
					{
						jsonWriter.WritePropertyName(keyValuePair.Key);
						jsonWriter.WriteValue(JSONUtils.GetJSONObjectString<long>(keyValuePair.Value));
					}
				}
				jsonWriter.WriteEndObject();
			}
			return stringBuilder.ToString();
		}
	}
}
