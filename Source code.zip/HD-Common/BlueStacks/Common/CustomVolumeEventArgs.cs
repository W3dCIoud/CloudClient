﻿using System;
using System.Collections.Generic;

namespace BlueStacks.Common
{
	// Token: 0x020000E7 RID: 231
	public class CustomVolumeEventArgs : EventArgs
	{
		// Token: 0x17000197 RID: 407
		// (get) Token: 0x0600063A RID: 1594 RVA: 0x00005B7F File Offset: 0x00003D7F
		// (set) Token: 0x0600063B RID: 1595 RVA: 0x00005B87 File Offset: 0x00003D87
		public int Volume { get; set; }

		// Token: 0x17000198 RID: 408
		// (get) Token: 0x0600063C RID: 1596 RVA: 0x00005B90 File Offset: 0x00003D90
		// (set) Token: 0x0600063D RID: 1597 RVA: 0x00005B98 File Offset: 0x00003D98
		public Dictionary<string, string> dictData { get; set; }

		// Token: 0x17000199 RID: 409
		// (get) Token: 0x0600063E RID: 1598 RVA: 0x00005BA1 File Offset: 0x00003DA1
		// (set) Token: 0x0600063F RID: 1599 RVA: 0x00005BA9 File Offset: 0x00003DA9
		public string mSelected { get; set; }

		// Token: 0x06000640 RID: 1600 RVA: 0x00005BB2 File Offset: 0x00003DB2
		public CustomVolumeEventArgs(int volume)
		{
			this.Volume = volume;
		}

		// Token: 0x06000641 RID: 1601 RVA: 0x00005BC1 File Offset: 0x00003DC1
		public CustomVolumeEventArgs(Dictionary<string, string> dict, string selected)
		{
			this.dictData = dict;
			this.mSelected = selected;
		}
	}
}
