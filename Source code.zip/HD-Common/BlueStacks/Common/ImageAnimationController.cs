﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace BlueStacks.Common
{
	// Token: 0x02000182 RID: 386
	public class ImageAnimationController : IDisposable
	{
		// Token: 0x06000D46 RID: 3398 RVA: 0x00034628 File Offset: 0x00032828
		internal ImageAnimationController(Image image, ObjectAnimationUsingKeyFrames animation, bool autoStart)
		{
			this._image = image;
			this._animation = animation;
			this._animation.Completed += this.AnimationCompleted;
			this._clock = this._animation.CreateClock();
			this._clockController = this._clock.Controller;
			ImageAnimationController._sourceDescriptor.AddValueChanged(image, new EventHandler(this.ImageSourceChanged));
			this._clockController.Pause();
			this._image.ApplyAnimationClock(Image.SourceProperty, this._clock);
			if (autoStart)
			{
				this._clockController.Resume();
			}
		}

		// Token: 0x06000D47 RID: 3399 RVA: 0x0000C2E4 File Offset: 0x0000A4E4
		private void AnimationCompleted(object sender, EventArgs e)
		{
			this._image.RaiseEvent(new RoutedEventArgs(ImageBehavior.AnimationCompletedEvent, this._image));
		}

		// Token: 0x06000D48 RID: 3400 RVA: 0x0000C301 File Offset: 0x0000A501
		private void ImageSourceChanged(object sender, EventArgs e)
		{
			this.OnCurrentFrameChanged();
		}

		// Token: 0x170003B0 RID: 944
		// (get) Token: 0x06000D49 RID: 3401 RVA: 0x0000C309 File Offset: 0x0000A509
		public int FrameCount
		{
			get
			{
				return this._animation.KeyFrames.Count;
			}
		}

		// Token: 0x170003B1 RID: 945
		// (get) Token: 0x06000D4A RID: 3402 RVA: 0x0000C31B File Offset: 0x0000A51B
		public bool IsPaused
		{
			get
			{
				return this._clock.IsPaused;
			}
		}

		// Token: 0x170003B2 RID: 946
		// (get) Token: 0x06000D4B RID: 3403 RVA: 0x0000C328 File Offset: 0x0000A528
		public bool IsComplete
		{
			get
			{
				return this._clock.CurrentState == ClockState.Filling;
			}
		}

		// Token: 0x06000D4C RID: 3404 RVA: 0x000346C8 File Offset: 0x000328C8
		public void GotoFrame(int index)
		{
			ObjectKeyFrame objectKeyFrame = this._animation.KeyFrames[index];
			this._clockController.Seek(objectKeyFrame.KeyTime.TimeSpan, TimeSeekOrigin.BeginTime);
		}

		// Token: 0x170003B3 RID: 947
		// (get) Token: 0x06000D4D RID: 3405 RVA: 0x00034704 File Offset: 0x00032904
		public int CurrentFrame
		{
			get
			{
				TimeSpan? time = this._clock.CurrentTime;
				var <>f__AnonymousType = this._animation.KeyFrames.Cast<ObjectKeyFrame>().Select((ObjectKeyFrame f, int i) => new
				{
					Time = f.KeyTime.TimeSpan,
					Index = i
				}).FirstOrDefault(fi => fi.Time >= time);
				if (<>f__AnonymousType != null)
				{
					return <>f__AnonymousType.Index;
				}
				return -1;
			}
		}

		// Token: 0x06000D4E RID: 3406 RVA: 0x0000C338 File Offset: 0x0000A538
		public void Pause()
		{
			this._clockController.Pause();
		}

		// Token: 0x06000D4F RID: 3407 RVA: 0x0000C345 File Offset: 0x0000A545
		public void Play()
		{
			this._clockController.Resume();
		}

		// Token: 0x1400000E RID: 14
		// (add) Token: 0x06000D50 RID: 3408 RVA: 0x0003477C File Offset: 0x0003297C
		// (remove) Token: 0x06000D51 RID: 3409 RVA: 0x000347B4 File Offset: 0x000329B4
		public event EventHandler CurrentFrameChanged;

		// Token: 0x06000D52 RID: 3410 RVA: 0x000347EC File Offset: 0x000329EC
		private void OnCurrentFrameChanged()
		{
			EventHandler currentFrameChanged = this.CurrentFrameChanged;
			if (currentFrameChanged != null)
			{
				currentFrameChanged(this, EventArgs.Empty);
			}
		}

		// Token: 0x06000D53 RID: 3411 RVA: 0x00034810 File Offset: 0x00032A10
		~ImageAnimationController()
		{
			this.Dispose(false);
		}

		// Token: 0x06000D54 RID: 3412 RVA: 0x0000C352 File Offset: 0x0000A552
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x06000D55 RID: 3413 RVA: 0x00034840 File Offset: 0x00032A40
		protected virtual void Dispose(bool disposing)
		{
			if (disposing)
			{
				this._image.BeginAnimation(Image.SourceProperty, null);
				this._animation.Completed -= this.AnimationCompleted;
				ImageAnimationController._sourceDescriptor.RemoveValueChanged(this._image, new EventHandler(this.ImageSourceChanged));
				this._image.Source = null;
			}
		}

		// Token: 0x04000713 RID: 1811
		private static readonly DependencyPropertyDescriptor _sourceDescriptor = DependencyPropertyDescriptor.FromProperty(Image.SourceProperty, typeof(Image));

		// Token: 0x04000714 RID: 1812
		private readonly Image _image;

		// Token: 0x04000715 RID: 1813
		private readonly ObjectAnimationUsingKeyFrames _animation;

		// Token: 0x04000716 RID: 1814
		private readonly AnimationClock _clock;

		// Token: 0x04000717 RID: 1815
		private readonly ClockController _clockController;
	}
}
