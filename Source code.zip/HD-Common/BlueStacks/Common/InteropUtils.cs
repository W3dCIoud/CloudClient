﻿using System;
using System.Runtime.InteropServices;

namespace BlueStacks.Common
{
	// Token: 0x020001AE RID: 430
	public static class InteropUtils
	{
		// Token: 0x06000E50 RID: 3664
		[DllImport("kernel32.dll")]
		public static extern long GetTickCount64();
	}
}
