﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Navigation;

namespace BlueStacks.Common
{
	// Token: 0x0200007F RID: 127
	public class EngineSettingBase : UserControl, IComponentConnector
	{
		// Token: 0x06000325 RID: 805 RVA: 0x00003B34 File Offset: 0x00001D34
		public EngineSettingBase()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000326 RID: 806 RVA: 0x00014424 File Offset: 0x00012624
		private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
		{
			try
			{
				Logger.Info("Opening url: " + e.Uri.AbsoluteUri);
				Utils.OpenUrl(e.Uri.AbsoluteUri);
				e.Handled = true;
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in opening url" + ex.ToString());
			}
		}

		// Token: 0x06000327 RID: 807 RVA: 0x00003B42 File Offset: 0x00001D42
		private void ASTCHelpCenterImage_MouseDown(object sender, MouseButtonEventArgs e)
		{
			Utils.OpenUrl(WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
			{
				WebHelper.GetServerHost(),
				"help_articles"
			})) + "&article=ASTC_Help");
		}

		// Token: 0x06000328 RID: 808 RVA: 0x00003B7D File Offset: 0x00001D7D
		private void mHelpCenterImage_MouseDown(object sender, MouseButtonEventArgs e)
		{
			Utils.OpenUrl(WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
			{
				WebHelper.GetServerHost(),
				"help_articles"
			})) + "&article=ABI_Help");
		}

		// Token: 0x06000329 RID: 809 RVA: 0x00003BB8 File Offset: 0x00001DB8
		private void GPUHelpCenterImage_MouseDown(object sender, MouseButtonEventArgs e)
		{
			Utils.OpenUrl(WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
			{
				WebHelper.GetServerHost(),
				"help_articles"
			})) + "&article=GPU_Setting_Help");
		}

		// Token: 0x0600032A RID: 810 RVA: 0x0001448C File Offset: 0x0001268C
		private void DirectXRadioButton_Click(object sender, RoutedEventArgs e)
		{
			EngineSettingBaseViewModel engineSettingBaseViewModel = base.DataContext as EngineSettingBaseViewModel;
			if (engineSettingBaseViewModel != null)
			{
				engineSettingBaseViewModel.SetGraphicMode(GraphicsMode.DirectX);
			}
		}

		// Token: 0x0600032B RID: 811 RVA: 0x000144B0 File Offset: 0x000126B0
		private void OpenGlRadioButton_Click(object sender, RoutedEventArgs e)
		{
			EngineSettingBaseViewModel engineSettingBaseViewModel = base.DataContext as EngineSettingBaseViewModel;
			if (engineSettingBaseViewModel != null)
			{
				engineSettingBaseViewModel.SetGraphicMode(GraphicsMode.OpenGL);
			}
		}

		// Token: 0x0600032C RID: 812 RVA: 0x00003BF3 File Offset: 0x00001DF3
		public void SetGraphicMode(GraphicsMode mode)
		{
			this.mDirectX.IsChecked = new bool?(mode == GraphicsMode.DirectX);
			this.mGlMode.IsChecked = new bool?(mode == GraphicsMode.OpenGL);
		}

		// Token: 0x0600032D RID: 813 RVA: 0x00003C1D File Offset: 0x00001E1D
		private void ScrollViewer_ScrollChanged(object sender, ScrollChangedEventArgs e)
		{
			BluestacksUIColor.ScrollBarScrollChanged(sender, e);
		}

		// Token: 0x0600032E RID: 814 RVA: 0x000144D4 File Offset: 0x000126D4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/settings/enginesettingbase/enginesettingbase.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600032F RID: 815 RVA: 0x000035E3 File Offset: 0x000017E3
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000330 RID: 816 RVA: 0x00014504 File Offset: 0x00012704
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((ScrollViewer)target).ScrollChanged += this.ScrollViewer_ScrollChanged;
				return;
			case 2:
				this.mDirectX = (CustomRadioButton)target;
				return;
			case 3:
				this.mGlMode = (CustomRadioButton)target;
				return;
			case 4:
				this.softwareDecoding = (CustomRadioButton)target;
				return;
			case 5:
				this.mHelpCenterImage = (CustomPictureBox)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000189 RID: 393
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mDirectX;

		// Token: 0x0400018A RID: 394
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mGlMode;

		// Token: 0x0400018B RID: 395
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton softwareDecoding;

		// Token: 0x0400018C RID: 396
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mHelpCenterImage;

		// Token: 0x0400018D RID: 397
		private bool _contentLoaded;
	}
}
