﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;

namespace BlueStacks.Common
{
	// Token: 0x020001B0 RID: 432
	public static class HTTP
	{
		// Token: 0x06000E59 RID: 3673 RVA: 0x000373AC File Offset: 0x000355AC
		public static string Get(string url, Dictionary<string, string> headers, bool gzip, int tries, int sleepTimeMSec, int timeout, NameValueCollection headerCollection = null, string userAgent = "")
		{
			string result = null;
			int i = tries;
			while (i > 0)
			{
				try
				{
					result = HTTP.GetInternal(url, headers, gzip, timeout, headerCollection, userAgent);
					break;
				}
				catch (Exception ex)
				{
					if (i == 1)
					{
						throw;
					}
					Logger.Warning("Exception when GET to url: {0}, Ex: {1}", new object[]
					{
						url,
						ex.Message
					});
				}
				i--;
				Thread.Sleep(sleepTimeMSec);
			}
			return result;
		}

		// Token: 0x06000E5A RID: 3674 RVA: 0x00037418 File Offset: 0x00035618
		private static string GetInternal(string url, Dictionary<string, string> headers, bool gzip, int timeout, NameValueCollection headerCollection = null, string userAgent = "")
		{
			HttpWebRequest httpWebRequest = WebRequest.Create(url) as HttpWebRequest;
			httpWebRequest.Method = "GET";
			if (timeout != 0)
			{
				httpWebRequest.Timeout = timeout;
			}
			if (gzip)
			{
				httpWebRequest.AutomaticDecompression = DecompressionMethods.GZip;
				httpWebRequest.Headers.Add(HttpRequestHeader.AcceptEncoding, "gzip");
			}
			if (headerCollection != null)
			{
				httpWebRequest.Headers.Add(headerCollection);
			}
			if (!string.IsNullOrEmpty(userAgent))
			{
				httpWebRequest.UserAgent = userAgent;
			}
			if (headers != null)
			{
				foreach (KeyValuePair<string, string> keyValuePair in headers)
				{
					httpWebRequest.Headers.Set(StringUtils.GetControlCharFreeString(keyValuePair.Key), StringUtils.GetControlCharFreeString(keyValuePair.Value));
				}
			}
			string result = null;
			using (HttpWebResponse httpWebResponse = httpWebRequest.GetResponse() as HttpWebResponse)
			{
				Logger.Debug("Response StatusCode:" + httpWebResponse.StatusCode.ToString());
				using (Stream responseStream = httpWebResponse.GetResponseStream())
				{
					using (StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8))
					{
						result = streamReader.ReadToEnd();
					}
				}
			}
			return result;
		}

		// Token: 0x06000E5B RID: 3675 RVA: 0x00037584 File Offset: 0x00035784
		public static string Post(string url, Dictionary<string, string> data, Dictionary<string, string> headers, bool gzip, int retries, int sleepTimeMSecs, int timeout, NameValueCollection headerCollection, string userAgent)
		{
			string result = null;
			int i = retries;
			while (i > 0)
			{
				try
				{
					result = HTTP.PostInternal(url, data, headers, gzip, timeout, headerCollection, userAgent);
					break;
				}
				catch (Exception ex)
				{
					if (i == 1)
					{
						throw;
					}
					Logger.Warning("Exception when posting to url: {0}, Ex: {1}", new object[]
					{
						url,
						ex.Message
					});
				}
				i--;
				Thread.Sleep(sleepTimeMSecs);
			}
			return result;
		}

		// Token: 0x06000E5C RID: 3676 RVA: 0x000375F4 File Offset: 0x000357F4
		private static string PostInternal(string url, Dictionary<string, string> data, Dictionary<string, string> headers, bool gzip, int timeout, NameValueCollection headerCollection, string userAgent)
		{
			HttpWebRequest httpWebRequest = WebRequest.Create(url) as HttpWebRequest;
			httpWebRequest.Method = "POST";
			if (timeout != 0)
			{
				httpWebRequest.Timeout = timeout;
			}
			if (gzip)
			{
				httpWebRequest.AutomaticDecompression = DecompressionMethods.GZip;
				httpWebRequest.Headers.Add(HttpRequestHeader.AcceptEncoding, "gzip");
			}
			if (headerCollection != null)
			{
				httpWebRequest.Headers.Add(headerCollection);
			}
			if (!string.IsNullOrEmpty(userAgent))
			{
				httpWebRequest.UserAgent = userAgent;
			}
			if (headers != null)
			{
				foreach (KeyValuePair<string, string> keyValuePair in headers)
				{
					httpWebRequest.Headers.Set(StringUtils.GetControlCharFreeString(keyValuePair.Key), StringUtils.GetControlCharFreeString(keyValuePair.Value));
				}
			}
			if (data == null)
			{
				data = new Dictionary<string, string>();
			}
			byte[] bytes = Encoding.UTF8.GetBytes(StringUtils.Encode(data));
			httpWebRequest.ContentType = "application/x-www-form-urlencoded";
			httpWebRequest.ContentLength = (long)bytes.Length;
			string result = null;
			using (Stream requestStream = httpWebRequest.GetRequestStream())
			{
				requestStream.Write(bytes, 0, bytes.Length);
				using (HttpWebResponse httpWebResponse = httpWebRequest.GetResponse() as HttpWebResponse)
				{
					Logger.Debug("Response StatusCode:" + httpWebResponse.StatusCode.ToString());
					using (Stream responseStream = httpWebResponse.GetResponseStream())
					{
						using (StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8))
						{
							result = streamReader.ReadToEnd();
						}
					}
				}
			}
			return result;
		}
	}
}
