﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200006D RID: 109
	public class AppInstalledEventArgs : BrowserEventArgs
	{
		// Token: 0x0600023C RID: 572 RVA: 0x000032A4 File Offset: 0x000014A4
		public AppInstalledEventArgs(BrowserControlTags tag, string packageName, string vmName) : base(tag, packageName, vmName)
		{
		}
	}
}
