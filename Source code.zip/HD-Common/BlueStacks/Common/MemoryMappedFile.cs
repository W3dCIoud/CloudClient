﻿using System;
using System.Runtime.InteropServices;

namespace BlueStacks.Common
{
	// Token: 0x020000A1 RID: 161
	public static class MemoryMappedFile
	{
		// Token: 0x060003E7 RID: 999
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern IntPtr OpenFileMapping(uint dwDesiredAccess, bool bInheritHandle, string lpName);

		// Token: 0x060003E8 RID: 1000
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern IntPtr MapViewOfFile(IntPtr hFileMappingObject, uint dwDesiredAccess, uint dwFileOffsetHigh, uint dwFileOffsetLow, UIntPtr dwNumberOfBytesToMap);

		// Token: 0x060003E9 RID: 1001
		[DllImport("kernel32.dll", SetLastError = true)]
		[return: MarshalAs(UnmanagedType.Bool)]
		private static extern bool CloseHandle(IntPtr hObject);

		// Token: 0x060003EA RID: 1002 RVA: 0x000163D4 File Offset: 0x000145D4
		public static int GetNCSoftAgentPort(string SharedMemoryName, uint NumBytes)
		{
			IntPtr intPtr = MemoryMappedFile.OpenFileMapping(983071U, false, SharedMemoryName);
			if (IntPtr.Zero == intPtr)
			{
				Logger.Error("Shared Memory Handle not found. Last Error : " + Marshal.GetLastWin32Error().ToString());
				return -1;
			}
			IntPtr intPtr2 = MemoryMappedFile.MapViewOfFile(intPtr, 983071U, 0U, 0U, new UIntPtr(NumBytes));
			if (intPtr2 == IntPtr.Zero)
			{
				Logger.Error("Cannot map view of file. Last Error : " + Marshal.GetLastWin32Error().ToString());
				return -1;
			}
			int result = -1;
			try
			{
				result = Marshal.ReadInt32(intPtr2);
			}
			catch (Exception ex)
			{
				Logger.Error("Failed to read memory as int32");
				Logger.Error(ex.ToString());
			}
			if (IntPtr.Zero != intPtr)
			{
				MemoryMappedFile.CloseHandle(intPtr);
				intPtr = IntPtr.Zero;
			}
			intPtr2 = IntPtr.Zero;
			return result;
		}

		// Token: 0x040001C7 RID: 455
		private const uint STANDARD_RIGHTS_REQUIRED = 983040U;

		// Token: 0x040001C8 RID: 456
		private const uint SECTION_QUERY = 1U;

		// Token: 0x040001C9 RID: 457
		private const uint SECTION_MAP_WRITE = 2U;

		// Token: 0x040001CA RID: 458
		private const uint SECTION_MAP_READ = 4U;

		// Token: 0x040001CB RID: 459
		private const uint SECTION_MAP_EXECUTE = 8U;

		// Token: 0x040001CC RID: 460
		private const uint SECTION_EXTEND_SIZE = 16U;

		// Token: 0x040001CD RID: 461
		private const uint SECTION_ALL_ACCESS = 983071U;

		// Token: 0x040001CE RID: 462
		private const uint FILE_MAP_ALL_ACCESS = 983071U;
	}
}
