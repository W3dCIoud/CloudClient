﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using BlueStacks.Common.Grm;
using Newtonsoft.Json;

namespace BlueStacks.Common
{
	// Token: 0x020000CD RID: 205
	public class AppRequirementsParser
	{
		// Token: 0x1700016E RID: 366
		// (get) Token: 0x06000559 RID: 1369 RVA: 0x0001CD28 File Offset: 0x0001AF28
		public static AppRequirementsParser Instance
		{
			get
			{
				if (AppRequirementsParser.sInstance == null)
				{
					object obj = AppRequirementsParser.syncRoot;
					lock (obj)
					{
						if (AppRequirementsParser.sInstance == null)
						{
							AppRequirementsParser.sInstance = new AppRequirementsParser();
						}
					}
				}
				return AppRequirementsParser.sInstance;
			}
		}

		// Token: 0x1700016F RID: 367
		// (get) Token: 0x0600055A RID: 1370 RVA: 0x000053E3 File Offset: 0x000035E3
		// (set) Token: 0x0600055B RID: 1371 RVA: 0x000053EB File Offset: 0x000035EB
		public List<AppRequirement> Requirements
		{
			get
			{
				return this.mRequirements;
			}
			set
			{
				this.mRequirements = value;
				EventHandler requirementConfigUpdated = this.RequirementConfigUpdated;
				if (requirementConfigUpdated == null)
				{
					return;
				}
				requirementConfigUpdated(this, new EventArgs());
			}
		}

		// Token: 0x1400000A RID: 10
		// (add) Token: 0x0600055C RID: 1372 RVA: 0x0001CD80 File Offset: 0x0001AF80
		// (remove) Token: 0x0600055D RID: 1373 RVA: 0x0001CDB8 File Offset: 0x0001AFB8
		public event EventHandler RequirementConfigUpdated;

		// Token: 0x0600055E RID: 1374 RVA: 0x0000540A File Offset: 0x0000360A
		private AppRequirementsParser()
		{
			this.mRequirementsJsonFile = Path.Combine(RegistryStrings.GadgetDir, "requirements.json");
			this.mRequirementsTranslationsFile = Path.Combine(RegistryStrings.GadgetDir, "req_trans.json");
		}

		// Token: 0x0600055F RID: 1375 RVA: 0x0001CDF0 File Offset: 0x0001AFF0
		public void PopulateRequirementsFromFile()
		{
			string value = "[]";
			string value2 = "[]";
			using (Mutex mutex = new Mutex(false, "BlueStacks_AppRequirementUpdate"))
			{
				if (mutex.WaitOne())
				{
					try
					{
						if (!File.Exists(this.mRequirementsJsonFile))
						{
							using (StreamWriter streamWriter = new StreamWriter(this.mRequirementsJsonFile, true))
							{
								streamWriter.Write("[");
								streamWriter.WriteLine();
								streamWriter.Write("]");
							}
						}
						using (StreamReader streamReader = new StreamReader(new FileStream(this.mRequirementsJsonFile, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))
						{
							value = streamReader.ReadToEnd();
						}
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to get app requirements");
						Logger.Error(ex.ToString());
					}
					try
					{
						if (!File.Exists(this.mRequirementsTranslationsFile))
						{
							using (StreamWriter streamWriter2 = new StreamWriter(this.mRequirementsTranslationsFile, true))
							{
								streamWriter2.Write("{}");
							}
						}
						using (StreamReader streamReader2 = new StreamReader(new FileStream(this.mRequirementsTranslationsFile, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))
						{
							value2 = streamReader2.ReadToEnd();
						}
					}
					catch (Exception ex2)
					{
						Logger.Error("Failed to get app requirements translations from file");
						Logger.Error(ex2.ToString());
					}
					finally
					{
						mutex.ReleaseMutex();
					}
				}
			}
			List<AppRequirement> requirements = new List<AppRequirement>();
			try
			{
				requirements = JsonConvert.DeserializeObject<List<AppRequirement>>(value, Utils.GetSerializerSettings());
			}
			catch (Exception ex3)
			{
				string str = "Exception in parsing apprequirement json ";
				Exception ex4 = ex3;
				Logger.Error(str + ((ex4 != null) ? ex4.ToString() : null));
			}
			Dictionary<string, Dictionary<string, string>> dictionary = new Dictionary<string, Dictionary<string, string>>();
			try
			{
				dictionary = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, string>>>(value2, Utils.GetSerializerSettings());
			}
			catch (Exception ex5)
			{
				string str2 = "Exception in parsing req translations json ";
				Exception ex6 = ex5;
				Logger.Error(str2 + ((ex6 != null) ? ex6.ToString() : null));
			}
			this.Requirements = requirements;
			if (dictionary != null && dictionary.Count > 0)
			{
				this.mTranslations = dictionary;
			}
		}

		// Token: 0x06000560 RID: 1376 RVA: 0x0001D0B4 File Offset: 0x0001B2B4
		public void UpdateOverwriteRequirements(string fullJson, string translationJson)
		{
			List<AppRequirement> list = JsonConvert.DeserializeObject<List<AppRequirement>>(fullJson, Utils.GetSerializerSettings());
			Dictionary<string, Dictionary<string, string>> dictionary = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, string>>>(translationJson, Utils.GetSerializerSettings());
			this.SaveRequirements(list, dictionary);
			if (dictionary.Count > 0)
			{
				this.mTranslations = dictionary;
			}
			this.Requirements = list;
		}

		// Token: 0x06000561 RID: 1377 RVA: 0x0001D0F8 File Offset: 0x0001B2F8
		public string GetLocalizedString(string key)
		{
			string text = RegistryManager.Instance.UserSelectedLocale;
			text = Globalization.FindClosestMatchingLocale(text);
			if (this.mTranslations.ContainsKey(text) && this.mTranslations[text].ContainsKey(key))
			{
				return this.mTranslations[text][key];
			}
			return key;
		}

		// Token: 0x06000562 RID: 1378 RVA: 0x0001D150 File Offset: 0x0001B350
		private void SaveRequirements(List<AppRequirement> appRequirements, Dictionary<string, Dictionary<string, string>> translations)
		{
			using (Mutex mutex = new Mutex(false, "BlueStacks_AppRequirementUpdate"))
			{
				if (mutex.WaitOne())
				{
					try
					{
						FileInfo fileInfo = new FileInfo(this.mRequirementsJsonFile + ".tmp");
						JsonSerializer jsonSerializer = JsonSerializer.Create(Utils.GetSerializerSettings());
						using (TextWriter textWriter = new StreamWriter(fileInfo.Open(FileMode.Create)))
						{
							using (JsonWriter jsonWriter = new JsonTextWriter(textWriter))
							{
								jsonSerializer.Serialize(jsonWriter, appRequirements);
							}
						}
						File.Copy(this.mRequirementsJsonFile, this.mRequirementsJsonFile + ".bak", true);
						File.Delete(this.mRequirementsJsonFile);
						int num = 10;
						while (File.Exists(this.mRequirementsJsonFile) && num > 0)
						{
							num--;
							Thread.Sleep(100);
						}
						File.Move(this.mRequirementsJsonFile + ".tmp", this.mRequirementsJsonFile);
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to write/move requirements to apps json file");
						Logger.Error(ex.ToString());
					}
					try
					{
						FileInfo fileInfo2 = new FileInfo(this.mRequirementsTranslationsFile + ".tmp");
						JsonSerializer jsonSerializer2 = JsonSerializer.Create(Utils.GetSerializerSettings());
						using (TextWriter textWriter2 = new StreamWriter(fileInfo2.Open(FileMode.Create)))
						{
							using (JsonWriter jsonWriter2 = new JsonTextWriter(textWriter2))
							{
								jsonSerializer2.Serialize(jsonWriter2, translations);
							}
						}
						File.Copy(this.mRequirementsTranslationsFile, this.mRequirementsTranslationsFile + ".bak", true);
						File.Delete(this.mRequirementsTranslationsFile);
						int num2 = 10;
						while (File.Exists(this.mRequirementsTranslationsFile) && num2 > 0)
						{
							num2--;
							Thread.Sleep(100);
						}
						File.Move(this.mRequirementsTranslationsFile + ".tmp", this.mRequirementsTranslationsFile);
					}
					catch (Exception ex2)
					{
						Logger.Error("Failed to write/move requirements translations to req translations json file");
						Logger.Error(ex2.ToString());
					}
					finally
					{
						mutex.ReleaseMutex();
					}
				}
			}
		}

		// Token: 0x040002D0 RID: 720
		private static object syncRoot = new object();

		// Token: 0x040002D1 RID: 721
		private static volatile AppRequirementsParser sInstance;

		// Token: 0x040002D2 RID: 722
		private List<AppRequirement> mRequirements;

		// Token: 0x040002D3 RID: 723
		private Dictionary<string, Dictionary<string, string>> mTranslations = new Dictionary<string, Dictionary<string, string>>();

		// Token: 0x040002D5 RID: 725
		private readonly string mRequirementsJsonFile;

		// Token: 0x040002D6 RID: 726
		private readonly string mRequirementsTranslationsFile;
	}
}
