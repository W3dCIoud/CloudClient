﻿using System;
using System.Collections.Generic;
using System.IO;

namespace BlueStacks.Common
{
	// Token: 0x020000CE RID: 206
	public sealed class BlueStacksUIColorManager
	{
		// Token: 0x06000564 RID: 1380 RVA: 0x0000223B File Offset: 0x0000043B
		private BlueStacksUIColorManager()
		{
		}

		// Token: 0x06000565 RID: 1381 RVA: 0x0001D3FC File Offset: 0x0001B5FC
		public static string GetThemeFilePath(string themeName)
		{
			string text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ThemeFile");
			if (File.Exists(text))
			{
				return text;
			}
			return Path.Combine(Path.Combine(RegistryManager.Instance.ClientInstallDir, themeName), "ThemeFile");
		}

		// Token: 0x17000170 RID: 368
		// (get) Token: 0x06000566 RID: 1382 RVA: 0x0001D444 File Offset: 0x0001B644
		public static BlueStacksUIColorManager Instance
		{
			get
			{
				if (BlueStacksUIColorManager.mInstance == null)
				{
					object obj = BlueStacksUIColorManager.syncRoot;
					lock (obj)
					{
						if (BlueStacksUIColorManager.mInstance == null)
						{
							BlueStacksUIColorManager.mInstance = new BlueStacksUIColorManager();
						}
					}
				}
				return BlueStacksUIColorManager.mInstance;
			}
		}

		// Token: 0x17000171 RID: 369
		// (get) Token: 0x06000567 RID: 1383 RVA: 0x0001D49C File Offset: 0x0001B69C
		// (set) Token: 0x06000568 RID: 1384 RVA: 0x00005453 File Offset: 0x00003653
		public static BluestacksUIColor AppliedTheme
		{
			get
			{
				if (BlueStacksUIColorManager.mAppliedTheme == null)
				{
					object obj = BlueStacksUIColorManager.syncRoot;
					lock (obj)
					{
						if (BlueStacksUIColorManager.mAppliedTheme == null)
						{
							BluestacksUIColor bluestacksUIColor = BluestacksUIColor.Load(BlueStacksUIColorManager.GetThemeFilePath(RegistryManager.ClientThemeName));
							if (bluestacksUIColor != null && bluestacksUIColor.DictBrush.Count > 0)
							{
								BlueStacksUIColorManager.mAppliedTheme = bluestacksUIColor;
							}
							if (BlueStacksUIColorManager.mAppliedTheme != null)
							{
								BlueStacksUIColorManager.mAppliedTheme.NotifyUIElements();
							}
						}
					}
				}
				return BlueStacksUIColorManager.mAppliedTheme;
			}
			private set
			{
				if (value != null)
				{
					BlueStacksUIColorManager.mAppliedTheme = value;
					BlueStacksUIColorManager.mAppliedTheme.NotifyUIElements();
				}
			}
		}

		// Token: 0x06000569 RID: 1385 RVA: 0x0001D51C File Offset: 0x0001B71C
		public static void ReloadAppliedTheme(string themeName)
		{
			BluestacksUIColor bluestacksUIColor = BluestacksUIColor.Load(BlueStacksUIColorManager.GetThemeFilePath(themeName));
			if (bluestacksUIColor != null && bluestacksUIColor.DictBrush.Count > 0)
			{
				BlueStacksUIColorManager.AppliedTheme = bluestacksUIColor;
				RegistryManager.Instance.SetClientThemeNameInRegistry(themeName);
				CustomPictureBox.UpdateImagesFromNewDirectory("");
			}
		}

		// Token: 0x0600056A RID: 1386 RVA: 0x0001D564 File Offset: 0x0001B764
		public static IEnumerable<string> GetThemes()
		{
			List<string> list = new List<string>();
			foreach (string text in Directory.GetDirectories(RegistryManager.Instance.ClientInstallDir))
			{
				if (File.Exists(Path.Combine(text, "ThemeFile")))
				{
					list.Add(Path.GetFileName(text));
				}
			}
			return list;
		}

		// Token: 0x0600056B RID: 1387 RVA: 0x0001D5B8 File Offset: 0x0001B7B8
		public static string GetThemeName(string themeName)
		{
			string text = "";
			try
			{
				if (!File.Exists(BlueStacksUIColorManager.GetThemeFilePath(themeName)))
				{
					throw new Exception("Theme file not found exception " + themeName);
				}
				text = BluestacksUIColor.Load(BlueStacksUIColorManager.GetThemeFilePath(themeName)).DictThemeAvailable["ThemeDisplayName"];
				text = LocaleStrings.GetLocalizedString(text);
			}
			catch (Exception ex)
			{
				Logger.Warning("Error checking for theme availability in Theme file " + themeName + Environment.NewLine + ex.ToString());
				text = "";
			}
			return text;
		}

		// Token: 0x0600056C RID: 1388 RVA: 0x0001D644 File Offset: 0x0001B844
		public static void ApplyTheme(string themeName)
		{
			try
			{
				if (!File.Exists(BlueStacksUIColorManager.GetThemeFilePath(themeName)))
				{
					throw new Exception("Theme file not found exception " + themeName);
				}
				BluestacksUIColor bluestacksUIColor = BluestacksUIColor.Load(BlueStacksUIColorManager.GetThemeFilePath(themeName));
				if (bluestacksUIColor != null && bluestacksUIColor.DictBrush.Count > 0)
				{
					BlueStacksUIColorManager.AppliedTheme = bluestacksUIColor;
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error checking for theme availability in Theme file " + themeName + Environment.NewLine + ex.ToString());
			}
		}

		// Token: 0x040002D7 RID: 727
		public const string ThemeFileName = "ThemeFile";

		// Token: 0x040002D8 RID: 728
		private static volatile BlueStacksUIColorManager mInstance = null;

		// Token: 0x040002D9 RID: 729
		private static object syncRoot = new object();

		// Token: 0x040002DA RID: 730
		private static BluestacksUIColor mAppliedTheme = null;
	}
}
