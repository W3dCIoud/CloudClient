﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001E1 RID: 481
	public static class InstallerStatsEvent
	{
		// Token: 0x04000B0C RID: 2828
		public const string InstallStarted = "install_launched";

		// Token: 0x04000B0D RID: 2829
		public const string InstallAborted = "install_aborted_by_user";

		// Token: 0x04000B0E RID: 2830
		public const string InstallLicenseAgreed = "install_license_agreed";

		// Token: 0x04000B0F RID: 2831
		public const string InstallChecksPassed = "install_checks_passed";

		// Token: 0x04000B10 RID: 2832
		public const string InstallCompleted = "install_completed";

		// Token: 0x04000B11 RID: 2833
		public const string InstallFailed = "install_failed";

		// Token: 0x04000B12 RID: 2834
		public const string UpgradeLaunched = "upgrade_launched";

		// Token: 0x04000B13 RID: 2835
		public const string BackupCancel = "backup_cancel";

		// Token: 0x04000B14 RID: 2836
		public const string BackupContinue = "backup_continue";

		// Token: 0x04000B15 RID: 2837
		public const string BackupCross = "backup_cross";

		// Token: 0x04000B16 RID: 2838
		public const string UpgradeStart = "upgrade_start";

		// Token: 0x04000B17 RID: 2839
		public const string UpgradeAborted = "upgrade_aborted_by_user";

		// Token: 0x04000B18 RID: 2840
		public const string UpgradeCleaned = "upgrade_cleaned";

		// Token: 0x04000B19 RID: 2841
		public const string UpgradeChecksPassed = "upgrade_checks_passed";

		// Token: 0x04000B1A RID: 2842
		public const string UpgradeCompleted = "upgrade_completed";

		// Token: 0x04000B1B RID: 2843
		public const string UpgradeFailed = "upgrade_failed";

		// Token: 0x04000B1C RID: 2844
		public const string MiLaunched = "mi_launched";

		// Token: 0x04000B1D RID: 2845
		public const string MiUacPrompted = "mi_uac_prompted";

		// Token: 0x04000B1E RID: 2846
		public const string MiUacPromptRetried = "mi_uac_prompt_retried";

		// Token: 0x04000B1F RID: 2847
		public const string MiAdminLaunched = "mi_admin_launched";

		// Token: 0x04000B20 RID: 2848
		public const string MiBackupContinue = "mi_backup_continue";

		// Token: 0x04000B21 RID: 2849
		public const string MiBackupCancel = "mi_backup_cancel";

		// Token: 0x04000B22 RID: 2850
		public const string MiBackupCross = "mi_backup_cross";

		// Token: 0x04000B23 RID: 2851
		public const string MiInstallLicenseAgreed = "mi_license_agreed";

		// Token: 0x04000B24 RID: 2852
		public const string MiLowDiskSpaceRetried = "mi_low_disk_space_retried";

		// Token: 0x04000B25 RID: 2853
		public const string MiChecksPassed = "mi_checks_passed";

		// Token: 0x04000B26 RID: 2854
		public const string MiDownloadStarted = "mi_download_started";

		// Token: 0x04000B27 RID: 2855
		public const string MiDownloadFailed = "mi_download_failed";

		// Token: 0x04000B28 RID: 2856
		public const string MiDownloadRetried = "mi_download_retried";

		// Token: 0x04000B29 RID: 2857
		public const string MiDownloadCompleted = "mi_download_completed";

		// Token: 0x04000B2A RID: 2858
		public const string MiMinimizePopupInit = "mi_minimizepopup_init";

		// Token: 0x04000B2B RID: 2859
		public const string MiMinimizePopupYes = "mi_minimizepopup_yes";

		// Token: 0x04000B2C RID: 2860
		public const string MiMinimizePopupNo = "mi_minimizepopup_no";

		// Token: 0x04000B2D RID: 2861
		public const string MiClosed = "mi_closed";

		// Token: 0x04000B2E RID: 2862
		public const string MiFailed = "mi_failed";

		// Token: 0x04000B2F RID: 2863
		public const string MiFullInstallerLaunched = "mi_full_installer_launched";

		// Token: 0x04000B30 RID: 2864
		public const string MiAdminProcCompleted = "mi_admin_proc_completed";

		// Token: 0x04000B31 RID: 2865
		public const string MiRegistryNotFound = "mi_registry_not_found";

		// Token: 0x04000B32 RID: 2866
		public const string MiClientLaunchFailed = "mi_client_launch_failed";

		// Token: 0x04000B33 RID: 2867
		public const string MiClientLaunched = "mi_client_launched";

		// Token: 0x04000B34 RID: 2868
		public const string DeviceProvisioned = "device_provisioned";

		// Token: 0x04000B35 RID: 2869
		public const string GoogleLoginCompleted = "google_login_completed";

		// Token: 0x04000B36 RID: 2870
		public const string BlueStacksLoginCompleted = "bluestacks_login_completed";
	}
}
