﻿using System;

namespace BlueStacks.Common.Interop
{
	// Token: 0x0200021A RID: 538
	public enum UUIDTYPE
	{
		// Token: 0x04000D08 RID: 3336
		GLOBAL,
		// Token: 0x04000D09 RID: 3337
		LOCAL
	}
}
