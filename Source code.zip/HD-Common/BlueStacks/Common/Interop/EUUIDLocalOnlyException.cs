﻿using System;
using System.Runtime.Serialization;

namespace BlueStacks.Common.Interop
{
	// Token: 0x02000218 RID: 536
	[Serializable]
	public class EUUIDLocalOnlyException : EUUIDException
	{
		// Token: 0x060010EB RID: 4331 RVA: 0x0000E21D File Offset: 0x0000C41D
		public EUUIDLocalOnlyException()
		{
		}

		// Token: 0x060010EC RID: 4332 RVA: 0x0000E225 File Offset: 0x0000C425
		public EUUIDLocalOnlyException(string message) : base(message)
		{
		}

		// Token: 0x060010ED RID: 4333 RVA: 0x0000E22E File Offset: 0x0000C42E
		public EUUIDLocalOnlyException(string message, Exception innerException) : base(message, innerException)
		{
		}

		// Token: 0x060010EE RID: 4334 RVA: 0x0000E238 File Offset: 0x0000C438
		protected EUUIDLocalOnlyException(SerializationInfo serializationInfo, StreamingContext streamingContext) : base(serializationInfo, streamingContext)
		{
		}
	}
}
