﻿using System;
using System.Runtime.Serialization;

namespace BlueStacks.Common.Interop
{
	// Token: 0x02000217 RID: 535
	[Serializable]
	public class EUUIDException : Exception
	{
		// Token: 0x060010E7 RID: 4327 RVA: 0x000023F8 File Offset: 0x000005F8
		public EUUIDException()
		{
		}

		// Token: 0x060010E8 RID: 4328 RVA: 0x00002400 File Offset: 0x00000600
		public EUUIDException(string reason) : base(reason)
		{
		}

		// Token: 0x060010E9 RID: 4329 RVA: 0x00002409 File Offset: 0x00000609
		public EUUIDException(string message, Exception innerException) : base(message, innerException)
		{
		}

		// Token: 0x060010EA RID: 4330 RVA: 0x00002413 File Offset: 0x00000613
		protected EUUIDException(SerializationInfo serializationInfo, StreamingContext streamingContext) : base(serializationInfo, streamingContext)
		{
		}
	}
}
