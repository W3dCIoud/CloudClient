﻿using System;
using System.Runtime.Serialization;

namespace BlueStacks.Common.Interop
{
	// Token: 0x02000219 RID: 537
	[Serializable]
	public class EUUIDNoAddressException : EUUIDException
	{
		// Token: 0x060010EF RID: 4335 RVA: 0x0000E21D File Offset: 0x0000C41D
		public EUUIDNoAddressException()
		{
		}

		// Token: 0x060010F0 RID: 4336 RVA: 0x0000E225 File Offset: 0x0000C425
		public EUUIDNoAddressException(string message) : base(message)
		{
		}

		// Token: 0x060010F1 RID: 4337 RVA: 0x0000E22E File Offset: 0x0000C42E
		public EUUIDNoAddressException(string message, Exception innerException) : base(message, innerException)
		{
		}

		// Token: 0x060010F2 RID: 4338 RVA: 0x0000E238 File Offset: 0x0000C438
		protected EUUIDNoAddressException(SerializationInfo serializationInfo, StreamingContext streamingContext) : base(serializationInfo, streamingContext)
		{
		}
	}
}
