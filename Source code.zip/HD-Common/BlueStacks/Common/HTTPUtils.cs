﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x020000F4 RID: 244
	public static class HTTPUtils
	{
		// Token: 0x1700025F RID: 607
		// (get) Token: 0x0600081C RID: 2076 RVA: 0x00007F91 File Offset: 0x00006191
		public static string PartnerServerUrl
		{
			get
			{
				return string.Format(CultureInfo.InvariantCulture, "{0}:{1}", new object[]
				{
					HTTPUtils.sLoopbackUrl,
					RegistryManager.Instance.PartnerServerPort
				});
			}
		}

		// Token: 0x17000260 RID: 608
		// (get) Token: 0x0600081D RID: 2077 RVA: 0x00007FC2 File Offset: 0x000061C2
		public static string AgentServerUrl
		{
			get
			{
				return string.Format(CultureInfo.InvariantCulture, "{0}:{1}", new object[]
				{
					HTTPUtils.sLoopbackUrl,
					RegistryManager.Instance.AgentServerPort
				});
			}
		}

		// Token: 0x0600081E RID: 2078 RVA: 0x00007FF3 File Offset: 0x000061F3
		public static string FrontendServerUrl(string vmName = "Android")
		{
			return string.Format(CultureInfo.InvariantCulture, "{0}:{1}", new object[]
			{
				HTTPUtils.sLoopbackUrl,
				RegistryManager.Instance.Guest[vmName].FrontendServerPort
			});
		}

		// Token: 0x0600081F RID: 2079 RVA: 0x0000802F File Offset: 0x0000622F
		public static string GuestServerUrl(string vmName = "Android")
		{
			return string.Format(CultureInfo.InvariantCulture, "{0}:{1}", new object[]
			{
				HTTPUtils.sLoopbackUrl,
				RegistryManager.Instance.Guest[vmName].BstAndroidPort
			});
		}

		// Token: 0x17000261 RID: 609
		// (get) Token: 0x06000820 RID: 2080 RVA: 0x0000806B File Offset: 0x0000626B
		public static string BTvServerUrl
		{
			get
			{
				return string.Format(CultureInfo.InvariantCulture, "{0}:{1}", new object[]
				{
					HTTPUtils.sLoopbackUrl,
					RegistryManager.Instance.BTVServerPort
				});
			}
		}

		// Token: 0x06000821 RID: 2081 RVA: 0x00023850 File Offset: 0x00021A50
		public static string UrlForBstCommandProcessor(string url)
		{
			try
			{
				Uri uri = new Uri(url);
				foreach (string text in RegistryManager.Instance.VmList)
				{
					if (uri.Segments.Length > 1 && string.Compare("ping", uri.Segments[1], StringComparison.OrdinalIgnoreCase) != 0 && uri.Port == RegistryManager.Instance.Guest[text].BstAndroidPort)
					{
						return text;
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error Occured, Err: {0}", new object[]
				{
					ex.ToString()
				});
			}
			return null;
		}

		// Token: 0x06000822 RID: 2082 RVA: 0x000238F8 File Offset: 0x00021AF8
		public static NameValueCollection GetRequestHeaderCollection(string vmName)
		{
			NameValueCollection nameValueCollection = new NameValueCollection();
			nameValueCollection.Add("x_oem", RegistryManager.Instance.Oem);
			nameValueCollection.Add("x_email", RegistryManager.Instance.RegisteredEmail);
			nameValueCollection.Add("x_machine_id", GuidUtils.GetBlueStacksMachineId());
			nameValueCollection.Add("x_version_machine_id", GuidUtils.GetBlueStacksVersionId());
			if (!string.IsNullOrEmpty(vmName))
			{
				if (vmName.Contains("Android"))
				{
					nameValueCollection.Add("vmname", vmName);
					nameValueCollection.Add("x_google_aid", Utils.GetGoogleAdIdfromRegistry(vmName));
					nameValueCollection.Add("x_android_id", Utils.GetAndroidIdfromRegistry(vmName));
					if (string.Equals(vmName, "Android", StringComparison.InvariantCultureIgnoreCase))
					{
						nameValueCollection.Add("vmid", "0");
					}
					else
					{
						nameValueCollection.Add("vmid", vmName.Split(new char[]
						{
							'_'
						})[1]);
					}
				}
				else
				{
					nameValueCollection.Add("vmid", vmName);
					if (vmName.Equals("0", StringComparison.InvariantCultureIgnoreCase))
					{
						nameValueCollection.Add("vmname", "Android");
						nameValueCollection.Add("x_google_aid", Utils.GetGoogleAdIdfromRegistry("Android"));
						nameValueCollection.Add("x_android_id", Utils.GetAndroidIdfromRegistry("Android"));
					}
					else
					{
						nameValueCollection.Add("vmname", "Android_" + vmName);
						nameValueCollection.Add("x_google_aid", Utils.GetGoogleAdIdfromRegistry("Android_" + vmName));
						nameValueCollection.Add("x_android_id", Utils.GetAndroidIdfromRegistry("Android_" + vmName));
					}
				}
			}
			return nameValueCollection;
		}

		// Token: 0x06000823 RID: 2083 RVA: 0x0000809C File Offset: 0x0000629C
		public static RequestData ParseRequest(HttpListenerRequest req)
		{
			return HTTPUtils.ParseRequest(req, true);
		}

		// Token: 0x06000824 RID: 2084 RVA: 0x00023A84 File Offset: 0x00021C84
		public static RequestData ParseRequest(HttpListenerRequest req, bool printData)
		{
			RequestData requestData = new RequestData();
			bool flag = false;
			string text = null;
			requestData.Headers = ((req != null) ? req.Headers : null);
			requestData.RequestVmId = 0;
			requestData.RequestVmName = "Android";
			foreach (string text2 in requestData.Headers.AllKeys)
			{
				if (requestData.Headers[text2].Contains("multipart"))
				{
					text = "--" + requestData.Headers[text2].Substring(requestData.Headers[text2].LastIndexOf("=", StringComparison.OrdinalIgnoreCase) + 1);
					Logger.Debug("boundary: {0}", new object[]
					{
						text
					});
					flag = true;
				}
				if (text2 == "vmid" && requestData.Headers[text2] != null)
				{
					if (!requestData.Headers[text2].Equals("0", StringComparison.OrdinalIgnoreCase))
					{
						requestData.RequestVmId = int.Parse(requestData.Headers["vmid"], CultureInfo.InvariantCulture);
						if (requestData.RequestVmName == "Android")
						{
							RequestData requestData2 = requestData;
							requestData2.RequestVmName = requestData2.RequestVmName + "_" + requestData.Headers[text2].ToString(CultureInfo.InvariantCulture);
						}
					}
				}
				else if (text2 == "vmname" && requestData.Headers[text2] != null)
				{
					requestData.RequestVmName = requestData.Headers[text2].ToString(CultureInfo.InvariantCulture);
				}
			}
			requestData.QueryString = req.QueryString;
			if (!req.HasEntityBody)
			{
				return requestData;
			}
			Stream inputStream = req.InputStream;
			byte[] array = new byte[16384];
			MemoryStream memoryStream = new MemoryStream();
			int count;
			while ((count = inputStream.Read(array, 0, array.Length)) > 0)
			{
				memoryStream.Write(array, 0, count);
			}
			byte[] array2 = memoryStream.ToArray();
			memoryStream.Close();
			inputStream.Close();
			Logger.Debug("byte array size {0}", new object[]
			{
				array2.Length
			});
			string @string = Encoding.UTF8.GetString(array2);
			if (!flag)
			{
				if (!req.ContentType.Contains("application/json", StringComparison.InvariantCultureIgnoreCase))
				{
					requestData.Data = HttpUtility.ParseQueryString(@string);
				}
				else
				{
					JObject jobject = JObject.Parse(@string);
					NameValueCollection nameValueCollection = new NameValueCollection();
					foreach (string text3 in (from p in jobject.Properties()
					select p.Name).ToList<string>())
					{
						nameValueCollection.Add(text3, jobject[text3].ToString());
					}
					requestData.Data = nameValueCollection;
				}
				return requestData;
			}
			byte[] bytes = Encoding.UTF8.GetBytes(text);
			List<int> list = HTTPUtils.IndexOf(array2, bytes);
			for (int j = 0; j < list.Count - 1; j++)
			{
				Logger.Info("Creating part");
				int num = list[j];
				int num2 = list[j + 1];
				int num3 = num2 - num;
				byte[] array3 = new byte[num3];
				Logger.Debug("Start: {0}, End: {1}, Length: {2}", new object[]
				{
					num,
					num2,
					num3
				});
				Logger.Debug("byteData length: {0}", new object[]
				{
					array2.Length
				});
				Buffer.BlockCopy(array2, num, array3, 0, num3);
				Logger.Debug("bytePart length: {0}", new object[]
				{
					array3.Length
				});
				string string2 = Encoding.UTF8.GetString(array3);
				Match match = new Regex("(?<=Content\\-Type:)(.*?)(?=\\r\\n)").Match(string2);
				Match match2 = new Regex("(?<=filename\\=\\\")(.*?)(?=\\\")").Match(string2);
				string text4 = new Regex("(?<=name\\=\\\")(.*?)(?=\\\")").Match(string2).Value.Trim();
				Logger.Info("Got name: {0}", new object[]
				{
					text4
				});
				if (match.Success && match2.Success)
				{
					Logger.Debug("Found file");
					string text5 = match.Value.Trim();
					Logger.Debug("Got contenttype: {0}", new object[]
					{
						text5
					});
					string text6 = match2.Value.Trim();
					Logger.Info("Got filename: {0}", new object[]
					{
						text6
					});
					int num4 = string2.IndexOf("\r\n\r\n", StringComparison.OrdinalIgnoreCase) + "\r\n\r\n".Length;
					Encoding.UTF8.GetBytes("\r\n" + text);
					int num5 = num3 - num4;
					byte[] array4 = new byte[num5];
					Logger.Debug("startindex: {0}, contentlength: {1}", new object[]
					{
						num4,
						num5
					});
					Buffer.BlockCopy(array3, num4, array4, 0, num5);
					string path = RegistryStrings.BstUserDataDir;
					if (text6.StartsWith("tombstone", StringComparison.OrdinalIgnoreCase))
					{
						path = RegistryStrings.BstLogsDir;
					}
					string text7 = Path.Combine(path, text6);
					FileStream fileStream = File.OpenWrite(text7);
					fileStream.Write(array4, 0, num5);
					fileStream.Close();
					requestData.Files.Add(text4, text7);
				}
				else
				{
					Logger.Info("No file in this part");
					int num6 = string2.LastIndexOf("\r\n\r\n", StringComparison.OrdinalIgnoreCase);
					string text8 = string2.Substring(num6, string2.Length - num6);
					text8 = text8.Trim();
					if (printData)
					{
						Logger.Info("Got value: {0}", new object[]
						{
							text8
						});
					}
					else
					{
						Logger.Info("Value hidden");
					}
					requestData.Data.Add(text4, text8);
				}
			}
			return requestData;
		}

		// Token: 0x06000825 RID: 2085 RVA: 0x0002405C File Offset: 0x0002225C
		private static List<int> IndexOf(byte[] searchWithin, byte[] searchFor)
		{
			List<int> list = new List<int>();
			int startIndex = 0;
			int num = Array.IndexOf<byte>(searchWithin, searchFor[0], startIndex);
			Logger.Debug("boundary size = {0}", new object[]
			{
				searchFor.Length
			});
			do
			{
				int num2 = 0;
				while (num + num2 < searchWithin.Length && searchWithin[num + num2] == searchFor[num2])
				{
					num2++;
					if (num2 == searchFor.Length)
					{
						list.Add(num);
						Logger.Debug("Got boundary postion: {0}", new object[]
						{
							num
						});
						break;
					}
				}
				if (num + num2 > searchWithin.Length)
				{
					break;
				}
				num = Array.IndexOf<byte>(searchWithin, searchFor[0], num + num2);
			}
			while (num != -1);
			return list;
		}

		// Token: 0x06000826 RID: 2086 RVA: 0x000240F4 File Offset: 0x000222F4
		public static string MergeQueryParams(string urlOriginal, string urlOverideParams, bool paramsOnly = false)
		{
			NameValueCollection nameValueCollection = new NameValueCollection();
			if (paramsOnly)
			{
				nameValueCollection = HttpUtility.ParseQueryString(urlOverideParams);
			}
			else
			{
				nameValueCollection = HttpUtility.ParseQueryString(new UriBuilder(urlOverideParams).Query);
			}
			UriBuilder uriBuilder = new UriBuilder(urlOriginal);
			NameValueCollection nameValueCollection2 = HttpUtility.ParseQueryString(uriBuilder.Query);
			foreach (object obj in nameValueCollection.Keys)
			{
				nameValueCollection2.Set(obj.ToString(), nameValueCollection[obj.ToString()]);
			}
			uriBuilder.Query = nameValueCollection2.ToString();
			return uriBuilder.Uri.OriginalString;
		}

		// Token: 0x06000827 RID: 2087 RVA: 0x000080A5 File Offset: 0x000062A5
		public static void Write(StringBuilder sb, HttpListenerResponse res)
		{
			HTTPUtils.Write((sb != null) ? sb.ToString() : null, res);
		}

		// Token: 0x06000828 RID: 2088 RVA: 0x000241AC File Offset: 0x000223AC
		public static void Write(string s, HttpListenerResponse res)
		{
			try
			{
				byte[] bytes = Encoding.UTF8.GetBytes(s);
				if (res != null)
				{
					res.ContentLength64 = (long)bytes.Length;
					res.OutputStream.Write(bytes, 0, bytes.Length);
					res.OutputStream.Flush();
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in writing response to http output stream:{0}", new object[]
				{
					ex
				});
			}
		}

		// Token: 0x06000829 RID: 2089 RVA: 0x00024218 File Offset: 0x00022418
		public static HTTPServer SetupServer(int startingPort, int maxPort, Dictionary<string, HTTPServer.RequestHandler> routes, string s_RootDir)
		{
			HTTPServer httpserver = null;
			int i;
			for (i = startingPort; i < maxPort; i++)
			{
				try
				{
					httpserver = new HTTPServer(i, routes, s_RootDir);
					httpserver.Start();
					i = httpserver.Port;
					Logger.Info("Server listening on port " + httpserver.Port.ToString());
					if (!string.IsNullOrEmpty(httpserver.RootDir))
					{
						Logger.Info("Serving static content from " + httpserver.RootDir);
					}
					break;
				}
				catch (Exception ex)
				{
					Logger.Warning("Error occured, port: {0} Err: {1}", new object[]
					{
						i,
						ex
					});
				}
			}
			if (i == maxPort || httpserver == null)
			{
				Logger.Fatal("No free port available or server could not be started, exiting.");
				Environment.Exit(2);
			}
			return httpserver;
		}

		// Token: 0x0600082A RID: 2090 RVA: 0x000242D4 File Offset: 0x000224D4
		public static void SendRequestToClientAsync(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			if (retries == 1)
			{
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					try
					{
						HTTPUtils.SendRequestToClient(route, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec);
					}
					catch (Exception ex)
					{
						Logger.Error("An exception in SendRequestToClient. route: {0}, \n{1}", new object[]
						{
							route,
							ex
						});
					}
				});
				return;
			}
			new Thread(delegate()
			{
				try
				{
					HTTPUtils.SendRequestToClient(route, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec);
				}
				catch (Exception ex)
				{
					Logger.Error("An exception in SendRequestToClient. route: {0}, \n{1}", new object[]
					{
						route,
						ex
					});
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x0600082B RID: 2091 RVA: 0x0002435C File Offset: 0x0002255C
		public static void SendRequestToEngineAsync(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			if (retries == 1)
			{
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					try
					{
						HTTPUtils.SendRequestToEngine(route, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, "");
					}
					catch (Exception ex)
					{
						Logger.Error("An exception in SendRequestToEngine. route: {0}, \n{1}", new object[]
						{
							route,
							ex
						});
					}
				});
				return;
			}
			new Thread(delegate()
			{
				try
				{
					HTTPUtils.SendRequestToEngine(route, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, "");
				}
				catch (Exception ex)
				{
					Logger.Error("An exception in SendRequestToEngine. route: {0}, \n{1}", new object[]
					{
						route,
						ex
					});
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x0600082C RID: 2092 RVA: 0x000243E4 File Offset: 0x000225E4
		public static void SendRequestToAgentAsync(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			if (retries == 1)
			{
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					try
					{
						HTTPUtils.SendRequestToAgent(route, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec);
					}
					catch (Exception ex)
					{
						Logger.Error("An exception in SendRequestToAgent. route: {0}, \n{1}", new object[]
						{
							route,
							ex
						});
					}
				});
				return;
			}
			new Thread(delegate()
			{
				try
				{
					HTTPUtils.SendRequestToAgent(route, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec);
				}
				catch (Exception ex)
				{
					Logger.Error("An exception in SendRequestToAgent. route: {0}, \n{1}", new object[]
					{
						route,
						ex
					});
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x0600082D RID: 2093 RVA: 0x0002446C File Offset: 0x0002266C
		public static void SendRequestToGuestAsync(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			if (retries == 1)
			{
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					try
					{
						HTTPUtils.SendRequestToGuest(route, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec);
					}
					catch (Exception ex)
					{
						Logger.Error("An exception in SendRequestToGuest. route: {0}, \n{1}", new object[]
						{
							route,
							ex
						});
					}
				});
				return;
			}
			new Thread(delegate()
			{
				try
				{
					HTTPUtils.SendRequestToGuest(route, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec);
				}
				catch (Exception ex)
				{
					Logger.Error("An exception in SendRequestToGuest. route: {0}, \n{1}", new object[]
					{
						route,
						ex
					});
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x0600082E RID: 2094 RVA: 0x000244F4 File Offset: 0x000226F4
		public static void SendRequestToCloudAsync(string api, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			if (retries == 1)
			{
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					try
					{
						HTTPUtils.SendRequestToCloud(api, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
					}
					catch (Exception ex)
					{
						Logger.Error("An exception in SendRequestToCloud. route: {0}, \n{1}", new object[]
						{
							api,
							ex
						});
					}
				});
				return;
			}
			new Thread(delegate()
			{
				try
				{
					HTTPUtils.SendRequestToCloud(api, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
				}
				catch (Exception ex)
				{
					Logger.Error("An exception in SendRequestToCloud. route: {0}, \n{1}", new object[]
					{
						api,
						ex
					});
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x0600082F RID: 2095 RVA: 0x0002457C File Offset: 0x0002277C
		public static void SendRequestToCloudWithParamsAsync(string api, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			if (retries == 1)
			{
				ThreadPool.QueueUserWorkItem(delegate(object obj)
				{
					try
					{
						HTTPUtils.SendRequestToCloudWithParams(api, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec);
					}
					catch (Exception ex)
					{
						Logger.Error("An exception in SendRequestToCloudWithParams. route: {0}, \n{1}", new object[]
						{
							api,
							ex
						});
					}
				});
				return;
			}
			new Thread(delegate()
			{
				try
				{
					HTTPUtils.SendRequestToCloudWithParams(api, data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec);
				}
				catch (Exception ex)
				{
					Logger.Error("An exception in SendRequestToCloudWithParams. route: {0}, \n{1}", new object[]
					{
						api,
						ex
					});
				}
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x06000830 RID: 2096 RVA: 0x00024604 File Offset: 0x00022804
		public static string SendRequestToClient(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			return HTTPUtils.SendHTTPRequest(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
			{
				HTTPUtils.PartnerServerUrl,
				route
			}), data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
		}

		// Token: 0x06000831 RID: 2097 RVA: 0x00024644 File Offset: 0x00022844
		public static string SendRequestToEngine(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0, string destinationVmName = "")
		{
			if (string.IsNullOrEmpty(destinationVmName))
			{
				destinationVmName = vmName;
			}
			return HTTPUtils.SendHTTPRequest(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
			{
				HTTPUtils.FrontendServerUrl(destinationVmName),
				route
			}), data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
		}

		// Token: 0x06000832 RID: 2098 RVA: 0x00024694 File Offset: 0x00022894
		public static string SendRequestToAgent(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			return HTTPUtils.SendHTTPRequest(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
			{
				HTTPUtils.AgentServerUrl,
				route
			}), data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
		}

		// Token: 0x06000833 RID: 2099 RVA: 0x000246D4 File Offset: 0x000228D4
		public static string SendRequestToGuest(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			return HTTPUtils.SendHTTPRequest(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
			{
				HTTPUtils.GuestServerUrl(vmName),
				route
			}), data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
		}

		// Token: 0x06000834 RID: 2100 RVA: 0x00024714 File Offset: 0x00022914
		public static string SendRequestToBTv(string route, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			return HTTPUtils.SendHTTPRequest(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
			{
				HTTPUtils.BTvServerUrl,
				route
			}), data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
		}

		// Token: 0x06000835 RID: 2101 RVA: 0x00024754 File Offset: 0x00022954
		public static string SendRequestToCloud(string api, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0, bool isOnUIThreadOnPurpose = false)
		{
			return HTTPUtils.SendHTTPRequest(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
			{
				RegistryManager.Instance.Host,
				api
			}), data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, isOnUIThreadOnPurpose);
		}

		// Token: 0x06000836 RID: 2102 RVA: 0x0002479C File Offset: 0x0002299C
		public static string SendRequestToCloudWithParams(string api, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			return HTTPUtils.SendHTTPRequest(WebHelper.GetUrlWithParams(string.Format(CultureInfo.InvariantCulture, "{0}/{1}", new object[]
			{
				RegistryManager.Instance.Host,
				api
			})), data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
		}

		// Token: 0x06000837 RID: 2103 RVA: 0x000247E8 File Offset: 0x000229E8
		public static string SendRequestToNCSoftAgent(int port, string api, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0)
		{
			return HTTPUtils.SendHTTPRequest(string.Format(CultureInfo.InvariantCulture, "{0}:{1}/{2}", new object[]
			{
				HTTPUtils.sLoopbackUrl,
				port,
				api
			}), data, vmName, timeout, headers, printResponse, retries, sleepTimeMSec, false);
		}

		// Token: 0x06000838 RID: 2104 RVA: 0x00024834 File Offset: 0x00022A34
		private static string SendHTTPRequest(string url, Dictionary<string, string> data = null, string vmName = "Android", int timeout = 0, Dictionary<string, string> headers = null, bool printResponse = false, int retries = 1, int sleepTimeMSec = 0, bool isOnUIThreadOnPurpose = false)
		{
			string text;
			if (data == null)
			{
				Logger.Info("Sending GET to {0}", new object[]
				{
					url
				});
				text = BstHttpClient.Get(url, headers, false, vmName, timeout, retries, sleepTimeMSec, isOnUIThreadOnPurpose);
			}
			else
			{
				Logger.Info("Sending POST to {0}", new object[]
				{
					url
				});
				text = BstHttpClient.Post(url, data, headers, false, vmName, timeout, retries, sleepTimeMSec, isOnUIThreadOnPurpose);
			}
			if (printResponse)
			{
				Logger.Info("Loopback resp: {0}", new object[]
				{
					text
				});
			}
			else
			{
				Logger.Debug("Loopback resp: {0}", new object[]
				{
					text
				});
			}
			return text;
		}

		// Token: 0x06000839 RID: 2105 RVA: 0x000248C4 File Offset: 0x00022AC4
		public static void WriteSuccessArrayJson(HttpListenerResponse res, string reason = "")
		{
			if (string.IsNullOrEmpty(reason))
			{
				HTTPUtils.Write(JSonTemplates.SuccessArrayJSonTemplate, res);
				return;
			}
			JArray jarray = new JArray();
			JObject item = new JObject
			{
				{
					"success",
					true
				},
				{
					"reason",
					reason
				}
			};
			jarray.Add(item);
			HTTPUtils.Write(jarray.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x0600083A RID: 2106 RVA: 0x0002492C File Offset: 0x00022B2C
		public static void WriteErrorArrayJson(HttpListenerResponse res, string reason = "")
		{
			if (string.IsNullOrEmpty(reason))
			{
				HTTPUtils.Write(JSonTemplates.FailedArrayJSonTemplate, res);
				return;
			}
			JArray jarray = new JArray();
			JObject item = new JObject
			{
				{
					"success",
					false
				},
				{
					"reason",
					reason
				}
			};
			jarray.Add(item);
			HTTPUtils.Write(jarray.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x0600083B RID: 2107 RVA: 0x00024994 File Offset: 0x00022B94
		public static void WriteArrayJson(HttpListenerResponse res, Dictionary<string, string> data)
		{
			JArray jarray = new JArray();
			if (data != null)
			{
				JObject jobject = new JObject();
				foreach (KeyValuePair<string, string> keyValuePair in data)
				{
					jobject.Add(keyValuePair.Key, keyValuePair.Value);
				}
				jarray.Add(jobject);
			}
			HTTPUtils.Write(jarray.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x0600083C RID: 2108 RVA: 0x00024A20 File Offset: 0x00022C20
		public static void WriteArrayJson(HttpListenerResponse res, Dictionary<string, object> data)
		{
			JArray jarray = new JArray();
			if (data != null)
			{
				JObject jobject = new JObject();
				foreach (KeyValuePair<string, object> keyValuePair in data)
				{
					jobject.Add(keyValuePair.Key, JToken.FromObject(keyValuePair.Value));
				}
				jarray.Add(jobject);
			}
			HTTPUtils.Write(jarray.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x0600083D RID: 2109 RVA: 0x00024AAC File Offset: 0x00022CAC
		public static void WriteSuccessJson(HttpListenerResponse res, string reason = "")
		{
			if (string.IsNullOrEmpty(reason))
			{
				HTTPUtils.Write(JSonTemplates.SuccessJSonTemplate, res);
				return;
			}
			HTTPUtils.Write(new JObject
			{
				{
					"success",
					true
				},
				{
					"reason",
					reason
				}
			}.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x0600083E RID: 2110 RVA: 0x00024B08 File Offset: 0x00022D08
		public static void WriteErrorJson(HttpListenerResponse res, string reason = "")
		{
			if (string.IsNullOrEmpty(reason))
			{
				HTTPUtils.Write(JSonTemplates.FailedJSonTemplate, res);
				return;
			}
			HTTPUtils.Write(new JObject
			{
				{
					"success",
					false
				},
				{
					"reason",
					reason
				}
			}.ToString(Formatting.None, new JsonConverter[0]), res);
		}

		// Token: 0x04000416 RID: 1046
		private static string sLoopbackUrl = "http://127.0.0.1";
	}
}
