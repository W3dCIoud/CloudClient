﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace BlueStacks.Common
{
	// Token: 0x0200015E RID: 350
	public sealed class MacroGraph
	{
		// Token: 0x1700038A RID: 906
		// (get) Token: 0x06000BB4 RID: 2996 RVA: 0x0002AD70 File Offset: 0x00028F70
		public static BiDirectionalGraph<MacroRecording> Instance
		{
			get
			{
				if (MacroGraph.mInstance == null)
				{
					object obj = MacroGraph.lockObj;
					lock (obj)
					{
						if (MacroGraph.mInstance == null)
						{
							MacroGraph.mInstance = new BiDirectionalGraph<MacroRecording>(null);
							MacroGraph.CreateMacroGraphInstance();
						}
					}
				}
				return MacroGraph.mInstance;
			}
		}

		// Token: 0x06000BB5 RID: 2997 RVA: 0x0000B863 File Offset: 0x00009A63
		public static void ReCreateMacroGraphInstance()
		{
			if (MacroGraph.mInstance == null)
			{
				MacroGraph.mInstance = new BiDirectionalGraph<MacroRecording>(null);
			}
			MacroGraph.mInstance.Vertices.Clear();
			MacroGraph.CreateMacroGraphInstance();
		}

		// Token: 0x06000BB6 RID: 2998 RVA: 0x0002ADC8 File Offset: 0x00028FC8
		private static void CreateMacroGraphInstance()
		{
			if (Directory.Exists(RegistryStrings.MacroRecordingsFolderPath))
			{
				foreach (string path in Directory.GetFiles(RegistryStrings.MacroRecordingsFolderPath))
				{
					string path2 = Path.Combine(RegistryStrings.MacroRecordingsFolderPath, path);
					if (File.Exists(path2))
					{
						try
						{
							MacroRecording macroRecording = JsonConvert.DeserializeObject<MacroRecording>(File.ReadAllText(path2), Utils.GetSerializerSettings());
							if (macroRecording != null && !string.IsNullOrEmpty(macroRecording.Name) && !string.IsNullOrEmpty(macroRecording.TimeCreated))
							{
								if (macroRecording.Events == null)
								{
									ObservableCollection<MergedMacroConfiguration> mergedMacroConfigurations = macroRecording.MergedMacroConfigurations;
									if (mergedMacroConfigurations == null || mergedMacroConfigurations.Count <= 0)
									{
										goto IL_98;
									}
								}
								MacroGraph.mInstance.AddVertex(macroRecording);
							}
							IL_98:;
						}
						catch
						{
							Logger.Error("Unable to deserialize userscript.");
						}
					}
				}
				MacroGraph.DrawMacroGraph();
			}
		}

		// Token: 0x06000BB7 RID: 2999 RVA: 0x0002AEA0 File Offset: 0x000290A0
		private static void DrawMacroGraph()
		{
			foreach (BiDirectionalVertex<MacroRecording> biDirectionalVertex in MacroGraph.mInstance.Vertices)
			{
				MacroGraph.LinkMacroChilds(biDirectionalVertex as MacroRecording);
			}
		}

		// Token: 0x06000BB8 RID: 3000 RVA: 0x0002AEF4 File Offset: 0x000290F4
		public static void LinkMacroChilds(MacroRecording macro)
		{
			if (((macro != null) ? macro.MergedMacroConfigurations : null) != null)
			{
				using (IEnumerator<string> enumerator = macro.MergedMacroConfigurations.SelectMany((MergedMacroConfiguration macro_) => macro_.MacrosToRun).GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						string dependentMacro = enumerator.Current;
						MacroGraph.mInstance.AddParentChild(macro, (from MacroRecording macro_ in MacroGraph.mInstance.Vertices
						where string.Equals(macro_.Name, dependentMacro, StringComparison.InvariantCultureIgnoreCase)
						select macro_).FirstOrDefault<MacroRecording>());
					}
				}
			}
		}

		// Token: 0x06000BB9 RID: 3001 RVA: 0x0002AFAC File Offset: 0x000291AC
		public static bool CheckIfDependentMacrosAreAvailable(MacroRecording macro)
		{
			if (macro2 == null)
			{
				return false;
			}
			if (macro2.RecordingType == RecordingTypes.SingleRecording)
			{
				return true;
			}
			if (macro2.MergedMacroConfigurations.SelectMany((MergedMacroConfiguration macro) => macro.MacrosToRun).Distinct<string>().Count<string>() != macro2.Childs.Count)
			{
				return false;
			}
			return macro2.Childs.Cast<MacroRecording>().All((MacroRecording childMacro) => MacroGraph.CheckIfDependentMacrosAreAvailable(childMacro));
		}

		// Token: 0x04000671 RID: 1649
		private static BiDirectionalGraph<MacroRecording> mInstance = null;

		// Token: 0x04000672 RID: 1650
		private static readonly object lockObj = new object();
	}
}
