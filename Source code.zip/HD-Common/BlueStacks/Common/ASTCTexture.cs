﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200007A RID: 122
	public enum ASTCTexture
	{
		// Token: 0x0400013D RID: 317
		Disabled,
		// Token: 0x0400013E RID: 318
		Software,
		// Token: 0x0400013F RID: 319
		Hardware
	}
}
