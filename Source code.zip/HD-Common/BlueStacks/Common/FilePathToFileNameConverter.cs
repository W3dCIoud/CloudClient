﻿using System;
using System.Globalization;
using System.IO;
using System.Windows.Data;

namespace BlueStacks.Common
{
	// Token: 0x02000085 RID: 133
	public class FilePathToFileNameConverter : IValueConverter
	{
		// Token: 0x0600035B RID: 859 RVA: 0x00003DF3 File Offset: 0x00001FF3
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			if (value is string)
			{
				return Path.GetFileName(value.ToString());
			}
			return Binding.DoNothing;
		}

		// Token: 0x0600035C RID: 860 RVA: 0x00003E0E File Offset: 0x0000200E
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			throw new NotImplementedException();
		}
	}
}
