﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000067 RID: 103
	public class BrowserEventArgs : EventArgs
	{
		// Token: 0x17000098 RID: 152
		// (get) Token: 0x06000230 RID: 560 RVA: 0x0000323E File Offset: 0x0000143E
		// (set) Token: 0x06000231 RID: 561 RVA: 0x00003246 File Offset: 0x00001446
		public BrowserControlTags ClientTag { get; private set; }

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x06000232 RID: 562 RVA: 0x0000324F File Offset: 0x0000144F
		// (set) Token: 0x06000233 RID: 563 RVA: 0x00003257 File Offset: 0x00001457
		public string mPackageName { get; private set; } = string.Empty;

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x06000234 RID: 564 RVA: 0x00003260 File Offset: 0x00001460
		// (set) Token: 0x06000235 RID: 565 RVA: 0x00003268 File Offset: 0x00001468
		public string mVmName { get; private set; } = string.Empty;

		// Token: 0x06000236 RID: 566 RVA: 0x00003271 File Offset: 0x00001471
		public BrowserEventArgs(BrowserControlTags tag, string packageName, string vmName)
		{
			this.ClientTag = tag;
			this.mPackageName = packageName;
			this.mVmName = vmName;
		}
	}
}
