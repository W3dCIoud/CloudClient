﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;

namespace BlueStacks.Common
{
	// Token: 0x020000EB RID: 235
	public class CustomSettingsButton : Button, IComponentConnector
	{
		// Token: 0x06000677 RID: 1655 RVA: 0x000218A0 File Offset: 0x0001FAA0
		public CustomSettingsButton()
		{
			this.InitializeComponent();
			this.SetBackground();
			base.Loaded += this.CustomSettingsButton_Loaded;
			BlueStacksUIBinding.Instance.PropertyChanged += this.BlueStacksUIBinding_PropertyChanged;
		}

		// Token: 0x06000678 RID: 1656 RVA: 0x00005ED5 File Offset: 0x000040D5
		private void CustomSettingsButton_Loaded(object sender, RoutedEventArgs e)
		{
			this.SetNotification();
			this.SetSelectedLine();
		}

		// Token: 0x06000679 RID: 1657 RVA: 0x00005EE3 File Offset: 0x000040E3
		private void BlueStacksUIBinding_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			if (e.PropertyName == "LocaleModel")
			{
				this.SetSelectedLine();
			}
		}

		// Token: 0x170001B2 RID: 434
		// (get) Token: 0x0600067A RID: 1658 RVA: 0x00005EFD File Offset: 0x000040FD
		// (set) Token: 0x0600067B RID: 1659 RVA: 0x00005F05 File Offset: 0x00004105
		public string Group { get; set; } = string.Empty;

		// Token: 0x170001B3 RID: 435
		// (get) Token: 0x0600067C RID: 1660 RVA: 0x00005F0E File Offset: 0x0000410E
		// (set) Token: 0x0600067D RID: 1661 RVA: 0x00005F16 File Offset: 0x00004116
		public string ImageName { get; set; } = string.Empty;

		// Token: 0x170001B4 RID: 436
		// (get) Token: 0x0600067E RID: 1662 RVA: 0x00005F1F File Offset: 0x0000411F
		// (set) Token: 0x0600067F RID: 1663 RVA: 0x00021900 File Offset: 0x0001FB00
		public bool IsSelected
		{
			get
			{
				return this.isSelected;
			}
			set
			{
				this.isSelected = value;
				this.SetBackground();
				this.SetForeGround();
				this.SetSelectedLine();
				if (this.IsSelected && !string.IsNullOrEmpty(this.Group))
				{
					if (CustomSettingsButton.dictSelecetedButtons.ContainsKey(this.Group))
					{
						CustomSettingsButton.dictSelecetedButtons[this.Group].IsSelected = false;
					}
					CustomSettingsButton.dictSelecetedButtons[this.Group] = this;
				}
			}
		}

		// Token: 0x170001B5 RID: 437
		// (get) Token: 0x06000680 RID: 1664 RVA: 0x00005F27 File Offset: 0x00004127
		// (set) Token: 0x06000681 RID: 1665 RVA: 0x00005F2F File Offset: 0x0000412F
		public bool ShowButtonNotification
		{
			get
			{
				return this.showButtonNotification;
			}
			set
			{
				this.showButtonNotification = value;
				this.SetNotification();
			}
		}

		// Token: 0x06000682 RID: 1666 RVA: 0x00021974 File Offset: 0x0001FB74
		private void SetNotification()
		{
			Ellipse ellipse = (Ellipse)base.Template.FindName("mBtnNotification", this);
			if (ellipse != null)
			{
				if (this.showButtonNotification)
				{
					ellipse.Visibility = Visibility.Visible;
					return;
				}
				ellipse.Visibility = Visibility.Hidden;
			}
		}

		// Token: 0x06000683 RID: 1667 RVA: 0x00005F3E File Offset: 0x0000413E
		private void SetForeGround()
		{
			if (this.isSelected)
			{
				BlueStacksUIBinding.BindColor(this, Control.ForegroundProperty, "SettingsWindowTabMenuItemSelectedForeground");
				return;
			}
			BlueStacksUIBinding.BindColor(this, Control.ForegroundProperty, "SettingsWindowTabMenuItemForeground");
		}

		// Token: 0x06000684 RID: 1668 RVA: 0x00005F69 File Offset: 0x00004169
		private void SetBackground()
		{
			if (this.IsSelected)
			{
				BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "SettingsWindowTabMenuItemSelectedBackground");
				return;
			}
			this.Button_MouseEvent(null, null);
		}

		// Token: 0x06000685 RID: 1669 RVA: 0x000219B4 File Offset: 0x0001FBB4
		private void SetSelectedLine()
		{
			Line line = (Line)base.Template.FindName("mSelectedLine", this);
			ContentPresenter contentPresenter = (ContentPresenter)base.Template.FindName("contentPresenter", this);
			if (line != null)
			{
				if (this.isSelected)
				{
					line.Visibility = Visibility.Visible;
					TextBlock textBlock = (TextBlock)contentPresenter.Content;
					Typeface typeface = new Typeface(textBlock.FontFamily, textBlock.FontStyle, textBlock.FontWeight, textBlock.FontStretch);
					double widthIncludingTrailingWhitespace = new FormattedText(textBlock.Text, Thread.CurrentThread.CurrentCulture, textBlock.FlowDirection, typeface, textBlock.FontSize, textBlock.Foreground).WidthIncludingTrailingWhitespace;
					line.X2 = widthIncludingTrailingWhitespace;
					return;
				}
				line.Visibility = Visibility.Collapsed;
			}
		}

		// Token: 0x06000686 RID: 1670 RVA: 0x00005F8C File Offset: 0x0000418C
		private void Button_MouseEvent(object sender, MouseEventArgs e)
		{
			if (!this.IsSelected)
			{
				if (base.IsMouseOver)
				{
					BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "SettingsWindowTabMenuItemHoverBackground");
					return;
				}
				BlueStacksUIBinding.BindColor(this, Control.BackgroundProperty, "SettingsWindowTabMenuItemBackground");
			}
		}

		// Token: 0x06000687 RID: 1671 RVA: 0x00005FBF File Offset: 0x000041BF
		private void Button_Click(object sender, RoutedEventArgs e)
		{
			if (!this.IsSelected)
			{
				this.IsSelected = true;
			}
		}

		// Token: 0x06000688 RID: 1672 RVA: 0x00005FD0 File Offset: 0x000041D0
		private void Button_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (string.IsNullOrEmpty(this.Group))
			{
				this.IsSelected = true;
			}
		}

		// Token: 0x06000689 RID: 1673 RVA: 0x00005FE6 File Offset: 0x000041E6
		private void Button_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			if (string.IsNullOrEmpty(this.Group))
			{
				this.IsSelected = false;
				this.Button_MouseEvent(null, null);
			}
		}

		// Token: 0x0600068A RID: 1674 RVA: 0x00021A6C File Offset: 0x0001FC6C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/customsettingsbutton.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600068B RID: 1675 RVA: 0x00021A9C File Offset: 0x0001FC9C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				((CustomSettingsButton)target).MouseEnter += this.Button_MouseEvent;
				((CustomSettingsButton)target).MouseLeave += this.Button_MouseEvent;
				((CustomSettingsButton)target).Click += this.Button_Click;
				((CustomSettingsButton)target).PreviewMouseDown += this.Button_PreviewMouseDown;
				((CustomSettingsButton)target).PreviewMouseUp += this.Button_PreviewMouseUp;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x0400037A RID: 890
		private static Dictionary<string, CustomSettingsButton> dictSelecetedButtons = new Dictionary<string, CustomSettingsButton>();

		// Token: 0x0400037D RID: 893
		private bool isSelected;

		// Token: 0x0400037E RID: 894
		private bool showButtonNotification;

		// Token: 0x0400037F RID: 895
		private bool _contentLoaded;
	}
}
