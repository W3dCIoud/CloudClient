﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.IO;
using System.Net;
using System.Threading;

namespace BlueStacks.Common
{
	// Token: 0x02000097 RID: 151
	public class HTTPServer : IDisposable
	{
		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x060003A3 RID: 931 RVA: 0x00004108 File Offset: 0x00002308
		public int Port { get; }

		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x060003A4 RID: 932 RVA: 0x00004110 File Offset: 0x00002310
		// (set) Token: 0x060003A5 RID: 933 RVA: 0x00004118 File Offset: 0x00002318
		public string RootDir { get; set; }

		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x060003A6 RID: 934 RVA: 0x00004121 File Offset: 0x00002321
		// (set) Token: 0x060003A7 RID: 935 RVA: 0x00004128 File Offset: 0x00002328
		public static bool FileWriteComplete { get; set; } = true;

		// Token: 0x060003A8 RID: 936 RVA: 0x00004130 File Offset: 0x00002330
		public HTTPServer(int port, Dictionary<string, HTTPServer.RequestHandler> routes, string rootDir)
		{
			this.Port = port;
			this.Routes = routes;
			this.RootDir = rootDir;
		}

		// Token: 0x060003A9 RID: 937 RVA: 0x000155C4 File Offset: 0x000137C4
		public void Start()
		{
			string uriPrefix = string.Format(CultureInfo.InvariantCulture, "http://{0}:{1}/", new object[]
			{
				"*",
				this.Port
			});
			this.mListener = new HttpListener();
			this.mListener.Prefixes.Add(uriPrefix);
			try
			{
				this.mShutDown = false;
				this.mListener.Start();
			}
			catch (HttpListenerException ex)
			{
				Logger.Error("Failed to start listener. err: " + ex.ToString());
				throw new ENoPortAvailableException("No free port available");
			}
		}

		// Token: 0x060003AA RID: 938 RVA: 0x00015660 File Offset: 0x00013860
		public void Run()
		{
			while (!this.mShutDown)
			{
				HttpListenerContext ctx = null;
				try
				{
					ctx = this.mListener.GetContext();
				}
				catch (Exception ex)
				{
					Logger.Error("Exception while processing HTTP context: " + ex.ToString());
					continue;
				}
				ThreadPool.QueueUserWorkItem(new WaitCallback(new HTTPServer.Worker(ctx, this.Routes, this.RootDir).ProcessRequest));
			}
		}

		// Token: 0x060003AB RID: 939 RVA: 0x000156D4 File Offset: 0x000138D4
		public void Stop()
		{
			if (this.mListener != null)
			{
				try
				{
					this.mShutDown = true;
					this.mListener.Close();
				}
				catch (HttpListenerException ex)
				{
					Logger.Error("Failed to stop listener. err: " + ex.ToString());
				}
			}
		}

		// Token: 0x060003AC RID: 940 RVA: 0x00015728 File Offset: 0x00013928
		~HTTPServer()
		{
			this.Dispose(false);
		}

		// Token: 0x060003AD RID: 941 RVA: 0x0000414D File Offset: 0x0000234D
		protected virtual void Dispose(bool disposing)
		{
			if (!this.disposedValue)
			{
				HttpListener httpListener = this.mListener;
				if (httpListener != null)
				{
					httpListener.Close();
				}
				this.disposedValue = true;
			}
		}

		// Token: 0x060003AE RID: 942 RVA: 0x00004171 File Offset: 0x00002371
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x040001AA RID: 426
		private HttpListener mListener;

		// Token: 0x040001AB RID: 427
		private bool mShutDown;

		// Token: 0x040001AD RID: 429
		private readonly Dictionary<string, HTTPServer.RequestHandler> Routes;

		// Token: 0x040001B0 RID: 432
		private bool disposedValue;

		// Token: 0x02000098 RID: 152
		// (Invoke) Token: 0x060003B1 RID: 945
		public delegate void RequestHandler(HttpListenerRequest req, HttpListenerResponse res);

		// Token: 0x02000099 RID: 153
		private class Worker
		{
			// Token: 0x060003B4 RID: 948 RVA: 0x00004188 File Offset: 0x00002388
			public Worker(HttpListenerContext ctx, Dictionary<string, HTTPServer.RequestHandler> routes, string rootDir)
			{
				this.mCtx = ctx;
				this.mRoutes = routes;
				this.mRootDir = rootDir;
			}

			// Token: 0x060003B5 RID: 949 RVA: 0x00015758 File Offset: 0x00013958
			[STAThread]
			public void ProcessRequest(object stateInfo)
			{
				try
				{
					if (this.mCtx.Request.Url.AbsolutePath.StartsWith("/static/", StringComparison.OrdinalIgnoreCase))
					{
						this.StaticFileHandler(this.mCtx.Request, this.mCtx.Response);
					}
					else if (this.mCtx.Request.Url.AbsolutePath.StartsWith("/static2/", StringComparison.OrdinalIgnoreCase))
					{
						this.StaticFileChunkHandler(this.mCtx.Request, this.mCtx.Response, "");
					}
					else if (this.mCtx.Request.Url.AbsolutePath.StartsWith("/staticicon/", StringComparison.OrdinalIgnoreCase))
					{
						this.StaticFileChunkHandler(this.mCtx.Request, this.mCtx.Response, Path.Combine(RegistryManager.Instance.EngineDataDir, "UserData\\Gadget"));
					}
					else if (this.mRoutes.ContainsKey(this.mCtx.Request.Url.AbsolutePath))
					{
						HTTPServer.RequestHandler requestHandler = this.mRoutes[this.mCtx.Request.Url.AbsolutePath];
						if (requestHandler != null)
						{
							if (this.mCtx.Request.UserAgent != null)
							{
								Logger.Info("Request received {0}", new object[]
								{
									this.mCtx.Request.Url.AbsolutePath
								});
								Logger.Debug("UserAgent = {0}", new object[]
								{
									this.mCtx.Request.UserAgent
								});
							}
							if (HTTPServer.Worker.IsTokenValid(this.mCtx.Request.Headers))
							{
								requestHandler(this.mCtx.Request, this.mCtx.Response);
							}
							else
							{
								Logger.Warning("Token validation check failed, unauthorized access");
								HTTPUtils.WriteErrorJson(this.mCtx.Response, "Unauthorized Access(401)");
								this.mCtx.Response.StatusCode = 401;
							}
						}
					}
					else
					{
						Logger.Warning("Exception: No Handler registered for " + this.mCtx.Request.Url.AbsolutePath);
						HTTPUtils.WriteErrorJson(this.mCtx.Response, "Request NotFound(404)");
						this.mCtx.Response.StatusCode = 404;
					}
				}
				catch (Exception ex)
				{
					Logger.Error("Exception while processing HTTP handler: " + ex.ToString());
					HTTPUtils.WriteErrorJson(this.mCtx.Response, "Internal Server Error(500)");
					this.mCtx.Response.StatusCode = 500;
				}
				finally
				{
					try
					{
						this.mCtx.Response.OutputStream.Close();
					}
					catch (Exception ex2)
					{
						Logger.Warning("Exception during mCtx.Response.OutputStream.Close(): " + ex2.ToString());
					}
				}
			}

			// Token: 0x060003B6 RID: 950 RVA: 0x000041A5 File Offset: 0x000023A5
			private static bool IsTokenValid(NameValueCollection headers)
			{
				return headers["x_api_token"] != null && headers["x_api_token"].ToString(CultureInfo.InvariantCulture).Equals(RegistryManager.Instance.ApiToken, StringComparison.OrdinalIgnoreCase);
			}

			// Token: 0x060003B7 RID: 951 RVA: 0x00015A70 File Offset: 0x00013C70
			public void StaticFileHandler(HttpListenerRequest req, HttpListenerResponse res)
			{
				string text = req.Url.AbsolutePath;
				text = text.Substring(text.Substring(1).IndexOf("/", StringComparison.OrdinalIgnoreCase) + 2);
				string text2 = Path.Combine(this.mRootDir, text.Replace("/", "\\"));
				if (File.Exists(text2))
				{
					byte[] array = File.ReadAllBytes(text2);
					if (text2.EndsWith(".css", StringComparison.OrdinalIgnoreCase))
					{
						res.Headers.Add("Content-Type: text/css");
					}
					else if (text2.EndsWith(".js", StringComparison.OrdinalIgnoreCase))
					{
						res.Headers.Add("Content-Type: application/javascript");
					}
					res.OutputStream.Write(array, 0, array.Length);
					return;
				}
				Logger.Error(string.Format(CultureInfo.InvariantCulture, "File {0} doesn't exist", new object[]
				{
					text2
				}));
				res.StatusCode = 404;
				res.StatusDescription = "Not Found.";
			}

			// Token: 0x060003B8 RID: 952 RVA: 0x00015B54 File Offset: 0x00013D54
			public void StaticFileChunkHandler(HttpListenerRequest req, HttpListenerResponse res, string dir = "")
			{
				string text = req.Url.AbsolutePath;
				text = text.Substring(text.Substring(1).IndexOf("/", StringComparison.OrdinalIgnoreCase) + 2);
				string text2;
				if (string.IsNullOrEmpty(dir))
				{
					text2 = Path.Combine(this.mRootDir, text.Replace("/", "\\"));
				}
				else
				{
					text2 = Path.Combine(dir, text.Replace("/", "\\"));
				}
				Logger.Info(string.Format(CultureInfo.InvariantCulture, "StaticFileChunkHandler: serving {0} from {1}", new object[]
				{
					req.Url,
					text2
				}));
				int num = 50;
				while (!File.Exists(text2))
				{
					num++;
					Thread.Sleep(100);
					if (num == 50)
					{
						break;
					}
				}
				num = 0;
				if (File.Exists(text2))
				{
					if (text2.EndsWith(".flv", StringComparison.OrdinalIgnoreCase))
					{
						res.Headers.Add("Content-Type: video/x-flv");
					}
					int num2 = 1048576;
					FileStream fileStream = new FileStream(text2, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
					for (;;)
					{
						byte[] buffer = new byte[num2];
						int num3 = fileStream.Read(buffer, 0, num2);
						if (num3 != 0)
						{
							res.OutputStream.Write(buffer, 0, num3);
							num = 0;
						}
						else
						{
							Thread.Sleep(100);
							if (num++ == 50)
							{
								break;
							}
						}
					}
					fileStream.Close();
					return;
				}
				Logger.Error(string.Format(CultureInfo.InvariantCulture, "File {0} doesn't exist", new object[]
				{
					text2
				}));
				res.StatusCode = 404;
				res.StatusDescription = "Not Found.";
			}

			// Token: 0x040001B1 RID: 433
			private Dictionary<string, HTTPServer.RequestHandler> mRoutes;

			// Token: 0x040001B2 RID: 434
			private HttpListenerContext mCtx;

			// Token: 0x040001B3 RID: 435
			private string mRootDir;
		}
	}
}
