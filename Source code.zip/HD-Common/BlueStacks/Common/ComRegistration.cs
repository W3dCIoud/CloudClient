﻿using System;
using System.Diagnostics;
using System.IO;

namespace BlueStacks.Common
{
	// Token: 0x0200009B RID: 155
	public static class ComRegistration
	{
		// Token: 0x060003BD RID: 957 RVA: 0x000041DE File Offset: 0x000023DE
		public static int Register()
		{
			Logger.Info("Registering COM components");
			return ComRegistration.RunBinary("-reg");
		}

		// Token: 0x060003BE RID: 958 RVA: 0x000041F4 File Offset: 0x000023F4
		public static int Unregister()
		{
			Logger.Info("Unregistering COM components");
			return ComRegistration.RunBinary("-unreg");
		}

		// Token: 0x060003BF RID: 959 RVA: 0x00015CC4 File Offset: 0x00013EC4
		private static int RunBinary(string args)
		{
			Process process = new Process();
			process.StartInfo.FileName = ComRegistration.BIN_PATH;
			process.StartInfo.Arguments = args;
			process.StartInfo.UseShellExecute = true;
			process.StartInfo.CreateNoWindow = true;
			process.StartInfo.Verb = "runas";
			process.Start();
			process.WaitForExit();
			return process.ExitCode;
		}

		// Token: 0x040001B4 RID: 436
		private static string BIN_PATH = Path.Combine(RegistryStrings.InstallDir, "HD-ComRegistrar.exe");
	}
}
