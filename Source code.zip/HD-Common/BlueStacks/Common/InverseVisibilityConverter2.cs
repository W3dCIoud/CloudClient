﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace BlueStacks.Common
{
	// Token: 0x0200005F RID: 95
	public class InverseVisibilityConverter2 : IValueConverter
	{
		// Token: 0x06000208 RID: 520 RVA: 0x00002FFA File Offset: 0x000011FA
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			if (value == null)
			{
				return Binding.DoNothing;
			}
			return ((Visibility)value == Visibility.Visible) ? Visibility.Collapsed : Visibility.Visible;
		}

		// Token: 0x06000209 RID: 521 RVA: 0x00002FFA File Offset: 0x000011FA
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			if (value == null)
			{
				return Binding.DoNothing;
			}
			return ((Visibility)value == Visibility.Visible) ? Visibility.Collapsed : Visibility.Visible;
		}
	}
}
