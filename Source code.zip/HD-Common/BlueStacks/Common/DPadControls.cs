﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000124 RID: 292
	public enum DPadControls
	{
		// Token: 0x0400053C RID: 1340
		KeyUp,
		// Token: 0x0400053D RID: 1341
		KeyLeft,
		// Token: 0x0400053E RID: 1342
		KeyDown,
		// Token: 0x0400053F RID: 1343
		KeyRight,
		// Token: 0x04000540 RID: 1344
		DpadTitle,
		// Token: 0x04000541 RID: 1345
		GamepadStick,
		// Token: 0x04000542 RID: 1346
		KeySpeedModifier1,
		// Token: 0x04000543 RID: 1347
		KeySpeedModifier2
	}
}
