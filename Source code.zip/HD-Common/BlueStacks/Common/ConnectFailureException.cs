﻿using System;
using System.Runtime.Serialization;

namespace BlueStacks.Common
{
	// Token: 0x020001A5 RID: 421
	[Serializable]
	public class ConnectFailureException : Exception
	{
		// Token: 0x170003D9 RID: 985
		// (get) Token: 0x06000E2C RID: 3628 RVA: 0x0000CBB0 File Offset: 0x0000ADB0
		// (set) Token: 0x06000E2D RID: 3629 RVA: 0x0000CBB8 File Offset: 0x0000ADB8
		public int ErrorCode { get; set; } = 1;

		// Token: 0x170003DA RID: 986
		// (get) Token: 0x06000E2E RID: 3630 RVA: 0x0000CBC1 File Offset: 0x0000ADC1
		public override string Message
		{
			get
			{
				return "The remote service point could not be contacted.";
			}
		}

		// Token: 0x06000E2F RID: 3631 RVA: 0x0000CBC8 File Offset: 0x0000ADC8
		public ConnectFailureException(Exception innerException) : base("", innerException)
		{
		}

		// Token: 0x06000E30 RID: 3632 RVA: 0x0000CBDD File Offset: 0x0000ADDD
		public ConnectFailureException()
		{
		}

		// Token: 0x06000E31 RID: 3633 RVA: 0x0000CBEC File Offset: 0x0000ADEC
		public ConnectFailureException(string message) : base(message)
		{
		}

		// Token: 0x06000E32 RID: 3634 RVA: 0x0000CBFC File Offset: 0x0000ADFC
		public ConnectFailureException(string message, Exception innerException) : base(message, innerException)
		{
		}

		// Token: 0x06000E33 RID: 3635 RVA: 0x0000CC0D File Offset: 0x0000AE0D
		protected ConnectFailureException(SerializationInfo serializationInfo, StreamingContext streamingContext) : base(serializationInfo, streamingContext)
		{
		}
	}
}
