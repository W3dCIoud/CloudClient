﻿using System;
using System.Runtime.InteropServices;

namespace BlueStacks.Common
{
	// Token: 0x020000DF RID: 223
	public static class ConsoleControl
	{
		// Token: 0x060005F0 RID: 1520
		[DllImport("Kernel32")]
		private static extern bool SetConsoleCtrlHandler(ConsoleControl.Handler handler, bool Add);

		// Token: 0x060005F1 RID: 1521 RVA: 0x000057BE File Offset: 0x000039BE
		public static void SetHandler(ConsoleControl.Handler handler)
		{
			ConsoleControl.SetConsoleCtrlHandler(handler, true);
		}

		// Token: 0x020000E0 RID: 224
		// (Invoke) Token: 0x060005F3 RID: 1523
		public delegate bool Handler(CtrlType ctrlType);
	}
}
