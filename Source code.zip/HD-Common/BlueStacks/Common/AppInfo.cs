﻿using System;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x0200012D RID: 301
	public class AppInfo
	{
		// Token: 0x17000271 RID: 625
		// (get) Token: 0x0600089A RID: 2202 RVA: 0x000082F2 File Offset: 0x000064F2
		// (set) Token: 0x0600089B RID: 2203 RVA: 0x000082FA File Offset: 0x000064FA
		public string Name { get; set; }

		// Token: 0x17000272 RID: 626
		// (get) Token: 0x0600089C RID: 2204 RVA: 0x00008303 File Offset: 0x00006503
		// (set) Token: 0x0600089D RID: 2205 RVA: 0x0000830B File Offset: 0x0000650B
		public string Img { get; set; }

		// Token: 0x17000273 RID: 627
		// (get) Token: 0x0600089E RID: 2206 RVA: 0x00008314 File Offset: 0x00006514
		// (set) Token: 0x0600089F RID: 2207 RVA: 0x0000831C File Offset: 0x0000651C
		public string Package { get; set; }

		// Token: 0x17000274 RID: 628
		// (get) Token: 0x060008A0 RID: 2208 RVA: 0x00008325 File Offset: 0x00006525
		// (set) Token: 0x060008A1 RID: 2209 RVA: 0x0000832D File Offset: 0x0000652D
		public string Activity { get; set; }

		// Token: 0x17000275 RID: 629
		// (get) Token: 0x060008A2 RID: 2210 RVA: 0x00008336 File Offset: 0x00006536
		// (set) Token: 0x060008A3 RID: 2211 RVA: 0x0000833E File Offset: 0x0000653E
		public string System { get; set; }

		// Token: 0x17000276 RID: 630
		// (get) Token: 0x060008A4 RID: 2212 RVA: 0x00008347 File Offset: 0x00006547
		// (set) Token: 0x060008A5 RID: 2213 RVA: 0x0000834F File Offset: 0x0000654F
		public string Url { get; set; }

		// Token: 0x17000277 RID: 631
		// (get) Token: 0x060008A6 RID: 2214 RVA: 0x00008358 File Offset: 0x00006558
		// (set) Token: 0x060008A7 RID: 2215 RVA: 0x00008360 File Offset: 0x00006560
		public string Appstore { get; set; }

		// Token: 0x17000278 RID: 632
		// (get) Token: 0x060008A8 RID: 2216 RVA: 0x00008369 File Offset: 0x00006569
		// (set) Token: 0x060008A9 RID: 2217 RVA: 0x00008371 File Offset: 0x00006571
		public string Version { get; set; }

		// Token: 0x17000279 RID: 633
		// (get) Token: 0x060008AA RID: 2218 RVA: 0x0000837A File Offset: 0x0000657A
		// (set) Token: 0x060008AB RID: 2219 RVA: 0x00008382 File Offset: 0x00006582
		public string VersionName { get; set; } = "Unknown";

		// Token: 0x1700027A RID: 634
		// (get) Token: 0x060008AC RID: 2220 RVA: 0x0000838B File Offset: 0x0000658B
		// (set) Token: 0x060008AD RID: 2221 RVA: 0x00008393 File Offset: 0x00006593
		public bool Gl3Required { get; set; }

		// Token: 0x1700027B RID: 635
		// (get) Token: 0x060008AE RID: 2222 RVA: 0x0000839C File Offset: 0x0000659C
		// (set) Token: 0x060008AF RID: 2223 RVA: 0x000083A4 File Offset: 0x000065A4
		public bool VideoPresent { get; set; }

		// Token: 0x060008B0 RID: 2224 RVA: 0x000083AD File Offset: 0x000065AD
		public AppInfo()
		{
		}

		// Token: 0x060008B1 RID: 2225 RVA: 0x00025D8C File Offset: 0x00023F8C
		public AppInfo(JObject app)
		{
			this.Name = ((app != null) ? app["name"].ToString() : null);
			this.Img = app["img"].ToString();
			this.Package = app["package"].ToString();
			this.Activity = app["activity"].ToString();
			this.System = app["system"].ToString();
			this.Url = (app.ContainsKey("url") ? app["url"].ToString() : null);
			this.Appstore = (app.ContainsKey("appstore") ? app["appstore"].ToString() : "Unknown");
			this.Version = (app.ContainsKey("version") ? app["version"].ToString() : "Unknown");
			this.Gl3Required = (app.ContainsKey("gl3required") && app["gl3required"].ToObject<bool>());
			this.VideoPresent = (app.ContainsKey("videopresent") && app["videopresent"].ToObject<bool>());
			if (app.ContainsKey("versionName"))
			{
				this.VersionName = app["versionName"].ToString();
			}
		}

		// Token: 0x060008B2 RID: 2226 RVA: 0x00025F08 File Offset: 0x00024108
		public AppInfo(string InName, string InImage, string InPackage, string InActivity, string InSystem, string InAppStore, string InVersion, bool InGl3required, bool InVideoPresent, string appVersionName)
		{
			this.Name = InName;
			this.Img = InImage;
			this.Package = InPackage;
			this.Activity = InActivity;
			this.System = InSystem;
			this.Url = null;
			this.Appstore = InAppStore;
			this.Version = InVersion;
			this.Gl3Required = InGl3required;
			this.VideoPresent = InVideoPresent;
			this.VersionName = appVersionName;
		}
	}
}
