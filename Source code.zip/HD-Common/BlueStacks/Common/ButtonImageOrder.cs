﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000121 RID: 289
	public enum ButtonImageOrder
	{
		// Token: 0x04000531 RID: 1329
		BeforeText,
		// Token: 0x04000532 RID: 1330
		AfterText
	}
}
