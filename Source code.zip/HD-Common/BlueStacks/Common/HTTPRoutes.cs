﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001B2 RID: 434
	public static class HTTPRoutes
	{
		// Token: 0x020001B3 RID: 435
		public static class Agent
		{
			// Token: 0x040007B5 RID: 1973
			public const string Ping = "ping";

			// Token: 0x040007B6 RID: 1974
			public const string GuestBootFailed = "guestBootFailed";

			// Token: 0x040007B7 RID: 1975
			public const string LaunchDefaultWebApp = "launchDefaultWebApp";

			// Token: 0x040007B8 RID: 1976
			public const string Installed = "installed";

			// Token: 0x040007B9 RID: 1977
			public const string Uninstalled = "uninstalled";

			// Token: 0x040007BA RID: 1978
			public const string GetAppList = "getAppList";

			// Token: 0x040007BB RID: 1979
			public const string Install = "install";

			// Token: 0x040007BC RID: 1980
			public const string Uninstall = "uninstall";

			// Token: 0x040007BD RID: 1981
			public const string RunApp = "runApp";

			// Token: 0x040007BE RID: 1982
			public const string SetLocale = "setLocale";

			// Token: 0x040007BF RID: 1983
			public const string InstallAppByUrl = "installAppByUrl";

			// Token: 0x040007C0 RID: 1984
			public const string AppCrashedInfo = "appCrashedInfo";

			// Token: 0x040007C1 RID: 1985
			public const string GetUserData = "getUserData";

			// Token: 0x040007C2 RID: 1986
			public const string ShowNotification = "showNotification";

			// Token: 0x040007C3 RID: 1987
			public const string AppDownloadStatus = "appDownloadStatus";

			// Token: 0x040007C4 RID: 1988
			public const string ShowFeNotification = "showFeNotification";

			// Token: 0x040007C5 RID: 1989
			public const string BindMount = "bindmount";

			// Token: 0x040007C6 RID: 1990
			public const string UnbindMount = "unbindmount";

			// Token: 0x040007C7 RID: 1991
			public const string QuitFrontend = "quitFrontend";

			// Token: 0x040007C8 RID: 1992
			public const string GetAppImage = "getAppImage";

			// Token: 0x040007C9 RID: 1993
			public const string ShowTrayNotification = "showTrayNotification";

			// Token: 0x040007CA RID: 1994
			public const string Restart = "restart";

			// Token: 0x040007CB RID: 1995
			public const string Notification = "notification";

			// Token: 0x040007CC RID: 1996
			public const string Clipboard = "clipboard";

			// Token: 0x040007CD RID: 1997
			public const string IsAppInstalled = "isAppInstalled";

			// Token: 0x040007CE RID: 1998
			public const string TopActivityInfo = "topActivityInfo";

			// Token: 0x040007CF RID: 1999
			public const string SysTrayVisibility = "sysTrayVisibility";

			// Token: 0x040007D0 RID: 2000
			public const string RestartAgent = "restartAgent";

			// Token: 0x040007D1 RID: 2001
			public const string ShowTileInterface = "showTileInterface";

			// Token: 0x040007D2 RID: 2002
			public const string SetNewLocation = "setNewLocation";

			// Token: 0x040007D3 RID: 2003
			public const string AdEvents = "adEvents";

			// Token: 0x040007D4 RID: 2004
			public const string ExitAgent = "exitAgent";

			// Token: 0x040007D5 RID: 2005
			public const string StopApp = "stopApp";

			// Token: 0x040007D6 RID: 2006
			public const string ReleaseApkInstallThread = "releaseApkInstallThread";

			// Token: 0x040007D7 RID: 2007
			public const string ClearAppData = "clearAppData";

			// Token: 0x040007D8 RID: 2008
			public const string RestartGameManager = "restartGameManager";

			// Token: 0x040007D9 RID: 2009
			public const string PostHttpUrl = "postHttpUrl";

			// Token: 0x040007DA RID: 2010
			public const string InstanceExist = "instanceExist";

			// Token: 0x040007DB RID: 2011
			public const string QueryInstances = "queryInstances";

			// Token: 0x040007DC RID: 2012
			public const string CreateInstance = "createInstance";

			// Token: 0x040007DD RID: 2013
			public const string DeleteInstance = "deleteInstance";

			// Token: 0x040007DE RID: 2014
			public const string StartInstance = "startInstance";

			// Token: 0x040007DF RID: 2015
			public const string GetRunningInstances = "getRunningInstances";

			// Token: 0x040007E0 RID: 2016
			public const string StopInstance = "stopInstance";

			// Token: 0x040007E1 RID: 2017
			public const string SetVmConfig = "setVmConfig";

			// Token: 0x040007E2 RID: 2018
			public const string IsMultiInstanceSupported = "isMultiInstanceSupported";

			// Token: 0x040007E3 RID: 2019
			public const string SetCpu = "setCpu";

			// Token: 0x040007E4 RID: 2020
			public const string SetDpi = "setDpi";

			// Token: 0x040007E5 RID: 2021
			public const string SetRam = "setRam";

			// Token: 0x040007E6 RID: 2022
			public const string SetResolution = "setResolution";

			// Token: 0x040007E7 RID: 2023
			public const string GetGuid = "getGuid";

			// Token: 0x040007E8 RID: 2024
			public const string Backup = "backup";

			// Token: 0x040007E9 RID: 2025
			public const string Restore = "restore";

			// Token: 0x040007EA RID: 2026
			public const string AppJsonUpdatedForVideo = "appJsonUpdatedForVideo";

			// Token: 0x040007EB RID: 2027
			public const string DeviceProfileUpdated = "deviceProfileUpdated";

			// Token: 0x040007EC RID: 2028
			public const string InstanceStopped = "instanceStopped";

			// Token: 0x040007ED RID: 2029
			public const string GetInstanceStatus = "getInstanceStatus";

			// Token: 0x040007EE RID: 2030
			public const string IsEngineReady = "isEngineReady";

			// Token: 0x040007EF RID: 2031
			public const string FrontendStatusUpdate = "FrontendStatusUpdate";

			// Token: 0x040007F0 RID: 2032
			public const string GuestStatusUpdate = "GuestStatusUpdate";

			// Token: 0x040007F1 RID: 2033
			public const string CopyToAndroid = "copyToAndroid";

			// Token: 0x040007F2 RID: 2034
			public const string CopyToWindows = "copyToWindows";

			// Token: 0x040007F3 RID: 2035
			public const string SetCurrentVolume = "setCurrentVolume";

			// Token: 0x040007F4 RID: 2036
			public const string DownloadInstalledAppsCfg = "downloadInstalledAppsCfg";

			// Token: 0x040007F5 RID: 2037
			public const string SetVMDisplayName = "setVMDisplayName";

			// Token: 0x040007F6 RID: 2038
			public const string SortWindows = "sortWindows";

			// Token: 0x040007F7 RID: 2039
			public const string MaintenanceWarning = "maintenanceWarning";

			// Token: 0x040007F8 RID: 2040
			public const string EnableDebugLogs = "enableDebugLogs";

			// Token: 0x040007F9 RID: 2041
			public const string LogAppClick = "logAppClick";

			// Token: 0x040007FA RID: 2042
			public const string SetNCPlayerCharacterName = "setNCPlayerCharacterName";

			// Token: 0x040007FB RID: 2043
			public const string LaunchPlay = "launchPlay";

			// Token: 0x040007FC RID: 2044
			public const string RemoveAccount = "removeAccount";

			// Token: 0x040007FD RID: 2045
			public const string SetDeviceProfile = "setDeviceProfile";

			// Token: 0x040007FE RID: 2046
			public const string ScreenLock = "screenLock";

			// Token: 0x040007FF RID: 2047
			public const string MakeDir = "makeDir";

			// Token: 0x04000800 RID: 2048
			public const string GetHeightWidth = "getHeightWidth";

			// Token: 0x04000801 RID: 2049
			public const string SetStreamingStatus = "setStreamingStatus";

			// Token: 0x04000802 RID: 2050
			public const string GetShortcut = "getShortcut";

			// Token: 0x04000803 RID: 2051
			public const string SetShortcut = "setShortcut";

			// Token: 0x04000804 RID: 2052
			public const string SendEngineTimelineStats = "sendEngineTimelineStats";

			// Token: 0x04000805 RID: 2053
			public const string GrmAppLaunch = "grmAppLaunch";

			// Token: 0x04000806 RID: 2054
			public const string ReInitLocalization = "reinitlocalization";

			// Token: 0x04000807 RID: 2055
			public const string TestCloudAnnouncement = "testCloudAnnouncement";

			// Token: 0x04000808 RID: 2056
			public const string OverrideDesktopNotificationSettings = "overrideDesktopNotificationSettings";
		}

		// Token: 0x020001B4 RID: 436
		public static class Client
		{
			// Token: 0x04000809 RID: 2057
			public const string Ping = "ping";

			// Token: 0x0400080A RID: 2058
			public const string AppDisplayed = "appDisplayed";

			// Token: 0x0400080B RID: 2059
			public const string CloseCrashedAppTab = "closeCrashedAppTab";

			// Token: 0x0400080C RID: 2060
			public const string AppLaunched = "appLaunched";

			// Token: 0x0400080D RID: 2061
			public const string ShowApp = "showApp";

			// Token: 0x0400080E RID: 2062
			public const string ShowWindow = "showWindow";

			// Token: 0x0400080F RID: 2063
			public const string IsGMVisible = "isVisible";

			// Token: 0x04000810 RID: 2064
			public const string AppUninstalled = "appUninstalled";

			// Token: 0x04000811 RID: 2065
			public const string AppInstalled = "appInstalled";

			// Token: 0x04000812 RID: 2066
			public const string EnableWndProcLogging = "enableWndProcLogging";

			// Token: 0x04000813 RID: 2067
			public const string Quit = "quit";

			// Token: 0x04000814 RID: 2068
			public const string Google = "google";

			// Token: 0x04000815 RID: 2069
			public const string ShowWebPage = "showWebPage";

			// Token: 0x04000816 RID: 2070
			public const string ShowHomeTab = "showHomeTab";

			// Token: 0x04000817 RID: 2071
			public const string CloseTab = "closeTab";

			// Token: 0x04000818 RID: 2072
			public const string GooglePlayAppInstall = "googlePlayAppInstall";

			// Token: 0x04000819 RID: 2073
			public const string AppInstallStarted = "appInstallStarted";

			// Token: 0x0400081A RID: 2074
			public const string AppInstallFailed = "appInstallFailed";

			// Token: 0x0400081B RID: 2075
			public const string OTSCompleted = "oneTimeSetupCompleted";

			// Token: 0x0400081C RID: 2076
			public const string UpdateUserInfo = "updateUserInfo";

			// Token: 0x0400081D RID: 2077
			public const string BootFailedPopup = "bootFailedPopup";

			// Token: 0x0400081E RID: 2078
			public const string OpenPackage = "openPackage";

			// Token: 0x0400081F RID: 2079
			public const string DragDropInstall = "dragDropInstall";

			// Token: 0x04000820 RID: 2080
			public const string StopInstance = "stopInstance";

			// Token: 0x04000821 RID: 2081
			public const string StartInstance = "startInstance";

			// Token: 0x04000822 RID: 2082
			public const string HideBluestacks = "hideBluestacks";

			// Token: 0x04000823 RID: 2083
			public const string TileWindow = "tileWindow";

			// Token: 0x04000824 RID: 2084
			public const string CascadeWindow = "cascadeWindow";

			// Token: 0x04000825 RID: 2085
			public const string ToggleFarmMode = "toggleFarmMode";

			// Token: 0x04000826 RID: 2086
			public const string LaunchWebTab = "launchWebTab";

			// Token: 0x04000827 RID: 2087
			public const string OpenNotificationSettings = "openNotificationSettings";

			// Token: 0x04000828 RID: 2088
			public const string IsAnyAppRunning = "isAnyAppRunning";

			// Token: 0x04000829 RID: 2089
			public const string ChangeTextOTS = "changeTextOTS";

			// Token: 0x0400082A RID: 2090
			public const string ShowIMESwitchPrompt = "showIMESwitchPrompt";

			// Token: 0x0400082B RID: 2091
			public const string LaunchDefaultWebApp = "launchDefaultWebApp";

			// Token: 0x0400082C RID: 2092
			public const string MacroCompleted = "macroCompleted";

			// Token: 0x0400082D RID: 2093
			public const string AppInfoUpdated = "appInfoUpdated";

			// Token: 0x0400082E RID: 2094
			public const string SendAppDisplayed = "sendAppDisplayed";

			// Token: 0x0400082F RID: 2095
			public const string IsGmVisible = "static";

			// Token: 0x04000830 RID: 2096
			public const string RestartFrontend = "restartFrontend";

			// Token: 0x04000831 RID: 2097
			public const string GcCollect = "gcCollect";

			// Token: 0x04000832 RID: 2098
			public const string ShowWindowAndApp = "showWindowAndApp";

			// Token: 0x04000833 RID: 2099
			public const string UnsupportedCpuError = "unsupportedCpuError";

			// Token: 0x04000834 RID: 2100
			public const string ChangeOrientaion = "changeOrientaion";

			// Token: 0x04000835 RID: 2101
			public const string ShootingModeChanged = "shootingModeChanged";

			// Token: 0x04000836 RID: 2102
			public const string GuestBootCompleted = "guestBootCompleted";

			// Token: 0x04000837 RID: 2103
			public const string GetRunningInstances = "getRunningInstances";

			// Token: 0x04000838 RID: 2104
			public const string AppJsonChanged = "appJsonChanged";

			// Token: 0x04000839 RID: 2105
			public const string GetCurrentAppDetails = "getCurrentAppDetails";

			// Token: 0x0400083A RID: 2106
			public const string MaintenanceWarning = "maintenanceWarning";

			// Token: 0x0400083B RID: 2107
			public const string RequirementConfigUpdated = "requirementConfigUpdated";

			// Token: 0x0400083C RID: 2108
			public const string DeviceProfileUpdated = "deviceProfileUpdated";

			// Token: 0x0400083D RID: 2109
			public const string UpdateSizeOfOverlay = "updateSizeOfOverlay";

			// Token: 0x0400083E RID: 2110
			public const string AndroidLocaleChanged = "androidLocaleChanged";

			// Token: 0x0400083F RID: 2111
			public const string SaveComboEvents = "saveComboEvents";

			// Token: 0x04000840 RID: 2112
			public const string HandleClientOperation = "handleClientOperation";

			// Token: 0x04000841 RID: 2113
			public const string MacroPlaybackComplete = "macroPlaybackComplete";

			// Token: 0x04000842 RID: 2114
			public const string ObsStatus = "obsStatus";

			// Token: 0x04000843 RID: 2115
			public const string ReportObsError = "reportObsError";

			// Token: 0x04000844 RID: 2116
			public const string CapturingError = "capturingError";

			// Token: 0x04000845 RID: 2117
			public const string OpenGLCapturingError = "openGLCapturingError";

			// Token: 0x04000846 RID: 2118
			public const string ToggleStreamingMode = "toggleStreamingMode";

			// Token: 0x04000847 RID: 2119
			public const string HandleClientGamepadButton = "handleClientGamepadButton";

			// Token: 0x04000848 RID: 2120
			public const string HandleGamepadConnection = "handleGamepadConnection";

			// Token: 0x04000849 RID: 2121
			public const string HandleGamepadGuidanceButton = "handleGamepadGuidanceButton";

			// Token: 0x0400084A RID: 2122
			public const string DeviceProvisioned = "deviceProvisioned";

			// Token: 0x0400084B RID: 2123
			public const string GoogleSignin = "googleSignin";

			// Token: 0x0400084C RID: 2124
			public const string ShowFullscreenSidebar = "showFullscreenSidebar";

			// Token: 0x0400084D RID: 2125
			public const string UpdateLocale = "updateLocale";

			// Token: 0x0400084E RID: 2126
			public const string ScreenshotCaptured = "screenshotCaptured";

			// Token: 0x0400084F RID: 2127
			public const string SetCurrentVolumeFromAndroid = "setCurrentVolumeFromAndroid";

			// Token: 0x04000850 RID: 2128
			public const string HotKeyEvents = "hotKeyEvents";

			// Token: 0x04000851 RID: 2129
			public const string SetLocale = "setLocale";

			// Token: 0x04000852 RID: 2130
			public const string EnableDebugLogs = "enableDebugLogs";

			// Token: 0x04000853 RID: 2131
			public const string SetDMMKeymapping = "setDMMKeymapping";

			// Token: 0x04000854 RID: 2132
			public const string NCSetGameInfoOnTopBar = "ncSetGameInfoOnTopBar";

			// Token: 0x04000855 RID: 2133
			public const string LaunchPlay = "launchPlay";

			// Token: 0x04000856 RID: 2134
			public const string EnableKeyboardHookLogging = "enableKeyboardHookLogging";

			// Token: 0x04000857 RID: 2135
			public const string MuteAllInstances = "muteAllInstances";

			// Token: 0x04000858 RID: 2136
			public const string ScreenLock = "screenLock";

			// Token: 0x04000859 RID: 2137
			public const string GetHeightWidth = "getHeightWidth";

			// Token: 0x0400085A RID: 2138
			public const string AccountSetupCompleted = "accountSetupCompleted";

			// Token: 0x0400085B RID: 2139
			public const string OpenThemeEditor = "openThemeEditor";

			// Token: 0x0400085C RID: 2140
			public const string SetStreamingStatus = "setStreamingStatus";

			// Token: 0x0400085D RID: 2141
			public const string PlayerScriptModifierClick = "playerScriptModifierClick";

			// Token: 0x0400085E RID: 2142
			public const string ReloadShortcuts = "reloadShortcuts";

			// Token: 0x0400085F RID: 2143
			public const string ShowFullscreenTopBar = "showFullscreenTopbar";

			// Token: 0x04000860 RID: 2144
			public const string ReloadPromotions = "reloadPromotions";

			// Token: 0x04000861 RID: 2145
			public const string HandleOverlayControlsVisibility = "overlayControlsVisibility";

			// Token: 0x04000862 RID: 2146
			public const string ShowGrmAndLaunchApp = "showGrmAndLaunchApp";

			// Token: 0x04000863 RID: 2147
			public const string ReinitRegistry = "reinitRegistry";

			// Token: 0x04000864 RID: 2148
			public const string OpenCFGReorderTool = "openCFGReorderTool";

			// Token: 0x04000865 RID: 2149
			public const string UpdateCrc = "updateCrc";
		}

		// Token: 0x020001B5 RID: 437
		public static class Cloud
		{
			// Token: 0x04000866 RID: 2150
			public const string GetAnnouncement = "/getAnnouncement";

			// Token: 0x04000867 RID: 2151
			public const string AppUsage = "/bs3/stats/v4/usage";

			// Token: 0x04000868 RID: 2152
			public const string FrontendClickStats = "/bs3/stats/frontend_click_stats";

			// Token: 0x04000869 RID: 2153
			public const string ScheduledPing = "/api/scheduledping";

			// Token: 0x0400086A RID: 2154
			public const string ScheduledPingStats = "/stats/scheduledpingstats";

			// Token: 0x0400086B RID: 2155
			public const string SecurityMetrics = "/bs4/security_metrics";

			// Token: 0x0400086C RID: 2156
			public const string UnifiedInstallStats = "/bs3/stats/unified_install_stats";

			// Token: 0x0400086D RID: 2157
			public const string UpdateLocale = "updateLocale";

			// Token: 0x0400086E RID: 2158
			public const string ProblemCategories = "/app_settings/problem_categories";

			// Token: 0x0400086F RID: 2159
			public const string Promotions = "promotions";

			// Token: 0x04000870 RID: 2160
			public const string GrmFetchUrl = "grm/files";

			// Token: 0x04000871 RID: 2161
			public const string BtvFetchUrl = "bs4/btv/GetBTVFile";

			// Token: 0x04000872 RID: 2162
			public const string HelpArticles = "help_articles";

			// Token: 0x04000873 RID: 2163
			public const string GuidanceWindow = "guidance_window";

			// Token: 0x04000874 RID: 2164
			public const string CalendarStats = "/bs4/stats/calendar_stats";

			// Token: 0x04000875 RID: 2165
			public const string PostBootUrl = "/bs4/post_boot";
		}

		// Token: 0x020001B6 RID: 438
		public static class HelpArticlesKeys
		{
			// Token: 0x04000876 RID: 2166
			public const string KMScriptFAQ = "keymapping_script_faq";

			// Token: 0x04000877 RID: 2167
			public const string BS4MinRequirements = "bs3_nougat_min_requirements";

			// Token: 0x04000878 RID: 2168
			public const string BGPCompatKKVersion = "bgp_kk_compat_version";

			// Token: 0x04000879 RID: 2169
			public const string EnableVirtualization = "enable_virtualization";

			// Token: 0x0400087A RID: 2170
			public const string VtxUnavailable = "vtx_unavailable";

			// Token: 0x0400087B RID: 2171
			public const string UpgradeSupportInfo = "upgrade_support_info";

			// Token: 0x0400087C RID: 2172
			public const string BS3MinRequirements = "bs3_min_requirements";

			// Token: 0x0400087D RID: 2173
			public const string DisableAntivirus = "disable_antivirus";

			// Token: 0x0400087E RID: 2174
			public const string ChangePowerPlan = "change_powerplan";

			// Token: 0x0400087F RID: 2175
			public const string FailedSslConnection = "failed_ssl_connection";

			// Token: 0x04000880 RID: 2176
			public const string AudioServiceIssue = "audio_service_issue";

			// Token: 0x04000881 RID: 2177
			public const string TermsOfUse = "terms_of_use";

			// Token: 0x04000882 RID: 2178
			public const string DisableHypervisors = "disable_hypervisor";

			// Token: 0x04000883 RID: 2179
			public const string ChangeGraphicsMode = "change_graphics_mode";

			// Token: 0x04000884 RID: 2180
			public const string AdvancedGameControl = "advanced_game_control";

			// Token: 0x04000885 RID: 2181
			public const string SmartControl = "smart_control";

			// Token: 0x04000886 RID: 2182
			public const string GameSettingsKnowMorePubg = "game_settings_know_more_pubg";

			// Token: 0x04000887 RID: 2183
			public const string GameSettingsKnowMoreFreefire = "game_settings_know_more_freefire";

			// Token: 0x04000888 RID: 2184
			public const string GameSettingsKnowMoreCOD = "game_settings_know_more_callofduty";

			// Token: 0x04000889 RID: 2185
			public const string GameSettingsKnowMoreSevenDeadly = "game_settings_know_more_sevendeadly";

			// Token: 0x0400088A RID: 2186
			public const string ProfileSettingsWarningInPubg = "profile_settings_warning_pubg";

			// Token: 0x0400088B RID: 2187
			public const string FreeDiskSpaceUsingDiskCompactiontool = "free_disk_space_using_diskcompactiontool";

			// Token: 0x0400088C RID: 2188
			public const string GameGuideReadArticle = "game_guide_article";

			// Token: 0x0400088D RID: 2189
			public const string AbiHelpUrl = "ABI_Help";

			// Token: 0x0400088E RID: 2190
			public const string AstcHelpUrl = "ASTC_Help";

			// Token: 0x0400088F RID: 2191
			public const string GpuSettingHelpUrl = "GPU_Setting_Help";

			// Token: 0x04000890 RID: 2192
			public const string MergeMacroHelpUrl = "MergeMacro_Help";

			// Token: 0x04000891 RID: 2193
			public const string NativeGamepadHelpUrl = "native_gamepad_help";

			// Token: 0x04000892 RID: 2194
			public const string UnsureWhereStart = "unsure_start";

			// Token: 0x04000893 RID: 2195
			public const string TroubleInstallingRunningGame = "trouble_installing_running_game";

			// Token: 0x04000894 RID: 2196
			public const string StopMovementMOBAHelpUrl = "moba_stop_movement_help";

			// Token: 0x04000895 RID: 2197
			public const string MOBASkillSettingsHelpUrl = "moba_skill_settings_help";
		}

		// Token: 0x020001B7 RID: 439
		public static class BTv
		{
			// Token: 0x04000896 RID: 2198
			public const string Ping = "ping";

			// Token: 0x04000897 RID: 2199
			public const string ReceiveAppInstallStatus = "receiveAppInstallStatus";
		}

		// Token: 0x020001B8 RID: 440
		public static class Engine
		{
			// Token: 0x04000898 RID: 2200
			public const string Ping = "ping";

			// Token: 0x04000899 RID: 2201
			public const string RefreshKeymapUri = "refreshKeymap";

			// Token: 0x0400089A RID: 2202
			public const string Shutdown = "shutdown";

			// Token: 0x0400089B RID: 2203
			public const string SwitchOrientation = "switchOrientation";

			// Token: 0x0400089C RID: 2204
			public const string ShowWindow = "showWindow";

			// Token: 0x0400089D RID: 2205
			public const string RefreshWindow = "refreshWindow";

			// Token: 0x0400089E RID: 2206
			public const string SetParent = "setParent";

			// Token: 0x0400089F RID: 2207
			public const string ShareScreenshot = "shareScreenshot";

			// Token: 0x040008A0 RID: 2208
			public const string GoBack = "goBack";

			// Token: 0x040008A1 RID: 2209
			public const string CloseScreen = "closeScreen";

			// Token: 0x040008A2 RID: 2210
			public const string SoftControlBarEvent = "softControlBarEvent";

			// Token: 0x040008A3 RID: 2211
			public const string InputMapperFilesDownloaded = "inputMapperFilesDownloaded";

			// Token: 0x040008A4 RID: 2212
			public const string EnableWndProcLogging = "enableWndProcLogging";

			// Token: 0x040008A5 RID: 2213
			public const string PingVm = "pingVm";

			// Token: 0x040008A6 RID: 2214
			public const string CopyFiles = "copyFiles";

			// Token: 0x040008A7 RID: 2215
			public const string GetWindowsFiles = "getWindowsFiles";

			// Token: 0x040008A8 RID: 2216
			public const string GpsCoordinates = "gpsCoordinates";

			// Token: 0x040008A9 RID: 2217
			public const string InitGamepad = "initGamepad";

			// Token: 0x040008AA RID: 2218
			public const string GetVolume = "getVolume";

			// Token: 0x040008AB RID: 2219
			public const string SetVolume = "setVolume";

			// Token: 0x040008AC RID: 2220
			public const string TopDisplayedActivityInfo = "topDisplayedActivityInfo";

			// Token: 0x040008AD RID: 2221
			public const string AppDisplayed = "appDisplayed";

			// Token: 0x040008AE RID: 2222
			public const string GoHome = "goHome";

			// Token: 0x040008AF RID: 2223
			public const string IsKeyboardEnabled = "isKeyboardEnabled";

			// Token: 0x040008B0 RID: 2224
			public const string SetKeymappingState = "setKeymappingState";

			// Token: 0x040008B1 RID: 2225
			public const string Keymap = "keymap";

			// Token: 0x040008B2 RID: 2226
			public const string SetFrontendVisibility = "setFrontendVisibility";

			// Token: 0x040008B3 RID: 2227
			public const string GetFeSize = "getFeSize";

			// Token: 0x040008B4 RID: 2228
			public const string Mute = "mute";

			// Token: 0x040008B5 RID: 2229
			public const string Unmute = "unmute";

			// Token: 0x040008B6 RID: 2230
			public const string GetCurrentKeymappingStatus = "getCurrentKeymappingStatus";

			// Token: 0x040008B7 RID: 2231
			public const string Shake = "shake";

			// Token: 0x040008B8 RID: 2232
			public const string IsKeyNameFocussed = "isKeyNameFocussed";

			// Token: 0x040008B9 RID: 2233
			public const string AndroidImeSelected = "androidImeSelected";

			// Token: 0x040008BA RID: 2234
			public const string IsGpsSupported = "isGpsSupported";

			// Token: 0x040008BB RID: 2235
			public const string InstallApk = "installApk";

			// Token: 0x040008BC RID: 2236
			public const string InjectCopy = "injectCopy";

			// Token: 0x040008BD RID: 2237
			public const string InjectPaste = "injectPaste";

			// Token: 0x040008BE RID: 2238
			public const string StopZygote = "stopZygote";

			// Token: 0x040008BF RID: 2239
			public const string StartZygote = "startZygote";

			// Token: 0x040008C0 RID: 2240
			public const string GetKeyMappingParserVersion = "getKeyMappingParserVersion";

			// Token: 0x040008C1 RID: 2241
			public const string VibrateHostWindow = "vibrateHostWindow";

			// Token: 0x040008C2 RID: 2242
			public const string LocaleChanged = "localeChanged";

			// Token: 0x040008C3 RID: 2243
			public const string GetScreenshot = "getScreenshot";

			// Token: 0x040008C4 RID: 2244
			public const string SetPcImeWorkflow = "setPcImeWorkflow";

			// Token: 0x040008C5 RID: 2245
			public const string SetUserInfo = "setUserInfo";

			// Token: 0x040008C6 RID: 2246
			public const string GetUserInfo = "getUserInfo";

			// Token: 0x040008C7 RID: 2247
			public const string GetPremium = "getPremium";

			// Token: 0x040008C8 RID: 2248
			public const string SetCursorStyle = "setCursorStyle";

			// Token: 0x040008C9 RID: 2249
			public const string OpenMacroWindow = "openMacroWindow";

			// Token: 0x040008CA RID: 2250
			public const string StartReroll = "startReroll";

			// Token: 0x040008CB RID: 2251
			public const string AbortReroll = "abortReroll";

			// Token: 0x040008CC RID: 2252
			public const string SetPackagesForInteraction = "setPackagesForInteraction";

			// Token: 0x040008CD RID: 2253
			public const string GetInteractionForPackage = "getInteractionForPackage";

			// Token: 0x040008CE RID: 2254
			public const string ToggleScreen = "toggleScreen";

			// Token: 0x040008CF RID: 2255
			public const string SendGlWindowSize = "sendGlWindowSize";

			// Token: 0x040008D0 RID: 2256
			public const string DeactivateFrontend = "deactivateFrontend";

			// Token: 0x040008D1 RID: 2257
			public const string StartRecordingCombo = "startRecordingCombo";

			// Token: 0x040008D2 RID: 2258
			public const string StopRecordingCombo = "stopRecordingCombo";

			// Token: 0x040008D3 RID: 2259
			public const string HandleClientOperation = "handleClientOperation";

			// Token: 0x040008D4 RID: 2260
			public const string InitMacroPlayback = "initMacroPlayback";

			// Token: 0x040008D5 RID: 2261
			public const string StopMacroPlayback = "stopMacroPlayback";

			// Token: 0x040008D6 RID: 2262
			public const string FarmModeHandler = "farmModeHandler";

			// Token: 0x040008D7 RID: 2263
			public const string StartOperationsSync = "startOperationsSync";

			// Token: 0x040008D8 RID: 2264
			public const string StopOperationsSync = "stopOperationsSync";

			// Token: 0x040008D9 RID: 2265
			public const string StartSyncConsumer = "startSyncConsumer";

			// Token: 0x040008DA RID: 2266
			public const string StopSyncConsumer = "stopSyncConsumer";

			// Token: 0x040008DB RID: 2267
			public const string ShowFPS = "showFPS";

			// Token: 0x040008DC RID: 2268
			public const string CloseCrashedAppTab = "closeCrashedAppTab";

			// Token: 0x040008DD RID: 2269
			public const string OTSCompleted = "oneTimeSetupCompleted";

			// Token: 0x040008DE RID: 2270
			public const string VisibleChangedUri = "frontendVisibleChanged";

			// Token: 0x040008DF RID: 2271
			public const string AppDataFEUrl = "appDataFeUrl";

			// Token: 0x040008E0 RID: 2272
			public const string RunAppInfo = "runAppInfo";

			// Token: 0x040008E1 RID: 2273
			public const string StopAppInfo = "stopAppInfo";

			// Token: 0x040008E2 RID: 2274
			public const string QuitFrontend = "quitFrontend";

			// Token: 0x040008E3 RID: 2275
			public const string ShowFeNotification = "showFeNotification";

			// Token: 0x040008E4 RID: 2276
			public const string ToggleGamepadButton = "toggleGamepadButton";

			// Token: 0x040008E5 RID: 2277
			public const string DeviceProvisioned = "deviceProvisioned";

			// Token: 0x040008E6 RID: 2278
			public const string GoogleSignin = "googleSignin";

			// Token: 0x040008E7 RID: 2279
			public const string ShowFENotification = "showFENotification";

			// Token: 0x040008E8 RID: 2280
			public const string IsAppPlayerRooted = "isAppPlayerRooted";

			// Token: 0x040008E9 RID: 2281
			public const string SetIsFullscreen = "setIsFullscreen";

			// Token: 0x040008EA RID: 2282
			public const string GetInteractionStats = "getInteractionStats";

			// Token: 0x040008EB RID: 2283
			public const string EnableGamepad = "enableGamepad";

			// Token: 0x040008EC RID: 2284
			public const string ExportCfgFile = "exportCfgFile";

			// Token: 0x040008ED RID: 2285
			public const string ImportCfgFile = "importCfgFile";

			// Token: 0x040008EE RID: 2286
			public const string EnableDebugLogs = "enableDebugLogs";

			// Token: 0x040008EF RID: 2287
			public const string RunMacroUnit = "runMacroUnit";

			// Token: 0x040008F0 RID: 2288
			public const string PauseRecordingCombo = "pauseRecordingCombo";

			// Token: 0x040008F1 RID: 2289
			public const string ReloadShortcutsConfig = "reloadShortcutsConfig";

			// Token: 0x040008F2 RID: 2290
			public const string AccountSetupCompleted = "accountSetupCompleted";

			// Token: 0x040008F3 RID: 2291
			public const string ScriptEditingModeEntered = "scriptEditingModeEntered";

			// Token: 0x040008F4 RID: 2292
			public const string PlayPauseSync = "playPauseSync";

			// Token: 0x040008F5 RID: 2293
			public const string ReinitGuestRegistry = "reinitGuestRegistry";

			// Token: 0x040008F6 RID: 2294
			public const string UpdateMacroShortcutsDict = "updateMacroShortcutsDict";

			// Token: 0x040008F7 RID: 2295
			public const string IsAstcHardwareSupported = "IsAstcHardwareSupported";

			// Token: 0x040008F8 RID: 2296
			public const string SetAstcOption = "setAstcOption";

			// Token: 0x040008F9 RID: 2297
			public const string ValidateScriptCommands = "validateScriptCommands";

			// Token: 0x040008FA RID: 2298
			public const string ChangeImei = "changeimei";

			// Token: 0x040008FB RID: 2299
			public const string EnableNativeGamepad = "enableNativeGamepad";

			// Token: 0x040008FC RID: 2300
			public const string SendImagePickerCoordinates = "sendImagePickerCoordinates";

			// Token: 0x040008FD RID: 2301
			public const string ToggleImagePickerMode = "toggleImagePickerMode";

			// Token: 0x040008FE RID: 2302
			public const string HandleLoadConfigOnTabSwitch = "handleLoadConfigOnTabSwitch";

			// Token: 0x040008FF RID: 2303
			public const string SendCustomCursorEnabledApps = "sendCustomCursorEnabledApps";
		}

		// Token: 0x020001B9 RID: 441
		public static class Guest
		{
			// Token: 0x04000900 RID: 2304
			public const string Ping = "ping";

			// Token: 0x04000901 RID: 2305
			public const string Install = "install";

			// Token: 0x04000902 RID: 2306
			public const string Xinstall = "xinstall";

			// Token: 0x04000903 RID: 2307
			public const string BrowserInstall = "browserInstall";

			// Token: 0x04000904 RID: 2308
			public const string Uninstall = "uninstall";

			// Token: 0x04000905 RID: 2309
			public const string InstalledPackages = "installedPackages";

			// Token: 0x04000906 RID: 2310
			public const string Clipboard = "clipboard";

			// Token: 0x04000907 RID: 2311
			public const string CustomStartActivity = "customStartActivity";

			// Token: 0x04000908 RID: 2312
			public const string AmzInstall = "amzInstall";

			// Token: 0x04000909 RID: 2313
			public const string ConnectHostTemp = "connectHost";

			// Token: 0x0400090A RID: 2314
			public const string DisconnectHostTemp = "disconnectHost";

			// Token: 0x0400090B RID: 2315
			public const string ConnectHostPermanently = "connectHost?d=permanent";

			// Token: 0x0400090C RID: 2316
			public const string DisconnectHostPermanently = "disconnectHost?d=permanent";

			// Token: 0x0400090D RID: 2317
			public const string CheckAdbStatus = "checkADBStatus";

			// Token: 0x0400090E RID: 2318
			public const string CustomStartService = "customStartService";

			// Token: 0x0400090F RID: 2319
			public const string SetNewLocation = "setNewLocation";

			// Token: 0x04000910 RID: 2320
			public const string BindMount = "bindmount";

			// Token: 0x04000911 RID: 2321
			public const string UnbindMount = "unbindmount";

			// Token: 0x04000912 RID: 2322
			public const string CheckIfGuestReady = "checkIfGuestReady";

			// Token: 0x04000913 RID: 2323
			public const string IsOTSCompleted = "isOTSCompleted";

			// Token: 0x04000914 RID: 2324
			public const string GetDefaultLauncher = "getDefaultLauncher";

			// Token: 0x04000915 RID: 2325
			public const string SetDefaultLauncher = "setDefaultLauncher";

			// Token: 0x04000916 RID: 2326
			public const string Home = "home";

			// Token: 0x04000917 RID: 2327
			public const string RemoveAccountsInfo = "removeAccountsInfo";

			// Token: 0x04000918 RID: 2328
			public const string GetGoogleAdID = "getGoogleAdID";

			// Token: 0x04000919 RID: 2329
			public const string CheckSSLConnection = "checkSSLConnection";

			// Token: 0x0400091A RID: 2330
			public const string GetConfigList = "getConfigList";

			// Token: 0x0400091B RID: 2331
			public const string GetVolume = "getVolume";

			// Token: 0x0400091C RID: 2332
			public const string SetVolume = "setVolume";

			// Token: 0x0400091D RID: 2333
			public const string ChangeDeviceProfile = "changeDeviceProfile";

			// Token: 0x0400091E RID: 2334
			public const string FileDrop = "fileDrop";

			// Token: 0x0400091F RID: 2335
			public const string GetCurrentIMEID = "getCurrentIMEID";

			// Token: 0x04000920 RID: 2336
			public const string IsPackageInstalled = "isPackageInstalled";

			// Token: 0x04000921 RID: 2337
			public const string GetPackageDetails = "getPackageDetails";

			// Token: 0x04000922 RID: 2338
			public const string GetLaunchActivityName = "getLaunchActivityName";

			// Token: 0x04000923 RID: 2339
			public const string GetAppName = "getAppName";

			// Token: 0x04000924 RID: 2340
			public const string AppJSonChanged = "appJSonChanged";

			// Token: 0x04000925 RID: 2341
			public const string SetWindowsAgentAddr = "setWindowsAgentAddr";

			// Token: 0x04000926 RID: 2342
			public const string SetWindowsFrontendAddr = "setWindowsFrontendAddr";

			// Token: 0x04000927 RID: 2343
			public const string SetGameManagerAddr = "setGameManagerAddr";

			// Token: 0x04000928 RID: 2344
			public const string SetBlueStacksConfig = "setBlueStacksConfig";

			// Token: 0x04000929 RID: 2345
			public const string ShowTrayNotification = "showTrayNotification";

			// Token: 0x0400092A RID: 2346
			public const string MuteAppPlayer = "muteAppPlayer";

			// Token: 0x0400092B RID: 2347
			public const string UnmuteAppPlayer = "unmuteAppPlayer";

			// Token: 0x0400092C RID: 2348
			public const string HostOrientation = "hostOrientation";

			// Token: 0x0400092D RID: 2349
			public const string GetProp = "getprop";

			// Token: 0x0400092E RID: 2350
			public const string GetAndroidID = "getAndroidID";

			// Token: 0x0400092F RID: 2351
			public const string GuestOrientation = "guestorientation";

			// Token: 0x04000930 RID: 2352
			public const string IsSharedFolderMounted = "isSharedFolderMounted";

			// Token: 0x04000931 RID: 2353
			public const string GameSettingsEnabled = "gameSettingsEnabled";

			// Token: 0x04000932 RID: 2354
			public const string SwitchAbi = "switchAbi";

			// Token: 0x04000933 RID: 2355
			public const string ChangeImei = "changeimei";

			// Token: 0x04000934 RID: 2356
			public const string LaunchChrome = "launchchrome";

			// Token: 0x04000935 RID: 2357
			public const string GrmPackages = "grmPackages";

			// Token: 0x04000936 RID: 2358
			public const string SetApplicationState = "setapplicationstate";

			// Token: 0x04000937 RID: 2359
			public const string SetLocale = "setLocale";

			// Token: 0x04000938 RID: 2360
			public const string AddCalendarEvent = "addcalendarevent";

			// Token: 0x04000939 RID: 2361
			public const string UpdateCalendarEvent = "updatecalendarevent";

			// Token: 0x0400093A RID: 2362
			public const string DeleteCalendarEvent = "deletecalendarevent";

			// Token: 0x0400093B RID: 2363
			public const string CheckAndroidTouchPointsState = "checkTouchPointState";

			// Token: 0x0400093C RID: 2364
			public const string ShowTouchPoints = "showTouchPoints";

			// Token: 0x0400093D RID: 2365
			public const string SetCustomAppSize = "setcustomappsize";
		}

		// Token: 0x020001BA RID: 442
		public static class NCSoftAgent
		{
			// Token: 0x0400093E RID: 2366
			public const string AccountGoogleLogin = "account/google/login";

			// Token: 0x0400093F RID: 2367
			public const string ErrorCrash = "error/crash";

			// Token: 0x04000940 RID: 2368
			public const string ActionButtonStreaming = "action/button/streaming";
		}
	}
}
