﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000FF RID: 255
	public enum EngineState
	{
		// Token: 0x04000456 RID: 1110
		plus,
		// Token: 0x04000457 RID: 1111
		raw,
		// Token: 0x04000458 RID: 1112
		legacy
	}
}
