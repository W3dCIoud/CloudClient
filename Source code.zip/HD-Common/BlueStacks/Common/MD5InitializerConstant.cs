﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001DE RID: 478
	public enum MD5InitializerConstant : uint
	{
		// Token: 0x04000B00 RID: 2816
		A = 1732584193U,
		// Token: 0x04000B01 RID: 2817
		B = 4023233417U,
		// Token: 0x04000B02 RID: 2818
		C = 2562383102U,
		// Token: 0x04000B03 RID: 2819
		D = 271733878U
	}
}
