﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000079 RID: 121
	public enum GraphicsMode
	{
		// Token: 0x04000139 RID: 313
		None,
		// Token: 0x0400013A RID: 314
		DirectX = 4,
		// Token: 0x0400013B RID: 315
		OpenGL = 1
	}
}
