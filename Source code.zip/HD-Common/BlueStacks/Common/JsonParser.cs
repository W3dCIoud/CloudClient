﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x0200012C RID: 300
	public class JsonParser
	{
		// Token: 0x17000270 RID: 624
		// (get) Token: 0x06000881 RID: 2177 RVA: 0x000082E1 File Offset: 0x000064E1
		// (set) Token: 0x06000882 RID: 2178 RVA: 0x000082E9 File Offset: 0x000064E9
		public string VmName { get; set; }

		// Token: 0x06000883 RID: 2179 RVA: 0x00025284 File Offset: 0x00023484
		public JsonParser(string vmName)
		{
			if (string.IsNullOrEmpty(vmName))
			{
				this.VmName = "";
				this.mAppsDotJsonFile = Path.Combine(RegistryStrings.GadgetDir, "systemApps.json");
			}
			else
			{
				this.VmName = vmName;
				this.mAppsDotJsonFile = Path.Combine(RegistryStrings.GadgetDir, "apps_" + vmName + ".json");
			}
			using (Mutex mutex = new Mutex(false, "BlueStacks_AppJsonUpdate"))
			{
				if (mutex.WaitOne())
				{
					try
					{
						JsonParser.DeleteIfInvalidJsonFile(this.mAppsDotJsonFile);
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to delete invalid json file... Err : " + ex.ToString());
					}
					finally
					{
						mutex.ReleaseMutex();
					}
				}
			}
		}

		// Token: 0x06000884 RID: 2180 RVA: 0x0002535C File Offset: 0x0002355C
		public static List<string> GetInstalledAppsList(string vmName)
		{
			List<string> list = new List<string>();
			AppInfo[] appList = new JsonParser(vmName).GetAppList();
			for (int i = 0; i < appList.Length; i++)
			{
				if (appList[i] != null && appList[i].Package != null)
				{
					list.Add(appList[i].Package);
				}
			}
			return list;
		}

		// Token: 0x06000885 RID: 2181 RVA: 0x000253A8 File Offset: 0x000235A8
		public AppInfo[] GetAppList()
		{
			string json = "[]";
			using (Mutex mutex = new Mutex(false, "BlueStacks_AppJsonUpdate"))
			{
				if (mutex.WaitOne())
				{
					try
					{
						if (!File.Exists(this.mAppsDotJsonFile))
						{
							using (StreamWriter streamWriter = new StreamWriter(this.mAppsDotJsonFile, true))
							{
								streamWriter.Write("[");
								streamWriter.WriteLine();
								streamWriter.Write("]");
							}
						}
						StreamReader streamReader = new StreamReader(this.mAppsDotJsonFile);
						json = streamReader.ReadToEnd();
						streamReader.Close();
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to create empty app json... Err : " + ex.ToString());
					}
					finally
					{
						mutex.ReleaseMutex();
					}
				}
			}
			this.GetOriginalJson(JArray.Parse(json));
			return this.mOriginalJson;
		}

		// Token: 0x06000886 RID: 2182 RVA: 0x0002549C File Offset: 0x0002369C
		private void GetOriginalJson(JArray input)
		{
			this.mOriginalJson = new AppInfo[input.Count];
			for (int i = 0; i < input.Count; i++)
			{
				this.mOriginalJson[i] = JsonConvert.DeserializeObject<AppInfo>(input[i].ToString());
			}
		}

		// Token: 0x06000887 RID: 2183 RVA: 0x000254E4 File Offset: 0x000236E4
		public int GetInstalledAppCount()
		{
			this.GetAppList();
			int num = 0;
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (string.Compare(this.mOriginalJson[i].Activity, ".Main", StringComparison.OrdinalIgnoreCase) != 0 && string.Compare(this.mOriginalJson[i].Appstore, "yes", StringComparison.OrdinalIgnoreCase) != 0)
				{
					num++;
				}
			}
			return num;
		}

		// Token: 0x06000888 RID: 2184 RVA: 0x00025548 File Offset: 0x00023748
		public bool GetAppInfoFromAppName(string appName, out string packageName, out string imageName, out string activityName)
		{
			packageName = null;
			imageName = null;
			activityName = null;
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].Name == appName)
				{
					packageName = this.mOriginalJson[i].Package;
					imageName = this.mOriginalJson[i].Img;
					activityName = this.mOriginalJson[i].Activity;
					return true;
				}
			}
			return false;
		}

		// Token: 0x06000889 RID: 2185 RVA: 0x000255C0 File Offset: 0x000237C0
		public bool GetAppInfoFromPackageName(string packageName, out string appName, out string imageName, out string activityName, out string appstore)
		{
			appName = "";
			imageName = "";
			activityName = "";
			appstore = "";
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].Package == packageName)
				{
					appName = this.mOriginalJson[i].Name;
					imageName = this.mOriginalJson[i].Img;
					activityName = this.mOriginalJson[i].Activity;
					appstore = this.mOriginalJson[i].Appstore;
					return true;
				}
			}
			return false;
		}

		// Token: 0x0600088A RID: 2186 RVA: 0x0002565C File Offset: 0x0002385C
		public AppInfo GetAppInfoFromPackageName(string packageName)
		{
			AppInfo result = null;
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].Package == packageName)
				{
					result = this.mOriginalJson[i];
				}
			}
			return result;
		}

		// Token: 0x0600088B RID: 2187 RVA: 0x000256A4 File Offset: 0x000238A4
		public string GetAppNameFromPackageActivity(string packageName, string activityName)
		{
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].Package == packageName && this.mOriginalJson[i].Activity == activityName)
				{
					return this.mOriginalJson[i].Name;
				}
			}
			return string.Empty;
		}

		// Token: 0x0600088C RID: 2188 RVA: 0x00025708 File Offset: 0x00023908
		public string GetAppNameFromPackage(string packageName)
		{
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].Package == packageName)
				{
					return this.mOriginalJson[i].Name;
				}
			}
			return string.Empty;
		}

		// Token: 0x0600088D RID: 2189 RVA: 0x00025758 File Offset: 0x00023958
		public static bool GetGl3RequirementFromPackage(AppInfo[] appJson, string packageName)
		{
			if (appJson != null)
			{
				for (int i = 0; i < appJson.Length; i++)
				{
					if (appJson[i].Package == packageName)
					{
						return appJson[i].Gl3Required;
					}
				}
			}
			return false;
		}

		// Token: 0x0600088E RID: 2190 RVA: 0x00025790 File Offset: 0x00023990
		public static bool GetVideoPresentRequirementFromPackage(AppInfo[] appJson, string packageName)
		{
			if (appJson != null)
			{
				for (int i = 0; i < appJson.Length; i++)
				{
					if (appJson[i].Package == packageName)
					{
						return appJson[i].VideoPresent;
					}
				}
			}
			return false;
		}

		// Token: 0x0600088F RID: 2191 RVA: 0x000257C8 File Offset: 0x000239C8
		public string GetPackageNameFromActivityName(string activityName)
		{
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].Activity == activityName)
				{
					return this.mOriginalJson[i].Package;
				}
			}
			return string.Empty;
		}

		// Token: 0x06000890 RID: 2192 RVA: 0x00025818 File Offset: 0x00023A18
		public string GetActivityNameFromPackageName(string packageName)
		{
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].Package == packageName)
				{
					return this.mOriginalJson[i].Activity;
				}
			}
			return string.Empty;
		}

		// Token: 0x06000891 RID: 2193 RVA: 0x00025868 File Offset: 0x00023A68
		public bool IsPackageNameSystemApp(string packageName)
		{
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].Package == packageName)
				{
					return this.mOriginalJson[i].System == "1";
				}
			}
			return false;
		}

		// Token: 0x06000892 RID: 2194 RVA: 0x000258C4 File Offset: 0x00023AC4
		public bool IsAppNameSystemApp(string appName)
		{
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].Name == appName)
				{
					return this.mOriginalJson[i].System == "1";
				}
			}
			return false;
		}

		// Token: 0x06000893 RID: 2195 RVA: 0x00025920 File Offset: 0x00023B20
		public bool IsAppInstalled(string packageName)
		{
			string text;
			return this.IsAppInstalled(packageName, out text);
		}

		// Token: 0x06000894 RID: 2196 RVA: 0x00025938 File Offset: 0x00023B38
		public bool IsAppInstalled(string packageName, out string version)
		{
			this.GetAppList();
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].Package == packageName)
				{
					version = this.mOriginalJson[i].Version;
					return true;
				}
			}
			version = "NA";
			return false;
		}

		// Token: 0x06000895 RID: 2197 RVA: 0x00025990 File Offset: 0x00023B90
		public bool GetAppData(string package, string activity, out string name, out string img)
		{
			this.GetAppList();
			name = "";
			img = "";
			for (int i = 0; i < this.mOriginalJson.Length; i++)
			{
				if (this.mOriginalJson[i].Package == package && this.mOriginalJson[i].Activity == activity)
				{
					name = this.mOriginalJson[i].Name;
					img = this.mOriginalJson[i].Img;
					Logger.Info("Got AppName: {0} and AppIcon: {1}", new object[]
					{
						name,
						img
					});
					return true;
				}
			}
			return false;
		}

		// Token: 0x06000896 RID: 2198 RVA: 0x00025A30 File Offset: 0x00023C30
		public void WriteJson(AppInfo[] json)
		{
			JArray jarray = new JArray();
			Logger.Info("JsonParser: Writing json object array to json writer");
			if (json != null)
			{
				for (int i = 0; i < json.Length; i++)
				{
					JObject jobject = new JObject
					{
						{
							"img",
							json[i].Img
						},
						{
							"name",
							json[i].Name
						},
						{
							"system",
							json[i].System
						},
						{
							"package",
							json[i].Package
						},
						{
							"appstore",
							json[i].Appstore
						},
						{
							"activity",
							json[i].Activity
						},
						{
							"version",
							json[i].Version
						},
						{
							"versionName",
							json[i].VersionName
						},
						{
							"gl3required",
							json[i].Gl3Required
						},
						{
							"videopresent",
							json[i].VideoPresent
						}
					};
					if (json[i].Url != null)
					{
						jobject.Add("url", json[i].Url);
					}
					jarray.Add(jobject);
				}
			}
			using (Mutex mutex = new Mutex(false, "BlueStacks_AppJsonUpdate"))
			{
				if (mutex.WaitOne())
				{
					try
					{
						StreamWriter streamWriter = new StreamWriter(this.mAppsDotJsonFile + ".tmp");
						streamWriter.Write(jarray.ToString(Formatting.None, new JsonConverter[0]));
						streamWriter.Close();
						File.Copy(this.mAppsDotJsonFile + ".tmp", this.mAppsDotJsonFile + ".bak", true);
						File.Delete(this.mAppsDotJsonFile);
						int num = 10;
						while (File.Exists(this.mAppsDotJsonFile) && num > 0)
						{
							num--;
							Thread.Sleep(100);
						}
						File.Move(this.mAppsDotJsonFile + ".tmp", this.mAppsDotJsonFile);
					}
					catch (Exception ex)
					{
						Logger.Error("Failed to write in apps json file... Err : " + ex.ToString());
					}
					finally
					{
						mutex.ReleaseMutex();
					}
				}
			}
		}

		// Token: 0x06000897 RID: 2199 RVA: 0x00025C98 File Offset: 0x00023E98
		public int AddToJson(AppInfo json)
		{
			this.GetAppList();
			Logger.Info("Adding to Json");
			AppInfo[] array = new AppInfo[this.mOriginalJson.Length + 1];
			int i;
			for (i = 0; i < this.mOriginalJson.Length; i++)
			{
				array[i] = this.mOriginalJson[i];
			}
			array[i] = json;
			this.WriteJson(array);
			return this.mOriginalJson.Length;
		}

		// Token: 0x06000898 RID: 2200 RVA: 0x00025CF8 File Offset: 0x00023EF8
		public static void DeleteIfInvalidJsonFile(string fileName)
		{
			try
			{
				if (!JsonParser.IsValidJsonFile(fileName))
				{
					File.Delete(fileName);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Some error in deleting file, ex: " + ex.Message);
			}
		}

		// Token: 0x06000899 RID: 2201 RVA: 0x00025D40 File Offset: 0x00023F40
		private static bool IsValidJsonFile(string fileName)
		{
			bool result;
			try
			{
				JArray.Parse(File.ReadAllText(fileName));
				result = true;
			}
			catch (Exception ex)
			{
				Logger.Error("Invalid JSon file: " + fileName);
				Logger.Error(ex.Message);
				result = false;
			}
			return result;
		}

		// Token: 0x0400055F RID: 1375
		private string mAppsDotJsonFile;

		// Token: 0x04000560 RID: 1376
		private AppInfo[] mOriginalJson;
	}
}
