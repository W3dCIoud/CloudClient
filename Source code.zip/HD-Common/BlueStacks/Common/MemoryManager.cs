﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;

namespace BlueStacks.Common
{
	// Token: 0x0200009E RID: 158
	public static class MemoryManager
	{
		// Token: 0x060003CA RID: 970
		[DllImport("KERNEL32.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "SetProcessWorkingSetSize", SetLastError = true)]
		private static extern bool SetProcessWorkingSetSize32(IntPtr pProcess, int dwMinimumWorkingSetSize, int dwMaximumWorkingSetSize);

		// Token: 0x060003CB RID: 971
		[DllImport("KERNEL32.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "SetProcessWorkingSetSize", SetLastError = true)]
		private static extern bool SetProcessWorkingSetSize64(IntPtr pProcess, long dwMinimumWorkingSetSize, long dwMaximumWorkingSetSize);

		// Token: 0x060003CC RID: 972
		[DllImport("psapi.dll")]
		private static extern int EmptyWorkingSet(IntPtr hwProc);

		// Token: 0x060003CD RID: 973 RVA: 0x0000424A File Offset: 0x0000244A
		public static void TrimMemory()
		{
			new Thread(delegate()
			{
				int millisecondsTimeout = RegistryManager.Instance.TrimMemoryDuration * 1000;
				Logger.Info("Setting trim memory duration to: " + millisecondsTimeout.ToString());
				for (;;)
				{
					Thread.Sleep(millisecondsTimeout);
					try
					{
						GC.Collect(2, GCCollectionMode.Forced);
						GC.WaitForPendingFinalizers();
						if (Environment.OSVersion.Platform == PlatformID.Win32NT)
						{
							if (IntPtr.Size == 8)
							{
								MemoryManager.SetProcessWorkingSetSize64(Process.GetCurrentProcess().Handle, -1L, -1L);
							}
							else
							{
								MemoryManager.SetProcessWorkingSetSize32(Process.GetCurrentProcess().Handle, -1, -1);
							}
						}
						using (Process currentProcess = Process.GetCurrentProcess())
						{
							Logger.Debug("Trimming memory");
							MemoryManager.EmptyWorkingSet(currentProcess.Handle);
						}
					}
					catch (Exception ex)
					{
						Logger.Error("Exception while trimming memory ex: " + ex.ToString());
					}
				}
			})
			{
				IsBackground = true
			}.Start();
		}
	}
}
