﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200011D RID: 285
	public enum GuidanceVideoType
	{
		// Token: 0x04000511 RID: 1297
		Default,
		// Token: 0x04000512 RID: 1298
		Pan,
		// Token: 0x04000513 RID: 1299
		Moba,
		// Token: 0x04000514 RID: 1300
		Gamepad,
		// Token: 0x04000515 RID: 1301
		Special,
		// Token: 0x04000516 RID: 1302
		SchemeSpecific
	}
}
