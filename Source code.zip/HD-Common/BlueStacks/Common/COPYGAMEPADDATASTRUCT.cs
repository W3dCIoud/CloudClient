﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001F2 RID: 498
	public struct COPYGAMEPADDATASTRUCT
	{
		// Token: 0x1700041B RID: 1051
		// (get) Token: 0x06000F86 RID: 3974 RVA: 0x0000D8AE File Offset: 0x0000BAAE
		// (set) Token: 0x06000F87 RID: 3975 RVA: 0x0000D8B6 File Offset: 0x0000BAB6
		public IntPtr dwData { readonly get; set; }

		// Token: 0x1700041C RID: 1052
		// (get) Token: 0x06000F88 RID: 3976 RVA: 0x0000D8BF File Offset: 0x0000BABF
		// (set) Token: 0x06000F89 RID: 3977 RVA: 0x0000D8C7 File Offset: 0x0000BAC7
		public int size { readonly get; set; }

		// Token: 0x1700041D RID: 1053
		// (get) Token: 0x06000F8A RID: 3978 RVA: 0x0000D8D0 File Offset: 0x0000BAD0
		// (set) Token: 0x06000F8B RID: 3979 RVA: 0x0000D8D8 File Offset: 0x0000BAD8
		public IntPtr lpData { readonly get; set; }
	}
}
