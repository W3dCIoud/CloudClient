﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000107 RID: 263
	public struct GamePad
	{
		// Token: 0x17000268 RID: 616
		// (get) Token: 0x06000867 RID: 2151 RVA: 0x000081A4 File Offset: 0x000063A4
		// (set) Token: 0x06000868 RID: 2152 RVA: 0x000081AC File Offset: 0x000063AC
		public int X { readonly get; set; }

		// Token: 0x17000269 RID: 617
		// (get) Token: 0x06000869 RID: 2153 RVA: 0x000081B5 File Offset: 0x000063B5
		// (set) Token: 0x0600086A RID: 2154 RVA: 0x000081BD File Offset: 0x000063BD
		public int Y { readonly get; set; }

		// Token: 0x1700026A RID: 618
		// (get) Token: 0x0600086B RID: 2155 RVA: 0x000081C6 File Offset: 0x000063C6
		// (set) Token: 0x0600086C RID: 2156 RVA: 0x000081CE File Offset: 0x000063CE
		public int Z { readonly get; set; }

		// Token: 0x1700026B RID: 619
		// (get) Token: 0x0600086D RID: 2157 RVA: 0x000081D7 File Offset: 0x000063D7
		// (set) Token: 0x0600086E RID: 2158 RVA: 0x000081DF File Offset: 0x000063DF
		public int Rx { readonly get; set; }

		// Token: 0x1700026C RID: 620
		// (get) Token: 0x0600086F RID: 2159 RVA: 0x000081E8 File Offset: 0x000063E8
		// (set) Token: 0x06000870 RID: 2160 RVA: 0x000081F0 File Offset: 0x000063F0
		public int Ry { readonly get; set; }

		// Token: 0x1700026D RID: 621
		// (get) Token: 0x06000871 RID: 2161 RVA: 0x000081F9 File Offset: 0x000063F9
		// (set) Token: 0x06000872 RID: 2162 RVA: 0x00008201 File Offset: 0x00006401
		public int Rz { readonly get; set; }

		// Token: 0x1700026E RID: 622
		// (get) Token: 0x06000873 RID: 2163 RVA: 0x0000820A File Offset: 0x0000640A
		// (set) Token: 0x06000874 RID: 2164 RVA: 0x00008212 File Offset: 0x00006412
		public int Hat { readonly get; set; }

		// Token: 0x1700026F RID: 623
		// (get) Token: 0x06000875 RID: 2165 RVA: 0x0000821B File Offset: 0x0000641B
		// (set) Token: 0x06000876 RID: 2166 RVA: 0x00008223 File Offset: 0x00006423
		public uint Mask { readonly get; set; }
	}
}
