﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000118 RID: 280
	public enum ABISetting
	{
		// Token: 0x040004F6 RID: 1270
		ARM = 4,
		// Token: 0x040004F7 RID: 1271
		Auto = 15
	}
}
