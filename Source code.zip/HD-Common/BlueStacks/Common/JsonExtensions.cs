﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x0200012B RID: 299
	public static class JsonExtensions
	{
		// Token: 0x06000877 RID: 2167 RVA: 0x000250F4 File Offset: 0x000232F4
		public static IEnumerable<KeyValuePair<string, string>> ToStringStringEnumerableKvp(this JToken obj)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			if (obj != null)
			{
				foreach (KeyValuePair<string, string> keyValuePair in obj.ToObject<Dictionary<string, string>>())
				{
					dictionary.Add(keyValuePair.Key, keyValuePair.Value);
				}
			}
			return dictionary;
		}

		// Token: 0x06000878 RID: 2168 RVA: 0x00025160 File Offset: 0x00023360
		public static IDictionary<string, T> ToDictionary<T>(this JToken obj)
		{
			Dictionary<string, T> dictionary = new Dictionary<string, T>();
			if (obj != null)
			{
				foreach (KeyValuePair<string, T> keyValuePair in obj.ToObject<IDictionary<string, T>>())
				{
					dictionary.Add(keyValuePair.Key, keyValuePair.Value);
				}
			}
			return dictionary;
		}

		// Token: 0x06000879 RID: 2169 RVA: 0x000251C4 File Offset: 0x000233C4
		public static SerializableDictionary<string, T> ToSerializableDictionary<T>(this JToken obj)
		{
			SerializableDictionary<string, T> serializableDictionary = new SerializableDictionary<string, T>();
			if (obj != null)
			{
				foreach (KeyValuePair<string, T> keyValuePair in obj.ToObject<SerializableDictionary<string, T>>())
				{
					serializableDictionary.Add(keyValuePair.Key, keyValuePair.Value);
				}
			}
			return serializableDictionary;
		}

		// Token: 0x0600087A RID: 2170 RVA: 0x0000822C File Offset: 0x0000642C
		public static IEnumerable<string> ToIenumerableString(this JToken obj)
		{
			if (obj != null)
			{
				return obj.ToObject<List<string>>();
			}
			return null;
		}

		// Token: 0x0600087B RID: 2171 RVA: 0x00008239 File Offset: 0x00006439
		public static bool AssignIfContains<T>(this JToken resJson, string key, Action<T> setter)
		{
			if (resJson != null && resJson[key] != null && setter != null)
			{
				setter(resJson.Value<T>(key));
				return true;
			}
			return false;
		}

		// Token: 0x0600087C RID: 2172 RVA: 0x0000825A File Offset: 0x0000645A
		public static void AssignStringIfContains(this JToken resJson, string key, ref string result)
		{
			if (resJson != null && resJson[key] != null)
			{
				result = resJson[key].ToString();
			}
		}

		// Token: 0x0600087D RID: 2173 RVA: 0x00008276 File Offset: 0x00006476
		public static void AssignDoubleIfContains(this JToken resJson, string key, ref double result)
		{
			if (resJson != null && resJson[key] != null)
			{
				result = resJson[key].ToObject<double>();
			}
		}

		// Token: 0x0600087E RID: 2174 RVA: 0x00008292 File Offset: 0x00006492
		public static bool IsNullOrEmptyBrackets(string str)
		{
			str = Regex.Replace(str, "\\s+", "");
			return string.IsNullOrEmpty(str) || string.Compare(str, "{}", StringComparison.OrdinalIgnoreCase) == 0;
		}

		// Token: 0x0600087F RID: 2175 RVA: 0x000082C1 File Offset: 0x000064C1
		public static string GetValue(this JToken obj, string key)
		{
			if (obj != null && obj[key] != null)
			{
				return obj[key].ToString();
			}
			return string.Empty;
		}

		// Token: 0x06000880 RID: 2176 RVA: 0x00025230 File Offset: 0x00023430
		public static bool IsNullOrEmpty(this JToken token)
		{
			return token == null || (token.Type == JTokenType.Array && !token.HasValues) || (token.Type == JTokenType.Object && !token.HasValues) || (token.Type == JTokenType.String && string.IsNullOrEmpty(token.ToString())) || token.Type == JTokenType.Null;
		}
	}
}
