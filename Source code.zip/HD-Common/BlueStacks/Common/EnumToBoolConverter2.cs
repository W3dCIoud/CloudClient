﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace BlueStacks.Common
{
	// Token: 0x0200005E RID: 94
	public class EnumToBoolConverter2 : IValueConverter
	{
		// Token: 0x06000205 RID: 517 RVA: 0x00002FAD File Offset: 0x000011AD
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			if (parameter == null || value == null)
			{
				return Binding.DoNothing;
			}
			return value.ToString().Equals(parameter.ToString(), StringComparison.InvariantCultureIgnoreCase);
		}

		// Token: 0x06000206 RID: 518 RVA: 0x00002FD2 File Offset: 0x000011D2
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			if (parameter == null || value == null)
			{
				return Binding.DoNothing;
			}
			if (!value.Equals(true))
			{
				return Binding.DoNothing;
			}
			return parameter.ToString();
		}
	}
}
