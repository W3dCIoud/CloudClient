﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace BlueStacks.Common
{
	// Token: 0x02000053 RID: 83
	[Serializable]
	public class AppConfigurationManager
	{
		// Token: 0x1700008B RID: 139
		// (get) Token: 0x060001D4 RID: 468 RVA: 0x00010DA8 File Offset: 0x0000EFA8
		public static AppConfigurationManager Instance
		{
			get
			{
				if (AppConfigurationManager.sInstance == null)
				{
					object obj = AppConfigurationManager.syncRoot;
					lock (obj)
					{
						if (AppConfigurationManager.sInstance == null)
						{
							AppConfigurationManager.Init();
						}
					}
				}
				return AppConfigurationManager.sInstance;
			}
		}

		// Token: 0x060001D5 RID: 469 RVA: 0x00002DDA File Offset: 0x00000FDA
		private AppConfigurationManager()
		{
		}

		// Token: 0x060001D6 RID: 470 RVA: 0x00010DF8 File Offset: 0x0000EFF8
		private static void Init()
		{
			try
			{
				AppConfigurationManager.sInstance = JsonConvert.DeserializeObject<AppConfigurationManager>(RegistryManager.Instance.AppConfiguration, Utils.GetSerializerSettings());
			}
			catch (Exception ex)
			{
				Logger.Warning("Error loading app configurations. Ex: " + ex.ToString());
			}
		}

		// Token: 0x060001D7 RID: 471 RVA: 0x00002DED File Offset: 0x00000FED
		public static void Save()
		{
			if (AppConfigurationManager.sInstance != null)
			{
				RegistryManager.Instance.AppConfiguration = JsonConvert.SerializeObject(AppConfigurationManager.sInstance, Utils.GetSerializerSettings());
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x060001D8 RID: 472 RVA: 0x00002E13 File Offset: 0x00001013
		[JsonProperty("VmAppConfig", DefaultValueHandling = DefaultValueHandling.Populate, NullValueHandling = NullValueHandling.Ignore)]
		public Dictionary<string, Dictionary<string, AppSettings>> VmAppConfig { get; } = new Dictionary<string, Dictionary<string, AppSettings>>();

		// Token: 0x060001D9 RID: 473 RVA: 0x00010E4C File Offset: 0x0000F04C
		public bool CheckIfTrueInAnyVm(string package, Predicate<AppSettings> rule)
		{
			foreach (Dictionary<string, AppSettings> dictionary in this.VmAppConfig.Values)
			{
				if (dictionary.ContainsKey(package) && rule(dictionary[package]))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x040000B8 RID: 184
		private static volatile AppConfigurationManager sInstance;

		// Token: 0x040000B9 RID: 185
		private static object syncRoot = new object();
	}
}
