﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x020000D1 RID: 209
	public class CornerRadiusToDoubleConvertor : MarkupExtension, IValueConverter
	{
		// Token: 0x06000578 RID: 1400 RVA: 0x000054CA File Offset: 0x000036CA
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return CornerRadiusToDoubleConvertor.Convert(value, targetType);
		}

		// Token: 0x06000579 RID: 1401 RVA: 0x000054CA File Offset: 0x000036CA
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return CornerRadiusToDoubleConvertor.Convert(value, targetType);
		}

		// Token: 0x0600057A RID: 1402 RVA: 0x0001D714 File Offset: 0x0001B914
		public static object Convert(object value, Type targetType)
		{
			if (typeof(double).Equals(targetType))
			{
				return ((CornerRadius)value).TopLeft;
			}
			return value;
		}

		// Token: 0x0600057B RID: 1403 RVA: 0x000054B6 File Offset: 0x000036B6
		public override object ProvideValue(IServiceProvider serviceProvider)
		{
			return this;
		}
	}
}
