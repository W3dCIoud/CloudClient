﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000101 RID: 257
	public enum GenericAction
	{
		// Token: 0x0400045F RID: 1119
		InstallPlay = 1,
		// Token: 0x04000460 RID: 1120
		InstallCDN,
		// Token: 0x04000461 RID: 1121
		ApplicationBrowser = 4,
		// Token: 0x04000462 RID: 1122
		UserBrowser = 8,
		// Token: 0x04000463 RID: 1123
		AppCenter = 16,
		// Token: 0x04000464 RID: 1124
		HomeAppTab = 32,
		// Token: 0x04000465 RID: 1125
		SettingsMenu = 64,
		// Token: 0x04000466 RID: 1126
		KeyBasedPopup = 128,
		// Token: 0x04000467 RID: 1127
		OpenSystemApp = 256,
		// Token: 0x04000468 RID: 1128
		PopupBrowser = 512,
		// Token: 0x04000469 RID: 1129
		QuickLaunch = 1024,
		// Token: 0x0400046A RID: 1130
		None = 65536
	}
}
