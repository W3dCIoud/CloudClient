﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace BlueStacks.Common
{
	// Token: 0x02000140 RID: 320
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("000214F9-0000-0000-C000-000000000046")]
	[ComImport]
	public interface IShellLink
	{
		// Token: 0x06000ADC RID: 2780
		void GetPath([MarshalAs(UnmanagedType.LPWStr)] [Out] StringBuilder pszFile, int cchMaxPath, out WIN32_FIND_DATAW pfd, int fFlags);

		// Token: 0x06000ADD RID: 2781
		void GetIDList(out IntPtr ppidl);

		// Token: 0x06000ADE RID: 2782
		void SetIDList(IntPtr pidl);

		// Token: 0x06000ADF RID: 2783
		void GetDescription([MarshalAs(UnmanagedType.LPWStr)] [Out] StringBuilder pszName, int cchMaxName);

		// Token: 0x06000AE0 RID: 2784
		void SetDescription([MarshalAs(UnmanagedType.LPWStr)] string pszName);

		// Token: 0x06000AE1 RID: 2785
		void GetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] [Out] StringBuilder pszDir, int cchMaxPath);

		// Token: 0x06000AE2 RID: 2786
		void SetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] string pszDir);

		// Token: 0x06000AE3 RID: 2787
		void GetArguments([MarshalAs(UnmanagedType.LPWStr)] [Out] StringBuilder pszArgs, int cchMaxPath);

		// Token: 0x06000AE4 RID: 2788
		void SetArguments([MarshalAs(UnmanagedType.LPWStr)] string pszArgs);

		// Token: 0x06000AE5 RID: 2789
		void GetHotkey(out short pwHotkey);

		// Token: 0x06000AE6 RID: 2790
		void SetHotkey(short wHotkey);

		// Token: 0x06000AE7 RID: 2791
		void GetShowCmd(out int piShowCmd);

		// Token: 0x06000AE8 RID: 2792
		void SetShowCmd(int iShowCmd);

		// Token: 0x06000AE9 RID: 2793
		void GetIconLocation([MarshalAs(UnmanagedType.LPWStr)] [Out] StringBuilder pszIconPath, int cchIconPath, out int piIcon);

		// Token: 0x06000AEA RID: 2794
		void SetIconLocation([MarshalAs(UnmanagedType.LPWStr)] string pszIconPath, int iIcon);

		// Token: 0x06000AEB RID: 2795
		void SetRelativePath([MarshalAs(UnmanagedType.LPWStr)] string pszPathRel, int dwReserved);

		// Token: 0x06000AEC RID: 2796
		void Resolve(IntPtr hwnd, int fFlags);

		// Token: 0x06000AED RID: 2797
		void SetPath([MarshalAs(UnmanagedType.LPWStr)] string pszFile);
	}
}
