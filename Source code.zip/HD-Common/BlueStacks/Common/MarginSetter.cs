﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x0200012E RID: 302
	public class MarginSetter : MarkupExtension
	{
		// Token: 0x060008B3 RID: 2227 RVA: 0x000083C0 File Offset: 0x000065C0
		private static Thickness GetMargin(DependencyObject obj)
		{
			return (Thickness)obj.GetValue(MarginSetter.MarginProperty);
		}

		// Token: 0x060008B4 RID: 2228 RVA: 0x000083D2 File Offset: 0x000065D2
		public static void SetMargin(DependencyObject obj, Thickness value)
		{
			if (obj != null)
			{
				obj.SetValue(MarginSetter.MarginProperty, value);
			}
		}

		// Token: 0x060008B5 RID: 2229 RVA: 0x00025F7C File Offset: 0x0002417C
		public static void CreateThicknesForChildren(object sender, DependencyPropertyChangedEventArgs e)
		{
			Panel panel = sender as Panel;
			if (panel == null)
			{
				return;
			}
			foreach (object obj in panel.Children)
			{
				FrameworkElement frameworkElement = obj as FrameworkElement;
				if (frameworkElement != null)
				{
					frameworkElement.Margin = MarginSetter.GetMargin(panel);
				}
			}
		}

		// Token: 0x060008B6 RID: 2230 RVA: 0x000054B6 File Offset: 0x000036B6
		public override object ProvideValue(IServiceProvider serviceProvider)
		{
			return this;
		}

		// Token: 0x0400056D RID: 1389
		public static readonly DependencyProperty MarginProperty = DependencyProperty.RegisterAttached("Margin", typeof(Thickness), typeof(MarginSetter), new UIPropertyMetadata(default(Thickness), new PropertyChangedCallback(MarginSetter.CreateThicknesForChildren)));
	}
}
