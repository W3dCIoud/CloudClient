﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001F4 RID: 500
	public struct IconInfo
	{
		// Token: 0x1700041E RID: 1054
		// (get) Token: 0x06000F8C RID: 3980 RVA: 0x0000D8E1 File Offset: 0x0000BAE1
		// (set) Token: 0x06000F8D RID: 3981 RVA: 0x0000D8E9 File Offset: 0x0000BAE9
		public bool fIcon { readonly get; set; }

		// Token: 0x1700041F RID: 1055
		// (get) Token: 0x06000F8E RID: 3982 RVA: 0x0000D8F2 File Offset: 0x0000BAF2
		// (set) Token: 0x06000F8F RID: 3983 RVA: 0x0000D8FA File Offset: 0x0000BAFA
		public int xHotspot { readonly get; set; }

		// Token: 0x17000420 RID: 1056
		// (get) Token: 0x06000F90 RID: 3984 RVA: 0x0000D903 File Offset: 0x0000BB03
		// (set) Token: 0x06000F91 RID: 3985 RVA: 0x0000D90B File Offset: 0x0000BB0B
		public int yHotspot { readonly get; set; }

		// Token: 0x17000421 RID: 1057
		// (get) Token: 0x06000F92 RID: 3986 RVA: 0x0000D914 File Offset: 0x0000BB14
		// (set) Token: 0x06000F93 RID: 3987 RVA: 0x0000D91C File Offset: 0x0000BB1C
		public IntPtr hbmMask { readonly get; set; }

		// Token: 0x17000422 RID: 1058
		// (get) Token: 0x06000F94 RID: 3988 RVA: 0x0000D925 File Offset: 0x0000BB25
		// (set) Token: 0x06000F95 RID: 3989 RVA: 0x0000D92D File Offset: 0x0000BB2D
		public IntPtr hbmColor { readonly get; set; }
	}
}
