﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000071 RID: 113
	public interface ISubscriber
	{
		// Token: 0x1700009B RID: 155
		// (get) Token: 0x06000243 RID: 579
		// (set) Token: 0x06000244 RID: 580
		string CallbackFunction { get; set; }

		// Token: 0x06000245 RID: 581
		void SubscribeTag(BrowserControlTags args);

		// Token: 0x06000246 RID: 582
		void UnsubscribeTag(BrowserControlTags args);

		// Token: 0x06000247 RID: 583
		void Message(EventArgs eventArgs);
	}
}
