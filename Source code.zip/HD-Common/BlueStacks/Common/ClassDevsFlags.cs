﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000163 RID: 355
	[Flags]
	public enum ClassDevsFlags
	{
		// Token: 0x0400067E RID: 1662
		DIGCF_DEFAULT = 1,
		// Token: 0x0400067F RID: 1663
		DIGCF_PRESENT = 2,
		// Token: 0x04000680 RID: 1664
		DIGCF_ALLCLASSES = 4,
		// Token: 0x04000681 RID: 1665
		DIGCF_PROFILE = 8,
		// Token: 0x04000682 RID: 1666
		DIGCF_DEVICEINTERFACE = 16
	}
}
