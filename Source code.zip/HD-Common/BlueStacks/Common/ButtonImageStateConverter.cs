﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace BlueStacks.Common
{
	// Token: 0x02000089 RID: 137
	public class ButtonImageStateConverter : IValueConverter
	{
		// Token: 0x06000367 RID: 871 RVA: 0x00003E2D File Offset: 0x0000202D
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			if (parameter == null)
			{
				return Binding.DoNothing;
			}
			if (!string.IsNullOrEmpty((string)value))
			{
				return value.ToString() + "_" + parameter.ToString();
			}
			return "";
		}

		// Token: 0x06000368 RID: 872 RVA: 0x00002FA6 File Offset: 0x000011A6
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return Binding.DoNothing;
		}
	}
}
