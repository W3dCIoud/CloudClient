﻿using System;
using System.Globalization;
using System.IO;
using System.Text;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x0200020C RID: 524
	internal static class GifHelpers
	{
		// Token: 0x06001062 RID: 4194 RVA: 0x0003E114 File Offset: 0x0003C314
		public static string ReadString(Stream stream, int length)
		{
			byte[] array = new byte[length];
			stream.ReadAll(array, 0, length);
			return Encoding.ASCII.GetString(array);
		}

		// Token: 0x06001063 RID: 4195 RVA: 0x0003E13C File Offset: 0x0003C33C
		public static byte[] ReadDataBlocks(Stream stream, bool discard)
		{
			MemoryStream memoryStream = discard ? null : new MemoryStream();
			byte[] result;
			using (memoryStream)
			{
				int num;
				while ((num = stream.ReadByte()) > 0)
				{
					byte[] buffer = new byte[num];
					stream.ReadAll(buffer, 0, num);
					if (memoryStream != null)
					{
						memoryStream.Write(buffer, 0, num);
					}
				}
				if (memoryStream != null)
				{
					result = memoryStream.ToArray();
				}
				else
				{
					result = null;
				}
			}
			return result;
		}

		// Token: 0x06001064 RID: 4196 RVA: 0x0003E1B0 File Offset: 0x0003C3B0
		public static GifColor[] ReadColorTable(Stream stream, int size)
		{
			int num = 3 * size;
			byte[] array = new byte[num];
			stream.ReadAll(array, 0, num);
			GifColor[] array2 = new GifColor[size];
			for (int i = 0; i < size; i++)
			{
				byte r = array[3 * i];
				byte g = array[3 * i + 1];
				byte b = array[3 * i + 2];
				array2[i] = new GifColor(r, g, b);
			}
			return array2;
		}

		// Token: 0x06001065 RID: 4197 RVA: 0x0000DDF8 File Offset: 0x0000BFF8
		public static bool IsNetscapeExtension(GifApplicationExtension ext)
		{
			return ext.ApplicationIdentifier == "NETSCAPE" && Encoding.ASCII.GetString(ext.AuthenticationCode) == "2.0";
		}

		// Token: 0x06001066 RID: 4198 RVA: 0x0000DE28 File Offset: 0x0000C028
		public static ushort GetRepeatCount(GifApplicationExtension ext)
		{
			if (ext.Data.Length >= 3)
			{
				return BitConverter.ToUInt16(ext.Data, 1);
			}
			return 1;
		}

		// Token: 0x06001067 RID: 4199 RVA: 0x0000DE43 File Offset: 0x0000C043
		public static Exception UnexpectedEndOfStreamException()
		{
			return new GifDecoderException("Unexpected end of stream before trailer was encountered");
		}

		// Token: 0x06001068 RID: 4200 RVA: 0x0000DE4F File Offset: 0x0000C04F
		public static Exception UnknownBlockTypeException(int blockId)
		{
			return new GifDecoderException("Unknown block type: 0x" + blockId.ToString("x2", CultureInfo.InvariantCulture));
		}

		// Token: 0x06001069 RID: 4201 RVA: 0x0000DE71 File Offset: 0x0000C071
		public static Exception UnknownExtensionTypeException(int extensionLabel)
		{
			return new GifDecoderException("Unknown extension type: 0x" + extensionLabel.ToString("x2", CultureInfo.InvariantCulture));
		}

		// Token: 0x0600106A RID: 4202 RVA: 0x0000DE93 File Offset: 0x0000C093
		public static Exception InvalidBlockSizeException(string blockName, int expectedBlockSize, int actualBlockSize)
		{
			return new GifDecoderException(string.Format(CultureInfo.InvariantCulture, "Invalid block size for {0}. Expected {1}, but was {2}", new object[]
			{
				blockName,
				expectedBlockSize,
				actualBlockSize
			}));
		}

		// Token: 0x0600106B RID: 4203 RVA: 0x0000DEC5 File Offset: 0x0000C0C5
		public static Exception InvalidSignatureException(string signature)
		{
			return new GifDecoderException("Invalid file signature: " + signature);
		}

		// Token: 0x0600106C RID: 4204 RVA: 0x0000DED7 File Offset: 0x0000C0D7
		public static Exception UnsupportedVersionException(string version)
		{
			return new GifDecoderException("Unsupported version: " + version);
		}

		// Token: 0x0600106D RID: 4205 RVA: 0x0003E210 File Offset: 0x0003C410
		public static void ReadAll(this Stream stream, byte[] buffer, int offset, int count)
		{
			for (int i = 0; i < count; i += stream.Read(buffer, offset + i, count - i))
			{
			}
		}
	}
}
