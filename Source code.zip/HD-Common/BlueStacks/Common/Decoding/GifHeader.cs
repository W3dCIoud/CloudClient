﻿using System;
using System.IO;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x0200020B RID: 523
	internal class GifHeader : GifBlock
	{
		// Token: 0x17000444 RID: 1092
		// (get) Token: 0x06001058 RID: 4184 RVA: 0x0000DDB4 File Offset: 0x0000BFB4
		// (set) Token: 0x06001059 RID: 4185 RVA: 0x0000DDBC File Offset: 0x0000BFBC
		public string Signature { get; private set; }

		// Token: 0x17000445 RID: 1093
		// (get) Token: 0x0600105A RID: 4186 RVA: 0x0000DDC5 File Offset: 0x0000BFC5
		// (set) Token: 0x0600105B RID: 4187 RVA: 0x0000DDCD File Offset: 0x0000BFCD
		public string Version { get; private set; }

		// Token: 0x17000446 RID: 1094
		// (get) Token: 0x0600105C RID: 4188 RVA: 0x0000DDD6 File Offset: 0x0000BFD6
		// (set) Token: 0x0600105D RID: 4189 RVA: 0x0000DDDE File Offset: 0x0000BFDE
		public GifLogicalScreenDescriptor LogicalScreenDescriptor { get; private set; }

		// Token: 0x0600105E RID: 4190 RVA: 0x0000DC80 File Offset: 0x0000BE80
		private GifHeader()
		{
		}

		// Token: 0x17000447 RID: 1095
		// (get) Token: 0x0600105F RID: 4191 RVA: 0x0000DDE7 File Offset: 0x0000BFE7
		internal override GifBlockKind Kind
		{
			get
			{
				return GifBlockKind.Other;
			}
		}

		// Token: 0x06001060 RID: 4192 RVA: 0x0000DDEA File Offset: 0x0000BFEA
		internal static GifHeader ReadHeader(Stream stream)
		{
			GifHeader gifHeader = new GifHeader();
			gifHeader.Read(stream);
			return gifHeader;
		}

		// Token: 0x06001061 RID: 4193 RVA: 0x0003E090 File Offset: 0x0003C290
		private void Read(Stream stream)
		{
			this.Signature = GifHelpers.ReadString(stream, 3);
			if (this.Signature != "GIF")
			{
				throw GifHelpers.InvalidSignatureException(this.Signature);
			}
			this.Version = GifHelpers.ReadString(stream, 3);
			if (this.Version != "87a" && this.Version != "89a")
			{
				throw GifHelpers.UnsupportedVersionException(this.Version);
			}
			this.LogicalScreenDescriptor = GifLogicalScreenDescriptor.ReadLogicalScreenDescriptor(stream);
		}
	}
}
