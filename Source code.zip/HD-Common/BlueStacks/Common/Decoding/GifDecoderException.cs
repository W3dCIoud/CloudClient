﻿using System;
using System.Runtime.Serialization;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x02000206 RID: 518
	[Serializable]
	public class GifDecoderException : Exception
	{
		// Token: 0x06001028 RID: 4136 RVA: 0x000023F8 File Offset: 0x000005F8
		internal GifDecoderException()
		{
		}

		// Token: 0x06001029 RID: 4137 RVA: 0x00002400 File Offset: 0x00000600
		internal GifDecoderException(string message) : base(message)
		{
		}

		// Token: 0x0600102A RID: 4138 RVA: 0x00002409 File Offset: 0x00000609
		internal GifDecoderException(string message, Exception inner) : base(message, inner)
		{
		}

		// Token: 0x0600102B RID: 4139 RVA: 0x00002413 File Offset: 0x00000613
		protected GifDecoderException(SerializationInfo info, StreamingContext context) : base(info, context)
		{
		}
	}
}
