﻿using System;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x02000203 RID: 515
	internal enum GifBlockKind
	{
		// Token: 0x04000CBB RID: 3259
		Control,
		// Token: 0x04000CBC RID: 3260
		GraphicRendering,
		// Token: 0x04000CBD RID: 3261
		SpecialPurpose,
		// Token: 0x04000CBE RID: 3262
		Other
	}
}
