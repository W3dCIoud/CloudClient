﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x02000210 RID: 528
	internal class GifPlainTextExtension : GifExtension
	{
		// Token: 0x1700045A RID: 1114
		// (get) Token: 0x0600109B RID: 4251 RVA: 0x0000E062 File Offset: 0x0000C262
		// (set) Token: 0x0600109C RID: 4252 RVA: 0x0000E06A File Offset: 0x0000C26A
		public int BlockSize { get; private set; }

		// Token: 0x1700045B RID: 1115
		// (get) Token: 0x0600109D RID: 4253 RVA: 0x0000E073 File Offset: 0x0000C273
		// (set) Token: 0x0600109E RID: 4254 RVA: 0x0000E07B File Offset: 0x0000C27B
		public int Left { get; private set; }

		// Token: 0x1700045C RID: 1116
		// (get) Token: 0x0600109F RID: 4255 RVA: 0x0000E084 File Offset: 0x0000C284
		// (set) Token: 0x060010A0 RID: 4256 RVA: 0x0000E08C File Offset: 0x0000C28C
		public int Top { get; private set; }

		// Token: 0x1700045D RID: 1117
		// (get) Token: 0x060010A1 RID: 4257 RVA: 0x0000E095 File Offset: 0x0000C295
		// (set) Token: 0x060010A2 RID: 4258 RVA: 0x0000E09D File Offset: 0x0000C29D
		public int Width { get; private set; }

		// Token: 0x1700045E RID: 1118
		// (get) Token: 0x060010A3 RID: 4259 RVA: 0x0000E0A6 File Offset: 0x0000C2A6
		// (set) Token: 0x060010A4 RID: 4260 RVA: 0x0000E0AE File Offset: 0x0000C2AE
		public int Height { get; private set; }

		// Token: 0x1700045F RID: 1119
		// (get) Token: 0x060010A5 RID: 4261 RVA: 0x0000E0B7 File Offset: 0x0000C2B7
		// (set) Token: 0x060010A6 RID: 4262 RVA: 0x0000E0BF File Offset: 0x0000C2BF
		public int CellWidth { get; private set; }

		// Token: 0x17000460 RID: 1120
		// (get) Token: 0x060010A7 RID: 4263 RVA: 0x0000E0C8 File Offset: 0x0000C2C8
		// (set) Token: 0x060010A8 RID: 4264 RVA: 0x0000E0D0 File Offset: 0x0000C2D0
		public int CellHeight { get; private set; }

		// Token: 0x17000461 RID: 1121
		// (get) Token: 0x060010A9 RID: 4265 RVA: 0x0000E0D9 File Offset: 0x0000C2D9
		// (set) Token: 0x060010AA RID: 4266 RVA: 0x0000E0E1 File Offset: 0x0000C2E1
		public int ForegroundColorIndex { get; private set; }

		// Token: 0x17000462 RID: 1122
		// (get) Token: 0x060010AB RID: 4267 RVA: 0x0000E0EA File Offset: 0x0000C2EA
		// (set) Token: 0x060010AC RID: 4268 RVA: 0x0000E0F2 File Offset: 0x0000C2F2
		public int BackgroundColorIndex { get; private set; }

		// Token: 0x17000463 RID: 1123
		// (get) Token: 0x060010AD RID: 4269 RVA: 0x0000E0FB File Offset: 0x0000C2FB
		// (set) Token: 0x060010AE RID: 4270 RVA: 0x0000E103 File Offset: 0x0000C303
		public string Text { get; private set; }

		// Token: 0x17000464 RID: 1124
		// (get) Token: 0x060010AF RID: 4271 RVA: 0x0000E10C File Offset: 0x0000C30C
		// (set) Token: 0x060010B0 RID: 4272 RVA: 0x0000E114 File Offset: 0x0000C314
		public IList<GifExtension> Extensions { get; private set; }

		// Token: 0x060010B1 RID: 4273 RVA: 0x0000DC31 File Offset: 0x0000BE31
		private GifPlainTextExtension()
		{
		}

		// Token: 0x17000465 RID: 1125
		// (get) Token: 0x060010B2 RID: 4274 RVA: 0x0000323B File Offset: 0x0000143B
		internal override GifBlockKind Kind
		{
			get
			{
				return GifBlockKind.GraphicRendering;
			}
		}

		// Token: 0x060010B3 RID: 4275 RVA: 0x0000E11D File Offset: 0x0000C31D
		internal static GifPlainTextExtension ReadPlainText(Stream stream, IEnumerable<GifExtension> controlExtensions, bool metadataOnly)
		{
			GifPlainTextExtension gifPlainTextExtension = new GifPlainTextExtension();
			gifPlainTextExtension.Read(stream, controlExtensions, metadataOnly);
			return gifPlainTextExtension;
		}

		// Token: 0x060010B4 RID: 4276 RVA: 0x0003E374 File Offset: 0x0003C574
		private void Read(Stream stream, IEnumerable<GifExtension> controlExtensions, bool metadataOnly)
		{
			byte[] array = new byte[13];
			stream.ReadAll(array, 0, array.Length);
			this.BlockSize = (int)array[0];
			if (this.BlockSize != 12)
			{
				throw GifHelpers.InvalidBlockSizeException("Plain Text Extension", 12, this.BlockSize);
			}
			this.Left = (int)BitConverter.ToUInt16(array, 1);
			this.Top = (int)BitConverter.ToUInt16(array, 3);
			this.Width = (int)BitConverter.ToUInt16(array, 5);
			this.Height = (int)BitConverter.ToUInt16(array, 7);
			this.CellWidth = (int)array[9];
			this.CellHeight = (int)array[10];
			this.ForegroundColorIndex = (int)array[11];
			this.BackgroundColorIndex = (int)array[12];
			byte[] bytes = GifHelpers.ReadDataBlocks(stream, metadataOnly);
			this.Text = Encoding.ASCII.GetString(bytes);
			this.Extensions = controlExtensions.ToList<GifExtension>().AsReadOnly();
		}

		// Token: 0x04000CEB RID: 3307
		internal const int ExtensionLabel = 1;
	}
}
