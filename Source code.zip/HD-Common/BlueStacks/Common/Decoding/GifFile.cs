﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x02000208 RID: 520
	internal class GifFile
	{
		// Token: 0x17000433 RID: 1075
		// (get) Token: 0x0600102E RID: 4142 RVA: 0x0000DC88 File Offset: 0x0000BE88
		// (set) Token: 0x0600102F RID: 4143 RVA: 0x0000DC90 File Offset: 0x0000BE90
		public GifHeader Header { get; private set; }

		// Token: 0x17000434 RID: 1076
		// (get) Token: 0x06001030 RID: 4144 RVA: 0x0000DC99 File Offset: 0x0000BE99
		// (set) Token: 0x06001031 RID: 4145 RVA: 0x0000DCA1 File Offset: 0x0000BEA1
		public GifColor[] GlobalColorTable { get; set; }

		// Token: 0x17000435 RID: 1077
		// (get) Token: 0x06001032 RID: 4146 RVA: 0x0000DCAA File Offset: 0x0000BEAA
		// (set) Token: 0x06001033 RID: 4147 RVA: 0x0000DCB2 File Offset: 0x0000BEB2
		public IList<GifFrame> Frames { get; set; }

		// Token: 0x17000436 RID: 1078
		// (get) Token: 0x06001034 RID: 4148 RVA: 0x0000DCBB File Offset: 0x0000BEBB
		// (set) Token: 0x06001035 RID: 4149 RVA: 0x0000DCC3 File Offset: 0x0000BEC3
		public IList<GifExtension> Extensions { get; set; }

		// Token: 0x17000437 RID: 1079
		// (get) Token: 0x06001036 RID: 4150 RVA: 0x0000DCCC File Offset: 0x0000BECC
		// (set) Token: 0x06001037 RID: 4151 RVA: 0x0000DCD4 File Offset: 0x0000BED4
		public ushort RepeatCount { get; set; }

		// Token: 0x06001038 RID: 4152 RVA: 0x0000223B File Offset: 0x0000043B
		private GifFile()
		{
		}

		// Token: 0x06001039 RID: 4153 RVA: 0x0000DCDD File Offset: 0x0000BEDD
		internal static GifFile ReadGifFile(Stream stream, bool metadataOnly)
		{
			GifFile gifFile = new GifFile();
			gifFile.Read(stream, metadataOnly);
			return gifFile;
		}

		// Token: 0x0600103A RID: 4154 RVA: 0x0003DE88 File Offset: 0x0003C088
		private void Read(Stream stream, bool metadataOnly)
		{
			this.Header = GifHeader.ReadHeader(stream);
			if (this.Header.LogicalScreenDescriptor.HasGlobalColorTable)
			{
				this.GlobalColorTable = GifHelpers.ReadColorTable(stream, this.Header.LogicalScreenDescriptor.GlobalColorTableSize);
			}
			this.ReadFrames(stream, metadataOnly);
			GifApplicationExtension gifApplicationExtension = this.Extensions.OfType<GifApplicationExtension>().FirstOrDefault(new Func<GifApplicationExtension, bool>(GifHelpers.IsNetscapeExtension));
			if (gifApplicationExtension != null)
			{
				this.RepeatCount = GifHelpers.GetRepeatCount(gifApplicationExtension);
				return;
			}
			this.RepeatCount = 1;
		}

		// Token: 0x0600103B RID: 4155 RVA: 0x0003DF0C File Offset: 0x0003C10C
		private void ReadFrames(Stream stream, bool metadataOnly)
		{
			List<GifFrame> list = new List<GifFrame>();
			List<GifExtension> list2 = new List<GifExtension>();
			List<GifExtension> list3 = new List<GifExtension>();
			for (;;)
			{
				GifBlock gifBlock = GifBlock.ReadBlock(stream, list2, metadataOnly);
				if (gifBlock.Kind == GifBlockKind.GraphicRendering)
				{
					list2 = new List<GifExtension>();
				}
				if (gifBlock is GifFrame)
				{
					list.Add((GifFrame)gifBlock);
				}
				else
				{
					GifExtension gifExtension = gifBlock as GifExtension;
					if (gifExtension != null)
					{
						GifBlockKind kind = gifExtension.Kind;
						if (kind != GifBlockKind.Control)
						{
							if (kind == GifBlockKind.SpecialPurpose)
							{
								list3.Add(gifExtension);
							}
						}
						else
						{
							list2.Add(gifExtension);
						}
					}
					else if (gifBlock is GifTrailer)
					{
						break;
					}
				}
			}
			this.Frames = list.AsReadOnly();
			this.Extensions = list3.AsReadOnly();
		}
	}
}
