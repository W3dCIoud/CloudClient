﻿using System;
using System.IO;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x0200020D RID: 525
	internal class GifImageData
	{
		// Token: 0x17000448 RID: 1096
		// (get) Token: 0x0600106E RID: 4206 RVA: 0x0000DEE9 File Offset: 0x0000C0E9
		// (set) Token: 0x0600106F RID: 4207 RVA: 0x0000DEF1 File Offset: 0x0000C0F1
		public byte LzwMinimumCodeSize { get; set; }

		// Token: 0x17000449 RID: 1097
		// (get) Token: 0x06001070 RID: 4208 RVA: 0x0000DEFA File Offset: 0x0000C0FA
		// (set) Token: 0x06001071 RID: 4209 RVA: 0x0000DF02 File Offset: 0x0000C102
		public byte[] CompressedData { get; set; }

		// Token: 0x06001072 RID: 4210 RVA: 0x0000223B File Offset: 0x0000043B
		private GifImageData()
		{
		}

		// Token: 0x06001073 RID: 4211 RVA: 0x0000DF0B File Offset: 0x0000C10B
		internal static GifImageData ReadImageData(Stream stream, bool metadataOnly)
		{
			GifImageData gifImageData = new GifImageData();
			gifImageData.Read(stream, metadataOnly);
			return gifImageData;
		}

		// Token: 0x06001074 RID: 4212 RVA: 0x0000DF1A File Offset: 0x0000C11A
		private void Read(Stream stream, bool metadataOnly)
		{
			this.LzwMinimumCodeSize = (byte)stream.ReadByte();
			this.CompressedData = GifHelpers.ReadDataBlocks(stream, metadataOnly);
		}
	}
}
