﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x02000209 RID: 521
	internal class GifFrame : GifBlock
	{
		// Token: 0x17000438 RID: 1080
		// (get) Token: 0x0600103C RID: 4156 RVA: 0x0000DCEC File Offset: 0x0000BEEC
		// (set) Token: 0x0600103D RID: 4157 RVA: 0x0000DCF4 File Offset: 0x0000BEF4
		public GifImageDescriptor Descriptor { get; private set; }

		// Token: 0x17000439 RID: 1081
		// (get) Token: 0x0600103E RID: 4158 RVA: 0x0000DCFD File Offset: 0x0000BEFD
		// (set) Token: 0x0600103F RID: 4159 RVA: 0x0000DD05 File Offset: 0x0000BF05
		public GifColor[] LocalColorTable { get; private set; }

		// Token: 0x1700043A RID: 1082
		// (get) Token: 0x06001040 RID: 4160 RVA: 0x0000DD0E File Offset: 0x0000BF0E
		// (set) Token: 0x06001041 RID: 4161 RVA: 0x0000DD16 File Offset: 0x0000BF16
		public IList<GifExtension> Extensions { get; private set; }

		// Token: 0x1700043B RID: 1083
		// (get) Token: 0x06001042 RID: 4162 RVA: 0x0000DD1F File Offset: 0x0000BF1F
		// (set) Token: 0x06001043 RID: 4163 RVA: 0x0000DD27 File Offset: 0x0000BF27
		public GifImageData ImageData { get; private set; }

		// Token: 0x06001044 RID: 4164 RVA: 0x0000DC80 File Offset: 0x0000BE80
		private GifFrame()
		{
		}

		// Token: 0x1700043C RID: 1084
		// (get) Token: 0x06001045 RID: 4165 RVA: 0x0000323B File Offset: 0x0000143B
		internal override GifBlockKind Kind
		{
			get
			{
				return GifBlockKind.GraphicRendering;
			}
		}

		// Token: 0x06001046 RID: 4166 RVA: 0x0000DD30 File Offset: 0x0000BF30
		internal static GifFrame ReadFrame(Stream stream, IEnumerable<GifExtension> controlExtensions, bool metadataOnly)
		{
			GifFrame gifFrame = new GifFrame();
			gifFrame.Read(stream, controlExtensions, metadataOnly);
			return gifFrame;
		}

		// Token: 0x06001047 RID: 4167 RVA: 0x0003DFB0 File Offset: 0x0003C1B0
		private void Read(Stream stream, IEnumerable<GifExtension> controlExtensions, bool metadataOnly)
		{
			this.Descriptor = GifImageDescriptor.ReadImageDescriptor(stream);
			if (this.Descriptor.HasLocalColorTable)
			{
				this.LocalColorTable = GifHelpers.ReadColorTable(stream, this.Descriptor.LocalColorTableSize);
			}
			this.ImageData = GifImageData.ReadImageData(stream, metadataOnly);
			this.Extensions = controlExtensions.ToList<GifExtension>().AsReadOnly();
		}

		// Token: 0x04000CCA RID: 3274
		internal const int ImageSeparator = 44;
	}
}
