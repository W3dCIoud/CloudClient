﻿using System;
using System.IO;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x0200020A RID: 522
	internal class GifGraphicControlExtension : GifExtension
	{
		// Token: 0x1700043D RID: 1085
		// (get) Token: 0x06001048 RID: 4168 RVA: 0x0000DD40 File Offset: 0x0000BF40
		// (set) Token: 0x06001049 RID: 4169 RVA: 0x0000DD48 File Offset: 0x0000BF48
		public int BlockSize { get; private set; }

		// Token: 0x1700043E RID: 1086
		// (get) Token: 0x0600104A RID: 4170 RVA: 0x0000DD51 File Offset: 0x0000BF51
		// (set) Token: 0x0600104B RID: 4171 RVA: 0x0000DD59 File Offset: 0x0000BF59
		public int DisposalMethod { get; private set; }

		// Token: 0x1700043F RID: 1087
		// (get) Token: 0x0600104C RID: 4172 RVA: 0x0000DD62 File Offset: 0x0000BF62
		// (set) Token: 0x0600104D RID: 4173 RVA: 0x0000DD6A File Offset: 0x0000BF6A
		public bool UserInput { get; private set; }

		// Token: 0x17000440 RID: 1088
		// (get) Token: 0x0600104E RID: 4174 RVA: 0x0000DD73 File Offset: 0x0000BF73
		// (set) Token: 0x0600104F RID: 4175 RVA: 0x0000DD7B File Offset: 0x0000BF7B
		public bool HasTransparency { get; private set; }

		// Token: 0x17000441 RID: 1089
		// (get) Token: 0x06001050 RID: 4176 RVA: 0x0000DD84 File Offset: 0x0000BF84
		// (set) Token: 0x06001051 RID: 4177 RVA: 0x0000DD8C File Offset: 0x0000BF8C
		public int Delay { get; private set; }

		// Token: 0x17000442 RID: 1090
		// (get) Token: 0x06001052 RID: 4178 RVA: 0x0000DD95 File Offset: 0x0000BF95
		// (set) Token: 0x06001053 RID: 4179 RVA: 0x0000DD9D File Offset: 0x0000BF9D
		public int TransparencyIndex { get; private set; }

		// Token: 0x06001054 RID: 4180 RVA: 0x0000DC31 File Offset: 0x0000BE31
		private GifGraphicControlExtension()
		{
		}

		// Token: 0x17000443 RID: 1091
		// (get) Token: 0x06001055 RID: 4181 RVA: 0x00006447 File Offset: 0x00004647
		internal override GifBlockKind Kind
		{
			get
			{
				return GifBlockKind.Control;
			}
		}

		// Token: 0x06001056 RID: 4182 RVA: 0x0000DDA6 File Offset: 0x0000BFA6
		internal static GifGraphicControlExtension ReadGraphicsControl(Stream stream)
		{
			GifGraphicControlExtension gifGraphicControlExtension = new GifGraphicControlExtension();
			gifGraphicControlExtension.Read(stream);
			return gifGraphicControlExtension;
		}

		// Token: 0x06001057 RID: 4183 RVA: 0x0003E00C File Offset: 0x0003C20C
		private void Read(Stream stream)
		{
			byte[] array = new byte[6];
			stream.ReadAll(array, 0, array.Length);
			this.BlockSize = (int)array[0];
			if (this.BlockSize != 4)
			{
				throw GifHelpers.InvalidBlockSizeException("Graphic Control Extension", 4, this.BlockSize);
			}
			byte b = array[1];
			this.DisposalMethod = (b & 28) >> 2;
			this.UserInput = ((b & 2) > 0);
			this.HasTransparency = ((b & 1) > 0);
			this.Delay = (int)(BitConverter.ToUInt16(array, 2) * 10);
			this.TransparencyIndex = (int)array[4];
		}

		// Token: 0x04000CCF RID: 3279
		internal const int ExtensionLabel = 249;
	}
}
