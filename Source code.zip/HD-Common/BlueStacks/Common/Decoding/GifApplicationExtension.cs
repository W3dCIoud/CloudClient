﻿using System;
using System.IO;
using System.Text;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x02000201 RID: 513
	internal class GifApplicationExtension : GifExtension
	{
		// Token: 0x1700042B RID: 1067
		// (get) Token: 0x06001011 RID: 4113 RVA: 0x0000DBED File Offset: 0x0000BDED
		// (set) Token: 0x06001012 RID: 4114 RVA: 0x0000DBF5 File Offset: 0x0000BDF5
		public int BlockSize { get; private set; }

		// Token: 0x1700042C RID: 1068
		// (get) Token: 0x06001013 RID: 4115 RVA: 0x0000DBFE File Offset: 0x0000BDFE
		// (set) Token: 0x06001014 RID: 4116 RVA: 0x0000DC06 File Offset: 0x0000BE06
		public string ApplicationIdentifier { get; private set; }

		// Token: 0x1700042D RID: 1069
		// (get) Token: 0x06001015 RID: 4117 RVA: 0x0000DC0F File Offset: 0x0000BE0F
		// (set) Token: 0x06001016 RID: 4118 RVA: 0x0000DC17 File Offset: 0x0000BE17
		public byte[] AuthenticationCode { get; private set; }

		// Token: 0x1700042E RID: 1070
		// (get) Token: 0x06001017 RID: 4119 RVA: 0x0000DC20 File Offset: 0x0000BE20
		// (set) Token: 0x06001018 RID: 4120 RVA: 0x0000DC28 File Offset: 0x0000BE28
		public byte[] Data { get; private set; }

		// Token: 0x06001019 RID: 4121 RVA: 0x0000DC31 File Offset: 0x0000BE31
		private GifApplicationExtension()
		{
		}

		// Token: 0x1700042F RID: 1071
		// (get) Token: 0x0600101A RID: 4122 RVA: 0x0000DC39 File Offset: 0x0000BE39
		internal override GifBlockKind Kind
		{
			get
			{
				return GifBlockKind.SpecialPurpose;
			}
		}

		// Token: 0x0600101B RID: 4123 RVA: 0x0000DC3C File Offset: 0x0000BE3C
		internal static GifApplicationExtension ReadApplication(Stream stream)
		{
			GifApplicationExtension gifApplicationExtension = new GifApplicationExtension();
			gifApplicationExtension.Read(stream);
			return gifApplicationExtension;
		}

		// Token: 0x0600101C RID: 4124 RVA: 0x0003DCD4 File Offset: 0x0003BED4
		private void Read(Stream stream)
		{
			byte[] array = new byte[12];
			stream.ReadAll(array, 0, array.Length);
			this.BlockSize = (int)array[0];
			if (this.BlockSize != 11)
			{
				throw GifHelpers.InvalidBlockSizeException("Application Extension", 11, this.BlockSize);
			}
			this.ApplicationIdentifier = Encoding.ASCII.GetString(array, 1, 8);
			byte[] array2 = new byte[3];
			Array.Copy(array, 9, array2, 0, 3);
			this.AuthenticationCode = array2;
			this.Data = GifHelpers.ReadDataBlocks(stream, false);
		}

		// Token: 0x04000CB5 RID: 3253
		internal const int ExtensionLabel = 255;
	}
}
