﻿using System;
using System.Collections.Generic;
using System.IO;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x02000207 RID: 519
	internal abstract class GifExtension : GifBlock
	{
		// Token: 0x0600102C RID: 4140 RVA: 0x0003DE1C File Offset: 0x0003C01C
		internal static GifExtension ReadExtension(Stream stream, IEnumerable<GifExtension> controlExtensions, bool metadataOnly)
		{
			int num = stream.ReadByte();
			if (num < 0)
			{
				throw GifHelpers.UnexpectedEndOfStreamException();
			}
			if (num <= 249)
			{
				if (num == 1)
				{
					return GifPlainTextExtension.ReadPlainText(stream, controlExtensions, metadataOnly);
				}
				if (num == 249)
				{
					return GifGraphicControlExtension.ReadGraphicsControl(stream);
				}
			}
			else
			{
				if (num == 254)
				{
					return GifCommentExtension.ReadComment(stream);
				}
				if (num == 255)
				{
					return GifApplicationExtension.ReadApplication(stream);
				}
			}
			throw GifHelpers.UnknownExtensionTypeException(num);
		}

		// Token: 0x04000CC4 RID: 3268
		internal const int ExtensionIntroducer = 33;
	}
}
