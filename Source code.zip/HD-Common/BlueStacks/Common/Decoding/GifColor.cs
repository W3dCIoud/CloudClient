﻿using System;
using System.Globalization;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x02000204 RID: 516
	internal struct GifColor
	{
		// Token: 0x06001020 RID: 4128 RVA: 0x0000DC4A File Offset: 0x0000BE4A
		internal GifColor(byte r, byte g, byte b)
		{
			this.R = r;
			this.G = g;
			this.B = b;
		}

		// Token: 0x06001021 RID: 4129 RVA: 0x0003DDA4 File Offset: 0x0003BFA4
		public override string ToString()
		{
			return string.Format(CultureInfo.InvariantCulture, "#{0:x2}{1:x2}{2:x2}", new object[]
			{
				this.R,
				this.G,
				this.B
			});
		}

		// Token: 0x04000CBF RID: 3263
		private readonly byte R;

		// Token: 0x04000CC0 RID: 3264
		private readonly byte G;

		// Token: 0x04000CC1 RID: 3265
		private readonly byte B;
	}
}
