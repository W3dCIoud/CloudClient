﻿using System;
using System.IO;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x0200020F RID: 527
	internal class GifLogicalScreenDescriptor
	{
		// Token: 0x17000452 RID: 1106
		// (get) Token: 0x06001088 RID: 4232 RVA: 0x0000DFCC File Offset: 0x0000C1CC
		// (set) Token: 0x06001089 RID: 4233 RVA: 0x0000DFD4 File Offset: 0x0000C1D4
		public int Width { get; private set; }

		// Token: 0x17000453 RID: 1107
		// (get) Token: 0x0600108A RID: 4234 RVA: 0x0000DFDD File Offset: 0x0000C1DD
		// (set) Token: 0x0600108B RID: 4235 RVA: 0x0000DFE5 File Offset: 0x0000C1E5
		public int Height { get; private set; }

		// Token: 0x17000454 RID: 1108
		// (get) Token: 0x0600108C RID: 4236 RVA: 0x0000DFEE File Offset: 0x0000C1EE
		// (set) Token: 0x0600108D RID: 4237 RVA: 0x0000DFF6 File Offset: 0x0000C1F6
		public bool HasGlobalColorTable { get; private set; }

		// Token: 0x17000455 RID: 1109
		// (get) Token: 0x0600108E RID: 4238 RVA: 0x0000DFFF File Offset: 0x0000C1FF
		// (set) Token: 0x0600108F RID: 4239 RVA: 0x0000E007 File Offset: 0x0000C207
		public int ColorResolution { get; private set; }

		// Token: 0x17000456 RID: 1110
		// (get) Token: 0x06001090 RID: 4240 RVA: 0x0000E010 File Offset: 0x0000C210
		// (set) Token: 0x06001091 RID: 4241 RVA: 0x0000E018 File Offset: 0x0000C218
		public bool IsGlobalColorTableSorted { get; private set; }

		// Token: 0x17000457 RID: 1111
		// (get) Token: 0x06001092 RID: 4242 RVA: 0x0000E021 File Offset: 0x0000C221
		// (set) Token: 0x06001093 RID: 4243 RVA: 0x0000E029 File Offset: 0x0000C229
		public int GlobalColorTableSize { get; private set; }

		// Token: 0x17000458 RID: 1112
		// (get) Token: 0x06001094 RID: 4244 RVA: 0x0000E032 File Offset: 0x0000C232
		// (set) Token: 0x06001095 RID: 4245 RVA: 0x0000E03A File Offset: 0x0000C23A
		public int BackgroundColorIndex { get; private set; }

		// Token: 0x17000459 RID: 1113
		// (get) Token: 0x06001096 RID: 4246 RVA: 0x0000E043 File Offset: 0x0000C243
		// (set) Token: 0x06001097 RID: 4247 RVA: 0x0000E04B File Offset: 0x0000C24B
		public double PixelAspectRatio { get; private set; }

		// Token: 0x06001098 RID: 4248 RVA: 0x0000E054 File Offset: 0x0000C254
		internal static GifLogicalScreenDescriptor ReadLogicalScreenDescriptor(Stream stream)
		{
			GifLogicalScreenDescriptor gifLogicalScreenDescriptor = new GifLogicalScreenDescriptor();
			gifLogicalScreenDescriptor.Read(stream);
			return gifLogicalScreenDescriptor;
		}

		// Token: 0x06001099 RID: 4249 RVA: 0x0003E2CC File Offset: 0x0003C4CC
		private void Read(Stream stream)
		{
			byte[] array = new byte[7];
			stream.ReadAll(array, 0, array.Length);
			this.Width = (int)BitConverter.ToUInt16(array, 0);
			this.Height = (int)BitConverter.ToUInt16(array, 2);
			byte b = array[4];
			this.HasGlobalColorTable = ((b & 128) > 0);
			this.ColorResolution = ((b & 112) >> 4) + 1;
			this.IsGlobalColorTableSorted = ((b & 8) > 0);
			this.GlobalColorTableSize = 1 << (int)((b & 7) + 1);
			this.BackgroundColorIndex = (int)array[5];
			this.PixelAspectRatio = ((array[5] == 0) ? 0.0 : ((double)(15 + array[5]) / 64.0));
		}
	}
}
