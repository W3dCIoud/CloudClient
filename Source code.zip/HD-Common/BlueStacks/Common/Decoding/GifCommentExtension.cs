﻿using System;
using System.IO;
using System.Text;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x02000205 RID: 517
	internal class GifCommentExtension : GifExtension
	{
		// Token: 0x17000431 RID: 1073
		// (get) Token: 0x06001022 RID: 4130 RVA: 0x0000DC61 File Offset: 0x0000BE61
		// (set) Token: 0x06001023 RID: 4131 RVA: 0x0000DC69 File Offset: 0x0000BE69
		public string Text { get; private set; }

		// Token: 0x06001024 RID: 4132 RVA: 0x0000DC31 File Offset: 0x0000BE31
		private GifCommentExtension()
		{
		}

		// Token: 0x17000432 RID: 1074
		// (get) Token: 0x06001025 RID: 4133 RVA: 0x0000DC39 File Offset: 0x0000BE39
		internal override GifBlockKind Kind
		{
			get
			{
				return GifBlockKind.SpecialPurpose;
			}
		}

		// Token: 0x06001026 RID: 4134 RVA: 0x0000DC72 File Offset: 0x0000BE72
		internal static GifCommentExtension ReadComment(Stream stream)
		{
			GifCommentExtension gifCommentExtension = new GifCommentExtension();
			gifCommentExtension.Read(stream);
			return gifCommentExtension;
		}

		// Token: 0x06001027 RID: 4135 RVA: 0x0003DDF0 File Offset: 0x0003BFF0
		private void Read(Stream stream)
		{
			byte[] array = GifHelpers.ReadDataBlocks(stream, false);
			if (array != null)
			{
				this.Text = Encoding.ASCII.GetString(array);
			}
		}

		// Token: 0x04000CC2 RID: 3266
		internal const int ExtensionLabel = 254;
	}
}
