﻿using System;
using System.Collections.Generic;
using System.IO;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x02000202 RID: 514
	internal abstract class GifBlock
	{
		// Token: 0x0600101D RID: 4125 RVA: 0x0003DD54 File Offset: 0x0003BF54
		internal static GifBlock ReadBlock(Stream stream, IEnumerable<GifExtension> controlExtensions, bool metadataOnly)
		{
			int num = stream.ReadByte();
			if (num < 0)
			{
				throw GifHelpers.UnexpectedEndOfStreamException();
			}
			if (num == 33)
			{
				return GifExtension.ReadExtension(stream, controlExtensions, metadataOnly);
			}
			if (num == 44)
			{
				return GifFrame.ReadFrame(stream, controlExtensions, metadataOnly);
			}
			if (num != 59)
			{
				throw GifHelpers.UnknownBlockTypeException(num);
			}
			return GifTrailer.ReadTrailer();
		}

		// Token: 0x17000430 RID: 1072
		// (get) Token: 0x0600101E RID: 4126
		internal abstract GifBlockKind Kind { get; }
	}
}
