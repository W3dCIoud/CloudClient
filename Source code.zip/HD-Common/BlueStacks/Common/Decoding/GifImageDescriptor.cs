﻿using System;
using System.IO;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x0200020E RID: 526
	internal class GifImageDescriptor
	{
		// Token: 0x1700044A RID: 1098
		// (get) Token: 0x06001075 RID: 4213 RVA: 0x0000DF36 File Offset: 0x0000C136
		// (set) Token: 0x06001076 RID: 4214 RVA: 0x0000DF3E File Offset: 0x0000C13E
		public int Left { get; private set; }

		// Token: 0x1700044B RID: 1099
		// (get) Token: 0x06001077 RID: 4215 RVA: 0x0000DF47 File Offset: 0x0000C147
		// (set) Token: 0x06001078 RID: 4216 RVA: 0x0000DF4F File Offset: 0x0000C14F
		public int Top { get; private set; }

		// Token: 0x1700044C RID: 1100
		// (get) Token: 0x06001079 RID: 4217 RVA: 0x0000DF58 File Offset: 0x0000C158
		// (set) Token: 0x0600107A RID: 4218 RVA: 0x0000DF60 File Offset: 0x0000C160
		public int Width { get; private set; }

		// Token: 0x1700044D RID: 1101
		// (get) Token: 0x0600107B RID: 4219 RVA: 0x0000DF69 File Offset: 0x0000C169
		// (set) Token: 0x0600107C RID: 4220 RVA: 0x0000DF71 File Offset: 0x0000C171
		public int Height { get; private set; }

		// Token: 0x1700044E RID: 1102
		// (get) Token: 0x0600107D RID: 4221 RVA: 0x0000DF7A File Offset: 0x0000C17A
		// (set) Token: 0x0600107E RID: 4222 RVA: 0x0000DF82 File Offset: 0x0000C182
		public bool HasLocalColorTable { get; private set; }

		// Token: 0x1700044F RID: 1103
		// (get) Token: 0x0600107F RID: 4223 RVA: 0x0000DF8B File Offset: 0x0000C18B
		// (set) Token: 0x06001080 RID: 4224 RVA: 0x0000DF93 File Offset: 0x0000C193
		public bool Interlace { get; private set; }

		// Token: 0x17000450 RID: 1104
		// (get) Token: 0x06001081 RID: 4225 RVA: 0x0000DF9C File Offset: 0x0000C19C
		// (set) Token: 0x06001082 RID: 4226 RVA: 0x0000DFA4 File Offset: 0x0000C1A4
		public bool IsLocalColorTableSorted { get; private set; }

		// Token: 0x17000451 RID: 1105
		// (get) Token: 0x06001083 RID: 4227 RVA: 0x0000DFAD File Offset: 0x0000C1AD
		// (set) Token: 0x06001084 RID: 4228 RVA: 0x0000DFB5 File Offset: 0x0000C1B5
		public int LocalColorTableSize { get; private set; }

		// Token: 0x06001085 RID: 4229 RVA: 0x0000223B File Offset: 0x0000043B
		private GifImageDescriptor()
		{
		}

		// Token: 0x06001086 RID: 4230 RVA: 0x0000DFBE File Offset: 0x0000C1BE
		internal static GifImageDescriptor ReadImageDescriptor(Stream stream)
		{
			GifImageDescriptor gifImageDescriptor = new GifImageDescriptor();
			gifImageDescriptor.Read(stream);
			return gifImageDescriptor;
		}

		// Token: 0x06001087 RID: 4231 RVA: 0x0003E238 File Offset: 0x0003C438
		private void Read(Stream stream)
		{
			byte[] array = new byte[9];
			stream.ReadAll(array, 0, array.Length);
			this.Left = (int)BitConverter.ToUInt16(array, 0);
			this.Top = (int)BitConverter.ToUInt16(array, 2);
			this.Width = (int)BitConverter.ToUInt16(array, 4);
			this.Height = (int)BitConverter.ToUInt16(array, 6);
			byte b = array[8];
			this.HasLocalColorTable = ((b & 128) > 0);
			this.Interlace = ((b & 64) > 0);
			this.IsLocalColorTableSorted = ((b & 32) > 0);
			this.LocalColorTableSize = 1 << (int)((b & 7) + 1);
		}
	}
}
