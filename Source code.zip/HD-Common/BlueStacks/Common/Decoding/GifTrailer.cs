﻿using System;

namespace BlueStacks.Common.Decoding
{
	// Token: 0x02000211 RID: 529
	internal class GifTrailer : GifBlock
	{
		// Token: 0x060010B5 RID: 4277 RVA: 0x0000DC80 File Offset: 0x0000BE80
		private GifTrailer()
		{
		}

		// Token: 0x17000466 RID: 1126
		// (get) Token: 0x060010B6 RID: 4278 RVA: 0x0000DDE7 File Offset: 0x0000BFE7
		internal override GifBlockKind Kind
		{
			get
			{
				return GifBlockKind.Other;
			}
		}

		// Token: 0x060010B7 RID: 4279 RVA: 0x0000E12D File Offset: 0x0000C32D
		internal static GifTrailer ReadTrailer()
		{
			return new GifTrailer();
		}

		// Token: 0x04000CF7 RID: 3319
		internal const int TrailerByte = 59;
	}
}
