﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x020000E1 RID: 225
	public class CustomButton : Button, IComponentConnector, IStyleConnector
	{
		// Token: 0x060005F6 RID: 1526 RVA: 0x000057C8 File Offset: 0x000039C8
		public CustomButton()
		{
			this.InitializeComponent();
		}

		// Token: 0x060005F7 RID: 1527 RVA: 0x000057D6 File Offset: 0x000039D6
		public CustomButton(ButtonColors color) : this()
		{
			this.ButtonColor = color;
		}

		// Token: 0x17000182 RID: 386
		// (get) Token: 0x060005F8 RID: 1528 RVA: 0x000057E5 File Offset: 0x000039E5
		// (set) Token: 0x060005F9 RID: 1529 RVA: 0x000057F7 File Offset: 0x000039F7
		public ButtonColors ButtonColor
		{
			get
			{
				return (ButtonColors)base.GetValue(CustomButton.ButtonColorProperty);
			}
			set
			{
				base.SetValue(CustomButton.ButtonColorProperty, value);
			}
		}

		// Token: 0x17000183 RID: 387
		// (get) Token: 0x060005FA RID: 1530 RVA: 0x0000580A File Offset: 0x00003A0A
		// (set) Token: 0x060005FB RID: 1531 RVA: 0x0000581C File Offset: 0x00003A1C
		public bool IsMouseDown
		{
			get
			{
				return (bool)base.GetValue(CustomButton.IsMouseDownProperty);
			}
			set
			{
				base.SetValue(CustomButton.IsMouseDownProperty, value);
			}
		}

		// Token: 0x060005FC RID: 1532 RVA: 0x0000582F File Offset: 0x00003A2F
		private void Button_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			this.IsMouseDown = true;
		}

		// Token: 0x060005FD RID: 1533 RVA: 0x00005838 File Offset: 0x00003A38
		private void Button_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
			this.IsMouseDown = false;
		}

		// Token: 0x17000184 RID: 388
		// (get) Token: 0x060005FE RID: 1534 RVA: 0x00005841 File Offset: 0x00003A41
		// (set) Token: 0x060005FF RID: 1535 RVA: 0x00005853 File Offset: 0x00003A53
		public ButtonImageOrder ImageOrder
		{
			get
			{
				return (ButtonImageOrder)base.GetValue(CustomButton.ImageOrderProperty);
			}
			set
			{
				base.SetValue(CustomButton.ImageOrderProperty, value);
			}
		}

		// Token: 0x17000185 RID: 389
		// (get) Token: 0x06000600 RID: 1536 RVA: 0x00005866 File Offset: 0x00003A66
		// (set) Token: 0x06000601 RID: 1537 RVA: 0x00005878 File Offset: 0x00003A78
		public string ImageName
		{
			get
			{
				return (string)base.GetValue(CustomButton.ImageNameProperty);
			}
			set
			{
				base.SetValue(CustomButton.ImageNameProperty, value);
			}
		}

		// Token: 0x17000186 RID: 390
		// (get) Token: 0x06000602 RID: 1538 RVA: 0x00005886 File Offset: 0x00003A86
		// (set) Token: 0x06000603 RID: 1539 RVA: 0x00005898 File Offset: 0x00003A98
		public Thickness ImageMargin
		{
			get
			{
				return (Thickness)base.GetValue(CustomButton.ImageMarginProperty);
			}
			set
			{
				base.SetValue(CustomButton.ImageMarginProperty, value);
			}
		}

		// Token: 0x17000187 RID: 391
		// (get) Token: 0x06000604 RID: 1540 RVA: 0x000058AB File Offset: 0x00003AAB
		// (set) Token: 0x06000605 RID: 1541 RVA: 0x000058BD File Offset: 0x00003ABD
		public bool IsForceTooltipRequired
		{
			get
			{
				return (bool)base.GetValue(CustomButton.IsForceTooltipRequiredProperty);
			}
			set
			{
				base.SetValue(CustomButton.IsForceTooltipRequiredProperty, value);
			}
		}

		// Token: 0x06000606 RID: 1542 RVA: 0x000058D0 File Offset: 0x00003AD0
		private void ButtonTextBlock_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			this.ToolTipIfTextTrimmed();
		}

		// Token: 0x06000607 RID: 1543 RVA: 0x000058D0 File Offset: 0x00003AD0
		private void ButtonTextBlock_Loaded(object sender, RoutedEventArgs e)
		{
			this.ToolTipIfTextTrimmed();
		}

		// Token: 0x06000608 RID: 1544 RVA: 0x00020918 File Offset: 0x0001EB18
		private void ToolTipIfTextTrimmed()
		{
			if (!this.IsForceTooltipRequired)
			{
				ContentPresenter contentPresenter = WpfUtils.FindVisualChild<ContentPresenter>(this);
				if (contentPresenter != null)
				{
					TextBlock textBlock = contentPresenter.ContentTemplate.FindName("buttonTextBlock", contentPresenter) as TextBlock;
					if (textBlock != null && textBlock.IsTextTrimmed())
					{
						ToolTipService.SetIsEnabled(this, true);
						return;
					}
					ToolTipService.SetIsEnabled(this, false);
				}
			}
		}

		// Token: 0x06000609 RID: 1545 RVA: 0x00020968 File Offset: 0x0001EB68
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/custombutton.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600060A RID: 1546 RVA: 0x00020998 File Offset: 0x0001EB98
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mButton = (CustomButton)target;
				this.mButton.PreviewMouseDown += this.Button_PreviewMouseDown;
				this.mButton.PreviewMouseUp += this.Button_PreviewMouseUp;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x0600060B RID: 1547 RVA: 0x000058D8 File Offset: 0x00003AD8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 2)
			{
				((TextBlock)target).Loaded += this.ButtonTextBlock_Loaded;
				((TextBlock)target).SizeChanged += this.ButtonTextBlock_SizeChanged;
			}
		}

		// Token: 0x0400033E RID: 830
		public static readonly DependencyProperty ButtonColorProperty = DependencyProperty.Register("ButtonColor", typeof(ButtonColors), typeof(CustomButton), new PropertyMetadata(ButtonColors.Blue));

		// Token: 0x0400033F RID: 831
		public static readonly DependencyProperty IsMouseDownProperty = DependencyProperty.Register("IsMouseDown", typeof(bool), typeof(CustomButton), new PropertyMetadata(false));

		// Token: 0x04000340 RID: 832
		public static readonly DependencyProperty ImageOrderProperty = DependencyProperty.Register("ImageOrder", typeof(ButtonImageOrder), typeof(CustomButton), new PropertyMetadata(ButtonImageOrder.BeforeText));

		// Token: 0x04000341 RID: 833
		public static readonly DependencyProperty ImageNameProperty = DependencyProperty.Register("ImageName", typeof(string), typeof(CustomButton), new PropertyMetadata(""));

		// Token: 0x04000342 RID: 834
		public static readonly DependencyProperty ImageMarginProperty = DependencyProperty.Register("ImageMargin", typeof(Thickness), typeof(CustomButton), new PropertyMetadata(new Thickness(0.0, 0.0, 5.0, 0.0)));

		// Token: 0x04000343 RID: 835
		public static readonly DependencyProperty IsForceTooltipRequiredProperty = DependencyProperty.Register("IsForceTooltipRequired", typeof(bool), typeof(CustomButton), new PropertyMetadata(false));

		// Token: 0x04000344 RID: 836
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mButton;

		// Token: 0x04000345 RID: 837
		private bool _contentLoaded;
	}
}
