﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000109 RID: 265
	public enum ButtonColors
	{
		// Token: 0x0400048C RID: 1164
		Red,
		// Token: 0x0400048D RID: 1165
		DarkRed,
		// Token: 0x0400048E RID: 1166
		White,
		// Token: 0x0400048F RID: 1167
		WhiteWithGreyFG,
		// Token: 0x04000490 RID: 1168
		Blue,
		// Token: 0x04000491 RID: 1169
		Orange,
		// Token: 0x04000492 RID: 1170
		Background,
		// Token: 0x04000493 RID: 1171
		BackgroundBlueBorder,
		// Token: 0x04000494 RID: 1172
		BackgroundOrangeBorder,
		// Token: 0x04000495 RID: 1173
		BackgroundWhiteBorder,
		// Token: 0x04000496 RID: 1174
		Green,
		// Token: 0x04000497 RID: 1175
		Border,
		// Token: 0x04000498 RID: 1176
		Transparent,
		// Token: 0x04000499 RID: 1177
		Overlay
	}
}
