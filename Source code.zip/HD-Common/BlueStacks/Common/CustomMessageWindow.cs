﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BlueStacks.Common
{
	// Token: 0x020000E8 RID: 232
	public class CustomMessageWindow : CustomWindow, IComponentConnector
	{
		// Token: 0x1700019A RID: 410
		// (get) Token: 0x06000642 RID: 1602 RVA: 0x00005BD7 File Offset: 0x00003DD7
		// (set) Token: 0x06000643 RID: 1603 RVA: 0x00005BDF File Offset: 0x00003DDF
		public EventHandler MinimizeEventHandler { get; set; }

		// Token: 0x1700019B RID: 411
		// (get) Token: 0x06000644 RID: 1604 RVA: 0x00005BE8 File Offset: 0x00003DE8
		// (set) Token: 0x06000645 RID: 1605 RVA: 0x00005BF0 File Offset: 0x00003DF0
		public ButtonColors ClickedButton { get; set; } = ButtonColors.Background;

		// Token: 0x1700019C RID: 412
		// (get) Token: 0x06000646 RID: 1606 RVA: 0x00005BF9 File Offset: 0x00003DF9
		// (set) Token: 0x06000647 RID: 1607 RVA: 0x00005C01 File Offset: 0x00003E01
		public double ContentMaxWidth
		{
			get
			{
				return this.mContentMaxWidth;
			}
			set
			{
				this.mContentMaxWidth = value;
				this.mTitleGrid.MaxWidth = value;
				this.mBodyTextStackPanel.MaxWidth = value;
				this.mProgressGrid.MaxWidth = value;
			}
		}

		// Token: 0x1700019D RID: 413
		// (set) Token: 0x06000648 RID: 1608 RVA: 0x00005C2E File Offset: 0x00003E2E
		public bool ProgressBarEnabled
		{
			set
			{
				this.mProgressGrid.Visibility = (value ? Visibility.Visible : Visibility.Collapsed);
			}
		}

		// Token: 0x1700019E RID: 414
		// (set) Token: 0x06000649 RID: 1609 RVA: 0x00005C42 File Offset: 0x00003E42
		public bool ProgressStatusEnabled
		{
			set
			{
				this.mProgressUpdatesGrid.Visibility = (value ? Visibility.Visible : Visibility.Collapsed);
			}
		}

		// Token: 0x1700019F RID: 415
		// (set) Token: 0x0600064A RID: 1610 RVA: 0x00005C56 File Offset: 0x00003E56
		public bool IsWindowMinizable
		{
			set
			{
				if (value)
				{
					this.mCustomMessageBoxMinimizeButton.Visibility = Visibility.Visible;
					return;
				}
				this.mCustomMessageBoxMinimizeButton.Visibility = Visibility.Hidden;
			}
		}

		// Token: 0x170001A0 RID: 416
		// (set) Token: 0x0600064B RID: 1611 RVA: 0x00005C74 File Offset: 0x00003E74
		public bool IsWindowClosable
		{
			set
			{
				if (value)
				{
					this.mCustomMessageBoxCloseButton.Visibility = Visibility.Visible;
					return;
				}
				this.mCustomMessageBoxCloseButton.Visibility = Visibility.Hidden;
			}
		}

		// Token: 0x170001A1 RID: 417
		// (set) Token: 0x0600064C RID: 1612 RVA: 0x00005C92 File Offset: 0x00003E92
		public bool IsWindowCloseButtonDisabled
		{
			set
			{
				if (value)
				{
					this.mCustomMessageBoxCloseButton.ToolTip = null;
					this.mCustomMessageBoxCloseButton.IsDisabled = true;
					this.mCustomMessageBoxCloseButton.PreviewMouseLeftButtonUp -= this.Close_PreviewMouseLeftButtonUp;
				}
			}
		}

		// Token: 0x170001A2 RID: 418
		// (set) Token: 0x0600064D RID: 1613 RVA: 0x00005CC6 File Offset: 0x00003EC6
		public string ImageName
		{
			set
			{
				this.mTitleIcon.ImageName = value;
				if (!string.IsNullOrEmpty(value))
				{
					this.mTitleIcon.Visibility = Visibility.Visible;
				}
			}
		}

		// Token: 0x170001A3 RID: 419
		// (set) Token: 0x0600064E RID: 1614 RVA: 0x00005CE8 File Offset: 0x00003EE8
		public bool IsWithoutButtons
		{
			set
			{
				if (value)
				{
					this.mStackPanel.Visibility = Visibility.Collapsed;
					return;
				}
				this.mStackPanel.Visibility = Visibility.Visible;
			}
		}

		// Token: 0x170001A4 RID: 420
		// (get) Token: 0x0600064F RID: 1615 RVA: 0x00005D06 File Offset: 0x00003F06
		public TextBlock TitleTextBlock
		{
			get
			{
				return this.mTitleText;
			}
		}

		// Token: 0x170001A5 RID: 421
		// (get) Token: 0x06000650 RID: 1616 RVA: 0x00005D0E File Offset: 0x00003F0E
		public CustomPictureBox MessageIcon
		{
			get
			{
				return this.mMessageIcon;
			}
		}

		// Token: 0x170001A6 RID: 422
		// (get) Token: 0x06000651 RID: 1617 RVA: 0x00005D16 File Offset: 0x00003F16
		public TextBlock BodyTextBlockTitle
		{
			get
			{
				return this.mBodyTextBlockTitle;
			}
		}

		// Token: 0x170001A7 RID: 423
		// (get) Token: 0x06000652 RID: 1618 RVA: 0x00005D1E File Offset: 0x00003F1E
		public TextBlock BodyTextBlock
		{
			get
			{
				return this.mBodyTextBlock;
			}
		}

		// Token: 0x170001A8 RID: 424
		// (get) Token: 0x06000653 RID: 1619 RVA: 0x00005D26 File Offset: 0x00003F26
		public TextBlock BodyWarningTextBlock
		{
			get
			{
				return this.mBodyWarningTextBlock;
			}
		}

		// Token: 0x170001A9 RID: 425
		// (get) Token: 0x06000654 RID: 1620 RVA: 0x00005D2E File Offset: 0x00003F2E
		public TextBlock AboveBodyWarningTextBlock
		{
			get
			{
				return this.mAboveBodyWarningTextBlock;
			}
		}

		// Token: 0x170001AA RID: 426
		// (get) Token: 0x06000655 RID: 1621 RVA: 0x00005D36 File Offset: 0x00003F36
		public CustomPictureBox CloseButton
		{
			get
			{
				return this.mCustomMessageBoxCloseButton;
			}
		}

		// Token: 0x170001AB RID: 427
		// (get) Token: 0x06000656 RID: 1622 RVA: 0x00005D3E File Offset: 0x00003F3E
		public TextBlock UrlTextBlock
		{
			get
			{
				return this.mUrlTextBlock;
			}
		}

		// Token: 0x170001AC RID: 428
		// (get) Token: 0x06000657 RID: 1623 RVA: 0x00005D46 File Offset: 0x00003F46
		public Hyperlink UrlLink
		{
			get
			{
				return this.mUrlLink;
			}
		}

		// Token: 0x170001AD RID: 429
		// (get) Token: 0x06000658 RID: 1624 RVA: 0x00005D4E File Offset: 0x00003F4E
		public CustomCheckbox CheckBox
		{
			get
			{
				return this.mCheckBox;
			}
		}

		// Token: 0x170001AE RID: 430
		// (get) Token: 0x06000659 RID: 1625 RVA: 0x00005D56 File Offset: 0x00003F56
		public BlueProgressBar CustomProgressBar
		{
			get
			{
				return this.mProgressbar;
			}
		}

		// Token: 0x170001AF RID: 431
		// (get) Token: 0x0600065A RID: 1626 RVA: 0x00005D5E File Offset: 0x00003F5E
		public TextBlock ProgressStatusTextBlock
		{
			get
			{
				return this.mProgressStatus;
			}
		}

		// Token: 0x170001B0 RID: 432
		// (get) Token: 0x0600065B RID: 1627 RVA: 0x00005D66 File Offset: 0x00003F66
		public Label ProgressPercentageTextBlock
		{
			get
			{
				return this.mProgressPercentage;
			}
		}

		// Token: 0x170001B1 RID: 433
		// (get) Token: 0x0600065C RID: 1628 RVA: 0x00005D6E File Offset: 0x00003F6E
		// (set) Token: 0x0600065D RID: 1629 RVA: 0x00005D76 File Offset: 0x00003F76
		public bool IsDraggable { get; set; }

		// Token: 0x0600065E RID: 1630 RVA: 0x00005D7F File Offset: 0x00003F7F
		protected override void OnClosed(EventArgs e)
		{
			base.OnClosed(e);
		}

		// Token: 0x0600065F RID: 1631 RVA: 0x000211DC File Offset: 0x0001F3DC
		public CustomMessageWindow()
		{
			this.InitializeComponent();
			base.Loaded += this.CustomMessageWindow_Loaded;
			base.SizeChanged += this.CustomMessageWindow_SizeChanged;
			this.mStackPanel.Children.Clear();
			this.ContentMaxWidth = 340.0;
		}

		// Token: 0x06000660 RID: 1632 RVA: 0x0002124C File Offset: 0x0001F44C
		private void CustomMessageWindow_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (this.mStackPanel.ActualWidth > this.ContentMaxWidth)
			{
				if (this.mButton2 != null)
				{
					this.mStackPanel.Orientation = Orientation.Vertical;
					this.mStackPanel.Height = 90.0;
					this.mButton1.Width = this.ContentMaxWidth;
					this.mButton1.Height = 35.0;
					this.mButton2.Width = this.ContentMaxWidth;
					this.mButton2.Height = 35.0;
					this.mButton2.Margin = new Thickness(0.0, 15.0, 0.0, 0.0);
					return;
				}
				this.mButton1.MaxWidth = this.ContentMaxWidth;
			}
		}

		// Token: 0x06000661 RID: 1633 RVA: 0x00005D88 File Offset: 0x00003F88
		public void CustomMessageWindow_Loaded(object sender, RoutedEventArgs e)
		{
			if (base.Owner == null || InteropWindow.FindMainWindowState(this) == WindowState.Minimized)
			{
				base.WindowStartupLocation = WindowStartupLocation.CenterScreen;
			}
			if (this.mButton2 != null)
			{
				base.UpdateLayout();
			}
		}

		// Token: 0x06000662 RID: 1634 RVA: 0x00005DB0 File Offset: 0x00003FB0
		public void CloseButtonHandle(Predicate<object> handle, object data = null)
		{
			this.mCloseButtonEventHandler = handle;
			this.mCloseButtonEventData = data;
		}

		// Token: 0x06000663 RID: 1635 RVA: 0x0002132C File Offset: 0x0001F52C
		public void CloseButtonHandle(EventHandler handle, object data = null)
		{
			this.mCloseButtonEventHandler = delegate(object o)
			{
				if (handle != null)
				{
					handle(o, new EventArgs());
				}
				return false;
			};
			this.mCloseButtonEventData = data;
		}

		// Token: 0x06000664 RID: 1636 RVA: 0x00021360 File Offset: 0x0001F560
		private void HandleMouseDrag(object sender, MouseButtonEventArgs e)
		{
			if (this.IsDraggable && e.OriginalSource.GetType() != typeof(CustomPictureBox))
			{
				try
				{
					base.DragMove();
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000665 RID: 1637 RVA: 0x00005DC0 File Offset: 0x00003FC0
		public void AddWarning(string title, string imageName = "")
		{
			this.mBodyWarningTextBlock.Text = title;
			if (!string.IsNullOrEmpty(imageName))
			{
				this.mMessageIcon.Visibility = Visibility.Visible;
				this.mMessageIcon.ImageName = imageName;
			}
		}

		// Token: 0x06000666 RID: 1638 RVA: 0x00005DEE File Offset: 0x00003FEE
		public void AddAboveBodyWarning(string title)
		{
			this.mAboveBodyWarningTextBlock.Text = title;
		}

		// Token: 0x06000667 RID: 1639 RVA: 0x00005DFC File Offset: 0x00003FFC
		public void AddButton(ButtonColors color, string text, EventHandler handle, string image = null, bool ChangeImageAlignment = false, object data = null)
		{
			this.AddButtonInUI(new CustomButton(color), color, text, handle, image, ChangeImageAlignment, data);
		}

		// Token: 0x06000668 RID: 1640 RVA: 0x000213A8 File Offset: 0x0001F5A8
		public void AddButtonInUI(CustomButton button, ButtonColors color, string text, EventHandler handle, string image, bool ChangeImageAlignment, object data)
		{
			if (button != null)
			{
				if (this.mButton1 == null)
				{
					this.mButton1 = button;
				}
				else
				{
					this.mButton2 = button;
					button.Margin = new Thickness(15.0, 0.0, 0.0, 0.0);
				}
				button.Click += this.Button_Click;
				button.MinWidth = 100.0;
				button.Visibility = Visibility.Visible;
				BlueStacksUIBinding.Bind(button, text);
				if (image != null)
				{
					button.ImageName = image;
					button.ImageMargin = new Thickness(0.0, 6.0, 5.0, 6.0);
					if (ChangeImageAlignment)
					{
						button.ImageOrder = ButtonImageOrder.AfterText;
						button.ImageMargin = new Thickness(5.0, 6.0, 0.0, 6.0);
					}
				}
			}
			this.mStackPanel.Children.Add(button);
			this.mDictActions.Add(button, new Tuple<ButtonColors, EventHandler, object>(color, handle, data));
		}

		// Token: 0x06000669 RID: 1641 RVA: 0x000214D0 File Offset: 0x0001F6D0
		public void AddHyperLinkInUI(string text, Uri navigateUri, RequestNavigateEventHandler handle)
		{
			Hyperlink hyperlink = new Hyperlink(new Run(text))
			{
				NavigateUri = navigateUri
			};
			hyperlink.RequestNavigate += handle.Invoke;
			hyperlink.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#047CD2"));
			this.mUrlTextBlock.Inlines.Clear();
			this.mUrlTextBlock.Inlines.Add(hyperlink);
			this.mUrlTextBlock.Visibility = Visibility.Visible;
		}

		// Token: 0x0600066A RID: 1642 RVA: 0x0002154C File Offset: 0x0001F74C
		public void Button_Click(object sender, RoutedEventArgs e)
		{
			this.ClickedButton = this.mDictActions[sender].Item1;
			if (this.mDictActions[sender].Item2 != null)
			{
				this.mDictActions[sender].Item2(this.mDictActions[sender].Item3, new EventArgs());
			}
			this.CloseWindow();
		}

		// Token: 0x0600066B RID: 1643 RVA: 0x00005E13 File Offset: 0x00004013
		private void Close_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (this.mCloseButtonEventHandler != null && this.mCloseButtonEventHandler(this.mCloseButtonEventData))
			{
				return;
			}
			this.CloseWindow();
		}

		// Token: 0x0600066C RID: 1644 RVA: 0x00005E37 File Offset: 0x00004037
		public void CloseWindow()
		{
			base.Close();
		}

		// Token: 0x0600066D RID: 1645 RVA: 0x00005E3F File Offset: 0x0000403F
		private void Minimize_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			EventHandler minimizeEventHandler = this.MinimizeEventHandler;
			if (minimizeEventHandler != null)
			{
				minimizeEventHandler(this, null);
			}
			base.WindowState = WindowState.Minimized;
		}

		// Token: 0x0600066E RID: 1646 RVA: 0x000215B8 File Offset: 0x0001F7B8
		public void AddBulletInBody(string text)
		{
			Ellipse ellipse = new Ellipse
			{
				Width = 9.0,
				Height = 9.0,
				VerticalAlignment = VerticalAlignment.Center
			};
			BlueStacksUIBinding.BindColor(ellipse, Shape.FillProperty, "ContextMenuItemForegroundDimColor");
			TextBlock textBlock = new TextBlock
			{
				FontSize = 18.0,
				MaxWidth = 300.0,
				FontWeight = FontWeights.Regular
			};
			BlueStacksUIBinding.BindColor(textBlock, Control.ForegroundProperty, "ContextMenuItemForegroundDimColor");
			textBlock.TextWrapping = TextWrapping.Wrap;
			textBlock.Text = text;
			textBlock.HorizontalAlignment = HorizontalAlignment.Left;
			textBlock.VerticalAlignment = VerticalAlignment.Center;
			textBlock.Margin = new Thickness(0.0, 0.0, 0.0, 10.0);
			BulletDecorator element = new BulletDecorator
			{
				Bullet = ellipse,
				Child = textBlock
			};
			this.mBodyTextStackPanel.Children.Add(element);
		}

		// Token: 0x0600066F RID: 1647 RVA: 0x00005E5B File Offset: 0x0000405B
		private void mMessageIcon_IsVisibleChanged(object _1, DependencyPropertyChangedEventArgs _2)
		{
			if (this.mMessageIcon.Visibility == Visibility.Visible)
			{
				this.mTitleGrid.MaxWidth = this.ContentMaxWidth + 85.0;
				return;
			}
			this.mTitleGrid.MaxWidth = this.ContentMaxWidth;
		}

		// Token: 0x06000670 RID: 1648 RVA: 0x000216B0 File Offset: 0x0001F8B0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/custommessagewindow.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000671 RID: 1649 RVA: 0x000035E3 File Offset: 0x000017E3
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000672 RID: 1650 RVA: 0x000216E0 File Offset: 0x0001F8E0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mMaskBorder = (Border)target;
				return;
			case 2:
				this.mParentGrid = (Grid)target;
				this.mParentGrid.MouseDown += this.HandleMouseDrag;
				return;
			case 3:
				this.mTitleGrid = (Grid)target;
				return;
			case 4:
				this.mTitleIcon = (CustomPictureBox)target;
				return;
			case 5:
				this.mTitleText = (TextBlock)target;
				return;
			case 6:
				this.mCustomMessageBoxMinimizeButton = (CustomPictureBox)target;
				return;
			case 7:
				this.mCustomMessageBoxCloseButton = (CustomPictureBox)target;
				return;
			case 8:
				this.mMessageIcon = (CustomPictureBox)target;
				return;
			case 9:
				this.mTextBlockGrid = (Grid)target;
				return;
			case 10:
				this.mBodyTextStackPanel = (StackPanel)target;
				return;
			case 11:
				this.mBodyTextBlockTitle = (TextBlock)target;
				return;
			case 12:
				this.mAboveBodyWarningTextBlock = (TextBlock)target;
				return;
			case 13:
				this.mBodyTextBlock = (TextBlock)target;
				return;
			case 14:
				this.mBodyWarningTextBlock = (TextBlock)target;
				return;
			case 15:
				this.mUrlTextBlock = (TextBlock)target;
				return;
			case 16:
				this.mUrlLink = (Hyperlink)target;
				return;
			case 17:
				this.mCheckBox = (CustomCheckbox)target;
				return;
			case 18:
				this.mProgressGrid = (Grid)target;
				return;
			case 19:
				this.mProgressbar = (BlueProgressBar)target;
				return;
			case 20:
				this.mProgressUpdatesGrid = (Grid)target;
				return;
			case 21:
				this.mProgressStatus = (TextBlock)target;
				return;
			case 22:
				this.mProgressPercentage = (Label)target;
				return;
			case 23:
				this.mStackPanel = (StackPanel)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000358 RID: 856
		private Dictionary<object, Tuple<ButtonColors, EventHandler, object>> mDictActions = new Dictionary<object, Tuple<ButtonColors, EventHandler, object>>();

		// Token: 0x04000359 RID: 857
		private Predicate<object> mCloseButtonEventHandler;

		// Token: 0x0400035B RID: 859
		private CustomButton mButton1;

		// Token: 0x0400035C RID: 860
		private CustomButton mButton2;

		// Token: 0x0400035D RID: 861
		private object mCloseButtonEventData;

		// Token: 0x0400035F RID: 863
		private double mContentMaxWidth;

		// Token: 0x04000361 RID: 865
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mMaskBorder;

		// Token: 0x04000362 RID: 866
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mParentGrid;

		// Token: 0x04000363 RID: 867
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mTitleGrid;

		// Token: 0x04000364 RID: 868
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mTitleIcon;

		// Token: 0x04000365 RID: 869
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mTitleText;

		// Token: 0x04000366 RID: 870
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCustomMessageBoxMinimizeButton;

		// Token: 0x04000367 RID: 871
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mCustomMessageBoxCloseButton;

		// Token: 0x04000368 RID: 872
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mMessageIcon;

		// Token: 0x04000369 RID: 873
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mTextBlockGrid;

		// Token: 0x0400036A RID: 874
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mBodyTextStackPanel;

		// Token: 0x0400036B RID: 875
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mBodyTextBlockTitle;

		// Token: 0x0400036C RID: 876
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mAboveBodyWarningTextBlock;

		// Token: 0x0400036D RID: 877
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mBodyTextBlock;

		// Token: 0x0400036E RID: 878
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mBodyWarningTextBlock;

		// Token: 0x0400036F RID: 879
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mUrlTextBlock;

		// Token: 0x04000370 RID: 880
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Hyperlink mUrlLink;

		// Token: 0x04000371 RID: 881
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomCheckbox mCheckBox;

		// Token: 0x04000372 RID: 882
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mProgressGrid;

		// Token: 0x04000373 RID: 883
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal BlueProgressBar mProgressbar;

		// Token: 0x04000374 RID: 884
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mProgressUpdatesGrid;

		// Token: 0x04000375 RID: 885
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mProgressStatus;

		// Token: 0x04000376 RID: 886
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Label mProgressPercentage;

		// Token: 0x04000377 RID: 887
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal StackPanel mStackPanel;

		// Token: 0x04000378 RID: 888
		private bool _contentLoaded;
	}
}
