﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace BlueStacks.Common
{
	// Token: 0x0200008B RID: 139
	public class BiDirectionalGraph<T>
	{
		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x0600036D RID: 877 RVA: 0x00003E61 File Offset: 0x00002061
		public ObservableCollection<BiDirectionalVertex<T>> Vertices { get; }

		// Token: 0x0600036E RID: 878 RVA: 0x00003E69 File Offset: 0x00002069
		public BiDirectionalGraph(ObservableCollection<BiDirectionalVertex<T>> initialNodes = null)
		{
			this.Vertices = (initialNodes ?? new ObservableCollection<BiDirectionalVertex<T>>());
		}

		// Token: 0x0600036F RID: 879 RVA: 0x00003E81 File Offset: 0x00002081
		public void AddVertex(BiDirectionalVertex<T> vertex)
		{
			if (vertex != null && !this.Vertices.Contains(vertex))
			{
				this.Vertices.Add(vertex);
			}
		}

		// Token: 0x06000370 RID: 880 RVA: 0x00003EA0 File Offset: 0x000020A0
		public void AddParentChild(BiDirectionalVertex<T> parent, BiDirectionalVertex<T> child)
		{
			if (parent != null && child != null)
			{
				this.AddVertex(parent);
				this.AddVertex(child);
				this.AddParentChildRelation(parent, child);
			}
		}

		// Token: 0x06000371 RID: 881 RVA: 0x00003EBE File Offset: 0x000020BE
		public void RemoveVertex(BiDirectionalVertex<T> vertex)
		{
			if (vertex != null && this.Vertices.Contains(vertex))
			{
				this.DeLinkMacro(vertex);
				this.Vertices.Remove(vertex);
			}
		}

		// Token: 0x06000372 RID: 882 RVA: 0x00014B70 File Offset: 0x00012D70
		public void DeLinkMacroChild(BiDirectionalVertex<T> recording)
		{
			if (recording != null)
			{
				foreach (BiDirectionalVertex<T> biDirectionalVertex in recording.Childs)
				{
					biDirectionalVertex.RemoveParent(recording);
				}
				recording.Childs.Clear();
			}
		}

		// Token: 0x06000373 RID: 883 RVA: 0x00014BD0 File Offset: 0x00012DD0
		public void DeLinkMacroParent(BiDirectionalVertex<T> recording)
		{
			if (recording != null)
			{
				foreach (BiDirectionalVertex<T> biDirectionalVertex in recording.Parents)
				{
					biDirectionalVertex.RemoveChild(recording);
				}
				recording.Parents.Clear();
			}
		}

		// Token: 0x06000374 RID: 884 RVA: 0x00003EE5 File Offset: 0x000020E5
		public void DeLinkMacro(BiDirectionalVertex<T> recording)
		{
			this.DeLinkMacroChild(recording);
			this.DeLinkMacroParent(recording);
		}

		// Token: 0x06000375 RID: 885 RVA: 0x00003EF5 File Offset: 0x000020F5
		private void AddParentChildRelation(BiDirectionalVertex<T> parent, BiDirectionalVertex<T> child)
		{
			if (parent != null && child != null)
			{
				if (!child.Parents.Contains(parent))
				{
					child.AddParent(parent);
				}
				if (!parent.Childs.Contains(child))
				{
					parent.AddChild(child);
				}
			}
		}

		// Token: 0x06000376 RID: 886 RVA: 0x00014C30 File Offset: 0x00012E30
		private bool ChildExist(BiDirectionalVertex<T> root, BiDirectionalVertex<T> searchVertex)
		{
			if (!root.IsVisited)
			{
				root.IsVisited = true;
				return root.Equals(searchVertex) || root.Childs.Any((BiDirectionalVertex<T> child) => this.ChildExist(child, searchVertex));
			}
			return false;
		}

		// Token: 0x06000377 RID: 887 RVA: 0x00003F27 File Offset: 0x00002127
		public bool DoesParentExist(BiDirectionalVertex<T> root, BiDirectionalVertex<T> searchVertex)
		{
			if (root == null)
			{
				return false;
			}
			this.UnVisitAllVertices();
			return this.ParentExist(root, searchVertex);
		}

		// Token: 0x06000378 RID: 888 RVA: 0x00014C8C File Offset: 0x00012E8C
		private bool ParentExist(BiDirectionalVertex<T> root, BiDirectionalVertex<T> searchVertex)
		{
			if (!root.IsVisited)
			{
				root.IsVisited = true;
				return root.Equals(searchVertex) || root.Parents.Any((BiDirectionalVertex<T> parent) => this.ParentExist(parent, searchVertex));
			}
			return false;
		}

		// Token: 0x06000379 RID: 889 RVA: 0x00014CE8 File Offset: 0x00012EE8
		private void UnVisitAllVertices()
		{
			foreach (BiDirectionalVertex<T> biDirectionalVertex in this.Vertices)
			{
				biDirectionalVertex.IsVisited = false;
			}
		}

		// Token: 0x0600037A RID: 890 RVA: 0x00014D34 File Offset: 0x00012F34
		public List<BiDirectionalVertex<T>> GetAllChilds(BiDirectionalVertex<T> vertex)
		{
			BiDirectionalGraph<T>.<>c__DisplayClass15_0 CS$<>8__locals1;
			CS$<>8__locals1.dependents = new List<BiDirectionalVertex<T>>();
			if (vertex != null)
			{
				BiDirectionalGraph<T>.<GetAllChilds>g__GetChilds|15_0(vertex, ref CS$<>8__locals1);
			}
			return CS$<>8__locals1.dependents;
		}

		// Token: 0x0600037B RID: 891 RVA: 0x00014D60 File Offset: 0x00012F60
		public List<MacroRecording> GetAllLeaves(MacroRecording macro)
		{
			BiDirectionalGraph<T>.<>c__DisplayClass16_0 CS$<>8__locals1;
			CS$<>8__locals1.leaves = new List<MacroRecording>();
			if (macro != null)
			{
				BiDirectionalGraph<T>.<GetAllLeaves>g__IterateForLeaves|16_0(macro, ref CS$<>8__locals1);
			}
			return CS$<>8__locals1.leaves;
		}

		// Token: 0x0600037C RID: 892 RVA: 0x00014D8C File Offset: 0x00012F8C
		[CompilerGenerated]
		internal static void <GetAllChilds>g__GetChilds|15_0(BiDirectionalVertex<T> node, ref BiDirectionalGraph<T>.<>c__DisplayClass15_0 A_1)
		{
			foreach (BiDirectionalVertex<T> biDirectionalVertex in node.Childs)
			{
				if (!A_1.dependents.Contains(biDirectionalVertex))
				{
					A_1.dependents.Add(biDirectionalVertex);
					if (biDirectionalVertex.Childs.Count > 0)
					{
						BiDirectionalGraph<T>.<GetAllChilds>g__GetChilds|15_0(biDirectionalVertex, ref A_1);
					}
				}
			}
		}

		// Token: 0x0600037D RID: 893 RVA: 0x00014E08 File Offset: 0x00013008
		[CompilerGenerated]
		internal static void <GetAllLeaves>g__IterateForLeaves|16_0(MacroRecording recording, ref BiDirectionalGraph<T>.<>c__DisplayClass16_0 A_1)
		{
			foreach (BiDirectionalVertex<MacroRecording> biDirectionalVertex in recording.Childs)
			{
				MacroRecording macroRecording = (MacroRecording)biDirectionalVertex;
				if (macroRecording.Childs.Count == 0 && !A_1.leaves.Contains(macroRecording))
				{
					A_1.leaves.Add(macroRecording);
				}
				else
				{
					BiDirectionalGraph<T>.<GetAllLeaves>g__IterateForLeaves|16_0(macroRecording, ref A_1);
				}
			}
		}
	}
}
