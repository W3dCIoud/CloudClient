﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace BlueStacks.Common
{
	// Token: 0x02000086 RID: 134
	public class ButtonColorMultiConverter : IMultiValueConverter
	{
		// Token: 0x0600035E RID: 862 RVA: 0x0001497C File Offset: 0x00012B7C
		public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
		{
			if (parameter == null || values == null)
			{
				return Binding.DoNothing;
			}
			string[] array = parameter.ToString().Split(new char[]
			{
				'_'
			});
			if (!BlueStacksUIBinding.Instance.ColorModel.ContainsKey(values[0].ToString() + array[0] + array[1]))
			{
				return BlueStacksUIBinding.Instance.ColorModel[values[0].ToString() + "MouseOut" + array[1]];
			}
			return BlueStacksUIBinding.Instance.ColorModel[values[0].ToString() + array[0] + array[1]];
		}

		// Token: 0x0600035F RID: 863 RVA: 0x00003A87 File Offset: 0x00001C87
		public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
		{
			return null;
		}
	}
}
