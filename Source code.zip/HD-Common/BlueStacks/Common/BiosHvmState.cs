﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000A4 RID: 164
	public enum BiosHvmState
	{
		// Token: 0x040001D6 RID: 470
		False,
		// Token: 0x040001D7 RID: 471
		True,
		// Token: 0x040001D8 RID: 472
		Unknown
	}
}
