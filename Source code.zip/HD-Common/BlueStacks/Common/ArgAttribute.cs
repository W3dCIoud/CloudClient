﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001BC RID: 444
	[AttributeUsage(AttributeTargets.Field)]
	public class ArgAttribute : Attribute
	{
		// Token: 0x170003E8 RID: 1000
		// (get) Token: 0x06000E7E RID: 3710 RVA: 0x0000CE6C File Offset: 0x0000B06C
		// (set) Token: 0x06000E7F RID: 3711 RVA: 0x0000CE74 File Offset: 0x0000B074
		public string Name { get; set; }

		// Token: 0x170003E9 RID: 1001
		// (get) Token: 0x06000E80 RID: 3712 RVA: 0x0000CE7D File Offset: 0x0000B07D
		// (set) Token: 0x06000E81 RID: 3713 RVA: 0x0000CE85 File Offset: 0x0000B085
		public object Value { get; set; }

		// Token: 0x170003EA RID: 1002
		// (get) Token: 0x06000E82 RID: 3714 RVA: 0x0000CE8E File Offset: 0x0000B08E
		// (set) Token: 0x06000E83 RID: 3715 RVA: 0x0000CE96 File Offset: 0x0000B096
		public string Description { get; set; }
	}
}
