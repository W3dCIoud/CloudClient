﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000A3 RID: 163
	public enum CpuHvmState
	{
		// Token: 0x040001D2 RID: 466
		False,
		// Token: 0x040001D3 RID: 467
		True,
		// Token: 0x040001D4 RID: 468
		Unknown
	}
}
