﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Threading;

namespace BlueStacks.Common
{
	// Token: 0x020000BA RID: 186
	public static class LocaleStrings
	{
		// Token: 0x14000007 RID: 7
		// (add) Token: 0x060004BB RID: 1211 RVA: 0x00018620 File Offset: 0x00016820
		// (remove) Token: 0x060004BC RID: 1212 RVA: 0x00018654 File Offset: 0x00016854
		public static event EventHandler SourceUpdatedEvent;

		// Token: 0x1700013E RID: 318
		// (get) Token: 0x060004BD RID: 1213 RVA: 0x00004B69 File Offset: 0x00002D69
		// (set) Token: 0x060004BE RID: 1214 RVA: 0x00004B83 File Offset: 0x00002D83
		public static Dictionary<string, string> DictLocalizedString
		{
			get
			{
				if (LocaleStrings.sDictLocalizedString == null)
				{
					LocaleStrings.InitLocalization(null, "Android", false);
				}
				return LocaleStrings.sDictLocalizedString;
			}
			set
			{
				LocaleStrings.sDictLocalizedString = value;
			}
		}

		// Token: 0x1700013F RID: 319
		// (get) Token: 0x060004BF RID: 1215 RVA: 0x00004B8B File Offset: 0x00002D8B
		// (set) Token: 0x060004C0 RID: 1216 RVA: 0x00004B92 File Offset: 0x00002D92
		public static string Locale { get; set; }

		// Token: 0x060004C1 RID: 1217 RVA: 0x00018688 File Offset: 0x00016888
		public static void InitLocalization(string localeDir = null, string vmName = "Android", bool skipLocalePickFromRegistry = false)
		{
			if (localeDir == null)
			{
				LocaleStrings.sResourceLocation = Path.Combine(RegistryManager.Instance.UserDefinedDir, "Locales");
			}
			else
			{
				LocaleStrings.sResourceLocation = localeDir;
			}
			LocaleStrings.sDictLocalizedString = new Dictionary<string, string>(StringComparer.InvariantCultureIgnoreCase);
			LocaleStrings.Locale = LocaleStrings.GetLocaleName(vmName, skipLocalePickFromRegistry);
			Globalization.PopulateLocaleStrings(LocaleStrings.sResourceLocation, LocaleStrings.sDictLocalizedString, "en-US");
			if (string.Compare(LocaleStrings.Locale, "en-US", StringComparison.OrdinalIgnoreCase) != 0)
			{
				Globalization.PopulateLocaleStrings(LocaleStrings.sResourceLocation, LocaleStrings.sDictLocalizedString, LocaleStrings.Locale);
			}
			EventHandler sourceUpdatedEvent = LocaleStrings.SourceUpdatedEvent;
			if (sourceUpdatedEvent == null)
			{
				return;
			}
			sourceUpdatedEvent("Locale_Updated", null);
		}

		// Token: 0x060004C2 RID: 1218 RVA: 0x00018728 File Offset: 0x00016928
		public static string GetLocaleName(string vmName, bool skipLocalePickFromRegistry = false)
		{
			string text = skipLocalePickFromRegistry ? null : RegistryManager.Instance.Guest[vmName].Locale;
			if (string.IsNullOrEmpty(text))
			{
				if (FeatureManager.Instance.IsCustomUIForDMM)
				{
					return "ja-JP";
				}
				text = Globalization.FindClosestMatchingLocale(Thread.CurrentThread.CurrentCulture.Name);
			}
			return text;
		}

		// Token: 0x060004C3 RID: 1219 RVA: 0x00018784 File Offset: 0x00016984
		public static string GetLocalizedString(string id)
		{
			if (id == null)
			{
				return string.Empty;
			}
			string result = id.Trim();
			try
			{
				if (LocaleStrings.sDictLocalizedString == null)
				{
					LocaleStrings.InitLocalization(null, "Android", false);
				}
				if (LocaleStrings.sDictLocalizedString.ContainsKey(id.ToUpper(CultureInfo.InvariantCulture)))
				{
					result = LocaleStrings.sDictLocalizedString[id.ToUpper(CultureInfo.InvariantCulture)];
				}
				else
				{
					result = LocaleStrings.RemoveConstants(id);
				}
			}
			catch
			{
				Logger.Warning("Localized string not available for: {0}", new object[]
				{
					id
				});
			}
			return result;
		}

		// Token: 0x060004C4 RID: 1220 RVA: 0x00018814 File Offset: 0x00016A14
		internal static string RemoveConstants(string path)
		{
			if (path.Contains(Constants.ImapLocaleStringsConstant))
			{
				path = path.Replace(Constants.ImapLocaleStringsConstant, "");
				path = path.Replace("_", " ");
			}
			else if (path.Contains(Constants.LocaleStringsConstant))
			{
				path = path.Replace(Constants.LocaleStringsConstant, "");
				path = path.Replace("_", " ");
			}
			return path;
		}

		// Token: 0x060004C5 RID: 1221 RVA: 0x00018888 File Offset: 0x00016A88
		public static bool AppendLocaleIfDoesntExist(string key, string value)
		{
			bool result = false;
			try
			{
				if (!LocaleStrings.sDictLocalizedString.ContainsKey(key))
				{
					LocaleStrings.sDictLocalizedString.Add(key, value);
					result = true;
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Error appending locale entry: {0}" + ex.Message);
			}
			return result;
		}

		// Token: 0x04000270 RID: 624
		private static string sResourceLocation;

		// Token: 0x04000272 RID: 626
		private static Dictionary<string, string> sDictLocalizedString;
	}
}
