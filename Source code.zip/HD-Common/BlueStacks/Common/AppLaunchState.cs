﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000123 RID: 291
	public enum AppLaunchState
	{
		// Token: 0x04000537 RID: 1335
		Unknown,
		// Token: 0x04000538 RID: 1336
		Fresh,
		// Token: 0x04000539 RID: 1337
		Installed,
		// Token: 0x0400053A RID: 1338
		Launched
	}
}
