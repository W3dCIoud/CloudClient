﻿using System;
using System.Net;

namespace BlueStacks.Common
{
	// Token: 0x02000092 RID: 146
	public class ExtendedWebClient : WebClient
	{
		// Token: 0x06000393 RID: 915 RVA: 0x00004099 File Offset: 0x00002299
		public ExtendedWebClient(int timeout)
		{
			this.mTimeout = timeout;
		}

		// Token: 0x06000394 RID: 916 RVA: 0x000040A8 File Offset: 0x000022A8
		protected override WebRequest GetWebRequest(Uri address)
		{
			WebRequest webRequest = base.GetWebRequest(address);
			webRequest.Timeout = this.mTimeout;
			return webRequest;
		}

		// Token: 0x040001A7 RID: 423
		private int mTimeout;
	}
}
