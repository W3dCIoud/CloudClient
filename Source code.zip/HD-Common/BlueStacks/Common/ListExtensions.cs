﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace BlueStacks.Common
{
	// Token: 0x02000094 RID: 148
	public static class ListExtensions
	{
		// Token: 0x06000397 RID: 919 RVA: 0x0001526C File Offset: 0x0001346C
		public static void ClearSync<T>(this List<T> list)
		{
			if (list != null)
			{
				object syncRoot = ((ICollection)list).SyncRoot;
				lock (syncRoot)
				{
					list.Clear();
				}
			}
		}

		// Token: 0x06000398 RID: 920 RVA: 0x000152A8 File Offset: 0x000134A8
		public static void ClearAddRange<T>(this List<T> list, List<T> listToAdd)
		{
			if (list != null)
			{
				object syncRoot = ((ICollection)list).SyncRoot;
				lock (syncRoot)
				{
					list.Clear();
					if (listToAdd != null && listToAdd.Count > 0)
					{
						list.AddRange(listToAdd);
					}
				}
			}
		}
	}
}
