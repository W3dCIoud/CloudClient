﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace BlueStacks.Common
{
	// Token: 0x020000CB RID: 203
	[SuppressMessage("Performance", "CA1822:Mark members as static", Justification = "<Pending>")]
	public class BlueStacksUIBinding : INotifyPropertyChanged
	{
		// Token: 0x17000154 RID: 340
		// (get) Token: 0x060004F2 RID: 1266 RVA: 0x00004EE7 File Offset: 0x000030E7
		// (set) Token: 0x060004F3 RID: 1267 RVA: 0x00004EFF File Offset: 0x000030FF
		public static BlueStacksUIBinding Instance
		{
			get
			{
				if (BlueStacksUIBinding._Instance == null)
				{
					BlueStacksUIBinding._Instance = new BlueStacksUIBinding();
				}
				return BlueStacksUIBinding._Instance;
			}
			set
			{
				BlueStacksUIBinding._Instance = value;
			}
		}

		// Token: 0x060004F4 RID: 1268 RVA: 0x00004F07 File Offset: 0x00003107
		private BlueStacksUIBinding()
		{
			LocaleStrings.SourceUpdatedEvent += this.Locale_Updated;
			BluestacksUIColor.SourceUpdatedEvent += this.BluestacksUIColor_Updated;
			CustomPictureBox.SourceUpdatedEvent += this.BluestacksImage_Updated;
		}

		// Token: 0x060004F5 RID: 1269 RVA: 0x00004F42 File Offset: 0x00003142
		public void Locale_Updated(object sender, EventArgs e)
		{
			this.NotifyPropertyChanged("LocaleModel");
		}

		// Token: 0x060004F6 RID: 1270 RVA: 0x00004F4F File Offset: 0x0000314F
		public void BluestacksUIColor_Updated(object sender, EventArgs e)
		{
			this.NotifyPropertyChanged("ColorModel");
			this.NotifyPropertyChanged("GeometryModel");
			this.NotifyPropertyChanged("CornerRadiusModel");
			this.NotifyPropertyChanged("TransformModel");
		}

		// Token: 0x060004F7 RID: 1271 RVA: 0x00004F7D File Offset: 0x0000317D
		public void BluestacksImage_Updated(object sender, EventArgs e)
		{
			this.NotifyPropertyChanged("ImageModel");
		}

		// Token: 0x14000008 RID: 8
		// (add) Token: 0x060004F8 RID: 1272 RVA: 0x00018D7C File Offset: 0x00016F7C
		// (remove) Token: 0x060004F9 RID: 1273 RVA: 0x00018DB4 File Offset: 0x00016FB4
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x17000155 RID: 341
		// (get) Token: 0x060004FA RID: 1274 RVA: 0x00004F8A File Offset: 0x0000318A
		// (set) Token: 0x060004FB RID: 1275 RVA: 0x0000358C File Offset: 0x0000178C
		public Dictionary<string, Brush> ColorModel
		{
			get
			{
				return BlueStacksUIColorManager.AppliedTheme.DictBrush;
			}
			set
			{
			}
		}

		// Token: 0x17000156 RID: 342
		// (get) Token: 0x060004FC RID: 1276 RVA: 0x00004F96 File Offset: 0x00003196
		// (set) Token: 0x060004FD RID: 1277 RVA: 0x0000358C File Offset: 0x0000178C
		public Dictionary<string, Geometry> GeometryModel
		{
			get
			{
				return BlueStacksUIColorManager.AppliedTheme.DictGeometry;
			}
			set
			{
			}
		}

		// Token: 0x17000157 RID: 343
		// (get) Token: 0x060004FE RID: 1278 RVA: 0x00004FA2 File Offset: 0x000031A2
		// (set) Token: 0x060004FF RID: 1279 RVA: 0x0000358C File Offset: 0x0000178C
		public Dictionary<string, CornerRadius> CornerRadiusModel
		{
			get
			{
				return BlueStacksUIColorManager.AppliedTheme.DictCornerRadius;
			}
			set
			{
			}
		}

		// Token: 0x17000158 RID: 344
		// (get) Token: 0x06000500 RID: 1280 RVA: 0x00004FAE File Offset: 0x000031AE
		// (set) Token: 0x06000501 RID: 1281 RVA: 0x0000358C File Offset: 0x0000178C
		public Dictionary<string, Transform> TransformModel
		{
			get
			{
				return BlueStacksUIColorManager.AppliedTheme.DictTransform;
			}
			set
			{
			}
		}

		// Token: 0x17000159 RID: 345
		// (get) Token: 0x06000502 RID: 1282 RVA: 0x00004FBA File Offset: 0x000031BA
		// (set) Token: 0x06000503 RID: 1283 RVA: 0x0000358C File Offset: 0x0000178C
		public Dictionary<string, string> LocaleModel
		{
			get
			{
				return LocaleStrings.DictLocalizedString;
			}
			set
			{
			}
		}

		// Token: 0x1700015A RID: 346
		// (get) Token: 0x06000504 RID: 1284 RVA: 0x00004FC1 File Offset: 0x000031C1
		// (set) Token: 0x06000505 RID: 1285 RVA: 0x0000358C File Offset: 0x0000178C
		public Dictionary<string, Tuple<BitmapImage, bool>> ImageModel
		{
			get
			{
				return CustomPictureBox.sImageAssetsDict;
			}
			set
			{
			}
		}

		// Token: 0x06000506 RID: 1286 RVA: 0x00004FC8 File Offset: 0x000031C8
		public void NotifyPropertyChanged(string name)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged == null)
			{
				return;
			}
			propertyChanged(this, new PropertyChangedEventArgs(name));
		}

		// Token: 0x06000507 RID: 1287 RVA: 0x00004FE1 File Offset: 0x000031E1
		public static void Bind(UserControl uc, string path)
		{
			BindingOperations.SetBinding(uc, FrameworkElement.ToolTipProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x06000508 RID: 1288 RVA: 0x00004FF5 File Offset: 0x000031F5
		public static void Bind(CustomRadioButton tb, string path)
		{
			BindingOperations.SetBinding(tb, ContentControl.ContentProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x06000509 RID: 1289 RVA: 0x00004FF5 File Offset: 0x000031F5
		public static void Bind(ToggleButton tb, string path)
		{
			BindingOperations.SetBinding(tb, ContentControl.ContentProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x0600050A RID: 1290 RVA: 0x00005009 File Offset: 0x00003209
		public static void Bind(GroupBox gb, string path)
		{
			BindingOperations.SetBinding(gb, HeaderedContentControl.HeaderProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x0600050B RID: 1291 RVA: 0x00004FF5 File Offset: 0x000031F5
		public static void Bind(Label label, string path)
		{
			BindingOperations.SetBinding(label, ContentControl.ContentProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x0600050C RID: 1292 RVA: 0x0000501D File Offset: 0x0000321D
		public static void Bind(Run run, string path)
		{
			BindingOperations.SetBinding(run, TextBlock.TextProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x0600050D RID: 1293 RVA: 0x00005031 File Offset: 0x00003231
		public static void Bind(Window wind, string path)
		{
			BindingOperations.SetBinding(wind, Window.TitleProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x0600050E RID: 1294 RVA: 0x00018DEC File Offset: 0x00016FEC
		public static void Bind(TextBlock tb, string path, string stringFormat = "")
		{
			Binding localeBinding = BlueStacksUIBinding.GetLocaleBinding(path);
			if (!string.IsNullOrEmpty(stringFormat))
			{
				localeBinding.StringFormat = stringFormat;
			}
			BindingOperations.SetBinding(tb, TextBlock.TextProperty, localeBinding);
		}

		// Token: 0x0600050F RID: 1295 RVA: 0x00005045 File Offset: 0x00003245
		public static void Bind(DependencyObject icon, string path, DependencyProperty dp)
		{
			BindingOperations.SetBinding(icon, dp, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x06000510 RID: 1296 RVA: 0x00005055 File Offset: 0x00003255
		public static void ClearBind(DependencyObject icon, DependencyProperty dp)
		{
			BindingOperations.ClearBinding(icon, dp);
		}

		// Token: 0x06000511 RID: 1297 RVA: 0x00004FF5 File Offset: 0x000031F5
		public static void Bind(ComboBoxItem comboBoxItem, string path)
		{
			BindingOperations.SetBinding(comboBoxItem, ContentControl.ContentProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x06000512 RID: 1298 RVA: 0x00004FF5 File Offset: 0x000031F5
		public static void Bind(Button button, string path)
		{
			BindingOperations.SetBinding(button, ContentControl.ContentProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x06000513 RID: 1299 RVA: 0x00004FE1 File Offset: 0x000031E1
		public static void Bind(Image button, string path)
		{
			BindingOperations.SetBinding(button, FrameworkElement.ToolTipProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x06000514 RID: 1300 RVA: 0x0000505E File Offset: 0x0000325E
		public static void Bind(TextBox textBox, string path)
		{
			BindingOperations.SetBinding(textBox, TextBox.TextProperty, BlueStacksUIBinding.GetLocaleBinding(path));
		}

		// Token: 0x06000515 RID: 1301 RVA: 0x00018E1C File Offset: 0x0001701C
		public static Binding GetLocaleBinding(string path)
		{
			Binding binding = new Binding
			{
				Source = BlueStacksUIBinding.Instance
			};
			string text = "";
			if (path != null)
			{
				for (int i = 0; i < path.Length; i++)
				{
					text = text + "^" + path[i].ToString();
				}
			}
			binding.Path = new PropertyPath("Instance.LocaleModel.[" + text.ToUpper(CultureInfo.InvariantCulture) + "]", new object[0]);
			binding.Mode = BindingMode.OneWay;
			binding.FallbackValue = LocaleStrings.RemoveConstants(path);
			binding.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
			LocaleStrings.AppendLocaleIfDoesntExist(path, LocaleStrings.RemoveConstants(path));
			return binding;
		}

		// Token: 0x06000516 RID: 1302 RVA: 0x00005072 File Offset: 0x00003272
		public static void BindColor(DependencyObject dObj, DependencyProperty dp, string path)
		{
			BindingOperations.SetBinding(dObj, dp, BlueStacksUIBinding.GetColorBinding(path));
		}

		// Token: 0x06000517 RID: 1303 RVA: 0x00005082 File Offset: 0x00003282
		public static void BindCornerRadius(DependencyObject dObj, DependencyProperty dp, string path)
		{
			BindingOperations.SetBinding(dObj, dp, BlueStacksUIBinding.GetCornerRadiusBinding(path));
		}

		// Token: 0x06000518 RID: 1304 RVA: 0x00005092 File Offset: 0x00003292
		public static void BindCornerRadiusToDouble(DependencyObject dObj, DependencyProperty dp, string path)
		{
			BindingOperations.SetBinding(dObj, dp, BlueStacksUIBinding.GetCornerRadiusDoubleBinding(path));
		}

		// Token: 0x06000519 RID: 1305 RVA: 0x00018EC8 File Offset: 0x000170C8
		public static Binding GetColorBinding(string path)
		{
			return new Binding
			{
				Converter = new BrushToColorConvertor(),
				Source = BlueStacksUIBinding.Instance,
				Path = new PropertyPath("Instance.ColorModel.[" + path + "]", new object[0]),
				Mode = BindingMode.OneWay,
				UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
			};
		}

		// Token: 0x0600051A RID: 1306 RVA: 0x00018F24 File Offset: 0x00017124
		public static Binding GetCornerRadiusBinding(string path)
		{
			return new Binding
			{
				Converter = new CornerRadiusToThicknessConvertor(),
				Source = BlueStacksUIBinding.Instance,
				Path = new PropertyPath("Instance.CornerRadiusModel.[" + path + "]", new object[0]),
				Mode = BindingMode.OneWay,
				UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
			};
		}

		// Token: 0x0600051B RID: 1307 RVA: 0x00018F80 File Offset: 0x00017180
		public static Binding GetCornerRadiusDoubleBinding(string path)
		{
			return new Binding
			{
				Converter = new CornerRadiusToDoubleConvertor(),
				Source = BlueStacksUIBinding.Instance,
				Path = new PropertyPath("Instance.CornerRadiusModel.[" + path + "]", new object[0]),
				Mode = BindingMode.OneWay,
				UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
			};
		}

		// Token: 0x0600051C RID: 1308 RVA: 0x000050A2 File Offset: 0x000032A2
		public static void Bind(Image button, DependencyProperty dp, string path)
		{
			BindingOperations.SetBinding(button, dp, BlueStacksUIBinding.GetImageBinding(path));
		}

		// Token: 0x0600051D RID: 1309 RVA: 0x00018FDC File Offset: 0x000171DC
		public static Binding GetImageBinding(string path)
		{
			return new Binding
			{
				Source = BlueStacksUIBinding.Instance,
				Path = new PropertyPath("Instance.ImageModel.[" + path + "].Item1", new object[0]),
				Mode = BindingMode.OneWay,
				UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
			};
		}

		// Token: 0x0600051E RID: 1310 RVA: 0x000050B2 File Offset: 0x000032B2
		public static void BindTransform(DependencyObject button, DependencyProperty dp, string path)
		{
			BindingOperations.SetBinding(button, dp, BlueStacksUIBinding.GetTransformBinding(path));
		}

		// Token: 0x0600051F RID: 1311 RVA: 0x0001902C File Offset: 0x0001722C
		public static Binding GetTransformBinding(string path)
		{
			return new Binding
			{
				Source = BlueStacksUIBinding.Instance,
				Path = new PropertyPath("Instance.TransformModel.[" + path + "]", new object[0]),
				Mode = BindingMode.OneWay,
				UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
			};
		}

		// Token: 0x040002C3 RID: 707
		private static BlueStacksUIBinding _Instance;
	}
}
