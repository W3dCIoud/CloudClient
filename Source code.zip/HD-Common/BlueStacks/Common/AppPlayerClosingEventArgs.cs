﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200006A RID: 106
	public class AppPlayerClosingEventArgs : BrowserEventArgs
	{
		// Token: 0x06000239 RID: 569 RVA: 0x000032A4 File Offset: 0x000014A4
		public AppPlayerClosingEventArgs(BrowserControlTags tag, string packageName, string vmName) : base(tag, packageName, vmName)
		{
		}
	}
}
