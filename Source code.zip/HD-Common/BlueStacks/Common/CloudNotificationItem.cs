﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000DA RID: 218
	public class CloudNotificationItem
	{
		// Token: 0x17000174 RID: 372
		// (get) Token: 0x06000587 RID: 1415 RVA: 0x00005533 File Offset: 0x00003733
		// (set) Token: 0x06000588 RID: 1416 RVA: 0x0000553B File Offset: 0x0000373B
		public string Title { get; set; } = string.Empty;

		// Token: 0x17000175 RID: 373
		// (get) Token: 0x06000589 RID: 1417 RVA: 0x00005544 File Offset: 0x00003744
		// (set) Token: 0x0600058A RID: 1418 RVA: 0x0000554C File Offset: 0x0000374C
		public string Url { get; set; } = string.Empty;

		// Token: 0x17000176 RID: 374
		// (get) Token: 0x0600058B RID: 1419 RVA: 0x00005555 File Offset: 0x00003755
		// (set) Token: 0x0600058C RID: 1420 RVA: 0x0000555D File Offset: 0x0000375D
		public string Message { get; set; } = string.Empty;

		// Token: 0x17000177 RID: 375
		// (get) Token: 0x0600058D RID: 1421 RVA: 0x00005566 File Offset: 0x00003766
		// (set) Token: 0x0600058E RID: 1422 RVA: 0x0000556E File Offset: 0x0000376E
		public string ImagePath { get; set; } = string.Empty;

		// Token: 0x17000178 RID: 376
		// (get) Token: 0x0600058F RID: 1423 RVA: 0x00005577 File Offset: 0x00003777
		// (set) Token: 0x06000590 RID: 1424 RVA: 0x0000557F File Offset: 0x0000377F
		public bool IsRead { get; set; }

		// Token: 0x06000591 RID: 1425 RVA: 0x00005588 File Offset: 0x00003788
		public CloudNotificationItem()
		{
		}

		// Token: 0x06000592 RID: 1426 RVA: 0x0001DA3C File Offset: 0x0001BC3C
		public CloudNotificationItem(string title, string content, string imagePath, string url)
		{
			this.Title = title;
			this.Message = content;
			this.ImagePath = imagePath;
			this.Url = url;
		}
	}
}
