﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x020000E3 RID: 227
	public class CustomComboBox : ComboBox, IComponentConnector, IStyleConnector
	{
		// Token: 0x06000627 RID: 1575 RVA: 0x00005A69 File Offset: 0x00003C69
		public CustomComboBox()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000628 RID: 1576 RVA: 0x00005A77 File Offset: 0x00003C77
		private void OnRequestBringIntoView(object sender, RequestBringIntoViewEventArgs e)
		{
			if (Keyboard.IsKeyDown(Key.Down) || Keyboard.IsKeyDown(Key.Up))
			{
				return;
			}
			e.Handled = true;
		}

		// Token: 0x17000192 RID: 402
		// (get) Token: 0x06000629 RID: 1577 RVA: 0x00005A93 File Offset: 0x00003C93
		// (set) Token: 0x0600062A RID: 1578 RVA: 0x00005AA5 File Offset: 0x00003CA5
		public bool Highlight
		{
			get
			{
				return (bool)base.GetValue(CustomComboBox.HighlightProperty);
			}
			set
			{
				base.SetValue(CustomComboBox.HighlightProperty, value);
			}
		}

		// Token: 0x0600062B RID: 1579 RVA: 0x00021164 File Offset: 0x0001F364
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/customcombobox.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600062C RID: 1580 RVA: 0x00005AB8 File Offset: 0x00003CB8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			this._contentLoaded = true;
		}

		// Token: 0x0600062D RID: 1581 RVA: 0x00021194 File Offset: 0x0001F394
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				EventSetter eventSetter = new EventSetter();
				eventSetter.Event = FrameworkElement.RequestBringIntoViewEvent;
				eventSetter.Handler = new RequestBringIntoViewEventHandler(this.OnRequestBringIntoView);
				((Style)target).Setters.Add(eventSetter);
			}
		}

		// Token: 0x0400034F RID: 847
		public static readonly DependencyProperty HighlightProperty = DependencyProperty.Register("Highlight", typeof(bool), typeof(CustomComboBox), new PropertyMetadata(false));

		// Token: 0x04000350 RID: 848
		private bool _contentLoaded;
	}
}
