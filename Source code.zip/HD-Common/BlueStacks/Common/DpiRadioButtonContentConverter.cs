﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace BlueStacks.Common
{
	// Token: 0x0200005D RID: 93
	public class DpiRadioButtonContentConverter : IValueConverter
	{
		// Token: 0x06000202 RID: 514 RVA: 0x00002F82 File Offset: 0x00001182
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			if (parameter == null || value == null)
			{
				return Binding.DoNothing;
			}
			return parameter.ToString() + " " + value.ToString();
		}

		// Token: 0x06000203 RID: 515 RVA: 0x00002FA6 File Offset: 0x000011A6
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return Binding.DoNothing;
		}
	}
}
