﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000068 RID: 104
	public class BootCompleteEventArgs : BrowserEventArgs
	{
		// Token: 0x06000237 RID: 567 RVA: 0x000032A4 File Offset: 0x000014A4
		public BootCompleteEventArgs(BrowserControlTags tag, string packageName, string vmName) : base(tag, packageName, vmName)
		{
		}
	}
}
