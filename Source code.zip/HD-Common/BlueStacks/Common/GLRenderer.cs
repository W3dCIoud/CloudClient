﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001A7 RID: 423
	public enum GLRenderer
	{
		// Token: 0x0400079F RID: 1951
		OpenGL = 1,
		// Token: 0x040007A0 RID: 1952
		DX9,
		// Token: 0x040007A1 RID: 1953
		DX11,
		// Token: 0x040007A2 RID: 1954
		DX11FallbackDX9
	}
}
