﻿using System;
using System.Collections.Generic;
using System.IO;

namespace BlueStacks.Common
{
	// Token: 0x020001AF RID: 431
	public static class IOUtils
	{
		// Token: 0x06000E51 RID: 3665 RVA: 0x00037208 File Offset: 0x00035408
		public static void DeleteIfExists(IEnumerable<string> filesToDelete)
		{
			if (filesToDelete != null)
			{
				foreach (string text in filesToDelete)
				{
					try
					{
						if (File.Exists(text))
						{
							File.Delete(text);
						}
					}
					catch (Exception ex)
					{
						Logger.Error("Exception while deleting file " + text + ex.ToString());
					}
				}
			}
		}

		// Token: 0x06000E52 RID: 3666 RVA: 0x0000CD1F File Offset: 0x0000AF1F
		public static long GetAvailableDiskSpaceOfDrive(string path)
		{
			return new DriveInfo(path).AvailableFreeSpace;
		}

		// Token: 0x06000E53 RID: 3667 RVA: 0x0000CD2C File Offset: 0x0000AF2C
		public static string GetPartitionNameFromPath(string path)
		{
			return new DriveInfo(path).Name;
		}

		// Token: 0x06000E54 RID: 3668 RVA: 0x00037284 File Offset: 0x00035484
		public static long GetDirectorySize(string dirPath)
		{
			if (!Directory.Exists(dirPath))
			{
				return 0L;
			}
			DirectoryInfo directoryInfo = new DirectoryInfo(dirPath);
			long num = 0L;
			foreach (FileInfo fileInfo in directoryInfo.GetFiles())
			{
				num += fileInfo.Length;
			}
			foreach (DirectoryInfo directoryInfo2 in directoryInfo.GetDirectories())
			{
				num += IOUtils.GetDirectorySize(directoryInfo2.FullName);
			}
			return num;
		}

		// Token: 0x06000E55 RID: 3669 RVA: 0x0000CD39 File Offset: 0x0000AF39
		public static bool IfPathExists(string path)
		{
			return new DirectoryInfo(path).Exists || new FileInfo(path).Exists;
		}

		// Token: 0x06000E56 RID: 3670 RVA: 0x000372F8 File Offset: 0x000354F8
		public static string GetFileOrFolderName(string path)
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(path);
			if (directoryInfo.Exists)
			{
				return directoryInfo.Name;
			}
			FileInfo fileInfo = new FileInfo(path);
			if (fileInfo.Exists)
			{
				return fileInfo.Name;
			}
			throw new IOException("File or folder name does not exist");
		}

		// Token: 0x06000E57 RID: 3671 RVA: 0x0003733C File Offset: 0x0003553C
		public static bool IsDirectoryEmpty(string dir)
		{
			bool result = true;
			if (!Directory.Exists(dir))
			{
				Logger.Info(dir + " does not exist");
				return result;
			}
			if (Directory.GetFiles(dir).Length == 0)
			{
				Logger.Info(dir + " is empty");
			}
			else
			{
				result = false;
			}
			foreach (string text in Directory.GetDirectories(dir))
			{
				Directory.GetFiles(text);
				if (!IOUtils.IsDirectoryEmpty(text))
				{
					result = false;
				}
			}
			return result;
		}

		// Token: 0x040007B0 RID: 1968
		public static readonly char[] DisallowedCharsInDirs = new char[]
		{
			'&',
			'<',
			'>',
			'"',
			'\'',
			'^'
		};
	}
}
