﻿using System;
using System.Threading;

namespace BlueStacks.Common
{
	// Token: 0x020001E2 RID: 482
	public class Countdown
	{
		// Token: 0x06000F6A RID: 3946 RVA: 0x0000D7AF File Offset: 0x0000B9AF
		public Countdown()
		{
		}

		// Token: 0x06000F6B RID: 3947 RVA: 0x0000D7C2 File Offset: 0x0000B9C2
		public Countdown(int initialCount)
		{
			this._value = initialCount;
		}

		// Token: 0x06000F6C RID: 3948 RVA: 0x0000D7DC File Offset: 0x0000B9DC
		public void Signal()
		{
			this.AddCount(-1);
		}

		// Token: 0x06000F6D RID: 3949 RVA: 0x0003B5E8 File Offset: 0x000397E8
		public void AddCount(int amount)
		{
			object locker = this._locker;
			lock (locker)
			{
				this._value += amount;
				if (this._value <= 0)
				{
					Monitor.PulseAll(this._locker);
				}
			}
		}

		// Token: 0x06000F6E RID: 3950 RVA: 0x0003B640 File Offset: 0x00039840
		public void Wait()
		{
			object locker = this._locker;
			lock (locker)
			{
				while (this._value > 0)
				{
					Monitor.Wait(this._locker);
				}
			}
		}

		// Token: 0x04000B37 RID: 2871
		private object _locker = new object();

		// Token: 0x04000B38 RID: 2872
		private int _value;
	}
}
