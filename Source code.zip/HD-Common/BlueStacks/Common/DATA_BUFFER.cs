﻿using System;
using System.Runtime.InteropServices;

namespace BlueStacks.Common
{
	// Token: 0x02000162 RID: 354
	public struct DATA_BUFFER
	{
		// Token: 0x0400067C RID: 1660
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 1024)]
		public string Buffer;
	}
}
