﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace BlueStacks.Common
{
	// Token: 0x02000056 RID: 86
	public sealed class BooleanToVisibilityConverter2 : IValueConverter
	{
		// Token: 0x060001EB RID: 491 RVA: 0x00010F0C File Offset: 0x0000F10C
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			bool flag = false;
			if (value is bool)
			{
				flag = (bool)value;
			}
			else if (value is bool?)
			{
				bool? flag2 = (bool?)value;
				flag = (flag2 != null && flag2.Value);
			}
			return (!flag) ? Visibility.Collapsed : Visibility.Visible;
		}

		// Token: 0x060001EC RID: 492 RVA: 0x00002EE2 File Offset: 0x000010E2
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			if (value is Visibility)
			{
				return (Visibility)value == Visibility.Visible;
			}
			return false;
		}
	}
}
