﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x0200009C RID: 156
	internal class JSonTemplates
	{
		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x060003C1 RID: 961 RVA: 0x00015D2C File Offset: 0x00013F2C
		public static string SuccessArrayJSonTemplate
		{
			get
			{
				if (string.IsNullOrEmpty(JSonTemplates.mSuccessArrayJsonString))
				{
					JArray jarray = new JArray();
					JObject item = new JObject
					{
						{
							"success",
							true
						},
						{
							"reason",
							""
						}
					};
					jarray.Add(item);
					JSonTemplates.mSuccessArrayJsonString = jarray.ToString(Formatting.None, new JsonConverter[0]);
				}
				return JSonTemplates.mSuccessArrayJsonString;
			}
		}

		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x060003C2 RID: 962 RVA: 0x00015D94 File Offset: 0x00013F94
		public static string FailedArrayJSonTemplate
		{
			get
			{
				if (string.IsNullOrEmpty(JSonTemplates.mFailedArrayJsonString))
				{
					JArray jarray = new JArray();
					JObject item = new JObject
					{
						{
							"success",
							false
						},
						{
							"reason",
							""
						}
					};
					jarray.Add(item);
					JSonTemplates.mFailedArrayJsonString = jarray.ToString(Formatting.None, new JsonConverter[0]);
				}
				return JSonTemplates.mFailedArrayJsonString;
			}
		}

		// Token: 0x170000FA RID: 250
		// (get) Token: 0x060003C3 RID: 963 RVA: 0x00015DFC File Offset: 0x00013FFC
		public static string SuccessJSonTemplate
		{
			get
			{
				if (string.IsNullOrEmpty(JSonTemplates.mSuccessJsonString))
				{
					JSonTemplates.mSuccessJsonString = new JObject
					{
						{
							"success",
							true
						},
						{
							"reason",
							""
						}
					}.ToString(Formatting.None, new JsonConverter[0]);
				}
				return JSonTemplates.mSuccessJsonString;
			}
		}

		// Token: 0x170000FB RID: 251
		// (get) Token: 0x060003C4 RID: 964 RVA: 0x00015E58 File Offset: 0x00014058
		public static string FailedJSonTemplate
		{
			get
			{
				if (string.IsNullOrEmpty(JSonTemplates.mFailedJsonString))
				{
					JSonTemplates.mFailedJsonString = new JObject
					{
						{
							"success",
							false
						},
						{
							"reason",
							""
						}
					}.ToString(Formatting.None, new JsonConverter[0]);
				}
				return JSonTemplates.mFailedJsonString;
			}
		}

		// Token: 0x040001B5 RID: 437
		private static string mSuccessArrayJsonString = string.Empty;

		// Token: 0x040001B6 RID: 438
		private static string mFailedArrayJsonString = string.Empty;

		// Token: 0x040001B7 RID: 439
		private static string mSuccessJsonString = string.Empty;

		// Token: 0x040001B8 RID: 440
		private static string mFailedJsonString = string.Empty;
	}
}
