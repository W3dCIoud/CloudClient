﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace BlueStacks.Common
{
	// Token: 0x0200006F RID: 111
	public static class EventAggregator
	{
		// Token: 0x0600023E RID: 574 RVA: 0x00012210 File Offset: 0x00010410
		public static void Publish<TMessageType>(TMessageType message)
		{
			Type typeFromHandle = typeof(TMessageType);
			if (EventAggregator.mSubscriber.ContainsKey(typeFromHandle))
			{
				foreach (object obj in ((IEnumerable)new List<Subscription<TMessageType>>(EventAggregator.mSubscriber[typeFromHandle].Cast<Subscription<TMessageType>>())))
				{
					((Subscription<TMessageType>)obj).Action(message);
				}
			}
		}

		// Token: 0x0600023F RID: 575 RVA: 0x00012294 File Offset: 0x00010494
		public static Subscription<TMessageType> Subscribe<TMessageType>(Action<TMessageType> action)
		{
			Type typeFromHandle = typeof(TMessageType);
			Subscription<TMessageType> subscription = new Subscription<TMessageType>(action);
			IList list;
			if (!EventAggregator.mSubscriber.TryGetValue(typeFromHandle, out list))
			{
				list = new List<Subscription<TMessageType>>();
				list.Add(subscription);
				EventAggregator.mSubscriber.Add(typeFromHandle, list);
			}
			else
			{
				list.Add(subscription);
			}
			return subscription;
		}

		// Token: 0x06000240 RID: 576 RVA: 0x000122E8 File Offset: 0x000104E8
		public static void Unsubscribe<TMessageType>(Subscription<TMessageType> subscription)
		{
			Type typeFromHandle = typeof(TMessageType);
			if (EventAggregator.mSubscriber.ContainsKey(typeFromHandle))
			{
				EventAggregator.mSubscriber[typeFromHandle].Remove(subscription);
			}
		}

		// Token: 0x04000109 RID: 265
		private static Dictionary<Type, IList> mSubscriber = new Dictionary<Type, IList>();
	}
}
