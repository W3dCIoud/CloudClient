﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x020000EC RID: 236
	public class CustomTextBox : XTextBox, IComponentConnector
	{
		// Token: 0x0600068D RID: 1677 RVA: 0x00006010 File Offset: 0x00004210
		public CustomTextBox()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600068E RID: 1678 RVA: 0x00021B28 File Offset: 0x0001FD28
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/customtextbox.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600068F RID: 1679 RVA: 0x000035E3 File Offset: 0x000017E3
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000690 RID: 1680 RVA: 0x0000601E File Offset: 0x0000421E
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				this.mTextBox = (CustomTextBox)target;
				return;
			}
			this._contentLoaded = true;
		}

		// Token: 0x04000380 RID: 896
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox mTextBox;

		// Token: 0x04000381 RID: 897
		private bool _contentLoaded;
	}
}
