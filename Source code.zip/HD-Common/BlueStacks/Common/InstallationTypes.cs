﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200010F RID: 271
	public enum InstallationTypes
	{
		// Token: 0x040004B0 RID: 1200
		None,
		// Token: 0x040004B1 RID: 1201
		GamingEdition,
		// Token: 0x040004B2 RID: 1202
		FullEdition,
		// Token: 0x040004B3 RID: 1203
		ClientOnly
	}
}
