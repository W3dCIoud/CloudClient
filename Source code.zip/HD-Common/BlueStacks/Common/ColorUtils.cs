﻿using System;
using System.Drawing;
using System.Windows.Media;

namespace BlueStacks.Common
{
	// Token: 0x020000DB RID: 219
	[Serializable]
	public class ColorUtils
	{
		// Token: 0x17000179 RID: 377
		// (get) Token: 0x06000593 RID: 1427 RVA: 0x000055BC File Offset: 0x000037BC
		// (set) Token: 0x06000594 RID: 1428 RVA: 0x000055C4 File Offset: 0x000037C4
		public byte R { get; set; }

		// Token: 0x1700017A RID: 378
		// (get) Token: 0x06000595 RID: 1429 RVA: 0x000055CD File Offset: 0x000037CD
		// (set) Token: 0x06000596 RID: 1430 RVA: 0x000055D5 File Offset: 0x000037D5
		public byte G { get; set; }

		// Token: 0x1700017B RID: 379
		// (get) Token: 0x06000597 RID: 1431 RVA: 0x000055DE File Offset: 0x000037DE
		// (set) Token: 0x06000598 RID: 1432 RVA: 0x000055E6 File Offset: 0x000037E6
		public byte B { get; set; }

		// Token: 0x1700017C RID: 380
		// (get) Token: 0x06000599 RID: 1433 RVA: 0x000055EF File Offset: 0x000037EF
		// (set) Token: 0x0600059A RID: 1434 RVA: 0x000055F7 File Offset: 0x000037F7
		public byte A { get; set; }

		// Token: 0x0600059B RID: 1435 RVA: 0x00005600 File Offset: 0x00003800
		public ColorUtils()
		{
			this.R = byte.MaxValue;
			this.G = byte.MaxValue;
			this.B = byte.MaxValue;
			this.A = byte.MaxValue;
		}

		// Token: 0x0600059C RID: 1436 RVA: 0x00005634 File Offset: 0x00003834
		public ColorUtils(System.Windows.Media.Color value)
		{
			this.R = value.R;
			this.G = value.G;
			this.B = value.B;
			this.A = value.A;
		}

		// Token: 0x0600059D RID: 1437 RVA: 0x00005670 File Offset: 0x00003870
		public ColorUtils(System.Drawing.Color value)
		{
			this.R = value.R;
			this.G = value.G;
			this.B = value.B;
			this.A = value.A;
		}

		// Token: 0x0600059E RID: 1438 RVA: 0x0001DA98 File Offset: 0x0001BC98
		public static implicit operator System.Drawing.Color(ColorUtils rgb)
		{
			if (rgb != null)
			{
				return System.Drawing.Color.FromArgb((int)rgb.A, (int)rgb.R, (int)rgb.G, (int)rgb.B);
			}
			return default(System.Drawing.Color);
		}

		// Token: 0x0600059F RID: 1439 RVA: 0x000056AC File Offset: 0x000038AC
		public static explicit operator ColorUtils(System.Drawing.Color c)
		{
			return new ColorUtils(c);
		}

		// Token: 0x060005A0 RID: 1440 RVA: 0x000056B4 File Offset: 0x000038B4
		public static ColorUtils FromHSL(double H, double S, double L)
		{
			return ColorUtils.FromHSLA(H, S, L, 1.0);
		}

		// Token: 0x060005A1 RID: 1441 RVA: 0x0001DAD0 File Offset: 0x0001BCD0
		public static ColorUtils FromHSLA(double H, double S, double L, double A)
		{
			if (H > 1.0)
			{
				H = 1.0;
			}
			if (S > 1.0)
			{
				S = 1.0;
			}
			if (L > 1.0)
			{
				L = 1.0;
			}
			if (H < 0.0)
			{
				H = 0.0;
			}
			if (S < 0.0)
			{
				S = 0.0;
			}
			if (L < 0.0)
			{
				L = 0.0;
			}
			if (A > 1.0)
			{
				A = 1.0;
			}
			double num = L;
			double num2 = L;
			double num3 = L;
			double num4 = (L <= 0.5) ? (L * (1.0 + S)) : (L + S - L * S);
			if (num4 > 0.0)
			{
				double num5 = L + L - num4;
				double num6 = (num4 - num5) / num4;
				H *= 6.0;
				int num7 = (int)H;
				double num8 = H - (double)num7;
				double num9 = num4 * num6 * num8;
				double num10 = num5 + num9;
				double num11 = num4 - num9;
				switch (num7)
				{
				case 0:
					num = num4;
					num2 = num10;
					num3 = num5;
					break;
				case 1:
					num = num11;
					num2 = num4;
					num3 = num5;
					break;
				case 2:
					num = num5;
					num2 = num4;
					num3 = num10;
					break;
				case 3:
					num = num5;
					num2 = num11;
					num3 = num4;
					break;
				case 4:
					num = num10;
					num2 = num5;
					num3 = num4;
					break;
				case 5:
					num = num4;
					num2 = num5;
					num3 = num11;
					break;
				}
			}
			return new ColorUtils
			{
				R = Convert.ToByte(num * 255.0),
				G = Convert.ToByte(num2 * 255.0),
				B = Convert.ToByte(num3 * 255.0),
				A = Convert.ToByte(A * 255.0)
			};
		}

		// Token: 0x1700017D RID: 381
		// (get) Token: 0x060005A2 RID: 1442 RVA: 0x0001DCAC File Offset: 0x0001BEAC
		public float H
		{
			get
			{
				return this.GetHue() / 360f;
			}
		}

		// Token: 0x1700017E RID: 382
		// (get) Token: 0x060005A3 RID: 1443 RVA: 0x0001DCD0 File Offset: 0x0001BED0
		public float S
		{
			get
			{
				return this.GetSaturation();
			}
		}

		// Token: 0x1700017F RID: 383
		// (get) Token: 0x060005A4 RID: 1444 RVA: 0x0001DCEC File Offset: 0x0001BEEC
		public float L
		{
			get
			{
				return this.GetBrightness();
			}
		}

		// Token: 0x17000180 RID: 384
		// (get) Token: 0x060005A5 RID: 1445 RVA: 0x000056C7 File Offset: 0x000038C7
		public System.Windows.Media.Color WPFColor
		{
			get
			{
				return System.Windows.Media.Color.FromArgb(this.A, this.R, this.G, this.B);
			}
		}
	}
}
