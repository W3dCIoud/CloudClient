﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;

namespace BlueStacks.Common
{
	// Token: 0x02000151 RID: 337
	public class CustomPictureBox : Image
	{
		// Token: 0x17000371 RID: 881
		// (get) Token: 0x06000B2D RID: 2861 RVA: 0x0000B390 File Offset: 0x00009590
		// (set) Token: 0x06000B2E RID: 2862 RVA: 0x0000B398 File Offset: 0x00009598
		public CustomPictureBox.State ButtonState { get; set; }

		// Token: 0x17000372 RID: 882
		// (get) Token: 0x06000B2F RID: 2863 RVA: 0x0000B3A1 File Offset: 0x000095A1
		// (set) Token: 0x06000B30 RID: 2864 RVA: 0x0000B3A9 File Offset: 0x000095A9
		public bool IsFullImagePath { get; set; }

		// Token: 0x17000373 RID: 883
		// (get) Token: 0x06000B31 RID: 2865 RVA: 0x0000B3B2 File Offset: 0x000095B2
		// (set) Token: 0x06000B32 RID: 2866 RVA: 0x0000B3C4 File Offset: 0x000095C4
		public string ImageName
		{
			get
			{
				return (string)base.GetValue(CustomPictureBox.ImageNameProperty);
			}
			set
			{
				base.SetValue(CustomPictureBox.ImageNameProperty, value);
			}
		}

		// Token: 0x17000374 RID: 884
		// (get) Token: 0x06000B33 RID: 2867 RVA: 0x0000B3D2 File Offset: 0x000095D2
		// (set) Token: 0x06000B34 RID: 2868 RVA: 0x0000B3E4 File Offset: 0x000095E4
		public bool IsImageHover
		{
			get
			{
				return (bool)base.GetValue(CustomPictureBox.IsImageHoverProperty);
			}
			set
			{
				base.SetValue(CustomPictureBox.IsImageHoverProperty, value);
			}
		}

		// Token: 0x17000375 RID: 885
		// (get) Token: 0x06000B35 RID: 2869 RVA: 0x0000B3F7 File Offset: 0x000095F7
		// (set) Token: 0x06000B36 RID: 2870 RVA: 0x0000B409 File Offset: 0x00009609
		public bool IsAlwaysHalfSize
		{
			get
			{
				return (bool)base.GetValue(CustomPictureBox.IsAlwaysHalfSizeProperty);
			}
			set
			{
				base.SetValue(CustomPictureBox.IsAlwaysHalfSizeProperty, value);
			}
		}

		// Token: 0x1400000B RID: 11
		// (add) Token: 0x06000B37 RID: 2871 RVA: 0x000297D8 File Offset: 0x000279D8
		// (remove) Token: 0x06000B38 RID: 2872 RVA: 0x0002980C File Offset: 0x00027A0C
		public static event EventHandler SourceUpdatedEvent;

		// Token: 0x17000376 RID: 886
		// (get) Token: 0x06000B39 RID: 2873 RVA: 0x0000B41C File Offset: 0x0000961C
		// (set) Token: 0x06000B3A RID: 2874 RVA: 0x00029840 File Offset: 0x00027A40
		public bool IsImageToBeRotated
		{
			get
			{
				return this.mIsImageToBeRotated;
			}
			set
			{
				this.mIsImageToBeRotated = value;
				if (value)
				{
					base.SizeChanged -= this.CustomPictureBox_SizeChanged;
					base.IsVisibleChanged -= this.CustomPictureBox_IsVisibleChanged;
					base.SizeChanged += this.CustomPictureBox_SizeChanged;
					base.IsVisibleChanged += this.CustomPictureBox_IsVisibleChanged;
					return;
				}
				if (this.mStoryBoard != null)
				{
					this.mStoryBoard.Stop();
				}
				base.SizeChanged -= this.CustomPictureBox_SizeChanged;
				base.IsVisibleChanged -= this.CustomPictureBox_IsVisibleChanged;
			}
		}

		// Token: 0x06000B3B RID: 2875 RVA: 0x0000B424 File Offset: 0x00009624
		public void SetDisabledState()
		{
			this.ButtonState = CustomPictureBox.State.disabled;
			base.Opacity = 0.4;
			this.SetDefaultImage();
		}

		// Token: 0x06000B3C RID: 2876 RVA: 0x0000B442 File Offset: 0x00009642
		public void SetNormalState()
		{
			this.ButtonState = CustomPictureBox.State.normal;
			base.Opacity = 1.0;
		}

		// Token: 0x06000B3D RID: 2877 RVA: 0x000298D8 File Offset: 0x00027AD8
		private string AppendStringToImageName(string appendText)
		{
			if (this.ImageName.EndsWith(".png", StringComparison.InvariantCultureIgnoreCase) || this.ImageName.EndsWith(".jpg", StringComparison.InvariantCultureIgnoreCase) || this.ImageName.EndsWith(".jpeg", StringComparison.InvariantCultureIgnoreCase) || this.ImageName.EndsWith(".ico", StringComparison.InvariantCultureIgnoreCase))
			{
				string extension = Path.GetExtension(this.ImageName);
				string directoryName = Path.GetDirectoryName(this.ImageName);
				return string.Concat(new string[]
				{
					directoryName,
					Path.DirectorySeparatorChar.ToString(),
					Path.GetFileNameWithoutExtension(this.ImageName),
					appendText,
					extension
				});
			}
			return this.ImageName + appendText;
		}

		// Token: 0x17000377 RID: 887
		// (get) Token: 0x06000B3E RID: 2878 RVA: 0x0000B45A File Offset: 0x0000965A
		private string HoverImage
		{
			get
			{
				return this.AppendStringToImageName("_hover");
			}
		}

		// Token: 0x17000378 RID: 888
		// (get) Token: 0x06000B3F RID: 2879 RVA: 0x0000B467 File Offset: 0x00009667
		private string ClickImage
		{
			get
			{
				return this.AppendStringToImageName("_click");
			}
		}

		// Token: 0x17000379 RID: 889
		// (get) Token: 0x06000B40 RID: 2880 RVA: 0x0000B474 File Offset: 0x00009674
		private string DisabledImage
		{
			get
			{
				return this.AppendStringToImageName("_dis");
			}
		}

		// Token: 0x1700037A RID: 890
		// (get) Token: 0x06000B41 RID: 2881 RVA: 0x0000B481 File Offset: 0x00009681
		public string SelectedImage
		{
			get
			{
				return this.AppendStringToImageName("_selected");
			}
		}

		// Token: 0x1700037B RID: 891
		// (get) Token: 0x06000B42 RID: 2882 RVA: 0x0000B48E File Offset: 0x0000968E
		public static string AssetsDir
		{
			get
			{
				return Path.Combine(RegistryManager.Instance.ClientInstallDir, RegistryManager.ClientThemeName);
			}
		}

		// Token: 0x06000B43 RID: 2883 RVA: 0x0002998C File Offset: 0x00027B8C
		public CustomPictureBox()
		{
			base.MouseEnter += this.PictureBox_MouseEnter;
			base.MouseLeave += this.PictureBox_MouseLeave;
			base.MouseDown += this.PictureBox_MouseDown;
			base.MouseUp += this.PictureBox_MouseUp;
			RenderOptions.SetBitmapScalingMode(this, BitmapScalingMode.HighQuality);
		}

		// Token: 0x06000B44 RID: 2884 RVA: 0x000299F0 File Offset: 0x00027BF0
		public static void UpdateImagesFromNewDirectory(string path = "")
		{
			foreach (Tuple<string, bool> tuple in (from _ in CustomPictureBox.sImageAssetsDict
			select new Tuple<string, bool>(_.Key, _.Value.Item2)).ToList<Tuple<string, bool>>())
			{
				if (tuple.Item1.IndexOfAny(new char[]
				{
					Path.AltDirectorySeparatorChar,
					Path.DirectorySeparatorChar
				}) == -1)
				{
					CustomPictureBox.sImageAssetsDict.Remove(tuple.Item1);
					CustomPictureBox.GetBitmapImage(tuple.Item1, path, tuple.Item2);
				}
			}
			CustomPictureBox.NotifyUIElements();
		}

		// Token: 0x06000B45 RID: 2885 RVA: 0x0000B4A4 File Offset: 0x000096A4
		internal static void NotifyUIElements()
		{
			if (CustomPictureBox.SourceUpdatedEvent != null)
			{
				CustomPictureBox.SourceUpdatedEvent(null, null);
			}
		}

		// Token: 0x06000B46 RID: 2886 RVA: 0x00029AB4 File Offset: 0x00027CB4
		private static void ImageNameChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
		{
			CustomPictureBox customPictureBox = source as CustomPictureBox;
			if (!DesignerProperties.GetIsInDesignMode(customPictureBox))
			{
				customPictureBox.SetDefaultImage();
			}
		}

		// Token: 0x06000B47 RID: 2887 RVA: 0x00029AD8 File Offset: 0x00027CD8
		private static void IsImageHoverChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
		{
			CustomPictureBox customPictureBox = source as CustomPictureBox;
			if (!DesignerProperties.GetIsInDesignMode(customPictureBox))
			{
				if (customPictureBox.IsImageHover)
				{
					customPictureBox.SetHoverImage();
					return;
				}
				customPictureBox.SetDefaultImage();
			}
		}

		// Token: 0x06000B48 RID: 2888 RVA: 0x00029AB4 File Offset: 0x00027CB4
		private static void IsAlwaysHalfSizeChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
		{
			CustomPictureBox customPictureBox = source as CustomPictureBox;
			if (!DesignerProperties.GetIsInDesignMode(customPictureBox))
			{
				customPictureBox.SetDefaultImage();
			}
		}

		// Token: 0x06000B49 RID: 2889 RVA: 0x0000B4B9 File Offset: 0x000096B9
		private void PictureBox_MouseEnter(object sender, MouseEventArgs e)
		{
			if (this.ButtonState == CustomPictureBox.State.normal && !this.IsFullImagePath)
			{
				this.SetHoverImage();
			}
		}

		// Token: 0x06000B4A RID: 2890 RVA: 0x0000B4D1 File Offset: 0x000096D1
		private void PictureBox_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.IsFullImagePath)
			{
				this.SetDefaultImage();
			}
		}

		// Token: 0x06000B4B RID: 2891 RVA: 0x0000B4E1 File Offset: 0x000096E1
		private void PictureBox_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (this.ButtonState == CustomPictureBox.State.normal && !this.IsFullImagePath)
			{
				this.SetClickedImage();
			}
		}

		// Token: 0x06000B4C RID: 2892 RVA: 0x0000B4F9 File Offset: 0x000096F9
		private void PictureBox_MouseUp(object sender, MouseButtonEventArgs e)
		{
			if (!this.IsFullImagePath)
			{
				if (base.IsMouseOver && this.ButtonState == CustomPictureBox.State.normal)
				{
					this.SetHoverImage();
					return;
				}
				this.SetDefaultImage();
			}
		}

		// Token: 0x06000B4D RID: 2893 RVA: 0x00029B0C File Offset: 0x00027D0C
		public void SetHoverImage()
		{
			try
			{
				if (!this.IsFullImagePath)
				{
					CustomPictureBox.SetBitmapImage(this, this.HoverImage, false);
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000B4E RID: 2894 RVA: 0x00029B44 File Offset: 0x00027D44
		public void SetClickedImage()
		{
			try
			{
				if (!this.IsFullImagePath)
				{
					CustomPictureBox.SetBitmapImage(this, this.ClickImage, false);
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000B4F RID: 2895 RVA: 0x00029B7C File Offset: 0x00027D7C
		public void SetSelectedImage()
		{
			try
			{
				if (!this.IsFullImagePath)
				{
					CustomPictureBox.SetBitmapImage(this, this.SelectedImage, false);
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000B50 RID: 2896 RVA: 0x00029BB4 File Offset: 0x00027DB4
		public void SetDisabledImage()
		{
			try
			{
				if (!this.IsFullImagePath)
				{
					CustomPictureBox.SetBitmapImage(this, this.DisabledImage, false);
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000B51 RID: 2897 RVA: 0x00029BEC File Offset: 0x00027DEC
		public void SetDefaultImage()
		{
			try
			{
				CustomPictureBox.SetBitmapImage(this, this.ImageName, this.IsFullImagePath);
			}
			catch
			{
			}
		}

		// Token: 0x06000B52 RID: 2898 RVA: 0x00029C20 File Offset: 0x00027E20
		public static BitmapImage GetBitmapImage(string fileName, string assetDirectory = "", bool isFullImagePath = false)
		{
			if (string.IsNullOrEmpty(fileName))
			{
				return null;
			}
			if (CustomPictureBox.sImageAssetsDict.ContainsKey(fileName))
			{
				return CustomPictureBox.sImageAssetsDict[fileName].Item1;
			}
			BitmapImage bitmapImage = null;
			if (fileName.IndexOfAny(new char[]
			{
				Path.AltDirectorySeparatorChar,
				Path.DirectorySeparatorChar
			}) != -1)
			{
				if (!isFullImagePath)
				{
					Logger.Warning("Full image path not marked false for image: " + fileName);
				}
				bitmapImage = CustomPictureBox.BitmapFromPath(fileName);
			}
			else if (isFullImagePath)
			{
				Logger.Warning("Full image path marked true for image: " + fileName);
			}
			if (bitmapImage == null)
			{
				if (string.IsNullOrEmpty(assetDirectory))
				{
					assetDirectory = CustomPictureBox.AssetsDir;
				}
				bitmapImage = CustomPictureBox.BitmapFromPath(Path.Combine(assetDirectory, Path.GetFileNameWithoutExtension(fileName) + ".png"));
				if (bitmapImage == null)
				{
					bitmapImage = CustomPictureBox.BitmapFromPath(Path.Combine(assetDirectory, fileName));
					if (bitmapImage == null)
					{
						bitmapImage = CustomPictureBox.BitmapFromPath(Path.Combine(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets"), Path.GetFileNameWithoutExtension(fileName) + ".png"));
					}
				}
			}
			CustomPictureBox.sImageAssetsDict.Add(fileName, new Tuple<BitmapImage, bool>(bitmapImage, isFullImagePath));
			if (bitmapImage == null)
			{
				Logger.Warning("Returning a null image for {0}", new object[]
				{
					fileName
				});
			}
			return bitmapImage;
		}

		// Token: 0x06000B53 RID: 2899 RVA: 0x00029D40 File Offset: 0x00027F40
		private static BitmapImage BitmapFromPath(string path)
		{
			BitmapImage bitmapImage = null;
			if (File.Exists(path))
			{
				bitmapImage = new BitmapImage();
				FileStream fileStream = File.OpenRead(path);
				bitmapImage.BeginInit();
				bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
				bitmapImage.StreamSource = fileStream;
				bitmapImage.EndInit();
				fileStream.Close();
				fileStream.Dispose();
			}
			return bitmapImage;
		}

		// Token: 0x06000B54 RID: 2900 RVA: 0x00029D8C File Offset: 0x00027F8C
		public static void SetBitmapImage(Image image, string fileName, bool isFullImagePath = false)
		{
			BitmapImage bitmapImage = CustomPictureBox.GetBitmapImage(fileName, "", isFullImagePath);
			if (bitmapImage != null)
			{
				bitmapImage.Freeze();
				BlueStacksUIBinding.Bind(image, Image.SourceProperty, fileName);
				if (image is CustomPictureBox)
				{
					CustomPictureBox customPictureBox = image as CustomPictureBox;
					customPictureBox.BitmapImage = bitmapImage;
					if (customPictureBox.IsAlwaysHalfSize)
					{
						customPictureBox.maxSize = new Point(customPictureBox.MaxWidth, customPictureBox.MaxHeight);
						customPictureBox.MaxWidth = bitmapImage.Width / 2.0;
						customPictureBox.MaxHeight = bitmapImage.Height / 2.0;
					}
					else if (customPictureBox.maxSize != default(Point))
					{
						customPictureBox.MaxWidth = customPictureBox.maxSize.X;
						customPictureBox.MaxHeight = customPictureBox.maxSize.Y;
					}
				}
			}
		}

		// Token: 0x06000B55 RID: 2901 RVA: 0x00029E60 File Offset: 0x00028060
		private void CustomPictureBox_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			if (base.RenderTransform != null)
			{
				RotateTransform rotateTransform = base.RenderTransform as RotateTransform;
				if (rotateTransform != null)
				{
					rotateTransform.CenterX = base.ActualWidth / 2.0;
					rotateTransform.CenterY = base.ActualHeight / 2.0;
				}
			}
		}

		// Token: 0x06000B56 RID: 2902 RVA: 0x00029EB0 File Offset: 0x000280B0
		private void CustomPictureBox_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			if (base.IsVisible && this.mIsImageToBeRotated)
			{
				if (this.mStoryBoard == null)
				{
					this.mStoryBoard = new Storyboard();
					this.animation = new DoubleAnimation
					{
						From = new double?(0.0),
						To = new double?((double)360),
						RepeatBehavior = RepeatBehavior.Forever,
						Duration = new Duration(new TimeSpan(0, 0, 1))
					};
					RotateTransform renderTransform = new RotateTransform
					{
						CenterX = base.ActualWidth / 2.0,
						CenterY = base.ActualHeight / 2.0
					};
					base.RenderTransform = renderTransform;
					Storyboard.SetTarget(this.animation, this);
					Storyboard.SetTargetProperty(this.animation, new PropertyPath("(UIElement.RenderTransform).(RotateTransform.Angle)", new object[0]));
					this.mStoryBoard.Children.Add(this.animation);
				}
				this.mStoryBoard.Begin();
				return;
			}
			Storyboard storyboard = this.mStoryBoard;
			if (storyboard == null)
			{
				return;
			}
			storyboard.Pause();
		}

		// Token: 0x1700037C RID: 892
		// (set) Token: 0x06000B57 RID: 2903 RVA: 0x00029FCC File Offset: 0x000281CC
		public bool IsDisabled
		{
			set
			{
				if (value)
				{
					base.MouseEnter -= this.PictureBox_MouseEnter;
					base.MouseLeave -= this.PictureBox_MouseLeave;
					base.MouseDown -= this.PictureBox_MouseDown;
					base.MouseUp -= this.PictureBox_MouseUp;
					base.Opacity = 0.5;
				}
			}
		}

		// Token: 0x06000B58 RID: 2904 RVA: 0x0002A034 File Offset: 0x00028234
		public void ReloadImages()
		{
			CustomPictureBox.sImageAssetsDict.Remove(this.ClickImage);
			CustomPictureBox.sImageAssetsDict.Remove(this.ImageName);
			CustomPictureBox.sImageAssetsDict.Remove(this.HoverImage);
			CustomPictureBox.sImageAssetsDict.Remove(this.SelectedImage);
			CustomPictureBox.sImageAssetsDict.Remove(this.DisabledImage);
			this.SetDefaultImage();
			CustomPictureBox.GCCollectAsync();
		}

		// Token: 0x06000B59 RID: 2905 RVA: 0x0000B520 File Offset: 0x00009720
		private static void GCCollectAsync()
		{
			new Thread(delegate()
			{
				GC.Collect();
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x1700037D RID: 893
		// (get) Token: 0x06000B5A RID: 2906 RVA: 0x0000B552 File Offset: 0x00009752
		// (set) Token: 0x06000B5B RID: 2907 RVA: 0x0000B564 File Offset: 0x00009764
		public bool AllowClickThrough
		{
			get
			{
				return (bool)base.GetValue(CustomPictureBox.AllowClickThroughProperty);
			}
			set
			{
				base.SetValue(CustomPictureBox.AllowClickThroughProperty, value);
			}
		}

		// Token: 0x06000B5C RID: 2908 RVA: 0x0002A0A4 File Offset: 0x000282A4
		protected override HitTestResult HitTestCore(PointHitTestParameters hitTestParameters)
		{
			try
			{
				if (hitTestParameters != null && this.AllowClickThrough)
				{
					Point position = Mouse.GetPosition(this);
					int pixelWidth = ((BitmapSource)base.Source).PixelWidth;
					int pixelHeight = ((BitmapSource)base.Source).PixelHeight;
					double num = position.X * (double)pixelWidth / base.ActualWidth;
					double num2 = position.Y * (double)pixelHeight / base.ActualHeight;
					byte[] array = new byte[4];
					try
					{
						new CroppedBitmap((BitmapSource)base.Source, new Int32Rect((int)num, (int)num2, 1, 1)).CopyPixels(array, 4, 0);
						if ((int)array[3] < RegistryManager.Instance.AdvancedControlTransparencyLevel)
						{
							Logger.Info(string.Format("HitTestCore pixel density at Image location- (X:{0} Y:{1}) is (R:{2} B:{3} G{4} A{5})", new object[]
							{
								num,
								num2,
								array[0],
								array[1],
								array[2],
								array[3]
							}));
							return null;
						}
					}
					catch (Exception)
					{
						Logger.Info(string.Format("Unable to get HitTestCore pixel density at Image location- X:{0} Y:{1}", num, num2));
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Error("HitTestCore: " + ex.Message);
			}
			return base.HitTestCore(hitTestParameters);
		}

		// Token: 0x0400063F RID: 1599
		private Point maxSize;

		// Token: 0x04000640 RID: 1600
		internal BitmapImage BitmapImage;

		// Token: 0x04000641 RID: 1601
		internal DoubleAnimation animation;

		// Token: 0x04000644 RID: 1604
		public static readonly DependencyProperty ImageNameProperty = DependencyProperty.Register("ImageName", typeof(string), typeof(CustomPictureBox), new FrameworkPropertyMetadata("", new PropertyChangedCallback(CustomPictureBox.ImageNameChanged)));

		// Token: 0x04000645 RID: 1605
		public static readonly DependencyProperty IsImageHoverProperty = DependencyProperty.Register("IsImageHover", typeof(bool), typeof(CustomPictureBox), new FrameworkPropertyMetadata(false, new PropertyChangedCallback(CustomPictureBox.IsImageHoverChanged)));

		// Token: 0x04000646 RID: 1606
		public static readonly DependencyProperty IsAlwaysHalfSizeProperty = DependencyProperty.Register("IsAlwaysHalfSize", typeof(bool), typeof(CustomPictureBox), new FrameworkPropertyMetadata(false, new PropertyChangedCallback(CustomPictureBox.IsAlwaysHalfSizeChanged)));

		// Token: 0x04000648 RID: 1608
		public static readonly Dictionary<string, Tuple<BitmapImage, bool>> sImageAssetsDict = new Dictionary<string, Tuple<BitmapImage, bool>>();

		// Token: 0x04000649 RID: 1609
		private Storyboard mStoryBoard;

		// Token: 0x0400064A RID: 1610
		private bool mIsImageToBeRotated;

		// Token: 0x0400064B RID: 1611
		public static readonly DependencyProperty AllowClickThroughProperty = DependencyProperty.Register("AllowClickThrough", typeof(bool), typeof(CustomPictureBox), new FrameworkPropertyMetadata(false));

		// Token: 0x02000152 RID: 338
		public enum State
		{
			// Token: 0x0400064D RID: 1613
			normal,
			// Token: 0x0400064E RID: 1614
			disabled
		}
	}
}
