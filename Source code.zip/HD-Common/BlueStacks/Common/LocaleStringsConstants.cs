﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000BB RID: 187
	public static class LocaleStringsConstants
	{
		// Token: 0x04000274 RID: 628
		public const string DefaultExitOption = "STRING_CLOSE_CURRENT_INSTANCE";

		// Token: 0x04000275 RID: 629
		public static readonly string[] ExitOptions = new string[]
		{
			"STRING_CLOSE_CURRENT_INSTANCE",
			"STRING_CLOSE_ALL_RUNNING_INSTANCES"
		};

		// Token: 0x04000276 RID: 630
		public static readonly string[] RestartOptions = new string[]
		{
			"STRING_RESTART_CURRENT_INSTANCE"
		};
	}
}
