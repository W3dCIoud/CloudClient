﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace BlueStacks.Common
{
	// Token: 0x020000C8 RID: 200
	public class MacroExceutionSpeedToIndexConverter : IValueConverter
	{
		// Token: 0x060004E9 RID: 1257 RVA: 0x00018C70 File Offset: 0x00016E70
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			double num = System.Convert.ToDouble(value, CultureInfo.InvariantCulture);
			if (num == 0.0)
			{
				return 0;
			}
			return (int)(num / 0.5 - 2.0);
		}

		// Token: 0x060004EA RID: 1258 RVA: 0x00018CB8 File Offset: 0x00016EB8
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			int num = System.Convert.ToInt32(value, CultureInfo.InvariantCulture);
			if (num < 0)
			{
				return 1.0;
			}
			return (double)(num + 2) * 0.5;
		}
	}
}
