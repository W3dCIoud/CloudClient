﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000120 RID: 288
	public enum ButtonColorType
	{
		// Token: 0x04000524 RID: 1316
		MouseOut_BorderBackground,
		// Token: 0x04000525 RID: 1317
		MouseOut_GridBackGround,
		// Token: 0x04000526 RID: 1318
		MouseOut_ForeGround,
		// Token: 0x04000527 RID: 1319
		MouseIn_BorderBackground,
		// Token: 0x04000528 RID: 1320
		MouseIn_GridBackGround,
		// Token: 0x04000529 RID: 1321
		MouseIn_ForeGround,
		// Token: 0x0400052A RID: 1322
		MouseDown_BorderBackground,
		// Token: 0x0400052B RID: 1323
		MouseDown_GridBackGround,
		// Token: 0x0400052C RID: 1324
		MouseDown_ForeGround,
		// Token: 0x0400052D RID: 1325
		Disabled_BorderBackground,
		// Token: 0x0400052E RID: 1326
		Disabled_GridBackGround,
		// Token: 0x0400052F RID: 1327
		Disabled_ForeGround
	}
}
