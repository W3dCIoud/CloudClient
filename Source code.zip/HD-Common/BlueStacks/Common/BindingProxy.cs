﻿using System;
using System.Windows;

namespace BlueStacks.Common
{
	// Token: 0x02000060 RID: 96
	public class BindingProxy : Freezable
	{
		// Token: 0x0600020B RID: 523 RVA: 0x00003016 File Offset: 0x00001216
		protected override Freezable CreateInstanceCore()
		{
			return new BindingProxy();
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x0600020C RID: 524 RVA: 0x0000301D File Offset: 0x0000121D
		// (set) Token: 0x0600020D RID: 525 RVA: 0x0000302A File Offset: 0x0000122A
		public object Data
		{
			get
			{
				return base.GetValue(BindingProxy.DataProperty);
			}
			set
			{
				base.SetValue(BindingProxy.DataProperty, value);
			}
		}

		// Token: 0x040000FC RID: 252
		public static readonly DependencyProperty DataProperty = DependencyProperty.Register("Data", typeof(object), typeof(BindingProxy), new PropertyMetadata(null));
	}
}
