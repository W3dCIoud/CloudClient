﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001F3 RID: 499
	public enum GetAncestorFlags
	{
		// Token: 0x04000C24 RID: 3108
		GetParent = 1,
		// Token: 0x04000C25 RID: 3109
		GetRoot,
		// Token: 0x04000C26 RID: 3110
		GetRootOwner
	}
}
