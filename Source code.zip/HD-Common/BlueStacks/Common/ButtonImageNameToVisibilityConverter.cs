﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace BlueStacks.Common
{
	// Token: 0x02000088 RID: 136
	public class ButtonImageNameToVisibilityConverter : IValueConverter
	{
		// Token: 0x06000364 RID: 868 RVA: 0x00003E15 File Offset: 0x00002015
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return string.IsNullOrEmpty((string)value) ? Visibility.Collapsed : Visibility.Visible;
		}

		// Token: 0x06000365 RID: 869 RVA: 0x00002FA6 File Offset: 0x000011A6
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return Binding.DoNothing;
		}
	}
}
