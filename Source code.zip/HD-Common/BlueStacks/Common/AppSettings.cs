﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace BlueStacks.Common
{
	// Token: 0x02000054 RID: 84
	[Serializable]
	public class AppSettings
	{
		// Token: 0x1700008D RID: 141
		// (get) Token: 0x060001DB RID: 475 RVA: 0x00002E27 File Offset: 0x00001027
		// (set) Token: 0x060001DC RID: 476 RVA: 0x00002E2F File Offset: 0x0000102F
		[JsonProperty("IsKeymappingTooltipShown")]
		public bool IsKeymappingTooltipShown
		{
			get
			{
				return this.mIsKeymappingTooltipShown;
			}
			set
			{
				this.mIsKeymappingTooltipShown = value;
				AppConfigurationManager.Save();
			}
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x060001DD RID: 477 RVA: 0x00002E3D File Offset: 0x0000103D
		// (set) Token: 0x060001DE RID: 478 RVA: 0x00002E45 File Offset: 0x00001045
		[JsonProperty("IsDefaultSchemeRecorded")]
		public bool IsDefaultSchemeRecorded
		{
			get
			{
				return this.mIsDefaultSchemeRecorded;
			}
			set
			{
				this.mIsDefaultSchemeRecorded = value;
				AppConfigurationManager.Save();
			}
		}

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x060001DF RID: 479 RVA: 0x00002E53 File Offset: 0x00001053
		// (set) Token: 0x060001E0 RID: 480 RVA: 0x00002E5B File Offset: 0x0000105B
		[JsonProperty("IsAppOnboardingCompleted")]
		public bool IsAppOnboardingCompleted
		{
			get
			{
				return this.mIsAppOnboardingCompleted;
			}
			set
			{
				this.mIsAppOnboardingCompleted = value;
				AppConfigurationManager.Save();
			}
		}

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x060001E1 RID: 481 RVA: 0x00002E69 File Offset: 0x00001069
		// (set) Token: 0x060001E2 RID: 482 RVA: 0x00002E71 File Offset: 0x00001071
		[JsonProperty("IsGeneralAppOnBoardingCompleted")]
		public bool IsGeneralAppOnBoardingCompleted
		{
			get
			{
				return this.mIsGeneralAppOnBoardingCompleted;
			}
			set
			{
				this.mIsGeneralAppOnBoardingCompleted = value;
				AppConfigurationManager.Save();
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x060001E3 RID: 483 RVA: 0x00002E7F File Offset: 0x0000107F
		// (set) Token: 0x060001E4 RID: 484 RVA: 0x00002E87 File Offset: 0x00001087
		[JsonProperty("IsCloseGuidanceOnboardingCompleted")]
		public bool IsCloseGuidanceOnboardingCompleted
		{
			get
			{
				return this.mIsCloseGuidanceOnboardingCompleted;
			}
			set
			{
				this.mIsCloseGuidanceOnboardingCompleted = value;
				AppConfigurationManager.Save();
			}
		}

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x060001E5 RID: 485 RVA: 0x00002E95 File Offset: 0x00001095
		// (set) Token: 0x060001E6 RID: 486 RVA: 0x00002E9D File Offset: 0x0000109D
		[JsonExtensionData]
		public IDictionary<string, object> ExtraData { get; set; }

		// Token: 0x040000BB RID: 187
		private bool mIsKeymappingTooltipShown;

		// Token: 0x040000BC RID: 188
		private bool mIsDefaultSchemeRecorded;

		// Token: 0x040000BD RID: 189
		private bool mIsAppOnboardingCompleted = true;

		// Token: 0x040000BE RID: 190
		private bool mIsGeneralAppOnBoardingCompleted = true;

		// Token: 0x040000BF RID: 191
		private bool mIsCloseGuidanceOnboardingCompleted = true;
	}
}
