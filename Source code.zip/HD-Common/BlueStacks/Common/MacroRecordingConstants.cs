﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000D8 RID: 216
	public static class MacroRecordingConstants
	{
		// Token: 0x04000318 RID: 792
		public const int LoopCount = 1;

		// Token: 0x04000319 RID: 793
		public const int DelayNextScript = 0;

		// Token: 0x0400031A RID: 794
		public const int LoopInterval = 0;

		// Token: 0x0400031B RID: 795
		public const double Acceleration = 1.0;
	}
}
