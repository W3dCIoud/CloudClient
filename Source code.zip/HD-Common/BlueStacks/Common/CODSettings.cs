﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000D6 RID: 214
	public static class CODSettings
	{
		// Token: 0x04000306 RID: 774
		public const string Resolution720p = "720";

		// Token: 0x04000307 RID: 775
		public const string Resolution1080p = "1080";

		// Token: 0x04000308 RID: 776
		public const string Resolution1440p = "1440";

		// Token: 0x04000309 RID: 777
		public const string Resolution2160p = "2160";

		// Token: 0x0400030A RID: 778
		public const string QualityAuto = "-1";

		// Token: 0x0400030B RID: 779
		public const string QualitySmooth = "0";

		// Token: 0x0400030C RID: 780
		public const string QualityBalanced = "1";

		// Token: 0x0400030D RID: 781
		public const string QualityHD = "2";

		// Token: 0x0400030E RID: 782
		public const string FrameRateLevelOn = "1";
	}
}
