﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200006E RID: 110
	public class AppUninstalledEventArgs : BrowserEventArgs
	{
		// Token: 0x0600023D RID: 573 RVA: 0x000032A4 File Offset: 0x000014A4
		public AppUninstalledEventArgs(BrowserControlTags tag, string packageName, string vmName) : base(tag, packageName, vmName)
		{
		}
	}
}
