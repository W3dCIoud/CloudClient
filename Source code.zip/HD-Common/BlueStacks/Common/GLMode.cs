﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001A8 RID: 424
	public enum GLMode
	{
		// Token: 0x040007A4 RID: 1956
		PGA = 1,
		// Token: 0x040007A5 RID: 1957
		AGA
	}
}
