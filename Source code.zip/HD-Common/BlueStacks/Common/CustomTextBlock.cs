﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x02000082 RID: 130
	public class CustomTextBlock : TextBlock, IComponentConnector
	{
		// Token: 0x06000337 RID: 823 RVA: 0x00003C26 File Offset: 0x00001E26
		public CustomTextBlock()
		{
			this.InitializeComponent();
		}

		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x06000338 RID: 824 RVA: 0x00003C34 File Offset: 0x00001E34
		// (set) Token: 0x06000339 RID: 825 RVA: 0x00003C46 File Offset: 0x00001E46
		public bool ForcedTooltip
		{
			get
			{
				return (bool)base.GetValue(CustomTextBlock.ForcedTooltipProperty);
			}
			set
			{
				base.SetValue(CustomTextBlock.ForcedTooltipProperty, value);
			}
		}

		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x0600033A RID: 826 RVA: 0x00003C59 File Offset: 0x00001E59
		// (set) Token: 0x0600033B RID: 827 RVA: 0x00003C6B File Offset: 0x00001E6B
		public bool SetToolTip
		{
			get
			{
				return (bool)base.GetValue(CustomTextBlock.SetToolTipProperty);
			}
			set
			{
				base.SetValue(CustomTextBlock.SetToolTipProperty, value);
			}
		}

		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x0600033C RID: 828 RVA: 0x00003C59 File Offset: 0x00001E59
		// (set) Token: 0x0600033D RID: 829 RVA: 0x00003C6B File Offset: 0x00001E6B
		public bool HoverForegroundProperty
		{
			get
			{
				return (bool)base.GetValue(CustomTextBlock.SetToolTipProperty);
			}
			set
			{
				base.SetValue(CustomTextBlock.SetToolTipProperty, value);
			}
		}

		// Token: 0x0600033E RID: 830 RVA: 0x00003C7E File Offset: 0x00001E7E
		private static void OnSetToolTipChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			(d as CustomTextBlock).OnSetToolTipChanged(e);
		}

		// Token: 0x0600033F RID: 831 RVA: 0x00014604 File Offset: 0x00012804
		private void OnSetToolTipChanged(DependencyPropertyChangedEventArgs args)
		{
			if (!this.ForcedTooltip)
			{
				bool flag;
				if (bool.TryParse(args.NewValue.ToString(), out flag) && flag && this.IsTextTrimmed())
				{
					ToolTipService.SetIsEnabled(this, true);
					if (base.ToolTip == null)
					{
						base.ToolTip = base.Text;
						return;
					}
				}
				else
				{
					ToolTipService.SetIsEnabled(this, false);
				}
			}
		}

		// Token: 0x06000340 RID: 832 RVA: 0x0001465C File Offset: 0x0001285C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/customtextblock.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000341 RID: 833 RVA: 0x00003C8C File Offset: 0x00001E8C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			this._contentLoaded = true;
		}

		// Token: 0x0400018E RID: 398
		public static readonly DependencyProperty SetToolTipProperty = DependencyProperty.Register("SetToolTip", typeof(bool), typeof(CustomTextBlock), new PropertyMetadata(false, new PropertyChangedCallback(CustomTextBlock.OnSetToolTipChanged)));

		// Token: 0x0400018F RID: 399
		public static readonly DependencyProperty MouseOverForegroundChangedProperty = DependencyProperty.RegisterAttached("HoverForegroundProperty", typeof(bool), typeof(CustomTextBlock), new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.AffectsRender));

		// Token: 0x04000190 RID: 400
		public static readonly DependencyProperty ForcedTooltipProperty = DependencyProperty.Register("ForcedTooltip", typeof(bool), typeof(CustomButton), new PropertyMetadata(false));

		// Token: 0x04000191 RID: 401
		private bool _contentLoaded;
	}
}
