﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000DE RID: 222
	public enum CtrlType
	{
		// Token: 0x04000339 RID: 825
		CTRL_C_EVENT,
		// Token: 0x0400033A RID: 826
		CTRL_BREAK_EVENT,
		// Token: 0x0400033B RID: 827
		CTRL_CLOSE_EVENT,
		// Token: 0x0400033C RID: 828
		CTRL_LOGOFF_EVENT = 5,
		// Token: 0x0400033D RID: 829
		CTRL_SHUTDOWN_EVENT
	}
}
