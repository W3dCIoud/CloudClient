﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x02000077 RID: 119
	public class DisplaySettingsBase : System.Windows.Controls.UserControl, INotifyPropertyChanged, IComponentConnector
	{
		// Token: 0x14000004 RID: 4
		// (add) Token: 0x06000272 RID: 626 RVA: 0x00012878 File Offset: 0x00010A78
		// (remove) Token: 0x06000273 RID: 627 RVA: 0x000128B0 File Offset: 0x00010AB0
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06000274 RID: 628 RVA: 0x000034C9 File Offset: 0x000016C9
		public void OnPropertyChanged(string name)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(name));
			}
			CommandManager.InvalidateRequerySuggested();
		}

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x06000275 RID: 629 RVA: 0x000034E8 File Offset: 0x000016E8
		// (set) Token: 0x06000276 RID: 630 RVA: 0x000034F0 File Offset: 0x000016F0
		public DisplaySettingsBaseModel InitialDisplaySettingsModel { get; set; }

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x06000277 RID: 631 RVA: 0x000034F9 File Offset: 0x000016F9
		// (set) Token: 0x06000278 RID: 632 RVA: 0x00003501 File Offset: 0x00001701
		public DisplaySettingsBaseModel CurrentDisplaySettingsModel
		{
			get
			{
				return this.mCurrentDisplaySettingsModel;
			}
			set
			{
				this.mCurrentDisplaySettingsModel = value;
				this.OnPropertyChanged("CurrentDisplaySettingsModel");
			}
		}

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x06000279 RID: 633 RVA: 0x00003515 File Offset: 0x00001715
		// (set) Token: 0x0600027A RID: 634 RVA: 0x0000351D File Offset: 0x0000171D
		public bool IsOpenedFromMultiInstance { get; set; }

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x0600027B RID: 635 RVA: 0x00003526 File Offset: 0x00001726
		// (set) Token: 0x0600027C RID: 636 RVA: 0x0000352E File Offset: 0x0000172E
		public string VmName { get; set; } = "Android";

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x0600027D RID: 637 RVA: 0x00003537 File Offset: 0x00001737
		// (set) Token: 0x0600027E RID: 638 RVA: 0x0000353F File Offset: 0x0000173F
		public ICommand SaveCommand { get; set; }

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x0600027F RID: 639 RVA: 0x00003548 File Offset: 0x00001748
		// (set) Token: 0x06000280 RID: 640 RVA: 0x00003550 File Offset: 0x00001750
		public int MinResolutionWidth { get; set; } = 540;

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x06000281 RID: 641 RVA: 0x00003559 File Offset: 0x00001759
		// (set) Token: 0x06000282 RID: 642 RVA: 0x00003561 File Offset: 0x00001761
		public int MinResolutionHeight { get; set; } = 540;

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x06000283 RID: 643 RVA: 0x0000356A File Offset: 0x0000176A
		// (set) Token: 0x06000284 RID: 644 RVA: 0x00003572 File Offset: 0x00001772
		public int MaxResolutionWidth { get; set; } = 2560;

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x06000285 RID: 645 RVA: 0x0000357B File Offset: 0x0000177B
		// (set) Token: 0x06000286 RID: 646 RVA: 0x00003583 File Offset: 0x00001783
		public int MaxResolutionHeight { get; set; } = 2560;

		// Token: 0x06000287 RID: 647 RVA: 0x0000358C File Offset: 0x0000178C
		protected virtual void Save(object param)
		{
		}

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x06000288 RID: 648 RVA: 0x0000358E File Offset: 0x0000178E
		// (set) Token: 0x06000289 RID: 649 RVA: 0x00003596 File Offset: 0x00001796
		public Window Owner { get; private set; }

		// Token: 0x0600028A RID: 650 RVA: 0x000128E8 File Offset: 0x00010AE8
		public DisplaySettingsBase(Window owner, string vmName)
		{
			this.Owner = owner;
			this.VmName = vmName;
			this.Init();
			this.LoadViewFromUri("/HD-Common;component/Settings/DisplaySettingBase/DisplaySettingsBase.xaml");
			base.Visibility = Visibility.Hidden;
		}

		// Token: 0x0600028B RID: 651 RVA: 0x00012958 File Offset: 0x00010B58
		public void Init()
		{
			this.InitialDisplaySettingsModel = new DisplaySettingsBaseModel(Utils.GetDpiFromBootParameters(RegistryManager.Instance.Guest[this.VmName].BootParameters), RegistryManager.Instance.Guest[this.VmName].GuestWidth, RegistryManager.Instance.Guest[this.VmName].GuestHeight);
			this.CurrentDisplaySettingsModel = this.InitialDisplaySettingsModel.DeepCopy<DisplaySettingsBaseModel>();
			this.SaveCommand = new RelayCommand2(new Func<object, bool>(this.CanSave), new Action<object>(this.Save));
			this.MaxResolutionWidth = Math.Max(this.MaxResolutionWidth, Screen.PrimaryScreen.Bounds.Width);
			this.MaxResolutionHeight = Math.Max(this.MaxResolutionHeight, Screen.PrimaryScreen.Bounds.Height);
		}

		// Token: 0x0600028C RID: 652 RVA: 0x0000359F File Offset: 0x0000179F
		private bool CanSave(object _1)
		{
			return this.IsDirty() && this.IsValid();
		}

		// Token: 0x0600028D RID: 653 RVA: 0x00012A40 File Offset: 0x00010C40
		public bool IsDirty()
		{
			return this.InitialDisplaySettingsModel.ResolutionType.ResolutionWidth != this.CurrentDisplaySettingsModel.ResolutionType.ResolutionWidth || this.InitialDisplaySettingsModel.ResolutionType.ResolutionHeight != this.CurrentDisplaySettingsModel.ResolutionType.ResolutionHeight || this.CurrentDisplaySettingsModel.Dpi != this.InitialDisplaySettingsModel.Dpi;
		}

		// Token: 0x0600028E RID: 654 RVA: 0x000035B1 File Offset: 0x000017B1
		public bool IsValid()
		{
			return !Validation.GetHasError(this.CustomResolutionHeight) && !Validation.GetHasError(this.CustomResolutionWidth);
		}

		// Token: 0x0600028F RID: 655 RVA: 0x00012AB0 File Offset: 0x00010CB0
		protected void SaveDisplaySetting()
		{
			Logger.Info("Saving Display setting");
			Utils.SetDPIInBootParameters(RegistryManager.Instance.Guest[this.VmName].BootParameters, this.CurrentDisplaySettingsModel.Dpi, this.VmName);
			RegistryManager.Instance.Guest[this.VmName].GuestWidth = this.CurrentDisplaySettingsModel.ResolutionType.ResolutionWidth;
			RegistryManager.Instance.Guest[this.VmName].GuestHeight = this.CurrentDisplaySettingsModel.ResolutionType.ResolutionHeight;
			Stats.SendMiscellaneousStatsAsync("Setting-save", RegistryManager.Instance.UserGuid, RegistryManager.Instance.ClientVersion, "Display-Settings", "", null, this.VmName, null, null, "Android", 0);
			this.InitialDisplaySettingsModel.InitDisplaySettingsBaseModel(Utils.GetDpiFromBootParameters(RegistryManager.Instance.Guest[this.VmName].BootParameters), RegistryManager.Instance.Guest[this.VmName].GuestWidth, RegistryManager.Instance.Guest[this.VmName].GuestHeight);
		}

		// Token: 0x06000290 RID: 656 RVA: 0x000035D0 File Offset: 0x000017D0
		public void DiscardCurrentChangingModel()
		{
			this.CurrentDisplaySettingsModel = this.InitialDisplaySettingsModel.DeepCopy<DisplaySettingsBaseModel>();
		}

		// Token: 0x06000291 RID: 657 RVA: 0x00012BE0 File Offset: 0x00010DE0
		protected void AddToastPopup(string message)
		{
			try
			{
				if (this.mToastPopup == null)
				{
					this.mToastPopup = new CustomToastPopupControl(this.Owner);
				}
				this.mToastPopup.Init(this.Owner, message, null, null, System.Windows.HorizontalAlignment.Center, VerticalAlignment.Bottom, null, 12, null, null, false);
				this.mToastPopup.ShowPopup(1.3);
			}
			catch (Exception ex)
			{
				Logger.Error("Exception in showing toast popup: " + ex.ToString());
			}
		}

		// Token: 0x06000292 RID: 658 RVA: 0x00012C70 File Offset: 0x00010E70
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/settings/displaysettingbase/displaysettingsbase.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x06000293 RID: 659 RVA: 0x000035E3 File Offset: 0x000017E3
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x06000294 RID: 660 RVA: 0x00012CA0 File Offset: 0x00010EA0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mOrientation = (CustomComboBox)target;
				return;
			case 2:
				this.mRadioButtons = (Grid)target;
				return;
			case 3:
				this.mResolution960x540 = (CustomRadioButton)target;
				return;
			case 4:
				this.mResolution1280x720 = (CustomRadioButton)target;
				return;
			case 5:
				this.mResolution1600x900 = (CustomRadioButton)target;
				return;
			case 6:
				this.mResolution1920x1080 = (CustomRadioButton)target;
				return;
			case 7:
				this.mResolution2560x1440 = (CustomRadioButton)target;
				return;
			case 8:
				this.CustomResolutionTextBoxes = (Grid)target;
				return;
			case 9:
				this.CustomResolutionWidth = (CustomTextBox)target;
				return;
			case 10:
				this.CustomResolutionHeight = (CustomTextBox)target;
				return;
			case 11:
				this.mDpi160 = (CustomRadioButton)target;
				return;
			case 12:
				this.mDpi240 = (CustomRadioButton)target;
				return;
			case 13:
				this.mDpi320 = (CustomRadioButton)target;
				return;
			case 14:
				this.mInfoIcon = (CustomPictureBox)target;
				return;
			case 15:
				this.mSaveButton = (CustomButton)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x0400011E RID: 286
		private DisplaySettingsBaseModel mCurrentDisplaySettingsModel;

		// Token: 0x04000127 RID: 295
		private CustomToastPopupControl mToastPopup;

		// Token: 0x04000128 RID: 296
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomComboBox mOrientation;

		// Token: 0x04000129 RID: 297
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid mRadioButtons;

		// Token: 0x0400012A RID: 298
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mResolution960x540;

		// Token: 0x0400012B RID: 299
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mResolution1280x720;

		// Token: 0x0400012C RID: 300
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mResolution1600x900;

		// Token: 0x0400012D RID: 301
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mResolution1920x1080;

		// Token: 0x0400012E RID: 302
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mResolution2560x1440;

		// Token: 0x0400012F RID: 303
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Grid CustomResolutionTextBoxes;

		// Token: 0x04000130 RID: 304
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox CustomResolutionWidth;

		// Token: 0x04000131 RID: 305
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomTextBox CustomResolutionHeight;

		// Token: 0x04000132 RID: 306
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mDpi160;

		// Token: 0x04000133 RID: 307
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mDpi240;

		// Token: 0x04000134 RID: 308
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomRadioButton mDpi320;

		// Token: 0x04000135 RID: 309
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mInfoIcon;

		// Token: 0x04000136 RID: 310
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomButton mSaveButton;

		// Token: 0x04000137 RID: 311
		private bool _contentLoaded;
	}
}
