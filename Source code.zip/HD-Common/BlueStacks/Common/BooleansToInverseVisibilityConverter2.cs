﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace BlueStacks.Common
{
	// Token: 0x02000055 RID: 85
	public class BooleansToInverseVisibilityConverter2 : IValueConverter
	{
		// Token: 0x060001E8 RID: 488 RVA: 0x00010EBC File Offset: 0x0000F0BC
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			bool flag = false;
			if (value is bool)
			{
				flag = (bool)value;
			}
			else if (value is bool?)
			{
				bool? flag2 = (bool?)value;
				flag = (flag2 != null && flag2.Value);
			}
			return (!flag) ? Visibility.Visible : Visibility.Collapsed;
		}

		// Token: 0x060001E9 RID: 489 RVA: 0x00002EC3 File Offset: 0x000010C3
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			if (value is Visibility)
			{
				return (Visibility)value > Visibility.Visible;
			}
			return true;
		}
	}
}
