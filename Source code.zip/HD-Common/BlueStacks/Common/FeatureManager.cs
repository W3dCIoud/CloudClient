﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Xml;
using System.Xml.Serialization;

namespace BlueStacks.Common
{
	// Token: 0x020000EF RID: 239
	public class FeatureManager
	{
		// Token: 0x170001B6 RID: 438
		// (get) Token: 0x060006A0 RID: 1696 RVA: 0x0002211C File Offset: 0x0002031C
		public static FeatureManager Instance
		{
			get
			{
				if (FeatureManager.sInstance == null)
				{
					object obj = FeatureManager.syncRoot;
					lock (obj)
					{
						if (FeatureManager.sInstance == null)
						{
							FeatureManager.sInstance = new FeatureManager();
							FeatureManager.Init(true);
						}
					}
				}
				return FeatureManager.sInstance;
			}
		}

		// Token: 0x060006A1 RID: 1697 RVA: 0x0002217C File Offset: 0x0002037C
		public static void Init(bool isAsync = true)
		{
			try
			{
				string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
				FeatureManager.sFilePath = Path.Combine(RegistryManager.Instance.ClientInstallDir, "bst_config");
				if (RegistryManager.Instance.UpdateBstConfig)
				{
					FeatureManager.DownloadBstConfig(isAsync);
				}
				else if (File.Exists(FeatureManager.sFilePath))
				{
					Logger.Info("Loading cfg from : " + FeatureManager.sFilePath);
					FeatureManager.LoadFile(FeatureManager.sFilePath, true);
				}
				else
				{
					Logger.Info("bst_config not found. Trying to fetch new file from cloud.");
					FeatureManager.DownloadBstConfig(isAsync);
				}
			}
			catch (Exception ex)
			{
				Logger.Info("Error loading config" + ex.ToString());
			}
		}

		// Token: 0x060006A2 RID: 1698 RVA: 0x0000605D File Offset: 0x0000425D
		private static void DownloadBstConfig(bool isAsync)
		{
			FeatureManager.SetDefaultSettings();
			if (isAsync)
			{
				FeatureManager.DownloadFileAsync();
				return;
			}
			FeatureManager.DownloadFile();
		}

		// Token: 0x060006A3 RID: 1699 RVA: 0x00006072 File Offset: 0x00004272
		private static void DownloadFileAsync()
		{
			new Thread(delegate()
			{
				FeatureManager.DownloadFile();
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x060006A4 RID: 1700 RVA: 0x00022228 File Offset: 0x00020428
		private static void DownloadFile()
		{
			try
			{
				string urlWithParams = WebHelper.GetUrlWithParams(WebHelper.GetServerHost() + "/serve_config_file");
				string directoryName = Path.GetDirectoryName(FeatureManager.sFilePath);
				if (!Directory.Exists(directoryName))
				{
					Logger.Info("--------- For debugging -------. FeatureManager was used before creating directory. This should not happen.");
					Directory.CreateDirectory(directoryName);
				}
				using (WebClient webClient = new WebClient())
				{
					webClient.DownloadFile(urlWithParams, FeatureManager.sFilePath);
					RegistryManager.Instance.UpdateBstConfig = false;
				}
			}
			catch (Exception ex)
			{
				Logger.Warning("Failed to download bst_config file. Err: " + ex.ToString());
				RegistryManager.Instance.UpdateBstConfig = true;
				return;
			}
			FeatureManager.LoadFile(FeatureManager.sFilePath, false);
		}

		// Token: 0x060006A5 RID: 1701 RVA: 0x000060A4 File Offset: 0x000042A4
		private static void SetDefaultSettings()
		{
			if (FeatureManager.sInstance == null)
			{
				FeatureManager.sInstance = new FeatureManager();
			}
		}

		// Token: 0x060006A6 RID: 1702 RVA: 0x000222E4 File Offset: 0x000204E4
		public static void LoadFile(string filePath, bool retryOnError = true)
		{
			try
			{
				using (XmlReader xmlReader = XmlReader.Create(File.OpenRead(filePath)))
				{
					Logger.Info("Loading Oem Settings from " + filePath);
					FeatureManager.sInstance = (FeatureManager)new XmlSerializer(typeof(FeatureManager)).Deserialize(xmlReader);
				}
			}
			catch (Exception)
			{
				FeatureManager.SetDefaultSettings();
				try
				{
					if (retryOnError)
					{
						if (File.Exists(filePath))
						{
							File.Delete(filePath);
						}
						FeatureManager.DownloadFileAsync();
					}
				}
				catch (Exception)
				{
				}
			}
		}

		// Token: 0x060006A7 RID: 1703 RVA: 0x00022388 File Offset: 0x00020588
		internal void Save()
		{
			try
			{
				using (XmlTextWriter xmlTextWriter = new XmlTextWriter(FeatureManager.sFilePath, Encoding.UTF8))
				{
					xmlTextWriter.Formatting = Formatting.Indented;
					new XmlSerializer(typeof(FeatureManager)).Serialize(xmlTextWriter, FeatureManager.sInstance);
					xmlTextWriter.Flush();
				}
			}
			catch (Exception ex)
			{
				Logger.Info(ex.ToString());
			}
		}

		// Token: 0x170001B7 RID: 439
		// (get) Token: 0x060006A8 RID: 1704 RVA: 0x000060BB File Offset: 0x000042BB
		// (set) Token: 0x060006A9 RID: 1705 RVA: 0x000060C3 File Offset: 0x000042C3
		public bool IsBTVEnabled { get; set; }

		// Token: 0x170001B8 RID: 440
		// (get) Token: 0x060006AA RID: 1706 RVA: 0x000060CC File Offset: 0x000042CC
		// (set) Token: 0x060006AB RID: 1707 RVA: 0x000060D4 File Offset: 0x000042D4
		public bool IsWallpaperChangeDisabled { get; set; }

		// Token: 0x170001B9 RID: 441
		// (get) Token: 0x060006AC RID: 1708 RVA: 0x000060DD File Offset: 0x000042DD
		// (set) Token: 0x060006AD RID: 1709 RVA: 0x000060E5 File Offset: 0x000042E5
		public bool IsCreateBrowserOnStart { get; set; }

		// Token: 0x170001BA RID: 442
		// (get) Token: 0x060006AE RID: 1710 RVA: 0x000060EE File Offset: 0x000042EE
		// (set) Token: 0x060006AF RID: 1711 RVA: 0x000060F6 File Offset: 0x000042F6
		public bool IsOpenActivityFromAccountIcon { get; set; }

		// Token: 0x170001BB RID: 443
		// (get) Token: 0x060006B0 RID: 1712 RVA: 0x000060FF File Offset: 0x000042FF
		// (set) Token: 0x060006B1 RID: 1713 RVA: 0x00006107 File Offset: 0x00004307
		public bool IsBrowserKilledOnTabSwitch { get; set; }

		// Token: 0x170001BC RID: 444
		// (get) Token: 0x060006B2 RID: 1714 RVA: 0x00006110 File Offset: 0x00004310
		// (set) Token: 0x060006B3 RID: 1715 RVA: 0x00006118 File Offset: 0x00004318
		public bool IsPromotionDisabled { get; set; }

		// Token: 0x170001BD RID: 445
		// (get) Token: 0x060006B4 RID: 1716 RVA: 0x00006121 File Offset: 0x00004321
		// (set) Token: 0x060006B5 RID: 1717 RVA: 0x00006129 File Offset: 0x00004329
		public bool IsGuidBackUpEnable { get; set; } = true;

		// Token: 0x170001BE RID: 446
		// (get) Token: 0x060006B6 RID: 1718 RVA: 0x00006132 File Offset: 0x00004332
		// (set) Token: 0x060006B7 RID: 1719 RVA: 0x0000613A File Offset: 0x0000433A
		public bool IsCustomUIForDMMSandbox { get; set; }

		// Token: 0x170001BF RID: 447
		// (get) Token: 0x060006B8 RID: 1720 RVA: 0x00006143 File Offset: 0x00004343
		// (set) Token: 0x060006B9 RID: 1721 RVA: 0x0000614B File Offset: 0x0000434B
		public bool IsCustomUIForDMM { get; set; }

		// Token: 0x170001C0 RID: 448
		// (get) Token: 0x060006BA RID: 1722 RVA: 0x00006154 File Offset: 0x00004354
		// (set) Token: 0x060006BB RID: 1723 RVA: 0x0000615C File Offset: 0x0000435C
		public bool IsThemeEnabled { get; set; } = true;

		// Token: 0x170001C1 RID: 449
		// (get) Token: 0x060006BC RID: 1724 RVA: 0x00006165 File Offset: 0x00004365
		// (set) Token: 0x060006BD RID: 1725 RVA: 0x0000616D File Offset: 0x0000436D
		public bool IsSearchBarVisible { get; set; } = true;

		// Token: 0x170001C2 RID: 450
		// (get) Token: 0x060006BE RID: 1726 RVA: 0x00006176 File Offset: 0x00004376
		// (set) Token: 0x060006BF RID: 1727 RVA: 0x0000617E File Offset: 0x0000437E
		public bool IsCustomResolutionInputAllowed { get; set; }

		// Token: 0x170001C3 RID: 451
		// (get) Token: 0x060006C0 RID: 1728 RVA: 0x00006187 File Offset: 0x00004387
		// (set) Token: 0x060006C1 RID: 1729 RVA: 0x0000618F File Offset: 0x0000438F
		public bool ShowBeginnersGuidePreference { get; set; } = true;

		// Token: 0x170001C4 RID: 452
		// (get) Token: 0x060006C2 RID: 1730 RVA: 0x00006198 File Offset: 0x00004398
		// (set) Token: 0x060006C3 RID: 1731 RVA: 0x000061A0 File Offset: 0x000043A0
		public bool IsShowNotificationCentre { get; set; } = true;

		// Token: 0x170001C5 RID: 453
		// (get) Token: 0x060006C4 RID: 1732 RVA: 0x000061A9 File Offset: 0x000043A9
		// (set) Token: 0x060006C5 RID: 1733 RVA: 0x000061B1 File Offset: 0x000043B1
		public bool IsUseWpfTextbox { get; set; }

		// Token: 0x170001C6 RID: 454
		// (get) Token: 0x060006C6 RID: 1734 RVA: 0x000061BA File Offset: 0x000043BA
		// (set) Token: 0x060006C7 RID: 1735 RVA: 0x000061C2 File Offset: 0x000043C2
		public bool IsComboKeysDisabled { get; set; }

		// Token: 0x170001C7 RID: 455
		// (get) Token: 0x060006C8 RID: 1736 RVA: 0x000061CB File Offset: 0x000043CB
		// (set) Token: 0x060006C9 RID: 1737 RVA: 0x000061D3 File Offset: 0x000043D3
		public bool IsMacroRecorderEnabled { get; set; }

		// Token: 0x170001C8 RID: 456
		// (get) Token: 0x060006CA RID: 1738 RVA: 0x000061DC File Offset: 0x000043DC
		// (set) Token: 0x060006CB RID: 1739 RVA: 0x000061E4 File Offset: 0x000043E4
		public bool IsFarmingModeDisabled { get; set; }

		// Token: 0x170001C9 RID: 457
		// (get) Token: 0x060006CC RID: 1740 RVA: 0x000061ED File Offset: 0x000043ED
		// (set) Token: 0x060006CD RID: 1741 RVA: 0x000061F5 File Offset: 0x000043F5
		public bool IsOperationsSyncEnabled { get; set; }

		// Token: 0x170001CA RID: 458
		// (get) Token: 0x060006CE RID: 1742 RVA: 0x000061FE File Offset: 0x000043FE
		// (set) Token: 0x060006CF RID: 1743 RVA: 0x00006206 File Offset: 0x00004406
		public bool IsRotateScreenDisabled { get; set; }

		// Token: 0x170001CB RID: 459
		// (get) Token: 0x060006D0 RID: 1744 RVA: 0x0000620F File Offset: 0x0000440F
		// (set) Token: 0x060006D1 RID: 1745 RVA: 0x00006217 File Offset: 0x00004417
		public bool IsUserAccountBtnEnabled { get; set; } = true;

		// Token: 0x170001CC RID: 460
		// (get) Token: 0x060006D2 RID: 1746 RVA: 0x00006220 File Offset: 0x00004420
		// (set) Token: 0x060006D3 RID: 1747 RVA: 0x00006228 File Offset: 0x00004428
		public bool IsWarningBtnEnabled { get; set; } = true;

		// Token: 0x170001CD RID: 461
		// (get) Token: 0x060006D4 RID: 1748 RVA: 0x00006231 File Offset: 0x00004431
		// (set) Token: 0x060006D5 RID: 1749 RVA: 0x00006239 File Offset: 0x00004439
		public bool IsAppCenterTabVisible { get; set; } = true;

		// Token: 0x170001CE RID: 462
		// (get) Token: 0x060006D6 RID: 1750 RVA: 0x00006242 File Offset: 0x00004442
		// (set) Token: 0x060006D7 RID: 1751 RVA: 0x0000624A File Offset: 0x0000444A
		public bool IsMultiInstanceControlsGridVisible { get; set; } = true;

		// Token: 0x170001CF RID: 463
		// (get) Token: 0x060006D8 RID: 1752 RVA: 0x00006253 File Offset: 0x00004453
		// (set) Token: 0x060006D9 RID: 1753 RVA: 0x0000625B File Offset: 0x0000445B
		public bool IsPromotionFixed { get; set; }

		// Token: 0x170001D0 RID: 464
		// (get) Token: 0x060006DA RID: 1754 RVA: 0x00006264 File Offset: 0x00004464
		// (set) Token: 0x060006DB RID: 1755 RVA: 0x0000626C File Offset: 0x0000446C
		public bool IsShowLanguagePreference { get; set; } = true;

		// Token: 0x170001D1 RID: 465
		// (get) Token: 0x060006DC RID: 1756 RVA: 0x00006275 File Offset: 0x00004475
		// (set) Token: 0x060006DD RID: 1757 RVA: 0x0000627D File Offset: 0x0000447D
		public bool IsShowDesktopShortcutPreference { get; set; } = true;

		// Token: 0x170001D2 RID: 466
		// (get) Token: 0x060006DE RID: 1758 RVA: 0x00006286 File Offset: 0x00004486
		// (set) Token: 0x060006DF RID: 1759 RVA: 0x0000628E File Offset: 0x0000448E
		public bool IsShowGamingSummaryPreference { get; set; } = true;

		// Token: 0x170001D3 RID: 467
		// (get) Token: 0x060006E0 RID: 1760 RVA: 0x00006297 File Offset: 0x00004497
		// (set) Token: 0x060006E1 RID: 1761 RVA: 0x0000629F File Offset: 0x0000449F
		public bool IsShowSpeedUpTips { get; set; } = true;

		// Token: 0x170001D4 RID: 468
		// (get) Token: 0x060006E2 RID: 1762 RVA: 0x000062A8 File Offset: 0x000044A8
		// (set) Token: 0x060006E3 RID: 1763 RVA: 0x000062B0 File Offset: 0x000044B0
		public bool IsShowPostOTSScreen { get; set; } = true;

		// Token: 0x170001D5 RID: 469
		// (get) Token: 0x060006E4 RID: 1764 RVA: 0x000062B9 File Offset: 0x000044B9
		// (set) Token: 0x060006E5 RID: 1765 RVA: 0x000062C1 File Offset: 0x000044C1
		public bool IsShowHelpCenter { get; set; } = true;

		// Token: 0x170001D6 RID: 470
		// (get) Token: 0x060006E6 RID: 1766 RVA: 0x000062CA File Offset: 0x000044CA
		// (set) Token: 0x060006E7 RID: 1767 RVA: 0x000062D2 File Offset: 0x000044D2
		public bool IsAppSettingsAvailable { get; set; } = true;

		// Token: 0x170001D7 RID: 471
		// (get) Token: 0x060006E8 RID: 1768 RVA: 0x000062DB File Offset: 0x000044DB
		// (set) Token: 0x060006E9 RID: 1769 RVA: 0x000062E3 File Offset: 0x000044E3
		public bool IsShowPerformancePreference { get; set; } = true;

		// Token: 0x170001D8 RID: 472
		// (get) Token: 0x060006EA RID: 1770 RVA: 0x000062EC File Offset: 0x000044EC
		// (set) Token: 0x060006EB RID: 1771 RVA: 0x000062F4 File Offset: 0x000044F4
		public bool IsShowDiscordPreference { get; set; } = true;

		// Token: 0x170001D9 RID: 473
		// (get) Token: 0x060006EC RID: 1772 RVA: 0x000062FD File Offset: 0x000044FD
		// (set) Token: 0x060006ED RID: 1773 RVA: 0x00006305 File Offset: 0x00004505
		public bool IsCustomUIForNCSoft { get; set; }

		// Token: 0x170001DA RID: 474
		// (get) Token: 0x060006EE RID: 1774 RVA: 0x0000630E File Offset: 0x0000450E
		// (set) Token: 0x060006EF RID: 1775 RVA: 0x00006316 File Offset: 0x00004516
		public bool AllowADBSettingToggle { get; set; } = true;

		// Token: 0x170001DB RID: 475
		// (get) Token: 0x060006F0 RID: 1776 RVA: 0x0000631F File Offset: 0x0000451F
		// (set) Token: 0x060006F1 RID: 1777 RVA: 0x00006327 File Offset: 0x00004527
		public bool ShowClientOnTopPreference { get; set; } = true;

		// Token: 0x170001DC RID: 476
		// (get) Token: 0x060006F2 RID: 1778 RVA: 0x00006330 File Offset: 0x00004530
		// (set) Token: 0x060006F3 RID: 1779 RVA: 0x00006338 File Offset: 0x00004538
		public bool IsAllowGameRecording { get; set; } = true;

		// Token: 0x170001DD RID: 477
		// (get) Token: 0x060006F4 RID: 1780 RVA: 0x00006341 File Offset: 0x00004541
		// (set) Token: 0x060006F5 RID: 1781 RVA: 0x00006349 File Offset: 0x00004549
		public bool IsShowAppRecommendations { get; set; } = true;

		// Token: 0x170001DE RID: 478
		// (get) Token: 0x060006F6 RID: 1782 RVA: 0x00006352 File Offset: 0x00004552
		// (set) Token: 0x060006F7 RID: 1783 RVA: 0x0000635A File Offset: 0x0000455A
		public bool IsCheckForQuitPopup { get; set; } = true;

		// Token: 0x170001DF RID: 479
		// (get) Token: 0x060006F8 RID: 1784 RVA: 0x00006363 File Offset: 0x00004563
		// (set) Token: 0x060006F9 RID: 1785 RVA: 0x0000636B File Offset: 0x0000456B
		public bool IsCustomCursorEnabled { get; set; }

		// Token: 0x170001E0 RID: 480
		// (get) Token: 0x060006FA RID: 1786 RVA: 0x00006374 File Offset: 0x00004574
		// (set) Token: 0x060006FB RID: 1787 RVA: 0x0000637C File Offset: 0x0000457C
		public bool ForceEnableMacroAndSync { get; set; }

		// Token: 0x170001E1 RID: 481
		// (get) Token: 0x060006FC RID: 1788 RVA: 0x00006385 File Offset: 0x00004585
		// (set) Token: 0x060006FD RID: 1789 RVA: 0x0000638D File Offset: 0x0000458D
		public bool IsHtmlSideBar { get; set; } = true;

		// Token: 0x170001E2 RID: 482
		// (get) Token: 0x060006FE RID: 1790 RVA: 0x00006396 File Offset: 0x00004596
		// (set) Token: 0x060006FF RID: 1791 RVA: 0x0000639E File Offset: 0x0000459E
		public bool IsTimelineStatsEnabled { get; set; } = true;

		// Token: 0x170001E3 RID: 483
		// (get) Token: 0x06000700 RID: 1792 RVA: 0x000063A7 File Offset: 0x000045A7
		// (set) Token: 0x06000701 RID: 1793 RVA: 0x000063AF File Offset: 0x000045AF
		public bool IsShowAdvanceExitOption { get; set; }

		// Token: 0x170001E4 RID: 484
		// (get) Token: 0x06000702 RID: 1794 RVA: 0x000063B8 File Offset: 0x000045B8
		// (set) Token: 0x06000703 RID: 1795 RVA: 0x000063C0 File Offset: 0x000045C0
		public bool IsShowAndroidInputDebugSetting { get; set; } = true;

		// Token: 0x0400038B RID: 907
		private const string sConfigFilename = "bst_config";

		// Token: 0x0400038C RID: 908
		private static string sFilePath = string.Empty;

		// Token: 0x0400038D RID: 909
		private static volatile FeatureManager sInstance;

		// Token: 0x0400038E RID: 910
		private static object syncRoot = new object();
	}
}
