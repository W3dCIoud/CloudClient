﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200018E RID: 398
	public static class Assets
	{
		// Token: 0x0200018F RID: 399
		public static class Common
		{
			// Token: 0x04000750 RID: 1872
			public const string CheckboxUnchecked = "bgpcheckbox";

			// Token: 0x04000751 RID: 1873
			public const string CheckboxChecked = "bgpcheckbox_checked";
		}

		// Token: 0x02000190 RID: 400
		public static class MicroInstaller
		{
			// Token: 0x04000752 RID: 1874
			public const string CheckedGray = "checked_gray";

			// Token: 0x04000753 RID: 1875
			public const string UncheckedGray = "unchecked_gray";
		}

		// Token: 0x02000191 RID: 401
		public static class Topbar
		{
			// Token: 0x04000754 RID: 1876
			public const string SidebarExpand = "sidebar_show";

			// Token: 0x04000755 RID: 1877
			public const string SidebarCollapse = "sidebar_hide";
		}

		// Token: 0x02000192 RID: 402
		public static class Sidebar
		{
			// Token: 0x04000756 RID: 1878
			public const string Back = "sidebar_back";

			// Token: 0x04000757 RID: 1879
			public const string Controls = "sidebar_controls";

			// Token: 0x04000758 RID: 1880
			public const string Fullscreen = "sidebar_fullscreen";

			// Token: 0x04000759 RID: 1881
			public const string FullscreenMinimize = "sidebar_fullscreen_minimize";

			// Token: 0x0400075A RID: 1882
			public const string Gamepad = "sidebar_gamepad";

			// Token: 0x0400075B RID: 1883
			public const string Home = "sidebar_home";

			// Token: 0x0400075C RID: 1884
			public const string Location = "sidebar_location";

			// Token: 0x0400075D RID: 1885
			public const string LockCursor = "sidebar_lock_cursor";

			// Token: 0x0400075E RID: 1886
			public const string LockCursorActive = "sidebar_lock_cursor_active";

			// Token: 0x0400075F RID: 1887
			public const string Macro = "sidebar_macro";

			// Token: 0x04000760 RID: 1888
			public const string MediaFolder = "sidebar_media_folder";

			// Token: 0x04000761 RID: 1889
			public const string MIManager = "sidebar_mm";

			// Token: 0x04000762 RID: 1890
			public const string Operation = "sidebar_operation";

			// Token: 0x04000763 RID: 1891
			public const string OptionsClose = "sidebar_options_close";

			// Token: 0x04000764 RID: 1892
			public const string OptionsOpen = "sidebar_options_open";

			// Token: 0x04000765 RID: 1893
			public const string Overlay = "sidebar_overlay";

			// Token: 0x04000766 RID: 1894
			public const string OverlayInactive = "sidebar_overlay_inactive";

			// Token: 0x04000767 RID: 1895
			public const string OverlayPopup = "sidebar_overlay_popup";

			// Token: 0x04000768 RID: 1896
			public const string OverlayInactivePopup = "sidebar_overlay_inactive_popup";

			// Token: 0x04000769 RID: 1897
			public const string Rotate = "sidebar_rotate";

			// Token: 0x0400076A RID: 1898
			public const string Screenshot = "sidebar_screenshot";

			// Token: 0x0400076B RID: 1899
			public const string Shake = "sidebar_shake";

			// Token: 0x0400076C RID: 1900
			public const string Toggle = "sidebar_toggle";

			// Token: 0x0400076D RID: 1901
			public const string ToggleOff = "sidebar_toggle_off";

			// Token: 0x0400076E RID: 1902
			public const string Upfront = "sidebar_upfront";

			// Token: 0x0400076F RID: 1903
			public const string VideoCapture = "sidebar_video_capture";

			// Token: 0x04000770 RID: 1904
			public const string VideoLoading = "sidebar_video_loading";

			// Token: 0x04000771 RID: 1905
			public const string VideoCaptureActive = "sidebar_video_capture_active";

			// Token: 0x04000772 RID: 1906
			public const string Volume = "sidebar_volume";

			// Token: 0x04000773 RID: 1907
			public const string VolumePopup = "sidebar_volume_popup";

			// Token: 0x04000774 RID: 1908
			public const string VolumeMutedPopup = "sidebar_volume_muted_popup";

			// Token: 0x04000775 RID: 1909
			public const string VolumeMuted = "sidebar_volume_muted";

			// Token: 0x04000776 RID: 1910
			public const string VolumeUp = "sidebar_volume_up";

			// Token: 0x04000777 RID: 1911
			public const string VolumeDown = "sidebar_volume_down";

			// Token: 0x04000778 RID: 1912
			public const string StreamVideo = "sidebar_stream_video";

			// Token: 0x04000779 RID: 1913
			public const string Settings = "sidebar_settings";

			// Token: 0x0400077A RID: 1914
			public const string StreamVideoActive = "sidebar_stream_video_active";

			// Token: 0x0400077B RID: 1915
			public const string GameGuide = "sidebar_gameguide";

			// Token: 0x0400077C RID: 1916
			public const string GameGuideActive = "sidebar_gameguide_active";

			// Token: 0x0400077D RID: 1917
			public const string GameGuideInactive = "sidebar_gameguide_inactive";
		}

		// Token: 0x02000193 RID: 403
		public static class SettingsDropdown
		{
			// Token: 0x0400077E RID: 1918
			public const string ToggleOn = "toggle_on";

			// Token: 0x0400077F RID: 1919
			public const string ToggleOff = "toggle_off";
		}
	}
}
