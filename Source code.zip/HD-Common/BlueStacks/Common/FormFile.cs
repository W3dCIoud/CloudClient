﻿using System;
using System.IO;

namespace BlueStacks.Common
{
	// Token: 0x020001B1 RID: 433
	public class FormFile
	{
		// Token: 0x170003DD RID: 989
		// (get) Token: 0x06000E5D RID: 3677 RVA: 0x0000CD72 File Offset: 0x0000AF72
		// (set) Token: 0x06000E5E RID: 3678 RVA: 0x0000CD7A File Offset: 0x0000AF7A
		public string Name { get; set; }

		// Token: 0x170003DE RID: 990
		// (get) Token: 0x06000E5F RID: 3679 RVA: 0x0000CD83 File Offset: 0x0000AF83
		// (set) Token: 0x06000E60 RID: 3680 RVA: 0x0000CD8B File Offset: 0x0000AF8B
		public string ContentType { get; set; }

		// Token: 0x170003DF RID: 991
		// (get) Token: 0x06000E61 RID: 3681 RVA: 0x0000CD94 File Offset: 0x0000AF94
		// (set) Token: 0x06000E62 RID: 3682 RVA: 0x0000CD9C File Offset: 0x0000AF9C
		public string FilePath { get; set; }

		// Token: 0x170003E0 RID: 992
		// (get) Token: 0x06000E63 RID: 3683 RVA: 0x0000CDA5 File Offset: 0x0000AFA5
		// (set) Token: 0x06000E64 RID: 3684 RVA: 0x0000CDAD File Offset: 0x0000AFAD
		public Stream Stream { get; set; }
	}
}
