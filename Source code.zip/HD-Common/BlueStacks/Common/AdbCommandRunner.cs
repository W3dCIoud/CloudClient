﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Threading;
using Newtonsoft.Json.Linq;

namespace BlueStacks.Common
{
	// Token: 0x02000050 RID: 80
	public class AdbCommandRunner
	{
		// Token: 0x17000087 RID: 135
		// (get) Token: 0x060001B3 RID: 435 RVA: 0x00002CA1 File Offset: 0x00000EA1
		// (set) Token: 0x060001B4 RID: 436 RVA: 0x00002CA9 File Offset: 0x00000EA9
		public int Port { get; set; }

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x060001B5 RID: 437 RVA: 0x00002CB2 File Offset: 0x00000EB2
		// (set) Token: 0x060001B6 RID: 438 RVA: 0x00002CBA File Offset: 0x00000EBA
		public string Path { get; set; }

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x060001B7 RID: 439 RVA: 0x00002CC3 File Offset: 0x00000EC3
		// (set) Token: 0x060001B8 RID: 440 RVA: 0x00002CCB File Offset: 0x00000ECB
		public bool IsHostConnected { get; set; }

		// Token: 0x060001B9 RID: 441 RVA: 0x00010938 File Offset: 0x0000EB38
		public AdbCommandRunner(string vmName = "Android")
		{
			if (!string.IsNullOrEmpty(vmName))
			{
				this.mVmName = vmName;
				AdbCommandRunner.GUEST_URL = string.Format(CultureInfo.InvariantCulture, "http://127.0.0.1:{0}", new object[]
				{
					RegistryManager.Instance.Guest[this.mVmName].BstAndroidPort
				});
			}
			this.IsHostConnected = this.EnableADB();
		}

		// Token: 0x060001BA RID: 442 RVA: 0x000109B0 File Offset: 0x0000EBB0
		private static bool CheckIfGuestCommandSuccess(string res)
		{
			string text = JObject.Parse(res)["result"].ToString().Trim();
			if (string.Equals(text, "ok", StringComparison.InvariantCultureIgnoreCase))
			{
				return true;
			}
			Logger.Error("result: {0}", new object[]
			{
				text
			});
			return false;
		}

		// Token: 0x060001BB RID: 443 RVA: 0x00002CD4 File Offset: 0x00000ED4
		public void Dispose()
		{
			this.DisableADB();
		}

		// Token: 0x060001BC RID: 444 RVA: 0x00010A00 File Offset: 0x0000EC00
		private bool EnableADB()
		{
			string api = "connectHost";
			return this.HitGuestAPI(api);
		}

		// Token: 0x060001BD RID: 445 RVA: 0x00010A1C File Offset: 0x0000EC1C
		private bool DisableADB()
		{
			string api = "disconnectHost";
			return this.HitGuestAPI(api);
		}

		// Token: 0x060001BE RID: 446 RVA: 0x00010A38 File Offset: 0x0000EC38
		private bool HitGuestAPI(string api)
		{
			try
			{
				return AdbCommandRunner.CheckIfGuestCommandSuccess(HTTPUtils.SendRequestToGuest(api, null, this.mVmName, 0, null, false, 1, 0));
			}
			catch (Exception ex)
			{
				Logger.Error("Error in Sending request {0} to guest {1}", new object[]
				{
					api,
					ex.ToString()
				});
			}
			return false;
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x060001BF RID: 447 RVA: 0x00002CDD File Offset: 0x00000EDD
		// (set) Token: 0x060001C0 RID: 448 RVA: 0x00002CE5 File Offset: 0x00000EE5
		public AdbCommandRunner.OutputLineHandlerDelegate OutputLineHandler { get; set; }

		// Token: 0x060001C1 RID: 449 RVA: 0x00010A94 File Offset: 0x0000EC94
		public bool Connect(string vmName)
		{
			this.Port = RegistryManager.Instance.Guest[vmName].BstAdbPort;
			this.Path = System.IO.Path.Combine(RegistryStrings.InstallDir, "HD-Adb.exe");
			if (!this.RunInternal(string.Format(CultureInfo.InvariantCulture, "connect 127.0.0.1:{0}", new object[]
			{
				this.Port
			}), true))
			{
				return false;
			}
			this.RunInternal("devices", true);
			return true;
		}

		// Token: 0x060001C2 RID: 450 RVA: 0x00010B10 File Offset: 0x0000ED10
		private bool RunInternal(string cmd, bool retry = true)
		{
			Logger.Info("ADB CMD: " + cmd);
			bool result;
			using (Process process = new Process())
			{
				process.StartInfo.FileName = this.Path;
				process.StartInfo.Arguments = cmd;
				process.StartInfo.UseShellExecute = false;
				process.StartInfo.RedirectStandardOutput = true;
				process.StartInfo.RedirectStandardError = true;
				process.StartInfo.CreateNoWindow = true;
				process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs evt)
				{
					Logger.Info("ADB OUT: " + evt.Data);
				};
				process.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs evt)
				{
					if (!string.IsNullOrEmpty(evt.Data))
					{
						Logger.Info("ERR: " + evt.Data);
					}
				};
				process.Start();
				process.BeginOutputReadLine();
				process.BeginErrorReadLine();
				process.WaitForExit();
				int num = process.ExitCode;
				Logger.Info("ADB EXIT: " + num.ToString());
				if (num != 0 && retry)
				{
					Thread.Sleep(4000);
					num = (this.RunInternal(cmd, false) ? 0 : 1);
				}
				result = (num == 0);
			}
			return result;
		}

		// Token: 0x060001C3 RID: 451 RVA: 0x00010C44 File Offset: 0x0000EE44
		public bool Push(string localPath, string remotePath)
		{
			Logger.Info("Pushing {0} to {1}", new object[]
			{
				localPath,
				remotePath
			});
			return this.RunInternal(string.Format(CultureInfo.InvariantCulture, "-s 127.0.0.1:{0} push \"{1}\" \"{2}\"", new object[]
			{
				this.Port,
				localPath,
				remotePath
			}), true);
		}

		// Token: 0x060001C4 RID: 452 RVA: 0x00010C9C File Offset: 0x0000EE9C
		public bool Pull(string filePath, string destPath)
		{
			Logger.Info("Pull file {0} in {1}", new object[]
			{
				filePath,
				destPath
			});
			return this.RunInternal(string.Format(CultureInfo.InvariantCulture, "-s 127.0.0.1:{0} pull \"{1}\" \"{2}\"", new object[]
			{
				this.Port,
				filePath,
				destPath
			}), true);
		}

		// Token: 0x060001C5 RID: 453 RVA: 0x00002CEE File Offset: 0x00000EEE
		public bool RunShell(string fmt, params object[] args)
		{
			return this.RunShell(string.Format(CultureInfo.InvariantCulture, fmt, args));
		}

		// Token: 0x060001C6 RID: 454 RVA: 0x00002D02 File Offset: 0x00000F02
		public bool RunShell(string cmd)
		{
			Logger.Info("RunShell: " + cmd);
			return this.RunInternal(string.Format(CultureInfo.InvariantCulture, "-s 127.0.0.1:{0} shell {1}", new object[]
			{
				this.Port,
				cmd
			}), true);
		}

		// Token: 0x060001C7 RID: 455 RVA: 0x00010CF4 File Offset: 0x0000EEF4
		public bool RunShellScript(string[] cmdList)
		{
			if (cmdList != null)
			{
				foreach (string cmd in cmdList)
				{
					if (!this.RunShell(cmd))
					{
						return false;
					}
				}
			}
			return true;
		}

		// Token: 0x060001C8 RID: 456 RVA: 0x00002D42 File Offset: 0x00000F42
		public bool RunShellPrivileged(string fmt, params object[] cmd)
		{
			return this.RunShellPrivileged(string.Format(CultureInfo.InvariantCulture, fmt, cmd));
		}

		// Token: 0x060001C9 RID: 457 RVA: 0x00010D24 File Offset: 0x0000EF24
		public bool RunShellPrivileged(string cmd)
		{
			Logger.Info("RunShellPrivileged: " + cmd);
			return this.RunInternal(string.Format(CultureInfo.InvariantCulture, "-s 127.0.0.1:{0} shell {1} -c {2}", new object[]
			{
				this.Port,
				"/system/xbin/bstk/su",
				cmd
			}), true);
		}

		// Token: 0x060001CA RID: 458 RVA: 0x00010D78 File Offset: 0x0000EF78
		public bool RunShellScriptPrivileged(string[] cmdList)
		{
			if (cmdList != null)
			{
				foreach (string cmd in cmdList)
				{
					if (!this.RunShellPrivileged(cmd))
					{
						return false;
					}
				}
			}
			return true;
		}

		// Token: 0x040000AE RID: 174
		private const string SU_PATH = "/system/xbin/bstk/su";

		// Token: 0x040000AF RID: 175
		private static string GUEST_URL = string.Format(CultureInfo.InvariantCulture, "http://127.0.0.1:{0}", new object[]
		{
			RegistryManager.Instance.Guest["Android"].BstAndroidPort
		});

		// Token: 0x040000B2 RID: 178
		private string mVmName = "Android";

		// Token: 0x02000051 RID: 81
		// (Invoke) Token: 0x060001CD RID: 461
		public delegate void OutputLineHandlerDelegate(string line);
	}
}
