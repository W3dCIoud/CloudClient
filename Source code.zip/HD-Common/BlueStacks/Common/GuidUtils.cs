﻿using System;
using System.IO;
using Microsoft.Win32;

namespace BlueStacks.Common
{
	// Token: 0x020001AD RID: 429
	public static class GuidUtils
	{
		// Token: 0x06000E47 RID: 3655 RVA: 0x00036F6C File Offset: 0x0003516C
		public static string ReuseOrGenerateMachineId()
		{
			string text = "";
			try
			{
				string blueStacksMachineId = GuidUtils.GetBlueStacksMachineId();
				if (!string.IsNullOrEmpty(blueStacksMachineId))
				{
					return blueStacksMachineId;
				}
				text = Guid.NewGuid().ToString();
				GuidUtils.SetBlueStacksMachineId(text);
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't generate/find Machine ID. Ex: {0}", new object[]
				{
					ex.Message
				});
			}
			return text;
		}

		// Token: 0x06000E48 RID: 3656 RVA: 0x00036FE0 File Offset: 0x000351E0
		public static string ReuseOrGenerateVersionId()
		{
			string text = "";
			try
			{
				string blueStacksVersionId = GuidUtils.GetBlueStacksVersionId();
				if (!string.IsNullOrEmpty(blueStacksVersionId))
				{
					return blueStacksVersionId;
				}
				text = Guid.NewGuid().ToString();
				GuidUtils.SetBlueStacksVersionId(text);
			}
			catch (Exception ex)
			{
				Logger.Error("Couldn't generate/find Version ID. Ex: {0}", new object[]
				{
					ex.Message
				});
			}
			return text;
		}

		// Token: 0x06000E49 RID: 3657 RVA: 0x0000CCAD File Offset: 0x0000AEAD
		public static string GetBlueStacksMachineId()
		{
			if (string.IsNullOrEmpty(GuidUtils.sBlueStacksMachineId))
			{
				GuidUtils.sBlueStacksMachineId = StringUtils.GetControlCharFreeString(GuidUtils.GetIdFromRegistryOrFile("MachineID").Trim());
			}
			return GuidUtils.sBlueStacksMachineId;
		}

		// Token: 0x06000E4A RID: 3658 RVA: 0x0000CCD9 File Offset: 0x0000AED9
		public static bool SetBlueStacksMachineId(string newId)
		{
			return GuidUtils.SetIdInRegistryAndFile("MachineID", newId);
		}

		// Token: 0x06000E4B RID: 3659 RVA: 0x0000CCE6 File Offset: 0x0000AEE6
		public static string GetBlueStacksVersionId()
		{
			if (string.IsNullOrEmpty(GuidUtils.sBlueStacksVersionId))
			{
				GuidUtils.sBlueStacksVersionId = StringUtils.GetControlCharFreeString(GuidUtils.GetIdFromRegistryOrFile("VersionMachineId_4.190.0.5002").Trim());
			}
			return GuidUtils.sBlueStacksVersionId;
		}

		// Token: 0x06000E4C RID: 3660 RVA: 0x0000CD12 File Offset: 0x0000AF12
		public static bool SetBlueStacksVersionId(string newId)
		{
			return GuidUtils.SetIdInRegistryAndFile("VersionMachineId_4.190.0.5002", newId);
		}

		// Token: 0x06000E4D RID: 3661 RVA: 0x00037054 File Offset: 0x00035254
		public static string GetIdFromRegistryOrFile(string id)
		{
			string text = "";
			text = (string)RegistryUtils.GetRegistryValue("Software\\BlueStacksInstaller", id, "", RegistryKeyKind.HKEY_LOCAL_MACHINE);
			if (!string.IsNullOrEmpty(text))
			{
				return text;
			}
			try
			{
				string text2 = Path.Combine(new DirectoryInfo(ShortcutHelper.CommonDesktopPath).Parent.FullName, "BlueStacks");
				if (!Directory.Exists(text2))
				{
					Directory.CreateDirectory(text2);
				}
				string path = Path.Combine(text2, id);
				if (File.Exists(path))
				{
					string text3 = File.ReadAllText(path);
					if (!string.IsNullOrEmpty(text3))
					{
						text = text3;
					}
				}
			}
			catch
			{
			}
			if (!string.IsNullOrEmpty(text))
			{
				return text;
			}
			RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\BlueStacksInstaller");
			if (registryKey != null)
			{
				text = (string)registryKey.GetValue(id, "");
			}
			return text;
		}

		// Token: 0x06000E4E RID: 3662 RVA: 0x00037120 File Offset: 0x00035320
		public static bool SetIdInRegistryAndFile(string id, string value)
		{
			bool result = false;
			value = ((value != null) ? value.Trim() : null);
			result = RegistryUtils.SetRegistryValue("Software\\BlueStacksInstaller", id, value, RegistryValueKind.String, RegistryKeyKind.HKEY_LOCAL_MACHINE);
			try
			{
				string text = Path.Combine(new DirectoryInfo(ShortcutHelper.CommonDesktopPath).Parent.FullName, "BlueStacks");
				if (!Directory.Exists(text))
				{
					Directory.CreateDirectory(text);
				}
				string path = Path.Combine(text, id);
				if (File.Exists(path))
				{
					File.Delete(path);
				}
				File.WriteAllText(path, value);
				result = true;
			}
			catch (Exception ex)
			{
				Logger.Warning("Failed to write in in file. Error: " + ex.Message);
			}
			try
			{
				Registry.CurrentUser.CreateSubKey("Software\\BlueStacksInstaller").SetValue(id, value);
				result = true;
			}
			catch (Exception ex2)
			{
				Logger.Warning("Failed to write id in HKCU. Error: " + ex2.Message);
			}
			return result;
		}

		// Token: 0x040007AE RID: 1966
		private static string sBlueStacksMachineId;

		// Token: 0x040007AF RID: 1967
		private static string sBlueStacksVersionId;
	}
}
