﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000057 RID: 87
	[AttributeUsage(AttributeTargets.Parameter, Inherited = false)]
	internal class CallerMemberNameAttribute : Attribute
	{
	}
}
