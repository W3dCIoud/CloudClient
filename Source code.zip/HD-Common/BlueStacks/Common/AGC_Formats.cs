﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000D7 RID: 215
	public static class AGC_Formats
	{
		// Token: 0x0400030F RID: 783
		public const string WAIT_FOR = "wait {0}";

		// Token: 0x04000310 RID: 784
		public const string MOUSE_DOWN = "mouseDown {0} {1}";

		// Token: 0x04000311 RID: 785
		public const string MOUSE_UP = "mouseUp {0} {1}";

		// Token: 0x04000312 RID: 786
		public const string MOUSE_MOVE = "mouseMove {0} {1}";

		// Token: 0x04000313 RID: 787
		public const string KEY_DOWN = "keyDown {0}";

		// Token: 0x04000314 RID: 788
		public const string KEY_UP = "keyUp {0}";

		// Token: 0x04000315 RID: 789
		public const string TEXT = "text {0}";

		// Token: 0x04000316 RID: 790
		public const string BACKSPACE = "text backspace {0}";

		// Token: 0x04000317 RID: 791
		public const string MOUSE_WHEEL = "mouseWheel {0} {1} {2}";
	}
}
