﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020000D9 RID: 217
	public static class DisplaySettingConstants
	{
		// Token: 0x0400031C RID: 796
		public const string Dpi160 = "550";

		// Token: 0x0400031D RID: 797
		public const string Dpi240 = "800";

		// Token: 0x0400031E RID: 798
		public const string Dpi320 = "1200";

		// Token: 0x0400031F RID: 799
		public const string Resolution960x540 = "960 x 540";

		// Token: 0x04000320 RID: 800
		public const string Resolution1280x720 = "1280 x 720";

		// Token: 0x04000321 RID: 801
		public const string Resolution1600x900 = "1600 x 900";

		// Token: 0x04000322 RID: 802
		public const string Resolution1920x1080 = "1920 x 1080";

		// Token: 0x04000323 RID: 803
		public const string Resolution2560x1440 = "2560 x 1440";

		// Token: 0x04000324 RID: 804
		public const string Resolution540x960 = "540 x 960";

		// Token: 0x04000325 RID: 805
		public const string Resolution720x1280 = "720 x 1280";

		// Token: 0x04000326 RID: 806
		public const string Resolution900x1600 = "900 x 1600";

		// Token: 0x04000327 RID: 807
		public const string Resolution1080x1920 = "1080 x 1920";

		// Token: 0x04000328 RID: 808
		public const string Resolution1440x2560 = "1440 x 2560";
	}
}
