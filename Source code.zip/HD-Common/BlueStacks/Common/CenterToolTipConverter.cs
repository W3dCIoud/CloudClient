﻿using System;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using System.Windows.Markup;

namespace BlueStacks.Common
{
	// Token: 0x020000D2 RID: 210
	public class CenterToolTipConverter : MarkupExtension, IMultiValueConverter
	{
		// Token: 0x0600057D RID: 1405 RVA: 0x0001D748 File Offset: 0x0001B948
		public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
		{
			if (values.FirstOrDefault((object v) => v == DependencyProperty.UnsetValue) != null)
			{
				return double.NaN;
			}
			double num = 0.0;
			double num2 = 0.0;
			if (values != null)
			{
				num = (double)values[0];
				num2 = (double)values[1];
			}
			return num / 2.0 - num2 / 2.0;
		}

		// Token: 0x0600057E RID: 1406 RVA: 0x00004AC9 File Offset: 0x00002CC9
		public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600057F RID: 1407 RVA: 0x000054B6 File Offset: 0x000036B6
		public override object ProvideValue(IServiceProvider serviceProvider)
		{
			return this;
		}
	}
}
