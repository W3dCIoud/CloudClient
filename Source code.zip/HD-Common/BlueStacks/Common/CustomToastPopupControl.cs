﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace BlueStacks.Common
{
	// Token: 0x020000ED RID: 237
	public class CustomToastPopupControl : UserControl, IComponentConnector
	{
		// Token: 0x06000691 RID: 1681 RVA: 0x00006038 File Offset: 0x00004238
		public CustomToastPopupControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000692 RID: 1682 RVA: 0x00021B58 File Offset: 0x0001FD58
		public CustomToastPopupControl(Window window)
		{
			this.InitializeComponent();
			if (window != null)
			{
				this.ParentWindow = window;
				Grid grid = new Grid();
				object content = window.Content;
				window.Content = grid;
				grid.Children.Add(content as UIElement);
				grid.Children.Add(this);
			}
		}

		// Token: 0x06000693 RID: 1683 RVA: 0x00021BB0 File Offset: 0x0001FDB0
		public CustomToastPopupControl(UserControl control)
		{
			this.InitializeComponent();
			if (control != null)
			{
				this.ParentControl = control;
				Grid grid = new Grid();
				object content = control.Content;
				control.Content = grid;
				grid.Children.Add(content as UIElement);
				grid.Children.Add(this);
			}
		}

		// Token: 0x06000694 RID: 1684 RVA: 0x00021C08 File Offset: 0x0001FE08
		public void Init(Window window, string text, Brush background = null, Brush borderBackground = null, HorizontalAlignment horizontalAlign = HorizontalAlignment.Center, VerticalAlignment verticalAlign = VerticalAlignment.Bottom, Thickness? margin = null, int cornerRadius = 12, Thickness? toastTextMargin = null, Brush toastTextForeground = null, bool isShowCloseIcon = false)
		{
			this.mToastIcon.Visibility = Visibility.Collapsed;
			if (window != null)
			{
				this.ParentWindow = window;
			}
			if (isShowCloseIcon)
			{
				this.mToastCloseIcon.Visibility = Visibility.Visible;
			}
			else
			{
				this.mToastCloseIcon.Visibility = Visibility.Collapsed;
			}
			this.InitProperties(0, text, background, borderBackground, horizontalAlign, verticalAlign, margin, cornerRadius, toastTextMargin, toastTextForeground, isShowCloseIcon);
		}

		// Token: 0x06000695 RID: 1685 RVA: 0x00021C64 File Offset: 0x0001FE64
		public void Init(UserControl control, string text, Brush background = null, Brush borderBackground = null, HorizontalAlignment horizontalAlign = HorizontalAlignment.Center, VerticalAlignment verticalAlign = VerticalAlignment.Bottom, Thickness? margin = null, int cornerRadius = 12, Thickness? toastTextMargin = null, Brush toastTextForeground = null)
		{
			this.mToastIcon.Visibility = Visibility.Collapsed;
			if (control != null)
			{
				this.ParentControl = control;
			}
			this.InitProperties(1, text, background, borderBackground, horizontalAlign, verticalAlign, margin, cornerRadius, toastTextMargin, toastTextForeground, false);
		}

		// Token: 0x06000696 RID: 1686 RVA: 0x00021CA0 File Offset: 0x0001FEA0
		private void InitProperties(int callType, string text, Brush background = null, Brush borderBackground = null, HorizontalAlignment horizontalAlign = HorizontalAlignment.Center, VerticalAlignment verticalAlign = VerticalAlignment.Bottom, Thickness? margin = null, int cornerRadius = 12, Thickness? toastTextMargin = null, Brush toastTextForeground = null, bool isCloseIconVisible = false)
		{
			if (background == null)
			{
				this.mToastPopupBorder.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#AE000000"));
			}
			else
			{
				this.mToastPopupBorder.Background = background;
			}
			if (borderBackground == null)
			{
				this.mToastPopupBorder.BorderThickness = new Thickness(0.0);
			}
			else
			{
				this.mToastPopupBorder.BorderBrush = borderBackground;
				this.mToastPopupBorder.BorderThickness = new Thickness(1.0);
			}
			if (margin == null)
			{
				this.mToastPopupBorder.Margin = new Thickness(0.0, 0.0, 0.0, 40.0);
			}
			else
			{
				this.mToastPopupBorder.Margin = margin.Value;
			}
			if (toastTextMargin == null)
			{
				this.mToastTextblock.Margin = new Thickness(0.0);
			}
			else
			{
				this.mToastTextblock.Margin = toastTextMargin.Value;
			}
			if (toastTextForeground == null)
			{
				this.mToastTextblock.Foreground = Brushes.White;
			}
			else
			{
				this.mToastTextblock.Foreground = toastTextForeground;
			}
			this.mToastPopupBorder.CornerRadius = new CornerRadius((double)cornerRadius);
			this.mToastTextblock.Text = text;
			this.mToastPopupBorder.VerticalAlignment = verticalAlign;
			this.mToastPopupBorder.HorizontalAlignment = horizontalAlign;
			this.mToastTextblock.TextWrapping = TextWrapping.WrapWithOverflow;
			if (callType == 0)
			{
				this.mToastTextblock.MaxWidth = this.ParentWindow.ActualWidth - (double)cornerRadius - 15.0;
			}
			else
			{
				this.mToastTextblock.MaxWidth = this.ParentControl.ActualWidth - (double)cornerRadius - 15.0;
			}
			this.mToastTextblock.TextAlignment = TextAlignment.Center;
			if (isCloseIconVisible)
			{
				this.mToastTextblock.MaxWidth = this.ParentWindow.ActualWidth - (double)cornerRadius - 30.0;
			}
		}

		// Token: 0x06000697 RID: 1687 RVA: 0x00021E94 File Offset: 0x00020094
		public void AddImage(string imageName, double height = 0.0, double width = 0.0, Thickness? margin = null)
		{
			this.mToastIcon.ImageName = imageName;
			if (height != 0.0)
			{
				this.mToastIcon.Height = height;
			}
			if (width != 0.0)
			{
				this.mToastIcon.Width = width;
			}
			if (margin != null)
			{
				this.mToastIcon.Margin = margin.Value;
			}
			this.mToastIcon.Visibility = Visibility.Visible;
		}

		// Token: 0x06000698 RID: 1688 RVA: 0x00021F04 File Offset: 0x00020104
		public void ShowPopup(double seconds = 1.3)
		{
			base.Visibility = Visibility.Visible;
			base.Opacity = 0.0;
			DoubleAnimation doubleAnimation = new DoubleAnimation
			{
				From = new double?(0.0),
				To = new double?(seconds),
				Duration = new Duration(TimeSpan.FromSeconds(0.3))
			};
			Storyboard storyboard = new Storyboard();
			storyboard.Children.Add(doubleAnimation);
			Storyboard.SetTarget(doubleAnimation, this);
			Storyboard.SetTargetProperty(doubleAnimation, new PropertyPath(UIElement.OpacityProperty));
			storyboard.Completed += delegate(object <p0>, EventArgs <p1>)
			{
				this.Visibility = Visibility.Visible;
				DoubleAnimation doubleAnimation2 = new DoubleAnimation
				{
					From = new double?(seconds),
					To = new double?(0.0),
					FillBehavior = FillBehavior.Stop,
					BeginTime = new TimeSpan?(TimeSpan.FromSeconds(seconds)),
					Duration = new Duration(TimeSpan.FromSeconds(seconds / 2.0))
				};
				Storyboard storyboard2 = new Storyboard();
				storyboard2.Children.Add(doubleAnimation2);
				Storyboard.SetTarget(doubleAnimation2, this);
				Storyboard.SetTargetProperty(doubleAnimation2, new PropertyPath(UIElement.OpacityProperty));
				storyboard2.Completed += delegate(object <p0>, EventArgs <p1>)
				{
					this.Visibility = Visibility.Collapsed;
				};
				storyboard2.Begin();
			};
			storyboard.Begin();
		}

		// Token: 0x06000699 RID: 1689 RVA: 0x00006046 File Offset: 0x00004246
		private void ToastCloseIcon_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			base.Visibility = Visibility.Collapsed;
		}

		// Token: 0x0600069A RID: 1690 RVA: 0x00021FC0 File Offset: 0x000201C0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			Uri resourceLocator = new Uri("/HD-Common;component/uielements/customtoastpopupcontrol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		// Token: 0x0600069B RID: 1691 RVA: 0x000035E3 File Offset: 0x000017E3
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		// Token: 0x0600069C RID: 1692 RVA: 0x00021FF0 File Offset: 0x000201F0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Performance", "CA1800:DoNotCastUnnecessarily")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.mToastPopupBorder = (Border)target;
				return;
			case 2:
				this.mToastIcon = (CustomPictureBox)target;
				return;
			case 3:
				this.mToastTextblock = (TextBlock)target;
				return;
			case 4:
				this.mToastCloseIcon = (CustomPictureBox)target;
				return;
			default:
				this._contentLoaded = true;
				return;
			}
		}

		// Token: 0x04000382 RID: 898
		private Window ParentWindow;

		// Token: 0x04000383 RID: 899
		private UserControl ParentControl;

		// Token: 0x04000384 RID: 900
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal Border mToastPopupBorder;

		// Token: 0x04000385 RID: 901
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mToastIcon;

		// Token: 0x04000386 RID: 902
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal TextBlock mToastTextblock;

		// Token: 0x04000387 RID: 903
		[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
		internal CustomPictureBox mToastCloseIcon;

		// Token: 0x04000388 RID: 904
		private bool _contentLoaded;
	}
}
