﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x0200011E RID: 286
	public enum EngineStatsEvent
	{
		// Token: 0x04000518 RID: 1304
		player_launched,
		// Token: 0x04000519 RID: 1305
		android_file_integrity_passed,
		// Token: 0x0400051A RID: 1306
		graphics_inited,
		// Token: 0x0400051B RID: 1307
		vm_launched,
		// Token: 0x0400051C RID: 1308
		vm_running
	}
}
