﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace BlueStacks.Common
{
	// Token: 0x02000087 RID: 135
	public class ButtonCornerRadiusMultiConverter : IMultiValueConverter
	{
		// Token: 0x06000361 RID: 865 RVA: 0x00014A18 File Offset: 0x00012C18
		public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
		{
			if (values == null)
			{
				return Binding.DoNothing;
			}
			CornerRadius cornerRadius = (CornerRadius)values[0];
			double topLeft = (cornerRadius.TopLeft == 0.0) ? 0.0 : ((double)values[1] / cornerRadius.TopLeft);
			double topRight = (cornerRadius.TopRight == 0.0) ? 0.0 : ((double)values[1] / cornerRadius.TopRight);
			double bottomRight = (cornerRadius.BottomRight == 0.0) ? 0.0 : ((double)values[1] / cornerRadius.BottomRight);
			double bottomLeft = (cornerRadius.BottomLeft == 0.0) ? 0.0 : ((double)values[1] / cornerRadius.BottomLeft);
			return new CornerRadius(topLeft, topRight, bottomRight, bottomLeft);
		}

		// Token: 0x06000362 RID: 866 RVA: 0x00003A87 File Offset: 0x00001C87
		public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
		{
			return null;
		}
	}
}
