﻿using System;
using System.Runtime.InteropServices;

namespace BlueStacks.Common
{
	// Token: 0x020001F1 RID: 497
	public struct COPYDATASTRUCT
	{
		// Token: 0x17000418 RID: 1048
		// (get) Token: 0x06000F7F RID: 3967 RVA: 0x0000D87B File Offset: 0x0000BA7B
		// (set) Token: 0x06000F80 RID: 3968 RVA: 0x0000D883 File Offset: 0x0000BA83
		public IntPtr dwData { readonly get; set; }

		// Token: 0x17000419 RID: 1049
		// (get) Token: 0x06000F81 RID: 3969 RVA: 0x0000D88C File Offset: 0x0000BA8C
		// (set) Token: 0x06000F82 RID: 3970 RVA: 0x0000D894 File Offset: 0x0000BA94
		public int cbData { readonly get; set; }

		// Token: 0x1700041A RID: 1050
		// (get) Token: 0x06000F83 RID: 3971 RVA: 0x0000D89D File Offset: 0x0000BA9D
		// (set) Token: 0x06000F84 RID: 3972 RVA: 0x0000D8A5 File Offset: 0x0000BAA5
		public IntPtr lpData { readonly get; set; }

		// Token: 0x06000F85 RID: 3973 RVA: 0x0003B6EC File Offset: 0x000398EC
		public static COPYDATASTRUCT CreateForString(int dwData, string value, bool _ = false)
		{
			return new COPYDATASTRUCT
			{
				dwData = (IntPtr)dwData,
				cbData = ((value != null) ? value.Length : 1) * 2,
				lpData = Marshal.StringToHGlobalUni(value)
			};
		}
	}
}
