﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace BlueStacks.Common
{
	// Token: 0x02000093 RID: 147
	public static class DictionaryExtensions
	{
		// Token: 0x06000395 RID: 917 RVA: 0x0001519C File Offset: 0x0001339C
		public static void ClearSync<TKey, TValue>(this Dictionary<TKey, TValue> dic)
		{
			if (dic != null)
			{
				object syncRoot = ((ICollection)dic).SyncRoot;
				lock (syncRoot)
				{
					dic.Clear();
				}
			}
		}

		// Token: 0x06000396 RID: 918 RVA: 0x000151D8 File Offset: 0x000133D8
		public static void ClearAddRange<TKey, TValue>(this Dictionary<TKey, TValue> dic, Dictionary<TKey, TValue> dicToAdd)
		{
			if (dic != null)
			{
				object syncRoot = ((ICollection)dic).SyncRoot;
				lock (syncRoot)
				{
					dic.Clear();
					if (dicToAdd != null && dicToAdd.Count > 0)
					{
						foreach (KeyValuePair<TKey, TValue> keyValuePair in dicToAdd)
						{
							dic.Add(keyValuePair.Key, keyValuePair.Value);
						}
					}
				}
			}
		}
	}
}
