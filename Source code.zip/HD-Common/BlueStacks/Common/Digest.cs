﻿using System;
using System.Globalization;

namespace BlueStacks.Common
{
	// Token: 0x020001DF RID: 479
	public class Digest
	{
		// Token: 0x17000406 RID: 1030
		// (get) Token: 0x06000F49 RID: 3913 RVA: 0x0000D5D1 File Offset: 0x0000B7D1
		// (set) Token: 0x06000F4A RID: 3914 RVA: 0x0000D5D9 File Offset: 0x0000B7D9
		public uint A { get; set; }

		// Token: 0x17000407 RID: 1031
		// (get) Token: 0x06000F4B RID: 3915 RVA: 0x0000D5E2 File Offset: 0x0000B7E2
		// (set) Token: 0x06000F4C RID: 3916 RVA: 0x0000D5EA File Offset: 0x0000B7EA
		public uint B { get; set; }

		// Token: 0x17000408 RID: 1032
		// (get) Token: 0x06000F4D RID: 3917 RVA: 0x0000D5F3 File Offset: 0x0000B7F3
		// (set) Token: 0x06000F4E RID: 3918 RVA: 0x0000D5FB File Offset: 0x0000B7FB
		public uint C { get; set; }

		// Token: 0x17000409 RID: 1033
		// (get) Token: 0x06000F4F RID: 3919 RVA: 0x0000D604 File Offset: 0x0000B804
		// (set) Token: 0x06000F50 RID: 3920 RVA: 0x0000D60C File Offset: 0x0000B80C
		public uint D { get; set; }

		// Token: 0x06000F51 RID: 3921 RVA: 0x0000D615 File Offset: 0x0000B815
		public Digest()
		{
			this.A = 1732584193U;
			this.B = 4023233417U;
			this.C = 2562383102U;
			this.D = 271733878U;
		}

		// Token: 0x06000F52 RID: 3922 RVA: 0x0003ABC8 File Offset: 0x00038DC8
		public string GetString()
		{
			return Digest.ReverseByte(this.A).ToString("X8", CultureInfo.InvariantCulture) + Digest.ReverseByte(this.B).ToString("X8", CultureInfo.InvariantCulture) + Digest.ReverseByte(this.C).ToString("X8", CultureInfo.InvariantCulture) + Digest.ReverseByte(this.D).ToString("X8", CultureInfo.InvariantCulture);
		}

		// Token: 0x06000F53 RID: 3923 RVA: 0x0000D649 File Offset: 0x0000B849
		private static uint ReverseByte(uint uiNumber)
		{
			return (uiNumber & 255U) << 24 | uiNumber >> 24 | (uiNumber & 16711680U) >> 8 | (uiNumber & 65280U) << 8;
		}
	}
}
