﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x020001EE RID: 494
	public enum ComRegistrarCodes
	{
		// Token: 0x04000C10 RID: 3088
		SUCCESS,
		// Token: 0x04000C11 RID: 3089
		ALREADY_RUNNING,
		// Token: 0x04000C12 RID: 3090
		INVALID_ARGS,
		// Token: 0x04000C13 RID: 3091
		UNHANDLED_EXCEPTION,
		// Token: 0x04000C14 RID: 3092
		NON_ADMIN_CONTEXT,
		// Token: 0x04000C15 RID: 3093
		REGISTRATION_FAILED = 10
	}
}
