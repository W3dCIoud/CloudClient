﻿using System;

namespace BlueStacks.Common
{
	// Token: 0x02000103 RID: 259
	public enum ApplicationState
	{
		// Token: 0x0400046F RID: 1135
		Undefined,
		// Token: 0x04000470 RID: 1136
		Running,
		// Token: 0x04000471 RID: 1137
		NotRunning,
		// Token: 0x04000472 RID: 1138
		Booting,
		// Token: 0x04000473 RID: 1139
		Closing,
		// Token: 0x04000474 RID: 1140
		Deleting
	}
}
